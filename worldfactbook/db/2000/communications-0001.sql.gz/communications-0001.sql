SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68450d434212657ca2e66ac50ce34c7b5f2607ed97851986243b0c07a147c878',2000,'EH','Western Sahara','communications',14,'Telephones - main iines in use
Telephones - mobile cellular
Telephone system
domestic
internationai
Radio broadcast stations
Radios
Television broadcast stations
Televisions
Internet Service Providers (ISPs)
Communications - note
Telephones ■ main lines in use: 31,200 (1983);
note - there were 21 ,000 main lines in use in Kabul in
1998
Telephones - mobile cellular: NA
Telephone system:
domestic: very limited telephone and telegraph
service; in 1997, telecommunications links were
established between Mazar-e Sharif, Herat,
Kandahar, Jalalabad, and Kabul through satellite and
microwave systems
international: satellite earth stations - 1 1ntelsat (Indian
Ocean) linked only to Iran and 1 1ntersputnik (Atlantic
Ocean region); commercial satellite telephone center
in Ghazni
Radio broadcast stations: AM 7 (6 are inactive; the
active station is in Kabul), FM 1, shortwave 1
(broadcasts in Pushtu, Dari, Urdu, and English) (1 999)
Radios; 167,000(1999)
Television broadcast stations; at least 10 (one
government run central television station in Kabul and
regional stations in nine of the 30 provinces; the
regional stations operate on a reduced schedule; also,
in 1997, there was a station in Mazar-e Sharif
reaching four northern Afghanistan provinces) (1998)
Televisions: 100,000(1999)
Internet Service Providers (ISPs): NA
2
Afghanistan (continued)
I Transportation"
Railways;
fofa/;24.6 km
broad gauge: 9.6 km 1 .524-m gauge from Gushgy
(Turkmenistan) to Towraghondi; 15 km 1. 524-m
gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
Highways;
fofa/; 21,000 km
paved: 2,793 km
unpaved: tS, 207 km (1998 est.)
Waterways; 1,200 km; chiefiy Amu Darya, which
handies vessels up to about 500 DWT
Pipelines; petroleum products - Uzbekistan to
Bagram and Turkmenistan to Shindand; natural gas
180 km
Ports and harbors; Kheyrabad, Shir Khan
Airports; 46 (1999 est.)
Airports - with paved runways;
fofa/;14
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m: 2 [1 999 est.)
Airports - with unpaved runways;
total: 32
2,438 to 3,047 m: 5
1,524 to 2,437 m: 13
914 to 1,523 m: 3
under 914 m: 11 (1999 est.)
Heliports; 3 (1999 est.)
I" . ™MjnTaTy
Military branches; NA; note - the military does not
exist on a national basis; some elements of the former
Army, Air and Air Defense Forces, National Guard,
Border Guard Forces, National Police Force
(Sarandoi), and tribal militias still exist but are
factionalized among the various groups
Military manpower - military age; 22 years of age
Military manpower - availability;
males age 15-49: 6,401 ,980 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 3,432,236 (2000 est.)
Military manpower - reaching military age
annually;
mates; 244,958 (2000 est.)
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP; NA%
Background; In 1990 Albania ended 44 years of
xenophobic communist rule and established a
multiparty democracy. The transition has proven
difficult as corrupt governments have tried to deal with
severe unemployment, the collapse of a fraudulent
nationwide investment scheme, widespread
gangsterism, and massive refugee influxes from
neighboring Kosovo.
I Geo g r a p h y
Location; Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece and
Serbia and Montenegro
Geographic coordinates; 41 00 N, 20 00 E
Map references; Europe
Area;
total: 28,748 sq km
land: 27,398 sq km
water; 1,350 sqkm
Area - comparative; slightly smaller than Maryland
Land boundaries;
total: 720 km
border countries: Greece 282 km. The Former
Yugoslav Republic of Macedonia 1 51 km, Serbia and
Montenegro 287 km (1 14 km with Serbia, 173 km with
Montenegro)
Coastline; 362 km
Maritime claims;
continental shelf: 200-m depth or to the depth of
exploitation
terr/tor/a/ sea; 12 nm
Climate; mild temperate; cool, cloudy, wet winters;
hot, clear, dry summers; interior is cooler and wetter
Terrain; mostly mountains and hills; small plains
along coast
Elevation extremes;
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
|~ Tran s n a t i 6 n a I I s s u d s
Disputes - international; support to Islamic
militants worldwide by some factions; question over
which group should hold Afghanistan''s seat at the UN
Illicit drugs; world''s largest illicit opium producer,
surpassing Burma (potential production in 1999 -
1 ,670 metric tons; cultivation in 1999 - 51 ,500
hectares, a 23% increase over 1998); a major source
of hashish; increasing number of heroin-processing
laboratories being set up in the country; major political
factions in the country profit from drug trade
3
Albania (continued)
Natural resources; petroleum, natural gas, coal,
chromium, copper, timber, nickel, hydropower
Land use;
arable land: 2^%
permanent crops: 5%
permanent pastures: 1 5%
forests and woodland: 38%
other 21% (1993 est.)
Irrigated land; 3,410 sq km (1993 est.)
Natural hazards; destructive earthquakes; tsunamis
occur along southwestern coast
Environment - current issues; deforestation; soil
erosion; water pollution from Industrial and domestic
effluents
Environment - internationai agreements;
party to: Biodiversity, Climate Change, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note; strategic location along Strait of
Otranto (links Adriatic Sea to Ionian Sea and
Mediterranean Sea)
I People
Population; 3,490,435 (July 2000 est.)
Age structure;
0-14 years: 30% (male 545,329; female 507,589)
15-64 years: 63% (male 1 ,056,583; female
1,141,664)
65 years and over: 7% (male 104,086; female
135,184) (2000 est.)
Population growth rate; 0.26% (2000 est.)
Birth rate; 19.47 births/1 ,000 population (2000 est.)
Death rate; 6.5 deaths/1 ,000 population (2000 est.)
Net migration rate; -10.36 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate; 41 .33 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 71 .57 years
male: 68.75 years
female: 74.59 years (2000 est.)
Total fertility rate; 2.37 children born/woman
(2000 est.)
Nationality;
noun: Albanian(s)
adjective: Albanian
Ethnic groups; Albanian 95%, Greeks 3%, other 2%
(Vlachs, Gypsies, Serbs, and Bulgarians) (1989 est.)
note: in 1 989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions; Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
note: all mosques and churches were closed in 1967
and religious observances prohibited; in November
1990, Albania began allowing private religious
practice
Languages; Albanian (Tosk is the official dialect),
Greek
Literacy;
definition: age 9 and over can read and write
total population: 93% (1 997 est.)
male: NA%
female: NA%
f Government
Country name;
conventional long form: Republic of Albania
conventional short form: Albania
local long form: Republika e Shqiperise
local short form: Shqiperia
former: People''s Socialist Republic of Albania
Data code; AL
Government type; emerging democracy
Capital; Tirana
Administrative divisions; 36 districts (rrethe,
singular - rreth) and 1 municipality* (bashki); Berat,
Bulqize, Delvine, Devoll (Bilisht), Diber (Peshkopi),
Durres, Elbasan, Pier, Gjirokaster, Gramsh, Has
(Krume), Kavaje, Kolonje (Erseke), Korce, Kruje,
Kucove, Kukes, Kurbin, Lezhe, Librazhd, Lushnje,
MalesI e Madhe (Koplik), Mallakaster (Ballsh), Mat
(Burrel), Mirdite (Rreshen), Peqin, Permet, Pogradec,
Puke, Sarande, Shkoder, Skrapar (Corovode),
Tepelene, Tirane (Tirana), Tirana* (Tirana), Tropoje
(Bajram Curri), VIore
note: administrative divisions have the same names
as their administrative centers (exceptions have the
administrative center name following in parentheses)
Independence; 28 November 1912 (from Ottoman
Empire)
National holiday; Independence Day, 28 November
(1912)
Constitution; a new constitution was adopted by
popular referendum on 28 November 1 998; note - the
opposition Democratic Party boycotted the vote
Legal system; has not accepted compulsory ICJ
jurisdiction
Suffrage; 1 8 years of age; universal and compulsory
Executive branch;
chief of state: President of the Republic Rexhep
MEIDANI (since 24 July 1997)
head of government: Prime Minister llir META (since
29 October 1999)
cabinet: Council of Ministers nominated by the prime
minister and approved by the president
elections: president elected by the People''s Assembly
for a five-year term; election last held 24 July 1 997
(next to be held NA 2002); prime minister appointed
by the president
election results: Rexhep MEIDANI elected president;
People''s Assembly vote by number - total votes 122,
for 110, against 3, abstained 2, invalid 7
Legislative branch; unicameral People''s Assembly
or Kuvendi Popullor (155 seats; most members are
elected by direct popular vote and some by
proportional vote for four-year terms)
elections: last held 29 June 1997 (next to be held NA
2001)
election results: percent of vote by party - PS 53.36%,
PD 25.33%, PSD 2.5%, PBDNJ 2.78%, PBK 2.36%,
PAD 2.85%, PR 2.25%, PLL 3.09%, PDK 1.00%,
PBSD 0.84%; seats by party - PS 101 , PD 27, PSD 8,
PBDNJ 4, PBK 3, PAD 2, PR 2, PLL 2, PDK 1 , PBSD
1 , PUK 1 , independents 3
Judicial branch; Supreme Court, chairman of the
Supreme Court is elected by the People''s Assembly
for a four-year term
Political parties and leaders; Albanian Republican
Party or PR [Fatmir MEHDIU]; Albanian Socialist
Party or PS (formerly the Albania Workers Party)
[Fatos NANC, chairman]; Albanian United Right or
DBSH (includes PBK, Albanian Republican Party or
PRS, AND PDD) [Abaz ERMENJI]; Christian
Democratic Party or PDK [Zef BUSHATIj; Democratic
Alliance or PAD [Neritan CEKA); Democratic Party or
PD [Sail BERISHA); Democratic Party of the Right or
PDD [Petrit KALAKULA); Liberal Union Party [Teodor
LACOj; Movement of Legality Party or PLL [Ekrem
SPAHIA]; National Front (Balli Kombetar) or PBK
[Abaz ERMENJI); Party of National Unity or PUK
[Idajet BEQIRI); Right National Front [Hysni SELFCj;
Social Democratic Party or PSD [Skender G JINUSHIj;
Unity for Human Rights Party or PBDNJ [Vasil MELD,
chairman); note - Teodar LACD of the Liberal Union
Party was leader of the Social Democratic Union of
Albania or PBSD
International organization participation; BSEC,
CCC, CE, CEI, EAPC, EBRD, ECE, FAD, IAEA,
IBRD, ICAD, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILD,
IMF, IMD, Intelsat (nonsignatory user), Interpol, ICC,
IDM, ISC, ITU, Die, DPCW, CSCE, PFP, UN,
UNCTAD, UNESCD, UNIDD, UNDMIG, UPU, WFTU,
WHD, WIPD, WMD, WToD, WTrC (applicant)
Diplomatic representation in the US;
chief of mission: ^rr\\hassador Petrit BUSH ATI
chancery: 21 00 S Street NW, Washington, DC 20008
telephone: [1] {202) 223-4942
FAX; [1] (202) 628-7342
Diplomatic representation from the US;
chief of mission: Ambassador Joseph LIMPRECHT
embassy: Rruga Elbasanit 103, Tirana
mailing address: American Embassy, Tirana,
Department of State, Washington, DC 20521-9510
telephone: [355] (42) 47285 through 47289
FAX; [355] (42) 32222
Flag description; red with a black two-headed eagle
in the center','ea94afba9274a93d5cca564788360d0589dfe640d233a1010581cb8d1235469e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec98fec43c4cfa90960acaacbf72e525345ec539178ff073d0aef67f244dac42',2000,'DZ','Algeria','communications',21,'Telephones - main lines in use; 1.176 million
(1995)
Telephones - mobile cellular; 33,500 (1999)
Telephone system;
domestic: good service in north but sparse in south;
domestic satellite system with 12 earth stations (20
additional domestic earth stations are planned)
international: 5 submarine cables; microwave radio
relay to Italy, France, Spain, Morocco, and Tunisia;
coaxial cable to Morocco and Tunisia; participant in
Medarabtel; satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean), 1 InterSputnik,
and 1 Arabsat
Radio broadcast stations; AM 25, FM 1 , shortwave
8(1999)
Radios; 7.1 million (1997)
Television broadcast stations; 18 (not including
low-power stations) (1999)
Televisions; 3.1 million (1997)
Internet Service Providers (ISPs); 1 (1999)
I f Tali sport a t ion
Railways;
tofa/; 4,820 km (301 km electrified; 215 km double
track)
standard gauge: 3,664 km 1.435-m gauge (301 km
electrified; 215 km double track)
narrow gauge: 1 ,1 56 km 1 .055-m gauge (1 996)
Highways;
total: 104,000 km
paved: 71 ,656 km (including 640 km of expressways)
unpaved: 32,344 km (1996 est.)
Pipelines; crude oil 6,612 km; petroleum products
298 km; natural gas 2,948 km
Ports and harbors; Algiers, Annaba, Arzew, Bejaia,
Beni Saf, Deliys, Djendjene, Ghazaouet, Jijel,
Mostaganem, Oran, Skikda, Tenes
Merchant marine;
total: 78 ships (1 ,000 GRT or over) totaling 940,1 96
GRT/1 ,094,104 DWT
ships by type: bulk 9, cargo 27, chemical tanker 7,
liquified gas 1 1 , petroleum tanker 5, roll-on/roll-off 1 3,
short-sea passenger 5, specialized tanker 1
(1999 est.)
Airports; 137 (1999 est.)
Airports - with paved runways;
total:
over 3,047 m: 6
2,438 to 3,047 m: 25
1,524 to 2,437 m:t2
914 to 1,523 m: 5
under 914 m:1 (1999 est.)
Airports - with unpaved runways;
total: 86
2,438 to 3,047 m: 3
1,524 to 2,437 m: 23
914 to 1,523 m: 41
under 914 m; 19 (1999 est.)
Heliports; 1 (1999 est.)
f Military
Military branches; National Popular Army, Navy, Air
Force, Territorial Air Defense, National Gendarmerie
Military manpower - military age; 1 9 years of age
Military manpower - availability;
males age 15-49: 8,523,257 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 5,220,318 (2000 est.)
Military manpower - reaching military age
annually;
males: 373,547 (2000 est.)
Military expenditures - dollar figure; $1 .3 billion
(FY94)
Military expenditures - percent of GDP; 2.7%
(FY94)
I f r a n s n at i o nail s s u e s "
Disputes - international; part of southeastern
region claimed by Libya
lAmerican Samoa
l:(territoryofthe US)
f introduction
Background; Settled as early as 1 000 B. C., Samoa
was "discovered" by European explorers in the 18th
century. International rivalries in the latter half of the
19th century were settled by an 1899 treaty in which
Germany and the US divided the Samoan
archipelago. The US formally occupied its portion - a
smaller group of eastern islands with the excellent
harbor of Pago Pago - the following year.','63962f834e9311bf332028f55c2067dc61ebeb72dca5a7154928eb97f387b346','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c171908d7a1fe343ea1b72e756922383048ffa9510c968a666079cabb8d1e22',2000,'AD','Andorra','communications',23,'Telephones - main lines in use: 10,000 (1994)
Telephones - mobile cellular: 1 ,200 (1 994)
Telephone system:
domestic: good telex, telegraph, facsimile and cellular
telephone services; domestic satellite system with 1
Comsat earth station
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 1 , shortwave
0(1998)
Radios: 57,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 14,000(1997)
Internet Service Providers (ISPs): NA
Telephones ■ main lines in use: 60,000 (1 995)
Telephones - mobile cellular: 1 ,994 (1 995)
Telephone system: telephone service limited
mostly to government and business use; HF
radiotelephone used extensively for military links
domestic: limited system of wire, microwave radio
relay, and tropospheric scatter
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 34, FM 7, shortwave
9(1999)
Radios: 630,000(1997)
Television broadcast stations: 7 (1999)
Televisions: 150,000(1997)
Internet Service Providers (ISPs): 2 (1999)','438bd87b796f55d9abb8fa60f3135a3f40d8b1f46e0bac53ce3308506ad46077','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('229c89c2dc1c3d778145842ff59f601bebfabc99d49ea4a49281b6f1d24f1d89',2000,'BS','Bahamas','communications',60,'Telephones - main lines in use: 77,000 (1994)
Telephones - mobile cellular: 2,400 (1993)
Telephone system:
domesf/c; totally automatic system; highly developed
international: tropospheric scatter and submarine
cable to Florida; 3 coaxial subrnarine cables; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave
0(1998)
Radios: 215,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 67,000(1997)
Internet Service Providers (ISPs): 3 (1999)','cbb299eaae200f36a6f34756cdfc41d2b09e14c40ff60e51650cf1e1ec1301b4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('399046a3e0e0914fe31a5472ac5c4a41eacc1d6f25b767208a50e9cde1301e2a',2000,'BY','Belarus','communications',78,'Telephones - main lines in use; 4.632 million
(1995)
Telephones - mobile cellular; 664,000 (1 999)
Telephone system: highly developed,
technologically advanced, and completely automated
domestic and international telephone and telegraph
facilities
domestic: nationwide cellular telephone system;
extensive cable network; limited microwave radio
relay network
international: 5 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Eutelsat
Radio broadcast stations; FM 79, AM 7, shortwave
1 (1998)
Radios: 8.075 million (1997)
Television broadcast stations: 24 (1997)
Televisions: 4.72 million (1997)
Internet Service Providers (ISPs): 51 (1999)
Telephones - main lines in use: 29,600 (1996)
Telephones - mobile cellular: 1 ,237 (1 995)
Telephone system: above-average system
domesf/c; trunk network depends primarily on
microwave radio relay
international: saleWWe earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 1 2, shortwave
0(1998)
Radios: 133,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 41,000(1997)
Internet Service Providers (ISPs): NA
52
B6liZ6 (continued)
I Transportation
Railways; Okm
Highways;
total: 2,872 km
paved: 488 km
unpaved: 2,384 km (1998 est.)
Waterways; 825 km river network used by
shallow-draft craft; seasonally navigable
Ports and harbors; Belize City, Big Creek, Corozol,
Punta Gorda
Merchant marine;
tofa/;414 ships (1,000 GRT or over) totaling
1,647,452 GRT/2,339,134DWT
ships by type: bulk 36, cargo 275, chemical tanker 7,
container 9, liquified gas 1 , passenger 1 , passenger/
cargo 2, petroleum tanker 51, refrigerated cargo 14,
roll-on/roll-off 9, short-sea passenger 3, specialized
tanker 4, vehicle carrier 2 (1 999 est.)
note: a flag of convenience registry; includes ships of
7 countries: Cuba 2, Cyprus 1 , Greece 1 , Singapore 2,
UAE12, UK 1, and US 1 (1998 est.)
Airports; 44 (1999 est.)
Airports • with paved runways;
total: 3
1,524 to 2,437 m:t
under 914 m: 2 (1 999 est.)
Airports • with unpaved runways;
total: 41
2,438 to 3,047 m:1
914 to 1,523 m: 10
under 914 m: 30 (1 999 est.)
I"'' Military
Military branches; Belize Defense Force (includes
Ground Forces, Maritime Wing, Air Wing, and
Volunteer Guard), Belize National Police
Military manpower - military age; 18 years of age
Military manpower - availability;
males age 15-49: 60,482 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 35,874 (2000 est.)
Military manpower - reaching military age
annually;
males: 2,735 (2000 est.)
Military expenditures - dollar figure; $15 million
(FY97/98)
Military expenditures - percent of GDP; 2%
(FY97/98)
I f r a n s n a t i 0 n a I Tssues
Disputes - international; territory in Belize claimed
by Guatemala; precise alignment of boundary in
dispute
Illicit drugs; transshipment point for cocaine;
small-scale illicit producer of cannabis for the
international drug trade; minor money-laundering
center
Background; Dahomey gained its independence
from France in 1 960; the name was changed to Benin
in 1 975. From 1 974 to 1 989 the country was a socialist
state; free elections were reestablished in 1991.
If ” gI 6 g r ayii y
Location; Western Africa, bordering the North
Atlantic Ocean, between Nigeria and Togo
Geographic coordinates; 9 30 N, 2 15 E
Map references; Africa
Area;
total: 112,620 sq km
land: 110,620 sq km
water: 2,000 sq km
Area - comparative; slightly smaller than
Pennsylvania
Land boundaries;
tofa/; 1,989 km
border countries: Burkina Faso 306 km, Niger 266
km, Nigeria 773 km, Togo 644 km
Coastline; 121 km
Maritime claims;
territorial sea: 200 nm
Climate; tropical; hot, humid in south; semiarid in
north
Terrain; mostly flat to undulating plain; some hills
and low mountains
Elevation extremes;
lowest point: AWanWc Ocean 0 m
highest point: Mont Sokbaro 658 m
Natural resources; small offshore oil deposits,
limestone, marble, timber
Land use;
arable land: 13%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 31 %
other; 48% (1993 est.)
Irrigated land; 100 sq km (1993 est.)
Natural hazards; hot, dry, dusty harmattan wind
may affect north in winter
Environment - current issues; recent droughts
have severely affected marginal agriculture in north;
inadequate supplies of potable water; poaching
threatens wildlife populations; deforestation;
desertification
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note; no natural harbors
Population; 6,395,919
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 47% (male 1 ,531 ,636; female 1 ,503,552)
15-64 years: 50% (male 1 ,551 ,867; female
1,660,845)
65 years and over: 3% (male 63,71 7; female 84,302)
(2000 est.)
Population growth rate; 3.03% (2000 est.)
Birth rate; 44.81 births/1 ,000 population (2000 est.)
Death rate; 14.51 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.03 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.07 male(s)/female (2000 est.)
Infant mortality rate; 90.84 deaths/1 ,000 live births
(2000 est.)
53
Bonin (continued)
Life expectancy at birth:
total population: 50.18 years
male: 49.24 years
female: 51 .16 years (2000 est.)
Total fertility rate: 6.32 children born/woman
(2000 est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 70%, Muslim 15%,
Christian 15%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
least six major ones in north)
Literacy:
definition: age 15 and over can read and \\write
total population: 37%
male: 48.7%
female: 25.8% (1995 est.)
Telephones - main lines in use: 5,000 (1995)
Telephones - mobile cellular; NA
Telephone system:
domestic: domestic telephone service is very poor
with few telephones in use
international: international telephone and telegraph
service is by landline through India; a satellite earth
station was planned (1990)
Radio broadcast stations: AM 0, FM 1 , shortwave
1 (1998)
Radios: 37,000(1997)
Television broadcast stations; 0 (1997)
Televisions: 11,000(1997)
Internet Service Providers (ISPs): NA
58
Bhutan (continued)
I transportation
Railways; 0 km
Highways:
total: 3,285 km
paved: 1 ,994 km
unpaved: t, 291 km (1996 est.)
Ports and harbors: none
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:-\\ (1999 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1999 est.)
f Military
Military branches: Royal Bhutan Army, Palace
Guard, Militia, Royal Police Force
Military manpower - military age: 18 years of age
Military manpower - availability;
males age 15-49: 491 ,427 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 262,316 (2000 est.)
Military manpower - reaching military age
annually;
males: 20,374 (2000 est.)
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP: NA%
I fransnationaf Issues
Disputes - international; over approximately
96,500 Bhutanese refugees in Nepal
Background: Bolivia, named after independence
fighter Simon BOLIVAR, broke away from Spanish
rule in 1825; much of its subsequent history has
consisted of a series of nearly 200 coups and
counter-coups. Comparatively democratic civilian rule
was established in the 1980s, but leaders have faced
difficult problems of deep-seated poverty, social
unrest, and drug production. Current goals include
attracting foreign investment, strengthening the
educational system, continuing the privatization
program, and waging an anti-corruption campaign.
I G eTg''r a p h y”""’
Location: Central South America, southwest of Brazil
Geographic coordinates: 17 00 S, 65 00 W
Map references; South America
Area;
total: 1 ,098,580 sq km
land: 1 ,084,390 sq km
wafer; 14,190 sq km
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km,
Chile 861 km, Paraguay 750 km, Peru 900 km
Coastline; 0 km (landlocked)
Maritime claims; none (landlocked)
Climate: varies with altitude; humid and tropical to
cold and semiarid
Terrain: rugged Andes Mountains with a highland
plateau (Altiplano), hills, lowland plains of the Amazon
Basin
Elevation extremes;
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Natural resources; tin, natural gas, petroleum, zinc,
tungsten, antimony, silver, iron, lead, gold, timber,
hydropower
Land use;
arable land: 2%
permanent crops: 0%
permanent pastures: 24%
forests and woodland: 53%
of/?er;21%(1993 est.)
Irrigated land: 1 ,750 sq km (1 993 est.)
Natural hazards: cold, thin air of high plateau is
obstacle to efficient fuel combustion, as well as to
physioal activity by those unaccustomed to it from
birth; flooding in the northeast (March-April)
Environment - current issues; the clearing of land
for agricultural purposes and the international demand
for tropical timber are contributing to deforestation;
soil erosion from overgrazing and poor cultivation
methods (including slash-and-burn agriculture);
desertification; loss of biodiversity; industrial pollution
of water supplies used for drinking and irrigation
Environment - international agreements;
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification,
Marine Dumping, Marine Life Conservation, Ozone
Layer Protection
Geography • note: landlocked; shares control of
Lago Titicaca, world’s highest navigable lake
(elevation 3,805 m), with Peru
f''”" . . . .
Population: 8,152,620 (July 2000 est.)
Age structure;
0- 14 years: 39.1 1 % (male 1 ,624,404; female
1,564,057)
15-64 years: 56.42% (male 2,247,013; female
2,352,824)
65 years and over: 4.47% (male 1 64,473; female
199,849) (2000 est.)
Population growth rate: 1 .83% (2000 est.)
Birth rate: 28.15 births/1 ,000 population (2000 est.)
Death rate: 8.36 deaths/1 ,000 population
(2000 est.)
Net migration rate; -1 .47 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate; 60.44 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 63.7 years
ma/e; 61.19 years
female: 66.34 years (2000 est.)
Total fertility rate: 3.66 children born/woman
(2000 est.)
59
Bolivia (continued)
Nationality;
noun: Bolivian(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, Aymara 25%,
mestizo (mixed white and Amerindian ancestry) 30%,
white 15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy;
definition: age 1 5 and over can read and write
total population: 83 A%
male: 90.5%
fema/e.- 76% (1 995 est.)
Telephones - main lines in use: 368,874 (1996)
Telephones - mobile cellular: 7,229 (1 995)
Telephone system: new subscribers face
bureaucratic difficulties; most telephones are
concentrated in La Paz and other cities
domestic: primary trunk system, which is being
expanded, employs digital microwave radio relay;
some areas are served by fiber-optic cable; mobile
cellular systems are being expanded
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 171, FM 73,
shortwave 77 (1999)
Radios: 5.25 million (1997)
Television broadcast stations: 48 (1997)
Televisions: 900,000(1997)
Internet Service Providers (ISPs): 5 (1 999)
I Transportation
Railways:
total: 3,691 km (single track)
narrow gauge: 3,652 km 1.000-m gauge; 39 km
0.760-m gauge (13 km electrified) (1995)
Highways:
total: 52,215 km
paved: 2,872 km (including 27 km of expressways)
unpaved: 49,344 km (1995 est.)
Waterways: 1 0,000 km of commercially navigable
waterways
Pipelines: crude oil 1,800 km; petroleum products
580 km; natural gas 1,495 km
Ports and harbors: none; however, Bolivia has free
port privileges in the maritime ports of Argentina,
Brazil, Chile, and Paraguay
Merchant marine:
total: 32 ships (1,000 GRT or over) totaling 116,373
GRT/1 82,283 DWT
ships by type: bulk 3, cargo 17, chemical tanker 3,
container 1 , petroleum tanker 6, roll-on/roll-off 2
(1999 est.)
Airports: 1,109 (1999 est.)
Airports • with paved runways:
fofa/;13
over 3,047 m: A
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m; 2 (1999 est.)
Airports - with unpaved runways:
total: 1,095
2,438 to 3,047 m: 3
1,524 to 2,437 m: 57
914 to 1,523 m: 219
under 914 m: 807 (1 999 est.)
I Military
Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval Boliviana, includes Marines), Air Force
(Fuerza Aerea Boliviana), National Police Force
(Policia Nacional de Bolivia)
Military manpower ■ military age: 19 years of age
Military manpower - availability:
males age 15-49; 1,949,267 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,269,228 (2000 est.)
Military manpower - reaching military age
annually:
males: 86,863 (2000 est.)
Military expenditures - dollar figure: $1 47 million
(FY99)
Military expenditures - percent of GDP: 1 .8%
(FY99)
i Transhationai Issues
Disputes - international: has wanted a sovereign
corridor to the South Pacific Ocean since the Atacama
area was lost to Chile in 1 884; dispute with Chile over
Rio Lauca water rights
Illicit drugs: world''s third-largest cultivator of coca
(after Peru and Colombia) with an estimated 21,800
hectares under cultivation in 1 999, a 45% decrease in
overall cultivation of coca from 1998 levels;
intermediate coca products and cocaine exported to
or through Colombia, Brazil, Argentina, and Chile to
the US and other international drug markets;
alternative crop program aims to reduce illicit coca
cultivation
61
Bosnia and IH
Herzegovina
Background: Bosnia and Herzegovina''s declaration
of sovereignty in October of 1 991 , was followed by a
referendum for independence from the former
Yugoslavia in February of 1992. The Bosnian Serbs -
supported by neighboring Serbia - responded with
armed resistance aimed at partitioning the republic
along ethnic lines and joining Serb-held areas to form
a "greater Serbia." In March 1994, Bosnia''s Bosniaks
and Croats reduced the number of warring factions
from three to two by signing an agreement creating a
joint Bosniak/Croat Federation of Bosnia and
Herzegovina. On 21 November 1 995, in Dayton, Ohio,
the warring parties signed a peace agreement that
brought to a halt the three years of interethnic civil
strife (the final agreement was signed in Paris on 14
December 1995). The Dayton Agreement divides
Bosnia and Herzegovina roughly equally between the
Federation of Bosnia and Herzegovina and the
Bosnian Serb Republika Srpska. In 1995-96, a
NATO-led international peacekeeping force (IFOR) of
60,000 troops served in Bosnia to implement and
monitor the military aspects of the agreement. IFOR
was succeeded by a smaller, NATO-led Stabilization
Force (SFOR) whose mission is to deter renewed
hostilities. SFOR remains in place, with troop levels to
be reduced to about 19,000 by spring 2000.
Telephones - main lines in use: 238,000 (1995)
Telephones - mobile cellular: 4,000 (1 999)
Telephone system: telephone and telegraph
network is in need of modernization and expansion;
many urban areas are below average when compared
with services in other former Yugoslav republics
domestic: NA
international: no satellite earth stations
Radio broadcast stations: AM 8, FM 1 6, shortwave
1 (1998)
Radios: 940,000(1997)
Television broadcast stations: 33 (plus 292
repeaters) (September 1995)
Televisions: NA
Internet Service Providers (ISPs): 2 (1999)
Telephones - main lines in use: 78,000 (1998)
Telephones ■ mobile cellular: NA
Telephone system: sparse system
domestic: small system of open-wire lines, microwave
radio relay links, and a few radiotelephone
communication stations
international: two international exchanges; digital
microwave radio relay links to Zambia, Zimbabwe,
and South Africa; satellite earth station - 1 Intelsat
(Indian Ocean)
Radio broadcast stations: AM 7, FM 1 5, shortwave
5(1998)
Radios: 237,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 31,000(1997)
Internet Service Providers (ISPs): 2 (1999)','28ad9f1cf4cec73cf409e497f5727cceb0b52a9dd765c3f7859b8ef1c2525b9a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7637979c6c510fe9d6da17e299a0c82f7e0b05cd0a03c885d204aceac752c37',2000,'IO','British Indian Ocean Territory','communications',90,'Telephones - main lines in use: 9,000 (1994)
Telephones - mobile cellular: NA
Telephone system: worldwide telephone service
domestic: NA
International: submarine cable to Bermuda
Radio broadcast stations: AM 1 , FM 4, shortwave
0(1998)
Radios: 9,000(1997)
Television broadcast stations: 1 (plus one cable
company) (1997)
Televisions: 4,000(1997)
Internet Service Providers (ISPs): 1 (1999)
I Transportation
Railways: 0 km
Highways:
total: M3 km (1995 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Road Town
Merchant marine: none (1999 est.)
Airports: 3 (1999 est.)
Airports • with paved runways:
total: 2
91410 1,523 m:1
under 914 m:1 (1999 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1999 est.)
f Military
Military - note: defense is the responsibility of
the UK
I transnational issues
Disputes - international: none
72
Background: Although greatly reduced In size since
its heyday of the 1 6th century, the Sultanate of Brunei
sits atop extensive petroieum and natural gas fields,
the source of one of the highest per capita GDPs in
the less developed countries.
IP ~ Geography
Location: Southeastern Asia, bordering the South
China Sea and Malaysia
Geographic coordinates: 4 30 N, 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
Area - comparative: slightly smaller than Delaware
Land boundaries:
total: 381 km
border countries: Ma\\ays\\a 381 km
Coastline: 161km
Maritime claims:
exclusive economic zone: 200 nm or to median line
femfor/a/sea;12nm
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east;
hilly lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1 ,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 1%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 85%
other: 12% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: typhoons, earthquakes, and
severe flooding are very rare
Environment - current issues: seasonal smoke/
haze resulting from forest fires in Indonesia
Environment - international agreements:
party to: Endangered Species, Law of the Sea, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: close to vital sea lanes through
South China Sea linking Indian and Pacific Oceans;
two parts physically separated by Malaysia; almost an
enclave of Malaysia
"People " "''"7^
Population: 336,376 (July 2000 est.)
Age structure:
0-14 years: 31% (male 53,812; female 51 ,628)
15-64 years: 66% (male 1 18,207; female 1 03,81 9)
65 years and over: 3% (male 4,317; female 4,593)
(2000 est.)
Population growth rate: 2.17% (2000 est.)
Birthrate: 20.81 births/1 ,000 population (2000 est.)
Death rate: 3.39 deaths/1,000 population
(2000 est.)
Net migration rate: 4.25 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.14 male(s)/female
65 years and over: 0.94 male(s)^emale
total population: 1 .1 male(s)/female (2000 est.)
Infant mortality rate: 14.84 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73.58 years
male: 71 .23 years
female: 76.06 years (2000 est.)
Total fertility rate: 2.47 children born/woman
(2000 est.)
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic groups: Malay 62%, Chinese 15%,
indigenous 6%, other 17%
Religions: Muslim (official) 67%, Buddhist 13%,
Christian 10%, indigenous beliefs and other 10%
Languages: Malay (official), English, Chinese
Literacy:
definition: age 1 5 and over can read and write
total population: 88.2%
male: 92.6%
female: 83.4% (1995 est.)
I Government
Country name:
conventional long form: Negara Brunei Darussalam
conventional short form: Brunei
Data code: BX
Government type: constitutional sultanate
Capital: Bandar Seri Begawan
Administrative divisions: 4 districts
(daerah-daerah, singular - daerah); Belait, Brunei and
Muara, Temburong, Tutong
Independence: 1 January 1984 (from UK)
National holiday: National Day, 23 February (1984)
Constitution: 29 September 1959 (some provisions
suspended under a State of Emergency since
December 1962, others since independence on 1
January 1984)
Legal system: based on English common law; for
Muslims, Islamic Shari''a law supersedes civil law in a
number of areas
Suffrage: none
Executive branch:
c/7/ef of sfafe: Sultan and Prime Minister His Majesty
Paduka Seri Baginda Sultan Haji HASSANAL Bolkiah
Mu''izzaddin Waddaulah (since 5 October 1967);
note - the monarch is both the chief of state and head
of government
head of government: Sultan and Prime Minister His
Majesty Paduka Seri Baginda Sultan Haji HASSANAL
Bolkiah Mu''izzaddin Waddaulah (since 5 October
1 967); note - the monarch is both the chief of state and
head of government
cabinet: Council of Cabinet Ministers appointed and
presided over by the monarch; deals with executive
matters
note; there is also a Religious Council (members
appointed by the monarch) that advises on religious
matters, a Privy Council (members appointed by the
monarch) that deals with constitutional matters, and
the Council of Succession (members appointed by the
monarch) that determines the succession to the
throne if the need arises
elections: none; the monarch is hereditary
Legislative branch: unicameral Legislative Council
or Majlis Masyuarat Megeri (a privy council that serves
only in a consultative capacity; NA seats; members
appointed by the monarch)
elections: last held in March 1962
note: in 1 970 the Council was changed to an
appointive body by decree of the monarch; an elected
Legislative Council is being considered as part of
constitutional reform, but elections are unlikely for
several years
Judicial branch: Supreme Court, chief justice and
judges are sworn in by the monarch for three-year
terms
Political parties and leaders: Brunei Solidarity
National Party or PPKB in Malay [Haji Mohd HATTA
bin Haji Zainal Abidin, president]; the PPKB is the only
legal political party in Brunei; it was registered in 1985,
but became largely inactive after 1 988, it was revived
in 1995 and again in 1998; it has less than 200
registered party members; other parties include
Brunei People''s Party or PRB (banned in 1962) and
Brunei National Democratic Party (registered in May
1965, deregistered by the Brunei Government in
1988)
International organization participation: APEC,
ASEAN, C, CCC, ESCAP, G-77, IBRD, ICAO, ICRM,
IDB, IFRCS, IMF, IMO, Inmarsat, Intelsat, Interpol,
73
Brunei (continued)
IOC, ISO (correspondent), ITU, NAM, OIC, OPCW,
UN, UNCTAD, UPU, WHO, WlPO, WMO, WTrO
Diplomatic representation in the US:
cWef of m/ss/on; Ambassador Pengiran Anak Dato
Haji PUTEH Ibni Mohammad Alam
chancery: 3520 international Court NW, Washington,
DC 20008
telephone: [t] {202) 3A2-Qt59
FAX; [11(202)342-0158
Diplomatic representation from the US:
chief of mission: Ambassador Sylvia Gaye
STANFIELD
embassy: Third Fioor, Teck Guan Piaza, Jaian Suitan,
Bandar Seri Begaw;an
mailing address: PSC 470 (BSB), FPO AP 96507
telephone: [673] {2) 229670
FAX; [673] (2) 225293
Flag description: yeiiow w/ith hwo diagonai bands of
white (top, aimost doubie width) and biack starting
from the upper hoist side; the nationai embiem in red
is superimposed at the center; the embiem inciudes a
swallow-taiied fiag on top of a winged coiumn within
an upturned crescent above a scroli and fianked by
two upraised hands
Telephones - main lines in use: 68,000 (1995)
Telephones - mobile cellular: 57,000 (1998)
Telephone system: service throughout country is
excellent; international service good to Europe, US,
and East Asia
domestic: NA
International: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean); digital submarine
cable links to Malaysia, Singapore, and Philippines
Radio broadcast stations: AM 3, FM 10, shortwave
0(1998)
Radios: 319,408(1997)
Television broadcast stations: 2 (1997)
Televisions: 196,009(1997)
Internet Service Providers (ISPs): 1 (1999)
Telephones ■ main lines in use; 3.186 million
(1999)
Telephones - mobile cellular: 300,000 (1999)
Telephone system: more than two-thirds of the lines
are residential
domestic: extensive but antiquated transmission
system of coaxial cable and microwave radio relay;
telephone service is available in most villages; a more
modern digital cable trunk line now connects
switching centers in most of the regions, the others
being connected by digital microwave
internationai: direct dialing to 58 countries; satellite
earth stations - 1 1ntersputnik (Atlantic Ocean region);
2 Intelsat (Atlantic and Indian Ocean regions)
Radio broadcast stations: AM 24, FM 93,
shortwave 2 (1998)
Radios: 4.51 million (1997)
Television broadcast stations: 33 (1999)
Televisions: 3.31 million (1997)
Internet Service Providers (ISPs): 20 (1999)','d0a7125dc454ed597b00dd3876efe8d1f2b68570cb7abf60d51b08813183e7ae','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa1d41183dee22697dbf296085aeff13f0796b605b1146ce329ac540c0793c80',2000,'HN','Honduras','communications',115,'Telephones - main lines in use: 19,000 (1995)
Telephones - mobile cellular; 2,534 (1995)
Telephone system:
domestic: NA
94
Cayman Islands (continued)
international: 1 submarine coaxial cable; satellite
earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 5, shortwave
0(1998)
Radios: 36,000(1997)
Television broadcast stations: NA
Televisions: 7,000(1997)
Internet Service Providers (ISPs): 1 (1999)
I transportation
Railways: 0 km
Highways:
fofa/;406km
paved: 304 km
unpaved: 102 km
Ports and harbors: Cayman Brae, George Town
Merchant marine:
total: 85 ships (1 ,000 GRT or over) totaling 1 ,139,740
GRT/1 ,693,21 2 DWT
ships by type: bulk 18, cargo 10, chemical tanker 14,
container 4, liquified gas 1 , petroleum tanker 2,
refrigerated cargo 26, roll-on/roll-off 6, specialized
tanker 2, vehicle carrier 2 (1999 est.)
note: a flag of convenience registry; includes ships
from 1 1 countries among which are: Greece 1 5, US 5,
UK 5, Cyprus 2, Denmark 2, Norway 3 (1 998 est.)
Airports: 3 (1999 est.)
Airports • with paved runways:
total: 2
1,524 to 2,437 m: 2 (mo est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1999 est.)
F Military
Military branches: Royal Cayman Islands Police
Force (RCIPF)
Military - note: defense is the responsibility of
the UK
I" t r a n s n a t i 0 ri a i issues
Disputes - international: none
Illicit drugs: vulnerable to drug money laundering
and drug transshipment
Background: The former French colony of
Ubangi-Shari became the Central African Republic
upon independence in 1960. After three tumultuous
decades of misrule - mostly by military governments -
a civilian government was installed in 1993.
I'' '' G''l’yg''rTp''y
Location: Central Africa, north of Democratic
Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,984 sq km
land: 622,984 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries;
total: 5,203 km
border countries: Cameroon 797 km, Chad 1 ,1 97 km,
Democratic Republic of the Congo 1,577 km.
Republic of the Congo 467 km, Sudan 1 ,1 65 km
Coastline; 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet
summers
Terrain: vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1 ,420 m
Natural resources; diamonds, uranium, timber,
gold, oil, hydropower
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other; 17% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: hot, dry, dusty harmattan winds
affect northern areas; floods are common
Environment - current issues: tap water is not
potable; poaching has diminished its reputation as
one of the last great wildlife refuges; desertification;
deforestation
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban, Ozone Layer Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography - note: landlocked; almost the precise
center of Africa
I People
Population; 3,512,751
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result In lower life expectancy, higher infant
mortality and death rates, lower population and
grovrth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 43% (male 768,550; female 757,710)
15-64 years: 53% (male 909,463; female 946,083)
65 years and over: 4% (male 58,224; female 72,721)
(2000 est.)
Population growth rate; 1 .77% (2000 est.)
Birth rate: 37.52 births/1 ,000 population (2000 est.)
Death rate: 1 8.44 deaths/1 ,000 population
(2000 est.)
Net migration rate; -1 .42 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 106.69 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth;
total population: 44.02 years
male: 42.26 years
female: 45.84 years (2000 est.)
Total fertility rate: 4.95 children born/woman
(2000 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups; Baya 34%, Banda 27%, Sara 10%,
Mandjia 21%, Mboum 4%, M''Baka 4%, Europeans
6,500 (including 1 ,500 French)
Religions; indigenous beliefs 24%, Protestant 25%,
Roman Catholic 25%, Muslim 1 5%, other 1 1 %
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), Arabic, Hunsa, Swahili
Literacy:
definition: age 15 and over can read and write
95
Central African Republic (continued)
total population: 60%
male: 68.5%
fema/e; 52.4% (1995 est.)
Telephones - main iines in use; NA
Telephones - mobile cellular: 0 (1 999)
Telephone system:
domestic: NA
international: external telephone and telex services
are provided by Intelsat satellite
Radio broadcast stations: AM 1 , FM 1, shortwave
0(1998)
Radios: 1,000(1997)
Television broadcast stations; NA
Televisions: 600 (1997)
Internet Service Providers (ISPs): NA','81c75f789e8b18b6f972b0a02777b389059ad4b31d0036021e80a8ee72c13f09','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654176190863fcf8924ab5ce31647aa49e3653a192c4983b8c3db7b6d7327748',2000,'FR','France','communications',131,'Telephones- main iines in use: NA
Telephones - mobile cellular: 0 (1 999)
Telephone system:
domestic: NA
international: telephone, telex, and facsimile
communications with Australia and elsewhere via
satellite; 1 satellite earth station of NA type
Radio broadcast stations: AM 1 , FM 0, shortwave
0(1998)
Radios: 300(1992)
Television broadcast stations: 0 (1997)
Televisions: NA
Internet Service Providers (ISPs): NA
f transportation
Railways; 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; lagoon anchorage only
Merchant marine: none (1999 est.)
Airports; 1 (1999est.)
Airports - with paved runways;
total: 1
1,524 to 2,437 m:1 (1999 est.)
Telephones - main lines in use: 182,000 (1998)
Telephones - mobile cellular: more than 60,000
(December 1998)
Telephone system: well-developed by African
standards but operating well below capacity
domestic: open-wire lines and microwave radio relay;
90% digitalized
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean); 2 coaxial
submarine cables (June 1999)
Radio broadcast stations: AM 2, FM 8, shortwave
3(1998)
Radios: 2.26 million (1997)
Television broadcast stations: 14 (1999)
Televisions: 900,000(1997)
internet Service Providers (iSPs): NA
Telephones - main lines in use: 554,000 (1995)
Telephones - mobile cellular: 1 50 (1 995)
Telephone system:
domestic: local - T''bilisi and K''ut''aisi have cellular
telephone networks with about 10,000 customers
total; urban areas 20 telephones/100 people; rural
areas 4 telephones/1 00 people; intercity - a fiber-optic
line connects T''bilisi to K''ut''aisi (Georgia''s second
largest city); nationwide pager service
186
Georgia (continued)
international: Georgia and Russia are working on a
fiber-optic iine between P''ot''i and Sochi (Russia);
present international service is available by
microwave, landline, and satellite through the Moscow
switch; international electronic mail and telex service
available
Radio broadcast stations: AM 7, FM 1 2, shortwave
4(1998)
Radios: 3.02 million (1997)
Television broadcast stations: 12 (plus repeaters)
(1998)
Televisions: 2.57 million (1997)
Internet Service Providers (ISPs): 5 (1999)
I Transportation
Railways:
total: 1 ,583 km in common carrier service; does not
include industrial lines
broad gauge: 1 ,583 km 1 .520-m gauge (1993)
Highways:
total: 20,700 km
paved; 19,354 km
unpaved: 1 ,346 km (1 996 est.)
Pipelines: crude oil 370 km; refined products 300
km; natural gas 440 km (1992)
Ports and harbors: Batumi, P''ot''i, Sokhumi
Merchant marine:
total: 17 ships (1,000 GRT or over) totaling 103,080
GRT/1 58,803 DWT
ships by type: cargo 10, chemical tanker 1 , petroleum
tanker 6 (1999 est.)
Airports: 28 (1994 est.)
Airports ■ with paved runways:
fofa/;14
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m: 1 (1994 est.)
Airports - with unpaved runways:
fofa/;14
over3,047m;1
2,438 to 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 5
under 914 m: 6 (1 994 est.)
Transportation - note: transportation network is in
poor condition and disrupted by ethnic conflict,
criminal activities, and fuel shortages; network lacks
maintenance and repair
I Military
Military branches: Ground Forces, Navy, Air Force,
Air Defense Forces, Naval Forces, National Guard,
Republic Security Forces (internal and border troops)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 1 ,291 ,190 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,021 ,072 (2000 est.)
Military manpower - reaching military age
annually:
males: 40,694 (2000 est.)
Military expenditures - dollar figure: $27 million
(FY99)
Military expenditures - percent of GDP: 1%
(FY99)
Military - note: a CIS peacekeeping force consisting
of Russian troops is deployed in the Abkhazia region
of Georgia together with a UN military observer group;
a Russian peacekeeping battalion is deployed in
South Ossetia
I Transnational issues
Disputes - international; none
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for domestic consumption; used
as transshipment point for opiates via Central Asia to
Western Europe and Russia
in t r 0 d u c t i 0 n
Background: As Western Europe''s richest and most
populous nation, Germany remains a key member of
the continent''s economic, political, and defense
organizations. European power struggles immersed
the country in two devastating World Wars in the first
half of the 20th century and left the country occupied
by the victorious Allied powers of the US, UK, France,
and the Soviet Union in 1945. With the advent of the
Cold War, two German states were formed in 1 949:
the western Federal Republic of Germany (FRG) and
the eastern German Democratic Republic (GDR). The
democratic FRG embedded itself in key Western
economic and security organizations, the EC and
NATO, while the communist GDR was on the front line
of the Soviet-led Warsaw Pact. The decline of the
USSR and the end of the Cold War allowed for
German unification in 1990. Since then Germany has
expended considerable funds to bring eastern
productivity and wages up to western standards. In
January 1999, Germany and 10 other EU countries
formed a common European currency, the euro.
I Geography
Location: Central Europe, bordering the Baltic Sea
and the North Sea, between the Netherlands and
Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area:
total: 357,021 sq km
land: 349,223 sq km
water: 7,798 sq km
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 3,821 km
border countries: Austha 784 km, Belgium 167 km,
Czech Republic 646 km, Denmark 68 km, France 451
km, Luxembourg 138 km, Netherlands 577 km,
Poland 456 km, Switzerland 334 km
Gormany (continued)
Coastline: 2,389 km
Maritime ciaims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
femMa/ sea; 12 nm
Climate: temperate and marine; cool, cloudy, wet
winters and summers; occasional warm foehn wind
Terrain: lowlands in north, uplands in center.
Bavarian Alps in south
Elevation extremes:
lowest point: Freepsum Lake -2 m
highest point: Zugspitze 2,963 m
Natural resources: iron ore, coal, potash, timber,
lignite, uranium, copper, natural gas, salt, nickel,
arable land
Land use:
arable land: 33%
permanent crops: t^/o
permanent pastures: 1 5%
forests and woodland: 31 %
of/7er;20%(1993 est.)
Irrigated land: 4,750 sq km (1993 est.)
Natural hazards: flooding
Environment - current issues: emissions from
coal-burning utilities and industries contribute to air
pollution; acid rain, resulting from sulfur dioxide
emissions, is damaging forests; pollution in the Baltic
Sea from raw sewage and industrial effluents from
rivers in eastern Germany; hazardous waste disposal;
government currently attempting to define mechanism
for ending the use of nuclear power; government
working to meet EU commitment to identify nature
preservation areas in line with the EU''s Flora, Fauna,
and Habitat directive
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location on North
European Plain and along the entrance to the Baltic
Sea
j; People
Population: 82,797,408 (July 2000 est.)
Age structure:
0-14 years: 16% (male 6,679,930; female 6,333,110)
15-64 years: 68% (male 28,638,814; female
27,693,630)
65 years and over: 16% (male 5,133,121; female
8,318,803) (2000 est.)
Population growth rate: 0.29% (2000 est.)
Birth rate: 9.35 births/1 ,000 population (2000 est.)
Death rate: 1 0.49 deaths/1 ,000 population
(2000 est.)
Net migration rate: 4.01 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 4.77 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.44 years
male: 74.3 years
female: 80.75 years (2000 est.)
Total fertility rate: 1 .38 children born/woman
(2000 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91 .5%, T urkish 2.4%, other
6.1% (made up largely of Serbo-Croatian, Italian,
Russian, Greek, Polish, Spanish)
Religions: Protestant 38%, Roman Catholic 34%,
Muslim 1 .7%, unaffiliated or other 26.3%
Languages: German
Literacy:
definition: age 1 5 and over can read and write
total population: 99% (1977 est.)
mate: NA%
female: NA%
I ~ Gover"Hment
Country name:
conventional long form: Federal Republic of Germany
conventional short form: Germany
local long form: Bundesrepublik Deutschland
local short form: Deutschland
Data code: GM
Government type: federal republic
Capital: Berlin
Administrative divisions: 16 states (Laender,
singular - Land); Baden-Wuerttemberg, Bayern,
Berlin, Brandenburg, Bremen, Hamburg, Hessen,
Mecklenburg-Vorpommern, Niedersachsen ,
Nordrhein-Westfalen, Rheinland-Pfalz, Saarland,
Sachsen, Sachsen-Anhalt, Schleswig-Holstein,
Thueringen
Independence: 18 January 1871 (German Empire
unification); divided into four zones of occupation (UK,
US, USSR, and later, France) in 1945 following World
War II; Federal Republic of Germany (FRG or West
Germany) proclaimed 23 May 1949 and included the
former UK, US, and French zones; German
Democratic Republic (GDR or East Germany)
proclaimed 7 October 1949 and included the former
USSR zone; unification of West Germany and East
Germany took place 3 October 1990; all four powers
formally relinquished rights 1 5 March 1 991
National holiday: German Unity Day (Day of Unity),
3 October (1990)
Constitution: 23 May 1949, known as Basic Law;
became constitution of the united German people 3
October 1990
Legal system: civil law system with indigenous
concepts; judicial review of legislative acts in the
Federal Constitutional Court; has not accepted
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Johannes RAU (since 1 July
1999)
head of government: Chancellor Gerhard
SCHROEDER (since 27 October 1998)
cabinet: Cabinet or Bundeskanzier appointed by the
president on the recommendation of the chancellor
elections: president elected for a five-year term by a
Federal Convention including all members of the
Federal Assembly and an equal number of delegates
elected by the Land Parliaments; election last held 23
May 1999 (next to be held 23 May 2004); chancellor
elected by an absolute majority of the Federal
Assembly for a four-year term; election last held 27
September 1998 (next to be held in the fall of 2002)
election results: Johannes RAU elected president;
percent of Federal Convention vote - 57.6%; Gerhard
SCHROEDER elected chancellor; percent of Federal
Assembly - 52.7%
Legislative branch: bicameral Parliament or
Parlament consists of the Federal Assembly or
Bundestag (656 seats usually, but 669 for the 1998
term; elected by popular vote under a system
combining direct and proportional representation; a
party must win 5% of the national vote or three direct
mandates to gain representation; members serve
four-year terms) and the Federal Council or Bundesrat
(69 votes; state governments are directly represented
by votes; each has 3 to 6 votes depending on
population and are required to vote as a block)
elections: Federal Assembly - last held 27 September
1 998 (next to be held by the fall of 2002); note - there
are no elections for the Bundesrat; composition is
determined by the composition of the state-level
governments; the composition of the Bundesrat has
the potential to change any time one of the 1 6 states
holds an election
election results: Federal Assembly - percent of vote
by party - SPD 40.9%, Alliance ''90/Greens 6.7%,
CDU/CSU 35.1%, FDP 6.2%, PDS 5.1%; seats by
party - SPD 298, Alliance ''90/Greens 47, CDU/CSU
245, FDP 43, PDS 36; Federal Council - current
composition - votes by party - SPD-led states 26,
CDU-led states 28, grand coalitions 15
Judicial branch: Federal Constitutional Court or
Bundesverfassungsgericht, half the judges are
elected by the Bundestag and half by the Bundesrat
Political parties and leaders: Alliance ''90/Greens
[Gunda ROESTEL and Antje RADCKEj; Christian
Democratic Union orCDU [Angela MERKEL]; Christian
Social Union or CSU [Edmund STOIBER, chairmanj;
Free Democratic Party or FDP [Wolfgang GERHARDT,
chairman); Party of Democratic Socialism or PDS
[Lothar BISKY, chairman]; Social Democratic Party or
SPD [Gerhard SCHROEDER, chairman]
188
Gormany (continued)
Political pressure groups and leaders:
employers'' organizations; expellee, refugee, trade
unions, and veterans groups
International organization participation: AfDB,
AsDB, Australia Group, BDEAC, BIS, CBSS, CCC,
CDB (non-regional), CE, CERN, EAPC, EBRD, ECE,
EIB, EMU, ESA, EU, FAO, G- 5, G- 7, G-10, lADB,
IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, lEA,
IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, lOM, ISO, ITU, MONUC, NAM
(guest), NATO, NEA, NSG, OAS (observer), OECD,
OPCW, OSCE, PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNIKOM, UNITAR, UNMIBH,
UNMIK, UNOMIG, UPU, WADB (nonregional), WEU,
WHO, WlPO, WMO, WToO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Juergen CHROBOG
chancery: 4645 Reservoir Road NW, Washington, DC
20007
telephone: [\\] {202) 298-8141
FAX; [1] (202) 298-4249
consulate(s) general: Atlanta, Boston, Chicago,
Houston, Los Angeles, Miami, New York, San
Francisco
consu/afefsj; Wellington (America Samoa)
Diplomatic representation from the US:
cWefofm/ssrbrj; Ambassador John C. KORNBLUM
errrbassy; Neustaedtische Kirchstrasse 4-5, 10117
Berlin
mailing address: PSC 120, Box 1000, APO AE 09265
telephone: [AS] {30) 238-5174
FAX; [49] (30) 238-6290
consulate(s) general: Dusseldorf, Frankfurt am Main,
Hamburg, Leipzig, Munich
Flag description: three equal horizontal bands of
black (top), red, and gold
I '' ’ 1 c 0 n 0 m ^
Economy - overview: Germany possesses the
world''s third most technologically powerful economy
after the US and Japan, but Its basic capitalistic
economy has started to struggle under the burden of
generous social benefits. Structural rigidities - like a
high rate of social contributions on wages - have made
unemployment a long-term, not just cyclical, problem,
while Germany''s aging population has pushed social
security outlays to exceed contributions from workers.
The integration and upgrading of the eastern German
economy remains a costly long-term problem, with
annual transfers from the west amounting to roughly
$100 billion. Growth slowed to 1 .5% in 1999, largely
due to lower export demand and still-low business
confidence. Recovering Asian demand, a push for
fiscal consolidation, and newly proposed business
and income tax cuts - if passed - are expected to
boost growth back to trend rates around 2.5% in 2000
and beyond. The adoption of a common European
currency and the general political and economic
integration of Europe will bring major changes to the
German economy in the early 21st century.
GDP: purchasing power parity - $1 .864 trillion
(1999est.)
GDP - real growth rate: 1.5% (1999 est.)
GDP - per capita: purchasing power parity -
$22,700 (1999 est.)
GDP - composition by sector:
agriculture: 1 .2%
Industry: 30.4%
services: 68.4% (1 999)
Population below poverty line: NA%
Inflation rate (consumer prices): 0.8% (1999 est.)
Labor force: 40.5 million (1999 est.)
Labor force - by occupation: industry 33.7%,
agriculture 2.7%, services 63.6% (1998)
Unemployment rate: 10.5% (1999 est.)
Budget:
revenues: $996 billion
expenditures: $1,036 trillion, including capital
expenditures of $NA (1999 est.)
Industries: among world''s largest and
technologically advanced producers of iron, steel,
coal, cement, chemicals, machinery, vehicles,
machine tools, electronics, food and beverages;
shipbuilding; textiles
Industrial production growth rate: 0.9% (1999)
Electricity - production: 525.356 billion kWh (1 998)
Electricity • production by source:
fossil fuel: 65.77%
hydro: 3.2%
nuclear: 29.06%
other; 1.97% (1998)
Electricity ■ consumption: 488.041 billion kWh
(1998)
Electricity - exports: 39.1 billion kWh (1998)
Electricity • imports: 38.56 billion kWh (1998)
Agriculture - products: potatoes, wheat, barley,
sugar beets, fruit, cabbages; cattle, pigs, poultry
Exports; $610 billion (f.o.b., 1999 est.)
Exports - commodities: machinery, vehicles,
chemicals, metals and manufactures, foodstuffs,
textiles (1999)
Exports - partners: EU 56.4% (France 1 1 .1%, UK
8.6%, Italy 7.4%, Netherlands 6.8%, Benelux 5.7%),
US 9.4%, Japan 1.9% (1998)
Imports: $587 billion (f.o.b., 1999 est.)
Imports - commodities: machinery, vehicles,
chemicals, foodstuffs, textiles, metals (1999)
Imports - partners: EU 53.7% (France 11.1 %,
Netherlands 7.7%, Italy 7.8%, UK 6.8%, Benelux
5.6%), US 8.3%, Japan 5.0% (1998)
Debt -external; $NA
Economic aid - donor: ODA, $5.6 billion (1 998)
Currency: 1 deutsche mark (DM) = 100 pfennige
Exchange rates: euros per US$1 -0.9867 (January
2000), 0.9386 (1999); deutsche marks (DM) per
US$1 - 1.69 (January 1999), 1.7597 (1998), 1.7341
(1997), 1.5048 (1996), 1.4331 (1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 1 .95583 deutsche marks per euro; the euro will
replace the local currency in consenting countries for
all transactions in 2002
Fiscal year: calendar year
P Communications
K-r... .
Telephones - main lines in use; NA; 46.5 million
main lines are installed (July 1999)
Telephones - mobile cellular: 15.318 million (April
1999)
Telephone system: Germany has one of the world''s
most technologically advanced telecommunications
systems; as a result of intensive capital expenditures
since reunification, the formerly backward system of
the eastern part of the country has been modernized
and integrated with that of the western part
domestic: Germany is served by an extensive system
of automatic telephone exchanges connected by
modern networks of fiber-optic cable, coaxial cable,
microwave radio relay, and a domestic satellite
system; cellular telephone service is widely available
and includes roaming service to many foreign
countries
international: satellite earth stations - 14 Intelsat (12
Atlantic Ocean and 2 Indian Ocean), 1 Eutelsat, 1
Inmarsat (Atlantic Ocean region), 2 Intersputnik (1
Atlantic Ocean region and 1 1ndian Ocean region); 7
submarine cable connections; 2 HF radiotelephone
communication centers; tropospheric scatter links
Radio broadcast stations; AM 51 , FM 767,
shortwave 4 (1998)
Radios; 77.8 million (1997)
Television broadcast stations: 9,513 (Including
repeaters) (1998)
Televisions: 51 .4 million (1998)
Internet Service Providers (ISPs): 625 (1999)
Railways;
total: 40,826 km including at least 14,253 km
electrified and 14,768 km double- or multiple-tracked
(1998)
note: since privatization in 1994, Deutsche Bahn AG
(DBAG) no longer publishes details of the tracks it
owns; in addition to the DBAG system there are 102
privately owned railway companies which own an
approximate 3,000 km to 4,000 km of the total tracks
Highways;
total: 656,140 km
paved; 650,891 km (including 11,400 km of
expressways)
unpaved: 5,249 km (all-weather) (1998 est.)
Waterways; 7,500 km (1999); major rivers include
the Rhine and Elbe; Kiel Canal is an important
connection between the Baltic Sea and North Sea
Pipelines: crude oil 2,500 km (1998)
Ports and harbors: Berlin, Bonn, Brake, Bremen,
Bremerhaven, Cologne, Dresden, Duisburg, Emden,
Hamburg, Karlsruhe, Kiel, Lubeck, Magdeburg,
Mannheim, Rostock, Stuttgart
Merchant marine:
total: 475 ships (1 ,000 GRT or over) totaling
6,395,990 GRT/8,014,132 DWT
ships by type: bulk 2, cargo 181, chemical tanker 1 2,
container 239, liquified gas 2, multi-functional large
load carrier 5, passenger 2, petroleum tanker 8, rail
189
Gsrmany (continued)
car carrier 2, refrigerated cargo 2, roii-on/roii-off 13,
short-sea passenger 7 (1999 est.)
Airports: 615 (1999 est.)
Airports - with paved runways:
total: 320
over 3,047 m:
2,438 to 3,047 m:6t
1,524 to 2,437 m: 67
914 to 1,523 m: 56
under 914 m: 1 22 (1 999 est.)
Airports - with unpaved runways:
total: 295
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 6
914 to 1,523 m: 55
under 914 m: 226 (1 999 est.)
Heiiports: 59 (1999 est.)
Telephones - main lines in use: 20,000 (1 995)
Telephones - mobile cellular: 2,308 (1995)
Telephone system: adequate domestic and
international service provided by cables and
microwave radio relay; totally digitalized in 1995
domestic: microwave radio relay
international: 2 coaxial submarine cables; satellite
earth station - 1 Intelsat (Atlantic Qcean)
Radio broadcast stations: AM 5, FM 1 2, shortwave
0 (1998)
Radios: 27,000(1997)
Television broadcast stations: 1 publicly-owned
station, some local low-power stations, and three
AFRTS (US Air Force) stations (1997)
Televisions: 22,000(1997)
Internet Service Providers (ISPs): 1 (1999)
198
Greenland (continued)
I Transportation
Railways: 0 km
Highways:
total: 150 km
paved: 60 km
unpaved: 90 km
Ports and harbors: Kangerluarsoruseq,
Kangerlussuaq, Nanortalik, Narsarsuaq, Nuuk
(Godlhab), Sisimiut
Airports: 14(1999est.)
Airports - with paved runways:
total: to
over 3,047 m:t
2,438 to 3,047 m-.t
1,524 to 2,437 m:t
914 to 1,523 m: 2
under 91 4 m: 5 (1999 est.)
Airports - with unpaved runways:
total: 4
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 91 4 m: 1 (1 999 est.)
I Hii i li t a r y
Military - note: defense is the responsibility of
Telephones - main lines in use: 159,000 (1 995)
Telephones - mobile cellular: 814 (1990)
Telephone system: domestic facilities inadequate
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); microwave radio relay to Antigua
and Barbuda, Dominica, and Martinique
Radio broadcast stations: AM 1 , FM 17, shortwave
0(1998)
Radios: 113,000(1997)
Television broadcast stations: 5 (plus several
low-power repeaters) (1997)
Televisions: 118,000(1997)
Internet Service Providers (ISPs): NA
202
Guadoloupo (continued)
I transportation
Railways:
total: NA km; privately-owned, narrow-gauge
plantation lines
Highways:
total: 2,082 km
paved; 1,742 km
unpaved: 340 km (1985 est.)
note: in 1996 there were a total of 3,200 km of roads
Ports and harbors: Basse-Terre, Gustavia (on
Saint Barthelemy), Marigot, Pointe-a-Pitre
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,240 GRT/
109 DWT
ships by type: passenger 1 (1999 est.)
Airports: 9 (1999 est.)
Airports - with paved runways:
total: 8
over 3,047 m:t
914 to 1,523 m: 2
under 914 m; 5 (1 999 est.)
Airports - with unpaved runways:
total: 1
under 914 m:''\\ (1999 est.)
I ” M i r i t a r y
Military branches: French Forces, Gendarmerie
Military - note: defense is the responsibility of
Telephones - main lines in use: 82,669 (1997)
Telephones ■ mobile cellular: 55,000 (1998)
Telephone system:
domestic: NA
International: satellite earth stations - 2 Intelsat
(Pacific Ocean); submarine cables to US and Japan
Radio broadcast stations: AM 4, FM 7, shortwave
0(1998)
Radios: 221,000(1997)
Television broadcast stations: 5 (1997)
Televisions: 106,000(1997)
Internet Service Providers (ISPs): 5 (1999)
Telephones - main lines In use: 342,000 (1996)
Telephones - mobile cellular; 29,999 (1995)
Telephone system: fairly modern network centered
in the city of Guatemala
domestic: NA
international: conne','8353d612c5e929484a80b2f1390504d234db3e0251972e49cf2c5fc036b2044c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6688d1dd55fadfa7b7fd45c7cb12eb833a46dc1e9b375a70ba731fd2cb9f36ac',2000,'FR','France','communications',132,'cted to Central American
Microwave System; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations; AM 101, FM 32,
shortwave 15 (1998)
Radios: 835,000(1997)
Television broadcast stations: 6 (plus 17
repeaters) (1997)
Televisions: 640,000(1997)
Internet Service Providers (ISPs): 7 (1999)
Telephones - main lines in use: 41 ,850 (1 983)
Telephones -mobile cellular: NA
Telephone system:
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1 , FM 1 , shortwave
0(1998)
Radios: NA
Teievision broadcast stations: 1 (1997)
Televisions: NA
Internet Service Providers (ISPs): NA
Telephones - main iines in use: 1 1 ,000 (1 995)
Telephones - mobile cellular: 950 (1 995)
Telephone system: poor to fair system of open-wire
lines, small radiotelephone communication stations,
and new microwave radio relay system
domestic: microwave radio relay and radiotelephone
communication
International: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 4, FM 8, shortwave
3(1998)
Radios: 357,000(1997)
Television broadcast stations; 6 (1997)
Televisions: 85,000(1997)
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 1 .963 million
(1995)
Telephones - mobile cellular: 4,600 (1995)
Telephone system: service is poor; equipment
antiquated
domestic: intercity by landline and microwave radio
relay; mobile cellular systems are available in most of
Government type; NA
Capital; Saint-Denis
Administrative divisions; none (overseas
department of France); there are no first-order
administrative divisions as defined by the US
407
Reunion (continued)
Government, but there are four arrondissements, 24
communes, and 47 cantons
Independence: none (overseas department of
France)
National holiday: National Day, Taking of the
Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: French law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France
(since 17 May 1995), represented by Prefect Robert
POMMIES (since NA1996)
head of government: President of the General
Council Jean-Luc POUDROUX (since NA March
1998) and President of the Regional Council Paul
VERGES (since NA March 1993)
cabinet: NA
eiections: French president elected by popular vote
for a seven-year term; prefect appointed by the
French president on the advice of the French Ministry
of the Interior; the presidents of the General and
Regional Councils are elected by the members of
those councils
Legislative branch: unicameral General Council (47
seats; members are elected by direct popular vote to
serve six-year terms) and unicameral Regional
Council (45 seats; members are elected by direct
popular vote to serve six-year terms)
eiections: General Council - last held NA March 1 994
(next to be held NA 2000); Regional Council - last held
15 March 1998 (next to be held NA 2004)
election results: General Council - percent of vote by
party - NA; seats by party - PCR 12, PS 12, UDF 1 1 ,
RPR 5, others 7; Regional Council - percent of vote by
party - NA; seats by party - PCR 7, UDF 8, PS 6, RPR
4, various right-wing candidates 15, various left-wing
candidates 5
note: Reunion elects three representatives to the
French Senate; elections last held 1 4 April 1 996 (next
to be held NA 2001); results - percent of vote by
party - NA; seats by party - RPR 1 , PCR 2; Reunion
also elects five deputies to the French National
Assembly; elections last held 25 May and 1 June 1 997
(next to be held NA 2002); results - percent of vote by
party - NA; seats by party - PCR 3, PS 1 , and
RPR-UDF 1
Judicial branch: Court of Appeals or Cour d'' Appel
Political parties and leaders: Communist Party of
Reunion or PCR [Paul VERGES]; France-Reunion
Future or FRA [Andre THIEN AH KOON); Mouvement
des Radicaux de Gauche or MRG [Jean-Marie
FINCKj; National Front or FN [Alix MOREL); Rally for
the Republic or RPR [Andre Maurice PIHOUEEj;
Socialist Party or PS [Jean-Claude FRUTEAUj; Union
for France or UPF (includes RPR and UDF) [leader
NA); Union for French Democracy or UDF [Gilbert
GERARD]
International organization participation: FZ,
InOC, WFTU
Diplomatic representation in the US: none
(overseas department of France)
Diplomatic representation from the US: none
(overseas department of France)
Flag description: the flag of France is used
Telephones • main lines in use: 236,500 (1997)
Telephones • mobile cellular: 42,000 (1998)
Telephone system: adequate system; principal
center is Saint-Denis
domestic: modern open wire and microwave radio
relay network
international: radiotelephone communication to
Comoros, France, Madagascar; new microwave route
to Mauritius; satellite earth station - 1 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 2, FM 55, shortwave
0(1998)
Radios: 173,000(1997)
Television broadcast stations: 22 (plus 18
low-power repeaters) (1997)
Televisions: 127,000(1997)
Internet Service Providers (ISPs): NA
Teiephones - main iines in use; 20,500 (1998)
Telephones - mobile ceiluiar: 83 (1993)
Telephone system:
domestic: islandwide, fully automatic telephone
system; VHF/UHF radiotelephone from Saint Vincent
to the other islands of the Grenadines
international: VHFIdHF radiotelephone from Saint
Vincent to Barbados; new SHF radiotelephone to
Grenada and to Saint Lucia; access to Intelsat earth
station in Martinique through Saint Lucia
Radio broadcast stations: AM 1 , FM 3, shortwave
0(1998)
Radios: 77,000(1997)
Television broadcast stations; 1 (plus three
repeaters) (1997)
Televisions; 18,000(1997)
Internet Service Providers (ISPs): NA
Telephones - main lines in use; 628,000 (1997)
Telephones - mobile cellular: 50,000 (1 998)
Telephone system: above the African average and
continuing to be upgraded; key centers are Sfax,
Sousse, Bizerte, and Tunis; Internet access available
domestic: trunk facilities consist of open-wire lines,
coaxial cable, and microwave radio relay
international: 5 submarine cables; satellite earth
stations - 1 Intelsat (Atlantic Ocean) and 1 Arabsat;
coaxial cable and microwave radio relay to Algeria
and Libya; participant in Medarabtel; two international
gateway digital switches
Radio broadcast stations: AM 7, FM 20, shortwave
2(1998)
Radios: 2.06 million (1997)
Television broadcast stations: 19 (plus some low
power stations) (1997)
Televisions: 920,000(1997)
Internet Service Providers (ISPs): 4 (1999)','f996d485256ef0597400ab4e354ee44afbedc6e22cbdf2da8d405e582ed9150c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44c407310e5acdc3d2c57e7c4a700af269eda3fa8c661f326eacbb0236f91ee5',2000,'AU','Australia','communications',136,'Telephones - main iines in use; 5,433,565
(December 1997)
Telephones - mobile cellular: 1 ,800,229
(December 1998)
Telephone system: modern system in many
respects
domestic: nationwide microwave radio relay system;
domestic satellite system with 41 earth stations;
fiber-optic network linking 50 cities
International satellite earth stations - 6 Intelsat, 1
Inmarsat; 3 fully digitalized international switching
centers; 8 submarine cables
Radio broadcast stations; AM 454, FM 34,
shortwave 27 (1999)
Radios: 21 million (1997)
Television broadcast stations; 60 (includes seven
low-power stations) (1997)
Televisions: 4.59 million (1997)
Internet Service Providers (ISPs): 13 (1999)
Telephones - main lines in use: 3.708 million
(1998)
Telephones - mobile cellular: 2.4 million (July
1998)
Telephone system: modem facilities provide
excellent domestic and international services
domestic: microwave radio relay links and extensive
fiber-optic network
international: satellite earth stations - 3 Intelsat (1
Pacific Ocean and 2 Indian Ocean); coaxial cable to
Guangzhou, China; access to 5 international
submarine cables providing connections to ASEAN
member nations, Japan, Taiwan, Australia, Middle
East, and Western Europe
Radio broadcast stations: AM 7, FM 13, shortwave
0(1998)
Radios: 4.45 million (1997)
Television broadcast stations: 4 (plus two
repeaters) (1997)
Televisions: 1.84 million (1997)
Internet Service Providers (ISPs): 49 (1999)
Telephones ■ main lines in use: 1 .893 million
(1995)
Telephones - mobile cellular: 1.269 million (1995)
Telephone system: the telephone system has been
modernized and is capable of satisfying all requests
for telecommunication service
domestic: the system is digitalized and highly
automated; trunk services are carried by fiber-optic
cable and digital microwave radio relay; a program for
fiber-optic subscriber connections was initiated in
1 996; heavy use is made of mobile cellular telephones
international: Hungary has fiber-optic cable
connections with all neighboring countries; the
international switch is in Budapest; satellite earth
stations - 2 Intelsat (Atlantic Ocean and Indian Ocean
regions), 1 Inmarsat, 1 very small aperture terminal
(VSAT) system of ground terminals
Radio broadcast stations: AM 17, FM 57,
shortwave 3 (1998)
Radios: 7.01 million (1997)
Television broadcast stations: 39 (plus several
low-power stations) (1997)
Televisions: 4.42 million (1997)
Internet Service Providers (ISPs): 13 (1999)
Telephones - main lines in use: 1 ,087 (1983)
Telephones - mobile cellular: 0 (1 983)
Telephone system:
domestic: NA
international: radiotelephone service with Sydney
(Austraiia)
Radio broadcast stations: AM 0, FM 3, shortwave
0(1998)
Radios: 2,500(1996)
Television broadcast stations: 1 (local
programming station plus two repeaters that bring in
Australian programs by satellite) (1998)
Televisions: 1,200(1996)
Internet Service Providers (ISPs): NA','f3f27a8a5d52e99094272ae227497f93cc26f547253a2e80e0be3980ffb0979e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a935d74ef183f7167f4956ae8fd919fd1123db188f2dd08ac540291426db64b',2000,'CG','Congo','communications',146,'Telephones - main lines in use: 21 ,000 (1 995)
Telephones - mobile cellular: NA
Telephone system: services barely adequate for
government use; key exchanges are in Brazzaville,
Pointe-Noire, and Loubomo; intercity lines frequently
out-of-order
domestic: primary network consists of microwave
radio relay and coaxial cable
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations; AM 1 , FM 5, shortwave
1 (1999)
Radios: 341,000(1997)
Television broadcast stations; 1 (1999)
Televisions: 33,000(1997)
Internet Service Providers (ISPs); NA
f transportation
Railways;
total: 795 km (includes 285 km private track)
narrow gauge: 795 km 1.067-m gauge (1995 est.)
Highways;
total: 12,800 km
paved: 1,242 km
unpaved: 11,558 km (1996 est.)
Waterways: the Congo and Ubangi (Oubangui)
rivers provide 1 ,120 km of commercially navigable
wafer transport; other rivers are used for local traffic
only
Pipelines: crude oil 25 km
Ports and harbors: Brazzaville, Impfondo, Ouesso,
Oyo, Pointe-Noire
Airports; 36 (1999 est.)
Airports - with paved runways:
total: 4
over 3,047 m:1
1,524 to 2,437 m: 3 [1999 est.)
Airports - with unpaved runways:
total: 32
1,524 to 2,437 m:S
914 to 1,523 m:U
under 914 m: 1 0 (1 999 est.)
117
Congo, Republic of the (continued)','07ef1fa8c8b225a7b95ded83bb7371ac749c20b958d2a83a328c0b45666cd5ee','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4693ff18bf112eccf495682c89d80f6e1fd2e161f3c3e025ac32f77397e40233',2000,'CK','Cook Islands','communications',155,'Communications - note: there are automatic
weather stations on many of the isles and reefs
relaying data to the mainland
T r a n s p 0 r t a t i 0 n
Ports and harbors: none; offshore anchorage only
Telephones - main iines in use: 451 ,000 (525,700
main lines installed) (yearend 1996)
Telephones - mobile cellular: 46,500 (December
1996)
Telephone system: very good domestic telephone
service
domestic: point-to-point and point-to-muiti-point
microwave, fiber-optic and coaxial cable link rural
areas; Internet service is available
international: connected to Central American
Microwave System; satellite earth stations - 2 Intelsat
(Atlantic Ocean); two submarine cables (1999)
Radio broadcast stations; AM 50, FM 43,
shortwave 19 (1998)
Radios: 980,000(1997)
Television broadcast stations; 6 (plus 1 1
repeaters) (1997)
Televisions: 525,000(1997)
Internet Service Providers (ISPs): 2 (1 999)','bc52e1900057f666d041353e18e5e39e63a4a6ea0916ed337266490c9a7cb13c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b74c20e61ba09b0cc0ee7f459a99d1fc47d7e3b0ab861fe70b89112dfd1ff582',2000,'PE','Peru','communications',178,'Telephones - main lines in use: 380,000 (1998)
Telephones - mobile cellular: 1 3,475 (1 995)
Telephone system:
domestic: nationwide microwave radio relay system
international: satellite earth station - 1 Intelsat
(Atlantic Ocean); connected to Central American
Microwave System
Radio broadcast stations: AM 61 (plus 24
repeaters), FM 30, shortwave 0 (1998)
Radios: 2.75 million (1997)
Television broadcast stations: 5 (1997)
Televisions: 600,000(1990)
Internet Service Providers (ISPs): 2 (1999)','28dc8a8d50ef92623cb379cce3ba771955130342cb89d5144b6a48c48c5ef29c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96abf22adbff21eeff776a821f3d003a1542c056a872076b4d1eb795f0977c87',2000,'GN','Guinea','communications',184,'Telephones - main lines in use; 23,578 (2000)
Telephones - mobile cellular; 0 (1 995)
Telephone system:
domestic: very inadequate; most telephones are in
Asmara; government is seeking international tenders
to improve the system
international: NA
Radio broadcast stations: AM 2, FM 1, shortwave
2 (2000)
Radios: 345,000(1997)
Television broadcast stations: 1 (2000)
Televisions: 1,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Telephones - main lines in use: 476,078 (yearend
1998)
Telephones - mobile cellular: 246,000 (yearend
1998)
Telephone system: foreign investment in the form
of joint business ventures greatly improved telephone
service; Internet services available throughout most of
the country; about 150,000 unfilled subscriber
requests
domestic: local - the Ministry of Transport and
Communications is expanding cellular telephone
services to form rural networks; intercity - highly
developed fiber-optic backbone (double loop) system
presently serving at least 16 major cities (1998)
international: fiber-optic cables to Finland, Sweden,
Latvia, and Russia provide worldwide packet switched
service; two international switches are located in
Tallinn
Radio broadcast stations: AM 3 (all AM stations
inactive since July 1998), FM 82, shortwave 1 (1998)
Radios: 1.01 million (1997)
Television broadcast stations: 31 (plus five
repeaters) (September 1995)
Televisions: 605,000(1997)
Internet Service Providers (ISPs): 6 (1999)
t Transportation
Railways:
total: 1 ,018 km common carrier lines only; does not
Include dedicated industrial lines
broad gauge: 1 ,018 km 1 .520-m gauge (132 km
electrified) (1995)
Highways:
total: 49,480 km
paved: 10,935 km (including 75 km of expressways)
urrpaved; 38,545 km (1998 est.)
Waterways: 320 km perennially navigable
Pipelines: natural gas 420 km (1992)
Ports and harbors: Haapsalu, Kunda, Muuga,
Paldiski, Parnu, Tallinn
Merchant marine:
total: 50 ships (1 ,000 GRT or over) totaling 306,264
GRT/293,083 DWT
ships by type: bulk 3, cargo 20, combination bulk 1 ,
container 5, petroleum tanker 2, roll-on/roll-off 13,
short-sea passenger 6 (1999 est.)
Airports: 5 (1997 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m:t
914 to 1,523 m; 3 (1997 est.)
I Military
Military branches: Ground Forces, Navy/Coast
Guard, Air and Air Defense Force (not officially
sanctioned). Maritime Border Guard, Volunteer
Defense League (Kaitseliit), Security Forces (internal
and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 359,764 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 282,456 (2000 est.)
Military manpower - reaching military age
annually;
males: 10,965 (2000 est.)
158
Estonia (continued)
Military expenditures - dollar figure: $70 million
(FY99)
Military expenditures - percent of GDP: 1 .2%
(FY99)
I Transnational Issues
Disputes - international: Estonian and Russian
negotiators reached a technical border agreement in
December 1996 which has not been signed or ratified
as of 1 January 2000
Illicit drugs: transshipment point for opiates and
cannabis from Southwest Asia and the Caucasus via
Russia, cocaine from Latin America to Western
Europe and Scandinavia, and synthetic drugs from
Western Europe to Scandinavia; possible precursor
manufacturing and/or trafficking
Background: Unique among African countries, the
ancient Ethiopian monarchy maintained its freedom
from colonial rule, one exception being the Italian
occupation of 1936-41. In 1974 a military junta, the
Derg, deposed Emperor Haile SALASSIE (who had
ruled since 1930) and established a socialist state.
Torn by bloody coups, uprisings, wide-scale drought,
and massive refugee problems, the regime was finally
toppled by a coalition of rebel forces, the Ethiopian
People''s Revolutionary Democratic Front (EPRDF), in
1 991 . A constitution was adopted in 1 994 and
Ethiopia''s first multiparty elections were held in 1995.
A border war with Eritrea that erupted in May 1 998 has
strengthened the ruling coalition, but has hurt the
nation''s economy.
G e 0 g r a p h y
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
fofa/;1,127,127 sq km
/and; 1,1 19,683 sq km
water: 7,444 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,31 1 km
border countries: Djibouti 337 km, Eritrea 912 km,
Kenya 830 km, Somalia 1 ,626 km, Sudan 1 ,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central mountain range
divided by Great Rift Valley
Elevation extremes:
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small resen/es of gold, platinum,
copper, potash, natural gas, hydropower
Land use:
arable land: 12%
permanent crops: tVo
permanent pastures: 40%
forests and woodland: 25%
of/)er;22%(1993est.)
Irrigated land: 1 ,900 sq km (1 993 est.)
Natural hazards: geologically active Great Rift
Valley susceptible to earthquakes, volcanic eruptions;
frequent droughts
Environment - current issues: deforestation;
overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection
signed, but not ratified: Environmental Modification,
Law of the Sea, Nuclear Test Ban
Geography ■ note: landlocked - entire coastline
along the Red Sea was lost with the de jure
independence of Eritrea on 24 May 1993
I People”
Population: 64,117,452
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: A7% (male 15,167,395; female
14,977,346)
15-64 years: 50% (male 1 6,1 95,637; female
15,987,089)
65 years and over: 3% (male 81 6,01 1 ; female
973,974) (2000 est.)
Population growth rate: 2.76% (2000 est.)
Birth rate: 45.1 3 births/1 ,000 population (2000 est.)
Death rate: 17.63 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.14 migrant(s)/1 ,000
population (2000 est.)
note: repatriation of Ethiopians who fled to Sudan for
refuge from war and famine in earlier years is
expected to continue for several years; small numbers
of Sudanese and Somali refugees, who fled to
Ethiopia from the fighting or famine in their own
countries, continue to return to their homes
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.01 male(s)/female (2000 est.)
Infant mortality rate: 1 01 .29 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 45.1 7 years
Ethiopia (continued)
mate: 44.41 years
female: A5.94 years (2000 est.)
Total fertility rate: 7.07 children born/wonnan
(2000 est.)
Nationaiity:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Annhara and Tigre
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic, Tigrinya, Orominga,
Guaraginga, Somali, Arabic, other local languages,
English (major foreign language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
fema/e; 25.3% (1995 est.)
I Government
Country name:
conventional long form: Federal Democratic Republic
of Ethiopia
conventional short form: Ethiopia
local long form: Ityop''iya Federalawi Demokrasiyawi
Ripeblik
local short form: Ityop''iya
abbreviation: FDRE
Data code: ET
Government type: federal republic
Capital: Addis Ababa
Administrative divisions: 9 ethnically-based
administrative regions (astedader akababiwach,
singular - astedader akabibi) and 2 chartered cities*:
Addis Ababa*; Afar; Amhara, Benishangul/Gumaz;
Dire Dawa*; Gambela; Harar; Oromia; Somali;
Southern Nations, Nationalities, and Peoples Region;
Tigray
Independence: oldest independent country in Africa
and one of the oldest in the world - at least 2,000
years
National holiday: National Day, 28 May (1991)
(defeat of MENGISTU regime)
Constitution: ratified December 1994; effective 22
August 1995
Legal system: currently transitional mix of national
and regional courts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President NEGASSO Gidada (since 22
August 1995)
head of government: Prime Minister MELES Zenawi
(since NA August 1995)
cabinet: Council of Ministers as provided for in the
December 1994 constitution; ministers are selected
by the prime minister and approved by the House of
People''s Representatives
elections: president elected by the House of People''s
Representatives for a six-year term; election last held
NA June 1995 (next to be held NA May 2001); prime
minister designated by the party in power following
legislative elections
election results: NEGASSO Gidada elected
president; percent of vote by the House of People''s
Representatives - NA
Legislative branch: bicameral Parliament consists
of the House of Federation or upper chamber (117
seats; members are chosen by state assemblies to
serve five-year terms) and the House of People''s
Representatives or lower chamber (548 seats;
members are directly elected by popular vote from
single-member districts to serve five-year terms)
elections: regional and national popular elections
were held in May and June 1995 (next to be held NA
May 2000)
election results: percent of vote - NA; seats - EPRDF
483, regional political groupings 46, independents 8;
note - 1 1 seats unconfirmed
note: many opposition groups, including the Oromo
Liberation Front, boycotted the election
Judicial branch: Federal Supreme Court; the
president and vice president of the Federal Supreme
Court are recommended by the prime minister and
appointed by the House of People''s Representatives;
for other federal judges, the prime minister submits
candidates selected by the Federal Judicial
Administrative Council to the House of People’s
Representatives for appointment
Political parties and leaders: All-Amhara People''s
Organization or AAPO [Dr. ASRAT Woldeyesj;
Coalition of Alternative Forces for Peace and
Democracy or CAFPD [leader NA); Ethiopian
Democratic Union or EDU [leader NA]; Ethiopian
Movement for Democracy, Peace, and Unity or
EMDPU [GOSHU Waldej; Ethiopian National
Democratic Party or ENDP [NEBIYU Samuel,
FEKADU Gedamuj; Ethiopian People''s Revolutionary
Democratic Front or EPRDF [MELES Zenawi]; Oromo
Liberation Front or OLF [GELASA Dilboj; dozens of
small parties
Political pressure groups and leaders: Southern
Ethiopia People''s Democratic Coalition; numerous
small, ethnically based groups have formed since the
defeat of the former MENGISTU regime in 1991 ,
including several Islamic militant groups
International organization participation: ACP,
AfDB, CCC, EGA, FAO, G-24, G-77, IAEA, IBRD,
ICAO, ICRM, IDA, IFAD, IFC, IFRCS, IGAD, ILO, IMF,
IMO, Intelsat, Interpol, IOC, lOM (observer), ISO, ITU,
NAM, OAU, OPCW, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNU, UPU, WFTU, WHO, WlPO,
WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador BERHAN E
Gebre-Christos
chancery: 21 34 Kalorama Road NW, Washington, DC
20008
fe/ephorre; [11(202) 234-2281
FAX; [11(202) 328-7950
Diplomatic representation from the US:
chief of mission: Ambassador Tibor P. NAGY
embassy: Entoto Street, Addis Ababa
mailing address: P. 0. Box 1014, Addis Ababa
fe/ephone; [2511 (1)550666
FAX;[2511 (1)551328
Flag description: three equal horizontal bands of
green (top), yellow, and red with a yellow pentagram
and single yellow rays emanating from the angles
between the points on a light blue disk centered on the
three bands; Ethiopia is the oldest independent
country in Africa, and the colors of her flag were so
often adopted by other African countries upon
independence that they became known as the
pan-African colors
I Economy
Economy - overview: Ethiopia''s economy is based
on agriculture, which accounts for half of GDP, 90% of
exports, and 80% of total employment. The
agricultural sector suffers from frequent periods of
drought and poor cultivation practices, and as many
as 4.6 million people need food assistance annually.
Coffee is critical to the Ethiopian economy, and
Ethiopia earned $267 million in 1999 by exporting
105,000 metric tons. According to current estimates,
coffee contributes 10% of Ethiopia''s GDP. More than
15 million people (25% of the population) derive their
livelihood from the coffee sector. Other exports
include live animals, hides, gold, and qat. In
December 1999, Ethiopia signed a $1 .4 billion joint
venture deal to develop a huge natural gas field in the
Somali Regional State. The war with Eritrea has
forced the government to spend scarce resources on
the military and forced the government to scale back
ambitious development plans. Foreign investment has
declined significantly. Government taxes imposed in
late 1 999 to raise money for the war will depress an
already weak economy. The war has forced the
government to improve roads and other parts of the
previously neglected infrastructure, but only certain
regions of the nation have benefited.
GDP: purchasing power parity - $33.3 billion
(1999 est.)
GDP - real growth rate: 0% (1999 est.)
GDP - per capita: purchasing power parity - $560
(1999 est.)
GDP - composition by sector:
agriculture: 46%
Industry: 12%
services: 42% (1 998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4% (1999 est.)
Labor force: NA
Labor force - by occupation: agriculture and
animal husbandry 80%, government and sen/ices
12%, industry and construction 8% (1985)
Unemployment rate: NA%
Budget:
revenues: $1 billion
160
Ethiopia (continued)
expenditures: $1 .48 billion, including capital
expenditures of $415 million (FY96/97)
Industries: food processing, beverages, textiles,
chemicals, metals processing, cement
Industrial production growth rate; NA%
Electricity - production: 1.36 billion kWh (1998)
Electricity - production by source:
fossil fuel: 7.35%
hydro: 89.34%
nuclear: 0%
of/rer; 3.31% (1998)
Electricity - consumption: 1 .265 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products; cereals, pulses, coffee,
oilseed, sugarcane, potatoes; hides, cattle, sheep,
goats
Exports: $420 million (f.o.b., 1998)
Exports - commodities; coffee, gold, leather
products, oilseeds
Exports - partners: Germany 22%, Japan 12%,
Italy 9%, UK5%(1997est.)
Imports: $1.25 billion (f.o.b., 1998 est.)
Imports - commodities: food and live animals,
petroleum and petroleum products, chemicals,
machinery, motor vehicles
Imports - partners: Italy 10%, US 9%, Japan 8%,
Jordan 5% (1997 est.)
Debt - external: $1 0 billion (1 997)
Economic aid - recipient: $367 million (FY95/96)
Currency: 1 birr (Br) = 100 cents
Exchange rates: birr (Br) per US$1 (end of period) -
8.2 (January 2000), 7.5030 (1998), 6.8640 (1997),
6.4260 (1996), 6.3200 (1995)
note: since May 1 993, the birr market rate has been
determined in an interbank market supported by
weekly wholesale auction; prior to that date, the
official rate was pegged to US$1 = 5.000 birr
Fiscal year: 8 July - 7 July
I Communications
Telephones - main lines in use: 365,000 (1999)
Telephones - mobile cellular; 4,000 (1 999)
Telephone system: open wire and microwave radio
relay system adequate for government use
domestic: open wire; microwave radio relay; radio
communication in the HF, VHF, and UHF frequencies;
two domestic satellites provide the national trunk
service
international: open wire to Sudan and Djibouti;
microwave radio relay to Kenya and Djibouti; satellite
earth stations - 3 intelsat (1 Atlantic Ocean and 2
Pacific Ocean)
Radio broadcast stations; AM 5, FM 0, shortwave
2(1999)
Radios; 1 1 .75 million (1997)
Television broadcast stations: 25 (1999)
Televisions; 320,000(1997)
Internet Service Providers (ISPs): 1 (1999)
I transportation
Railways;
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1.000-m gauge
note: in April 1998, Djibouti and Ethiopia announced
plans to revitalize the century-oid railroad that links
their capitals; since May 1998 Ethiopia has expended
considerable effort to repair and maintain the iines
Highways:
total: 28,500 km
paved: 4,275 km
unpaved: 24,225 km (1 996 est.)
Ports and harbors: none; Ethiopia is landlocked
and was by agreement with Eritrea using the ports of
Assab and Massawa; since the border dispute with
Eritrea flared, Ethiopia has used the port of Djibouti for
nearly all of Its imports
Merchant marine:
total: 1 2 ships (1 ,000 GRT or over) totaling 84,91 5
GRT/1 1 2,634 DWT
ships by type: cargo 7, container 1 , petroleum tanker
1, roll-on/roll-off 3 (1999 est.)
Airports; 85 (1999 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 3
2,438 to 3,047 m: 8
1,524 to 2,437 m: 2 {m9esl)
Airports - with unpaved runways:
total: 74
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m:U
914 to 1,523 m: 35
under 914 m: 19 {1 999 est.)
f Military
Military branches; Ground Forces, Air Force,
Police, Militia
note: Ethiopia is landlocked and has no navy;
following the independence of Eritrea, Ethiopian naval
facilities remained in Eritrean possession and ships
which belonged to the former Ethiopian Navy and
based at Djibouti have been sold
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 14,184,072 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 7,392,677 (2000 est.)
Military manpower - reaching military age
annually;
mates: 686,801 (2000 est.)
Military expenditures - dollar figure; $138 million
(FY98/99)
Military expenditures - percent of GDP; 2.5%
(FY98/99)
I Transnational Issues
Disputes - international; most of the southern half
of the boundary with Somalia is a Provisional
Administrative Line; territorial dispute with Somalia
over the Ogaden; dispute over aiignment of boundary
with Eritrea led to armed conflict in 1 998, which is still
unresolved despite arbitration efforts
Illicit drugs: transit hub for heroin originating in
Southwest and Southeast Asia and destined for
Europe and North America as well as cocaine
destined for markets in southern Africa; cultivates qat
(chat) for iocai use and regional export, principally to
Djibouti and Somalia
161
Europa Island H ■
(possession of France)
G e b graph y
Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from southern
Madagascar to southern Mozambique
Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total: 28 sq km
land: 28 sq km
water: 0 sq km
Area - comparative: about 0.1 6 times the size of
Washington, DC
Land boundaries: 0 km
Coastiine: 22.2 km
Maritime claims:
exclusive economic zone: 200 nm
fern''tor/a/ sea; 12 nm
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues: NA
Geography - note: wildlife sanctuary
Communications - note: 1 meteorological station
I Transportation
Ports and harbors: none; offshore anchorage only
Airports: 1 (1 999 est.)
Airports • with unpaved runways:
total: 1
914 to 1,523 m; 1 (1999 est.)','23ce7cd1b0ca7b56fcd3cff15708d48d5cd09f1bd06f05037975192e5b190a19','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9860a011ce7ae1737460fd1a10b968dd322a18ada8333e9d0d34b45e5ed03aa9',2000,'JE','Jersey','communications',198,'Telephones - main lines in use: 2.861 million
(1997)
Telephones - mobile cellular: 2,162,574 (1997)
Telephone system: modern system with excellent
sen/ice
domestic: cable, microwave radio relay, and an
extensive cellular net take provide of domestic needs
international: 1 submarine cable; satellite earth
stations - access to Intelsat transmission service via a
Swedish satellite earth station, 1 Inmarsat (Atlantic
and Indian Ocean regions); note - Finland shares the
Inmarsat earth station with the other Nordic countries
(Denmark, Iceland, Norway, and Sweden)
Radio broadcast stations: AM 2, FM 186,
shortwave 1 (1998)
Radios: 7.7 million (1997)
Television broadcast stations: 130 (plus 385
repeaters) (1995)
Televisions: 3.2 million (1997)
Internet Service Providers (ISPs): 36 (1 999)
i Transportation
Railways:
total: 5,865 km
broad gauge: 5,865 km 1.524-m gauge (2,192 km
electrified; 480 km double- or multiple-track) (1998)
Highways:
total: 77,895 km
paved: 49,853 km (including 473 km of expressways)
unpaved: 28,042 km (1998 est.)
Waterways: 6,675 km total (including Saimaa
Canal); 3,700 km suitable for steamers
Pipelines: natural gas 580 km
Ports and harbors: Hamina, Helsinki, Kokkola,
Kotka, Loviisa, Oulu, Pori, Rauma, Turku,
Uusikaupunki, Varkaus
Merchant marine:
total: 1 01 ships (1 ,000 GRT or over) totaling
1,185,966 GRT/1,153,089DWT
ships by type: bulk 9, cargo 23, chemical tanker 6,
passenger 1 , petroleum tanker 1 1 , rail car carrier 1 ,
roll-on/roll-off 38, short-sea passenger 12 (1999 est.)
Airports: 157 (1999 est.)
Airports - with paved runways:
total: 69
over 3,047 m: 3
2,438 to 3,047 m: 26
1,524 to 2,437m: to
914 to 1,523 m: 20
under 914 m: 10 (1999 est.)
Airports - with unpaved runways:
total: 88
914 to 1,523 m: 6 i
under 914 m: 82 (1999 est.)
Telephones - main lines in use: 7,000 (1995)
Telephones - mobile cellular: 230 (1995)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 3, FM 0, shortwave
0(1998)
Radios: 57,000(1997)
Television broadcast stations: 0 (1997)
Televisions: 3,000(1997)
Internet Service Providers (ISPs): NA
V transportation
Railways: 0 km
Highways;
total: 1 ,360 km
paved: 34 km
unpaved: 1 ,326 km (includes about 800 km of private
plantation roads) (1996 est.)
Ports and harbors: Aola Bay, Honiara, Lofung,
Noro, Viru Harbor, Yandina
Merchant marine: none (1999 est.)
Airports: 33 (1999 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1,523 m;1 (1999 est.)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 21 (1999 est.)','fd2cb1916d32d7a8ccdbb6e45d527d34a3af65312055baecc07111ae328c527a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d737307b662ee6aea11ac59337f79ce8dc90e9f44a56a8432affea9d4d08b0a2',2000,'GH','Ghana','communications',217,'Telephones - main lines in use: 200,000
(1998 est.)
Telephones - mobile cellular: 30,000 (yearend
1998)
191
Ghana (continued)
Telephone system: poor to fair system; Internet
accessible; many rural communities not yet
connected; expansion of services is underway
domestic: primarily microwave radio relay; wireless
local loop has been installed
mternationai: satellite earth stations - 4 Intelsat
(Atlantic Ocean); microwave radio relay link to
Panaftel system connects Ghana to its neighbors
Radio broadcast stations: AM 0, FM 1 8, shortwave
3(1999)
Radios: 4.4 million (1997)
Television broadcast stations: 11 (1999)
Televisions: 1.73 million (1997)
Internet Service Providers (ISPs): 2 (1999)
i transportation
Railways:
totai: 953 km (undergoing major rehabilitation)
narrow gauge: 953 km 1.067-m gauge (32 km double
track) (1997 est.)
Highways:
totai: 39,409 km
paved: 1 1 ,653 km (including 30 km of expressways)
unpaved: 27,756 km (1997 est.)
Waterways: Volta, Ankobra, and Tano Rivers
provide 168 km of perennial navigation for launches
and lighters; Lake Volta provides 1 ,125 km of arterial
and feeder waterways
Pipelines: 0 km
Ports and harbors: Takoradi, Tema
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 3,484
GRT/1 8,583 DWT
ships by type: petroleum tanker 2, refrigerated cargo
4(1999 est.)
Airports: 12 (1999 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m:-[
1,524 to 2,437 m: 3
914 to 1,523 m: 2 {1999 est.)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 914 m: 2 {1 999 est.)
I Military
Military branches: Army, Navy, Air Force, National
Police Force, Palace Guard, Civil Defense
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 4,739,526 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,629,954 (2000 est.)
Military manpower - reaching military age
annually:
mates; 196,549 (2000 est.)
Military expenditures - dollar figure: $53 million
(FY99)
Military expenditures - percent of GDP: 0.7%
(FY99)
I Transn^tiohal 1 s s iTe s
Disputes - international: none
Illicit drugs: illicit producer of cannabis for the
international drug trade; transit hub for Southwest and
Southeast Asian heroin and South American cocaine
destined for Europe and the US
fGibraltar
|:(bverseas territory
of the UK)
0 1/2 1 km '''' ''4
— r-- - 1 \\ SPAIN
1/2 imi \\_ - NEUTRAL
ZONE
Strait of Gibraltar
lighthouse
I ” In t r 0 d u c t i o n
Background: Strategically important Gibraltar was
ceded to Great Britain by Spain in 1713. In a 1967
referendum, Gibraltarians ignored Spanish pressure
and voted overwhelmingly to remain a British
dependency.
. ''"‘G''e''ogTa p¥y
Location: Southwestern Europe, bordering the Strait
of Gibraltar, which links the Mediterranean Sea and
the North Atlantic Ocean, on the southern coast of','d720e11bafaba723c11021e28f1c001994ed39fc8cafd52ee7c59faf85f3de25','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6939ca06d14f22773d69afea681471c139e65481c3ec9e6cbd17b244c2409f05',2000,'ES','Spain','communications',218,'Geographic coordinates: 36 1 1 N, 5 22 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries:
total: 1 .2 km
border countries: Spain 1 .2 km
Coastline: 12 km
Maritime claims:
territorial sea: 3 nm
Climate: Mediterranean with mild winters and warm
summers
Terrain: a narrow coastal lowland borders the Rock
of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other; 100% (1993 est.)
192
Gibraltar (continued)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: limited natural
freshwater resources; large concrete or natural rock
water catchments collect rain water
Geography - note: strategic location on Strait of
Gibraltar that links the North Atlantic Ocean and
Mediterranean Sea
- -
Population: 29,481 (July 2000 est.)
Age structure:
0-14yea.rs-.2yia (male 3,167; female 3,013)
15-64 years: 65% (male 10,141; female 8,925)
65 years and over: 1 4% (male 1 ,769; female 2,466) .
(2000 est.)
Population growth rate: 0.91% (2000 est.)
Birth rate: 14.14 births/1,000 population (2000 est.)
Death rate: 8.45 deaths/1,000 population
(2000 est.)
Net migration rate: 3.39 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.14 male(s)/female
65 years and over. 0.72 male(s)/female
total population: 1.05 male(s)/female (2000 est.)
Infant mortality rate: 5.6 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.95 years
male: 76.09 years
female: 81 .96 years (2000 est.)
Total fertility rate: 2.15 children born/woman
(2000 est.)
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Italian, Engiish, Maltese,
Portuguese, Spanish
Religions: Roman Catholic 76.9%, Church of
England 6.9%, Muslim 6.9%, Jewish 2.3%, none or
other 7% (1991)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese, Russian
Literacy:
definition: NA
total population: above 80%
male: NA%
female: NA%
Country name:
conventional long form: none
conventional short form: Gibraltar
Data code: Gl
Dependency status: overseas territory of the UK
Government type: NA
Capital: Gibraltar
Administrative divisions: none (overseas territory
of the UK)
Independence: none (overseas territory of the UK)
National holiday: Commonwealth Day (second
Monday of March)
Constitution: 30 May 1969
Legal system: English law
Suffrage: 18 years of age; universal, plus other UK
subjects who have been residents six months or more
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor and
Commander-in-Chief, the Right Honorable Sir Richard
LUCE (since 24 February 1 997); note - a new governor
has been appointed and will arrive in March 2000
head of government: Chief Minister Peter CARUANA
(since 17 May 1996)
cabinet: Council of Ministers appointed from among
the 1 5 elected members of the House of Assembly by
the governor in consultation with the chief minister
note: there is also a Gibraltar Council that advises the
governor
elections: none; the monarch is hereditary; governor
appointed by the monarch; chief minister appointed by
the governor
Legislative branch: unicameral House of Assembly
(1 8 seats - 1 5 elected by popular vote, one appointed
for the Speaker, and two ex officio members;
members serve four-year terms)
elections: last held 1 0 February 2000 (next to be held
NA2004)
election results: percent of vote by party - SD 54%,
GSLA 40%; seats by party - NA
Judicial branch: Supreme Court; Court of Appeal
Political parties and leaders: Gibraltar Labor
Party/Association tor the Advancement of Civil Rights
or GCL/AACR [Adolfo CANEPA]; Gibraltar Liberal
Party or GLP (has become the Gibraltar National
Party or NP) [Joe GARCIA]; Gibraltar Social
Democrats or SD [Peter CARUANA]; Gibraltar
Socialist Labor Party or SL [Joe BOSSANO]; Gibraltar
Socialist Liberal Alliance or GSLA [Joe BOSSANO]
(includes SL and GLP)
Political pressure groups and leaders: Chamber
of Commerce; Gibraltar Representatives
Organization; Housewives Association
International organization participation: Interpol
(subbureau)
Diplomatic representation in the US: none
(overseas territory of the UK)
Diplomatic representation from the US: none
(overseas territory of the UK)
Flag description: two horizontal bands of white (top,
double width) and red with a three-towered red castle
in the center of the white band; hanging from the
castie gate is a gold key centered in the red band
Economy - overview: Gibraltar benefits from an
extensive shipping trade, offshore banking, and its
position as an international conference center. The
British military presence has been sharply reduced
and now contributes about 11% to the local economy.
The financial sector accounts for 20% of GDP; tourism
(almost 6 million visitors in 1998), shipping services
fees, and duties on consumer goods also generate
revenue. In recent years, Gibraltar has seen major
structural change from a public to a private sector
economy, but changes in government spending still
have a major impact on the level of employment.
GDP: purchasing power parity - $500 million
(1997 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$17,500 (1997 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Popuiation beiow poverty line: NA%
Household income or consumption by percentage
share:
lov/est 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .5% (1 998)
Labor force: 14,800 (including non-Gibraltar
laborers) .
Labor force - by occupation: services 60%,
industry 40%, agriculture NEGL%
Unemployment rate: 13.5% (1996)
Budget:
revenues; $11 9.3 million
expenditures: $122.1 million, including capital
expenditures of $NA (FY96/97)
Industries: tourism, banking and finance,
ship-building and repairing; support to large UK naval
and air bases; tobacco, mineral water, beer, canned
fish
Industrial production growth rate: NA%
Electricity ■ production: 90 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1906)
Electricity - consumption: 84 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: none
Exports: $81.1 million (f.o.b., 1997)
Exports - commodities: (principally reexports)
petroleum 51%, manufactured goods 41%, other 8%
Exports - partners: UK, Morocco, Portugal,
Netherlands, Spain, US, Germany
Imports: $492 million (c.i.f., 1997)
Imports - commodities: fuels, manufactured
goods, and foodstuffs
Imports ■ partners: UK, Spain, Japan, Netherlands
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 Gibraltar pound = 100 pence
Exchange rates: Gibraltar pounds per US$1 -
0.6092 (January 2000), 0.61 80 (1999), 0.6037 (1 998),
0.6106 (1997), 0.6403 (1996), 0.6335 (1995); note -
the Gibraltar pound is at par with the British pound
Fiscal year: 1 July - 30 June
193
Gibraltar (continued)
Telephones - main lines in use: 17,000 (1995)
Telephones - mobile cellular: 1,161 (1 999)
Telephone system: adequate, automatic domestic
system and adequate internationai faciiities
domestic: automatic exchange faciiities
international: radiotelephone; microwave radio reiay;
satellite earth station - 1 1nteisat (Atiantic Ocean)
Radio broadcast stations: AM 1 , FM 5, shortwave
0(1998)
Radios: 37,000(1997)
Television broadcast stations: 1 (plus three
low-power repeaters) (1997)
Televisions: 10,000 (1997)
Internet Service Providers (ISPs): NA','c88e6d14800d339d6b8507c9d32604418cc9041669498348bdb667b32e09001d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('578b59155ece45d4cc17f95d839659161d23a5b3950f8c1bf4c9bbac5e2359cd',2000,'DK','Denmark','communications',224,'I transnational Issues
Disputes ■ international: none
Background: The smallest independent country in
the western hemisphere, Grenada was seized by a
Marxist military council on 1 9 October 1 983. Six days
later the island was invaded by US forces and those of
six other Caribbean nations, which quickly captured
the ringleaders and their hundreds of Cuban advisers.
Free elections were reinstituted the following year.
Location: Caribbean, island between the Caribbean
Sea and Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the Caribbean
Area:
total: 340 sq km
land: 340 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
fem''foria/sea;12 nm
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater
harbors
Land use:
arable land: 15%
permanent crops: 18%
permanent pastures: 3%
forests and woodland: 9%
other: 55% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: lies on edge of hurricane belt;
hurricane season lasts from June to November
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
I People
Population: 89,01 8 (July 2000 est.)
Age structure:
0-14 years: 38% (male 17,106; female 16,634)
15-64 years: 58% (male 27,267; female 24,356)
65 years and over: 4% (male 1 ,653; female 2,002)
(2000 est.)
Population growth rate: -0.36% (2000 est.)
Birth rate: 20.96 births/1,000 population (2000 est.)
Death rate: 8.02 deaths/1,000 population
(2000 est.)
Net migration rate: -1 6.54 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .07 male(s)/female (2000 est.)
Infant mortality rate: 14.63 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 64.52 years
male: 62.74 years
female: 66.31 years (2000 est.)
Total fertility rate: 2.42 children born/woman
(2000 est.)
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: black 82% some South Asians (East
Indians) and Europeans, trace Arawak/Carib
Amerindian
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant 33.2%
Languages: English (official), French patois
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 98% (1970 est.)
I Government
Country name:
conventional long form: none
conventional short form: Grenada
Data code: GJ
Government type: constitutional monarchy with
Westminster-style parliament
199
Gronada (continued)
Capital: Saint George''s
Administrative divisions: 6 parishes and 1
dependency*; Carriacou and Petit Martinique*, Saint
Andrew, Saint David, Saint George, Saint John, Saint
Mark, Saint Patrick
Independence: 7 February 1974 (from UK)
National holiday: Independence Day, 7 February
(1974)
Constitution: 19 December 1973
Legal system: based on English common law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Daniel
WILLIAMS (since 9 August 1996)
head of government: Prime Minister Keith MITCHELL
(since 22 June 1995)
cabinet: Cabinet appointed by the governor general
on the advice of the prime minister
eiections: none; the monarch is hereditary; governor
general appointed by the monarch; prime minister
appointed by the governor general from among the
members of the House of Assembly
Legislative branch: bicameral Parliament consists
of the Senate (a 13-member body, 10 appointed by
the government and three by the leader of the
opposition) and the House of Representatives (15
seats; members are elected by popular vote to serve
five-year terms)
elections: last held on 18 January 1999 (next to be
held by NA October 2004)
election results: House of Representatives - percent
of vote by party - NA; seats by party - NNP 1 5
Judicial branch: West Indies Associate States
Supreme Court (an associate judge resides in
Grenada)
Political parties and leaders: Grenada United
Labor Party or GULP [Herbert PREUDHOMME);
Maurice Bishop Patriotic Movement or MBPM
[Terrence MARRYSHOW]; National Democratic
Congress or NDC [George BRIZAN); New National
Party or NNP [Keith MITCHELL]; The Democratic
Labor Party or DLP [Francis ALEXIS); The National
Party or TNP [Ben JONES]
International organization participation: ACP, C,
Caricom, CDB, ECLAC, FAO, G-77, IBRD, ICAO,
ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Interpol, IOC, ISO (subscriber), ITU, LAES, NAM,
OAS, OECS, OPANAL, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WHO, WlPO, WToO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Denis G. ANTOINE
chancery: 1701 New Hampshire Avenue NW,
Washington, DC 20009
fe/eptone;[1](202) 265-2561
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Vne ambassador to Barbados is
accredited to Grenada; Charge d''Affairs Lloyd MOSS
embassy: Point Salines, Saint George''s
mailing address: P. 0. Box 54, Saint George''s,
Grenada, West Indies
telephone: [1] (473) 444-1173 through 1176
FAX: [1] (473) 444-4820
Flag description: a rectangle divided diagonally into
yellow triangles (top and bottom) and green triangles
(hoist side and outer side), with a red border around
the flag; there are seven yellow, five-pointed stars with
three centered in the top red border, three centered in
the bottom red border, and one on a red disk
superimposed at the center of the flag; there is also a
symbolic nutmeg pod on the hoist-side triangle
(Grenada is the world''s second-largest producer of
nutmeg, after Indonesia); the seven stars represent
the seven administrative divisions
Telephones ■ main lines in use: 23,000 (1995)
Telephones ■ mobile cellular: 400 (1995)
Telephone system: automatic, islandwide
telephone system
domestic: interisland VHF and UHF radiotelephone
links
internationai: new SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad
Radio broadcast stations: AM 2, FM 1 , shortwave
0(1998)
Radios: 57,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 33,000(1997)
Internet Service Providers (ISPs): 1 (1999)','fefcafe22d759e7556e40475dbcfa19beeb430607f2e8c6866fbb8c97199d0b9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d0e9ab042400a1d2100714695138320d2d2f1099ee872286d6f76100502f74b',2000,'ET','Ethiopia','communications',229,'Telephones - main lines in use; 13,120 (1995)
Telephones - mobile cellular; NA
Telephone system: small system
domestic: combination of microwave radio relay,
open-wire lines, radiotelephone, and cellular
International: NA
Radio broadcast stations: AM 1 , FM 2, shortwave
0(1998)
Radios: 49,000(1997)
Television broadcast stations; 2 (1997)
Televisions; NA
internet Service Providers (iSPs): NA
Telephones - main lines in use: 3,000 (1995)
Telephones - mobile cellular: NA
Telephone system:
domestic: minimal system
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 4, shortwave
0(1998)
Radios: 38,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 23,000(1997)
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 3.1 million (1998)
Telephones - mobile cellular; 1 million
note: in 1998, the government contracted for the
installation of 575,000 additional Group Specials
Mobile (GSM) cellular telephone lines over 1 5 months
to raise the total number of subscribers to more than
one million; Riyadh planned to further expand the
GSM system in 1999 by adding an additional one
million lines (1998)
434
Saudi Arabia (continued)
Telephone system: modern system
domestic: extensive microwave radio reiay and
coaxiai and fiber-optic cabie systems
international: microwave radio reiay to Bahrain,
Jordan, Kuwait, Qatar, UAE, Yemen, and Sudan;
coaxial cable to Kuwait and Jordan; submarine cable
to Djibouti, Egypt and Bahrain; satellite earth
stations - 5 Intelsat (3 Atlantic Ocean and 2 Indian
Ocean), 1 Arabsat, and 1 1nmarsat (Indian Ocean
region)
Radio broadcast stations; AM 43, FM 31,
shortwave 2 (1998)
Radios: 6.25 million (1997)
Television broadcast stations: 1 1 7 (1997)
Televisions: 5.1 million (1997)
Internet Service Providers (ISPs); 6 (1999)
I Transportation
Railways:
total: 1 ,390 km
standard gauge: t, 390 km 1.435-m gauge (448 km
double track) (1992)
Highways;
fofa/; 146,524 km
paved; 44, 104 km
unpaved: 102,420 km (1997 est.)
Pipelines: crude oil 6,400 km; petroleum products
150 km; natural gas 2,200 km (includes natural gas
liquids 1,600 km)
Ports and harbors: Ad Dammam, Al Jubayl, Duba,
Jiddah, Jizan, Rabigh, Ra''s al Khafji, Mishab, Ras
Tanura, Yanbu'' al Bahr, Madinat Yanbu'' al Sinaiyah
Merchant marine;
total: 70 ships (1 ,000 GRT or over) totaling 1 ,071 ,003
GRT/1 ,388,802 DWT
ships by type: cargo 12, chemical tanker 7, container
5, liquified gas 1 , livestock carrier 3, passenger 1 ,
petroleum tanker 17, refrigerated cargo 4, roll-on/
roll-off 12, short-sea passenger 8 (1999 est.)
Airports; 205 (1999 est.)
Airports - with paved runways;
total: 72
over 3,047 m: 31
2,438 to 3,047 m: 13
1,524 to 2,437 m: 23
914 to 1,523 m: 3
under 914 m: 2 [1999 est)
Airports - with unpaved runways;
total: 133
2,438 to 3,047 m: 4
1,524 to 2,437 m: 77
914 to 1,523 m: 39
under 914 m: 13 (1999 est.)
Heliports: 4 (1999 est.)
p MTiitary
Military branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces (paramilitary)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 5,786,089 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 3,225,809 (2000 est.)
Military manpower - reaching miiitary age
annually:
males: 221 ,026 (2000 est.)
Military expenditures -dollar figure: $18.1 billion
(FY97)
Military expenditures - percent of GDP; 1 2%
(FY97)
I T r a n s n a t i o n a I I s s u e s
Disputes - international: large section of boundary
with Yemen not defined; location and status of
boundary with UAE is not final, de facto boundary
reflects 1974 agreement; Kuwaiti ownership of Qaruh
and Umm al Maradim islands is disputed by Saudi
Arabia; June 1999 agreement has furthered the goal
of definitively establishing the border with Qatar
Illicit drugs: death penalty for traffickers; increasing
consumption of heroin and cocaine
Background: Independent from France in 1960,
Senegal joined with The Gambia to form the nominal
confederation of Senegambia in 1982. However, the
envisaged integration of the two countries was never
carried out, and the union was dissolved in 1989.
Despite peace talks, a southern separatist group
sporadically has clashed with government forces
since 1 982, Senegal has a long history of participating
in international peacekeeping.
!■ G''eo''grr¥p¥y
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and','86b48e34c6d4a058dd96485ed2fd29a8a71a98df17b3112874a884314b947a1b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63b2f0cedcaa6b7c494cc2d2b08b4c0e46f51b399759fb4f145b4c1338844d1b',2000,'GY','Guyana','communications',232,'Teiephones - main lines in use: 45,000 (1995)
Telephones - mobile cellular: 1 ,243 (1 995)
Telephone system: fair system for long-distance
calling
domestic: microwave radio relay network for trunk
lines
International: tropospheric scatter to Trinidad; satellite
earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3, shortwave
1 (1998)
Radios: 420,000(1997)
Television broadcast stations: 3 (one public
station; two private stations which relay US satellite
services) (1997)
Televisions: 46,000(1997)
Internet Service Providers (ISPs): 2 (1999)','02657f8e7fb64c8e558e867fb0e34b3248499d0ea10f1985daf1f858989cbe79','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8d2347cebabcd46b34cf1d37ab6586ffa31b452febb5cb3dfe2573d4492c257',2000,'IS','Iceland','communications',237,'Telephones - main lines in use: 1 62,31 0 (1 997)
Telephones - mobile cellular: 65,746 (1997)
Telephone system: adequate domestic service
domestic: the trunk network consists of coaxial and
fiber-optic cables and microwave radio relay links
228
ICGland (continued)
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean), 1 1nmarsat (Atlantic and Indian
Ocean regions); note - Iceland shares the Inmarsat
earth station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 3, FM about 70
(including repeaters), shortwave 1 (1998)
Radios: 260,000(1997)
Teievision broadcast stations: 14 (plus 1 56
low-power repeaters) (1997)
Televisions: 98,000(1997)
Internet Service Providers (ISPs): 14 (1 999)
f~~^fTa n s p 0 r ia t i o n
Railways: 0 km
Highways:
total: 12,689 km
paved: 3,439 km
unpaved: 9,250 km (1998 est.)
Ports and harbors: Akureyri, Hornafjordur,
Isafjordhur, Keflavik, Raufarhofn, Reykjavik,
Seydhisfjordhur, Straumsvik, Vestmannaeyjar
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 1 3,085
GRT/1 6,938 DWT
ships by type: chemical tanker 1 , container 1 ,
petroleum tanker 1 (1999 est.)
Airports: 86 (1999 est.)
Airports - with paved runways:
total: t2
over 3,047 m:t
1,524 to 2,437 m: 4
914 to 1,523 m: 7 (1999 est.)
Airports - with unpaved runways:
fpte/;74
1,524 to 2,437 m: 3
914 to 1,523 m: 19
under 914 m: 52 (1 999 est.)
MTTTtTr y ”
Military branches: no regular armed forces; Police,
Coast Guard; note - Iceland''s defense is provided by
the US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military manpower - availability:
males age 15-49: 71 ,486 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 62,990 (2000 est.)
Military expenditures - dollar figure: $0
Military - note: Iceland''s defense is provided by the
US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
iTTsTraTTYira T "TTs u e s
Disputes - international: Rockall continental shelf
dispute involving Denmark, Ireland, and the UK
(Ireland and the UK have signed a boundary
agreement in the Rockall area)
|~" f n t r 0 d u c t i 0 n
Background: Nonviolent resistance to British
colonialism under Mohandas GANDHI and Jawaharlal
NEHRU led to independence in 1947. The
subcontinent was divided into the secular state of
India and the smaller Muslim state of Pakistan. A third
war between the two countries in 1971 resulted In
East Pakistan becoming the separate nation of
Bangladesh. Fundamental concerns in India include
the ongoing dispute with Pakistan over Kashmir,
massive overpopulation, environmental degradation,
extensive poverty, and ethnic strife, all this despite
impressive gains in economic investment and output.
Geograp¥y
Location: Southern Asia, bordering the Arabian Sea
and the Bay of Bengal, between Burma and Pakistan
Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area:
total: 3,287,590 sq km
/arrd; 2,973,190 sq km
wafer; 314,400 sq km
Area - comparative: slightly more than one-third the
size of the US
Land boundaries:
total: 14,103 km
border countries: Bangladesh 4,053 km, Bhutan 605
km, Burma 1 ,463 km, China 3,380 km, Nepal 1 ,690
km, Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical monsoon in south to
temperate in north
Terrain: upland plain (Deccan Plateau) in south, flat
to rolling plain along the Ganges, deserts in west,
Himalayas in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest reserves In
the world), iron ore, manganese, mica, bauxite,
titanium ore, chromite, natural gas, diamonds,
petroleum, limestone, arable land
Land use:
arable land: 56%
permanent crops: 1%
permanent pastures: 4%
forests and woodland: 23%
other; 16% (1993 est.)
Irrigated land; 480,000 sq km (1993 est.)
Natural hazards: droughts, flash floods, severe
thunderstorms common; earthquakes
Environment - current issues; deforestation; soil
erosion; overgrazing; desertification; air pollution from
industrial effluents and vehicle emissions; water
pollution from raw sewage and runoff of agricultural
pesticides; tap water is not potable throughout the
country; huge and growing population is overstraining
natural resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography ■ note; dominates South Asian
subcontinent; near important Indian Ocean trade
routes
^ ^ .
Population; 1 ,01 4,003,81 7 (July 2000 est.)
Age structure;
0-14 years: 34% (male 175,228,164; female
165,190,951)
15-64 years: 62% (male 324,699,562; female
301,821,383)
65 years and over: 4% (male 23,925,371 ; female
23,138,386) (2000 est.)
Population growth rate; 1 .58% (2000 est.)
Birth rate: 24.79 births/1,000 population (2000 est.)
Death rate; 8.88 deaths/1,000 population
(2000 est.)
Net migration rate: -0.08 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.07 male(s)/female (2000 est.)
229
India (continued)
Infant mortality rate: 64.9 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 62.5 years
male: 61 .89 years
fema/e; 63.1 3 years (2000 est.)
Total fertility rate: 3.1 1 children born/woman
(2000 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3%
Religions: Hindu 80%, Muslim 1 4%, Christian 2.4%,
Sikh 2%, Buddhist 0.7%, Jains 0.5%, other 0.4%
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication, Hindi the national
language and primary tongue of 30% of the people,
Bengali (official), Telugu (official), Marathi (official),
Tamil (official), Urdu (official), Gujarati (official),
Malayalam (official), Kannada (official), Oriya
(official), Punjabi (official), Assamese (official),
Kashmiri (official), Sindhi (official), Sanskrit (official),
Hindustani (a popular variant of Hindi/Urdu spoken
widely throughout northern India)
note: 24 languages each spoken by a million or more
persons; numerous other languages and dialects, for
the most part mutually unintelligible
Literacy:
definition: age 15 and over can read and write
total population: 52%
male: 65.5%
fema/e; 37.7% (1995 est.)','33fbb1c87b5109b2448e335a7c89d1f1c831dee2266b5d996e3e4bf0779c4ce6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3de4ec8d31551e68ba125bab862e26af98f33e82990b33dd20145f6a946f20ec',2000,'IQ','Iraq','communications',246,'Teiephones - main lines in use: 1 ,642,541 (1 999)
Telephones - mobile cellular: 941 ,775 (1 999)
Telephone system: modern digital system using
cable and microwave radio relay
domestic: microwave radio relay
International: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 9, FM 106,
shortwave 0 (1 998)
Radios: 2.55 million (1997)
Television broadcast stations: 10 (plus 36
low-power repeaters) (1997)
Televisions: 1.47 million (1997)
Internet Service Providers (ISPs): 14(1 999)','ead487eac941f6a0a74fd589071bdb6b49ef8178170d569319c6952dc4043987','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79477c30a7630fa3230f2a82f770e3e0be0cee4bcbeb886407e334fce6ca2eb8',2000,'TN','Tunisia','communications',256,'Telephones - main iines in use: 292,000 (1995)
Telephones - mobile cellular: 45,178 (1995)
Telephone system: fully automatic domestic
telephone network
domestic: NA
/nfemaf/ona/; satellite earth stations - 2 Intelsat
(Atlantic Ocean); 3 coaxial submarine cables
Radio broadcast stations: AM 10, FM 13,
shortwave 0 (1998)
Radios: 1 .21 5 million (1 997)
Television broadcast stations: 7 (1997)
Televisions: 460,000(1997)
Internet Service Providers (ISPs): 6 (1999)','f410db1c806071374e7ddb1e0976940a98f7b6010443b9d50ba9c1e74163ef65','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7faeb34fea0d629b45046d96315ae7b8ea60b138b79a533ecda06348d18017a7',2000,'JO','Jordan','communications',262,'Telephones ■ main lines in use: 402,600 (1997)
Telephones - mobile cellular: 75,000 (1999)
Telephone system: service has improved recently
with the increased use of digital switching equipment,
but better access to the telephone system is needed
in the rural areas and easier access to pay telephones
is needed by the urban public
domestic: microwave radio relay transmission and
coaxial and fiber-optic cable are employed on trunk
lines; considerable use is made of mobile cellular
systems; Internet service is available
international: satellite earth stations - 3 Intelsat, 1
Arabsat, and 29 land and maritime Inmarsat
terminals; fiber-optic cable to Saudi Arabia and
microwave radio relay link with Egypt and Syria;
connection to international submarine cable FLAG
(Fiber-Optic Link Around the Globe); participant in
MEDARABTEL; international links total about 4,000
Radio broadcast stations: AM 6, FM 5, shortwave
1 (1999)
Radios: 1.66 million (1997)
Television broadcast stations: 8 (plus
approximately 42 repeaters and 1 TV receive-only
satellite link) (1999)
Televisions: 500,000(1997)
Internet Service Providers (ISPs): 8 (1999)','e607e3193347b29a98524a37d2d7cf5990c6fb741e9117ce35d8a750b3a799f7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469b9eac559b7e38fed1b74e3d3da3066bf7622341cdedb3419b011b539aedcd',2000,'KZ','Kazakhstan','communications',265,'international: international traffic with other former
Soviet republics and China carried by landline and
microwave radio relay; with other countries by satellite
and bytheTrans-Asia-Europe (TAE) fiber-optic cable;
satellite earth stations - 2 Intelsat
Radio broadcast stations: AM 60, FM 17,
shortwave 9 (1998)
Radios: 6.47 million (1997)
Television broadcast stations: 12 (plus nine
repeaters) (1998)
Televisions: 3.88 million (1997)
Internet Service Providers (ISPs): 83 (Kazakhstan
and Russia) (1999)','c426796d003836550ecddb31f27943126a96cdd584e6a24361fdc13c80605d93','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b3c3f0d262aac3b7711cc48da46df60248ef12eeacfe816737c7c37f49e2174',2000,'CN','China','communications',285,'Telephones - main lines in use: 357,000 (1995)
Telephones - mobile cellular: NA
Telephone system: poorly developed; about
100,000 unsatisfied applications for household
telephones
domestic: principally microwave radio relay; one
cellular provider, probably limited to Bishkek region
International: connections with other CIS countries by
landline or microwave radio relay and with other
countries by leased connections with Moscow
international gateway switch and by satellite; satellite
earth stations - 1 1ntersputnik and 1 Intelsat;
connected internationally by the Trans-Asia-Europe
(TAE) fiber-optic line
Radio broadcast stations: AM 12 (plus 10 repeater
stations), FM 14, shortwave 2 (1998)
Radios: 520,000(1997)
Television broadcast stations: NA (repeater
stations throughout the country relay programs from
Russia, Uzbekistan, Kazakhstan, and Turkey) (1997)
Televisions: 210,000(1997)
Internet Service Providers (ISPs): NA
I t r ali s porta i i o n
Railways:
total: 370 km in common carrier service; does not
include industrial lines
broad gauge: 370 km 1 .520-m gauge (1 990)
Highways:
total: 18,500 km
paved: 1 6,854 km (including 1 40 km of expressways)
unpaved: 1 ,646 km (1996 est.)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or
Rybach''ye)
Airports: 54 (1994 est.)
Airports • with paved runways:
total: 14
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
under 914 m:1 (1994 est.)
Airports • with unpaved runways:
total: 40
1,524 to 2,437 m: A
914 to 1,523 m: A
under 914 m: 32 (1994 est.)
F M i I i t a r y
Military branches: Army, Air and Air Defense,
Security Forces (internal and border troops)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49:1,172,899 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 951,395 (2000 est.)
Military manpower - reaching military age
annually:
males: 48,551 (2000 est.)
Military expenditures - dollar figure: $1 2 million
(FY99)
Military expenditures - percent of GDP: 1%
(FY99)
Telephones - main lines in use: 20,000 (1995)
Telephones - mobile cellular; 1 ,600 (1 997)
Telephone system: service to general public is poor
but improving, with over 20,000 telephones currently
in service and an additional 48,000 expeoted by 2001 ;
the government relies on a radiotelephone network to
communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station - 1 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 1 2, FM 1 , shortwave
4(1998)
Radios: 730,000(1997)
Television broadcast stations; 4 (1999)
Televisions: 52,000(1997)
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 93,800 (1998)
Telephones - mobile cellular: NA
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntersputnik
(Indian Ocean Region)
Radio broadcast stations: AM 12, FM 2, shortwave
13(1998)
Radios: 360,000(1997)
Television broadcast stations: 1 (plus 18
provincial repeaters) (1997)
Televisions: 118,000(1997)
Internet Service Providers (ISPs): NA
I ~ transportation
Railways:
total: 1 ,928 km
broad gauge: 1 ,928 km 1 .524-m gauge (1994)
Highways:
total: 49,250 km
paved: 1 ,674 km
unpaved: 47,576 km (1998 est.)
note: much of the unpaved rural road system consists
of rough cross-country tracks
Waterways: 400 km of principal routes (1999)
Ports and harbors: none
Airports: 34 (1994 est.)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 7
under 914 m:1 (1994 est.)
Airports - with unpaved runways:
total: 26
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 3
under 914 rrj;5(1994est.)
I ^ Military ™
Military branches: Mongolian People''s Army
(includes Internal Security Forces and Border
Guards), Air Force, Civil Defense troops
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 727,844 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 473,326 (2000 est.)
Military manpower - reaching military age
annually:
males: 29,364 (2000 est.)
Military expenditures - dollar figure: $20 million
(FY97)
Military expenditures - percent of GDP; 2%
(FY97)
|;"T fa n s n a t i o n a I "issues
Disputes - international: none
IMontserrat
I (brereeas territory
I
.of the UK)
0
1 2 km
/ °
i 2 mi
Liitle Bay — f
Carr''s Bay — ^ \\
/ St. John''s \\
j ^St. Peter''s ^
Caribbean j
Sea / \\
y .Salem
PLYMOUTH
\\(abartdoned)
Patrick''s
/
Guadeloupe Passage','c70e3ce451977fa62b6a0a19fd03494e1905f86c3e89f56d4191a7c972636776','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('335eccb471eb119839055b3da6fae1af1a112292d91689ef4e2aff04e7d38785',2000,'CH','Switzerland','communications',299,'Telephones - main lines in use: 1 .048 million
(1997)
Telephones - mobile cellular: 297,500 (1 998)
Telephone system: inadequate but is being
modernized to provide an improved international
capability and better residential access
domestic: a national fiber-optic cable interurban trunk
system is nearing completion; rural exchanges are
being improved and expanded; mobile cellular
systems are being installed; access to the Internet is
available; still many unsatisfied telephone subscriber
applications
international: landline connections to Latvia and
Poland; major international connections are to
Denmark, Sweden, and Norway by submarine cable
for further transmission by satellite
Radio broadcast stations: AM 3, FM 1 12,
shortwave 1 (1998)
Radios: 1.9 million (1997)
Television broadcast stations: 82 (mainly repeater
stations) (1998)
Televisions: 1.7 million (1997)
Internet Service Providers (ISPs): 10(1 999)','6a65f00c98a1ccaa403224cc0d23d0a34d31b0e0cdd6d1d87935a70b2fbfa38a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e5a67f866b204ba719728e17e3ebeeb8faea9b99ebfe863e03abc5e7a88205',2000,'DE','Germany','communications',306,'Telephones - main lines in use: 222,500 (1997)
Telephones - mobile cellular: 55,000 (1998)
Telephone system: fairly modern communication
facilities maintained for domestic and international
services
domestic: NA
international: HF radiotelephone communication
facility; access to international communications
carriers provided via Hong Kong and China; satellite
earth station - 1 Intelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 2, shortwave
0(1998)
Radios: 160,000(1997)
Television broadcast stations: 0 (receives Hong
Kong broadcasts) (1997)
Televisions: 49,000(1997)
Internet Service Providers (ISPs): NA
298
Macau (continued)
f Transportation
Railways; 0 km
Highways;
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors; Macau
Merchant marine; none (1999 est.)
Airports; 1 (1999 est.)
Airports - with paved runways;
total: 1
over 3,047 m: 1 (1999 est.)
I Military
Military branches; Macau garrison of China''s
People''s Liberation Army (PLA) inciudes about 500
troops
Military manpower - availability;
males age 15-49: 123,581 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 67,974 (2000 est.)
Military - note; responsibility for defense reverted to
China on 20 December 1999
^ ^ - ... _
Disputes - international; none
Background; International recognition of The
Former Yugoslav Republic of Macedonia''s (FYROM)
independence from Yugoslavia in 1991 was deiayed
by Greece''s objection to the new state''s use of what it
considered a Helienic name and symbois. Greece
finally lifted its trade blockade in 1995, and the two
countries agreed to normalize relations. FYROM''s
large Albanian minority and the de facto
independence of neighboring Kosovo continue to be
sources of ethnic tension.
F""’ .
Location; Southeastern Europe, north of Greece
Geographic coordinates; 41 50 N, 22 00 E
Map references; Europe
Area;
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area - comparative; slightly larger than Vermont
Land boundaries;
total: 748 km
border countries: Mbavia 151 km, Bulgaria 148 km,
Greece 228 km, Serbia and Montenegro 221 km (all
with Serbia)
Coastline; 0 km (landlocked)
Maritime claims; none (landlocked)
Climate; warm, dry summers and autumns and
relatively cold winters with heavy snowfall
Terrain; mountainous territory covered with deep
basins and valleys; three large lakes, each divided by
a frontier line; country bisected by the Vardar River
Elevation extremes;
lowest point: Vardar River 50 m
highest point: Golem Korab (Maja e Korabit) 2,753 m
Natural resources; chromium, lead, zinc,
manganese, tungsten, nickel, low-grade iron ore,
asbestos, sulfur, timber, arable land
Land use;
arable land: 24%
permanent crops: 2%
permanent pastures: 25%
forests and woodland: 39%
of/ier;10%(1993est.)
Irrigated land; 830 sq km (1993 est.)
Natural hazards; high seismic risks
Environment - current issues; air pollution from
metallurgical plants
Environment - international agreements;
party to; Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note; landlocked; major transportation
corridor from Western and Central Europe to Aegean
Sea and Southern Europe to Western Europe
l '' P e 0 p fe
Population; 2,041,467 (July 2000 est.)
Age structure;
0-14 years: 23% (male 248,400; female 230,091)
15-64 years: 67% (male 684,025; female 678,014)
65 years and over: 10% (male 89,539; female
111,398) (2000 est.)
Population grovirth rate; 0.04% (2000 est.)
Birth rate; 13.73 births/1 ,000 population (2000 est.)
Death rate; 7.69 deaths/1 ,000 population
(2000 est.)
Net migration rate; -5.66 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .08 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate; 1 3.35 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 73.79 years
male: 71 .58 years
female: 76.1 9 years (2000 est.)
Total fertility rate; 1 .82 children born/woman
(2000 est.)
Nationality;
noun: Macedonian(s)
adjective: Macedonian
Ethnic groups; Macedonian 66.6%, Albanian
22.7%, Turkish 4%, Roma 2.2%, Serb 2.1%, other
2,4% (1994)
Religions; Macedonian Orthodox 67%, Muslim 30%,
other 3%
Languages; Macedonian 70%, Albanian 21%,
Turkish 3%, Serbo-Croatian 3%, other 3%
Literacy;
definition: NA
total population: NA%
male: NA%
female: NA%
299
Macedonia, The Former Yugoslav Republic of (continued)
I Government
Country name;
conventional long form: The Former Yugoslav
Republic of Macedonia
conventional short form: none
local long form: Republika Makedonija
local short form: Makedonija
abbreviation: F.Y.R.O.M.
Data code; MK
Government type; emerging democracy
Capital; Skopje
Administrative divisions; 34 counties (opstini,
singular - opstina) Berovo, Bitola, Brod, Debar,
Delcevo, Gevgelija, Gostivar, Kavadarci, Kicevo,
Kocani, Kratovo, Kriva Palanka, Krusevo, Kumanovo,
Murgasevo, Negotino, Ohrid, Prilep, Probistip,
Radovis, Resen, Skopje-Centar, Skopje-Cair,
Skopje-Karpos, Skopje-Kisela Voda, Skopje-Gazi
Baba, Slip, Struga, Strumica, Sveti Nikole, Tetovo,
Titov Veles, Valandovo, Vinica
note: in September 1996, the Macedonian Assembly
passed legislation changing the territorial division of
the country; names of the 123 new municipalities are
as follows: Aracinovo, Bac, Belcista, Berovo, Bistrica,
Bitola, Blatec, Bo Lukovo, Bogdanci, Bogomila,
Bogovinje, Bosilovo, Brvenica, Cair (Skopje), Capari,
Caska, Cegrane, Centar Zupa, Cesinovo,
Cucer-Sandevo, Debar, Delcevo, Delogozdi, Demir
Hisar, Demir Kapija, Djepiste, Dobrusevo, Dolna
Banjica, Dolneni, Drugovo, Gazi Baba (Skopje),
Gevgelija, Gjorce Petrov (Skopje), Gostivar, Gradsko,
liinden, izvor, Jegunovce, Kamenjane, Karbinci,
Karpos (Skopje), Kadarci, Kicevo, Kisela Voda
(Skopje), Klecevce, Kocani, Konce, Kondovo,
Konopiste, Kosel, Kratovo, Kriva Orasac, Kriva
Palanka, Krivogastani, Krusevo, Kuklis, Kukurecani,
Kumanovo, Labunista, Lipkovo, Lozovo, Lukovo,
Mak. Brod, Mak. Kamenica, Mavrovi Anovi, Meseista,
Miravci, Mogila, Murtino, Negotino, Novaci, Novo
Selo, Oblesevo, Ohrid, Opstina Centar (Skopje),
Orasac, Orizari, Oslomej, Pehcevo, Petrovec,
Plasnia, Podares, Prilep, Probistip, Radovis,
Rakovce, Resen, Rosoman, Rostusha, Samokov,
Saraj, Sipkovica, Sopiste, Sopotnika, Srbinovo, Star
Dojran, Staro Nagoricane, Stip, Stravina, Struga,
Strumica, Studenicani, Suto Orizari (Skopje), Sveti
Nikoie, Tearce, Tetovo, Topolcani, Valandovo,
Vasilevo, Veleista, Veles, Vevcani, Vinica, Vitoliste,
Vranestica, Vrapciste, Vratnica Vrutok, Zajas,
Zelenikovo, Zileno, Zitose, ZIetovo, Zrnovci
Independence; 17 September 1991 (from
Yugoslavia)
National holiday; 8 September Independence Day
Constitution; adopted 1 7 November 1991, effective
20 November 1991
note: Democratic Party for Albanians (DPA), which is
now a member party of the government, is calling for
a rewrite of the constitution to declare ethnic
Albanians a national group and allow for regional
autonomy
Legal system; based on civil law system; judicial
review of legislative acts
Suffrage; 18 years of age; universal
Executive branch;
chief of state: President Boris TRAJKOVSKI (since 1 5
December 1999)
head of government: Prime Minister Ljubco
GEORGIEVSKI (since 30 November 1998)
cabinet: Council of Ministers elected by the majority
vote of all the deputies in the Assembly; note - current
cabinet formed by the government coalition parties
VMRO-DPMNE, DA, and DPA
elections: president elected by popular vote for a
five-year term; election last held 14 November 1999
(next to be held NA October 2004); prime minister
appointed by the president
election results: Boris TRAJKOVSKI elected
president on second-round ballot; percent of vote -
Boris TRAJKOVSKI 52.4%, Tito PETKOVSKI 46.2%
Legislative branch; unicameral Assembly or
Sobranje (120 seats - 85 members are elected by
popular vote; 35 members come from lists of
candidates submitted by parties based on the
percentage that parties gain from the overall vote; all
serve four-year terms)
elections: last held 1 8 October and 1 November 1 998
(next to be held NA 2002)
election results: percent of vote by party - NA; seats
by party - VMRO-DPMNE 49, SDSM 27, PDP 1 4, DA
1 3, DPA 1 1 , LDP 4, Socialist Party 1 , Roma Party 1
Judicial branch; Constitutional Court, judges are
elected by the Judicial Council; Judicial Court of the
Republic, judges are elected by the Judicial Council
Political parties and leaders; Alliance of Romas
[leader NA]; Alliance of Communists [leader NAj; Civic
Liberal Party [leader NA]; Communist Party [leader
NA]; Democratic Alternative or DA [Vasil
TUPURKOVSKI, president]; Democratic Party for
Albanians or DPA [Arben XHAFERI, president];
Democratic Party of Macedonia or DPM [Tomislav
STOJANOVSK-BOMBAJ]; Democratic Party of Serbs
or DPSM [Dragisa MILETIC]; Democratic Party of
Turks or DPTM [Erdogan SARAC]; Democratic
Progressive Party of Romas [leader NA]; Internal
Macedonian Revolutionary Organization - Democratic
Party for Macedonian National Unity or
VMRO-DPMNE [Ljubcho GEORGIEVSKI, president];
Labor Party or LP [Krste JANKOVSKI]; League of
Democracy [leader NA]; Liberal Democratic Party or
LDP [Risto PENOV]; Movement for All Macedonian
Action or MAAK [Straso ANGELOVSKI]; Party for
Democratic Action-True Path [leader NA]; Party for
Democratic Prosperity or PDP [Abdurahman HALITI,
president]; Party for the Complete Emancipation of
Romas or PCER [Bajram BERAT]; Party of
Pensioners of Macedonia [leader NA]; Republican
Party for National Unity [leader NA]; Social Christian
Party of Macedonia [leader NA]; Social-Democratic
Alliance of Macedonia or SDSM (former Communist
Party) [Branko CRVENKOVSKI, president]; Social
Democratic Party of Macedonia or SDPM [leader NA];
Socialist Party of Macedonia or SP [Ljubisav IVANOV,
president]
International organization participation; BIS,
CCC, CE, CEI, EAPC, EBRD, ECE, FAO, IAEA,
IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Intelsat (nonsignatory user), Interpol, IOC, ISO,
ITU, OSCE, PFP, UN, UNCTAD, UNESCO, UNIDO,
UPU, WHO, WlPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US;
c/i/ef of m/ss/orr; Ambassador Ljubica Z. ACEVSKA
chancery: 3050 K Street, NW, Suite 210, Washington,
DC 20007
telephone: [t] {202) 337 3063
FAX: [1] (202) 337-3093
consulate(s) general: New York
Diplomatic representation from the US;
chief of mission: Amhassabor Michael EINIK
embassy: Bui. Ilindenska bb, 91000 Skopje
mailing address: American Embassy Skopje,
Department of State, Washington, DC 20521-7120
(pouch)
fe/eptor7e.''[389] (91) 116-180
FAX;[389] (91) 117-103
Flag description; a rising yellow sun with eight rays
extending to the edges of the red field
r Economy
Economy - overview; The breakup of Yugoslavia in
1991 deprived Macedonia, then its poorest republic,
of key protected markets and large transfer payments
from the center. Worker remittances and foreign aid
have softened the subsequent volatile recovery
period. Continued recovery depends on Macedonia''s
ability to attract investment, to redevelop trade ties
with Greece and Serbia and Montenegro, and to
maintain its commitm,ent to economic liberalization.
The economy can meet its basic food needs but
depends on outside sources for all of its oil and gas
and most of its modern machinery and parts. Growth
in 1999 was held down by the severe regional
economic dislocations caused by the Kosovo conflict.
GDP; purchasing power parity - $7.6 billion
(1999 est.)
GDP - real growth rate; 2.5% (1999 est.)
GDP - per capita; purchasing power parity - $3,800
(1999 est.)
GDP - composition by sector;
agriculture: 13%
industry: 32%
senrices: 55% (1998 est.)
Population below poverty line; NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 1% (1999 est.)
Labor force; 673,000 (1 995 est.)
Labor force - by occupation; agriculture NA%,
industry NA%, services NA%
Unemployment rate; 35% (1999 est.)
Budget;
revenues: $1 .06 billion
expenditures: ^1 billion, including capital
expenditures of $107 million (1996 est.)
300
Macedonia, The Former Yugoslav Republic of (continued)
Industries: coal, metallic chromium, iead, zinc,
ferronickel, textiles, wood products, tobacco
Industrial production growth rate: -2% (1 999 est.)
Electricity - production: 6.664 billion kWh (1 998)
Electricity ■ production by source:
fossil fuel: 85.37%
hydro: 14.63%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 6.198 billion kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agricuiture - products: rice, tobacco, wheat, corn,
miilet, cotton, sesame, muiberry leaves, citrus,
vegetables; beef, pork, poultry, mutton
Exports: $1.2 billion (f.o.b., 1999 est.)
Exports - commodities: food, beverages, tobacco;
miscellaneous manufactures, iron and steel
Exports - partners: Germany 21 %, Serbia and
Montenegro 18%, US 13%, Greece 7%, itaiy 6%
(1998)
Imports: $1.56 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment,
chemicais, fueis; food products
Imports - partners: Germany 1 3%, Serbia and
Montenegro 1 3%, Siovenia 8%, Ukraine 6%, itaiy 6%
(1998)
Debt - external: $1 .7 billion (1998 est.)
Economic aid - recipient: Taiwan $1 0.5 million; EU
$100 million to be split with Albania (1999)
Currency; 1 Macedonian denar (MKD) = 100 deni
Exchange rates: denars per US$1 - 59.773
(January 2000), 56.902 (1 999), 54.462 (1 998), 50.004
(1997), 39.981 (1996), 37.882 (1995)
Fiscal year: calendar year
I "cl) m m u n i c^a 1 1 0 n s
Telephones - main lines in use: 407,000 (1997)
Telephones - mobile cellular: NA
Telephone system:
domestic: NA
international: NA
Radio broadcast stations: AM 29, FM 20,
shortwave 0 (1998)
Radios: 410,000(1997)
Television broadcast stations: 136 (1997)
Televisions: 510,000(1997)
Internet Service Providers (ISPs): 6 (1 999)
g._- g nsp o rt a t i g
Railways;
total: 699 km
standard gauge: 699 km 1 .435-m gauge (233 km
electrified)
note: a new 56-km line is under construction to the
Bulgarian border (1999)
Highways:
total: 8,684 km
paved: 5,540 km (including 133 km of expressways)
unpaved: 3,144 km (1997 est.)
Waterways; none, lake transport only
Pipelines: 10 km
Ports and harbors: none
Airports: 16 (1999 est.)
Airports - with paved runways;
total: to
2,438 to 3,047 m: 2
under 914 m; 8 (1999 est.)
Airports - with unpaved runways;
total: 6
914 to 1,523 m: 3
under 914 m; 3 (1999 est.)
f M i I i t ary ^
Military branches: Army, Navy, Air and Air Defense
Forces, Police Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 545,852 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 440,287 (2000 est.)
Military manpower - reaching military age
annually:
males: 17,942 (2000 est.)
Military expenditures - dollar figure: $77 million
(FY99)
Military expenditures • percent of GDP; 2.5%
(FY99)
f f r a ri s n a t i o n aT Ts s u e s
Disputes • international: dispute with Greece over
its name; the border commission formed by The
Former Yugoslav Republic of Macedonia and Serbia
and Montenegro in April 1996 to resolve differences in
delineation of their mutual border has made no
progress so far; Albanians in F.Y.R.O.M. claim
discrimination in education, access to public-sector
jobs, and representation in government
Illicit drugs: increasing transshipment point for
Southwest Asian heroin and hashish; minor transit
point for South American cocaine destined for Europe
f. '' " G e¥g> a p hY
Location; Southern Africa, island in the Indian
Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area;
total: 587,040 sq km
/and; 581,540 sq km
wafer; 5,500 sq km
Area - comparative: slightly less than twice the size
of Arizona
Land boundaries: 0 km
Coastline; 4,828 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or 1 00 nm from the 2,500-m
deep isobath
301
Madagascar (continued)
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical along coast, temperate inland, arid
in south
Terrain: narrow coastal plain, high plateau and
mountains in center
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal,
bauxite, salt, quartz, tar sands, semiprecious stones,
mica, fish, hydropower
Land use:
arable land: 4%
permanent crops: t%
permanent pastures: 41 %
forests and woodland: 40%
ote14%(1993 est.)
Irrigated iand: 10,870 sq km (1993 est.)
Natural hazards: periodic cyclones
Environment - current issues: soil erosion results
from deforestation and overgrazing; desertification;
surface water contaminated with raw sewage and
other organic wastes; several species of flora and
fauna unique to the island are endangered
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Life Consen/ation, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography ■ note: world''s fourth-largest island;
strategic location along Mozambique Channel','506ae34cf751685f8458f2855d887f3bcc0e5246c537398c5ed13945afd16501','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2775cda99bbcf252ed254c3035600a55097ba0e987154937fd79e321b71241e2',2000,'MV','Maldives','communications',318,'Telephones - main lines in use: 1 7,000 (1 995)
Telephones - mobile cellular: 0 (1 995)
Telephone system: domestic system poor but
improving; provides only minimal service
domestic: network consists of microwave radio relay,
open wire, and radiotelephone communications
stations; expansion of microwave radio relay in
progress
International: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean)
Radio broadcast stations: AM 1 , FM 1 4, shortwave
7(1998)
Radios: 570,000(1997)
Television broadcast stations: 1 (plus two
repeaters) (1997)
Televisions: 45,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Telephones - main lines in use: 171 ,000 (1 995)
Telephones - mobile cellular: 1 5,650 (1 999)
Telephone system: automatic system satisfies
normal requirements
domestic: submarine cable and microwave radio relay
between islands
international: 2 submarine cables; satellite earth
station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 1 8, shortwave
6(1999)
Radios: 255,000(1997)
Television broadcast stations: 6 (1999)
Televisions: 280,000(1997)
Internet Service Providers (ISPs): 4 (1999)','05f466332ad88fd0aff41be785ed8053ff145e6f8fd7bb4c0762173a4a639cc3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78baddd8e5cea55d1b68dc4138ae042e7d403e9921e8779b398a2d651ce4db7e',2000,'MR','Mauritania','communications',329,'Teiephones - main iines in use: 9,000 (1995)
Teiephones - mobiie celiular; 0 (1995)
Telephone system: poor system of cable and
open-wire lines, minor microwave radio reiay iinks,
and radiotelephone communications stations
(improvements being made)
domestic: mostly cable and open-wire iines; a recentiy
compieted domestic sateliite telecommunications
system links Nouakchott with regionai capitais
international: sateiiite earth stations - 1 Intelsat
(Atlantic Ocean) and 2 Arabsat
Radio broadcast stations: AM 1 , FM 2, shortwave
1 (1998)
Radios: 360,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 62,000(1997)
internet Service Providers (iSPs): NA
Geographic coordinates; 14 00 N, 14 00 W
Map references: Africa
Area;
fofa/;196,190sq km
/and; 1 92,000 sq km
wafer; 4,190 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries;
total: 2,640 km
border countries: The Gambia 740 km, Guinea 330
km, Guinea-Bissau 338 km, Mali 419 km, Mauritania
813 km
Coastline: 531 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Climate: tropical; hot, humid; rainy season (May to
November) has strong southeast winds; dry season
(December to April) dominated by hot, dry, harmattan
wind
435
SenGgal (continued)
Terrain: generally low, rolling, plains rising to
foothills in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen Diakha
581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 1 6%
forests and woodland: 54%
other: 18% (1993 est.)
Irrigated land: 710 sq km (1993 est.)
Natural hazards: lowlands seasonally flooded;
periodic droughts
Environment - current issues: wildlife populations
threatened by poaching; deforestation; overgrazing;
soil erosion; desertification; overfishing
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Marine Dumping
Geography - note: The Gambia is almost an
enclave of Senegal
Telephones - main lines in use: 2.017 million
(1995)
Telephones - mobile cellular: 38,552 (1999)
Telephone system:
domestic: NA
international: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 13, FM 194,
shortwave 2 (1998)
Radios: 3.15 million (1997)
Television broadcast stations: more than 771
(including 86 strong stations and 685 low-power
stations, plus 20 repeaters in the principal networks;
also numerous local or private stations in Serbia and
Vojvodina) (1997)
Televisions: 2.75 million (1997)
Internet Service Providers (ISPs): 6 (1999)
Telephones - main lines in use: 17,844 (1997)
Telephones - mobile cellular: 2,249 (1997)
Telephone system:
domestic: radiotelephone communications between
islands in the archipelago
international: direct radiotelephone communications
with adjacent island countries and African coastal
countries; satellite earth station - 1 Intelsat (Indian
Ocean)
Radio broadcast stations: AM 1 , FM 2, shortwave
2(1998)
Radios: 42,000(1997)
Television broadcast stations: 2 (plus 9 repeaters)
(1997)
Televisions: 11,000(1997)
Internet Service Providers (ISPs): 1 (1999)','c85585339a157d84f978e76f671324dbde74358783704c6b6b12211b5517c037','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69f81eef8735691453cdb282e68b3fa17b16a0e7d0ba2fa1b36276b042b86612',2000,'YT','Mayotte','communications',339,'Telephones - main lines in use: 9.6 million (1998)
Telephones - mobile cellular: 2.02 million (1998)
Telephone system: highly developed system with
extensive microwave radio relay links; privatized in
December 1 990; opened to competition January 1 997
domestic: adequate telephone service for business
and government, but the population is poorly served;
domestic satellite system with 120 earth stations;
extensive microwave radio relay network;
considerable use of fiber-optic cable, coaxial cable,
and mobile cellular service
international: satellite earth stations - 32 Intelsat, 2
Solidaridad (giving Mexico improved access to South
America, Central America, and much of the US as well
as enhancing domestic communications), numerous
Inmarsat mobile earth stations; linked to Central
American Microwave System of trunk connections;
high capacity Columbus-2 fiber-optic submarine cable
with access to the US, Virgin Islands, Canary Islands,
Morocco, Spain, and Italy (1997)
Radio broadcast stations: AM 865, FM about 500,
shortwave 13(1999)
Radios: 31 million (1997)
Television broadcast stations: 236 (plus
repeaters) (1997)
Televisions: 25.6 million (1997)
Internet Service Providers (ISPs): 167 (1999)','4ce3c2d741456599b3cf84ae607cb8f5b5696337734d3fcb394fed51824e9bd3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c33a31b566f85225cd44c21536d430ddc1570f91531cb9174b5136d0d2ec09fa',2000,'ID','Indonesia','communications',344,'Telephones - main iines in use: 8,000 (1995)
Telephones - mobile cellular: NA
Telephone system:
domestic: islands interconnected by shortwave
radiotelephone (used mostly for government purposes)
international: satellite earth stations - 4 Intelsat
(Pacific Ocean)
Radio broadcast stations; AM 5, FM 1 , shortwave
0(1998)
Radios; NA
Television broadcast stations: 2 (1997)
Televisions: NA
Internet Service Providers (ISPs): NA
Telephones - main lines in use: 54.6 million
(including 46.62 million that serve facsimile machines,
computers, and other communication devices) (1998)
Telephones - mobile cellular: 1 .02 million (1 998)
Telephone system: good domestic facilities; good
international service
domestic: NA
international: submarine cables to Malaysia (Sabah
and Peninsular Malaysia), Indonesia, and the
Philippines; satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean), and 1 Inmarsat
(Pacific Ocean region)
Radio broadcast stations: AM 0, FM 1 5, shortwave
5(1998)
Radios: 2.55 million (1997)
Television broadcast stations: 4 (1997)
Televisions: 1.33 million (1997)
Internet Service Providers (ISPs): 8 (1 999)','123eb519897c9d7097a162185966a20591a303edd7a1680e46cbc4beb4950b08','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9903c1410134f239f06b2bf30ec55adb99013fd1260df51160e9033cfca0645',2000,'MZ','Mozambique','communications',352,'Telephones - main lines in use: 60,000 (1995)
Telephones - mobile cellular; NA
Telephone system: fair system of tropospheric
scatter, open-wire lines, and microwave radio relay
domestic: microwave radio relay and tropospheric
scatter
international: satellite earth stations - 5 Intelsat (2
Atlantic Ocean and 3 Indian Ocean)
Radio broadcast stations; AM 14, FM 4, shortwave
17(1998)
Radios: 730,000(1997)
Television broadcast stations; 1 (1997)
Televisions: 90,000(1997)
Internet Service Providers (ISPs); 2 (1999)
I transportation
Railways;
total: 3,131 km
narrow gauge: 2,933 km 1.067-m gauge; 143 km
0.762-m gauge (1994)
Highways:
total: 30,400 km
paved: 5,685 km
unpavecf;24,715 km (1996 est.)
Waterways: about 3,750 km of navigable routes
Pipelines: crude oil 306 km; petroleum products 289
km
note: not operating
Ports and harbors: Beira, Inhambane, Maputo,
Nacala, Pemba, Quelimane
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 4,125 GRT/
7,024 DWT
ships by type: cargo 3 (1999 est.)
Airports: 170 (1999 est.)
Airports - with paved runways;
total: 22
over 3,047 m:1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
343
Mozambique (continued)
914 to 1,523 m: 4
under 9/4 m; 4 (1 999 est.)
Airports ■ with unpaved runways;
tofa/;148
2,438 to 3,047 m:1
1,524 to 2,437 m: 16
914 to 1,523 m: 39
under 914 m: 92 (1 999 est.)
M i i i t a r y
Miiitary branches: Army, Naval Command, Air and
Air Defense Forces, Militia
Military manpower - availability:
males age 15-49: 4,536,132 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,617,720 (2000 est.)
Military expenditures - dollar figure; $72 million
(FY97)
Military expenditures - percent of GDP: 4.7%
(FY97)
Telephones - main lines in use: 100,848 (1997)
Telephones - mobile cellular: 20,000 (1998)
Telephone system:
domestic: good urban services; fair rural service;
microwave radio reiay links major towns; connections
to other popuiated piaces are by open wire; 100%
digital
international: fiber-optic cabie to South Africa,
microwave radio relay link to Botswana, direct links to
other neighboring countries; connected to Africa ONE
and South African Far East (SAFE) submarine cabies
through South Africa; sateliite earth stations - 4
Inteisat
Radio broadcast stations: AM 2, FM 34, shortwave
5(1998)
Radios: 232,000(1997)
Television broadcast stations: 8 (plus about 20
low-power repeaters) (1997)
Televisions: 60,000(1997)
Internet Service Providers (ISPs): 4 (1999)
Telephones - main lines in use: 12 million
(October 1999)
Telephones - mobile cellular: 1 0.2 million (October
1999)
Telephone system:
domestic: provides modern telecommunications
service for every business and private need;
completely digitalized
/nfemaf/ona/; satellite earth stations - 2 Intelsat (1
Pacific Ocean and 1 1ndian Ocean); submarine cables
to Japan (Okinawa), Philippines, Guam, Singapore,
Hong Kong, Indonesia, Australia, Middle East, and
Western Europe (1999)
Radio broadcast stations: AM 218, FM 333,
shortwave 50 (1999)
Radios: 16 million (1994)
Television broadcast stations: 29 (plus two
repeaters) (1997)
Televisions: 8.8 million (1998)
Internet Service Providers (ISPs): 15 (1999)','c4b3ee05c11b073daa5ece56d97fb93964cce1b6639eb945c4ca25cbd239919c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98f82087d358578c1d22dfe1ff58a6daac865550c81319c41f960c96cb5f5a9f',2000,'NZ','New Zealand','communications',366,'Teiephones - main iines in use: 1 .71 9 million
(1995)
Telephones - mobile cellular; 588,000 (1998)
Telephone system: excellent international and
domestic systems
domestic: NA
international: submarine cables to Australia and Fiji;
satellite earth stations - 2 Intelsat (Pacific Ocean)
Radio broadcast stations; AM 124, FM 290,
shortwave 4 (1998)
Radios: 3.75 million (1997)
Television broadcast stations: 41 (plus 52
medium-power repeaters and over 650 low-power
repeaters) (1997)
Televisions: 1.926 million (1997)
Internet Service Providers (ISPs): 56 (1999)
Telephones - main lines in use: 1 40,000 (1 996)
Telephones - mobile cellular; 4,400 (1 995)
Telephone system: low-capacity microwave radio
relay and wire system being expanded; connected to
Central American Microwave System
domestic: wire and microwave radio relay
international: satellite earth stations - 1 Intersputnik
(Atlantic Ocean region) and 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 63, FM 32,
shortwave 1 (1 998)
Radios: 1.24 million (1997)
Television broadcast stations: 3 (plus seven
low-power repeaters) (1997)
Televisions: 320,000(1997)
Internet Service Providers (ISPs): 5 (1999)
Communications - note: important meteorological
station','abc6cf6a43f54945a643894895a5e584396a732fa93411a693f18e620ecb622e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b91f9716d7fcba7e9f4b2dbd8e12ebdb513076aac5d668eb932d5f8cc40f43aa',2000,'NO','Norway','communications',374,'Telephones - main lines in use: 2,325,010 (1997)
Telephones • mobile cellular: 1 ,676,763 (1997)
Telephone system: high-quality domestic and
international telephone, telegraph, and telex services
domestic: domestic satellite system
international: 2 buried coaxial cable systems; 4
coaxial submarine cables; satellite earth stations - NA
Eutelsat, NA Intelsat (Atlantic Ocean), and 1 1nmarsat
(Atlantic and Indian Ocean regions); note - Norway
shares the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Iceland, and Sweden)
Radio broadcast stations: AM 5, FM at least 650,
shortwave 1 (1998)
Radios: 4.03 million (1997)
Television broadcast stations: 209 (1997)
Televisions: 2.03 million (1997)
Internet Service Providers (ISPs): 21 (1999)
j Transpiortation
Railways:
total: 4,012 km
standard gauge: 4,012 km 1.435-m gauge (2,530 km
electrified; 96 km double track) (1998)
Highways:
total: 90,741 km
paved: 67,602 km (including 128 km of expressways)
unpaved: 23,139 km (1998 est.)
Waterways: 1 ,577 km along west coast; navigable
by 2.4 m draft vessels maximum
Pipelines: refined petroleum products 53 km
Ports and harbors: Bergen, Drammen, Floro,
Hammerfest, Harstad, Haugesund, Kristiansand,
Larvik, Narvik, Oslo, Porsgrunn, Stavanger, Tromso,
Trondheim
Merchant marine:
total: 788 ships (1 ,000 GRT or over) totaling
21,460,260 GRT/34,178,125 DWT
ships by type: bulk 100, cargo 142, chemical tanker
111, combination bulk 9, combination ore/oil 35,
container 18, liquified gas 86, multi-functional large
load carrier 1 , passenger 1 1 , petroleum tanker 157,
refrigerated cargo 1 1 , roll-on/roll-off 48, short-sea
passenger 22, vehicle carrier 37 (1999 est.)
note: the government has created an internal register,
the Norwegian international Ship register (NIS), as a
subset of the Norwegian register; ships on the NiS
enjoy many benefits of fiags of convenience and do
not have to be crewed by Norwegians (1998 est.)
Airports: 103 (1999 est.)
Airports - with paved runways:
total: 67
over 3,047 m:t
2,438 to 3,047 m:\\2
1,524 to 2,437 m: 13
914 to 1,523 m: 12
under 914 m: 29 (1 999 est.)
Airports ■ with unpaved runways:
total: 36
914 to 1,523 m: 5
under 914 m: 31 (1 999 est.)
Heliports: 1 (1999 est.)','23052bfbaf9c8003670038d80f54be2a70822d45dbee7579020125a3d3c7b853','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67c5adadeda993ef47c44c413bf4b185426baa77203869d053f1c8eaf9eeee6e',2000,'PW','Palau','communications',377,'Telephones - main iines in use: 1 ,500 (1 988)
Telephones - mobile cellular: 0 (1988)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave
1 (1998)
Radios: 12,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 1 1 ,000 (1 997)
Internet Service Providers (ISPs): NA','4b1e1a10f6bba18cc2445f86e625cf4ea5e1bebaaf44aecfe19cb8740fd2f0d4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6fc91e93512a282de23f4b249e6db5bbcffbd5476d644e2215bbaaf021c4164',2000,'AR','Argentina','communications',388,'Telephones - main lines in use: 167,000 (1995)
Telephones - mobile cellular: 15,807 (1995)
Telephone system: meager telephone service;
principal switching center is Asuncion
domesf/c.-fair microwave radio relay network
International: satellite earth station - 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 46, FM 27,
shortwave 6 (three inactive) (1998)
Radios: 925,000(1997)
Television broadcast stations: 10 (1997)
Televisions: 515,000 (1997)
Internet Service Providers (ISPs): 4 (1999)
Teiephones - main iines in use: 1 .9 million (1 997)
Telephones - mobile cellular: 1 .959 million (1 998)
Telephone system: good international
radiotelephone and submarine cable services;
domestic and interisland service adequate
domestic: domestic satellite system with 1 1 earth
stations
international: 9 international gateways; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Pacific
Ocean); submarine cables to Hong Kong, Guam,
Singapore, Taiwan, and Japan
Radio broadcast stations: AM 366, FM 290,
shortwave 3 (1999)
Radios: 11.5 million (1997)
Television broadcast stations: 31 (1997)
Televisions: 3.7 million (1997)
Internet Service Providers (ISPs): 93 (1999)
I transportation
Railways:
total: 492 km (an additional 405 km are not in
operation)
narrow gauge: A92 km 1.067-m gauge (1996)
Highways:
total: m, 950 km
paved: 39,590 km
unpaved: 160,360 km (1998 est.)
Waterways: 3,219 km; limited to shallow-draft (less
than 1 .5 m) vessels
Pipelines: petroleum products 357 km
Ports and harbors: Batangas, Cagayan de Oro,
Cebu, Davao, Guimaras Island, lligan, Iloilo, Jolo,
Legaspi, Manila, Masao, Puerto Princesa, San
Fernando, Subic Bay, Zamboanga
Merchant marine:
total: 480 ships (1 ,000 GRT or over) totaling
5,973,024 GRT/9,025,087 DWT
ships by type: bulk 1 59, cargo 1 22, chemical tanker 5,
combination bulk 9, container 7, liquified gas 13,
livestock carrier 9, passenger 4, passenger/cargo 12,
petroleum tanker 47, refrigerated cargo 20, roll-on/
roll-off 1 9, short-sea passenger 32, specialized tanker
2, vehicle carrier 20 (1 999 est.)
note: a flag of convenience registry; Japan owns 1 9
ships, Hong Kong 5, Cyprus 1 , Denmark 1 , Greece 1 ,
Netherlands 1 , Singapore 1 , and UK 1 (1998 est.)
Airports: 266 (1999 est.)
Airports - with paved runways:
total: 76
over 3,047 m: A
2,438 to 3,047 m: 5
1,524 to 2,437 m: 26
914 to 1,523 m: 31
under 914 m: 10 (1999 est.)
Airports ■ with unpaved runways:
tofa/;190
1,524 to 2,437 m: 3
914 to 1,523 m: 66
under 914 m: 121 (1999 est.)
Heliports: 1 (1999 est.)
I Mi N t a r y
Miiitary branches: Army, Navy (includes Coast
Guard and Marine Corps), Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 20,731,979 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 14,607,014 (2000 est.)
Military manpower - reaching military age
annually:
males: 835,81 7 (2000 est.)
Military expenditures - dollar figure: $995 million
(FY98)
Military expenditures - percent of GDP: 1 .5%
(FY98)
i t r a n s n a t i 0 n a I I s s u e s
Disputes - international: involved in a complex
dispute over the Spratly Islands with China, Malaysia,
Taiwan, Vietnam, and possibly Brunei; claim to
Malaysia''s Sabah State has not been fully revoked
Illicit drugs: exports locally produced marijuana and
hashish to East Asia, the US, and other Western
markets; serves as a transit point for heroin and
crystal methamphetamine
[Pitcairn Isiands SESgg/M
i (overseas territory
[of the UK) Ulllllll^gg
0 50 100 km
6 50 100 mi
gSandy
Oeno
(, Henderson
ADAMSTOWN
Dude a
\\^Bounty','c1f9a98e2862b689566a764028cd0ebaecad752324c811b898778107e97552e4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4972606915bc388cd6ae77853cbb366409a369f17370e5905d1b2e0627241ac1',2000,'PN','Pitcairn','communications',391,'South Pacific Ocean
I introdu c t i o n
Background: Pitcairn Island was discovered in 1 767
by the British and settled in 1790 by the Bounty
mutineers and their Tahitian companions.
Outmigration, primarily to New Zealand, has thinned
the population from a peak of 233 in 1937 to about 50
today.
Geo graph y
Location: Oceania, islands in the South Pacific
Ocean, about one-half of the way from Peru to New
Zealand
Geographic coordinates: 25 04 S, 1 30 06 W
Map references: Oceania
Area:
total: 47 sq km
land: 47 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 3 nm
Climate: tropical, hot, humid; modified by southeast
trade winds; rainy season (November to March)
Terrain: rugged volcanic formation; rocky coastline
with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold, silver, and zinc
have been discovered offshore
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
396
Pitcairn Islands (continued)
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards; typhoons (especially November to
March)
Environment - current issues: deforestation (only
a small portion of the original forest remains because
of burning and clearing for settlement)
r ^ ~
Population: 54 (July 2000 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: HA
Population growth rate; -2.06% (2000 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions; Seventh-Day Adventist 100%
Languages; English (official), Pitcairnese, Tahitian,
18th century English dialect
I Govern rii e n t
Country name;
conventional long form: Pitcairn, Henderson, Ducie,
and Oeno Islands
conventional short form: Pitcairn Islands
Data code: PC
Dependency status; overseas territory of the UK
Government type: NA
Capital: Adamstown
Administrative divisions; none (overseas territory
of the UK)
Independence: none (overseas territory of the UK)
National holiday: Celebration of the Birthday of the
Queen (second Saturday in June)
Constitution; Local Government Ordinance of 1 964
Legal system; local island by-laws
Suffrage: 1 8 years of age; universal with three years
residency
Executive branch:
chief of state: Queen ELIZABETH 1 1 (since 6 February
1952), represented by UK High Commissioner to New
Zealand and Governor (nonresident) of the Pitcairn
Islands Martin WILLIAMS (since NA May 1998);
Commissioner (nonresident) Leon SALT (since NA; is
the liaison person between the governor and the
Island Council)
head of government: Island Magistrate and Chairman
of the Island Council Jay WARREN (since NA)
cabinet: NA
elections: the monarch is hereditary; high
commissioner and commissioner appointed by the
monarch; island magistrate elected by popular vote
for a three-year term; last known election held NA
December 1993 (next was to be held NA December
1996)
election results: Jay WARREN reelected island
magistrate; percent of vote - NA
Legislative branch; unicameral Island Council (10
seats - 6 elected by popular vote, 1 appointed by the
6 elected members, 2 appointed by the governor, and
1 seat for the Island Secretary; members serve
one-year terms)
elections: take place each December; last held NA
December 1 999 (next to be held NA December 2000)
election results: percent of vote - NA; seats ■ all
independents
Judicial branch: Island Court, island magistrate
presides over the court and is elected every three
years
Political parties and leaders: none
International organization participation; SPC
Diplomatic representation in the US: none
(overseas territory of the UK)
Diplomatic representation from the US; none
(overseas territory of the UK)
Flag description: blue with the flag of the UK in the
upper hoist-side quadrant and the Pitcairn Islander
coat of arms centered on the outer half of the flag; the
coat of arms is yellow, green, and light blue with a
shield featuring a yellow anchor
1^'' ■ - ”£^0 n’o iny''"" . . .
Economy - overview: The inhabitants of this tiny
economy exist on fishing, subsistence farming,
handicrafts, and postage stamps. The fertile soil of the
valleys produces a wide variety of fruits and
vegetables, including citrus, sugarcane, watermelons,
bananas, yams, and beans. Bartering is an important
part of the economy. The major sources of revenue
are the sale of postage stamps to collectors and the
sale of handicrafts to passing ships.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector;
agriculture: NA%
industry: NA%
services: NA%
Popuiation below poverty line; NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 1 2 able-bodied men (1 997)
Labor force - by occupation; no business
community in the usual sense; some public works;
subsistence farming and fishing
Unemployment rate; NA%
Budget:
revenues: $729,884
expend/fures; $878,1 19, including capital
expenditures of $NA (FY94/95 est.)
Industries: postage stamps, handicrafts
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source;
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Eiectricity - consumption: NA kWh
Eiectricity - exports: NA kWh
Eiectricity - imports: NAkWh
Agriculture - products; wide variety of fruits and
vegetabies
Exports; $NA
Exports - commodities: fruits, vegetables, curios,
stamps
Exports - partners; NA
Imports: $NA
Imports - commodities; fuel oil, machinery, building
materials, flour, sugar, other foodstuffs
Imports - partners; NA
Debt - external: $NA
Economic aid ■ recipient: $NA
Currency: 1 New Zealand dollar (NZ$) = 100 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1 - 1 .9451 (January 2000), 1 .8886 (1 999), 1 .8629
(1998), 1.5083 (1997), 1.4543 (1996), 1.5235 (1995)
Fiscal year: 1 April - 31 March
Q- jj „ ions
Telephones - main lines in use; 1 (there are 17
telephones on one party line) (1997)
Telephone system: party line telephone service on
the isiand
domestic: NA
international: radiotelephone
Radio broadcast stations: AM 1 , FM 0, shortwave
0(1998)
Radios; NA
Television broadcast stations: 0 (1997)
Televisions; NA
Internet Service Providers (ISPs); NA
g™. p-g I
Railways; 0 km
Highways;
total: 6.4 km
paved: 0 km
unpaved: 6.4 km
Ports and harbors: Bounty Bay
Merchant marine: none (1999 est.)
Airports: none
P " “ -- ™ " ''
Military - note; defense is the responsibility of the
UK
p TTan s filTFo n a I Issues
Disputes - international: none
397
I introduction
Background: Poland gained its independence in
1918 only to be overrun by Germany and the Soviet
Union in World War II. It became a Soviet satellite
country following the war, but one that was
comparatively tolerant and progressive. Labor turmoil
in 1980 led to the formation of an independent trade
union “Solidarity" that over time became a political
force and by 1990 had swept parliamentary elections
and the presidency. Complete freedom came with the
implosion of the USSR in 1 991 . A “shock therapy"
program during the early 1 990s enabled the country to
transform its economy into one of the most robust in
Central Europe, boosting hopes for early acceptance
to the EU. Poland joined the NATO alliance in 1999.
i Geography
Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
fofa/; 312,685 sq km
land: 304,465 sq km
water: 8,220 sq km
Area - comparative: slightly smaller than New','bd0754fccf1434d1557e40d0d99e58963833ebcd5f94af3b53709e2a129802c3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05dc2e78806d97ab7079d5d3a36447eba0395c0fd9ca6256fff67360dfabffa4',2000,'MX','Mexico','communications',392,'Land boundaries:
total: 2,888 km
border countries: Belarus 605 km, Czech Republic
658 km, Germany 456 km, Lithuania 91 km, Russia
(Kaliningrad Oblast) 206 km, Slovakia 444 km,
Ukraine 428 km
Coastline: 491 km
Maritime claims:
exclusive economic zone: defined by international
treaties
fem''tor/a/ sea.- 12 nm
Climate: temperate with cold, cloudy, moderately
severe winters with frequent precipitation; mild
summers with frequent showers and thundershowers
Terrain: mostly flat plain; mountains along southern
border
Elevation extremes:
lowest point: Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas,
silver, lead, salt, arable land
Land use:
arable land: 47%
permanent crops: 1%
permanent pastures: 1 3%
forests and woodland: 29%
of/ier;10%(1993est.)
Irrigated land: 1 ,000 sq km (1 993 est.)
Natural hazards: NA
Environment - current issues: situation has
improved since 1 989 due to decline in heavy industry
and increased environmental concern by
postcommunist governments; air pollution
nonetheless remains serious because of sulfur
dioxide emissions from coal-fired power plants, and
the resulting acid rain has caused forest damage;
water pollution from industrial and municipal sources
is also a problem, as is disposal of hazardous wastes
Environment - international agreements:
party to: Air Pollution, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Climate Change-Kyoto Protocol
Geography - note: historically, an area of conflict
because of flat terrain and the lack of natural barriers
on the North European Piain
Telephones • main lines in use: 3.724 million
(1996)
Telephones • mobile cellular: 887,21 6 (1 999)
Telephone system:
domestic: generally adequate integrated network of
coaxial cables, open wire, microwave radio relay, and
domestic satellite earth stations
internationai: 6 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian
Ocean), NA Eutelsat; tropospheric scatter to Azores;
note - an earth station for Inmarsat (Atlantic Ocean
region) is planned
Radio broadcast stations: AM 47, FM 172 (many
are repeaters), shortwave 2 (1998)
Radios: 3.02 million (1997)
Television broadcast stations: 36 (plus 62
repeaters) (1997)
Televisions: 3.31 million (1997)
Internet Service Providers (ISPs): 20 (1999)','286005392200a9abe1401f09f4e5ce893ffaf41084c6793ae12503364399ab23','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eac65d570ea362e6ef52c30e805504dd030dbbca4b84186f3be28958df0a6c73',2000,'DO','Dominican Republic','communications',404,'Telephones - main lines in use: 146,980 (1995)
Telephones - mobile cellular: 1 8,469 (1 995)
Telephone system: modern system centered in
Doha
domestic: NA
international: tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia and UAE;
submarine cable to Bahrain and UAE; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 6, FM 5, shortwave
1 (1998)
Radios: 256,000(1997)
Television broadcast stations: 2 (plus three
repeaters) (1997)
Televisions: 230,000(1997)
Internet Service Providers (ISPs): NA
406
Qatar (continued)
p Transportation
Railways; 0 km
Highways;
total: 1 ,230 km
paved; 1,107 km
unpaved: 123 km (1996 est.)
Pipelines; crude oil 235 km; natural gas 400 km
Ports and harbors; Doha, Halul Island, Umm Said
Merchant marine;
total: 24 ships (1 ,000 GRT or over) totaling 721 ,756
GRT/1,132,510DWT
ships by type: cargo 1 0, combination ore/oil 2,
container 7, petroleum tanker 5 (1999 est.)
Airports; 4 (1999 est.)
Airports - with paved runways;
total: 2
over 3,047 m: 2 (1 999 est.)
Airports - with unpaved runways;
total: 2
914 to 1,523 m:t
under 914 m:1 (1999 est.)
Heliports; 1 (1999 est.)
f —
Military branches; Army, Navy, Air Force, Public
Security
Military manpower - military age; 18 years of age
Military manpower - availability;
rr)alesage 15-49:306,850
note: includes non-nationals (2000 est.)
Military manpower - fit for military service;
males age 15-49: 160,899 (2000 est.)
Military manpower - reaching military age
annually;
males: 6,471 (2000 est.)
Military expenditures - dollar figure; $81 6 million
(FY99/00)
Military expenditures ■ percent of GDP; 8.1%
(FY99/00)
f T r a n s n a t i b n a I Issues
Disputes - international; the territorial dispute with
Bahrain over the Hawar Islands and the maritime
boundary dispute with Bahrain are currently before
the International Court of Justice (ICJ); June 1999
agreement has furthered the goal of definitively
establishing the border with Saudi Arabia
I Introduction
Background; The Portuguese discovered the
uninhabited island in 1513. From the 17th to the 19th
centuries, French immigration supplemented by
influxes of Africans, Chinese, Malays, and Malabar
Indians gave the island its ethnic mix. The opening of
the Suez Canal in 1869 cost the island its importance
as a stopover on the East Indies trade route.
|;'' . . . ''G eTgTap''hT "■
Location; Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates; 21 06 S, 55 36 E
Map references; World
Area;
fofa/;2,512sq km
land: 2,502 sq km
wafer; lOsq km
Area - comparative; slightly smaller than Rhode
Island
Land boundaries; Okm
Coastline; 207 km
Maritime claims;
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Climate; tropical, but temperature moderates with
elevation; cooi and dry from May to November, hot
and rainy from November to April
Terrain; mostly rugged and mountainous; fertiie
lowlands along coast
Elevation extremes;
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources; fish, arable land, hydropower
Land use;
arable land: 17%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 35%
other; 41% (1993 est.)
Irrigated land; 60 sq km (1993 est.)
Natural hazards; periodic, devastating cyclones
(December to April); Piton de la Fournaise on the
southeastern coast Is an active volcano
Environment - current issues; NA
I P e 0 p i e
Population; 720,934 (July 2000 est.)
Age structure;
0-14years:32% (male 119,291; female 113,741)
15-64 years: 62% (male 220,066; female 227,632)
65 years and over: 6% (male 1 6,336; female 23,868)
(2000 est.)
Population growth rate; 1 .63% (2000 est.)
Birth rate; 21 .84 births/1 ,000 population (2000 est.)
Death rate; 5.55 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/femaie
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 maie(s)/female (2000 est.)
Infant mortality rate; 8.67 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 72.68 years
male: 69.28 years
female: 76.24 years (2000 est.)
Total fertility rate; 2.61 children born/woman
(2000 est.)
Nationality;
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups; French, African, Malagasy, Chinese,
Pakistani, Indian
Religions; Roman Catholic 86%, Hindu, Muslim,
Buddhist (1995)
Languages; French (official). Creole widely used
Literacy;
definition: age 15 and over can read and write
total population: 79%
male: 76%
female: 80% (1982 est.)
|r" Go vein merit
Country name;
conventional long form: Department of Reunion
conventional short form: Reunion
local long form: none
local short form: lie de la Reunion
Data code; RE
Dependency status; overseas department of','be45060b294ef2994985d3f15fd9e5170c8b4f3d17f6d34b0f90f5e993ce5ff6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb022354e18afce3635c21c86649b0d1e602af0ae01ce03fb7e8cf52ae080a94',2000,'UA','Ukraine','communications',409,'Telephones - main lines in use; 25.019 million
(1995)
Telephones - mobile cellular: 645,000 (1999)
Telephone system: the telephone system has
undergone significant changes in the 1 990s; there are
more than 1 ,000 companies licensed to offer
communication services; access to digital lines has
improved, particularly in urban centers; Internet and
e-mail services are improving; Russia has made
progress toward building the telecommunications
infrastructure necessary for a market economy
domestic: cross-country digital trunk lines run from
Saint Petersburg to Khabarovsk, and from Moscow to
Novorossiysk; the telephone systems in 60 regional
capitals have modern digital infrastructures; cellular
services, both analog and digital, are available in
many areas; in rural areas, the telephone services are
still outdated, inadequate, and low density
international: Russia is connected internationally by
three undersea fiber-optic cables; digital switches in
several cities provide more than 50,000 lines for
international calls; satellite earth stations provide
access to Intelsat, Intersputnik, Eutelsat, Inmarsat,
and Orbita
Radio broadcast stations: AM 420, FM 447,
shortwave 56 (1998)
Radios: 61.5 million (1997)
Television broadcast stations; 7,349 (1996)
Televisions: 60.5 million (1997)
Internet Service Providers (ISPs): 83 (Russia and
Kazakhstan) (1999)','16cd7f0adf3b0aaabce552a40f197efae2a197abc53b20203f21cc6dff9381ed','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e50060f57bcb251f547c23521624471fbd360c574373f061b1f8783d52f60e8',2000,'VC','Saint Vincent and the Grenadines','communications',417,'Telephones - main lines in use: 8,000 (1994)
Telephones - mobile cellular; 1 ,200 (1 994)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 3, shortwave
0(1998)
Radios: 178,000(1997)
Television broadcast stations: 6 (1997)
Televisions: 1 1 ,000 (1 997)
Internet Service Providers (ISPs): NA
428
Samoa (continued)
I transportation
Railways; 0 km
Highways:
total: 790 km
paved: 332 km
unpaved: 458 km (1996 est.)
Ports and harbors: Apia, Asau, Mulifanua,
Salelologa
Airports: 3 (1999 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:-\\ (1999 esl.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (1999 est.)
I " Military
Military branches: no regular armed services;
Samoa Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP; NA%
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which is required to consider any
Samoan request for assistance under the 1 962 T reaty
of Friendship
f f 7 a n s n a t ional Issues
Disputes • international; none
Background: The world''s third smallest state also
claims to be the world''s oldest republic, founded by
Saint Marines (for whom the country is named) in 301
A. D. San Marino''s foreign policy is aligned with that of
Italy. Social and political trends in the republic also
track closely with those of its larger neighbor.
I . . G e 0 gVi p h y''”"
Location; Southern Europe, an enclave in central','da2e04595412d36d7324cb1138d0619a414f7eaa6c0a79e9407716638da2d551','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('781b34d436d29546c9248b20f209ec6a31be82c657a9b85da73b80cd81664ebf',2000,'IT','Italy','communications',418,'Geographic coordinates; 43 46 N, 12 25 E
Map references; Europe
Area;
total: 60.5 sq km
land: 60.5 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries:
total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate; Mediterranean; mild to cool winters; warm,
sunny summers
Terrain; rugged mountains
Elevation extremes;
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 749 m
Natural resources: building stone
Land use;
arable land: 17%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 83% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Nuclear Test Ban
signed, but not ratified: Air Pollution
Geography - note: landlocked; smallest
independent state in Europe after the Holy See and
Monaco; dominated by the Apennines
I People
Population: 26,937 (July 2000 est.)
Age structure;
0-14 years: 16% (male 2,181; female 2,038)
15-64 years: 68% (male 8,992; female 9,425)
65 years and over: 16% (male 1,849; female 2,452)
(2000 est.)
Population growth rate: 1 .49% (2000 est.)
Birth rate: 10.88 births/1,000 population (2000 est.)
Death rate: 7.65 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 1 .62 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 6.33 deaths/1,000 live births
(2000 est.)
Life expectancy at birth;
total population: 81.14 years
male: 77.57 years
female: 85.02 years (2000 est.)
Total fertility rate: 1 .29 children born/woman
(2000 est.)
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions; Roman Catholic
Languages; Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
fema/e; 95% (1976 est.)
I Government
Country name;
conventional long form: Republic of San Marino
conventional short form: San Marino
local long form: Repubblica di San Marino
local short form: San Marino
Data code: SM
Government type: republic
Capital: San Marino
Administrative divisions: 9 municipalities (castelli,
singular - castello); Acquaviva, Borgo Maggiore,
Chiesanuova, Domagnano, Faetano, Florentine,
Monte Giardino, San Marino, Serravalle
429
San Marino (continued)
Independence: 301 (by tradition)
National holiday: Anniversary of the Foundation of
the Republic, 3 September (301)
Constitution: 8 October 1 600; electoral law of 1 926
serves some of the functions of a constitution
Legal system: based on civil law system with Italian
law influences; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: cochiefs of state Captain Regent Loris
FRANCINI and Captain Regent Alberto CECCHETTI
(for the period 1 April 1999-30 September 1999)
head of government: Secretary of State for Foreign
and Political Affairs Gabriele GATTI (since NA July
1986)
cabinet: Congress of State elected by the Great and
General Council for a five-year term
elections: cochiefs of state (captain regents) elected
by the Great and General Council for a six-month
term; election last held NA September 1999 (next to
be held NA March 2000); secretary of state for foreign
and political affairs elected by the Great and General
Council for a five-year term; election last held NA June
1998 (next to be held NA June 2003)
election results: Loris FRANCINI and Alberto
CECCETTI elected captain regents; percent of
legislative vote - NA; Gabriele GATTI reelected
secretary of state for foreign and political affairs;
percent of legislative vote - NA
note: the popularly elected parliament (Grand and
General Council) selects two of its members to serve
as the Captains Regent (cochiefs of state) for a
six-month period; they preside over meetings of the
Grand and General Council and its cabinet (Congress
of State) which has ten other members, all selected by
the Grand and General Council; assisting the captains
regent are three secretaries of state - Foreign Affairs,
Internal Affairs, and Finance - and several additional
secretaries; the secretary of state for Foreign Affairs
has assumed many of the prerogatives of a prime
minister
Legislative branch: unicameral Grand and General
Council or Consiglio Grande e Generale (60 seats;
members are elected by direct popular vote to serve
five-year terms)
elections: last held 31 May 1998 (next to be held by
NA May 2003)
election results: percent of vote by party - PDCS
40.8%, PSS 23.3%, PPDS 18.6%, APDS 9.8%, RC
3.3%, SR 4.2%; seats by party - PDCS 25, PSS 14,
PPDS 11, APDS 6, RC2, SR 2
Judicial branch: Council of Twelve or Consiglio dei
XII
Political parties and leaders: Communist
Refoundation or RC [Giuseppe AMICFII]; Democratic
Movement or MD [Emilio DELLA BALDA]; San Marino
Christian Democratic Party or PDCS [Cesare Antonio
GASPERONI, secretary general]; San Marino Popular
Democratic Party or APDS [Antonella MULARONIj;
San Marino Progressive Democratic Party or PPDS
[Stefano MACINA, secretary general]; San Marino
Socialist Party or PSS [Maurizio RATTINI, secretary
general]; Socialists for Reform or SR [Renzo
GIARDI]
International organization participation: CE,
ECE, ICAO, ICFTU, ICRM, IFRCS, ILO, IMF, IOC,
lOM (observer), ITU, OPCW, OSCE, UN, UNCTAD,
UNESCO, UPU, WHO, WlPO, WToO
Diplomatic representation in the US: San Marino
does not have an embassy in the US
honorary consulate(s) general: Washington, DC, and
New York
honorary consulate(s): Detroit
Diplomatic representation from the US: the US
does not have an embassy in San Marino; the US
Consul General in Florence (Italy) is accredited to San
Marino
Flag description: two equal horizontal bands of
white (top) and light blue with the national coat of arms
superimposed in the center; the coat of arms has a
shield (featuring three towers on three peaks) flanked
by a wreath, below a crown and above a scroll bearing
the word LIBERTAS (Liberty)
Telephones - main lines in use: 18,000 (1998)
Telephones - mobile cellular: 3,010 (1998)
Telephone system:
domestic: automatic telephone system completely
integrated into Italian system
international: microwave radio relay and cable
connections to Italian network; no satellite earth
stations
Radio broadcast stations: AM 0, FM 3, shortwave
0(1998)
Radios: 16,000(1997)
Television broadcast stations: 1 (San Marino
residents also receive broadcasts from Italy) (1997)
Televisions: 9,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Telephones - main lines in use: 930,000 (1995)
Telephones - mobile cellular: NA
Telephone system: fair system currently
undergoing significant improvement and digital
upgrades, including fiber-optic technology
domestic: coaxial cable and microwave radio relay
network
international: satellite earth stations - 1 1ntelsat
(Indian Ocean) and 1 1ntersputnik (Atlantic Ocean
region); 1 submarine cable; coaxial cable and
microwave radio relay to Iraq, Jordan, Lebanon, and
Turkey; participant in Medarabtel
Radio broadcast stations: AM 1 4, FM 2, shortwave
1 (1998)
Radios: 4.15 million (1997)
Television broadcast stations: 54 (of which 36 are
low-power and repeater stations) (1 997)
Televisions: 1 .05 million (1997)
Internet Service Providers (ISPs): NA','b9514b40c0eb0a120ac3ce3eaa26a831eed4383ba90ecfceec74455f57ba455e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7ab1dde17416208f88a8f07f62013af43cac7c949b65e660f0a9e8ef832d4a7',2000,'MY','Malaysia','communications',422,'Teiephones - main iines in use; 1.557 million
(1998)
Telephones - mobile cellular; 641 ,000 (1998)
Telephone system;
domestic: predominantly an analog system which is
now receiving digital equipment and is being enlarged
with fiber-optic cable, especially in the larger cities;
mobile cellular capability has been added
international: 3 international exchanges, 1 in
Bratislava and 2 In Banska Bystrica, are available;
Slovakia is participating in several international
telecommunications projects which will increase the
availability of external services
Radio broadcast stations; AM 15, FM 78,
shortwave 2 (1998)
Radios; 3.12 million (1997)
Television broadcast stations; 41 (1998)
Televisions; 2.62 million (1997)
Internet Service Providers (ISPs); 11 (1999)
I Transportation
Railways;
total: 3,660 km
broad gauge: 102 km 1.520-m gauge
standard gauge: 3,507 km 1 .435-m gauge (1505 km
electrified; 1 ,01 1 km double track)
narrow gauge: km (46 km 1,000-m gauge; 5 km
0.750-m gauge) (1998)
Highways;
total: 17,710 km
paved: 17,533 km (including 288 km of expressways)
unpaved: 177 km (1998 est.)
Waterways; 172 km on the Danube
Pipelines; petroleum products NA km; natural gas
2,700 km
Ports and harbors; Bratislava, Komarno
Merchant marine;
total: 3 ships (1 ,000 GRT or over) totaling 1 5,041
GRT/19,517 DWT
ships by type: cargo 3 (1 999 est.)
Airports; 36 (1999 est.)
Airports - with paved runways;
fofa/;18
over 3,047 m:t
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 91 4 m; 8 (1999 est.)
Airports - with unpaved runways;
tofa/;18
2,438 to 3,047 m:1
914 to 1,523 m: 9
under 914 m: 3 {1999 est.)
I Mifitary
Military branches; Ground Forces, Air and Air
Defense Forces, Territorial Defense Forces, Civil
Defense Force
Military manpower - military age; 18 years of age
Military manpower - availability;
males age f 5-49; 1,484,567 (2000 est.)
Military manpower - fit for military service;
males age 15-49:1,134,751 (2000 est.)
Military manpower - reaching military age
annually;
males: 45,605 (2000 est.)
Military expenditures - dollar figure: $332 million
(FY99)
Military expenditures - percent of GDP; 1 .7%
(FY99)
I t r a rTs n a t i oli¥T Issues^
Disputes - international: ongoing Gabcikovo Dam
dispute with Hungary; agreement with Czech
Republic signed 24 November 1998 resolves issues
of redistribution of former Czechoslovak federal
property - approval by both parliaments is expected in
2000
Illicit drugs: transshipment point for Southwest
Asian heroin bound for Western Europe
449
: Slovenia','cdbb2eb67699a4633584003d8246c35414a05b33478cd483b44fdb72caa580a3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8eda112166bb753f875880063a51b35b98d7adb5720a4260b3342fc21e998dc',2000,'SO','Somalia','communications',427,'Telephones - main lines in use: NA
Telephones ■ mobile cellular; NA
Telephone system: the public telecommunications
system was completely destroyed or dismantled by
the civil war factions; all relief organizations depend
on their own private systems
domestic: recently, local cellular telephone systems
have been established in Mogadishu and in several
other population centers
international: international connections are available
from Mogadishu by satellite
Radio broadcast stations: AM 0, FM 0, shortwave
4(1988)
Radios: 470,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 135,000(1997)
Internet Service Providers (ISPs); NA','46d445bb0d8da49cc7bc0147c363493b4aca08134ce14d077b6939417bfd19ad','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb9cf0c94bf3335f6a8375ae2329cb2522c6f4b6c8bcf06902331c8b6cdf8fb3',2000,'ZA','South Africa','communications',433,'Telephones - main lines in use: 5.075 million
(1999)
Telephones - mobile cellular: over 2,000,000
(1999)
Telephone system: the system is the best
developed and most modern in Africa
domestic: consists of carrier-equipped open-wire
lines, coaxial cables, microwave radio relay links,
fiber-optic cable, radiotelephone communication
stations, and wireless local loops; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria
international: 2 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean)
Radio broadcast stations: AM 14, FM 347 (plus
243 repeaters), shortwave 1 (1998)
Radios: 13.75 million (1997)
Television broadcast stations: 556 (plus 144
network repeaters) (1997)
Televisions: 5.2 million (1997)
Internet Service Providers (ISPs): 58 (1999)
Telephones - main lines in use: 17.336 million
(1999)
Telephones - mobile cellular: 8.394 million (1999)
Telephone system: generally adequate, modern
facilities
domestic: NA
international: 22 coaxial submarine cables; satellite
earth stations - 2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean), NA Eutelsat; tropospheric scatter to
adjacent countries
Radio broadcast stations: AM 208, FM 715,
shortwave 1 (1998)
Radios; 13.1 million (1997)
Television broadcast stations: 228 (plus 2,1 12
repeaters); note - these figures include 1 1 television
broadcast stations and 89 repeaters in the Canary
Islands (September 1995)
Televisions: 16.2 million (1997)
Internet Service Providers (ISPs): 49 (1999)
Railways;
total: 13,950 km
broad gauge: 12,781 km 1.668-m gauge (6,358 km
electrified; 2,295 km double track)
standard gauge: 525 km 1 .435-m gauge (525 km
electrified)
narrow gauge: 644 km 1 .000-m gauge (438 km
electrified) (1998)
Highways;
total: 346,858 km
paved: 343,389 km (including 9,063 km of
expressways)
unpaved: 3,469 km (1997 est.)
Waterways: 1 ,045 km, but of minor economic
importance
Pipelines: crude oil 265 km; petroleum products
1 ,794 km; natural gas 1 ,666 km
Ports and harbors: Aviles, Barcelona, Bilbao,
Cadiz, Cartagena, Castellon de la Plana, Ceuta,
Huelva, La Coruna, Las Palmas (Canary Islands),
Malaga, Melilla, Pasajes, Gijon, Santa Cruz de
Tenerife (Canary Islands), Santander, Tarragona,
Valencia, Vigo
Merchant marine:
total: 130 ships (1 ,000 GRT or over) totaling
1,131,648 GRT/1, 688,996 DWT
ships by type: bulk 1 1 , cargo 24, chemical tanker 9,
container 9, liquified gas 2, livestock carrier 1 ,
passenger 1 , petroleum tanker 24, refrigerated cargo
5, roll-on/roll-off 36, short-sea passenger 7,
specialized tanker 1 (1999 est.)
463
Spain (continued)
Airports: 105 (1999 est.)
Airports - with paved runways:
total: 70
over 3,047 m: 15
2,438 to 3,047 m:tt
1,524 to 2,437 m:M
91 4 to 1,523 m:M
under 914 m; 10 (1999 est.)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 914 m:25 (1999 est.)
Heliports: 2 (1999 est.)','884f94fca643724637874a74e0e5675f9752109be50493aeaecf334dcb0c6cbb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80ddd78679be9a301176f9d3c96a00af8e3cd7b19935fac1f5036ad8fe586486',2000,'PH','Philippines','communications',440,'Telephones - main lines in use: 494,509 (1998)
Telephones - mobile cellular: 228,604 (1999)
Telephone system: very inadequate domestic
service, particularly in rural areas; some hope for
improvement with privatization of national telephone
company and encouragement to private investment;
good international service (1999)
domestic: national trunk network consists mostly of
digital miorowave radio relay; fiber-optic links now in
use in Colombo area and two fixed wireless local
loops have been installed; competition is strong in
mobile cellular systems; telephone density remains
low at 2.6 main lines per 100 persons (1999)
466
Sri Lanka (continued)
international: submarine cables to Indonesia and
Djibouti; satellite earth stations - 2 Intelsat (Indian
Ocean) (1999)
Radio broadcast stations; AM 26, FM 45,
shortwave 1 (1998)
Radios: 3.85 million (1997)
Television broadcast stations; 21 (1997)
Televisions: 1.53 million (1997)
Internet Service Providers (ISPs): 4 (1999)
I Transportation
Railways:
total: 1 ,463 km
broad gauge: 1 ,404 km 1 .676-m gauge
narrow gauge: 59 km 0.762-m gauge (1996)
Highways:
total: 1 1 ,285 km
paved; 10,721 km
unpaved: 564 km (1 998 est.)
Waterways: 430 km; navigable by shallow-draft craft
Pipelines: crude oil and petroleum products 62 km
(1987)
Ports and harbors: Colombo, Galle, Jaffna,
Trincomalee
Merchant marine;
total: 24 ships (1,000 GRT or over) totaling 192,190
GRT/293,832 DWT
ships by type: bulk 1 , cargo 1 6, container 1 ,
petroleum tanker 1, refrigerated cargo 5 (1999 est.)
Airports: 14 (1999 est.)
Airports - with paved runways;
total: t2
over 3,047 m: t
1,524 to 2,437 m: 5
9/4 to 1,523m;6 (1999 est.)
Airports - with unpaved runways;
total: 2
1,524 to 2,437 m:1
under 914 m:1 (1999 est.)
I Military
Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
Military manpower - availability:
mates age 15-49: 5,251 ,045 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 4,081 ,742 (2000 est.)
Military manpower - reaching military age
annually:
males: 196,584 (2000 est.)
Military expenditures - dollar figure; $71 9 million
(FY98)
Military expenditures - percent of GDP: 4.2%
(FY98)
J; transnational Issues
Disputes - international: none
I" Introduction"
Background; Military dictatorships promulgating an
Islamic government have mostly run the country since
independence from the UK in 1 956. Over the past two
decades, a civil war pitting black Christians and
animists in the south against the Arab-Muslims of the
north has cost at least 1.5 million lives in war and
famine-related deaths, as well as the displacement of
millions of others.
r . '' '' " q g oYf a p hY
Location: Northern Africa, bordering the Red Sea,
between Egypt and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area;
tofa/; 2,505,81 Osq km
land: 2.376 million sq km
water; 129,810 sq km
Area - comparative: slightly more than one-quarter
the size of the US
Land boundaries:
total: 7,687 km
border counfr/''es; Central African Republic 1,165 km,
Chad 1,360 km, Democratic Republic of the Congo
628 km, Egypt 1 ,273 km, Eritrea 605 km, Ethiopia
1 ,606 km, Kenya 232 km, Libya 383 km, Uganda 435
km
Coastline: 853 km
Maritime claims:
contiguous zone: 1 8 nm
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: tropical in south; arid desert in north; rainy
season (April to October)
Terrain: generally flat, featureless plain; mountains
in east and west
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of
iron ore, copper, chromium ore, zinc, tungsten, mica,
silver, gold, hydropower
Land use;
arable land: 5%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 19%
ofber;30% (1993 est.)
Irrigated land: 19,460 sq km (1993 est.)
Natural hazards; dust storms
Environment - current issues; inadequate
supplies of potable water; wildlife populations
threatened by excessive hunting; soil erosion;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: largest country in Africa;
dominated by the Nile and its tributaries
I;''"''"* . py--’-
Population: 35,079,814 (July 2000 est.)
Age structure:
0-14 years: 45% (male 8,064,592; female 7,712,839)
15-64 years: 53% (male 9,300,886; female
9,290,340)
65 years and over: 2% (male 406,034; female
305,123) (2000 est.)
Population growth rate: 2.84% (2000 est.)
Birth rate: 38.58 births/1 ,000 population (2000 est.)
Death rate: 10.28 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0.05 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .33 male(s)/female
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 70.21 deaths/1,000 live births
(2000 est.)
Life expectancy at birth;
total population: 56.55 years
male: 55.49 years
female: 57.66 years (2000 est.)
Total fertility rate: 5.47 children born/woman
(2000 est.)
Nationality;
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%, other 1%
Religions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
467
Sudan (continued)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
note: program of Arabization in process
Literacy:
definition: age 15 and over can read and write
total population: 46.1 %
mate: 57.7%
female: 34.6% (1995 est.)','f1164b7a8fe508fe34f44af00dfa745db6331018b8ef1341183cd2879d716a21','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba795d40da2bd4b2b62a6ded40b3bda017584babbef8b7ffb40fa2592d1eb38',2000,'ZW','Zimbabwe','communications',456,'Teiephones - main iines in use: 263,000 (1995)
Telephones - mobile ceiiuiar: NA
Teiephone system: poorly developed and not well
maintained; many towns are not reached by the
national network
domesf/c; cable and microwave radio relay
international: linked by cable and microwave radio
relay to other CIS republics, and by leased
connections to the Moscow international gateway
switch; Dushanbe linked by Intelsat to international
gateway switch in Ankara (Turkey); satellite earth
stations - 1 Orbita and 2 Intelsat
Radio broadcast stations: AM 9, FM 6, shortwave
5(1998)
Radios: 1.291 million (1991)
Television broadcast stations: 0 (there are,
however, repeaters that relay programs from Russia,
Iran, and Turkey) (1997)
Televisions: 860,000(1991)
Internet Service Providers (ISPs): NA
I f r a n s p 0 r Fa f i 0 n
Railways:
total: 480 km in common carrier service; does not
include industrial lines (1990)
Highways:
total: 13,700 km
paved: 1 1 ,330 km (these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel surfaced)
unpaved: 2,370 km (1 996 est.)
Pipelines: natural gas 400 km (1992)
Ports and harbors: none
Airports: 59 (1994 est.)
Airports - with paved runways:
fofa/;14
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m:1 (1994 est.)
Airports - with unpaved runways:
total: 45
914 to 1,523 m: 9
under 914 m: 36 (1 994 est.)
f Military
Military branches: Army, Air Force, Air Defense
Forces, Presidential National Guard, Security Forces
(internal and border troops)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 1 ,529,832 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,253,427 (2000 est.)
Military manpower - reaching military age
annually:
males: 68,262 (2000 est.)
Military expenditures - dollar figure: $1 7 million
(FY97)
Military expenditures - percent of GDP: 1 .8%
(FY97)
I t r a n s n a t i 0 n a I lH s u e s ~
Disputes - international: portions of the boundary
with China are indefinite; territorial dispute with
Kyrgyzstan on northern boundary in Isfara Valley area
Illicit drugs: limited illicit cultivation of cannabis,
mostly for domestic consumption; opium poppy
cultivation negligible in 1998 because of government
eradication program; major transshipment point for
illicit drugs from Southwest Asia to Russia and
Western Europe
Telephones - main lines in use: 5.4 million (1998)
Telephones - mobile cellular: 2.3 million (1998)
Telephone system: service to general public
adequate, but investment in technological upgrades
reduced by recession; bulk of service to government
activities provided by multichannel cable and
microwave radio relay network
domestic: microwave radio relay and multichannel
cable; domestic satellite system being developed
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 204, FM 334,
shortwave 6 (1999)
Radios: 13.96 million (1997)
Television broadcast stations: 5 (all in Bangkok;
plus 131 repeaters) (1997)
Televisions: 1 5.1 9 million (1 997)
Internet Service Providers (ISPs): 13 (1999)
Telephones - main lines in use: 22,000 (1995)
Telephones • mobile cellular; NA
Telephone system: fairsystem based on network of
microwave radio relay routes supplemented by
open-wire lines and cellular system
domestic: microwave radio relay and open-wire lines
for conventional system; cellular system has capacity
of 10,000 telephones
international: satellite earth stations - 1 Intelsat
(Atlantic Ocean) and 1 Symphonie
Radio broadcast stations; AM 2, FM 9, shortwave
4(1998)
Radios: 940,000(1997)
Television broadcast stations; 3 (plus two
repeaters) (1997)
Televisions: 73,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Telephones - main lines in use: NA
Telephones - mobile cellular: 0 (1 999)
Telephone system:
domestic: radiotelephone service between islands
international: radiotelephone service to Samoa;
government-regulated telephone service (TeleTok),
with 3 satellite earth stations, established in 1997
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: each atoll has a radio broadcast station of
unknown type that broadcasts shipping and weather
reports (1998)
Radios: 1,000(1997)
Television broadcast stations: NA
Televisions: 0(1997)
Internet Service Providers (ISPs): NA','559885f76b53a3e8308b2d02c6f39b0ec4260a58f67b6617d2ba94d37fb84369','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65d202aaa42990166b1d5a3b684d676a59c41ca6c4bba9175d395e9fbe63268a',2000,'MP','Northern Mariana Islands','communications',484,'Teiephone system: satellite communications; 1
DSN circuit off the Overseas Telephone System
(OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM NA,
shortwave NA
rrofe; Armed Forces Radio/Television Service
(AFRTS) radio service provided by satellite (1998)
Television broadcast stations: 0 (1997)','10a508b1b35880309e82fa3b0daaa206d959c0037558be37750d33a0a6a44a27','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

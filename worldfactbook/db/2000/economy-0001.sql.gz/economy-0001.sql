SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e58ed801ea662eee24c79c9530df20047b66a1f30d8f6db827491764017d0fe',2000,'EH','Western Sahara','economy',13,'Economy - overview
GDP
GDP - real growth rate
GDP - per capita
GDP - composition by sector
agriculture
industry
services
Population below poverty line
Household income or consumption by
percentage share
lowest 10%
highest 10%
Inflation rate (consumer prices)
Labor force
Labor force - by occupation
Unemployment rate
Budget
revenues
expenditures
Industries
Industrial production growth rate
Electricity - production
Electricity - production by source
fossil fuel
hydro
nuclear
other
Electricity - consumption
Electricity - exports
Electricity • imports
Agriculture - products
Exports
Exports - commodities
Exports - partners
Imports
Imports - commodities
Imports - partners
Debt - external
Economic aid - donor
Economic aid - recipient
Currency
Exchange rates
Fiscal year
Economy - overview: Afghanistan is an extremely
poor, landlocked country, highly dependent on
farming and livestock raising (sheep and goats).
Economic considerations have played second fiddle
to political and military upheavals during two decades
of war, including the nearly 10-year Soviet military
occupation (which ended 15 February 1 989). During
that conflict one-third of the population fled the
country, with Pakistan and Iran sheltering a combined
peak of more than 6 million refugees. In early 1999,
1 .2 million Afghan refugees remained in Pakistan and
about 1 .4 million in Iran. Gross domestic product has
fallen substantially over the past 20 years because of
the loss of labor and capital and the disruption of trade
and transport. The majority of the population
continues to suffer from insufficient food, clothing,
housing, and medical care. Inflation remains a serious
problem throughout the country. International aid can
deal with only a fraction of the humanitarian problem,
let alone promote economic development. The
economic situation did not improve in 1998-99, as
internal civil strife continued, hampering both
domestic economic policies and internationai aid
efforts. Numericai data are likely to be either
unavailable or unreliable. Afghanistan was by far the
largest producer of opium poppies in 1999, and
narcotics trafficking is a major source of revenue.
GDP: purchasing power parity- $21 billion (1 999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $800
(1999 est.)
GDP - composition by sector:
agriculture: 53%
industry: 28.5%
sem''ces; 18.5% (1990)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force; 8 million (1997 est.)
Labor force - by occupation: agriculture 68%,
industry 16%, services 16% (1980 est.)
Unemployment rate: 8% (1995 est.)
Budget;
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: small-scale production of textiles, soap,
furniture, shoes, fertilizer, and cement; handwoven
carpets; naturai gas, oil, coal, copper
Electricity - production: 430 million kWh (1998)
Electricity - production by source;
fossil fuel: 41 .86%
hydro: 58.14%
nuclear: 0%
often 0% (1998)
Electricity - consumption: 510 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 110 million kWh (1998)
Agriculture - products: opium poppies, wheat,
fruits, nuts, karakul pelts; wool, mutton
Exports: $80 million (does not include opium)
(1996 est.)
Exports - commodities: opium, fruits and nuts,
handwoven carpets, wool, cotton, hides and pelts,
precious and semi-precious gems
Exports - partners: FSU, Pakistan, Iran, Germany,
India, UK, Belgium, Luxembourg, Czech Republic
Imports: $150 million (1996 est.)
Imports - commodities; capital goods, food and
petroleum products; most consumer goods
Imports - partners: FSU, Pakistan, Iran, Japan,
Singapore, India, South Korea, Germany
Debt - external: $5.5 billion (1996 est.)
Economic aid - recipient: US provided about $70
million in humanitarian assistance in 1997; US
continues to contribute to multilateral assistance
through the UN programs of food aid, immunization,
land mine removal, and a wide range of aid to
refugees and displaced persons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (Af) per US$1 - 4,700
(January 2000), 4,750 (February 1999), 17,000
(December 1996), 7,000 (January 1995), 1,900
(January 1994), 1,019 (March 1993), 850 (1991);
note - these rates reflect the free market exchange
rates rather than the official exchange rate, which was
fixed at 50.600 afghanis to the dollar until 1 996, when
it rose to 2,262.65 per dollar, and finally became fixed
again at 3,000.00 per dollar In April 1996
Fiscal year: 21 March - 20 March
Economy - overview; An extremely poor country by
European standards, Albania is making the difficult
transition to a more open-market economy. The
economy rebounded in 1993-95 after a severe
depression accompanying the collapse of the
previous centrally planned system in 1990 and 1991.
However, a weakening of government resolve to
maintain stabilization policies in the election year of
1996 contributed to renewal of inflationary pressures.
4
Albania (continued)
spurred by the budget deficit which exceeded 12%.
The coliapse of financial pyramid schemes in early
1 997 - which had attracted deposits from a substantial
portion of Albania''s population - triggered severe
social unrest which led to more than 1 ,500 deaths,
widespread destruction of property, and an 8% drop in
GDP. The new government, installed in July 1 997, has
taken strong measures to restore public order and to
revive economic activity and trade. The economy
continues to be bolstered by remittances of some 20%
of the labor force that works abroad, mostly in Greece
and Italy. These remittances supplement GDP and
help offset the large foreign trade deficit. Most
agricultural land was privatized in 1992, substantially
improving peasant incomes. In 1998, Albania
recovered the 8% drop in GDP of 1997 and pushed
ahead by 7% in 1999. International aid has helped
defray the high costs of receiving and returning
refugees from the Kosovo conflict.
GDP: purchasing power parity - $5.6 billion
(1999 est.)
GDP - real growth rate: 8% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,650
(1999 est.)
GDP - composition by sector:
agriculture: 54%
industry: 25%
serv/ces:21%(1998)
Population below poverty line: 1 9.6% (1 996 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 0.5% (1999 est.)
Labor force: 1 .692 million (including 352,000
emigrant workers and 261,000 domestically
unemployed) (1994 est.)
Labor force - by occupation: agriculture 49.5%,
industry and services 50.5%
Unemployment rate: 1 4% (October 1 997) officially,
but may be as high as 28%
Budget:
revenues: $393 million
expenditures: $676 million, including capital
expenditures of $NA (1997 est.)
Industries: food processing, textiles and clothing;
lumber, oil, cement, chemicals, mining, basic metals,
hydropower
Industrial production growth rate: 7% (1999 est.)
Electricity - production: 5.15 billion kWh (1998)
Electricity ■ production by source:
fossil fuel: 2.91%
hydro: 97.09%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 5.29 billion kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 500 million kWh (1 998)
Agriculture - products: wheat, corn, potatoes,
vegetables, fruits, sugar beets, grapes; meat, dairy
products
Exports: $242 million (f.o.b., 1999 est.)
Exports - commodities: textiles and footwear;
asphalt, metals and metallic ores, crude oil;
vegetables, fruits, tobacco
Exports - partners: Italy 63%, Greece 12%,
Germany 6%, Netherlands, Belgium, US (1998)
Imports: $925 million (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment,
foodstuffs, textiles, chemicals
Imports - partners: Italy 43%, Greece 29%, Turkey
4%, Germany 4%, Bulgaria, The Former Yugoslav
Republic of Macedonia (1998)
Debt - external: $820 million (1998)
Economic aid - recipient: EU pledged $100 million
to share with The Former Yugoslav Republic of
Macedonia (1999)
Currency: 1 lek(L) = 100qintars
Exchange rates: leke (L) per US$1 - 135.31
(December 1999), 137.69 (1999), 150.63 (1998),
148.93 (1997), 104.50 (1996), 92.70 (1995)
Fiscal year: calendar year
I C^fnln u n i clTt i cTiTs ^
Telephones - main lines in use: 42,000 (1995)
Telephones - mobile cellular: 3,100 (1999)
Telephone system:
domestic: obsolete wire system; no longer provides a
telephone for every village; in 1992, following the fall
of the communist government, peasants cut the wire
to about 1 ,000 villages and used it to build fences
international: inadequate; international traffic carried
by microwave radio relay from the Tirana exchange to
Italy and Greece
Radio broadcast stations: AM 16, FM 3, shortwave
2(1999)
Radios: 810,000(1997)
Television broadcast stations: 13 (1999)
Televisions: 405,000(1997)
Internet Service Providers (ISPs): 2 (1999)
I franspoFTaTTon ^
Railways:
total: 670 km
standard gauge: 670 km 1 .435-m gauge (1 996)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1998 est.)
Waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55
km; natural gas 64 km (1991)
Ports and harbors: Durres, Sarande, Shengjin,
VIore
Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 10,907
GRT/16,101 DWT
ships by type: cargo 6 (1999 est.)
Airports: 10 (1999 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m; 3 (1999 est.)
Airports - with unpaved runways:
total: 7
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m: 3 [1999 est.)
Heliports: 1 (1999 est.)
Military branches: Army, Navy, Air and Air Defense
Forces, Interior Ministry Troops, Border Guards
Military manpower - miiitary age: 1 9 years of age
Military manpower - availability:
males age 15-49: 856,820 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 701 ,194 (2000 est.)
Military manpower - reaching military age
annualiy:
males: 35,508 (2000 est.)
Military expenditures - dollar figure: $42 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
|r”f” • a n~s rTaTToiraT i s sTTeT^
Disputes - international: the Albanian Government
supports protection of the rights of ethnic Albanians
outside of its borders but has downplayed them to
further its primary foreign policy goal of regional
cooperation; Albanian majority in Kosovo seeks
independence from Serbian Republic; Albanians in
The Former Yugoslav Republic of Macedonia claim
discrimination in education, access to public-sector
jobs, and representation in government
Illicit drugs: increasingly active transshipment point
for Southwest Asian opiates, hashish, and cannabis
transiting the Balkan route and - to a far lesser extent
■ cocaine from South America destined for Western
Europe; limited opium and cannabis production;
ethnic Albanian narcotrafficking organizations active
and rapidly expanding in Europe
5','26a1b41377131728ed9ca2373607388454ecf9ecce24129a2c1243939d90bd0d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14712fd76de0f4dddcc8322a34ba46a58f3507634c439d497269f7f27b0d8568',2000,'DZ','Algeria','economy',18,'Background: After a century of rule by France,
Algeria became independent in 1962. The surprising
first round success of the fundamentalist FIS (Islamic
Salvation Front) party in December 1991 balloting
caused the army to intervene, crack dowm on the FIS,
and postpone the subsequent elections. The FIS
response has resulted in a continuous low-grade civil
conflict with the secular state apparatus, which
nonetheless has allowed elections featuring
pro-government and moderate religious-based
parties. FIS''s armed wing, the Islamic Salvation Army,
dissolved itself in January 2000 and many armed
insurgents surrendered under an amnesty program
designed to promote national reconciliation.
Nevertheless, some residual fighting continues. Other
concerns include large-scale unemployment and the
need to diversify the petroleum-based economy.
f Geography
Location: Northern Africa, bordering the
Mediterranean Sea, between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total: 2,381 ,740 sq km
land: 2,381 ,740 sq km
water: 0 sq km
Area - comparative: slightly less than 3.5 times the
size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km,
Mauritania 463 km, Morocco 1 ,559 km, Niger 956 km,
Tunisia 965 km. Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 nm
territorial sea: t2 nm
Ciimate: arid to semiarid; mild, wet winters with hot,
dry summers along coast; drier with cold winters and
hot summers on high piateau; sirocco is a hot, dust/
sand-laden wind especiaiiy common in summer
Terrain: mostly high piateau and desert; some
mountains; narrow, discontinuous coastal plain
Elevation extremes:
lowest point: Chott Meirhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 2%
other: 82% (1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to
severe earthquakes; mud slides
Environment - current issues: soil erosion from
overgrazing and other poor farming practices;
desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters;
Mediterranean Sea, in particular, becoming polluted
from oil wastes, soil erosion, and fertilizer runoff;
inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Nuclear T est Ban
Geography • note: second-largest country in Africa
(after Sudan)','de12416868e7aa7e716e983f56a2e248a882a28d4fa242175dd653fd4f426b11','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b24ab2bb9be49ea8978063307c22dbaf556186ba3a105eaa734f4884d0a16da',2000,'AI','Anguilla','economy',34,'Economy - overview; Anguilla has few natural
resources, and the economy depends heavily on
luxury tourism, offshore banking, lobster fishing, and
remittances from emigrants. The economy, and
especially the tourism sector, suffered a setback in
late 1995 due to the effects of Hurricane Luis in
September but recovered in 1996. Increased activity
in the tourism industry, which has spurred the growth
of the construction sector, contributed to economic
growth in 1997-98. Anguillan officials have put
substantial effort into developing the offshore
financing sector. A comprehensive package of
financial services legislation was enacted in late 1 994.
In the medium term, prospects for the economy will
depend on the tourism sector and, therefore, on
continuing income growth in the industrialized nations
as well as favorable weather conditions.
GDP: purchasing power parity - $88 million
(1998 est.)
GDP - real growth rate: 6.5% (1998 est.)
GDP - per capita: purchasing power parity - $7,900
(1998 est.)
GDP - composition by sector:
agriculture: 4%
Industry: 16%
services: 78% (1 997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 2.5% (1998 est.)
Labor force: 4,400(1992)
Labor force - by occupation: commerce 36%,
services 29%, construction 18%, transportation and
utilities 10%, manufacturing 3%, agriculture/fishing/
forestry/mining 4%
Unemployment rate: 7% (1992 est.)
Budget:
revenues: $20.4 million
expenditures: $23.3 million, including capital
expenditures of $3.8 million (1 997 est.)
Industries: tourism, boat building, offshore financial
services
Industrial production growth rate: 3.1%
(1997 est.)
Electricity - production; NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products; small quantities of tobacco,
vegetables; cattle raising
Exports: $4.5 million (1998)
Exports - commodities: lobster, fish, livestock, salt
Exports - partners; NA
Imports; $57.6 million (1998)
Imports - commodities; NA
Imports - partners; NA
Debt - external; $8.8 million (1998)
Economic aid - recipient; $3.5 million (1995)
Currency: 1 East Caribbean dollar (EC$) = 100
cents
Exchange rates; East Caribbean dollars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March
15
Anguilla (continued)
I Communications
Teiephones - main iines in use: 4,000 (1994)
Telephones - mobile cellular: NA
Telephone system:
domestic: modern internal telephone system
internationai: microwave radio relay to island of Saint
Martin (Guadeloupe and Netherlands Antilles)
Radio broadcast stations: AM 5, FM 6,
shortwave 1 (1998)
Radios: 3,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000(1997)
Internet Service Providers (ISPs): NA','6b5f63cd9ef2241c0ca7e629da1947ccacf56608a6266f87e27f8bfc795326b0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0529fb35447095b501e2925b563b1c0e92d7ce47e6f1e0cdd859ef84a9b17724',2000,'GP','Guadeloupe','economy',43,'Economy - overview: Economic activity is limited to
the exploitation of natural resources, including
petroleum, natural gas, fish, and seals.
t Transportation
Ports and harbors: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
T ransportation - note: sparse network of air, ocean,
river, and land routes; the Northwest Passage (North
America) and Northern Sea Route (Eurasia) are
important seasonal waterways
I transnationaf issues
Disputes - internationai: some maritime disputes
(see littoral states); Svalbard is the focus of a maritime
boundary dispute between Norway and Russia
20
Background: Following independence from Spain in
1816, Argentina experienced periods of internal
political conflict between conservatives and liberals
and between civilian and military factions. After World
War II, a long period of Peronist dictatorship was
followed by a military junta that took power in 1 976.
Democracy returned in 1983, and four free elections
since then have underscored Argentina''s progress in
democratic consolidation.
I Geo g r a p h y” ~
Location: Southern South America, bordering the
South Atlantic Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
wafer; 30,200 sq km
Area - comparative: slightly less than three-tenths
the size of the US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1 ,224 km,
Chile 5,150 km, Paraguay 1 ,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: ''\\2r\\m
Climate: mostly temperate; arid In southeast;
subantarctic in southwest
Terrain: rich plains of the Pampas in northern half,
flat to rolling plateau of Patagonia in south, rugged
Andes along western border
Elevation extremes:
lowest point: Salinas Chicas 40 m (located on
Peninsula Valdes)
highest point: Cerro Aconcagua 6,960 m
Natural resources: fertile plains of the pampas,
lead, zinc, tin, copper, iron ore, manganese,
petroleum, uranium
Land use:
arable land: 9%
permanent crops: 1 %
permanent pastures: 52%
forests and woodland: 19%
of/jer;19%(1993 est.)
Irrigated land: 17,000 sq km (1993 est.)
Natural hazards: San Miguel de Tucuman and
Mendoza areas in the Andes subject to earthquakes;
pamperos are violent windstorms that can strike the
Pampas and northeast; heavy flooding
Environment - current issues: environmental
problems (urban and rural) typical of an industrializing
economy such as soil degradation, desertification, air
pollution, and water pollution
note: Argentina is a world leader in setting voluntary
greenhouse gas targets
Environment - international agreements:
party fo: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: second-largest country in South
America (after Brazil); strategic location relative to sea
lanes between South Atlantic and South Pacific
Oceans (Strait of Magellan, Beagle Channel, Drake
Passage)
Population: 36,955,182 (July 2000 est.)
Age structure:
0-14 years: 27% (male 5,061 ,588; female 4,827,582)
15-64 years: 63% (male 1 1 ,625,574; female
11,613,358)
65 years and over: 1 0% (male 1 ,582,861 ; female
2,244,219) (2000 est.)
Population growth rate: 1.16% (2000 est.)
Birth rate: 18.59 births/1,000 population (2000 est.)
Death rate: 7.59 deaths/1,000 population
(2000 est.)
Net migration rate: 0.65 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 18.31 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 75.05 years
ma/e; 71.67 years
female: 78.61 years (2000 est.)
Total fertility rate: 2.47 children born/woman
(2000 est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Italian)
97%, mestizo, Amerindian, or other nonwhite groups
3%
Religions: nominally Roman Catholic 92% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 4%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
male: 96.2%
female: 98.2% (1995 est.)
I — ™ Government
Country name:
conventional long form: Argentine Republic
conventional short form: Argentina
local long form: Republica Argentina
local short form: Argentina
Data code: AR
Government type: republic
Capital: Buenos Aires
Administrative divisions: 23 provinces (provincias,
singular - provincia), and 1 federal district* (distrito
federal); Buenos Aires; Catamarca; Chaco; Chubut;
Cordoba; Corrientes; Distrito Federal*; Entre Rios;
Formosa; Jujuy; La Pampa; La Rioja; Mendoza;
Misiones; Neuquen; Rio Negro; Salta; San Juan; San
Luis; Santa Cruz; Santa Fe; Santiago del Estero;
Tierra del Fuego, Antartica e Islas del Atlantico Sur;
Tucuman
note; the US does not recognize any claims to','56b129039694c99a97a7e6d0c0c919c99fe45f8dd520fb88faf9cc743843aa66','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d13a2147e6a6f356326baf4bc5e29f6e08b3355639986ba3bebbec27f3b7168',2000,'AQ','Antarctica','economy',44,'Independence: 9 July 1816 (from Spain)
National holiday: Revolution Day, 25 May (1810)
Constitution: 1 May 1853; revised August 1994
Legal system: mixture of US and West European
legal systems; has not accepted compulsory ICJ
jurisdiction
21
Argentina (continued)
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Fernando DE LA RUA (since
10 December 1999); Vice President Carios Alberto
ALVAREZ (since 10 December 1999); note - the
president is both the chief of state and head of
Economy - overview: Argentina benefits from rich
natural resources, a highly literate population, an
export-oriented agricultural sector, and a diversified
industrial base. However, when President Carlos
MENEM took office in 1989, the country had piled up
huge external debts, inflation had reached 200% per
month, and output was plummeting. To combat the
economic crisis, the government embarked on a path
of trade liberalization, deregulation, and privatization.
In 1991 , it implemented radical monetary reforms
which pegged the peso to the US dollar and limited the
growth in the monetary base by law to the growth in
reserves. Inflation fell sharply in subsequent years. In
1995, the Mexican peso crisis produced capital flight,
the loss of banking system deposits, and a severe, but
short-lived, recession; a series of reforms to bolster
the domestic banking system followed. Real GDP
growth recovered strongly, reaching 8% in 1997. In
1998, international financial turmoil caused by
Russia''s problems and increasing investor anxiety
over Brazil produced the highest domestic interest
rates in more than three years, halving the growth rate
of the economy. Conditions worsened in 1999 with
GDP falling by 3%. President Fernando DE LA RUA,
who took office in December 1999, sponsored tax
increases and spending cuts to reduce the deficit,
which had ballooned to 2.5% of GDP in 1999. The
new government also arranged a new $7.4 billion
stand-by facility with the IMF for contingency
purposes - almost three times the size of the previous
arrangement. Key challenges facing the new
government include reforming the country''s rigid labor
code and addressing the precarious financial situation
of several highly indebted provinces.
GDP: purchasing power parity -$367 billion (1999 est.)
GDP - real growth rate: -3% (1999 est.)
GDP - per capita: purchasing power parity - $1 0,000
(1999 est.)
GDP - composition by sector:
agriculture: 7%
industry: 29%
services: 64% (1 999 est.)
Popuiation below poverty line: 36% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -2% (1999 est.)
Labor force: 15 million (1999)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 14% (December 1999)
Budget:
revenues: $44 billion
expenditures: $48 billion, including capital
expenditures of $NA billion (2000 est.)
Industries; food processing, motor vehicles,
consumer durables, textiles, chemicals and
petrochemicals, printing, metallurgy, steel
Industrial production growth rate: -7% (1999 est.)
Electricity - production: 75.237 billion kWh (1998)
Electricity - production by source;
fossil fuel: 42.71%
hydro: 47.55%
nuclear: 9.47%
other 0.27% (1998)
Electricity - consumption; 75.57 billion kWh (1 998)
Electricity - exports: 250 million kWh (1998)
Electricity - imports: 5.85 billion kWh (1998)
Agriculture - products; sunflower seeds, lemons,
soybeans, grapes, corn, tobacco, peanuts, tea,
wheat; livestock
Exports: $23 billion (f.o.b., 1999 est.)
Exports - commodities: edible oils, fuels and
energy, cereals, feed, motor vehicles
Exports - partners: Brazil 24%, EU 21%, US 11%
(1999 est.)
Imports: $25 billion (c.i.f., 1999 est.)
Imports - commodities: machinery and equipment,
motor vehicles, chemicals, metal manufactures,
plastics
Imports - partners: EU 28%, US 22%, Brazil 21%
(1999 est.)
Debt - external: $149 billion (1999 est.)
Economic aid - recipient: $2,833 billion (1 995)
Currency: 1 peso = 100 centavos
Exchange rates: peso is pegged to the US dollar at
an exchange rate of 1 peso = $1
Fiscal year: calendar year
22
Argentina (continued)
I Communications
Telephones - main lines in use; 7.5 million (1997)
Telephones - mobile cellular: 1 .8 million (1 997)
Telephone system: 12,000 public telephones;
extensive modern system but many families do not
have telephones; despite extensive use of microw/ave
radio relay, the telephone system frequently fails
during rainstorms, even in Buenos Aires
domestic: microwave radio relay and a domestic
satellite system with 40 earth stations serve the trunk
network
international: satellite earth stations - 3 Intelsat
(Atlantic Ocean); two international gateways near
Buenos Aires; Atlantis II submarine cable (1999)
Radio broadcast stations; AM 260 (including 10
inactive stations), FM NA (probably more than 1,000,
mostly unlicensed), shortwave 6 (1998)
Radios; 24.3 million (1997)
Television broadcast stations: 42 (plus 444
repeaters) (1997)
Televisions: 7.95 million (1997)
Internet Service Providers (ISPs): 47 (1999)
I transportation
Railways;
tofa/; 38,326 km (160 km electrified)
broad gauge; 24,481 km 1.676-m gauge (134 km
electrified)
standard gauge: 2, 7Q5 km 1.435-m gauge (26 km
electrified)
narrow gauge; 11,080 km 1.000-m gauge (1999)
Highways:
tofa/; 21 5,434 km
paved: 63,553 km (including 734 km of expressways)
unpaved: 151,881 km (1998 est.)
Waterways: 10,950 km navigable
Pipelines: crude oil 4,090 km; petroleum products
2,900 km; natural gas 9,91 8 km
Ports and harbors: Bahia Blanca, Buenos Aires,
Comodoro Rivadavia, Concepcion del Uruguay, La
Plata, Mar del Plata, Necochea, Rio Gallegos,
Rosario, Santa Fe, Ushuaia
Merchant marine;
total: 26 ships (1,000 GRT or over) totaling 218,540
GRT/333,413 DWT
ships by type: cargo 9, petroleum tanker 1 1 , rail car
carrier 1 , refrigerated cargo 2, roll-on/roll-off 1 ,
short-sea passenger 2 (1999 est.)
Airports; 1,359 (1999 est.)
Airports - with paved runways;
total: 142
over 3,047 m: 5
2,438 to 3,047 m: 26
1,524 to 2,437 m: 60
914 to 1,523 m: 44
under 914 m: 7 (1 999 est.)
Airports - with unpaved runways;
tofa/; 1,217
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 63
914 to 1,523 m: 61 4
under 914 m: 536 (1999 est.)
I Military
Military branches; Argentine Army, Navy of the
Argentine Republic (includes Naval Aviation, Marines,
and Coast Guard), Argentine Air Force, National
Gendarmerie, National Aeronautical Police Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 9,287,499 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 7,530,476 (2000 est.)
Military manpower - reaching military age
annually:
rrta/es; 341 ,544 (2000 est.)
Military expenditures - dollar figure: $4.3 billion
(FY99)
Military expenditures - percent of GDP: 1 .3%
(FY99)
I f r a n s national I s s u e^
Disputes - international: claims UK-administered
Falkland Islands (Islas Malvinas); claims
UK-administered South Georgia and the South
Sandwich Islands; territorial claim in Antarctica
Illicit drugs: increasing use as a transshipment
country for cocaine headed for Europe and the US;
increasing use as a money-laundering center;
domestic consumption of drugs has skyrocketed
i ii''t Fo d u c t i o h
Background: An Orthodox Christian country,
Armenia was incorporated into Russia in 1 828 and the
USSR in 1 920. Armenian leaders remain preoccupied
by the long conflict with Azerbaijan over
Nagorno-Karabakh, a primarily Armenian-populated
exclave, assigned to Soviet Azerbaijan in the 1920s
by Moscow. Armenia and Azerbaijan began fighting
over the exclave in 1988; the struggle escalated after
both countries attained independence from the Soviet
Union in 1 991 . By May 1 994, when a cease-fire took
hold, Armenian forces held not only
Nagorno-Karabakh but also a significant portion of
Azerbaijan proper. The economies of both sides have
been hurt by their inability to make substantial
progress toward a peaceful resolution.
r '' "Geo''g''rlap''hy
Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent
States
Area;
total: 29,800 sq km
land: 28,400 sq km
wafer; 1,400 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries;
total: 1 ,254 km
border courrfrv''es; Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia 164
km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold
winters
Terrain: Armenian Highland with mountains; little
forest land; fast flowing rivers; good soil in Aras River
valley
23
Armsnia (continued)
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of goid, copper,
molybdenum, zinc, aiumina
Land use:
arable land: 17%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 15%
ofter;41%(1993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes;
droughts
Environment - current issues: soil pollution from
toxic chemicals such as DDT; energy blockade, the
result of conflict with Azerbaijan, has led to
deforestation when citizens scavenged for firewood;
pollution of Hrazdan (Razdan) and Aras Rivers; the
draining of Sevana Lich (Lake Sevan), a result of its
use as a source for hydropower, threatens drinking
water supplies; restart of Metsamor nuclear power
plant without adequate (IAEA-recommended) safety
and backup systems
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, NuclearTestBan,
Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: landlocked
f” ~ p^o pTe
Population: 3,344,336 (July 2000 est.)
Age structure:
0-14 years: 24% (male 415,297; female 400,590)
15-64 years: 66% (male 1 ,084,588; female
1,131,387)
65 years and over: 1 0% (male 1 29,890; female
182,584) (2000 est.)
Population growth rate: -0.28% (2000 est.)
Birth rate: 1 0.97 births/1 ,000 population (2000 est.)
Death rate: 9.53 deaths/1 ,000 population
(2000 est.)
Net migration rate: -4.23 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 41 .48 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 66.4 years
mate: 51. 98 years
female: 71 .04 years (2000 est.)
Total fertility rate: 1 .47 children born/woman
(2000 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian
2%, other (mostly Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had
emigrated from Armenia
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)
I Government
Country name:
conventional long form: Republic of Armenia
conventional short form: Armenia
local long form: Hayastani Hanrapetut''yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic; Armenian
Republic
Data code: AM
Government type: republic
Capital: Yerevan
Administrative divisions: 10 provinces (marzer,
singular - marz) and 1 city* (k''aghak''ner, singular -
k''aghak''); Aragatsotn, Ararat, Armavir, Geghark''unik'',
Kotayk'', Lorri, Shirak, Syunik''.Tavush, Vayots'' Dzor,
Yerevan*
Independence: 28 May 1918-2 December 1920
(First Armenian Republic); 23 September 1991 (from
Soviet Union)
National holiday: Referendum Day, 21 September
Constitution: adopted by nationwide referendum 5
July 1995
Legal system: based on civil law system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Robert KOCHARIAN (since
30 March 1998)
head of government: Prime Minister Aram
SARKISYAN (since 3 November 1999)
cabinet: Council of Ministers appointed by the prime
minister
elections: president elected by popular vote for a
five-year term; special election last held 30 March
1 998 (next to be held NA March 2003); prime minister
appointed by the president
election results: Robert KOCHARIAN elected
president; percent of vote - Robert KOCHARIAN 59%,
Karen DEMIRCHYAN 41%
Legislative branch: unicameral National Assembly
(Parliament) or Azgayin Zhoghov (131 seats;
members serve four-year terms)
elections: last held 30 May 1 999 (next to be held in the
spring of 2003)
election results: percent of vote by party - NA; seats
by party - unity bloc 61 (Republican Party 41 , People''s
Party of Armenia 20), Stability Group (independent
Armenian deputies who have formed a bloc) 21 , ACP
10, independents 10, ARF (Dashnak) 8, Law and
Unity Party 7, NDU 6, Law-Governed Party 6, unfilled
2; note - seats by party change frequently
Judicial branch: Supreme Court; Constitutional
Court
Political parties and leaders: Armenian
Communist Party or ACP [Vladimir DARBINIAN];
Armenian National Movement or ANM [Vano
SIRADEGIAN, chairman]; Armenian Revolutionary
Federation ("Dashnak" Party) or ARF [Vahan
HAVHANNISIANj; Christian Democratic Union or
CDU [Azat ARSHAKYN, chairman]; Democratic
Liberal Party [RamkavarAZATAKAN, chairman]; Free
Armenian''s Mission [Ruben MNATSANIAN,
chairman]; Law and Unity Party [Artashes
GEGAMIAN, chairman]; Law-Governed Party [Artur
BAGDASARIAN, chairman]; Mission Party [Artush
PAPOIAN, chairman]; National Democratic Union or
NDU [Vazgen MANUKIAN]; National State Party
[Samvel SHAGINIAN]; People''s Party of Armenia
[Stepan DEMIRCHYAN]; Republican Party [Andranik
MARKARYAN]; Shamiram Women''s Movement or
SWM [Maria NERSISSIAN]; Social Democratic
(Hnchakian) Party [Yeghia NACHARIAN]; Stability
Group [Vartan AYV/tZIAN, chairman]; Union of
National Self-Determination or NSDU [Paruir
HAIRIKIAN, chairman]
International organization participation: BSEC,
CCC, CE (guest), CIS, EAPC, EBRD, ECE, ESCAP,
FAO, IAEA, IBRD, ICAO, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, Intelsat, Interpol, IOC, lOM, ISO,
ITU, NAM (observer), OPCW, OSCE, PFP, UN,
UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WlPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Arman KIRAKOSIAN
chancery: 2225 R Street NW, Washington, DC 20008
telephone: [1] (202) 319-1976
FAX; [1] (202) 319-2982
consulate(s) general: Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Michael LEMMON
embassy: 18 General Bagramian Avenue, Yerevan
mailing address: American Embassy Yerevan,
Department of State, Washington, DC 20521-7020
telephone: [374] (2) 151-551
FAX; [374] (2) 151-550
Flag description: three equal horizontal bands of
red (top), blue, and orange
I Economy
Economy - overview: Under the old Soviet central
planning system, Armenia had developed a modern
industrial sector, supplying machine tools, textiles,
and other manufactured goods to sister republics in
exchange for raw materials and energy. Since the
implosion of the USSR in December 1991, Armenia
has switched to small-scale agriculture away from the
large agroindustrial complexes of the Soviet era. The
agricultural sector has long-term needs for more
investment and updated technology. The privatization
of industry has been at a slower pace, but has been
24
Armenia (continued)
given renewed emphasis by the current
administration. Armenia is a food importer, and its
mineral deposits (gold, bauxite) are small. The
ongoing conflict with Azerbaijan over the ethnic
Armenian-dominated region of Nagorno-Karabakh
and the breakup of the centrally directed economic
system of the former Soviet Union contributed to a
severe economic decline in the early 1990s. By 1994,
however, the Armenian Government had launched an
ambitious IMF-sponsored economic program that has
resulted in positive growth rates in 1995-99. Armenia
also managed to slash Inflation and to privatize most
small- and medium-sized enterprises. The chronic
energy shortages Armenia suffered in recent years
have been largely offset by the energy supplied by
one of its nuclear power plants at Metsamor.
Continued Russian financial difficulties have hurt the
trade sector especially, but have been offset by
international aid, domestic restructuring, and foreign
direct investment.
GDP: purchasing power parity - $9.9 billion
(1999est.)
GDP - real growth rate: 5% (1999 est.)
GDP ■ per capita: purchasing power parity • $2,900
(1999 est.)
GDP - composition by sector:
agriculture: 40%
industry: 25%
services: 35% (1999 est.)
Popuiation below poverty tine: 45% (1999 est.)
Househotd income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (1999)
Labor force: 1 .5 million (1 999)
Labor force - by occupation: agriculture 55%,
services 25%, manufacturing, mining, and
construction 20% (1999 est.)
Unemployment rate: 20% (1998 est.)
note: official rate is 9.3% for 1998
Budget:
revenues: $360 million
expenditures: $566 million, including capital
expenditures of $NA (1999 est.)
Industries: metal-cutting machine tools,
forging-pressing machines, electric motors, tires,
knitted wear, hosiery, shoes, silk fabric, washing
machines, chemicals, trucks, watches, instruments,
microelectronics
Industrial production growth rate: -2% (1998)
Electricity - production: 5.764 billion kWh (1998)
Electricity - production by source:
fossil fuel: A8.92%
hydro; 26.44%
nuclear: 24.64%
other; 0% (1998)
Electricity - consumption: 5.361 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: fruit (especially grapes),
vegetables; livestock
Exports: $240 million (1999 est.)
Exports - commodities: diamonds, scrap metal,
machinery and equipment, cognac, copper ore
Exports - partners: Belgium, Russia, Iran,
Turkmenistan, US, Georgia (1998)
Imports: $782 million (1999 est.)
Imports - commodities: natural gas, petroleum,
tobacco products, foodstuffs, diamonds
Imports - partners: Russia, US, UK, Iran, Turkey,
Belgium (1998)
Debt - external: $862.7 million (1999)
Economic aid - recipient: $245.5 million (1995)
Currency: 1 dram = 100 luma
Exchange rates: dram per US$1 - 527.02 (January
2000), 535.06 (1999), 504.92 (1998), 490.85 (1997),
414.04 (1996), 405.91 (1995)
Fiscal year: calendar year
1^ cTitTm u n i c a t i o n s
Telephones - main lines in use: 583,000 (1995)
Telephones - mobile cellular: NA
Telephone system: system Inadequate; now 90%
privately owned and undergoing modernization and
expansion
domestic: the majority of subscribers and the most
modern equipment are in Yerevan (this includes
paging and mobile cellular service)
international: Yerevan is connected to the
Trans-Asia-Europe fiber-optic cable through Iran;
additional international service is available by
microwave radio relay and landline connections to the
other countries of the Commonwealth of Independent
States and through the Moscow international switch
and by satellite to the rest of the world; satellite earth
stations - 1 Intelsat
Radio broadcast stations: AM 9, FM 6, shortwave
1 (1998)
Radios: 850,000(1997)
Television broadcast stations: 4 (1998)
Televisions: 825,000(1997)
Internet Service Providers (ISPs): 1 (1999)
I Transportation ™
Railways:
total: 825 km in common carrier service; does not
include industrial lines
broad gauge: 825 km 1.520-m gauge (825 km
electrified) (1995)
Highways:
total: 15,998 km
paved; 15,998 km (including 7,567 km of
expressways)
unpaved: 0 km (1 998 est.)
Waterways: NAkm
Pipelines: natural gas 900 km (1991)
Ports and harbors: none
Airports: 11 (1996 est.)
Airports - with paved runways:
total: 5
over 3,047 m: 2
1,524 to 2,437 m:1
914 to 1,523 m: 2 {1998 esl.)
Airports - with unpaved runways:
total: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m:1 (1996 est.)
I Military
Military branches: Army, Air Force and Air Defense
Aviation, Air Defense Force, Security Forces (internal
and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 896,646 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 708,940 (2000 est.)
Military manpower - reaching military age
annually:
males: 33,391 (2000 est.)
Military expenditures - dollar figure: $75 million
(FY99)
Military expenditures - percent of GDP: 4%
(FY99)
I T r ah s hi t ronaTl Tss u e s
Disputes - international: Armenia supports ethnic
Armenians in the Nagorno-Karabakh region of
Azerbaijan in the longstanding, separatist conflict
against the Azerbaijani Government; traditional
demands regarding former Armenian lands in Turkey
have subsided
Illicit drugs: Illicit cultivator of cannabis mostly for
domestic consumption; increasingly used as a
transshipment point for illicit drugs - mostly opium and
hashish - to Western Europe and the US via Iran,
Central Asia, and Russia
25
Background: Formerly one of the Netherlands
Antilles, Aruba became an autonomous part of the
Netherlands in 1986.
Economy - overview: no economic activity
I " f r a n s p 0 ft a t i o n
Ports and harbors: none; offshore anchorage only
I Military
Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force
t transnational Issues
Disputes - international; none
|Atlantic Ocean
f Intfbduclion
Background; A spring 2000 decision by the
International Hydrographic Organization delimited a
fifth world ocean from the southern portions of the
Atlantic Ocean, Indian Ocean, and Pacific Ocean. The
new ocean extends from the coast of Antarctica north
to 60 degrees south latitude which coincides with the
Antarctic T reaty Limit. The Atlantic Ocean remains the
second-largest of the world''s five oceans (after the
Pacific Ocean, but larger than the Indian Ocean,
Southern Ocean, and Arctic Ocean).
Elevation extremes:
lowest point: Milwaukee Deep in the Puerto Rico
Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine
mammals (seals and whales), sand and gravel
aggregates, placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in Davis Strait,
Denmark Strait, and the northwestern Atlantic Ocean
from February to August and have been spotted as far
south as Bermuda and the Madeira Islands; ships
subject to superstructure icing in extreme northern
Atlantic from October to May; persistent fog can be a
maritime hazard from May to September; hurricanes
(May to December)
Environment - current issues: endangered marine
species include the manatee, seals, sea lions, turtles,
and whales; drift net fishing is hastening the decline of
fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern
Brazil, and eastern Argentina; oil pollution in
Caribbean Sea, Gulf of Mexico, Lake Maracaibo,
Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North
Sea, and Mediterranean Sea
Geography - note: major chokepoints include the
Dardanelles, Strait of Gibraltar, access to the Panama
and Suez Canals; strategic straits include the Strait of
Dover, Straits of Florida, Mona Passage, The Sound
(Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic
Ocean and South Atlantic Ocean
Economy - overview: The Atlantic Ocean provides
some of the world''s most heavily trafficked sea routes,
between and within the Eastern and Western
Hemispheres. Other economic activity includes the
exploitation of natural resources, e.g., fishing, the
dredging of aragonite sands (The Bahamas), and
production of crude oil and natural gas (Caribbean
Sea, Gulf of Mexico, and North Sea).','69424959e284595ad78c07935ae8a5a75aced0263e0054e73328fa84e87f4af7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38cbcdffd51438b01b68b064710ea80ce82dae74ca3a335952a4bb11a4671f3f',2000,'AU','Australia','economy',52,'Economy - overview: Australia has a prosperous
Western-style capitalist economy, with a per capita
GDP at the level of the four dominant West European
economies. Rich in natural resources, Australia is a
major exporter of agricultural products, minerals,
metals, and fossil fuels. Commodities account for 57%
of the value of total exports, so that a downturn in
world commodity prices can have a big impact on the
economy. The government is pushing for increased
exports of manufactured goods, but competition in
international markets continues to be severe. While
Australia has suffered from the low growth and high
unemployment characterizing the OECD countries in
the early 1990s and during the recent financial
problems in East Asia, the economy has expanded at
a solid 4% annual growth pace in the last five years.
Canberra''s emphasis on reforms is a key factor
behind the economy''s resilience to the regional crisis
and its stronger than expected growth rate. Growth in
2000 will depend on key international commodity
prices, the extent of recovery in nearby Asian
economies, and the strength of US and European
markets.
GDP: purchasing power parity - $41 6.2 billion
(1999 est.)
GDP ■ real growth rate: 4.3% (1999 est.)
GDP - per capita: purchasing power parity - $22,200
(1999 est.)
GDP ■ composition by sector;
agriculture: 3%
industry: 26%
services: 71 % (1 998 est.)
Population below poverty line; NA%
Househoid income or consumption by percentage
share;
lowest 10%: 2.5%
highest 10%; 24.8% (1989)
Infiation rate (consumer prices): 1 .8% (1 999 est.)
Labor force: 8.9 million (December 1999)
Labor force - by occupation: services 73%,
industry 22%, agriculture 5% (1997 est.)
Unemployment rate: 7.5% (1 999)
Budget:
revenues: $90.73 billion
expenditures: $89.04 billion, including capital
expenditures of $NA (FY98/99 est.)
Industries: mining, industrial and transportation
equipment, food processing, chemicals, steel
Industrial production growth rate; 1 .5%
(1999 est.)
Electricity - production: 1 86.387 billion kWh (1 998)
Electricity - production by source;
fossil fuel: 89.85%
hydro: 8.35%
nuclear: 0%
ofher1.8%(1998)
30
Australia (continued)
Electricity - consumption: 173.34 billion kWh
(1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: wheat, barley, sugarcane,
fruits; cattle, sheep, poultry
Exports: $58 billion (f.o.b., 1999 est.)
Exports - commodities: coal, gold, meat, wool,
alumina, iron ore, wheat, machinery and transport
equipment
Exports - partners: Japan 20%, EU 14%, ASEAN
11%, US 10%, South Korea, NZ, Taiwan, Hong Kong,
China (1998)
Imports: $67 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and transport
equipment, computers and office machines,
telecommunication equipment and parts; crude oil
and petroleum products
Imports - partners: EU 24%, US 22%, Japan 14%,
ASEAN 12% (1998)
Debt - external: $222 billion (1999)
Economic aid - donor: ODA, $1 .43 billion
(FY97/98)
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1.52068 (January 2000), 1.5497 (1999), 1.5888
(1998), 1.3439 (1997), 1.2773 (1996), 1.3486 (1995)
Fiscal year'' 1 July - 30 June
I Communications
Telephones - main lines in use: 92 million (1995)
Telephones - mobile cellular: 5.29 million (1998)
Telephone system: excellent domestic and
international service
domestic: domestic satellite system
international: submarine cables to New Zealand,
Papua New Guinea, and Indonesia; satellite earth
stations - 10 Intelsat (4 Indian Ocean and 6 Pacific
Ocean), 2 Inmarsat (Indian and Pacific Ocean
regions)
Radio broadcast stations: AM 262, FM 345,
shortwave 1 (1998)
Radios: 25.5 million (1997)
Television broadcast stations: 104 (1997)
Televisions: 10.15 million (1997)
Internet Service Providers (ISPs): 709 (1999)
I transportation
Railways:
total: 33,8^9 km (2,540 km electrified)
broad gauge: 3,719 km 1 .600-m gauge
standard gauge: 15,422 km 1.435-m gauge
narrow gauge: 14,506 km 1.067-m gauge
dual gauge: 172 km NA gauges (1999)
Highways:
fofa/;913,000 km
paved: 353, 33t km (including 13,630 km of
expressways)
unpaved: 559,889 km (1996 est.)
Waterways: 8,368 km; mainly by small, shallow-draft
craft
Pipelines: crude oil 2,500 km; petroleum products
500 km; natural gas 5,600 km
Ports and harbors: Adelaide, Brisbane, Cairns,
Darwin, Devonport (Tasmania), Fremantle, Geelong,
Hobart (Tasmania), Launceston (Tasmania), Mackay,
Melbourne, Sydney, Townsville
Merchant marine:
total: 57 ships (1 ,000 GRT or over) totaling 1 ,657,1 94
GRT/2,206,574 DWT
ships by type: bulk 28, cargo 4, chemical tanker 4,
container 1, liquified gas 4, passenger 2, petroleum
tanker 8, roll-on/roll-off 6 (1 999 est.)
Airports: 408 (1999 est.)
Airports - with paved runways:
total: 265
over 3,047 m-.tt
2,438 to 3,047 m:n
1,524 to 2,437 m:t-i5
914 to 1,523 m: 120
under 914 m: 8 (1 999 est.)
Airports - with unpaved runways:
total: 143
1,524 to 2,437 m: 18
914 to 1,523 m: 113
under 914 m: 1 2 (1 999 est.)
I Military
Military branches: Australian Army, Royal
Australian Navy, Royal Australian Air Force
Military manpower - military age: 1 7 years of age
Military manpower - availability:
males age 15-49: 4,963,948 (2000 est.)
Military manpower - fit for military service:
males age f 5-49; 4,282,821 (2000 est.)
Military manpower • reaching military age
annually:
males: 135,434 (2000 est.)
Military expenditures - dollar figure: $6.9 billion
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)
p t r a n s n a f ion a i issues
Disputes - international: territorial claim in
Antarctica (Australian Antarctic Territory)
Illicit drugs: Tasmania is one of the world''s major
suppliers of licit opiate products; government
maintains strict controls over areas of opium poppy
cultivation and output of poppy straw concentrate
r In trod u c t i 0 h
ju. . . . .
Background: Once the center of power for the large
Austro-Hungarian Empire, Austria was reduced to a
small republic after its defeat in World War I. Following
annexation by Nazi Germany in 1 938 and subsequent
occupation by the victorious Allies, Austria''s 1955
State Treaty declared the country "permanently
neutral" as a condition of Soviet military withdrawal.
Neutrality, once ingrained as part of the Austrian
cultural identity, has been called into question since
the Soviet collapse and Austria''s increasingly
prominent role in European affairs. A prosperous
country, Austria joined the European Union in 1995
and the euro monetary system in 1999.
I" . " G e 0 g Va p h y
Location: Central Europe, north of Italy and Slovenia
Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area:
total: 83,858 sq km
land: 82,738 sq km
wafer; 1,120 sq km
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2,562 km
border countries: Czech Republic 362 km, Germany
784 km, Hungary 366 km, Italy 430 km, Liechtenstein
35 km, Slovakia 91 km, Slovenia 330 km, Switzerland
164 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; continental, cloudy; cold winters
with frequent rain in lowlands and snow in mountains;
cool summers with occasional showers
Terrain: in the west and south mostly mountains
(Alps); along the eastern and northern margins mostly
flat or gently sloping
31
Austria (continued)
Elevation extremes:
lowest point: Neusiedler See 1 1 5 m
highest point: Qmssg\\oc\\^ner 3,798 m
Natural resources: iron ore, oil, timber, magnesite,
lead, coal, lignite, copper, hydropower
Land use:
arable land: 17%
permanent crops: t%
permanent pastures: 23%
forests and woodland: 39%
other; 20% (1996 est.)
irrigated land: 40 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: some forest
degradation caused by air and soil pollution; soil
pollution results from the use of agricultural
chemicals; air pollution results from emissions by
coal- and oil-fired power stations and industrial plants
and from trucks transiting Austria between northern
and southern Europe
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked; strategic location at
the crossroads of central Europe with many easily
traversable Alpine passes and valleys; major river is
the Danube; population is concentrated on eastern
lowlands because of steep slopes, poor soils, and low
temperatures elsewhere
I People
Population: 8,131,111 (July 2000 est.)
Age structure:
0-14 years: 17% (male 697,283; female 663,459)
15-64 years: 68% (male 2,787,555; female
2,731,446)
65 years and over: 1 5% (male 474,067; female
777,301) (2000 est.)
Population growth rate: 0.25% (2000 est.)
Birth rate: 9.9 births/1 ,000 population (2000 est.)
Death rate: 9.91 deaths/1 ,000 population
(2000 est.)
Net migration rate: 2.46 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 4.5 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.68 years
male: 74.52 years
female: 80.99 years (2000 est.)
Total fertility rate: 1 .39 children born/woman
(2000 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: German 98%, Croatian, Slovene,
other (includes Hungarians, Czechs, Slovaks, Roma)
Religions: Roman Catholic 78%, Protestant 5%,
Muslim and other 17%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: NA%
female: NA%
I Government
Country name:
conventional long form: Republic of Austria
conventional short form: Austria
local long form: Republik Oesterreich
local short form: Oesterreich
Data code: AU
Government type: federal republic
Capital: Vienna
Administrative divisions: 9 states (bundeslaender,
singular - bundesland); Burgenland, Kaernten,
Niederoesterreich, Oberoesterreich, Salzburg,
Steiermark, Tirol, Vorarlberg, Wien
Independence: 1156 (from Bavaria)
National holiday: National Day, 26 October (1955)
Constitution: 1920; revised 1929 (reinstated 1 May
1945)
Legal system: civil law system with Roman iaw
origin; judicial review of legislative acts by the
Constitutional Court; separate administrative and civil/
penal supreme courts; has not accepted compulsory
ICJ jurisdiction
Suffrage: 1 9 years of age; universal; compulsory for
presidential elections
Executive branch:
chief of state: President Thomas KLESTIL (since 8
July 1992)
head of government: Chancellor Wolfgang
SCHUESSEL (OeVP)(since 4 February 2000); Vice
Chancellor Susanne RIESS-PASSER (FPOe) (since
4 February 2000)
cabinet: Council of Ministers chosen by the president
on the advice of the chancellor
elections: president elected by direct popular vote for
a six-year term; presidential election last held 1 9 April
1 998 (next to be held in the spring of 2004); chancellor
traditionally chosen by the president from the plurality
party in the National Council; in the case of the current
coalition, the chancellor was chosen from another
party after the plurality party faiied to form a
government; vice chancellor chosen by the president
on the advice of the chancellor
election results: Thomas KLESTIL reelected
president; percent of vote - Thomas KLESTIL 63%,
Gertraud KNOLL 14%, Heide SCHMIDT 11%,
Richard LUGNER 10%, Kari NOWAK 2%
note: government coalition - FPOe and OeVP
Legislative branch: bicameral Federal Assembly or
Bundesversammiung consists of Federal Council or
Bundesrat (64 members; members represent each of
the states on the basis of population, but with each
state having at least three representatives; members
serve a four- or six-year term) and the National
Council or Nationalrat (183 seats; members elected
by direct popular vote to serve four-year terms)
elections: National Council - last held 3 October 1 999
(next to be held in the fall of 2003)
election results: National Council - percent of vote by
party - SPOe 33.2%, OeVP 26.9%, FPOe 26.9%,
Greens 7.4%; seats by party - SPOe 65, OeVP 52,
FPOe 52, Greens 14
Judicial branch: Supreme Judicial Court or
Oberster Gerichtshof; Administrative Court or
Verwaltungsgerichtshof; Constitutional Court or
Verfassungsgerichtshof
Political parties and leaders: Austrian People''s
Party or OeVP [Wolfgang SCHUESSEL, chairman];
Communist Party or KPOe [Walter BAIER, chairman];
Freedom Party of Austria or FPOe [Susanne
RIESS-PASSER]; Liberal Forum or LF [Heide
SCHMIDT]; Social Democratic Party of Austria or
SPOe [Viktor KLIMA, chairman]; The Greens or GA
[Alexander VAN DER BELLEN, party spokesman]
Political pressure groups and leaders: Austrian
T rade Union Federation (primarily Socialist) or OeGB;
Federal Economic Chamber; OeVP-oriented League
of Austrian Industrialists or VOel; Roman Catholic
Church, including its chief lay organization. Catholic
Action; three composite leagues of the Austrian
People''s Party or OeVP representing business, labor,
and farmers
International organization participation: AfDB,
AsDB, Australia Group, BIS, BSEC (observer), CCC,
CE, CEI, CERN, EAPC, EBRD, ECE, EIB, EMU, ESA,
EU, FAO, G- 9, lADB, IAEA, IBRD, ICAO, ICC,
ICFTU, ICRM, IDA, lEA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Intelsat, Interpol, IOC, lOM, ISO, ITU,
MINURSO, NAM (guest), NEA, NSG, OAS
(observer), OECD, OPCW, OSCE, PCA, PFP, UN,
UNCTAD, UNDOF, UNESCO, UNFICYP, UNHCR,
UNIDO, UNIKOM, UNITAR, UNMIBH, UNMIK,
UNMOT, UNOMIG, UNTAET, UNTSO, UPU, WCL,
WEU (observer), WFTU, WHO, WlPO, WMO, WToO,
WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Peter MOSER
chancery: 3524 International Court NW, Washington,
DC 20008-3035
telephone: [1] {202) 895-6700
FAX: [1] (202) 895-6750
consulate(s) general: Chicago, Los Angeles, and New
York
32
Austria (continued)
Diplomatic representation from the US:
chief of mission: Ambassador Kathryn Walt HALL
embassy: Boltzmanngasse 1 6, A-1 091 , Vienna
mailing address: use embassy street address
telephone: [43] (1)31 3-39
FAX;[43] (1)310-0682
Flag description: three equal horizontal bands of
red (top), white, and red
f Economy
Economy - overview: Austria with its
well-developed market economy and high standard of
living is closely tied to other EU economies, especially
Germany''s. Membership in the EU has drawn an
influx of foreign investors attracted by Austria''s access
to the single European market. Through privatization
efforts, the 1996-98 budget consolidation programs,
and austerity measures, Austria has brought its total
public sector deficit down to 2.1 % of GDP in 1 999 and
public debt - at 63.1% of GDP in 1998 - more or less
in line with the 60% of GDP required by the EMU''s
Maastricht criteria. Cuts mainly have affected the civil
service and Austria''s generous social benefit system,
the two major causes of the government''s deficit. To
meet increased competition from both EU and Central
European countries, Austria will need to emphasize
knowledge-based sectors of the economy and
deregulate the service sector. Growth, which slowed
to 2,0% in 1 999, probably will rebound to 2.8% in both
2000 and 2001.
GDP: purchasing power parity - $1 90,6 billion
(1999 est.)
GDP - real growth rate: 2% (1 999 est.)
GDP - per capita: purchasing power parity - $23,400
(1999 est.)
GDP - composition by sector:
agriculture: 1 .3%
industry: 32A%
services: 66.3% (1 998 est.)
Population below poverty line: NA%
Inflation rate (consumer prices): 0.5% (1999)
Labor force: 3.7 million (1999)
Labor force - by occupation: services 68%,
industry and crafts 29%, agriculture and forestry 3%
(1999 est.)
Unemployment rate: 4.4% (1999)
Budget:
revenues: $54 billion
expenditures: $59.5 billion, including capital
expenditures of $NA (1 999 est.)
Industries: construction, machinery, vehicles and
parts, food, chemicals, lumber and wood processing,
paper and paperboard, communications equipment,
tourism (1997)
Industrial production growth rate: 2.3% (1999)
Electricity - production: 56.066 billion kWh (1998)
Electricity - production by source:
fossil fuel: .46%
hydro: 65.92%
nuclear: 0%
other: 2.62% (1998)
Electricity - consumption: 51.891 billion kWh
(1998)
Electricity - exports: 10.5 billion kWh (1998)
Electricity - imports: 1 0.25 billion kWh (1998)
Agriculture - products: grains, potatoes, sugar
beets, wine, fruit; dairy products, cattle, pigs, poultry;
lumber
Exports: $62.9 billion (1999 est.)
Exports - commodities: machinery and equipment,
paper and paperboard, metal goods, chemicals, iron
and steel; textiles, foodstuffs (1998)
Exports - partners: EU 65% (Germany 36%, Italy
9%, France 5%), Switzerland 5%, Hungary 5%, US
4.5% (1999 est.)
Imports: $69.9 billion (1999 est.)
Imports - commodities: machinery and equipment,
chemicals, metal goods, oil and oil products;
foodstuffs (1998)
Imports - partners: EU 70% (Germany 42%, Italy
8%, France 5%), US 5%, Hungary 3%, Switzerland
3% (1999 est.)
Debt - external: $31 .7 billion (1998)
Economic aid - donor: ODA, $452 million (1998)
Currency: 1 Austrian schilling (AS) = 100 groschen
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); Austrian schiilings (AS) per
US$1 - 11.86 (January 1999), 12.91 (1999), 12.379
(1998), 12.204 (1997), 10.587 (1996), 10.081 (1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 13.7603 Austrian shillings per euro; the euro will
replace the local currency in consenting countries for
all transactions in 2002
Fiscal year: calendar year
1^ C 0 m m iTivi c Ft i 0 n s
Telephones - main lines in use: 3.726 million (plus
83,100 ISDN or Integrated Services Digital Network
connections) (1997)
Telephones - mobile cellular: 2.31 million (1998)
Telephone system:
domestic: highly developed and efficient
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 1ndian Ocean) and 2 Eutelsat
Radio broadcast stations: AM 1, FM 61 (plus
several hundred repeaters), shortwave 1 (1998)
Radios: 6.08 million (1997)
Television broadcast stations: 51 (plus 920
repeaters) (1999)
Televisions: 4.25 million (1997)
Internet Service Providers (ISPs): 35 (1999)
|~ Tran s^FTr tTtTFF" ^
Railways:
total: 6,123 km (3,523 km electrified)
standard gauge: 5,639 km 1 .435-m gauge (3,429 km
electrified)
narrow gauge: 464 km (13 km 0.600-m gauge, 468
km 0.760-m gauge - 94 km electrified, and 3 km
0.600-m gauge) (1999)
Highways: 200,000 km
paved: 200,000 km (including 1 ,613 km of
expressways)
i/npavecf;0km(1999)
Waterways: 358 km (1999)
Pipelines: crude oil 777 km; natural gas 840 km
(1999)
Ports and harbors: Linz, Vienna, Enns, Krems
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 65,284
GRT/91,951 DWT
ships by type: bulk 1 , cargo 15, combination bulk 2,
container 2 (1999 est.)
Airports: 55 (1999 est.)
Airports - with paved runways:
total: 22
over 3,047 m:t
2,438 to 3,047 m: 5
1,524 to 2,437 m:t
914 to 1,523 m: 3
under 914 m: 12 (1999 est.)
Airports - with unpaved runways:
total: 33
914 to 1,523 m: 4
under 914 m: 29 (1 999 est.)
Heliports: 1 (1 999 est.)
Military branches: Army (includes Flying Division)
Military manpower ■ military age: 1 9 years of age
Military manpower ■ availability:
males age 15-49: 2,088,993 (2000 est.)
Military manpower ■ fit for military service:
males age 15-49: 1 ,733,681 (2000 est.)
Military manpower - reaching military age
annually:
males: 51 ,335 (2000 est.)
Military expenditures ■ dollar figure: $1 .7 billion
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
I T r a n s n at ion a I I s s u e s
Disputes - international: none
Illicit drugs: transshipment point for Southwest
Asian heroin and South American cocaine destined
for Western Europe
33
Economy ■ overview: Colombia is poised for
moderate growth in the next several years, marking an
end to the severe 1999 recession when GDP fell by
about 5%. President PASTRANA''S well-respected
economic team is taking steps to keep the recovery on
track, such as lowering interest rates and shoring up
the financial system. In its loan agreement with the
IMF, the administration has pledged to take additional
steps to restore growth, reduce inflation, and improve
the public sector''s fiscal health. Many challenges to
sustainable growth remain, however. Unemployment
reached a record 20% in 1999 and may remain high,
contributing to the extreme inequality in income
distribution. Colombia''s leading exports, oil and
coffee, face an uncertain future: new exploration is
needed to offset a pending decline in oil production,
and the coffee harvest has dropped off because of
aging plantations and natural disasters. The lack of
public security is a key concern for investors, making
progress in the government''s peace negotiations with
insurgent groups an important driver of economic
performance. Colombia is looking for international
financial assistance to boost economic recovery and
peace prospects.
GDP: purchasing power parity -$245.1 billion
(1999 est.)
GDP - real growth rate: -5% (1999 est.)
GDP - per capita: purchasing power parity - $6,200
(1999 est.)
GDP - composition by sector:
agriculture:
industry: 26%
sen/ices: 55% (1 999 est.)
Population below poverty line: 17.7% (1992 est.)
Household Income or consumption by percentage
share:
lowest 10%: 1%
highest 10%; 46.9% (1995)
Inflation rate (consumer prices): 9.2% (1999)
Labor force: 16.8 million (1997 est.)
Labor force - by occupation; services 46%,
agriculture 30%, industry 24% (1990)
Unemployment rate: 20% (1999 est.)
Budget:
revenues: $22 billion
expenditures: $24 billion including capital
expenditures of $NA (2000 est.)
Industries: textiles, food processing, oil, clothing
and footwear, beverages, chemicals, cement; gold,
coal, emeralds
Industrial production growth rate: -7% (1999 est.)
Electricity - production: 45.02 billion kWh (1998)
Electricity - production by source:
fossil fuel 30.11%
hydro: 69.25%
nuclear: 0%
o/her; 0.64% (1998)
Electricity - consumption: 41 .963 billion kWh
(1998)
Electricity ■ exports: 0 kWh (1 998)
Electricity - imports: 94 million kWh (1 998)
Agriculture - products: coffee, cut flowers,
bananas, rice, tobacco, corn, sugarcane, cocoa
beans, oilseed, vegetables; forest products; shrimp
Exports: $11.5 billion (f.o.b., 1999 est.)
Exports - commodities: petroleum, coffee, coal,
gold, bananas, cut flowers
Exports - partners: US 39%, EU 24%, Andean
Community 15%, Japan 2% (1998)
Imports: $10 billion (f.o.b., 1999 est.)
Imports - commodities: industrial equipment,
transportation equipment, consumer goods,
chemicals, paper products, fuels, electricity
Imports - partners: US 35%, EU 20%, Andean
Community 15%, Japan 7% (1998)
Debt - external: $35 billion (1 998 est.)
Economic aid - recipient: $40.7 million (1995)
Currency: 1 Colombian peso (Col$) = 1 00 centavos
Exchange rates: Colombian pesos (Col$) per US$1
- 1 ,925.63 (January 2000), 1 ,756.23 (1 999), 1 ,426.04
(1998), 1,140.96 (1997), 1,036.69 (1996), 912.83
(1995)
Fiscal year: calendar year
Economy - overview: Hungary continues to
demonstrate strong economic growth and to work
toward accession to the European Union. Over 85% of
the economy has been privatized. Foreign ownership
of and investment in Hungarian firms has been
widespread with cumulative foreign direct investment
$21 billion by 1999. Hungarian sovereign debt is now
rated investment grade. GDP growth of 4% in 1999
will likely be matched or even exceeded in 2000.
Inflation, while diminished, is still high at 10%','b14c3cd64f5b6b306ab163987091c3ec77e716fbda6565f955e303cc923c9aa9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0af61d8d6f13d66504bf9525e5e8005deafdc6465ff2c179299b11f60f606acc',2000,'AU','Australia','economy',53,'.
Economic reform measures include regional
development, encouragement of small- and
medium-size enterprises, and support of housing.
GDP: purchasing power parity - $79.4 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $7,800
(1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 30%
services: 65% (1999 est.)
Population below poverty line: 25.3% (1993 est.)
Household income or consumption by percentage
share:
lowest 10%; 4.1%
highest 10%; 24% (1993)
Inflation rate (consumer prices): 10% (1999 est.)
Labor force: 4.2 million (1997)
Labor force - by occupation: services 65%,
industry 27%, agriculture 8% (1996)
Unemployment rate: 10% (1999 est.)
Budget:
revenues; $13.5 billion
expenditures: billion, including capital
expenditures of $NA (1999 est.)
Industries: mining, metallurgy, construction
materials, processed foods, textiles, chemicals
(especially pharmaceuticals), motor vehicles
Industrial production growth rate: 6% (1999 est.)
Electricity - production: 35.104 billion kWh (1998)
Electricity - production by source:
fossil fuel:
hydro: 1%
nuclear: 38%
other: 0% (1999 est.)
Electricity - consumption: 33.317 billion kWh
(1998)
Electricity - exports: 3.3 billion kWh (1998)
Electricity - imports: 3.97 billion kWh (1998)
Agriculture - products: wheat, corn, sunflower
seed, potatoes, sugar beets; pigs, cattle, poultry, dairy
products
Exports: $22.6 billion (f.o.b., 1999)
Exports - commodities: machinery and equipment
51 .9%, other manufactures 32.7%, agriculture and
food products 10.5%, raw materials 2.9%, fuels and
electricity 1 .9% (1998)
Exports - partners: Germany 37%, Austria 11%,
Italy 6%, Netherlands 5% (1998)
Imports: $25.1 billion (f.o.b., 1999)
Imports - commodities: machinery and equipment
46.5%, other manufactures 40.2%, fuels and
electricity 6.6%, agricultural and food products 3.7%,
raw materials 3.0% (1998)
Imports - partners: Germany 28%, Austria 10%,
Italy 8%, Russia 7% (1998)
Debt - external: $27 billion (1999)
Economic aid - recipient: $122.7 million (1995)
Currency: 1 forint (Ft) = 100 filler
Exchange rates: forints per US$1 - 251.150
(January 2000), 237.146 (1999), 214.402 (1998),
186.789(1997), 152.647(1996), 125.681 (1995)
Fiscal year: calendar year
Imports: $4.1 million (c.i.f., 1989)
Imports - commodities: food, live animals,
manufactured goods, machinery, fuels, lubricants,
chemicals, drugs
Imports - partners: NZ 59%, Fiji 20%, Japan 13%,
Samoa, Australia, US
Debt - external: $NA
Economic aid - recipient: $8.3 million (1995)
368
NiU6 (continued)
Currency: 1 New Zealand dollar (NZ$) = 100 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1 - 1 .9451 (January 2000), 1 .8889 (1999), 1 .8629
(1998), 1.5082 (1997), 1.4543 (1996), 1.5235 (1995)
Fiscal year: 1 April - 31 March
I C 0 u n i c a t i 0 n s
Telephones - main lines in use: 376 (1991)
Telephones - mobile cellular: 0 (1991)
Telephone system:
domestic: single-line telephone system connects all
villages on island
international: NA
Radio broadcast stations: AM 1, FM 1, shortwave
0(1998)
Radios: 1,000(1997)
Television broadcast stations: 1 (1997)
Televisions: NA
Internet Service Providers (ISPs): NA
P Transportation
Railways: 0 km
Highways:
total: 234 km
paved: 0 km
unpaved: 234 km
Ports and harbors: none; offshore anchorage only
Merchant marine: none (1999 est.)
Airports: 1 (1 999 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:-\\ (1999 est.)
I Military
Military branches: Police Force
Military - note: defense is the responsibility of New
Zealand
I fransnationaT Issues''
Disputes - international: none
Background: Two British attempts at establishing
the island as a penal colony (1788-1814 and 1825-55)
were ultimately abandoned In 1856, the island
was resettled by Pitcairn Islanders, descendants
of the Bounty mutineers and their Tahitian
companions.
I" Geo g r a p h y
Location: Oceania, island in the South Pacific
Ocean, east of Australia
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
Area - comparative: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 31 9 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 0%
other: 75% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (especially May to July)
Environment - current issues: NA
r People
Population: 1 ,892 (July 2000 est.)
Age structure:
0-14 years: tiA
15-64 years: NA
65 years and over; NA
Population growth rate: -0.68% (2000 est.)
Birth rate: NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesians
Religions: Anglican 39%, Roman Catholic 1 1 .7%,
Uniting Church in Australia 16.4%, Seventh-Day
Adventist 4.4%, none 9.2%, unknown 16.9%, other
2.4% (1986)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian
r ^ ---
Country name:
conventional long form; Territory of Norfolk Island
conventional short form: Norfolk Island
Data code: NF
Dependency status; territory of Australia; Canberra
administers Commonwealth responsibilities on
Norfolk Island through the Department of
Environment, Sport and Territories
Government type: NA
Capital; Kingston
Administrative divisions; none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: Pitcairners Arrival Day
Anniversary, 8 June (1856)
Constitution: Norfolk Island Act of 1979
Legal system; based on the laws of Australia, local
ordinances and acts; English common law applies in
matters not covered by either Australian or Norfolk
Island law
Suffrage: 18 years of age; universal
Executive branch;
chief of state: Queen ELIZABETH II (since 6 February
1952); the UK and Australia are represented by
Administrator A. J. MESSNER (since 4 August 1 997)
head of government: Assembly President and Chief
Minister George Charles SMITH (since 30 April 1997)
cabinet: Executive Council is made up of four of the
nine members of the Legislative Assembly; the
council devises government policy and acts as an
advisor to the Administrator
elections: the monarch is hereditary; administrator
appointed by the governor general of Australia; chief
369
Norfolk Island (continued)
minister eiected by the Legisiative Assembiy for a
term of not more than three years; eiection iast heid 30
April 1997 (next to be heid by May 2000)
election results: George Charies SMITH eiected chief
minister; percent of Legislative Assembly vote - NA
Legislative branch: unicameral Legislative
Assembly (9 seats; members elected by electors who
have nine equal votes each but only four votes can be
given to any one candidate; members serve
three-year terms)
elections: last held 30 April 1997 (next to be held by
May 2000)
election results: percent of vote - NA; seats -
independents 9
Judicial branch: Supreme Court; Court of Petty
Sessions
Political parties and leaders: none
International organization participation: none
Diplomatic representation in the US: none
(territory of Australia)
Diplomatic representation from the US: none
(territory of Australia)
Flag description: three vertical bands of green
(hoist side), white, and green with a iarge green
Norfolk Island pine tree centered in the siightiy wider
white band
Economy - overview: Tourism, the primary
economic activity, has steadiiy increased over the
years and has brought a ievel of prosperity unusual
among inhabitants of the Pacific isiands. The
agricuitural sector has become seif-sufficient in the
production of beef, pouitry, and eggs.
GDP: purchasing power parity - $NA
GDP ■ real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 1,395 (1991 est.)
Labor force - by occupation: tourism NA%,
subsistence agricuiture NA%
Unemployment rate: NA%
Budget:
revenues: $4.6 million
expenditures: $4.8 million, including capital
expenditures of $NA (FY92/93)
Industries: tourism
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: Norfolk Island pine seed,
Kentia palm seed, cereals, vegetables, fruit; cattle,
poultry
Exports: $1.5 million (f.o.b., FY91/92)
Exports - commodities: postage stamps, seeds of
the Norfolk Island pine and Kentia palm, small
quantities of avocados
Exports - partners: Australia, other Pacific island
countries, NZ, Asia, Europe
Imports: $17.9 million (c.i.f., FY91/92)
Imports - commodities: NA
Imports - partners: Australia, other Pacific island
countries, NZ, Asia, Europe
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1 .5207 (January 2000), 1 .5497 (1 999), 1 .5888 (1 998),
1 .3439 (1 997), 1 .2773 (1 996), 1 .3486 (1 995)
Fiscal year: 1 July - 30 June','894635af1dc5a4c1d17cca8a906601ee8683f5118a4bd65457a6b41f54e18c25','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e31228eb76ac4bd688e9eb32c34f5d3ba0f31bef4f2a6d7036f059798788ff40',2000,'BD','Bangladesh','economy',66,'Economy - overview: Despite sustained domestic
and international efforts to improve economic and
demographic prospects, Bangladesh remains one of
the world''s poorest, most densely populated, and
least developed nations. The economy is largely
agricultural, with the cultivation of rice the single most
important activity in the economy. Major impediments
to growth include frequent cyclones and floods, the
inefficiency of state-owned enterprises, a rapidly
growing labor force that cannot be absorbed by
agriculture, delays in exploiting energy resources
(natural gas), inadequate power supplies, and slow
implementation of economic reforms. Prime Minister
Sheikh HASINA Wajed''s Awami League government
has made some headway improving the ciimate for
foreign investors and liberalizing the capital markets;
for example, it has negotiated with foreign firms for oil
and gas exploration, better countrywide distribution of
cooking gas, and the construction of natural gas
pipelines and power plants. Progress on other
economic reforms has been halting because of
opposition from the bureaucracy, public sector unions,
and other vested interest groups. The especially
severe floods of 1 998 increased the country''s reliance
on large-scale international aid. So far the East Asian
financial crisis has not had major impact on the
GDP: purchasing power parity - $1 87 billion
(1999 est.)
GDP - real growth rate: 5.2% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,470
(1999 est.)
GDP - composition by sector:
agriculture: 30%
industry: t7%
services: 53% (1999 est.)
Population below poverty line: 35.6%
(FY95/96 est.)
Household income or consumption by percentage
share:
lowest 10%; 4.1%
highest 10%; 23.7% (1992)
Inflation rate (consumer prices): 9%
(FY98/99 est.)
Labor force: 56 million (1995-96)
note: extensive export of labor to Saudi Arabia,
Kuwait, UAE, Oman, Qatar, Malaysia, and Singapore
Labor force - by occupation: agriculture 63%,
services 26%, industry 11% (FY95/96)
Unemployment rate: 35.2% (1996)
Budget:
revenues: $4.3 billion
expenditures: $6.5 billion, including capital
expenditures of $NA (1997)
Industries: cotton textiles, jute, garments, tea
processing, paper newsprint, cement, chemical
fertilizer, light engineering, sugar
Industrial production growth rate: 2.5%
(1997 est.)
Electricity - production: 12.5 billion kWh
(1999 est.)
Electricity - production by source:
fossil fuel: 98%
hydro: 2%
nuclear: 0%
other 0% (1999)
Electricity - consumption: 1 1 .039 billion kWh
(1998)
Electricity - exports: 0 kWh (1 999)
Electricity - imports: 0 kWh (1999)
Agriculture - products: rice, jute, tea, wheat,
sugarcane, potatoes; beef, milk, poultry, tobacco,
pulses, oilseeds, spices, fruit
Exports: $5.1 biilion (1998)
Exports - commodities: garments, jute and jute
goods, leather, frozen fish and seafood
Exports - partners: US 33%, Germany 10%, UK
9%, France 6%, Italy 5% (1997)
Imports: $8.01 billion (1998)
Imports - commodities: machinery and equipment,
chemicals, iron and steel, textiles, raw cotton, food,
crude oil and petroleum products, cement
Imports - partners: India 12%, China 9%, Japan
7%, Hong Kong 6%, South Korea 6% (1997)
Debt - external: $16.5 billion (1998)
42
Bangladesh (continued)
Economic aid - recipient: $1 .475 billion (FY96/97)
Currency; 1 taka (Tk) = 100 poisha
Exchange rates: taka (Tk) per US$1 - 51 .000
(January 2000), 49.085 (1999), 46.906 (1998), 43.892
(1997), 41.794 (1996), 40.278 (1995)
Fiscal year: 1 July - 30 June
I Communications
Telephones - main lines in use: 470,000 (1998)
Telephones - mobile cellular: 41 ,000 (1 998)
Telephone system;
domestic: modernizing; introducing digital systems;
trunk systems include VHF and UHF microwave, and
some fiber-optic cable in cities
international: satellite earth stations - 2 Intelsat (Indian
Ocean); international radiotelephone communications
and landline service to neighboring countries
Radio broadcast stations: AM 12, FM 12,
shortwave 2 (1999)
Radios; 6.15 million (1997)
Television broadcast stations: 15 (1999)
Televisions: 770,000(1997)
Internet Service Providers (ISPs): 6 (1999)
I Transportation
Railways;
total: 2,745 km
broad gauge: 923 km 1 .676-m gauge
narrow gauge:!, 822 km 1.000-m gauge (1998 est.)
Highways;
tofa/; 201, 182 km
paved; 19,112 km
unpaved: 182,070 km (1997 est.)
Waterways: 5,150-8,046 km navigable waterways
(includes 2,575-3,058 km main cargo routes)
Pipelines: natural gas 1 ,220 km
Ports and harbors: Chittagong, Dhaka, Mongla
Port
Merchant marine;
total: 36 ships (1 ,000 GRT or over) totaling 284,489
GRT/405,845 DWT
ships by type: bulk 2, cargo 28, container 1 ,
petroleum tanker 2, refrigerated cargo 1 , roll-on/
roll-off 2 (1999 est.)
Airports: 16 (1999 est.)
Airports - with paved runways:
total: !8
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m:!
under 914 m; 6 (1999 est.)
Economy - overview: Historically, the Barbadian
economy had been dependent on sugarcane
cultivation and related activities, but production in
recent years has diversified into manufacturing and
tourism. The start of the Port Charles Marina project in
Speightstown helped the tourism industry continue to
expand in 1996-99. Offshore finance and informatics
are important foreign exchange earners, and there is
also a light manufacturing sector. The government
continues its efforts to reduce the unacceptably high
unemployment rate, encourage direct foreign
investment, and privatize remaining state-owned
enterprises.
GDP: purchasing power parity - $2.9 billion
(1998 est.)
GDP - real growth rate: 4.4% (1998 est.)
GDP - per capita: purchasing power parity - $1 1 ,200
(1998 est.)
GDP - composition by sector:
agriculture: 4.9%
industry: 15.6%
services: 79.5% (1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .7% (1 998)
Labor force: 1 36,000 (1998 est.)
Labor force - by occupation: services 75%,
industry 15%, agriculture 10% (1996 est.)
Unemployment rate: 1 2% (1 998 est.)
Budget:
revenues: $725.5 million
expenditures: $750.6 million, including capital
expenditures of $126.3 million (FY97/98 est.)
Industries: tourism, sugar, light manufacturing,
component assembly for export
Industrial production growth rate: 0.8% (1996)
Electricity - production: 672 million kWh (1998)
44
Barbados (continued)
Electricity - production by source;
fossil fuel: t00%
hydro: 0%
nuclear. 0%
other; 0% (1998)
Electricity - consumption; 625 million kWh (1998)
Electricity - exports; 0 kWh (1998)
Electricity - imports; 0 kWh (1 998)
Agricuiture - products; sugarcane, vegetables,
cotton
Exports; $21 1 .2 million (1 998)
Exports - commodities; sugar and molasses, rum,
other foods and beverages, chemicals, electrical
components, clothing
Exports - partners; UK 14.8%, US 1 1 .6%, Trinidad
and Tobago 7.6%, Venezuela 6.1%, Jamaica 5.8%
(1998)
Imports; $1.01 billion (1998)
Imports - commodities; consumer goods,
machinery, foodstuffs, construction materials,
chemicals, fuel, electrical components
Imports - partners; US30.7%,TrinldadandTobago
10.2%, Japan 8.3%, UK 7.7%, Canada 2.2% (1998)
Debt - external; $550 million (1998 est.)
Economic aid - recipient; $9.1 million (1995)
Currency; 1 Barbadian dollar (Bds$) = 100 cents
Exchange rates; Barbadian dollars (Bds$) per US$1
- 2.0000 (fixed rate pegged to the US dollar)
Fiscal year; 1 April - 31 March
I ~ C 0 m m u h i c ft I o n s
Telephones - main lines in use; 90,000 (1995)
Telephones - mobile cellular; 4,614 (1 995)
Telephone system;
domestic: island-wide automatic telephone system
international: satellite earth stations - 4 Intelsat
(Atlantic Ocean); tropospheric scatter to T rinidad and','0dc7486a477839afa1290eb2ca055f143c4bc02e7a37814c8814c17932541740','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2f782699d4ed9f337a59946b650b75c6e7f78e1f0ab5df632710fbb0849ee8',2000,'LC','Saint Lucia','economy',69,'Radio broadcast stations; AM 2, FM 3, shortwave
0(1998)
Radios; 237,000(1997)
Television broadcast stations; 1 (plus two cable
channels) (1997)
Televisions; 76,000(1997)
Internet Service Providers (ISPs); 3 (1999)
I transportation
Railways; 0 km
Highways;
tofa/; 1,600 km
paved; 1,578 km
unpaved: 22 km (1998 est.)
Ports and harbors; Bridgetown, Speightstown (Port
Charles Marina)
Merchant marine;
total: 47 ships (1 ,000 GRT or over) totaling 654,580
GRT/1, 103,780 DWT
ships by type: bulk 1 0, cargo 29, combination bulk 1 ,
container 1 , petroleum tanker 4, refrigerated cargo 2
(1999 est.)
note: a flag of convenience registry; includes ships of
2 countries: Canada owns 2 ships, Hong Kong 1
(1998 est.)
Airports; 1 (1 999 est.)
Airports - with paved runways;
total: 1
over 3,047 m: 1 (1999 est.)
” M i TiTa r y
Military branches; Royal Barbados Defense Force
(includes Ground Forces and Coast Guard), Royal
Barbados Police Force
Military manpower - availability;
males age 15-49: 77,789 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 53,472 (2000 est.)
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP; NA%
I TransnatTonaTl fssues™"
Disputes - international; none
Illicit drugs; one of many Caribbean transshipment
points for narcotics bound for the US and Europe
Location; Southern Africa, islands in the southern
Mozambique Channel, about one-half of the way from
Madagascar to Mozambique
Geographic coordinates; 21 30 S, 39 50 E
Map references; Africa
Area;
total: 0.2 sq km
land: 0.2 sqkm
water: 0 sq km
Area - comparative; about one-third the size of The
Mall in Washington, DC
Land boundaries; 0 km
Coastline; 35.2 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nrr\\
Climate; tropical
Terrain; volcanic rock
Elevation extremes;
lowest point: Indian Ocean 0 m
highest point: unnamed location 2.4 m
Natural resources; none
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (all rock)
Irrigated land; 0 sqkm (1993)
Natural hazards; maritime hazard since it is usually
under water during high tide and surrounded by reefs;
subject to periodic cyclones
Environment - current issues; NA
f People
Population; uninhabited (July 2000 est.)
45
Bassas da India (continued)
Economy - overview: no economic activity','f1e3da1f250eb438891e928efe8a32ec4c52e4b69ea5eb0e5f36f4705a2f7313','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d076869bb5768752cd6c2ea265335e4f9e4af7a133d741c3cdbebdf4c360e3',2000,'BY','Belarus','economy',76,'Economy - overview: Belarus has seen little
structural reform since 1995, when President
LUKASHENKO launched the country on the path of
"market socialism." In keeping with this policy,
LUKASHENKO re-imposed administrative controls
over prices and currency exchange rates and
expanded the state''s right to inten/ene in the
management of private enterprise. In addition to the
burdens imposed by high inflation, businesses have
been subject to pressure on the part of central and
local governments, e.g., arbitrary changes in
regulations, numerous rigorous inspections, and
retroactive application of new business regulations
prohibiting practices that had been legal. Further
economic problems are two consecutive bad
harvests, 1 998-99, and persistent trade deficits. Close
relations with Russia, possibly leading to reunion,
color the pattern of economic developments. For the
time being, Belarus remains self-isolated from the
West and its open-market economies.
GDP: purchasing power parity - $55.2 billion
(1999 est.)
GDP - real growth rate: 1 .5% (1999 est.)
GDP - per capita: purchasing power parity - $5,300
(1999 est.)
GDP - composition by sector:
agriculture: 23%
industry: 28%
senrices: 49% (1 998 est.)
Population below poverty line: 22% (1995 est.)
Household income or consumption by percentage
share:
lowest 10%: 4.9%
highest 10%: 19.4% (1993)
Inflation rate (consumer prices): 295% (1999 est.)
Labor force: 4.3 million (1998)
Labor force - by occupation: industry and
construction NA%, agriculture and forestry NA%,
services NA%
Unemployment rate: 2.3% officially registered
unemployed (December 1998); large number of
underemployed workers
Budget:
revenues: $4 billion
expenditures: $4.1 billion, including capital
expenditures of $180 million (1997 est.)
Industries: metal-cutting machine tools, tractors,
trucks, earth movers, motorcycles, TV sets, chemical
fibers, fertilizer, textiles, radios, refrigerators
47
Bolarus (continued)
Industrial production growth rate: 8% (1999 est.)
Electricity - production: 21.893 billion kWh (1998)
Electricity - production by source:
fossil fuei: 99.89%
hydro; 0.11%
nuclear: 0%
other; 0% (1998)
Electricity ■ consumption: 28.66 billion kWh (1 998)
Electricity - exports: 2.3 billion kWh (1998)
Electricity - imports: 10.6 billion kWh (1998)
Agriculture ■ products: grain, potatoes,
vegetables, sugar beets, flax; beef, milk
Exports: $6 billion (f.o.b., 1999)
Exports - commodities: machinery and equipment,
chemicals, metals, textiles, foodstuffs
Exports - partners: Russia 66%, Ukraine, Poland,
Germany, Lithuania (1998)
Imports: $6.4 billion (c.i.f., 1999)
Imports - commodities: mineral products,
machinery and equipment, metals, chemicals,
foodstuffs
Imports - partners: Russia 54%, Ukraine, Germany,
Poland, Lithuania (1998)
Debt - external: $1.1 billion (1998 est.)
Economic aid - recipient: $194.3 million (1995)
Currency: Belarusian rubel (BR)
Exchange rates: Belarusian rubels per US$1 -
730,000 (15 December 1999), 139,000 (25 January
1999), 46,080 (2nd qtr 1998), 25,964 (1997), 15,500
(yearend 1996), 11,500 (yearend 1995)
Fiscal year: calendar year
I C 0 m m u n I cat ions
Telephones - main lines in use: 2.537 million
(1997)
Telephones - mobile cellular: 8,000 (1999)
Telephone system: the Ministry of
Telecommunications controls all telecommunications
through its carrier (a joint stock company) Beltelcom
which is a monopoly
domestic: local - Minsk has a digital metropolitan
network and a cellular NMT-450 network; waiting lists
for telephones are long; local service outside Minsk is
neglected and poor; intercity - Belarus has a partly
developed fiber-optic backbone system presently
serving at least 13 major cities (1998); Belarus''s fiber
optics form synchronous digital hierarchy rings
through other countries'' systems; an inadequate
analog system remains operational
international: Belarus is a member of the
Trans-European Line (TEL), Trans-Asia-Europe
Fiber-Optic Line (TAE) and has access to the
Trans-Siberia Line (TSL); three fiber-optic segments
provide connectivity to Latvia, Poland, Russia, and
Ukraine; worldwide service is available to Belarus
through this infrastructure; additional analog lines to
Russia; Intelsat, Eutelsat, and Intersputnik earth
stations
Radio broadcast stations: AM 28, FM 37,
shortwave 11 (1998)
Radios: 3.02 million (1997)
Television broadcast stations: 17 (1997)
Televisions: 2.52 million (1997)
Internet Service Providers (ISPs): 1 (1999)
r transportation
Railways:
total: 5,563 km
broad gauge: 5,563 km 1 .520-m gauge (894 km
electrified)
Highways:
total: 255 km
paved: 60,567 km
unpaved: 2,755 km (1998 est.)
Waterways: NA km; note - Belarus has extensive
and widely used canal and river systems
Pipelines: crude oil 1,470 km; refined products
1,100 km; natural gas 1,980 km (1992)
Ports and harbors: Mazyr
Airports: 118 (1996 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m:^5
1,524 to 2,437 m: 5
under 914 m: 1 1 (1 996 est.)
Airports - with unpaved runways:
total: 52
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 62 (1996 est.)
i Mil it ary
Military branches: Army, Air Force, Air Defense
Force, Interior Ministry Troops, Border Guards
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,714,420 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,126,655 (2000 est.)
Military manpower - reaching military age
annually:
males: 82,720 (2000 est.)
Military expenditures - dollar figure: $1 56 million
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
Economy - overview: This modern private
enterprise economy has capitaiized on its centrai
geographic iocation, highiy deveioped transport
network, and diversified industriai and commercial
base. Industry is concentrated mainiy in the popuious
Flemish area in the north, aithough the government is
encouraging investment in the southern region of
Wallonia. With few naturai resources, Beigium must
import substantial quantities of raw materiais and
export a large volume of manufactures, making its
economy unusualiy dependent on the state of worid
markets. About three-quarters of its trade is with other
EU countries. Beigium''s pubiic debt feii from 127% of
GDP in 1996 to 122% of GDP in 1998 and the
government is trying to control its expenditures to
bring the figure more into line with other industriaiized
countries. Beigium became a charter member of the
European Monetary Union (EMU) in January 1999.
The dioxin crisis - beginning in June 1999 with the
discovery of a cancer-causing substance in animai
feed - constituted a serious biow to the
food-processing industry, both domesticaiiy and
internationaliy. This crisis siowed down GDP growth
with recovery expected in the year 2000.
GDP: purchasing power parity - $243.4 biiiion
(1999 est.)
GDP - real growth rate: 1 .8% (1 999 est.)
GDP - per capita: purchasing power parity - $23,900
(1999 est.)
GDP - composition by sector:
agriculture: 1 .4%
industry: 27%
services: 71 .6% (1 999 est.)
Population below poverty line: 4%
Household income or consumption by percentage
share:
lowest 10%: 3.7%
highest 10%: 20.2% (1992)
Inflation rate (consumer prices): 1% (1999 est.)
Labor force: 4.341 million (1999)
Labor force - by occupation; sen/ices 73%,
industry 25%, agriculture 2% (1999 est.)
Unemployment rate: 9% (1999 est.)
Budget:
revenues; $11 6.5 billion
expenditures: $119 billion, including capitai
expenditures of $10.7 billion (1998 est.)
Industries: engineering and metal products, motor
vehicle assembly, processed food and beverages,
chemicals, basic metals, textiles, glass, petroleum,
coal
Industrial production growth rate: -1%(1999 est.)
Electricity - production: 78.702 billion kWh (1998)
Electricity - production by source:
fossil fuel: 42.48%
hydro: 0.49%
nuclear: 55.72%
other: 1.31% (im)
Electricity - consumption: 74.543 billion kWh
(1998)
Electricity - exports: 6.4 billion kWh (1998)
Electricity - imports: 7.75 billion kWh (1998)
Agriculture - products: sugar beets, fresh
vegetables, fruits, grain, tobacco; beef, veal, pork, milk
Exports: $1 87.3 billion (f.o.b., 1999)
Exports - commodities: machinery and equipment,
chemicais, diamonds, metals and metal products
Exports - partners: EU 76% (Germany 19%,
France 18%, Netherlands 12%, UK 10%) (1998)
Imports: $172.8 billion (f.o.b., 1999)
Imports - commodities: machinery and equipment,
chemicais, metals and metal products
Imports ■ partners: EU 71% (Germany 18%,
Netherlands 17%, France 14%, UK 9%) (1998)
Debt - external: $28.3 billion (1 999 est.)
Economic aid - donor: ODA, $764 million (1997)
Currency: 1 Belgian franc (BF) = 100 centimes
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); Belgian francs (BF) per US$1 -
34.77 (January 1999), 36.229 (1998), 35.774 (1997),
30.962 (1996), 29.480 (1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 40.3399 Belgian francs per euro; the euro will
replace the local currency in consenting countries for
all transactions in 2002
Fiscal year: calendar year
Economy - overview: The small, essentially private
enterprise economy is based primarily on agriculture,
agro-based industry, and merchandising, with tourism
and construction assuming greater importance.
Sugar, the chief crop, accounts for nearly half of
exports, while the banana industry is the country''s
largest employer. The government''s tough austerity
program in 1997 resulted in an economic slowdown
that continued in 1998. The trade deficit has been
growing, mostly as a result of low export prices for
sugar and bananas. The new government faces
important challenges to economic stability. Rapid
action to improve tax collection has been promised,
but a lack of progress in reining in spending could
bring the exchange rate under pressure. The tourist
and construction sectors strengthened in early 1999,
leading to a preliminary estimate of revived growth at
4%.
GDP: purchasing power parity - $740 million
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $3,1 00
(1999 est.)
GDP - composition by sector:
agriculture:
industry: 22%
services: 56% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -0.9% (1 999 est.)
Labor force: 71,000
note: shortage of skilled labor and all types of
technical personnel (1997 est.)
Labor force - by occupation: agriculture 38%,
industry 32%, services 30% (1994)
Unemployment rate: 14.3% (1998)
Budget:
revenues; $140 million
expenditures: $180 million, including capital
expenditures of $NA (1997)
Industries: garment production, food processing,
tourism, construction
Industrial production growth rate: -4.4% (1998)
Electricity - production: 175 million kWh (1998)
Electricity ■ production by source:
fossil fuel: 57.14%
hydro: 42.86%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 1 63 million kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, coca, citrus,
sugarcane; lumber; fish, cultured shrimp
Exports: $150 million (f.o.b., 1998)
Exports - commodities: sugar, bananas, citrus
fruits, clothing, fish products, molasses, wood
Exports - partners: US 45.5%, UK 30%, EU 10%,
Caricom 4.2%, Mexico 3.4%, Canada 3.3% (1997)
Imports: $320 million (c.i.f., 1998)
Imports - commodities: machinery and
transportation equipment, manufactured goods, food,
fuels, chemicals, pharmaceuticals
Imports - partners: US 52%, Mexico 13%, UK 5%
(1997)
Debt -external: $380 million (1997)
Economic aid - recipient: $23.4 million (1995)
Currency: 1 Belizean dollar (Bz$) = 100 cents
Exchange rates: Belizean dollars (Bz$) per US$1 -
2.0000 (fixed rate)
Fiscal year: 1 April - 31 March
Economy - overview: The economy of Benin
remains underdeveloped and dependent on
subsistence agriculture, cotton production, and
regional trade. Grovrth in real output has averaged a
sound 4% in 1990-95 and 5% in 1996-99. Rapid
population growth has offset much of this growth in
output. Inflation has subsided over the past three
years. Commercial and transport activities, which
make up a large part of GDP, are vulnerable to
developments in Nigeria, particularly fuel shortages.
The Paris Club and bilateral creditors have eased the
external debt situation in recent years. The
government, still burdened with money-losing state
enterprises and a bloated civil service, has been
gradually implementing a structural adjustment
program since 1991.
GDP: purchasing power parity - $8.1 billion
(1999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,300
(1999 est.)
GDP - composition by sector:
agriculture: 34%
industry: 14%
services: 52% (1997)
Population beiow poverty iine: 33% (1995 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Infiation rate (consumer prices): 3% (1999 est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $299 million
expenditures: $445 million, including capital
expenditures of $14 million (1995 est.)
Industries: textiles, cigarettes; beverages, food;
construction materials, petroleum
Industrial production growth rate: NA%
Electricity - production: 6 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%{im)
Electricity - consumption: 276 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 270 million kWh (1998)
Agriculture - products: corn, sorghum, cassava
(tapioca), yams, beans, rice, cotton, palm oil, peanuts;
poultry, livestock
Exports: $396 million (f.o.b., 1999)
Exports - commodities: cotton, crude oil, palm
products, cocoa
Exports - partners: Brazil 32%, Libya, Indonesia,
Spain (1998)
54
B@nin (continued)
note: both sexes are liable for military service
(2000 est.)
Military manpower - fit for military service:
males age f5-49; 71 7,289
females age 15-49: 732,196 (2000 est.)
Military manpower - reaching military age
annually;
males: 69,065
females: 67,961 (2000 est.)
Military expenditures - dollar figure: $27 million
(FY96)
Military expenditures - percent of GDP: 1 .2%
(FY96)
I T r a n s n a t i o h a I Issues
Disputes - international: none
Illicit drugs: transshipment point for narcotics
associated with Nigerian trafficking organizations and
most commonly destined for Western Europe and
the US
pBermuda
l(overseas territory of
I^UK)
North Atlantic
Ocean
North Atlantic
Ocean
I Introduction
Background: Bermuda was first settled in 1609 by
shipwrecked English colonists headed for Virginia.
Tourism to the island to escape North American
winters first developed in Victorian times. Bermuda
has developed into highly successful offshore
financial center. A referendum on independence was
soundly defeated in 1995.
Imports; $566 million (f.o.b., 1999)
Imports - commodities: foodstuffs, tobacco,
petroleum products, capital goods
Imports - partners: France 22%, China 16%, UK,
Netherlands (1998)
Debt - external: $1 .6 billion (1 997 est.)
Economic aid - recipient: $281 .2 million (1 995)
Currency: 1 Communaute Financiers Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 -
647.25 (January 2000), 61 5.70 (1 999), 589.95 (1 998),
583.67 (1997), 511.55 (1996), 499.15 (1995)
note: from 1 January 1 999, the CFAF is pegged to the
euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 28,000 (1995)
Telephones - mobile cellular: 1 ,050 (1 995)
Telephone system:
domestic: ta:\\r system of open wire, microwave radio
relay, and cellular connections
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean); submarine cable
Radio broadcast stations: AM 2, FM 9, shortwave
4(1998)
Radios: 620,000(1997)
Television broadcast stations: 2 (one
privately-owned) (1997)
Televisions: 60,000(1997)
Internet Service Providers (ISPs); NA
I Transportation
Railways:
total: 578 km (single track)
narrow gauge: 578 km 1.000-m gauge (1995 est.)
Highways:
fofa/; 6,787 km
paved: 1 ,357 km (including 1 0 km of expressways)
urrpaved; 5,430 km (1997 est.)
Waterways: navigable along small sections,
important only locally
Ports and harbors: Cotonou, Porto-Novo
Merchant marine: none (1999 est.)
Airports: 5 (1999 est.)
Airports - with paved runways;
total: 2
2,438 to 3,047 m:1
1,524 to 2,437 m:1 (1999 est.)
Airports - with unpaved runways;
total: 3
1,524 to 2,437 m:1
914 to 1,523 m: 2 {1999 est.)
I Military
Military branches: Armed Forces (includes Army,
Navy, Air Force), National Gendarmerie
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,402,566
females age 15-49: 1 ,445,082
G e 0 g77p h“y''
Location: North America, group of islands in the
North Atlantic Ocean, east of North Carolina (US)
Geographic coordinates; 32 20 N, 64 45 W
Map references: North America
Area;
total: 58.8 sq km
land: 58.8 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 103 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate; subtropical; mild, humid; gales, strong
winds common in winter
Terrain: low hills separated by fertile depressions
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Jowr\\ Hill 76 m
Natural resources: limestone, pleasant climate
fostering tourism
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 94% (55% developed, 39% rural/open space)
(1997 est.)
55
Bermuda (continued)
Irrigated land; NAsqkm
Natural hazards: hurricanes (June to November)
Environment - current issues: asbestos disposal;
water pollution; preservation of open space
Geography - note: consists of about 360 small coral
islands with ample rainfall, but no rivers or freshwater
lakes; some land, reclaimed and otherwise, was
leased by US Government from 1941 to 1995
Economy - overview: Bermuda en]oys one of the
highest per capita incomes in the world, having
successfully exploited its location by providing
financial services for international firms and luxury
tourist facilities for 360,000 visitors annually. The
tourist industry, which accounts for an estimated 28%
of GDP, attracts 84% of its business from North
America. The industrial sector is small, and agriculture
is severely limited by a lack of suitable land. About
80% of food needs are imported. International
business contributes over 60% of Bermuda''s
economic output; a failed independence vote in late
1995 can be partially attributed to Bermudian fears of
scaring away foreign firms. Government economic
priorities are the further strengthening of the tourist
and international financial sectors.
GDP: purchasing power parity - $2 billion (1 999 est.)
GDP - real growth rate: 2.5% (1999 est.)
GDP - per capita: purchasing power parity - $31 ,500
(1999 est.)
GDP - composition by sector;
agriculture: 1%
industry: 10%
services: 89% (1995 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
inflation rate (consumer prices); 2% (1998 est.)
Labor force: 35,296(1997)
Labor force - by occupation: clerical 23%,
services 22%, laborers 17%, professional and
technical 17%, administrative and managerial 12%,
sales 7%, agriculture and fishing 2% (1996)
Unemployment rate: NEGL%(1995)
Budget;
revenues: $504.6 million
expenditures: $537 million, including capital
expenditures of $75 million (FY97/98)
Industries: tourism, finance, insurance, structural
concrete products, paints, perfumes,
pharmaceuticals, ship repairing
Industrial production growth rate: NA%
Electricity - production: 420 million kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% {1998)
Electricity - consumption: 391 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: bananas, vegetables,
citrus, flowers; dairy products
Exports: $32 million (1998 est.)
Exports - commodities: reexports of
pharmaceuticals
Exports - partners: UK 29.5%, US 9.8% (1997)
Imports: $624 million (1 998 est.)
Imports - commodities: machinery and transport
equipment, construction materials, chemicals, food
and live animals
Imports - partners: US 34%, UK 9%, Mexico 8%
(1997)
Debt - external; $NA
Economic aid - recipient: $27.9 million (1995)
56
Bermuda (continued)
Currency: 1 Bermudian dollar (Bd$) = 100 cents
Exchange rates: Bermudian dollar (Bd$) per US$1 -
1.0000 (fixed rate)
Fiscal year: 1 April - 31 March
I Communications
Telephones - main lines in use: 48,000 (1995)
Telephones - mobile cellular: 6,324 (1 995)
Telephone system:
domestic: modern, fully automatic telephone system
international: 3 submarine cables; satellite earth
stations - 3 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 5, FM 3, shortwave
0(1998)
Radios: 82,000(1997)
Television broadcast stations^ 3 (1997)
Televisions: 66,000(1997)
Internet Service Providers (ISPs): 3 (1 999)
I " f rTn s p 0 r t a Ti o
Railways: 0 km
Highways:
total: 225 km
paved: 225 km
unpaved: 0 km (1 997 est.)
note: in addition, there are 232 km of paved and
unpaved roads that are privately owned
Ports and harbors: Hamilton, Saint George
Merchant marine:
total: 115 ships (1 ,000 GRT or over) totaling
6,536,975 GRT/1 1,337,483 DWT
ships by type: bulk 27, cargo 4, chemical tanker 2,
container 17, liquified gas 7, petroleum tanker 33,
refrigerated cargo 14, roll-on/roll-off 8, short-sea
passenger 3 (1999 est.)
note: a flag of convenience registry; includes ships
from 1 1 countries among which are UK 24, Canada
12, Hong Kong 1 1 , US 1 1 , Nigeria 4, Sweden 4,
Nonvay 3, and Switzerland 2 (1998 est.)
Airports: 1 (1 999 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m; 1 (1999 est.)
I Military
Military branches: Bermuda Regiment, Bermuda
Police Force, Bermuda Reserve Constabulary
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
the UK
I Transnational Issues
Disputes - international: none
Background: Under British influence a monarchy
was set up in 1907; three years later a treaty was
signed whereby the country became a British
protectorate. Independence was attained in 1949,
with India subsequently guiding foreign relations and
supplying aid.
r ■ ''G e 0 g Va p h y-"---'' . .
Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
/and; 47,000 sqkm
water: 0 sq km
Area - comparative: about half the size of Indiana
Land boundaries;
tofa/; 1,075 km
border counfr/es; China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims; none (landlocked)
Climate: varies; tropical in southern plains; cool
winters and hot summers in central valleys; severe
winters and cool summers in Himalayas
Terrain: mostly mountainous with some fertile
valleys and savanna
Elevation extremes;
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower, gypsum,
calcium carbide
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 66%
other; 26% (1993 est.)
Irrigated land; 340 sq km (1993 est.)
Natural hazards: violent storms coming down from
the Himalayas are the source of the country''s name
which translates as Land of the Thunder Dragon;
frequent landslides during the rainy season
Environment - current issues: soil erosion; limited
access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Nuclear Test
Ban
signed, but not ratified: Law of the Sea
Geography - note: landlocked; strategic location
between China and India; controls several key','60cdc771e3ef6935643bfcb120a54bf752ab52dd98104354ecf90ee686eccd99','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aac8ee97dfd061916d3a30c144777faa3c1d19d27e6c101509a73145ddd1f578',2000,'BY','Belarus','economy',77,'Himalayan mountain passes
i People
Population: 2,005,222
note: other estimates range as low as 800,000 (July
2000 est.)
Age structure:
0-14 years: 40% (male 417,627; female 387,927)
15-64 years: 56% (male 576,533; female 544,076)
65 years and over: 4% (male 40,081 ; female 38,978)
(2000 est.)
Population growth rate: 2.19% (2000 est.)
Birth rate: 36.22 births/1 ,000 population (2000 est.)
Death rate: 14.32 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.07 male(s)/female (2000 est.)
Infant mortality rate: 1 1 0.99 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 52.4 years
male: 52.79 years
female: 51 .99 years (2000 est.)
Total fertility rate: 5.13 children born/woman
(2000 est.)
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%,
indigenous or migrant tribes 15%
Religions; Lamaistic Buddhist 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 42,2%
male: 56.2%
female: 28.1 % (1 995 est.)
People - note: refugee issue over the presence in
Nepal of approximately 96,500 Bhutanese refugees,
90% of whom are in seven United Nations Office of the
High Commissioner for Refugees (UNHCR) camps
57
Bhutan (continued)
Economy - overview: The economy, one of the
world''s smallest and least developed, is based on
agriculture and forestry, which provide the main
livelihood for 90% of the population and account for
about 40% of GDP. Agriculture consists largely of
subsistence farming and animal husbandry. Rugged
mountains dominate the terrain and make the building
of roads and other infrastructure difficult and
expensive. The economy is closely aligned with
India''s through strong trade and monetary links. The
industrial sector is technologically backward, with
most production of the cottage industry type. Most
development projects, such as road construction, rely
on Indian migrant labor. Bhutan''s hydropower
potential and its attraction for tourists are key
resources. The Bhutanese Government has made
some progress in expanding the nation''s productive
base and improving social welfare. Model education,
social, and environment programs in Bhutan are
underway with support from multilateral development
organizations. Each economic program takes into
account the government''s desire to protect the
country''s environment and cultural traditions. Detailed
controls and uncertain policies in areas like industrial
licensing, trade, labor, and finance continue to
hamper foreign investment.
GDP: purchasing power parity - $2.1 billion
(1999 est.)
GDP - real growth rate: 7% (1 999 est.)
GDP - per capita: purchasing power parity - $1 ,060
(1999 est.)
GDP - composition by sector:
agriculture: 38%
industry: 37%
serv/ces; 25% (1998)
Population below poverty line; NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 9% (1998)
Labor force: NA
note: massive lack of skilled labor
Labor force - by occupation: agriculture 93%,
services 5%, industry and commerce 2%
Unemployment rate: NA%
Budget;
revenues; $146 million
expenditures: $152 million, including capital
expenditures of $NA (FY95/96 est.)
note: the government of India finances nearly
three-fifths of Bhutan''s budget expenditures
Industries: cement, wood products, processed
fruits, alcoholic beverages, calcium carbide
Industrial production growth rate: 9.3%
(1996 est.)
Electricity - production: 1 .788 billion kWh (1998)
Electricity - production by source;
fossil fuel: 0.39%
hydro; 99.61%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 345 million kWh (1998)
Electricity - exports: 1 .339 billion kWh
note; exports electricity to India (1998)
Electricity - imports: 21 million kWh (1998)
Agriculture - products: rice, corn, root crops, citrus,
foodgrains; dairy products, eggs
Exports; $111 million (f.o.b., 1998)
Exports - commodities; cardamom, gypsum,
timber, handicrafts, cement, fruit, electricity (to India),
precious stones, spices
Exports - partners: India 94%, Bangladesh
Imports: $136 million (c.i.f., 1998)
Imports - commodities: fuel and lubricants, grain,
machinery and parts, vehicles, fabrics, rice
Imports ■ partners: India 77%, Japan, UK,
Germany, US
Debt - external: $120 million (1998)
Economic aid - recipient: $73.8 million (1995)
Currency: 1 ngultrum (Nu) = 100 chetrum; note -
Indian currency is also legal tender
Exchange rates: ngultrum (Nu) per US$1 - 43.552
(January 2000), 43.055 (1 999), 41 .259 (1 998), 36.31 3
(1997), 35.433 (1996), 32.427 (1995); note ■ the
Bhutanese ngultrum is at par with the Indian rupee
Fiscal year: 1 July - 30 June
Economy - overview: Bolivia, long one of the
poorest and least developed Latin American
countries, has made considerable progress toward
the development of a market-oriented economy.
Successes under President SANCHEZ DE LOZADA
(1993-1997) included the signing of a free trade
agreement with Mexico and the Southern Cone
Common Market (Mercosur) as weil as the
privatization of the state airiine, telephone company,
railroad, electric power company, and oil company.
His successor, Hugo BANZER Suarez has tried to
further improve the country''s investment climate with
an anticorruption campaign. Growth slowed in 1999,
in part due to tight government budget policies, which
limited needed appropriations for anti-poverty
programs, and the fallout from the Asian financial
crisis. Growth should rebound to perhaps 4% in 2000
given reasonably favorable world commodity prices.
GDP: purchasing power parity - $24.2 billion
(1999 est.)
GDP - real growth rate: 2% (1999 est.)
GDP - per capita: purchasing power parity - $3,000
(1999 est.)
GDP - composition by sector:
agriculture: 16.8%
industry: 35.5%
services: 47.9% (1998 est.)
60
Bolivia (continued)
Population below poverty line: 70% (1999 est.)
Househoid income or consumption by percentage
share:
lowest 10%: 2.3%
highest 10%: 31. 7% {1990)
Infiation rate (consumer prices): 2.1% (1999 est.)
Labor force: 2.5 million
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 1 1 .4% (1 997) with widespread
underemployment
Budget:
revenues: $2.7 billion
expenditures: $2.7 billion including capital
expenditures of $NA (1 998)
Industries: mining, smelting, petroleum, food and
beverages, tobacco, handicrafts, clothing
Industrial production growth rate: 4% (1995 est.)
Electricity - production: 2.576 billion kWh (1998)
Electricity - production by source:
fossil fuel: 42.43%
hydro: 55.75%
nuclear: 0%
of/rer; 1.82% (1998)
Electricity - consumption: 2.41 2 billion kWh (1998)
Electricity ■ exports: 4 million kWh (1 998)
Electricity • imports: 20 million kWh (1998)
Agriculture • products: soybeans, coffee, coca,
cotton, corn, sugarcane, rice, potatoes; timber
Exports: $1.1 billion (f.o.b., 1999 est.)
Exports - commodities: soybeans, natural gas,
zinc, gold, wood
Exports - partners: UK 16%, US 12%, Peru 11%,
Argentina 10%, Colombia 7% (1998)
Imports: $1.6 billion (c.i.f., 1999 est.)
Imports - commodities: capital goods, raw
materials and semi-manufactures, chemicals,
petroleum, food
imports - partners: US 32%, Japan 24%, Brazil
12%, Argentina 12%, Chile 7%, Peru 4%, Germany
3% (1998)
Debt - external: $5.7 billion (1 999)
Economic aid - recipient: $588 million (1997)
Currency: 1 boliviano ($B) = 100 centavos
Exchange rates: bolivianos ($B) per US$1 - 6.0065
(January 2000), 5.81 24 (1999), 5.51 01 (1 998), 5.2543
(1997), 5.0746 (1996), 4.8003 (1995)
Fiscal year: calendar year
Economy ■ overview: Agriculture still provides a
livelihood for more than 80% of the population but
supplies only about 50% of food needs and accounts
for only 3% of GDP. Subsistence farming and cattle
raising predominate. The sector is plagued by erratic
rainfall and poor soils. Diamond mining and tourism
also are important to the economy. Substantial
mineral deposits were found in the 1970s and the
mining sector grew from 25% of GDP in 1 980 to 38%
in 1998. Unemployment officially is 21% but unofficial
estimates place it closer to 40%. The Orapa 2000
project, which will double the capacity of the country''s
main diamond mine, will be finished in early 2000.
This will be the main force behind continued economic
expansion.
GDP: purchasing power parity - $5.7 billion
(1999 est.)
GDP - real grovrth rate: 6.5% (1999 est.)
GDP - per capita: purchasing power parity - $3,900
(1999 est.)
GDP - composition by sector:
agriculture: 4%
industry: 46% (including 36% mining)
services: 50% (1998 est.)
Population below poverty line: 47% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 7.7% (1999 est.)
Labor force: 235,000 formal sector employees
(1995)
Labor force - by occupation: 1 00,000 public
sector; 135,000 private sector, including 14,300 who
are employed in various mines in South Africa; most
others engaged in cattle raising and subsistence
agriculture (1995 est.)
Unemployment rate: 20%-40% (1999 est.)
Budget:
revenues; $1.6 billion
expenditures: $1 .8 billion, including capital
expenditures of $560 million (FY96/97)
Industries; diamonds, copper, nickel, coal, salt,
soda ash, potash; livestock processing
Industrial production growth rate: 4.6%
(FY92/93)
Electricity - production: 1 billion kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
of/7er;0%(1998)
Electricity - consumption: 1 .61 9 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity • imports: 689 million kWh (1998)
Agriculture - products: sorghum, corn, millet,
pulses, groundnuts (peanuts), beans, cowpeas,
sunflower seed; livestock
Exports: $2.36 billion (f.o.b., 1999 est.)
Exports ■ commodities: diamonds 72%, vehicles,
copper, nickel, meat (1998)
Exports - partners: EU 74%, Southern African
Customs Union (SACU) 21%, Zimbabwe 3% (1996)
Imports: $2.05 billion (f.o.b., 1999 est.)
Imports - commodities: foodstuffs, machinery and
transport equipment, textiles, petroleum products
Imports - partners; Southern African Customs
Union (SACU) 78%, Europe 8%, Zimbabwe 6%
(1996)
Debt -external: $651 million (1998)
Economic aid - recipient: $73 million (1995)
Currency: 1 pula (P) = 100 thebe
Exchange rates: pulas (P) per US$1 - 4.6168
(January 2000), 4.6244 (1999), 4.2259 (1 998), 3.6508
(1997), 3.3242 (1996), 2.7722 (1995)
Fiscal year: 1 April - 31 March','4270da42f5bdf1d9f267d5eb24a2f3ba2c9467d2c3ef933e8987481d9d9c7e6b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c784e421d5761eb7d996486eef7249702e481406bc6f11adbd90a990b7d6385',2000,'IO','British Indian Ocean Territory','economy',91,'Economy - overview: This smali, weaithy economy
is a mixture of foreign and domestic entrepreneurship,
government regulation and weifare measures, and
viliage tradition. It is almost totally supported by
exports of crude oil and natural gas, with revenues
from the petroleum sector accounting for over half of
GDP. Per capita GDP is far above most other Third
World countries, and substantial income from
overseas investment supplements income from
domestic production. The government provides for all
medical services and subsidizes food and housing.
The government has shown progress in its basic
policy of diversifying the economy away from oil and
gas. Brunei''s leaders are concerned that steadily
increased integration in the world economy will
undermine internal social cohesion although it has
taken steps to become a more prominent player by
serving as chairman for the 2000 APEC (Asian Pacific
Economic Cooperation) forum. Growth in 1999 is
estimated at 2.5% due to higher oil prices in the
second half.
GDP: purchasing power parity - $5.6 billion
(1999 est.)
GDP - real growth rate: 2.5% (1999 est.)
GDP - per capita: purchasing power parity - $1 7,400
(1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 46%
services: 49% (1 996 est.)
Population below poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
infiation rate (consumer prices): 1 % (1 999 est.)
Labor force: 144,000 (1995 est.); note - includes
foreign workers and military personnel
note: temporary residents make up 41 % of labor force
(1991)
Labor force - by occupation: government 48%,
production of oil, natural gas, services, and
construction 42%, agriculture, forestry, and fishing
10% (1999 est.)
Unemployment rate: 4.9% (1995 est.)
Budget:
revenues: $2.5 billion
expenditures: ^2.6 billion, including capital
expenditures of $768 million (1995 est.)
Industries: petroleum, petroleum refining, liquefied
natural gas, construction
Industrial production growth rate: 4% (1997 est.)
Electricity - production: 2.56 billion kWh (1998)
Electricity - production by source:
fossil fuel: 10Q%
hydro: 0%
nuclear: 0%
other: Q%(im)
Electricity - consumption: 2.381 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture ■ products: rice, cassava (tapioca),
bananas; water buffalo
Exports: $2.04 billion (f.o.b., 1998 est.)
Exports - commodities: crude oil, liquefied natural
gas, petroleum products
Exports • partners: Japan 51%, UK 14%, US 10%,
Singapore 8%, Thailand 3% (1998)
Imports: $1.38 billion (c.i.f., 1998 est.)
Imports ■ commodities: machinery and transport
equipment, manufactured goods, food, chemicals
Imports - partners: Singapore 32%, UK 17%,
Malaysia 12%, France 12%, US 5% (1998)
Debt - external: $0
Economic aid - recipient: $4.3 million (1995)
Currency: 1 Bruneian dollar (B$) = 100 cents
Exchange rates: Bruneian dollars (B$) per US$1 -
1 .6733 (January 2000), 1 .6950 (1 999), 1 .6736 (1 998),
1.4848 (1997), 1.4100 (1996), 1.4174 (1995); note -
the Bruneian dollar is at par with the Singapore dollar
Fiscal year: calendar year
Economy - overview: In April 1 997, the current
ruling Union of Democratic Forces (UDF) government
won pre-term parliamentary elections and introduced
an IMF currency board system which succeeded in
stabilizing the economy. The triple digit inflation of
1 996 and 1 997 has given way to an official consumer
price increase of 6.2% in 1999. Following declines in
GDP in both 1996 and 1997, the economy grew an
officially estimated 3.5% in 1998 and 2.5% in 1999. In
September 1998, the IMF approved a three-year
Extended Fund Facility, which provides credits worth
approximately $900 million, designed to support
Bulgaria''s reform efforts. In 1999, an unfavorable
international environment - primarily caused by the
Kosovo conflict - and structural reforms slowed
economic growth, but forecasters are predicting
accelerated growth over the next several, years. The
government''s structural reform program includes: (a)
privatization and, where appropriate, liquidation of
state-owned enterprises (SOEs); (b) liberalization of
agricultural policies, including creating conditions for
the development of a land market; (c) reform of the
country''s social insurance programs; and (d) reforms
to strengthen contract enforcement and fight crime
and corruption.
GDP: purchasing power parity - $34.9 billion
(1999 est.)
GDP - real growth rate: 2,5% (1999 est.)
GDP - per capita: purchasing power parity - $4,300
(1999 est.)
GDP - composition by sector;
agriculture: 21%
industry: 29%
services: 50% (1999 est.)
Population below poverty line; NA%
Household income or consumption by percentage
share:
iowest 10%: 3.3%
highest 10%; 24.7% (1992)
Inflation rate (consumer prices): 6.2% (1999 est.)
Labor force: 3.82 million (1998 est.)
Labor force - by occupation: agriculture 26%,
industry 31%, services 43% (1998 est.)
Unemployment rate: 15% (1999 est.)
Budget:
revenues: $4.69 billion
expenditures: $5.06 billion, including capital
expenditures of $NA (1999 est.)
Industries: machine building and metal working,
food processing, chemicals, construction materials,
ferrous and nonferrous metals, nuclear fuel
Industrial production growth rate: -3% (1999 est.)
Electricity - production: 38.423 billion kWh (1998)
Electricity - production by source:
fossil fuel: 52.34%
hydro:!. 35%
nuclear: 40.31%
other: 0%(im)
Electricity - consumption: 35.493 billion kWh
(1998)
Electricity - exports: 2 billion kWh (1998)
Electricity - imports: 1 .76 billion kWh (1 998)
Agriculture - products: vegetables, fruits, tobacco,
livestock, wine, wheat, barley, sunflowers, sugar
beets
Exports: $3.8 billion (f.o.b., 1999 est.)
Exports - commodities; machinery and equipment;
metals, minerals, and fuels; chemicals and plastics;
food, tobacco, clothing (1998)
Exports - partners: Italy 13%, Germany 10%,
Greece 9%, Turkey 8%, Russia (1998)
Imports: $5.3 billion (f.o.b., 1999 est.)
Imports - commodities: fuels, minerals, and raw
materials; machinery and equipment; metals and
ores; chemicals and plastics; food, textiles (1998)
Imports - partners: Russia 20%, Germany 14%,
Italy 8%, Greece 6%, US 4% (1998)
Debt - external: $1 0 billion (1 999 est.)
Economic aid - recipient: $NA
Currency: 1 lev (Lv) = 100 stotinki
Exchange rates: leva (Lv) per US$1 - 1 .9295
(January 2000), 1.8364 (1999), 1,760.36 (1998),
1,681.88 (1997), 177.89 (1996), 67.17 (1995)
note: on 5 July 1999 the lev was re-denominated; the
post-5 July 1 999 lev is equal to 1 ,000 of the pre-5 July
1999 leva
Fiscal year: calendar year','dfb8ee14952d5e6f08e26c0e7ba9d856ef915eeaa43edd223bc35f6cdc1197ce','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79a52a49f5df5ceda45f11a6afacacec3cad78a54eb35682405a2b86f468cfef',2000,'ET','Ethiopia','economy',95,'Economy - overview: One of the poorest countries
in the world, landlocked Burkina Faso has a high
population density, few natural resources, and a
fragile soil. About 90% of the population is engaged in
(mainly subsistence) agriculture which is highly
vulnerable to variations in rainfall. Industry remains
dominated by unprofitable government-controlled
corporations. Following the African franc currency
devaluation in January 1 994 the government updated
its development program in conjunction with
international agencies, and exports and economic
growth have increased. Maintenance of its
macroeconomic progress in 2000-2001 depends on
continued low inflation, reduction in the trade deficit,
and reforms designed to encourage private
investment.
GDP: purchasing power parity - $12.4 billion
(1999 est.)
GDP - real growth rate: 5.5% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,100
(1999 est.)
GDP - composition by sector:
agriculture: 36%
industry: 20%
sefv;ces;44% (1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (1999 est.)
Labor force: 4.679 million (persons 1 0 years old and
over, according to a sample survey taken in 1991)
note: a large pari of the male labor force migrates
annually to neighboring countries for seasonal
employment
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: NA%
Budget:
revenues: $277 million
expenditures: $^92 million, including capital
expenditures of $233 million (1995 est.)
Industries: cotton lint, beverages, agricultural
processing, soap, cigarettes, textiles, gold
Industrial production growth rate: 4.2% (1995)
Electricity - production: 225 million kWh (1998)
Electricity - production by source:
fossil fuel: 64.44%
hydro: 35.56%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 209 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: peanuts, shea nuts,
sesame, cotton, sorghum, millet, corn, rice; livestock
Exports: $311 million (f.o.b., 1998 est.)
78
Burkina Faso (continued)
Exports - commodities: cotton, animal products,
gold
Exports - partners: Cote d''Ivoire, Taiwan, France,
Coiombia, Italy, Mali
Imports: $572 miliion (f.o.b., 1998 est.)
Imports - commodities: machinery, food products,
petroleum
Imports - partners: Cote d''Ivoire, France, Senegal,
Togo, Nigeria, US
Debt - external: $1.3biliion(19g7)
Economic aid - recipient: $484.1 million (1995)
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiere Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
615.70 (1999), 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
note: since 1 January 1 999, the CFAF franc is pegged
to the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
|~~ C 0 m"m u h i c a t i o n s
Telephones - main lines in use: 30,000 (1995)
Telephones - mobile cellular: 0 (1995)
Telephone system: all services only fair
domestic: microwave radio relay, open wire, and
radiotelephone communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 17, shortwave
1 (1998)
Radios: 370,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 100,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Economy - overview: One of the 20 poorest
countries in the world, Guinea-Bissau depends mainly
on farming and fishing. Cashew crops have increased
remarkably in recent years, and the country now ranks
sixth in cashew production. Guinea-Bissau exports
fish and seafood along with small amounts of peanuts,
palm kernels, and timber. Rice is the major crop and
staple food. However, intermittent fighting between
Senegalese-backed government troops and a military
junta destroyed much of the country''s infrastructure
and caused widespread damage to the economy in
1 998; the civil war led to a 28% drop in GDP that year,
with partial recovery in 1999. Before the war, trade
reform and price liberalization were the most
successful part of the country''s structural adjustment
program under IMF sponsorship. The tightening of
monetary policy and the development of the private
sector had also begun to reinvigorate the economy.
Because of high costs, the development of petroleum,
phosphate, and other mineral resources is not a
near-term prospect. However, unexploited off-shore
oil reserves could provide much-needed revenue in
the long run.
GDP: purchasing power parity- $1.1 billion
(1999 est.)
GDP - real growth rate; 9.5% (1999 est.)
GDP - per capita: purchasing power parity - $900
(1999 est.)
GDP - composition by sector;
agriculture: 54%
industry: 11%
services: 35% (1 996 est.)
Population below poverty line: 50% (1991 est.)
Household income or consumption by percentage
share;
lowest 10%: 0.5%
highest 10%; 42.4% (1991)
Inflation rate (consumer prices): 5.5% (1999)
Labor force: 480,000
Labor force - by occupation; agriculture 78%
Unemployment rate: NA%
Budget: $NA
Industries: agricultural products processing, beer,
soft drinks
Industrial production growth rate; 2.6%
(1997 est.)
Electricity - production: 40 million kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%{mB)
Electricity - consumption: 37 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: rice, corn, beans, cassava
(tapioca), cashew nuts, peanuts, palm kernels, cotton;
timber; fish
Exports: $26.8 million (f.o.b., 1998)
Exports - commodities: cashew nuts 70%, shrimp,
peanuts, palm kernels, sawn lumber (1996)
Exports - partners: India 59%, Singapore 1 2%, Italy
10% (1997)
Imports: $22.9 million (f.o.b., 1998)
Imports - commodities; foodstuffs, machinery and
transport equipment, petroleum products (1996)
Imports - partners: Portugal 26%, France 8%,
Senegal 8%, Netherlands 7% (1997)
Debt - external: $921 million (1997 est.)
Economic aid - recipient; $1 1 5.4 million (1 995)
Currency: 1 Communaute Financiers Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
615.70 (1999), 589.95 (1998), 583.67 (1997);
Guinea-Bissauan pesos (PG) per US$1 - 26,373
(1996), 18,073(1995)
note: as of 1 May 1997, Guinea-Bissau adopted the
CFA franc as the national currency following its
membership in BCEAO; since 1 January 1999, the
CFAF is pegged to the euro at a rate of 655.957 CFA
francs per euro
Fiscal year: calendar year
Economy - overview: This small poor island
economy has become increasingly dependent on
cocoa since independence 25 years ago. However,
cocoa production has substantially declined because
of drought and mismanagement. The resulting
shortage of cocoa for export has created a persistent
balance-of-payments problem. Sao Tome has to
import all fuels, most manufactured goods, consumer
goods, and a significant amount of food. Over the
years, it has been unable to service its external debt
and has had to depend on concessional aid and debt
rescheduling. Considerable potential exists for
development of a tourist industry, and the government
has taken steps to expand facilities in recent years.
The government also has attempted to reduce price
controls and subsidies, but economic growth has
remained sluggish. Sao Tome is also optimistic that
significant petroleum discoveries are forthcoming in
its territorial waters in the oil-rich waters of the Gulf of
Guinea. Corruption scandals continue to weaken the
GDP: purchasing power parity - $1 69 million
(1999 est.)
GDP - real growth rate: 1 .5% (1 999 est.)
GDP - per capita: purchasing power parity - $1 ,1 00
(1999 est.)
GDP - composition by sector:
agriculture: 23%
industry: 19%
senrices: 58% (1 997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 10.5% (yearend
1999 est.)
Labor force: NA
Labor force - by occupation: population mainly
engaged in subsistence agriculture and fishing
note: shortages of skilled workers
Unemployment rate: 50% in the formal business
sector (1998 est.)
Budget:
revenues: $58 million
expenditures: $1U million, including capital
expenditures of $54 million (1993 est.)
Industries: light construction, textiles, soap, beer;
fish processing; timber
Industrial production growth rate: NA%
Electricity - production: 1 5 million kWh (1 998)
Electricity - production by source:
fossil fuel: 46.67%
hydro: 53.33%
nuclear: 0%
often 0% (1998)
Electricity - consumption: 14 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cocoa, coconuts, palm
kernels, copra, cinnamon, pepper, coffee, bananas,
papayas, beans; poultry; fish
Exports: $4.9 million (f.o.b., 1999 est.)
Exports - commodities: cocoa 90%, copra, coffee,
palm oil (1997)
Exports - partners: Netherlands 51%, Germany
6%, Portugal 6% (1997)
Imports: $19.5 million (f.o.b., 1999 est.)
Imports - commodities: machinery and electrical
equipment, food products, petroleum products
Imports - partners: Portugal 26%, France 18%,
Angola, Belgium, Japan (1997)
Debt - external: $274 million (1998)
Economic aid • recipient: $57.3 million (1995)
Currency: 1 dobra (Db) = 100 centimos
Exchange rates: dobras (Db) per US$1 - 7,200.0
(October 1999), 7,104.05 (1998), 4,552.5 (1997),
2,203,2 (1996), 1,420,3(1995)
Fiscal year: calendar year
Economy - overview: This is an oil-based economy
with strong government controls over major economic
activities. Saudi Arabia has the largest reserves of
petroleum in the world (26% of the proved total), ranks
as the largest exporter of petroleum, and plays a
leading role in OPEC. The petroleum sector accounts
for roughly 75% of budget revenues, 40% of GDP, and
90% of export earnings. About 35% of GDP comes
from the private sector. Roughly 4 million foreign
workers play an important role in the Saudi economy,
for example, in the oil and service sectors. Saudi
Arabia was a key player in the successful efforts of
OPEC and other oil producing countries to raise the
price of oil in 1999 to its highest level since the Gulf
War by reducing production. Although oil prices are
expected to remain relatively high in 2000, Riyadh
expects to have a $7.5 billion budget deficit in part
because of increased spending for education and
other social problems. The government in 1999
announced plans to begin privatizing the electricity
companies, which follows the ongoing privatization of
the telecommunications company. The government is
expected to continue calling for private sector growth
to lessen the kingdom''s dependence on oil and
increase employment opportunities for the swelling
Saudi population. Shortages of water and rapid
population growth will constrain government efforts to
increase self-sufficiency in agricultural products.
GDP: purchasing power parity - $1 91 billion
(1999 est.)
GDP - real growth rate: 1 .6% (1 999 est.)
GDP - per capita: purchasing power parity - $9,000
(1999 est.)
GDP - composition by sector:
agriculture: 6%
Industry: 47%
services: 47% (1 998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -1 .2% (1 999)
Labor force; 7 million
note: 35% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force - by occupation: agriculture 1 2%,
industry 25%, services 63% (1999 est.)
Unemployment rate: NA%
Budget:
revenues: $41 .9 billion
expenditures: $49.4 billion, including capital
expenditures of $NA (2000 est.)
Industries: crude oil production, petroleum refining,
basic petrochemicals, cement, construction, fertilizer,
plastics
Industrial production growth rate: 1% (1997 est.)
Electricity - production: 1 1 0. 1 32 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity • consumption: 1 02.423 billion kWh
(1998)
Electricity ■ exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: wheat, barley, tomatoes,
melons, dates, citrus; mutton, chickens, eggs, milk
Exports: $48 billion (f.o.b., 1999)
Exports - commodities; petroleum and petroleum
products 90%
Exports - partners: Japan 17%, US 15%, South
Korea 11%, Singapore 8%, India 4%, France 4%
(1998)
Imports: $28 billion (f.o.b., 1999)
Imports - commodities: machinery and equipment,
foodstuffs, chemicals, motor vehicles, textiles
Imports - partners: US 21%, UK 9%, Japan 9%,
Germany 6%, France 5%, Italy 4% (1998)
Debt - external: $28 billion (1998 est.)
Economic aid - donor; pledged $100 million in
1993 to fund reconstruction of Lebanon; since 1993,
Saudi Arabia has committed $208 million for
assistance to the Palestinians
Currency: 1 Saudi riyal (SR) = 100 halalah
Exchange rates: Saudi riyals (SR) per US$1 -
3.7450 (fixed rate since June 1986)
Fiscal year: calendar year','12132eb53d4931dd77c2390eace7af2cba94c8c93bca938c47f313d357b4de52','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d4aeab9264dc3644bb1f757a1bea4c454a23df20e3af81a29cf3b6e70a2af8c',2000,'US','United States','economy',108,'Economy - overview: As an affluent, high-tech
industrial society, Canada today closely resembles
the US in its market-oriented economic system,
pattern of production, and high living standards. Since
World War II, the impressive growth of the
manufacturing, mining, and service sectors has
transformed the nation from a largely rural economy
into one primarily industrial and urban. Real rates of
growth have averaged nearly 3.0% since 1993.
Unemployment is falling and government budget
surpluses are being partially devoted to reducing the
large public sector debt. The 1989 US-Canada Free
Trade Agreement (FTA) and 1994 North American
Free Trade Agreement (NAFTA) (which included
Mexico) have touched off a dramatic increase in trade
and economic integration with the US. With its great
natural resources, skilled labor force, and modern
capital plant Canada enjoys solid economic
prospects. Two shadows loom, the first being the
continuing constitutional impasse between English-
and French-speaking areas, which has been raising
the possibility of a split in the federation. Another
long-term concern is the flow south to the US of
professional persons lured by higher pay, lower taxes,
and the immense high-tech infrastructure.
GDP: purchasing power parity - $722.3 billion
(1999 est.)
GDP - real growth rate: 3.6% (1999 est.)
GDP - per capita: purchasing power parity - $23,300
(1999 est.)
GDP - composition by sector:
agriculture: 3%
industry: 3t%
services: QQ% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.8%
highest 10%.- 23.8% (1994)
Inflation rate (consumer prices): 1 .7% (1999)
Labor force: 1 5.9 million (1 999)
Labor force - by occupation: services 75%,
manufacturing 16%, construction 5%, agriculture 3%,
other 1% (1997)
Unemployment rate: 7.6% (1999)
Budget:
reverrues; $121 .8 billion
expenditures: $115.1 billion, including capital
expenditures of $1.7 billion (1998)
Industries: processed and unprocessed minerals,
food products, wood and paper products,
transportation equipment, chemicals, fish products,
petroleum and natural gas
Industrial production growth rate: 4.3%
(1999 est.)
Electricity - production: 550.852 billion kWh (1 998)
Electricity ■ production by source:
fossil fuel: 27.18%
hydro: 59.77%
nuclear: 12.25%
other; 0.8% (1998)
Electricity - consumption: 484.515 billion kWh
(1998)
Electricity - exports: 39.502 billion kWh (1998)
Electricity - imports: 1 1 .725 billion kWh (1 998)
Agriculture - products: wheat, barley, oilseed,
tobacco, fruits, vegetables; dairy products; forest
products; fish
Exports: $277 billion (f.o.b., 1999 est.)
Exports - commodities: motor vehicles and parts,
newsprint, wood pulp, timber, crude petroleum,
machinery, natural gas, aluminum,
telecommunications equipment, electricity
Exports - partners: US 84%, Japan 3%, UK,
Germany, South Korea, Netherlands, China (1998)
Imports: $259.3 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment,
crude oil, chemicals, motor vehicles and parts,
durable consumer goods, electricity
Imports - partners: US 77%, Japan 3%, UK,
Germany, France, Mexico, Taiwan, South Korea
(1998)
Debt -external: $253 billion (1996)
Economic aid - donor: ODA, $2.1 billion (1997)
Currency: 1 Canadian dollar (Can$) = 100 cents
Exchange rates: Canadian dollars (Can$) per
US$1 - 1 .4489 (January 2000), 1 .4857 (1 999), 1 .4835
(1998), 1.3846 (1997), 1.3635 (1996), 1.3724 (1995)
Fiscal year: 1 April - 31 March
90
Canada (continued)
Communtcations
Telephones - main lines in use; 1 8.5 million (1999)
Telephones - mobile cellular; 3 million (1999)
Telephone system; excellent service provided by
modem technology
domestic: domestic satellite system with about 300
earth stations
international: 5 coaxial submarine cables; satellite
earth stations - 5 Intelsat (4 Atlantic Ocean and 1
Pacific Ocean) and 2 Intersputnik (Atlantic Ocean
region)
Radio broadcast stations; AM 535, FM 53,
shortwave 6 (1998)
Radios; 32.3 million (1997)
Television broadcast stations; 80 (plus many
repeaters) (1997)''
Televisions; 21.5 million (1997)
Internet Service Providers (ISPs); 750 (1999 est.)
I T r a n s p 0 rl a t i 0 n
Railways;
total: 36,1 14 km; note - there are two major
transcontinental freight railway systems: Canadian
National (privatized November 1995) and Canadian
Pacific Railway; passenger service provided by
government-operated firm VIA, which has no trackage
of its own
standard gauge: A km 1.435-m gauge (156 km
electrified) (1998)
Highways;
fofa/;901,902km
paved; 31 8,371 km (including 16,571 km of
expressways)
unpaved; 583,531 km (1999 est.)
Waterways; 3,000 km, including Saint Lawrence
Seaway
Pipelines; crude and refined oil 23,564 km; natural
gas 74,980 km
Ports and harbors; Becancour (Quebec), Churchill,
Halifax, Hamilton, Montreal, New Westminster, Prince
Rupert, Quebec, Saint John (New Brunswick), St.
John''s (Newfoundland), Sept Isles, Sydney,
Trois-Rivieres, Thunder Bay, Toronto, Vancouver,
Windsor
Merchant marine;
total: 114 ships (1 ,000 GRT or over) totaling
1,602,275 GRT/2, 371,146 DWT
ships by type: barge carrier 1 , bulk 61 , cargo 1 1 ,
chemical tanker 5, combination bulk 2, passenger 3,
passenger/cargo 1, petroleum tanker 16, rail car
carrier 2, roll-on/roll-off 8, short-sea passenger 3,
specialized tanker 1 (1999 est.)
note: does not include ships used exclusively in the
Great Lakes (1998 est.)
Airports; 1,411 (1999 est.)
Airports - with paved runways;
total: 5t5
over 3,047 m:
2,438 to 3,047 m:M
1,524 to 2,437 m:tb2
I n t r 0 d u c t i o n
Background; The uninhabited islands were
discovered and colonized by the Portuguese in the
1 5th century; they subsequently became a trading
center for African slaves. Most Cape Verdeans
descend from both groups. Independence was
achieved in 1975.
.
Location; Western Africa, group of islands in the
North Atlantic Ocean, west of Senegal
Geographic coordinates; 1 6 00 N, 24 00 W
Map references; World
Area;
total: 4,033 sq km
land: 4,033 sq km
water: 0 sq km
Area ■ comparative; slightly larger than Rhode
Island
Land boundaries; 0 km
Coastline; 965 km
Maritime claims; measured from claimed
archipelagic baselines
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; temperate; warm, dry summer; precipitation
meager and very erratic
Terrain; steep, rugged, rocky, volcanic
Elevation extremes;
/owes? po/hf; Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on Fogo
Island)
Natural resources; salt, basalt rock, pozzuolana (a
siliceous volcanic ash used to produce hydraulic
cement), limestone, kaolin, fish
Land use;
arable land: 11%
permanent crops: 0%
permanent pastures: 6%
914 to 1,523 m: 240
under 914 m: 90 (1 999 est.)
Airports - with unpaved runways;
total: 8%
1,524 to 2,437 m: 73
914 to 1,523 m: 362
under 914 m: 461 (1 999 est.)
Heliports; 15 (1999 est.)
I Military
Military branches; Canadian Forces (includes Land
Forces Command or LC, Maritime Command or MC,
Air Command or AC, Communications Command or
CC, Training Command orTC), Royal Canadian
Mounted Police (RCMP)
Military manpower - military age; 17 years of age
Military manpower - availability;
males age 15-49: 8,282,846 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 7,086,335 (2000 est.)
Military manpower - reaching military age
annually;
mates; 212,701 (2000 est.)
Military expenditures - dollar figure; $7.4 billion
(FY97/98)
Military expenditures - percent of GDP; 1 .2%
(FY97/98)
I Tran s^a t i o h a I Issues
Disputes - international; maritime boundary
disputes with the US (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island)
Illicit drugs; illicit producer of cannabis for the
domestic drug market; use of hydroponics technology
permits growers to plant large quantities of
high-quality marijuana indoors; growing role as a
transit point for heroin and cocaine entering the US
market
91
Cape Verde (continued)
forests and woodland: 0%
often 83% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: prolonged droughts; harmattan
wind can obscure visibility; volcanically and
seismically active
Environment - current issues: overgrazing of
livestock and improper land use such as the
cultivation of crops on steep slopes has led to soil
erosion; demand for wood used as fuel has resulted in
deforestation; desertification; environmental damage
has threatened several species of birds and reptiles;
overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location 500 km from
west coast of Africa near major north-south sea
routes; important communications station; important
sea and air refueling site
j People
Population: 401 ,343 (July 2000 est.)
Age structure:
0-14 years: 44% (male 88,202; female 86,630)
15-64 years: 50% (male 95,079; female 105,928)
65 years and over: 6% (male 1 0,043; female 1 5,461 )
(2000 est.)
Population growth rate: 0.98% (2000 est.)
Birth rate: 29.67 births/1 ,000 population (2000 est.)
Death rate: 7.38 deaths/1 ,000 population
(2000 est.)
Net migration rate: -12.49 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate: 54.58 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 58.01 years
male: 65.63 years
female: 72.29 years (2000 est.)
Total fertility rate: 4.19 children born/woman
(2000 est.)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1%
Religions: Roman Catholic (infused with indigenous
beliefs); Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crioulo (a blend of
Portuguese and West African words)
Literacy:
definition: age 15 and over can read and write
total population: 71 .6%
male: 81 .4%
female: 63.8% (1995 est.)','0a6914ce6c9ff6c24d6418cbc5a6e8d5aa3086bda6ad55628e0a16e1a3f8383c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7992fbe9a7cdb6f3b4f75d6d2839596bba4292aec9874f27cc29d81f7c54e1db',2000,'PT','Portugal','economy',110,'Economy - overview: Cape Verde''s low per capita
GDP reflects a poor natural resource base. Including
serious water shortages exacerbated by cycles of
long-term drought. The economy is service-oriented,
with commerce, transport, and public sen/ices
accounting for almost 70% of GDP. Although nearly
70% of the population lives in rural areas, the share of
agriculture in GDP in 1998 was only 13%, of which
fishing accounts for 1 .5%. About 90% of food must be
imported. The fishing potential, mostly lobster and
tuna. Is not fully exploited. Cape Verde annually runs
a high trade deficit, financed by foreign aid and
remittances from emigrants; remittances constitute a
supplement to GDP of more than 20%. Economic
reforms, launched by the new democratic government
In 1991 , are aimed at developing the private sector
and attracting foreign investment to diversify the
economy. Prospects for 2000 depend heavily on the
maintenance of aid flows, remittances, and the
momentum of the government''s development
program.
GDP; purchasing power parity - $618 million
(1999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,500
(1999 est.)
92
Cap0 Verde (continued)
GDP - composition by sector;
agriculture: 13%
industry: W/o
serv/ces; 68% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 5% (1999)
Labor force; NA
Unemployment rate: NA%
Budget:
revenues; $188 million
expenditures: %22B million, including capital
expenditures of $1 1 6 miliion (1 996)
Industries: food and beverages, fish processing,
shoes and garments, salt mining, ship repair
Industrial production growth rate: NA%
Electricity - production: 40 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity • consumption: 37 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture • products: bananas, corn, beans,
sweet potatoes, sugarcane, coffee, peanuts; fish
Exports; $38 million (f.o.b., 1999 est.)
Exports ■ commodities: fuel, shoes, garments, fish,
bananas, hides
Exports - partners; Portugal, Germany, Spain,
France, UK, Malaysia
Imports: $225 million (f.o.b., 1999 est.)
Imports - commodities: foodstuffs, industrial
products, transport equipment, fuels
Imports - partners: Portugal, Netherlands, France,
UK, Spain, US
Debt - external; $220 million (1998)
Economic aid - recipient; $1 1 1 .3 million (1995)
Currency: 1 Cape Verdean escudo (CVEsc) = 100
centavos
Exchange rates: Cape Verdean escudos (CVEsc)
per US$1 - 107.280 (December 1999), 102.700
(1999), 98.158 (1998), 93.177 (1997), 82.591 (1996),
76.853 (1995)
Fiscal year: calendar year
f C 0 m m u tTi c a t i 0 n s
Telephones - main lines in use: 22,000 (1995)
Telephones - mobile cellular: 0 (1 995)
Telephone system:
domestic: interisland microwave radio relay system
with both analog and digital exchanges; work Is in
progress on a submarine fiber-optic cable system
which was scheduled for completion in 1998
international: 2 coaxial submarine cables; HF
radiotelephone to Senegal and Guinea-Bissau;
satellite earth station - 1 1ntelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 6, shortwave
0(1998)
Radios: 73,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 2,000(1997)
Internet Service Providers (ISPs); NA
I™ f r a rTs p 0 r t aTTo n
Railways: 0 km
Highways;
total: 1,100 km
paved: 858 km
unpaved: 242 km (1996 est.)
Ports and harbors; Mindelo, Praia, Tarrafal
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 9,523 GRT/
11,795 DWT
ships by type: cargo 4, chemical tanker 1 (1999 est.)
Airports: 6 (1999 est.)
Airports - with paved runways:
total: 6
over 3,047 m:1
914 to 1,523 m; 5 (1999 est.)
|r~ Milifary”
Military branches; single branch that includes both
ground and naval elements
Military manpower - availability:
males age 15-49: 86,675 (2000 est.)
Military manpower • fit for military service:
males age 15-49: 49,069 (2000 est.)
Military expenditures - dollar figure: $4 million
(FY96)
Military expenditures - percent of GDP; 1 .8%
(FY96)
1^ f r a n sITa^t i o n a I I s s u e
Disputes - international: none
Illicit drugs: used as a transshipment point for iiiicit
drugs moving from Latin America and Africa destined
for Western Europe
[Cayman islands
( (overseas territory
ioftheUK)
Caribbean
Sea
Grand
Cayman
GEORGETOWN
Little
Cayman
Cayman
Brae
Intro d u c t i on
Background: The Cayman Islands were colonized
from Jamaica by the British during the 18th and 19th
centuries. Administered by Jamaica from 1863, they
remained a British dependency after 1962 when the
former became independent.
”6 e 0 g r a p
Location: Caribbean, island group in Caribbean
Sea, nearly one-half of the way from Cuba to
Imports: $66 million (c.i.f., 1997 est.)
424
Saint Pierre and Miqueion (continued)
Imports - commodities; meat, clothing, fuel,
electrical equipment, machinery, building materials
Imports - partners: Canada, France, US,
Netherlands, UK
Debt - external: $NA
Economic aid - recipient: approximately $65
million in annual grants from France
Currency: 1 French franc (F) = 100 centimes
Exchange rates: euros per US$1 - 0.98673
(January 2000), 0.93863 (1999); French francs (F) per
US$1 - 5.65 (January 1999), 5.8995 (1998), 5.8367
(1997), 5.1155 (1996), 4.9915 (1995)
Fiscal year: calendar year
I Communications
Telephones ■ main lines in use: 4,000 (1994)
Telephones ■ mobile cellular; 0 (1 994)
Telephone system:
domestic: NA
international: radiotelephone communication with
most countries in the world; 1 earth station in French
domestic satellite system
Radio broadcast stations: AM 1 , FM 4, shortwave
0(1998)
Radios; 4,000(1997)
Television broadcast stations: 0 (there are,
however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions: 4,000(1997)
Internet Service Providers (ISPs): NA
I transportation
Railways: 0 km
Highways;
fofa/;114km
paved: 69 km
unpaved: 45 km (1994 est.)
Ports and harbors: Saint Pierre
Merchant marine; none (1999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways;
total: 2
1,524 to 2,437 m:-\\
914to 1,523 m:1 (1999 est.)
I Military
Military - note: defense is the responsibiiity of','bebe32906177d285d152d60ffdaff18c5e6aa0d4c290a0719db66bde9850124f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05c6422345ac6d13136ee21977f43da9e0fdb6c39a33c43d06e2be84b1f6bbd5',2000,'HN','Honduras','economy',111,'Geographic coordinates: 1 9 30 N, 80 30 W
Map references; Central America and the
Caribbean
Area:
total: 259 sq km
land: 259 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 160 km
Maritime claims;
exclusive fishing zone: 200 nm
femfor/a/sea;12nm
Climate: tropical marine; warm, rainy summers (May
to October) and cool, relatively dry winters (November
to April)
Terrain: low-lying limestone base surrounded by
coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff 43 m
Natural resources: fish, climate and beaches that
foster tourism
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 23%
other; 69% (1993 est.)
93
Cayman Islands (continued)
Irrigated land; NAsqkm
Natural hazards: hurricanes (July to November)
Environment - current issues: no natural fresh
water resources; drinking water supplies must be met
by rainwater catchment
Geography - note: important location between
Cuba and Central America
Economy - overview: With no direct taxation, the
islands are a thriving offshore financial center. More
than 40,000 companies were registered in the
Cayman Islands as of 1997, including almost 600
banks and trust companies; banking assets exceed
$500 billion. A stock exchange was opened in 1997.
T ourism is also a mainstay, accounting for about 70%
of GDP and 75% of foreign currency earnings. The
tourist industry is aimed at the luxury market and
caters mainly to visitors from North America. Total
tourist arrivals exceeded 1.2 million visitors in 1997.
About 90% of the islands'' food and consumer goods
must be imported. The Caymanians enjoy one of the
highest outputs per capita and one of the highest
standards of living in the world.
GDP: purchasing power parity - $930 million
(1997 est.)
GDP - real growth rate: 5% (1997 est.)
GDP - per capita: purchasing power parity - $24,500
(1997 est.)
GDP - composition by sector:
agriculture: 1 .4%
industry: 3.2%
services: 95.4% (1994 est.)
Population below poverty line; NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (1998)
Labor force: 1 9,820 (1 995)
Labor force - by occupation: agriculture 1 .4%,
industry 12.6%, services 86% (1995)
Unemployment rate: 5.1% (1996)
Budget:
revenues: $265.2 million
expenditures: $246.9 million, including capital
expenditures of $NA (1997)
Industries: tourism, banking, insurance and finance,
construction, construction materials, furniture
Industrial production growth rate: NA%
Electricity • production: 290 million kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1996)
Electricity - consumption: 270 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: vegetables, fruit; livestock,
turtle farming
Exports: $2.17 million (1997)
Exports - commodities: turtle products,
manufactured consumer goods
Exports - partners: mostly US
Imports: $432 million (1997)
Imports - commodities: foodstuffs, manufactured
goods
Imports - partners: US, Trinidad and Tobago, UK,
Netherlands Antilles, Japan
Debt - external: $70 million (1996)
Economic aid ■ recipient; $NA
Currency: 1 Caymanian dollar (Cl$) = 100 cents
Exchange rates: Caymanian dollars (Cl$) per US$1
- 0.83 (3 November 1995), 0.85 (22 November 1993)
Fiscal year: 1 April - 31 March
Economy - overview: Subsistence agriculture,
together with forestry, remains the backbone of the
economy of the Central African Republic (CAR), with
more than 70% of the population living in outlying
areas. The agricultural sector generates half of GDP.
Timber has accounted for about 16% of export
earnings and the diamond industry for nearly 54%.
Important constraints to economic development
include the CAR''s landlocked position, a poor
transportation system, a largely unskilled work force,
and a legacy of misdirected macroeconomic policies.
The 50% devaluation of the currencies of 14
Francophone African nations on 1 2 January 1 994 had
mixed effects on the CAR''s economy. Diamond,
timber, coffee, and cotton exports increased, leading
an estimated rise of GDP of 7% in 1 994 and nearly 5%
in 1995. Military rebellions and social unrest in 1996
were accompanied by widespread destruction of
property and a drop in GDP of 2%. Ongoing violence
between the government and rebel military groups
over pay issues, living conditions, and political
representation has destroyed many businesses in the
capital and reduced tax revenues for the government.
The IMF approved an Extended Structure Adjustment
Facility in 1998. The government has set targets of
annual 5% growth and 2.5% inflation for 2000-2001 .
GDP: purchasing power parity - $5.8 billion (1 999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,700
(1999 est.)
GDP - composition by sector:
agriculture: 53%
industry: 2)%
sen/ices: 26% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.6% (1999 est.)
Labor force: NA
Unemployment rate: 6% (1993)
Budget:
revenues: $638 million
expenditures: $1 .9 billion, including capital
expenditures of $888 million (1994 est.)
Industries: diamond mining, sawmills, breweries,
textiles, footwear, assembly of bicycles and
motorcycles
Industrial production growth rate: NA%
Electricity - production: 105 million kWh (1998)
Electricity - production by source:
fossil fuel: 19.05%
hydro: 80.95%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 98 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cotton, coffee, tobacco,
manioc (tapioca), yams, millet, corn, bananas; timber
Exports: $195 million (f.o.b., 1999)
Exports - commodities: diamonds, timber, cotton,
coffee, tobacco
Exports - partners: Benelux 36%, Cote d''Ivoire 5%,
Spain 4%, Egypt 3%, France (1997)
Imports: $170 million (f.o.b., 1999)
Imports - commodities: food, textiles, petroleum
products, machinery, electrical equipment, motor
vehicles, chemicals, pharmaceuticals, consumer
goods, industrial products
Imports - partners: France 30%, Cote d''Ivoire 1 8%,
Cameroon 11%, Germany 4%, Japan (1997)
Debt - external: $790 million (1999 est.)
Economic aid - recipient: $172.2 million (1995);
note - traditional budget subsidies from France
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiere Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
96
Central African Republic (continued)
615.70 (1999), 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
note: since 1 January 1 999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: caiendar year
I ”C 0 m rnli n [cations
Telephones - main lines in use: 8,000 (1995)
Telephones - mobile cellular: 79 (1995)
Telephone system: fair system
domestic: network consists principaiiy of microwave
radio relay and low-capacity, low-powered
radiotelephone communication
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 1 , FM 3, shortwave
1 (1998)
Radios: 283,000(1997)
Television broadcast stations: NA
Televisions: 18,000(1997)
Internet Service Providers (ISPs): NA
I ~ T r alTs p o r t a t Vo iT
Railways: 0 km
Highways:
fofa/; 23,81 0 km
paved: 429 km
unpaved: 23,381 km (1998 est.)
Waterways: 800 km; traditional trade carried on by
means of shallow-draft dugouts; Oubangui is the most
important river
Ports and harbors: Bangui, Nola
Airports: 52 (1999 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m: 2 {1999 est.)
Airports - with unpaved runways:
total: 49
2,438 to 3,047 m:1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 91 4 m: 15 (1999 est.)
I M i [i t a r y
Military branches: Central African Armed Forces
(includes Republican Guard and Air Force),
Presidential Guard, National Gendarmerie, Police
Force
Military manpower - availability:
males age 15-49: 804,941 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 420,619 (2000 est.)
Military expenditures - dollar figure: $29 million
(FY96)
Military expenditures - percent of GDP: 2.2%
(FY96)
f~f r a n s nali o n a I Issues
Disputes - international: none
Background: Chad, part of France''s African
holdings until 1960, endured three decades of ethnic
warfare as well as invasions by Libya before a
semblance of peace was finally restored in 1 990. A
transitional government eventually suppressed or
came to terms with most political-military groups,
settled a territorial dispute with Libya on terms
favorable to Chad, drafted a democratic constitution,
and held multiparty presidential and National
Assembly elections in 1996 and 1997 respectively. In
1998 a new rebellion broke out in northern Chad,
which continued to escalate throughout 1 999. Despite
movement toward democratic reform, power remains
in the hands of a northern ethnic oligarchy.
f"''" " "Geography ■''
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total: 1 .284 million sq km
/and; 1,259,200 sq km
wafer; 24,800 sqkm
Area - comparative: slightly more than three times
the size of California
Land boundaries:
total: 5,968 km
border countries: Cameroor\\ 1,094 km. Central
African Republic 1,197 km, Libya 1,055 km, Niger
1 ,1 75 km, Nigeria 87 km, Sudan 1 ,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north,
mountains in northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but
exploration under way), uranium, natron, kaolin, fish
(Lake Chad)
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 36%
forests and woodland: 26%
of/)er;35%(1993 est.)
Irrigated land: 1 40 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan winds
occur in north; periodic droughts; locust plagues
Environment - current issues: inadequate
supplies of potable water; improper waste disposal in
rural areas contributes to soil and water pollution;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography - note: landlocked; Lake Chad is the
most significant water body in the Sahel
P e 0 pie
Population: 8,424,504 (July 2000 est.)
Age structure:
0-14 years: 48% (male 2,022,339; female 1 ,994,978)
15-64 years: 49% (male 1,964,216; female
2,204,902)
65 years and over: 3% (male 99,459; female
138,610) (2000 est.)
Population growth rate: 3.31% (2000 est.)
Birth rate: 48.81 births/1,000 population (2000 est.)
Death rate: 15.71 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.89 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 96.66 deaths/1 ,000 live births
(2000 est.)
97
Chad (continued)
Life expectancy at birth:
total population: 50.49 years
male: 48.5 years
female: 52.56 years (2000 est.)
Total fertility rate: 6.63 children born/woman
(2000 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Muslims, commonly referred to as
"northerners" or "gorane" (Arabs, Toubou, Hadjerai,
Fulbe, Kotoko, Kanembou, Baguirmi, Boulala,
Zaghawa, and Maba); non-Muslims, commonly
referred to as "southerners" (Sara, Ngambaye,
Mbaye, Goulaye, Moundang, Mousse!, Massa)
including nonindigenous 150,000 (of whom 1,000 are
French)
note: ethnicity and regional background more
commonly used to identify Chadians than religious
affiliation
Religions: Muslim 50%, Christian 25%, indigenous
beliefs (mostly animism) 25%
Languages: French (official), Arabic (official), Sara
and Sango (in south), more than 100 different
languages and dialects
Literacy:
definition: age 1 5 and over can read and write French
or Arabic
total population: iSAVa
male: 62,1%
fema/e;34.7%(1995est,)
Economy - overview: Landlocked Chad''s economic
development suffers from it''s geographic remoteness,
drought, lack of infrastructure, and political turmoil.
About 85% of the population depends on agriculture,
including the herding of livestock. Of Africa''s
Francophone countries, Chad benefited least from the
50% devaluation of their currencies in January 1994.
Financial aid from the World Bank, the African
Development Fund, and other sources is directed
largely at the improvement of agriculture, especially
livestock production. Due to lack of financing, the
development of the Doba Basin oil fields, originally
due to finish in 2000, has been substantially delayed.
GDP: purchasing power parity - $7.6 billion
(1999 est.)
GDP - real growth rate: 0.6% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,000
(1999 est.)
GDP - composition by sector:
agriculture: 38%
industry: 14%
serv/ces; 48% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 12% (1998 est.)
Labor force: NA
Labor force • by occupation: agriculture 85%
(subsistence farming, herding, and fishing)
Unemployment rate: NA%
Budget:
reverrues; $198 million
expenditures: $218 million, including capital
expenditures of $146 million (1998 est.)
Industries: cotton textiles, meat packing, beer
brewing, natron (sodium carbonate), soap, cigarettes,
construction materials
Industrial production growth rate: 5% (1995)
Electricity - production: 100 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 93 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cotton, sorghum, millet,
peanuts, rice, potatoes, manioc (tapioca); cattle,
sheep, goats, camels
Exports: $288 million (f.o.b., 1999 est.)
Exports - commodities: cotton, cattle, textiles
Exports - partners: Portugal 30%, Germany 14%,
Thailand, Costa Rica, South Africa, France (1997)
Imports: $359 million (f.o.b., 1999 est.)
Imports - commodities: machinery and
transportation equipment, industrial goods, petroleum
products, foodstuffs, textiles
98
Chad (continued)
Imports - partners: France 41%, Nigeria 10%,
Cameroon 7%, India 6% (1997)
Debt - external: $1 billion (1999 est.)
Economic aid - recipient: $238.3 million (1995);
note - $125 million committed by Taiwan (August
1997); $30 million committed by African Development
Bank
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
Francs (CFAF) per US$1 ■ 647.25 (January 2000),
615.70 (1999), 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
note; since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 5,000 (1995)
Telephones - mobile cellular: 0 (1 995)
Telephone system: primitive system
domesf/c.''fair system of radiotelephone
communication stations
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave
5(1998)
Radios: 1.67 million (1997)
Television broadcast stations: 1 (1997)
Televisions: 10,000(1997)
Internet Service Providers (ISPs): 1 (1999)
t ran s p o r t a 1 1 o n
Railways: 0 km
Highways:
total: 33,400 km
paved: 267 km
unpaved: 33,133 km (1996 est.)
Waterways: 2,000 km navigable
Ports and harbors: none
Airports: 49 (1999 est.)
Airports - with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m:t
914 to 1,523 m:1
under 914 m:1 (1999 est.)
Airports - with unpaved runways:
total: 42
1,524 to 2,437 m: 13
914 to 1,523 m: 19
under 91 4 m: 10 (1999 est.)
I Military
Military branches: Armed Forces (includes Ground
Force, Air Force, and Gendarmerie), Republican
Guard, Rapid Intervention Force, Police, Rural and
Nomadic Guard (GNNT)
Military manpower - miiitary age: 20 years of age
Military manpower - availability:
males age 15-49: 1,749,033 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 915,664 (2000 est.)
Military manpower - reaching military age
annually:
males: 79,596 (2000 est.)
Military expenditures - dollar figure: $39 million
(FY96)
Military expenditures - percent of GDP: 3.5%
(FY96)
I Transnational Issues
6.‘. .
Disputes - international: delimitation of
international boundaries in the vicinity of Lake Chad,
the lack of which led to border incidents in the past,
has been completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria
Background: A three-year-old Marxist government
was overthrown in 1 973 by a dictatorial military regime
led by Augusto PINOCHET, which ruled until a freely
elected president was installed In 1990. Sound
economic policies, first implemented by the
PINOCHET dictatorship, led to unprecedented growth
in 1991-97 and have helped secure the country''s
commitment to democratic and representative
government. Growth slowed in 1998-99, but will likely
recover in 2000.
F g r a p h y
Location: Southern South America, bordering the
South Atlantic Ocean and South Pacific Ocean,
between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area:
total: 756,950 sq km
land: 748,800 sq km
wafer; 8,150 sq km
note: includes Easter Island (Isla de Pascua) and Isla
Sala y Gomez
99
ChilS (continued)
Area - comparative: slightly smaller than twice the
size of Montana
Land boundaries:
total: 6,171 km
border countries: Argentina 5,1 50 km, Bolivia 861 km,
Peru 160 km
Coastline: 6,435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200/350 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; desert in north; Mediterranean
in central region; cool and damp in south
Terrain: low coastal mountains; fertile central valley;
rugged Andes in east
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Cerro Aconcagua 6,962 m
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum, hydropower
Land use:
arable land: 5%
permanent crops: 0%
permanent pastures: 1 8%
forests and woodland: 22%
other; 55% (1993 est.)
Irrigated land: 12,650 sq km (1993 est.)
Natural hazards: severe earthquakes; active
volcanism; tsunamis
Environment ■ current issues: air pollution from
industrial and vehicle emissions; water pollution from
raw sewage
Environment - international agreements:
party to; Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note; strategic location relative to sea
lanes between Atlantic and Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Passage);
Atacama Desert is one of world''s driest regions
[ . pVoTpTe
Population : 1 5, 1 53,797 (July 2000 est.)
Age structure;
0-14 years: 28% (male 2,1 37,826; female 2,044,546)
15-64 years: 65% (male 4,91 9,060; female
4,958,030)
65 years and over: 7% (male 453,234; female
641,101) (2000 est.)
Population growth rate: 1 .17% (2000 est.)
Birth rate: 1 7.1 9 births/1 ,000 population (2000 est.)
Death rate: 5.52 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: QM male(s)/female (2000 est.)
Infant mortality rate: 9.6 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 75.74 years
mate: 72.43 years
female: 79.22 years (2000 est.)
Total fertility rate: 2.2 children born/woman
(2000 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 11%,
Jewish NEGL
Languages; Spanish
Literacy:
definition: age 15 and over can read and write
total population: 95.2%
male: 95.4%
ferr;a/e;95%(1995est.)
|r G 0 V e r n lii e n t
Country name:
conventional long form: Republic of Chile
conventional short form: Chile
local long form: Republica de Chile
local short form: Chile
Data code: Cl
Government type: republic
Capital; Santiago
Administrative divisions; 13 regions (regiones,
singular - region); Aisen del General Carlos Ibanez del
Campo, Antofagasta, Araucania, Atacama, Blo-Blo,
Coquimbo, LIbertador General Bernardo O''Higgins,
Los Lagos, Magallanes y de la Antartica Chllena,
Maule, Region Metropolitana (Santiago), Tarapaca,
Valparaiso
note: the US does not recognize claims to Antarctica
Independence: 18 September 1810 (from Spain)
National holiday: Independence Day, 18
September (1810)
Constitution: 1 1 September 1980, effective 1 1
March 1981; amended 30 July 1 989 and in 1 993
Legal system: based on Code of 1 857 derived from
Spanish law and subsequent codes Influenced by
French and Austrian law; judicial review of legislative
acts In the Supreme Court; does not accept
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
Executive branch;
chief of state: President Ricardo LAGOS Escobar
(since 1 1 March 2000); note - the president is both the
chief of state and head of government
head of government: President Ricardo LAGOS
Escobar (since 1 1 March 2000); note - the president is
both the chief of state and head of government
cabinet: Cabinet appointed by the president
elections: president elected by popular vote for a
six-year term; election last held 12 December 1999,
with runoff election held 16 January 2000 (next to be
held NA December 2005)
election results: Ricardo LAGOS Escobar elected
president; percent of vote - Ricardo LAGOS Escobar
51.32%, Joaquin LAVIN 48.68%
Legislative branch: bicameral National Congress or
Congreso Naclonal consists of the Senate or Senado
(48 seats, 38 elected by popular vote and 10
appointed (all former presidents are senators for life);
members serve eight-year terms - one-half elected
every four years) and the Chamber of Deputies or
Camara de Diputados (120 seats; members are
elected by popular vote to sen/e four-year terms)
elections: Senate - last held 1 1 December 1 997 (next
to be held NA December 2001 ); Chamber of Deputies
- last held 11 December 1997 (next to be held NA
December 2001)
election results: Senate - percent of vote by party -
NA%; seats by party - CPD (PDC 14, PS 4, PPD 2),
UPP 1 7 (RN 7, UD1 1 0), Chile 2000 (UCCP) 1 ,
Independents 10; Chamber of Deputies - percent of
vote by party - CPD 50.55% (PDC 22.98%, PS
11.10%, PPD 12,55%, PRSD3.13%), UPP 36.23%
(RN 16.78%, UD1 14,43%); seats by party - CPD 70
(PDC 39, PPD 16, PRSD 4, PS 1 1), UPP 46 (RN 24,
UDI 21, Party of the South 1), right-wing Independents
4
Judicial branch: Supreme Court or Corte Suprema,
judges are appointed by the president and ratified by
the Senate from lists of candidates provided by the
court itself, the president of the Supreme Court is
elected by the 21 -member court; Constitutional
Tribunal
Political parties and leaders: Chile 2000 - main
party is UCCP [Alejandro GARCIA-HUIDBORO];
Christian Democratic Party or PDC [Gutenberg
MARTINEZ]; Coalition of Parties for Democracy
("Concertacion") or CPD [Eduardo FREI Ruiz-Tagle] -
including PDC, PS, PPD, PRSD; Independent
Democratic Union or UDI [Pablo LONGUEIRAj;
National Renewal','2a4bff61e5ce70e80b43df4c89594b95760c8455133b1c881f2adef1b76d9784','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24ce897062d1938ddae8bd1852cd7d40f5f2c683ab4c2ca75e0290625f473255',2000,'HN','Honduras','economy',112,'or RN [Alberto CARDEMIL]; Party
for Democracy or PPD [Sergio BITAR]; Party of the
South or PS [leader NA]; Progressive Center-Center
Union or UCCP [Francisco Javier ERRAZURIZ];
Radical Social Democratic Party or PRSD [Anselmo
SULE]; Socialist Party or PS [Ricardo NUNEZ]; Union
for the Progress of Chile ("Alliance for Chile") or UPP
[Arturo ALESSANDRI Besa] - including RN and UDI
Political pressure groups and leaders: revitalized
university student federations at all major universities;
Roman Catholic Church; United Labor Central or CUT
includes trade unionists from the country''s five largest
labor confederations
International organization participation: APEC,
CCC, ECLAC, FAO, G-11, G-77, lADB, IAEA, IBRD,
ICAO, ICC, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
100
Chile (continued)
IHO, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC,
lOM, ISO, ITU, LABS, LAIA, Mercosur (associate),
NAM, OAS, OPANAL, OPCW, PCA, RG, UN,
UNCTAD, UNESCO, UNIDO, UNITAR, UNMIBH,
UNMOGIP, UNTSO, UNU, UPU, WCL, WFTU, WHO,
WlPO, WMO, WToO, WTrO
Diplomatic representation in the US;
chief of mission: Ambassador Mario ARTAZA
chancery: M32 Massachusetts Avenue NW,
Washington, DC 20036
te/ephone;[1] (202) 785-1746
FAX; [1] (202) 887-5579
consulate(s) general: Chicago, Houston, Los
Angeles, Miami, New York, Philadelphia, San
Francisco, and San Juan (Puerto Rico)
Diplomatic representation from the US:
chief of mission: Ambassador John O''LEARY
embassy; Avenida Andres Bello 2800, Santiago
mailing address: APO AA 34033
fe/epbone;[56](2) 232-2600
FAX; [56] (2) 330-3710
Flag description; two equal horizontal bands of
white (top) and red; there is a blue square the same
height as the white band at the hoist-side end of the
white band; the square bears a white five-pointed star
in the center; design was based on the US flag
I "” " £"00 n 0 m y
Economy ■ overview: Chile has a market-oriented
economy characterized by a high level of foreign
trade. During the early 1990s, Chile''s reputation as a
role model for economic reform was strengthened
when the democratic government of Patricio AYLWIN
- which took over from the military in 1 990 - deepened
the economic reform initiated by the military
government. Growth in real GDP averaged 8% during
the period 1 991 -1997, but fell to half that level in 1 998
because of tight monetary policies implemented to
keep the current account deficit in check and lower
export earnings - the latter a product of the global
financial crisis. A severe drought exacerbated the
recession in 1999, reducing crop yields and causing
hydroelectric shortfalls and rationing, and Chile
experienced negative economic growth for the first
time in more than 15 years. Despite the effects of the
recession, Chile maintained its reputation for strong
financial institutions and sound policy that have given
It the strongest sovereign bond rating in South
America. By the end of 1999, exports and economic
activity had begun to recover, and a return to strong
growth in 2000 is likely. The inauguration of Ricardo
LAGOS in March 2000, succeeding Eduardo FREI,
will keep the presidency in the hands of the center-left
Concertacion coalition that has held office since the
return of civilian rule in 1990.
GDP: purchasing power parity -$185.1 billion
(1999 est.)
GDP - real growth rate: -1% (1999 est.)
GOP - per capita; purchasing power parity - $1 2,400
(1999 est.)
GDP - composition by sector;
agriculture: 6%
industry: 33%
serv/ces; 61% (1999)
Population below poverty line: 22% (1998 est.)
Household income or consumption by percentage
share;
lowest 10%: t. 2%
highest 10%: At. 3% (im)
Inflation rate (consumer prices): 3.4% (1999 est.)
Labor force; 5.8 million (1999 est.)
Labor force - by occupation: agriculture 14%,
industry 27%, services 59% (1997 est.)
Unemployment rate: 9% (1999)
Budget:
reverrues; $17 billion
expenditures: $17 billion, including capital
expenditures of $NA (1998 est.)
Industries: copper, other minerals, foodstuffs, fish
processing, iron and steel, wood and wood products,
transport equipment, cement, textiles
Industrial production growth rate: -1.3%
(1999 est.)
Electricity - production: 37.49 billion kWh (1999)
Electricity - production by source:
fossil fuel: 50%
hydro: 50%
nuclear: 0%
other: 0% (December 1999)
Electricity - consumption: 26.665 billion kWh
(1998)
Electricity ■ exports: 0 kWh (1998)
Electricity ■ imports: 0 kWh (1998)
Agriculture ■ products; wheat, com, grapes, beans,
sugar beets, potatoes, fruit; beef, poultry, wool; fish;
timber
Exports; $15.6 billion (f.o.b., 1999)
Exports - commodities: copper, fish, fruits, paper
and pulp, chemicals
Exports - partners: EU 27%, US 16%, Japan 14%,
Brazil 6%, Argentina 5% (1998)
Imports: $13.9 billion (c.i.f., 1999)
Imports - commodities; consumer goods,
chemicals, motor vehicles, fuels, electrical machinery,
heavy industrial machinery, food
Imports - partners: US 24%, EU 23%, Argentina
11%, Brazil 6%, Japan 6%, Mexico 5% (1998)
Debt -external; $39 billion (1999)
Economic aid - recipient: ODA, $50.3 million
(1996 est.)
Currency: 1 Chilean peso (Ch$) = 100 centavos
Exchange rates; Chilean pesos (Ch$) per US$1 -
520.45 (January 2000), 508.78 (1999), 460.29 (1998),
419.30 (1997), 412.27 (1996), 396.77 (1995)
Fiscal year: calendar year
I Co nTm u n 1 c a t i^li s
Telephones - main lines in use: 2.603 million
(1998)
Telephones - mobile cellular: 197,300 (1995)
Telephone system: modern system based on
extensive microwave radio relay facilities
domestic: extensive microwave radio relay links;
domestic satellite system with 3 earth stations
International: satellite earth stations - 2 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 180 (eight inactive),
FM 64, shortwave 17 (one inactive) (1998)
Radios: 5.18 million (1997)
Television broadcast stations: 63 (plus 121
repeaters) (1997)
Televisions: 3.15 million (1997)
Internet Service Providers (ISPs): 26 (1999)
I f Fa h s p 0 r t a t fo n
Railways;
total: 6,782 km
broad gauge: 3,743 km 1 .676-m gauge (1 ,653 km
electrified)
narrow gauge: 116 km 1.067-m gauge; 2,923 km
1 .000-m gauge (40 km electrified) (1995)
Highways:
total: 79,800 km
paved; 11,012 km
unpaved: 63,766 km (1996 est.)
Waterways: 725 km
Pipelines: crude oil 755 km; petroleum products 785
km; natural gas 320 km
Ports and harbors; Antofagasta, Arica, Chanaral,
Coquimbo, Iquique, Puerto Montt, Punta Arenas, San
Antonio, San Vicente, Talcahuano, Valparaiso
Merchant marine:
total: 45 ships (1 ,000 GRT or over) totaling 580,749
GRT/860,034 DWT
ships by type: bulk 1 1 , cargo 9, chemical tanker 8,
container 2, liquified gas 2, passenger 3, petroleum
tanker 4, roll-on/roll-off 4, vehicle carrier 2 (1999 est.)
Airports: 370 (1999 est.)
Airports - with paved runways:
total: 62
over 3,047 m: 6
2,438 to 3,047 m: 6
1,524 to 2,437 m: 20
914 to 1,523 m: 20
under 914 m: 10 (1999 est.)
Airports - with unpaved runways:
total: 306
over 3,047 m:1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 12
914 to 1,523 m: 66
under 914 m: 223 (1 999 est.)
I Military
Military branches: Army, Navy (includes Naval Air,
Coast Guard, and Marines), Air Force, Carabineros of
Chile (National Police), Investigations Police
note: normally administered by Ministry of Interior; in
times of national emergency, Carabineros and
Investigations Police are considered part of the
Economy - overview: Phosphate mining had been
the only significant economic activity, but in December
1987 the Australian Government closed the mine. In
1991, the mine was reopened by union workers. With
the support of the government, Australian-based
Casinos Austria International Ltd. built a $34 million
casino on Christmas Island, which opened in 1 993. As
of yearend 1999, gaming facilities at the casino were
temporarily closed but were expected to reopen in
early 2000. Another economic prospect is the possible
location of a space-launching site on the island.
GDP: purchasing power parity - $NA
GDP ■ real growth rate: NA%
GDP ■ per capita: purchasing power parity - $NA
GDP ■ composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force; NA
Labor force - by occupation: tourism 400 people,
mining 100 people (1995)
Unemployment rate; NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: tourism, phosphate extraction (near
depletion)
Industrial production growth rate; NA%
Electricity - production: NA kWh
Electricity ■ production by source;
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products; NA
Exports: $NA
Exports - commodities: phosphate
Exports - partners: Australia, NZ
Imports: $NA
Imports - commodities: consumer goods
Imports - partners: principally Australia
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1 .5207 (January 2000), 1 .5497 (1 999), 1 .5888 (1 998),
1.3439 (1997), 1.2773 (1996), 1.3486 (1995)
Fiscal year: 1 July - 30 June','4503f483101cfd2f0598f28b3287fba54c6785db2b97a1f2dda853e15cb8247d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f0a706eb835128543cad39fef9b4835e29f3a34020d179c0d48db8722f7d53f',2000,'FR','France','economy',127,'Economy - overview: Grown throughout the
islands, coconuts are the sole cash crop. Copra and
fresh coconuts are the major export earners. Small
local gardens and fishing contribute to the food
supply, but additional food and most other necessities
must be imported from Australia.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); NA%
Labor force; NA
Labor force - by occupation; the Cocos Islands
Cooperative Society Ltd. employs construction
workers, stevedores, and lighterage worker
operations; tourism employs others
Budget;
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: copra products and tourism
industrial production growth rate; NA%
Electricity - production; NA kWh
Electricity ■ production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: vegetables, bananas,
pawpaws, coconuts
Exports: $NA
Exports - commodities: copra
Exports - partners: Australia
Imports: $NA
Imports - commodities; foodstuffs
Imports - partners: Australia
Debt -external: $NA
Economic aid - recipient: $NA
Currency; 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1 .5207 (January 2000), 1 .5497 (1 999), 1 .5888 (1 998),
1 .3439 (1997), 1.2773 (1996), 1.3486 (1995)
Fiscal year: 1 July - 30 June
Economy - overview: Cote d''Ivoire is among the
world''s largest producers and exporters of coffee,
cocoa beans, and palm oil. Consequently, the
economy is highly sensitive to fluctuations in
international prices for these products and to weather
conditions. Despite attempts by the government to
diversify the economy, it is still largely dependent on
agriculture and related activities, which engage
roughly 68% of the population. After several years of
lagging performance, the Ivorian economy began a
comeback in 1 994, due to the devaluation of the CFA
franc and improved prices for cocoa and coffee,
growth in nontraditional primary exports such as
pineapples and rubber, limited trade and banking
liberalization, offshore oil and gas discoveries, and
generous external financing and debt rescheduling by
multilateral lenders and France. The 50% devaluation
of Franc Zone currencies on 1 2 January 1 994 caused
a one-time jump in the inflation rate to 26% in 1994,
but the rate fell sharply in 1996-99. Moreover,
government adherence to donor-mandated reforms
led to a jump in growth to 5% annually in 1996-99.
Growth may slow in 2000 because of the difficulty of
meeting the conditions of international donors,
continued low prices of key exports, and post-coup
instability.
GDP: purchasing power parity - $25.7 billion
(1999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,600
(1999 est.)
GDP - composition by sector:
agriculture: 32%
industry: 18%
services: 50% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.8%
highest 10%; 28.5% (1988)
inflation rate (consumer prices): 2.5% (1999 est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $2.3 billion
expenditures: $2,6 billion, including capital
expenditures of $640 million (1997 est.)
Industries: foodstuffs, beverages; wood products,
oil refining, automobile assembly, textiles, fertilizer,
construction materials, electricity
Industrial production growth rate: 15%
(1998 est.)
Electricity - production: 3.36 billion kWh (1998)
Electricity - production by source:
fossil fuel: 85.71%
hydro: 64.29%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 3.165 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 40 million kWh (1998)
Agriculture - products: coffee, cocoa beans,
bananas, palm kernels, corn, rice, manioc (tapioca),
sweet potatoes, sugar, cotton, rubber; timber
Exports: $3.9 billion (f.o.b., 1999 est.)
Exports - commodities: cocoa 37%, coffee, tropical
woods, petroleum, cotton, bananas, pineapples, palm
oil, cotton, fish (1998)
Exports - partners: France 17%, Netherlands 12%,
US 9%, Italy 6% (1998)
Imports: $2.6 billion (f.o.b., 1999 est.)
Imports - commodities: food, consumer goods;
capital goods, fuel, transport equipment
Imports - partners: France 29%, US 5%, Italy 5%,
Germany 5% (1998)
Debt - external: $16.8 billion (1998 est.)
Economic aid - recipient: ODA, $1 billion
(1996 est.)
Currency: 1 Communaute Financiers Africaine franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per US$1 -
647.25 (January 2000), 61 5.70 (1999), 589.95 (1998),
583.67 (1997), 511.55 (1996), 499.15 (1995)
note: since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
Economy - overview: Economic activity is limited to
servicing meteorological and geophysical research
stations and French and other fishing fleets. The fish
catches landed on lies Kerguelen by foreign ships are
exported to France and Reunion.
Budget;
revenues; $18 million
expenditures: $NA, including capital expenditures of
$NA
t r a n s p or t a t i on
Ports and harbors: none; offshore anchorage only
Merchant marine:
total: 72 ships (1 ,000 GRT or over) totaling 2,892,91 1
GRT/5,165,713 DWT
ships by type: bulk 7, cargo 5, chemical tanker 1 0,
container 9, liquified gas 6, petroleum tanker 24,
refrigerated cargo 1, roll-on/roll-off 10
note: a subset of the French register allowing
French-owned ships to operate under more liberal
taxation and manning regulations than permissible
under the main French register (1999 est.)
Airports: none
Economy - overview: Gabon enjoys a per capita
income four times that of most nations of sub-Saharan
Africa. This has supported a sharp decline in extreme
poverty; yet because of high income inequality a large
proportion of the population remains poor. Gabon
depended on timber and manganese until oil was
discovered offshore in the early 1970s. The oil sector
now accounts for 50% of GDP. Gabon continues to
face fluctuating prices for its oil, timber, manganese,
and uranium exports. Despite the abundance of
natural wealth, the economy is hobbled by poor fiscal
management. In 1992, the fiscal deficit widened to
2.4% of GDP, and Gabon failed to settle arrears on its
bilateral debt, leading to a cancellation of
rescheduling agreements with official and private
creditors. Devaluation of its Francophone currency by
50% on 12 January 1994 sparked a one-time
inflationary surge, to 35%; the rate dropped to 6% in
1996. The iMF provided a one-year standby
arrangement in 1 994-95 and a three-year Enhanced
Financing Facility (EFF) at near commercial rates
beginning in late 1995. Those agreements mandate
progress in privatization and fiscai discipline. France
provided additional financial support in January 1997
after Gabon had met IMF targets for mid-1996. In
1997, an IMF mission to Gabon criticized the
government for overspending on off-budget items,
overborrowing from the central bank, and slipping on
its schedule for privatization and administrative
reform. The rebound of oil prices in 1999 helped
growth, but drops in production hampered Gabon
from fully realizing potential gains. With support from
higher oil prices, growth will move up in 2000-01 .
GDP: purchasing power parity - $7.9 billion
(1999 est.)
GDP - real growth rate: 1 .7% (1 999 est.)
GDP - per capita: purchasing power parity - $6,500
(1999 est.)
GDP - composition by sector:
agriculture: 10%
industry: 60%
services: 30% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.9% (1999 est.)
Labor force: 600,000
Labor force - by occupation: agriculture 60%,
services and government 25%, industry and
commerce 15%
Unemployment rate: 21% (1997 est.)
Budget:
revenues: $1 .5 billion
expenditures: $1.3 billion, including capital
expenditures of $302 million (1996 est.)
Industries: food and beverage; textile; lumbering
and plywood; cement; petroleum extraction and
refining; manganese, uranium, and gold mining;
chemicals; ship repair
Industrial production growth rate: 2.3% (1995)
Electricity - production: 1 .025 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 27.8%
hydro: 72.2%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 953 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: cocoa, coffee, sugar, palm
oil, rubber; cattle; okoume (a tropical softwood); fish
Exports: $2.4 billion (f.o.b., 1999 est.)
Exports - commodities: crude oil 75%, timber,
manganese, uranium (1998)
Exports - partners: US 68%, China 9%, France 8%,
Japan 3% (1998)
Imports: $1.2 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment,
foodstuffs, chemicals, petroleum products,
construction materials
Imports - partners: France 39%, US 6%, Cameroon
5%, Netherlands 5%, Cote d''Ivoire, Japan (1998)
Debt - external: $4.6 billion (1999 est.)
Economic aid - recipient: $331 million (1995)
Currency: 1 Communaute Financiere Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiere Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
615.70 (1999), 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
note: since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 32,000 (1995)
Telephones - mobile cellular: 4,000 (1995)
Telephone system:
domestic: adequate system of cable, microwave radio
relay, tropospheric scatter, radiotelephone
communication stations, and a domestic satellite
system with 12 earth stations
international: satellite earth stations - 3 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 6, FM 7, shortwave
6(1998)
Radios: 208,000(1997)’
Television broadcast stations: 4 (plus five
low-power repeaters) (1997)
Televisions: 63,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Economy - overview: The Gambia has no important
mineral or other natural resources and has a limited
agricultural base. About 75% of the population
depends on crops and livestock for its livelihood.
Small-scale manufacturing activity features the
processing of peanuts, fish, and hides. Reexport trade
normally constitutes a major segment of economic
activity, but the 50% devaluation of the CFA franc in
January 1994 made Senegalese goods more
competitive and hurt the reexport trade. The Gambia
has benefited from a rebound in tourism after its
decline in response to the military''s takeover in July
1994. Short-run economic progress remains highly
dependent on sustained bilateral and multilateral aid
and on responsible government economic
management as forwarded by IMF technical help and
advice. Annual GDP growth is expected to fall to less
than 4% over 2000-01 .
GDP: purchasing power parity - $1 .4 billion
(1999 est.)
GDP - real growth rate: 4.2% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,030
(1999 est.)
GDP - composition by sector:
agriculture: 23%
industry: tOJo
services: 64% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.5% (1999 est.)
Labor force: 400,000
Labor force ■ by occupation: agriculture 75%,
industry, commerce, and services 19%, government
6%
Unemployment rate: NA%
Budget:
revenues: $88.6 million
expenditures: $98.2 million, including capital
expenditures of $NA (FY96/97 est.)
Industries: processing peanuts, fish, and hides;
tourism; beverages; agricultural machinery assembly,
woodworking, metalworking; clothing
Industrial production growth rate: NA%
Electricity - production: 75 million kWh (1998)
Electricity ■ production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 70 million kWh (1998)
Electricity ■ exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: peanuts, millet, sorghum,
rice, corn, cassava (tapioca), palm kernels; cattle,
sheep, goats; forest and fishery resources not fully
exploited
Exports: $132 million (f.o.b., 1998)
Exports - commodities: peanuts and peanut
products, fish, cotton lint, palm kernels
Exports - partners: Benelux 78%, Japan, UK, Hong
Kong, France, Spain (1997)
Imports: $201 million (f.o.b., 1998)
Imports - commodities: foodstuffs, manufactures,
fuel, machinery and transport equipment
Imports - partners: Hong Kong, UK, Netherlands,
Cote d''Ivoire, France, Senegal, Belgium (1997)
Debt - external: $430 million (1997 est.)
Economic aid - recipient: $45.4 million (1995)
Currency: 1 dalasi (D) = 100 butut
182
Gambia, Tha (continued)
Exchange rates: dalasi (D) per US$1 - 1 1 .626
(November 1999), 10.643 (1998), 10.200 (1997),
9.789(1996), 9.546 (1995)
Fiscal year: 1 July - 30 June
I Communications
Telephones - main lines in use: 22,000 (1998)
Telephones - mobile cellular: 4,485 (1998)
Telephone system:
domestic: adequate network of microwave radio relay
and open wire
international: microwave radio relay links to Senegal
and Guinea-Bissau; satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 2, shortwave
0(1998)
Radios: 196,000(1997)
Television broadcast stations: 1
(government-owned) (1997)
Televisions: 4,000(1997)
Internet Service Providers (ISPs): 2 (1999)
I transportation
Railways: 0 km
Highways:
total: 2,700 km
paved: 956 km
urrpaved; 1,744 km (1996 est.)
Waterways: 400 km
Ports and harbors: Banjul
Merchant marine: none (1999 est.)
Airports: 1 (1 999 est.)
Airports - with paved runways:
total: 1
over 3,047 m:t (1999 est.)
I M i I i Ta r y
Military branches: Army (includes marine unit).
National Police, National Guard
Military manpower - availability:
males age 15-49: 306,359 (2000 est.)
Military manpower - fit for military service:
males age 15-49; 154,432 (2000 est.)
Military expenditures - dollar figure: $1 million
(FY96/97)
Military expenditures - percent of GDP: 2%
(FY96/97)
I transnational issues
Disputes - international: short section of boundary
with Senegal is indefinite
(Gaza Strip
t, .
Background: The Israel-PLO Declaration of
Principles on Interim Self-Government Arrangements
(the DOP), signed in Washington on 13 September
1 993, provides for a transitional period not exceeding
five years of Palestinian interim self-government in the
Gaza Strip and the West Bank. Under the DOP, Israel
agreed to transfer certain powers and responsibilities
to the Palestinian Authority, which includes a
Palestinian Legislative Council elected in January
1996, as part of interim self-governing arrangements
in the West Bank and Gaza Strip. A transfer of powers
and responsibilities for the Gaza Strip and Jericho
took place pursuant to the Israel-PLO 4 May 1994
Cairo Agreement on the Gaza Strip and the Jericho
Area and in additional areas of the West Bank
pursuant to the Israel-PLO 28 September 1995
Interim Agreement, the Israel-PL0 15 January 1997
Protocol Concerning Redeployment in Hebron, the
Israel-PLO 23 October 1998 Wye River
Memorandum, and the 4 September 1999 Sharm
el-Sheikh Agreement. The DOP provides that Israel
will retain responsibility during the transitional period
for external security and for internal security and
public order of settlements and Israeli citizens.
Permanent status is to be determined through direct
negotiations, which resumed in September 1 999 after
a three-year hiatus.
I Geography"
Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli-occupied with current
status subject to the Israeli-Palestinian Interim
Agreement - permanent status to be determined
through further negotiation
Climate: temperate, mild winters, dry and warm to
hot summers
Terrain: flat to rolling, sand- and dune-covered
coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: arable land
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 1 1 %
other; 26% (1993 est.)
Irrigated land; 120 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: desertification;
salination of fresh water; sewage treatment
Geography • note: there are 24 Israeli settlements
and civilian land use sites in the Gaza Strip (August
1999 est.)
I '' . P e ^T p l e
Population; 1,132,063
note: in addition, there are some 6,500 Israeli settlers
in the Gaza Strip (July 2000 est.)
Age structure;
0-14 years: 50% (male 289,954; female 275,628)
15-64 years: 47% (male 271 ,365; female 263,1 97)
65 years and over: 3% (male 1 3,792; female 1 8,1 27)
(2000 est.)
Population growth rate: 3.97% (2000 est.)
Birth rate: 43.14 births/1 ,000 population (2000 est.)
Death rate: 4.31 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.83 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 25.97 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.82 years
male: 69.58 years
female: 72.1 1 years (2000 est.)
Total fertility rate: 6.55 children born/woman
(2000 est.)
Nationality:
noun: NA
adjective: NA
183
Gaza Strip (continued)
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%,
Christian 0.7%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: NA
total popuiation:M%
male: NA%
female: NA%
Economy - overview: Georgia''s economy has
traditionally revolved around Black Sea tourism;
cultivation of citrus fruits, tea, and grapes; mining of
manganese and copper; and output of a small
industrial sector producing wine, metals, machinery,
chemicals, and textiles. The country imports the bulk
of its energy needs, including natural gas and oil
products. Its only sizable internal energy resource is
hydropower. Despite the severe damage the
economy has suffered due to civil strife, Georgia, with
the help of the IMF and World Bank, made substantial
economic gains since 1995, increasing GDP growth
and slashing inflation. The Georgian economy
continues to experience iarge budget deficits due to a
failure to collect tax revenues. Georgia also still
suffers from energy shortages: it privatized the
distribution network in 1998, and deliveries are
steadily improving. Georgia is pinning its hopes for
iong-term recovery on the development of an
international transportation corridor through the key
Black Sea ports of P''ot''i and Bat''umi. The growing
trade deficit, continuing problems with tax evasion and
corruption, and poiiticai uncertainties cloud the
short-term economic picture. However, revived
investment could spur higher economic growth in
2000, perhaps up to 6%.
GDP: purchasing power parity - $1 1 .7 billion
(1999 est.)
GDP - real growth rate: 3.5% (1999 est.)
GDP - per capita: purchasing power parity - $2,300
(1999 est.)
GDP - composition by sector:
agriculture: 32%
industry: 23%
services: 45% (1 999 est.)
Population below poverty line: 60% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 9% (1 999 est.)
Labor force: 3.08 million (1997)
Labor force - by occupation: industry and
construction 20%, agriculture and forestry 40%,
services 40% (1999 est.)
Unemployment rate: 14.5% (1998 est.)
Budget:
revenues: $364 million
expenditures: $568 million, including capital
expenditures of $NA (1998)
Industries: steel, aircraft, machine tools, electric
locomotives, trucks, tractors, textiles, shoes,
chemicals, wood products, wine
Industrial production growth rate: -0.3%
(1998 est.)
Electricity - production: 6.96 billion kWh (1998)
Electricity - production by source:
fossil fuel: 14.66%
hydro; 85.34%
nuclear: 0%
other; 0% (1998)
Electricity ■ consumption: 6. 123 billion kWh (1998)
Electricity - exports: 700 million kWh (1998)
Electricity - imports: 350 million kWh (1998)
Agriculture ■ products: citrus, grapes, tea,
vegetables, potatoes; livestock
Exports: $330 million (1999 est.)
Exports - commodities: citrus fruits, tea, wine,
other agricultural products; diverse types of
machinery and metals; chemicals; fuel reexports;
textiles
Exports - partners: Russia 27%, Turkey 20%,
Azerbaijan 10%, Armenia 8% (1997)
Imports: $840 million (1999 est.)
Imports - commodities: fuel, grain and other foods,
machinery and parts, transport equipment
Imports - partners: EU 22%, Russia 15%, Turkey
12%, Azerbaijan 12%, US 7% (1997)
Debt - external: $1 .8 billion (1 998)
Economic aid - recipient: $212.7 million (1995)
Currency: 1 lari (GEL) = 100 tetri
Exchange rates: lari per US$1 (end of period) -
1.9503 (December 1999), 2.0245 (1999), 1.3898
(1998), 1.2975 (1997), 1.2628 (1996), 1.24
(December 1995)
Fiscal year: calendar year
Economy - overview: Greenland suffered negative
economic growth in the early 1990s, but since 1993
the economy has improved. The Greenland Home
Rule Government (GHRG) has pursued a tight fiscal
policy since the late 1980s which has helped create
surpluses in the public budget and low inflation. Since
1990, Greenland has registered a foreign trade deficit
following the closure of the last remaining lead and
zinc mine in 1990. Greenland today is critically
dependent on fishing and fish exports; the shrimp
fishery is by far the largest income earner. Despite
resumption of several interesting hydrocarbon and
minerals exploration activities, it will take several years
before production can materialize. Tourism is the only
sector offering any near-term potential and even this is
limited due to a short season and high costs. The
public sector, including publicly owned enterprises and
the municipalities, plays the dominant role in
Greenland''s economy. About half the government
revenues come from grants from the Danish
Government, an important supplement of GDP.
GDP: purchasing power parity - $945 million
(1997 est.)
GDP - real growth rate: 0.6% (1997 est.)
GDP - per capita: purchasing power parity -
$16,100 (1997 est.)
GDP ■ composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .2% (1 998 est.)
Labor force: 24,500 (1995 est.)
Unemployment rate: 10.5% (1995 est.)
Budget:
revenues: $706 million
expenditures: $697 million, including capital
expenditures of $NA (1995)
Industries: fish processing (mainly shrimp),
handicrafts, furs, small shipyards
Industrial production growth rate: NA%
Electricity - production: 245 million kWh (1 998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
often 0% (1998)
Electricity - consumption: 228 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: forage crops, garden
vegetables; sheep, reindeer; fish
Exports: $363.4 million (f.o.b., 1995)
Exports - commodities: fish and fish products 95%
Exports - partners: Denmark 89%, Japan 5%i, UK
5%
Imports: $421 million (c.i.f,, 1995)
Imports - commodities: machinery and transport
equi','c7a0dae84a520781e6d831368c84ad5bd3283d5c408983e44dbd1ccd31392e56','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e28d563665bece681867bb87c8c3e6ed32be06e968b22ac068915693ac528949',2000,'FR','France','economy',128,'pment, manufactured goods, food and live
animals, petroleum products
Imports - partners: Denmark 7,5%, Iceland 3.8%,
Japan 3.3%, Norway 3.1%, US 2.4%, Germany 2.4%,
Sweden 1 .8%
Debt - external: $243 million (1995)
Economic aid ■ recipient: $427 million (annual
subsidy from Denmark) (1995)
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: Danish kroner (DKr) per US$1 -
7.336 (January 2000), 6.976 (1999), 6.701 (1998),
6.604 (1997), 5.799 (1996), 5.602 (1995)
Fiscal year: calendar year
Economy - overview: The economy depends on
agriculture, tourism, light industry, and services. It
also depends on France for large subsidies and
imports. Tourism is a key industry, with most tourists
from the US; an increasingly large number of cruise
ships visit the islands. The traditional sugarcane crop
is slowly being replaced by other crops, such as
bananas (which now supply about 50% of export
earnings), eggplant, and flowers. Other vegetables
and root crops are cultivated for local consumption,
although Guadeloupe is still dependent on imported
food, mainly from France. Light industry features
sugar and rum production. Most manufactured goods
and fuel are imported. Unemployment is especially
high among the young. Hurricanes periodically
devastate the economy.
GDP: purchasing power parity - $3.7 billion
(1996 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $9,000
(1996 est.)
GDP - composition by sector:
agriculture: 6%
Industry: 9%
services: 85% (1 993 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA
Labor force: 1 25,900 (1 997)
Labor force - by occupation: agriculture 15%,
industry 17%, services 68% (1997)
Unemployment rate: 27.8% (1 998)
Budget:
revenues: $225 million
expenditures: $390 million, including capital
expenditures of $105 million (1996)
Industries: construction, cement, rum, sugar,
tourism
Industrial production growth rate: NA%
Electricity - production: 1 .22 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 1Q0%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 1 .135 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, sugarcane,
tropical fruits and vegetables; cattle, pigs, goats
Exports: $140 million (f.o.b., 1997)
Exports • commodities: bananas, sugar, rum
Exports - partners: France 60%, Martinique 18%,
US 4% (1997)
Imports: $1,7 billion (c.i.f., 1997)
Imports • commodities: foodstuffs, fuels, vehicles,
clothing and other consumer goods, construction
materials
Imports - partners: France 63%, Germany 4%, US
3%, Japan 2%, Netherlands Antilles 2% (1997)
Debt -external: $NA
Economic aid - recipient: $NA; note - substantial
annual French subsidies
Currency: 1 French franc (F) = 100 centimes
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0,9386 (1999); French francs (F) per US$1 -
5.65 (January 1999), 5.8995 (1998), 5.8367 (1997),
5.1155(1996), 4.9915 (1995)
Fiscal year: calendar year
Economy - overview: The economy depends
mainly on US military spending and on tourist
revenue. Over the past 20 years, the tourist industry
has grown rapidly, creating a construction boom for
new hotels and the expansion of older ones. More
than 1 million tourists visit Guam each year. The
industry suffered a setback in 1998 because of the
continuing Japanese recession; the Japanese
normally make up almost 90% of the tourists. Most
food and industrial goods are imported. Guam faces
the problem of building up the civilian economic sector
to offset the impact of military downsizing.
GDP: purchasing power parity - $3 billion (1 996 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$19,000 (1996 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4% (1992 est.)
Labor force: 65,660(1995)
Labor force - by occupation: federal and territorial
government 31%, private 69% (trade 21%, services
33%, construction 12%, other 3%) (1995)
Unemployment rate: 2% (1992 est.)
Budget:
revenues: $524.3 million
expenditures: $361 .4 million, including capital
expenditures of $NA (1995)
Industries: US military, tourism, construction,
transshipment services, concrete products, printing
and publishing, food processing, textiles
Industrial production growth rate: NA%
Electricity - production: 800 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(im)
Electricity - consumption: 744 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: fruits, copra, vegetables;
eggs, pork, poultry, beef
Exports: $86.1 million (f.o.b., 1992)
Exports - commodities: mostly transshipments of
refined petroleum products, construction materials,
fish, food and beverage products
Exports - partners: US 25%
Imports: $202.4 million (c.i.f., 1992)
Imports - commodities: petroleum and petroleum
products, food, manufactured goods
Imports - partners: US 23%, Japan 1 9%, other 58%
Debt - external: $NA
Economic aid - recipient: $NA; note - although
Guam receives no foreign aid, it does receive large
transfer payments from the general revenues of the
US Federal Treasury into which Guamanians pay no
income or excise taxes; under the provisions of a
special law of Congress, the Guam Treasury, rather
than the US Treasury, receives federal income taxes
paid by military and civilian Federal employees
stationed in Guam
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October - 30 September
Economy - overview: The agricultural sector
accounts for one-fourth of GDP, two-thirds of exports,
and half of the labor force. Coffee, sugar, and
bananas are the main products. Manufacturing and
construction account for one-fifth of GDP. Since
assuming office in January 1996, former President
ARZU worked to implement a program of economic
liberalization and political modernization. The signing
of the peace accords in December 1 996, which ended
36 years of civil war, removed a major obstacle to
foreign investment. In 1998, Hurricane Mitch caused
relatively little damage to Guatemala compared to its
neighbors. Remaining challenges include beefing up
government revenues, negotiating further assistance
from international donors, and increasing the
efficiency and openness of both government and
private financial operations. Growth should remain at
the same level in 2000 provided world agricultural
prices do not plunge.
GDP: purchasing power parity - $47.9 billion
(1999 est.)
GDP - real growth rate: 3.5% (1999 est.)
GDP - per capita: purchasing power parity - $3,900
(1999 est.)
GDP - composition by sector:
agriculture: 23%
industry: 20%
services: 57% (1999 est.)
Population below poverty line: 75%
Household income or consumption by percentage
share:
lowest 10%: 0.6%
highest 10%; 46.6% (1989)
Inflation rate (consumer prices): 6.8% (1999 est.)
Labor force: 3.32 million (1997 est.)
Labor force - by occupation: agriculture 50%,
industry 1 5%, services 35% (1999 est.)
Unemployment rate: 7.5% (1999 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: sugar, textiles and clothing, furniture,
chemicals, petroleum, metals, rubber, tourism
Industrial production growth rate: NA%
Electricity - production: 3.085 billion kWh (1998)
Electricity - production by source:
fossil fuel: 26.42%
hydro: 66.61%
nuclear: 0%
often 6.97% (1998)
Electricity - consumption: 2.914 billion kWh (1 998)
Electricity - exports: 6 million kWh (1 998)
Electricity - imports: 51 million kWh (1998)
Agriculture - products; sugarcane, corn, bananas,
coffee, beans, cardamom; cattle, sheep, pigs,
chickens
Exports: $2.4 billion (f.o.b., 1999)
Exports - commodities: coffee, sugar, bananas,
fruits and vegetables, meat, apparel, petroleum,
electricity
Exports - partners: US 48%, El Salvador 10%,
Honduras 6%, Germany 5%, Costa Rica 4% (1997)
Imports: $4.5 billion (c.i.f., 1999)
Imports - commodities: fuels, machinery and
transport equipment, construction materials, grain,
fertilizers, electricity
Imports - partners: US 46%, Mexico 13%, El
Salvador 5%, Venezuela 5%, Japan 4% (1997)
Debt - external: $4.4 billion (1998 est.)
Economic aid - recipient: $212 million (1995)
Currency: 1 quetzal (Q) = 100 centavos
Exchange rates: quetzales (Q) per US$1 - 7.8829
(January 2000), 7.3856 (1 999), 6.3947 (1998), 6.0653
(1997), 6.0495 (1996), 5.8103 (1995)
Fiscal year: calendar year
Economy - overview: Financial services - banking,
fund management, insurance, etc. - account for about
55% of total income in this tiny Channel Island
economy. Tourism, manufacturing, and horticulture,
mainly tomatoes and cut flowers, have been declining.
Light tax and death duties make Guernsey a popular
tax haven. The evolving economic integration of the
EU nations is changing the rules of the game under
which Guernsey operates.
GDP: purchasing power parity -$1.15 billion
(1997 est.)
GDP - real growth rate: 2.3% (1 997 est.)
GDP - per capita: purchasing power parity -
$18,100(1997 est.)
GDP - composition by sector:
agriculture: 4%
industry: 10%
services: 86% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4.7% (1997 est.)
Labor force: NA
Unemployment rate: 0.5% (1997 est.)
Budget:
revenues: $300.8 million
expenditures: $298.1 million, including capital
expenditures of $NA (1998 est.)
Industries: tourism, banking
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: tomatoes, greenhouse
flowers, sweet peppers, eggplant, fruit; Guernsey
cattle
Exports: $NA
Exports - commodities: tomatoes, flowers and
ferns, sweet peppers, eggplant, other vegetables
Exports - partners: UK (regarded as internal trade)
Imports: $NA
Imports - commodities: coal, gasoline, oil,
machinery and equipment
Imports - partners: UK (regarded as internal trade)
Debt • external: $NA
Economic aid - recipient: $NA
Currency: 1 Guernsey pound = 100 pence
Exchange rates: Guernsey pounds per US$1 -
0.6092 (January 2000), 0.61 80 (1 999), 0.6037 (1 998),
0.6106 (1997), 0.6403 (1996), 0.6335 (1995); note -
the Guernsey pound is at par with the British pound
Fiscal year: calendar year
Economy - overview: Guinea possesses major
mineral, hydropower, and agricultural resources, yet
remains a poor underdeveloped nation. The
agricultural sector employs 80% of the work force.
Guinea possesses over 25% of the world''s bauxite
reserves and is the second largest bauxite producer.
The mining sector accounted for about 75% of exports
in 1998. Long-run improvements in government fiscal
arrangements, literacy, and the legal framework are
needed If the country is to move out of poverty. The
government made encouraging progress in budget
management in 1997-99. Even with a recovery in
prices for some of Guinea''s main commodity exports,
annual GDP is unlikely to increase by more than 5%
in 2000-2001.
GDP: purchasing power parity - $9.2 billion
(1999 est.)
GDP - real growth rate: 3.7% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,200
(1999 est.)
GDP ■ composition by sector:
agriculture: 24%
Industry: 31%
services: 45% (1 996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 0.9%
highest 10%; 31 .7% (1991)
inflation rate (consumer prices): 4.5% (1999 est.)
Labor force: 2.4 million (1983)
Labor force - by occupation: agriculture 80%,
industry and commerce 11%, services 5.4%, civil
service 3.6%
Unemployment rate: NA%
Budget:
revenues: $553 million
expenditures: $652 million, including capital
expenditures of $317 million (1995 est.)
Industries: bauxite, gold, diamonds; alumina
refining; light manufacturing and agricultural
processing industries
Industrial production growth rate: 3.2% (1994)
Electricity - production: 535 million kWh (1 998)
Electricity - production by source:
fossil fuel: 63.55%
hydro: 36.45%
nuclear: 0%
other: 0% (1998)
Electricity ■ consumption: 498 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports; 0 kWh (1998)
Agriculture - products: rice, coffee, pineapples,
palm kernels, cassava (tapioca), bananas, sweet
potatoes; cattle, sheep, goats; timber
Exports: $695 million (f.o.b., 1998 est.)
Exports - commodities: bauxite, alumina, gold,
diamonds, coffee, fish, agricultural products
Exports - partners: Russia, US, Benelux, Ukraine,
Ireland, Spain (1997)
Imports: $560 million (f.o.b., 1998 est.)
Imports - commodities: petroleum products,
metals, machinery, transport equipment, textiles,
grain and other foodstuffs (1997)
Imports - partners: France, Cote d''Ivoire, US,
Benelux, Hong Kong (1997)
Debt - external: $3.15 billion (1998 est.)
Economic aid - recipient: $433.6 million (1995)
Currency: 1 Guinean franc (FG) = 100 centimes
Exchange rates: Guinean francs (FG) per US$1 -
1,292.5 (January 1999), 1,236.8 (1998), 1,095.3
(1997), 1,004.0 (1996), 991.4 (1995)
Fiscal year: calendar year
I Transnational issues
Disputes - international: none
iMongolia
ri
Erdenet,
Bulgan*
.Bayanhongor
RUSSIA
Choybalsan,
ULAANBAATAR
Buyant-Uhaa,
Dalandzadgad .
Economy - overview: The economy has
traditionally been based on agriculture. Sugarcane
has been the primary crop for more than a century,
and in some years it accounts for 85% of exports. The
government has been pushing the development of a
tourist industry to relieve high unemployment, which
amounts to more than 40% of the labor force. The gap
in Reunion between the well-off and the poor is
extraordinary and accounts for the persistent social
tensions. The white and Indian communities are
substantially better off than other segments of the
population, often approaching European standards,
whereas minority groups suffer the poverty and
unemployment typical of the poorer nations of the
African continent. The outbreak of severe rioting in
February 1991 illustrates the seriousness of
socioeconomic tensions. The economic well-being of
Reunion depends heavily on continued financial
assistance from France.
GDP: purchasing power parity - $3.4 billion
(1998 est.)
GDP • real growth rate: 3.8% (1998 est.)
GDP ■ per capita: purchasing power parity - $4,800
(1998 est.)
GDP ■ composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 261,000(1995)
Labor force - by occupation: agriculture 8%,
industry 19%, services 73% (1990)
Unemployment rate: 42.8% (1998)
Budget:
revenues: $1 .2 billion
expenditures: $2.6 billion, including capital
expenditures of $260 million (1995)
Industries: sugar, rum, cigarettes, handicraft items,
flower oil extraction
Industrial production growth rate: NA%
Electricity - production: 1.11 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 54.05%
hydro: 45.95%
nuclear: 0%
other: 0% {1998)
Electricity - consumption: 1 .032 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: sugarcane, vanilla,
tobacco, tropical fruits, vegetables, corn
Exports: $214,162 million (f.o.b., 1997)
Exports - commodities: sugar 63%, rum and
molasses 4%, perfume essences 2%, lobster 3%,
(1993)
Exports - partners: France 74%, Japan 6%,
Comoros 4% (1994)
Imports: $2.5 billion (c.i.f., 1997)
Imports - commodities: manufactured goods, food,
beverages, tobacco, machinery and transportation
equipment, raw materials, and petroleum products
Imports - partners: France 64%, Bahrain 3%,
Germany 3%, Italy 3% (1994)
Debt - external: $NA
Economic aid - recipient: $NA; note - substantial
annual subsidies from France
Currency: 1 French franc (F) = 100 centimes
Exchange rates: euros per IJS$1 - 0.9867 (January
2000), 0.9386 (1999); French francs (F) per US$1 -
5.65 (January 1999), 5.8995 (1998), 5.8367 (1997),
5.1155 (1996), 4.9915 (1995)
Fiscal year: calendar year
I transnational Issues
Disputes - international: none
I n t r 0 d u c t i b n
Background: Disputed between France and Great
Britain in the 1 8th century. Saint Vincent was ceded to
the latter in 1 783. Autonomy was granted in 1 969, and
independence in 1979.
r G e 0 g r a p h y
Location: Caribbean, islands in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates; 13 15 N, 61 12 W
Map references: Central America and the
Caribbean
Area:
total: 389 sq km (Saint Vincent 344 sq km)
land: 389 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries; 0 km
Coastline; 84 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
femtor/a/ sea; 12 nm
Climate: tropical; little seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1,234 m
Natural resources: hydropower, cropland
Land use;
arable land: 1Q%
permanent crops: 18%
permanent pastures: 5%
forests and woodland: 36%
other: 31% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards; hurricanes; Soufriere volcano on
the island of Saint Vincent is a constant threat
Environment - current issues: pollution of coastal
waters and shorelines from discharges by pleasure
yachts and other effluents; in some areas, pollution is
severe enough to make swimming prohibitive
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
I People
Population: 115,461 (July 2000 est.)
Age structure;
0-14 years: 30% (male 17,868; female 17,263)
15-64 years: 63% (male 37,377; female 35,623)
65 years and over: 7% (male 3,144; female 4,186)
(2000 est.)
Population growth rate: 0.43% (2000 est.)
Birth rate: 18.25 births/1 ,000 population (2000 est.)
Death rate; 6.21 deaths/1 ,000 population
(2000 est.)
Net migration rate: -7.75 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate: 1 7.06 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 72.3 years
male: 70.6 years
female: 74.06 years (2000 est.)
Total fertility rate: 2.11 children born/woman
(2000 est.)
Nationality;
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black 66%, mixed 19%, East Indian
6%, Carib Amerindian 2%
Religions: Anglican 47%, Methodist 28%, Roman
Catholic 13%, Seventh-Day Adventist, Hindu, other
Protestant
Languages: English, French patois
Literacy;
definition: age 15 and over has ever attended school
total population: 96%
male: 96%
fema/e; 96% (1970 est.)
I " Gov e r n m e n t
Country name;
conventional long form: none
conventional short form: Saint Vincent and the
Grenadines
425
Saint Vincent and the Grenadines (continued)
Data code: VC
Government type: parliamentary democracy;
independent sovereign state within the
Commonwealth
Capital: Kingstown
Administrative divisions: 6 parishes; Charlotte,
Grenadines, Saint Andrew, Saint David, Saint
George, Saint Patrick
Independence: 27 October 1979 (from UK)
National holiday: Independence Day, 27 October
(1979)
Constitution: 27 October 1979
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Charles
ANTROBUS (since NA)
head of government: Prime Minister James F.
MITCHELL (since 30 July 1984)
cabinet: Cabinet appointed by the governor general
on the advice of the prime minister
elections: none; the monarch is hereditary; the
governor general is appointed by the monarch;
following legislative elections, the leader of the
majority party is usually appointed prime minister by
the governor general; deputy prime minister
appointed by the governor general on the advice of
the prime minister
Legislative branch: unicameral House of Assembly
(21 seats, 1 5 elected representatives and 6 appointed
senators; representatives are elected by popular vote
from single-member constituencies to serve five-year
terms)
elections: last held 15 June 1998 (next to be held by
NA May 2003)
election results: percent of vote by party - NA; seats
by party - NDP 8, ULP 7
Judicial branch: Eastern Caribbean Supreme Court
(based on Saint Lucia), one judge of the Supreme
Court resides in Saint Vincent
Political parties and leaders: National Reform
Party or NRP [Joel MIGUEL]; New Democratic Party
or NDP [James F. MITCHELL]; Progressive Labor
Party or PLP [leader NA]; United People''s Movement
or UPM [Adrian SAUNDERS]; Unity Labor Party or
ULP [Ralph GONSALVES] (formed by the coalition of
Saint Vincent Labor Party or SVLP and the Movement
for National Unity or MNU)
International organization participation: ACP, C,
Caricom, CDB, ECLAC, FAO, G-77, IBRD, ICAO,
ICFTU, ICRM, IDA, IFAD, IFRCS, ILO, IMF, IMO,
Intelsat (nonsignatory user), Interpol, IOC, ITU, OAS,
OECS, OPANAL, OPCW, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WlPO, WlrO
Diplomatic representation in the US:
c/r/ef of m/ss/on; Ambassador Kingsley C. A. LAYNE
chancery: 3216 New Mexico Avenue NW,
Washington, DC 20016
telephone: [t] (202) 364-6730
FAX; [1] (202) 364-6736
Diplomatic representation from the US: the US
does not have an embassy in Saint Vincent and the
Grenadines; the US Ambassador in Barbados is
accredited to Saint Vincent and the Grenadines
Flag description: three vertical bands of blue (hoist
side), gold (double width), and green; the gold band
bears three green diamonds arranged in a V pattern
Economy - overview: Agriculture, dominated by
banana production, is the most important sector of this
lower-middle-income economy. The senrices sector,
based mostly on a growing tourist industry, is also
important. The government has been relatively
unsuccesstui at introducing new industries, and a high
unemployment rate of 22% continues. The continuing
dependence on a single crop represents the biggest
obstacle to the islands'' development; tropical storms
wiped out substantial portions of crops in both 1994
and 1995. The tourism sector has considerable
potential for development over the next decade.
Recent growth has been stimulated by strong activity
in the construction sector and an improvement in
tourism. There is a small manufacturing sector and a
small offshore financial sector whose particularly
restrictive secrecy laws have caused some
international concern.
GDP: purchasing power parity - $309 million
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $2,600
(1999 est.)
GDP - composition by sector:
agriculture: tO.OJo
industry: 17.5%
services: 71 .9% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%>: NA%
Inflation rate (consumer prices); 2% (1999 est.)
Labor force: 67,000 (1984 est.)
Labor force - by occupation: agriculture 26%,
industry 17%, services 57% (1980 est.','8654dccf2d9b69957a3dd4332c1c7f7f253b60d8f70ff8e703a0b272dde14a40','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5b2ae4b61b8b01f9169de08d1ad8d952a26196ea5a1b269c1cc43644d95f74d',2000,'FR','France','economy',129,')
Unemployment rate: 22% (1997 est.)
Budget:
revenues: $85.7 million
expenditures: $98.6 million, including capital
expenditures of $25.7 million (1997 est.)
Industries: food processing, cement, furniture,
clothing, starch
Industrial production growth rate; -0.9%
(1997 est.)
Electricity - production: 64 million kWh (1998)
Electricity - production by source:
fossil fuel: 67.19%
hydro: 32.81%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 60 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, coconuts, sweet
potatoes, spices; small numbers of cattle, sheep, pigs,
goats; fish
Exports: $47.8 million (1998 est.)
Exports - commodities: bananas 39%, eddoes and
dasheen (taro), arrowroot starch, tennis racquets
Exports - partners: Caricom countries 49%, UK
16%, US 10% (1995)
Imports: $180 million (1998 est.)
Imports - commodities: foodstuffs, machinery and
equipment, chemicals and fertilizers, minerals and
fuels
Imports - partners: US 36%, Caricom countries
28%, UK 13% (1995)
Debt - external: $83.6 million (1997)
Economic aid - recipient: $47.5 million (1995);
note - EU $34.5 million (1998)
Currency: 1 East Caribbean dollar (EC$) = 100
cents
Exchange rates: East Caribbean dollars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year; calendar year
Economy - overview: Turkey has a dynamic
economy that is a complex mix of modern industry and
commerce along with traditional village agriculture
and crafts. It has a strong and rapidly growing private
sector, yet the state still plays a major role in basic
industry, banking, transport, and communication. Its
most important industry - and largest exporter - is
textiles and clothing, which is almost entirely in private
hands. The economic situation in recent years has
been marked by erratic economic growth and serious
imbalances. After a sharp drop in 1994, real GNP
Turksy (continued)
averaged 6.5% annual growth in 1995-98; it then fell
about 5% in 1999 as Turkey was adversely affected
by Russia''s economic crisis and two major
earthquakes. The aiready-large public sector fiscai
deficit widened in 1 999 to perhaps 1 4% of GDP - due
in iarge part to the huge burden of interest payments
which accounted for 42% of central grovernment
spending. Despite the implementation in January
1996 of a customs union with the EL), foreign direct
investment in the country remains low - less than $1
billion annually - perhaps because potential investors
are concerned about economic and politicai stabiiity.
Prospects for the future are brighter - including
prospects for foreign investment - because the
ECEVIT government is implementing a major
economic reform program, including a tighter budget,
social security reform, banking reorganization, and
greatiy accelerated privatization.
GDP: purchasing power parity - $409.4 biliion
(1999 est.)
GDP - real growth rate: -5% (1 999 est.)
GDP - per capita: purchasing power parity - $6,200
(1999 est.)
GDP - composition by sector:
agriculture: 18%
industry: 29%
services: 53% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
/oivesffO%;NA%
highest 10%: m%
inflation rate (consumer prices): 65% (1999 est.)
Labor force; 23.8 million (April 1999)
note: about 1.5 million Turks work abroad (1994)
Labor force - by occupation: agriculture 45.8%,
services 33.7%, industry 20.5% (April 1999)
Unemployment rate: 7.3% plus underemployment
of 6.9% (April 1999 est.)
Budget:
revenues: $45.2 billion
expenditures: $66.7 billion, including capital
expenditures of $3.4 billion (1999)
Industries; textiles, food processing, autos, mining
(coal, chromite, copper, boron), steel, petroleum,
construction, lumber, paper
Industrial production growth rate: -5.2%
(1999 est.)
Electricity - production: 1 1 6.5 billion kWh (1999)
Electricity - production by source:
fossil fuel: 69.4%
hydro: 30.5%
nuclear: 0%
of/ier; 0.1% (1999 est.)
Electricity - consumption; 1 1 8.5 billion kWh (1 999)
Electricity - exports: 209 million kWh (1999 est.)
Electricity - imports: 2.3 billion kWh (1999 est.)
Agriculture - products: tobacco, cotton, grain,
olives, sugar beets, pulse, citrus; livestock
Exports; $26 billion (f.o.b., 1999 est.)
Exports - commodities: apparel 28%, foodstuffs
17%, textiles 12%, metal manufactures 9% (1998)
Exports - partners; Germany 21%, US 9%, UK 7%,
Italy 6%, France 6% (1999)
Imports: $40 billion (c.i.f., 1999 est.)
Imports - commodities: machinery 29%,
semi-finished goods 16%, chemicals 14%, transport
equipment 1 1 %, fuels 8% (1998)
Imports - partners: Germany 14%, Italy 8%, US
8%, France 8%, Russia 6%, UK 5% (1999)
Debt -external: $104 billion (1999)
Economic aid - recipient: ODA, $1 95 million (1 993)
Currency: Turkish lira (TL) = 100 kurus (theoretical)
Exchange rates: Turkish liras (TL) per US$1 -
545,584 (January 2000), 418,783 (1999), 260,724
(1998), 151,865 (1997), 81,405 (1996), 45,845.1
(1995)
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 17.244 million
(1998)
Telephones - mobile cellular: 3.2 million (1998)
Telephone system: undergoing rapid
modernization and expansion, especially cellular
telephones
domestic: additional digital exchanges are permitting
a rapid increase in subscribers; the construction of a
network of technologically advanced intercity trunk
lines, using both fiber-optic cable and digital
microwave radio relay is facilitating communication
between urban centers; remote areas are reached by
a domestic satellite system; the number of
subscribers to mobile cellular telephone service is
growing rapidly
international: international service is provided by three
submarine fiber-optic cables in the Mediterranean and
Black Seas, linking Turkey with Italy, Greece, Israel,
Bulgaria, Romania, and Russia, by 12 Intelsat earth
stations, and by 328 mobile satellite terminals in the
Inmarsat and Eutelsat systems
Radio broadcast stations; AM 16, FM 72,
shortwave 6 (1998)
Radios: 11.3 million (1997)
Television broadcast stations: 69 (plus 476
low-power repeaters) (1997)
Televisions: 20.9 million (1997)
Internet Service Providers (ISPs): 24 (1 999)
I T^r a n s p 0 r fal fo n
Railways:
total: 8,607 km
standard gauge: 8,607 km 1 .435-m gauge (1 ,524 km
electrified) (1999)
Highways;
total: 382,397 km
paved: 95,599 km (including 1,726 km of
expressways)
unpaved: 286,798 km (1999 est.)
Waterways: about 1,200 km
Pipelines: crude oil 1,738 km; petroleum products
2,321 km; natural gas 708 km
Ports and harbors: Gemlik, Hopa, Iskenderun,
Istanbul, Izmir, Kocaeli (Izmit), Icel (Mersin), Samsun,
Trabzon
Merchant marine:
total: 547 ships (1 ,000 GRT or over) totaling
5,935,173 GRT/9,771 ,421 DWT
ships by type: bulk 155, cargo 244, chemical tanker
37, combination bulk 5, combination ore/oil 6,
container 20, liquified gas 5, passenger/cargo 1 ,
petroleum tanker 35, refrigerated cargo 3, roll-on/
roll-off 22, short-sea passenger 9, specialized tanker
5(1999 est.)
Airports: 118 (1999 est.)
Airports - with paved runways;
total: 82
over 3,047 m: 15
2,438 to 3,047 m: 27
1,524 to 2,437 m: 18
914 to 1,523 m: 16
under 914 m;5 (1999 est.)
Airports ■ with unpaved runways:
total: 36
1,524 to 2,437 m:1
914 to 1,523 m: 9
under 914 m: 26 (1 999 est.)
Heliports: 2 (1999 est.)
I ^ Military
Military branches; Land Forces, Navy (includes
Naval Air and Naval Infantry), Air Force, Coast Guard,
Gendarmerie
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 18,523,950 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,227,922 (2000 est.)
Military manpower - reaching military age
annually;
males: 664,024 (2000 est.)
Military expenditures - dollar figure: $6,737 billion
(FY97)
Military expenditures - percent of GDP: 4.3%
(FY97)
I Tran s n a f i o n a 1 Issues
Disputes - international: complex maritime, air, and
territorial disputes with Greece in Aegean Sea;
Cyprus question with Greece; dispute with
downstream riparian states (Syria and Iraq) over
water development plans for the Tigris and Euphrates
rivers; traditional demands regarding former
Armenian lands in Turkey have subsided
Illicit drugs: key transit route for Southwest Asian
heroin to Western Europe and - to a far lesser extent
the US - via air, land, and sea routes; major Turkish,
Iranian, and other international trafficking
organizations operate out of Istanbul; laboratories to
convert imported morphine base into heroin are in
remote regions of Turkey as well as near Istanbul;
government maintains strict controls over areas of
legal opium poppy cultivation and output of poppy
straw concentrate
503
Background: Annexed by Russia between 1 865 and
1885, Turkmenistan became a Soviet repubiic in
1925. It achieved its independence upon the
dissoiution of the USSR in 1 991 . President NIYAZOV
retains absolute control over the country and
opposition is not toierated. Extensive hydrocarbon/
natural gas reserves could prove a boon to this
underdeveloped country if extraction and delivery
projects can be worked out,
I G e 0 g r a p F y
Location: Central Asia, bordering the Caspian Sea,
between Iran and Kazakhstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Commonwealth of Independent
States
Area:
total: 488,100 sqkm
/and; 488,100 sq km
water: 0 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 3,736 km
border counfnes; Afghanistan 744 km, Iran 992 km,
Kazakhstan 379 km, Uzbekistan 1 ,621 km
Coastline: 0 km
note; Turkmenistan borders the Caspian Sea (1,768
km)
Maritime ciaims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising
to mountains in the south; low mountains along border
with Iran; borders Caspian Sea in west
Elevation extremes:
lowest point: Vpadma Akchanaya -81 m (note -
Sarygamysh Koli is a lake in north eastern
Turkmenistan whose water levels fluctuate widely; at
its shallowest, its level is -1 10 m; it is presently at -60
m, 20 m above Vpadina Akchanaya)
highest point: Ayrybaba 3,139 m
Natural resources: petroleum, natural gas, coal,
sulfur, salt
Land use:
arabie iand: 3%
permanent crops: 0%
permanent pastures: 63%
forests and woodiand: 8%
other: 26% (imest)
Irrigated land: 13,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: contamination of
soil and groundwater with agricultural chemicals,
pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of
a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish
the Aral Sea; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
. ■''■■p''eF''plT^
Population: 4,518,268 (July 2000 est.)
Age structure:
0-14 years: 38% (male 887,088; female 850,384)
15-64 years: 58% (male 1 ,277,176; female
1,321,465)
65 years and over: 4% (male 69,383; female
11 2,772) (2000 est.)
Population growth rate: 1.87% (2000 est.)
Birth rate: 28.88 births/1,000 population (2000 est.)
Death rate: 9.04 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1.11 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 73.3 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
totai population: 60.91 years
maie: 57.29 years
femaie: 64.71 years (2000 est.)
Total fertility rate: 3.63 children born/woman
(2000 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 77%, Uzbek 9.2%,
Russian 6.7%, Kazakh 2%, other 5.1% (1995)
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek
9%, other 7%
Literacy:
definition: age 15 and over can read and write
total population: 98%
maie: 99%
fema/e; 97% (1989 est.)
I Government
Country name:
conventionai tong form: none
conventionai short form: Turkmenistan
tocal tong form: none
iocal short form: T urkmenistan
former; Turkmen Soviet Socialist Republic
Data code: TX
Government type: republic
Capital: Ashgabat
Administrative divisions: 5 welayatlar (singular -
welayat): Ahal Welayaty (Ashgabat), Balkan Welayaty
(Nebitdag),DashhowuzWelayaty(formerlyTashauz),
Lebap Welayaty (Charjew), Mary Welayaty
note: administrative divisions have the same names
as their administrative centers (exceptions have the
administrative center name following in parentheses)
Independence: 27 October 1991 (from the Soviet
Union)
National holiday: Independence Day, 27 October
(1991)
Constitution: adopted 18 May 1992
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President and Chairman of the Cabinet
of Ministers Saparmurat NIYAZOV (since 27 October
1990, when the first direct presidential election
occurred); note - the president is both the chief of
state and head of government
head of government: President and Chairman of the
Cabinet of Ministers Saparmurat NIY/\\ZOV (since 27
October 1 990, when the first direct presidential
election occurred); note - the president is both the
chief of state and head of government
Turkmenistan (continued)
cabinet: Council of Ministers appointed by the
president
note: NIYAZOV''s term in office was extended
indefinitely on 28 December 1999 by the Assembly
(Majlis) during a session of the People''s Council (Halk
Maslahaty)
elections: president elected by popular vote for a
five-year term; election last held 21 June 1992 (next
scheduled to be held NA); note - President NIYAZOV
was unanimously approved as president for life by the
Assembly on 28 December 1 999); deputy chairmen of
the cabinet of ministers are appointed by the president
election results: Saparmurat NIYAZOV elected
president without opposition; percent of vote -
Saparmurat NIYAZOV 99.5%
Legislative branch: under the 1992 constitution,
there are two parliamentary bodies, a unicameral
People''s Council or Halk Maslahaty (more than 100
seats, some of which are elected by popular vote and
some of which are appointed; meets infrequently) and
a unicameral Assembly or Majlis (50 seats; members
are elected by popular vote to serve five-year terms)
elections: People''s Council - NA; Assembly - last held
12 December 1999 (next to be held NA 2004)
election results: Assembly - percent of vote by party -
NA; seats by party - NA; note - all 50 elected officials
preapproved by President NIYAZOV; most are from
the DPT
Judicial branch; Supreme Court, judges are
appointed by the president
Political parties and leaders; Democratic Party of
Turkmenistan or DPT [Saparmurat NIYAZOV]
nofe; formal opposition parties are outlawed;
unofficial, small opposition movements exist
underground or in foreign countries
International organization participation; CCC,
CIS, EAPC, EBRD, ECE, ECO, ESCAP, FAO, IBRD,
ICAO, ICRM, IDB, IFC, IFRCS, ILO, IMF, IMO,
Intelsat (nonsignatory user), IOC, lOM (observer),
ISO (correspondent), ITU, NAM, OIC, OPCW, OSCE,
PFP, UN, UNCTAD, UNESCO, UPU, WFTU, WHO,
WlPO, WMO, WToO, WTrO (observer)
Diplomatic representation in the US:
cWef of m/ss/on; Ambassador Halil UGUR
chancery: 2207 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [t] [202) 588-1500
FAX; [11(202)588-0697
Diplomatic representation from the US:
cfj/ef of m/ss/on; Ambassador Steven R. MANN
embassy: 9 Pushkin Street, Ashgabat
mailing address: use embassy street address
telephone: [9] (9312) 35-00-45, 35-00-46, 35-00-42,
51-13-06, Tie Line [8] 962-0000
FAX; [9](9312) 51-13-05
Flag description: green field with a vertical red
stripe near the hoist side, containing five carpet guls
(designs used in producing rugs) stacked above two
crossed olive branches similar to the olive branches
on the UN flag; a white crescent moon and five white
stars appear in the upper corner of the field just to the
ly side of the red stripe
I 6 c o"n''b my
Economy - overview: Turkmenistan is largely
desert country with nomadic cattle raising, intensive
agriculture in irrigated oases, and huge gas and oil
resources. One-half of its irrigated land is planted in
cotton, making it the world''s tenth largest producer. It
also possesses the world''s fifth largest resen/es of
natural gas and substantial oil resources. Until the end
of 1993, Turkmenistan had experienced less
economic disruption than other former Soviet states
because its economy received a boost from higher
prices for oil and gas and a sharp increase in hard
currency earnings. In 1994, Russia''s refusal to export
Turkmen gas to hard currency markets and mounting
debts of its major customers in the former USSR for
gas deliveries contributed to a sharp fall in industrial
production and caused the budget to shift from a
surplus to a slight deficit. With an authoritarian
ex-communist regime in power and a tribally based
social structure, Turkmenistan has taken a cautious
approach to economic reform, hoping to use gas and
cotton sales to sustain its inefficient economy.
Privatization goals remain limited. Turkmenistan is
working hard to open new gas export channels
through Iran and T urkey to Europe, but these will take
many years to realize. In 1998-99, Turkmenistan
faced revenue shortfalls due to the continued lack of
adequate export routes for natural gas and obligations
on extensive short-term external debt. Prospects in
the near future are discouraging because of
widespread internal poverty and the burden of foreign
debt. IMF assistance would seem to be necessary, yet
the government is not as yet ready to accept IMF
requirements. Turkmenistan''s 1999 deal to ship 20
billion cubic meters (bcm) of natural gas through
Russia''s Gazprom will help alleviate the 2000 fiscal
shortfall, but will not make up for the absence of
meaningful progress in economic reform.
GDP: purchasing power parity - $7.7 billion
(1999 est.)
GDP - real growth rate; 9% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,800
(1999 est.)
GDP - composition by sector:
agriculture: 10%
Industry: 62%
services: 28% (1 997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: 2.7%
highest 10%: 26.9% {m3)
inflation rate (consumer prices); 30% (1999 est.)
Labor force: 2.34 million (1996)
Labor force - by occupation: agriculture and
forestry 44%, industry and construction 19%, other
37% (1996)
Unemployment rate: NA%
Budget:
revenues: $521 million
expenditures: $548 million, including capital
expenditures of $83 million (1996 est.)
Industries: natural gas, oil, petroleum products,
textiles, food processing
Industrial production growth rate; NA%
Electricity - production; 8.745 billion kWh (1998)
Electricity - production by source:
fossil fuel: 99.94%
hydro: 0.06%
nuclear: 0%
other: 0%(m6)
Electricity - consumption; 5.453 billion kWh (1 998)
Electricity - exports: 2.74 billion kWh (1 998)
Electricity • imports: 60 million kWh (1998)
Agriculture - products: cotton, grain; livestock
Exports; $1.1 billion (1999 est.)
Exports - commodities: oil and gas 55%, cotton
22% (1998)
Exports - partners: Iran, Turkey, Russia,
Kazakhstan, Tajikistan, Azerbaijan
Imports: $1 .25 billion (1999 est.)
Imports - commodities: machinery and equipment
45%, chemicals, foodstuffs (1998)
Imports - partners: Ukraine, Turkey, Russia,
Germany, US, Kazakhstan, Uzbekistan
Debt - external: $2.1 billion (1999 est.)
Economic aid - recipient: $27.2 million (1995)
Currency: 1 Turkmen manat (TMM) = 100 tenesi
Exchange rates: Turkmen manats per US$1 -5,200
(January 2000), 5,350 (January 1999), 4,070
(January 1997), 2,400 (January 1996)
Fiscal year; calendar year
|r C 0 irTm uTil c~al i 0 nT ^
Telephones - main lines in use: 320,000 (1995)
Telephones - mobile cellular: NA
Telephone system: poorly developed
domestic: NA
international: linked by cable and microwave radio
relay to other CIS republics and to other countries by
leased connections to the Moscow international
gateway switch; a new telephone link from Ashgabat
to Iran has been established; a new exchange in
Ashgabat switches international traffic through T urkey
via Intelsat; satellite earth stations - 1 Orbita and 1
Intelsat
Radio broadcast stations: AM 16, FM 8, shortwave
2 (1998)
Radios; 1.225 million (1997)
Television broadcast stations: 3 (much
programming reiayed from Russia and Turkey) (1 997)
Televisions: 820,000(1997)
Internet Service Providers (ISPs): NA
I; Transportation
Railways;
fofa/;2,187km
broad gauge: 2,167 km 1.520-m gauge (1996 est.)
Highways;
total: 24,000 km
paved: 1 9,488 km (these roads are said to be
hard-surfaced, meaning that some are paved and
some are aii-weather gravei surfaced)
unpaved: 4,512 km (1996 est.)
505
Turkmenistan (continued)
Waterways: the Amu Darya is an important inland
waterway
Pipelines; crude oil 250 km; natural gas 4,400 km
Ports and harbors: Turkmenbashi
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 1 ,896 GRT/
3,389 DWT
ships by type: petroleum tanker 1 (1999 est.)
Airports: 64 (1994 est.)
Airports - with paved runways:
total: 22
2,438 to 3,047 m:t3
1,524 to 2,437 m:B
914 to 1,523 m:1 (1994 est.)
Airports - with unpaved runways:
total: 42
914 to 1,523 m: 7
under 914 m: 35 (1994 est.)
f Military
Military branches: Ministry of Defense (Army, Air
and Air Defense, Navy, Border Troops, and Internal
Troops), National Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1 ,141 ,227 (2000 est.)
Military manpower • fit for military service;
males age 15-49: 926,160 (2000 est.)
Military manpower - reaching military age
annually;
males: 48,467 (2000 est.)
Military expenditures • dollar figure; $90 million
(FY99)
Military expenditures - percent of GDP: 3.4%
(FY99)
1^ Transnational Issues
Disputes - international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan
Illicit drugs: limited illicit cultivator of opium poppy,
mostly for domestic consumption; limited government
eradication program; increasingly used as
transshipment point for illicit drugs from Southwest
Asia to Russia and Western Europe; also a
transshipment point for acetic anhydride destined for
Economy - overview: The US has the most
technologically powerful, diverse, advanced, and
largest economy in the world, with a per capita GDP of
$33,900. In this market-oriented economy, private
individuals and business firms make most of the
decisions, and government buys needed goods and
services predominantly in the private marketplace. US
business firms enjoy considerably greater flexibility
than their counterparts in Western Europe and Japan
in decisions to expand capital plant, lay off surplus
workers, and develop new products. At the same time,
they face higher barriers to entry in their rivals'' home
markets than the barriers to entry of foreign firms in
US markets. US firms are at or near the forefront in
technological advances, especially in computers and
in medical, aerospace, and military equipment,
although their advantage has narrowed since the end
of World War II. The onrush of technology largely
explains the gradual development of a "two-tier labor
market" in which those at the bottom lack the
education and the professional/technical skills of
those at the top and, more and more, fail to get pay
raises, health insurance coverage, and other benefits.
Since 1975, practically all the gains in household
income have gone to the top 20% of households. The
years 1994-99 witnessed solid increases in real
output, low inflation rates, and a drop in
unemployment to below 5%, Long-term problems
include inadequate investment in economic
infrastructure, rapidly rising medical costs of an aging
population, sizable tra','de654fb097059571c3a110ab4f24fe64ec1c6e44eac6e198a2bd350b7d0b951f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf10fe1f4f83f607ba4242c4cd42cc421e7fcc5575d8c98fdc35349f9a68bf17',2000,'FR','France','economy',130,'de deficits, and stagnation of
family income in the lower economic groups. The
outlook for 2000 is clouded by the continued economic
problems of Japan, Russia, Indonesia, Brazil, and
many other countries. Domestically, the potentially
most serious problem is the exuberant level of stock
prices in relation to corporate earnings.
GDP: purchasing power parity - $9,255 trillion
(1999 est.)
GDP - real growth rate: 4.1% (1999 est.)
GDP - per capita: purchasing power parity -
$33,900(1999 est.)
GDP - composition by sector:
agriculture: 2%
industry: 18%
services: 80% (1999)
Population below poverty line: 12.7% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 1 .5%
highest 10%; 28.5% (1994)
Inflation rate (consumer prices): 2.2% (1999)
Labor force: 139.4 million (includes unemployed)
(1999)
Labor force - by occupation: managerial and
professional 30.3%, technical, sales and
administrative support 29.2%, sen/ices 13.4%,
manufacturing, mining, transportation, and crafts
24.5%, farming, forestry, and fishing 2.6% (1999)
note: figures exclude the unemployed
United States (continued)
Unemployment rate: 4.2% (1999)
Budget:
revenues: $1 .828 trillion
expenditures: $1 .703 trillion, including capital
expenditures of $NA (1 999)
Industries: leading industrial power in the world,
highly diversified and technologically advanced;
petroleum, steel, motor vehicles, aerospace,
telecommunications, chemicals, electronics, food
processing, consumer goods, lumber, mining
Industrial production growth rate: 2.4%
(1999 est.)
Electricity - production: 3.62 trillion kWh (1998)
Electricity - production by source:
fossil fuel: 70.34%
hydro; 8.96%
nuclear: 18.61%
other; 2.09% (1998)
Electricity - consumption: 3.365 trillion kWh (1998)
Electricity - exports: 12.772 billion kWh (1998)
Electricity - imports: 39.513 billion kWh (1998)
Agriculture - products: wheat, other grains, corn,
fruits, vegetables, cotton; beef, pork, poultry, dairy
products; forest products; fish
Exports: $663 billion (f.o.b., 1998 est.)
Exports - commodities: capital goods,
automobiles, industrial supplies and raw materials,
consumer goods, agricultural products
Exports ■ partners: Canada 23%, Mexico 12%,
Japan 8%, UK 6%, Germany 4%, France 3%,
Netherlands 3% (1998)
Imports: $912 billion (c.i.f., 1998 est.)
Imports - commodities: crude oil and refined
petroleum products, machinery, automobiles,
consumer goods, industrial raw materials, food and
beverages
Imports - partners: Canada 19%, Japan 13%,
Mexico 10%, China 8%, Germany 5%, UK 4%,
Taiwan 4% (1998)
Debt - external: $862 billion (1995 est.)
Economic aid - donor: ODA, $6.9 billion (1997)
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: British pounds per US$ - 0.6092
(January 2000), 0.61 80 (1 999), 0.6037 (1998), 0.61 06
(1997), 0.6403 (1996), 0.6335 (1995); Canadian
dollars (Can$) per US$ - 1 .4489 (January 2000),
1.4857 (1999), 1.4835 (1998), 1.3846 (1997), 1.3635
(1996), 1.3724 (1995); French francs (F) per US$ -
5.65 (January 1999), 5.8995 (1998), 5.8367 (1997),
5.1155 (1996), 4.9915 (1995), 5.5520 (1994); Italian
lire (Lit) per US$ - 1,668.7 (January 1999), 1,763.2
(1998), 1,703.1 (1997), 1,542.9 (1996), 1,628.9
(1995), 1,612.4 (1994); Japanese yen per US$ -
105.16 (January 2000), 113.91 (1999), 130.91 (1998),
120.99 (1997), 108.78 (1996), 94.06 (1995); German
deutsche marks (DM) per US$ - 1 .69 (January 1 999),
1.9692 (1998), 1.7341 (1997), 1.5048 (1996), 1.4331
(1995), 1.6228 (1994); Euro per US$ - 0.98673
(January 1999), 0.93863 (1999)
note: France, Italy, and Germany have adopted the
euro since 1998
Fiscal year: 1 October - 30 September
I Co mm li h i c a t i 0 n s
Telephones - main lines in use: 178 million (1999)
Telephones - mobile cellular: 55.312 million
(1997)
Telephone system:
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries every form of telephone traffic; a
rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: 24 ocean cable systems in use; satellite
earth stations - 61 Intelsat (45 Atlantic Ocean and 16
Pacific Ocean), 5 Intersputnik (Atlantic Ocean region),
and 4 Inmarsat (Pacific and Atlantic Ocean regions)
(2000)
Radio broadcast stations: AM about 5,000, FM
about 5,000, shortwave 18 (1998)
Radios: 575 million (1997)
Television broadcast stations: more than 1 ,500
(including nearly 1 ,000 stations affiliated with the five
major networks - NBC, ABC, CBS, FOX, and PBS; in
addition, there are about 9,000 cable TV systems)
(1997)
Televisions: 219 million (1997)
Internet Service Providers (ISPs): 7,600
(1999 est.)
I alt s^^o^FTa t i 0 n "
Railways:
total: 240,000 km mainline routes (nongovernment
owned)
standard gauge: 240,000 km 1 .435-m gauge (1 989)
Highways:
fofa/;6,348,227 km
paved: 3,732,757 km (including 88,727 km of
expressways)
unpaved: 2,615,470 km (1997 est.)
Waterways: 41 ,009 km of navigable inland
channels, exclusive of the Great Lakes
Pipelines: petroleum products 276,000 km; natural
gas 331 ,000 km (1991)
Ports and harbors: Anchorage, Baltimore, Boston,
Charleston, Chicago, Duluth, Hampton Roads,
Honolulu, Houston, Jacksonville, Los Angeles, New
Orleans, New York, Philadelphia, Port Canaveral,
Portland (Oregon), Prudhoe Bay, San Francisco,
Savannah, Seattle, Tampa, Toledo
Merchant marine:
total: 386 ships (1 ,000 GRT or over) totaling
11,634,608 GRT/15.574,117 DWT
ships by type: barge carrier 10, bulk 67, cargo 28,
chemical tanker 14, combination bulk 2, container 84,
liquified gas 10, multi-functional large load carrier 3,
passenger 7, passenger/cargo 1, petroleum tanker
104, roll-on/roll-off 43, short-sea passenger 3,
specialized tanker 1 , vehicle carrier 9 (1999 est.)
Airports: 14,572 (1999 est.)
Airports - with paved runways:
fofa/;5,174
over 3,047 m: 180
2,438 to 3,047 m:22^
1,524 to 2,437 m: 1,310
914 to 1,523 m: 2, 448
under 914 m: 1 ,01 5 (1 999 est.)
Airports - with unpaved runways:
total: 9,398
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 155
914 to 1,523 m: 1,561
under 914 m; 7,574 (1999 est.)
Heliports: 118 (1999 est.)
I" Military
Military branches: Department of the Army,
Department of the Navy (includes Marine Corps),
Department of the Air Force
note; the Coast Guard is normally subordinate to the
Department of Transportation, but in wartime reports
to the Department of the Navy
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49; 70,502,691 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,056,762 (2000 est.)
Military expenditures - dollar figure: $276.7 billion
(FY1999 est.)
Military expenditures - percent of GDP: 3.2%
(FY1999est.)
f r an s n "a t ion a I Issues
Disputes ■ international: maritime boundary
disputes with Canada (Dixon Entrance, Beaufort Sea,
Strait of Juan de Fuca, Machias Seal Island); US
Naval Base at Guantanamo Bay is leased from Cuba
and only mutual agreement or US abandonment of the
area can terminate the lease; Haiti claims Navassa
Island; US has made no territorial claim in Antarctica
(but has reserved the right to do so) and does not
recognize the claims of any other nation; Marshall
Islands claims Wake Island
Illicit drugs: consumer of cocaine shipped from
Colombia through Mexico and the Caribbean;
consumer of heroin, marijuana, and increasingly
methamphetamines from Mexico; consumer of
high-quality Southeast Asian heroin; illicit producer of
cannabis, marijuana, depressants, stimulants,
hallucinogens, and methamphetamines;
drug-money-laundering center
523
Economy - overview: Western Sahara, a territory
poor in natural resources and lacking sufficient
rainfall, depends on pastoral nomadism, fishing, and
phosphate mining as the principal sources of income
for the population. Most of the food for the urban
population must be imported. All trade and other
economic activities are controlled by the Moroccan
Government. Incomes and standards of living are
substantially below the Moroccan level.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP ■ composition by sector:
agriculture: NA%
industry: NA%
services: 40%-45% (1 996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force; 12,000
Labor force - by occupation: animal husbandry
and subsistence farming 50%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: phosphate mining, handicrafts
Industrial production growth rate; NA%
Electricity - production: 85 million kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%{im)
Electricity - consumption: 79 million kWh (1998)
Electricity - exports; 0 kWh (1998)
542
Western Sahara (continued)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: fruits and vegetables
(grown in the few oases); camels, sheep, goats (kept
by nomads)
Exports: $NA
Exports - commodities: phosphates 62%
Exports - partners: Morocco claims and
administers Western Sahara, so trade partners are
included in overall Moroccan accounts
Imports: $NA
Imports - commodities: fuel for fishing fleet,
foodstuffs
Imports - partners: Morocco claims and administers
Western Sahara, so trade partners are included in
overall Moroccan accounts
Debt - external: $NA
Economic aid ■ recipient: $NA
Currency: 1 Moroccan dirham (DH) = 100 centimes
Exchange rates: Moroccan dirhams (DH) per
US$1 - 10.051 (January 2000), 9.804 (1999), 9.604
(1998), 9.527 (1997), 8.716 (1996), 8.540 (1995)
Fiscal year: calendar year
I Communications
if.''
Telephones - main lines in use: about 2,000
(1999 est.)
Telephones - mobile cellular: 0 (1 999)
Telephone system: sparse and limited system
domestic: NA
international: Wed into Morocco''s system by
microwave radio relay, tropospheric scatter, and
satellite; satellite earth stations - 2 Intelsat (Atlantic
Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0, shortwave
0(1998)
Radios: 56,000(1997)
Television broadcast stations: NA
Televisions: 6,000(1997)
Internet Service Providers (ISPs): NA
I Transportation
Railways: 0 km
Highways:
total: 6,200 km
paved: 1 ,350 km
unpaved: 4,850 km (1991 est.)
Ports and harbors: Ad Dakhia, Cabo Bojador,
Laayoune (El Aaiun)
Airports: 12 (1999 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 {mo est.)
Airports - with unpaved runways:
total: 9
1,524 to 2,437 m:t
914 to 1,523 m: 5
under 914 m: 3(1 999 est.)
Heliports: 1 (1999 est.)
F Military
Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
''fransnationajissues
Disputes - international: claimed and administered
by Morocco, but sovereignty is unresolved and the UN
is attempting to hold a referendum on the issue; the
UN-administered cease-fire has been in effect since
September 1991
543
iWorld
I Geography
Map references: World, Time Zones
Area:
total: 510.072 million sq km
land: 148,94 miliion sq km
water: 361.132 miliion sq km
note: 70.8% of the world''s surface is water, 29.2% is
iand
Area - comparative: land area about 1 6 times the
size of the US
Land boundaries: the land boundaries in the world
total 251,480.24 km (not counting shared boundaries
twice)
Coastline: 356,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most, but can
vary
continental shelf: 200-m depth ciaimed by most or to
depth of expioitation; others ciaim 200 nm or to the
edge of the continental margin
exclusive fishing zone: 200 nm claimed by most, but
can vary
exclusive economic zone: 200 nm ciaimed by most,
but can vary
territorial sea: 12 nm claimed by most, but can vary
note: boundary situations with neighboring states
prevent many countries from extending their fishing or
economic zones to a fuli 200 nm; 43 nations and other
areas that are landlocked include Afghanistan,
Andorra, Armenia, Austria, Azerbaijan, Belarus,
Bhutan, Bolivia, Botswana, Burkina Faso, Burundi,
Central African Republic, Chad, Czech Repubiic,
Ethiopia, Holy See (Vatican City), Hungary,
Kazakhstan, Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Luxembourg, Malawi, Mali, Moldova,
Mongolia, Nepal, Niger, Paraguay, Rwanda, San
Marino, Siovakia, Swaziland, Switzerland, Tajikistan,
The Former Yugoslav Republic of Macedonia,
Turkmenistan, Uganda, Uzbekistan, West Bank,
Zambia, Zimbabwe
Climate: two large areas of polar climates separated
by two rather narrow temperate zones from a wide
equatorial band of tropical to subtropical climates
Terrain: the greatest ocean depth is the Mariana
Trench at 10,924 m in the Pacific Ocean
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Mount Everest 8,850 m (1999 est.)
Natural resources: the rapid using up of
nonrenewable mineral resources, the depletion of
forest areas and wetlands, the extinction of animal
and plant species, and the deterioration in air and
water quality (especially in Eastern Europe, the former
USSR, and China) pose serious long-term problems
that governments and peoples are only beginning to
address
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 26%
forests and woodland: 32%
other: 31% {1993 est)
Irrigated land: 2,481,250 sq km (1993 est.)
Natural hazards: large areas subject to severe
weather (tropical cyclones), natural disasters
(earthquakes, landslides, tsunamis, volcanic
eruptions)
Environment - current issues: large areas subject
to overpopulation, industrial disasters, pollution (air,
water, acid rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertification), loss of
wildlife, soil degradation, soil depletion, erosion
I Pc 0 pi e
Population: 6,080,671 ,21 5 (July 2000 est.)
Age structure:
0-14 years: 29.92% (male 932,832,91 3; female
885,970,165)
15-64 years: 63.17% (male 1 ,942,402,264; female
1,898,479,062)
65 years and over: 6.91 % (male 1 84,072,470; female
235,017,660) (2000 est.)
Population growth rate: 1 .3% (2000 est.)
Birth rate: 22 births/1 ,000 population (2000 est.)
Death rate: 9 deaths/1 ,000 population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1.01 male(s)/female (2000 est.)
Infant mortality rate: 54 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 64 years
male: 62 years
female: 65 years (2000 est.)
Total fertility rate: 2.8 children born/woman
(2000 est.)
i Government
Data code: none; there is no FIPS 1 0-4 country code
for the World, so the Factbook uses the "W" data code
from DIAM 65-18 "Geopolitical Data Elements and
Related Features," Data Standard No. 3, March 1984,
published by the Defense Intelligence Agency; see the
Cross-Reference List of Country Data Codes appendix
Administrative divisions: 267 nations, dependent
areas, other, and miscellaneous entries
Legal system: all members of the UN (excluding
Yugoslavia) plus Switzerland are parties to the statute
that established the International Court of Justice
(ICJ) or World Court
I " Economy ~
Economy - overview: Growth in global output
(gross world product, GWP) rose to 3% in 1999 from
2% in 1998 despite continued recession in Japan,
severe financial difficulties in other East Asian
countries, and widespread dislocations in several
transition economies, notably Russia. The US
economy continued its remarkable sustained
prosperity, growing at 4.1% in 1999, and accounted
for 23% of GWP. Western Europe''s economies grew
at roughly 2%, not enough to cut deeply into the
region''s high unemployment; the EU economies
produced 20% of GWP. China, the second largest
economy in the world, continued its strong growth and
accounted for 12% of GWP. Japan grew at only 0.3%
in 1999; its share in GWP is 7%. As usual, the 15
successor nations of the USSR and the other old
Warsaw Pact nations experienced widely different
rates of growth. The developing nations varied widely
in their growth results, with many countries facing
population increases that eat up gains in output.
Externally, the nation-state, as a bedrock
economic-political institution, is steadily losing control
over international flows of people, goods, funds, and
technology. Internally, the central government often
finds its control over resources slipping as separatist
regional movements - typically based on ethnicity -
gain momentum, e.g., in many of the successor states
of the former Soviet Union, in the former Yugoslavia,
in India, and in Canada. In Western Europe,
544
World (continued)
governments face the difficult political problem of
channeling resources away from welfare programs in
order to increase investment and strengthen
incentives to seek employment. The addition of 80
million people each year to an already overcrowded
globe is exacerbating the problems of pollution,
desertification, underemployment, epidemics, and
famine. Because of their own internal problems and
priorities, the industrialized countries devote
insufficient resources to deal effectively with the
poorer areas of the world, which, at least from the
economic point of view, are becoming further
marginalized. Continued financial difficulties in East
Asia, Russia, and many African nations cast a shadow
over short-term global economic prospects. The
introduction of the euro as the common currency of
much of Western Europe in January 1999, while
strengthening prospects for an integrated economic
powerhouse, poses serious economic risks because
of varying levels of income and cultural and political
differences among the participating nations. (For
specific economic developments in each country of
the world in 1999, see the individual country entries.)
GDP: GWP (gross world product) - purchasing
power parity - $40.7 trillion (1999 est.)
GDP - real growth rate: 3% (1999 est.)
GDP - per capita: purchasing power parity - $6,800
(1999 est.)
GDP • composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): all countries
25%; developed countries 1% to 3% typically;
developing countries 5% to 60% typically (1999 est.)
note: national inflation rates vary widely in individual
cases, from stable prices in Japan to hyperinflation in
a number of Third World countries
Labor force: NA
Labor force - by occupation: agricultue NA%,
industry NA%, services NA%
Unemployment rate: 30% combined
unemployment and underemployment In many
non-industriallzed countries; developed countries
typically 4%-12% unemployment (1999 est.)
Industries: dominated by the onrush of technology,
especially in computers, robotics,
telecommunications, and medicines and medical
equipment; most of these advances take place in
OECD nations; only a small portion of non-OECD
countries have succeeded in rapidly adjusting to these
technological forces; the accelerated development of
new industrial (and agricultural) technology is
complicating already grim environmental problems
Industrial production growth rate: NA%
Electricity - production: 12,342.7 billion kWh (1994)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: 12,342.7 billion kWh
(1994)
Exports: $5.6 trillion (f.o.b., 1999 est.)
Exports - commodities: the whole range of
industrial and agricultural goods and services
Exports - partners: in value, about 75% of exports
from the developed countries
Imports: $5.6 trillion (f.o.b., 1999 est.)
Imports - commodities: the whole range of
industrial and agricultural goods and sen/ices
Imports - partners: in value, about 75% of imports
by the developed countries
Debt - external: $2 trillion for less developed
countries (1999 est.)
Economic aid - recipient: traditional worldwide
foreign aid $50 biliion (1997 est.)
„„ C ^nTin u n i c a t folni s
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system;
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM NA,
shortwave NA
Radios; NA
Television broadcast stations: NA
Televisions; NA
Internet Service Providers (ISPs): 13,1 19 (1999)
f transporTation ~
Railways;
total: 1 ,201 ,337 km includes about 1 90,000 to
195,000 km of electrified routes of which 147,760 km
are in Europe, 24,509 km in the Far East, 1 1 ,050 km
in Africa, 4,223 km in South America, and 4,1 60 km in
North America; note - fastest speed in daily service is
300 km/hr attained by France''s Societe Nationals des
Chemins-de-Fer Francais (SNCF) Le Train a Grande
Vitesse (TGV) - Atlantique line
broad gauge: 251 ,153 km
standard gauge: 710,754 km
narrow gauge: 239,430 km
Highways;
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Chiba, Houston, Kawasaki,
Kobe, Marseille, Mina'' al Ahmadi (Kuwait), New
Orleans, New York, Rotterdam, Yokohama
^
Military expenditures - dollar figure; aggregate
real expenditure on arms worldwide in 1 999 remained
at approximately the 1 998 level, about three-quarters
of a trillion dollars (1 999 est.)
Military expenditures - percent of GDP: roughly
2% of gross world product (1999 est.)
lYemen
r 0
100 200 km
0
100 200 mi','8c66cdba560f8bf4037000c927d9d031a23f48ec1f587a7e2c638b18a92ed8b0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d40484761ede73c7808fd5ce2c2488853010eb71a32f580c487a1f25b8f2670b',2000,'MZ','Mozambique','economy',142,'Economy - overview: One of the world''s poorest
countries, Comoros is made up of three islands that
have inadequate transportation links, a young and
rapidly increasing population, and few natural
resources. The low educational level of the labor force
contributes to a subsistence level of economic activity,
high unemployment, and a heavy dependence on
foreign grants and technical assistance. Agriculture,
including fishing, hunting, and forestry, is the leading
sector of the economy. It contributes 40% to GDP,
employs 80% of the labor force, and provides most of
the exports. The country is not self-sufficient in food
production; rice, the main staple, accounts for the bulk
of imports. The government is struggling to upgrade
education and technical training, to privatize
commercial and industrial enterprises, to improve
health services, to diversify exports, to promote
tourism, and to reduce the high population growth
rate. Continued foreign support is essential if the goal
of 4% annual GDP growth is to be met.
GDP: purchasing power parity - $410 million
(1998 est.)
GDP - real growth rate: 0% (1998 est.)
GDP - per capita: purchasing power parity - $725
(1998 est.)
GDP - composition by sector:
agriculture: 40%
industry: 5%
services: 55% (1997 est.)
Population below poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
infiation rate (consumer prices): 4% (1998)
Labor force: 1 44,500 (1 996 est.)
Labor force - by occupation: agriculture 80%,
government 3%
Unemployment rate: 20% (1996 est.)
Budget;
revenues: $48 million
expenditures: $53 million, including capital
expenditures of $NA (1997)
Industries: tourism, perfume disfillation, textiles,
furniture, jewelry, construction materials, soft drinks
Industrial production growth rate: NA%
Electricity - production: 15 million kWh (1998)
Electricity - production by source;
fossil fuel: 86.67%
hydro: 13.33%
nuclear: 0%
other: 0% (1993)
Electricity - consumption: 14 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: vanilla, cloves, perfume
essences, copra, coconuts, bananas, cassava
(tapioca)
Exports: $9.3 million (f.o.b., 1998 est.)
Exports - commodities: vanilla, ylang-ylang,
cloves, perfume oil, copra
Exports - partners: France 43%, US 43%, Germany
7% (1997)
Imports; $49.5 million (f.o.b., 1998 est.)
Imports - commodities: rice and other foodstuffs,
consumer goods; petroleum products, cement,
transport equipment
Imports - partners: France 59%, South Africa 15%,
Kenya 6% (1997)
Debt - external; $197 million (1997 est.)
Economic aid - recipient: $28.1 million (1997)
Currency: 1 Comoran franc (CF) = 100 centimes
Exchange rates: Comoran francs (CF) per US$1 -
485.44 (January 2000), 461 .77 (1 999), 442.46 (1 998),
437.75 (1997), 383.66 (1996), 374.36 (1995)
note: prior to January 1999, the official rate was
pegged to the French franc at 75 CFs per French
franc; since 1 January 1999, the CF is pegged to the
euro at a rate of 491 .9677 Comoran francs per euro
Fiscal year: calendar year
112
Comoros (continued)
f Communications
Telephones - main lines in use: 5,000 (1995)
Telephones - mobile cellular: 0 (1995)
Telephone system: sparse system of microwave
radio relay and HF radiotelephone communication
stations
domestic: HF radiotelephone communications and
microwave radio relay
international: HF radiotelephone communications to
Madagascar and Reunion
Radio broadcast stations: AM 1 , FM 2, shortwave
1 (1998)
Radios: 90,000(1997)
Television broadcast stations: 0(1998)
Televisions: 1,000(1997)
Internet Service Providers (ISPs): 1 (1999)
I Transportation ”
Railways: 0 km
Highways:
total: 880 km
paved: 673 km
unpaved: 207 km (1996 est.)
Ports and harbors: Fomboni, Moroni,
Moutsamoudou
Merchant marine: none (1999 est.)
Airports: 4 (1999 est.)
Airports - with paved runways:
total: 4
2,438 to 3,047 m:t
914 to 1,523 m: 3 {mo est.)
f M i n t a r y ~ ~
Military branches: Comoran Security Force
Military manpower - availability:
males age 15-49: 136,914 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 81 ,477 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
I fransnationaF Issued
Disputes - international: claims
French-administered Mayotte; the islands of Anjouan
(Nzwani) and Moheli (Mwall) have moved to secede
from Comoros
^Congo, Democratic
IRepublic of the
Background: Almost five centuries as a Portuguese
colony came to a close with independence in 1975.
Large-scale emigration by whites, economic
dependence on South Africa, a severe drought, and a
prolonged civil war hindered the country''s
development. The ruling party formally abandoned
Marxism in 1989, and a new constitution the following
year provided for multiparty elections and a free
market economy. A UN-negotiated peace agreement
with rebei forces ended the fighting in 1992.
Economy - overview: no economic activity
|“^"~f7Tirs^p 0 r t at i olT
Ports and harbors: none; offshore anchorage only
I Military
Military ■ note: defense is the responsibility of the
US
f lrTriVn a 1 1 o n a I I s s u e s
Disputes - international: claimed by Haiti
the century-old system of rule by hereditary premiers
and instituted a cabinet system of government.
Reforms in 1990 established a multiparty democracy
within the framework of a constitutional monarchy.
I'' ^
Location: Southern Asia, between China and India
Geographic coordinates; 28 00 N, 84 00 E
Map references: Asia
Area:
total: 140,800 sq km
land: 136,800 sq km
water: 4,000 sq km
Area - comparative: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1 ,236 km, India 1 ,690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe
winters in north to subtropical summers and mild
winters in south
Terrain: Terai or flat river plain of the Ganges in
south, central hill region, rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,850 m (1999 est.)
Natural resources: quartz, water, timber,
hydropower, scenic beauty, small deposits of lignite,
copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
permanent pastures: 15%
forests and woodland: 42%
of/ier;26%(1993est.)
Irrigated land; 8,500 sq km (1993 est.)
Natural hazards: severe thunderstorms, flooding,
Environment - current issues: deforestation
(overuse of wood for fuel and lack of alternatives);
contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life
Conservation
Geography - note: landlocked; strategic location
between China and India; contains eight of world''s 1 0
highest peaks
.
Population: 24,702,1 1 9 (July 2000 est.)
Age structure:
0-14 years: 41 % (male 5,187,805; female 4,860,583)
15-64 years: 56% (male 7,056,784; female
6,746,293)
65 years and over: 3% (male 422,314; female
428,340) (2000 est.)
Population growth rate: 2.34% (2000 est.)
Birth rate: 33.83 births/1,000 population (2000 est.)
Death rate: 10.41 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .05 male(s)/female (2000 est.)
349
Nepal (continued)
Infant mortality rate: 75.93 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 57.84 years
male: 58.3 years
female: 57.35 years (2000 est.)
Total fertility rate: 4.68 children born/woman
(2000 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais, Limbus,
Sherpas
Religions: Hindu 90%, Buddhist 5%, Muslim 3%,
other 2% (1981)
note: only official Hindu state in the world
Languages: Nepali (officiai), over 20 other
languages divided into numerous dialects
Literacy:
definition: age 15 and over can read and write
total population: 27.5%
male: 40.9%
/ema/e; 14% (1995 est.)
People - note: refugee issue over the presence in
Nepai of approximateiy 96,500 Bhutanese refugees,
90% of whom are in seven United Nations Office of
the High Commissioner for Refugees (UNHCR)
camps
Economy - overview: Nepal is among the poorest
and least developed countries in the worid with nearly
half of its popuiation iiving below the poverty line.
Agriculture is the mainstay of the economy, providing
a iiveiihood for over 80% of the popuiation and
accounting for 41% of GDP. Industrial activity mainly
involves the processing of agricuiturai produce
including jute, sugarcane, tobacco, and grain.
Production of textiles and carpets has expanded
recently and accounted for about 80% of foreign
exchange earnings in the past three years.
Agricultural production is growing by about 5% on
average as compared with annual population growth
of 2.3%. Since May 1991 , the government has been
moving forward with economic reforms, particuiariy
those that encourage trade and foreign investment,
e.g., by reducing business licenses and registration
requirements in order to simplify investment
procedures. The government has also been cutting
expenditures by reducing subsidies, privatizing state
industries, and laying off civil servants. More recently,
however, political Instability - five different
governments over the past few years - has hampered
Kathmandu''s ability to forge consensus to impiement
key economic reforms. Nepai has considerable scope
for accelerating economic growth by exploiting its
potential In hydropower and tourism, areas of recent
foreign investment interest. Prospects for foreign
trade or investment in other sectors wili remain poor,
however, because of the smaii size of the economy,
its technologicai backwardness, its remoteness, its
landlocked geographic location, and its susceptibility
to natural disaster. The international community''s roie
of funding more than 60% of Nepai''s development
budget and more than 28% of total budgetary
expenditures will likely continue as a major ingredient
of growth.
GDP: purchasing power parity - $27.4 billion
(1999 est.)
GDP - real growth rate: 3.4% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,1 00
(1999 est.)
GDP - composition by sector:
agriculture: 4t%
industry: 22%
services: 37% (1998)
Population below poverty line: 42% (1995-96 est.)
Household Income or consumption by percentage
share:
lowest 10%: 3.2%
highest 10%: 29.8% (1995-96)
inflation rate (consumer prices): 1 1 .8% (FY98/99
est.)
350
Nepal (continued)
Labor force: 10 million (1996 est.)
note: severe lack of skilled labor
Labor force - by occupation: agriculture 81%,
services 16%, industry 3%
Unemployment rate: NA%; substantial
underemployment (1999)
Budget:
revenues: $536 million
expenditures: million, including capital
expenditures of $NA (FY96/97 est.)
Industries: tourism, carpet, textile; small rice, jute,
sugar, and oilseed mills; cigarette; cement and brick
production
Industrial production growth rate: NA%
Electricity - production: 1.17 billion kWh (1998)
Electricity - production by source:
fossii fuel: 5.\\3%
hydro: 94.87%
nuclear: 0%
other: 0%{\\998)
Electricity - consumption: 1.212 billion kWh (1998)
Electricity - exports: 72 million kWh (1 998)
Electricity - imports: 196 million kWh (1998)
Agriculture - products: rice, corn, wheat,
sugarcane, root crops; milk, water buffalo meat
Exports: $485 million (f.o.b., 1998), but does not
include unrecorded border trade with India
Exports - commodities: carpets, clothing, leather
goods, jute goods, grain
Exports ■ partners: India 33%, US 26%, Germany
25% (FY97/98)
Imports: $1.2 billion (f.o.b., 1998)
Imports - commodities: gold, machinery and
equipment, petroleum products, fertilizer
Imports - partners: India 31%, China/Hong Kong
16%, Singapore 14% (FY97/98)
Debt - external: $2.4 billion (1 997)
Economic aid - recipient: $41 1 million (FY97/98)
Currency: 1 Nepalese rupee (NR) = 100 paisa
Exchange rates: Nepalese rupees (NRs) per
US$1 - 68.784 (January 2000), 68.253 (1 999), 65.976
(1998), 58.010 (1997), 56.692 (1996), 51.890 (1995)
Fiscal year: 1 6 July - 1 5 July
I" Communications
Telephones - main lines in use: 236,816 (January
2000)
Telephones - mobile cellular: NA
Telephone system: poor telephone and telegraph
sen/ice; fair radiotelephone communication service
and mobile cellular telephone network
domestic: NA
international: radiotelephone communications;
microwave landline to India; satellite earth station - 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 6, FM 5, shortwave
1 (January 2000)
Radios: 840,000(1997)
Television broadcast stations: 6 (1998)
Televisions: 130,000(1997)
Internet Service Providers (ISPs): NA
I " T r a n s p o r t a fi o n
Railways:
total: 101 km; note - all in Kosi close to Indian border
narrow gauge: 101 km 0.762-m gauge
Highways:
total: 1 3, 223 km
paved: 4,073 km
unpaved: 9,150 km (April 1999)
Ports and harbors: none
Airports: 45 (1999 est.)
Airports - with paved runways:
total: 5
over 3,047 m:t
1,524 to 2,437 m: 3
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
total: 40
1,524 to 2,437 m: 2
914 to 1,523 m: 9
under 914 m: 29 (1999 est.)
" Mil i t”a fy
Military branches: Royal Nepalese Army, Royal
Nepalese Army Air Service, Nepalese Police Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 6,108,424 (2000 est.)
Military manpower • fit for military service:
males age 15-49: 3,174,809 (2000 est.)
Military manpower - reaching military age
annually:
mates.'' 287,032 (2000 est.)
Military expenditures - dollar figure: $44 million
(FY96/97)
Military expenditures - percent of GDP: 0.9%
(FY96/97)
I fransnational lsstTes
Disputes - international: over approximately
96,500 Bhutanese refugees in Nepal
Illicit drugs: illicit producer of cannabis for the
domestic and international drug markets; transit point
for opiates from Southeast Asia to the West
iNetherlands
0 25 50 km
25 50 mi
, Den
North Helder,
EuropoortI
Background: The Kingdom of the Netherlands was
formed in 1 81 5. In 1 830 Belgium seceded and formed
a separate kingdom. The Netherlands remained
neutral in World War I but suffered a brutal invasion
and occupation by Germany in World War II. A
modern, industrialized nation, the Netherlands Is also
a large exporter of agricultural products. The country
was a founding member of NATO and the EC, and
participated in the introduction of the euro in 1999.
I * Geo g r a”p h y
Location: Western Europe, bordering the North Sea,
between Belgium and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total: 41 ,532 sq km
land: 33,889 sq km
water: 7,643 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: temperate; marine; cool summers and mild
winters
Terrain: mostly coastal lowland and reclaimed land
(polders); some hills in southeast
Elevation extremes:
lowest point: Prins Alexanderpolder -7 m
highest point: Vaalserberg 321 m
Natural resources: natural gas, petroleum, arable
land
Land use:
arable land: 25%
permanent crops: 3%
351
Netherlands (continued)
permanent pastures: 25%
forests and woodland: 8%
of/ier;39%(1996 est.)
Irrigated land: 6,000 sq km (1996 est.)
Natural hazards: the extensive system of dikes and
dams protects neariy one-haif of the totai area from
being flooded
Environment - current issues: water pollution in
the form of heavy metals, organic compounds, and
nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Environment ■ international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Biodiversity, Climate
Change-Kyoto Protocol
Geography - note: located at mouths of three major
European rivers (Rhine, Maas or Meuse, and
Schelde)
i People
Population: 15,892,237 (July 2000 est.)
Age structure:
0-14 years: 1 8% (male 1 ,497,290; female 1 ,431 ,671 )
15-64 years: 68% (male 5,490,518; female
5,305,848)
65 years and over: 14% (male 885,839; female
1,281,071) (2000 est.)
Population growth rate: 0.57% (2000 est.)
Birth rate: 12.12 births/1,000 population (2000 est.)
Death rate: 8.72 deaths/1 ,000 population
(2000 est.)
Net migration rate: 2.3 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 4.42 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.28 years
male: 75.4 years
female: 81 .28 years (2000 est.)
Totai fertiiity rate: 1 .64 children born/woman
(2000 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 91%, Moroccans, Turks, and
other 9% (1999 est.)
Religions: Roman Catholic 34%, Protestant 25%,
Muslim 3%, other 2%, unaffiliated 36% (1991)
Languages: Dutch
Literacy:
definition: age 15 and over can read and write
total population: 99% (1 979 est.)
male: NA%
female: NA%
Economy - overview: The Netherlands is a
prosperous and open economy in which the
government has successfully reduced its role since
the 1980s. Industrial activity is predominantly in food
352
Netherlands (continued)
processing, chemicals, petroleum refining, and
electrical machinery. A highly mechanized agricultural
sector employs no more than 4% of the labor force but
provides large surpluses for the food-processing
industry and for exports. The Dutch rank third
wrorldwide in value of agricultural exports, behind the
US and France. The Netherlands successfully
addressed the issue of public finances and stagnating
job growth long before its European partners. This has
helped cushion the economy from a slowdown in the
euro area. Strong 3.8% GDP growth in 1998 was
followed by an only slightly lower 3.4% expansion in
1999. The outlook remains favorable, with real GDP
growth in 2000 projected at 3.25%, along with a small
budget surplus. The Dutch were among the first 1 1 EU
countries establishing the euro currency zone on 1
January 1999.
GDP; purchasing power parity - $365.1 billion
(1999 est.)
GDP - real growth rate: 3.4% (1999 est.)
GDP - per capita: purchasing power parity -
$23,100 (1999 est.)
GDP - composition by sector:
agriculture: 3.5%
industry: 26.8%
services: 69.7% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: 2.9%
highest f0%.- 24.7% (1991)
Inflation rate (consumer prices); 2.2% (1999 est.)
Labor force: 7 million (1998 est.)
Labor force - by occupation: services 73%,
industry 23%, agriculture 4% (1998 est.)
Unemployment rate: 3.5% but generous welfare
benefits have prompted large numbers to drop out of
the labor market (1999 est.)
Budget;
revenues: $163 billion
expenditures: $170 billion, including capital
expenditures of $NA (1999 est.)
Industries: agroindustries, metal and engineering
products, electrical machinery and equipment,
chemicals, petroleum, construction, microelectronics,
fishing
Industrial production growth rate; 3% (1999)
Electricity - production: 88.736 billion kWh (1998)
Electricity - production by source;
fossil fuel: 91. 32%
hydro: 0.11%
nuclear: 4.08%
of/ier; 4.49% (1998)
Electricity - consumption: 94.325 billion kWh
(1998)
Electricity - exports: 400 million kWh (1998)
Electricity - imports: 12.2 billion kWh (1998)
Agriculture - products: grains, potatoes, sugar
beets, fruits, vegetables; livestock
Exports: $169 billion (f.o.b., 1998)
Exports - commodities: machinery and equipment,
chemicals, fuels; foodstuffs
Exports - partners: EU 78% (Germany 27%,
Belgium-Luxembourg 13%, France 11%, UK 10%,
Italy 6%), Central and Eastern Europe, US (1998)
Imports: $152 billion (f.o.b., 1998)
Imports - commodities: machinery and transport
equipment, chemicals, fuels; foodstuffs, clothing
Imports - partners: EU 61% (Germany 20%,
Belgium-Luxembourg 11%, UK 10%, France 7%), US
9%, Central and Eastern Europe (1998)
Debt -external: $0
Economic aid - donor: ODA, $3.4 billion (1 999)
Currency: 1 Netherlands guilder, gulden, or florin (f.)
= 100 cents; note - to be replaced by the euro on 1
January 2002
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); Netherlands guilders, gulden,
or florins (f.) per US$1 - 1.8904 (January 1999),
1.9837 (1998), 1.9513 (1997), 1.6859 (1996), 1.6057
(1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 2.20371 guilders per euro; the euro will replace the
local currency in consenting countries for all
transactions in 2002
Fiscal year: calendar year
I ^ iri tiiirnTTal i o li s
Telephones • main lines in use: 8.431 million
(1996)
Telephones - mobile cellular: 1 .01 6 million (1 996)
Telephone system; highly developed and well
maintained
domestic: Ihe existing system of multi-conductor
cables is gradually being replaced by fiber-optic
cables; the density of cellular telephone traffic is
rapidly increasing and further modernization of the
system is expected in the year 2001 , with the
introduction of the third generation of the Global
System for Mobile Communications (GSM)
international: 5 submarine cables; satellite earth
stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic
Ocean), 1 Eutelsat, and 1 1nmarsat (Atlantic and
Indian Ocean regions) (1996)
Radio broadcast stations: AM 4, FM 58, shortwave
3(1998)
Radios: 15.3 million (1996)
Television broadcast stations: 15 (plus five
low-power repeaters) (1997)
Televisions: 8.1 million (1997)
Internet Service Providers (ISPs): 70 (1999)
I Transportation
Railways:
total: 2,739 km
standard gauge: 2,739 km 1 .435-m gauge; (1 ,991 km
electrified) (1998)
Highways:
total: 125,575 km
paved: 1 13,018 km (including 2,235 km of
expressways)
unpaved: 12,557 km (1998 est.)
Waterways: 5,046 km, of which 47% is usable by
craft of 1 ,000 metric ton capacity or larger
Pipelines: crude oil 418 km; petroleum products 965
km; natural gas 10,230 km
Ports and harbors: Amsterdam, DelfzijI, Dordrecht,
Eemshaven, Groningen, Haarlem, Ijmuiden,
Maastricht, Rotterdam, Terneuzen, Utrecht
Merchant marine:
total: 563 ships (1 ,000 GRT or over) totaling
4,035,899 GRT/4,576,841 DWT
ships by type: bulk 3, cargo 343, chemical tanker 41 ,
combination bulk 2, container 56, liquified gas 20,
livestock carrier 1 , multi-functional large load carrier 8,
passenger 8, petroleum tanker 25, refrigerated cargo
32, roll-on/roll-off 16, short-sea passenger 3,
specialized tanker 5 (1999 est.)
note: many Dutch-owned ships are also operating
under the registry of Netherlands Antilles (1 998 est.)
Airports: 28 (1999 est.)
Airports - with paved runways;
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m:1 (1999 est.)
Airports ■ with unpaved r','347367d565efbfeffb68ac9eb1de34e48f6ca055496f8b251f1ba251e4e99c49','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9278a661f69da5a365199c1404498a90e706e45d7ebfc2d2670a0e652318190f',2000,'MZ','Mozambique','economy',143,'unways:
total: 9
914 to 1,523 m: 3
under 914 m: 6 [1999 esi.)
Heliports; 1 (1 999 est.)
I ” Military
Military branches: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and
Marine Corps), Royal Netherlands Air Force, Royal
Constabulary
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 4,090,273 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 3,566,882 (2000 est.)
Miiitary manpower - reaching military age
annually:
males: 96,684 (2000 est.)
Military expenditures - doliar figure; $6,956 billion
(FY98)
Military expenditures - percent of GDP: NA%
F f r a n s n a t i 0 n a I Issues
Disputes - international: none
Illicit drugs: major European producer of illicit
amphetamines and other synthetic drugs; important
gateway for cocaine, heroin, and hashish entering
Europe
353','fab4990d38ca62b75960b7db332373d77b681d26e26a53602070d20fe7e91e71','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d43fae41dce070547a3ec91390fc9275b8460407a88085e40d30b4b6b61004f',2000,'CK','Cook Islands','economy',154,'Economy - overview: no economic activity
Costa Rica ^
Location: Oceania, islands in the Coral Sea,
northeast of Australia
Geographic coordinates; 1 8 00 S, 1 52 00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
wafer; 0 sq km
note: includes numerous small islands and reefs
scattered over a sea area of about 1 million sq km,
with the Willis Islets the most important
Area - comparative: NA
Land boundaries; 0 km
Coastline: 3,095 km
Maritime claims;
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: NEGL
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly grass or scrub cover)
Irrigated land: 0sqkm(1993)
Natural hazards: occasional, tropical cyclones
Environment - current issues: no permanent fresh
wafer resources
Geography - note: important nesting area for birds
and turtles
Economy • overview: no economic activity
Economy - overview; A remote country of 33
scattered coral atolls, Kiribati has few national
resources. Commercially viable phosphate deposits
were exhausted at the time of independence from the
UK in 1979. Copra and fish now represent the bulk of
production and exports. The economy has fluctuated
widely in recent years. Economic development is
constrained by a shortage of skilled workers, weak
infrastructure, and remoteness from international
markets. Tourism provides more than one-fifth of
GDP. The financial sector is at an early stage of
development as is the expansion of private sector
initiatives. Foreign financial aid, largely from the UK
and Japan, is a critical supplement to GDP, equal to
25%-50% of GDP in recent years. Remittances from
workers abroad account for more than $5 million each
year.
GDP; purchasing power parity - $74 million
(1999 est.), supplemented by a nearly equal amount
from external sources
GDP - real growth rate; 2.5% (1 999 est.)
GDP - per capita; purchasing power parity - $860
(1999 est.)
GDP - composition by sector;
agriculture: 14%
industry: 7%
services: 79% (1 996 est.)
Population below poverty line; NA%
266
Kiribati (continued)
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2% (1 999 est.)
Labor force: 7,870 economically active, not
including subsistence farmers (1985 est.)
Unemployment rate: 2%; underemployment 70%
(1992 est.)
Budget;
revenues: $33.3 million
expenditures: $47.7 million, including capital
expenditures of $NA million (1996 est.)
Industries: fishing, handicrafts
Industrial production growth rate: 0.7%
(1992 est.)
Electricity - production: 7 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 7 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: copra, taro, breadfruit,
sweet potatoes, vegetables; fish
Exports; $6 million (f.o.b., 1998)
Exports ■ commodities: copra 62%, seaweed, fish
Exports ■ partners: US, Australia, NZ (1 996)
Imports; $37 million (c.i.f., 1998)
Imports - commodities: foodstuffs, machinery and
equipment, miscellaneous manufactured goods, fuel
Imports - partners: Australia 46%, Fiji, Japan, NZ,
US (1996)
Debt ■ external: $7.2 million (1996 est.)
Economic aid - recipient: $15.5 million (1995),
largely from UK and Japan
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1.5207 (January 2000), 1.5497(1999), 1.5888(1998),
1.3439 (1997), 1.2773 (1996), 1.3486 (1995)
Fiscal year: NA
I Communications
Telephones - main lines in use; 2,600 (1995)
Telephones - mobile cellular: 0 (1995)
Telephone system;
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
note: Kiribati is being linked to the Pacific Ocean
Cooperative Telecommunications Network, which
should improve telephone service
Radio broadcast stations: AM 1, FM 1, shortwave
1 (1998)
Radios: 17,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000(1997)
Internet Service Providers (ISPs): NA
I t r a n s p 0 f t a t i 0 h
Railways; 0 km
Highways:
total: 070 km (1996 est.)
paved: NA km
unpaved: NA km
Waterways: small network of canals, totaling 5 km,
in Line Islands
Ports and harbors: Banaba, Betio, English Harbor,
Kanton
Merchant marine;
total: 1 ship (1,000 CRT or over) totaling 1 ,291 GRT/
1,295 DWT
ships by type: passenger/cargo 1 (1999 est.)
Airports: 21 (1999 est.)
Airports - with paved runways:
total: 4
1,524 to 2,437 m; 4 (1999 est.)
Airports - with unpaved runways:
total; 17
914 to 1,523 m: 12
under 914 m: 5 (1 999 est.)
[ llTilitary
Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small police posts are on all
islands)
Military expenditures - dollar figure: $NA
Military expenditures • percent of GDP: NA%
Military ■ note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
I Transnational Issues
Disputes - international; none
Korea, North
0 50 too km
RUSSIA
too ml','e305ab65652640870828d6308a9fb110229adf534feeb7104f04b53270136126','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0692510834c72c9ddd23be33bb38498048a44957fd7d7e27daffc30256132c5',2000,'SI','Slovenia','economy',162,'Economy - overview: Before the dissolution of
Yugoslavia, the Republic of Croatia, after Slovenia,
was the most prosperous and industrialized area, with
a per capita output perhaps one-third above the
Yugoslav average. Croatia faces considerable
economic problems stemming from: the legacy of
longtime communist mismanagement of the
economy; damage during the internecine fighting to
bridges, factories, power lines, buildings, and houses;
the large refugee and displaced population, both
Croatian and Bosnian; and the disruption of economic
ties. Western aid and investment, especially in the
tourist and oil industries, would help restore the
economy. The government has been successful in
some reform efforts - partially macroeconomic
stabilization policies - and it has normalized relations
with its creditors. Yet it still is struggling with
privatization of large state enterprises and with bank
reform. The recession that began at the end of 1998
continued through most of 1999, and GDP growth for
the year was flat. Inflation remained in check and the
kuna was stable. The death of President TUDJMAN in
December 1999, and the defeat of his ruling Coatian
Democratic Union or HDZ party in parliamentary and
presidential elections in January 2000 has ushered in
a new government committed to economic reform but
faced with the challenge of halting the economic
decline.
126
Croatia (continued)
GDP: purchasing power parity - $23.9 biliion
(1999 est.)
GDP - real growth rate: 0% (1999 est.)
GDP - per capita: purchasing power parity - $5,100
(1999 est.)
GDP - composition by sector:
agriculture: t0%
industry: 2A%
sen/ices: 66% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4.4% (1999)
Labor force: 1 .65 million (1 999)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 20% (1999 est.)
Budget:
revenues: $6 billion
expenditures: $4.7 billion, including capital
expenditures of $NA (1 998)
Industries: chemicals and plastics, machine tools,
fabricated metal, electronics, pig iron and rolled steel
products, aluminum, paper, wood products,
construction materials, textiles, shipbuilding,
petroleum and petroleum refining, food and
beverages; tourism
Industrial production growth rate: -2% (1999 est.)
Electricity ■ production: 9.515 billion kWh (1998)
Electricity - production by source:
fossil fuel: 42.72%
hydro: 57 28%
nuclear 0%
other: 0% {1998)
Electricity - consumption: 12.949 billion kWh
(1998)
Electricity - exports: 900 million kWh (1998)
Electricity - imports: 5 billion kWh (1998)
Agriculture - products: wheat, com, sugar beets,
sunflower seed, alfalfa, clover, olives, citrus, grapes,
vegetables; livestock, dairy products
Exports: $4.5 billion (f.o.b., 1998)
Exports - commodities: textiles, chemicals,
foodstuffs, fuels
Exports - partners: Italy 21%, Germany 18%,
Bosnia and Herzegovina 15%, Slovenia 12% (1997)
Imports: $8.4 billion (c.i.f., 1998)
Imports - commodities: machinery, transport and
electrical equipment, chemicals, fuels and lubricants,
foodstuffs
Imports - partners: Germany 20%, Italy 19%,
Slovenia 8%, Austria 8% (1997)
Debt - external: $8.1 billion (October 1999)
Economic aid - recipient: $NA
Currency: 1 Croatian kuna (HRK) = 100 lipas
Exchange rates: Croatian kuna per US$1 - 7.591
(January 2000), 7.112 (1999), 6.362 (1998), 6.157
(1997), 5.434 (1996), 5.230 (1995)
Fiscal year: calendar year
f C o m m u n i c a it i 0 n s
Telephones - main lines in use: 1.477 million
(1997)
Telephones - mobile cellular: 187,000 (yearend
1998)
Telephone system:
domestic: reconstruction plan calls for replacement of
all analog circuits with digital and enlarging the
network; a backup will be included in the plan for the
main trunk
international: digital international service is provided
through the main switch in Zagreb; Croatia
participates in the TEL project which consists of two
fiber-optic trunk connections with Slovenia and a
fiber-optic trunk line from Rijeka to Split and
Dubrovnik; Croatia is also investing in ADRIA 1 , a joint
fiber-optic project with Germany, Albania, and Greece
(2000)
Radio broadcast stations: AM 16, FM 98,
shortwave 5 (1999)
Radios: 1.51 million (1997)
Television broadcast stations: 36 (plus 321
repeaters) (September 1995)
Televisions: 1 .22 million (1997)
Internet Service Providers (ISPs): 4 (1999)
I T rTn sl> 0 r t a t i o^n
Railways:
total: 2,298 km
standard gauge: 2,298 km 1.435-m gauge (983 km
electrified)
note: some lines remain inoperative or not in use;
disrupted by territorial dispute (1997)
Highways:
total: 27,840 km
paved: 23,497 km (including 330 km of expressways)
unpavecf; 4,343 km (1998 est.)
Waterways: 785 km perennially navigable; large
sections of Sava blocked by downed bridges, silt, and
debris
Pipelines: crude oil 670 km; petroleum products 20
km; natural gas 310 km (1992); note - under repair
following territorial dispute
Ports and harbors: Dubrovnik, Dug! Rat, Omisalj,
Ploce, Pula, Rijeka, Sibenik, Split, Vukovar (inland
waterway port on Danube), Zadar
Merchant marine:
total: 65 ships (1 ,000 GRT or over) totaling 81 8,887
GRT/1 ,232,803 DWT
ships by type: bulk 15, cargo 25, chemical tanker 1 ,
combination bulk 5, containers, liquified gas 1,
multi-functional large load carrier 3, passenger 1,
petroleum tanker 1 , refrigerated cargo 1, roll-on/
roll-off 4, short-sea passenger 3 (1999 est.)
Airports: 67 (1999 est.)
Airports - with paved runways:
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 91 4 m: 8 {1 999 est.)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m:1
914 to 1,523 m: 8
under 914 m: 36 (1 999 est.)
Heliports: 1 (1 999 est.)
|r M i r i t a r y
Military branches: Ground Forces, Naval Forces,
Air and Air Defense Forces, Frontier Guard, Home
Guard
Military manpower - military age: 1 9 years of age
Military manpower - avaiiabiiity:
males age 15-49: 1 ,086,805 (2000 est.)
Military manpower - fit for miiitary service:
males age 15-49: 860,023 (2000 est.)
Military manpower - reaching military age
annualiy:
males: 30,022 (2000 est.)
Military expenditures - dollar figure: $950 million
(FY99)
Military expenditures ■ percent of GDP: 5%
(FY99)
1^ f r a ns n a t ion a I Issues
Disputes ■ international: Eastern Slavonia, which
was held by ethnic Serbs during the ethnic conflict
between the Croats and the Serbs, was returned to
Croatian control by the UN Transitional Administration
for Eastern Slavonia on 1 5 January 1 998; Croatia and
Italy made progress toward resolving a bilateral issue
dating from World War II over property and ethnic
minority rights; significant progress has been made
with Slovenia toward resolving a maritime border
dispute over direct access to the sea in the Adriatic;
Serbia and Montenegro is disputing Croatia''s claim to
the Prevlaka Peninsula in southern Croatia because it
controls the entrance to Boka Kotorska In
Montenegro; Prevlaka is currently under obsen/ation
by the UN Military Observer Mission in Prevlaka
(UNMOP)
Illicit drugs: transit point along the Balkan route for
Southwest Aslan heroin to Western Europe; a minor
transit point for maritime shipments of South
American cocaine bound for Western Europe
127','c8896dd74d0a91e980ad30d550bf5b371c1682dcc916ff7c2e26be5f4d66d9ca','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4143bb0681a416cd1c31477f7f16ebcc3a700ba07cb937507849bac6af2e3c44',2000,'CU','Cuba','economy',163,'Background: Fidel CASTRO led a rebel army to
victory in 1959; his iron will has held the country
together since. Cuba''s communist revolution, with
Soviet support, was exported throughout Latin
America and Africa during the 1960s, 70s, and 80s.
The country is now slowly recovering from a severe
economic recession following the withdrawal of former
Soviet subsidies, worth $4 billion to $6 billion annually,
in 1990. Havana blames its difficulties on the US
embargo in place since 1962.
Economy - overview: Economic affairs are
dominated by the division of the country into the
southern (Greek) area controlled by the Cyprus
Government and the northern Turkish
Cypriot-administered area. The Greek Cypriot
economy is prosperous but highly susceptible to
external shocks. Erratic growth rates in the 1990s
reflect the economy''s vulnerability to swings in tourist
arrivals, caused by political instability on the island
and fluctuations in economic conditions in Western
Europe. Economic policy in the south is focused on
meeting the criteria for admission to the EU. As in the
Turkish sector, water shortage is a growing problem,
and several desalination plants are planned. The
Turkish Cypriot economy has about one-fifth the
population and one-third the per capita GDP of the
south. Because it is recognized only by Turkey, it has
had much difficulty arranging foreign financing, and
foreign firms have hesitated to invest there. The
economy remains heavily dependent on agriculture
and government service, which together employ
about half of the work force. Moreover, the small,
vulnerable economy has suffered because the
Turkish lira is legal tender. To compensate for the
economy''s weakness, Turkey provides direct and
indirect aid to tourism, education, industry, etc.
GDP: Greek Cypriot area; purchasing power parity -
$9 billion; Turkish Cypriot area: purchasing power
parity - $820 million (1998 est.)
GDP - real growth rate: Greek Cypriot area: 3.0%;
Turkish Cypriot area: 5.3% (1998 est.)
GDP - per capita: Greek Cypriot area: purchasing
power parity - $15,400; Turkish Cypriot area:
purchasing power parity - $5,000 (1998 est.)
GDP - composition by sector: Greek Cypriot area:
agriculture 6.3%, industry 22.4%, services 71 .3%;
Turkish Cypriot area: agriculture 1 1 .8%, industry
20.5%, services 67.7% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): Greek Cypriot
area: 2.3% (1998 est.); Turkish Cypriot area: 66%
(1998 est.)
Labor force: Greek Cypriot area: 289,400; Turkish
Cypriot area: 80,200 (1998)
132
Cyprus (continued)
Labor force - by occupation: Greek Cypriot area:
services 66.6%, industry 23.2%, agriculture 10.2%
(1 998); Turkish Cypriot area: services 55.4%, industry
21.6%, agriculture 23% (1997)
Unemployment rate: Greek Cypriot area: 3.3%
(1998 est.); Turkish Cypriot area: 6.4% (1997)
Budget:
revenues: Greek Cypriot area - $2.9 billion (1998);
Turkish Cypriot area - $171 million (1997 est.)
expenditures: Greek Cypriot area - $3.4 billion,
including capital expenditures of $345 million (1998);
Turkish Cypriot area - $306 million, including capital
expenditures of $56.8 million (1997 est.)
Industries: food, beverages, textiles, chemicals,
metal products, tourism, wood products
Industrial production growth rate: Greek Cypriot
area: 2.4% (1998); Turkish Cypriot area: 5.1% (1997)
Electricity - production: Greek Cypriot area: 2.675
billion kWh; Turkish Cypriot area: NA kWh (1998)
Electricity - production by source:
fossil fuel: tOOVo
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: Greek Cypriot area:
2.488 billion kWh; Turkish Cypriot area: NA kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - Imports: 0 kWh (1 998)
Agriculture • products: potatoes, citrus,
vegetables, barley, grapes, olives, vegetables
Exports: Greek Cypriot area: $1.1 billion (f.o.b.,
1998 est.); Turkish Cypriot area: $63.9 million (f.o.b.,
1998)
Exports - commodities: Greek Cypriot area: citrus,
potatoes, grapes, wine, cement, clothing and shoes;
Turkish Cypriot area: citrus, potatoes, textiles (1998)
Exports - partners: Greek Cypriot area: UK 14.5%,
Russia 14.5%, Greece 9.8%, Lebanon 5.5%, UAE
4.9%; Turkish Cypriot area: Turkey 47%, UK 26%,
otherEU15%(1998)
Imports: Greek Cypriot area: $3.5 billion (f.o.b.,
1998 est.); Turkish Cypriot area: $374 million (f.o.b.,
1997)
Imports - commodities: Greek Cypriot area:
consumer goods, petroleum and lubricants, food and
feed grains, machinery (1998); Turkish Cypriot area:
food, minerals, chemicals, machinery (1997)
Imports - partners: Greek Cypriot area: US 12.5%,
UK 1 1 .3%, Italy 9.4%, Germany 8.5%, Greece 8.2%
(1998); Turkish Cypriot area: Turkey 56.4%, UK
13.5%, other EU 12.2% (1997)
Debt - external: Greek Cypriot area: $1 .27 billion;
Turkish Cypriot area: $NA (1998)
Economic aid - recipient: Greek Cypriot area - $1 7
million (1 998); Turkish Cypriot area - $700 million from
Turkey in grants and loans (1990-97) that are usually
forgiven
Currency: Greek Cypriot area: 1 Cypriot pound =
100 cents; Turkish Cypriot area: 1 Turkish lira (TL) =
100 kurus
Exchange rates: Cypriot pounds per US$1 - 0.5688
(January 2000), 0.5423(1999), 0.5170(1998), 0.5135
(1997), 0.4663 (1996), 0.4522 (1995); Turkish liras
(TL) per US$1 - 545,584 (January 2000), 418,783
(1999), 260,724 (1998), 151,865 (1997), 81,405
(1996), 45,845.1 (1995)
Fiscal year: calendar year
I C^ommunicatio n^T
Telephones - main lines in use: Greek Cypriot
area: 405,000 (1998); Turkish Cypriot area: 70,845
(1996)
Telephones - mobile cellular: Greek Cypriot area:
68,000 (1998); Turkish Cypriot area: 70,000 (1999)
Telephone system: excellent in both the Greek
Cypriot and Turkish Cypriot areas
domestic: open wire, fiber-optic cable, and microwave
radio relay
/rrfemaf/ona/.'' tropospheric scatter; 3 coaxial and 5
fiber-optic submarine cables; satellite earth stations -
3 Intelsat (1 Atlantic Ocean and 2 Indian Ocean), 2
Eutelsat, 2 Intersputnik, and 1 Arabsat
Radio broadcast stations: Greek Cypriot area: AM
7, FM 60, shortwave 1 (1998); Turkish Cypriot area:
AM 3, FM 11, shortwave 1 (1998)
Radios: Greek Cypriot area: 31 0,000 (1 997); Turkish
Cypriot area: 56,450 (1994)
Television broadcast stations: Greek Cypriot
area: 4 plus 225 low-power repeaters; Turkish Cypriot
area: 4 plus 5 repeaters (September 1995)
Televisions: Greek Cypriot area: 248,000 (1 997);
Turkish Cypriot area: 52,300 (1994)
Internet Service Providers (ISPs): 5 (1 999)
tTT n s p 0 r fa 1 1 0 n ~ ”
Railways: 0 km
Highways:
total: Greek Cypriot area: 10,663 km (1998 est.);
Turkish Cypriot area: 2,350 km (1996 est.)
paved: Greek Cypriot area: 6,249 km (1998 est.);
Turkish Cypriot area: 1 ,370 km (1996 est.)
unpaved: Greek Cypriot area: 4,414 km (1998 est.);
Turkish Cypriot area: 980 km (1996 est.)
Ports and harbors: Famagusta, Kyrenia, Larnaca,
Limassol, Paphos, Vasilikos
Merchant marine:
total: 1 ,41 4 ships (1 ,000 GRT or over) totaling
23,497,776 GRT/37,331 ,506 DWT
ships by type: barge carrier 2, bulk 442, cargo 495,
chemical tanker 22, combination bulk 40, combination
ore/oil 8, container 144, liquified gas 6, passenger 8,
petroleum tanker 142, refrigerated cargo 41, roll-on/
roll-off 45, short-sea passenger 1 3, specialized tanker
4, vehicle carrier 2 (1 999 est.)
note: a flag of convenience registry; includes ships
from 37 countries among which are Greece 61 1 ,
Germany 129, Russia 49, Latvia 278, Netherlands 20,
Japan 28, Cuba 16, China 15, Hong Kong 13, and
Poland 15 (1998 est.)
Airports: 15 (1999 est.)
Airports - with paved runways:
total:
2,438 to 3,047 m: 7
1,524 to 2, 437 m::
914 to 1,523 m: 3
under 914 m:: (1999 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m::
under 914 m: 2 (1999 est.)
Heliports: 6 (1999 est.)
I Military
Military branches: Greek Cypriot area: Greek
Cypriot National Guard (GCNG; includes air and naval
elements), Hellenic Forces Regiment on Cyprus
(ELDYK), Greek Cypriot Police; Turkish Cypriot area:
Turkish Cypriot Security Force (TCSF), Turkish
mainland army units
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49; 196,317 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 134,865 (2000 est.)
Military manpower - reaching military age
annually:
males: 6,541 (2000 est.)
Military expenditures - dollar figure: $320 million
(FY99)
Military expenditures - percent of GDP: 5%
(FY99)
I^TFa n s n a 1 1 o n al I s s u eV
Disputes - international: 1 974 hostilities divided the
island into two de facto autonomous areas, a Greek
Cypriot area controlled by the internationally
recognized Cypriot Government (59% of the island''s
land area) and a Turkish-Cypriot area (37% of the
island), that are separated by a UN buffer zone (4% of
the island); there are two UK sovereign base areas
mostly within the Greek Cypriot portion of the island
Illicit drugs: minor transit point for heroin and
hashish via air routes and container traffic to Europe,
especially from Lebanon and Turkey; some cocaine
transits as well
133
Czech Republic j|||||||||||j
Background: After World War 1 1 , Czechoslovakia fell
within the Soviet sphere of influence. In 1968, an
invasion by Warsaw Pact troops ended the efforts of
the country''s leaders to liberalize party rule and create
"socialism with a human face." Anti-Soviet
demonstrations the following year ushered in a period
of harsh repression. With the collapse of Soviet
authority in 1989, Czechoslovakia regained its
freedom through a peaceful "Velvet Revolution." On 1
January 1993, the country underwent a "velvet
divorce" into its two national components, the Czech
Republic and Slovakia. Now a member of NATO, the
Czech Republic has moved toward integration in
world markets, a development that poses both
opportunities and risks.','6b4a582dccc3a1e12ddd4f49e5f1610fdaf7316126411a5752f4e6729a27ff95','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70566aedd913c81072af2579b8d0da417fcef9a28ad6275e7e60a1d233dbb947',2000,'GN','Guinea','economy',183,'Economy - overview: With independence from
Ethiopia on 24 May 1 993, Eritrea faced the economic
problems of a small, desperately poor country. The
economy is largely based on subsistence agriculture,
with 80% of the population involved in farming and
herding. The small industrial sector consists mainly of
light industries with outmoded technologies. Domestic
output (GDP) is substantially augmented by worker
remittances from abroad. Government revenues
come from custom duties and taxes on income and
sales. Road construction is a top domestic priority. In
the long term, Eritrea may benefit from the
development of offshore oil, offshore fishing, and
tourism. Eritrea''s economic future depends on its
ability to master fundamental social and economic
problems, e.g., by reducing illiteracy, promoting job
creation, expanding technical training, attracting
foreign investment, and streamlining the bureaucracy.
The most immediate threat to the economy, however,
is the possible expansion of the border conflict with
Ethiopia, which broke out in May 1998. The hostilities
have drained away substantial resources vital to
Eritrea''s economic development.
GDP: purchasing power parity - $2.9 billion
(1999 est.)
GDP - real growth rate: 3% (1999 est.)
GDP - per capita: purchasing power parity - $750
(1999 est.)
GDP - composition by sector:
agriculture: ^8%
industry: 20%
senrices: 62% (1995 est.)
Population below poverty line: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 9% (1998 est.)
Labor force: NA
Labor force - by occupation: agriculture 80%,
industry and commerce 20%
Unemployment rate: NA%
Budget:
revenues: $283.9 million
expenditures: $351 .6 million, including capital
expenditures of $NA (1997 est.)
Industries: food processing, beverages, clothing
and textiles
Industrial production growth rate; NA%
Electricity - production: 177.6 million kWh
(1997 est.)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
of/ier;0%(1997est.)
Electricity - consumption: 177.6 million kWh
(1997 est.)
Electricity - exports: 0 kWh (1997)
Electricity - imports: 0 kWh (1997)
Agriculture - products: sorghum, lentils,
vegetables, corn, cotton, tobacco, coffee, sisal;
livestock, goats; fish
Exports: $52.9 million (f.o.b., 1997)
Exports - commodities: livestock, sorghum,
textiles, food, small manufactures
Exports - partners: Ethiopia 64%, Sudan 17%, Italy
5%, Saudi Arabia 2%, US, Yemen (1997)
Imports: $489.4 million (c.i.f., 1997)
Imports - commodities: processed goods,
machinery, petroleum products
Imports ■ partners: Saudi Arabia 16%, Italy 14%,
UAE 13%, Ethiopia 9%, Germany 6% (1997)
Debt ■ external: $76 million (1997 est.)
Economic aid - recipient: $123.1 million (1997)
Currency: 1 nafka = 100 cents
Exchange rates: nakfa per US$1 = 9.5 (January
2000), 7.6 (January 1999), 7.2 (March 1998 est.)
Fiscal year: calendar year
Economy - overview: In 1 999, Estonia experienced
its worst year economically since it regained
independence in 1991 largely because of the impact
of the August 1998 Russian financial crisis. Estonia
joined the WTO in November 1999 - the second Baltic
state to join - and continued its EU accession talks.
GDP is forecast to grow 4% in 2000. Privatization of
energy, telecommunications, railways, and other
state-owned companies will continue in 2000. Estonia
expects to complete its preparations for EU
membership by the end of 2002.
GDP: purchasing power parity - $7.9 billion
(1999 est.)
GDP - real growth rate: -0.5% (1999 est.)
GDP - per capita: purchasing power parity - $5,600
(1999 est.)
GDP - composition by sector:
agriculture: 3.6%
industry: 30.7%
sen/ices: 65.7% (1 999)
Population below poverty line; 6.3% (1994 est.)
Household income or consumption by percentage
share:
lowest f0%;3.2%
highest f0%; 28.5% (1996)
Inflation rate (consumer prices): 3.7% (1999 est.)
Labor force: 785,500 (1999 est.)
Labor force - by occupation: industry 20%,
agriculture and forestry 11%, sen/ices 69%
(1999 est.)
Unemployment rate: 1 1 .7% (1 999 est.)
Budget:
revenues; $1.37 billion
expenditures: $1.37 biliion, including capital
expenditures of $NA (1997 est.)
Industries: oil shale, shipbuilding, phosphates,
electric motors, excavators, cement, furniture,
clothing, textiles, paper, shoes, apparel
Industrial production growth rate; 3% (1996 est.)
Electricity - production: 8.742 billion kWh (1998)
Electricity - production by source:
fossil fuel: 99.98%
hydro: 0.02%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 7.58 billion kWh (1998)
Electricity - exports: 700 million kWh (1 998)
Electricity - imports: 1 50 million kWh (1 998)
Agriculture - products: potatoes, fruits, vegetables;
livestock and dairy products; fish
Exports: $2.5 billion (f.o.b., 1999)
Exports ■ commodities: machinery and appliances
19%, wood products 15%, textiles 13%, food products
12%, metals 10%, chemical products 8% (1999)
Exports - partners: Sweden 19.3%, Finland 18.8%,
Russia 8.8%, Latvia 8.8%, Germany 7.3%, US 2.5%
(1999)
Imports: $3.4 billion (f.o.b., 1999)
Imports - commodities: machinery and appliances
26%, foodstuffs 15%, chemical products 10%, metal
products 9%, textiles 8% (1999)
Imports - partners: Finland 23%, Russia 13.2%,
Sweden 10%, Germany 9.1%, US 4.7 (1999)
Debt - external: $270 million (January 1996)
Economic aid - recipient: $137.3 million (1995)
Currency: 1 Estonian kroon (EEK) = 100 sents
Exchange rates: krooni (EEK) per US$1 - 15.417
(January 2000), 4.678 (1999), 14.075 (1998), 13.882
(1997), 12.034 (1996), 11.465 (1995); note - krooni
are tied to the German deutsche mark at a fixed rate
of 8 to 1
Fiscal year: calendar year','50880e3530e79fe7834e2b0a1e392eb2a5ca6b023e2b8c131f8ec449cbc00e5e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0885fe393e42b88cc83cbfbb72c1ab813ccabc751cc9d11ed8a26398931ffa6',2000,'WF','Wallis and Futuna','economy',200,'Economy - overview: France''s economy combines
modern capitalistic methods with extensive, but
declining, government intervention. The government
retains considerable influence over key segments of
each sector, with majority ownership of railway,
electricity, aircraft, and telecommunication firms. It
has been gradually relaxing its control over these
sectors since the early 1990s. The government is
slowly selling off holdings in France Telecom, in Air
France, and in the insurance, banking, and defense
industries. Meanwhile, large tracts of fertile land, the
application of modern technology, and subsidies have
combined to make France the leading agricultural
producer in Western Europe. Persistently high
unemployment will continue to pose a major problem
for the government; a 35-hour work week is being
introduced. France has shied away from cutting
exceptionally generous social welfare benefits or the
enormous state bureaucracy, preferring to pare
defense spending and raise taxes to keep the deficit
down. France joined 1 0 other EU members to launch
the euro on 1 January 1999.
GDP: purchasing power parity - $1 .373 trillion
(1999 est.)
GDP - real growth rate: 2.7% (1999 est.)
GDP ■ per capita: purchasing power parity -
$23,300 (1999 est.)
GDP ■ composition by sector:
agriculture: 3.3%
industry: 26. t%
semces; 70.6% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 2.5%
highest ?0%; 24.9% (1989)
Inflation rate (consumer prices): 0.5% (1999 est.)
Labor force: 25.4 million (1994)
Labor force - by occupation: services 69%,
industry 26%, agriculture 5% (1995)
Unemployment rate: 1 1 % (1 999 est.)
Budget:
revenues: $325 billion
expenditures: $360 billion, including capital
expenditures of $NA (1999 est.)
Industries: steel, machinery, chemicals,
automobiles, metallurgy, aircraft, electronics, mining;
textiles, food processing; tourism
Industrial production growth rate: 2% (1999 est.)
Electricity - production: 480.972 billion kWh (1998)
Electricity - production by source:
fossil fuel: 10.77%
hydro: 12.45%
nuclear: 76.24%
other; 0.54% (1998)
Electricity - consumption: 389.254 billion kWh
(1998)
Electricity - exports: 62 billion kWh (1 998)
Electricity - imports: 3.95 billion kWh (1998)
172
France (continued)
Agriculture - products: wheat, cereals, sugar
beets, potatoes, wine grapes; beef, dairy products;
fish
Exports: $304.7 billion (f.o.b., 1999)
Exports - commodities: machinery and
transportation equipment, chemicals, iron and steel
products; agricultural products, textiles and clothing
Exports - partners: EU 63% (Germany 16%, UK
10%, Italy 9%, Spain 9%, Belgium-Luxembourg 8%),
US 7% (1998)
Imports: $280.8 billion (f.o.b., 1999)
Imports - commodities: crude oil, machinery and
equipment, chemicals; agricultural products
Imports - partners: EU 62% (Germany 17%, Italy
10%, Belgium-Luxembourg 8%, UK 8%, Spain 7%),
US 9% (1998)
Debt - external: $1 17.6 billion (1996 est.)
Economic aid - donor: ODA, $6.3 billion (1997)
Currency: 1 French franc (F) = 100 centimes
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); French francs (F) per US$1 -
5.65 (January 1999), 5.8995 (1998), 5.8367 (1997),
5.1155 (1996), 4.9915 (1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 6.55957 French francs per euro; the euro will
replace the local currency in consenting countries for
all transactions in 2002
Fiscal year: calendar year
I C 0 m m u n I c a t T 6 n s
Telephones • main lines in use: 34.86 million
(yearend 1998)
Telephones - mobile cellular: 1 1 .078 million
(yearend 1998)
Telephone system: highly developed
domestic: extensive cable and microwave radio relay;
extensive introduction of fiber-optic cable; domestic
satellite system
international: satellite earth stations - 2 Intelsat (with
total of 5 antennas - 2 for Indian Ocean and 3 for
Atlantic Ocean), NA Eutelsat, 1 1nmarsat (Atlantic
Ocean region); HF radiotelephone communications
with more than 20 countries
Radio broadcast stations: AM 41 , FM about 3,500
(this figure is an approximation and includes many
repeaters), shortwave 2 (1998)
Radios: 55.3 million (1997)
Television broadcast stations: 574 (plus 9,634
repeaters) (1995)
Televisions: 34.8 million (1997)
Internet Service Providers (ISPs): 128(1999)
I transportation
Railways:
total: 31 ,939 km (31 ,940 km are operated by French
National Railways (SNCF); 1 4,1 76 km of SNCF routes
are electrified and 12,132 km are double- or
multiple-tracked)
standard gauge: 3t,8A0 km 1.435-m gauge
narrow gauge: 99 km 1.000-m gauge (1998)
Highways:
total: 893,300 km
paved: 893,300 km (including 10,300 km of
expressways)
unpaved: 0 km (1998 est.)
Waterways: 14,932 km; 6,969 km heavily traveled
Pipelines: crude oil 3,059 km; petroleum products
4,487 km; natural gas 24,746 km
Ports and harbors: Bordeaux, Boulogne,
Cherbourg, Dijon, Dunkerque, La Pallice, Le Havre,
Lyon, Marseille, Mullhouse, Nantes, Paris, Rouen,
Saint Nazaire, Saint Male, Strasbourg
Merchant marine:
total: 55 ships (1 ,000 GRT or over) totaling 1 ,155,286
GRT/1 ,693,030 DWT
ships by type: bulk 3, cargo 5, chemical tanker 6,
combination bulk 1, container 5, liquified gas 4,
multi-functional large load carrier 1, passenger 3,
petroleum tanker 16, roll-on/roll-off 6, short-sea
passenger 4, specialized tanker 1 (1999 est.)
note: France also maintains a captive register for
French-owned ships in lies Kerguelen (French
Southern and Antarctic Lands) (1998 est.)
Airports: 474 (1999 est.)
Airports - with paved runways:
total: 267
over 3,047 m: lA
2,438 to 3,047 m: 30
1,524 to 2,437 m: 92
914 to 1,523 m: 74
under 914 m: 57 (1 999 est.)
Airports - with unpaved runways:
total: 207
1,524 to 2,437 m: 4
914 to 1,523 m: 76
under 914 m: 127 (1999 est.)
Heliports: 3 (1999 est.)
I” Military
Military branches: Army (includes Marines), Navy
(includes Naval Air), Air Force (includes Air Defense),
National Gendarmerie
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,619,317 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 12,167,421 (2000 est.)
Military manpower - reaching military age
annually:
rrra/es; 402,987 (2000 est.)
Military expenditures - dollar figure: $39,831
billion (FY97)
Military expenditures - percent of GDP: 2.5%
(FY97)','5c7300feecdc5c8c0f06056f62b93c31c55a06de5ef76339313d9992adaa1ae8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19a61bae6c78fef9c13cc63769ccc750eff35517147638e4e70b0856a0791c38',2000,'DK','Denmark','economy',225,'Economy - overview: In this island economy
progress in fiscal reforms and prudent
macroeconomic management have boosted annual
growth to 5%-6% in 1998-99. The increase in
economic activity has been led by construction and
trade. Tourist facilities are being expanded; tourism is
the leading foreign exchange earner. Major short-term
concerns are the rising fiscal deficit and the
deterioration in the external account balance.
Grenada shares a common central bank and a
common currency with seven other members of the
Organization of Eastern Caribbean States (OECS).
GDP: purchasing power parity - $360 million
(1999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP ■ per capita: purchasing power parity - $3,700
(1999 est.)
GDP - composition by sector:
agriculture: 9.7%
industry: 15%
services: 75.3% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .3% (1 998)
Labor force: 42,300(1996)
Labor force - by occupation: services 62%,
agriculture 24%, industry 14% (1999 est.)
Unemployment rate: 15% (1997)
Budget:
revenues: $85.8 million
expenditures: $102.1 million, including capital
expenditures of $28 million (1997)
Industries: food and beverages, textiles, light
assembly operations, tourism, construction
Industrial production growth rate: 0.7%
(1997 est.)
Electricity - production: 105 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 98 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: bananas, cocoa, nutmeg,
mace, citrus, avocados, root crops, sugarcane, corn,
vegetables ■
Exports: $26.8 million (1998)
Exports - commodities: bananas, cocoa, nutmeg,
fruit and vegetables, clothing, mace
Exports - partners: Caricom 32.3%, UK 20%, US
13%, Netherlands 8.8% (1991)
Imports: $200 million (1998)
Imports - commodities: food, manufactured goods,
machinery, chemicals, fuel (1989)
Imports - partners: US 31 .2%, Caricom 23.6%, UK
13.8%, Japan 7.1% (1991)
Debt - external: $89.2 million (1998)
Economic aid - recipient: $8.3 million (1995)
Currency: 1 East Caribbean dollar (EC$) = 100
cents
Exchange rates: East Caribbean dollars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year: calendar year','08ae1a19390eed253abb96435f78c36d3cc615aebe2038e203cd4b849cc1920f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d824373ffe42ed4116dd72ab4baca6108872ee11a22459261f416a7d980410f4',2000,'GY','Guyana','economy',231,'Economy - overview: Severe drought and political
turmoil contributed to Guyana''s negative growth of
-1 .8% for 1 998 following six straight years of growth of
5% or better. Growth came back to a positive 1 .8% in
1999. Underlying growth factors have included
expansion in the key agricultural and mining sectors,
a more favorable atmosphere for business initiative, a
more realistic exchange rate, a moderate inflation
rate, and continued support by international
organizations. President JAGDEO, the former finance
minister, is taking steps to reform the economy,
including drafting an investment code and
restructuring the inefficient and unresponsive public
sector. Problems include a shortage of skilled labor
and an inadequate and poorly maintained
transportation system. Also, electricity has been in
short supply; the privatization of the sector in August
1999 is expected to improve prospects. The
government must persist in efforts to manage its
sizable external debt and extend its privatization
program.
GDP: purchasing power parity - $1 .86 billion
(1999 est.)
GDP - real growth rate: 1 .8% (1 999 est.)
GDP ■ per capita: purchasing power parity - $2,500
(1999 est.)
GDP - composition by sector:
agriculture: 34.7%
Industry: 32.5%
services: 32.8% (1998 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 5.5% (1 999 est.)
Labor force: 245,492(1992)
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 12% (1992 est.)
Budget:
revenues: $220.1 million
expenditures: $286.4 million, including capital
expenditures of $86.6 million (1998)
Industries: bauxite, sugar, rice milling, timber,
fishing (shrimp), textiles, gold mining
Industrial production growth rate: 7.1%
(1997 est.)
Electricity - production: 325 million kWh (1998)
Electricity - production by source:
fossil fuel: 98.46%
hydro: 1 .54%
nuclear: 0%
other: Q%(im)
Electricity - consumption: 302 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: sugar, rice, wheat,
vegetable oils; beef, pork, poultry, dairy products;
forest and fishery potential not exploited
Exports: $574 million (f.o.b., 1999 est.)
Exports - commodities: sugar, gold, bauxite/
alumina, rice, shrimp, molasses, rum, timber
Exports - partners: US 25%, Canada 24%, UK
19%, Netherlands Antilles 11%, Jamaica 5% (1998)
Imports: $620 million (c.i.f., 1999 est.)
Imports - commodities: manufactures, machinery,
petroleum, food
Imports - partners: US 28%, Trinidad and Tobago
21%, Netherlands Antilles 14%, UK 7%, Japan 5%
(1998)
Debt - external: $1.4 billion (1998)
Economic aid - recipient: $84 million (1 995),
Heavily Indebted Poor Country Initiative (HIPC) $253
million (1997)
Currency: 1 Guyanese dollar (G$) = 100 cents
Exchange rates: Guyanese dollars (G$) per US$1 -
180.4 (December 1999), 178.0 (1999), 150.5 (1998),
142.4 (1997), 140.4 (1996), 142.0 (1995)
Fiscal year: calendar year','a7b5721761c35eb08c4a872dffe299cf8ed5b08046a3baf585d16438646cc8d6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4dce2acafa57cdf1b7e3abbd1a9bcbe907c66ea9afd17da6b38761ce860b520',2000,'IS','Iceland','economy',240,'Economy - overview: The Indonesian economy
stabilized in 1 999, following the sharp contraction and
high inflation of 1998. By following tight monetary
policy, the government reduced inflation from over
70% in 1998 to 2% in 1999. Although interest rates
spiked as high as 70% in response to the monetary
contraction, they fell rapidly to the 10% to 15% range.
The economy stopped its free-fall as GDP showed
some growth in the second half of 1999, although
GDP for the year as a whole showed no growth. The
government managed to recapitalize a handful of
private banks and has begun recapitalizing the
state-owned banking sector. New lending, however,
remains almost unavailable as banks continue to be
wary of issuing new debt in an environment where
little progress has been made in restructuring the
huge burden of outstanding debts. IMF payments
were suspended late in 1 999 as the result of evidence
that a private bank had illegally tunneled payments it
received from the government to one of the political
parties. The government has forecast grovrth of 3.8%
for FYOO/01 . The spread of sectarian violence and
continuing dissatisfaction with the pace of bank and
debt restructuring will make it difficult for Indonesia to
attract the private investment necessary to achieve
this goal.
GDP: purchasing power parity - $610 billion
(1999 est.)
GDP - real growth rate: 0% (1999 est.)
GDP - per capita: purchasing power parity - $2,800
(1999 est.)
GDP - composition by sector:
agriculture: 21%
industry: 35%
sen/ices: 44% (1 999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3.6%
highest 10%: 30.3% (19%)
Inflation rate (consumer prices): 2% (1999 est.)
Labor force: 88 million (1998)
Labor force - by occupation: agriculture 45%,
trade, restaurant, and hotel 1 9%, manufacturing 1 1 %,
transport and communications 5%, construction 4%
(1998)
Unemployment rate: 15%-20% (1998 est.)
Budget:
revenues: $25.4 billion (of which $6 billion is from
international financial institutions)
expenditures: $25.4 billion, including capital
expenditures of $NA (FY99/00 est.)
Industries: petroleum and natural gas; textiles,
apparel, and footwear; mining, cement, chemical
fertilizers, plywood; rubber; food; tourism
Industrial production growth rate: 1 .5%
(1999 est.)
Electricity - production: 73.13 billion kWh (1998)
Electricity - production by source:
fossil fuel: 83.19%
hydro: 8.39%
nuclear: 0%
ofter; 3.42% (1998)
Electricity - consumption: 68.01 1 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: rice, cassava (tapioca),
peanuts, rubber, cocoa, coffee, palm oil, copra;
poultry, beef, pork, eggs
Exports: $48 billion (f.o.b., 1999 est.)
Exports - commodities: oil and gas, plywood,
textiles, rubber
Exports - partners: Japan 18%, EU 15%, US 14%,
Singapore 13%, South Korea 5%, Hong Kong 4%,
China 4%, Taiwan 3% (1999 est.)
Imports: $24 billion (c.i.f., 1999 est.)
Imports - commodities: machinery and equipment;
chemicals, fuels, foodstuffs
Imports - partners: Japan 17%, US 13%, Singapore
10%, Germany 9%, Australia 6%, South Korea 5%,
Taiwan 3%, China 3% (1999 est.)
234
IndonGSia (continued)
Debt - external: $140 billion (1998 est.)
Economic aid - recipient; $43 billion from IMF
program and other official external financing
(1997-2000)
Currency: Indonesian rupiah (Rp) = 100 sen
Exchange rates; Indonesian rupiahs (Rp) per
US$1 - 7,278.8 (January 2000), 7,855.2 (1999),
10,013.6 (1998), 2,909.4 (1997), 2,342.3 (1996),
2,248.6(1995)
Fiscal year: 1 April - 31 March
I Communications
Telephones - main lines in use; 3.291 million
(1995)
Telephones ■ mobile cellular; 1 .2 million (1 998)
Telephone system: domestic service fair,
international service good
domestic: interisland microwave system and HF radio
police net; domestic satellite communications system
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Pacific Ocean)
Radio broadcast stations: AM 678, FM 43,
shortwave 82 (1998)
Radios; 31.5 million (1997)
Television broadcast stations; 41 (1999)
Televisions: 13.75 million (1997)
Internet Service Providers (ISPs): 24 (1999)
I transportation
Railways;
tofa/; 6,458 km
narrow gauge: 5, 96t km 1.067-m gauge (101 km
electrified; 101 km double track); 497 km 0.750-m
gauge (1995)
Highways;
total: 342,700 km
paved; 158,670 km
unpaved: 184,030 km (1997 est.)
Waterways: 21 ,579 km total; Sumatra 5,471 km,
Java and Madura 820 km, Kalimantan 10,460 km,
Sulawesi (Celebes) 241 km, Irian Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum products
456 km; natural gas 1,703 km (1989)
Ports and harbors: Cilacap, Cirebon, Jakarta,
Kupang, Palembang, Semarang, Surabaya,
Ujungpandang
Merchant marine;
total: 586 ships (1 ,000 GRT or over) totaling
2,676,875 GRT/3,700,864 DWT
ships by type: bulk 38, cargo 346, chemical tanker 9,
container 19, liquified gas 5, livestock carrier 1,
passenger 7, passenger/cargo 13, petroleum tanker
114, refrigerated cargo 1 , roll-on/roll-off 1 1 , short-sea
passenger 8, specialized tanker 9, vehicle carrier 5
(1999 est.)
Airports: 446 (1999 est.)
Airports - with paved runways;
tofa/; 127
over 3,047 m: 4
2,438 to 3,047 m:^2
1,524 to 2,437 m: 39
914 to 1,523 m: 41
under 9/4 m; 31 (1 999 est.)
Airports - with unpaved runways:
total: 319
1,524 to 2, 437 m: 5
914 to 1,523 m: 33
under 914 m: 231 (1999 est.)
Heliports: 4 (1999 est.)
I Military^
Military branches: Army, Navy, Air Force, National
Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 62,948,286 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 36,826,282 (2000 est.)
Military manpower - reaching military age
annually:
males: 2,273,324 (2000 est.)
Military expenditures -dollar figure: $1 billion
(FY98/99)
Military expenditures - percent of GDP: 1 .3%
(FY98/99)
I t r a n s^ a t i o ii a I Is s ii e s
Disputes • international: Sipadan and Ligitan
Islands in dispute with Malaysia
Illicit drugs: illicit producer of cannabis largely for
domestic use; possible growing role as transshipment
point for Golden Triangle heroin
Economy - overview: Iran''s economy is a mixture of
central planning, state ownership of oil and other large
enterprises, village agriculture, and small-scale
private trading and service ventures. President
KHATAMI has continued to follow the market reform
plans of former President RAFSANJANI and has
indicated that he will pursue diversification of Iran''s
oil-reliant economy although he has made little
progress toward that goal. The strong oil market in
1996 helped ease financial pressures on Iran and
allowed for Tehran''s timely debt service payments.
Iran''s financial situation tightened in 1997 and
deteriorated further in 1998 because of lower oil
prices. The subsequent zoom in oil prices in 1999
afforded Iran fiscal breathing room but does not solve
Iran''s structural economic problems.
GDP: purchasing power parity - $347.6 billion
(1999est.)
GDP - real growth rate: 1% (1999 est.)
GDP - per capita: purchasing power parity - $5,300
(1999 est.)
GDP - composition by sector:
agriculture: zn
industry: 34%
services: 45% (1 997 est.)
Population below poverty line: 53% (1996 est.)
Household income or consumption by percentage
share:
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices): 30% (1999 est.)
Labor force: 15.4 million
note: shortage of skilled labor
Labor force • by occupation: agriculture 33%,
industry 25%, services 42% (1997 est.)
Unemployment rate: 25% (1999 est.)
Budget:
revenues: $34.6 billion
expenditures: $34.9 billion, including capital
expenditures of $1 1 .8 billion (FY96/97)
Industries: petroleum, petrochemicals, textiles,
cement and other construction materials, food
processing (particularly sugar refining and vegetable
oil production), metal fabricating, armaments
Industrial production growth rate: 5.7% (FY95/96
est.)
Electricity - production: 95.31 billion kWh (1998)
Electricity - production by source:
fossil fuel: 92.33%
hydro: 7. 67%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 88.638 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: wheat, rice, other grains,
sugar beets, fruits, nuts, cotton; dairy products, wool;
caviar
Exports: $12.2 billion (f.o.b., 1998 est.)
Exports - commodities: petroleum 80%, carpets,
fruits, nuts, hides, iron, steel
Exports - partners: Japan, Italy, Greece, France,
Spain, South Korea
Imports: $13.8 billion (f.o.b., 1998 est.)
Imports - commodities: machinery, militaty
supplies, metal works, foodstuffs, pharmaceuticals,
technical services, refined oil products
Imports - partners: Germany, Italy, Japan, DAE,
UK, Belgium
Debt - external: $21 .9 billion (1 996 est.)
Economic aid - recipient: $1 16.5 million (1995)
Currency: 10 Iranian rials (IR) = 1 toman; note -
domestic figures are generally referred to in terms of
the toman
Exchange rates: Iranian rials (IR) per US$1 -
1,754.90 (January 2000), 1,725.93 (1999), 1,751.86
(1998), 1,752.92 (1997), 1,750.76 (1996), 1,747.93
(1995); black market rate: 7,000 rials per US$1
(December 1998); note - as of May 1995, the "official
rate" of 1 ,750 rials per US$1 is used for imports of
essential goods and services and for oil exports,
whereas the "official export rate" of 3,000 rials per
US$1 is used for non-oil exports and Imports not
covered by the official rate
Fiscal year: 21 March - 20 March
”C 0 m m u n fc a t i 0 n s ™
Telephones - main lines in use: 7 million
(1998 est.)
Telephones - mobile cellular: 265,000 (August
1998)
Telephone system: inadequate but currently being
modernized and expanded with the goal of not only
improving the efficiency and increasing the volume of
the urban service but also bringing telephone service
to several thousand villages, not presently connected
domestic: as a result of heavy investing in the
telephone system since 1994, the number of long
distance channels in the microwave radio relay trunk
has grown substantially; many villages have been
brought into the net; the number of main lines in the
urban systems have approximately doubled; and
thousands of mobile cellular subscribers are being
served; moreover, the technical level of the system
has been raised by the installation of thousands of
digital switches
international: HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan,
Turkmenistan, Syria, Kuwait, Tajikistan, and
Uzbekistan; submarine fiber-optic cable to UAE with
access to Fiber-Optic Link Around the Globe (FLAG);
Trans Asia Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran to
Turkmenistan with expansion to Georgia and
Azerbaijan; satellite earth stations - 9 Intelsat and 4
Inmarsat; Internet service available but limited to
electronic mail to promote Iranian culture
Radio broadcast stations: AM 72, FM 5, shortwave
5(1998)
Radios: 17 million (1997)
Television broadcast stations: 28 (plus 450
low-power repeaters) (1997)
Televisions: 4.61 million (1997)
Internet Service Providers (ISPs): 1 (1999)
I Transportation
Railways: 5,600 km
broad gauge: 94 km 1 .676-m gauge
standard gauge: 5,506 km 1.435-m gauge (146 km
electrified) (1998)
Highways:
total: 140,200 km
paved: 49,440 km (including 470 km of expressways)
unpaved: 90,760 km (1 998 est.)
Waterways: 904 km; the Shaft al Arab is usually
navigable by maritime traffic for about 130 km;
channel has been dredged to 3 m and is in use
Pipelines: crude oil 5,900 km; petroleum products
3,900 km; natural gas 4,550 km
Ports and harbors: Abadan (largely destroyed in
fighting during 1980-88 war), Ahvaz, Bandar ''Abbas,
Bandar-e Anzali, Bushehr, Bandar-e Emam
Khomeyni, Bandar-e Lengeh, Bandar-e Mahshahr,
Bandar-e Torkaman, Chabahar (Bandar Beheshti),
Jazireh-ye Khark, Jazireh-ye Lavan, Jazireh-ye Sirri,
Khorramshahr (limited operation since November
1992), NowShahr
Merchant marine:
total: 1 38 ships (1 ,000 GRT or over) totaling
3,517,751 GRT/6,208,230 DWT
ships by type: bulk 45, cargo 36, chemical tanker 4,
combination bulk 1, container 7, liquified gas 1,
multi-functional large load carrier 6, petroleum tanker
26, refrigerated cargo 2, roll-on/roll-off 9, short-sea
passenger 1 (1999 est.)
Airports: 288 (1999 est.)
Airports - with paved runways:
total: 112
over 3,047 m: 36
2,438 to 3,047 m: 21
1,524 to 2,437 m: 23
914 to 1,523 m: 24
under 914 m; 6 (1999 est.)
Airports - with unpaved runways:
total: 176
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
914 to 1,523 m: 123
under 914 m: 32 (1999 est.)
Heliports: 11 (1999 est.)
I
Military branches: Islamic Republic of Iran regular
forces (includes Ground Forces, Navy, Air and Air
Defense Forces), Revolutionary Guards (includes
Ground, Air, Navy, Qods, and
Basij-mobilization-forces), Law Enforcement Forces
Military manpower - miiitary age: 21 years of age
Military manpower - availability:
males age 15-49: 17,762,030 (2000 est.)
237
Iran (continued)
Military manpower - fit for military service:
males age f 5-49; 10,545,869 (2000 est.)
Miiitary manpower - reaching military age
annualiy:
males: 801 ,260 (2000 est.)
Military expenditures - doiiar figure: $5,787 billion
(FY98/99)
Military expenditures - percent of GDP: 2.9%
(FY98/99)','d835087c889f116b44f52752af2316e000d0458cafa8ee03d64d0f1569c177db','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0334b6c24ccc66517aed43b8ff53ad31a0df257d474c883f8f67b27ce62a285c',2000,'JE','Jersey','economy',249,'Economy - overview: Israel has a technologically
advanced market economy with substantial
government participation. It depends on imports of
crude oil, grains, raw materials, and military
equipment. Despite limited natural resources, Israel
has intensively developed its agricultural and
industrial sectors over the past 20 years. Israel is
largely self-sufficient in food production except for
grains. Diamonds, high-technology equipment, and
agricultural products (fruits and vegetables) are
leading exports. Israel usually posts sizable current
account deficits, which are covered by large transfer
payments from abroad and by foreign loans. Roughly
half of the government''s external debt is owed to the
US, which is its major source of economic and military
aid. The influx of Jewish immigrants from the former
USSR topped 750,000 during the period 1989-99,
bringing the population of Israel from the former Soviet
Union to 1 million, one-sixth of the total population,
and adding scientific and professional expertise of
substantial value for the economy''s future. The influx,
coupled with the opening of new markets at the end of
the Cold War, energized Israel''s economy, which
grew rapidly in the early 1990s. But growth began
slowing in 1 996 when the government imposed tighter
fiscal and monetary policies and the immigration
bonus petered out. Those policies brought inflation
down to record low levels in 1999 and, coupled with
improved prospects for the Middle East peace
process, are creating a climate for stronger GDP
growth in the year 2000.
GDP: purchasing power parity - $105.4 billion
(1999 est.)
GDP - real growth rate: 2.1% (1999 est.)
GDP ■ per capita: purchasing power parity -
$18,300(1999 est.)
GDP ■ composition by sector:
agriculture: 2%
industry: 17%
serv/ces; 81% (1997 est.)
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: 2.6%
highest 10%; 26.9% (1992)
Inflation rate (consumer prices): 1 .3% (1 999 est.)
Labor force: 2.3 million (1997)
Labor force - by occupation: public services
31 .2%, manufacturing 20.2%, finance and business
13.1%, commerce 12.8%, construction 7.5%,
personal and other services 6.4%, transport, storage,
and communications 6.2%, agriculture, forestry, and
fishing 2.6% (1996)
Unemployment rate: 9.1% (1999 est.)
Budget:
revenues: $40 billion
expenditures: $42.4 billion, including capital
expenditures of $NA (2000 est.)
Industries: food processing, diamond cutting and
polishing, textiles and apparel, chemicals, metal
244
IsraGi (continued)
products, military equipment, transport equipment,
electrical equipment, potash mining, high-technology
electronics, tourism
Industrial production growth rate: 5.4% (1996)
Electricity - production: 35.338 billion kWh (1998)
Electricity - production by source:
fossil fuel: 99.9%
hydro: 0.1%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 31 .805 billion kWh
(1998)
Electricity - exports: 1.061 billion kWh (1998)
Electricity - imports: 2 million kWh (1998)
Agriculture - products: citrus, vegetables, cotton;
beef, poultry, dairy products
Exports: $23.5 billion (f.o.b., 1999)
Exports - commodities: machinery and equipment,
software, cut diamonds, chemicals, textiles and
apparel, agricultural products
Exports - partners: US 32%, UK, Hong Kong,
Benelux, Japan, Netherlands (1997)
Imports: $30.6 billion (f.o.b., 1999)
Imports - commodities: raw materials, military
equipment, investment goods, rough diamonds, fuels,
consumer goods
Imports - partners: US 19%, Benelux 12%,
Germany 9%, UK 8%, Italy 7%, Switzerland 6%
(1997)
Debt - external: $18.7 billion (1997)
Economic aid - recipient: $1 .1 billion from the US
(1999)
Currency: 1 new Israeli shekel (NIS) = 100 new
agorot
Exchange rates: new Israeli shekels (NIS) per
US$1 - 4.2260 (November 1999), 3.8001 (1999),
3.4494 (1 997), 3.1 91 7 (1996), 3.01 1 3 (1 995)
Fiscal year: calendar year
f Communications
Telephones - main lines in use: 2.8 million (1999)
Telephones - mobile cellular: 2.5 million (1999)
Telephone system: most highly developed system
in the Middle East although not the largest
domestic: good system of coaxial cable and
microwave radio relay; all systems are digital
International: 3 submarine cables; satellite earth
stations - 3 Intelsat (2 Atlantic Ocean and 1 1ndian
Ocean)
Radio broadcast stations: AM 23, FM 15,
shortwave 2 (1998)
Radios: 3.07 million (1997)
Television broadcast stations: 24 (plus 31
low-power repeaters) (1997)
Televisions: 1.69 million (1997)
Internet Service Providers (ISPs): 23 (1 999)
f Transportation
Railways:
fofa/;610km
standard gauge: 610 km 1.435-m gauge (1996)
Highways:
tofa/; 15,965 km
paved: 15,965 km (including 56 km of expressways)
unpaved: 0 km (1 998 est.)
Pipelines: crude oil 708 km; petroleum products 290
km; natural gas 89 km
Ports and harbors: Ashdod, Ashqelon, Elat (Eilat),
Hadera, Haifa, Tel Aviv-Yafo
Merchant marine:
total: 20 ships (1 ,000 GRT or over) totaling 71 1 ,831
GRT/823,929 DWT
ships by type: container 19, roll-on/roll-off 1
(1999 est.)
Airports: 58 (1999 est.)
Airports - with paved runways:
total: 33
over 3,047 m: 2
2,438 to 3,047 m:7
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 7 (1 999 est.)
Airports - with unpaved runways;
total: 25
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 20 (1 999 est.)
Heliports: 2 (1999 est.)
I * ~ ™ M i I i riTy
Military branches: Israel Defense Forces (includes
ground, naval, and air components). Pioneer Fighting
Youth (Nahal), Frontier Guard, Chen (women); note -
historically there have been no separate Israeli
military services
Military manpower • military age: 18 years of age
Military manpower - availability:
males age 15-49:1,499,186
females age 15-49; 1,462,063 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 1,226,903
females age 15-49; 1,192,319 (2000 est.)
Military manpower - reaching military age
annually:
males: 50,348
females; 47,996 (2000 est.)
Military expenditures - dollar figure; $8.7 billion
(FY99)
Military expenditures - percent of GDP; 9.4%
(FY99)
f TransnatFonai Issues
Disputes - international; West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation;
Golan Heights is Israeli-occupied; Israeli troops in
southern Lebanon since June 1982
Illicit drugs: increasingly concerned about cocaine
and heroin abuse; drugs arrive in country from
Lebanon and increasingly Jordan
I introduction
Background: Italy became a nation-state belatedly -
in 1861 when the city-states of the peninsula and
Sicily were united under King Victor EMMANUEL. The
Fascist dictatorship of Benito MUSSOLINI that took
over after World War I led to a disastrous alliance with
Nazi Germany and Italian defeat in World War II.
Revival followed. Italy was a charter member of NATO
and the European Economic Community (EEC) and
joined the growing political and economic unification
of Western Europe, including the introduction of the
euro in 1999. Persistent problems include illegal
immigration, the ravages of organized crime,
corruption, high unemployment, and the low incomes
and technical standards of southern Italy compared
with the more prosperous north.
f GToVr a p''h^y”''
Location: Southern Europe, a peninsula extending
into the central Mediterranean Sea, northeast of
Economy - overview: In this small landlocked
economy, subsistence agriculture occupies more than
60% of the population. Manufacturing features a
number of agroprocessing factories. Mining has
declined in importance in recent years; high-grade
iron ore deposits were depleted by 1978, and health
concerns have cut world demand for asbestos.
Exports of soft drink concentrate, sugar, and wood
pulp are the main earners of hard currency.
Surrounded by South Africa, except for a short border
with Mozambique, Swaziland is heavily dependent on
South Africa from which it receives four-fifths of its
imports and to which it sends three-fourths of its
exports. Remittances from Swazi workers in South
African mines supplement domestically earned
income by as much as 20%. The government is trying
to improve the atmosphere for foreign investment.
Overgrazing, soil depletion, and drought persist as
problems for the future.
GDP: purchasing power parity - $4.2 billion
(1999 est.)
GDP - real growth rate: 3.1% (1999 est.)
GDP - per capita: purchasing power parity - $4,200
(1999 est.)
GDP - composition by sector:
agriculture: 10%
474
Swaziland (continued)
industry: 48%
services: 42% (1 997 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices): 6% (1999 est.)
Labor force: NA
Labor force - by occupation: private sector about
70%, public sector about 30%
Unemployment rate: 22% (1995 est.)
Budget:
revenues: $400 million
expenditures: $450 million, including capital
expenditures of $1 15 million (FY96/97)
Industries: mining (coal and asbestos), wood pulp,
sugar, soft drink concentrates
Industrial production growth rate: 3.7%
(FY95/96)
Electricity - production: 420 million kWh (1998)
Electricity - production by source:
fossil fuel: 48.81%
hydro: 51.19%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 1 .078 billion kWh (1 998)
Electricity • exports: 0 kWh (1998)
Electricity • imports: 687 million kWh
note: imports about 60% of its electricity from South
Africa (1998)
Agriculture - products: sugarcane, cotton, corn,
tobacco, rice, citrus, pineapples, sorghum, peanuts;
cattle, goats, sheep
Exports: $825 million (f.o.b., 1999)
Exports - commodities: soft drink concentrates,
sugar, wood pulp, cotton yarn, refrigerators, citrus and
canned fruit
Exports - partners: South Africa 74%, EU 12%,
Mozambique 5%, US, North Korea (1997)
Imports: $1.05 billion (f.o.b., 1999)
Imports - commodities: motor vehicles, machinery,
transport equipment, foodstuffs, petroleum products,
chemicals
Imports - partners: South Africa 83%, EU 6%,
Japan, UK, Singapore (1997)
Debt - external: $180 million (1999)
Economic aid - recipient: $55 million (1995)
Currency: 1 lilangeni (E) = 100 cents
Exchange rates: emalangeni (E) per US$1 - 6.1237
(January 2000), 6.1087 (1999), 5.4807 (1998), 4.6032
(1997), 4.2706 (1996), 3.6266 (1995); note - the
Swazi lilangeni is at par with the South African rand
Fiscal year: 1 April - 31 March
I Communications
Telephones - main lines in use: 20,000 (1996)
Telephones - mobile cellular: 0 (1 996)
Telephone system:
domestic: system consists of carrier-equipped,
open-wire lines and low-capacity, microwave radio
^elay
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 3, FM 4, shortwave
1 (1998)
Radios: 155,000(1997)
Television broadcast stations: 2 (plus seven
repeaters) (1997)
Televisions: 21,000(1997)
Internet Service Providers (ISPs): 2 (1999)
I transportation ^
Railways:
total: 297 km; note - includes 71 km which are not in
use
narrow gauge: 297 km 1.067-m gauge
Highways:
total: 2,896 km (1997 est.)
paved: NA km
unpaved: NA km
Ports and harbors: none
Airports: 18 (1999 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (1999 est.)
Airports - with unpaved runways:
total: 17
914 to 1,523 m: 7
under 914 m: 10 (1999 est.)
I ~ MiTTtaTy ^
Military branches: Umbutfo Swaziland Defense
Force (Army), Royal Swaziland Police Force
Military manpower • availability:
males age 15-49: 242,398 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 140,299 (2000 est.)
Military expenditures • dollar figure: $23 million
(FY95/96)
Military expenditures - percent of GDP: 1 .9%
(FY95/96)
I Transnational issues
Disputes - international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
Background: A military power during the 17th
century, Sweden has not participated in any war in
almost two centuries. An armed neutrality was
preserved in both World Wars. Sweden''s
long-successful economic formula of a capitalist
system interlarded with substantial welfare elements
has recently been undermined by high unemployment,
rising maintenance costs, and a declining position in
world markets. Indecision over the country''s role in the
political and economic integration of Europe caused
Sweden not to join the EU until 1 995, and to forgo the
introduction of the euro in 1999.
I ~ G e 0 g r a p h y
Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, Kattegat, and Skagerrak,
between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
/and; 41 0,934 sq km
water: 39,030 sq km
475
Swedon (continued)
Area - comparative: slightly larger than California
Land boundaries:
total: 2,205 km
border countries: Finland 586 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: agreed boundaries or
midlines
territorial sea: 12 nm (adjustments made to return a
portion of straits to high seas)
Climate: temperate in south with cold, cloudy winters
and cool, partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands;
mountains in west
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Kebnekaise 2,111m
Natural resources: zinc, iron ore, lead, copper,
silver, timber, uranium, hydropower
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 68%
other; 24% (1993 est.)
Irrigated land: 1,150 sq km (1993 est.)
Natural hazards: ice floes in the surrounding waters,
especially in the Gulf of Bothnia, can interfere with
maritime traffic
Environment - current issues: acid rain damaging
soils and lakes; pollution of the North Sea and the
Baltic Sea
Environment - international agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location along Danish
Straits linking Baltic and North Seas
j People
Population: 8,873,052 (July 2000 est.)
Age structure:
0-14 years: 18% (male 837,358; female 794,774)
15-64 years: 64% (male 2,901 ,809; female
2,805,138)
65 years and over: 18% (male 648,865; female
885,108) (2000 est.)
Population grovirth rate: 0.02% (2000 est.)
Birth rate: 10.01 births/1,000 population (2000 est.)
Death rate: 1 0.62 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.86 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/femaie
under 15 years: 1.05 maie(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.73 maie(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 3.49 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 79.58 years
male: 76.95 years
female: 82.37 years (2000 est.)
Total fertility rate: 1 .53 chiidren born/woman
(2000 est.)
Nationaiity:
noun: Swede(s)
adjective: Swedish
Ethnic groups: indigenous population: Swedes and
Finnish and Lapp (Sami) minorities; foreign-born or
first-generation immigrants; Finns, Yugosiavs, Danes,
Norwegians, Greeks, Turks
Reiigions: Lutheran 87%, Roman Catholic,
Orthodox, Baptist, Muslim, Jewish, Buddhist
Languages; Swedish
note: small Lapp- and Finnish-speaking minorities
Literacy;
definition: age 15 and over can read and write
total population: 99% (1979 est.)
male: NA%
female: NA%
Country name;
conventional long form: Kingdom of Sweden
conventional short form: Sweden
local long form: Konungariket Sverige
local short form: Sverige
Data code; SW
Government type: constitutional monarchy
Capital: Stockholm
Administrative divisions; 21 counties (Ian, singular
and plural); Blekinge, Dalarnas, Gavleborgs,
Gotlands, Hallands, Jamtiands, Jonkopings, Kalmar,
Kronobergs, Norrbottens, Orebro, Ostergotlands,
Skane, Sodermanlands, Stockholms, Uppsala,
Varmlands, Vasterbottens, Vasternorriands,
Vastmanlands, Vastra Gotalands
Independence: 6 June 1523 (Gustav VASA elected
king)
National holiday: Day of the Swedish Flag, 6 June
Constitution: 1 January 1975
Legal system: civil law system influenced by
customary law; accepts compulsory ICJ jurisdiction,
with reservations
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: King CARL XVI GUSTAF (since 19
September 1973); Heir Apparent Princess VICTORIA
Ingrid Alice Desiree, daughter of the monarch (born 1 4
July 1977)
head of government: Prime Minister Goran
PERSSON (since 21 March 1996)
cabinet: Cabinet appointed by the prime minister
elections: the monarch is hereditary; prime minister
elected by the Parliament; election last held NA
September 1998 (next to be held NA 2002)
election results: Goran PERSSON reelected prime
minister with 131 out of 349 votes
Legislative branch: unicameral Parliament or
Riksdag (349 seats; members are elected by popular
vote on a proportional representation basis to serve
four-year terms)
elections: last held 20 September 1998 (next to be
held NA September 2002)
electiori results: percent of vote by party - Social
Democrats 36.5%, Moderates 22.7%, Left Party 12%,
Christian Democrats 1 1 .8%, Center Party 5.1%,
Liberal Party 4.7%, Greens 4.5%; seats by party -
Social Democrats 131, Moderates 82, Left Party 43,
Christian Democrats 42, Center Party 18, Liberal
Party 17, Greens 16
Judicial branch: Supreme Court or Hogsta
Domstolen, judges are appointed by the government
(prime minister and cabinet)
Political parties and leaders; Center Party
[Lennart DALEUSj; Christian Democratic Party [Alf
SVENSSONj; Communist Workers’ Party [Rolf
HAGEL); Green Party [no formal leader but party
spokesperson is Briger SCHLAUGj; Left Party or VP
(formerly Communist) [Gudrun SCHYMANj; Liberal
People''s Party [Lars LEIJONBORGj; Moderate Party
(conservative) [Bo LUNDGRENj; New Democracy
Party [Vivianne FRANZENj; Social Democratic Parly
[Goran PERSSON]
International organization participation: AfDB,
AsDB, Australia Group, BIS, CBSS, CCC, CE, CERN,
EAPC, EBRD, ECE, EIB, ESA, EU, FAO, G- 6, G- 9,
G-10, lADB, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM,
IDA, lEA, IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, lOM, ISO, ITU,
MINURSO, MONUC, NAM (guest), NC, NEA, NIB,
NSG, OAS (observer), OECD, OPCW, OSCE, PCA,
PFP, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UNIKOM, UNMIBH, UNMIK, UNMOGIP, UNMOP,
UNOMIG, UNTAET, UNTSO, UPU, WEU (observer),
WFTU, WHO, WlPO, WMO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Arrrbassador Rolf EKEUS
chancery: 1501 M Street NW, Washington, DC
20005-1702
telephone: [1] {202) 467-2600
FAX; [1] (202) 467-2699
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US;
chief of mission: Ambassador Lyndon Lowell
OLSON, Jr.
embassy: Strandvagen 1 01 , S-1 1 5 89 Stockholm
mailing address: American Embassy Stockholm,
Department of State, Washington, DC 20521-5750
(pouch)
telephone: [46] (8) 783 53 00
FAX; [46] (8)661 19 64
Sweden (continued)
Flag description: blue with a yellow cross that
extends to the edges of the flag; the vertical part of the
cross is shifted to the hoist side in the style of the
Dannebrog (Danish flag)
F I c 0 n o m y
Economy - overview: Aided by peace and neutrality
for the whole twentieth century, Sweden has achieved
an enviable standard of living under a mixed system of
high-tech capitalism and extensive welfare benefits. It
has a modern distribution system, excellent internal
and external communications, and a skilled labor
force. Timber, hydropower, and iron ore constitute the
resource base of an economy heavily oriented toward
foreign trade. Privately owned firms account for about
90% of industrial output, of which the engineering
sector accounts for 50% of output and exports.
Agriculture accounts for only 2% of GDP and 2% of
the jobs. In recent years, however, this extraordinarily
favorable picture has been clouded by budgetary
difficulties, inflation, high unemployment, and a
gradual loss of competitiveness in international
markets. Sweden has harmonized its economic
policies with those of the EL), which it joined at the
start of 1995. Sweden decided not to join the euro
system at its outset in January 1999 but plans to hold
a referendum in 2000 on whether to join. GDP growth
is forecast for 4% in 2000, buttressed by solid
consumer confidence.
GDP: purchasing power parity - $1 84 billion
(1999 est.) •
GDP - real growth rate: 3.8% (1999 est.)
GDP - per capita: purchasing power parity -
$20,700(1999 est.)
GDP • composition by sector:
agriculture: 2.2%
industry: 30.5%
services: 67.3% (1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3.7%
highest 10%: 20.1% (m2)
Inflation rate (consumer prices): 0.4% (1999 est.)
Labor force: 4.3 million (1996)
Labor force - by occupation: agriculture 2%,
industry 24%, services 74% (1999 est.)
Unemployment rate: 5.5% plus about 5% in training
programs (1999 est.)
Budget:
revenues; $109.4 billion
expend/fures; $146.1 billion, including capital
expenditures of $NA (FY95/96)
Industries: iron and steel, precision equipment
(bearings, radio and telephone parts, armaments),
wood pulp and paper products, processed foods,
motor vehicles
Industrial production growth rate: 3% (1999 est.)
Electricity - production: 1 56.772 billion kWh (1 998)
Electricity • production by source:
fossil fuel: 6.09%
hydro; 46.49%
nuclear: 45.16%
other: 2.26% (1998)
Electricity - consumption: 135.098 billion kWh
(1998)
Electricity - exports: 1 6.8 billion kWh (1 998)
Electricity - imports: 6.1 billion kWh (1998)
Agriculture - products: grains, sugar beets,
potatoes; meat, milk
Exports: $85.7 billion (f.o.b., 1999)
Exports - commodities: machinery 35%, motor
vehicles, paper products, pulp and wood, iron and
steel products, chemicals
Exports - partners: EL) 57% (Germany 11%, UK
9%, Denmark 6%, Finland 5%), Norway 9%, US 9%
(1998)
Imports: $67.9 billion (f.o.b., 1999)
Imports - commodities: machinery, petroleum and
petroleum products, chemicals, motor vehicles, iron
and steel; foodstuffs, clothing
Imports - partners: EU 68% (Germany 19%, UK
10%, Denmark 6%, France 6%), Norway 8%, US 6%
(1998)
Debt - external: $66.5 billion (1994)
Economic aid - donor: ODA, $1 .7 billion (1 997)
Currency: 1 Swedish krona (SKr) = iOO oere
Exchange rates: Swedish kronor (SKr) per US$1 -
8.4831 (January 2000), 8.2624 (1 999), 7.9499 (1 998),
7.6349 (1997), 6.7060 (1996), 7.1333 (1995)
Fiscal year: calendar year
|T ’ c 0 m m li nT (Ta t i o h"s ”
Telephones - main lines in use: 6.017 million
(December 1998)
Telephones - mobile cellular: 3.835 million
(October 1998)
Telephone system: excellent domestic and
international facilities; automatic system
domestic: coaxial and multiconductor cable carry
most voice traffic; parallel microwave radio relay
network carries some additional telephone channels
international: 5 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean), 1 Eutelsat,
and 1 1nmarsat (Atlantic and Indian Ocean regions);
note - Sweden shares the Inmarsat earth station with
the other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations: AM 1, FM 265,
shortwave 1 (1998)
Radios: 8.25 million (1997)
Television broadcast stations: 1 63 (1 997)
Televisions: 4.6 million (1997)
Internet Service Providers (ISPs): 29 (1999)
f T r all s p 0 r t a t i 0 n
Railways:
total: 12','ef730e81b82b2df626ce725e098366d3da2f6373b2b5de6bcc31537eb935c871','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11fed75c6dd6ceb3e8f0f6112fef7b631af85045e82f7fa688ebbb7f6e84efb2',2000,'JE','Jersey','economy',250,',821 km (includes 3,594 km of
privately-owned railways)
standard gauge: 1 2,821 km 1 .435-m gauge (7,91 8 km
electrified and 1,152 km double track) (1998)
Highways:
tofa/; 210,907 km
paved; 163,453 km (including 1,439 km of
expressways)
unpaved; 47,454 km (1998 est.)
Waterways: 2,052 km navigable for small steamers
and barges
Pipelines: natural gas 84 km
Ports and harbors: Gavie, Goteborg, Halmstad,
Helsingborg, Hudiksvall, Kalmar, Karlshamn, Malmo,
Solvesborg, Stockholm, Sundsvall
Merchant marine:
total: 1 65 ships (1 ,000 GRT or over) totaling
2,301 ,633 GRT/1 ,726,01 8 DWT
ships by type: bulk 6, cargo 26, chemical tanker 33,
combination ore/oil 4, liquified gas 1 , petroleum tanker
23, rail car carrier 1 , roll-on/roll-off 43, short-sea
passenger 4, specialized tanker 6, vehicle carrier 18
(1999 est.)
Airports: 256 (1999 est.)
Airports - with paved runways:
total: 147
over 3,047 m: 3
2,438 to 3,047 m: 11
1,524 to 2,437 m: 60
914 to 1,523 m: 28 •
under 914 m: 25 (1 999 est.)
Airports - with unpaved runways:
total: 109
914 to 1,523 m: 5
under 914 m: 1 04 (1 999 est.)
Heliports: 1 (1999 est.)
I Military”
Military branches: Swedish Army, Royal Swedish
Navy, Swedish Air Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49; 2,067,631 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,809,129 (2000 est.)
Military manpower - reaching military age
annually:
males: 51 ,962 (2000 est.)
Military expenditures - dollar figure: $5 billion
(FY98)
Military expenditures • percent of GDP: 2.1%
(FY98)
p t r a n s n a 1 1 0 n a I issues
Disputes - international: none
477','f86d8564bd3de17c9489a8b1961302d58d9877de996919bdc34ba5e0fa395471','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d335b72e364086dc2a6494390121780d52411dd81af4eb017c9e3db52f40580',2000,'TN','Tunisia','economy',251,'Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
total: 301 ,230 sq km
land: 294,020 sq km
wafer; 7,21 Osq km
note: includes Sardinia and Sicily
Area - comparative: slightly larger than Arizona
Land boundaries:
total: 1,932.2 km
border countries: Austria 430 km, France 488 km,
Holy See (Vatican City) 3.2 km, San Marino 39 km,
Slovenia 232 km, Switzerland 740 km
Coastline; 7,600 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
terr/for/al sea; 12 nm
245
Italy (continued)
Climate: predominantly Mediterranean; Alpine in far
north; hot, dry in south
Terrain: mostly rugged and mountainous; some
plains, coastal lowlands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc (Monte Bianco) 4,807 m
Natural resources: mercury, potash, marble, sulfur,
dwindling natural gas and crude oil reserves, fish,
coal, arable land
Land use:
arable land: 3t%
permanent crops: 10%
permanent pastures: 1 5%
forests and woodland: 23%
other; 21% (1993 est.)
Irrigated land: 27,100 sq km (1993 est.)
Natural hazards: regional risks include landslides,
mudflows, avalanches, earthquakes, volcanic
eruptions, flooding; land subsidence in Venice
Environment - current issues: air pollution from
industrial emissions such as sulfur dioxide; coastal
and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes;
inadequate industrial waste treatment and disposal
facilities
Environment ■ international agreements:
party to; Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: strategic location dominating
central Mediterranean as well as southern sea and air
approaches to Western Europe','c7952c0f13434bea21a8c2a02cbefb655fc13b21b6711a1db0fa724b05fa11ca','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b31fe4a3fa5f3b18d1df1037d9ba3fe2fb60b4d5588e1fa6e88d03dd6ad93dfe',2000,'JO','Jordan','economy',261,'Economy - overview: Jordan is a small Arab
country with inadequate supplies of water and other
natural resources such as oil. The Persian Gulf crisis.
which began in August 1990, aggravated Jordan''s
already serious economic problems, forcing the
government to shelve the IMF program, stop most
debt payments, and suspend rescheduling
negotiations. Aid from Gulf Arab states, worker
remittances, and trade contracted; and refugees
flooded the country, producing serious
balance-of-payments problems, stunting GDP growth,
and straining government resources. The economy
rebounded in 1992, largely due to the influx of capital
repatriated by workers returning from the Gulf. After
averaging 9% in 1992-95, GDP growth averaged only
2% during 1 996-99. In an attempt to spur growth. King
ABDALLAH has undertaken limited economic reform,
including partial privatization of some state owned
enterprises and Jordan''s entry in January 2000 into
the World Trade Organization (WTrO). Debt, poverty,
and unemployment are fundamental ongoing
economic problems.
GDP: purchasing power parity - $16 billion
(1999 est.)
GDP - real growth rate: 2% (1999 est.)
GDP - per capita: purchasing power parity - $3,500
(1999 est.)
GDP - composition by sector:
agriculture: 3%
industry: 25%
sen/ices: 72% (1 998 est.)
Population below poverty line: 30% (1998 est.)
Household Income or consumption by percentage
share;
iowest 10%; 2,4%
highest 10%; 34.7% (1991)
Inflation rate (consumer prices): 3% (1999 est.)
Labor force; 1.15 million
note: in addition, at least 300,000 workers are
employed abroad (1997 est.)
Labor force - by occupation; industry 1 1 .4%,
commerce, restaurants, and hotels 10.5%,
construction 10%, transport and communications
8.7%, agriculture 7.4%, other services 52% (1992)
Unemployment rate: 15% official rate; actual rate is
25%-30% (1999 est.)
Budget:
revenues: $2.8 billion
expenditures: $3,1 billion, including capital
expenditures of $NA (2000 est.)
Industries: phosphate mining, petroleum refining,
cement, potash, light manufacturing, tourism
Industrial production growth rate: -3.4% (1996)
Electricity - production; 6.08 billion kWh (1998)
Electricity - production by source;
fossil fuel: 99.5t%
hydro: 0.49%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 6.102 billion kWh (1998)
Electricity - exports: 2 million kWh (1998)
Electricity - imports: 450 million kWh (1998)
Agriculture - products; wheat, barley, citrus,
tomatoes, melons, olives; sheep, goats, poultry
Exports: $1 .8 billion (f.o.b., 1999 est.)
Exports - commodities: phosphates, fertilizers,
potash, agricultural products, manufactures
Exports - partners: Iraq, India, Saudi Arabia, EU,
Indonesia, UAE, Lebanon, Kuwait, Syria, Ethiopia
Imports: $3.3 billion (c.i.f., 1999 est.)
Imports - commodities: crude oil, machinery,
transport equipment, food, live animals, manufactured
goods
Imports - partners: Germany, Iraq, US, Japan, UK,
Italy, Turkey, Malaysia, Syria, China
Debt - external: $8.4 billion (1 998 est.)
Economic aid - recipient: ODA, $850 million
(1996 est.)
Currency: 1 Jordanian dinar (JD) = 1 ,000 fils
Exchange rates: Jordanian dinars (JD) per US$1 -
0.7090 (January 2000-1996), 0.7005 (1995)
note: since May 1 989, the dinar has been pegged to a
group of currencies
Fiscal year: calendar year','2e0a8957511772460a5b44de2f0425b7505c08972a830c93ccdd6323bcc29132','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3575ad1ff4224bb678e19db97e3d2d0d0dd978271fb10c75bb147db5b1983403',2000,'CN','China','economy',272,'Islajin
Ch’ongjin^
''’Hyesan
.Kanggye
Kimch’aek
j^SinQiju
Hamhung,
Korea •
^ungnam
Sea
t ^Sunch’on 1
of
P’YONGY^
jfs Sypnsan
Economy - overview; The 1975-91 civil war
seriously damaged Lebanon''s economic
infrastructure, cut national output by half, and all but
ended Lebanon''s position as a Middle Eastern
282
Lebanon (continued)
entrepot and banking hub. Peace has enabled the
central government to restore control in Beirut, begin
collecting taxes, and regain access to key port and
government facilities. Economic recovery has been
helped by a financially sound banking system and
resilient small- and medium-scale manufacturers, with
family remittances, banking services, manufactured
and farm exports, and international aid as the main
sources of foreign exchange. Lebanon''s economy has
made impressive gains since the launch of "Horizon
2000," the government''s $20 billion reconstruction
program in 1 993. Real GDP grew 8% in 1 994 and 7%
in 1995 before Israel''s Operation Grapes of Wrath in
April 1996 stunted economic activity. Real GDP grew
at an average annual rate of less than 3% per year for
1997 and 1998 and only 1% in 1999. During 1992-98,
annual inflation fell from more than 100% to 5%, and
foreign exchange reserves jumped to more than $6
billion from $1.4 billion. Burgeoning capital inflows
have generated foreign payments surpluses, and the
Lebanese pound has remained relatively stable.
Progress also has been made in rebuilding Lebanon''s
war-torn physical and financial infrastructure.
Solidere, a $2-billion firm, is managing the
reconstruction of Beirut''s central business district; the
stock market reopened in January 1996; and
international banks and insurance companies are
returning. The government nonetheless faces serious
challenges in the economic arena. It has had to fund
reconstruction by tapping foreign exchange reserves
and boosting borrowing. Reducing the government
budget deficit is a major goal of the LAHUD
government. The stalled peace process and ongoing
violence in southern Lebanon could lead to wider
hostilities that would disrupt vital capital inflows.
Furthermore, the gap between rich and poor has
widened in the 1990''s, resulting in grassroots
dissatisfaction over the skewed distribution of the
reconstruction''s benefits and leading the government
to shift its focus from rebuilding infrastructure to
improving living conditions.
GDP: purchasing power parity - $1 6.2 billion
(1999 est.)
GDP - real growth rate: 1% (1999 est.)
GDP - per capita: purchasing power parity - $4,500
(1999 est.)
GDP - composition by sector:
agriculture: 12%
industry: 27%
senrices: 61% (1998 est.)
Popuiation below poverty line: 28% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4.5% (1999 est.)
Labor force: 1 .3 million (1 999 est.)
note: in addition, there are as many as 1 million
foreign workers (1997 est.)
Labor force - by occupation: services 62%,
industry 31%, agriculture 7% (1997 est.)
Unemployment rate: 18% (1997 est.)
Budget:
revenues: $4.9 billion
expenditures: $8.36 billion, including capital
expenditures of $NA (1999 est.)
Industries: banking; food processing; jewelry;
cement; textiles; mineral and chemical products;
wood and furniture products; oil refining; metal
fabricating
Industrial production growth rate: NA%
Electricity - production: 9.7 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 90.72%
hydro: 9.28%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 9.629 billion kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 608 million kWh (1998)
Agriculture - products: citrus, grapes, tomatoes,
apples, vegetables, potatoes, olives, tobacco; sheep,
goats
Exports: $866 million (f.o.b., 1999 est.)
Exports - commodities: foodstuffs and tobacco,
textiles, chemicals, metal and metal products,
electrical equipment and products, jewelry, paper and
paper products
Exports - partners: Saudi Arabia 12%, UAE 10%,
France 9%, Syria 7%, US 7%, Kuwait 4%, Jordan,
Turkey (1998)
Imports: $5.7 billion (f.o.b., 1999 est.)
Imports ■ commodities: foodstuffs, machinery and
transport equipment, consumer goods, chemicals,
textiles, metals, fuels, agricultural foods
Imports - partners: Italy 12%, France 10%, US 9%,
Germany 9%, Switzerland 6%, Japan, UK, Syria
(1998)
Debt - external: $8.8 billion (1999 est.)
Economic aid - recipient: $3.5 billion (pledges
1997-2001)
Currency: 1 Lebanese pound = 100 piasters
Exchange rates: Lebanese pounds per US$1 ■
1,507.5 (January 2000), 1,507.8 (1999), 1,516.1
(1998), 1,539.5(1997), 1,571.4 (1996), 1,621.4
(1995)
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 330,000 (1995)
Telephones - mobile cellular: 120,000 (1995)
Telephone system: telecommunications system
severely damaged by civil war; rebuilding well
undenvay
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean) (erratic
operations); coaxial cable to Syria; microwave radio
relay to Syria but inoperable beyond Syria to Jordan;
3 submarine coaxial cables
Radio broadcast stations: AM 20, FM 22,
shortwave 4 (1998)
Radios: 2.85 million (1997)
Television broadcast stations: 28 (1997)
Televisions: 1.18 million (1 997)
Internet Service Providers (ISPs): 1 9 (1 999)
f Introduction
Background: Long a province of China, Mongolia
won its independence in 1921 with Soviet backing. A
communist regime was installed in 1924. During the
early 1990s, the ex-communist Mongolian People''s
Revolutionary Party (MPRP) gradually yielded its
monopoly on power. In 1996, the Democratic Union
Coalition (DUC) defeated the MPRP in a national
election and has attempted to establish a number of
reforms to modernize the economy. However, many
former communists retain key posts and
implementation has been difficult.
I™ ~ ~ G e 0 g r a p h y
Location; Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references; Asia
Area;
total: t. 565 million sq km
/and; 1.565 million sqkm
water: 0 sq km
Area - comparative; slightly smaller than Alaska
Land boundaries:
fofa/;8,114 km
border counfr/es; China 4,673 km, Russia 3,441 km
Coastline: 0 km (landlocked)
Maritime claims; none (landlocked)
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains;
mountains in west and southwest; Gobi Desert in
southeast
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Tavan Bogd Uul 4,374 m
Natural resources; oil, coal, copper, molybdenum,
tungsten, phosphates, tin, nickel, zinc, wolfram,
fluorspar, gold
Land use:
arable land: 1%
9 100 200 km
0 100 200 ml
permanent crops: 0%
permanent pastures: 80%
forests and woodland: 9%
ofber;10%(1993 est.)
Irrigated land: 800 sq km (1993 est.)
Natural hazards: dust storms can occur in the
spring; grassland fires
Environment - current issues: limited natural fresh
water resources; policies of the former communist
regime promoting rapid urbanization and industrial
growth have raised concerns about their negative
effects on the environment; the burning of soft coal in
power plants and the lack of enforcement of
environmental laws have severely polluted the air In
Ulaanbaatar; deforestation, overgrazing, the
converting of virgin land to agricultural production
have increased soil erosion from wind and rain;
desertification and mining activities have also had a
deleterious effect on the environment
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; strategic location
between China and Russia
I People
Population: 2,650,952 (July 2000 est.)
Age structure;
0-14 years: 34% (male 461 ,71 9; female 447,426)
15-64 years: 62% (male 816,851 ; female 816,651)
65 years and over: 4% (male 46,682; female 61 ,623)
(2000 est.)
Population growth rate; 1 .54% (2000 est.)
Birth rate: 21 .53 births/1 ,000 population (2000 est.)
Death rate: 6.14 deaths/1 ,000 population
(2000 est.)
335
Mongolia (continued)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: t. 05 male(s)/female
under 15 years: t. 03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 male(s)/female (2000 est.)
infant mortaiity rate: 41 .22 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 67.25 years
male: 64.98 years
female: 69.64 years (2000 est.)
Totai fertiiity rate: 2.4 children born/woman
(2000 est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol 90%, Kazakh 4%, other 6%
Religions: predominantly Tibetan Buddhist, Muslim
4%
note: previously limited religious activity because of
communist regime
Languages: Khalkha Mongol 90%, Turkic, Russian
Literacy:
definition: age 1 5 and over can read and write
total population: 82.9%
male: 88.6%
female: 77. 2% {ms est.)
Economy - overview: Economic activity traditionally
has been based on agriculture and breeding of
livestock. Mongolia also has extensive mineral
deposits: copper, coal, molybdenum, tin, tungsten,
and gold account for a large part of industrial
production. Soviet assistance, at its height one-third of
GDP, disappeared almost overnight in 1 990-91 , at the
time of the dismantlement of the USSR. Mongolia was
driven into deep recession, which was prolonged by
the Mongolian People''s Revolutionary Party''s (MPRP)
reluctance to undertake serious economic reform. The
Democratic Union Goalition (DUG) government has
embraced free-market economics, easing price
controls, liberalizing domestic and international trade,
and attempting to restructure the banking system and
the energy sector. Major domestic privatization
programs have been undertaken, as well as fostering
of foreign investment through international tender of
the oil distribution company, a leading cashmere
company, and banks. Reform has been held back by
the ex-communist MPRP opposition and by the
political instability brought about through four
successive governments under the DUG. Economic
growth picked up in 1 997-99 after stalling in 1 996 due
to a series of natural disasters and declines in world
prices of copper and cashmere. Public revenues and
exports collapsed in 1998 and 1999 due to the
repercussions of the Asian financial crisis. In August
and September 1999, the economy suffered from a
temporary Russian ban on exports of oil and oil
products. Mongolia joined the World Trade
Organization (WTrO) in 1997. The international donor
community pledged over $300 million per year at the
last Gonsultative Group Meeting, held in Ulaanbaatar
in June 1999.
336
Mongolia (continued)
GDP: purchasing power parity - $6.1 biliion
(1999 est.)
GDP - real growth rate: 3.5% (1999 est.)
GDP - per capita: purchasing power parity - $2,320
(1999 est.)
GDP - composition by sector:
agriculture: 33%
industry: 24%
services: 43% (1999 est.)
Population below poverty line: 40% (1 999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.9%
highest 10%; 24.5% (1995)
Inflation rate (consumer prices): 9.5% (1998)
Labor force: 1 .256 million (1 998)
Labor force - by occupation: primarily herding/
agricultural
Unemployment rate: 4.5% (1998)
Budget:
revenues: $260 million
expenditures: $366 million, including capital
expenditures of $NA (1 999)
Industries: construction materials, mining
(particularly coal and copper); food and beverages,
processing of animal products
Industrial production growth rate: 3.2% (1998)
Electricity ■ production: 2.66 billion kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% {1990)
Electricity ■ consumption: 2.81 6 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 342 million kWh (1998)
Agriculture - products: wheat, barley, potatoes,
forage crops; sheep, goats, cattle, camels, horses
Exports: $316.8 million (f.o.b., 1998)
Exports - commodities: copper, livestock, animal
products, cashmere, wool, hides, fluorspar, other
nonferrous metals
Exports - partners: China 30.1%, Switzerland
21.5%, Russia 12.1%, South Korea 9.7%, US 8.1%
(1998)
Imports: $472.4 million (f.o.b., 1998)
Imports - commodities: machinery and equipment,
fuels, food products, industrial consumer goods,
chemicals, building materials, sugar, tea
Imports - partners: Russia 30.6%, China 13.3%,
Japan 1 1 .7%, South Korea 7.5%, US 6.9% (1 998)
Debt - external: $715 million (1998 est.)
Economic aid - recipient: $250 million (1998 est.)
Currency: 1 tughrik (Tug) = 100 mongos
Exchange rates: tughriks (Tug) per US$1 -1,070.39
(December 1999), 1,072.37 (1999), 840.83 (1998),
789.99 (1997), 548.40 (1996), 448.61 (1995)
Fiscal year: calendar year
Economy - overview: Severe volcanic activity,
which began in July 1 995, put a damper on this small,
open economy throughout 1996-99. A catastrophic
eruption in June 1997 closed the air and sea ports,
causing further economic and social dislocation.
Two-thirds of the 12,000 inhabitants fled the island.
Some began to return in 1998, but lack of housing
limited the number. The agriculture sector continued
to be affected by the lack of suitable land for farming
and the destruction of crops. Construction was the
dominant activity in 1997 and 1998. GDP declined
again in 1 998. Prospects for the economy depend
largely on developments in relation to the volcano and
on public sector construction activity. The UK
committed about $100 million in 1996-98 to help
reconstruct the economy and has programmed
additional aid for 1 999-2001 .
GDP: purchasing power parity - $31 million
(1998 est.)
GDP - real growth rate: -16% (1998 est.)
GDP - per capita: purchasing power parity - $NA
GDP ■ composition by sector:
agriculture: 5.4%
industry: 13.5%
services: 81% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 5% (1998)
Labor force: 4,521 (1992); note - recently lowered
by flight of people from volcanic activity
Labor force - by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 20% (1996 est.)
Budget;
revenues: $31 .4 million
expenditures: $31 .6 million, including capital
expenditures of $8.4 million (1997 est.)
Industries: tourism, rum, textiles, electronic
appliances
Industrial production growth rate: NA%
Electricity - production: 10 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1995)
Electricity - consumption: 9 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cabbages, carrots,
cucumbers, tomatoes, onions, peppers; livestock
products
Exports; $1.5 million (1998)
Exports - commodities: electronic components,
plastic bags, apparel, hot peppers, live plants, cattle
Exports - partners: US, Antigua and Barbuda
(1993)
Imports: $26 million (1998)
Imports - commodities: machinery and
transportation equipment, foodstuffs, manufactured
goods, fuels, lubricants, and related materials
Imports - partners: US, UK, Trinidad and Tobago,
Japan, Canada (1993)
Debt - external: $8.9 million (1997)
338
Montserrat (continued)
Economic aid - recipient; $9.8 million (1995);
note - about $100 million (1996-98) in reconstruction
aid from the UK; Country Poiicy Pian (1999) is a
three-year program for spending $122.8 miiiion in
British budgetary assistance
Currency; 1 East Caribbean doiiar (EC$) = 100
cents
Exchange rates; East Caribbean doiiars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year; 1 Aprii - 31 March
I Communications
Telephones - main lines in use; 4,000 (1992)
Telephones - mobile cellular; 70 (1994)
Telephone system;
domestic: NA
international: NA
Radio broadcast stations; AM 1, FM 2, shortwave
0(1998)
Radios; 7,000(1997)
Television broadcast stations; 1 (1997)
Televisions; 3,000(1997)
Internet Service Providers (ISPs); NA
I" Transportation
Railways; 0 km
Highways;
total: 2Q9 km
paved: 203 km
mpaved;66km(1995)
Ports and harbors; Plymouth (abandoned). Little
Bay (anchorages and ferry landing), Carr''s Bay
Merchant marine; none (1999 est.)
Airports; 1 (1999 est.)
Airports - with paved runways;
total: 1
914 to 1,523 m:t (1999 est.)
Military branches; Police Force
Military - note; defense is the responsibility of the
UK
I fransnationaT Issues
Disputes - international; none
Background; Morocco''s long struggle for
independence from France ended in 1956. The
internationalized city of Tangier was turned over to the
new country that same year. Morocco virtually
annexed Western Sahara during the late 1970s, but
final resolution on the status of the territory remains
unresolved. Gradual political reforms in the 1990s
resulted in the establishment of a bicameral
legislature in 1997.
I . . 0 g''FTp''h^
Location; Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea, between
Algeria and Western Sahara
Geographic coordinates; 32 00 N, 5 00 W
Map references; Africa
Area;
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
Area - comparative; slightly larger than California
Land boundaries;
total: 2,017.9 km
border countries: Algeria 1,559 km, Western Sahara
443 km, Spain (Ceuta) 6.3 km, Spain (Melilla) 9.6 km
Coastline; 1,835 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 r)m
Climate; Mediterranean, becoming more extreme in
the interior
Terrain; northern coast and interior are mountainous
with large areas of bordering plateaus, intermontane
valleys, and rich coastal plains
Elevation extremes;
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources; phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use;
arable land: 21%
permanent crops: 1%
permanent pastures: 47%
forests and woodland: 20%
other; 11% (1993 est.)
Irrigated land; 12,580 sq km (1993 est.)
Natural hazards; northern mountains geologically
unstable and subject to earthquakes; periodic
droughts
Environment ■ current issues; land degradation/
desertification (soil erosion resulting from farming of
marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution of coastal
waters
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Erwirorrmentai Modification,
Law of the Sea
Geography ■ note; strategic location along Strait of','dac29557bf41a9b7051031d766dde7d993e3905f9720476cc4fb2b096af65e06','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('952b351fb3daac6694d92eabd419338ae371514e3329058724d2dfd8737cd871',2000,'JP','Japan','economy',273,'Bay NampSg
*a:Songnlm >^Kos6ng
-Sariwon „^rcatlou,\\
Kaesorig \\
!j^V\\j^i^P’anmunj6m \\
Yellow Sea
SOUTH KOREA \\
Economy - overview; North Korea ranks among the
world''s most centrally planned and isolated
economies. The resulting economic distortions and
the government''s reluctance to publicize economic
data limit the amount of reliable information available.
State-owned industry produces nearly all
manufactured goods, and the regime continues to
devote its focus on heavy and military industries at the
expense of light and consumer industries. Economic
conditions remain stagnant at best and the country''s
deepening economic slide has been fueled by acute
energy shortages, poorly maintained and aging
industrial facilities, and a lack of new investment. The
agricultural outlook, though slightly improved over
268
Korea, North (continued)
previous years, remains weak. The combined effects
of serious fertiiizer shortages, successive natural
disasters, and structural constraints - such as
marginal arable land and a short growing season -
have reduced staple grain output to more than 1
million tons less than what the country needs to meet
even minimum international requirements. The steady
flow of international food aid has been critical in
meeting the population''s basic food needs. The
impact of other forms of humanitarian assistance such
as medical supplies and agricultural assistance
largely has been limited to local areas. Even with aid,
malnutrition rates are among the world''s highest and
estimates of mortality range in the hundreds of
thousands as a direct result of starvation or
famine-related diseases.
GDP: purchasing power parity - $22.6 billion
(1999 est.)
GDP - real growth rate: 1 % (1 999 est.)
GDP - per capita: purchasing power parity - $1 ,000
(1999 est.)
GDP - composition by sector:
agriculture: 30%
industry: 42%
services: 28% (1 999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): NA%
Labor force: 9.6 million
Labor force - by occupation: agricultural 36%,
nonagricultural 64%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: SNA, including capital expenditures of
SNA
Industries: military products; machine building,
electric power, chemicals; mining (coal, iron ore,
magnesite, graphite, copper, zinc, lead, and precious
metals), metallurgy; textiles, food processing; tourism
Industrial production growth rate: NA%
Electricity - production: 31 .975 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 34.4%
hydro: 653%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 29.737 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: rice, corn, potatoes,
soybeans, pulses; cattle, pigs, pork, eggs
Exports; $680 million (f.o.b., 1998 est.)
Exports - commodities: minerals, metallurgical
products, manufactures (including armaments);
agricultural and fishery products
Exports - partners: Japan 28%, South Korea 21 %,
China 5%, Germany 4%, Russia 1% (1995)
Imports: $954 million (c.i.f., 1998 est.)
Imports - commodities; petroleum, coking coal,
machinery and equipment; consumer goods, grain
Imports - partners; China 33%, Japan 17%, Russia
5%, South Korea 4%, Germany 3% (1995)
Debt - external; $12 billion (1996 est.)
Economic aid - recipient: $NA; note - an estimated
$200 million to $300 million in humanitarian aid from
US, South Korea, Japan, and EU in 1997 plus much
additional aid from the UN and non-governmental
organizations
Currency: 1 North Korean won (Wn) = 100 chon
Exchange rates: official: North Korean won (Wn)
per US$1 - 2.15 (May 1994), 2.13 (May 1992), 2.14
(September 1991), 2.1 (January 1990), 2.3
(December 1989); market: North Korean won (Wn)
per US$1 - 200
Fiscal year: calendar year
I cId m m iTnTc a tio ii¥
Telephones - main lines in use: 1.1 million (1995)
Telephones - mobile cellular: 0 (1999)
Telephone system:
international: satellite earth stations - 1 1ntelsat
(Indian Ocean) and 1 Russian (Indian Ocean Region);
other international connections through Moscow and
Beijing
Radio broadcast stations: AM 16, FM 14,
shortwave 12 (1999)
Radios: 3.36 million (1997)
Television broadcast stations; 38 (1999)
Televisions: 1 .2 million (1997)
Internet Service Providers (ISPs): NA
Railways:
total: 5,000 km
standard gauge: A, 095 km 1.435-m gauge (3,500 km
electrified; 159 km double track)
narrow gauge: 665 km 0.762-m gauge
dual gauge: 240 km 1 .435-m and 1 .600-m gauges
(four rails interlaced) (1996 est.)
Highways;
total: 31 ,200 km
paved: 1 ,997 km
unpaved: 29,203 km (1996 est.)
Waterways: 2,253 km; mostly navigable by small
craft only
Pipelines; crude oil 37 km; petroleum product 180
km
Ports and harbors; Ch''ongjin, Haeju, Hungnam
(Hamhung), Kimch''aek, Kosong, Najin, Namp''o,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang, Wonsan
Merchant marine:
total: 107 ships (1,000 GRT or over) totaling 675,609
GRT/937,477 DWT
ships by type: bulk 5, cargo 91 , combination bulk 1 ,
multi-functional large load carrier 1, passenger 2,
passenger/cargo 1, petroleum tanker 4, short-sea
passenger 2 (1999 est.)
Airports; 49 (1994 est.)
Airports - with paved runways;
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 15
1,524 to 2,437 m: 2
914 to 1,523 m:1
under 914 m; 2 (1994 est.)
Airports - with unpaved runways:
total: 27
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 6 (1 994 est.)
I MTlTt ary
Military branches: Korean People''s Army (includes
Army, Navy, Air Force), Civil Security Forces
Military manpower - military age; 18 years of age
Military manpower - availability:
males age 15-49: 5,853,635 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 3,527,760 (2000 est.)
Military manpower - reaching military age
annually;
mates; 178,931 (2000 est.)
Military expenditures - dollar figure: $3.7 billion to
$4.9 billion (FY98 est.)
Military expenditures - percent of GDP: 25% to
33%(FY98est.)
i 0 iTa I i s"ru e s
Disputes - international: 33-km section of
boundary with China in the Paektu-san (mountain)
area is indefinite; Demarcation Line with South Korea
269','b4bcda9dd643a5e88a94bb289f1f178b67c3c250d1baa4f7b0f8f127d3e21744','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('647ce56984a28541aacd429b2d81a77b4c7aeb12984f1495797af06efdd6fde2',2000,'DE','Germany','economy',305,'Economy • overview: The economy is based
largely on tourism (including gambling) and textile and
fireworks manufacturing. Efforts to diversify have
spawned other small industries - toys, artificial
flowers, and electronics. The tourist sector has
accounted for roughly 25% of GDP, and the clothing
industry has provided about three-fourths of export
earnings; the gambling industry probably represents
over 40% of GDP. Macau depends on China for most
of its food, fresh water, and energy imports. Japan and
Hong Kong are the main suppliers of raw materials
and capital goods. Output dropped 4% in 1998 and
the economy remained weak in 1 999. Macau reverted
to Chinese administration on 20 December 1999.
Gang violence, a dark spot in the economy, probably
will be reduced in 2000 to the advantage of the
tourism sector.
GDP: purchasing power parity - $7.65 billion
(1998 est.)
GDP - real growth rate: -4% (1998 est.)
GDP - per capita: purchasing power parity -
$17,500 (1998 est.)
GDP - composition by sector:
agriculture: 1%
industry: 40%
services: 59% (1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -3% (1999 est.)
Labor force: 281,117(1998)
Labor force - by occupation: industry 31 %,
restaurants and hotels 28%, other services 41%
Unemployment rate: 6.9% (1999)
Budget:
revenues: $1 .34 billion
expenditures: $1 .34 billion, including capital
expenditures of $260 million (1998 est.)
Industries: clothing, textiles, toys, electronics,
footwear, tourism, gambling
Industrial production growth rate; NA%
Electricity - production: 1 .34 billion kWh (1998)
Electricity - production by source;
fossii fuel: 106%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity ■ consumption: 1 .42 billion kWh (1 998)
Electricity - exports: 1 million kWh (1998)
Electricity - imports: 175 million kWh (1998)
Agriculture ■ products: rice, vegetables
Exports: $1.7 billion (f.o.b., 1999)
Exports - commodities: textiles, clothing, toys,
electronics, cement, footwear, machinery
Exports • partners: US 48%, EU 31%, Hong Kong
8%, China 7% (1998)
Imports: $1.5 billion (c.i.f., 1999)
Imports - commodities: raw materials, foodstuffs,
capital goods, fuels, consumer goods
Imports - partners: China 33%, Hong Kong 24%,
EU 11%, Taiwan 10%, Japan 8% (1998)
Debt -external: $1.7 billion (1997)
Economic aid - recipient: $NA
Currency: 1 pataca (P) = 100 avos
Exchange rates: patacas (P) per US$1 - 8.01
(January 2000), 7.99 (1 999), 7.98 (1 998), 7.99 (1 997),
7.962 (1996), 8,034 (1993-95); note - linked to the
Hong Kong dollar at the rate of 1 .03 patacas per Hong
Kong dollar
Fiscal year; calendar year
Economy - overview: Landlocked Malawi ranks
among the world''s least developed countries. The
economy is predominately agricultural, with about
90% of the population living in rural areas. Agriculture
accounts for 37% of GDP and 85% of export
revenues. The economy depends on substantial
inflows of economic assistance from the IMF, the
World Bank, and individual donor nations. The
government faces strong challenges, e.g., to spur
exports, to improve educational and health facilities,
to face up to environmental problems of deforestation
and erosion, and to deal with the rapidly growing
problem of HIV/AIDS.
GDP: purchasing power parity - $9.4 billion
(1999est.)
GDP - real growth rate: 4.2% (1999 est.)
GDP - per capita: purchasing power parity - $940
(1999 est.)
GDP - composition by sector:
agriculture: 37%
industry: 29%
services: 34% (1 998 est.)
Population below poverty line: 54%(1 990-91 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 45% (1999)
Labor force: 3.5 million
Labor force - by occupation: agriculture 86%,
wage earners 14% (1990 est.)
Unemployment rate: NA%
Budget:
revenues: $490 million
expenditures: $523 million, including capital
expenditures of $NA (FY99/00 est.)
Industries: tobacco, tea, sugar, sawmill products,
cement, consumer goods
Industrial production growth rate: NA%
Electricity • production: 922 million kWh (1998)
Electricity - production by source:
fossil fuel: 2.39%
hydro: 97.61%
nuclear: 0%
other: 0% (1996)
Electricity ■ consumption: 857 million kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: tobacco, sugarcane,
cotton, tea, corn, potatoes, cassava (tapioca),
sorghum, pulses; cattle, goats
Exports: $510 million (f.o.b., 1999)
Exports - commodities: tobacco, tea, sugar,
cotton, coffee, peanuts, wood products
Exports - partners: South Africa 15%, US 9%,
Germany 9%, Netherlands 7%, Japan (1998)
Imports: $512 million (f.o.b., 1999)
Imports - commodities: food, petroleum products,
semimanufactures, consumer goods, transportation
equipment
Imports - partners: South Africa 38%, Zimbabwe
18%, Zambia 8%, Japan 4%, US, UK, Germany
(1998)
Debt - external: $2.3 billion (1999 est.)
Economic aid - recipient; $416.5 million (1995)
Currency: 1 Malawian kwacha (MK) = 100 tambala
Exchange rates; Malawian kwachas (MK) per
US$1 -46.3494 (December 1999), 44.0881 (1999),
31.0727 (1998), 16.4442 (1997), 15.3085 (1996),
15.2837(1995)
Fiscal year: 1 July - 30 June
I Co mm u n i c a 1 1 0 n s
Telephones - main lines In use: 34,000 (1995)
Telephones - mobile cellular: 382 (1995)
Telephone system:
domesf/c.-fair system of open-wire lines, microwave
radio relay links, and radiotelephone communications
stations
international: satellite earth stations - 2 Intelsat (1
Indian Ocean and 1 Atlantic Ocean)
Radio broadcast stations; AM 9, FM 4 (plus 15
repeater stations), shortwave 3 (1 998)
Radios; 2.6 million (1997)
Television broadcast stations: 1 (1999)
Televisions; 0(1999)
Internet Service Providers (ISPs): 1 (1999)
I r a n¥p 0 ^ ~
Railways;
total: 789 km
narrow gauge: 789 km 1 .067-m gauge
Highways:
total: 28,400 km
paved: 5,254 km
unpaved: 23, U6 km (1996 est.)
Waterways: Lake Nyasa (Lake Malawi); Shire River,
144 km
Ports and harbors; Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota, Chilumba
Airports: 44 (1999 est.)
Airports ■ with paved runways;
total: 5
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 3 (1999 est.)
Airports - with unpaved runways:
total: 39
1,524 to 2,437 m:1
914 to 1,523 m: 15
under 914 m: 23 (1999 est.)
1"^''"'' . . ™ M i I i t a r y ™
Military branches: Army (includes Air Wing and
Naval Detachment), Police (includes paramilitary
Mobile Force Unit)
Military manpower - availability:
males age 15-49: 2,397,385 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,229,676 (2000 est.)
Military expenditures - dollar figure: $17 million
(FY96/97)
Military expenditures - percent of GDP: 0.8%
(FY96/97)
I '' t r a nTFa^ tTo n O llTu eT^''^
Disputes - international; dispute with Tanzania
over the boundary in Lake Nyasa (Lake Malawi)
305','2d89891201d6e3cf05c459b3e6630ea0f9926856509fdce7ec996518ad9f3b02','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f665aaa3f0410a6a7fa3f960f0daef547078f90810a85044fda0f53057e8a2b',2000,'MY','Malaysia','economy',308,'the merging of Malaya (independent in 1957) and the
former British Singapore, both of which formed West
Malaysia, and Sabah and Sarawak in north Borneo,
which composed East Malaysia. The first three years
of independence were marred by hostilities with
Indonesia. Singapore seceded from the union in 1 965.','6d5743dc8af8096cd9b509056203eb3a455e1f9a21566d20957faa6b0c8d386d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d4136a436536ae9b023376cb44d8b43683cf7b73164810e46f78f8adf93aa9',2000,'MR','Mauritania','economy',328,'Economy - overview: A majority of the population
still depends on agriculture and livestock for a
livelihood, even though most of the nomads and many
subsistence farmers were forced into the cities by
recurrent droughts in the 1970s and 1980s.
Mauritania has extensive deposits of iron ore, which
account for almost 50% of total exports. The decline in
world demand for this ore, however, has led to
cutbacks in production. The nation''s coastal waters
are among the richest fishing areas in the world, but
overexploitation by foreigners threatens this key
source of revenue. The country''s first deepwater port
opened near Nouakchott in 1986. In recent years,
drought and economic mismanagement have resulted
in a buildup of foreign debt. In March 1999, the
government signed an agreement with a joint World
Bank-IMF mission on a $54 million enhanced
structural adjustment facility (ESAF). The economic
objectives have been set for 1999-2002. Privatization
remains one of the key issues. Mauritania is unlikely
to meet ESAF''s annual GDP growth objectives of
4%-5%.
GDP: purchasing power parity - $4.9 billion
(1999 est.)
GDP - real growth rate: 3.7% (1999 est.)
GDP - per capita: purchasing power parity - $1,910
(1999 est.)
GDP - composition by sector:
agriculture: 25%
Industry: 3t%
services: 44% (1997)
Population below poverty line; 57% (1990 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.7%
h/ghesf 10%; 30.4% (1988)
Inflation rate (consumer prices); 9.8% (1998)
Labor force: 465,000 (1981 est.); 45,000 wage
earners (1980)
Labor force - by occupation; agriculture 47%,
services 39%, industry 14%
Unemployment rate: 23% (1995 est.)
Budget:
revenues: $329 million
expenditures: $265 million, including capital
expenditures of $75 million (1996 est.)
Industries; fish processing, mining of iron ore and
gypsum
Industrial production grovirth rate: 7.2% (1994)
Electricity • production: 152 million kWh (1998)
Electricity - production by source;
fossil fuel: 80.26%
hydro: 19.74%
nuclear: 0%
other: 0%(199B)
Electricity - consumption: 141 million kWh (1998)
Electricity - exports; 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: dates, millet, sorghum, root
crops; cattle, sheep; fish products
Exports; $425 million (f.o.b., 1997)
Exports - commodities; fish and fish products, iron
ore, gold
Exports - partners: Japan 24%, Italy 17%, France
14%, Spain 8% (1997)
Imports: $444 million (f.o.b., 1997)
Imports - commodities: machinery and equipment,
petroleum products, capital goods, foodstuffs,
consumer goods
Imports - partners: France 26%, Spain 8%,
Germany 7%, Benelux 7% (1997)
Debt - external; $2.5 billion (1 997)
Economic aid - recipient: $227.9 million (1995)
Currency: 1 ouguiya (UM) = 5 khoums
Exchange rates; ouguiyas (UM) per US$1 -219.560
(December 1999), 209.514 (1999), 188.476 (1998),
151.853 (1997), 137.222 (1996), 129.768 (1995)
Fiscal year; calendar year
321
Mauritania (continued)
Economy - overview: Since independence in 1976,
per capita output in this Indian Ocean archipelago has
expanded to roughly seven times the old
near-subsistence level. Growth has been led by the
tourist sector, which employs about 30% of the labor
force and provides more than 70% of hard currency
earnings, and by tuna fishing. In recent years the
government has encouraged foreign investment in
order to upgrade hotels and other services. At the
same time, the government has moved to reduce the
dependence on tourism by promoting the
development of farming, fishing, and small-scale
manufacturing. The vulnerability of the tourist sector
was illustrated by the sharp drop in 1991-92 due
largely to the Gulf war. Although the industry has
rebounded, the government recognizes the continuing
need for upgrading the sector in the face of stiff
international competition. Other issues facing the
government are the curbing of the budget deficit and
further privatization of public enterprises. Growth
slowed in 1998-99, due to sluggish tourist and tuna
sectors.
GDP: purchasing power parity - $590 million
(1999 est.)
GDP - real growth rate: 1 .8% (1 999 est.)
GDP - per capita: purchasing power parity - $7,500
(1999 est.)
GDP - composition by sector:
agriculture: 4%
industry: 2t%
services: 75% (1996)
Popuiation beiow poverty iine: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (1999)
Labor force: 26,000(1996)
Labor force - by occupation: industry 1 9%,
services 57%, government 14%, fishing, agriculture,
and forestry 10% (1989)
Unemployment rate: NA%
Budget:
revenues: $220 million
expenditures: $241 million, including capital
expenditures of $36 million (1994 est.)
Industries: fishing; tourism; processing of coconuts
and vanilla, coir (coconut fiber) rope, boat building,
printing, furniture; beverages
Industrial production growth rate: NA%
Electricity - production: 125 million kWh (1998)
Electricity - production by source:
fossii fuel: 100%
hydro: 0%
nuclear: 0%
other: Q%{m8)
Electricity - consumption: 1 1 6 million kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: coconuts, cinnamon,
vanilla, sweet potatoes, cassava (tapioca), bananas;
broiler chickens; tuna fish
Exports: $91 million (f.o.b., 1998)
Exports - commodities: fish, cinnamon bark, copra,
petroleum products (reexports)
Exports - partners: France, UK, Netherlands, Italy,
China, Germany, Japan
Imports: $403 million (c.i.f., 1998)
Imports • commodities: machinery and equipment,
foodstuffs, petroleum products
Imports - partners: South Africa, UK, China,
Singapore, France, Italy
Debt ■ external: $149 million (1997 est.)
Economic aid - recipient: $16.4 million (1995)
Currency: 1 Seychelles rupee (SRe) = 100 cents
Exchange rates: Seychelles rupees (SRe) per
US$1 - 5.3060 (September 1999), 5.2622 (1998),
5.0263 (1997), 4.9700 (1996), 4.7620 (1995)
Fiscal year: calendar year','71aafe302b360d1452d38f79f5dffcbd8a2209bc31fe562c9c5641b5e2b47b0d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c19ecd69b9cd7160aeae0b07ea5bf2a922781dcfa3e6e3b4b36546956e04783',2000,'ID','Indonesia','economy',343,'Economy - overview: Economic activity consists
primarily of subsistence farming and fishing. The
islands have few mineral deposits worth exploiting,
except for high-grade phosphate. The potential for a
tourist industry exists, but the remoteness of the
location and a lack of adequate facilities hinder
development. Financial assistance from the US is the
primary source of revenue, with the US pledged to
spend $1.3 billion in the islands in 1986-2001.
Geographical isolation and a poorly developed
infrastructure are major impediments to long-term
growth.
GDP: purchasing power parity - $240 million
(1997 est.)
note: GDP is supplemented by grant aid, averaging
perhaps $100 million annually
GDP ■ real growth rate: 3% (1997 est.)
GDP ■ per capita: purchasing power parity - $2,000
(1997 est.)
GDP - composition by sector:
agriculture: 19%
industry: 4%
services: 77% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4% (1996 est.)
Labor force: NA
Labor force - by occupation: two-thirds are
government employees
Unemployment rate: 27% (1989)
Budget:
revenues: $58 million
expenditures: $52 million, including capital
expenditures of $4.7 million (FY95/96 est.)
Industries: tourism, construction, fish processing,
craft items from shell, wood, and pearls
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: black pepper, tropical fruits
and vegetables, coconuts, cassava (tapioca), sweet
potatoes; pigs, chickens
Exports: $73 million (f.o.b., 1996 est.)
Exports - commodities: fish, garments, bananas,
black pepper
Exports - partners: Japan, US, Guam
Imports: $168 million (c.i.f., 1996 est.)
Imports - commodities: food, manufactured goods,
machinery and equipment, beverages
Imports - partners: US, Japan, Australia
Debt - external: $1 1 1 million (1 997 est.)
Economic aid - recipient: $79 million (1 998); note -
under terms of the Compact of Free Association, the
US will provide $1.3 billion in grant aid during the
period 1986-2001
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October - 30 September
Economy - overview: Moldova enjoys a favorable
climate and good farmland but has no major mineral
deposits. As a result, the economy depends heavily
on agriculture, featuring fruits, vegetables, wine, and
tobacco. Moldova must import all of its supplies of oil,
coal, and natural gas, largely from Russia. Energy
shortages contributed to sharp production declines
after the breakup of the Soviet Union in 1 991 . As pari
of an ambitious reform effort, Moldova introduced a
stable convertible currency, freed all prices, stopped
issuing preferential credits to state enterprises,
backed steady land privatization, removed export
controls, and freed interest rates. Yet these efforts
could not offset the impact of political and economic
difficulties, both internal and regional. In 1998, the
economic troubles of Russia, by far Moldova''s leading
trade partner, were a major cause of the 8.6% drop in
GDP; the value of the currency in relation to the dollar
fell by half. In 1 999, GDP fell again, by 4.4%, the fifth
drop in the past six years; exports were down, and
energy supplies continued erratic. GDP is expected to
remain at about the same level in 2000.
GDP: purchasing power parity - $9.7 billion
(1999 est.)
GDP - real growth rate: -4.4% (1999 est.)
GDP - per capita: purchasing power parity - $2,200
(1999 est.)
GDP - composition by sector:
agriculture: 31%
industry: 35%
serv/ces; 34% (1998) ,
Population below poverty line: 75% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.7%
highest 10%; 25.8% (1992)
Inflation rate (consumer prices): 38% (1999 est.)
Labor force: 1.7 million (1998)
Labor force - by occupation: agriculture 40.2%,
industry 14.3%, other 45.5% (1998)
Unemployment rate: 2% (includes only officially
registered unemployed; large numbers of
underemployed workers) (September 1998)
Budget:
revenues: $536 million
expenditures: $594 million, including capital
expenditures of $NA (1998 est.)
Industries: food processing, agricultural machinery,
foundry equipment, refrigerators and freezers,
washing machines, hosiery, sugar, vegetable oil,
shoes, textiles
Industrial production growth rate: -10%
(1999 est.)
Electricity - production: 5.661 billion kWh (1998)
Electricity - production by source:
fossil fuel: 93%
hydro: 7%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 7.065 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 1 .8 billion kWh (1 998)
Agriculture - products: vegetables, fruits, wine,
grain, sugar beets, sunflower seed, tobacco; beef,
milk
332
Moldova (continued)
Exports: $470 million (f.o.b., 1999)
Exports - commodities: foodstuffs, wine, and
tobacco 66%; textiles and footwear, machinery (1 998)
Exports - partners: Russia 53%, Romania 10%,
Ukraine 8%, Germany 5%, Belarus 4% (1998)
Imports: $560 million (f.o.b., 1999)
Imports - commodities: mineral products and fuel
31%, machinery and equipment, chemicals, textiles
(1998)
Imports - partners: Russia 22%, Ukraine 1 6%,
Romania 12%, Belarus 9%, Germany 5% (1998)
Debt - external: $1 .3 billion (December 1999)
Economic aid - recipient: $100.8 million (1995);
note - $547 million from the IMF and World Bank
(1992-99)
Currency: Moldovan leu (MLD) (plural lei)
Exchange rates: lei (MLD) per US$1 (end of year) -
12.1408 (January 2000), 10.5158 (1999), 5.3707
(1998), 4.6236 (1997), 4.6045 (1996), 4.4958 (1995)
Fiscal year: calendar year
I C 0 mm u n i c a t i 0 n s
Telephones - main lines in use: 566,000 (1995)
Telephones - mobile cellular: 1 4 (1 995)
Telephone system: inadequate, outmoded, poor
service outside Chisinau, some effort to modernize is
under way
domestic: new subscribers face long wait for service;
mobile cellular telephone service being introduced
international: service through Romania and Russia
via landline; satellite earth stations - Intelsat, Eutelsat,
and Intersputnik
Radio broadcast stations: AM 7, FM 50, shortwave
3(1998)
Radios: 3.22 million (1997)
Television broadcast stations: 40 (1998)
Televisions: 1.26 million (1997)
Internet Service Providers (ISPs): 2 (1999)
I" Transportation
Railways:
total: 1 ,328 km
broad gauge: 1,328 km 1.520-m gauge (1992)
Highways:
total: 12,300 km
paved: 10,738 km
unpaved: 1 ,562 km (1 996 est.)
Waterways: 424 km (1994)
Pipelines: natural gas 310 km (1992)
Ports and harbors: none
Airports: 26 (1994 est.)
Airports - with paved runways:
total: 8
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 3 (1 994 est.)
Airports - with unpaved runways:
fofa/;18
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 8 (1 994 est.)
I; M i I i t a r y
Military branches: Ground Forces, Air and Air
Defense Forces, Republic Security Forces (internal
and border troops)
Military manpower - military age; 1 8 years of age
Military manpower - availability:
males age 15-49; 1,156,705 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 913,896 (2000 est.)
Military manpower - reaching military age
annually:
males: 40,239 (2000 est.)
Military expenditures - dollar figure: $6 million
(FY99) -
Military expenditures - percent of GDP; 1 %
(FY99)
transnational I s sTe s
Disputes - international; separatist Transnistria
region, comprising the area between the Nistru
(Dniester) River and Ukraine, has its own de facto
government, dominated by Moldovan Slavs
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for CIS consumption; transshipment
point for illicit drugs from Southwest Asia via Central
Asia to Russia, Western Europe and possibly the US
Background: Economic development was spurred
in the late 1 9th century with a railroad linkup to France
and the opening of a casino. Since then, the
principality''s mild climate, splendid scenery, and
gambling facilities have made Monaco world famous
as a tourist and recreation center.
I ~~G''e 0 g r a p h y
Location; Western Europe, bordering the
Mediterranean Sea, on the southern coast of France,
near the border with Italy
Geographic coordinates; 43 44 N, 7 24 E
Map references; Europe
Area;
total: 1 .95 sq km
land: 1 .95 sq km
water: 0 sq km
Area - comparative; about three times the size of
The Mall in Washington, DC
Land boundaries:
total: 4.4 km
border countries: France 4.4 km
Coastline; 4.1 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean with mild, wet winters and
hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes;
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (urban area)
Irrigated land: NAsqkm
333
Monaco (continued)
Natural hazards: NA
Environment - current issues; NA
Environment - internationai agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: second smallest independent
state in world (after Holy See); almost entirely urban
Economy - overview: Monaco, situated on the
French Mediterranean coast, is a popular resort,
attracting tourists to its casino and pleasant climate.
The Principality has successfully sought to diversify
into services and small, high-value-added,
nonpolluting industries. The state has no income tax
and low business taxes and thrives as a tax haven
both for individuals who have established residence
and for foreign companies that have set up
businesses and offices. The state retains monopolies
in a number of sectors, including tobacco, the
telephone network, and the postal sen/ice. Living
standards are high, roughly comparable to those in
prosperous French metropolitan areas. Monaco does
not publish national income figures; the estimates
below are extremely rough.
GDP: purchasing power parity - $870 million
(1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$27,000 (1999 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population beiow poverty iine: NA%
Househoid income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: ti^%
inflation rate (consumer prices): NA%
Labor force: 30,540 (January 1994)
Unemployment rate: 3.1% (1998)
Budget;
revenues; $51 8 million
expenditures: $531 million, including capital
expenditures of $NA (1995)
Industries: tourism, construction, small-scale
industrial and consumer products
Industrial production growth rate: NA%
Electricity - production; NA kWh
Electricity - production by source;
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: none
Exports: $NA; full customs integration with France,
which collects and rebates Monegasque trade duties;
also participates in EU market system through
customs union with France
Imports: $NA; full customs integration with France,
which collects and rebates Monegasque trade duties;
also participates in EU market system through
customs union with France
Debt ■ external; $NA
Economic aid - recipient: $NA
Currency: 1 French franc (F) = 100 centimes
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); French francs (F) per US$1 -
5.65 (January 1999), 5.8995 (1998), 5.8367 (1997),
5.1155 (1996), 4.9915 (1995)
Fiscal year: calendar year
334
Monaco (continued)
|f Communications
Telephones - main lines in use; 31,027 (1995)
Telephones - mobile cellular: 2,560 (1 994)
Telephone system: automatic telephone system
domestic: NA
international: no satellite earth stations; connected by
cable into the French communications system
Radio broadcast stations: AM 1, FM NA,
shortwave 8 (1998)
Radios: 34,000(1997)
Television broadcast stations: 5 (1997)
Televisions: 25,000(1997)
Internet Service Providers (ISPs): 4 (1999)
I Transportation
Railways:
total: t. 7 km
standard gauge: M km 1.435-m gauge
Highways:
total: 50 km
paved: 50 km
unpaved: 0 km (1996 est.)
Ports and harbors: Monaco
Merchant marine; none (1999 est.)
Airports: linked to airport in Nice, France, by
helicopter service
Heliports; 1 (shuttle service between the
international airport at Nice, France, and Monaco''s
heliport at Fontvieille)
I M M i tTf y ~ "
Military - note; defense Is the responsibility of
Economy - overview: Singapore is blessed with a
highly developed and successful free-market
economy, a remarkably open and corruption-free
business environment, stable prices, and the fifth
highest per capita GDP in the world. Exports,
particularly in electronics and chemicals, and services
are the main drivers of the economy. The government
promotes high levels of savings and investment
through a mandatory savings scheme and spends
heavily in education and technology. It also owns
government-linked companies (GLCs) - particularly in
manufacturing - that operate as commercial entities
and account for 60% of GDP. As Singapore looks to a
future increasingly marked by globalization, the
country is positioning itself as the region''s financial
and high-tech hub.
GDP: purchasing power parity - $98 billion
(1999 est.)
GDP - real growth rate: 5.5% (1999 est.)
GDP - per capita: purchasing power parity -
$27,800 (1999 est.)
GDP - composition by sector:
agriculture: NEGL%
industry: 28%
senrices: 72%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 0.4% (1999)
Labor force: 1 .932 million (1 998)
Labor force - by occupation: financial, business,
and other services 38%, manufacturing 21 .6%,
commerce 21.4%, construction 7%, other 12%
Unemployment rate: 3.2% (1999 est.)
Budget:
reverrues; $13.9 billion
expenditures: $16.9 billion, including capital
expenditures of $8.1 billion (FY98/99 est.)
Industries: electronics, financial services, oil drilling
equipment, petroleum refining, rubber processing and
rubber products, processed food and beverages, ship
repair, entrepot trade, biotechnology
Industrial production growth rate: 14%
(1999 est.)
Electricity - production: 26.586 billion kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1008)
Electricity - consumption: 24.725 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: rubber, copra, fruit,
vegetables; poultry, eggs, fish, vegetables, orchids,
ornamental fish
Exports: $114 billion (1999)
Exports - commodities: machinery and equipment
(including electronics) 63%, chemicals, mineral fuels
(1998)
Exports - partners: US 19%, Malaysia 17%, Hong
Kong 8%, Japan 7%, Taiwan 5%, Thailand 4%, UK
4%, China 3%, Germany 3% (1998)
Imports: $111 billion (1999)
Imports - commodities: machinery and equipment
57%, mineral fuels, chemicals, foodstuffs (1998)
Imports • partners: US 17%, Japan 17%, Malaysia
16%, Thailand 5%, China 5%, Taiwan 4%, Germany,
Saudi Arabia (1998)
Debt -external: $NA
Economic aid - recipient: $NA
Currency: 1 Singapore dollar (S$) = 100 cents
Exchange rates: Singapore dollars (S$) per US$1 -
1 .6733 (January 2000), 1 .6950 (1 999), 1 .6736 (1998),
1 .4848 (1997), 1 .41 00 (1 996), 1 .41 74 (1 995)
Fiscal year: 1 April - 31 March','86cb0a5afc59078f993eccfb079e21e9f95cae1af5f9b2db3dd04e34c6bfa4a8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f763772db8b0c35cc8793ff78a4bcd41b092362e9ea7511bd0fd3b4ddc90fc48',2000,'GI','Gibraltar','economy',349,'I . . .
Population; 30,122,350 (July 2000 est.)
Age structure;
0-14 years: 35% (male 5,372,393; female 5,175,1 14)
15-64 years: 60% (male 9,021 ,259; female
9,163,548)
65 years and over: 5% (male 632,698; female
757,338) (2000 est.)
Population growth rate; 1 .74% (2000 est.)
Birth rate; 24.6 births/1 ,000 population (2000 est.)
Death rate; 6.02 deaths/1 ,000 population
(2000 est.)
Net migration rate; -1.21 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate; 49.72 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 69.13 years
male: 66.92 years
female: 71 .44 years (2000 est.)
Total fertility rate; 3.13 children born/woman
(2000 est.)
Nationality;
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups; Arab-Berber 99.1%, other 0.7%,
Jewish 0.2%
339
Morocco (continued)
Religions: Muslim 98.7%, Christian 1.1%, Jewish
0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 15 and over can read and write
total population: 43.7%
male: 56.6%
female: 3t% (1995 est.)
Economy - overview: Morocco faces the problems
typical of developing countries - restraining
government spending, reducing constraints on private
activity and foreign trade, and achieving sustainable
economic growth. Since the early 1980s the
government has pursued an economic program
toward these objectives with the support of the IMF,
the World Bank, and the Paris Club of creditors. The
dirham is now fully convertible for current account
transactions; reforms of the financial sector have been
implemented; and state enterprises are being
privatized. Drought conditions depressed activity in
the key agricultural sector, and contributed to an
economic slowdown in 1999. Favorable rainfalls have
led Morocco to predict a grovrth of 6% for 2000.
Formidable long-term challenges include: servicing
the external debt; preparing the economy for freer
trade with the EU; and improving education and
attracting foreign investment to improve living
standards and job prospects for Morocco''s youthful
population.
GDP: purchasing power parity - $1 08 billion
(1999 est.)
GDP - real growth rate: 0% (1999 est.)
GDP - per capita: purchasing power parity - $3,600
(1999 est.)
GDP - composition by sector:
agriculture: 16%
industry: 30%
services: 54% (1998 est.)
Population below poverty line: 13.1%
(1990-91 est.)
Household income or consumption by percentage
share;
lowest 10%: 2.8%
highest 10%: 30.5% (1990-91)
inflation rate (consumer prices); 1 .9% (1 999 est.)
Labor force: 1 1 million (1 997 est.)
Labor force - by occupation: agriculture 50%,
services 35%, industry 15% (1999 est.)
Unemployment rate: 19% (1998 est.)
340
Morocco (continued)
Budget:
revenues: $9 A billion
expenditures: biliion, including capital
expenditures of $1 .7 biliion (FY98/99 est.)
Industries: phosphate rock mining and processing,
food processing, leather goods, textiles, construction,
tourism
Industrial production growth rate: 2% (1998 est.)
Electricity - production: 13.16 billion kWh (1998)
Electricity - production by source:
fossil fuel: 83.59%
hydro: 16.41%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 1 2.363 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 124 million kWh (1998)
Agriculture - products: barley, wheat, citrus, wine,
vegetables, olives; livestock
Exports: $7.1 billion (f.o.b., 1998)
Exports - commodities: phosphates and fertilizers,
food and beverages, minerals (1998)
Exports - partners: France 27%, Spain 11%, India
7%, Japan 6%, Italy 5% (1998)
Imports: $9.5 billion (f.o.b., 1998)
Imports - commodities: semiprocessed goods,
machinery and equipment, food and beverages,
consumer goods, fuel (1998)
Imports - partners: France 22%, Spain 10%, US
7%, Germany 6%, Italy 6% (1998)
Debt - external: $19.1 billion (1999 est.)
Economic aid ■ recipient: $565.6 million (1995)
Currency: 1 Moroccan dirham (DH) = 100 centimes
Exchange rates: Moroccan dirhams (DH) per
US$1 - 10.051 (January 2000), 9.804 (1999), 9.604
(1998), 9.527 (1997), 8.716 (1996), 8.540 (1995)
Fiscal year: July 1 - June 30
I Communications
Telephones - main lines in use: 1 .391 million
(1998)
Telephones - mobile cellular: 1 1 6,645 (1998)
Telephone system:
domestic: good system composed of open-wire lines,
cables, and microwave radio relay links; Internet
available but expensive; principal switching centers
are Casablanca and Rabat; national network nearly
100% digital using fiber-optic links; improved rural
service employs microwave radio relay
international: 7 submarine cables; satellite earth
stations - 2 Intelsat (Atlantic Ocean) and 1 Arabsat;
microwave radio relay to Gibraltar, Spain, and
Western Sahara; coaxial cable and microwave radio
relay to Algeria; participant in Medarabtel; fiber-optic
cable link from Agadir to Algeria and Tunisia
Radio broadcast stations: AM 27, FM 25,
shortwave 6 (1998)
Radios: 6.64 miliion (1997)
Television broadcast stations: 26 (plus 35
repeaters) (1997)
Televisions: 3.1 million (1997)
Internet Service Providers (ISPs): 27 (1999)
I Tr a n s p^ rt a t i o n
Railways:
total: 1 ,907 km
standard gauge: 1 ,907 km 1 .435-m gauge (1 ,003 km
electrified; 540 km double track)
Highways:
total: 57,847 km
paved: 30,254 km (including 327 km of expressways)
unpaved: 27,593 km (1 998 est.)
Pipelines: crude oil 362 km; petroleum products 491
km (abandoned); natural gas 241 km
Ports and harbors: Agadir, El Jadida, Casablanca,
El Jorf Lasfar, Kenitra, Mohammedia, Nador, Rabat,
Safi, Tangier; also Spanish-controlled Ceuta and
Melilla
Merchant marine:
total: 40 ships (1 ,000 GRT or over) totaling 21 8,987
GRT/263,191 DWT
ships by type: cargo 9, chemical tanker 6, container 3,
passenger 1 , petroieum tanker 3, refrigerated cargo 9,
roii-on/roli-off 8, short-sea passenger 1 (1999 est.)
Airports: 70 (1999 est.)
Airports - with paved runways:
total: 29
over 3,047 m: IQ
2,438 to 3,047 m: 5
1,524 to 2,437 m: 9
914 to 1,523 m:-\\
under914m:1 (1999 est.)
Airports - with unpaved runways:
total: 44
2,438 to 3,047 m:1
1,524 to 2,437 m: 10
914 to 1,523 m: 22
under 9/4 m; 1 1 (1 999 est.)
Heliports: 1 (1999est.)
I m1 f i t a r y
Military branches: Royal Armed Forces (includes
Army, Navy, Air Force), Gendarmerie, Auxiiiary
Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
mates age 15-49: 7,961 ,552 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 5,026,210 (2000 est.)
Military manpower - reaching military age
annually:
mates: 335,264 (2000 est.)
Military expenditures - dollar figure: $1 .361 billion
(FY97/98)
Military expenditures - percent of GDP: 3.8%
(FY97/98)
I fransnaticTinal lss¥Ts
Disputes - international: claims and administers
Western Sahara, but sovereignty is unresolved and
the UN is attempting to hold a referendum on the
issue; the UN-administered cease-fire has been in
effect since September 1991; Spain controls five
places of sovereignty (plazas de soberania) on and off
the coast of Morocco - the coastal enclaves of Ceuta
and Melilla which Morocco contests, as well as the
islands of Penon de AIhucemas, Penon de Velez de la
Gomera, and Islas Chafarinas
Illicit drugs: illicit producer of hashish; trafficking on
the increase for both domestic and international drug
markets; shipments of hashish mostly directed to
Western Europe; transit point for cocaine from South
America destined for Western Europe
341','d7c007b418a26888699b8bc8d61701d0ca86d46e734914c6299019bfcfc2f584','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c26211a92f3d6c8f140470f399950bf60d87467d5839e15ab8c5b5c04981e3e0',2000,'NL','Netherlands','economy',356,'Antilles
(part of the Kingdom of
the Netherlands)
J introduction
Background: Once the center of the Caribbean
slave trade, the island of Curacao was hard hit by the
abolition of slavery in 1863. Its prosperity (and that of
neighboring Aruba) was restored in the early 20th
century with the construction of oil refineries to sen/ice
the newly discovered Venezuelan oil fields. The island
of Sint Maarten is shared with France (whose northern
portion is named Saint Martin and is part of
Guadeloupe).','394a2ee3a1f5647bc304cf112da51b25909cc82fcd7f9daab741635128da612c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f70f162241c0716eac3e69d801c446c65e06aaf33950adbc0d0c3e04fb8a5ad7',2000,'NZ','New Zealand','economy',370,'Economy - overview: Nicaragua is one of the
hemisphere''s poorest countries, with low per capita
income, flagging socio-economic indicators, and huge
external debt. The country has made significant
progress toward macro-economic stabilization over
the past few years - even with the damage caused by
Hurricane Mitch in the fall of 1998. International aid,
debt relief, and continued foreign investment have
contributed to the stabilization process. GDP grew
6.3% in 1999, while inflation remained about 1 2%, and
unemployment dropped. Nicaragua may qualify for
the Highly Indebted Poor Countries (HIPC) initiative,
though aid is conditioned on improving governability,
the openness of government financial operations,
poverty alleviation, and human rights.
GDP: purchasing power parity - $12.5 billion
(1999 est.)
GDP - real growth rate: 6.3% (1999 est.)
GDP - per capita: purchasing power parity - $2,650
(1999 est.)
GDP - composition by sector:
agriculture: 34%
industry: 22%
services: 44% (1998)
Population below poverty line: 50% (1 999 est.)
Household income or consumption by percentage
share:
towesf f0%;1.6%
highest f0%; 39.8% (1993)
Inflation rate (consumer prices): 12% (1999 est.)
Labor force: 1 .7 million (1 999)
Labor force - by occupation: services 43%,
agriculture 42%, industry 15% (1999 est.)
Unemployment rate: 10.5% (1999 est.);
considerable underemployment
Budget:
revenues: $527 million
expenditures: $617 million, including capital
expenditures of $NA (1998 est.)
Industries: food processing, chemicals, machinery
and metal products, textiles, clothing, petroleum
refining and distribution, beverages, footwear, wood
Industrial production growth rate: 3.2% (1998 est.)
Electricity - production: 2.714 billion kWh (1998)
Electricity - production by source:
fossil fuel: 53.43%
hydro: 35.34%
nuclear: 0%
of/rer; 11.23% (1998)
Electricity ■ consumption: 2.52 billion kWh (1998)
Electricity - exports: 99 million kWh (1998)
Electricity - imports: 95 million kWh (1998)
Agriculture - products: coffee, bananas,
sugarcane, cotton, rice, corn, tobacco, sesame, soya,
beans; beef, veal, pork, poultry, dairy products
Exports: $573 million (f.o.b., 1998 est.)
Exports - commodities: coffee, shrimp and lobster,
cotton, tobacco, beef, sugar, bananas; gold
Exports - partners; US 35''%, Germany 13%, El
Salvador 10%, Spain 4%, Costa Rica 4%, France 2%
(1998)
Imports: $1 .5 billion (c.i.f., 1999 est.)
Imports - commodities: machinery and equipment,
raw materials, petroleum products, consumer goods
Imports - partners: US 31%, Costa Rica 11%,
Guatemala 8%, Venezuela 6%, El Salvador 5%,
Mexico 4% (1998)
Debt - external: $5.7 billion (1999 est.)
Economic aid - recipient: pledges of $1 .4 billion in
new aid in 1999
Currency: 1 gold cordoba (C$) = 100 centavos
Exchange rates: gold cordobas (C$) per US$1 -
12.29 (December 1999), 11.81 (1999), 10.58 (1998),
9.45 (1997), 8.44 (1996), 7.55 (1995)
Fiscal year: calendar year
Economy - overview: Niger is a poor, landlocked
Sub-Saharan nation, whose economy centers on
subsistence agriculture, animal husbandry, reexport
trade, and increasingly less on uranium, its major
export since the 1970s. The 50% devaluation of the
West African franc in January 1 994 boosted exports of
livestock, cowpeas, onions, and the products of
Niger''s small cotton industry. The government relies
on bilateral and multilateral aid - which was
suspended following the April 1999 coup d''etat - for
operating expenses and public investment.
Short-term prospects depend on upcoming
negotiations with the World Bank and the IMF on debt
relief and extended aid.
GDP: purchasing power parity - $9.6 billion
(1999 est.)
GDP - real growth rate: 2% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,000
(1999 est.)
GDP - composition by sector;
agriculture: 40%
industry: 18%
services; 42% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 10%; 29.3% (1992)
Inflation rate (consumer prices): 4.8% (1999)
Labor force: 70,000 receive regular wages or
salaries
Labor force - by occupation: agriculture 90%,
industry and commerce 6%, government 4%
Unemployment rate: NA%
Budget:
revenues: $377 million, including $146 million from
foreign sources
expenditures: $377 million, including capital
expenditures of $105 million (1999 est.)
Industries: uranium mining, cement, brick, textiles,
food processing, chemicals, slaughterhouses
Industrial production growth rate: NA%
Electricity - production: 180 million kWh (1998)
Electricity • production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
of/ter; 0% (1998)
Electricity - consumption: 363 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 196 million kWh (1998)
Agriculture - products: cowpeas, cotton, peanuts,
millet, sorghum, cassava (tapioca), rice; cattle, sheep,
goats, camels, donkeys, horses, poultry
Exports: $269 million (f.o.b., 1997)
Exports - commodities: uranium ore 65%, livestock
products, cowpeas, onions (1998 est.)
Exports - partners: US, Greece, Japan, France,
Nigeria, Benin
Imports: $295 million (c.i.f., 1997)
Imports - commodities: consumer goods, primary
materials, machinery, vehicles and parts, petroleum,
cereals
Imports - partners: France, Cote d''Ivoire, US,
Benelux, Nigeria
Debt - external: $1 .3 billion (1 999 est.)
Economic aid - recipient; $222 million (1995)
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
francs (CFAF) per US$1 - 670 (January 2000), 560.01
(January 1 999), 589.95 (1 998), 583.67 (1 997), 51 1 .55
(1996), 499.15 (1995)
note: since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
i Communications
Telephones - main lines in use: 13,000 (1995)
Telephones - mobile cellular; 0 (1995)
Telephone system: small system of wire,
radiotelephone communications, and microwave
radio relay links concentrated in southwestern area
domestic: wire, radiotelephone communications, and
microwave radio relay; domestic satellite system with
3 earth stations and 1 planned
international: satellite earth stations - 2 Intelsat (1
Atlantic Ocean and 1 Indian Ocean)
Radio broadcast stations; AM 5, FM 5, shortwave
4(1998)
Radios: 680,000(1997)
Television broadcast stations; 10 (plus seven
low-power repeaters) (1997)
Televisions: 125,000(1997)
Internet Service Providers (ISPs): 1 (1999)
Economy - overview: The oil-rich Nigerian
economy, long hobbled by political instability,
corruption, and poor macroeconomic management, is
undergoing substantial economic reform under the
new civilian administration. Nigeria''s former military
rulers failed to diversify the economy away from
overdependence on the capital-intensive oil sector,
which provides 20% of GDP, 95%offoreign exchange
earnings, and about 65% of budgetary revenues. The
largely subsistence agricultural sector has not kept up
with rapid population growth, and Nigeria, once a
large net exporter of food, now must import food. In
2000, Nigeria is likely to receive a debt-restructuring
deal with the Paris club and a $1 billion loan from the
IMF, both contingent on economic reforms. Increased
foreign investment combined with high world oil prices
should push growth to over 5% in 2000-01 .
GDP: purchasing power parity - $110.5 billion
(1999 est.)
GDP - real growth rate: 2.7% (1999 est.)
GDP - per capita: purchasing power parity - $970
(1999 est.)
GDP - composition by sector:
agriculture: 33%
industry: 42%
services: 25% (1997 est.)
Population below poverty line: 34.1%
(1992-93 est.)
Household income or consumption by percentage
share:
lowest 10%: t. 3%
highest 10%: 31 .4% (1 992-93)
Inflation rate (consumer prices): 12.5%
(1999 est.)
Labor force: 42.844 million
Labor force - by occupation: agriculture 54%,
industry 6%, sen/ices 40% (1999 est.)
Unemployment rate: 28% (1992 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
SNA
Industries: crude oil, coal, tin, coiumbite, palm oil,
peanuts, cotton, rubber, wood, hides and skins,
textiles, cement and other construction materials, food
products, footwear, chemicals, fertilizer, printing,
ceramics, steel
Industrial production growth rate: NA%
Electricity - production: 14.75 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 61 .69%
hydro: 33.31%
nuclear: 0%
other: 0% [1993)
Electricity - consumption: 13.717 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cocoa, peanuts, palm oil,
corn, rice, sorghum, millet, cassava (tapioca), yams,
rubber; cattle, sheep, goats, pigs; timber; fish
Exports: $13.1 billion (f.o.b., 1999)
Exports - commodities: petroleum and petroleum
products 95%, cocoa, rubber
Exports - partners: US 35%, Spain 1 1 %, India 9%,
France 6%, Italy (1 998 est.)
Imports: $10 billion (f.o.b., 1999)
Imports - commodities: machinery, chemicals,
transport equipment, manufactured goods, food and
live animals
Imports - partners: UK 13%, US 12%, Germany
10%, France 9%, Netherlands (1998 est.)
Debt - external: $29 billion (1999 est.)
Economic aid - recipient: $39.2 million (1995)
Currency: 1 naira (N) = 100 kobo
Exchange rates: nairas (N) per US$1 - 96.261
(October 1999), 99 (1999), 21.886 (1998), 21.886
(1997), 21.895 (1995)
Fiscal year: calendar year
366
Nigoria (continued)
I
I Communications
Teiephones - main iines in use: 405,000 (1995)
Teiephones - mobile cellular: 1 0,000 (1 999)
Telephone system: an inadequate system, further
limited by poor maintenance; major expansion is
required and a start has been made
domestic: intercity traffic is carried by coaxial cable,
microwave radio relay, a domestic communications
satellite system with 19 earth stations, and a coastal
submarine cable; mobile cellular facilities and the
Internet are available
international: satellite earth stations - 3 Intelsat (2
Atlantic Ocean and 1 1ndian Ocean); coaxial
submarine cable SAFE (South African Far East)
Radio broadcast stations: AM 82, FM 35,
shortwave 11 (1998)
Radios: 23.5 million (1997)
Television broadcast stations: 2
government-controlled; note - in addition, in 1993, 14
licenses to operate private television stations were
granted (1999)
Televisions: 6.9 million (1997)
Internet Service Providers (ISPs): 5 (1999)
I t r a n s p 0 Tt a t i 0 n
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1.067-m gauge
standard gauge: 52 km 1.435-m gauge
note: years of neglect of both the rolling stock and the
right-of-way have seriously reduced the capacity and
utility of the system; a project to restore Nigeria''s
railways is now underway
Highways;
total: 194,394 km
paved; 60,068 km (including 1,194 km of
expressways)
unpaved: 134,326 km (1998 est.)
note: many of the roads reported as paved may be
graveled; because of poor maintenance and years of
heavy freight traffic (in part the result of the failure of
the railroad system), much of the road system is
barely usable
Waterways; 8,575 km consisting of the Niger and
Benue rivers and smaller rivers and creeks
Pipelines: crude oil 2,042 km; petroleum products
3,000 km; natural gas 500 km
Ports and harbors: Calabar, Lagos, Onne, Port
Harcourt, Sapele, Warn
Merchant marine;
total: 40 ships (1 ,000 GRT or over) totaling 360,505
GRT/644,471 DWT
ships by type: bulk 1 , cargo 1 2, chemical tanker 4,
petroleum tanker 22, specialized tanker 1 (1 999 est.)
Airports: 71 (1999 est.)
Airports - with paved runways;
total: 37
over 3,047 m: 7
2,438 to 3,047 m: to
1,524 to 2,437 m: to
914 to 1,523 m: 8
under 914 m; 2 (1999 est.)
Airports - with unpaved runways:
total: 34
1,524 to 2,437 m:t
914 to 1,523 m:t 5
under 914m:t8{t 999 est.)
Heiiports: 1 (1 999 est.)
I Military
Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age; 1 8 years of age
Military manpower - availability:
males age 15-49: 29,082,802 (2000 est.)
Military manpower - fit for military service:
mates age 15-49: 16,708,344 (2000 est.)
Military manpower - reaching military age
annually:
mates; 1,360,023 (2000 est.)
Military expenditures - dollar figure: $236 million
(FY99)
Military expenditures - percent of GDP: 0.7%
(FY99)
I Trans nTFi onal Issues
Disputes • international: delimitation of
international boundaries in the vicinity of Lake Chad,
the iack of which led to border incidents in the past,
has been completed and awaits ratification by
Cameroon, Chad, Niger, and Nigeria; dispute with
Cameroon over land and maritime boundaries around
the Bakasi Peninsula is currently before the ICJ;
maritime boundary dispute with Equatorial Guinea
because of disputed jurisdiction over oii-rich areas in
the Gulf of Guinea
Illicit drugs: facilitates movement of heroin en route
from Southeast and Southwest Asia to Western
Europe and North America; increasingly a transit
route for cocaine from South America intended for
European, East Asian, and North American markets
Background; Niue''s remoteness, as well as cultural
and linguistic differences between its Polynesian
inhabitants and those of the rest of the Cook Islands,
have caused it to be separately administered. The
population of the island continues to drop (from a peak
of 5,200 in 1966 to 2,100 in 2000) with substantial
emigration to New Zealand.
l Geography
Location: Oceania, island in the South Pacific
Ocean, east of Tonga
Geographic coordinates; 19 02 S, 169 52 W
Map references; Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries; 0 km
Coastline; 64 km
Maritime claims:
exclusive economic zone: 200 nm
temfor/a/sea;12nm
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau
settlement 68 m
Natural resources; fish, arable land
Land use;
arable land: t9%
permanent crops: 8%
permanent pastures: 4%
forests and woodland: 19%
other: 50% (1993 est.)
367
NiU0 (continued)
Irrigated land: NAsqkm
Natural hazards: typhoons
Environment - current issues: increasing attention
to conservationist practices to counter ioss of soii
fertility from traditional slash and burn agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification
signed, but not ratified: Law of the Sea
Geography - note: one of world''s largest coral
islands
Economy - overview: The economy is heavily
dependent on aid and remittances from New Zealand.
Government expenditures regularly exceed revenues,
and the shortfall is made up by grants from New
Zealand which are used to pay wages to public
employees. Niue has cut government expenditures by
reducing the public service by almost half. The
agricultural sector consists mainly of subsistence
gardening, although some cash crops are grown for
export. Industry consists primarily of small factories to
process passion fruit, lime oil, honey, and coconut
cream. The sale of postage stamps to foreign
collectors is an important source of revenue. The
island in recent years has suffered a serious loss of
population because of migration of Niueans to New
Zealand. Efforts to increase GDP include the
promotion of tourism and a financial services industry.
GDP: purchasing power parity - $4.5 million
(1994 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $2,250
(1994 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
sen/ices: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1% (1995)
Labor force: 450 (1 992 est.)
Labor force - by occupation: most work on family
plantations; paid work exists only in government
service, small industry, and the Niue Development
Board
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: tourism, handicrafts, food processing
Industrial production growth rate: NA%
Electricity ■ production: 3 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 3 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: coconuts, passion fruit,
honey, limes, taro, yams, cassava (tapioca), sweet
potatoes; pigs, poultry, beef cattle
Exports: $117,500 (f.o.b., 1989)
Exports - commodities: canned coconut cream,
copra, honey, passion fruit products, pawpaws, root
crops, limes, footballs, stamps, handicrafts
Exports - partners: NZ 89%, Fiji, Cook Islands,
Economy - overview: no economic activity','f3a4101d72f379872ab4882174de9cd41c785aa62a1f9cd9f5ef160bb12c11ff','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('396b5fdafeda40d890ade5fb76bc4e3e2dbc4bfef3bcd9c444631a83f6d75f32',2000,'AR','Argentina','economy',387,'Economy - overview: Paraguay has a market
economy marked by a large informal sector. The
informal sector features both reexport of imported
consumer goods to neighboring countries as well as
the activities of thousands of microenterprises and
urban street vendors. Because of the importance of
the informal sector, accurate economic measures are
difficult to obtain. A large percentage of the population
derive their living from agricultural activity, often on a
subsistence basis. The formal economy grew by an
average of about 3% annually in 1995-97, but GDP
declined slightly in 1998 and 1999. On a per capita
basis, real income has stagnated at 1 980 levels. Most
obsen/ers attribute Paraguay''s poor economic
performance to political uncertainty, corruption, lack of
progress on structural reform, and deficient
infrastructure. Growth should recover In 2000,
perhaps to 2%.
GDP: purchasing power parity - $1 9.9 billion
(1999 est.)
GDP • real growth rate: -1% (1999 est.)
GDP - per capita: purchasing power parity - $3,650
(1999 est.)
GDP - composition by sector:
agriculture: 28%
Industry: 21%
services: 51 % (1 999 est.)
Population below poverty line: 32% (1997-98 est.)
Household income or consumption by percentage
share:
lowest 10%: 0.7%
highest 10%; 46.6% (1995)
Inflation rate (consumer prices): 5% (1999)
Labor force: 1 .7 million (1 996)
Labor force - by occupation: agriculture 45%
Unemployment rate: 12% (1998 est.)
Budget:
revenues: $1 .9 billion
expenditures: $2.1 billion, including capital
expenditures of $700 million (1995 est.)
Industries: sugar, cement, textiles, beverages,
wood products
Industrial production growth rate: -4% (1999 est.)
Electricity - production: 50.324 billion kWh (1998)
Electricity - production by source:
fossil fuel: 0.12%
hydro: 99.66%
nuclear: 0%
other; 0.22% (1998)
Electricity - consumption: 1 .494 billion kWh (1 998)
Electricity - exports: 45.307 billion kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cotton, sugarcane,
soybeans, corn, wheat, tobacco, cassava (tapioca),
fruits, vegetables; beef, pork, eggs, milk; timber
Exports: $3.1 billion (f.o.b., 1999 est.)
Exports - commodities: soybeans, feed, cotton,
meat, edible oils
Exports - partners: Brazil, Argentina, EU
Imports: $3.2 billion (f.o.b., 1999 est.)
Imports - commodities: road vehicles, consumer
goods, tobacco, petroleum products, electrical
machinery
Imports - partners: Brazil 34%, US, Argentina,
Uruguay, EU, Hong Kong (1998)
Debt - external: $2.7 billion (1 999)
Economic aid ■ recipient: $NA
Currency: 1 guarani (G) = 100 centimos
Exchange rates: guarani (G) per US$ - 3.332.0
(January 2000), 3,119.1 (1999), 2,726.5 (1998),
2,1 77.9 (1 997), 2,056.8 (1 996), 1 ,963.0 (1 995); note -
since early 1998, the exchange rate has operated as
a managed float; prior to that, the exchange rate was
determined freely in the market
Fiscal year: calendar year
Economy - overview: The Peruvian economy has
become increasingly market-oriented, with major
privatizations completed since 1990 in the mining,
electricity, and telecommunications industries.
Thanks to strong foreign investment and the
cooperation between the FUJIMORI government and
the IMF and World Bank, growth was strong in
1994-97 and inflation was brought under control. In
1998, El Nino''s impact on agriculture, the financial
crisis in Asia, and instability in Brazilian markets
undercut growth. And 1 999 was another lean year for
Peru, with the aftermath of El Nino and the Asian
financial crisis working its way through the economy.
Lima did manage to complete negotiations for an
Extended Fund Facility with the IMF in June 1999,
although it subsequently had to renegotiate the
targets. Pressure on spending is growing in the run-up
to the 2000 elections. Nevertheless, improved
commodity prices and the recovery of the fishing
sector should help drive GDP growth above the 5%
mark in 2000.
GDP: purchasing power parity - $1 1 6 billion
(1999 est.)
GDP - real growth rate: 2.4% (1999 est.)
GDP - per capita: purchasing power parity - $4,400
(1999 est.)
GDP - composition by sector;
agriculture: 13%
industry: A2%
services: 45% (1998)
Population below poverty line: 54% (1991 est.)
Household income or consumption by percentage
share:
lowest 10%: 1.9%
highest 10%; 34.3% (1994)
Inflation rate (consumer prices): 5.5% (1999 est.)
Labor force: 7.6 million (1996 est.)
Labor force - by occupation; agriculture, mining
and quarrying, manufacturing, construction, transport,
services
392
PGru (cxintinued)
Unemployment rate: 7.7%; extensive
underemployment (1997)
Budget;
revenues: $8.5 billion
expenditures: $9.3 billion, including capital
expenditures of $2 billion (1996 est.)
Industries; mining of metals, petroleum, fishing,
textiles, clothing, food processing, cement, auto
assembly, steel, shipbuilding, metal fabrication
Industrial production growth rate: 1 .2% (1 996)
Electricity - production: 18.28 billion kWh (1998)
Eiectricity - production by source:
fossil fuel: 24.53%
hydro: 74.79%
nuclear: 0%
ofher; 0.68% (1998)
Electricity - consumption: 17.002 billion kWh
(1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 2 million kWh (1998)
Agriculture - products: coffee, cotton, sugarcane,
rice, wheat, potatoes, plantains, coca; poultry, beef,
dairy products, wool; fish
Exports; $5.9 billion (f.o.b., 1999 est.)
Exports - commodities; fish and fish products,
copper, zinc, gold, crude petroleum and byproducts,
lead, coffee, sugar, cotton
Exports - partners: US 25%, China 8%, Japan 7%,
Switzerland, Germany, UK, Brazil (1997)
Imports; $8.4 billion (c.i.f., 1999 est.)
Imports - commodities; machinery, transport
equipment, foodstuffs, petroleum, iron and steel,
chemicals, pharmaceuticals
Imports - partners; US 19%, Colombia 6%,
Venezuela 5%, Chile 4%, Brazil 4% (1997)
Debt • external; $31 billion (1998 est.)
Economic aid - recipient; $895.1 million (1995)
Currency: 1 nuevo sol (S/.) = 100 centimos
Exchange rates: nuevo sol (S/.) per US$1 - 3.500
(January 2000), 3.383 (1999), 2.930 (1998), 2.664
(1997), 2.453 (1996), 2.253 (1995)
Fiscal year: calendar year
I Communications
Telephones - main lines in use; 1.509 million
(1998)
Telephones - mobile cellular; 504,995 (1 998)
Telephone system: adequate for most
requirements
domestic: nationwide microwave radio relay system
and a domestic satellite system with 12 earth stations
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean); Pan American submarine cable
Radio broadcast stations; AM 472, FM 198,
shortwave 189 (1999)
Radios; 6.65 million (1997)
Television broadcast stations: 13 (plus 112
repeaters) (1997)
Televisions: 3.06 million (1997)
Internet Service Providers (ISPs): 15 (1999)
I? transpoftaTl"on
Railways:
total: 1 ,988 km
standard gauge: 1 ,608 km 1.435-m gauge
narrow gauge: 380 km 0.91 4-m gauge
Highways:
total: 72,900 km
paved: 8,700 km
unpaved: 64,200 km (1999 est.)
Waterways; 8,600 km of navigable tributaries of
Amazon system and 208 km of Lago Titicaca
Pipelines: crude oil 800 km; natural gas and natural
gas liquids 64 km
Ports and harbors: Callao, Chimbote, llo, Matarani,
Paita, Puerto Maldonado, Salaverry, San Martin,
Talara, Iquitos, Pucallpa, Yurimaguas
note: Iquitos, Pucallpa, and Yurimaguas are all on the
upper reaches of the Amazon and its tributaries
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 65,193
GRT/1 00,584 DWT
ships by type: bulk 1 , cargo 6 (1999 est.)
Airports; 234 (1999 est.)
Airports - with paved runways:
total: 44
over 3,047 m: 7
2,438 to 3,047 m:\\7
1,524 to 2,437m: -{2
914 to 1,523 m: 7
under 914 m:1 (1999 est.)
Airports - with unpaved runways;
total: m
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 26
914 to 1,523 m: 67
under 914 m: 94 (1 999 est.)
I Military
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air,
Marines, and Coast Guard), Air Force (Fuerza Aerea
del Peru), National Police (Policia Nacional)
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 7,059,079 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 4,752,1 12 (2000 est.)
Military manpower - reaching military age
annually:
males: 268,646 (2000 est.)
Military expenditures - dollar figure: $1 .3 billion
(FY98)
Military expenditures - percent of GDP; 2%
(FY98)
I Tran s n a t i o n aTTss u e s
Disputes - international; demarcation of the
agreed-upon border with Ecuador was completed in
May 1999
Illicit drugs: until recently the world''s largest coca
leaf producer, Peru has reduced the area of coca
under cultivation by 24% to 38,700 hectares at the end
of 1 999; most of cocaine base is shipped to
neighboring Colombia, Bolivia, and Brazil for
processing into cocaine for the international drug
market, but exports of finished cocaine are increasing
by maritime conveyance to Mexico, US, and Europe
393
iPhilippines
CHINA''^
Luzon
Strait \\
<3','4f67986514cdaa6c0ecbde6ef44adb4845a1d631c275583e29cd11691f69de9b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e9ed475db7ec9fba822e8a17c866976386f52f51e940795adbdccd29f86a6de',2000,'MX','Mexico','economy',396,'Economy - overview: Portugal is an upcoming
capitaiist economy with a per capita GDP two-thirds
that of the four big West European economies. In
1999, it continued to enjoy sturdy economic growth,
falling interest rates, and low unemployment. The
country qualified for the European Monetary Union
(EMU) in 1998 and joined with 10 other European
countries in launching the euro on 1 January 1999.
Portugal''s inflation rate for 1999, 2.4%, was
comfortably low. The country continues to run a trade
deficit and a balance of payments deficit. The
government is working to modernize capital plant and
increase the country''s competitiveness in the
increasingly integrated world markets. Growth is
expected to remain stable in 2000 as the economic
integration of Europe proceeds. Improvement in the
education sector is critical to the catch-up process.
GDP: purchasing power parity - $1 51 .4 billion
(1999 est.)
GDP - real growth rate: 3.2% (1999 est.)
GDP - per capita: purchasing power parity -
$15,300 (1999 est.)
GDP - composition by sector:
agriculture: 4%
industry: 36%
services: 60% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: m%
highest f0%;NA%
Inflation rate (consumer prices): 2.4% (1999 est.)
Labor force: 4.75 million (1998 est.)
Labor force - by occupation: services 60%,
industry 30%, agriculture 10% (1999 est.)
Unemployment rate: 4.6% (1999 est.)
Budget:
revenues: $48 billion
expenditures: $52 billion, including capital
expenditures of $7.4 billion (1996 est.)
Industries: textiles and footwear; wood pulp, paper,
and cork; metalworking; oil refining; chemicals; fish
canning; wine; tourism
Industrial production growth rate: 2.9%
(1999 est.)
Electricity - production: 38.581 billion kWh (1998)
Electricity - production by source:
fossii fuei: 63AA%
hydro: 33.46%
nuciear: 0%
ofher 3.4% (1998)
Electricity - consumption: 36.18 billion kWh (1998)
Electricity - exports: 3.7 billion kWh (1998)
Electricity - imports: 4 billion kWh (1998)
Agriculture - products: grain, potatoes, olives,
grapes; sheep, cattle, goats, poultry, beef, dairy
products
Exports: $25 billion (f.o.b., 1998)
Exports - commodities: clothing and footwear,
machinery, chemicals, cork and paper products, hides
Exports - partners: EU 82% (Germany 20%, Spain
16%, France 14%, UK 12% Netherlands 5%, Benelux
5%, Italy), US 5% (1998)
Imports: $34.9 billion (f.o.b., 1998)
Imports - commodities: machinery and transport
equipment, chemicals, petroleum, textiles, agricultural
products
Imports - partners: EU 77% (Spain 24%, Germany
1 5%, France 11%, Italy 8%, UK 7%, Netherlands 5%),
US, Japan (1998)
Debt - external: $13.1 billion (1997 est.)
Economic aid - donor: ODA, $271 million (1995)
Currency: 1 Portuguese escudo (Esc) = 100
centavos
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); Portuguese escudos (Esc) per
US$1 - 172.78 (January 1999), 180.10(1998), 175.31
(1997), 154.24 (1996), 151.11 (1995)
note: on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 200.482 escudos per euro; the euro will replace the
local currency in consenting countries for all
transactions in 2002
Fiscal year: calendar year','45f98665f5da34fb983239b01e99c812c2f8f501915ecd660494cf06e698fcbd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e92a495e3da4a1bbb13bb54694fc470066dcfdb2ad254b44fac1de79c0a51b2c',2000,'UA','Ukraine','economy',408,'Economy - overview: Nine years after the collapse
of the USSR, Russia is still struggling to establish a
modern market economy and achieve strong
economic growth. Russian GDP has contracted an
estimated 45% since 1991, despite the country''s
wealth of natural resources, its well-educated
population, and its diverse - although increasingly
dilapidated - industrial base. By the end of 1997,
Russia had achieved some progress. Inflation had
been brought under control, the ruble was stabilized,
and an ambitious privatization program had
transferred thousands of enterprises to private
ownership. Some important market-oriented laws had
also been passed, including a commercial code
governing business relations and the establishment of
an arbitration court for resolving economic disputes.
But in 1998, the Asian financial crisis swept through
the country, contributing to a sharp decline in Russia''s
earnings from oil exports and resulting in an exodus of
foreign investors. Matters came to a head in August
1998 when the government allowed the ruble to fall
precipitously and stopped payment on $40 billion in
ruble bonds. In 1999, output increased for only the
second time since 1991 , by an officially estimated
3.2%, regaining much of the 4.6% drop of 1998. This
increase was achieved despite a year of potential
turmoil that included the tenure of three premiers and
culminated in the New Year''s Eve resignation of
President YELTSIN. Of great help was the tripling of
international oil prices in the second half of 1999,
raising the export surplus to $29 billion. On the
negative side, inflation rose to an average 86% in
1999, compared with a 28% average in 1998 and a
hoped-for 30% average in 2000. Ordinary persons
found their wages falling by roughly 30% and their
pensions by 45%. The PUTIN government has given
high priority to supplementing low incomes by paying
down wage and pension arrears. Many investors, both
domestic and international remain on the sidelines,
scared off by Russia''s long-standing problems with
capital flight, reliance on barter transactions,
widespread corruption among officials, and endemic
organized crime.
GDP: purchasing power parity - $620.3 billion
(1999 est.)
GDP - real growth rate: 3.2% (1999 est.)
GDP - per capita: purchasing power parity - $4,200
(1999 est.)
GDP - composition by sector:
agriculture: 8.4%
industry: 38.5%
services: 53.1% (1999 est.)
Population beiow poverty line; 40% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 1 0%: 22.2% (mS)
Infiation rate (consumer prices): 86% (1999 est.)
Labor force: 66 million (1997)
Labor force • by occupation: agriculture 15%,
industry 30%, sen/ices 55% (1999 est.)
Unemployment rate: 12.4% (1999 est.), plus
considerable underemployment
Budget:
revenues; $24.08 billion
expenditures: $26.82 billion, including capital
expenditures of $NA (1999 est.)
Industries: complete range of mining and extractive
industries producing coal, oil, gas, chemicals, and
metals; all forms of machine building from rolling mills
to high-performance aircraft and space vehicles;
shipbuilding; road and rail transportation equipment;
communications equipment; agricultural machinery,
tractors, and construction equipment; electric power
generating and transmitting equipment; medical and
scientific instruments; consumer durables, textiles,
foodstuffs, handicrafts
Industrial production growth rate; 8.1%
(1999 est.)
Electricity - production: 771 .947 billion kWh (1 998)
Electricity - production by source:
fossil fuel: ei. 77%
hydro; 19.49%
nuclear: 12.74%
other; 0% (1998)
Electricity - consumption: 702.711 billion kWh
(1998)
Electricity - exports: 21 billion kWh (1998)
Electricity - imports: 5.8 billion kWh (1 998)
Agriculture - products: grain, sugar beets,
sunflower seed, vegetables, fruits; beef, milk
Exports: $75.4 billion (1999 est.)
Exports - commodities: petroleum and petroleum
products, natural gas, wood and wood products,
metals, chemicals, and a wide variety of civilian and
military manufactures
Exports - partners: Ukraine, Germany, US,
Belarus, Netherlands, China
Imports: $48.2 billion (1999 est.)
Imports - commodities: machinery and equipment,
consumer goods, medicines, meat, grain, sugar,
semifinished metal products
Imports - partners: Germany, Belarus, Ukraine, US,
Kazakhstan, Italy
Debt - external: $166 billion (yearend 1999)
Economic aid ■ recipient: $8,523 billion (1995)
Currency: 1 ruble (R) = 100 kopeks
Exchange rates: rubles per US$1 - 26.7996
(December 1999), 24.6199 (1999), 9.7051 (1998),
5,785 (1997), 5,121 (1996), 4,559 (1995)
note: the post-1 January 1 998 ruble is equal to 1 ,000
of the pre-1 January 1998 rubles
Fiscal year: calendar year','275ae54a250a189fe9a061291d550ab3251fde60fe827a1dadf8c4317d62ca5e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d8036e88607da1579863f6d0e54457a7fc44fb8ab83f92f18bf6b9f2b8b2509',2000,'TT','Trinidad and Tobago','economy',411,'Economy - overview: The economy has
traditionally depended on the growing and processing
of sugarcane; decreasing world prices have hurt the
industry in recent years. Tourism, export-oriented
manufacturing, and offshore banking activity have
assumed larger roles. Most food is imported. The
government has undertaken a program designed to
revitalize the faltering sugar sector. It is also working
to improve revenue collection in order to better fund
social programs. In 1997 some leaders in Nevis were
urging separation from Saint Kitts on the basis that
Nevis was paying far more in taxes than it was
receiving in government services, but the vote on
cessation failed in August 1998. In late September
1 998, Hurricane Georges caused approximately $445
million in damages and limited GDP growth for the
year.
GDP: purchasing power parity - $244 million
(1998 est.)
GDP ■ real growth rate: 1 .6% (1 998 est.)
GDP • per capita: purchasing power parity - $6,000
(1998 est.)
GDP - composition by sector:
agriculture: 5.5%
industry: 22.5%
services: 72% (1996)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1% (1998 est.)
Labor force: 1 8, 1 72 (June 1 995)
Labor force - by occupation: NA
Unemployment rate: 4.5% (1997)
Budget:
reverrues;$64.1 million
expenditures: $78.8 million, including capital
expenditures of $10.4 million (1997 est.)
Industries: sugar processing, tourism, cotton, salt,
copra, clothing, footwear, beverages
Industrial production growth rate: NA%
Electricity - production: 85 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% [1998)
Electricity - consumption: 79 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
420
Saint Kitts and Nevis (continued)
I Military
Military branches; Royal Saint Kitts and Nevis
Police Force, Coast Guard, Royal Saint Kitts and
Nevis Defense Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
I Transnational Issues
Disputes - international: none
Illicit drugs: transshipmentpointforSouth American
drugs destined for the US and Europe
ISaint Lucia
Sain! Lucia Channel
0 4 8km
6 4 8 mi
) %
North
j, Atlantic
Ocean
Caribbean .^CASTRIES
\\
Sea [
\\
y Anse La Raye
pennery *
^Soufrifere
^icoud
N^ChoiseuI
Vieux Fort^
Saint Vincent Passage
1^ ’ ~ I n t r 0 d u c f 1 o n
Agriculture - products; sugarcane, rice, yams,
vegetables, bananas; fish
Exports: $42 million (1998)
Exports - commodities: machinery, food,
electronics, beverages, tobacco
Exports - partners: US 68.5%, UK 22.3%, Caricom
countries 5.5% (1995 est.)
Imports: $160 million (1998)
Imports - commodities: machinery, manufactures,
food, fuels
Imports - partners: US 42.4%, Caricom countries
17.2%, UK 11.3% (1995 est.)
Debt - external; $62 million (1 997)
Economic aid - recipient; $5.5 million (1995)
Currency; 1 East Caribbean dollar (EC$) = 100
cents
Exchange rates: East Caribbean dollars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year: calendar year
I ’ Communications
Telephones - main lines in use: 14,000 (1995)
Telephones - mobile cellular: 0 (1995)
Telephone system: good interisland VHF/UHF/SHF
radiotelephone connections and international link via
Antigua and Barbuda and Saint Martin (Guadeloupe
and Netherlands Antilles)
domestic: interisland links are handled by VHF/UHF/
SHF radiotelephone
international: international calls are carried by
radiotelephone to Antigua and Barbuda and from
there switched to submarine cable or to Intelsat, or
carried to Saint Martin (Guadeloupe and Netherlands
Antilles) by radiotelephone and switched to Intelsat
Radio broadcast stations; AM 3, FM 1 , shortwave
0(1998)
Radios: 28,000(1997)
Television broadcast stations: 1 (plus three
repeaters) (1997)
Televisions: 10,000(1997)
Internet Service Providers (ISPs): NA
I Transportation
Railways;
total: 58 km
narrow gauge: 58 km 0.762-m gauge on Saint Kitts to
serve sugarcane plantations (1995)
Highways;
total: 320 km
paved: 136 km
unpaved: 1 84 km (1996 est.)
Ports and harbors: Basseterre, Charlestown
Merchant marine: none (1999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:-\\
914 to 1,523 m:1 (1999 est.)
Background: The island, with its fine natural harbor
at Castries, was contested between England and
France throughout the 17th and early 18th centuries
(changing possession 1 4 times); it was finally ceded to
the UK in 1 81 4. Self government was granted in 1 967
and independence in 1979.
Location; Caribbean, island between the Caribbean
Sea and North Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates; 13 53 N, 60 68 W
Map references; Central America and the
Caribbean
Area;
total: 620 sq km
/ar?cf;610sq km
water: 10 sq km
Area - comparative; 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline; 158 km
Maritime claims: 200 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
femfona/ sea; 12 nm
Climate; tropical, moderated by northeast trade
winds; dry season from January to April, rainy season
from May to August
Terrain; volcanic and mountainous with some broad,
fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources; forests, sandy beaches,
minerals (pumice), mineral springs, geothermal
potential
Land use:
arable land: 8%
421
Saint Lucia (continued)
permanent crops: 21 %
permanent pastures: 5%
forests and woodland: 13%
other: 53% (1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: hurricanes and volcanic activity
Environment - current issues: deforestation; soii
erosion, particularly in the northern region
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
r People
Population: 1 56,260 (July 2000 est.)
Age structure:
0-14 years: 33% (male 26,087; female 25,159)
15-64 years: 62% (male 47,420; female 49,290)
65 years and over: 5% (male 3,113; female 5,191)
(2000 est.)
Population grovirth rate: 1 .21 % (2000 est.)
Birth rate: 22.1 9 births/1 ,000 population (2000 est.)
Death rate: 5.43 deaths/1 ,000 population
(2000 est.)
Net migration rate: -4.67 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/temale
65 years and over: 0.6 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 15.64 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 72.31 years
male: 68.74 years
female: 76.14 years (2000 est.)
Total fertility rate: 2.42 children born/woman
(2000 est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East Indian
3%, white 1%
Religions: Roman Catholic 90%, Protestant 7%,
Anglican 3%
Languages: English (official), French patois
Literacy:
definition: age 1 5 and over has ever attended school
total population: 57%
male: 65%
female: 59% {1980 est.)
Economy - overview: The recent changes in the EU
import preference regime and the increased
competition from Latin American bananas have made
economic diversification increasingly important in
Saint Lucia. Improvement in the construction sector
and growth of the tourism industry helped expand
GDP in 1998-99. The agriculture sector registered its
fifth year of decline in 1997 primarily because of a
severe decline in banana production. The
manufacturing sector is the most diverse in the
Eastern Caribbean, and the government is beginning
to develop regulations for the small offshore financial
sector.
GDP: purchasing power parity - $656 million
(1998 est.)
GDP • real growth rate: 2.9% (1998 est.)
GDP • per capita: purchasing power parity - $4,300
(1998 est.)
GDP '' composition by sector:
agriculture: 10.7%
industry: 32.3%
services: 57% (1 996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.7% (1998 est.)
Labor force: 43,800
Labor force - by occupation: agriculture 43.4%,
services 38.9%, industry and commerce 17.7%
(1983 est.)
Unemployment rate: 1 5% (1 996 est.)
Budget:
revenues; $141 .2 million
expenditures: $146.7 million, including capital
expenditures of $25.1 million (FY97/98 est.)
Industries: clothing, assembly of electronic
components, beverages, corrugated cardboard
boxes, tourism, lime processing, coconut processing
Industrial production growth rate: -8.9%
(1997 est.)
Electricity - production: 1 1 0 million kWh (1 998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% {1998)
Electricity - consumption: 102 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
422
Saint Lucia (continued)
Agriculture - products: bananas, coconuts,
vegetables, citrus, root crops, cocoa
Exports: $75 million (1998)
Exports - commodities: bananas 41%, clothing,
cocoa, vegetables, fruits, coconut oil
Exports - partners: UK 50%, US 24%, Caricom
countries 16% (1995)
Imports: $290 million (1998)
Imports - commodities: food 23%, manufactured
goods 21 %, machinery and transportation equipment
19%, chemicals, fuels
Imports - partners: US 36%, Caricom countries
22%, UK 11%, Japan 5%, Canada 4% (1995)
Debt - external: $135 million (1998)
Economic aid - recipient: $51.8 million (1995)
Currency: 1 East Caribbean dollar (EC$) = 100
cents
Exchange rates: East Caribbean dollars (EC$) per
US$1 - 2.7000 (fixed rate since 1976)
Fiscal year: 1 April - 31 March
I Communications ~
Telephones - main lines in use: 31,000 (1995)
Telephones - mobile cellular: 1 ,000 (1995)
Telephone system:
domestic: system is automatically switched
international: direct microwave radio relay link with
Martinique and Saint Vincent and the Grenadines;
tropospheric scatter to Barbados; international calls
beyond these countries are carried by Intelsat from','500548af432a3fc4e5fe70fc1a777d3ffb7ffbcba05e24117cc671f412283412','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b8e17a405caf2234e6590aa4465fd35744fda9ed05f9b6f7708fdf2046c7253',2000,'MQ','Martinique','economy',412,'Radio broadcast stations: AM 2, FM 7 (plus 3
repeaters), shortwave 0 (1998)
Radios: 111,000(1997)
Television broadcast stations: 3 (of which two are
commercial stations and one is a community antenna
television or CATV channel) (1997)
Televisions: 32,000(1997)
Internet Service Providers (ISPs): NA
I fransportatioiT
Railways: 0 km
Highways:
fofa/;1,210km
paved: 63 km
unpaved; 1,147 km (1996 est.)
Ports and harbors: Castries, Vieux Fort
Merchant marine: none (1999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:t
1,524 to 2,437 m:t {mo est.)
I Military
Military branches: Royal Saint Lucia Police Force
(includes Special Service Unit), Coast Guard
Military expenditures - dollar figure: $5 million
(FY91/92)
Military expenditures - percent of GDP: 2%
(FY91/92)
I t r a n s n a t i o n a I I s s u e s
Disputes - international: none
Illicit drugs: transit point for South American drugs
destined for the US and Europe
Saint Pierre
land Miqueion
•(territorial collectivity
• OfFmnce)
0 5 10 km
0 5 10 mi
MiquelontfV^
1 Miquelon
Gulf of
-o y (Grande
St. Lawrence \\
^ Miquelon)
Langlade
he Saint-Pierre
(Petite Miquelon) ( /
/^AINT-PIERRE
North Atlantic Ocean
I " ''l n tTl) fu m
Background: First settied by the French in the early
1 7th century, the islands represent the sole remaining
vestige of France’s once vast North American
possessions.
If’ ~ "G e 0 g r a p TTy . .
Location: Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland
(Canada)
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area:
total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the Saint Pierre
and the Miquelon groups
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 nm
fem''toria/ sea; 1 2 nm
Climate: cold and wet, with much mist and fog;
spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 4%
other: 83% {1993 est.)
423
Saint Pierre and Miqueion (continued)
Irrigated land: NAsqkm
Natural hazards: persistent fog throughout the year
can be a maritime hazard
Environment - current issues: NA
Geography - note: vegetation scanty
Economy - overview: The inhabitants have
traditionally earned their livelihood by fishing and by
servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining,
however, because of disputes with Canada over
fishing quotas and a steady decline in the number of
ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic
zone of 12,348 sq km to settle a longstanding
territorial dispute with Canada, although it represents
only 25% of what France had sought. The islands are
heavily subsidized by France to the great betterment
of living standards. The government hopes an
expansion of tourism will boost economic prospects.
GDP: purchasing power parity - $74 million
(1996 est.); supplemented by annual payments from
France of about $65 million
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$11,000(1996 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
inflation rate (consumer prices): 2.1% (1991-96
average)
Labor force: 3,000(1997)
Labor force - by occupation: fishing 18%, industry
(mainly fish-processing) 41%, services 41%
(1996 est.)
Unemployment rate: 9.8% (1997)
Budget:
revenues: $70 million
expenditures: $69 million, including capital
expenditures of $24 million (1996 est.)
Industries: fish processing and supply base for
fishing fleets; tourism
Industrial production growth rate: NA%
Electricity - production: 40 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% {1998)
Electricity - consumption: 37 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: vegetables; poultry, cattle,
sheep, pigs; fish
Exports: $5 million (f.o.b., 1997)
Exports - commodities: fish and fish products,
mollusks and crustaceans, fox and mink pelts
Exports - partners: US, France, UK, Canada,','eeea5f608cdcbfff7c652aefe449dda5d18dcf259c6f300dd8f3c6b54cee8dd0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57e2590890d24293d38f3599c26dffdae930b1ed3dfa10ba8d08f6f8e47f391d',2000,'VC','Saint Vincent and the Grenadines','economy',416,'Economy - overview: The economy of Samoa has
traditionally been dependent on development aid,
private family remittances from overseas, and
agricultural exports. The country is vulnerable to
devastating storms. Agriculture employs two-thirds of
the labor force, and furnishes 90% of exports,
featuring coconut cream, coconut oil, and copra.
Outside of a large automotive wire harness factory,
the manufacturing sector mainly processes
agricultural products. Tourism is an expanding sector;
more than 70,000 tourists visited the islands in 1996.
The Samoan Government has called for deregulation
of the financial sector, encouragement of investment,
and continued fiscal discipline. Observers point to the
flexibility of the labor market as a basic strength for
future economic advances.
GDP: purchasing power parity - $485 million
(1998 est.)
GDP - real growth rate: 1 .8% (1 998 est.)
GDP - per capita; purchasing power parity - $2,100
(1998 est.)
GDP - composition by sector:
agriculture: 40%
industry: 25%
services: 35% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.2% (1998 est.)
Labor force: 82,500(1991 est.)
Labor force - by occupation: agriculture 65%,
services 30%, industry 5% (1995 est.)
Unemployment rate: NA%
Budget:
revenues: $52 million
expenditures: $99 million, including capital
expenditures of $37 million (FY96/97 est.)
Industries: timber, tourism, food processing, fishing
Industrial production growth rate; 14%
(1996 est.)
Electricity - production: 65 million kWh (1998)
Electricity - production by source:
fossil fuel: 61 .54%
hydro; 38.46%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 60 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: coconuts, bananas, taro,
yams
Exports: $20.3 million (f.o.b., 1998)
Exports ■ commodities: coconut oil and cream,
copra, fish, beer
Exports - partners: American Samoa, Australia,
New Zealand, US, Germany
Imports: $96.6 million (f.o.b., 1998)
Imports - commodities: machinery and equipment,
foodstuffs
Imports - partners: Australia, New Zealand, Japan,
Fiji, US
Debt - external: $156 million (1997 est.)
Economic aid - recipient: $42.9 million (1995)
Currency: 1 tala (WS$) = 100 sene
Exchange rates: tala (WS$) per US$1 - 3.0460
(January 2000), 3.01 20 (1 999), 2.9429 (1 998), 2.5562
(1997), 2.4618 (1996), 2.4722 (1995)
Fiscal year: calendar year','a25666b7ae4ffbe385b0db4185ae1b0e03b33e8fadc281f480525c70552ac1c8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e584fbe93d3d48f61d03d32a291a654cf7af59b5c8377f80aa7b75f489ee8a93',2000,'IT','Italy','economy',419,'Economy - overview: The tourist sector contributes
over 50% of GDP. In 1997 more than 3.3 million
tourists visited San Marino. The key industries are
banking, wearing apparel, electronics, and ceramics.
Main agricultural products are wine and cheeses. The
per capita level of output and standard of living are
comparable to those of Italy, which supplies much of
its food.
GDP: purchasing power parity - $500 million
(1997 est.)
GDP ■ real growth rate: NA%
GDP - per capita: purchasing power parity -
$20,000 (1997 est.)
GDP - composition by sector:
agriculture: NA%
Industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2% (1997)
Labor force: 15,600(1995)
Labor force - by occupation: services 60%,
industry 38%, agriculture 2% (1998 est.)
Unemployment rate: 3.6% (April 1996)
Budget:
revenues: $320 million
expenditures: $320 million, including capital
expenditures of $26 million (1995 est.)
Industries: tourism, banking, textiles, electronics,
ceramics, cement, wine
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
note: electricity supplied by Italy
Agriculture - products: wheat, grapes, corn, olives;
cattle, pigs, horses, beef, cheese, hides
Exports: trade data are included with the statistics
for Italy
Exports - commodities: building stone, lime, wood,
chestnuts, wheat, wine, baked goods, hides, ceramics
Imports: trade data are included with the statistics
for Italy
Imports - commodities: wide variety of consumer
manufactures, food
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 Italian lira (Lit) = 100 centesimi; note -
also mints its own coins
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); Italian lire (Lit) per US$1 -
1,668.7 (January 1998), 1,736.2 (1998), 1,703.1
(1997), 1,542.9 (1996), 1,628.9 (1995)
Fiscal year: calendar year
Economy - overview: Syria''s predominantly statist
economy is on a shaky footing because of
Damascus''s failure to implement extensive economic
reform. The dominant agricultural sector remains
underdeveloped, with roughly 80% of agricultural land
still dependent on rain-fed sources. Although Syria
has sufficient water supplies in the aggregate at
normal levels of precipitation, the great distance
between major water supplies and population centers
poses serious distribution problems. The water
problem is exacerbated by rapid population growth,
industrial expansion, and increased water pollution.
Private investment is critical to the modernization of
the agricultural, energy, and export sectors. Oil
production is leveling off, and the efforts of the nonoil
sector to penetrate international markets have fallen
short. Syria''s inadequate infrastructure, outmoded
technological base, and weak educational system
make it vulnerable to future shocks and hamper
competition with neighbors such as Jordan and Israel.
GDP: purchasing power parity - $42.2 billion
(1999 est.)
GDP - real growth rate: 0% (1 999 est.)
GDP - per capita: purchasing power parity - $2,500
(1999 est.)
GDP - composition by sector:
agriculture: 29%
industry: 22%
sem''ces; 49% (1997)
Population beiow poverty iine: 15%-25%
Household income or consumption by percentage
share:
towesf 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.3% (1999 est.)
Labor force: 4.7 million (1998 est.)
Labor force - by occupation: agriculture 40%,
industry 20%, services 40% (1996 est.)
Unemployment rate: 1 2%-1 5% (1 998 est.)
Budget:
revenues: $3.5 billion
expenditures: $4.2 billion, including capital
expenditures of $NA (1997 est.)
Industries: petroleum, textiles, food processing,
beverages, tobacco, phosphate rock mining
Industrial production growth rate: 0.2%
(1996 est.)
Electricity - production: 17.5 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 42.86%
hydro; 57.14%
nuclear: 0%
often 0% (1998)
Electricity - consumption: 16.275 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: wheat, barley, cotton,
lentils, chickpeas, olives, sugar beets; beef, mutton,
eggs, poultry, milk
Exports: $3.3 billion (f.o.b., 1999 est.)
Exports - commodities: petroleum 65%, textiles
1 0%, manufactured goods 1 0%, fruits and vegetables
7%, raw cotton 5%, live sheep 2%, phosphates 1%
(1998 est.)
Exports - partners: Germany 14%, Turkey 13%,
Italy 1 2%, France 9%, Lebanon 9%, Spain (1 998 est.)
Imports: $3.2 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment
23%, foodstuffs/animals 20%, metal and metal
products 15%, textiles 10%, chemicals 10%
(1998 est.)
Imports - partners: Ukraine 16%, Italy 6%,
Germany 6%, Turkey 5%, France 4%, South Korea,
Japan, US (1998 est.)
Debt - external: $22 billion (1 999 est.)
Economic aid - recipient: $199 million (1997 est.)
Currency: 1 Syrian pound = 100 piastres
Exchange rates: Syrian pounds per US$1 - 46
(1998), 41.9 (January 1997); official fixed rate -
1 1 .225 Syrian pounds per US$1
Fiscal year: calendar year','b8cf8a043a00b0f81a8736101f1ce4f8f6ddc1f19619bdc5bcef6dfd2654491a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08f78fda6fcc6f1262db2cfa544e8665cedf0316f698affb8771fbba135e33f4',2000,'ZA','South Africa','economy',432,'Economy - overview; South Africa is a
middle-income, developing country with an abundant
supply of resources, well-developed financial, legal,
communications, energy, and transport sectors, a
stock exchange that ranks among the 1 0 largest in the
world, and a modern infrastructure supporting an
efficient distribution of goods to major urban centers
throughout the region. However, growth has not been
strong enough to cut into the 30% unemployment, and
daunting economic problems remain from the
apartheid era, especially the problems of poverty and
lack of economic empowerment among the
disadvantaged groups. Other problems are crime,
corruption, and HIV/AIDS. At the start of 2000,
President MBEKI vowed to promote economic growth
and foreign investment by relaxing restrictive labor
laws, stepping up the pace of privatization, and cutting
unneeded governmental spending. His policies face
strong opposition from organized labor.
GDP: purchasing power parity -$296.1 billion
(1999 est.)
GDP - real growth rate: 0.6% (1999 est.)
GDP - per capita: purchasing power parity - $6,900
(1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 35%
services: 60% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%; 1.4%
highest 10%; 47.3% (1993)
Inflation rate (consumer prices): 5.5% (1 999 est.)
Labor force: 1 5 million economically active (1 997)
Labor force - by occupation: agriculture 30%,
industry 25%, services 45% (1999 est.)
Unemployment rate: 30% (1999 est.)
Budget:
revenues: $30.5 billion
expenditures: $38 billion, including capital
expenditures of $2.6 billion (FY94/95 est.)
Industries: mining (world''s largest producer of
platinum, gold, chromium), automobile assembly,
metalworking, machinery, textile, iron and steel,
chemicals, fertilizer, foodstuffs
Industrial production growth rate: -5% (1998 est.)
Electricity • production: 1 92.01 5 billion kWh (1 998)
Electricity - production by source;
fossil fuel: 92.09%
hydro: 0.83%
nuclear: 7.08%
other: 0%{m8)
Electricity - consumption: 174.486 billion kWh
(1998)
Electricity - exports: 4.093 billion kWh (1998)
Electricity - imports: 5 million kWh (1998)
Agriculture - products: corn, wheat, sugarcane,
fruits, vegetables; beef, poultry, mutton, wool, dairy
products
Exports: $28 billion (f.o.b., 1999 est.)
Exports - commodities: gold, diamonds, other
metals and minerals, machinery and equipment
Exports - partners: UK, Italy, Japan, US, Germany
(1997)
Imports: $26 billion (f.o.b., 1999 est.)
Imports - commodities: machinery, foodstuffs and
equipment, chemicals, petroleum products, scientific
instruments
Imports - partners: Germany, US, UK, Japan
Debt - external: $25.7 billion (1 998 est.)
Economic aid - recipient: $676.3 million
Currency: 1 rand (R) = 100 cents
Exchange rates: rand (R) per US$1 - 6.12439
(January 2000), 6.10948 (1999), 5.52828 (1998),
4.60796 (1997), 4.29935 (1996), 3.62709 (1995)
Fiscal year: 1 April - 31 March','1f5f6f693e49a962435ad54a74a31e95c7e87865f65e8e49ebf2ab5bb221501a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f684e4660e601d0855cf0fb44c4c83b9032a92e6a9ceebe4eb7885099e48295',2000,'PH','Philippines','economy',436,'Economy - overview: Economic activity is limited to
commercial fishing. The proximity to nearby oil- and
gas-producing sedimentary basins suggests the
potential for oil and gas deposits, but the region is
largely unexplored, and there are no reliable
estimates of potential reserves; commercial
exploitation has yet to be developed.
Economy • overview: In 1977, Colombo
abandoned statist economic policies and its import
substitution trade policy for market-oriented policies
and export-oriented trade. Sri Lanka''s most dynamic
industries now are food processing, textiles and
apparel, food and beverages, telecommunications,
and insurance and banking. By 1996 plantation crops
made up only 20% of exports (compared with 93% in
1970), while textiles and garments accounted for
63%. GDP grew at an annual average rate of 5.5%
throughout the 1990s until a drought and a
deteriorating security situation lowered growth to
3.8% in 1996. The economy rebounded in 1997-98
with growth of 6.4% and 4.7% - but slowed to 3.7% in
1 999. For the next round of reforms, the central bank
of Sri Lanka recommends that Colombo expand
market mechanisms in nonplantation agriculture,
dismantle the government''s monopoly on wheat
imports, and promote more competition in the
financial sector. A continuing cloud over the economy
is the fighting between the Sinhalese and the minority
Tamils, which has cost 50,000 lives in the past 15
years.
GDP: purchasing power parity - $50.5 billion
(1999 est.)
GDP - real growth rate: 3.7% (1999 est.)
GDP - per capita: purchasing power parity - $2,600
(1999 est.)
GDP - composition by sector:
agriculture: 21%
industry: 19%
services: 60% (1998)
Population below poverty line: 22% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%: t. 8%
highest 10%: 39.7% (1995-96 est.)
Inflation rate (consumer prices): 6% (1999 est.)
Labor force: 6.6 million (1998)
Labor force - by occupation: services 45%,
agriculture 38%, industry 17% (1998 est.)
Unemployment rate: 9.5% (1998 est.)
Budget:
revenues: $2.7 billion
expenditures: $4.2 billion, including capital
expenditures of $1.1 billion (1998 est.)
Industries: processing of rubber, tea, coconuts, and
other agricultural commodities; clothing, cement,
petroleum refining, textiles, tobacco
Industrial production growth rate: 6.3% (1998)
Electricity - production: 5.505 billion kWh (1998)
Electricity - production by source:
fossil fuel: 30.97%
hydro: 69.08%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 5.12 billion kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: rice, sugarcane, grains,
pulses, oilseed, spices, tea, rubber, coconuts; milk,
eggs, hides, beef
Exports: $4.7 billion (f.o.b., 1998)
Exports • commodities: textiles and apparel, tea,
diamonds, coconut products, petroleum products
(1998)
Exports - partners: US 40%, UK 11%, Middle East
9%, Germany 5%, Japan 4% (1998)
Imports: $5.3 billion (f.o.b., 1998)
Imports - commodities: machinery and equipment,
textiles, petroleum, foodstuffs (1998)
Imports - partners: India 10%, Japan 10%, South
Korea 8%, Hong Kong 7%, Taiwan 6% (1998)
Debt - external: $8.4 billion (1998)
Economic aid - recipient: $577 million (1998)
Currency: 1 Sri Lankan rupee (SLRe) = 100 cents
Exchange rates: Sri Lankan rupees (SLRe) per
US$1 - 72.364 (January 2000), 70.402 (1 999), 64.593
(1998), 58.995 (1997), 55.271 (1996), 51.252 (1995)
Fiscal year: calendar year
Economy - overview: Sudan is buffeted by civil war,
chronic political instability, adverse weather, weak
world commodity prices, a drop in remittances from
abroad, and counterproductive economic policies.
The private sector''s main areas of activity are
agriculture and trading, with most private industrial
investment predating 1980. Agriculture employs 80%
of the work force. Industry mainly processes
agricultural items. Sluggish economic performance
over the past decade, attributable largely to declining
annual rainfall, has kept per capita income at low
levels. A large foreign debt and huge arrears continue
to cause difficulties. In 1990 the International
Monetary Fund (IMF) took the unusual step of
declaring Sudan noncooperative because of its
nonpayment of arrears to the Fund. After Sudan
backtracked on promised reforms in 1992-93, the IMF
threatened to expel Sudan from the Fund. To avoid
expulsion, Khartoum agreed to make token payments
468
Sudan (continued)
on its arrears to the Fund, liberalize exchange rates,
and reduce subsidies, measures it has partially
implemented. The government''s continued
prosecution of the civil war and its growing
international isolation continued to inhibit growth in the
nonagricultural sectors of the economy during 1 999.
The government has worked with foreign partners to
develop the oil sector, and the country is producing
approximately 150,000 barrels per day.
GDP: purchasing power parity - $32.6 billion
(1999 est.)
GDP - real growth rate: 3% (1999 est.)
GDP - per capita: purchasing power parity - $940
(1999 est.)
GDP - composition by sector:
agriculture: 4t%
industry: 17%
serv/ces; 42% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 20% (1999 est.)
Labor force: 11 million (1996 est.)
note: labor shortages for almost all categories of
skilled employment (1983 est.)
Labor force • by occupation: agriculture 80%,
industry and commerce 10%, government 6%,
unemployed 4%
Unemployment rate: 30% (FY92/93 est.)
Budget:
revenues: $1 .2 billion
expenditures: $1 .3 billion, including capital
expenditures of $NA (2000 est.)
Industries: cotton ginning, textiles, cement, edible
oils, sugar, soap distilling, shoes, petroleum refining
Industrial production growth rate: 5% (1996 est.)
Electricity - production: 1 .81 5 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 44.9%
hydro; 55.1%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 1 .688 billion kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cotton, groundnuts
(peanuts), sorghum, millet, wheat, gum arable,
sesame; sheep
Exports: $580 million (f.o.b., 1999 est.)
Exports - commodities: cotton, sesame, livestock,
groundnuts, oil, gum arable
Exports - partners: Saudi Arabia 24%, Italy 10%,
Germany 5%, Egypt 5%, France 3%, Japan 3%,
Dhina 1% (1998)
mports: $1.4 billion (c.i.f., 1999 est.)
mports - commodities: foodstuffs, petroleum
)roducts, manufactured goods, machinery and
ransport equipment, medicines and chemicals,
extiles
imports - partners: China 27%, France 14%, UK
10%, Germany 7%, Japan 4%, Netherlands 3%,
Canada 1% (1998)
Debt - external: $24 billion (1999 est.)
Economic aid - recipient: $187 million (1997)
Currency: 1 Sudanese dinar (SD) = 100 piastres;
note - in July 1 999 the Sudanese Central Bank made
the formal declaration that all dealings with the
Sudanese pound should stop
Exchange rates: Sudanese dinars (SD) per US$1 -
230.2 (1999), 172.2 (1998), 148.8 (1997), 118.2
(1996); (old currency) Sudanese pounds per US$1 -
2,526.34 (2d Qtr 1999), 2,008.02 (1998), 1,575.74
(1997), 1,250.79 (1996), 580.87 (1995)
Fiscal year: calendar year
1“ ■ c olirm u n i c a Fi 0 n s
Telephones - main lines in use: 75,000 (1995)
Telephones ■ mobile cellular: 3,000 (1 998)
Telephone system: large, well-equipped system by
regional standards, but barely adequate and poorly
maintained by modern standards; cellular
communications started in 1996
domestic: consists of microwave radio reiay, cable,
radiotelephone communications, tropospheric scatter,
and a domestic satellite system with 14 earth stations
international: satellite earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 Arabsat
Radio broadcast stations: AM 12, FM 1 , shortwave
1 (1998)
Radios: 7.55 million (1997)
Television broadcast stations: 3 (1997)
Televisions: 2.38 million (1997)
Internet Service Providers (ISPs): 1 (1999)
I Transportation
Railways:
total: 5,31 1 km
narrow gauge: 4,595 km 1.067-m gauge; 716 km
1.6096-m gauge plantation line
rjofe.''the main line linking Khartoum to Port Sudan
carries over two-thirds of Sudan''s rail traffic
Highways:
total: 1 1 ,900 km
paved; 4,320 km
unpaved: 7,580 km (1 996 est.)
Waterways: 5,310 km navigable
Pipelines: refined products 815 km
Ports and harbors: Juba, Khartoum, Kusti, Malakal,
Nimule, Port Sudan, Sawakin
Merchant marine:
total: 4 ships (1 ,000 GRT or over) totaling 38,093
GRT/49,727 DWT
ships by type: cargo 2, roll-on/roll-off 2 (1999 est.)
Airports: 61 (1999 est.)
Airports - with paved runways:
fofa/;12
over 3,047 m:1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3 (1999 esl)
Airports - with unpaved runways:
total: 49
1,524 to 2,437 m: 15
914 to 1,523 m: 24
under 914 m: 1 0 (1 999 est.)
Heliports: 1 (1999 est.)
|i ~ iTi rrF a ty
Military branches: Army, Navy, Air Force, Popular
Defense Force Militia
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 8,144,048 (2000 est.)
Military manpower - fit for military service:
mates age 15-49: 5,014,429 (2000 est.)
Military manpower - reaching military age
annually:
mates; 386,168 (2000 est.)
Military expenditures - dollar figure: $550 million
(FY98)
Military expenditures - percent of GDP: NA%
I T r a n s n a t i o n a tissues
Disputes - international: administrative boundary
with Kenya does not coincide with international
boundary; Egypt asserts its ciaim to the "Hala''ib
Triangie," a barren area of 20,580 sq km under partial
Sudanese administration that is defined by an
administrative boundary which supersedes the treaty
boundary of 1899
469','54693c8f9e6874de7987fbbd2f555a74b0adc54d2f697a75432d8e4a8b321679','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f6e24555c9514b166d495575588cc8bda23538e4183c12ad17c75530db7cb9',2000,'ZW','Zimbabwe','economy',455,'Economy - overview: Tajikistan has the lowest per
capita GDP among the 15 former Soviet republics.
Cotton is the most important crop. Mineral resources,
varied but limited in amount, include silver, gold.
uranium, and tungsten. Industry consists only of a
large aluminum plant, hydropower facilities, and small
obsolete factories mostly in light industry and food
processing. The Tajikistan! economy has been
gravely weakened by six years of civil conflict and by
the loss of subsidies from Moscow and of markets for
its products. Tajikistan thus depends on aid from
Russia and Uzbekistan and on international
humanitarian assistance for much of its basic
subsistence needs. Even if the peace agreement of
June 1997 is honored, the country faces major
problems in integrating refugees and former
combatants into the economy. The future of
Tajikistan''s economy and the potential for attracting
foreign investment depend upon stability and
continued progress in the peace process.
GDP: purchasing power parity - $6.2 billion
(1999 est.)
GDP - real growth rate: 2% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,020
(1999 est.)
GDP - composition by sector:
agriculture: 34%
industry: 24%
services: A2% (1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 22% (1999 est.)
Labor force: 1 .9 million (1 996)
Labor force - by occupation: agriculture and
forestry 50%, industry 20%, services 30% (1997 est.)
Unemployment rate: 5.7% includes only officially
registered unemployed; also large numbers of
underemployed workers and unregistered
unemployed people (December 1998)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of
SNA
Industries: aluminum, zinc, lead, chemicals and
fertilizers, cement, vegetable oil, metal-cutting
machine tools, refrigerators and freezers
Industrial production growth rate: 5% (1999 est.)
Electricity - production: 13.27 billion kWh (1998)
Electricity - production by source:
fossil fuel: 1 .51%
hydro: 98.49%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 12.561 billion kWh
(1998)
Electricity - exports: 3.33 billion kWh (1998)
Electricity - imports: 3.55 billion kWh (1998)
Agriculture - products: cotton, grain, fruits, grapes,
vegetables; cattle, sheep, goats
Exports: $634 million (1999 est.)
Exports - commodities: aluminum, electricity,
cotton, fruits, vegetable oil, textiles
484
Tajikistan (continued)
Exports - partners: Uzbekistan 37%, Liechtenstein
26%, Russia 16%, Kazakhstan 6% (1997)
Imports: $770 miiiion (1999 est.)
Imports - commodities: electricity, petroleum
products, aluminum oxide, machinery and equipment,
foodstuffs
Imports - partners: Netherlands 32%, Uzbekistan
29%, Switzerland 20%, Russia 9% (1997)
Debt - external: $1 .3 billion (1 999 est.)
Economic aid - recipient: $64.7 million (1995)
Currency: Tajikistani ruble (TJR) = 100 tanga
Exchange rates: Tajikistani rubles (TJR) per US$1 -
1550 (January 2000), 998 (January 1999), 350
(January 1997), 284 (January 1996)
Fiscal year: calendar year
Economy - overview: Tokelau''s small size (three
villages), isolation, and lack of resources greatly
restrain economic development and confine
agriculture to the subsistence level. The people must
rely on aid from New Zealand to maintain public
services, annual aid being substantially greater than
GDP. The principal sources of revenue come from
sales of copra, postage stamps, souvenir coins, and
handicrafts. Money is also remitted to families from
relatives in New Zealand.
GDP: purchasing power parity - $1 .5 million
(1993 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $1 ,000
(1993 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Popuiation beiow poverty iine: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $430,830
expenditures: $2.8 million, including capital
expenditures of $37,300 (1987 est.)
Industries: small-scale enterprises for copra
production, wood work, plaited craft goods; stamps,
coins; fishing
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: coconuts, copra, breadfruit,
papayas, bananas; pigs, poultry, goats
Exports: $98,000 (f.o.b., 1983)
Exports - commodities: stamps, copra, handicrafts
Exports - partners: NZ
Imports: $323,400 (c.i.f., 1983)
Imports - commodities: foodstuffs, building
materials, fuel
Imports - partners: NZ
Debt -external: $0
Economic aid - recipient: $3.8 million (1995)
Currency: 1 New Zealand dollar (NZ$) = 1 00 cents
Exchange rates: New Zealand dollars (NZ$) per
US$1 - 1 .9451 (January 2000), 1 .8886 (1 999), 1 .8632
(1998), 1.5083 (1997), 1.4543 (1996), 1.5235 (1995)
Fiscal year: 1 April - 31 March','91bca366125f68bf6431b7633a216049568ff6ef09024eedc11c7c03f89aeaca','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b31511c6fc09aa59b492002a73ef513ad8e5b467885288792ad763acf87405cf',2000,'AF','Afghanistan','economy',465,'Background; The islands were under Jamaican
jurisdiction until 1962, when they assumed the status
of a crown colony. The governor of The Bahamas
oversaw affairs from 1965 to 1973. With Bahamian
independence, the islands received a separate
governor in 1973. Although independence was
agreed upon for 1 982, the policy was reversed and the
islands are presently a British overseas territory.
. "^''''‘''“Geol''Taplh''y
Location; Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas
Geographic coordinates; 21 45 N, 71 35 W
Map references: Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
wafer: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline; 389 km
Maritime claims;
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; moderated by trade winds;
sunny and relatively dry
Terrain: low, flat limestone; extensive marshes and
mangrove swamps
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources; spiny lobster, conch
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
of/7er;98%(1993 est.)
Irrigated land; NAsqkm
Natural hazards; frequent hurricanes
Environment - current issues; limited natural fresh
water resources, private cisterns collect rainwater
Geography - note: 30 islands (eight inhabited)
C People
Population: 17,502 (July 2000 est.)
Age structure:
0-14 years: 33% (male 2,889; female 2,806)
15-64 years: 63% (male 5,834; female 5,274)
65 years and over: 4% (male 31 3; female 386)
(2000 est.)
Population growth rate: 3.55% (2000 est.)
Birth rate: 25.65 births/1 ,000 population (2000 est.)
Death rate: 4.57 deaths/1 ,000 population
(2000 est.)
Net migration rate: 14.46 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .1 1 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 .07 male(s)/female (2000 est.)
Infant mortality rate: 1 8.66 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 73.28 years
male: 71. 15 years
female: 75.51 years (2000 est.)
Total fertility rate: 3.25 children born/woman
(2000 est.)
Nationality;
noun: none
adjective: none
Ethnic groups; black
Religions: Baptist 41 .2%, Methodist 18.9%,
Anglican 18.3%, Seventh-Day Adventist 1 .7%, other
19.9% (1980)
Languages: English (official)
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 99%
female: 98% (1970 est.)
I Government
Country name:
conventional long form: none
conventional short form: Turks and Caicos Islands
Data code; TK
Dependency status: overseas territory of the UK
Government type: NA
Capital: Cockburn Town (on Grand Turk)
Administrative divisions: none (overseas territory
of the UK)
Independence: none (overseas territory of the UK)
Turks and Caicos Islands (continued)
National holiday; Constitution Day, 30 August
(1976)
Constitution; introduced 30 August 1976;
suspended in 1986; restored and revised 5 March
1988
Legal system; based on laws of England and
Wales, with a small number adopted from Jamaica
and The Bahamas
Suffrage; 18 years of age; universal
Executive branch;
chief of state: Queen ELIZABETH II (since 6 February
1953), represented by Governor John KELLY (since
NA September 1996)
head of government: Chief Minister Derek H.
TAYLOR (since 31 January 1995)
cabinet: Executive Council consists of three ex officio
members and five appointed by the governor from
among the members of the Legislative Council
elections: none; the monarch is hereditary; governor
appointed by the monarch; chief minister appointed by
the governor
Legislative branch; unicameral Legislative Council
(19 seats, of which 1 3 are popularly elected; members
serve four-year terms)
elections: last held 4 March 1999 (next to be held by
NA2003)
election results: percent of vote by party - RDM
52.2%, PNP 40.9%, independent 6.9%; seats by
party - PDM 9, PNP 4
Judicial branch; Supreme Court
Political parties and leaders; People''s Democratic
Movement or PDM [Derek H. TAYLOR]; Progressive
National Party or PNP [Washington MISICKj; United
Democratic Party or UDP [Wendal SWANN]
International organization participation; Caricom
(associate), CDB, Interpol (subbureau)
Diplomatic representation in the US; none
(overseas territory of the UK)
Diplomatic representation from the US; none
(overseas territory of the UK)
Flag description; blue, with the flag of the UK in the
upper hoist-side quadrant and the colonial shield
centered on the outer half of the flag; the shield Is
yellow and contains a conch shell, lobster, and cactus
Economy - overview; The Turks and Caicos
economy is based on tourism, fishing, and offshore
financial services. Most capital goods and food for
domestic consumption are imported. The US was the
leading source of tourists in 1 996, accounting for more
than half of the 87,000 visitors; tourist arrivals had
risen to 93,000 by 1 998. Major sources of government
revenue include fees from offshore financial activities
and customs receipts.
GDP; purchasing power parity - $1 17 million
(1997 est.)
GDP - real growth rate; 4% (1 997 est.)
GDP - per capita; purchasing power parity - $7,700
(1997 est.)
GDP • composition by sector;
agriculture: NA%
industry: NA%
senrices: NA%
Population below poverty line; NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 4% (1 995)
Labor force; 4,848 (1990 est.)
Labor force - by occupation; about 33% in
government and 20% in agriculture and fishing;
significant numbers in tourism, financial, and other
services (1997 est.)
Unemployment rate; 10% (1997 est.)
Budget;
revenues: $47 million
expenditures: $33.6 million. Including capital
expenditures of $NA (1997/98 est.)
Industries; tourism, offshore financial services
Industrial production growth rate; NA%
Electricity - production; 5 million kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption; 5 million kWh (1998)
Electricity • exports; 0 kWh (1998)
Electricity ■ imports; 0 kWh (1998)
Agriculture • products; com, beans, cassava
(tapioca), citrus fruits; fish
Exports; $4.7 million (1993)
Exports • commodities; lobster, dried and fresh
conch, conch shells
Exports - partners; US, UK
Imports; $46.6 million (1993)
Imports ■ commodities; food and beverages,
tobacco, clothing, manufactures, construction
materials
Imports - partners; US, UK
Debt - external; $NA
Economic aid - recipient; $5.7 million (1995)
Currency; 1 United States dollar (US$) = 100 cents
Exchange rates; US currency is used
Fiscal year; calendar year
f C 0 m m u n i c a t i 0 if s
Telephones - main lines in use; 3,000 (1994)
Telephones - mobile cellular; 0 (1994)
Telephone system; fair cable and radiotelephone
senrices
domestic: NA
international: 2 submarine cables; satellite earth
station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations; AM 3 (one inactive), FM
6, shortwave 0(1 998)
Radios; 8,000(1997)
Television broadcast stations; 0 (broadcasts from
The Bahamas are received; cable television is
established) (1997)
Televisions; NA
Internet Service Providers (ISPs); 1 (1999)
I t r a n s p 0 r t a t i 0 Tf
Railways; 0 km
Highways;
tofa/;121 km
paved: 24 km
unpaved: 97 km
Ports and harbors; Grand Turk, Providenciales
Merchant marine; none (1999 est.)
Airports; 7 (1999 est.)
Airports - with paved runways;
total: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (1999 est.)
Airports - with unpaved runways;
total: 3
914 to 1,523 m: 2
under 914 m: 1 (1999 est.)
I Military
Military - note; defense is the responsibility of the
UK
1^ t r a nTTi a t i o n a I I s s u e s
Disputes ■ international; none
Illicit drugs; transshipment point for South American
narcotics destined for the US
507
Background: In 1974, ethnic differences within the
British coiony of the Giibert and Eiiice Islands caused
the Polynesians of the Ellice Islands to vote for
separation from the Micronesians of the Gilbert
Islands. The following year, the Ellice Islands became
the separate British colony of Tuvalu. Independence
was granted in 1978. In 2000, Tuvalu negotiated a
contract leasing its Internet domain name ".tv" for $50
million in royalties over the next dozen years.
I Geography
Location: Oceania, island group consisting of nine
coral atolls in the South Pacific Ocean, about one-half
of the way from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sqkm
land: 26 sqkm
water: 0 sq km
Area - comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastiine: 24 km
Maritime ciaims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: t2 nm
Ciimate: tropical; moderated by easterly trade winds
(March to November); westerly gales and heavy rain
(November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other; 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: severe tropical storms are usually
rare, but, in 1 997, there were three cyclones; low-level
of islands make them very sensitive to sea-level rise
Environment - current issues: since there are no
streams or rivers and groundwater is not potable,
most water needs must be met by catchment systems
with storage facilities (the Japanese Government has
built one desalination plant and plans to build one
other); beachhead erosion because of the use of sand
for building materials; excessive clearance of forest
undergrowth for use as fuel; damage to coral reefs
from the spread of the Crown of Thorns starfish;
Tuvalu is very concerned about global increases in
greenhouse gas emissions and their effect on rising
sea levels, which threaten the country''s underground
water table
Environment - international agreements:
party to: Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Biodiversity, Law of the Sea
|r PeVp''le
Population: 10,838 (July 2000 est.)
Age structure:
0-14 years: 34% (male 1 ,872; female 1 ,802)
15-64 years: 61% (male 3,149; female 3,458)
65 years and over: 5% (male 239; female 31 8)
(2000 est.)
Population growth rate: 1.41% (2000 est.)
Birth rate: 21.78 births/1,000 population (2000 est.)
Death rate: 7.66 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 23.3 deaths/l ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 66.32 years
male: 64.21 years
female: 68.53 years (2000 est.)
Total fertility rate: 3.11 children born/woman
(2000 est.)
Nationality:
nourr; Tuvaluan(s)
ad/ecf;Ve; Tuvaluan
Ethnic groups: Polynesian 96%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1.4%, Baha''i 1%, other
0.6%
Languages; Tuvaluan, English
Literacy:
definition: NA
total population: HA%
male: NA%
female: NA%
I Government
Country name;
conventional long form: none
conventional short form: T uvalu
former: Ellice Islands
Data code: TV
Government type: constitutional monarchy with a
parliamentary democracy; began debating republic
status in 1992
Capital: Funafuti
Administrative divisions; none
Independence: 1 October 1978 (from UK)
National holiday: Independence Day, 1 October
(1978)
Constitution: 1 October 1978
Legal system: NA
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Tomasi
PUAPUA (since 26 June 1998)
head of government: Prime Minister lonatana
lONATANA (since NA April 1999) and Deputy Prime
Minister Lagitupu (of Nanumea) TUILIMU (since NA
April 1999)
cabinet: Cabinet appointed by the governor general
on the recommendation of the prime minister
elections: the monarch is hereditary; governor general
appointed by the monarch on the recommendation of
the prime minister; prime minister and deputy prime
minister elected by and from the members of
Parliament; election last held 27 April 1 999 (next to be
held NA 2002)
election results: lonatana lONATANA elected prime
minister; percent of Parliament vote - NA; Lagitupu (of
Nanumea) TUILIMU elected deputy prime minister;
percent of Parliament vote - NA
Legislative branch: unicameral Parliament or Fale I
Fono, also called House of Assembly (12 seats;
members elected by popular vote to serve four-year
terms)
elections: last held 26-27 March 1 998 (next to be held
by NA 2002)
election results: percent of vote - NA; seats -
independents 12
Judicial branch: eight Island Courts; High Court;
note - a chief justice visits twice a year to preside over
sessions of the High Court
Political parties and leaders: there are no political
parties but members of Parliament usually align
themselves in informal groupings
International organization participation: ACP,
AsDB, C (special), ESCAP, IFRCS (associate),
Intelsat (nonsignatory user), ITU, Sparteca, SPC,
SPF, UNESCO, UPU, WHO, WTrO (applicant)
508
Tuvalu (continued)
Diplomatic representation in the US; Tuvalu does
not have an embassy in the US
Diplomatic representation from the US: the US
does not have an embassy in Tuvalu; the US
ambassador to Fiji is accredited to Tuvalu
Flag description: light blue with the flag of the UK in
the upper hoist-side quadrant; the outer half of the flag
represents a map of the country with nine yellow
five-pointed stars symbolizing the nine islands
I TiTnoiTy
Economy - overview: Tuvalu consists of a densely
populated, scattered group of nine coral atolls with
poor soil. The country has no known mineral
resources and few exports. Subsistence farming and
fishing are the primary economic activities.
Government revenues largely come from the sale of
stamps and coins and worker remittances. About
1,000 Tuvaluans work in Nauru in the phosphate
mining industry. Nauru has begun repatriating
Tuvaluans, however, as phosphate resources decline.
Substantial income is received annuaily from an
international trust fund established in 1987 by
Australia, NZ, and the UK and supported also by
Japan and South Korea. Thanks to wise investments
and conservative withdrawals, this Fund has grown
from an initial $17 million to over $35 million in 1999.
The US government is also a major revenue source
for Tuvalu, with 1 999 payments from a 1988 treaty on
fisheries at about $9 million, a total which is expected
to rise annually. In an effort to reduce its dependence
on foreign aid, the government is pursuing public
sector reforms, including privatization of some
government functions and personnel cuts of up to 7%.
In 1 998, Tuvalu began deriving revenue from use of its
area code for “900" lines and from the sale of its “.tv"
Internet domain name. Royalites from these new
technology sources could raise GDP three or more
times over the next decade. Low-lying Tuvalu is
particularly vulnerable to any rise in the sea level from
future global warming.
GDP: purchasing power parity - $7.8 million
(1995 est.)
GDP - real growth rate: 8.7% (1995 est.)
GDP - per capita: purchasing power parity - $800
(1995 est.)
GDP - composition by sector;
agriculture: NA%
industry: NA%
services: NA%
Population beiow poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 3.9% (average
1985-93)
Labor force: NA
Labor force - by occupation: people make a living
mainly through exploitation of the sea, reefs, and
atolls and from wages sent home by those working
abroad (mostly workers in the phosphate industry and
sailors)
Unemployment rate: NA%
Budget;
revenues: $4.3 million
expenditures: $4.3 million, including capital
expenditures of $NA (1989 est.)
Industries: fishing, tourism, copra
Industrial production growth rate: NA%
Electricity - production: 3 million kWh (1 995)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: 3 million kWh (1995)
Electricity - exports: 0 kWh (1995)
Electricity • imports; 0 kWh (1995)
Agriculture - products; coconuts; fish
Exports; $165,000 (f.o.b., 1989)
Exports - commodities: copra
Exports - partners: Fiji, Austraiia, NZ
Imports: $4.4 million (c.i.f., 1989)
Imports - commodities: food, animals, mineral
fuels, machinery, manufactured goods
Imports • partners; Fiji, Australia, NZ
Debt • external; $NA
Economic aid • recipient: $7.9 million (1 995);
note - substantial annual support from an international
trust fund
Currency: 1 Tuvaluan dollar ($T) or 1 Australian
dollar ($A) = 100 cents
Exchange rates: T uvaluan dollars ($T) or Australian
dollars ($A) per US$1 - 1.5207 (January 2000),
1.5497 (1999), 1.5888 (1998), 1.3439(1997), 1.2773
(1996), 1.3486 (1995)
Fiscal year: calendar year
|r C 0 m m u n i c a rTcTtiT"”
Telephones - main lines in use: 400 (1994)
Telephones - mobile cellular: 0 (1994)
Telephone system;
domestic: radiotelephone communications between
islands
international: NA
Radio broadcast stations: AM 1, FM 0, shortwave
0(1998)
Radios: 4,000(1997)
Television broadcast stations: 0 (1997)
Televisions; NA
Internet Service Providers (ISPs): 1 (1999)
I f r"a~n s p o fTa 1 1 o n
Railways: 0 km
Highways:
fofa/;8km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Funafuti, Nukufetau
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 44,500
GRT/63,978 DWT
ships by type: cargo 5, passenger/cargo 1 , petroleum
tanker 1, roll-on/roll-off 1 (1999 est.)
Airports; 1 (1999 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m; 1 (1999 est.)
I''. MriiTaTy^’
Military branches: no regular military forces; Police
Force includes Maritime Surveillance Unit for search
and rescue missions and surveillance operations
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP; NA%
I fTairsn^tibnai~r¥sues ~
Disputes - internationai: none
509
I Introduction
Background; Uganda achieved independence from
the UK in 1962. The dictatorial regime of Idi AMIN
(1971 -79) was responsible for the deaths of some
300,000 opponents; guerrilla war and human rights
abuses under Milton OBOTE (1980-85) claimed
another 100,000 lives. During the 1990s the
government has promulgated non-party presidential
and legislative elections.
r . ^ r a p h y
Location: Eastern Africa, west of Kenya
Geographic coordinates; 1 00 N, 32 00 E
Map references: Africa
Area;
total: 236,040 sq km
/arrd; 199,710 sq km
wafer 36,330 sq km
Area ■ comparative: slightly smaller than Oregon
Land boundaries;
total: 2,698 km
border countries: Democratic Republic of the Congo
765 km, Kenya 933 km, Rwanda 169 km, Sudan 435
km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims; none (landlocked)
Climate: tropical; generally rainy with two dry
seasons (December to February, June to August);
semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount Stanley
5,110m
Natural resources: copper, cobalt, hydropower,
limestone, salt, arable land
Land use:
arable land: 25%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 28%
other; 29% (1 993 est.)
Irrigated iand: 90 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: draining of wetlands
for agricultural use; deforestation; overgrazing; soil
erosion; poaching is widespread
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Ermmmer\\\\a\\ Modification
Geography - note: landlocked
Population; 23,317,560
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would othenvise be
expected (July 2000 est.)
Age structure:
0-14 years: 51% (male 5,986,645; female 5,936,754)
15-64 years: 47% (male 5,443,613; female
5,448,563)
65 years and over: 2% (male 240,81 9; female
261,166) (2000 est.)
Population growth rate: 2.72% (2000 est.)
Birth rate: 48.04 births/1,000 population (2000 est.)
Death rate: 1 8.44 deaths/1 ,000 population
(2000 est.)
Net migration rate: -2.4 migrant(s)/1 ,000 population
(2000 est.)
note: according to the UNHCR, by the end of 1 998,
Uganda was host to 205,000 refugees from a number
of neighboring countries, including: Sudan 190,000,
Rwanda 7,500, and Democratic Republic of the
Congo 5,400; refugees began returning to their
countries of origin in 2000
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 93.25 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 42.93 years
ma/e; 42.22 years
female: 43.67 years (2000 est.)
Total fertility rate: 6.96 children born/woman
(2000 est.)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Karamojong 12%,
Basogo 8%, Iteso 8%, Langi 6%, Rwanda 6%, Bagisu
5%, Acholi 4%, Lugbara 4%, Bunyoro 3%, Batobo 3%,
non-African (European, Asian, Arab) 1%, other 23%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages; English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications in the capital and may be taught
in school), other Niger-Congo languages,
Nilo-Saharan languages, Swahili, Arabic
Literacy:
definition: age 1 5 and over can read and write
total population: 61 .8%
male: 73.7%
fema/e; 50.2% (1995 est.)
I Government
Country name;
conventional long form: Republic of Uganda
conventional short form: Uganda
Data code; UG
Government type; republic
Capital: Kampala
Administrative divisions; 39 districts; Apac, Arua,
Bundibugyo, Bushenyi, Gulu, Hoima, Iganga, Jinja,
Kabale, Kabarole, Kalangala, Kampala, Kamuli,
Kapchorwa, Kasese, Kibale, Kiboga, Kisoro, Kitgum,
Kotido, Kumi, Lira, Luwero, Masaka, Masindi, Mbale,
Mbarara, Moroto, Moyo, Mpigi, Mubende, Mukono,
Nebbi, Ntungamo, Pallisa, Rakai, Rukungiri, Soroti,
Tororo
Independence: 9 October 1962 (from UK)
National holiday: Independence Day, 9 October
(1962)
Constitution: 8 October 1 995; adopted by the
interim, 284-member Constituent Assembly, charged
with debating the draft constitution that had been
proposed in May 1 993; the Constituent Assembly was
dissolved upon the promulgation of the constitution in
October 1995
Legal system: in 1 995, the government restored the
legal system to one based on English common law
and customary law; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Lt. Gen. Yoweri Kaguta
MUSEVENI (since seizing power 29 January 1986);
note - the president is both chief of state and head of
Economy - overview: Uganda has substantial
natural resources, including fertile soils, regular
rainfall, and sizable mineral deposits of copper and
cobalt. Agriculture is the most important sector of the
economy, employing over 80% of the work force.
Coffee is the major export crop an','98df606c5bfecfeee883ad557100f741cb31ff8a6b586eec4fa6f9f94295d2ba','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c8da46ca8cd7dc18cd45c62983c23377d98f46861e06680fe03e70fd930a0f4',2000,'AF','Afghanistan','economy',466,'d accounts for the
bulk of export revenues. Since 1986, the
government - with the support of foreign countries and
international agencies - has acted to rehabilitate and
stabilize the economy by undertaking currency
reform, raising producer prices on export crops,
increasing prices of petroleum products, and
improving civil service wages. The policy changes are
especially aimed at dampening inflation and boosting
production and export earnings. In 1990-99, the
economy turned in a solid performance based on
continued investment in the rehabilitation of
infrastructure, improved incentives for production and
exports, reduced inflation, gradually improved
domestic security, and the return of exiled
Indian-Ugandan entrepreneurs. Ongoing Ugandan
involvement in the war in the Democratic Republic of
the Congo, growing corruption within the government,
and slippage in the government''s determination to
press reforms raise doubts about the continuation of
strong growth.
GDP: purchasing power parity - $24.2 billion
(1999 est.)
GDP - real growth rate: 5.5% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,060
(1999 est.)
GDP - composition by sector:
agriculture: 44%
industry: 17%
services: 39% (1997 est.)
Population below poverty line: 55% (1993 est.)
Household income or consumption by percentage
share:
lowest 10%: 3%
highest 10%: 22.4% {m2)
Inflation rate (consumer prices): 7% (1999)
Labor force: 8.361 million (1993 est.)
Labor force - by occupation: agriculture 82%,
industry 5%, services 13% (1999 est.)
Unemployment rate: NA%
Budget:
revenues: $959 million
expenditures: $1 .04 billion, including capital
expenditures of $NA (FY98/99 est.)
Industries: sugar, brewing, tobacco, cotton textiles,
cement
Industrial production growth rate: 9.3%
(FY98/99)
Electricity - production: 792 million kWh (1998)
Electricity - production by source:
fossil fuel: 0.88%
hydro; 99.1 2%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 622 million kWh (1998)
Electricity - exports: 1 1 5 million kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: coffee, tea, cotton, tobacco,
cassava (tapioca), potatoes, corn, millet, pulses; beef,
goat meat, milk, poultry
Exports: $471 million (f.o.b., 1999)
Exports - commodities: coffee, fish and fish
products, tea; electrical products, iron and steel
Exports - partners: EU 51% (Netherlands 6%,
Switzerland 6%, Germany 5%, Belgium 4%), Kenya
5% (1998)
Imports: $1.1 billion (f.o.b., 1999)
Imports ■ commodities: vehicles, petroleum,
medical supplies; cereals
Imports - partners: Kenya 12%, UK 6%, Japan 4%,
India 4%, South Africa (1998)
Debt - external: $3.1 billion (1998 est.)
Economic aid - recipient: $839.9 million (1997)
Currency: 1 Ugandan shilling (USh) = 100 cents
Exchange rates: Ugandan shillings (USh) per
US$1 - 1,525.8 (January 2000), 1,454.8 (1999),
1,240.2(1998), 1,083.0(1997), 1,046.1 (1996), 968.9
(1995)
Fiscal year: 1 July - 30 June
Telephones - main lines in use: 54,074 (1998)
Telephones - mobile cellular: 9,000 (1998)
Telephone system: seriously inadequate; two
cellular systems have been introduced, but a sharp .
increase in the number of main lines is essential;
e-mail and Internet services are available
domestic: intercity traffic by wire, microwave radio
relay, and radiotelephone communication stations,
fixed and mobile cellular systems for short range
traffic
international: sateMe earth stations - 1 1ntelsat
(Atlantic Ocean) and 1 1nmarsat; analog links to
Kenya and Tanzania
Radio broadcast stations: AM 1 9, FM 4, shortwave
5(1998)
Radios: 2.6 million (1997)
Television broadcast stations: 8 (plus one
low-power repeater) (1999)
Televisions: 315,000(1997)
Internet Service Providers (ISPs): 3(1999)
I Transportation
Railways:
total: 1 ,241 km
narrow gauge: 1,241 km 1.000-m gauge
note: a program to rehabilitate the railroad is
underway (1995)
Highways:
total: 27,000 km
paved: 1 ,800 km
unpaved: 25,200 km (of which about 4,800 km are
all-weather roads) (1990 est.)
Waterways: Lake Victoria, Lake Albert, Lake Kyoga,
Lake George, Lake Edward, Victoria Nile, Albert Nile
Ports and harbors: Entebbe, Jinja, Port Bell
511
Uganda (continued)
Merchant marine:
total: 3 ships (1 ,000 GRT or over) totaling 5,091 GRT/
8,229 DWT
ships by type: roll-on/roll-off 3 (1 999 est.)
Airports: 26 (1999 est.)
Airports - with paved runways:
total: A
over 3,047 m: 3
1,524 to 2,437 m:t (1999 est.)
Airports - with unpaved runways:
total: 22
2,438 to 3,047 m-.l
1,524 to 2,437 m:G
914 to 1,523 m: 8
under 914 m; 7 (1999 est.)
Heliports: 1 (1 999 est.)
1^ M ilT tT ry
Military branches: Army, Navy, Air Wing
Military manpower - availability:
males age 15-49: 4,952,945 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,687,924 (2000 est.)
Military expenditures - dollar figure: $95 million
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)
f Transnati oTT a I iT sues”
Disputes - international: Ugandan military forces
are supporting the rebel forces in the civil war in the
Democratic Republic of the Congo
I In t r 0 d u ift j o r1
Background: Richly endowed in natural resources,
Ukraine has been fought over and subjugated for
centuries; its 20th-century struggle for liberty is not yet
complete. A short-lived independence from Russia
(1917-1920) was followed by brutal Soviet rule that
engineered two artificial famines (1921-22 and
1 932-33) in which over 8 million died, and World War
II, in which German and Soviet armies were
responsible for some 7 million more deaths. Although
independence was attained in 1991 with the
dissolution of the USSR, true freedom remains elusive
as many of the former Soviet elite remain entrenched,
stalling efforts at economic reform, privatization, and
civic liberties.
I’
Location: Eastern Europe, bordering the Black Sea,
between Poland and Russia
Geographic coordinates: 49 00 N, 32 00 E
Map references: Commonwealth of Independent
States
Area:
total: 603,700 sq km
land: 603,700 sq km
wafer; 0 sq km
Area - comparative: slightiy smaller than Texas
Land boundaries:
total: 4,558 km
border countries: Belarus 891 km, Hungary 103 km,
Moldova 939 km, Poland 428 km, Romania (south)
169 km, Romania (west) 362 km, Russia 1,576 km,
Slovakia 90 km
Coastline: 2,782 km
Maritime claims:
continental shelf: 200-m or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate continental; Mediterranean only
on the southern Crimean coast; precipitation
disproportionately distributed, highest in west and
north, lesser in east and southeast; winters vary from
cool along the Black Sea to cold farther inland;
summers are warm across the greater part of the
country, hot in the south
Terrain: most of Ukraine consists of fertile plains
(steppes) and plateaus, mountains being found only in
the west (the Carpathians), and in the Crimean
Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese,
natural gas, oil, salt, sulfur, graphite, titanium,
magnesium, kaolin, nickel, mercury, timber, arable
land
Land use:
arable land: 58%
permanent crops: 2%
permanent pastures: 1 3%
forests and woodland: 18%
other: 9% (1993 est.)
Irrigated land: 26,050 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: inadequate
supplies of potable water; air and water pollution;
deforestation; radiation contamination in the northeast
from 1 986 accident at Chornobyl'' Nuclear Power Plant
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic Treaty,
Biodiversity, Climate Change, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Mr Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Climate
Change-Kyoto Protocol
512
UkrainG (continued)
Geography - note: strategic position at the
crossroads between Europe and Asia; second-largest
country in Europe
Population: 49,153,027 (July 2000 est.)
Age structure:
0-14 years: 18% (male 4,482,754; female 4,296,206)
15-64 years: 68% (male 16,018,331; female
17,509,078)
65 years and over: 14% (male 2,243,266; female
4,603,392) (2000 est.)
Population growth rate: -0.83% (2000 est.)
Birth rate: 9.03 births/1,000 population (2000 est.)
Death rate: 16.48 deaths/1,000 population
(2000 est.)
Net migration rate: -0.84 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years; 0.91 male(s)/female
65 years and over: 0.49 male(s)/female
total population: 0.86 male(s)/female (2000 est.)
Infant mortality rate: 21 .67 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 65.98 years
male: 60.39 years
female: 71 .85 years (2000 est.)
Total fertility rate: 1 .26 children born/woman
(2000 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 73%, Russian 22%,
Jewish 1%, other 4%
Religions: Ukrainian Orthodox - Moscow
Patriarchate, Ukrainian Orthodox - Kiev Patriarchate,
Ukrainian Autocephalous Orthodox, Ukrainian
Catholic (Uniate), Protestant, Jewish
Languages: Ukrainian, Russian, Romanian, Polish,
Hungarian
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 100%
female: 97% {1989 est.)
I Government
Country name:
conventional long form: none
conventional short form: Ukraine
local long form: none
local short form: Ukrayina
former: Ukrainian Soviet Socialist Republic
Data code: UP
Government type: republic
Capital: Kiev (Kyyiv)
Administrative divisions: 24 oblasti (singular -
oblast''), 1 autonomous republic* (avtomnaya
respublika), and 2 municipalities (mista, singular -
misto) with oblast status**; Cherkas''ka (Cherkasy),
Chernihivs''ka (Chernihiv), Chemivets''ka (Chernivtsi),
Dnipropetrovs''ka (Dnipropetrovs''k), Donets''ka
(Donets''k), Ivano-Frankivs''ka (Ivano-Frankivs''k),
Kharkivs''ka (Kharkiv), Khersons''ka (Kherson),
Khmel''nyts''ka (Khmel''nyts''kyy), Kirovohrads''ka
(Kirovohrad), Kyyiv**, Kyyivs''ka (Kiev), Luhans''ka
(Luhans''k), L''vivs''ka (L''viv), Mykolayivs''ka
(Mykolayiv), Odes''ka (Odesa), Poltavs''ka (Poltava),
Avtonomna Respublika Krym* (Simferopol''),
Rivnens''ka (Rivne), Sevastopol''**, Sums''ka (Sumy),
Ternopil''s''ka (Ternopil''), Vinnyts''ka (Vinnytsya),
Volyns''ka (Luts''k), Zakarpats''ka (Uzhhorod),
Zaporiz''ka (Zaporizhzhya), Zhytomyrs''ka (Zhytomyr)
note: oblasts have the administrative center name
following in parentheses
Independence: 1 December 1991 (from Soviet
Union, by voter approval)
National holiday: Independence Day, 24 August
(1991)
Constitution: adopted 28 June 1996
Legal system: based on civil law system; judicial
review of legislative acts
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Leonid D. KUCHMA (since
19 July 1994)
head of government: Prime Minister Viktor
YUSHCHENKO (since 22 December 1999), First
Deputy Prime Minister Yuriy YEKHANUROV (since
30 December 1 999), and three deputy prime ministers
cabinet: Cabinet of Ministers appointed by the
president and approved by the Supreme Council
nofe; there is also a National Security and Defense
Council or NSDC originally created in 1992 as the
National Security Council, but significantly revamped
and strengthened under President KUCHMA; the
NSDC staff is tasked with developing national security
policy on domestic and international matters and
advising the president; a Presidential Administration
that helps draft presidential edicts arid provides policy
support to the president; and a Council of Regions that
serves as an advisory body created by President
KUCHMA in September 1994 that includes chairmen
of the Kyyiv (Kiev) and Sevastopol'' municipalities and
chairmen of the oblasti
elections: president elected by popular vote for a
five-year term; election last held 31 October and 14
November 1999 (next to be held NA 2004); prime
minister and deputy prime ministers appointed by the
president and approved by the People''s Council
election results: Leonid D. KUCHMA elected
president; percent of vote - Leonid KUCHMA 56.21 %,
Petro SYMONENKO 37.77%
Legislative branch; unicameral Supreme Council or
Verkhovna Rada (450 seats; under Ukraine''s new
election law, half of the Rada''s seats are allocated on
a proportional basis to those parties that gain 4% of
the national electoral vote; the other 225 members are
elected by popular vote in single-mandate
constituencies; all serve four-year terms)
elections: last held 29 March 1 998 (next to be held NA
2002)
election results: percent of vote by party (for parties
clearing 4% hurdle on 29 March 1998) - Communist
24.7%, Rukh (combined) 9.4%, Socialist/Peasant
8.6%, Green 5.3%, People''s Democratic Party 5.0%,
Hromada 4.7%, Progressive Socialist 4.0%, United
Social Democratic Party 4.0%; seats by faction (as of
25 February 2000) - Communist 115, PRVU 36,
Fatherland Party 35, United Social Democratic 34,
People''s Democratic Party 27, Trudova Ukrayina 27,
Rukh (K) 27, left-center 23, Green 18, Rukh (U) 17,
Peasant Party 15, Hromada 14, Reforms Congress
12, independents 14, unaffiliated 31, vacant 5
Judicial branch: Supreme Court; Constitutional
Court
Political parties and leaders: Agrarian Party of
Ukraine or APU [Mykhaylo HLADIY, chairperson];
Communist Party of Ukraine [Petro SYMONENKO];
Fatherland (Motherland) All Ukrainian Party [Yuliya
TYMOSHENKO, chairperson]; Green Party of
Ukraine or PZU [Vitaliy KONONOV, chairman];
Hromada [Pavio LAZARENKO]; Liberal Party of
Ukraine or LPU [Volodymyr SHCHERBAN]; Party of
Regional Revival of Ukraine or PRVU [Volodymyr
RYBAK]; Peasant Party of Ukraine or SelPU [Serhiy
DOVHAN]; People''s Democratic Party [Valeriy
PUSTOVOYTENKO, chairman]; People''s Movement
of Ukraine or Rukh U [Hennadiy UDOVENKO,
chairman]; Progressive Socialist Party [Nataliya
VITRENKO]; Reforms Congress [leader NA]; Reforms
and Order Party [Viktor PYNZENYK]; Sobor Party
[Anatoliy MATVIYENKO, chairman]; Social
Democratic Party of Ukraine (United) [Viktor
MEDVEDCHUK, chairman]; Socialist Party of Ukraine
or SPU [Oleksandr MOROZ, chairman]; Trudova
Ukrayina/Working Ukraine [Igor SHAROV, chairman];
Ukrainian Popular Movement or Rukh K [Yuriy
KOSTENKO, chairman]; United Social Democratic
Party of Ukraine [Viktor MEDVEDCHUK]; Yabluko
Party [Viktor CHAYKA, chairman]
note: and numerous smaller parties
International organization participation; BSEC,
CCC, CE, CEI, CIS, EAPC, EBRD, ECE, IAEA, IBRD,
ICAO, ICRM, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat (nonsignatory user), Interpol, IOC,
lOM (observer), ISO, ITU, NAM (observer), NSG,
OAS (observer), OPCW, OSCE, PCA, PFP, UN, UN
Security Council (temporary), UNCTAD, UNESCO,
UNIDO, UNMIBH, UNMIK, UNMOP, UNMOT, UPU,
WFTU, WHO, WlPO, WMO, WToO, WTrO
(applicant), ZC
Diplomatic representation in the US:
chief of mission: kmhassador Konstantin Ivanovych
HRYSHCHENKO
chancery: 3350 M Street NW, Washington, DC 20007
fe/eptor7e;[1] (202) 333-0606
FAX; [1] (202) 333-0817
consulate(s) general: Chicago and New York
Diplomatic representation from the US:
chief of mission: Ambassador Steven Karl PIFER
embassy: 10 Yuria Kotsubynskoho, 254053 Kiev 53
UkrainG (continued)
mailing address: use embassy street address
fe/ep/)one; [380] (44) 246-9750
FAV; [380] (44) 244-7350
Flag description: two equal horizontal bands of
azure (top) and golden yellow represent grainfields
under a blue sky
I Economy
Economy - overview: After Russia, the Ukrainian
republic was far and away the most important
economic component of the former Soviet Union,
producing about four times the output of the
next-ranking republic. Its fertile black soil generated
more than one-fourth of Soviet agricultural output, and
its farms provided substantial quantities of meat, milk,
grain, and vegetables to other republics. Likewise, its
diversified heavy industry supplied equipment and
raw materials to industrial and mining sites in other
regions of the former USSR. Ukraine depends on
imports of energy, especially natural gas. Shortly after
the implosion of the USSR in December 1991, the
Ukrainian Government liberalized most prices and
erected a legal framework for privatization, but
widespread resistance to reform within the
government and the legislature soon stalled reform
efforts and led to some backtracking. Output in
1992-99 fell to less than 40% the 1991 level. Loose
monetary policies pushed inflation to hyperinflationary
levels in late 1993. Since his election in July 1994,
President KUCHMA has pushed economic reforms,
maintained financial discipline, and tried to remove
almost all remaining controls over prices and foreign
trade. The onset of the financial crisis in Russia
dashed Ukraine''s hopes for its first year of economic
growth in 1998 due to a sharp fall in export revenue
and reduced domestic demand. Output continued to
drop, slightly, in 1999. The government has also not
been able to significantly decrease its huge backlog of
wage and pension arrears. Despite increasing
pressure from the IMF to accelerate reform,
substantial economic restructuring remains unlikely in
2000, largely because of resistance in the
communist-dominated legislature to further
privatization.
GDP: purchasing power parity - $109.5 billion
(1999 est.)
GDP - real growth rate: -0.4% (1999 est.)
GDP - per capita: purchasing power parity - $2,200
(1999 est.)
GDP - composition by sector:
agriculture: 12%
industry: 26%
senrices: 62% (1 998 est.)
Population below poverty line: 50% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: ^A%
highest 10%; 20.8% (1992)
Inflation rate (consumer prices): 20% (1999 est.)
Labor force: 22.8 million (yearend 1997)
Labor force - by occupation: industry and
construction 32%, agriculture and forestry 24%,
health, education, and culture 17%, trade and
distribution 8%, transport and communication 7%,
other 12% (1996)
Unemployment rate: 4.3% officially registered;
large number of unregistered or underemployed
workers (December 1999)
Budget:
revenues: $8.3 billion
expenditures: $8.8 biliion, including capital
expenditures of $NA (1999 est.)
Industries: coal, electric power, ferrous and
nonferrous metals, machinery and transport
equipment, chemicals, food-processing (especially
sugar)
Industrial production growth rate: 4.3%
(1999 est.)
Electricity - production: 171 billion kWh (1999)
Electricity - production by source:
fossil fuel: 52%
hydro: 5.9%
nuclear: 42.1%
other; 0% (1999)
Electricity - consumption: 144.011 billion kWh
(1998)
Electricity - exports: 7 billion kWh (1998)
Electricity - imports: 4.15 billion kWh (1998)
Agriculture - products: grain, sugar beets,
sunflower seeds, vegetables; beef, milk
Exports: $1 1 .6 billion (1999 est.)
Exports ■ commodities: ferrous and nonferrous
metals, fuel and petroleum products, machinery and
transport equipment, food products
Exports - partners: Russia 20%, EU 17%, China
7%, Turkey 6%, US 4% (1999)
Imports: $1 1 .8 billion (1999 est.)
Imports ■ commodities: energy, machinery and
parts, transportation equipment, chemicals
Imports - partners: Russia 48%, EU 23%, US 3%
(1999)
Debt - external: $12.6 billion (January 2000 est.)
Economic aid - recipient; $637.7 million (1995);
IMF Extended Funds Facility $2.2 billion (1998)
Currency: 1 hryvna = 100 kopiykas
Exchange rates: hryvnia per US$1 - 5.59 (February
2000), 5.381 1 (January 2000), 4.1304 (1999), 2.4495
(1998), 1.8617 (1997), 1.8295 (1996), 1.4731 (1995)
Fiscal year: calendar year
r Communications
Telephones - main lines in use: 9.45 million (April
1999)
Telephones - mobile cellular: 236,000 (1 998)
Telephone system: Ukraine''s telecommunication
development plan, running through 2005, emphasizes
improving domestic trunk lines and international
connections, and developing a mobile cellular system
domestic: at independence in December 1991,
Ukraine inherited a telephone system that was
antiquated, inefficient and in disrepair; more than 3.5
million applications for telephones could not be
satisfied; telephone density is now rising slowly and
the domestic trunk system is being improved; from a
small base, the mobile cellular telephone system is
expanding at a high rate
International: two new domestic trunk lines are a part
of the fiber-optic T rans-Asia-Europe (TAE) system and
three Ukrainian links have been installed in the
fiber-optic Trans-European Lines (TEL) pro]ect which
connects 18 countries; additional international sen/ice
is provided by the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by earth stations in the
Intelsat, Inmarsat, and Intersputnik satellite systems
Radio broadcast stations: AM 134, FM 289,
shortwave 4 (1998)
Radios: 45.05 million (1997)
Television broadcast stations: at least 33 (plus 21
repeater stations that relay broadcasts from Russia)
(1997)
Televisions: 18.05 million (1997)
Internet Service Providers (ISPs): 35 (1999)
f transportation
Railways:
total: 23,350 km
broad gauge: 23,350 km 1 .524-m gauge (8,600 km
electrified)
Highways:
tota/; 176,310 km
paved: 170,139 km (including 1 ,770 km of
expressways); note - these roads are said to be
hard-surfaced, meaning that some are paved and
some are all-weather gravel-surfaced
unpaved: 6,171 km (1998 est.)
Waterways: 4,400 km navigable waterways, of
which 1 ,672 km were on the Pryp''yat'' and Dnistr
(1990)
Pipelines: crude oil 4,000 km (1995); petroleum
products 4,500 km (1995); natural gas 34,400 km
(1998)
Ports and harbors: Berdyans''k, lllichivs''k, Izmayil,
Kerch, Kherson, Kiev (Kyyiv), Mariupol'', Mykolayiv,
Odesa, Reni
Merchant marine:
total: 156 ships (1 ,000 GRT or over) totaling 862,690
GRT/963,550 DWT
ships by type: bulk 9, cargo 105, container 4,
passenger 11, passenger/cargo 3, petroleum tanker
14, rail car carrier 2, roll-on/roll-off 5, short-sea
passenger 3 (1999 est.)
Airports: 706 (1994 est.)
Airports - with paved runways:
total: 163
over 3,047 m: 14
2,438 to 3,047 m: 55
1,524 to 2,437 m: 34
914 to 1,523 m: 3
under 914 m: 57 (1 994 est.)
Airports - with unpaved runways:
total: 543
over 3,047 m: 7
2,438 to 3,047 m: 7
1,524 to 2,437 m: 16
914 to 1,523 m: 37
under 914 m: 476 (1 994 est.)
514
UkrainG (continued)
I Military
Military branches: Army, Navy, Air Force, Air
Defense Force, internal Troops, National Guard,
Border Troops
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 12,31 1 ,052 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 9,645,925 (2000 est.)
Military manpower - reaching military age
annually:
males: 373,595 (2000 est.)
Military expenditures - dollar figure: $500 million
(FY99)
Military expenditures - percent of GDP: 1 .4%
(FY99)
I transnational Issues
Disputes ■ international: dispute with Romania
over continental shelf of the Black Sea under which
significant gas and oil deposits may exist; agreed in
1 997 to two-year negotiating period, after which either
party can refer dispute to the ICJ; has made no
territorial claim in Antarctica (but has reserved the
right to do so) and does not recognize the claims of
any other nation
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; some
synthetic drug production for export to West; limited
government eradication program; used as
transshipment point for opiates and other illicit drugs
from Africa, Latin America, and T urkey, and to Europe
and Russia; drug-related money laundering a minor,
but growing, problem
lUnited Arab Emirates
^AIN
Persian Gulf
0 (, Junb al
Tunb af KubrS /%
§ughri h\\
, Ra s al / # .
Abu Musi‘S Khayma^ \\ /
Umm al Qaywayn.«f^ ''■k
’ P Omani
Ajm^y enclave 4
QATAR j
,DS$
“ Dub^Sharjah »
'' .
MTna’Jabal ’Ali>^
ABU
0 ^
Ar Ruways
SAUDI ARABIA \\
.Qutuf
50 TOO km
1.','047873cd30cbf6edc41dd445ac28553610bab67071d095c308741c5c2c88d390','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f0a1fba17df60e65bbabbf4a8714ee77ebb69373e171fd6861f513d74238765',2000,'OM','Oman','economy',468,'I introduction
Background: The Trucial States of the Persian Gulf
coast granted the UK control of their defense and
foreign affairs in 1 9th century treaties. In 1 971 , six of
these states - Abu Zaby, ''Ajman, Al Fujayrah, Ash
Shariqah, Dubayy, and Umm al Qaywayn - merged to
form the UAE. They were joined in 1972 by Ra''s al
Khaymah. The UAE''s per capita GDP is not far below
the GDPs of the leading West European nations. Its
generosity with oil revenues and its moderate foreign
policy stance have allowed it to play a vital role in the
affairs of the region.
I’
Location: Middle East, bordering the Gulf of Oman
and the Persian Gulf, between Oman and Saudi
Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 410 km, Saudi Arabia 457 km
Coastline: 1,318 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in
east
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: ^aba\\ Ylbir 1,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 2%
forests and woodland: 0%
of/ter; 98% (1993 est.)
Irrigated land: 50 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: lack of natural
freshwater resources being overcome by desalination
piants; desertification; beach pollution from oil spills
Environment - international agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: Biodiversity, Law of the Sea
Geography - note: strategic location along southern
approaches to Strait of Hormuz, a vital transit point for
world crude oil
Population: 2,369,153
note: includes 1 ,576,472 non-nationals (July
2000 est.)
Age structure:
0-14 years: 30% (male 359,134; female 345,51 8)
15-64 years: 68% (male 1 ,029,898; female 582,783)
65 years and over: 2% (male 35,928; female 1 5,892)
(2000 est.)
Population growth rate: 1 .61% (2000 est.)
Birth rate: 1 8 births/1 ,000 population (2000 est.)
Death rate: 3.68 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 .82 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
515
United Arab Emirates (continued)
15-64 years: Ml male(s)/female
65 years and over: 2.26 male(s)/female
total population: 1.51 male(s)/female (2000 est.)
Infant mortality rate: 17.17 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 74.06 years
male: 71 .64 years
fema/e; 76.61 years (2000 est.)
Total fertiiity rate: 3.29 children born/w/oman
(2000 est.)
Nationality;
noun: Emirian(s)
adjective: Emirian
Ethnic groups: Emiri 1 9%, other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1982)
note: less than 20% are UAE citizens (1 982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 15 and over can read and write
total population: 79.2%
ma/e; 78.9%
female: 79.8% (1995 est.)
I Government ^
Country name;
conventional long form: United Arab Emirates
conventional short form: none
local long form: Al Imarat al Arabiyah al Muttahidah
local short form: none
former Trucial States
abbreviation: UAE
Data code: TC
Government type: federation with specified powers
delegated to the UAE federal government and other
powers resenred to member emirates
Capital; Abu Dhabi
Administrative divisions; 7 emirates (imarat,
singular - imarah); Abu Zaby (Abu Dhabi), ''Ajman, Al
Fujayrah, Ash Shariqah (Sharjah), Dubayy (Dubai),
Ra''s al Khaymah, Umm al Qaywayn
Independence; 2 December 1971 (from UK)
National holiday: National Day, 2 December (1 971 )
Constitution: 2 December 1971 (made permanent
in 1996)
Legal system: federal court system introduced in
1971; all emirates except Dubayy (Dubai) and Ra''s al
Khaymah have joined the federal system; all emirates
have secular and Islamic law for civil, criminal, and
high courts
Suffrage; none
Executive branch:
chief of s^te: President ZAYID bin Sultan Al
Nuhayyan (since 2 December 1971), ruler of Abu
Zaby (Abu Dhabi) (since 6 August 1966) and Vice
President MAKTUM bin Rashid al-Maktum (since 8
October 1990), ruler of Dubayy (Dubai)
head of government: Prime Minister MAKTUM bin
Rashid al-Maktum (since 8 October 1990), ruler of
Dubayy (Dubai); Deputy Prime Minister SULTAN bin
Zayid Al Nuhayyan (since 20 November 1990)
cabinet: Council of Ministers appointed by the
president
note: there is also a Federal Supreme Council (FSC)
which is composed of the seven emirate rulers; the
council is the highest constitutional authority in the
UAE; establishes general policies and sanctions
federal legislation, Abu Zaby (Abu Dhabi) and Dubayy
(Dubai) rulers have effective veto power; meets four
times a year
elections: president and vice president elected by the
FSC (a group of seven electors) for five-year terms;
election last held NA October 1996 (next to be held
NA 2001); prime minister and deputy prime minister
appointed by the president
election results: ZAYID bin Sultan Al Nuhayyan
reelected president; percent of FSC vote - NA, but
believed to be unanimous; MAKTUM bin Rashid
al-Maktum elected vice president; percent of FSC
vote - NA, but believed to be unanimous
Legislative branch: unicameral Federal National
Council or Majlis al-Ittihad al-Watani (40 seats;
members appointed by the rulers of the constituent
states to serve two-year terms)
elections: none
note: reviews legislation, but cannot change or veto
Judicial branch: Union Supreme Court, judges
appointed by the president
Political parties and leaders: none
Political pressure groups and leaders; NA
International organization participation: ABEDA,
AfDB, AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO,
G-77, GCC, IAEA, IBRD, ICAO, ICRM, IDA, IDB,
IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, ISO (correspondent), ITU,
NAM, OAPEC, OIC, OPCW, OPEC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WlPO, WMO, WTrO
Diplomatic representation in the US;
chief of mission: fmbassaiot Muhammad bin
Husayn al-SHAALI
chancery: Suite 700, 1255 22nd Street NW,
Washington, DC 20037
telephone: [1] (202) 955-7999
Diplomatic representation from the US:
chief of mission: Ambassador Theodore H.
KATTOUF
embassy; Al-Sudan Street, Abu Dhabi
mailing address: P. 0. Box 4009, Abu Dhabi;
American Embassy Abu Dhabi, Department of State,
Washington, DC 20521-6010 (pouch); note - work
week is Saturday through Wednesday
telephone: [971] (2) 436691, 436692
FAX; [971] (2) 434771
consulate(s) general: Dubai
Flag description: three equal horizontal bands of
green (top), white, and black with a thicker vertical red
band on the hoist side
I Economy
Economy - overview: The UAE has an open
economy with a high per capita income and a sizable
annual trade surplus. Its wealth is based on oil and
gas output (about 33% of GDP), and the fortunes of
the economy fluctuate with the prices of those
commodities. Since 1973, the UAE has undergone a
profound transformation from an impoverished region
of small desert principalities to a modern state with a
high standard of living. At present levels of production,
oil and gas reserves should last for over 100 years.
Despite higher oil revenues in 1999, the government
has not drawn back from the economic reforms
implemented during the 1998 oil price depression.
The government has increased spending on job
creation and infrastructure expansion and is opening
up its utilities to greater private-sector involvement.
GDP: purchasing power parity - $41 .5 billion
(1999 est.)
GDP - real growth rate: 2.5% (1999 est.)
GDP - per capita: purchasing power parity -
$17,700 (1999 est.)
GDP - composition by sector;
agriculture: 3%
industry: 52%
services: 45% (1 996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4% (1999 est.)
Labor force: 1 .38 million (1 998 est.)
note: 75% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force - by occupation: services 60%,
industry 32%, agriculture 8% (1996 est.)
Unemployment rate: NA%
Budget;
revenues: $5.5 billion
expenditures: $6.2 billion, including capital
expenditures of $NA (1999 est.)
Industries: petroleum, fishing, petrochemicals,
construction materials, some boat building,
handicrafts, pearling
Industrial production growth rate: 0% (1997 est.)
Electricity - production: 20.1 1 billion kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other 0% (1998)
Electricity - consumption: 18.702 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: dates, vegetables,
watermelons; poultry, eggs, dairy products; fish
Exports: $34 billion (f.o.b., 1999 est.)
Exports - commodities: crude oil 45%, natural gas,
reexports, dried fish, dates
516
United Arab Emirates (continued)
Exports - partners: Japan 30%, South Korea 10%,
India 6%, Singapore 4.5%, Oman 3%, Iran (1998)
Imports: $27.5 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and transport
equipment, chemicals, food
Imports - partners: US 10%, Japan 9%, UK 9%,
Germany 6%, South Korea 5%, Italy (1998)
Debt - external: $15.5 billion (1998 est.)
Economic aid - recipient: $NA
Currency: 1 Emirian dirham (Dh) = 100 fils
Exchange rates: Emirian dirhams (Dh) per US$1 ■
central bank mid-point rate: 3.6725 (from 1998);
3.6711 (1997), 3.6710 (1995-96)
Fiscal year: calendar year
I “^Communications
Telephones - main iines in use: 915,223 (1998)
Telephones - mobile cellular: 1 million (1999)
Telephone system: modern system consisting of
microwave radio relay and coaxial cable; key centers
are Abu Dhabi and Dubai
domestic: microwave radio relay and coaxial cable
international: satellite earth stations - 3 Intelsat (1
Atlantic Ocean and 2 Indian Ocean) and 1 Arabsat;
submarine cables to Qatar, Bahrain, India, and
Pakistan; tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia
Radio broadcast stations: AM 13, FM 7, shortwave
2(1998)
Radios: 820,000(1997)
Television broadcast stations: 15 (1997)
Televisions: 310,000(1997)
Internet Service Providers (ISPs): 1 (1999)','9ffee492a0e01570979d4e33d593615dce0a0dc2d652014acdf13819e73a1c3c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c392fbcd5a3519f1f06bc1f13a2c9e19abb5b336c94ead5dcce62e70e9fd0527',2000,'UY','Uruguay','economy',471,'Background: A violent Marxist urban guerrilla
movement, the Tupamaros, launched in the late
1960s, led Uruguay''s president to agree to military
control of his administration in 1973. By the end of the
year the rebels had been crushed, but the military
continued to expand its hold throughout the
government, Civilian rule was not restored until 1985.
Uruguay has long had one of South America''s highest
standards of living; its political and labor conditions
are among the freest on the continent.
f Geography
Location: Southern South America, bordering the
South Atlantic Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
fofa/; 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area - comparative: slightly smaller than the state
of Washington
Land boundaries:
fofa/; 1,564 km
border counfr/es; Argentina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 200 nm; overflight and navigation
guaranteed beyond 12 nm
Climate: warm temperate; freezing temperatures
almost unknown
Terrain: mostly rolling plains and low hills; fertile
coastal lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: arable land, hydropower, minor
minerals, fisheries
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 77%
forests and woodland: 6%
ofber;10%(1997est.)
Irrigated land: 7,700 sq km (1997 est.)
Natural hazards: seasonally high winds (the
pampero is a chilly and occasional violent wind which
blows north from the Argentine pampas), droughts,
floods; because of the absence of mountains, which
act as weather barriers, all locations are particularly
vulnerable to rapid changes in weather fronts
Environment - current issues: water pollution from
meat packing/tannery industry: inadequate solid/
hazardous waste disposal
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: ClimMe Change-Kyoto
Protocol, Marine Dumping, Marine Life Conservation
f . . .
Population: 3,334,074 (July 2000 est.)
Age structure:
0-14 years: 24% (male 417,288; female 397,125)
15-64 years: 63% (male 1 ,030,201 ; female
1,057,968)
65 years and over: 13% (male 178,393; female
253,099) (2000 est.)
Population growth rate: 0.77% (2000 est.)
Birth rate: 17.42 births/1,000 population (2000 est.)
Death rate: 9.06 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.63 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 15.14 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 75.24 years
male: 71 .9 years
female: 78.75 years (2000 est.)
Total fertility rate: 2.37 children born/woman
(2000 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian, practically nonexistent
Religions: Roman Catholic 66% (less than one-half
of the adult population attends church regularly),
Protestant 2%, Jewish 2%, nonprofessinq or other
30%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 1 5 and over can read and write
total population: 97.3%
male: 96.9%
female: 97.7% (1995 est.)
Country name:
conventional long form: Oriental Republic of Uruguay
conventional short form: Uruguay
local long form: Republica Oriental del Uruguay
local short form: Uruguay
Data code: UY
Government type: republic
Capital: Montevideo
Administrative divisions: 1 9 departments
(departamentos, singular - departamento); Artigas,
Canelones, Cerro Largo, Colonia, Durazno, Flores,
Florida, Lavalleja, Maldonado, Montevideo,
Paysandu, Rio Negro, Rivera, Rocha, Salto, San
Jose, Soriano, Tacuarembo, Treinta y Tres
Independence: 25 August 1825 (from Brazil)
National holiday: Independence Day, 25 August
(1825)
Constitution: 27 November 1966, effective
February 1967, suspended 27 June 1973, new
constitution rejected by referendum 30 November
1980; two constitutional reforms approved by
plebiscite 26 November 1989 and 7 January 1997
Legal system: based on Spanish civil law system;
accepts compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: President Jorge BATLLE (since 1
March 2000) and Vice President Luis HIERRO (since
1 March 2000); note - the president is both the chief of
state and head of government
head of government: President Jorge BATLLE (since
1 March 2000) and Vice President Luis HIERRO
(since 1 March 2000); note - the president is both the
chief of state and head of government
cabinet: Council of Ministers appointed by the
president with parliamentary approval
elections: president and vice president elected on the
same ticket by popular vote for five-year terms;
election last held 31 October 1 999 with run-off election
on 28 November 1999 (next to be held NA 2004)
election resu/fs; Jorge BATLLE elected president;
percent of vote - 52% in a runoff against Tabare
VAZQUEZ
Legislative branch: bicameral General Assembly or
Asamblea General consists of Chamber of Senators
or Camara de Senadores (30 seats; members are
elected by popular vote to serve five-year terms) and
Chamber of Representatives or Camara de
524
Uruguay (continued)
Representantes (99 seats; members are elected by
popular vote to serve five-year terms)
elections: Chamber of Senators - last held 31 October
1999 (next to be held NA 2004); Chamber of
Representatives - last held 31 October 1999 (next to
be held NA 2004)
election results: Chamber of Senators - percent of
vote by party - NA; seats by party - Encuentro
Progresista 12, Colorado Party 10, Blanco 7, New
Sector/Space Coalition 1; Chamber of
Representatives - percent of vote by party - NA; seats
by party - Encuentro Progresista 40, Colorado Party
33, Blanco 22, New Sector/Space Coalition 4
Judicial branch: Supreme Court, judges are
nominated by the president and elected for 10-year
terms by the General Assembly
Political parties and leaders: Batllelst faction of the
Colorado Party [Julio M. SANGUINETTIj; Broad Front
Coalition [Tabare VAZQUEZ]; Colorado Party [Jorge
BATLLE]; Herrerista faction of the National Party [Luis
A. LACALLEj; Herrero Wilsonista faction of the
National Party [Alaberto VOLONTEj; National Party or
Blanco [Luis A. LACALLEj; New Sector/Space
Coalition or Nuevo Espacio [Rafael MICHELINIj;
Progressive Encounter in the Broad Front or
Encuentro Progresista [Tabare VAZQUEZ]
International organization participation: CCC,
ECLAC, FAQ, G-11, G-77, lADB, IAEA, IBRD, ICAQ,
ICC, ICRM, IFAD, IFC, IFRCS, IRQ, ILO, IMF, IMO,
Intelsat, Interpol, IQC, lOM, ISQ, ITU, LAES, LAIA,
Mercosur, MINURSQ, MQNUC, NAM (observer),
QAS, QPANAL, QPCW, PCA, RG, UN, UNCTAD,
UNESCO, UNIDO, UNIKOM, UNMOGIP, UNMOT,
UNOMIG, UNTAET, UPU, WCL, WFTU, WHO,
WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
cWef of m/ss/orr; Ambassador Alvaro DIEZ DE
MEDINA Suarez
chancery: 271 5 M Street, NW, Washington, DC
20007
telephone: [1] (202) 331-1313 through 1316
FAX; [11(202)331-8142
consulate(s) general: Chicago, Los Angeles, Miami,
and New York
Diplomatic representation from the US:
chief of mission: Ambassador Christopher C. ASHBY
embassy: Lauro Muller 1776, Montevideo
mailing address: APO AA 34035
telephone: [598] (2) 23 60 61 , 48 77 77
FAX; [598] (2) 48 8611
Flag description: nine equal horizontal stripes of
white (top and bottom) alternating with blue; there is a
white square in the upper hoist-side corner with a
yellow sun bearing a human face known as the Sun of
May and 16 rays alternately triangular and wavy
Economy - overview: Uruguay''s economy is
characterized by an export-oriented agricultural
sector, a well-educated workforce, relatively even
income distribution, and high levels of social
spending. After averaging growth of 5% annually in
1996-98, in 1999 the economy suffered from lower
demand in Argentina and Brazil, which together
account for about half of Uruguay''s exports. Despite
the severity of the trade shocks and ensuing
recession, Uruguay''s financial indicators remained
more stable than those of its neighbors, a reflection of
its solid reputation among investors and its,
investment-grade sovereign bond rating - one of only
two in Latin America. Challenges for the government
of incoming President Jorge BATLLE include
expanding Uruguay''s trade ties beyond its Mercosur
trade partners and bolstering Uruguay''s
competitiveness by increasing labor market flexibility
and reducing the costs of public services. Grovrth
should recover in 2000, to perhaps 3%.
GDP: purchasing power parity - $28 billion
(1999 est.)
GDP - real growth rate: -2.5% (1999 est.)
GDP - per capita: purchasing power parity - $8,500
(1999 est.)
GDP - composition by sector:
agriculture: 10%
industry: 28%
semces;62%(1999)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: Hk%
Inflation rate (consumer prices): 4% (1999 est.)
Labor force: 1 .38 million (1 997 est.)
Labor force ■ by occupation: agriculture NA%,
industry NA%, services NA%
Unemployment rate: 12% (1999)
Budget:
revenues: $4.4 billion
expenditures: $4.6 billion, including capital
expenditures of $500 million (1998 est.)
Industries: food processing, electrical machinery,
transportation equipment, petroleum products,
textiles, chemicals, beverages
Industrial production growth rate: -4% (1999 est.)
Electricity - production: 9.474 billion kWh (1998)
Electricity - production by source:
fossil fuel: 2.d1%
hydro: 95.62%
nuclear: 0%
other; 0.47% (1998)
Electricity - consumption: 6.526 billion kWh (1 998)
Electricity - exports: 2.363 billion kWh (1998)
Electricity - imports: 78 million kWh (1998)
Agriculture - products: wheat, rice, barley, corn,
sorghum; livestock; fish
Exports: $2.1 billion (f.o.b., 1999 est.)
Exports - commodities: meat, rice, leather
products, vehicles, dairy products, wool, electricity
Exports - partners: Mercosur partners 45%, EU
20%, US 7% (1999 est.)
Imports: $3.4 billion (f.o.b., 1999 est.)
Imports - commodities: road vehicles, electrical
machinery, metal manufactures, heavy industrial
machinery, crude petroleum
Imports - partners: MERCOSUR partners 43%, EU
20%, US 11% (1999 est.)
Debt - external: $8 billion (1999 est.)
Economic aid - recipient: $NA
Currency: 1 Uruguayan peso ($Ur) = 100
centesimos
Exchange rates: Uruguayan pesos ($Ur) per US$1 -
11.3393 (1999), 10.4719 (1998), 9.4418 (1997),
7.9718 (1996), 6.3490 (1995), 5.0439 (1994)
Fiscal year: calendar year
I C 0 in m u n i c a f l o n s
Telephones - main lines in use: 622,000 (1995)
Telephones - mobile cellular: 40,000 (1995)
Telephone system: some modern facilities
domestic: most modern facilities concentrated in
Montevideo; new nationwide microwave radio relay
network
international: satellite earth stations - 2 Intelsat
(Atlantic Qcean)
Radio broadcast stations: AM 94, FM 1 1 5,
shortwave 14 (seven are inactive) (1998)
Radios: 1.97 million (1997)
Television broadcast stations: 26 (plus ten
low-power repeaters for the Montevideo station)
(1997)
Televisions: 782,000(1997)
Internet Service Providers (ISPs): 5 (1999)
™ -p j, g g p 0 rl a t ion ^
Railways:
total: 2,073 km
standard gauge: 2,073 km 1.435-m gauge (1997)
Highways:
total: 8,983 km
paved: 8,085 km
unpaved: 898 km (1 999 est.)
Waterways: 1 ,600 km; used by coastal and
shallow-draft river craft
Ports and harbors: Fray Bentos, Montevideo,
Nueva Palmira, Paysandu, Punta del Este, Colonia,
Piriapolis
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 1 ,807 GRT/
2,405 DWT
ships by type: petroleum tanker 1 (1 999 est.)
Airports: 65 (1999 est.)
Airports - with paved runways:
total: 15
2,438 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m:1 (1999 est.)
Airports - with unpaved runways:
total: 50
1,524 to 2,437 m: 2
914 to 1,523 m: 15
under 914 m: 33 (1 999 est.)
525
Uruguay (continued)
I M i ii t a r y
Military branches: Army, Navy (includes Naval Air
Arm, Coast Guard, Marines), Air Force, Police
(Coracero Guard, Grenadier Guard)
Military manpower - availability:
males age t5-49; 81 0,490 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 656,492 (2000 est.)
Military expenditures ■ dollar figure: $172 million
(FY98)
Military expenditures - percent of GDP: 0.9%
(FY98)
I f^ransnational issues
Disputes - international: two short sections of the
boundary with Brazil are in dispute - Arroyo de la
Invernada (Arroio Invernada) area of the Rio Cuareim
(Rio Quarai) and the islands at the confluence of the
Rio Cuareim (Rio Quarai) and the Uruguay River
I r n t r 0 d u c 1 1 o n
Background: Russia conquered Uzbekistan in the
late 19th century. Stiff resistance to the Red Army
after World War I was eventually suppressed and a
socialist republic set up in 1 925. During the Soviet era,
intensive production of "white gold" (cotton) and grain
led to overuse of agrochemicals and the depletion of
water supplies, which have left the land poisoned and
the Aral Sea and certain rivers half dry. Independent
since 1991, the country seeks to gradually lessen its
dependence on agriculture while developing its
mineral and petroleum reserves. Current concerns
include terrorism by Islamic militant groups from
Tajikistan and Afghanistan, a non-convertible
currency, and the curtailment of human rights and
democratization.
i’ '' d e o''g’r a p’h y '' . .
Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Commonwealth of Independent
States
Area:
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 6,221 km
border counfr/es.'' Afghanistan 137 km, Kazakhstan
2,203 km, Kyrgyzstan 1,099 km, Tajikistan 1,161 km,
Turkmenistan 1,621 km
Coastline: 0 km
note: Uzbekistan includes the southern portion of the
Aral Sea with a 420 km shoreline
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in east
Terrain: mostly flat-to-rolling sandy desert with
dunes; broad, flat intensely irrigated river valleys
along course of Amu Darya, Sirdaryo (Syr Darya), and
Zarafshon; Fergana Valley in east surrounded by
mountainous Tajikistan and Kyrgyzstan; shrinking
Aral Sea in west
Elevation extremes:
towesfpo/nt; Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal,
gold, uranium, silver, copper, lead and zinc, tungsten,
molybdenum
Land use:
arable land: 9%
permanent crops: 1%
permanent pastures: 46%
forests and woodland: 3%
other: 41% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: drying up of the Aral
Sea is resulting in growing concentrations of chemical
pesticides and natural salts; these substances are
then blown from the increasingly exposed lake bed
and contribute to desertification; water pollution from
industrial wastes and the heavy use of fertilizers and
pesticides is the cause of many human health
disorders; increasing soil salination; soil
contamination from agricultural chemicals, including
DDT
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: along with Liechtenstein, one of
the only two doubly landlocked countries in the world','1fc78cd54a52ebaad80ae608e979ca5f68393a67c2639389a896aff191884bf3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a491678e61848a0771e505fc8ac0341789808124531849269b5ee382b3ff536',2000,'VU','Vanuatu','economy',480,'Economy - overview: Vietnam is a poor, densely
populated country that has had to recover from the
ravages of war, the loss of financial support from the
old Soviet Bloc, and the rigidities of a centraily
pianned economy. Substantiai progress was achieved
from 1986 to 1996 in moving forward from an
extremely low starting point - growth averaged around
9% per year from 1 993 to 1 997. The 1 997 Asian
financial crisis highiighted the probiems existing in the
Vietnamese economy but, rather than prompting
reform, reaffirmed the government''s beiief that shifting
to a market oriented economy ieads to disaster. GDP
growth of 8.5% in 1997 feii to 4% in 1998 and rose
siightiy to an estimated 4.8% in 1 999. These numbers
masked some major difficuities that are emerging in
economic performance. Many domestic industries,
including coal, cement, steel, and paper, have
reported large stockpiles of inventory and tough
competition from more efficient foreign producers.
Foreign direct investment has faiien dramaticaily, from
$8.3 biliion in 1 996 to about $1 .6 biiiion in 1 999.
Meanwhiie, Vietnamese authorities have slowed
implementation of the structurai reforms needed to
revitalize the economy and produce more competitive,
export-driven industries. Privatization of state
enterprises remains bogged down in poiitical
controversy, while the country''s dynamic private
sector is denied both financing and access to markets.
Reform of the banking sector - considered one of the
riskiest in the worid - is proceeding slowly, raising
concerns that the country wiii be unabie to tap
sufficient domestic savings to finance growth.
Administrative and legal barriers are also causing
costiy delays for foreign investors and are raising
simiiar doubts about Vietnam''s abiiity to attract
additionai foreign capital.
GDP: purchasing power parity -$143.1 biiiion
(1999 est.)
GDP - real growth rate: 4.8% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,850
(1999 est.)
GDP ■ composition by sector:
agriculture: 26%
Industry: 33%
serv/ces; 41% (1998 est.)
Population below poverty line: 37% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: 3.5%
highest 10%: 29% (1993)
Inflation rate (consumer prices): 4% (1999 est.)
Labor force: 38.2 million (1998 est.)
534
Vistnam (continued)
Labor force - by occupation: agriculture 67%,
industry and services 33% (1997 est.)
Unemployment rate: 25% (1995 est.)
Budget:
revenues: $5.6 biiiion
expenditures: $6 biiiion, including capitai
expenditures of $1 .7 biiiion (1996 est.)
Industries: food processing, garments, shoes,
machine buiiding, mining, cement, chemicai fertiiizer,
glass, tires, oii, coal, steel, paper
Industrial production growth rate: 10.3%
(1999 est.)
Electricity - production: 20.62 billion kWh (1998)
Electricity - production by source:
fossil fuel: 12.95%
hydro: 87.05%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 19.177 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: paddy rice, corn, potatoes,
rubber, soybeans, coffee, tea, bananas; poultry, pigs;
fish
Exports: $1 1 .5 billion (f.o.b., 1 999 est.)
Exports ■ commodities: crude oil, marine products,
rice, coffee, rubber, tea, garments, shoes
Exports ■ partners: Japan, Germany, Singapore,
Taiwan, Hong Kong, France, South Korea, US, China
Imports: $1 1 .6 billion (f.o.b., 1 999 est.)
Imports - commodities: machinery and equipment,
petroleum products, fertilizer, steel products, raw
cotton, grain, cement, motorcycles
Imports - partners: Singapore, South Korea, Japan,
France, Hong Kong, Taiwan, Thailand, Sweden
Debt - external: $7.3 billion Western countries; $4.5
billion CEMA debts primarily to Russia; $9 billion to
$18 billion nonconvertible debt (former CEMA, Iraq,
Iran)
Economic aid - recipient: $2 billion in credits and
grants pledged by international donors for 1999 and
again for 2000
Currency: 1 new dong (D) = 100 xu
Exchange rates: new dong (D) per US$1 - 14,020
(January 2000), 13,900 (December 1998), 11,100
(December 1 996), 1 1 ,1 93 (1 995 average), 1 1 ,000
(October 1994), 10,800 (November 1993)
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 775,000 (1995)
Telephones - mobile cellular: 1 78,000 (1 998)
Telephone system: while Vietnam''s
telecommunication sector lags far behind other
countries in Southeast Asia, Hanoi has made
considerable progress since 1991 in upgrading the
system; Vietnam has digitalized all provincial switch
boards, while fiber-optic and microwave transmission
systems have been extended from Hanoi, Da Nang,
and Ho Chi Minh City to all provinces; the density of
telephone receivers nationwide doubled from 1993 to
1 995, but is still far behind other countries in the
region
domestic: NA
international: satellite earth stations - 2 Intersputnik
(Indian Ocean region)
Radio broadcast stations: AM 65, FM 7, shortwave
29(1999)
Radios: 8.2 million (1997)
Television broadcast stations: at least 7 (plus 13
repeaters) (1998)
Televisions: 3.57 million (1997)
Internet Service Providers (ISPs): 5 (1999)
I t rahsportation
Railways:
total: 2,652 km
standard gauge: too km 1.435-m gauge
narrow gauge: 2, 2A0 km 1.000-m gauge
dual gauge: 237 km NA-m gauges (three rails) (1 998)
Highways:
total: 93,300 km
paved; 23,41 8 km
unpaved: 69,882 km (1996 est.)
Waterways; 17,702 km navigable; more than 5,149
km navigable at all times by vessels up to 1 .8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang,
Haiphong, Ho Chi Minh City, Hong Gai, Qui Nhon,
Nha Trang
Merchant marine:
total: 1 33 ships (1 ,000 GRT or over) totaling 61 6,1 1 5
GRT/941,611 DWT
ships by type: bulk 7, cargo 103, chemical tanker 1 ,
combination bulk 1, container 1, liquified gas 1,
petroleum tanker 15, refrigerated cargo 4 (1999 est.)
Airports: 48 (1999 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m: 8
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 7 (1994 est.)
Airports - with unpaved runways:
fofa/;12
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 5 (1994 est.)
^ g |. y ""
Military branches: People''s Army of Vietnam
(PAVN) (includes Ground Forces, Navy, and Air
Force), Coast Guard
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 21 ,149,579 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 13,335,337 (2000 est.)
Military manpower - reaching military age
annually:
mates; 949,532 (2000 est.)
Military expenditures - dollar figure: $650 million
(FY98)
Military expenditures - percent of GDP: 2.5%
(FY98)
I Tran s n a t i o n a I Issues
Disputes - international: maritime boundary with
Cambodia not defined; involved in a complex dispute
over the Spratly Islands with China, Malaysia,
Philippines, Taiwan, and possibly Brunei; maritime
boundary with Thailand resolved, August 1997;
maritime boundary dispute with China in the Gulf of
Tonkin; Paracel Islands occupied by China but
claimed by Vietnam and Taiwan; offshore islands and
sections of boundary with Cambodia are in dispute;
agreement on land border with China was signed in
December 1999, but details of alignment have not
been made public
Illicit drugs: minor producer of opium poppy with
2,100 hectares cultivated in 1999, capable of
producing 1 1 metric tons of opium; probably minor
transit point for Southeast Asian heroin destined for
the US and Europe; growing opium/heroin addiction;
possible small-scale heroin production
535
Background; During the 17th century, the
archipelago was divided into two territorial units, one
English and the other Danish. Sugarcane, produced
by slave labor, drove the islands'' economy during the
18th and early 19th centuries. In 1917, the US
purchased the Danish portion, which had been in
economic decline since the abolition of slavery in
1848.
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean, east of','375bbe5e70a742fdcd74cf89f6dcc1f5e6f6f255df19b56fb684940c4e62886c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5382ba7bc08308c40d1b72bd6f921b851e78408c78b8a1417d458f340ff1a09',2000,'PR','Puerto Rico','economy',481,'Geographic coordinates; 1 8 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area;
total: 352 sq km
land: 349 sq km
water: 3 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries; 0 km
Coastline; 188 km
Maritime claims:
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Climate: subtropical, tempered by easterly trade
winds, relatively low humidity, little seasonal
temperature variation; rainy season May to November
Terrain: mostly hilly to rugged and mountainous with
little level land
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use;
arable land: 15%
permanent crops: 6%
permanent pastures: 26%
forests and woodland: 6%
ofher;47%{1993est.)
Irrigated land: NAsqkm
Natural hazards: several hurricanes in recent years;
frequent and severe droughts and floods; occasional
earthquakes
Environment - current issues: lack of natural
freshwater resources
Geography - note; important location along the
Anegada Passage - a key shipping lane for the
Panama Canal; Saint Thomas has one of the best
natural, deepwater harbors in the Caribbean
’"■peopfe'''' ''
Population: 120,917 (July 2000 est.)
Age structure;
0-14 years: 27. S% (male 17,258; female 16,359)
15-64 years: 63.72% (male 35,026; female 42,021)
65 years and oven 8.48% (male 4,435; female 5,81 8)
(2000 est.)
Population growth rate; 1.07% (2000 est.)
Birth rate: 15.96 births/1,000 population (2000 est.)
Death rate: 5.36 deaths/1,000 population
(2000 est.)
Net migration rate: 0.12 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0,83 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.B6 male(s)/female (2000 est.)
Infant mortality rate: 9.64 deaths/l ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 78.11 years
male: 74.2 years
female: 82.25 years (2000 est.)
Total fertility rate: 2.27 children born/woman
(2000 est.)
Nationality:
noun: Virgin lslander(s)
adjective: Virgin Islander
Ethnic groups; black 80%, white 15%, other 5%
note: West Indian (45% bom in the Virgin Islands and
29% born elsewhere in the West Indies) 74%, US
mainland 13%, Puerto Rican 5%, other 8%
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English (official), Spanish, Creole
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
I " ’^''v e^^rTTm e ii t
Country name;
conventional long form: Virgin Islands of the United
States
conventional short form: Virgin Islands
former: Danish West Indies
Data code; VQ
Dependency status: organized, unincorporated
territory of the US with policy relations between the
Virgin Islands and the US under the jurisdiction of the
Office of Insular Affairs, US Department of the Interior
Government type; NA
Capital: Charlotte Amalie
Administrative divisions: none (territory of the US);
there are no first-order administrative divisions as
defined by the US Government, but there are three
islands at the second order; Saint Croix, Saint John,
Saint Thomas
National holiday: Transfer Day, 31 March (1917)
(from Denmark to US)
Constitution: Revised Organic Act of 22 July 1 954
Legal system: based on US laws
Suffrage: 18 years of age; universal; note -
indigenous inhabitants are US citizens but do not vote
in US presidential elections
Executive branch:
chief of state: President William Jefferson CLINTON
of the US (since 20 January 1993); Vice President
Albert GORE, Jr. (since 20 January 1993)
head of government: Governor Dr. Charles Wesley
TURNBULL (since 5 January 1999) and Lieutenant
Governor Gererd LUZ James II (since 5 January
1999)
cabinet: NA
elections: US president and vice president elected on
the same ticket for four-year terms; governor and
lieutenant governor elected on the same ticket by
popular vote for four-year terms; election last held 3
November 1998 (next to be held NA November 2002)
election results: Dr. Charles Wesley TURNBULL
elected governor; percent of vote - Dr. Charles W.
TURNBULL (Democrat) 58.9%, former Governor Roy
L. SCHNEIDER (ICM) 41.1%
Legislative branch: unicameral Senate (15 seats;
members are elected by popular vote to serve
two-year terms)
elections: last held 3 November 1 998 (next to be held
NA November 2000)
election results: percent of vote by party - NA; seats
by party - Democratic Party 6, Republican Party 2,
ICM 2, independents 5
note: the Virgin Islands elect one representative to the
US House of Representatives; election last held 3
November 1 §98 (next to be held NA November 2000);
results - Dr. Donna GREEN (Democrat) 80%, Victor
0. FRAZER (ICM) 20%
Judicial branch: US District Court, judges are
appointed by the president; Territorial Court, judges
appointed by the governor
Political parties and leaders: Democratic Party
[James O''BRYAN, Jr.]; Independent Citizens''
Movement or ICM [Virdin C. BROWN]; Republican
Party [James OLIVER]
International organization participation; ECLAC
(associate), Interpol (subbureau), IOC
Virgin Islands (continued)
Diplomatic representation in the US: none
(territory of the US)
Diplomatic representation from the US: none
(territory of the US)
Flag description: white, with a modified US coat of
arms in the center between the iarge blue initials V
and I; the coat of arms shows a yellow eagle holding
an olive branch in one talon and three arrows in the
other with a superimposed shield of vertical red and
white stripes below a blue panel
'' I p 0 n 0 m y
Economy - overview: Tourism is the primary
economic activity, accounting for more than 70% of
GDP and 70% of employment. The islands normally
host 2 million visitors a year. The manufacturing
sector consists of petroleum refining, textile,
electronics, pharmaceutical, and watch assembly
plants. The agricultural sector is small, with most food
being imported, international business and financial
services are a small but growing component of the
economy. One of the world''s largest petroleum
refineries is at Saint Croix. The islands are subject to
substantial damage from storms.
GDP: purchasing power parity - $1 .8 billion
(1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$15,000(1999 est.)
GDP ■ composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 47,443 (1990 est.)
Labor force - by occupation: agriculture 1%,
industry 20%, services 79% (1990 est.)
Unemployment rate: 4.9% (March 1999)
Budget:
revenues: $364.4 million
expenditures: $364.4 million, including capital
expenditures of $NA (1990 est.)
Industries: tourism, petroleum refining, watch
assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Industrial production growth rate: NA%
Electricity - production: 1 .01 9 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%(im)
Electricity - consumption: 948 million kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: fruit, vegetables, sorghum;
Senepol cattle
Exports: $NA
Exports - commodities: refined petroleum products
Exports - partners: US, Puerto Rico
Imports: $NA
Imports - commodities: crude oil, foodstuffs,
consumer goods, building materials
Imports - partners: US, Puerto Rico
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October - 30 September
I" 0 m nuTn i c a fi o n s^^ ™
Telephones - main lines in use: 58,000 (1995)
Telephones - mobile cellular: 2,000 (1992)
Telephone system:
domestic: modern, uses fiber-optic cable and
microwave radio relay
international: submarine cable and satellite
communications; satellite earth stations - NA
Radio broadcast stations: AM 5, FM 1 1 , shortwave
0(1998)
Radios: 107,000(1997)
Television broadcast stations: 2 (1997)
Televisions: 68,000 (1997)
Internet Service Providers (ISPs): 2 (1 999)
|~ " T r^ IT s p o r t aTTo iir
Railways: 0 km
Highways:
total: 856 km
paved: NA km
unpaved: NA km
Ports and harbors: Charlotte Amalie, Christiansted,
Cruz Bay, Port Alucroix
Merchant marine: none (1999 est.)
Airports: 2
note: international airports on Saint Thomas and Saint
Croix (1999 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m; 2 (1999 est.)
I ^ ^ STT l r t a r y" ” •
Military - note: defense is the responsibility of the
US
1^ f r a rTs n a t i 0 n al I Ts u e s ~
Disputes - international: none
Location: Oceania, atoll in the North Pacific Ocean,
about two-thirds of the way from Hawaii to the','80b86342c014a2c279b09ce637b8689b890c88c3e6c385b896da6f91d8e724b5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f235925289de7227c2e6c0693db248366a0ecbcc8d101c26b6073d22734e71b3',2000,'MP','Northern Mariana Islands','economy',482,'Geographic coordinates: 19 17 N, 166 36 E
Map references: Oceania
Area:
total: 6.5 sq km
land: 6.5 sq km
wafer; 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims:
exclusive economic zone: 200 nm
ferr/tor/a/ sea; 12 nm
Climate; tropical
Terrain; atoll of three coral islands built up on an
underwater volcano; central lagoon is former crater,
islands are part of the rim
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 6 m
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1998)
Natural hazards: occasional typhoons
Environment - current issues: NA
Geography - note: strategic location in the North
Pacific Ocean; emergency landing location for
transpacific flights
537
Wake Island (continued)','f20c04c7dbe718f5092aad5d1c4dc843ef2b4f4182067eb6d81f972b900a3073','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4330cdd615e22a37f6cc1f00cbb17e2464b2f81022313ee9d213b1531d0e6943',2000,'SA','Saudi Arabia','economy',488,'\\oMAN
N Habarut^.
\\ f , no defined \\ , — >
? IX Sa’dah boundary 3 — ^
J Al Ghayf^ah^-^
[SAN^ *Saywun jNIshtun
\\ ® .yarlb
0®%AI Hudaydah Arabian
^_/AI Mukalla Sea
, -■ ) Ja''izz
,a«)T.\\Mocha /
Gulf Of Aden
gJIflOUTI
Socotra','ca4881cce4a78ef80eec3e186be13e7428be8a9788809670e5b533b7dd6588f4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e4417d1c109909362fcbb72f79ec1065dc45e1ec9c08fd1e4d026a715ca22e9',2000,'SO','Somalia','economy',489,'ETHIOPW"^^
i Indian
\\ Ocean
I n t r 0 d u c t To^ n
Background; North Yemen became independent of
the Ottoman Empire in 1 91 8. The British, who had set
up a protectorate area around the southern port of
Aden in the 19th century, withdrew in 1967 from what
became South Yemen. Three years later, the
southern government adopted a Marxist orientation.
The massive exodus of hundreds of thousands of
Yemenis from the south to the north contributed to two
decades of hostility between the states. The two
countries were formally unified as the Republic of
Yemen in 1 990. A southern secessionist movement in
1994 was quickly subdued.
I Geography
Location; Middle East, bordering the Arabian Sea,
Gulf of Aden, and Red Sea, between Oman and Saudi
Arabia
Geographic coordinates; 15 00 N, 48 00 E
Map references; Middle East
Area;
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen
Arab Republic (YAR or North Yemen), and the former
People''s Democratic Republic of Yemen (PDRY or
South Yemen)
Area - comparative: slightly larger than twice the
size of Wyoming
Land boundaries:
fofa/; 1,746 km
border countries: Oman 288 km, Saudi Arabia 1,458
km
Coastline; 1,906 km
Maritime claims:
contiguous zone: 18 nm in the North; 24 nm in the
South
continental shelf: 200 nm or to the edge of the
continental margin
545
Yemen (continued)
exclusive economic zone: 200 nm
territorial sea: nm
Climate: mostly desert; hot and humid along west
coast; temperate in western mountains affected by
seasonal monsoon; extraordinarily hot, dry, harsh
desert in east
Terrain; narrow coastal plain backed by flat-topped
hills and rugged mountains; dissected upland desert
plains in center slope into the desert interior of the
Arabian Peninsula
Elevation extremes;
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt,
marble, small deposits of coal, gold, lead, nickel, and
copper, fertile soil in west
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 30%
forests and woodland: 4%
off)er;63%(1993 est.)
Irrigated land: 3,600 sq km (1993 est.)
Natural hazards: sandstorms and dust storms in
summer
Environment - current issues: very limited natural
fresh water resources; inadequate supplies of potable
water; overgrazing; soil erosion; desertification
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Bab el
Mandeb, the strait linking the Red Sea and the Gulf of
Aden, one of world''s most active shipping lanes','f82723932633536f1d54fac7f77239bffc7bf0095a0cb1ddc8f81b730025ce92','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

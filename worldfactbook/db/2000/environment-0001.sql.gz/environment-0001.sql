SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eddc85c9b7047be40cb88c8bceac5190ee6eab4484e90c25ce9a7b35400083e8',2000,'EH','Western Sahara','environment',9,'Notes and Definitions (continued)
soil degradation - damage to the land''s productive capacity because of poor
agricultural practices such as the excessive use of pesticides and fertilizers, soil
compaction from heavy equipment, or erosion of top soil, eventually resulting in
reduced ability to produce agricultural products.
soil erosion - the removal of soil by the action of water or wind, compounded
by poor agricultural practices, deforestation, overgrazing, and desertification.
ultra-violet (UV) radiation - a portion of the electromagnetic energy emitted by
the sun and naturally filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has been linked to increasing
rates of skin cancer in humans.
water-born diseases - those in which the bacteria survive in, and is transmitted
through, water; always a serious threat in areas with an untreated water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels - party to
and signed but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix D:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups starting with
the largest and normally includes the percent of total population.
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date or over a given period of time, as expressed in units of local
currency per US dollar and as determined by international market forces or official
fiat.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day
activities of the government. Cab/nef includes the official name for this body of
high-ranking advisers and the method for selection of members. Elections includes
the nature of election process or accession to power, date of the last election, and
date of the next election. Election results includes the percent of vote for each
candidate in the last election. In the UK, the monarch is the chief of state, and the
prime minister is the head of government. In the US, the president is both the chief
of state and the head of government.
Exports: This entry provides the total US dollar amount of exports on an f.o.b.
(free on board) basis.
Exports - commodities: This entry provides a rank ordering of exported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Exports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
XIV
Notes and Definitions (continued)
Fiscal year: This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the caiendar year but which may
begin in any month. Ali yearly references are for the calendar year (CY) unless
indicated as a noncalendar fiscal year (FY).
Flag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the
best information available at the time of preparation. The flags of independent
states are used by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all final goods
and services produced within a nation in a given year. GDP dollar estimates in the
Factbook are derived from purchasing power parity (PPP) calculations. See the
note on GDP methodofogy for more information.
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations rather than
from conversions at official currency exchange rates. The PPP method involves
the use of standardized international dollar price weights, which are applied to the
quantities of final goods and services produced in a given economy. The data
derived from the PPP method provide the best available starting point for
comparisons of economic strength and well-being between countries. The division
of a GDP estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries are often
rough approximations. Most of the GDP estimates are based on extrapolation of
PPP numbers published by the UN International Comparison Program (UNICP)
and by Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. In contrast, the currency exchange rate
method involves a variety of international and domestic financial forces that often
have little relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically one-fourth to
one-half the PPP estimate. Furthermore, exchange rates may suddenly go up or
down by 1 0% or more because of market forces or official fiat whereas real output
has remained unchanged. On 12 January 1994, for example, the 14 countries of
the African Financial Community (whose currencies are tied to the French franc)
devalued their currencies by 50%. This move, of course, did not cut the real output
of these countries by half. One important caution: the proportion of, say, defense
expenditures as a percentage of GDP in local currency accounts may differ
substantially from the proportion when GDP accounts are expressed in PPP
terms, as, for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: the numbers for GDP and other
economic data can nof be chained together from successive volumes of the
Factbook because of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information, and changes in
national statistical methods and practices.
XV
Notes and Definitions (continued)
GDP - composition by sector; This entry gives the percentage contribution of
agriculture, industry, and services to total GDP.
GDP - per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 Juiy for the same year.
GDP - real growth rate; This entry gives GDP growth on an annual basis adjusted
for infiation and expressed as a percent.
Geographic coordinates: This entry inciudes rounded iatitude and iongitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1 988,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix H:
Cross-Reference List of Geographic Names which indicates where various
geographic names - including aiternate names, former names, poiiticai or
geographical portions of larger entities, and the location of ali US Foreign Service
posts - can be found in The World Factbook. Spellings are normaliy, but not
aiways, those approved by the US Board on Geographic Names (BGN). Aiternate
names are included in parentheses, while additional information is included in
brackets.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being.
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g., republic,
constitutional monarchy, federal republic, parliamentary democracy, military
dictatorship).
Government - note: This entry includes miscellaneous government information
of significance not included elsewhere.
Gross domestic product; see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter takeoff and
landing sites (which may or may not have fuel or other services).
XVI
Notes and Definitions (continued)
Highways; This entry includes the total length of the highway system as well as
the length of the paved and unpaired components.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Illicit drugs: This entry gives information on the five categories of illicit drugs -
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxyluni coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanii, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(POP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
XVII
Notes and E>efinitions (continued)
Poppy straw concentrate is the alkaloid derived from the mature, dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
ephedrine, ecstasy (clarity, essence, doctor, Adam), phenmetrazine (Preludin),
methylphenidate (Ritalin), and others (Cylert, Sanorex, Tenuate).
Imports: This entry provides the total US dollar amount of imports on a c.i.f. (cost,
insurance, and freight) or f.o.b. (free on board) basis.
Imports - commodities: This entry provides a rank ordering of imported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Imports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Independence: For most countries, this entry gives the date that sovereignty was
achieved and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
"none" followed by the nature of their dependency status. Also see the
Terminology note.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births in the same year. This rate is often
used an indicator of the level of health in a country.
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previous year’s consumer prices.
Internet Service Providers (ISPs): This entry supplies the number of Internet
Service Providers within a country. An ISP is defined as a company that provides
access to the Internet.
International disputes: see Disputes - international
International organization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
xviii
Notes and Definitions (continued)
International organizations: This information is presented in Appendix C:
International Organizations and Groups which includes the name, abbreviation,
address, telephone, FAX, date established, aim, and members by category.
Introduction; This category includes one entry. Background.
Irrigated land; This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry contains a rank ordering of component
parts of the labor force by occupation.
Land boundaries; This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
Land use: This entry contains the percentage shares of total land area for five
different types of iand use: amble land - land cultivated for crops that are replanted
after each harvest like wheat, maize, and rice; permanent crops ■ land cultivated
for crops that are not replanted after each harvest like citrus, coffee, and rubber;
permanent pastures - land permanently used for herbaceous forage crops; forests
and woodland- land under dense or open stands of trees; other- any land type
not specifically mentioned above, such as urban areas, roads, desert, etc.
Languages; This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International Court of
Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and term of office. Elections
includes the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as Indicating the potential return on investment in human capital and is necessary
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of iiteracy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition - the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
XIX
Notes and Definitions (continued)
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country''s regional location, neighboring
countries, and adjacent bodies of water.
Map references: This entry includes the name of the Factbook reference map on
which a country may be found. The entry on Geographic coordinates may be
helpful in finding some smaller countries.
Maritime ciaims: This entry includes the following claims: contiguous zone,
continental shelf, exclusive economic zone, exclusive fishing zone, extended
fishing zone, none (usually for a landlocked country), other (unique maritime
claims like Libya’s Gulf of Sidra Closing Line or North Korea''s Military Boundary
Line), and territorial sea. The proximity of neighboring states may prevent some
national claims from being extended the full distance.
Merchant marine: Merchant marine may be defined as all ships engaged in the
carriage of goods; or all commercial vessels (as opposed to all nonmilitary ships),
which excludes tugs, fishing vessels, offshore oil rigs, etc.; or a grouping of
merchant ships by nationality or register. This entry contains information in two
subfields - total and ships by type. Total includes the total number of ships (1 ,000
GRT or over), total DWT for those ships, and total GRT for those ships. Ships by
type includes a listing of barge carriers, bulk cargo ships, cargo ships, combination
bulk carriers, combination ore/oil carriers, container ships, intermodal ships,
liquefied gas tankers, livestock carriers, multifunction large-load carriers, oil
tankers, passenger ships, passenger-cargo ships, railcar carriers, refrigerated
cargo ships, roll-on/roll-off cargo ships, short-sea passenger ships, specialized
tankers, tanker tug-barges, and vehicle carriers.
A captive register is a register of ships maintained by a territory, possession,
or colony primarily or exclusively for the use of ships owned in the parent country;
it is also referred to as an offshore register, the offshore equivalent of an internal
register. Ships on a captive register will fly the same flag as the parent country, or
a local variant of it, but will be subject to the maritime laws and taxation rules of
the offshore territory. Although the nature of a captive register makes it especially
desirable for ships owned in the parent country, just as in the internal register, the
ships may also be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an independent state.
A flag of convenience register is a national register offering registration to a
merchant ship not owned in the flag state. The major flags of convenience (FOC)
attract ships to their registers by virtue of low fees, low or nonexistent taxation of
profits, and liberal manning requirements. True FOC registers are characterized by
having relatively few of the registered ships actually owned in the flag state. Thus,
while virtually any flag can be used for ships under a given set of circumstances,
an FOC register is one where the majority of the merchant fleet is owned abroad.
It is also referred to as an open register.
A flag state is the nation in which a ship is registered and which holds legal
jurisdiction over operation of the ship, whether at home or abroad. Maritime
legislation of the flag state determines how a ship is crewed and taxed and
whether a foreign-owned ship may be placed on the register.
XX
Notes and Definitions (continued)
An internal register is a register of ships maintained as a subset of a national
register. Ships on the interna! register fly the national flag and have that nationality
but are subject to a separate set of maritime rules from those on the main national
register. These differences usually include low/er taxation of profits, use of foreign
nationals as crew members, and, usually, ownership outside the flag state (when
it functions as an FOC register). The Norwegian International Ship Register and
Danish International Ship Register are the most notable examples of an internal
register. Both have been instrumental in stemming flight from the national flag to
flags of convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
A merchant ship is a vessel that carries goods against payment of freight; it is
commonly used to denote any nonmilitary ship but accurately restricted to
commercial vessels only.
A register is the record of a ship''s ownership and nationality as listed with the
maritime authorities of a country; also, it is the compendium of such individual
ships'' registrations. Registration of a ship prov','48fe3dffe78ee82309e4f767d879e10aa748949a9f23544191df365852d2aece','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('453cbdccfe264d083ef1533729c04a04be5777d79ca64194c7a52f29bb592cdc',2000,'EH','Western Sahara','environment',10,'ides it with a nationality and makes
it subject to the laws of the country in which registered (the flag state) regardless
of the nationality of the ship''s ultimate owner.
Military: This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military branches: This entry lists the names of the ground, naval, air, marine,
and other defense or security forces.
Military expenditures • dollar figure; This entry gives current military
expenditures in US dollars; the figure is calculated by multiplying the estimated
defense spending in percentage terms by the gross domestic product (GDP)
calculated on an exchange rate basis nof purchasing power parity (PPP) terms.
However, in the case of Russia, estimates of military expenditures have been
made using PPP. Dollar figures for military expenditures should be treated with
caution because of different price patterns and accounting methods among
nations, as well as wide variations in the strength of their currencies.
Military expenditures - percent of GDP: This entry gives current military
expenditures as an estimated percent of gross domestic product (GDP).
Military manpower - availability: This entry gives the total numbers of males and
females age 1 5-49 and assumes that every individual is fit to serve.
Military manpower - fit for military service: This entry gives the number of
males and females age 15-49 fit for military service. This is a more refined
measure of potential military manpower availability which tries to correct for the
health situation in the country and reduces the maximum potential number to a
more realistic estimate of the actual number fit to serve.
Military manpower - military age: This entry gives the minimum age at which an
individual may volunteer for military service or be subject to conscription.
Military manpower - reaching military age annually: This entry gives the
number of draft-age males and females entering the military manpower pool in any
given year and is a measure of the availability of draft-age young adults.
Military - note; This entry includes miscellaneous military information of
significance not included elsewhere.
XXI
Notes and Definitions (continued)
Money figures: All money figures are expressed in contemporaneous US dollars
unless otherwise indicated.
National holiday: This entry gives the primary national day of celebration -
usually independence day.
Nationality: This entry provides the identifying terms for citizens - noun and
adjective.
Natural hazards: This entry lists potential natural disasters.
Natural resources: This entry lists a country''s mineral, petroleum, hydropower,
and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference between the
number of persons entering and leaving a country during the year per 1 ,000
persons (based on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56 migrants/1 ,000 population); an
excess of persons leaving the country as net emigration (e.g., -9.26 migrants/
1 ,000 population). The net migration rate indicates the contribution of migration to
the overall level of population change. High levels of migration can cause problems
such as increasing unemployment and potential ethnic strife (if people are coming
in) or a reduction in the labor force, perhaps in certain key sectors (if people are
leaving).
People: This category includes the entries dealing with the characteristics of the
people and their society.
People - note: This entry includes miscellaneous demographic information of
significance not included elsewhere.
Personal Names - Capitalization: The Factoook capitalizes the surname or
family name of individuals for the convenience of our users who are faced with a
world of different cultures and naming conventions. An example would be
President SADDAM Husayn of Iraq. Saddam is hjs name and Husayn is his
father''s name. He may be referred to as President SADDAM Husayn or President
SADDAM, but not President Husayn. The need for capitalization, bold type,
underlining, italics, or some other indicator of the individual''s surname is apparent
in the following examples: MAO Zedong, Fidel CASTRO Ruz, William Jefferson
CLINTON, and TUNKU SALAHUDDIN Abdul Aziz Shah ibni Al-Marhum Sultan
Hisammuddin Alam Shah. By knowing the surname, a short form without all capital
letters can be used with confidence as in President Saddam, President Castro,
Chairman Mao, President Clinton, or Sultan Tunku Salahuddin. The same system
of capitalization is extended to the names of leaders with surnames that are not
commonly used such as Queen ELIZABETH II.
Personal Names - Spelling: The romanization of personal names in the Factbook
normally follows the same transliteration system used by the US Board on
Geographic Names for spelling place names. At times, however, a foreign leader
expressly indicates a preference for, or the media or official documents regularly
use, a romanized spelling that differs from the transliteration derived from the US
Government standard. In such cases, the Factbook uses the alternative spelling.
xxii
Notes and Definitions (continued)
Personal Names - Titles: The Factooo/c capitalizes any valid title (or short form of
it) immediately preceding a person''s name. A title standing alone is lowercased.
Examples: President PUTIN and President CLINTON are chiefs of state. In
Russia, the president is chief of state and the premier is the head of the
government, while in the US, the president is both chief of state and head of','3f2ffd0d20c7edf3d155ef1d4ed702705186732e8f2b439f1d51dc6ee7a35be3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e61af4a0975370dc6510bd83cb943fe897fbeb3c82410744eeb7a2b3cb024c86',2000,'ZW','Zimbabwe','environment',240,'soil degradation damage to the land''s productive capacity because of
poor agricultural practices such as the excessive use of pesticides
and fertilizers, soil compaction from heavy equipment, or erosion of
top soil, eventually resulting in reduced ability to produce
agricultural products.
soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
ultraviolet (UV) radiation - a portion of the electromagnetic energy
emitted by the sun and naturally filtered in the upper atmosphere by
the ozone layer; UV radiation can be harmful to living organisms and
has been linked to increasing rates of skin cancer in humans.
water-born diseases those in which the bacteria survive in, and is
transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two
levels - party to and signed but not ratified. Agreements are listed
in alphabetical order by the abbreviated form of the full name.
Environmental agreements: This information is presented in [6]Appendix
D: Selected International Environmental Agreements, which includes the
name, abbreviation, date opened for signature, date entered into
force, objective, and parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups
starting with the largest and normally includes the percent of total
population.
Exchange rates: This entry provides the official value of a country''s
monetary unit at a given date or over a given period of time, as
expressed in units of local currency per US dollar and as determined
by international market forces or official fiat.
Executive branch: This entry includes several subfields. Chief of
state includes the name and title of the titular leader of the country
who represents the state at official and ceremonial functions but may
not be involved with the day-to-day activities of the government. Head
of government includes the name and title of the top administrative
leader who is designated to manage the day-to-day activities of the
government. Cabinet includes the official name for this body of
high-ranking advisers and the method for selection of members.
Elections includes the nature of election process or accession to
power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in
the last election. In the UK, the monarch is the chief of state, and
the prime minister is the head of government. In the US, the president
is both the chief of state and the head of government.
Exports: This entry provides the total US dollar amount of exports on
an f.o.b. (free on board) basis.
Exports - commodities: This entry provides a rank ordering of exported
products starting with the most important; it sometimes includes the
percent of total dollar value.
Exports - partners: This entry provides a rank ordering of trading
partners starting with the most important; it sometimes includes the
percent of total dollar value.
Fiscal year: This entry identifies the beginning and ending months for
a country''s accounting period of 12 months, which often is the
calendar year but which may begin in any month. All yearly references
are for the calendar year (CY) unless indicated as a noncalendar
fiscal year (FY).
Flag description: This entry provides a written flag description
produced from actual flags or the best information available at the
time the entry was written. The flags of independent states are used
by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at
the beginning of the country profile. The flag graphics were produced
from actual flags or the best information available at the time of
preparation. The flags of independent states are used by their
dependencies unless there is an officially recognized local flag. Some
disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all
final goods and services produced within a nation in a given year. GDP
dollar estimates in the Factbook are derived from purchasing power
parity (PPP) calculations. See the note on GDP methodology for more
information.
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations
rather than from conversions at official currency exchange rates. The
PPP method involves the use of standardized international dollar price
weights, which are applied to the quantities of final goods and
services produced in a given economy. The data derived from the PPP
method provide the best available starting point for comparisons of
economic strength and well-being between countries. The division of a
GDP estimate in domestic currency by the corresponding PPP estimate in
dollars gives the PPP conversion rate. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. Most of the GDP estimates are based on
extrapolation of PPP numbers published by the UN International
Comparison Program (UNICP) and by Professors Robert Summers and Alan
Heston of the University of Pennsylvania and their colleagues. In
contrast, the currency exchange rate method involves a variety of
international and domestic financial forces that often have little
relation to domestic output. In developing countries with weak
currencies the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Furthermore, exchange rates
may suddenly go up or down by 10% or more because of market forces or
official fiat whereas real output has remained unchanged. On 12
January 1994, for example, the 14 countries of the African Financial
Community (whose currencies are tied to the French franc) devalued
their currencies by 50%. This move, of course, did not cut the real
output of these countries by half. One important caution: the
proportion of, say, defense expenditures as a percentage of GDP in
local currency accounts may differ substantially from the proportion
when GDP accounts are expressed in PPP terms, as, for example, when an
observer tries to estimate the dollar level of Russian or Japanese
military expenditures. Note: the numbers for GDP and other economic
data can not be chained together from successive volumes of the
Factbook because of changes in the US dollar measuring rod, revisions
of data by statistical agencies, use of new or different sources of
information, and changes in national statistical methods and
practices.
GDP - composition by sector: This entry gives the percentage
contribution of agriculture, industry, and services to total GDP.
GDP - per capita: This entry shows GDP on a purchasing power parity
basis divided by population as of 1 July for the same year.
GDP - real growth rate: This entry gives GDP growth on an annual basis
adjusted for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and
longitude figures for the purpose of finding the approximate
geographic center of an entity and is based on the Gazetteer of
Conventional Names, Third Edition, August 1988, US Board on Geographic
Names and on other sources.
Geographic names: This information is presented in [7]Appendix H:
Cross-Reference List of Geographic Names which indicates where various
geographic names - including alternate names, former names, political
or geographical portions of larger entities, and the location of all
US Foreign Service posts - can be found in The World Factbook.
Spellings are normally, but not always, those approved by the US Board
on Geographic Names (BGN). Alternate names are included in
parentheses, while additional information is included in brackets.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note: This entry includes miscellaneous geographic
information of significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income earned
by its citizens abroad, minus income earned by foreigners from
domestic production. The Factbook, following current practice, uses
GDP rather than GNP to measure national production. However, the user
must realize that in certain countries net remittances from citizens
working abroad may be important to national well-being.
Government: This category includes the entries dealing with the system
for the adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g.,
republic, constitutional monarchy, federal republic, parliamentary
democracy, military dictatorship).
Government - note: This entry includes miscellaneous government
information of significance not included elsewhere.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value
of all final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of established helicopter
takeoff and landing sites (which may or may not have fuel or other
services).
Highways: This entry includes the total length of the highway system
as well as the length of the paved and unpaved components.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results
adjusted for household size. Nations use different standards and
procedures in collecting and adjusting the data. Surveys based on
income will normally show a more unequal distribution than surveys
based on consumption. The quality of surveys is improving with time,
yet caution is still necessary in making inter-country comparisons.
Illicit drugs: This entry gives information on the five categories of
illicit drugs - narcotics, stimulants, depressants (sedatives),
hallucinogens, and cannabis. These categories include many drugs
legally produced and prescribed by doctors as well as those illegally
produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana
(pot, Acapulco gold, grass, reefer), tetrahydrocannabinol (THC,
Marinol), hashish (hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa,
which comes from cacao seeds and is used in making chocolate, cocoa,
and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal,
phenobarbital), benzodiazepines (Librium, Valium), methaqualone
(Quaalude), glutethimide (Doriden), and others (Equanil, Placidyl,
Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual.
Hallucinogens are drugs that affect sensation, thinking,
self-awareness, and emotion. Hallucinogens include LSD (acid,
microdot), mescaline and peyote (mexc, buttons, cactus), amphetamine
variants (PMA, STP, DOB), phencyclidine (PCP, angel dust, hog),
phencyclidine analogues (PCE, PCPy, TCP), and others (psilocybin,
psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant
(Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis
sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia.
Narcotics are drugs that relieve pain, often induce sleep, and refer
to opium, opium derivatives, and synthetic substitutes. Natural
narcotics include opium (paregoric, parepectolin), morphine
(MS-Contin, Roxanol), codeine (Tylenol with codeine, Empirin with
codeine, Robitussan AC), and thebaine. Semisynthetic narcotics include
heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan),
methadone (Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of
the opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature, dried
opium poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis
that is chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and
activity, and include cocaine (coke, snow, crack), amphetamines
(Desoxyn, Dexedrine), ephedrine, ecstasy (clarity, essence, doctor,
Adam), phenmetrazine (Preludin), methylphenidate (Ritalin), and others
(Cylert, Sanorex, Tenuate).
Imports: This entry provides the total US dollar amount of imports on
a c.i.f. (cost, insurance, and freight) or f.o.b. (free on board)
basis.
Imports - commodities: This entry provides a rank ordering of imported
products starting with the most important; it sometimes includes the
percent of total dollar value.
Imports - partners: This entry provides a rank ordering of trading
partners starting with the most important; it sometimes includes the
percent of total dollar value.
Independence: For most countries, this entry gives the date that
sovereignty was achieved and from which nation, empire, or
trusteeship. For the other countries, the date given may not represent
"independence" in the strict sense, but rather some significant
nationhood event such as the traditional founding date or the date of
unification, federation, confederation, establishment, fundamental
change in the form of government, or state succession. Dependent areas
include the notation "none" followed by the nature of their dependency
status. Also see the Terminology note.
Industrial production growth rate: This entry gives the annual
percentage increase in industrial production (includes manufacturing,
mining, and construction).
Industries: This entry provides a rank ordering of industries starting
with the largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of
infants under one year old in a given year per 1,000 live births in
the same year. This rate is often used an indicator of the level of
health in a country.
Inflation rate (consumer prices): This entry furnishes the annual
percent change in consumer prices compared with the previous year''s
consumer prices.
Internet Service Providers (ISPs): This entry supplies the number of
Internet Service Providers within a country. An ISP is defined as a
company that provides access to the Internet.
International disputes: see Disputes - international
International organization participation: This entry lists in
alphabetical order by abbreviation those international organizations
in which the subject country is a member or participates in some other
way.
International organizations: This information is presented in
[8]Appendix C: International Organizations and Groups which includes
the name, abbreviation, address, telephone, FAX, date established,
aim, and members by category.
Introduction: This category includes one entry, Background.
Irrigated land: This entry gives the number of square kilometers of
land area that is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest
court(s) and a brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry contains a rank ordering of
component parts of the labor force by occupation.
Land boundaries: This entry contains the total length of all land
boundaries and the individual lengths for each of the contiguous
border countries.
Land use: This entry contains the percentage shares of total land area
for five different types of land use: arable land - land cultivated
for crops that are replanted after each harvest like wheat, maize, and
rice; permanent crops - land cultivated for crops that are not
replanted after each harvest like citrus, coffee, and rubber;
permanent pastures - land permanently used for herbaceous forage
crops; forests and woodland - land under dense or open stands of
trees; other - any land type not specifically mentioned above, such as
urban areas, roads, desert, etc.
Languages: This entry provides a rank ordering of languages starting
with the largest and sometimes includes the percent of total
population speaking that language.
Legal system: This entry contains a brief description of the legal
system''s historical roots, role in government, and acceptance of
International Court of Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure
(unicameral, bicameral, tricameral), formal name, number of seats, and
term of office. Elections includes the nature of election process or
accession to power, date of the last election, and date of the next
election. Election results includes the percent of vote and/or number
of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of
years to be lived by a group of people born in the same year, if
mortality at each age remains constant in the future. The entry
includes total population as well as the male and female components.
Life expectancy at birth is also a measure of overall quality of life
in a country and summarizes the mortality at all ages. It can also be
thought of as indicating the potential return on investment in human
capital and is necessary for the calculation of various actuarial
measures.
Literacy: This entry includes a definition of literacy and Census
Bureau percentages for the total population, males, and females. There
are no universal definitions and standards of literacy. Unless
otherwise specified, all rates are based on the most common definition
- the ability to read and write at a specified age. Detailing the
standards that individual countries use to assess the ability to read
and write is beyond the scope of the Factbook. Information on
literacy, while not a perfect measure of educational results, is
probably the most easily available and valid for international
comparisons. Low levels of literacy, and education in general, can
impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country''s regional location,
neighboring countries, and adjacent bodies of water.
Map references: This entry includes the name of the Factbook reference
map on which a country may be found. The entry on Geographic
coordinates may be helpful in finding some smaller countries.
Maritime claims: This entry includes the following claims: contiguous
zone, continental shelf, exclusive economic zone, exclusive fishing
zone, extended fishing zone, none (usually for a landlocked country),
other (unique maritime claims like Libya''s Gulf of Sidra Closing Line
or North Korea''s Military Boundary Line), and territorial sea. The
proximity of neighboring states may prevent some national claims from
being extended the full distance.
Merchant marine: Merchant marine may be defined as all ships engaged
in the carriage of goods; or all commercial vessels (as opposed to all
nonmilitary ships), which excludes tugs, fishing vessels, offshore oil
rigs, etc.; or a grouping of merchant ships by nationality or
register. This entry contains information in two subfields - total and
ships by type. Total includes the total number of ships (1,000 GRT or
over), total DWT for those ships, and total GRT for those ships. Ships
by type includes a listing of barge carriers, bulk cargo ships, cargo
ships, combination bulk carriers, combination ore/oil carriers,
container ships, intermodal ships, liquefied gas tankers, livestock
carriers, multifunction large-load carriers, oil tankers, passenger
ships, passenger-cargo ships, railcar carriers, refrigerated cargo
ships, roll-on/roll-off cargo ships, short-sea passenger ships,
specialized tankers, tanker tug-barges, and vehicle carriers.
A captive register is a register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships
owned in the parent country; it is also referred to as an offshore
register, the offshore equivalent of an internal register. Ships on a
captive register will fly the same flag as the parent country, or a
local variant of it, but will be subject to the maritime laws and
taxation rules of the offshore territory. Although the nature of a
captive register makes it especially desirable for ships owned in the
parent country, just as in the internal register, the ships may also
be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an
independent state.
A flag of convenience register is a national register offering
registration to a merchant ship not owned in the flag state. The major
flags of convenience (FOC) attract ships to their registers by virtue
of low fees, low or nonexistent taxation of profits, and liberal
manning requirements. True FOC registers are characterized by having
relatively few of the registered ships actually owned in the flag
state. Thus, while virtually any flag can be used for ships under a
given set of circumstances, an FOC register is one where the majority
of the merchant fleet is owned abroad. It is also referred to as an
open register.
A flag state is the nation in which a ship is registered and which
holds legal jurisdiction over operation of the ship, whether at home
or abroad. Maritime legislation of the flag state determines how a
ship is crewed and taxed and whether a foreign-owned ship may be
placed on the register.
An internal register is a register of ships maintained as a subset of
a national register. Ships on the internal register fly the national
flag and have that nationality but are subject to a separate set of
maritime rules from those on the main national register. These
differences usually include lower taxation of profits, use of foreign
nationals as crew members, and, usually, ownership outside the flag
state (when it functions as an FOC register). The Norwegian
International Ship Register and Danish International Ship Register are
the most notable examples of an internal register. Both have been
instrumental in stemming flight from the national flag to flags of
convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
A merchant ship is a vessel that carries goods against payment of
freight; it is commonly used to denote any nonmilitary ship but
accurately restricted to commercial vessels only.
A register is the record of a ship''s ownership and nationality as
listed with the maritime authorities of a country; also, it is the
compendium of such individual ships'' registrations. Registration of a
ship provides it with a nationality and makes it subject to the laws
of the country in which registered (the flag state) regardless of the
nationality of the ship''s ultimate owner.
Military: This category includes the entries dealing with a country''s
military structure, manpower, and expenditures.
Military bra','32dab1de2a5caacd3562c94474d52978257dfea36639bbdab335f342ab801594','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ebec694441eed82cb6a6009a49bd4037d432b98f3465d1a19e4c44c460d595e',2000,'ZW','Zimbabwe','environment',241,'nches: This entry lists the names of the ground, naval,
air, marine, and other defense or security forces.
Military expenditures - dollar figure: This entry gives current
military expenditures in US dollars; the figure is calculated by
multiplying the estimated defense spending in percentage terms by the
gross domestic product (GDP) calculated on an exchange rate basis not
purchasing power parity (PPP) terms. However, in the case of Russia,
estimates of military expenditures have been made using PPP. Dollar
figures for military expenditures should be treated with caution
because of different price patterns and accounting methods among
nations, as well as wide variations in the strength of their
currencies.
Military expenditures - percent of GDP: This entry gives current
military expenditures as an estimated percent of gross domestic
product (GDP).
Military manpower - availability: This entry gives the total numbers
of males and females age 15-49 and assumes that every individual is
fit to serve.
Military manpower - fit for military service: This entry gives the
number of males and females age 15-49 fit for military service. This
is a more refined measure of potential military manpower availability
which tries to correct for the health situation in the country and
reduces the maximum potential number to a more realistic estimate of
the actual number fit to serve.
Military manpower - military age: This entry gives the minimum age at
which an individual may volunteer for military service or be subject
to conscription.
Military manpower - reaching military age annually: This entry gives
the number of draft-age males and females entering the military
manpower pool in any given year and is a measure of the availability
of draft-age young adults.
Military - note: This entry includes miscellaneous military
information of significance not included elsewhere.
Money figures: All money figures are expressed in contemporaneous US
dollars unless otherwise indicated.
National holiday: This entry gives the primary national day of
celebration - usually independence day.
Nationality: This entry provides the identifying terms for citizens -
noun and adjective.
Natural hazards: This entry lists potential natural disasters.
Natural resources: This entry lists a country''s mineral, petroleum,
hydropower, and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference
between the number of persons entering and leaving a country during
the year per 1,000 persons (based on midyear population). An excess of
persons entering the country is referred to as net immigration (e.g.,
3.56 migrants/1,000 population); an excess of persons leaving the
country as net emigration (e.g., -9.26 migrants/1,000 population). The
net migration rate indicates the contribution of migration to the
overall level of population change. High levels of migration can cause
problems such as increasing unemployment and potential ethnic strife
(if people are coming in) or a reduction in the labor force, perhaps
in certain key sectors (if people are leaving).
People: This category includes the entries dealing with the
characteristics of the people and their society.
People - note: This entry includes miscellaneous demographic
information of significance not included elsewhere.
Personal Names - Capitalization: The Factbook capitalizes the surname
or family name of individuals for the convenience of our users who are
faced with a world of different cultures and naming conventions. An
example would be President SADDAM Husayn of Iraq. Saddam is his name
and Husayn is his father''s name. He may be referred to as President
SADDAM Husayn or President SADDAM, but not President Husayn. The need
for capitalization, bold type, underlining, italics, or some other
indicator of the individual''s surname is apparent in the following
examples: MAO Zedong, Fidel CASTRO Ruz, William Jefferson CLINTON, and
TUNKU SALAHUDDIN Abdul Aziz Shah ibni Al-Marhum Sultan Hisammuddin
Alam Shah. By knowing the surname, a short form without all capital
letters can be used with confidence as in President Saddam, President
Castro, Chairman Mao, President Clinton, or Sultan Tunku Salahuddin.
The same system of capitalization is extended to the names of leaders
with surnames that are not commonly used such as Queen ELIZABETH II.
Personal Names - Spelling: The romanization of personal names in the
Factbook normally follows the same transliteration system used by the
US Board on Geographic Names for spelling place names. At times,
however, a foreign leader expressly indicates a preference for, or the
media or official documents regularly use, a romanized spelling that
differs from the transliteration derived from the US Government
standard. In such cases, the Factbook uses the alternative spelling.
Personal Names - Titles: The Factbook capitalizes any valid title (or
short form of it) immediately preceding a person''s name. A title
standing alone is lowercased. Examples: President PUTIN and President
CLINTON are chiefs of state. In Russia, the president is chief of
state and the premier is the head of the government, while in the US,
the president is both chief of state and head of government.
Pipelines: This entry gives the lengths and types of pipelines for
transporting products like natural gas, crude oil, or petroleum
products.
Political parties and leaders: This entry includes a listing of
significant political organizations and their leaders.
Political pressure groups and leaders: This entry includes a listing
of organizations with leaders involved in politics, but not standing
for legislative election.
Population: This entry gives an estimate from the US Bureau of the
Census based on statistics from population censuses, vital statistics
registration systems, or sample surveys pertaining to the recent past
and on assumptions about future trends. The total population presents
one overall measure of the potential impact of the country on the
world and within its region. Note: starting with the 1993 Factbook,
demographic estimates for some countries (mostly African) have
explicitly taken into account the effects of the growing impact of the
HIV/AIDS epidemic. These countries are currently: The Bahamas, Benin,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Central African Republic, Democratic Republic of the Congo, Republic
of the Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti,
Honduras, Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria,
Rwanda, South Africa, Swaziland, Tanzania, Thailand, Togo, Uganda,
Zambia, and Zimbabwe.
Population below poverty line: National estimates of the percentage of
the population lying below the poverty line are based on surveys of
sub-groups, with the results weighted by the number of people in each
group. Definitions of poverty vary considerably among nations. For
example, rich nations generally employ more generous standards of
poverty than poor nations.
Population growth rate: The average annual percent change in the
population, resulting from a surplus (or deficit) of births over
deaths and the balance of migrants entering and leaving a country. The
rate may be positive or negative. The growth rate is a factor in
determining how great a burden would be imposed on a country by the
changing needs of its people for infrastructure (e.g., schools,
hospitals, housing, roads), resources (e.g., food, water,
electricity), and jobs. Rapid population growth can be seen as
threatening by neighboring countries.
Ports and harbors: This entry lists the major ports and harbors
selected on the basis of overall importance to each country. This is
determined by evaluating a number of factors (e.g., dollar value of
goods handled, gross tonnage, facilities, military significance).
Radio broadcast stations: This entry includes the total number of AM,
FM, and shortwave broadcast stations.
Radios: This entry gives the total number of radio receivers.
Railways: This entry includes the total route length of the railway
network and component parts by gauge: broad, dual, narrow, standard,
and other.
Reference maps: This section includes world, regional, and special or
current interest maps.
Religions: This entry includes a rank ordering of religions by
adherents starting with the largest group and sometimes includes the
percent of total population.
Sex ratio: This entry includes the number of males for each female in
five age groups - at birth, under 15 years, 15-64 years, 65 years and
over, and for the total population. Sex ratio at birth has recently
emerged as an indicator of certain kinds of sex discrimination in some
countries. For instance, high sex ratios at birth in some Asian
countries are now attributed to sex-selective abortion and infanticide
due to a strong preference for sons. This will affect future marriage
patterns and fertility patterns. Eventually it could cause unrest
among young adult males who are unable to find partners.
Suffrage: This entry gives the age at enfranchisement and whether the
right to vote is universal or restricted.
Telephone numbers: All telephone numbers in the Factbook consist of
the country code in brackets, the city or area code (where required)
in parentheses, and the local number. The one component that is not
presented is the international access code, which varies from country
to country. For example, an international direct dial telephone call
placed from the US to Madrid, Spain, would be as follows:
011 [34] (1) 577-xxxx, where
011 is the international access code for station-to-station calls
(01 is for calls other than station-to-station calls),
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another
country to the US would be as follows:
international access code + [1] (202) 939-xxxx, where
[1] is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system: This entry includes a brief characterization of the
system with details on the domestic and international components. The
following terms and abbreviations are used throughout the entry:
Africa ONE - a fiber-optic submarine cable link encircling the
continent of Africa.
Arabsat - Arab Satellite Communications Organization (Riyadh, Saudi
Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
cellular telephone system - the telephones in this system are radio
transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station
in its area (cell), from which the telephone signal is fed to a
regular telephone exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with
each other.
coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a
cylindrical conducting shell; a large number of telephone channels can
be made available within the insulated space by the use of a large
number of carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network or
Autovon); basic general-purpose, switched voice network of the Defense
Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization (Paris).
fiber-optic cable - a multichannel communications cable using a thread
of optical glass fibers as a transmission medium in which the signal
(voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised by
the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high-frequency; any radio frequency in the 3,000- to 30,000-kHz
range.
Inmarsat - International Mobile Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
landline - communication wire or cable of any sort that is installed
on poles or buried in the ground.
Marecs - Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in the
Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay,
linking Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi
Arabia, Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially
started in Morocco in 1970 by the Arab Telecommunications Union (ATU)
and was known at that time as the Middle East Mediterranean
Telecommunications Network.
microwave radio relay - transmission of long distance telephone calls
and television programs by highly directional radio microwaves that
are received and sent on from one booster station to another on an
optical path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system
that was developed jointly by the national telecommunications
authorities of the Nordic countries (Denmark, Finland, Iceland,
Norway, and Sweden).
Orbita - a Russian television service; also the trade name of a
packet-switched digital telephone network.
radiotelephone communications - the two-way transmission and reception
of sounds by broadcast radio on authorized frequencies using telephone
handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
satellite communication system - a communication system consisting of
two or more earth stations and at least one satellite that provides
long distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
satellite earth station - a communications facility with a microwave
radio transmitting and receiving antenna and required receiving and
transmitting equipment for communicating with satellites.
satellite link - a radio connection between a satellite and an earth
station permitting communication between them, either one-way (down
link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super-high-frequency; any radio frequency in the 3,000- to
30,000-MHz range.
shortwave - radio frequencies (from 1.605 to 30 MHz) that fall above
the commercial broadcast band and are used for communication over long
distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
telefax - facsimile service between subscriber stations via the public
switched telephone network or the international Datel network.
telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
telex - a communication service involving teletypewriters connected by
wire through automatic exchanges.
tropospheric scatter - a form of microwave radio transmission in which
the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra-high-frequency; any radio frequency in the 300- to
3,000-MHz range.
VHF - very-high-frequency; any radio frequency in the 30- to 300-MHz
range.
Telephones - main lines in use: This entry gives the total number of
main telephone lines in use.
Telephones - mobile cellular: This entry gives the total number of
mobile cellular telephones in use.
Television - broadcast stations: This entry gives the total number of
separate broadcast stations plus any repeater stations.
Televisions: This entry gives the total number of television sets.
Terminology: Due to the highly structured nature of the Factbook
database, some collective generic terms have to be used. For example,
the word Country in the Country name entry refers to a wide variety of
dependencies, areas of special sovereignty, uninhabited islands, and
other entities in addition to the traditional countries or independent
states. Military is also used as an umbrella term for various civil
defense, security, and defense activities in many entries. The
Independence entry includes the usual colonial independence dates and
former ruling states as well as other significant nationhood dates
such as the traditional founding date or the date of unification,
federation, confederation, establishment, or state succession that are
not strictly independence dates. Dependent areas have the nature of
their dependency status noted in this same entry.
Terrain: This entry contains a brief description of the topography.
Total fertility rate: This entry gives a figure for the average number
of children that would be born per woman if all women lived to the end
of their childbearing years and bore children according to a given
fertility rate at each age. The total fertility rate is a more direct
measure of the level of fertility than the crude birth rate, since it
refers to births per woman. This indicator shows the potential for
population growth in the country. High rates will also place some
limits on the labor force participation rates for women. Large numbers
of children born to women indicate large family sizes that might limit
the ability of the families to feed and educate their children.
Transnational Issues: This category includes only two entries at the
present time - Disputes - international and Illicit drugs - that deal
with current issues going beyond national boundaries.
Transportation: This category includes the entries dealing with the
means for movement of people and goods.
Transportation - note: This entry includes miscellaneous
transportation information of significance not included elsewhere.
Unemployment rate: This entry contains the percent of the labor force
that is without jobs. Substantial underemployment might be noted.
United Nations System: This information is presented in [9]Appendix B:
United Nations System as a chart, table, or text (depending on the
version of the Factbook) that shows the organization of the UN in
detail.
Waterways: This entry gives the total length and individual names of
navigable rivers, canals, and other inland bodies of water.
Weights and measures: This information is presented in [10]Appendix E:
Weights and Measures and includes mathematical notations (mathematical
powers and names), metric interrelationships (prefix; symbol; length,
weight, or capacity; area; volume), and standard conversion factors.
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY). The calendar year is an accounting
period of 12 months from 1 January to 31 December. The fiscal year is
an accounting period of 12 months other than 1 January to 31 December.
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates.
______________________________________________________________________
@Appendix A: Abbreviations
A
ABEDA Arab Bank for Economic Development in Africa
ACC Arab Cooperation Council
ACCT Agence de Cooperation Culturelle et Technique; see Agency for
Cultural and Technical Cooperation; changed name in 1996 to Agence de
la francophonie or Agency for the French-Speaking Community
ACP Group African, Caribbean, and Pacific Group of States
AfDB African Development Bank
AFESD Arab Fund for Economic and Social Development
AG Andean Group; see Andean Community of Nations (CAN)
Air Pollution Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Control of Emissions of Nitrogen
Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution on Persistent
Organic Pollutants
Air Pollution-Sulphur 85 Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution on the Reduction of Sulphur Emissions or
Their Transboundary Fluxes by at Least 30%
Air Pollution-Sulphur 94 Protocol to the 1979 Convention on Long-Range
Transboundary Air Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds Protocol to the 1979
Convention on Long-Range Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AL Arab League
ALADI Asociacion Latinoamericana de Integracion; see Latin American
Integration Association (LAIA)
AMF Arab Monetary Fund
AMU Arab Maghreb Union
Ancom Andean Common Market; see Andean Community of Nations (CAN)
Antarctic-Environmental Protocol Protocol on Environmental Protection
to the Antarctic Treaty
ANZUS Australia-New Zealand-United States Security Treaty
APEC Asia-Pacific Economic Cooperation
Arabsat Arab Satellite Communications Organization
AsDB Asian Development Bank
ASEAN Association of Southeast Asian Nations
Autodin Automatic Digital Network
B
BAD Banque Africaine de Developpement; see African Development Bank
(AfDB)
BADEA Banque Arabe de Developpement Economique en Afrique; see Arab
Bank
for Economic Development in Africa (ABEDA)
BCIE Banco Centroamericano de Integracion Economico;
see Central American Bank for Economic Integration (BCIE)
BDEAC Banque de Developpment des Etats de l''Afrique Centrale;
see Central African States Development Bank (BDEAC)
Benelux Benelux Economic Union
BID Banco Interamericano de Desarrollo;
see Inter-American Development Bank (IADB)
Biodiversity Convention on Biological Diversity
BIS Bank for International Settlements
BOAD Banque Ouest-Africaine de Developpement; see West African
Development Bank (WADB)
BSEC Black Sea Economic Cooperation Zone
C
C Commonwealth
CACM Central American Common Market
CAEU Council of Arab Economic Unity
CAN Andean Community of Nations
Caricom Caribbean Community and Common Market
CB citizen''s band mobile radio communications
CBSS Council of the Baltic Sea States
CCC Customs Cooperation Council
CDB Caribbean Development Bank
CE Council of Europe
CEAO Communaute Economique de l''Afrique de l''Ouest; see West African
Economic Community (CEAO)
CEEAC Communaute Economique des Etats de l''Afrique Centrale;
see Economic Community of Central African States (CEEAC)
CEI Central European Initiative
CEMA Council for Mutual Economic Assistance; also known as CMEA or
Comecon
CEPGL Communaute Economique des Pays des Grands Lacs;
see Economic Community of the Great Lakes Countries (CEPGL)
CERN Conseil Europeenne pour la Recherche Nucleaire;
see European Organizati','cdca408462953b53ace71b85a7c37f7d7f60e4db50574488da890fb01ddeb1d8','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14fe0740b56325da8644c65cee2e4071f91337338358d32938c0e0ec00dccdb0',2000,'ZW','Zimbabwe','environment',242,'on for Nuclear Research (CERN)
CG Contadora Group
c.i.f. cost, insurance, and freight
CIS Commonwealth of Independent States
CITES see Endangered Species
Climate Change United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol Kyoto Protocol to the United Nations
Framework Convention on Climate Change
CMEA Council for Mutual Economic Assistance (CEMA); also known as
Comecon
COCOM Coordinating Committee on Export Controls
Comecon Council for Mutual Economic Assistance (CEMA); also known as
CMEA
Comsat Communications Satellite Corporation
CP Colombo Plan
CSCE Conference on Security and Cooperation in Europe; see
Organization
for Security and Cooperation in Europe (OSCE)
CY calendar year
D
DC developed country
Desertification United Nations Convention to Combat Desertification in
Those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
DSN Defense Switched Network
DWT deadweight ton
E
EADB East African Development Bank
EAPC Euro-Atlantic Partnership Council
EBRD European Bank for Reconstruction and Development
EC European Community; see European Union (EU)
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East; see Economic and
Social Commission for Asia and the Pacific (ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America; see Economic Commission
for Latin America and the Caribbean (ECLAC)
ECLAC Economic Commission for Latin America and the Caribbean
ECO Economic Cooperation Organization
ECOSOC Economic and Social Council
ECOWAS Economic Community of West African States
ECS European Coal and Steel Community; see European Union (EU)
ECWA Economic Commission for Western Asia;
see Economic and Social Commission for Western Asia (ESCWA)
EEC European Economic Community; see European Union (EU)
EFTA European Free Trade Association
EIB European Investment Bank
EMU European Monetary Union
Endangered Species Convention on the International Trade in Endangered
Species of Wild Flora and Fauna (CITES)
Entente Council of the Entente
Environmental Modification Convention on the Prohibition of Military
or Any Other Hostile Use of Environmental Modification Techniques
ESA European Space Agency
ESCAP Economic and Social Commission for Asia and the Pacific
ESCWA Economic and Social Commission for Western Asia
est. estimate
EU European Union
Euratom European Atomic Energy Community; see European Community (EC)
Eutelsat European Telecommunications Satellite Organization
Ex-Im Export-Import Bank of the United States
F
FAO Food and Agriculture Organization
FAX facsimile
f.o.b. free on board
FLS Front Line States
FRG Federal Republic of Germany (West Germany);
used for information dated before 3 October 1990 or CY91
FSU former Soviet Union
FY fiscal year
FYROM The Former Yugoslav Republic of Macedonia
FZ Franc Zone
G
G-2 Group of 2
G-3 Group of 3
G-5 Group of 5
G-6 Group of 6 (not to be confused with the Big Six)
G-7 Group of 7
G-8 Group of 8
G-9 Group of 9
G-10 Group of 10
G-11 Group of 11
G-15 Group of 15
G-19 Group of 19
G-24 Group of 24
G-30 Group of 30
G-33 Group of 33
G-77 Group of 77
GATT General Agreement on Tariffs and Trade;
subsumed by the World Trade Organization (WTrO) on 1 January 1995
GCC Gulf Cooperation Council
GDP gross domestic product
GDR German Democratic Republic (East Germany);
used for information dated before 3 October 1990 or CY91
GNP gross national product
GRT gross register ton
GWP gross world product
H
Hazardous Wastes Basel Convention on the Control of Transboundary
Movements of Hazardous Wastes and Their Disposal
HF high-frequency
I
IADB Inter-American Development Bank
IAEA International Atomic Energy Agency
IBEC International Bank for Economic Cooperation
IBRD International Bank for Reconstruction and Development (World
Bank)
ICAO International Civil Aviation Organization
ICC International Chamber of Commerce
ICEM Intergovernmental Committee for European Migration;
see International Organization for Migration (IOM)
ICFTU International Confederation of Free Trade Unions; see World
Confederation of Labor (WCL)
ICJ International Court of Justice (World Court)
ICM Intergovernmental Committee for Migration; see International
Organization for Migration (IOM)
ICRC International Committee of the Red Cross
ICRM International Red Cross and Red Crescent Movement
IDA International Development Association
IDB Islamic Development Bank
IEA International Energy Agency
IFAD International Fund for Agricultural Development
IFC International Finance Corporation
IFCTU International Federation of Christian Trade Unions
IFRCS International Federation of Red Cross and Red Crescent Societies
IGAD Inter-Governmental Authority on Development
IGADD Inter-Governmental Authority on Drought and Development
IHO International Hydrographic Organization
IIB International Investment Bank
ILO International Labor Organization
IMCO Intergovernmental Maritime Consultative Organization; see
International Maritime Organization (IMO)
IMF International Monetary Fund
IMO International Maritime Organization
Inmarsat International Mobile Satellite Organization
InOC Indian Ocean Commission
Intelsat International Telecommunications Satellite Organization
Interpol International Criminal Police Organization
Intersputnik International Organization of Space Communications
IOC International Olympic Committee
IOM International Organization for Migration
ISO International Organization for Standardization
ITU International Telecommunication Union
K
kHz kilohertz
km kilometer
kW kilowatt
kWh kilowatt hour
L
LAES Latin American Economic System
LAIA Latin American Integration Association
LAS League of Arab States; see Arab League (AL)
Law of the Sea United Nations Convention on the Law of the Sea (LOS)
LDC less developed country
LLDC least developed country
London Convention see Marine Dumping
LORCS League of Red Cross and Red Crescent Societies;
see International Federation of Red Cross and Red Crescent Societies
(IFRCS)
LOS see Law of the Sea
M
m meter
Marecs Maritime European Communications Satellite
Marine Dumping Convention on the Prevention of Marine Pollution by
Dumping Wastes
and Other Matter
Marine Life Conservation Convention on Fishing and Conservation of
Living Resources of the
High Seas
MARPOL see Ship Pollution
Medarabtel Middle East Telecommunications Project of the International
Telecommunications Union
Mercosur Mercado Comun del Cono Sur; see Southern Cone Common Market
MHz megahertz
MINURSO United Nations Mission for the Referendum in Western Sahara
MINUGUA United Nations Verification Mission in Guatemala
MIPONUH United Nations Civilian Police Mission in Haiti
MONUA United Nations Observer Mission in Angola
MONUC United Nations Organization Mission in the Democratic Republic
of the Congo
N
NA not available
NACC North Atlantic Cooperation Council; see Euro-Atlantic Partnership
Council (EAPC)
NAM Nonaligned Movement
NATO North Atlantic Treaty Organization
NC Nordic Council
NEA Nuclear Energy Agency
NEGL negligible
NIB Nordic Investment Bank
NIC newly industrializing country; see newly industrializing economy
(NIE)
NIE newly industrializing economy
nm nautical mile
NMT Nordic Mobile Telephone
NSG Nuclear Suppliers Group
Nuclear Test Ban Treaty Banning Nuclear Weapons Tests in the
Atmosphere, in Outer Space, and Under Water
NZ New Zealand
O
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
ODA official development assistance
OECD Organization for Economic Cooperation and Development
OECS Organization of Eastern Caribbean States
OIC Organization of the Islamic Conference
ONUSAL United Nations Observer Mission in El Salvador
OOF other official flows
OPANAL Organismo para la Proscripcion de las Armas Nucleares en la
America Latina y el Caribe;
see Agency for the Prohibition of Nuclear Weapons in Latin America and
the Caribbean
OPCW Organization for the Prohibition of Chemical Weapons
OPEC Organization of Petroleum Exporting Countries
OSCE Organization for Security and Cooperation in Europe
Ozone Layer Protection Montreal Protocol on Substances That Deplete
the Ozone Layer
P
PCA Permanent Court of Arbitration
PDRY People''s Democratic Republic of Yemen [Yemen (Aden) or South
Yemen];
used for information dated before 22 May 1990 or CY91
PFP Partnership for Peace
R
Ramsar see Wetlands
RG Rio Group
S
SAARC South Asian Association for Regional Cooperation
SACU Southern African Customs Union
SADC Southern African Development Community
SADCC Southern African Development Coordination Conference;
see Southern African Development Community (SADC)
SELA Sistema Economico Latinoamericana; see Latin American Economic
System (LAES)
SFRY Socialist Federal Republic of Yugoslavia; dissolved 5 December
1991
SHF super-high-frequency
Ship Pollution Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Sparteca South Pacific Regional Trade and Economic Cooperation
Agreement
SPC South Pacific Commission
SPF South Pacific Forum
sq km square kilometer
sq mi square mile
T
TAT Trans-Atlantic Telephone
Tropical Timber 83 International Tropical Timber Agreement, 1983
Tropical Timber 94 International Tropical Timber Agreement, 1994
U
UAE United Arab Emirates
UDEAC Union Douaniere et Economique de l''Afrique Centrale;
see Central African Customs and Economic Union (UDEAC)
UEMOA Union Economique et Monetaire Ouest Africaine;
see West African Economic and Monetary Union (WAEMU)
UHF ultra-high-frequency
UK United Kingdom
UN United Nations
UNAMIR United Nations Assistance Mission for Rwanda
UNAMSIL United Nations Mission in Sierra Leone
UNAVEM III United Nations Angola Verification Mission III
UNCRO United Nations Confidence Restoration Operation in Croatia
UNCTAD United Nations Conference on Trade and Development
UNDOF United Nations Disengagement Observer Force
UNDP United Nations Development Program
UNEP United Nations Environment Program
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UNFICYP United Nations Peace-keeping Force in Cyprus
UNFPA United Nations Fund for Population Activities; see UN Population
Fund (UNFPA)
UNHCR United Nations High Commissioner for Refugees
UNICEF United Nations Children''s Fund
UNIDO United Nations Industrial Development Organization
UNIFIL United Nations Interim Force in Lebanon
UNIKOM United Nations Iraq-Kuwait Observation Mission
UNITAR United Nations Institute for Training and Research
UNMIH United Nations Mission in Haiti
UNMIBH United Nations Mission in Bosnia and Herzegovina
UNMIK United Nations Interim Administration Mission in Kosovo
UNMOGIP United Nations Military Observer Group in India and Pakistan
UNMOP United Nations Mission of Observers in Prevlaka
UNMOT United Nations Mission of Observers in Tajikistan
UNMOVIC United Nations Monitoring and Verification Commission
UNOMIG United Nations Observer Mission in Georgia
UNOMIL United Nations Observer Mission in Liberia
UNOMOZ United Nations Operation in Mozambique
UNOMSIL United Nations Mission of Observers in Sierra Leone
UNOMUR United Nations Observer Mission Uganda-Rwanda
UNOSOM II United Nations Operation in Somalia II
UNPREDEP United Nations Preventive Deployment Force
UNPROFOR United Nations Protection Force
UNRISD United Nations Research Institute for Social Development
UNRWA United Nations Relief and Works Agency for Palestine Refugees in
the Near East
UNSCOM United Nations Special Commission for the Elimination of Iraq''s
Weapons of Mass Destruction;
see United Nations Monitoring and Verification Commission (UNMOVIC)
UNSMIH United Nations Support Mission in Haiti
UNTAC United Nations Transitional Authority in Cambodia
UNTAES United Nations Transitional Administration in Eastern Slavonia,
Baranja, and Western Sirmium
UNTAET United Nations Transitional Administration in East Timor
UNTSO United Nations Truce Supervision Organization
UNU United Nations University
UPU Universal Postal Union
US United States
USSR Union of Soviet Socialist Republics (Soviet Union);
used for information dated before 25 December 1991
USSR/EE Union of Soviet Socialist Republics/Eastern Europe
V
VHF very-high-frequency
VSAT very small aperture terminal
W
WADB West African Development Bank
WAEMU West African Economic and Monetary Union
WCL World Confederation of Labor
WCO World Customs Organization; see Customs Cooperation Council
Wetlands Convention on Wetlands of International Importance Especially
As Waterfowl Habitat
WEU Western European Union
WFC World Food Council
WFP World Food Program
WFTU World Federation of Trade Unions
Whaling International Convention for the Regulation of Whaling
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
WP Warsaw Pact
WTO see WToO for World Tourism Organization or WTrO for World Trade
Organization
WToO World Tourism Organization
WTrO World Trade Organization
Y
YAR
Yemen Arab Republic [Yemen (Sanaa) or North Yemen];
used for information dated before 22 May 1990 or CY91
Z
ZC Zangger Committee
______________________________________________________________________
@Appendix B: United Nations System
[Appendix B of the 1998 CIA World Factbook is a graphic
depiction of the structure of the United Nations. It
is not included in the Project Gutenberg edition.]
______________________________________________________________________
@Appendix C: International Organizations and Groups
advanced developing countries
another term for those less developed countries (LDCs) with
particularly rapid industrial development; see newly industrializing
economies (NIEs)
_________________________________________________________________
advanced economies
a new term used by the International Monetary FUND (IMF) for the top
group in its hierarchy of advanced economies, countries in transition,
and developing countries; recently published IMF statistics include
the following 28 advanced economies: Australia, Austria, Belgium,
Canada, Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland,
Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Netherlands,
NZ, Norway, Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan,
UK, US; note - this group would presumably also cover the following
seven smaller countries of Andorra, Bermuda, Faroe Islands, Holy See,
Liechtenstein, Monaco, and San Marino which are included in the more
comprehensive group of "developed countries"
_________________________________________________________________
African, Caribbean, and Pacific Group of States (ACP Group)
address - Avenue Georges Henri 451, B-1200 Brussels, Belgium
telephone - [32] (2) 743 06 00
FAX - [32] (2) 735 55 73
established - 6 June 1975
aim - to manage their preferential economic and aid relationship with
the EU
members - (71) Angola, Antigua and Barbuda, The Bahamas, Barbados,
Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Dominica,
Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon,
The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti,
Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali,
Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Papua New
Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa Sudan, Suriname,
Swaziland, Tanzania, Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda,
Vanuatu, Zambia, Zimbabwe
_________________________________________________________________
African Development Bank (AfDB)
note - also known as Banque Africaine de Developpement (BAD)
address - 01 BP 1387, Abidjan 01, Cote d''Ivoire
telephone - [225] 20 44 44
FAX - [225] 21 77 53
established - 4 August 1963
aim - to promote economic and social development
regional members - (53) Algeria, Angola, Benin, Botswana, Burkina
Faso, Burundi, Cameroon, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote
d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia,
Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho,
Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius,
Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members - (25) Argentina, Austria, Belgium, Brazil,
Canada, China, Denmark, Finland, France, Germany, India, Italy, Japan,
South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia,
Spain, Sweden, Switzerland, UAE, UK, US
_________________________________________________________________
Agence de Cooperation Culturelle et Technique (ACCT)
see Agency for the French-speaking Community (ACCT)
_________________________________________________________________
Agence de la francophonie (ACCT)
see Agency for the French-speaking Community (ACCT)
_________________________________________________________________
Agency for Cultural and Technical Cooperation (ACCT)
see Agency for the French-speaking Community (ACCT); acronym from
Agence de Cooperation Culturelle et Technique
_________________________________________________________________
Agency for the French-Speaking Community (ACCT)
note - formerly Agency for Cultural and Technical Cooperation
address - 13 Quai Andre-Citroen, F-75015 Paris, France
telephone - [33] (1) 44 37 33 00
FAX - [33] (1) 45 79 14 98
established - 20 March 1970
name changed - 1996
aim - to promote cultural and technical cooperation among
French-speaking countries
members - (41) Belgium, Benin, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cote d''Ivoire, Djibouti, Dominica, Equatorial Guinea, France,
Gabon, Guinea, Haiti, Laos, Lebanon, Luxembourg, Madagascar, Mali,
Mauritius, Moldova, Monaco, Niger, Romania, Rwanda, Sao Tome and
Principe, Senegal, Seychelles, Switzerland, Togo, Tunisia, Vanuatu,
Vietnam
associate members - (5) Egypt, Guinea-Bissau, Mauritania, Morocco,
special members - (1) Tuvalu
_________________________________________________________________
Commonwealth of Independent States (CIS)
address - Kirov Street 17, 220000 Minsk, Belarus
telephone - [375] 223434, 223517
FAX - [375] 261944, 272339
established - 8 December 1991
effective - 21 December 1991
aim - to coordinate intercommonwealth relations and to provide a
mechanism for the orderly dissolution of the USSR
members - (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,','8170a1345edb2e68807d61e36e9462e9aa3ef0390d285dfd5bc01ceb4bd5d738','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb2e9da080813f8ae8ca6987a4191c4cc628db3867b22c8ba8572fbd80310a5a',2000,'LC','Saint Lucia','environment',243,'participating governments - (2) New Brunswick (Canada), Quebec
(Canada)
_________________________________________________________________
Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean (OPANAL)
note - acronym from Organismo para la Proscripcion de las Armas
Nucleares en la America Latina y el Caribe (OPANAL)
address - Temistocles 78, Col Polanco, CP 011560, Mexico City 5 DF,','fab6201ee37b4a23cb7a5c1e9a0d812638184554c946f14a9ebbc24342cfb074','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df6bd9db5eaf062f8d5920c0c3e0c77a01e37ec93569cb75df3a2e7a3bfe448',2000,'MX','Mexico','environment',244,'telephone - [52] (5) 280 4923, 280 5064, 280 2715
FAX - [52] (5) 280 2965
established - 14 February 1967 under the Treaty of Tlatelolco
effective - 25 April 1969 on the 11th ratification of the treaty
aim - to encourage the peaceful uses of atomic energy and prohibit
nuclear weapons
members - (32) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Dominica,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana,
Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, Uruguay, Venezuela
_________________________________________________________________
Andean Community of Nations (CAN)
note - formerly known as the Andean Group (AG), the Andean Parliament,
and most recently as the Andean Common Market (Ancom)
address - c/o General Secretariat of the Andean Community, Paseo de la
Republica 3895, Casilla 18-1177, Lima 18, Peru
telephone - [51] (1) 221 2222
FAX - [51] (1) 221 3329
established - 26 May 1969; present name established 1 October 1992
effective - 16 October 1969
aim - to promote harmonious development through economic integration
members - (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
associate member - (1) Panama
_________________________________________________________________
Andean Group (AG)
see Andean Community of Nations (CAN)
_________________________________________________________________
Arab Bank for Economic Development in Africa (ABEDA)
note - also known as Banque Arabe de Developpement Economique en
Afrique (BADEA)
address - Abdel Rahman El Mahdi Avenue, P. O. Box 2640, Khartoum,','7d4b53a36543c66e1ad9aadc17bab0d5cdf979004129bc4a46188fc94e3a4377','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05473746df2ca95d3545bed8fffee49e077df0c736f10de5eea8434227cef0f5',2000,'SD','Sudan','environment',245,'telephone - [249] (11) 770498, 773646, 773709
FAX - [249] (11) 770600
established - 18 February 1974
effective - 16 September 1974
aim - to promote economic development
members - (17 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE,
Palestine Liberation Organization; note - these are all the members of
the Arab League excluding Comoros, Djibouti, Somalia, Yemen
_________________________________________________________________
Arab Cooperation Council (ACC)
established - 16 February 1989
aim - to promote economic cooperation and integration, possibly
leading to an Arab Common Market
members - (4) Egypt, Iraq, Jordan, Yemen
_________________________________________________________________
Arab Fund for Economic and Social Development (AFESD)
address - P. O. Box 21923, Safat 13080, Kuwait
telephone - [965] 4844500
FAX - [965] 4815750, 4815760, 4815770
established - 16 May 1968
aim - to promote economic and social development
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt (suspended from 1979 to 1988), Iraq
(suspended 1993), Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco,
Oman, Qatar, Saudi Arabia, Somalia (suspended 1993), Sudan (suspended
1993), Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
_________________________________________________________________
Arab League (AL)
note - also known as League of Arab States (LAS)
address - Midan Attahrir, Tahrir Square, P. O. Box 11642, Cairo, Egypt
telephone - [20] (2) 750 511
FAX - [20] (2) 740 331
established - 22 March 1945
aim - to promote economic, social, political, and military cooperation
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
_________________________________________________________________
Arab Maghreb Union (AMU)
address - 27 Avenue Okba Agdal, Rabat, Morocco
telephone - [212] (7) 77 26 82, 77 26 76, 77 26 68
FAX - [212] (7) 77 26 93
established - 17 February 1989
aim - to promote cooperation and integration among the Arab states of
northern Africa
members - (5) Algeria, Libya, Mauritania, Morocco, Tunisia
_________________________________________________________________
Arab Monetary Fund (AMF)
address - P. O. Box 2818, Abu Dhabi, United Arab Emirates
telephone - [971] (2) 215000, 328500
FAX - [971] (2) 326454
established - 27 April 1976
effective - 2 February 1977
aim - to promote Arab cooperation, development, and integration in
monetary and economic affairs
members - (20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria,
Tunisia, UAE, Yemen, Palestine Liberation Organization
_________________________________________________________________
Asia-Pacific Economic Cooperation (APEC)
address - APEC Secretariat, 438 Alexandra Road, 14-00 Alexandra Point,
14th Floor 01/04, Singapore 119958, Singapore
telephone - [65] 276 1880
FAX - [65] 276 1775
established - 7 November 1989
aim - to promote trade and investment in the Pacific basin
members - (21) Australia, Brunei, Canada, Chile, China, Hong Kong,
Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea,
Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers - (3) Association of Southeast Asian Nations, Pacific
Economic Cooperation Conference, South Pacific Forum
_________________________________________________________________
Asian Development Bank (AsDB)
address - 6 ADB Avenue, Mandaluyong, 0401 METRO Manila, Philippines
telephone - [63] (2) 711 3851
FAX - [63] (2) 741 7961, 631 6816
established - 19 December 1966
aim - to promote regional economic cooperation
regional members - (41) Afghanistan, Australia, Bangladesh, Bhutan,
Burma, Cambodia, China, Cook Islands, Fiji, Hong Kong, India,
Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia,
Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan,
Thailand, Tonga, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members - (16) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Italy, Netherlands, Norway, Spain, Sweden,
Switzerland, Turkey, UK, US
_________________________________________________________________
Asociacion Latinoamericana de Integracion (ALADI)
see Latin American Integration Association (LAIA)
_________________________________________________________________
Association of Southeast Asian Nations (ASEAN)
note - the ASEAN Regional Forum (ARF) consists of the 9 ASEAN members,
2 observers, 2 consultative partners, and 8 dialogue partners:
Australia, Canada, EU, India, Japan, South Korea, New Zealand, US
address - 70 A Jalan Sisingamangaraja, Jakarta 12110, Indonesia
telephone - [62] (21) 7262991, 7243372
FAX - [62] (21) 7398234, 7243504
established - 8 August 1967
aim - to encourage regional economic, social, and cultural cooperation
among the non-Communist countries of Southeast Asia
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
observer - (1) Papua New Guinea
consultative partners - (2) China, Russia
_________________________________________________________________
Australia Group
established - 1984
aim - to consult on and coordinate export controls related to chemical
and biological weapons
members - (28) Argentina, Australia, Austria, Belgium, Canada, Czech
Republic, Denmark, Finland, France, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Poland,
Portugal, Slovakia, Spain, Sweden, Switzerland, UK, US; note - may now
include only 23 countries
observer - (1) Singapore
_________________________________________________________________
Australia-New Zealand-United States Security Treaty (ANZUS)
address - c/o Department of Foreign Affairs and Trade, Bag 8, Queen
Victoria Terrace, Canberra ACT 2600, Australia
telephone - [61] (6) 261 91 11
FAX - [61] (6) 261 21 51
established - 1 September 1951
effective - 29 April 1952
aim - to implement a trilateral mutual security agreement, although
the US suspended security obligations to NZ on 11 August 1986;
Australia and the US continue to hold annual meetings
members - (3) Australia, NZ, US
_________________________________________________________________
Banco Centroamericano de Integracion Economico (BCIE)
see Central American Bank for Economic Integration (BCIE)
_________________________________________________________________
Banco Interamericano de Desarrollo (BID)
see Inter-American Development Bank (IADB)
_________________________________________________________________
Bank for International Settlements (BIS)
address - Centralbahnplatz 2, CH-4002 Basel, Switzerland
telephone - [41] (61) 280 80 80
FAX - [41] (61) 280 91 00, 280 81 00
established - 20 January 1930
effective - 17 March 1930
aim - to promote cooperation among central banks in international
financial settlements
members - (45) Australia, Austria, Belgium, Brazil, Bulgaria, Canada,
China, Croatia, Czech Republic, Denmark, Estonia, Finland, France,
Germany, Greece, Hong Kong, Hungary, Iceland, India, Ireland, Italy,
Japan, South Korea, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Mexico, Netherlands, Norway, Poland, Portugal, Romania,
Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sweden, Switzerland, Turkey, UK, US, Yugoslavia (suspended)
_________________________________________________________________
Banque Africaine de Developpement (BAD)
see African Development Bank (AfDB)
_________________________________________________________________
Banque Arabe de Developpement Economique en Afrique (BADEA)
see Arab Bank for Economic Development in Africa (ABEDA)
_________________________________________________________________
Banque de Developpement des Etats de l''Afrique Centrale (BDEAC)
see Central African States Development Bank (BDEAC)
_________________________________________________________________
Banque Ouest-Africaine de Developpement (BOAD)
see West African Development Bank (WADB)
_________________________________________________________________
Benelux Economic Union (Benelux)
note - acronym from Belgium, Netherlands, and Luxembourg
address - Rue de la Regence 39, B-1000 Brussels, Belgium
telephone - [32] (2) 519 38 11
FAX - [32] (2) 513 42 06
established - 3 February 1958
effective - 1 November 1960
aim - to develop closer economic cooperation and integration
members - (3) Belgium, Luxembourg, Netherlands
_________________________________________________________________
Big Seven
note - membership is the same as the Group of 7
established - NA 1975
aim - to discuss and coordinate major economic policies
members - (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
the US
_________________________________________________________________
Big Six
note - not to be confused with the Group of 6
established - NA 1967
aim - to foster economic cooperation
members - (6) Canada, France, Germany, Italy, Japan, UK
_________________________________________________________________
Black Sea Economic Cooperation Zone (BSEC)
address - Istinye Cad Musir Fuad Pasa Yalisi Eski Tersame, Istinye
80860, Istanbul, Turkey
telephone - [90] (212) 229 6330
FAX - [90] (212) 229 6336
established - 25 June 1992
aim - to enhance regional stability through economic cooperation
members - (11) Albania, Armenia, Azerbaijan, Bulgaria, Georgia,
Greece, Moldova, Romania, Russia, Turkey, Ukraine
observers - (7) Austria, Egypt, Israel, Italy, Poland, Slovakia,','21fefdcb047b56173e4d4a54d2cd3c519b113a2dff34e2ef6d6c87cb62f6a007','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d63b4890b682137afa9a78371cf8a3b343e1a97d9c2d4a698d77e4e29546fe8',2000,'TN','Tunisia','environment',246,'_________________________________________________________________
Caribbean Community and Common Market (Caricom)
address - Caricom, P. O. Box 10827, Bank of Guyana Building, 3rd
floor, Avenue of the Republic, Georgetown, Guyana
telephone - [592] (2) 69281 through 69289
FAX - [592] (2) 66091, 67816, 57341
established - 4 July 1973
effective - 1 August 1973
aim - to promote economic integration and development, especially
among the less developed countries
members - (14) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Jamaica, Montserrat, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago
associate members - (3) Anguilla, British Virgin Islands, Turks and
Caicos Islands
observers - (10) Aruba, Bermuda, Cayman Islands, Colombia, Dominican
Republic, Haiti, Mexico, Netherlands Antilles, Puerto Rico, Venezuela
_________________________________________________________________
Caribbean Development Bank (CDB)
address - P. O. Box 408, Wildey, St. Michael, Barbados
telephone - [1] (246) 431 1600
FAX - [1] (246) 426 7269
established - 18 October 1969
effective - 26 January 1970
aim - to promote economic development and cooperation
regional members - (20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and
Tobago, Turks and Caicos Islands, Venezuela
nonregional members - (6) Canada, China, France, Germany, Italy, UK
_________________________________________________________________
Cartagena Group
see Group of 11
_________________________________________________________________
Central African Customs and Economic Union (UDEAC)
note - acronym from Union Douaniere et Economique de l''Afrique
Centrale
address - BP 969, Bangui, Central African Republic
telephone - [236] 61 09 22, 61 45 77
FAX - [236] 61 21 35
established - 8 December 1964
effective - 1 January 1966
aim - to promote the establishment of a Central African Common Market
members - (6) Cameroon, Central African Republic, Chad, Republic of
the Congo, Equatorial Guinea, Gabon
_________________________________________________________________
Central African States Development Bank (BDEAC)
note - acronym from Banque de Developpement des Etats de l''Afrique
Centrale
address - BDEAC, Place du Gouvernement, BP 1177, Brazzaville, Republic
of the Congo
telephone - [242] 81 18 85
FAX - [242] 81 18 80
established - 3 December 1975
aim - to provide loans for economic development
members - (9) Cameroon, Central African Republic, Chad, Republic of
the Congo, Equatorial Guinea, France, Gabon, Germany, Kuwait
_________________________________________________________________
Central American Bank for Economic Integration (BCIE)
note - acronym from Banco Centroamericano de Integracion Economico
address - Apartado Postal 772, Tegucigalpa DC, Honduras
telephone - [504] 228 2243
FAX - [504] 228 2185
established - 13 December 1960 signature of Articles of Agreement; 31
May 1961 began operations
aim - to promote economic integration and development
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members - (4) Argentina, Colombia, Mexico, Taiwan
_________________________________________________________________
Central American Common Market (CACM)
address - c/o SIECA, Apartado Postal 1237, 4a Avenida 10-25, Zona 14,
Guatemala 01901, Guatemala
telephone - [502] (2) 682151, 682152, 682153, 682154
FAX - [502] (2) 681071
established - 13 December 1960, collapsed in 1969, reinstated in 1991
aim - to promote establishment of a Central American Common Market
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua;
note - Panama, although not a member, pursues full regional
cooperation
_________________________________________________________________
Central European Initiative (CEI)
note - evolved from the Quadrilateral Initiative and the Hexagonal
Group
address - European Bank for Reconstruction and Development, One
Exchange Square, London EC2A 2EH, UK
telephone - [44] (171) 338 6152
FAX - [44] (171) 338 7472
established - 11 November 1989 as the Quadrilateral Initiative, 27
July 1991 became the Hexagonal Initiative, NA 1992 present name
adopted
aim - to form an economic and political cooperation group for the
region between the Adriatic and the Baltic Seas
members - (16) Albania, Austria, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Hungary, Italy, The Former Yugoslav
Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia,','036f3417631239f789b28648a0b500bd6ae89b5b5c57ce990befcb9ef7c0bbd5','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c84b81e91e192ec4fb15eb296398ceef5551041dcc9e6d35fda46ccaf154d81',2000,'UA','Ukraine','environment',247,'_________________________________________________________________
centrally planned economies
a term applied mainly to the traditionally communist states that
looked to the former USSR for leadership; most are now evolving toward
more democratic and market-oriented systems; also known formerly as
the Second World or as the communist countries; through the 1980s,
this group included Albania, Bulgaria, Cambodia, China, Cuba,
Czechoslovakia, GDR, Hungary, North Korea, Laos, Mongolia, Poland,
Romania, USSR, Vietnam, Yugoslavia
_________________________________________________________________
Colombo Plan (CP)
address - Colombo Plan Bureau, P. O. Box 596, 12 Melbourne Avenue,
Colombo 4, Sri Lanka
telephone - [94] (1) 581813, 581853, 581754
FAX - [94] (1) 581754
established - NA May 1950 proposal was adopted; 1 July 1951 commenced
full operations
aim - to promote economic and social development in Asia and the
Pacific
members - (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma,
Cambodia, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos,
Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea,
Philippines, Singapore, Sri Lanka, Thailand, US
_________________________________________________________________
Commission for Social Development
note - formerly Social Commission
address - General Assembly and ECOSOC Affairs Division, Department of
General Assembly Affairs and Conference Services, United Nations, Room
S-2950, New York, NY 10017, US
telephone - [1] (212) 963 1234
FAX - [1] (212) 963 5935
established - 21 June 1946 as the Social Commission, renamed 29 July
1966
aim - to deal, as part of the Economic and Social Council, with social
development programs of UN
members - (46) selected on a rotating basis from all regions
_________________________________________________________________
Commission on Crime Prevention and Criminal Justice
address - Center for International Crime Prevention, Vienna
International Center, P. O. Box 500, A-1400 Vienna, Austria
telephone - [43] (1) 21345, extension 4272
FAX - [43] (1) 21345 5898, 21345 5841
established - 6 February 1992
aim - to provide guidance, as part of the Economic and Social Council,
on crime prevention and criminal justice
members - (40) selected on a rotating basis from all regions
_________________________________________________________________
Commission on Human Rights
address - c/o Secretariat, United Nations Office of the High
Commissioner of Human Rights, United Nations Office at Geneva, CH-1211
Geneva 10, Switzerland
telephone - [41] (22) 917 90 00, 907 92 60
FAX - [41] (22) 917 90 11
established - 18 February 1946
aim - to assist, as part of the Economic and Social Council, with
human rights programs of UN
members - (53) selected on a rotating basis from all regions
_________________________________________________________________
Commission on Narcotic Drugs
address - c/o United Nations Drug Control Programme, Treaty
Implementation and Legal Affairs Branch, P. O. Box 500, A-1400 Vienna,','17279657b192831d6167bb8efd9b495aeb398829c65ac4a4b0a93c0d7d311763','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2730735584c34c5c1b1742500af6c70953219857ea4342b7b39d1b30eb59ced',2000,'AT','Austria','environment',248,'telephone - [43] (1) 213450
FAX - [43] (1) 21345-5885
established - 16 February 1946
aim - Economic and Social Council organization dealing with illicit
drugs programs of UN
members - (53) selected on a rotating basis from all regions with
emphasis on producing and processing countries
_________________________________________________________________
Commission on Population and Development
address - Division for Policy and Coordination and ECOSOC Affairs,
Department for Policy Coordination and Sustainable Development, United
Nations, Room 2963, New York, NY 10017, US
telephone - [1] (212) 963 1234
FAX - [1] (212) 963 5935
established - 10 August 1948
aim - to deal with population matters of importance to the UN, as part
of Economic and Social Council
members - (47) selected on a rotating basis from all regions
_________________________________________________________________
Commission on Science and Technology for Development
address - General Assembly and ECOSOC Affairs Division, Department of
General Assembly Affairs and Conference Services, United Nations, New
York, NY 10017, US
telephone - [1] (212) 963 1234
FAX - [1] (212) 963 5935
established - 20 July 1992
aim - to promote international cooperation, as part of the Economic
and Social Council, in the field of science and technology
members - (33) selected on a rotating basis from all regions
_________________________________________________________________
Commission on Sustainable Development
address - Division for Sustainable Development, United Nations
Department for Policy Coordination and Sustainable Development, Room
DC2-2274, New York, NY 10017, US
telephone - [1] (212) 963 0902
FAX - [1] (212) 963 4260
established - 12 February 1993
aim - to monitor, as part of the Economic and Social Council,
implementation of agreements reached at the UN Conference on
Environment and Development
members - (53) selected on a rotating basis from all regions
_________________________________________________________________
Commission on the Status of Women
address - Division for the Advancement of Women, Department for
Economic and Social Affairs, United Nations, Room DC2-1200, New York,
NY 10017, US
telephone - [1] (212) 963 3177
FAX - [1] (212) 963 3463
established - 21 June 1946
aim - to deal, as part of the Economic and Social Council, with
women''s rights goals of UN
members - (45) selected on a rotating basis from all regions
_________________________________________________________________
Commonwealth (C)
note - also known as Commonwealth of Nations
address - c/o Commonwealth Secretariat, Marlborough House, Pall Mall,
London SW1Y 5HX, UK
telephone - [44] (171) 839 3411, 747 6535
FAX - [44] (171) 930 0827, 839 9081
established - 31 December 1931
aim - to foster multinational cooperation and assistance, as a
voluntary association that evolved from the British Empire
members - (53) Antigua and Barbuda, Australia, The Bahamas,
Bangladesh, Barbados, Belize, Botswana, Brunei, Cameroon, Canada,
Cyprus, Dominica, Fiji, The Gambia, Ghana, Grenada, Guyana, India,
Jamaica, Kenya, Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta,
Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan
(suspended), Papua New Guinea, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Seychelles, Sierra Leone,
Singapore, Solomon Islands, South Africa, Sri Lanka, Swaziland,
Tanzania, Tonga, Trinidad and Tobago, Uganda, UK, Vanuatu, Zambia,','25361ed222580bbe7eb8755e27493330ca1070d48e5eee86f7888317b941af6f','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('636f6872694f65a7cd501df952d8b5dd7d11669fccbcb823182e908fcaa22354',2000,'UZ','Uzbekistan','environment',249,'_________________________________________________________________
Commonwealth of Nations
see Commonwealth (C)
_________________________________________________________________
Communaute Economique de l''Afrique de l''Ouest (CEAO)
see West African Economic Community (CEAO)
_________________________________________________________________
Communaute Economique des Etats de l''Afrique Centrale (CEEAC)
see Economic Community of Central African States (CEEAC)
_________________________________________________________________
Communaute Economique des Pays des Grands Lacs (CEPGL)
see Economic Community of the Great Lakes Countries (CEPGL)
_________________________________________________________________
communist countries
traditionally the Marxist-Leninist states with authoritarian
governments and command economies based on the Soviet model; most of
the original and the successor states are no longer communist; see
centrally planned economies
_________________________________________________________________
Conference on Security and Cooperation in Europe (CSCE)
see Organization for Security and Cooperation in Europe (OSCE)
_________________________________________________________________
Conseil Europeenne pour la Recherche Nucleaire (CERN)
see European Organization for Nuclear Research (CERN)
_________________________________________________________________
Contadora Group (CG)
established 5 January 1983 (on the Panamanian island of Contadora) to
reduce tensions and conflicts in Central America; members included
Colombia, Mexico, Panama, Venezuela; has evolved into the Rio Group
(RG)
_________________________________________________________________
Cooperation Council for the Arab States of the Gulf
see Gulf Cooperation Council (GCC)
_________________________________________________________________
Coordinating Committee on Export Controls (COCOM)
established in 1949 to control the export of strategic products and
technical data from member countries to proscribed destinations;
members were Australia, Belgium, Canada, Denmark, France, Germany,
Greece, Italy, Japan, Luxembourg, Netherlands, Norway, Portugal,
Spain, Turkey, UK, US; abolished 31 March 1994; COCOM members are
working on a new organization with expanded membership which focuses
on nonproliferation export controls as opposed to East-West control of
advanced technology
_________________________________________________________________
Council for Mutual Economic Assistance (CEMA)
note - also known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist
economies and abolished 1 January 1991; members included Afghanistan
(observer), Albania (had not participated since 1961 break with USSR),
Angola (observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia
(observer), GDR, Hungary, Laos (observer), Mongolia, Mozambique
(observer), Nicaragua (observer), Poland, Romania, USSR, Vietnam,
Yemen (observer), Yugoslavia (associate)
_________________________________________________________________
Council of Arab Economic Unity (CAEU)
address - International Trade Center Building, 12th Floor, 1191
Cornish El Nile, P. O. Box 1, Mohamad Fareed, Cairo, Egypt
telephone - [20] (2) 754252, 755321
FAX - [20] (2) 754090
established - 3 June 1957
effective - 30 May 1964
aim - to promote economic integration among Arab nations
members - (11 plus the Palestine Liberation Organization) Egypt, Iraq,
Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria, UAE, Yemen,
Palestine Liberation Organization
_________________________________________________________________
Council of Europe (CE)
address - Palais de l''Europe, F-67075 Strasbourg CEDEX, France
telephone - [33] (3) 88 41 20 00
FAX - [33] (3) 88 41 27 81, 88 41 27 82
established - 5 May 1949
effective - 3 August 1949
aim - to promote increased unity and quality of life in Europe
members - (41) Albania, Andorra, Austria, Belgium, Bulgaria, Croatia,
Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Moldova, Netherlands, Norway, Poland, Portugal,
Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK
guests - (3) Armenia, Azerbaijan, Bosnia and Herzegovina
observers - (4) Canada, Israel, Japan, US
_________________________________________________________________
Council of the Baltic Sea States (CBSS)
address - Ministry for Foreign Affairs, Box 16121, S-10323 Stockholm,','60d8a0e2ed02d5e5fbeae710b9830e0ee3a5e650568149c94d9d289244ce9cb8','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8c7f28d104db0b590854cee61273890b987b76fe4e9f935a4bc4aee8b8a6299',2000,'SE','Sweden','environment',250,'telephone - [46] (8) 405 1000
FAX - [46] (8) 723 1176
established - 6 March 1992
aim - to promote cooperation among the Baltic Sea states in the areas
of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and
education, and transportation and communication
members - (12) Denmark, Estonia, EU, Finland, Germany, Iceland,
Latvia, Lithuania, Norway, Poland, Russia, Sweden
_________________________________________________________________
Council of the Entente (Entente)
address - 01 BP 3734, Angle Avenue Verdier-Rue de Tessieres, Abidjan
01, Cote d''Ivoire
telephone - [225] 33 10 01, 33 28 35, 32 10 74
FAX - [225] 33 11 49
established - 29 May 1959
aim - to promote economic, social, and political coordination
members - (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
_________________________________________________________________
countries in transition
a new term used by the International Monetary FUND (IMF) for the
middle group in its hierarchy of advanced economies, countries in
transition, and developing countries; recently published IMF
statistics include the following 28 countries in transition: Albania,
Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria,
Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Serbia and
Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; note - this group is identical to the group traditionally
referred to as the "former USSR/Eastern Europe" except for the
addition of Mongolia
_________________________________________________________________
Customs Cooperation Council (CCC)
note - also known as World Customs Organization (WCO)
address - Rue du Marche 30, B-1210 Brussels, Belgium
telephone - [32] (2) 209 92 11
FAX - [32] (2) 109 92 92
established - 15 December 1950
aim - to promote international cooperation in customs matters
members - (145) Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Belarus,
Belgium, Bermuda, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cameroon, Canada, Cape Verde, Central African
Republic, Chile, China, Colombia, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Egypt, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guyana, Haiti, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, Macau, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Niger, Nigeria, Norway,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
_________________________________________________________________
developed countries (DCs)
the top group in the hierarchy of developed countries (DCs), former
USSR/Eastern Europe (former USSR/EE), and less developed countries
(LDCs); includes the market-oriented economies of the mainly
democratic nations in the Organization for Economic Cooperation and
Development (OECD), Bermuda, Israel, South Africa, and the European
ministates; also known as the First World, high-income countries, the
North, industrial countries; generally have a per capita GDP in excess
of $10,000 although four OECD countries and South Africa have figures
well under $10,000 and two of the excluded OPEC countries have figures
of more than $10,000; the 35 DCs are: Andorra, Australia, Austria,
Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France,
Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy, Japan,
Liechtenstein, Luxembourg, Malta, Mexico, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden,
Switzerland, Turkey, UK, US; note - similar to the new International
Monetary Fund (IMF) term "advanced economies" which adds Hong Kong,
South Korea, Singapore, and Taiwan but drops Malta, Mexico, South
Africa, and Turkey
_________________________________________________________________
developing countries
a new term used by the International Monetary FUND (IMF) for the
bottom group in its hierarchy of advanced economies, countries in
transition, and developing countries; recently published IMF
statistics include the following 126 developing countries:
Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba,
The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan,
Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq,
Jamaica, Jordan, Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Morocco, Mozambique, Namibia, Nepal, Netherlands Antilles,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon
Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland,
Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
Zimbabwe; note - this category would presumably also cover the
following 46 other countries that are traditionally included in the
more comprehensive group of "less developed countries": American
Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands,
Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland
Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar,
Greenland, Grenada, Guadeloupe, Guam, Guernsey, Jersey, North Korea,
Macau, Isle of Man, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau,
Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and
Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin
Islands, Wallis and Futuna, West Bank, Western Sahara
_________________________________________________________________
East African Development Bank (EADB)
address - 4 Nile Avenue, P. O. Box 7128, Kampala, Uganda
telephone - [256] (41) 230021, 230825
FAX - [256] (41) 259763
established - 6 June 1967
effective - 1 December 1967
aim - to promote economic development
members - (3) Kenya, Tanzania, Uganda
_________________________________________________________________
Economic and Social Commission for Asia and the Pacific (ESCAP)
address - United Nations Building, Rajadamnern Avenue, Bangkok 10200,','62271cc2191f555e6a1ade36e96eb8778b71ba2a1e34ecf7f5357133533de99f','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cdf65b0729347ddf6323aaea7c6799e69abe71511f7f9ec1a96a4e541d5cf63',2000,'TH','Thailand','environment',251,'telephone - [66] (2) 2881234
FAX - [66] (2) 2881000
established - 28 March 1947 as Economic Commission for Asia and the
Far East (ECAFE)
aim - to carry out the commitment of the Economic and Social Council
of the UN to promote economic development
members - (51) Afghanistan, Armenia, Australia, Azerbaijan,
Bangladesh, Bhutan, Brunei, Burma, Cambodia, China, Fiji, France,
India, Indonesia, Iran, Japan, Kazakhstan, Kiribati, North Korea,
South Korea, Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands,
Federated States of Micronesia, Mongolia, Nauru, Nepal, Netherlands,
NZ, Pakistan, Palau, Papua New Guinea, Philippines, Russia, Samoa,
Singapore, Solomon Islands, Sri Lanka, Tajikistan, Thailand, Tonga,
Turkey, Turkmenistan, Tuvalu, UK, US, Uzbekistan, Vanuatu, Vietnam
associate members - (9) American Samoa, Cook Islands, French
Polynesia, Guam, Hong Kong, Macau, New Caledonia, Niue, Northern
Mariana Islands
_________________________________________________________________
Economic and Social Commission for Western Asia (ESCWA)
address - P. O. Box 11-8575, Riad El-Sohl Square, Beirut, Lebanon
telephone - [961] (10) 981301
FAX - [961] (10) 981510
established - 9 August 1973 as Economic Commission for Western Asia
(ECWA)
aim - to promote economic development as a regional commission for the
UN''s Economic and Social Council
members - (12 plus the Palestine Liberation Organization) Bahrain,
Egypt, Iraq, Jordan, Kuwait, Lebanon, Oman, Qatar, Saudi Arabia,
Syria, UAE, Yemen, Palestine Liberation Organization
_________________________________________________________________
Economic and Social Council (ECOSOC)
address - United Nations, New York, NY 10017, US
telephone - [1] (212) 963 1234
FAX - [1] (212) 758 2718
established - 26 June 1945
effective - 24 October 1945
aim - to coordinate the economic and social work of the UN; includes
five regional commissions (see Economic Commission for Africa,
Economic Commission for Europe, Economic Commission for Latin America
and the Caribbean, Economic and Social Commission for Asia and the
Pacific, Economic and Social Commission for Western Asia) and 10
functional commissions (see Commission for Social Development,
Commission on Human Rights, Commission on Narcotic Drugs, Commission
on the Status of Women, Commission on Population and Development,
Statistical Commission, Commission on Science and Technology for
Development, Commission on Sustainable Development, and Commission on
Crime Prevention and Criminal Justice)
members - (54) selected on a rotating basis from all regions
_________________________________________________________________
Economic Commission for Africa (ECA)
address - P. O. Box 3001-3005, Addis Ababa, Ethiopia
telephone - [251] (1) 51 72 00
FAX - [251] (1) 51 44 16
established - 29 April 1958
aim - to promote economic development as a regional commission of the
UN''s Economic and Social Council
members - (53) Algeria, Angola, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote
d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia,
Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho,
Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius,
Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa,
Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
associate members - (2) France, UK
_________________________________________________________________
Economic Commission for Asia and the Far East (ECAFE)
see Economic and Social Commission for Asia and the Pacific (ESCAP)
_________________________________________________________________
Economic Commission for Europe (ECE)
address - Palais des Nations, CH-1211 Geneva 10, Switzerland
telephone - [41] (22) 917 4444
FAX - [41] (22) 917 0505
established - 28 March 1947
aim - to promote economic development as a regional commission of the
UN''s Economic and Social Council
members - (55) Albania, Andorra, Armenia, Austria, Azerbaijan,
Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia,
Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia
_________________________________________________________________
Economic Commission for Latin America (ECLA)
see Economic Commission for Latin America and the Caribbean (ECLAC)
_________________________________________________________________
Economic Commission for Latin America and the Caribbean (ECLAC)
address - Edificio Naciones Unidas, Avenida Dag Hammarskjold, Casilla
179 D, Santiago, Chile
telephone - [56] (2) 2102000
FAX - [56] (2) 2080252, 2081946
established - 25 February 1948 as Economic Commission for Latin
America (ECLA)
aim - to promote economic development as a regional commission of the
UN''s Economic and Social Council
members - (41) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba,
Dominica, Dominican Republic, Ecuador, El Salvador, France, Grenada,
Guatemala, Guyana, Haiti, Honduras, Italy, Jamaica, Mexico,
Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Spain,
Suriname, Trinidad and Tobago, UK, US, Uruguay, Venezuela
associate members - (7) Anguilla, Aruba, British Virgin Islands,
Montserrat, Netherlands Antilles, Puerto Rico, Virgin Islands
_________________________________________________________________
Economic Commission for Western Asia (ECWA)
see Economic and Social Commission for Western Asia (ESCWA)
_________________________________________________________________
Economic Community of Central African States (CEEAC)
note - acronym from Communaute Economique des Etats de l''Afrique
Centrale
address - CEEAC, BP 2112, Libreville, Gabon
telephone - [241] 73 35 47, 73 35 48, 73 36 77
established - 18 October 1983 treaty adopted
aim - to promote regional economic cooperation and establish a Central
African Common Market
members - (11) Angola, Burundi, Cameroon, Central African Republic,
Chad, Democratic Republic of the Congo, Republic of the Congo,
Equatorial Guinea, Gabon, Rwanda, Sao Tome and Principe
_________________________________________________________________
Economic Community of the Great Lakes Countries (CEPGL)
note - acronym from Communaute Economique des Pays des Grands Lacs
address - IRAZ-CEPGL, BP 91, Gitega, Burundi
established - 20 September 1976
aim - to promote regional economic cooperation and integration
members - (3) Burundi, Democratic Republic of the Congo, Rwanda
_________________________________________________________________
Economic Community of West African States (ECOWAS)
address - 6 King George V Road, PMB 12745, Lagos, Nigeria
telephone - [234] (1) 636839, 636841, 636064, 630398
FAX - [234] (1) 636822
established - 28 May 1975
aim - to promote regional economic cooperation
members - (16) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The
Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Mauritania,
Niger, Nigeria, Senegal, Sierra Leone, Togo
_________________________________________________________________
Economic Cooperation Organization (ECO)
address - No. 1 Goulbou Alley, Kamraniyeh, P. O. Box 14155-6176,
Teheran, Iran Islamic Republic
telephone - [98] (21) 2831731, 2831733
FAX - [98] (21) 2831732
established - 27-29 January 1985
aim - to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members - (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
associate member - (1) "Turkish Republic of Northern Cyprus"
_________________________________________________________________
Euro-Atlantic Partnership Council (EAPC)
note - began as the North Atlantic Cooperation Council (NACC); an
extension of NATO
address - c/o NATO, B-1110 Brussels, Belgium
telephone - [32] (2) 728 41 11
FAX - [32] (2) 728 45 79
established - 8 November 1991
effective - 20 December 1991
aim - to discuss cooperation on mutual political and security issues
members - (44) Albania, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Moldova, Netherlands, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland,
Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
_________________________________________________________________
European Bank for Reconstruction and Development (EBRD)
address - EBRD Headquarters, One Exchange Square, London EC2A 2EH, UK
telephone - [44] (171) 338 6000
FAX - [44] (171) 338 6100
established - 8-9 January 1990 (proposals made); 15 April 1991 (bank
inaugurated)
aim - to facilitate the transition of seven centrally planned
economies in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland,
Romania, former USSR, and former Yugoslavia) to market economies by
committing 60% of its loans to privatization
members - (60) Albania, Armenia, Australia, Austria, Azerbaijan,
Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank
(EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Malta, Mexico, Moldova, Morocco,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan; note - includes all 25
members of the OECD; also includes the EU as a single entity
_________________________________________________________________
European Community (or European Communities, EC)
was established 8 April 1965 to integrate the European Atomic Energy
Community (Euratom), the European Coal and Steel Community (ESC), the
European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of
Europe; merged into the European Union (EU) on 7 February 1992; member
states at the time of merger were Belgium, Denmark, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
_________________________________________________________________
European Free Trade Association (EFTA)
address - 9-11 Rue de Varembe, CH-1211 Geneva 20, Switzerland
telephone - [41] (22) 749 11 11
FAX - [41] (22) 733 92 91
established - 4 January 1960
effective - 3 May 1960
aim - to promote expansion of free trade
members - (4) Iceland, Liechtenstein, Norway, Switzerland
_________________________________________________________________
European Investment Bank (EIB)
address - Boulevard Konrad Adenauer 100, L-2950 Luxembourg, Luxembourg
telephone - [352] 4379 3122
FAX - [352] 4379 3188, 4379 3189
established - 25 March 1957
effective - 1 January 1958
aim - to promote economic development of the EU and its predecessors,
the EEC and the EC
members - (15) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain,
Sweden, UK
_________________________________________________________________
European Monetary Union (EMU)
note - an integral part of the European Union; also known as the
European Economic and Monetary Union
address - c/o European Commission, Rue de la Loi 200, B-1049 Brussels,','4c50e39e1fb4415a937e22d677d0b51d00b3e1862cbc654c283569cd2ced2512','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a13b3795fca4a5aa89d6e45d85b1deb09dfcdcdfc31843cd57fd19c7cface7d8',2000,'BE','Belgium','environment',252,'telephone - [32] (2) 299 11 11
proposed - 1-2 December 1969 at summit conference of heads of','785c1e0e8463acfea1c605717ac37f28ca4b796234580cacf974c8f7b009c10a','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b17008e590ad3cf3895eff97e9f3f31832cba534fb3468b5891f975b791d03b',2000,'ZM','Zambia','environment',253,'parties - (132) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Barbados, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burma, Cameroon, Cape Verde, Chile, China, Comoros,
Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica,
Egypt, Equatorial Guinea, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Iceland, India, Indonesia,
Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, The Former Yugoslav Republic of Macedonia,
Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Monaco, Mongolia, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Philippines,
Poland, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago,
Tunisia, Uganda, Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen, former
Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (38) Afghanistan,
Bangladesh, Belarus, Bhutan, Burkina Faso, Burundi, Cambodia, Canada,
Central African Republic, Chad, Colombia, Republic of the Congo,
Denmark, Dominican Republic, El Salvador, Ethiopia, Hungary, Iran,
North Korea, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg,
Madagascar, Malawi, Maldives, Morocco, Nicaragua, Niger, Niue, Qatar,
Rwanda, Swaziland, Switzerland, Thailand, Tuvalu, UAE
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in
Africa
note - abbreviated as Desertification
opened for signature - 14 October 1994
entered into force - 26 December 1996
objective - to combat desertification and mitigate the effects of
drought through national action programs that incorporate long-term
strategies supported by international cooperation and partnership
arrangements
parties - (159) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Austria, Azerbaijan, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa
Rica, Cote d''Ivoire, Cuba, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho,
Liberia, Libya, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Paraguay, Peru, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Togo, Tonga, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, United Arab Emirates, UK, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (4) Australia,
Croatia, Philippines, US
United Nations Framework Convention on Climate Change
note - abbreviated as Climate Change
opened for signature - 9 May 1992
entered into force - 21 March 1994
objective - to achieve stabilization of greenhouse gas concentrations
in the atmosphere at a low enough level to prevent dangerous
anthropogenic interference with the climate system
parties - (181) Albania, Algeria, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, EU,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Libya,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (4) Afghanistan,
Angola, Belarus, Liberia
Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
______________________________________________________________________
@Appendix E: Weights and Measures
Mathematical Notation
Mathematical Power Name
10^18 or 1,000,000,000,000,000,000 one quintillion
10^15 or 1,000,000,000,000,000 one quadrillion
10^12 or 1,000,000,000,000 one trillion
10^9 or 1,000,000,000 one billion
10^6 or 1,000,000 one million
10^3 or 1,000 one thousand
10^2 or 100 one hundred
10^1 or 10 ten
10^0 or 1 one
10-^1 or 0.1 one-tenth
10-^2 or 0.01 one-hundredth
10-^3 or 0.001 one-thousandth
10-^6 or 0.000 001 one-millionth
10-^9 or 0.000 000 001 one-billionth
10-^12 or 0.000 000 000 001 one-trillionth
10-^15 or 0.000 000 000 000 001 one-quadrillionth
10-^18 or 0.000 000 000 000 000 001 one-quintillionth
Metric Interrelationships
Prefix Symbol Length, weight, or capacity Area Volume
exa E 10^18 10^36 10^54
peta P 10^15 10^30 10^45
tera T 10^12 10^24 10^36
giga G 10^9 10^18 10^27
mega M 10^6 10^12 10^18
hectokilo hk 10^5 10^10 10^15
myria ma 10^4 10^8 10^12
kilo k 10^3 10^6 10^9
hecto h 10^2 10^4 10^6
basic unit -- 1 meter, 1 gram, 1 liter 1 meter^2 1 meter^3
deci d 10-^1 10-^2 10-^3
centi c 10-^2 10-^4 10-^6
milli m 10-^3 10-^6 10-^9
decimilli dm 10-^4 10-^8 10-^12
centimilli cm 10-^5 10-^10 10-^15
micro u 10-^6 10-^12 10-^18
nano n 10-^9 10-^18 10-^27
pico p 10-^12 10-^24 10-^36
femto f 10-^15 10-^30 10-^45
atto a 10-^18 10-^36 10-^54
Conversion Factors
To Convert From To Multiply By
acres ares 40.468 564 224
acres hectares 0.404 685 642 24
acres square feet 43,560
acres square kilometers 0.004 046 856 422 4
acres square meters 4,046.856 422 4
acres square miles (statute) 0.001 562 50
acres square yards 4,840
ares square meters 100
ares square yards 119.599
barrels, US beer gallons 31
barrels, US beer liters 117.347 77
barrels, US petroleum gallons (British) 34.97
barrels, US petroleum gallons (US) 42
barrels, US petroleum liters 158.987 29
barrels, US proof spirits gallons 40
barrels, US proof spirits liters 151.416 47
bushels (US) bushels (British) 0.968 9
bushels (US) cubic feet 1.244 456
bushels (US) cubic inches 2,150.42
bushels (US) cubic meters 0.035 239 07
bushels (US) cubic yards 0.046 090 96
bushels (US) dekaliters 3.523 907
bushels (US) dry pints 64
bushels (US) dry quarts 32
bushels (US) liters 35.239 070 17
bushels (US) pecks 4
cables fathoms 120
cables meters 219.456
cables yards 240
carat milligrams 200
centimeters feet 0.032 808 40
centimeters inches 0.393 700 8
centimeters meters 0.01
centimeters yards 0.010 936 13
centimeters, cubic cubic inches 0.061 023 744
centimeters, square square feet 0.001 076 39
centimeters, square square inches 0.155 000 31
centimeters, square square meters 0.000 1
centimeters, square square yards 0.000 119 599
chains, square surveyor''s ares 4.046 86
chains, square surveyor''s square feet 4,356
chains, surveyor''s feet 66
chains, surveyor''s meters 20.116 8
chains, surveyor''s rods 4
cords of wood cubic feet 128
cords of wood cubic meters 3.624 556
cords of wood cubic yards 4.740 7
cups liquid ounces (US) 8
cups liters 0.236 588 2
degrees Celsius degrees Fahrenheit multiply by 1.8 and add 32
degrees Fahrenheit degrees Celsius subtract 32 and divide by 1.8
dekaliters bushels 0.283 775 9
dekaliters cubic feet 0.353 146 7
dekaliters cubic inches 610.237 4
dekaliters dry pints 18.161 66
dekaliters dry quarts 9.080 829 8
dekaliters liters 10
dekaliters pecks 1.135 104
drams, avoirdupois avoirdupois ounces 0.062 55
drams, avoirdupois grains 27.344
drams, avoirdupois grams 1.771 845 2
drams, troy grains 60
drams, troy grams 3.887 934 6
drams, troy scruples 3
drams, troy troy ounces 0.125
drams, liquid (US) cubic inches 0.226
drams, liquid (US) liquid drams (British) 1.041
drams, liquid (US) liquid ounces 0.125
drams, liquid (US) milliliters 3.696 69
drams, liquid (US) minims 60
fathoms feet 6
fathoms meters 1.828 8
feet centimeters 30.48
feet inches 12
feet kilometers 0.000 304 8
feet meters 0.304 8
feet statute miles 0.000 189 39
feet yards 0.333 333 3
feet, cubic bushels 0.803 563 95
feet, cubic cubic decimeters 28.316 847
feet, cubic cubic inches 1,728
feet, cubic cubic meters 0.028 316 846 592
feet, cubic cubic yards 0.037 037 04
feet, cubic dry pints 51.428 09
feet, cubic dry quarts 25.714 05
feet, cubic gallons 7.480 519
feet, cubic gills 239.376 6
feet, cubic liquid ounces 957.506 5
feet, cubic liquid pints 59.844 16
feet, cubic liquid quarts 29.922 08
feet, cubic liters 28.316 846 592
feet, cubic pecks 3.214 256
feet, square acres 0.000 022 956 8
feet, square square centimeters 929.030 4
feet, square square decimeters 9.290 304
feet, square square inches 144
feet, square square meters 0.092 903 04
feet, square square yards 0.111 111 1
furlongs feet 660
furlongs inches 7,920
furlongs meters 201.168
furlongs statute miles 0.125
furlongs yards 220
gallons, liquid (US) cubic feet 0.133 680 6
gallons, liquid (US) cubic inches 231
gallons, liquid (US) cubic meters 0.003 785 411 784
gallons, liquid (US) cubic yards 0.004 951 13
gallons, liquid (US) gills (US) 32
gallons, liquid (US) liquid gallons (British) 0.832 67
gallons, liquid (US) liquid ounces 128
gallons, liquid (US) liquid pints 8
gallons, liquid (US) liquid quarts 4
gallons, liquid (US) liters 3.785 411 784
gallons, liquid (US) milliliters 3,785.411 784
gallons, liquid (US) minims 61,440
gills (US) centiliters 11.829 4
gills (US) cubic feet 0.004 177 517
gills (US) cubic inches 7.218 75
gills (US) gallons 0.031 25
gills (US) gills (British) 0.832 67
gills (US) liquid ounces 4
gills (US) liquid pints 0.25
gills (US) liquid quarts 0.125
gills (US) liters 0.118 294 118 25
gills (US) milliliters 118.294 118 25
gills (US) minims 1,920
grains avoirdupois drams 0.036 571 43
grains avoirdupois ounces 0.002 285 71
grains avoirdupois pounds 0.000 142 86
grains grams 0.064 798 91
grains kilograms 0.000 064 798 91
grains milligrams 64.798 910
grains pennyweights 0.042
grains scruples 0.05
grains troy drams 0.016 6
grains troy ounces 0.002 083 33
grains troy pounds 0.000 173 61
grams avoirdupois drams 0.564 383 39
grams avoirdupois ounces 0.035 273 961
grams avoirdupois pounds 0.002 204 622 6
grams grains 15.432 361
grams kilograms 0.001
grams milligrams 1,000
grams troy ounces 0.032 150 746 6
grams troy pounds 0.002 679 23
hands (height of horse) centimeters 10.16
hands (height of horse) inches 4
hectares acres 2.471 053 8
hectares square feet 107,639.1
hectares square kilometers 0.01
hectares square meters 10,000
hectares square miles 0.003 861 02
hectares square yards 11,959.90
hundredweights, long avoirdupois pounds 112
hundredweights, long kilograms 50.802 345
hundredweights, long long tons 0.05
hundredweights, long metric tons 0.050 802 345
hundredweights, long short tons 0.056
hundredweights, short avoirdupois pounds 100
hundredweights, short kilograms 45.359 237
hundredweights, short long tons 0.044 642 86
hundredweights, short metric tons 0.045 359 237
hundredweights, short short tons 0.05
inches centimeters 2.54
inches feet 0.083 333 33
inches meters 0.025 4
inches millimeters 25.4
inches yards 0.027 777 78
inches, cubic bushels 0.000 465 025
inches, cubic cubic centimeters 16.387 064
inches, cubic cubic feet 0.000 578 703 7
inches, cubic cubic meters 0.000 016 387 064
inches, cubic cubic yards 0.000 021 433 47
inches, cubic dry pints 0.029 761 6
inches, cubic dry quarts 0.014 880 8
inches, cubic gallons 0.004 329 0
inches, cubic gills 0.138 528 1
inches, cubic liquid ounces 0.554 112 6
inches, cubic liquid pints 0.034 632 03
inches, cubic liquid quarts 0.017 316 02
inches, cubic liters 0.016 387 064
inches, cubic milliliters 16.387 064
inches, cubic minims (US) 265.974 0
inches, cubic pecks 0.001 860 10
inches, square square centimeters 6.451 600
inches, square square feet 0.006 944 44
inches, square square meters 0.000 645 16
inches, square square yards 0.000 771 605
kilograms avoirdupois drams 564.383 4
kilograms avoirdupois ounces 35.273 962
kilograms avoirdupois pounds 2.204 622 622
kilograms grains 15,432.36
kilograms grams 1,000
kilograms long tons 0.000 984 2
kilograms metric tons 0.001
kilograms short hundredweights 0.022 046 23
kilograms short tons 0.001 102 31
kilograms troy ounces 32.150 75
kilograms troy pounds 2.679 229
kilometers meters 1,000
kilometers statute miles 0.621 371 192
kilometers, square acres 247.105 38
kilometers, square hectares 100
kilometers, square square meters 1,000,000
kilometers, square statute miles 0.386 102 16
knots (nautical mi/hr) kilometers/hour 1.852
knots (nautical mi/hr) statute miles/hour 1.151
leagues, nautical kilometers 5.556
leagues, nautical nautical miles 3
leagues, statute kilometers 4.828 032
leagues, statute statute miles 3
links, square surveyor''s square centimeters 404.686
links, square surveyor''s square inches 62.726 4
links, surveyor''s centimeters 20.116 8
links, surveyor''s chains 0.01
links, surveyor''s inches 7.92
liters bushels 0.028 377 59
liters cubic feet 0.035 314 67
liters cubic inches 61.023 74
liters cubic meters 0.001
liters cubic yards 0.001 307 95
liters dekaliters 0.1
liters dry pints 1.816 166
liters dry quarts 0.908 082 98
liters gallons 0.264 172 052
liters gills (US) 8.453 506
liters liquid ounces 33.814 02
liters liquid pints 2.113 376
liters liquid quarts 1.056 688 2
liters milliliters 1,000
liters pecks 0.113 510 4
meters centimeters 100
meters feet 3.280 839 895
meters inches 39.370 079
meters kilometers 0.001
meters millimeters 1,000
meters statute miles 0.000 621 371
meters yards 1.093 613 298
meters, cubic bushels 28.377 59
meters, cubic cubic feet 35.314 666 7
meters, cubic cubic inches 61,023.744
meters, cubic cubic yards 1.307 950 619
meters, cubic gallons 264.172 05
meters, cubic liters 1,000
meters, cubic pecks 113.510 4
meters, square acres 0.000 247 105 38
meters, square hectares 0.000 1
meters, square square centimeters 10,000
meters, square square feet 10.763 910 4
meters, square square inches 1,550.003 1
meters, square square yards 1.195 990 046
microns meters 0.000 001
microns inches 0.000 039 4
mils inches 0.001
mils millimeters 0.025 4
miles, nautical kilometers 1.852 0
miles, nautical statute miles 1.150 779 4
miles, statute centimeters 160,934.4
miles, statute feet 5,280
miles, statute furlongs 8
miles, statute inches 63,360
miles, statute kilometers 1.609 344
miles, statute meters 1,609.344
miles, statute rods 320
miles, statute yards 1,760
miles, square nautical square kilometers 3.429 904
miles, square nautical square statute miles 1.325
miles, square statute acres 640
miles, square statute hectares 258.998 811 033 6
miles, square statute sections 1
miles, square statute square kilometers 2.589 988 110 336
miles, square statute square nautical miles 0.755 miles
miles, square statute square rods 102,400
milligrams grains 0.015 432 358 35
milliliters cubic inches 0.061 023 744
milliliters gallons 0.000 264 17
milliliters gills (US) 0.008 453 5
milliliters liquid ounces 0.033 814 02
milliliters liquid pints 0.002 113 4
milliliters liquid quarts 0.001 056 7
milliliters liters 0.001
milliliters minims 16.230 73
millimeters inches 0.039 370 078 7
minims (US) cubic inches 0.003 759 77
minims (US) gills (US) 0.000 520 83
minims (US) liquid ounces 0.002 083 33
minims (US) milliliters 0.061 611 52
minims (US) minims (British) 1.041
ounces, avoirdupois avoirdupois drams 16
ounces, avoirdupois avoirdupois pounds 0.062 5
ounces, avoirdupois grains 437.5
ounces, avoirdupois grams 28.349 523 125
ounces, avoirdupois kilograms 0.028 349 523 125
ounces, avoirdupois troy ounces 0.911 458 3
ounces, avoirdupois troy pounds 0.075 954 86
ounces, liquid (US) cubic feet 0.001 044 38
ounces, liquid (US) centiliters 2.957 35
ounces, liquid (US) cubic inches 1.804 687 5
ounces, liquid (US) gallons 0.007 812 5
ounces, liquid (US) gills (US) 0.25
ounces, liquid (US) liquid drams 8
ounces, liquid (US) liquid ounces (British) 1.041
ounces, liquid (US) liquid pints 0.062 5
ounces, liquid (US) liquid quarts 0.031 25
ounces, liquid (US) liters 0.029 573 53
ounces, liquid (US) milliliters 29.573 529 6
ounces, liquid (US) minims 480
ounces, troy avoirdupois drams 17.554 29
ounces, troy avoirdupois ounces 1.097 143
ounces, troy avoirdupois pounds 0.068 571 43
ounces, troy grains 480
ounces, troy grams 31.103 476 8
ounces, troy pennyweights 20
ounces, troy troy drams 8
ounces, troy troy pounds 0.083 333 3
paces (US) centimeters 76.2
paces (US) inches 30
pecks (US) bushels 0.25
pecks (US) cubic feet 0.311 114
pecks (US) cubic inches 537.605
pecks (US) cubic meters 0.008 809 77
pecks (US) cubic yards 0.011 522 74
pecks (US) dekaliters 0.880 976 75
pecks (US) dry pints 16
pecks (US) dry quarts 8
pecks (US) liters 8.809 767 5
pecks (US) pecks (British) 0.968 9
pennyweights grains 24
pennyweights grams 1.555 173 84
pennyweights troy ounces 0.05
pints, dry (US) bushels 0.015 625
pints, dry (US) cubic feet 0.019 444 63
pints, dry (US) cubic inches 33.600 312 5
pints, dry (US) dekaliters 0.055 061 05
pints, dry (US) dry pints (British) 0.968 9
pints, dry (US) dry quarts 0.5
pints, dry (US) liters 0.550 610 47
pints, liquid (US) cubic feet 0.016 710 07
pints, liquid (US) cubic inches 28.875
pints, liquid (US) deciliters 4.731 76
pints, liquid (US) gallons 0.125
pints, liquid (US) gills (US) 4
pints, liquid (US) liquid ounces 16
pints, liquid (US) liquid pints (British) 0.832 67
pints, liquid (US) liquid quarts 0.5
pints, liquid (US) liters 0.473 176 473
pints, liquid (US) milliliters 473.176 473
pints, liquid (US) minims 7,680
points (typographical) inches 0.013 837
points (typographical) millimeters 0.351 459 8
pounds, avoirdupois avoirdupois drams 256
pounds, avoirdupois avoirdupois ounces 16
pounds, avoirdupois grains 7,000
pounds, avoirdupois grams 453.592 37
pounds, avoirdupois kilograms 0.453 592 37
pounds, avoirdupois long tons 0.000 446 428 6
pounds, avoirdupois metric tons 0.000 453 592 37
pounds, avoirdupois quintals 0.004 535 92
pounds, avoirdupois short tons 0.000 5
pounds, avoirdupois troy ounces 14.583 33
pounds, avoirdupois troy pounds 1.215 278
pounds, troy avoirdupois drams 210.651 4
pounds, troy avoirdupois ounces 13.165 71
pounds, troy avoirdupois pounds 0.822 857 1
pounds, troy grains 5,760
pounds, troy grams 373.241 721 6
pounds, troy kilograms 0.373 241 721 6
pounds, troy pennyweights 240
pounds, troy troy ounces 12
quarts, dry (US) bushels 0.031 25
quarts, dry (US) cubic feet 0.038 889 25
quarts, dry (US) cubic inches 67.200 625
quarts, dry (US) dekaliters 0.110 122 1
quarts, dry (US) dry pints 2
quarts, dry (US) dry quarts (British) 0.968 9
quarts, dry (US) liters 1.101 221
quarts, dry (US) pecks 0.125
quarts, dry (US) pints, dry (US) 2
quarts, liquid (US) cubic feet 0.033 420 14
quarts, liquid (US) cubic inches 57.75
quarts, liquid (US) deciliters 9.463 53
quarts, liquid (US) gallons 0.25
quarts, liquid (US) gills (US) 8
quarts, liquid (US) liquid ounces 32
quarts, liquid (US) liquid pints (US) 2
quarts, liquid (US) liquid quarts (British) 0.832 67
quarts, liquid (US) liters 0.946 352 946
quarts, liquid (US) milliliters 946.352 946
quarts, liquid (US) minims 15,360
quintals avoirdupois pounds 220.462 26
quintals kilograms 100
quintals metric tons 0.1
rods feet 16.5
rods meters 5.029 2
rods yards 5.5
rods, square acres 0.006 25
rods, square square meters 25.292 85
rods, square square yards 30.25
scruples grains 20
scruples grams 1.295 978 2
scruples troy drams 0.333
sections (US) square kilometers 2.589 988 1
sections (US) square statute miles 1
spans centimeters 22.86
spans inches 9
steres cubic meters 1
steres cubic yards 1.307 95
tablespoons milliliters 14.786 76
tablespoons teaspoons 3
teaspoons milliliters 4.928 922
teaspoons tablespoons 0.333 333
ton-miles, long metric ton-kilometers 1.635 169
ton-miles, short metric ton-kilometers 1.459 972
tons, gross register cubic feet of permanently enclosed space 100
tons, gross register cubic meters of permanently enclosed space 2.831 684 7
tons, long (deadweight) avoirdupois ounces 35,840
tons, long (deadweight) avoirdupois pounds 2,240
tons, long (deadweight) kilograms 1,016.046 909 8
tons, long (deadweight) long hundredweights 20
tons, long (deadweight) metric tons 1.016 046 908 8
tons, long (deadweight) short hundredweights 22.4
tons, long (deadweight) short tons 1.12
tons, metric avoirdupois pounds 2,204.623
tons, metric kilograms 1,000
tons, metric long hundredweights 19.684 130 3
tons, metric long tons 0.984 206 5
tons, metric quintals 10
tons, metric short hundredweights 22.046 23
tons, metric short tons 1.102 311 3
tons, metric troy ounces 32,150.75
tons, net register cubic feet of permanently enclosed space
for cargo and passengers 100
tons, net register cubic meters of permanently enclosed space
for cargo and passengers 2.831 684 7
tons, shipping cubic feet of permanently enclosed cargo space 42
tons, shipping cubic meters of permanently enclosed cargo space 1.189 307 574
tons, short avoirdupois pounds 2,000
tons, short kilograms 907.184 74
tons, short long hundredweights 17.857 14
tons, short long tons 0.892 857 1
tons, short metric tons 0.907 184 74
tons, short short hundredweights 20
townships (US) sections 36
townships (US) square kilometers 93.239 572
townships (US) square statute miles 36
miles, square statute acres 640
miles, square statute hectares 258.998 811 033 6
miles, square statute square feet 27,878,400
miles, square statute square meters 2,5','5c5c14a764e1942abb6730595a46a03377ff41dc91839baebe8ee5d9032d4246','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d6f3fe51fc1cfc0b42eaf12ffb9ae9a5a4cbec3ac05dd0e952d9c027bc14b1f',2000,'ZM','Zambia','environment',254,'89,988.110 336
miles, square statute square yards 3,097,600
yards centimeters 91.44
yards feet 3
yards inches 36
yards meters 0.914 4
yards miles 0.000 568 18
yards, cubic bushels 21.696 227
yards, cubic cubic feet 27
yards, cubic cubic inches 46,656
yards, cubic cubic meters 0.764 554 857 984
yards, cubic gallons 201.974 0
yards, cubic liters 764.554 857 984
yards, cubic pecks 86.784 91
yards, square acres 0.000 206 611 6
yards, square hectares 0.000 083 612 736
yards, square square centimeters 8,361.273 6
yards, square square feet 9
yards, square square inches 1,296
yards, square square meters 0.836 127 36
yards, square square miles 0.000 000 322 830 6
_________________________________________________________________
Note: At this time, only three countries - Burma, Liberia, and the US
- have not adopted the International System of Units (SI, or metric
system) as their official system of weights and measures. Although use
of the metric system has been sanctioned by law in the US since 1866,
it has been slow in displacing the American adaptation of the British
Imperial System known as the US Customary System. The US is the only
industrialized nation that does not mainly use the metric system in
its commercial and standards activities, but there is increasing
acceptance in science, medicine, government, and many sectors of
industry.
______________________________________________________________________
@Appendix F: Cross-Reference List of Country Data Codes
FIPS 10-4: Countries, Dependencies, Areas of Special Sovereignty, and
Their Principal Administrative Divisions (FIPS PUB 10-4) is maintained
by the Office of the Geographer and Global Issues (Department of
State) and published by the National Institute of Standards and
Technology (Department of Commerce). These two-character alphabetic
codes are included in the text of the Factbook in the Data code entry
under the Government category. FIPS 10-4 codes are intended for
general use throughout the US Government, especially in activities
associated with the mission of the Department of State and national
defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO
3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic
codes and three-digit numeric codes that may be needed for activities
involving exchange of data with international organizations that have
adopted that standard. Except for the numeric codes, ISO 3166 codes
have been adopted in the US as FIPS 104-1: American National Standard
Codes for the Representation of Names of Countries, Dependencies, and
Areas of Special Sovereignty for Information Interchange.
Internet: This is a provisional compilation that generally agrees with
the ISO 3166 two-character alphabetic codes.
Entity FIPS 10-4 ISO 3166 Internet Comment
Afghanistan AF AF AFG 004 AF
Albania AL AL ALB 008 AL
Algeria AG DZ DZA 012 DZ
American Samoa AQ AS ASM 016AS
Andorra AN AD AND 020 AD
Angola AO AO AGO 024 AO
Anguilla AV AI AIA 660 AI
Antarctica AY AQ ATA 010 AQ ISO defines as the territory south of 60
degrees south latitude
Antigua and Barbuda AC AG ATG 028 AG
Argentina AR AR ARG 032 AR
Armenia AM AM ARM 051 AM
Aruba AA AW ABW 533 AW
Ashmore and Cartier Islands AT -- -- -- -- ISO includes with Australia
Australia AS AU AUS 036 AU ISO includes Ashmore and Cartier
Austria AU AT AUT 040 AT
Azerbaijan AJ AZ AZE 031 AZ
The Bahamas BF BS BHS 044 BS
Bahrain BA BH BHR 048 BH
Baker Island FQ -- -- -- -- ISO includes with the US Minor Outlying Islands
Bangladesh BG BD BGD 050 BD
Barbados BB BB BRB 052 BB
Bassas da India BS -- -- -- -- ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Belarus BO BY BLR 112 BY
Belgium BE BE BEL 056 BE
Belize BH BZ BLZ 084 BZ
Benin BN BJ BEN 204 BJ
Bermuda BD BM BMU 060 BM
Bhutan BT BT BTN 064 BT
Bolivia BL BO BOL 068 BO
Bosnia and Herzegovina BK BA BIH 070 BA
Botswana BC BW BWA 072 BW
Bouvet Island BV BV BVT 074 BV
Brazil BR BR BRA 076 BR
British Indian Ocean Territory IO IO IOT 086 IO
British Virgin Islands VI VG VGB 092 VG
Brunei BX BN BRN 096 BN
Bulgaria BU BG BGR 100 BG
Burkina Faso UV BF BFA 854 BF
Burma BM MM MMR 104 MM ISO uses the name Myanmar
Burundi BY BI BDI 108 BI
Cambodia CB KH KHM 116 KH
Cameroon CM CM CMR 120 CM
Canada CA CA CAN 124 CA
Cape Verde CV CV CPV 132 CV
Cayman Islands CJ KY CYM 136 KY
Central African Republic CT CF CAF 140 CF
Chad CD TD TCD 148 TD
Chile CI CL CHL 152 CL
China CH CN CHN 156 CN see also Taiwan
Christmas Island KT CX CXR 162 CX
Clipperton Island IP -- -- -- -- ISO includes with French Polynesia
Cocos (Keeling) Islands CK CC CCK 166 CC
Colombia CO CO COL 170 CO
Comoros CN KM COM 174 KM
Congo, Democratic Republic of the CG ZR ZAR 180 ZR formerly Zaire
Congo, Republic of the CF CG COG 178 CG
Cook Islands CW CK COK 184 CK
Coral Sea Islands CR -- -- -- -- ISO includes with Australia
Costa Rica CS CR CRI 188 CR
Cote d''Ivoire IV CI CIV 384 CI
Croatia HR HR HRV 191 HR
Cuba CU CU CUB 192 CU
Cyprus CY CY CYP 196 CY
Czech Republic EZ CZ CZE 203 CZ
Denmark DA DK DNK 208 DK
Djibouti DJ DJ DJI 262 DJ
Dominica DO DM DMA 212 DM
Dominican Republic DR DO DOM 214 DO
East Timor - TP TMP 626 TP FIPS includes with Indonesia
Ecuador EC EC ECU 218 EC
Egypt EG EG EGY 818 EG
El Salvador ES SV SLV 222 SV
Equatorial Guinea EK GQ GNQ 226 GQ
Eritrea ER ER ERI 232 ER
Estonia EN EE EST 233 EE
Ethiopia ET ET ETH 231 ET
Europa Island EU -- -- -- -- ISO includes with the Miscellaneous
Falkland Islands (Islas Malvinas) FA FK FLK 238 FK
Faroe Islands FO FO FRO 234 FO
Fiji FJ FJ FJI 242 FJ
Finland FI FI FIN 246 FI
France FR FR FRA 250 FR
France, Metropolitan -- FX FXX 249 FX ISO limits to the European part
of France, excluding French Guiana, French Polynesia, French Southern
and Antarctic Lands, Guadeloupe, Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon, Wallis and Futuna
French Guiana FG GF GUF 254 GF
French Polynesia FP PF PYF 258 PF ISO includes Clipperton Island
French Southern and Antarctic Lands FS TF ATF 260 -- FIPS 10-4 does
not include the French-claimed portion of Antarctica (Terre Adelie)
Gabon GB GA GAB 266 GA
The Gambia GA GM GMB 270 GM
Gaza Strip GZ - - - -
Georgia GG GE GEO 268 GE
Germany GM DE DEU 276 DE
Ghana GH GH GHA 288 GH
Gibraltar GI GI GIB 292 GI
Glorioso Islands GO -- -- -- -- ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Greece GR GR GRC 300 GR
Greenland GL GL GRL 304 GL
Grenada GJ GD GRD 308 GD
Guadeloupe GP GP GLP 312 GP
Guam GQ GU GUM 316 GU
Guatemala GT GT GTM 320 GT
Guernsey GK -- -- -- -- ISO includes with the United Kingdom
Guinea GV GN GIN 324 GN
Guinea-Bissau PU GW GNB 624 GW
Guyana GY GY GUY 328 GY
Haiti HA HT HTI 332 HT
Heard Island and McDonald Islands HM HM HMD 334 HM
Holy See (Vatican City) VT VA VAT 336 VA
Honduras HO HN HND 340 HN
Hong Kong HK HK HKG 344 HK
Howland Island HQ -- -- -- -- ISO includes with the US Minor Outlying
Islands
Hungary HU HU HUN 348 HU
Iceland IC IS ISL 352 IS
India IN IN IND 356 IN
Indonesia ID ID IDN 360 ID
Iran IR IR IRN 364 IR
Iraq IZ IQ IRQ 368 IQ
Ireland EI IE IRL 372 IE
Israel IS IL ISR 376 IL
Italy IT IT ITA 380 IT
Jamaica JM JM JAM 388 JM
Jan Mayen JN -- -- -- -- ISO includes with Svalbard
Japan JA JP JPN 392 JP
Jarvis Island DQ -- -- -- -- ISO includes with the US Minor Outlying
Islands
Jersey JE -- -- -- -- ISO includes with the United Kingdom
Johnston Atoll JQ -- -- -- -- ISO includes with the US Minor Outlying
Islands
Jordan JO JO JOR 400 JO
Juan de Nova Island JU -- -- -- -- ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Kazakhstan KZ KZ KAZ 398 KZ
Kenya KE KE KEN 404 KE
Kingman Reef KQ -- -- -- -- ISO includes with the US Minor Outlying
Islands
Kiribati KR KI KIR 296 KI
Korea, North KN KP PRK 408 KP
Korea, South KS KR KOR 410 KR
Kuwait KU KW KWT 414 KW
Kyrgyzstan KG KG KGZ 417 KG
Laos LA LA LAO 418 LA
Latvia LG LV LVA 428 LV
Lebanon LE LB LBN 422 LB
Lesotho LT LS LSO 426 LS
Liberia LI LR LBR 430 LR
Libya LY LY LBY 434 LY
Liechtenstein LS LI LIE 438 LI
Lithuania LH LT LTU 440 LT
Luxembourg LU LU LUX 442 LU
Macau MC MO MAC 446 MO
Macedonia, The Republic of MK MK MKD 807 MK
Madagascar MA MG MDG 450 MG
Malawi MI MW MWI 454 MW
Malaysia MY MY MYS 458 MY
Maldives MV MV MDV 462 MV
Mali ML ML MLI 466 ML
Malta MT MT MLT 470 MT
Man, Isle of IM -- -- -- -- ISO includes with the United Kingdom
Marshall Islands RM MH MHL 584 MH
Martinique MB MQ MTQ 474 MQ
Mauritania MR MR MRT 478 MR
Mauritius MP MU MUS 480 MU
Mayotte MF YT MYT 175 YT
Mexico MX MX MEX 484 MX
Micronesia, Federated States of FM FM FSM 583 FM
Midway Islands MQ -- -- -- -- ISO includes with the US Minor Outlying
Islands
Miscellaneous (French) -- -- -- -- ISO includes Bassas da India,
Europa Island, Glorioso Islands, Juan de Nova Island, Tromelin Island
Moldova MD MD MDA 498 MD
Monaco MN MC MCO 492 MC
Mongolia MG MN MNG 496 MN
Montenegro* MW -- -- -- -- see footnote at end of table
Montserrat MH MS MSR 500 MS
Morocco MO MA MAR 504 MA
Mozambique MZ MZ MOZ 508 MZ
Myanmar -- -- -- -- -- see Burma
Namibia WA NA NAM 516 NA
Nauru NR NR NRU 520 NR
Navassa Island BQ - - - -
Nepal NP NP NPL 524 NP
Netherlands NL NL NLD 528 NL
Netherlands Antilles NT AN ANT 530 AN
New Caledonia NC NC NCL 540 NC
New Zealand NZ NZ NZL 554 NZ
Nicaragua NU NI NIC 558 NI
Niger NG NE NER 562 NE
Nigeria NI NG NGA 566 NG
Niue NE NU NIU 570 NU
Norfolk Island NF NF NFK 574 NF
Northern Mariana Islands CQ MP MNP 580 MP
Norway NO NO NOR 578 NO
Oman MU OM OMN 512 OM
Pakistan PK PK PAK 586 PK
Palau PS PW PLW 585 PW
Palmyra Atoll LQ -- -- -- -- ISO includes with the US Minor Outlying
Islands
Panama PM PA PAN 591 PA
Papua New Guinea PP PG PNG 598 PG
Paracel Islands PF - - - -
Paraguay PA PY PRY 600 PY
Peru PE PE PER 604 PE
Philippines RP PH PHL 608 PH
Pitcairn Islands PC PN PCN 612 PN
Poland PL PL POL 616 PL
Portugal PO PT PRT 620 PT
Puerto Rico RQ PR PRI 630 PR
Qatar QA QA QAT 634 QA
Reunion RE RE REU 638 RE
Romania RO RO ROM 642 RO
Russia RS RU RUS 643 RU
Rwanda RW RW RWA 646 RW
Saint Helena SH SH SHN 654 SH
Saint Kitts and Nevis SC KN KNA 659 KN
Saint Lucia ST LC LCA 662 LC
Saint Pierre and Miquelon SB PM SPM 666 PM
Saint Vincent and the Grenadines VC VC VCT 670 VC
Samoa WS WS WSM 882 WS
San Marino SM SM SMR 674 SM
Sao Tome and Principe TP ST STP 678 ST
Saudi Arabia SA SA SAU 682 SA
Senegal SG SN SEN 686 SN
Serbia* SR -- -- -- -- see footnote at end of table
Serbia and Montenegro* -- -- -- -- -- see footnote at end of table
Seychelles SE SC SYC 690 SC
Sierra Leone SL SL SLE 694 SL
Singapore SN SG SGP 702 SG
Slovakia LO SK SVK 703 SK
Slovenia SI SI SVN 705 SI
Solomon Islands BP SB SLB 090 SB
Somalia SO SO SOM 706 SO
South Africa SF ZA ZAF 710 ZA
South Georgia and the South Sandwich Islands SX GS SGS 239 GS
Spain SP ES ESP 724 ES
Spratly Islands PG -- -- -- --
Sri Lanka CE LK LKA 144 LK
Sudan SU SD SDN 736 SD
Suriname NS SR SUR 740 SR
Svalbard SV SJ SJM 744 SJ ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 SZ
Sweden SW SE SWE 752 SE
Switzerland SZ CH CHE 756 CH
Syria SY SY SYR 760 SY
Taiwan TW TW TWN 158 TW
Tajikistan TI TJ TJK 762 TJ
Tanzania TZ TZ TZA 834 TZ
Thailand TH TH THA 764 TH
Togo TO TG TGO 768 TG
Tokelau TL TK TKL 772 TK
Tonga TN TO TON 776 TO
Trinidad and Tobago TD TT TTO 780 TT
Tromelin Island TE -- -- -- -- ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Tunisia TS TN TUN 788 TN
Turkey TU TR TUR 792 TR
Turkmenistan TX TM TKM 795 TM
Turks and Caicos Islands TK TC TCA 796 TC
Tuvalu TV TV TUV 798 TV
Uganda UG UG UGA 800 UG
Ukraine UP UA UKR 804 UA
United Arab Emirates TC AE ARE 784 AE
United Kingdom UK GB GBR 826 UK/GB ISO includes Guernsey, Isle of Man, Jersey
United States US US USA 840 US
United States Minor Outlying Islands - UM UMI 581 UM ISO includes Baker
Island, Howland Island, Jarvis Island, Johnston Atoll, Kingman Reef,
Midway Islands, Palmyra Atoll, Wake Island
Uruguay UY UY URY 858 UY
Uzbekistan UZ UZ UZB 860 UZ
Vanuatu NH VU VUT 548 VU
Venezuela VE VE VEN 862 UE
Vietnam VM VN VNM 704 VN
Virgin Islands VQ VI VIR 850 VI
Virgin Islands (UK) - - - - - see British Virgin Islands
Virgin Islands (US) - - - - - see Virgin Islands
Wake Island WQ - - - - ISO includes with the US Minor Outlying Islands
Wallis and Futuna WF WF WLF 876 WF
West Bank WE - - - -
Western Sahara WI EH ESH 732 EH
Western Samoa - - - - - see Samoa
World - - - - - the Factbook uses the W data code from
DIAM 65-18 Geopolitical Data Elements and Related Features, Data Standard
No. 3, December 1994, published by the Defense Intelligence Agency
Yemen YM YE YEM 887 YE
Yugoslavia* - YU YUG 891 YU see footnote at end of table
Zaire - - - - - see Democratic Republic of the Congo
Zambia ZA ZM ZWB 894 ZM
Zimbabwe ZI ZW ZWE 716 ZW
_________________________________________________________________
*Serbia and Montenegro have asserted the formation of a joint
independent state, but this entity has not been formally recognized as
a state by the US;
the US view is that the Socialist Federal Republic of Yugoslavia
(SFRY) has dissolved and that none of the successor republics
represents its continuation.
______________________________________________________________________
@Appendix G: Cross-Reference List of Hydrographic Data Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft
4th Edition 1986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd
Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC),
United States Air Force; note - ACIC is now part of the National
Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data
Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic
codes similar to the Federal Information Processing Standards (FIPS)
10-4 country codes. The names and limits of the following oceans and
seas are not always directly comparable because of differences in the
customers, needs, and requirements of the individual organizations.
Even the number of principal water bodies varies from organization to
organization. Factbook users, for example, find the Atlantic Ocean and
Pacific Ocean entries useful, but none of the following standards
include those oceans in their entirety. Nor is there any provision for
combining codes or overcodes to aggregate water bodies. The recently
delimited Southern Ocean is not included.
Principal Oceans and Seas of the World With Hydrographic Codes by
Institution IHO
23-4th IHO
23-3rd* ACIC
M 49-1 DIAM
65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean - - - -
North Atlantic Ocean 1 23 B 1A
South Atlantic Ocean 4 32 C 2A
Baltic Sea 2 1 B26 7B
Indian Ocean 5 45 F 6A
Mediterranean Sea 3.1 28 B11 -
Eastern Mediterranean 3.1.2 28 B - 8E
Western Mediterranean 3.1.1 28 A - 8W
Pacific Ocean - - - -
North Pacific Ocean 7 57 D 3A
South Pacific Ocean 8 61 E 4A
South China and Eastern Archipelagic Seas 6 49, 48 D18 plus others 3U
plus others
Oceans and Seas of the World With Hydrographic Codes by Institution
IHO
23-4th IHO
23-3rd* ACIC
M 49-1 DIAM
65-18
ARCTIC OCEAN 9 17 A 5A
East Siberian Sea 9.1 11 A6 5S
Laptev Sea 9.2 10 A5 5P
Kara Sea 9.3 9 A4 5K
Barents Sea 9.4 7 A2 5B
White Sea 9.5 8 A3 5W
North Greenland Sea 9.6 - - -
Norwegian Sea 9.7 6 B30 5N
Iceland Sea 9.8 - - -
Davis Strait 9.9 15 B2 1V
Hudson Strait 9.10 16 A A15 1U
Hudson Bay 9.11 16 A10 1H
Baffin Bay 9.12 14 A A12 1P
Lincoln Sea 9.13 17 A A13 5L
Northwest Passages
(Northwest Passage, Northwestern Passages) 9.14 14 A9 5T
Beaufort Sea 9.15 13 A8 5U
Chukchi Sea 9.16 12 A7 5C
James Bay - - A11 -
Kane Basin - - A14 -
ATLANTIC OCEAN
(see North Atlantic Ocean and South Atlantic Ocean) - - - -
BALTIC SEA 2 1 B26 7B
Gulf of Bothnia 2.1 1 (a) B29 7T
Gulf of Finland 2.2 1 (b) B28 7F
Gulf of Riga 2.3 1 (c) B27 7H
The Sound 2.4 2 - -
The Great Belt 2.5 2 - -
The Little Belt 2.6 2 - -
Kattegat 2.7 2 B25 7K
INDIAN OCEAN 5 45 F 6A
Mozambique Channel 5.1 45 A F1 6Z
Gulf of Suez 5.2 35 F5 6W
Gulf of Aqaba 5.3 36 - 6Q
Red Sea 5.4 37 F4 6E
Gulf of Aden 5.5 38 F3 6D
Persian Gulf
(Gulf of Iran) 5.6 41 F7 6P
Gulf of Oman 5.7 40 F6 6M
Arabian Sea 5.8 39 F2 6R
Laccadive Sea (Lakshadweep Sea) 5.9 42 F9 6L
Gulf of Mannar 5.10 - F8 -
Palk Strait and Palk Bay 5.11 - - -
Bay of Bengal 5.12 43 F10 6B
Andaman Sea (Burma Sea) 5.13 44 F11 6N
Strait of Malacca (Malacca Strait) 5.14 46 (a) F12 6C
Great Australian Bight 5.15 62 F21 6G
Suez Canal - - - 6U
MEDITERRANEAN REGION 3 - - -
Mediterranean Sea 3.1 28 B11 -
Mediterranean Sea, Western Basin 3.1.1 28 A - 8W
Strait of Gibraltar 3.1.1.1 28 (a) B7 8S
Alboran Sea 3.1.1.2 28 (b) - 8Y
Balearic Sea (Balear Sea, Iberian Sea) 3.1.1.3 28 (c) B9 8J
Ligurian Sea (Ligure Sea) 3.1.1.4 28 (d) B10 8L
Tyrrhenian Sea (Tirreno Sea) 3.1.1.5 28 (e) B12 8T
Mediterranean Sea, Eastern Basin 3.1.2 28 B - 8E
Adriatic Sea 3.1.2.1 28 (g) B14 8D
Strait of Sicily (Strait of Sicilia) 3.1.2.2 - - -
Ionian Sea 3.1.2.3 28 (f) B13 8N
Aegean Sea 3.1.2.4 28 (h) B15 8G
Sea of Marmara 3.2 29 B16 8M
Black Sea 3.3 30 B17 8B
Sea of Azov 3.4 31 B18 8Z
Gulf of Lion (Gulf of Lions) - - B8 8X
Aral Sea - - - 8R
Bosporus - - - 8P
Caspian Sea - - - 8C
Dardanelles - - - 8U
NORTH ATLANTIC OCEAN 1 23 B 1A
Skagerrak 1.1 3 B24 1S
North Sea 1.2 4 B23 1N
Inner Seas off the West Coast of Scotland 1.3 18 - 1K
Irish Sea and Saint Georges Channel 1.4 19 B22 1R, 1Q
Bristol Channel 1.5 20 B21 1C
Celtic Sea 1.6 21 A - -
English Channel 1.7 21 B20 1E
Bay of Biscay 1.8 22 B19 1B
Canarias Sea 1.9 - - -
Gulf of Guinea 1.1 34 C4 1G
Caribbean Sea 1.11 27 B6 1X
Gulf of Mexico 1.12 26 B5 1M
Bay of Fundy 1.13 25 B4 1F
Gulf of Saint Lawrence 1.14 24 B3 1T
Labrador Sea 1.15 15 A - 1L
Greenland Sea 1.16 5 A1 5G
Denmark Strait - - B1 1D
Lake Erie - - - 9E
Lake Huron - - - 9H
Lake Michigan - - - 9M
Lake Ontario - - - 9N
Lake Superior - - - 9S
Panama Canal - - - 1J
Saint Lawrence Seaway - - - 9L
NORTH PACIFIC OCEAN 7 57 D 3A
Philippine Sea 7.1 56 D26 3P
Taiwan Strait (Formosa Strait) 7.2 - D17 3F
East China Sea (Tung Hai) 7.3 50 D13 3E
Yellow Sea (Huang Hai, Hwang Hai) 7.4 51 D14 3Y
Bo Hai (Bo Sea, Gulf of Chihli) 7.5 - D16 3X
Liaodong Wan (Liaodong Gulf) 7.6 - - -
Inland Sea of Japan (Seto Naikai) 7.7 53 - 3N
Sea of Japan (Japan Sea) 7.8 52 D11 3J
Gulf of Tartary 7.9 - D10 -
Sea of Okhotsk 7.10 54 D8 3Q
Bering Sea 7.11 55 D6 5D
Anadyrskiy Zaliv (Anadyrskiy Gulf) 7.12 - - 5Y
Gulf of Alaska 7.13 58 D4 5F
Coastal Waters of Southeast Alaska and British Columbia 7.14 59 D3 5E
Gulf of California 7.15 60 D2 3L
Gulf of Panama 7.16 - D1 -
Amurskiy Liman - - D27 -
Bering Strait - - D7 5R
Bristol Bay - - D5 -
Korea Bay - - D15 3R
Korea Strait - - D12 -
Sakhalinskiy Zaliv - - D28 3B
Zaliv Shelikhova
(Zaliv Shelekhova) - - D9 3K
Luzon Strait - - - 3I
Tatar Strait - - - 3D
PACIFIC OCEAN
(see North Pacific Ocean and South Pacific Ocean)
-
-
-
-
SOUTH ATLANTIC OCEAN 4 32 C 2A
Rio de la Plata 4.1 33 C1 2R
Drake Passage - - C5 2D
Golfo San Matias - - C2 2M
Golfo San Jorge - - C3 2J
Scotia Sea - - C6 2S
Weddell Sea - - C7 2W
SOUTH CHINA AND EASTERN
ARCHIPELAGIC SEAS 6 49 and 48 D18 plus others 3U plus others
South China Sea (Nan Hai) 6.1 49 D18 3U
Gulf of Tonkin 6.2 - D19 3G
Gulf of Thailand (Gulf of Siam) 6.3 47 D20 3T
Natuna Sea 6.4 - - -
Singapore Strait 6.5 46 (b) - 3Z
Sunda Strait 6.6 - - -
Java Sea (Jawa Sea) 6.7 48 (n) F13 4J
Makassar Strait (Makasar Strait) 6.8 48 (m) E1 4M
Bali Sea 6.9 48 (l) F14 4L
Flores Sea 6.10 48 (j) F16 4F
Sumba Strait 6.11 - - -
Savu Sea (Sawu Sea) 6.12 48 (o) F15 6S
Timor Sea 6.13 48 (i) F19 6T
Joseph Bonaparte Gulf 6.14 - F20 -
Gulf of Carpentaria 6.15 - E4 4P
Arafura Sea 6.16 48 (h) E3 4U
Aru Sea 6.17 - - -
Banda Sea 6.18 48 (g) E2 4B
Teluk Bone (Gulf of Bone, Gulf of Boni) 6.19 48 (k) F17 4E
Ceram Sea (Seram Sea) 6.20 48 (f) D25 4Q
Gulf of Berau 6.21 - - -
Halmahera Sea 6.22 48 (e) D24 3H
Molucca Sea (Molukka Sea, Maluku Sea) 6.23 48 (c) D23 3M
Teluk Tomini (Gulf of Tomini) 6.24 48 (d) F18 3V
Sulawesi Sea 6.25 - - -
Mindanao Sea 6.26 - - -
Sulu Sea 6.27 48 (a) D21 3S
Celebes Sea - 48 (b) D22 3C
SOUTH PACIFIC OCEAN 8 61 E 4A
Bismarck Sea 8.1 66 E6 4K
Solomon Sea 8.2 65 E7 4S
Torres Strait 8.3 - E5 -
Coastal Waters of Great Barrier Reefs 8.4 - - -
Coral Sea 8.5 64 E9 4C
Tasman Sea 8.6 63 E10 4T
Bass Strait 8.7 62 A F22 6F
Amundsen Sea - - E12 4D
Bellingshausen Sea - - E13 4G
Cook Strait - - E8 -
Ross Sea - - E11 4R
_________________________________________________________________
@Appendix H: Cross-Reference List of Geographic Names
This list indicates where various geographic names - including the
location of all United States Foreign Service Posts, alternate names,
former names, and political or geographical portions of larger
entities - can be found in The World Factbook. Spellings are normally
those approved by the US Board on Geographic Names (BGN). Additional
information is included in brackets.
Name Entry in The World Factbook Latitude Longitude
A
Abidjan [US Embassy] Cote d''Ivoire 5 19 N 4 02 W
Abkhazia [region] Georgia 43 00 N 41 00 E
Abu Dhabi [US Embassy] United Arab Emirates 24 28 N 54 22 E
Abu Musa [island] Iran 25 52 N 55 03 E
Abuja [US Embassy Branch Office] Nigeria 9 12 N 7 11 E
Abyssinia Ethiopia 8 00 N 38 00 E
Acapulco Mexico 16 51 N 99 55 W
Accra [US Embassy] Ghana 5 33 N 0 13 W
Adamstown Pitcairn Islands 25 04 S 130 05 W
Adana [US Consulate] Turkey 37 01 N 35 18 E
Addis Ababa [US Embassy] Ethiopia 9 02 N 38 42 E
Adelie Land (Terre Adelie) [claimed by France] Antarctica 66 30 S 139 00 E
Aden Yemen 12 46 N 45 01 E
Aden, Gulf of Indian Ocean 12 30 N 48 00 E
Admiralty Island United States (Alaska) 57 44 N 134 20 W
Admiralty Islands Papua New Guinea 2 10 S 147 00 E
Adriatic Sea Atlantic Ocean 42 30 N 16 00 E
Aegean Islands Greece 38 00 N 25 00 E
Aegean Sea Atlantic Ocean 38 30 N 25 00 E
Afars and Issas, French Territory of the (FTAI) Djibouti 11 30 N 43 00 E
Agalega Islands Mauritius 10 25 S 56 40 E
Agana (see Hagatna) Guam 13 28 N 144 45 E
Ajaccio France (Corsica) 41 55 N 8 44 E
Akmola (see Astana) Kazakhstan 51 10 N 71 30 E
Aland Islands Finland 60 15 N 20 00 E
Alaska United States 65 00 N 153 00 W
Alaska, Gulf of Pacific Ocean 58 00 N 145 00 W
Aldabra Islands (Groupe d''Aldabra) Seychelles 9 25 S 46 22 E
Alderney [island] Guernsey 49 43 N 2 12 W
Aleutian Islands United States (Alaska) 52 00 N 176 00 W
Alexander Archipelago United States (Alaska) 57 00 N 134 00 W
Alexander Island Antarctica 71 00 S 70 00 W
Alexandria Egypt 31 12 N 29 54 E
Algiers [US Embassy] Algeria 36 47 N 2 03 E
Alhucemas, Penon de Spain 35 13 N 3 53 W
Alma-Ata (see Almaty) Kazakhstan 43 15 N 76 57 E
Almaty [US Embassy] Kazakhstan 43 15 N 76 57 E
Alofi Niue 19 01 S 169 55 E
Alphonse Island Seychelles 7 01 S 52 45 E
Amami Strait Pacific Ocean 28 40 N 129 30 E
Amindivi Islands India 11 30 N 72 30 E
Amirante Isles (Les Amirantes) Seychelles 6 00 S 53 10 E
Amman [US Embassy] Jordan 31 57 N 35 56 E
Amsterdam [US Consulate General] Netherlands 52 22 N 4 54 E
Amsterdam Island (Ile Amsterdam) French Southern and Antarctic Lands
37 52 S 77 32 E
Amundsen Sea Southern Ocean 72 30 S 112 00 W
Amur River China, Russia 52 56 N 141 10 E
Anatolia [region] Turkey 39 00 N 35 00 E
Andaman Islands India 12 00 N 92 45 E
Andaman Sea Indian Ocean 10 00 N 95 00 E
Andorra la Vella Andorra 42 30 N 1 30 E
Andros [island] Greece 37 45 N 24 42 E
Andros Island The Bahamas 24 26 N 77 57 W
Anegada Passage Atlantic Ocean 18 30 N 63 40 W
Angkor Wat [ruins] Cambodia 13 26 N 103 50 E
Anglo-Egyptian Sudan Sudan 15 00 N 30 00 E
Anjouan [island] Comoros 12 15 S 44 25 E
Ankara [US Embassy] Turkey 39 56 N 32 52 E
Annobon [island] Equatorial Guinea 1 25 S 5 36 E
Antananarivo [US Embassy] Madagascar 18 52 S 47 30 E
Antigua [island] Antigua and Barbuda 14 34 N 90 44','b77e9a5e11c66fdc3a5f69693c07439ef78a33e2461680105f804cb059f53e40','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd6c99b5ae508bed361cbc9a5b448a6858219a9e96f36d08af3c2abcbcfeaa68',2000,'ZM','Zambia','environment',255,'W
Antipodes Islands New Zealand 49 41 S 178 43 E
Antwerp [European Logistical Support Office] Belgium 51 13 N 4 25 E
Aozou Strip Chad 22 00 N18 00 E
Apia [US Embassy] Samoa 13 50 S 171 44 N
Aqaba, Gulf of Indian Ocean 29 00 N 34 30 E
Aqmola (see Astana) Kazakhstan 51 10 N 71 30 E
Arab, Shatt al [river] Iran, Iraq 29 57 N 48 34 E
Arabian Sea Indian Ocean 15 00 N 65 00 E
Arafura Sea Pacific Ocean 9 00 S 133 00 E
Aral Sea Kazakhstan, Uzbekistan 45 00 N 60 00 E
Argun River China, Russia 53 20 N 121 28 E
Ascension Island Saint Helena 7 57 S 14 22 W
Ashgabat [US Embassy] Turkmenistan 37 57 N 58 23 E
Ashkhabad (see Ashgabat) Turkmenistan 37 57 N 58 23 E
Asmara [US Embassy] Eritrea 15 20 N 38 53 E
Asmera (see Asmara) Eritrea 15 20 N 38 53 E
Assumption Island Seychelles 9 46 S 46 34 E
Astana (Akmola) Kazakhstan 51 10 N 71 30 E
Asuncion [US Embassy] Paraguay 25 16 S 57 40 W
Asuncion Island Northern Mariana Islands 19 40 N 145 24 E
Atacama [region] Chile 24 30 S 69 15 W
Athens [US Embassy] Greece 37 59 N 23 44 E
Attu Island United States 52 55 N 172 57 E
Auckland [US Consulate General] New Zealand 36 52 S 174 46 E
Auckland Islands New Zealand 51 00 S 166 30 E
Australes, Iles (Iles Tubuai) French Polynesia 23 20 S 151 00 W
Avarua Cook Islands 21 12 S 159 46 W
Axel Heiberg Island Canada 79 30 N 90 00 W
Azad Kashmir Pakistan 34 30 N 74 00 E
Azores [islands] Portugal 38 30 N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 36 00 E
B
Bab el Mandeb [strait] Indian Ocean 12 40 N 43 20 E
Babuyan Channel Pacific Ocean 18 44 N 121 40 E
Babuyan Islands Philippines 19 10 N 121 40 E
Baffin Bay Arctic Ocean 73 00 N 66 00 W
Baffin Island Canada 68 00 N 70 00 W
Baghdad [US Embassy temporarily suspended;
US Interests Section located in Poland''s embassy in Baghdad]
Iraq 33 21 N44 25 E
Baki (see Baku) Azerbaijan 40 23 N 49 51 E
Baku [US Embassy] Azerbaijan 40 23 N 49 51 E
Baky (see Baku) Azerbaijan 40 23 N 49 51 E
Balabac Strait Pacific Ocean 7 35 N 117 00 E
Balearic Islands Spain 39 30 N 3 00 E
Balearic Sea (Iberian Sea) Atlantic Ocean 40 30 N 2 00 E
Bali [island] Indonesia 8 20 S 115 00 E
Bali Sea Indian Ocean 7 45 S 115 30 E
Balintang Channel Pacific Ocean 19 49 N 121 40 E
Balintang Islands Philippines 19 55 N 122 10 E
Balkan Peninsula Albania, Bosnia and Herzegovina, Bulgaria, Croatia, Greece,
Romania, Serbia and Montenegro, Slovenia, The Former Yugoslav Republic of
Macedonia, Turkey (European part) 42 00 N 23 00 E
Balleny Islands Antarctica 67 00 S 163 00 E
Balochistan [region] Pakistan 28 00 N 63 00 E
Baltic Sea Atlantic Ocean 57 00 N 19 00 E
Bamako [US Embassy] Mali 12 39 N 8 00 W
Banaba (Ocean Island) Kiribati 0 52 S 169 35 E
Bandar Seri Begawan [US Embassy] Brunei 4 52 S 114 55 E
Banda Sea Pacific Ocean 5 00 S 128 00 E
Bangkok [US Embassy] Thailand 13 45 N 100 31 E
Bangui [US Embassy] Central African Republic 4 22 N 18 35 E
Banjul [US Embassy] The Gambia 13 28 N 16 39 W
Banks Island Australia 10 12 S 142 16 E
Banks Island Canada 75 15 N 121 30 W
Banks Islands (Iles Banks) Vanuatu 14 00 S 167 30 E
Barbuda [island] Antigua and Barbuda 17 38 N 61 48 W
Barcelona [US Consulate General] Spain 41 23 N 2 11 E
Barents Sea Arctic Ocean 74 00 N 36 00 E
Barranquilla Colombia 10 59 N 74 48 W
Bashi Channel Pacific Ocean 22 00 N 121 00 E
Basilan Strait Pacific Ocean 6 49 N 122 05 E
Basque Provinces Spain 43 00 N 2 30 W
Bass Strait Pacific Ocean 39 20 S 145 30 E
Basse-Terre Guadeloupe 16 00 N 61 44 W
Basseterre Saint Kitts and Nevis 17 18 N 62 43 W
Bastia France (Corsica) 42 42 N 9 27 E
Basutoland Lesotho 29 30 S 28 30 E
Batan Islands Philippines 20 30 N 121 50 E
Bavaria (Bayern) Germany 48 30 N 11 30 E
Beagle Channel Atlantic Ocean 54 53 S 68 10 W
Bear Island (see Bjornoya) Svalbard 74 26 N 19 05 E
Beaufort Sea Arctic Ocean 73 00 N 140 00 W
Bechuanaland Botswana 22 00 S 24 00 E
Beijing [US Embassy] China 39 56 N 116 24 E
Beirut [US Embassy] Lebanon 33 53 N 35 30 E
Belau (Palau Islands) Palau 7 30 N 134 30 E
Belem [US Consular Agency] Brazil 1 27 S 48 29 W
Belep Islands (Iles Belep) New Caledonia 19 45 S 163 40 E
Belfast [US Consulate General] United Kingdom 54 35 N 5 55 W
Belgian Congo Democratic Republic of the Congo 0 00 N 25 00 E
Belgrade Serbia and Montenegro 44 50 N 20 30 E
Belize City [US Embassy] Belize 17 30 N 88 12 W
Belle Isle, Strait of Atlantic Ocean 51 35 N 56 30 W
Bellingshausen Sea Southern Ocean 71 00 S 85 00 W
Belmopan Belize 17 15 N 88 46 W
Belorussia Belarus 53 00 N 28 00 E
Bengal, Bay of Indian Ocean 15 00 N 90 00 E
Bering Sea Pacific Ocean 60 00 N 175 00 W
Bering Island Russia 55 00 N 166 30 E
Bering Strait Pacific Ocean 65 30 N 169 00 W
Berkner Island Antarctica 79 30 S 49 30 W
Berlin [US Branch Office] Germany 52 31 N 13 24 E
Berlin, East Germany 52 30 N 13 33 E
Berlin, West Germany 52 30 N 12 20 E
Bern [US Embassy] Switzerland 46 57 N 7 26 E
Bessarabia [region] Romania, Moldova, Ukraine 47 00 N 28 30 E
Bhopal India 23 16 N 77 24 E
Biafra [region] Nigeria 5 30 N 7 30 E
Big Diomede Island Russia 65 46 N 169 06 W
Bijagos, Arquipelago dos Guinea-Bissau 11 25 N 16 20 W
Bikini Atoll Marshall Islands 11 35 N 165 23 E
Bilbao Spain 43 15 N 2 58 W
Bioko [island] Equatorial Guinea 3 30 N 8 42 E
Biscay, Bay of Atlantic Ocean 44 00 N 4 00 W
Bishkek [US Embassy] Kyrgyzstan 42 54 N 74 36 E
Bishop Rock United Kingdom 49 52 N 6 27 W
Bismarck Archipelago Papua New Guinea 5 00 S 150 00 E
Bismarck Sea Pacific Ocean 4 00 S 148 00 E
Bissau [US Embassy] Guinea-Bissau 11 51 N 15 35 W
Bjornoya (Bear Island) Svalbard 74 26 N 19 05 E
Black Forest Germany 48 00 N 8 15 E
Black Rock South Georgia and the South Sandwich Islands 53 39 S 41 48 W
Black Sea Atlantic Ocean 43 00 N 35 00 E
Bloemfontein South Africa 29 12 S 26 07 E
Boa Vista [island] Cape Verde 16 05 N 22 50 W
Bogota [US Embassy] Colombia 4 36 N 74 05 W
Bohemia [region] Czech Republic 50 00 N 14 30 E
Bombay (see Mumbai) India 18 58 N 72 50 E
Bonaire [island] Netherlands Antilles 12 10 N 68 15 W
Bonifacio, Strait of Atlantic Ocean 41 01 N 14 00 E
Bonin Islands Japan 27 00 N 140 10 E
Bonn [US Embassy] Germany 50 44 N 7 05 E
Bophuthatswana South Africa 26 30 S 25 30 E
Bora-Bora [island] French Polynesia 16 30 S 151 45 W
Bordeaux France 44 50 N 0 34 W
Borneo [island] Brunei, Indonesia, Malaysia 0 30 N 114 00 E
Bornholm [island] Denmark 55 10 N 15 00 E
Bosnia Bosnia and Herzegovina 44 00 N 18 00 E
Bosporus [strait] Atlantic Ocean 41 00 N 29 00 E
Bothnia, Gulf of Atlantic Ocean 63 00 N 20 00 E
Bougainville [island] Papua New Guinea 6 00 S 155 00 E
Bougainville Strait Pacific Ocean 6 40 S 156 10 E
Bounty Islands New Zealand 47 43 S 174 00 E
Brasilia [US Embassy] Brazil 15 47 S 47 55 W
Bratislava [US Embassy] Slovakia 48 09 N 17 07 E
Brazzaville [US Embassy] Republic of the Congo 4 16 S 15 17 E
Bridgetown [US Embassy] Barbados 13 06 N 59 37 W
Brisbane Australia 27 28 S 153 02 E
Britain (see Great Britain) United Kingdom 54 00 N 2 00 W
British East Africa Kenya, Tanzania, Uganda 1 00 N 38 00 E
British Guiana Guyana 5 00 N 59 00 W
British Honduras Belize 17 15 N 88 45 W
British Solomon Islands Solomon Islands 8 00 S 159 00 E
British Somaliland Somalia 10 00 N 49 00 E
Brussels [US Embassy, US Mission to European Union (USEU),
US Mission to the North Atlantic Treaty Organization (USNATO)]
Belgium 50 50 N 4 20 E
Bubiyan [island] Kuwait 29 47 N 48 10 E
Bucharest [US Embassy] Romania 44 26 N 26 06 E
Budapest [US Embassy] Hungary 47 30 N 19 05 E
Buenos Aires [US Embassy] Argentina 34 36 S 58 27 W
Bujumbura [US Embassy] Burundi 3 23 S 29 22 E
Burnt Pine Norfolk Island 29 02 S 167 56 E
Byelorussia Belarus 53 00 N 28 00 E
C
Cabinda [province] Angola 5 33 S 12 12 E
Cabot Strait Atlantic Ocean 47 20 N 59 30 W
Caicos Islands Turks and Caicos Islands 21 56 N 71 58 W
Cairo [US Embassy] Egypt 30 03 N 31 15 E
Calcutta [US Consulate General] India 22 32 N 88 22 E
Calgary [US Consulate General] Canada 51 03 N 114 05 W
California, Gulf of Pacific Ocean 28 00 N 112 00 W
Campbell Island New Zealand 52 33 S 169 09 E
Canal Zone Panama 9 00 N 79 45 W
Canary Islands Spain 28 00 N 15 30 W
Canberra [US Embassy] Australia 35 17 S 149 08 E
Canton (Guangzhou) China 23 06 N 113 16 E
Canton Island (Kanton Island) Kiribati 2 49 S 171 40 W
Cape Town [US Consulate General] South Africa 33 55 S 18 22 E
Caracas [US Embassy] Venezuela 10 30 N 66 56 W
Cargados Carajos Shoals Mauritius 16 25 S 59 38 E
Caroline Islands Federated States of Micronesia, Palau 7 30 N 148 00 E
Caribbean Sea Atlantic Ocean 15 00 N 73 00 W
Carpentaria, Gulf of Pacific Ocean 14 00 S 139 00 E
Casablanca [US Consulate General] Morocco 33 39 N 7 35 W
Castries Saint Lucia 14 01 N 61 00 W
Catalonia [region] Spain 42 00 N 2 00 E
Cato Island Australia 23 15 S 155 32 E
Caucasus [region] Russia 42 00 N 45 00 E
Cayenne French Guiana 4 56 N 52 20 W
Cebu [US Consular Agency] Philippines 10 18 N 123 54 E
Celebes [island] Indonesia 2 00 S 121 00 E
Celebes Sea Pacific Ocean 3 00 N 122 00 E
Celtic Sea Atlantic Ocean 51 00 N 6 30 W
Central African Empire Central African Republic 7 00 N 21 00 E
Ceuta Spain 35 53 N 5 19 W
Ceylon Sri Lanka 7 00 N 81 00 E
Chafarinas, Islas Spain 35 12 N 2 26 W
Chagos Archipelago (Oil Islands) British Indian Ocean Territory
6 00 S 71 30 E
Channel Islands Guernsey, Jersey 49 20 N 2 20 W
Charlotte Amalie Virgin Islands 18 21 N 64 56 W
Chatham Islands New Zealand 44 00 S 176 30 W
Chechnya (Chechnia) Russia 43 15 N 45 40 E
Cheju-do [island] Korea, South 33 20 N 126 30 E
Cheju Strait Pacific Ocean 34 00 N 126 30 E
Chengdu [US Consulate General] China 39 39 N 104 04 E
Chennai (Madras) [US Consulate General] India 13 04 N 80 16 E
Chesterfield Islands (Iles Chesterfield) New Caledonia 19 52 S 158 15 E
Chiang Mai [US Consulate General] Thailand 18 47 N 98 59 E
Chihli, Gulf of (see Bo Hai) Pacific Ocean 38 30 N 120 00 E
China, People''s Republic of China 35 00 N 105 00 E
China, Republic of Taiwan 23 30 N 105 00 E
Chisinau [US Embassy] Moldova 47 00 N 28 50 E
Choiseul [island] Solomon Islands 7 05 S 121 00 E
Christmas Island [Indian Ocean] Australia 10 25 S 105 39 E
Christmas Island (Kiritimati) [Pacific Ocean] Kiribati 1 52 N 157 20 W
Chukchi Sea Arctic Ocean 69 00 N 171 00 W
Ciskei South Africa 33 00 S 27 00 E
Ciudad Juarez [US Consulate General] Mexico 31 44 N 106 29 W
Cluj-Napoca [US Branch Office] Romania 46 47 N 23 36 E
Cochin China [region] Vietnam 11 00 N 107 00 E
Coco, Isla del Costa Rica 5 32 N 87 04 W
Cocos Islands Cocos (Keeling) Islands 12 30 S 96 50 E
Colombo [US Embassy] Sri Lanka 6 56 N 79 51 E
Colon, Archipielago de (Galapagos Islands) Ecuador 0 00 N 90 30 W
Commander Islands (Komandorskiye Ostrova) Russia 55 00 N 167 00 E
Conakry [US Embassy] Guinea 9 31 N 13 43 W
Congo (Brazzaville) Republic of the Congo 1 00 S 15 00 E
Congo (Leopoldville) Democratic Republic of the Congo 0 00 N 25 00 E
Con Son [Islands] Vietnam 8 43 N 106 36 E
Cook Strait Pacific Ocean 41 15 S 174 30 E
Copenhagen [US Embassy] Denmark 55 40 N 12 35 E
Coral Sea Pacific Ocean 15 00 S 150 00 E
Corfu [island] Greece 39 40 N 19 45 E
Corinth Greece 37 56 N 22 56 E
Corisco [island] Equatorial Guinea 0 55 N 9 19 E
Corn Islands (Islas del Maiz) Nicaragua 12 15 N 83 00 W
Corocoro Island Guyana, Venezuela 3 38 N 66 50 W
Corsica (Corse) [island] France 42 00 N 9 00 E
Corsico [island] Equatorial Guinea 0 55 N 9 19 E
Cosmoledo Group (Atoll de Cosmoledo) Seyhelles 9 43 S 47 35 E
Cotonou [US Embassy] Benin 6 21 N 2 26 E
Courantyne River Guyana, Suriname 5 57 N 57 06 W
Crete [island] Greece 35 15 N 24 45 E
Crimea [region] Ukraine 45 00 N 34 00 E
Crimean Peninsula Ukraine 45 00 N 34 00 E
Crooked Island Passage Atlantic Ocean 22 55 N 74 35 W
Crozet Islands (Iles Crozet) French Southern and Antarctic Lands
46 30 S 51 00 E
Curacao [US Consulate General] Netherlands Antilles 12 11 N 69 00 W
Cyclades [islands] Greece 37 00 N 25 10 E
Czechoslovakia Czech Republic, Slovakia 49 00 N 18 00 E
D
Dahomey Benin 9 30 N 2 15 E
Daito Islands Japan 43 00 N 17 00 E
Dakar [US Embassy] Senegal 14 40 N 17 26 W
Dalmatia [region] Croatia 43 00 N 17 00 E
Daman (Damao) India 20 10 N 73 00 E
Damascus [US Embassy] Syria 33 30 N 36 18 E
Danger Islands (see Pukapuka Atoll) Cook Islands 10 53 S 165 49 W
Danish Straits Atlantic Ocean 58 00 N 11 00 E
Danish West Indies Virgin Islands 18 20 N 64 50 W
Danzig (Gdansk) Poland 54 23 N 18 40 E
Dao Bach Long Vi [island] Vietnam 20 08 N 107 44 E
Dardanelles [strait] Atlantic Ocean 40 15 N 26 25 E
Dar es Salaam [US Embassy] Tanzania 6 48 S 39 17 E
Davis Strait Atlantic Ocean 67 00 N 57 00 W
Dead Sea Israel, Jordan, West Bank 32 30 N 35 30 E
Deception Island Antarctica 62 56 S 60 34 W
Denmark Strait Atlantic Ocean 67 00 N 24 00 W
D''Entrecasteaux Islands Papua New Guinea 9 30 S 150 40 E
Desolation Islands (Isles Kerguelen) French Southern and Antarctic Lands
49 30 S 69 30 E
Devils Island (Ile du Diable) French Guiana 5 17 N 52 35 W
Devon Island Canada 76 00 N 87 00 W
Dhahran [US Consulate General] Saudi Arabia 26 18 N 50 08 E
Dhaka [US Embassy] Bangladesh 23 43 N 90 25 E
Dhofar [region] Oman 17 00 N 54 10 E
Diego Garcia [island] British Indian Ocean Territory 7 20 S 72 25 E
Diego Ramirez [islands] Chile 56 30 S 68 43 W
Diomede Islands Russia [Big Diomede], United States
[Little Diomede] 65 47 N 169 00 W
Diu India 20 42 N 70 59 E
Djibouti [US Embassy] Djibouti 11 30 N 43 15 E
Dnieper [river] (Dnyapro, Dnepr, Dnipro) Belarus, Russia,
Ukraine 46 30 N 32 18 E
Dniester [river] (Nistru, Dnister) Moldova, Ukraine 46 18 N 30 17 E
Dodecanese [islands] Greece 36 00 N 27 05 E
Dodoma Tanzania 6 11 S 35 45 E
Doha [US Embassy] Qatar 25 17 N 51 32 E
Donets Basin Russia, Ukraine 48 15 N 38 30 E
Douala Cameroon 4 03 N 9 42 E
Douglas Man, Isle of 54 09 N 4 28 W
Dover, Strait of Atlantic Ocean 51 00 N 1 30 E
Drake Passage Atlantic Ocean, Southern Ocean 60 00 S 60 00 W
Dubai [US Consulate General] United Arab Emirates 25 18 N 55 18 E
Dubayy (see Dubai) United Arab Emirates 25 18 N 55 18 E
Dublin [US Embassy] Ireland 53 20 N 6 15 W
Durban [US Consulate General] South Africa 29 55 S 30 56 E
Dushanbe [US Embassy] Tajikistan 38 35 N 68 48 E
Dutch Antilles Netherlands Antilles 52 05 N 4 18 E
Dutch East Indies Indonesia 5 00 S 120 00 E
Dutch Guiana Suriname 4 00 N 56 00 W
Dutch West Indies Netherlands Antilles 52 05 N 4 18 E
Dzungarian Gate China, Kazakhstan 45 25 N 82 25 E
E
East China Sea Pacific Ocean 30 00 N 126 00 E
East Frisian Islands Germany 53 44 N 7 25 E
East Germany (German Democratic Republic) Germany 52 00 N 13 00 E
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ocean 34 00 N 129 00 E
East Pakistan Bangladesh 24 00 N 90 00 E
East Siberian Sea Arctic Ocean 74 00 N 166 00 E
East Timor (Portuguese Timor) Indonesia 9 00 S 126 00 E
Easter Island (Isla de Pascua) Chile 27 07 S 109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ocean 34 00 N 129 00 E
Eastern Samoa American Samoa 14 20 S 170 00 W
Edinburgh [US Consulate General] United Kingdom 55 57 N 3 13 W
Eire Ireland 53 00 N 8 00 W
Elba [island] Italy 42 46 N 10 17 E
Ellef Ringnes Island Canada 78 00 N 103 00 W
Ellesmere Island Canada 81 00 N 80 00 W
Ellice Islands Tuvalu 8 00 S 178 00 E
Elobey, Islas de Equatorial Guinea 0 59 N 9 33 E
Enderbury Island Kiribati 3 08 S 171 05 W
Enewetak Atoll (Eniwetok Atoll) Marshall Islands 11 30 N 162 15 E
England [region] United Kingdom 52 30 N 1 30 W
English Channel Atlantic Ocean 50 20 N 1 00 W
Eniwetok Atoll (see Enewetak Atoll) Marshall Islands 11 30 N 162 15 E
Eolie, Isole Italy 38 30 N 15 00 E
Epirus, Northern Albania, Greece 40 00 N 20 30 E
Espana Spain 40 00 N 4 00 W
Essequibo [region] [claimed by Venezuela] Guyana 6 59 N 58 23 W
Etorofu (Iturup) [island] Russia [de facto] 44 55 N 147 40 E
F
Farquhar Group (Atoll de Farquhar) Seychelles 10 10 S 51 10 E
Fernando de Noronha Brazil 3 51 S 32 25 W
Fernando Po [island] (see Bioko) Equatorial Guinea 3 30 N 8 42 E
Finland, Gulf of Atlantic Ocean 60 00 N 27 00 E
Florence [US Consulate General] Italy 43 46 N 11 15 E
Florida, Straits of Atlantic Ocean 25 00 N 79 45 W
former Soviet Union (FSU) Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
Formosa [island] Taiwan 23 30 N 121 00 E
Formosa Strait (see Taiwan Strait) Pacific Ocean 24 00 N 119 00 E
Fortaleza [US Consular Agency] Brazil 3 43 S 38 30 W
Fort-de-France Martinique 14 36 N 61 05 W
Frankfurt am Main [US Consulate General] Germany 50 07 N 8 40 E
Franz Josef Land [islands] Russia 81 00 N 55 00 E
Freetown [US Embassy] Sierra Leone 8 30 N 13 15 W
French Cameroon Cameroon 6 00 N 12 00 E
French Guinea Guinea 11 00 N 10 00 W
French Indochina Cambodia, Laos, Vietnam 15 00 N 107 00 E
French Morocco Morocco 32 00 N 5 00 W
French Somaliland Djibouti 11 30 N 43 00 W
French Sudan Mali 17 00 N 4 00 W
French Territory of the Afars and Issas (FTAI) Djibouti 11 30 N 43 00 E
French Togoland Togo 8 00 N 1 10 E
French West Indies Guadeloupe, Martinique 16 30 N 62 00 W
Friendly Islands Tonga 20 00 S 175 00 W
Frisian Islands Denmark, Germany, Netherlands 53 35 N 6 40 E
Frunze (see Bishkek) Kyrgyzstan 42 54 N 74 36 E
Fukuoka [US Consulate] Japan 33 35 N 130 24 E
Funafuti Tuvalu 8 30 S 179 12 E
Fundy, Bay of Atlantic Ocean 45 00 N 66 00 W
Futuna Islands (Hoorn Islands/Iles de Horne)
Wallis and Futuna 14 19 S 178 05 W
G
Gaborone [US Embassy] Botswana 24 45 S 25 55 E
Galapagos Islands (Archipielago de Colon) Ecuador 0 00 N 90 30 W
Galilee [region] Israel 32 54 N 35 20 E
Galleons Passage Atlantic Ocean 11 00 N 60 55 W
Gambier Islands (Iles Gambier) French Polynesia 23 09 S 134 58 W
Gaspar Strait Pacific Ocean 3 00 S 107 00 E
Geneva [US Consular Agency, US Mission to European Office of the UN and
Other International Organizations] Switzerland 46 12 N 6 10 E
Genoa Italy 44 25 N 8 57 E
George Town Malaysia 5 26 N 100 16 E
George Town The Bahamas 23 30 N 75 46 W
George Town Cayman Islands 19 20 N 81 23 W
Georgetown The Gambia 13 30 N 14 47 W
Georgetown [US Embassy] Guyana 6 48 N 58 10 W
German Democratic Republic (East Germany) Germany 52 00 N 13 00 E
German Southwest Africa Namibia 22 00 S 17 00 E
Germany, Federal Republic of Germany 51 00 N 9 00 E
Gibraltar Gibraltar 36 11 N 5 22 W
Gibraltar, Strait of Atlantic Ocean 35 57 N 5 36 W
Gidi Pass Egypt 30 13 N 33 09 E
Gilbert Islands Kiribati 1 25 N 173 00 E
Goa [state] India 14 20 N 74 00 E
Godthab (Nuuk) Greenland 64 11 N 51 44 W
Gold Coast Ghana 8 00 N 2 00 W
Golan Heights [region] Syria 33 00 N 35 45 E
Good Hope, Cape of South Africa 34 24 S 18 30 E
Goteborg Sweden 57 43 N 11 58 E
Gotland [island] Sweden 57 30 N 18 33 E
Gough Island Saint Helena 40 10 S 9 45 W
Grand Banks Atlantic Ocean 47 06 N 55 48 W
Grand Cayman [island] Cayman Islands 19 20 N 81 20 W
Grand Turk Turks and Caicos Islands 21 28 N 71 08 W
Great Australian Bight Indian Ocean 35 00 S 130 00 E
Great Belt (Store Baelt) Atlantic Ocean 55 30 N 11 00 E
Great Bitter Lake Egypt 30 20 N 32 23 E
Great Britain United Kingdom 54 00 N 2 00 W
Great Channel Indian Ocean 6 25 N 94 20 E
Greater Sunda Islands Brunei, Indonesia, Malaysia 2 00 S 110 00 E
Green Islands Papua New Guinea 4 30 S 154 10 E
Greenland Sea Arctic Ocean 79 00 N 5 00 W
Grenadines, Northern Saint Vincent and the Grenadines 13 15 N 61 12 W
Grenadines, Southern Grenada 12 07 N 61 40 W
Grytviken South Georgia and the South Sandwich Islands 54 15 S 36 45 W
Guadalajara [US Consulate General] Mexico 20 40 N 103 20 W
Guadalcanal [island] Solomon Islands 9 32 S 160 12 E
Guadalupe, Isla de Mexico 29 11 N 118 17 W
Guangzhou [US Consulate General] China 23 06 N 113 16 E
Guantanamo Bay [US Naval Base] Cuba 20 00 N 75 08 W
Guatemala US Embassy] Guatemala 14 38 N 90 31 W
Guinea, Gulf of Atlantic Ocean 3 00 N 2 30 E
Guayaquil [US Consulate General] Ecuador 2 13 S 79 54 W
H
Ha''apai Group Tonga 19 42 S 174 29 W
Habomai Islands Russia [de facto] 43 30 N 146 10 E
Hadhramaut [region] Yemen 15 00 N 50 00 E
Hagatna (Agana) Guam 13 28 N 144 45 E
Hague, The [US Embassy] Netherlands 52 05 N 4 18 E
Haifa Israel 32 50 N 35 00 E
Haiphong Vietnam 20 52 N 106 41 E
Hainan Dao [island] China 19 00 N 109 30 E
Halifax [US Consulate General] Canada 44 39 N 63 36 W
Halmahera [island] Indonesia 1 00 N 128 00 E
Hamburg [US Consulate General] Germany 53 33 N 9 59 E
Hamilton [US Consulate General] Bermuda 32 17 N 64 46 W
Hanoi [US Embassy] Vietnam 21 02 N 105 51 E
Harare [US Embassy] Zimbabwe 17 50 S 31 03 E
Hatay [province] Turkey 36 30 N 36 15 E
Havana [US post not maintained; representation by US Interests Section
(USINT) of the Swiss Embassy] Cuba 23 08 N 82 22 W
Hawaii United States 20 00 N 157 45 W
Heard Island Heard Island and McDonald Islands 53 06 S 73 30 E
Hejaz [region] Saudi Arabia 24 30 N 38 30 E
Helsinki [US Embassy] Finland 60 10 N 24 58 E
Hermosillo [US Consulate] Mexico 29 04 N 110 58 W
Herzegovina Bosnia and Herzegovina 44 00 N 18 00 E
Hispaniola [island] Dominican Republic, Haiti 18 45 N 71 00 W
Ho Chi Minh City Vietnam 10 45 N 106 40 E
Hokkaido [island] Japan 44 00 N 143 00 E
Holland Netherlands 52 30 N 5 45 E
Hong Kong [US Consulate General] Hong Kong 22 15 N 114 10 E
Honiara Solomon Islands 9 26 S 159 57 E
Honshu [island] Japan 36 00 N 138 00 E
Hormuz, Strait of Indian Ocean 26 34 N 56 15 E
Horn, Cape (Cabo de Hornos) Chile 55 59 S 67 16 W
Horne, Iles de Wallis and Futuna 14 19 S 178 05 W
Horn of Africa Djibouti, Eritrea, Ethiopia, Somalia 8 00 N 48 00 E
Hudson Bay Arctic Ocean 60 00 N 86 00 W
Hudson Strait Arctic Ocean 62 00 N 71 00 W
Hunter Island New Caledonia, Vanuatu 22 24 S 172 06 E
I
Iberian Peninsula Portugal, Spain 40 00 N 5 00 W
Inaccessible Island Saint Helena 37 17 S 12 40 W
Indochina Cambodia, Laos, Vietnam 15 00 N 107 00 E
Inland Sea Japan 34 20 N 133 30 E
Inner Mongolia (Nei Mongol) China 42 00 N 113 00 E
Ionian Islands Greece 38 30 N 20 30 E
Ionian Sea Atlantic Ocean 38 30 N 18 00 E
Irian Jaya [province] Indonesia 5 00 S 138 00 E
Irish Sea Atlantic Ocean 53 30 N 5 20 W
Iron Gate Romania, Serbia and Montenegro 44 41 N 22 31 E
Islamabad [US Embassy] Pakistan 33 42 N 73 10 E
Islas Malvinas Falkland Islands (Islas Malvinas) 51 45 S 59 00 W
Istanbul [US Consulate General] Turkey 41 01 N 28 58 E
Istrian Peninsula Croatia, Slovenia 45 00 N 14 00 E
Italian East Africa Eritrea, Ethiopia, Somalia 8 00 N 38 00 E
Italian Somaliland Somalia 10 00 N 49 00 E
Iturup (see Etorofu) Russia [de facto] 44 55 N 147 40 E
Ivory Coast Cote d''Ivoire 8 00 N 5 00 W
Iwo Jima [island] Japan 24 47 N 141 20 E
J
Jakarta [US Embassy] Indonesia 6 10 S 106 48 E
Jamestown Saint Helena 15 56 S 5 44 W
Jammu India 32 42 N 74 52 E
Jammu and Kashmir [region] India, Pakistan 34 00 N 76 00 E
Japan, Sea of Pacific Ocean 40 00 N 135 00 E
Jars, Plain of Laos 19 27 N 103 10 E
Java [island] Indonesia 7 30 S 110 00 E
Java Sea Pacific Ocean 5 00 S 110 00 E
Jeddah (see Jiddah) Saudi Arabia 21 30 N 39 12 E
Jerusalem [US Consulate General] Israel, West Bank 31 47 N 35 14 E
Jiddah [US Consulate General] Saudi Arabia 21 30 N 39 12 E
Johannesburg [US Consulate General] South Africa 26 15 S 28 00 E
Juan de Fuca, Strait of Pacific Ocean 48 18 N 124 00 W
Juan Fernandez, Isla de Chile 33 00 S 80 00 W
Jubal, Strait of Indian Ocean 27 40 N 33 55 E
Judaea [region] Israel, West Bank 31 35 N 35 00 E
Jutland [region] Denmark 56 00 N 9 15 E
Juventud, Isla de la (Isle of Youth) Cuba 21 40 N 82 50 W
K
Kabul [US Embassy now closed] Afghanistan 34 31 N 69 12 E
Kaduna Nigeria 10 33 N 7 27 E
Kailas Range China, India 30 00 N 82 00 E
Kalimantan [region] Indonesia 0 00 N 115 00 E
Kamaran [island] Yemen 15 21 N 42 34 E
Kamchatka Peninsula (Poluostrov Kamchatka) Russia 56 00 N 160 00 E
Kampala [US Embassy] Uganda 0 19 N 32 25 E
Kampuchea Cambodia 13 00 N 105 00 E
Kanton Island Kiribati 2 49 S 171 40 W
Karachi [US Consulate General] Pakistan 24 52 N 67 03 E
Kara Sea Arctic Ocean 76 00 N 80 00 E
Karakoram Pass China, India 35 30 N 77 50 E
Karelian Isthmus Russia 60 25 N 30 00 E
Karimata Strait Pacific Ocean 2 05 S 108 40 E
Kashmir [region] India, Pakistan 34 00 N 76 00 E
Katanga [region] Democratic Republic of the Congo 10 00 S 26 00 E
Kathmandu [U','fb8b57aee708b4e094f04936b309ce6fcb1698251524f8733fa9d27ef3e03d52','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1a7d869d581b5371805f919fac0138a4a9dff5d91f4e712b3e08518874de801',2000,'ZM','Zambia','environment',256,'S Embassy] Nepal 27 43 N 85 19 E
Kattegat [strait] Atlantic Ocean 57 00 N 11 00 E
Kauai Channel Pacific Ocean 21 45 N 158 50 W
Keeling Islands Cocos (Keeling) Islands 12 30 S 96 50 E
Kerguelen, Iles French Southern and Antarctic Lands 49 30 S 69 30 E
Kermadec Islands New Zealand 29 50 S 178 15 W
Kerulen River China, Mongolia 48 48 N 117 00 E
Khabarovsk Russia 48 27 N 135 06 E
Khanka, Lake China, Russia 45 00 N 132 24 E
Khartoum [US Embassy] Sudan 15 36 N 32 32 E
Khmer Republic Cambodia 13 00 N 105 00 E
Khuriya Muriya Islands (Kuria Muria Islands) Oman 17 30 N 56 00 E
Khyber Pass Afghanistan, Pakistan 34 05 N 71 10 E
Kiel Canal (Nord-Ostsee Kanal) Atlantic Ocean 53 53 N 9 08 E
Kiev [US Embassy] Ukraine 50 26 N 30 31 E
Kigali [US Embassy] Rwanda 1 57 S 30 04 E
Kingston [US Embassy] Jamaica 18 00 N 76 48 W
Kingston Norfolk Island 29 03 S 167 58 E
Kingstown Saint Vincent and the Grenadines 13 09 N 61 14 W
Kinshasa [US Embassy] Democratic Republic of the Congo 4 18 S 15 18 E
Kirghiziya Kyrgyzstan 41 00 N 75 00 E
Kiritimati (Christmas Island) Kiribati 1 52 N 157 20 W
Kishinev (see Chisinau) Moldova 47 00 N 28 50 E
Kithira Strait Atlantic Ocean 36 00 N 23 00 E
Kobe Japan 34 41 N 135 10 E
Kodiak Island United States 57 49 N 152 23 W
Kola Peninsula (Kol''skiy Poluostrov) Russia 67 20 N 37 00 E
Kolonia [US Embassy] Federated States of Micronesia 6 58 N 158 13 E
Korea Bay Pacific Ocean 39 00 N 124 00 E
Korea, Democratic People''s Republic of North Korea 40 00 N 127 00 E
Korea, Republic of South Korea 37 00 N 127 30 E
Korea Strait Pacific Ocean 34 00 N 129 00 E
Koror [US Embassy] Palau 7 20 N 134 29 E
Kosovo [region] Serbia and Montenegro 42 30 N 21 00 E
Kowloon Hong Kong 22 18 N 114 10 E
Kra, Isthmus of Burma, Thailand 10 20 N 99 00 E
Krakatoa [volcano] Indonesia 6 07 S 105 24 E
Krakow [US Consulate General] Poland 50 03 N 19 58 E
Kuala Lumpur [US Embassy] Malaysia 3 10 N 101 42 E
Kunashiri (Kunashir) [island] Russia [de facto] 44 20 N 146 00 E
Kunlun Mountains China 36 00 N 84 00 E
Kuril Islands Russia [de facto] 46 10 N 152 00 E
Kuwait [US Embassy] Kuwait 29 20 N 47 59 E
Kuznetsk Basin Russia 54 00 N 86 00 E
Kwajalein Atoll Marshall Islands 9 05 N 167 20 E
Kyushu [island] Japan 33 00 N 131 00 E
Kyyiv (see Kiev) Ukraine 50 26 N 30 31 E
L
Labrador Canada 54 00 N 62 00 W
Laccadive Islands India 10 00 N 73 00 E
Laccadive Sea Indian Ocean 7 00 N 76 00 E
Lagos [US Embassy] Nigeria 6 27 N 3 24 E
Lahore [US Consulate General] Pakistan 31 35 N 74 18 E
Lakshadweep (Laccadive Islands) India 10 00 N 73 00 E
La Paz [US Embassy] Bolivia 16 30 S 68 09 W
La Perouse Strait Pacific Ocean 45 45 N 142 00 E
Laptev Sea Arctic Ocean 76 00 N 126 00 E
Las Palmas Spain 28 06 N 15 24 W
Lau Group Fiji 18 20 S 178 30 E
Lefkosa (see Nicosia) Cyprus 35 10 N 33 22 E
Leipzig [US Consulate General] Germany 51 19 N 12 20 E
Lemnos [island] Greece 39 54 N 25 21 E
Leningrad (see Saint Petersburg) Russia 59 55 N 30 15 E
Lesser Sunda Islands Indonesia 9 00 S 120 00 E
Lesvos [island] Greece 39 15 N 26 15 E
Leyte [island] Philippines 10 50 N 124 50 E
Liancourt Rocks [claimed by Japan] South Korea 37 15 N 131 50 E
Libreville [US Embassy] Gabon 0 23 N 9 27 E
Ligurian Sea Atlantic Ocean 43 30 N 9 00 E
Lilongwe [US Embassy] Malawi 13 59 S 33 44 E
Lima [US Embassy] Peru 12 03 S 77 03 W
Lincoln Sea Arctic Ocean 83 00 N 56 00 W
Line Islands Jarvis Island, Kingman Reef, Kiribati,
Palmyra Atoll 0 05 N 157 00 W
Lisbon [US Embassy] Portugal 38 43 N 9 08 W
Ljubljana [US Embassy] Slovenia 46 03 N 14 31 E
Lobamba Swaziland 26 27 S 31 12 E
Lombok Strait Indian Ocean 8 30 S 115 50 E
Lome [US Embassy] Togo 6 08 N 1 13 E
London [US Embassy] United Kingdom 51 30 N 0 10 W
Longyearbyen Svalbard 78 13 N 15 33 E
Lord Howe Island Australia 31 30 S 159 00 E
Louisiade Archipelago Papua New Guinea 11 00 S 153 00 E
Loyalty Islands (Iles Loyaute) New Caledonia 21 00 S 167 00 E
Luanda [US Embassy] Angola 8 48 S 13 14 E
Lubumbashi Democratic Republic of the Congo 11 40 S 27 28 E
Lusaka [US Embassy] Zambia 15 25 S 28 17 E
Luxembourg [US Embassy] Luxembourg 49 45 N 6 10 E
Luzon [island] Philippines 16 00 N 121 00 E
Luzon Strait Pacific Ocean 20 30 N 121 00 E
Lyakhov Islands Russia 73 45 N 138 00 E
M
Macao Macau 22 10 N 113 33 E
Macedonia The Former Yugoslav Republic of Macedonia 41 50 N 22 00 E
Macquarie Island Australia 30 07 S 147 24 E
Maddalena, Isola Italy 41 13 N 09 24 E
Madeira Islands Portugal 32 40 N 16 45 W
Madras (see Chennai) India 13 04 N 80 16 E
Madrid [US Embassy] Spain 40 24 N 3 41 W
Magellan, Strait of Atlantic Ocean 54 00 S 71 00 W
Maghreb Algeria, Libya, Mauritania, Morocco, Tunisia 30 00 N 5 00 E
Mahe Island Seychelles 4 41 S 55 30 E
Maiz, Islas del (Corn Islands) Nicaragua 12 15 N 83 00 W
Majorca Island (Isla de Mallorca) Spain 39 30 N 3 00 E
Majuro [US Embassy] Marshall Islands 7 05 N 171 08 E
Makassar Strait Pacific Ocean 2 00 S 117 30 E
Malabo Equatorial Guinea 3 45 N 8 47 E
Malacca, Strait of Indian Ocean 2 30 N 101 20 E
Malagasy Republic Madagascar 20 00 S 47 00 E
Male Maldives 4 10 N 73 31 E
Mallorca (Majorca) Spain 39 30 N 3 00 E
Malpelo, Isla de Colombia 4 00 N 90 30 W
Malta Channel Atlantic Ocean 56 44 N 26 53 E
Malvinas, Islas Falkland Islands (Islas Malvinas) 51 45 S 59 00 W
Mamoutzou Mayotte 12 47 S 45 14 E
Managua [US Embassy] Nicaragua 12 09 N 86 17 W
Manama [US Embassy] Bahrain 26 13 N 50 35 E
Manaus [US Consular Agency] Brazil 3 08 S 60 01 W
Manchukuo China 44 00 N 124 00 E
Manchuria China 44 00 N 124 00 E
Manila [US Embassy] Philippines 14 35 N 121 00 E
Manipa Strait Pacific Ocean 3 20 S 127 23 E
Mannar, Gulf of Indian Ocean 8 30 N 79 00 E
Manua Islands American Samoa 14 13 S 169 35 W
Maputo [US Embassy] Mozambique 25 58 S 32 35 E
Marcus Island (Minami-tori-shima) Japan 24 16 N 154 00 E
Mariana Islands Guam, Northern Mariana Islands 16 00 N 145 30 E
Marion Island South Africa 46 51 S 37 52 E
Marmara, Sea of Atlantic Ocean 40 40 N 28 15 E
Marquesas Islands (Iles Marquises) French Polynesia 9 00 S 139 30 W
Marseille [US Consulate General] France 43 18 N 5 24 E
Martin Vaz, Ilhas Brazil 20 30 S 28 51 W
Mas a Tierra (Robinson Crusoe Island) Chile 33 38 S 78 52 W
Mascarene Islands Mauritius, Reunion 21 00 S 57 00 E
Maseru [US Embassy] Lesotho 29 28 S 27 30 E
Matamoros [US Consulate] Mexico 25 53 N 97 30 W
Mata-Utu Wallis and Futuna 13 57 S 171 56 W
Matsu [island] Taiwan 26 13 N 119 56 E
Matthew Island New Caledonia, Vanuatu 22 20 S 171 20 E
Mazatlan Mexico 23 13 N 106 25 W
Mbabane [US Embassy] Swaziland 26 18 S 31 06 E
McDonald Islands Heard Island and McDonald Islands 53 06 S 73 30 E
Mecca Saudi Arabia 21 27 N 39 49 E
Medan [US Consulate General] Indonesia 3 35 N 98 40 E
Mediterranean Sea Atlantic Ocean 36 00 N 15 00 E
Melbourne [US Consulate General] Australia 37 49 S 144 58 E
Melilla Spain 35 19 N 2 58 W
Merida [US Consulate] Mexico 20 58 N 89 37 W
Mesopotamia Iraq 33 00 N 44 00 E
Messina, Strait of Atlantic Ocean 38 15 N 15 35 E
Mexico [US Embassy] Mexico 19 24 N 99 09 W
Mexico, Gulf of Atlantic Ocean 25 00 N 90 00 W
Middle Congo Republic of the Congo 1 00 S 15 00 E
Milan [US Consulate General] Italy 45 28 N 9 12 E
Minami-tori-shima (Marcus Island) Japan 24 16 N 154 00 E
Mindanao [island] Philippines 8 00 N 125 00 E
Mindoro [island] Philippines 12 50 N 121 05 E
Mindoro Strait Pacific Ocean 12 20 N 120 40 E
Minicoy Island India 8 17 N 73 02 E
Minsk [US Embassy] Belarus 53 54 N 27 34 E
Minorca Island (Isla de Menorca) Spain 40 00 N 4 00 E
Mitla Pass Egypt 30 02 N 32 54 E
Mogadishu Somalia 2 04 N 45 22 E
Moldavia [region] Moldova, Romania 47 00 N 29 00 E
Moluccas (Spice Islands) Indonesia 2 00 S 28 00 E
Mombasa Kenya 4 03 S 39 40 E
Mona Passage Atlantic Ocean 18 30 N 67 45 W
Monaco Monaco 43 44 N 7 25 E
Monrovia [US Embassy] Liberia 6 18 N 10 47 W
Montenegro Serbia and Montenegro 42 30 N 19 00 E
Monterrey Mexico 25 40 N 100 19 W
Montevideo [US Embassy] Uruguay 34 53 S 56 11 W
Montreal [US Consulate General, US Mission to the International Civil
Aviation Organization (ICAO)] Canada 45 31 N 73 34 W
Moravia [region] Czech Republic 49 30 N 17 00 E
Moravian Gate Czech Republic 49 35 N 17 50 E
Moroni Comoros 11 41 S 43 16 E
Mortlock Islands (Nomoi Islands) Federated States of Micronesia
5 30 N 153 40 E
Moscow [US Embassy] Russia 55 45 N 37 35 E
Mount Pinatubo Philippines 15 08 N 120 21 E
Mozambique Channel Indian Ocean 19 00 S 41 00 E
Mumbai [US Consulate General] India 18 58 N 72 50 E
Munich [US Consulate General] Germany 48 09 N 11 35 E
Musandam Peninsula Oman, United Arab Emirates 26 18 N 56 24 E
Muscat [US Embassy] Oman 23 37 N 58 35 E
Muscat and Oman Oman 21 00 N 57 00 E
Myanma, Myanmar Burma 22 00 N 98 00 E
N
Nagorno-Karabakh [region] Azerbaijan 40 00 N 46 40 E
Nagoya [US Consulate] Japan 35 10 N 136 55 E
Naha [US Consulate General] Japan 26 13 N 127 40 E
Nairobi [US Embassy] Kenya 1 17 S 36 49 E
Nampo-shoto [islands] Japan 30 00 N 140 00 E
Naples [US Consulate General] Italy 40 50 N 14 15 E
Nassau [US Embassy] The Bahamas 25 05 N 77 21 W
Natuna Besar Islands Indonesia 3 30 N 102 30 E
Naxcivan [region] Azerbaijan 39 20 N 45 20 E
N''Djamena [US Embassy] Chad 12 07 N 15 03 E
Negev [region] Israel 30 30 N 34 55 E
Negros [island] Philippines 10 00 N 123 00 E
Netherlands East Indies Indonesia 5 00 S 120 00 E
Netherlands Guiana Suriname 4 00 N 56 00 W
Nevis [island] Saint Kitts and Nevis 17 09 N 62 35 W
New Britain [island] Papua New Guinea 6 00 S 150 00 E
New Delhi [US Embassy] India 28 36 N 77 12 E
New Guinea Indonesia, Papua New Guinea 5 00 S 140 00 E
New Hebrides Vanuatu 16 00 S 167 00 E
New Siberian Islands Russia 75 00 N 142 00 E
New Territories Hong Kong 22 24 N 114 10 E
New York, New York [US Mission to the United Nations (USUN)]
United States 40 43 N 74 01 W
Newfoundland [island] Canada 52 00 N 56 00 W
Niamey [US Embassy] Niger 13 31 N 2 07 E
Nicobar Islands India 8 00 N 93 30 E
Nicosia [US Embassy] Cyprus 35 10 N 33 22 E
Nightingale Island Saint Helena 37 25 S 12 30 W
Nomoi Islands (Mortlock Islands) Federated States of Micronesia
5 30 N 153 40 E
North Atlantic Ocean Atlantic Ocean 30 00 N 45 00 W
North Channel Atlantic Ocean 55 10 N 5 40 W
North Frisian Islands Denmark, Germany 54 50 N 8 12 E
North Island New Zealand 39 00 S 176 00 E
North Korea North Korea 40 00 N 127 00 E
North Pacific Ocean Pacific Ocean 30 00 N 165 00 W
North Sea Atlantic Ocean 56 00 N 4 00 E
North Vietnam Vietnam 23 00 N 106 00 E
North Yemen (Yemen Arab Republic) Yemen 15 00 N 44 00 E
Northeast Providence Channel Atlantic Ocean 25 40 N 77 09 W
Northern Epirus Albania, Greece 40 00 N 20 30 E
Northern Grenadines Saint Vincent and the Grenadines 12 45 N 61 15 W
Northern Ireland United Kingdom 54 40 N 6 45 W
Northern Rhodesia Zambia 15 00 S 30 00 E
Northwest Passages Arctic Ocean 74 40 N 100 00 W
Norwegian Sea Atlantic Ocean 66 00 N 6 00 E
Nouakchott [US Embassy] Mauritania 18 06 N 15 57 W
Noumea New Caledonia 22 16 S 166 27 E
Novaya Zemlya [islands] Russia 74 00 N 57 00 E
Nubia Sudan 20 30 N 33 00 E
Nuku''alofa Tonga 21 08 S 175 12 W
Nuevo Laredo [US Consulate] Mexico 27 30 N 99 31 W
Nuuk (Godthab) Greenland 64 11 N 51 44 W
Nyasaland Malawi 13 30 S 34 00 E
O
Oahu United States 21 30 N 158 00 W
Ocean Island (Banaba) Kiribati 0 52 S 169 35 E
Ocean Island (Kure Island) United States 28 25 N 178 20 W
Ogaden [region] Ethiopia, Somalia 7 00 N 46 00 E
Oil Islands (Chagos Archipelago) British Indian Ocean Territory
6 00 S 71 30 E
Okhotsk, Sea of Pacific Ocean 53 00 N 150 00 E
Okinawa [island group] Japan 26 30 N 128 00 E
Oman, Gulf of Indian Ocean 24 30 N 58 30 E
Ombai Strait Pacific Ocean 8 30 S 125 00 E
Oran Algeria 35 43 N 0 43 W
Oranjestad Aruba 12 33 N 70 06 W
Oresund (The Sound) Atlantic Ocean 55 50 N 12 40 E
Orkney Islands United Kingdom 59 00 N 3 00 W
Osaka-Kobe [US Consulate General] Japan 34 40 N 135 30 E
Oslo [US Embassy] Norway 59 55 N 10 45 E
Osumi Strait (Van Diemen Strait) Pacific Ocean 31 00 N 131 00 E
Otranto, Strait of Atlantic Ocean 40 00 N 19 00 E
Ottawa [US Embassy] Canada 45 20 N 73 58 W
Ouagadougou [US Embassy] Burkina Faso 12 22 N 1 31 W
Outer Mongolia Mongolia 46 00 N 105 00 E
P
Pacific Islands, Trust Territory of the Marshall Islands,
Federated States of Micronesia, Northern Mariana Islands,
Palau 10 00 N 155 00 E
Pagan [island] Northern Mariana Islands 18 08 N 145 47 E
Pago Pago American Samoa 14 16 S 170 42 W
Palawan [island] Philippines 9 30 N 118 30 E
Palermo Italy 38 07 N 13 21 E
Palestine Israel, West Bank 32 00 N 35 15 E
Palikir Federated States of Micronesia 6 55 N 158 08 E
Palk Strait Indian Ocean 10 00 N 79 45 E
Pamirs [mountains] China, Tajikistan 38 00 N 73 00 E
Pampas [region] Argentina 35 00 N 63 00 W
Panama [US Embassy] Panama 8 58 N 79 32 W
Panama Canal Panama 9 00 N 79 45 W
Panama, Gulf of Pacific Ocean 8 00 N 79 30 W
Panay [island] Philippines 11 15 N 122 30 E
Pantelleria, Isola di Italy 36 47 N 12 00 E
Papeete French Polynesia 17 32 S 149 34 W
Paramaribo [US Embassy] Suriname 5 50 N 55 10 W
Parece Vela [island] Japan 20 20 N 136 00 E
Paris [US Embassy, US Mission to the Organization for Economic Cooperation
and Development (OECD), US Observer Mission to the UN Educational,
Scientific, and Cultural Organization (UNESCO)] France 48 52 N 2 20 E
Pascua, Isla de (Easter Island) Chile 27 07 S 109 22 W
Passion, Ile de la Clipperton Island 10 17 N 109 13 W
Pashtunistan [region] Afghanistan, Pakistan 32 00 N 69 00 E
Peking (see Beijing) China 39 56 N 116 24 E
Pelagian Islands (Isole Pelagie) Italy 35 40 N 12 40 E
Peleliu (Beliliou) [island] Palau 7 01 N 134 15 E
Pemba Island Tanzania 7 31 S 39 25 E
Penang Island Malaysia 5 23 N 100 15 E
Pentland Firth Atlantic Ocean 58 44 N 3 13 W
Perim [island] Yemen 12 39 N 43 25 E
Perouse Strait, La Pacific Ocean 44 45 N 142 00 E
Persia Iran 32 00 N 53 00 E
Persian Gulf Indian Ocean 27 00 N 51 00 E
Perth [US Consulate General] Australia 31 56 S 115 50 E
Pescadores [islands] Taiwan 23 30 N 119 30 E
Peshawar [US Consulate] Pakistan 34 01 N 71 33 E
Peter I Island Antarctica 68 48 S 90 35 W
Philip Island Norfolk Island 29 08 S 167 57 E
Philippine Sea Pacific Ocean 20 00 N 134 00 E
Phnom Penh [US Embassy] Cambodia 11 33 N 104 55 E
Phoenix Islands Kiribati 3 30 S 172 00 W
Pines, Isle of (Isla de la Juventud) Cuba 21 40 N 82 50 W
Pleasant Island Nauru 0 32 S 166 55 E
Plymouth Montserrat 16 44 N 62 14 W
Ponape (Pohnpei) [island] Federated States of Micronesia 6 55 N 158 15 E
Ponta Delgada [US Consulate] Portugal 37 44 N 25 40 W
Port-au-Prince [US Embassy] Haiti 18 32 N 72 20 W
Port Louis [US Embassy] Mauritius 20 10 S 57 30 E
Port Moresby [US Embassy] Papua New Guinea 9 30 S 147 10 E
Porto Alegre [US Consulate] Brazil 30 04 S 51 11 W
Port-of-Spain [US Embassy] Trinidad and Tobago 10 39 N 61 31 W
Porto-Novo Benin 6 29 N 2 37 E
Portuguese East Africa Mozambique 18 15 S 35 00 E
Portuguese Guinea Guinea-Bissau 12 00 N 15 00 W
Portuguese Timor (East Timor) Indonesia 9 00 S 126 00 E
Port-Vila Vanuatu 17 44 S 168 19 E
Poznan Poland 52 25 N 16 55 E
Prague [US Embassy] Czech Republic 40 55 N 21 00 E
Praia [US Embassy] Cape Verde 14 55 N 23 31 W
Pretoria [US Embassy] Prevlaka peninsula South Africa 25 45 S 28 10 E
Pribilof Islands United States 57 00 N 170 00 W
Prince Edward Island Canada 46 20 N 63 20 W
Prince Edward Islands South Africa 46 35 S 38 00 E
Prince Patrick Island Canada 76 30 N 119 00 W
Principe [island] Sao Tome and Principe 1 38 N 7 25 E
Prussia [region] Germany, Poland, Russia 53 00 N 14 00 E
Pukapuka Atoll Cook Islands 10 53 S 165 49 W
Pusan [US Consulate] South Korea 35 06 N 129 03 E
P''yongyang North Korea 39 01 N 125 45 E
Q
Quebec [US Consulate General] Canada 52 00 N 72 00 W
Queen Charlotte Islands Canada 53 00 N 132 00 W
Queen Elizabeth Islands Canada 78 00 N 95 00 W
Queen Maud Land [claimed by Norway] Antarctica 73 30 S 12 00 E
Quemoy [island] Taiwan 24 27 N 118 23 E
Quito [US Embassy] Ecuador 0 13 S 78 30 W
R
Rabat [US Embassy] Morocco 34 02 N 6 51 W
Ralik Chain Marshall Islands 8 00 N 167 00 E
Rangoon [US Embassy] Burma 16 47 N 96 10 E
Ratak Chain Marshall Islands 9 00 N 171 00 E
Recife [US Consulate] Brazil 8 03 S 34 54 W
Redonda [island] Antigua and Barbuda 16 55 N 62 19 W
Red Sea Indian Ocean 20 00 N 38 00 E
Revillagigedo Island United States 55 35 N 131 06 W
Revillagigedo Islands Mexico 19 00 N 112 45 W
Reykjavik [US Embassy] Iceland 19 00 N 111 30 W
Rhodes [island] Greece 36 10 N 28 00 E
Rhodesia Zimbabwe 20 00 S 30 00 E
Rhodesia, Northern Zambia 15 00 S 30 00 E
Rhodesia, Southern Zimbabwe 20 00 S 30 00 E
Riga [US Embassy] Latvia 56 57 N 24 06 E
Rio de Janeiro [US Consulate General] Brazil 22 54 S 43 14 W
Rio de Oro Western Sahara 23 45 N 15 45 W
Rio Muni Equatorial Guinea 1 30 N 10 00 E
Riyadh [US Embassy] Saudi Arabia 24 38 N 46 43 E
Road Town British Virgin Islands 18 27 N 64 37 W
Robinson Crusoe Island (Mas a Tierra) Chile 33 38 S 78 52 W
Rocas, Atol das Brazil 3 51 S 33 49 W
Rockall [island] United Kingdom 57 35 N 13 48 W
Rodrigues [island] Mauritius 19 42 S 63 25 E
Rome [US Embassy, US Mission to the UN Agencies for Food and Agriculture
(FODAG)] Italy 41 54 N 12 29 E
Roncador Cay Colombia 13 32 N 80 03 W
Roosevelt Island Antarctica 79 30 S 162 00 W
Roseau Dominica 15 18 N 61 24 W
Ross Dependency [claimed by New Zealand] Antarctica 80 00 S 180 00 E
Ross Island Antarctica 81 30 S 175 00 W
Ross Sea Antarctica, Southern Ocean 76 00 S 175 00 W
Rota [island] Northern Mariana Islands 14 10 N 145 12 E
Rotuma [island] Fiji 12 30 S 177 30 E
Ryukyu Islands Japan 26 30 N 128 00 E
S
Saba [island] Netherlands Antilles 17 38 N 63 10 W
Sabah [state] Malaysia 5 20 N 117 10 E
Sable Island Canada 43 55 N 59 50 W
Safety Islands (Iles du Salut) French Guiana 5 20 N 52 37 W
Sahel Burkina Faso, Cape Verde, Chad, The Gambia, Guinea- Bissau, Mali,
Mauritania, Niger, Senegal 15 00 N 8 00 W
Saigon (see Ho Chi Minh City) Vietnam 10 45 N 106 40 E
Saint Brandon (Cargados Carajos Shoals) Mauritius 16 25 S 59 38 E
Saint Christopher [island] Saint Kitts and Nevis 17 20 N 62 45 W
Saint Christopher and Nevis Saint Kitts and Nevis 17 20 N 62 45 W
Saint-Denis Reunion 20 52 S 55 28 E
Saint George''s [US Embassy] Grenada 12 03 N 61 45 W
Saint George''s Channel Atlantic Ocean 52 00 N 6 00 W
Saint Helier Jersey 49 12 N 2 37 W
Saint John''s Antigua and Barbuda 17 06 N 61 51 W
Saint Lawrence, Gulf of Atlantic Ocean 48 00 N 62 00 W
Saint Lawrence Island United States 49 30 N 67 00 W
Saint Lawrence Seaway Atlantic Ocean 49 15 N 67 00 W
Saint Martin [island] Guadeloupe 18 04 N 63 04 W
Saint Martin (Sint Maarten) Netherlands Antilles 18 04 N 63 04 W
Saint Paul Island Canada 47 12 N 60 09 W
Saint Paul Island United States 57 11 N 170 16 W
Saint Paul Island (Ile Saint-Paul) French Southern and
Antarctic Lands 38 43 S 77 29 E
Saint Peter and Saint Paul Rocks
(Penedos de Sao Pedro e Sao Paulo) Brazil 0 23 N 29 23 W
Saint Peter Port Guernsey 49 27 N 2 32 W
Saint Petersburg [US Consulate General] Russia 59 55 N 30 15 E
Saint-Pierre Saint Pierre and Miquelon 46 46 N 56 11 W
Saint Thomas [island] Virgin Islands 18 21 N 64 55 W
Saint Vincent Passage Atlantic Ocean 13 30 N 61 00 W
Saipan [island] Northern Mariana Islands 15 12 N 145 45 E
Sakishima Islands Japan 24 30 N 124 00 E
Sakhalin Island (Ostrov Sakhalin) Russia 51 00 N 143 00 E
Sala y Gomez, Isla Chile 26 28 S 105 00 W
Salisbury (see Harare) Zimbabwe 17 50 S 105 00 W
Salvador de Bahia [US Consular Agency] Brazil 12 59 S 38 31 W
Salzburg Austria 47 48 N 13 02 E
Samar [island] Philippines 12 00 N 125 00 E
Samaria [region] West Bank 32 15 N 35 10 E
Samoa Islands American Samoa, Samoa 14 00 S 171 00 W
Samos [island] Greece 37 48 N 26 44 E
Sanaa [US Embassy] Yemen 15 21 N 44 12 E
San Ambrosio, Isla Chile 26 21 S 79 52 W
San Andres y Providencia, Archipielago Colombia 13 00 N 81 30 W
San Bernardino Strait Pacific Ocean 12 32 N 124 10 E
San Felix, Isla Chile 26 17 S 80 05 W
San Jose [US Embassy] Costa Rica 9 56 N 84 05 W
San Juan Puerto Rico 18 28 N 66 07 W
San Marino San Marino 43 56 N 12 25 E
San Salvador [US Embassy] El Salvador 13 42 N 89 12 W
Santa Cruz Bolivia 17 48 S 63 10 W
Santa Cruz Islands Solomon Islands 11 00 S 166 15 E
Santiago [US Embassy] Chile 33 27 S 70 40 W
Santo Antao [island] Cape Verde 17 05 N 25 10 W
Santo Domingo [US Embassy] Dominican Republic 18 28 N 69 54 W
Sao Paulo [US Consulate General] Brazil 23 32 S 46 37 W
Sao Pedro e Sao Paulo, Penedos de [rocks] Brazil 0 23 N 29 23 W
Sao Tiago [island] Cape Verde 15 05 N 23 40 W
Sao Tome [island] Sao Tome and Principe 0 12 N 6 39 E
Sapporo [US Consulate General] Japan 43 03 N 141 21 E
Sapudi Strait Pacific Ocean 7 05 S 114 10 E
Sarajevo [US Embassy] Bosnia and Herzegovina 43 52 N 18 25 E
Sarawak [state] Malaysia 2 30 N 113 30 E
Sardinia [island] Italy 40 00 N 9 00 E
Sargasso Sea Atlantic Ocean 30 00 N 55 00 W
Sark [island] Guernsey 49 26 N 2 21 W
Saxony [region] Germany 51 00 N 13 00 E
Schleswig-Holstein [region] Germany 54 31 N 9 33 E
Scopus, Mount Israel, West Bank 31 48 N 35 14 E
Scotia Sea Atlantic Ocean, Southern Ocean 56 00 S 40 00 W
Scotland [region] United Kingdom 57 00 N 4 00 W
Scott Island Antarctica 67 24 S 179 55 W
Senyavin Islands Federated States of Micronesia 6 55 N 158 00 E
Seoul [US Embassy] South Korea 37 34 N 127 00 E
Serbia Serbia and Montenegro 43 00 N 21 00 E
Serrana Bank Colombia 14 25 N 80 16 W
Serranilla Bank Colombia 15 51 N 79 46 W
Settlement, The Christmas Island 18 44 N 64 19 W
Severnaya Zemlya (Northland) [island group] Russia 79 30 N 98 00 E
Shaba [region] Democratic Republic of the Congo 8 00 S 27 00 E
Shag Island Heard Island and McDonald Islands 53 00 S 72 30 E
Shag Rocks South Georgia and the South Sandwich Islands 53 33 S 42 02 W
Shanghai [US Consulate General] China 31 14 N 121 28 E
Shenyang [US Consulate General] China 41 48 N 123 27 E
Shetland Islands United Kingdom 60 30 N 1 30 W
Shikoku [island] Japan 33 45 N 133 30 E
Shikotan [island] Russia [de facto] 43 47 N 146 45 E
Siam Thailand 15 00 N 100 00 E
Siberia [region] Russia 60 00 N 100 00 E
Sibutu Passage Pacific Ocean 4 50 N 119 35 E
Sicily [island] Italy 37 30 N 14 00 E
Sicily, Strait of Atlantic Ocean 37 20 N 11 20 E
Sidra, Gulf of Atlantic Ocean 31 30 N 18 00 E
Sikkim [state] India 27 50 N 88 30 E
Sinai Peninsula Egypt 29 30 N 34 00 E
Singapore [US Embassy] Singapore 1 17 N 103 51 E
Singapore Strait Pacific Ocean 1 15 N 104 00 E
Sinkiang (Xinjiang) China 42 00 N 86 00 E
Sint Eustatius [island] Netherlands Antilles 17 29 N 62 58 W
Sint Maarten [island] Netherlands Antilles 18 04 N 63 04 W
Skagerrak [strait] Atlantic Ocean 57 45 N 9 00 E
Skopje [US Embassy] The Former Yugoslav Republic of Macedonia 41 59 N 21 26 E
Slavonia [region] Croatia 45 27 N 18 00 E
Society Islands (Iles de la Societe) French Polynesia 17 00 S 150 00 W
Socotra [island] Yemen 12 30 N 54 00 E
Sofia [US Embassy] Bulgaria 42 41 N 23 19 E
Solomon Islands, northern Papua New Guinea 6 00 S 155 00 E
Solomon Islands, southern Solomon Islands 8 00 S 159 00 E
Solomon Sea Pacific Ocean 8 00 S 153 00 E
Songkhla Thailand 7 12 N 100 36 E
Sound, The (Oresund) Atlantic Ocean 55 50 N 12 40 E
South Atlantic Ocean Atlantic Ocean 30 00 S 15 00 W
South China Sea Pacific Ocean 10 00 N 113 00 E
South Georgia [island] South Georgia and the South Sandwich Islands
54 15 S 36 45 W
South Island New Zealand 43 00 S 171 00 E
South Korea South Korea 37 00 N 127 30 E
South Orkney Islands Antarctica 61 00 S 45 00 W
South Ossetia [region] Georgia 42 20 N 44 00 E
South Pacific Ocean Pacific Ocean 30 00 S 130 00 W
South Sandwich Islands South Georgia and the South Sandwich Islands
57 45 S 26 30 W
South Shetland Islands Antarctica 62 00 S 59 00 W
South Tyrol [region] Italy 46 30 N 10 30 E
South Vietnam Vietnam 12 00 N 108 00 E
South Yemen (People''s Democratic Republic of Yemen) Yemen 14 00 N 48 00 E
South-West Africa Namibia 22 00 S 17 00 E
Southern Grenadines Grenada 12 20 N 61 30 W
Southern Rhodesia Zimbabwe 20 00 S 30 00 E
Soviet Union Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Spanish Guinea Equatorial Guinea 2 00 N 10 00 E
Spanish Moro','2c902a7ddf7431a03426e54d0d193ad75ff0a35f255180278713a0aa438527ba','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6744c9be12e44b33f45a27b78eb2e7aa7d57cb75a187dda589af9a612d62e9da',2000,'ZM','Zambia','environment',257,'cco Morocco 32 00 N 7 00 W
Spanish North Africa Spain (Ceuta, Islas Chafarinas, Melilla,
Penon de Alhucemas, Penon de Velez de la Gomera) 35 15 N 4 00 W
Spanish Sahara Western Sahara 24 30 N 13 00 W
Spice Islands (Moluccas) Indonesia 2 00 S 28 00 E
Spitsbergen [island] Svalbard 78 00 N 20 00 E
Stanley Falkland Islands (Islas Malvinas) 51 42 S 57 41 W
Stockholm [US Embassy] Sweden 59 20 N 18 03 E
Strasbourg [US Consulate General] France 48 35 N 7 45 E
Stuttgart Germany 48 46 N 9 11 E
Sucre Bolivia 19 02 S 65 17 W
Suez Canal Egypt 29 55 N 32 33 E
Suez, Gulf of Indian Ocean 28 10 N 33 27 E
Sulu Archipelago Philippines 6 00 N 121 00 E
Sulu Sea Pacific Ocean 8 00 N 120 00 E
Sumatra [island] Indonesia 0 00 N 102 00 E
Sumba [island] Indonesia 10 00 S 120 00 E
Sunda Islands (Soenda Isles) Indonesia, Malaysia 2 00 S 110 00 E
Sunda Strait Indian Ocean 6 00 S 105 45 E
Surabaya [US Consulate General] Indonesia 7 15 S 112 45 E
Surigao Strait Pacific Ocean 10 15 N 125 23 E
Surinam Suriname 4 00 N 56 00 W
Suva [US Embassy] Fiji 18 08 S 178 25 E
Sverdlovsk (see Yekaterinburg) Russia 56 50 N 60 39 E
Swains Island American Samoa 11 3 S 171 15 W
Swan Islands Honduras 17 25 S 83 56 W
Sydney [US Consulate General] Australia 33 52 S 151 13 E
T
Tahiti [island] French Polynesia 17 37 S 149 27 W
Taipei Taiwan 25 03 N 121 30 E
Taiwan Strait Pacific Ocean 24 00 N 119 00 E
Tallinn [US Embassy] Estonia 59 25 N 24 45 E
Tanganyika Tanzania 6 00 S 35 00 E
Tangier Morocco 35 48 N 5 45 W
Tarawa [island] Kiribati 1 25 N 173 00 E
Tatar Strait Pacific Ocean 50 00 N 141 00 E
Tashkent [US Embassy] Uzbekistan 41 20 N 69 18 E
Tasmania [island] Australia 43 00 S 147 00 E
Tasman Sea Pacific Ocean 4 30 S 168 00 E
Taymyr Peninsula (Poluostrov Taymyr) Russia 76 00 N 104 00 E
T''bilisi [US Embassy] Georgia 41 43 N 44 49 E
Tegucigalpa [US Embassy] Honduras 14 06 N 87 13 W
Tehran [US post not maintained; representation by Swiss Embassy]
Iran 35 40 N 51 26 E
Tel Aviv [US Embassy] Israel 32 05 N 34 48 E
Terre Adelie (Adelie Land) [claimed by France] Antarctica 66 30 S 139 00 E
Thailand, Gulf of Pacific Ocean 10 00 N 101 00 E
Thessaloniki [US Consulate General] Greece 40 38 N 22 56 E
Thimphu Bhutan 27 28 N 89 39 E
Thuringia [region] Germany 51 00 N 11 00 E
Thurston Island Antarctica 72 20 S 99 00 W
Tiberias, Lake Israel 32 48 N 35 35 E
Tibet (Xizang) China 32 00 N 90 00 E
Tibilisi (see T''bilisi) Georgia 41 43 N 44 49 E
Tien Shan [mountains] China, Kyrgyzstan 42 00 N 80 00 E
Tierra del Fuego Argentina, Chile 54 00 S 69 00 W
Tijuana [US Consulate General] Mexico 32 32 N 117 01 W
Timor [island] Indonesia 9 00 S 125 00 E
Timor Sea Pacific Ocean 11 00 S 128 00 E
Tinian [island] Northern Mariana Islands 15 00 N 145 38 E
Tiran, Strait of Indian Ocean 28 00 N 34 27 E
Tirana [US Embassy] Albania 41 20 N 19 50 E
Tirane (see Tirana) Albania 41 20 N 19 50 E
Tirol [region] Austria, Italy 47 00 N 11 00 E
Tobago [island] Trinidad and Tobago 11 15 N 60 40 W
Tokyo [US Embassy] Japan 35 42 N 139 46 E
Tonkin, Gulf of Pacific Ocean 20 00 N 108 00 E
Toronto [US Consulate General] Canada 43 39 N 79 23 W
Torres Strait Pacific Ocean 10 25 S 142 10 E
Torshavn Faroe Islands 62 01 N 6 46 W
Toshkent (see Tashkent) Uzbekistan 41 20 N 69 18 E
Transjordan Jordan 31 00 N 36 00 E
Transkei South Africa 32 15 S 28 15 E
Transylvania [region] Romania 46 30 N 24 00 E
Trindade, Ilha de Brazil 20 31 S 29 20 W
Tripoli Lebanon 34 26 N 35 51 E
Tripoli [US post not maintained; representation by Belgian Embassy]
Libya 32 54 N 13 11 E
Tristan da Cunha Group Saint Helena 37 04 S 12 19 W
Trobriand Islands Papua New Guinea 8 38 S 151 04 E
Trucial Coast United Arab Emirates 24 00 N 54 00 E
Trucial Oman United Arab Emirates 24 00 N 54 00 E
Trucial States United Arab Emirates 24 00 N 54 00 E
Truk Islands Federated States of Micronesia 7 25 N 151 47 E
Tsugaru Strait Pacific Ocean 41 35 N 141 00 E
Tuamotu Islands (Iles Tuamotu) French Polynesia 19 00 S 142 00 W
Tubuai Islands (Iles Tubuai) French Polynesia 23 00 S 150 00 W
Tunb al Kubra [island] Iran 26 14 N 55 19 E
Tunb as Sughra [island] Iran 26 14 N 55 09 E
Tunis [US Embassy] Tunisia 36 48 N 10 11 E
Turin Italy 45 04 N 7 40 E
Turkish Straits Atlantic Ocean 40 40 N 28 00 E
Turkmeniya Turkmenistan 40 00 N 60 00 E
Turks Island Passage Atlantic Ocean 21 40 N 71 00 W
Tuscany [region] Italy 43 25 N 11 00 E
Tutuila [island] American Samoa 14 18 S 170 42 W
Tyrol, South [region] Italy 46 30 N 10 30 E
Tyrrhenian Sea Atlantic Ocean 40 00 N 12 00 E
U
Udorn(Udon Thani) [US Consulate] Thailand 17 26 N 102 46 E
Ulaanbaatar [US Embassy] Mongolia 47 55 N 106 53 E
Ullung-do [island] South Korea 37 29 N 130 52 E
Unimak Pass [strait] Pacific Ocean 54 20 N 164 50 W
Union of Soviet Socialist Republics (USSR) Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova,
Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
United Arab Republic (UAR) Egypt, Syria
Upper Volta Burkina Faso 13 00 N 2 00 W
Ural Mountains Kazakhstan, Russia 60 00 N 60 00 E
Ussuri River China, Russia 48 28 N 135 02 E
V
Vaduz Liechtenstein 47 09 N 9 31 E
Vakhan (Wakhan Corridor) Afghanistan 37 00 N 73 00 E
Valletta [US Embassy] Malta 35 54 N 14 31 E
Valley, The Anguilla 18 13 N 63 04 W
Vancouver [US Consulate General] Canada 49 16 N 123 07 W
Vancouver Island Canada 49 45 N 126 00 W
Van Diemen Strait (Osumi Strait) Pacific Ocean 31 00 N 131 00 E
Vatican City [US Embassy] Holy See 41 54 N 12 27 E
Velez de la Gomera, Penon de Spain 35 11 N 4 18 W
Venda South Africa 23 00 S 31 00 E
Verde Island Passage Pacific Ocean 13 34 N 120 51 E
Victoria Hong Kong 22 17 N 114 09 E
Victoria Seychelles 4 38 S 55 27 E
Vienna [US Embassy, US Mission to International Organizations in Vienna
(UNVIE)] Austria 48 12 N 16 22 E
Vientiane [US Embassy] Laos 17 58 N 102 36 E
Vilnius [US Embassy] Lithuania 54 41 N 25 19 E
Viti Levu [island] Fiji 18 00 S 178 00 E
Vladivostok [US Consulate General] Russia 43 10 N 131 56 E
Volcano Islands Japan 25 00 N 141 00 E
Vostok Island Kiribati 10 06 S 152 23 W
Vrangelya, Ostrov (Wrangel Island) Russia 71 14 N 179 36 W
W
Wake Atoll Wake Island 19 17 N 166 36 E
Wakhan Corridor (see Vakhan) Afghanistan 37 00 N 73 00 E
Wales [region] United Kingdom 52 30 N 3 30 W
Wallis Islands Wallis and Futuna 13 17 S 176 10 W
Walvis Bay Namibia 22 59 S 14 31 E
Warsaw [US Embassy] Poland 52 15 N 21 00 E
Washington, DC [US Mission to the Organization of American States (OAS)]
United States 38 53 N 77 02 W
Weddell Sea Southern Ocean 72 00 S 45 00 W
Wellington [US Embassy] New Zealand 41 28 S 174 51 E
West Frisian Islands Netherlands 53 26 N 5 30 E
West Germany (Federal Republic of Germany) Germany 53 22 N 5 20 E
West Island Cocos (Keeling) Islands 12 10 S 96 55 E
West Korea Strait (Western Channel) Pacific Ocean 34 40 N 129 00 E
West Pakistan Pakistan 30 00 N 70 00 E
West Siberian Plain Russia 60 00 N 75 00 E
Western Channel (West Korea Strait) Pacific Ocean 34 40 N 129 00 E
Western Samoa Samoa 13 35 S 172 20 W
Wetar Strait Pacific Ocean 8 20 S 126 30 E
White Sea Arctic Ocean 65 30 N 38 00 E
Willemstad Netherlands Antilles 12 06 N 68 56 W
Windhoek [US Embassy] Namibia 22 34 S 17 06 E
Windward Passage Atlantic Ocean 20 00 N 73 50 W
Wrangel Island (Ostrov Vrangelya) Russia 71 14 N 179 36 W
Y
Yalu River China, North Korea 39 55 N 124 20 E
Yamoussoukro Cote d''Ivoire 6 49 N 5 17 W
Yangon (see Rangoon) Burma 16 47 N 96 10 E
Yaounde [US Embassy] Cameroon 3 52 N 11 31 E
Yap Islands Federated States of Micronesia 9 30 N 138 00 E
Yaren Nauru 0 32 S 166 55 E
Yekaterinburg (Sverdlovsk) [US Consulate General] Russia 56 50 N 60 39 E
Yellow Sea Pacific Ocean 36 00 N 123 00 E
Yemen (Aden) [People''s Democratic Republic of Yemen] Yemen 14 00 N 46 00 E
Yemen Arab Republic Yemen 15 00 N 44 00 E
Yemen, North [Yemen Arab Republic] Yemen 15 00 N 44 00 E
Yemen (Sanaa) [Yemen Arab Republic] Yemen 15 00 N 44 00 E
Yemen, People''s Democratic Republic of Yemen 14 00 N 46 00 E
Yemen, South [People''s Democratic Republic of Yemen] Yemen 14 00 N 46 00 E
Yerevan [US Embassy] Armenia 40 11 N 44 30 E
Youth, Isle of (Isla de la Juventud) Cuba 21 40 N 82 50 W
Yucatan Peninsula Mexico 19 30 N 89 00 W
Yucatan Channel Atlantic Ocean 21 45 N 85 45 W
Yugoslavia Bosnia and Herzegovina, Croatia,
The Former Yugoslav Republic of Macedonia, Serbia and Montenegro, Slovenia
Z
Zagreb [US Embassy] Croatia 45 48 N 15 58 E
Zaire Democratic Republic of the Congo 15 00 S 30 00 E
Zanzibar [island] Tanzania 6 10 S 39 11 E
Zion, Mount Israel, Jordan 31 46 N 35 14 E
Zurich Switzerland 47 23 N 8 32 E
End of the Project Gutenberg EBook of The 2000 CIA World Factbook, by
United States. Central Intelligence Agency.
*** END OF THIS PROJECT GUTENBERG EBOOK THE 2000 CIA WORLD FACTBOOK ***
***** This file should be named 3672.txt or 3672.zip *****
This and all associated files of various formats will be found in:
http://www.gutenberg.org/3/6/7/3672/
Produced by Martin M. Pedersen
Updated editions will replace the previous one--the old editions
will be renamed.
Creating the works from public domain print editions means that no
one owns a United States copyright in these works, so the Foundation
(and you!) can copy and distribute it in the United States without
permission and without paying copyright royalties. Special rules,
set forth in the General Terms of Use part of this license, apply to
copying and distributing Project Gutenberg-tm electronic works to
protect the PROJECT GUTENBERG-tm concept and trademark. Project
Gutenberg is a registered trademark, and may not be used if you
charge for the eBooks, unless you receive specific permission. If you
do not charge anything for copies of this eBook, complying with the
rules is very easy. You may use this eBook for nearly any purpose
such as creation of derivative works, reports, performances and
research. They may be modified and printed and given away--you may do
practically ANYTHING with public domain eBooks. Redistribution is
subject to the trademark license, especially commercial
redistribution.
*** START: FULL LICENSE ***
THE FULL PROJECT GUTENBERG LICENSE
PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK
To protect the Project Gutenberg-tm mission of promoting the free
distribution of electronic works, by using or distributing this work
(or any other work associated in any way with the phrase "Project
Gutenberg"), you agree to comply with all the terms of the Full Project
Gutenberg-tm License (available with this file or online at
http://gutenberg.net/license).
Section 1. General Terms of Use and Redistributing Project Gutenberg-tm
electronic works
1.A. By reading or using any part of this Project Gutenberg-tm
electronic work, you indicate that you have read, understand, agree to
and accept all the terms of this license and intellectual property
(trademark/copyright) agreement. If you do not agree to abide by all
the terms of this agreement, you must cease using and return or destroy
all copies of Project Gutenberg-tm electronic works in your possession.
If you paid a fee for obtaining a copy of or access to a Project
Gutenberg-tm electronic work and you do not agree to be bound by the
terms of this agreement, you may obtain a refund from the person or
entity to whom you paid the fee as set forth in paragraph 1.E.8.
1.B. "Project Gutenberg" is a registered trademark. It may only be
used on or associated in any way with an electronic work by people who
agree to be bound by the terms of this agreement. There are a few
things that you can do with most Project Gutenberg-tm electronic works
even without complying with the full terms of this agreement. See
paragraph 1.C below. There are a lot of things you can do with Project
Gutenberg-tm electronic works if you follow the terms of this agreement
and help preserve free future access to Project Gutenberg-tm electronic
works. See paragraph 1.E below.
1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation"
or PGLAF), owns a compilation copyright in the collection of Project
Gutenberg-tm electronic works. Nearly all the individual works in the
collection are in the public domain in the United States. If an
individual work is in the public domain in the United States and you are
located in the United States, we do not claim a right to prevent you from
copying, distributing, performing, displaying or creating derivative
works based on the work as long as all references to Project Gutenberg
are removed. Of course, we hope that you will support the Project
Gutenberg-tm mission of promoting free access to electronic works by
freely sharing Project Gutenberg-tm works in compliance with the terms of
this agreement for keeping the Project Gutenberg-tm name associated with
the work. You can easily comply with the terms of this agreement by
keeping this work in the same format with its attached full Project
Gutenberg-tm License when you share it without charge with others.
1.D. The copyright laws of the place where you are located also govern
what you can do with this work. Copyright laws in most countries are in
a constant state of change. If you are outside the United States, check
the laws of your country in addition to the terms of this agreement
before downloading, copying, displaying, performing, distributing or
creating derivative works based on this work or any other Project
Gutenberg-tm work. The Foundation makes no representations concerning
the copyright status of any work in any country outside the United
States.
1.E. Unless you have removed all references to Project Gutenberg:
1.E.1. The following sentence, with active links to, or other immediate
access to, the full Project Gutenberg-tm License must appear prominently
whenever any copy of a Project Gutenberg-tm work (any work on which the
phrase "Project Gutenberg" appears, or with which the phrase "Project
Gutenberg" is associated) is accessed, displayed, performed, viewed,
copied or distributed:
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
1.E.2. If an individual Project Gutenberg-tm electronic work is derived
from the public domain (does not contain a notice indicating that it is
posted with permission of the copyright holder), the work can be copied
and distributed to anyone in the United States without paying any fees
or charges. If you are redistributing or providing access to a work
with the phrase "Project Gutenberg" associated with or appearing on the
work, you must comply either with the requirements of paragraphs 1.E.1
through 1.E.7 or obtain permission for the use of the work and the
Project Gutenberg-tm trademark as set forth in paragraphs 1.E.8 or
1.E.9.
1.E.3. If an individual Project Gutenberg-tm electronic work is posted
with the permission of the copyright holder, your use and distribution
must comply with both paragraphs 1.E.1 through 1.E.7 and any additional
terms imposed by the copyright holder. Additional terms will be linked
to the Project Gutenberg-tm License for all works posted with the
permission of the copyright holder found at the beginning of this work.
1.E.4. Do not unlink or detach or remove the full Project Gutenberg-tm
License terms from this work, or any files containing a part of this
work or any other work associated with Project Gutenberg-tm.
1.E.5. Do not copy, display, perform, distribute or redistribute this
electronic work, or any part of this electronic work, without
prominently displaying the sentence set forth in paragraph 1.E.1 with
active links or immediate access to the full terms of the Project
Gutenberg-tm License.
1.E.6. You may convert to and distribute this work in any binary,
compressed, marked up, nonproprietary or proprietary form, including any
word processing or hypertext form. However, if you provide access to or
distribute copies of a Project Gutenberg-tm work in a format other than
"Plain Vanilla ASCII" or other format used in the official version
posted on the official Project Gutenberg-tm web site (www.gutenberg.net),
you must, at no additional cost, fee or expense to the user, provide a
copy, a means of exporting a copy, or a means of obtaining a copy upon
request, of the work in its original "Plain Vanilla ASCII" or other
form. Any alternate format must include the full Project Gutenberg-tm
License as specified in paragraph 1.E.1.
1.E.7. Do not charge a fee for access to, viewing, displaying,
performing, copying or distributing any Project Gutenberg-tm works
unless you comply with paragraph 1.E.8 or 1.E.9.
1.E.8. You may charge a reasonable fee for copies of or providing
access to or distributing Project Gutenberg-tm electronic works provided
that
- You pay a royalty fee of 20% of the gross profits you derive from
the use of Project Gutenberg-tm works calculated using the method
you already use to calculate your applicable taxes. The fee is
owed to the owner of the Project Gutenberg-tm trademark, but he
has agreed to donate royalties under this paragraph to the
Project Gutenberg Literary Archive Foundation. Royalty payments
must be paid within 60 days following each date on which you
prepare (or are legally required to prepare) your periodic tax
returns. Royalty payments should be clearly marked as such and
sent to the Project Gutenberg Literary Archive Foundation at the
address specified in Section 4, "Information about donations to
the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies
you in writing (or by e-mail) within 30 days of receipt that s/he
does not agree to the terms of the full Project Gutenberg-tm
License. You must require such a user to return or
destroy all copies of the works possessed in a physical medium
and discontinue all use of and all access to other copies of
Project Gutenberg-tm works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any
money paid for a work or a replacement copy, if a defect in the
electronic work is discovered and reported to you within 90 days
of receipt of the work.
- You comply with all other terms of this agreement for free
distribution of Project Gutenberg-tm works.
1.E.9. If you wish to charge a fee or distribute a Project Gutenberg-tm
electronic work or group of works on different terms than are set
forth in this agreement, you must obtain permission in writing from
both the Project Gutenberg Literary Archive Foundation and Michael
Hart, the owner of the Project Gutenberg-tm trademark. Contact the
Foundation as set forth in Section 3 below.
1.F.
1.F.1. Project Gutenberg volunteers and employees expend considerable
effort to identify, do copyright research on, transcribe and proofread
public domain works in creating the Project Gutenberg-tm
collection. Despite these efforts, Project Gutenberg-tm electronic
works, and the medium on which they may be stored, may contain
"Defects," such as, but not limited to, incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other intellectual
property infringement, a defective or damaged disk or other medium, a
computer virus, or computer codes that damage or cannot be read by
your equipment.
1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES - Except for the "Right
of Replacement or Refund" described in paragraph 1.F.3, the Project
Gutenberg Literary Archive Foundation, the owner of the Project
Gutenberg-tm trademark, and any other party distributing a Project
Gutenberg-tm electronic work under this agreement, disclaim all
liability to you for damages, costs and expenses, including legal
fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT
LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE
PROVIDED IN PARAGRAPH F3. YOU AGREE THAT THE FOUNDATION, THE
TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE
LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR
INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH
DAMAGE.
1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND - If you discover a
defect in this electronic work within 90 days of receiving it, you can
receive a refund of the money (if any) you paid for it by sending a
written explanation to the person you received the work from. If you
received the work on a physical medium, you must return the medium with
your written explanation. The person or entity that provided you with
the defective work may elect to provide a replacement copy in lieu of a
refund. If you received the work electronically, the person or entity
providing it to you may choose to give you a second opportunity to
receive the work electronically in lieu of a refund. If the second copy
is also defective, you may demand a refund in writing without further
opportunities to fix the problem.
1.F.4. Except for the limited right of replacement or refund set forth
in paragraph 1.F.3, this work is provided to you ''AS-IS'' WITH NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
WARRANTIES OF MERCHANTIBILITY OR FITNESS FOR ANY PURPOSE.
1.F.5. Some states do not allow disclaimers of certain implied
warranties or the exclusion or limitation of certain types of damages.
If any disclaimer or limitation set forth in this agreement violates the
law of the state applicable to this agreement, the agreement shall be
interpreted to make the maximum disclaimer or limitation permitted by
the applicable state law. The invalidity or unenforceability of any
provision of this agreement shall not void the remaining provisions.
1.F.6. INDEMNITY - You agree to indemnify and hold the Foundation, the
trademark owner, any agent or employee of the Foundation, anyone
providing copies of Project Gutenberg-tm electronic works in accordance
with this agreement, and any volunteers associated with the production,
promotion and distribution of Project Gutenberg-tm electronic works,
harmless from all liability, costs and expenses, including legal fees,
that arise directly or indirectly from any of the following which you do
or cause to occur: (a) distribution of this or any Project Gutenberg-tm
work, (b) alteration, modification, or additions or deletions to any
Project Gutenberg-tm work, and (c) any Defect you cause.
Section 2. Information about the Mission of Project Gutenberg-tm
Project Gutenberg-tm is synonymous with the free distribution of
electronic works in formats readable by the widest variety of computers
including obsolete, old, middle-aged and new computers. It exists
because of the efforts of hundreds of volunteers and donations from
people in all walks of life.
Volunteers and financial support to provide volunteers with the
assistance they need, is critical to reaching Project Gutenberg-tm''s
goals and ensuring that the Project Gutenberg-tm collection will
remain freely available for generations to come. In 2001, the Project
Gutenberg Literary Archive Foundation was created to provide a secure
and permanent future for Project Gutenberg-tm and future generations.
To learn more about the Project Gutenberg Literary Archive Foundation
and how your efforts and donations can help, see Sections 3 and 4
and the Foundation web page at http://www.pglaf.org.
Section 3. Information about the Project Gutenberg Literary Archive
Foundation
The Project Gutenberg Literary Archive Foundation is a non profit
501(c)(3) educational corporation organized under the laws of the
state of Mississippi and granted tax exempt status by the Internal
Revenue Service. The Foundation''s EIN or federal tax identification
number is 64-6221541. Its 501(c)(3) letter is posted at
http://pglaf.org/fundraising. Contributions to the Project Gutenberg
Literary Archive Foundation are tax deductible to the full extent
permitted by U.S. federal laws and your state''s laws.
The Foundation''s principal office is located at 4557 Melan Dr. S.
Fairbanks, AK, 99712., but its volunteers and employees are scattered
t','d465f09a2b73a935595b38ddad1d5ae0d53117a08241f1615f14c01f1887fcdb','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('385be0a0555e1220124bb31371ffb218878a3c0090b602172f3021a9483cddab',2000,'ZM','Zambia','environment',258,'hroughout numerous locations. Its business office is located at
809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887, email
business@pglaf.org. Email contact links and up to date contact
information can be found at the Foundation''s web site and official
page at http://pglaf.org
For additional contact information:
Dr. Gregory B. Newby
Chief Executive and Director
gbnewby@pglaf.org
Section 4. Information about Donations to the Project Gutenberg
Literary Archive Foundation
Project Gutenberg-tm depends upon and cannot survive without wide
spread public support and donations to carry out its mission of
increasing the number of public domain and licensed works that can be
freely distributed in machine readable form accessible by the widest
array of equipment including outdated equipment. Many small donations
($1 to $5,000) are particularly important to maintaining tax exempt
status with the IRS.
The Foundation is committed to complying with the laws regulating
charities and charitable donations in all 50 states of the United
States. Compliance requirements are not uniform and it takes a
considerable effort, much paperwork and many fees to meet and keep up
with these requirements. We do not solicit donations in locations
where we have not received written confirmation of compliance. To
SEND DONATIONS or determine the status of compliance for any
particular state visit http://pglaf.org
While we cannot and do not solicit contributions from states where we
have not met the solicitation requirements, we know of no prohibition
against accepting unsolicited donations from donors in such states who
approach us with offers to donate.
International donations are gratefully accepted, but we cannot make
any statements concerning tax treatment of donations received from
outside the United States. U.S. laws alone swamp our small staff.
Please check the Project Gutenberg Web pages for current donation
methods and addresses. Donations are accepted in a number of other
ways including including checks, online payments and credit card
donations. To donate, please visit: http://pglaf.org/donate
Section 5. General Information About Project Gutenberg-tm electronic
works.
Professor Michael S. Hart is the originator of the Project Gutenberg-tm
concept of a library of electronic works that could be freely shared
with anyone. For thirty years, he produced and distributed Project
Gutenberg-tm eBooks with only a loose network of volunteer support.
Project Gutenberg-tm eBooks are often created from several printed
editions, all of which are confirmed as Public Domain in the U.S.
unless a copyright notice is included. Thus, we do not necessarily
keep eBooks in compliance with any particular paper edition.
Most people start at our Web site which has the main PG search facility:
http://www.gutenberg.net
This Web site includes information about Project Gutenberg-tm,
including how to make donations to the Project Gutenberg Literary
Archive Foundation, how to help produce our new eBooks, and how to
subscribe to our email newsletter to hear about new eBooks.','3ea8be8f27ae31eb1504eded5a3d6b10a200bd1e4ab3981dde19282b1cc11549','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

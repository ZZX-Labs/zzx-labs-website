SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99aa3ec2bf10266d60d00d5c6373d724bd8f8f4547f6e5cf3cb55b5d71da96cf',2000,'AI','Anguilla','introduction',31,'Background: Colonized by English settlers from
Saint Kitts in 1650, Anguilla was administered by
Great Britain until the early 19th century, when the
island - against the wishes of the inhabitants - was
incorporated into a single British dependency along
with Saint Kitts and Nevis. Several attempts at
separation failed. In 1971, two years after a revolt,
Anguilla was finally allowed to secede; this
arrangement was formally recognized in 1980 with
Anguilla becoming a separate British dependency.','b091e64ef3067b0d44a686d7744f88f17d3ccc1cc0371f7698d72eaa0c2722f5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c87df22ea6ec090ad557173c90f1b7aea0cf7ac4ad24e8d7cabc87d2e028bc04',2000,'GP','Guadeloupe','introduction',42,'C’.
Background: A spring 2000 decision by the
International Hydrographic Organization delimited a
fifth world ocean from the southern portions of the
Atlantic Ocean, Indian Ocean, and Pacific Ocean. The
new ocean extends from the coast of Antarctica north
to 60 degrees south latitude which coincides with the
Antarctic Treaty Limit. The Arctic Ocean remains the
smallest of the world''s five oceans (after the Pacific
Ocean, Atlantic Ocean, Indian Ocean, and Southern
Ocean).
6 e 6”g rap h y
Location: body of water mostly north of the Arctic
Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Greenland Sea,
Hudson Bay, Hudson Strait, Kara Sea, Laptev Sea,
Northwest Passage, and other tributary water bodies
Area - comparative: slightly less than 1 .5 times the
size of the US
Coastline: 45,389 km
Climate: polar climate characterized by persistent
cold and relatively narrow annual temperature ranges;
winters characterized by continuous darkness, cold
and stable weather conditions, and clear skies;
summers characterized by continuous daylight, damp
and foggy weather, and weak cyclones with rain or
snow
Terrain: central surface covered by a perennial
drifting polar icepack that averages about 3 meters in
thickness, although pressure ridges may be three
times that size; clockwise drift pattern in the Beaufort
Gyral Stream, but nearly straight-line movement from
the New Siberian Islands (Russia) to Denmark Strait
(between Greenland and Iceland); the icepack is
surrounded by open seas during the summer, but
more than doubles in size during the winter and
extends to the encircling landmasses; the ocean floor
is about 50% continental shelf (highest percentage of
any ocean) with the remainder a central basin
interrupted by three submarine ridges (Alpha
Cordillera, Nansen Cordillera, and Lomonosov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates,
placer deposits, polymetallic nodules, oil and gas
fields, fish, marine mammals (seals and whales)
Natural hazards: ice islands occasionally break
away from northern Ellesmere Island; icebergs calved
from glaciers in western Greenland and extreme
northeastern Canada; permafrost in islands; virtually
ice locked from October to June; ships subject to
superstructure icing from October to May
Environment - current issues: endangered marine
species include walruses and whales; fragile
ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
Geography - note: major chokepoint is the southern
Chukchi Sea (northern access to the Pacific Ocean
via the Bering Strait); strategic location between North
America and Russia; shortest marine link between the
extremes of eastern and western Russia; floating
research stations operated by the US and Russia;
maximum snow cover in March or April about 20 to 50
centimeters over the frozen ocean; snow cover lasts
about 10 months
''j Government
Data code: none; the US Government has not
approved a standard for hydrographic codes - see the
Cross-Reference List of Hydrographic Data Codes
appendix','5a0402f3d171502feaa4b09c88644fdd9feb90991c618a2876c44897a21e2075','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf1aa9cdfe108a06e5c3b5b7912d17355846bcd7587a3f37cc3ff6d9bc310bce',2000,'AZ','Azerbaijan','introduction',54,'Background: Azerbaijan - a nation of Turkic
Musiims - has been an independent repubiic since the
coliapse of the Soviet Union in 1991. Despite a
cease-fire, in piace since 1994, Azerbaijan has yet to
resolve its confiict rwith Armenia over the Azerbaijani
Nagorno-Karabakh enciave (iargeiy Armenian
popuiated). Azerbaijan has iost almost 20% of its
territory and must support some 750,000 refugees as
a resuit of the conflict. Corruption is ubiquitous and the
promise of weaith from Azerbaijan''s undeveioped
petroieum resources remains iargeiy unfuifiiied.','30225e78b69f28ee72eba1f1a05a03b1ff32517c08b24f65b1b3558889ecc20d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa523979c0c448bc7743fde6db01d269b933ebf25fc08987df932508866dd471',2000,'ET','Ethiopia','introduction',98,'Background: Between 1993 and 1999, ethnic
violence between Hutu and Tutsi factions in Burundi
created hundreds of thousands of refugees and left at
least 250,000 dead. Although many refugees have
returned from neighboring countries, continued ethnic
strife has forced others to flee. Burundian troops,
seeking to secure their borders, have intervened in the
conflict in the Democratic Republic of the Congo.
I ''Geography
Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
/and; 25,650 Sq km
water: 2,180 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo
233 km, Rwanda 290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable
altitude variation (772 m to 2,670 m); average annual
temperature varies with altitude from 23 to 1 7 degrees
centigrade but is generally moderate as the average
altitude is about 1,700 m; average annual rainfall is
about 1 50 cm; wet seasons from February to May and
September to November, and dry seasons from June
to August and December to January
Terrain: hilly and mountainous, dropping to a plateau
in east, some plains
Elevation extremes:
lowest point: Lake Tanganyika Til m
highest point: Mount Heha 2,670 m
Natural resources: nickel, uranium, rare earth
oxides, peat, cobalt, copper, platinum (not yet
exploited), vanadium, arable land, hydropower
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures: 36%
forests and woodland: 3%
other: 8% (1993est.)
Irrigated land: 140 sq km (1 993 est.)
Natural hazards: flooding, landslides
Environment - current issues: soil erosion as a
result of overgrazing and the expansion of agriculture
into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for
fuel); habitat loss threatens wildlife populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear
Test Ban
Geography - note: landlocked; straddles crest of the
Nile-Congo watershed
I p''e 0 p I e "
Population: 6,054,714
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 47% (male 1 ,442,585; female 1 ,41 1 ,908)
15-64 years: 50% (male 1 ,485,177; female
1,541,754)
65 years and over: 3% (male 71 ,998; female
101 ,292) (2000 est.)
Population growth rate: 3.15% (2000 est.)
Birth rate: 40.46 births/1 ,000 population (2000 est.)
Death rate: 1 6.44 deaths/1 ,000 population
(2000 est.)
Net migration rate: 7.43 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 71.5 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 46.18 years
male: 45.23 years
female: 47.1 6 years (2000 est.)
Total fertility rate: 6.25 children born/woman
(2000 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 23%, Muslim 10%
Languages: Kirundi (official), French (official),
Swahili (along Lake Tanganyika and in the Bujumbura
area)
Literacy:
definition: age 15 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1 995 est.)','1d95c8f9bf286afc5f7c056ab5c97cb1351f1ecfa8ff79700c18607a0139900a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('107946bb1b70b148adc4817c83c342aa9b0fad7eedac4db24e306148371e5d7e',2000,'HN','Honduras','introduction',118,'Background: For centuries China has stood as a
leading civilization, outpacing the rest of the world in
the arts and sciences. But in the first half of the 20th
century, China was beset by major famines, civil
unrest, military defeats, and foreign occupation. After
World War II, the Communists under MAC Zedong
established a dictatorship that, while ensuring China''s
sovereignty, imposed strict controls over everyday life
and cost the lives of tens of millions of people. After
1978, his successor DENG Xiaoping decentralized
economic decision making. Cutput quadrupled in the
next 20 years and China now has the world''s second
largest GDP. Political controls remain tight even while
economic controls continue to weaken.
? G eFg r a p h y
Location: Eastern Asia, bordering the East China
Sea, Korea Bay, Yellow Sea, and South China Sea,
between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total: 9,596,960 sq km
land: 9,326,410 sq km
water: 270,550 sq km
Area - comparative: slightly smaller than the US
Land boundaries:
fofa/;22,143.34km
border countries: Afghanistan 76 km, Bhutan 470 km,
Burma 2,185 km, Hong Kong 30 km, India 3,380 km,
Kazakhstan 1 ,533 km. North Korea 1 ,416 km,
Kyrgyzstan 858 km, Laos 423 km, Macau 0.34 km,
Mongolia 4,673 km, Nepal 1,236 km, Pakistan 523
km, Russia (northeast) 3,605 km, Russia (northwest)
40 km, Tajikistan 414 km, Vietnam 1 ,281 km
Coastline: 14,500 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
territorial sea: 12 nm
Climate: extremely diverse; tropical in south to
subarctic in north
Terrain: mostly mountains, high plateaus, deserts in
west; plains, deltas, and hills in east
Elevation extremes:
lowest point; Turpan Pendi -154 m
highest point: Mount Everest 8,850 m (1999 est.)
Natural resources: coal, iron ore, petroleum, natural
gas, mercury, tin, tungsten, antimony, manganese,
molybdenum, vanadium, magnetite, aluminum, lead,
zinc, uranium, hydropower potential (world''s largest)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 43%
forests and woodland: 14%
other: 33% (1993 est.)
Irrigated land: 498,720 sq km (1993 est.)
Natural hazards: frequent typhoons (about five per
year along southern and eastern coasts); damaging
floods; tsunamis; earthquakes; droughts
Environment - current issues: air pollution
(greenhouse gases, sulfur dioxide particulates) from
reliance on coal, produces acid rain; water shortages,
particularly in the north; water pollution from untreated
wastes; deforestation; estimated loss of one-fifth of
agricultural land since 1949 to soil erosion and
economic development; desertification; trade in
endangered species
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: world''s fourth-largest country
(after Russia, Canada, and US)
102
China (continued)
I People
Population; 1 ,261 ,832,482 (July 2000 est.)
Age structure:
0-14 years: 25% (male 168,040,006; female
152,826,953)
15-64 years: 68% (male 439,736,737; female
413,454,673)
65 years and over: 7% (male 41 ,200,297; female
46,573,816) (2000 est.)
Population growth rate: 0.9% (2000 est.)
Birth rate: 16.12 births/1,000 population (2000 est.)
Death rate: 6.73 deaths/1,000 population
(2000 est.)
Net migration rate: -0.4 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.15 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.06 male(s)/female (2000 est.)
Infant mortality rate: 28.92 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .38 years
male: 69.6 years
female: 73.33 years (2000 est.)
Total fertility rate: 1.82 children born/woman
(2000 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91 .9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoist (Taoist), Buddhist, Muslim
2%-3%, Christian 1% (est.)
note: officially atheist
Languages; Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic groups entry)
Literacy;
definition: age 1 5 and over can read and write
total population: 81 .5%
male: 89.9%
fema/e; 72.7% (1995 est.)
I Government
Country name;
conventional long form: People''s Republic of China
conventional short form: China
local long form; Zhonghua Renmin Gongheguo
local short form: Zhong Guo
abbreviation: PRC
Data code: CH
Government type: Communist state
Capital; Beijing
Administrative divisions; 23 provinces (sheng,
singular and plural), 5 autonomous regions* (zizhiqu.
singular and plural), and 4 municipalities** (shi,
singular and plural); Anhui, Beijing**, Chongqing**,
Fujian, Gansu, Guangdong, Guangxi*, Guizhou,
Hainan, Hebei, Heilongjiang, Henan, Hubei, Hunan,
Jiangsu, Jiangxi, Jilin, Liaoning, Nei Mongol*,
NIngxia*, Qinghai, Shaanxi, Shandong, Shanghai**,
Shanxi, Sichuan, Tianjin**, Xinjiang*, Xizang* (Tibet),
Yunnan, Zhejiang
note: China considers Taiwan its 23rd province; see
separate entries for the special administrative regions
of Hong Kong and Macau
Independence: 221 BC (unification under the Qin or
Ch''in Dynasty 221 BC; Qing or Ch''ing Dynasty
replaced by the Republic on 12 February 1912;
People’s Republic established 1 October 1949)
National holiday; National Day, 1 October (1949)
Constitution: most recent promulgation 4 December
1982
Legal system: a complex amalgam of custom and
statute, largely criminal law; rudimentary civil code in
effect since 1 January 1987; new legal codes in effect
since 1 January 1980; continuing efforts are being
made to improve civil, administrative, criminal, and
commercial law
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President JIANG Zemin (since 27
March 1993) and Vice President HU Jintao (since 16
March 1998)
head of government: Premier ZHU Rongji (since 18
March 1998); Vice Premiers QIAN Qichen (since 29
March 1993), LI Lanqing (29 March 1993), WU
Bangguo (since 17 March 1995), and WEN Jiabao
(since 18 March 1998)
cabinet: State Council appointed by the National
People''s Congress (NPC)
elections: president and vice president elected by the
National People''s Congress for five-year terms;
elections last held 1 6-1 8 March 1 998 (next to be held
NA March 2003); premier nominated by the president,
confirmed by the National People''s Congress
election results: JIANG Zemin reelected president by
the Ninth National People''s Congress with a total of
2,882 votes (36 delegates voted against him, 29
abstained, and 32 did not vote); HU Jintao elected
vice president by the Ninth National People''s
Congress with a total of 2,841 votes (67 delegates
voted against him, 39 abstained, and 32 did not vote)
Legislative branch: unicameral National People''s
Congress or Quanguo Renmin Daibiao Dahui (2,979
seats; members elected by municipal, regional, and
provincial people''s congresses to serve five-year
terms)
elections: last held NA December 1997-NA February
1 998 (next to be held late 2002-NA March 2003)
election results: percent of vote - NA; seats - NA
Judicial branch; Supreme People''s Court, judges
appointed by the National People’s Congress
Political parties and leaders: Chinese Communist
Party or CCP [JiANG Zemin, General Secretary of the
Central Committee]; eight registered small parties
controlled by CCP
Political pressure groups and leaders: no
substantial political opposition groups exist, aithough
the government has identified the Falungong sect and
the China Democracy Party as potential rivals
International organization participation: AfDB,
APEC, AsDB, BIS, CCC, CDB (non-regional),
ESCAP, FAQ, G-77, IAEA, IBRD, ICAO, ICC, ICFTU,
ICRM, IDA, IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, ISO, ITU, LAIA
(observer), MINURSO, NAM (observer), OPCW,
PCA, UN, UN Security Council, UNAMSIL, UNCTAD,
UNESCO, UNHCR, UNIDO, UNIKOM, UNITAR,
UNTSO, UNU, UPU, WHO, WlPO, WMO, WToO,
WTrO (applicant), ZC
Diplomatic representation in the US:
chief of mission: kmbassador LI Zhaoxing
chancery: 2300 Connecticut Avenue NW,
Washington, DC 20008
fe/eptone;[1 1(202)328-2500
consulate(s) general: Chicago, Houston, Los
Angeles, New York, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Joseph W. PRUEHER
embassy; Xiu Shui Bei Jie 3, 100600 Beijing
mailing address: PSC 461 , Box 50, FPO AP
96521-0002
telephone: [66] [10) 6532-3831
FAX; [86] (10) 6532-6422
consulate(s) general: Chengdu, Guangzhou,
Shanghai, Shenyang
Flag description; red with a large yellow
five-pointed star and four smaller yellow five-pointed
stars (arranged in a vertical arc toward the middle of
the flag) in the upper hoist-side corner
ETon''o¥y
Economy - overview: Beginning in late 1 978 the
Chinese leadership has been moving the economy
from a sluggish Soviet-style centrally planned
economy to a more market-oriented economy but still
within a rigid political framework of Communist Party
control. To this end the authorities have switched to a
system of household responsibility in agriculture in
place of the old collectivization, increased the
authority of local officials and plant managers in
industry, permitted a wide variety of small-scale
enterprise in services and light manufacturing, and
opened the economy to increased foreign trade and
investment. The result has been a quadrupling of GDP
since 1978. In 1999, with its 1.25 billion people but a
GDP of just $3,800 per capita, China became the
second largest economy in the world after the US.
Agricultural output doubled in the 1 980s, and industry
also posted major gains, especially in coastal areas
near Hong Kong and opposite Taiwan, where foreign
investment helped spur output of both domestic and
export goods. On the darker side, the leadership has
often experienced in its hybrid system the worst
results of socialism (bureaucracy, lassitude,
corruption) and of capitalism (windfall gains and
stepped-up inflation). Beijing thus has periodically
backtracked, retightening central controls at intervals.
103
China (continued)
In late 1993 China''s leadership approved additional
long-term reforms aimed at giving stiii more piay to
market-oriented institutions and at strengthening the
center''s controi over the financiai system; state
enterprises would continue to dominate many key
industries in what was now termed "a socialist market
economy". In 1995-99 inflation dropped sharpiy,
refiecting tighter monetary policies and stronger
measures to control food prices. At the same time, the
government struggied to (a) coiiect revenues due from
provinces, businesses, and individuais; (b) reduce
corruption and other economic crimes; and (c) keep
afioat the iarge state-owned enterprises, most of
which had not participated in the vigorous expansion
of the economy and many of which had been losing
the ability to pay fuli wages and pensions. From 50 to
100 million surpius rurai workers are adrift between
the viiiages and the cities, many subsisting through
part-time low-paying jobs. Popular resistance,
changes in centrai poiicy, and loss of authority by rurai
cadres have weakened China''s popuiation controi
program, which is essentiai to maintaining growth in
living standards. Another iong-term threat to
continued rapid economic growth is the deterioration
in the environment, notably air poiiution, soii erosion,
and the steady faii of the water tabie especialiy in the
north. China continues to iose arabie land because of
erosion and economic deveiopment. The next few
years wiii witness increasing tensions between a
highiy centraiized poiiticai system and an increasingiy
decentralized economic system.
GDP: purchasing power parity - $4.8 triiiion
(1999 est.)
GDP - real growth rate: 7% (1999 est.)
GDP - per capita: purchasing power parity - $3,800
(1999 est.)
GDP - composition by sector:
agriculture: t5%
industry: 35%
services: 50% (1999 est.)
Population below poverty line: 10% (1999 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.2%
highest 10%: 30.9% {mS)
Inflation rate (consumer prices): -1 .3% (1 999 est.)
Labor force: 700 million (1998 est.)
Labor force - by occupation: agriculture 50%,
industry 24%, services 26% (1998)
Unemployment rate: urban unemployment roughly
10%; substantial unemployment and
underemployment in rural areas (1999 est.)
Budget:
revenues: $NA
expenditures: $NA, Including capitai expenditures of
SNA
Industries: iron and steel, coal, machine building,
armaments, textiles and apparel, petroleum, cement,
chemical fertilizers, footwear, toys, food processing,
automobiles, consumer electronics,
telecommunications
Industrial production growth rate: 8.8%
(1999 est.)
Electricity - production: 1.16 trillion kWh (1998)
Electricity - production by source:
fossil fuel: 80.31%
hydro: 18.46%
nuclear: 1 .23%
other 0% (1998)
Electricity - consumption: 1 .01 4 trillion kWh (1 998)
Electricity - exports: 7.935 billion kWh (1 998)
Electricity - imports: 89 million kWh (1998)
Agriculture - products: rice, wheat, potatoes,
sorghum, peanuts, tea, millet, barley, cotton, oilseed;
pork; fish
Exports: $1 94.9 billion (f.o.b., 1999)
Exports - commodities: machinery and equipment;
textiles and clothing, footwear, toys and sporting
goods; mineral fuels, chemicals
Exports - partners: US 22%, Hong Kong 19%,
Japan 1 7%, Germany, South Korea, Netherlands, UK,
Singapore, Taiwan (1999)
Imports: $165.8 billion (c.i.f., 1999)
Imports - commodities: machinery and equipment,
plastics, chemicals, iron and steel, mineral fuels
Imports - partners: Japan 20%, US 12%, Taiwan
12%, South Korea 10%, Germany, Hong Kong,
Russia, Singapore (1999)
Debt - external: $159 billion (1998 est.)
Economic aid - recipient: $NA
Currency: 1 yuan = 10 jiao
Exchange rates: yuan per US$1 - 8.2793 (January
2000), 8.2783 (1999), 8.2790 (1998), 8.2898 (1997),
8.3142 (1996), 8.3514 (1995)
note: beginning 1 January 1994, the People''s Bank of
China quotes the midpoint rate against the US dollar
based on the previous day''s prevailing rate in the
interbank foreign exchange market
Fiscal year: calendar year
I Communications
Telephones - main lines in use: 110 million
(1999 est.)
Telephones - mobile cellular: 23.4 million (1998)
Telephone system: domestic and international
services are increasingly available for private use;
unevenly distributed domestic system serves principal
cities, industrial centers, and many towns
domestic: interprovincial fiber-optic trunk lines and
cellular telephone systems have been installed; a
domestic satellite system with 55 earth stations is in
place
international: satellite earth stations - 5 Intelsat (4
Pacific Ocean and 1 1ndian Ocean), 1 Intersputnik
(Indian Ocean region) and 1 1nmarsat (Pacific and
Indian Ocean regions); several international
fiber-optic links to Japan, South Korea, Hong Kong,
Russia, and Germany
Radio broadcast stations: AM 369, FM 259,
shortwave 45 (1998)
Radios: 417 million (1997)
Television broadcast stations: 3,240 (of which 209
are operated by China Central Television, 31 are
provincial TV stations and nearly 3,000 are local city
stations) (1997)
Televisions: 400 million (1997)
Internet Service Providers (ISPs): 3 (1999)','11fb9296b913e749d369712aad5b4e7c5e22889da3954cc09b966b82b7343279','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3180a975985c5cf37fad370de67e2932373717a748f644c9981d704cdc23200c',2000,'AU','Australia','introduction',135,'Background: Colombia was one of the three
countries that emerged from the collapse of Gran
Colombia in 1830 (the others being Ecuador and
Venezuela). A 40-year insurgent campaign to
overthrow the Colombian Government escalated
during the 1990s, undergirded in part by funds from
the drug trade. Although the violence is deadly and
large swaths of the countryside are under guerrilla
influence, the movement lacks the military strength or
popular support necessary to overthrow the
government. While Bogota continues to try to
negotiate a settlement, neighboring countries worry
about the violence spilling over their borders.
Background: Occupied by the UK in 1 841 , Hong
Kong was formaliy ceded by China the foiiowing year;
various adjacent lands were added later in the 19th
century. Pursuant to an agreement signed by China
and the UK on 19 December 1984, Hong Kong
became the Hong Kong Speciai Administrative
Region (SAR) of China on 1 Juiy 1997. In this
agreement, China has promised that, under its "one
country, two systems" formuia, China''s sociaiist
economic system wiii not be practiced in Hong Kong
and that Hong Kong wiil enjoy a high degree of
autonomy in aii matters except foreign and defense
affairs for the next 50 years.
Background: Under US administration as part of the
UN Trust Territory of the Pacific, the people of the
Northern Mariana Islands decided in the 1970s not to
seek independence but instead to forge closer links
with the US. Negotiations for territorial status began in
1972. A covenant to establish a commonwealth in
political union with the US was approved in 1975. A
new government and constitution went into effect in
1978.','34d25a74a1fa6f4ca4ec85cc492ead0b52a2c2b92f5ebe8ae424e71bf18ab9c7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f486a3f9024e7902ba2fe6d1cf6752e355b7d1b24c10cbda6a01fdf3af9dfd8',2000,'YT','Mayotte','introduction',139,'Background; Unstable Comoros has endured 19
coups or attempted coups since gaining
independence from France in 1975. In 1997, the
islands of Anjouan and Moheli declared their
independence from Comoros. A subsequent attempt
by the government to reestablish control over the
rebellious islands by force failed, and presently the
Organization of African Unity is brokering negotiations
to effect a reconciliation.
f Geography
Location; Southern Africa, group of islands in the
Mozambique Channel, about two-thirds of the way
between northern Madagascar and northern','64364f75024f738256fb56f9f84141ba6a0c80698e32ee211dc9306d103d98e2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdb53737c3ccc852f7981013024ca336616091971ed179bfe91b816f8e325b59',2000,'MZ','Mozambique','introduction',140,'Geographic coordinates; 12 10 S, 44 15 E
Map references; Africa
Area;
total: 2,170 sqkm
land: 2,170 sq km
wafer 0 sq km
Area - comparative; slightly more than 1 2 times the
size of Washington, DC
Land boundaries; 0 km
Coastline; 340 km
Maritime ciaims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; tropical marine; rainy season (November to
May)
Terrain; volcanic islands, interiors vary from steep
mountains to low hills
Elevation extremes;
lowest point: Indian Ocean 0 m
highest point: Le Kartala 2,360 m
Natural resources; NEGL
Land use;
arable land: 35%
permanent crops: 1 0%
permanent pastures: 7%
forests and woodland: 1 8%
other: 30% (1993 est.)
Irrigated land; NAsqkm
Natural hazards; cyclones possible during rainy
season (December to April); Le Kartala on Grand
Comore is an active volcano
Environment - current issues; soil degradation
and erosion results from crop cultivation on slopes
without proper terracing; deforestation
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note; important location at northern
end of Mozambique Channel
!■ . - . .
Population; 578,400 (July 2000 est.)
Age structure;
0-14 years: 43% (male 123,891; female 123,241)
15-64 years: 54% (male 155,062; female 159,287)
65 years and over: 3% (male 8,072; female 8,847)
(2000 est.)
Population growth rate; 3.05% (2000 est.)
Birth rate; 40.05 births/1 ,000 population (2000 est.)
Death rate; 9.59 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate; 86.33 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 60.03 years
male: 57.85 years
female: 62.28 years (2000 est.)
Total fertility rate; 5.38 children born/woman
(2000 est.)
Nationality;
noun: Comoran(s)
adjective: Comoran
Ethnic groups; Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions; Sunni Muslim 98%, Roman Catholic 2%
Languages; Arabic (official), French (official),
Comoran (a blend of Swahili and Arabic)
Literacy;
definition: age 15 and over can read and write
total population: 57.3%
male: 64,2%
female: 50.4% (1995 est.)
Ill
Comoros (continued)
Background: Since 1994 the Democratic Republic
of the Congo (DROC; formerly called Zaire) has been
rent by ethnic strife and civil war, touched off by a
massive inflow of refugees from the fighting in
Rwanda and Burundi. Troops from Uganda, Rwanda,
Zimbabwe, Angola, and Namibia have intervened in
this devastating conflict. A cease-fire was signed on
10 July 1999, but skirmishing continues.
I — pipy
Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
total: 2,345, 41 Osq km
land: 2,267,600 sq km
water 77,810 sq km
Area - comparative: slightly less than one-fourth the
size of the US
Land boundaries:
total: 10,744 km
border courrfr/es; Angola 2,511 km, Burundi 233 km.
Central African Republic 1,577 km. Republic of the
Congo 2,410 km, Rwanda 217 km, Sudan 628 km,
Tanzania 473 km, Uganda 765 km, Zambia 1 ,930 km
Coastline: 37 km
Maritime claims:
exclusive economic zone: boundaries with neighbors
tern''torial sea: 12 nm
Climate: tropical; hot and humid in equatorial river
basin; cooler and drier in southern highlands; cooler
and wetter in eastern highlands; north of Equator - wet
season April to October, dry season December to
February; south of Equator - wet season November to
March, dry season April to October
Terrain: vast central basin is a low-lying plateau;
mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont Ngaliema
(Mount Stanley) 5,110 m
Natural resources: cobalt, copper, cadmium,
petroleum, industrial and gem diamonds, gold, silver,
zinc, manganese, tin, germanium, uranium, radium,
bauxite, iron ore, coal, hydropower, timber
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 77%
ofber13%(1993est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: periodic droughts in south;
volcanic activity
Environment - current issues: poaching threatens
wildlife populations; water pollution; deforestation;
refugees who arrived in mid-1994 were responsible
for significant deforestation, soil erosion, and wildlife
poaching in the eastern part of the country (most of
those refugees were repatriated in November and
December 1996)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropipal Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Geography • note: straddles Equator; very narrow
strip of land that controls the lower Congo river and is
only outlet to South Atlantic Ocean; dense tropicai rain
forest in central river basin and eastern highlands
I — - pi e 0 p
Population: 51,964,999
note: estimates for this country explicitly take into
account the effects of excess mortality due to AiDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 43% (male 12,597,444; female
12,490,279)
15-64 years: 49% (male 12,503,440; female
13,037,527)
65 years and over: 3% (male 567,823; female
768,486) (2000 est.)
Population growth rate: 3.19% (2000 est.)
Birth rate: 46.44 births/1,000 population (2000 est.)
Death rate: 1 5.38 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.82 migrant(s)/1,000
population (2000 est.)
note: in 1994, about a million refugees fled into Zaire
(now called the Democratic Republic of the Congo or
DROC), to escape the fighting between the Hutus and
the Tutsis in Rwanda and Burundi; the outbreak of
widespread fighting in the DROC between rebels and
government forces in October 1 996 spurred about
113
Congo, Democratic Republic of the
(continued)
875,000 refugees to return to Rwanda in late 1996
and early 1997; an additional 173,000 Rwandan
refugees disappeared in early 1 997 and are assumed
to have been killed by DROC forces; fighting renewed
in August 1998 and has continued sporadically into
2000 resulting in further internal displacement and
refugee movements within the Great Lakes region
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 1 01 .71 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 48.75 years
male: 46.72 years
female: 50.83 years (2000 est.)
Total fertility rate: 6.92 children born/woman
(2000 est.)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes -
Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and indigenous beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili or Swahili), Kikongo, Tshiluba
Literacy:
definition: age 15 and over can read and write French,
Lingala, Kingwana, or Tshiluba
total population: 77.3%
male: 86.6%
fema/e; 67.7% (1995 est.)','d25485da7eea593bddf6abdfe1a8a76b3422b9cc80371940597fea611e546e89','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02416a8de5332928c56944458855bdc951e82acd0adbf4420fbb9aa61d64f356',2000,'CK','Cook Islands','introduction',150,'Background: Named after Captain Cook, who
sighted them in 1770, the islands became a British
protectorate in 1888. By 1900, administrative control
was transferred to New Zealand; in 1965 residents
chose self-government in free association with New
Zealand. The emigration of skilled workers to New
Zealand and government deficits are continuing
problems.
Background: The island of Jersey and the other
Channel Islands represent the last remnants of the
medieval Dukedom of Normandy that held sway in
both France and England. These islands were the
only British soil occupied by German troops in World
War II.','7da6358897ccb37a7f8c35968525bc0a68844fa2d536548d5734b2743310d652','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af120e1e37642125a45eb5851ae74290b16d615a3c1a204421335995055b9b4c',2000,'CU','Cuba','introduction',172,'Background: The French Territory of the Afars and
the Issas became Djibouti in 1977. A peace accord in
1994 ended a three-year uprising by Afars rebels.','48eb37ea6d7da24ca75651a829c05952435f67b9f2fb2cbb94a482045fbc7ae8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0360b059fa2f96a7b3b0df21dc22acca06e1944fbceb9df2c9615df681f084e7',2000,'PE','Peru','introduction',174,'Background: Nominally independent from the UK in
1 922, Egypt acquired full sovereignty following World
War II. The completion of the Aswan High Dam in
1971 and the resultant Lake Nasser have altered the
time-honored place of the Nile River in the agriculture
and ecology of Egypt. A rapidly growing population
(the largest in the Arab world) will continue to stress
Egyptian society and overtax resources as the country
enters the new millennium.','967074bffb62c74bd7c2792448a7d2b89883221be912cd51f17b6a3c73345255','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a62655da9fad040c5895b558efc6bd3c8f04de8b3c071d6603e8d98f2f881f2b',2000,'IS','Iceland','introduction',241,'Background: Known as Persia until 1935, Iran
became an Islamic republic in 1979 after the ruling
shah was forced into exile. Conservative clerical
forces subsequently crushed westernizing liberal
elements. Militant Iranian students seized the US
Embassy in Tehran on 4 November 1979 and held it
until 20 January 1 981 . During 1 980-88, Iran fought a
bloody, indecisive war with Iraq over disputed
territory. The key current issue is how rapidly the
country should open up to the modernizing influences
of the outside world.
I- ’ G e 0 g f r
Location: Middle East, bordering the Gulf of Oman,
the Persian Gulf, and the Caspian Sea, between Iraq
and Pakistan
Geographic coordinates; 32 00 N, 53 00 E
Map references; Middie East
Area;
total: 1 .648 million sq km
land: 1 .636 million sq km
water: 12,000 sq km
Area - comparative: slightly larger than Alaska
Land boundaries;
total: 5,440 km
border counfries; Afghanistan 936 km, Armenia 35
km. Azerbaijan-proper 432 km, Azerbaijan-Naxcivan
exclave 179 km, Iraq 1,458 km, Pakistan 909 km,
Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km
note: Iran also borders the Caspian Sea (740 km)
Maritime claims;
contiguous zone: 24 nm
continental shelf: natural prolongation
exclusive economic zone: bilateral agreements, or
median lines in the Persian Gulf
ferriforia/ sea; 1 2 nm
Climate: mostly arid or semiarid, subtropical along
Caspian coast
235
Iran (continued)
Terrain: rugged, mountainous rim; high, central
basin with deserts, mountains; small, discontinuous
plains aiong both coasts
Elevation extremes;
lowest point: Caspian Sea -28 m
highest point: QoWeh-ye Damavand 5,671 m
Natural resources; petroleum, natural gas, coal,
chromium, copper, iron ore, lead, manganese, zinc,
sulfur
Land use;
arable land: 10%
permanent crops: t%
permanent pastures: 27%
forests and woodland: 7%
of/ier;55%(1993 est.)
Irrigated land: 94,000 sq km (1993 est.)
Natural hazards: periodic droughts, floods; dust
storms, sandstorms; earthquakes along western
border and in the northeast
Environment ■ current issues: air pollution,
especially in urban areas, from vehicle emissions,
refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution
in the Persian Gulf; inadequate supplies of potable
water
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea, Marine Lite Conservation
I People
Population: 65,619,636 (July 2000 est.)
Age structure:
0-14 years: 34% (male 1 1 ,542,446; female
11,035,705)
15-64 years: 61% (male 20,151,083; female
19,879,432)
65 years and over: 5% (male 1 ,592,753; female
1,418,217) (2000 est.)
Population growth rate: 0.83% (2000 est.)
Birth rate: 1 8.29 births/1 ,000 population (2000 est.)
Death rate: 5.45 deaths/1,000 population
(2000 est.)
Net migration rate: -4.55 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 30.02 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 69.66 years
male: 68.34 years
female: 71 .05 years (2000 est.)
Total fertility rate: 2.2 children born/woman
(2000 est.)
Nationality;
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azeri 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur 2%, Baloch
2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 10%,
Zoroastrian, Jewish, Christian, and Baha''i 1%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 72. 1 %
male: 78.4%
female: 65.8% (1994 est.)
I ^ G over ri me n t
Country name:
conventional long form: Islamic Republic of Iran
conventional short form: Iran
local long form: Jomhuri-ye Esiami-ye Iran
local short form: Iran
Data code: IR
Government type; theocratic republic
Capital: Tehran
Administrative divisions; 28 provinces (ostanha,
singular - ostan); Ardabil, Azarbayjan-e Gharbi,
Azarbayjan-e Sharqi, Bushehr, Chahar Mahall va
Bakhtiari, Esfahan, Pars, Gilan, Golestan, Hamadan,
Hormozgan, Ham, Kerman, Kermanshahan,
Khorasan, Khuzestan, Kohkiluyeh va Buyer Ahmadi,
Kordestan, Lorestan, Markazi, Mazandaran, Com,
Qazvin, Semnan, Sistan va Baluchestan, Tehran,
Yazd, Zanjan
Independence: 1 April 1979 (Islamic Republic of
Iran proclaimed)
National holiday; Islamic Republic Day, 1 April
(1979)
Constitution: 2-3 December 1979; revised 1989 to
expand powers of the presidency and eliminate the
prime ministership
Legal system: the Constitution codifies Islamic
principles of government
Suffrage: 1 5 years of age; universal
Executive branch;
chief of state: Leader of the Islamic Revolution
Ayatollah All Hoseini-KHAMENEI (since 4 June 1989)
head of government: President (Ali) Mohammad
KHATAMI-Ardakani (since 3 August 1 997); First Vice
President Hasan Ebrahim HABIBI (since NA August
1989)
cabinet: Council of Ministers selected by the president
with legislative approval
elections: leader of the Islamic Revolution appointed
for life by the Assembly of Experts; president elected
by popular vote for a four-year term; election last held
23 May 1 997 (next to be held NA May 2001 )
election results: (Ali) Mohammad KHATAMI-Ardakani
elected president; percent of vote - (Ali) Mohammad
KHATAMI-Ardakani 69%
Legislative branch: unicameral Islamic
Consultative Assembly or Majles-e-Shura-ye-Eslami
(290 seats, note - changed from 270 seats with the 1 8
February 2000 election; members elected by popular
vote to serve four-year terms)
elections: last held 1 8 February-N A April 2000 (next to
be held NA 2004)
election results: percent of vote - NA; seats - NA;
note - reformers received 70% of the vote (1 70 seats),
the conservatives received 30% (45 seats), and
independents (10 seats); 65 seats were up for runoff
election in April 2000
Judicial branch: Supreme Court
Political parties and leaders: since President
KHATAMI''S election in May 1997, several political
parties have been licensed; Executives of
Construction; Followers of the Imam''s Line and the
Leader (consen/ative); Islamic Coalition Association
[Habibollah ASQAR-OLADI]; Islamic Iran Solidarity
Party; Islamic Partnership Front; Militant Clerics
Association [Ayatollah Mahdavi KANI]; Second
Khordad Front (pro-reform); Tehran Militant Clergy
Association [Secretary General Ayatollah Mohammad
EMAMI-KASHANI]
Political pressure groups and leaders: active
student groups include the pro-reform "Organization
for Strengthening Unity" and "the Union of Islamic
Student Societies''; groups that generally support the
Islamic Republic include Ansar-e Hizballah,
Mojahedin of the Islamic Revolution, Muslim Students
Following the Line of the Imam, and the Islamic
Coalition Association; opposition groups include the
Liberation Movement of Iran and the Nation of Iran
party; armed political groups that have been almost
completely repressed by the government include
Mojahedin-e Khalq Organization (MEK), People''s
Fedayeen, Democratic Party of Iranian Kurdistan; the
Society for the Defense of Freedom
International organization participation: CCC,
CP, ECO, ESCAP, FAO, G-19, G-24, G-77, IAEA,
IBRD, ICAO, ICC, ICRM, IDA, IDB, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC,
lOM (observer), ISO, ITU, NAM, OIC, OPCW, OPEC,
PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WCL, WFTU, WHO, WMO, WToO
Diplomatic representation in the US: none; note -
Iran has an Interests Section in the Pakistani
Embassy, headed by Faramarz FATH-NEJAD;
address: Iranian Interests Section, Pakistani
Embassy, 2209 Wisconsin Avenue NW, Washington,
DC 20007; telephone: [1] (202) 965-4990
Diplomatic representation from the US: none;
note - protecting power in Iran is Switzerland
Flag description: three equal horizontal bands of
green (top), white, and red; the national emblem (a
stylized representation of the word Allah) in red is
centered in the white band; ALLAH AKBAR (God is
Great) in white Arabic script is repeated 1 1 times
along the bottom edge of the green band and 1 1 times
along the top edge of the red band
236
Iran (continued)','e48f895a2b1b8d5cafee977260fb7feb8fad9b9af49e9201f8cf4fcd57effc57','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b8c9f8520031fc6be8bf8ca32443a0ded6c9d3fd7089f966f7ba9bd7d3b5325',2000,'KE','Kenya','introduction',267,'Background: Ethnic divisions account for many of
Kenya''s problems. During the early 1990s, tribal
clashes killed thousands and left tens of thousands
homeless. Ethnically split opposition groups allowed
the regime of Daniel Toroltich arap MCI, In power
since 1 978, to be reelected for a fourth term in 1 997 in
balloting marred by violence and fraud.','54435b8fc509d2296f5e98bc22703d76197bfbe34eef11b2cd3c8acd9dc591d7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad595797dff10923105cfa89b7bfb7c50002b40d07d7916f80765326bb9b0ec5',2000,'JP','Japan','introduction',274,'Background: Following World War II, Korea was
split into a northern, communist half and a southern.
Western-oriented half. KIM Chong-ll has ruled North
Korea since his father and the country''s founder,
president KIM ll-sung, died in 1994. After decades of
mismanagement, the North relies heavily on
international food aid to feed its population, while
continuing to expend resources to maintain an army of
over 1 million, the fifth largest in the world. North
Korea''s long-range missile development and research
into nuclear and chemical weapons are of major
concern to the international community.
I G e 0 g r a p h y
Location: Eastern Asia, northern half of the Korean
Peninsula bordering the Korea Bay and the Sea of
Japan, between China and South Korea
Geographic coordinates; 40 00 N, 127 00 E
Map references; Asia
Area:
total; 120,540 sq km
/and; 120,410 sq km
water: 130 sq km
Area - comparative; slightly smaller than
Mississippi
Land boundaries;
total: 1 ,673 km
border countries: China 1 ,41 6 km. South Korea 238
km, Russia 19 km
Coastline; 2,495 km
Maritime ciaims;
territorial sea: 12 m
exclusive economic zone: 200 nm
note: military boundary line 50 nm in the Sea of Japan
and the exclusive economic zone limit in the Yellow
Sea where all foreign vessels and aircraft without
permission are banned
Climate; temperate with rainfall concentrated in
summer
267
Korea, North (continued)
Terrain; mostly hills and mountains separated by
deep, narrow valleys; coastal plains wide in west,
discontinuous in east
Eievation extremes;
lowest point: Sea of Japan 0 m
highest point: Paektu-san 2,744 m
Naturai resources; coal, lead, tungsten, zinc,
graphite, magnesite, iron ore, copper, gold, pyrites,
salt, fluorspar, hydropower
Land use;
arable land: 14%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 61 %
of/7er;23% (1993 est.)
Irrigated land; 14,600 sq km (1993 est.)
Natural hazards; late spring droughts often followed
by severe flooding; occasional typhoons during the
early fall
Environment - current issues; localized air
pollution attributable to inadequate industrial controls;
water pollution; inadequate supplies of potable water
Environment - international agreements;
parly to; Antarctic Treaty, Biodiversity, Climate
Change, Environmental Modification, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Law of the Sea
Geography - note; strategic location bordering
China, South Korea, and Russia; mountainous interior
is isolated and sparsely populated
Background: Following World War II, a republic was
set up in the southern half of the Korean Peninsula
while a communist government was installed in the
north. Between 1950 and 1953, US and other UN
forces intervened to defend South Korea from North
Korean attacks supported by the Chinese; an
armistice was signed in 1953. Thereafter, South
Korea achieved amazing economic growth, with per
capita income rising to 13 times the level of North
Korea. In 1997, the nation suffered a severe financial
crisis from which it continues to make a solid recovery.
South Korea has also maintained its commitment to
democratize its political processes.','bd962e49a8ed9d532f97e58eb77639bc7e79538b44aa39201565b5f4c6cbf8d0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a9ebf51840545115d2bb195b2f22b0ee0c0298dbdf2361888f898a18084f959',2000,'CN','China','introduction',281,'Background: A Central Asian country of incredible
natural beauty and proud nomadic traditions,
Kyrgyzstan was annexed by Russia in 1864; it
achieved independence from the Soviet Union in
1991, Current concerns include: privatization of
state-owned enterprises, expansion of democracy
and political freedoms, inter-ethnic relations, and
Background; Much of this island has been
devastated and two-thirds of the population has fled
abroad due to the eruption of the Soufriere Hills
volcano that began on 18 July 1995.
I ~ "Geography
Location; Caribbean, island in the Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates; 16 45 N, 62 12 W
Map references: Central America and the
Caribbean
Area;
total: 100 sq km
/arrd.’IOOsqkm
water: 0 sq km
Area - comparative: about 0.6 times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 40 km
Maritime claims:
exclusive fishing zone: 200 nm
territoriai sea: 3 nm
Climate: tropical; little daily or seasonal temperature
variation
Terrain: volcanic islands, mostly mountainous, with
small coastal lowland
Elevation extremes:
iowest point: Caribbean Sea 0 m
highest point: Chances Peak (in the Soufriere Hills)
914 m
Natural resources: NEGL
Land use;
arable land: 20%
permanent crops: 0%
permanent pastures: 10%
forests and woodland: 40%
of/ier;30%(1993est.)
Irrigated land; NAsqkm
337
Montserrat (continued)
Natural hazards; severe hurricanes (June to
November); volcanic eruptions (full-scale eruptions of
the Soufriere Hills volcano occurred during 1996-97)
Environment - current issues: land erosion occurs
on slopes that have been cleared for cultivation','eb47d6ade16dd0975308772879ff78eb030acfd18a3b5c469531b924c599f405','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5a5d3f70b228752045fe5e1946f34eaf67f9353404ecf6baca5794ff6e6b483',2000,'LI','Liechtenstein','introduction',296,'Background: The Principality of Liechtenstein was
established within the Holy Roman Empire in 1719; it
became a sovereign state in 1806. Until the end of
World War I, it was closely tied to Austria, but the
economic devastation caused by that conflict forced
Liechtenstein to conclude a customs and monetary
union with Switzerland. Since World War II (in which
Liechtenstein remained neutral) the country''s low
taxes have spurred outstanding economic grovrth.','0f21fdf54509fd5232740fcf1d70d5289f0ca941d28772b4f41b8eab97475812','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69cfa8c99f218f3a2168d25ac7859035a4c35d2d36e3729940c98cdad966722b',2000,'MV','Maldives','introduction',313,'Background: The Maldives were long a sultanate,
first under Dutch and then under British protection.
They became a republic in 1968, three years after
independence. Tourism and fishing are being
developed on the archipelago.
I CTe^graphy
Location: Southern Asia, group of atolls in the Indian
Ocean, south-southwest of India
Geographic coordinates; 3 15 N, 73 00 E
Map references; Asia
Area;
total: 300 sq km
land: 300 sq km
water: 0 sq km
Area - comparative: about 1 .7 times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 644 km
Maritime claims: measured from claimed
archipelagic baselines
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, humid; dry, northeast
monsoon (November to March); rainy, southwest
monsoon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Wilingili island in
the Addu Atoll 2.4 m
Natural resources; fish
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 3%
other: 84% (1993 est.)
308
fJld\\6\\\\IQS (continued)
Irrigated land: NA sq km
Natural hazards: low level of Islands makes them
very sensitive to sea level rise
Environment - current issues: depletion of
freshwater aquifers threatens water supplies; global
warming and sea level rise; coral reef bleaching
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Hazardous Wastes, Ozone
Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: 1 ,1 90 coral islands grouped into
26 atolls (200 inhabited islands, plus 80 islands with
tourist resorts); archipelago of strategic location
astride and along major sea lanes in Indian Ocean
p e 0 pT e ~ "
Population: 301,475 (July 2000 est.)
Age structure:
0-14 years: A6% (male 71,273; female 67,323)
15-64 years: 51% (male 78,598; female 75,331)
65 years and over: 3% (male 4,666; female 4,284)
(2000 est.)
Population growth rate: 3.06% (2000 est.)
Birth rate: 38.96 births/1 ,000 population (2000 est.)
Death rate: 8.32 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .04 male(s)/temale
65 years and over: 1 .09 male(s)/female
total population: 1 .05 male(s)/female (2000 est.)
Infant mortality rate: 65.52 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 62.2 years
male: 61 .05 years
female: 63.4 years (2000 est.)
Total fertility rate: 5.62 children born/woman
(2000 est.)
Nationality:
noun: Maldivian(s)
adjective: Maldivian
Ethnic groups: South Indians, Sinhalese, Arabs
Religions: Sunni Muslim
Languages: Maldivian Dhivehi (dialect of SInhala,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition: age 15 and over can read and write
total population: 93.2%
male: 93.3%
fema/e; 93% (1995 est.)
I Governmenl
Country name:
conventional long form: Republic of Maldives
conventional short form: Maldives
local long form: Dhivehi Raajjeyge Jumhooriyyaa
local short form: Dhivehi Raajje
Data code: MV
Government type: republic
Capital: Male
Administrative divisions: 19 atolls (atholhu,
singular and plural) and 1 other first-order
administrative division*; Alifu, Baa, Dhaalu, Faafu,
Gaafu Alifu, Gaafu Dhaalu, Gnaviyani, Haa Alifu, Haa
Dhaalu, Kaafu, Laamu, Lhaviyani, Maale*, Meemu,
Noonu, Raa, Seenu, Shaviyani, Thaa, Vaavu
Independence: 26 July 1965 (from UK)
National holiday: Independence Day, 26 July
(1965)
Constitution: adopted January 1998
Legal system: based on Islamic law with admixtures
of English common law primarily in commercial
matters; has not accepted compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state: President Maumoon Abdul GAYOOM
(since 1 1 November 1978); note - the president is
both the chief of state and head of government
head of government: President Maumoon Abdul
GAYOOM (since 11 November 1978); note - the
president is both the chief of state and head of','6f4993c6ef077e19f98ba53629fb25cecd4eeacba69412278870737054abc45a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cc083cc886becdb8a676052ef2e401f6047321d9114bb2d268ae3db1609452d',2000,'MH','Marshall Islands','introduction',321,'Background: After almost four decades under US
administration as the easternmost part of the U N Trust
Territory of the Pacific Islands, the Marshall Islands
attained independence in 1986 under a Compact of
Free Association. Compensation claims continue as a
result of US nuclear testing on some of the islands
between 1947 and 1962.','19536125d34b8e7b97589d567bc444c12320c8e975aedd0c36bb96701d6f31b1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d40517deb2c3f6636306da708c5e20be51d42ca600f3c75f76909d954b95e90f',2000,'MR','Mauritania','introduction',333,'Background: Discovered by the Portuguese in
1 505, Mauritius was subsequently held by the Dutch,
French, and British before independence was attained
in 1 968. A stable democracy with regular free
elections and a positive human rights record, the
country has attracted considerable foreign investment
and has earned one of Africa''s highest per capita
incomes. Recent protests over standards of living in
the Creole community have slowed economic growth.
Background: Serbia and Montenegro have asserted
the formation of a joint independent state, but this
entity has not been formaliy recognized as a state by
the US. The US view is that the Sociaiist Federal
Republic of Yugoslavia (SFRY) has dissolved and that
none of the successor republics represents its
continuation. In 1 999, massive expulsions by Serbs of
ethnic Albanians living in the autonomous republic of
Kosovo provoked an international response, including
the bombing of Serbia and the stationing of NATO and
Russian peacekeepers in Kosovo.','417b7ca135b7dceb88b47b84702d1cb34ebdf93ceb9806797c5aae3e768e0cd8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e8b4097521406822d3941f13546a064693e3394e3fd20e354ed339d6c34bba5',2000,'NL','Netherlands','introduction',359,'Background: Settled by both Britain and France
during the first haif of the 1 9th century, the island was
made a French possession in 1853. It served as a
penal colony for four decades after 1 864. Agitation for
independence during the 1980s and early 1990s
seems to have dissipated.
I Geography
Location: Oceania, islands in the South Pacific
Ocean, east of Australia
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
fofa/; 19,060 sq km
/and; 18,575 sq km
water: 485 sq km
Area - comparative: slightly smaller than New','3e3dbf12358e98ef728c6316f381156c44fac5a1b0bf43c811a4d5c0897102e7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab62f70dbce4e73172ff3998d7a4105ed1e0f281afe4430a1e13332df1e34eda',2000,'JE','Jersey','introduction',360,'Land boundaries: 0 km
Coastiine: 2,254 km
Maritime ciaims:
exclusive economic zone: 200 nm
femfor/a/sea;12nm
Ciimate: tropical; modified by southeast trade winds;
hot, humid
Terrain: coastal plains with interior mountains
Eievation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1 ,628 m
Natural resources: nickel, chrome, iron, cobalt,
manganese, silver, gold, lead, copper
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 2%
forests and woodland: 39%
often 49% (1993 est.)
Irrigated land: 160 sq km (1991)
Natural hazards: cyclones, most frequent from
November to March
Environment - current issues: erosion caused by
mining exploitation and forest fires
I People
Population: 201 ,816 (July 2000 est.)
Age structure:
0- 14 years: 31 % (male 31 ,396; female 30, 1 60)
15-64 years: 64% (male 65,042; female 63,961 )
65 years and over: 5% (male 5,324; female 5,933)
(2000 est.)
Population growth rate: 1.52% (2000 est.)
Birth rate: 20.84 births/1 ,000 population (2000 est.)
Death rate: 5.62 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 8.57 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 72.77 years
male: 69.84 years
female: 75.85 years (2000 est.)
Total fertility rate: 2.52 children born/woman
(2000 est.)
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1 .6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French (official), 33
Melanesian-Polynesian dialects
Literacy:
definition: age 15 and over can read and write
total population: 91%
male: 92%
female: 90% (1976 est.)
I Government
Country name:
conventional long fomr; Territory of New Caledonia
and Dependencies
conventional short form: New Caledonia
local long form: Territoire des Nouvelle-Caledonie et
Dependances
local short form: Nouvelle-Caledonie
Data code: NC
Dependency status: overseas territory of France
since 1956
Government type: NA
Capital: Noumea
Administrative divisions: none (overseas territory
of France); there are no first-order administrative
divisions as defined by the US Government, but there
are 3 provinces named lies Loyaute, Nord, and Sud
independence: none (overseas territory of France);
note - a referendum on independence was held in
1998 but did not pass
National holiday: National Day, Taking of the
Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: the 1988 Matignon Accords grant
substantial autonomy to the islands; formerly under
French law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President of France Jacques CHIRAC
(since 17 May 1995), represented by High
Commissioner Thierry LATASTE (since 19 July 1999)
head of government: President of the Government
Jean LEQUES (since 28 May 1999)
cabinet: Consultative Committee
elections: French president elected by popular vote
for a seven-year term; high commissioner appointed
by the French president on the advice of the French
Ministry of Interior; president of the government
elected by the members of the Territorial Congress
Legislative branch: unicameralTerritorial Congress
or Congres Territorial (54 seats; members are
members of the three Provincial Assemblies or
Assemblees Provinciales elected by popular vote to
serve five-year terms)
elections: last held 9 May 1999 (next to be held NA
2004)
election results: percent of vote by party - NA; seats
by party - RPCR 24, FLNKS 12, UNI 6, FCCI 4, FN 4,
Alliance pour la Caledonie 3, LKS 1
note: New Caledonia elects 1 seat to the French
Senate; elections last held 27 September 1992 (next
to be held NA September 2001); results - percent of
vote by party - NA; seats by party - RPR 1 ; New
Caledonia also elects 2 seats to the French National
Assembly; elections last held 25 May-1 June 1997
(next to be held NA 2002); results - percent of vote by
party - NA; seats by party - RPR 2
Judicial branch: Court of Appeal or Cour d''Appel;
County Courts; Joint Commerce Tribunal Court;
Children''s Court
Political parties and ieaders: Alliance pour la
Caledonie [Didier LEROUX]; Developper Ensemble
pour Construire I''Avenir or DEPCA [Robert FROUIN];
Federation des Comites de Coordination des
Independantistes or FCCI [Raphael MAPOU]; Front
Uni de Liberation Kanak or FULK [Ernest UNE];
Groups de I''Alliance Multiraciale or GAM [Dany
DALMAYRAE]; Independance et Progres [Alphonse
PUJAPUJANE]; Kanak Socialist Front for National
Liberation or FLNKS [Rock WAMYTAN] (includes
PALIKA, UNI, UC, UPM); La Caledonie Autrement
[Denis MILLIARD]; Loyalty Islands Development
Front or FDIL [Cono HAMU]; National Front or FN
[Guy GEORGE); Parti de Liberation Kanak or PALIKA
[Charles WASHETINE); Rally for Caledonia in the
Republic or RPCR [Jacques LAFLEUR); Renouveau
356
New Caledonia (continued)
[Thierry VALET]; Socialist Kanak Liberation or LKS
[Nidoish NAISSELINEj; Union Caledonienne or UC
[Bernard LEPEUj; Union Nationals pour
ITndependance or UNI [Paul NEAOUTYINEj; Union
Progressists Melanesienne or UPM [Andre GOPEA]
International organization participation: ESCAP
(associate), FZ, ICFTU, SPC, WFTU, WMO
Diplomatic representation in the US; none
(overseas territory of France)
Diplomatic representation from the US; none
(overseas territory of France)
Flag description; the flag of France is used
'' Icon 6 m y
Economy - overview: New Caledonia has more
than 20% of the world''s known nickel resources. In
recent years, the economy has suffered because of
depressed international demand for nickel, the
principal source of export earnings. Only a negligible
amount of the land is suitable for cultivation, and food
accounts for about 20% of imports. In addition to
nickel, the substantial financial support from France
and tourism are keys to the health of the economy.
The situation in 1998 was clouded by the spillover of
financial problems In East Asia and by lower prices for
nickel. Nickel prices jumped in 1999, and large
additions were made to capacity.
GDP: purchasing power parity - $3 billion (1998 est.)
GDP - real growth rate: 3.5% (1998 est.)
GDP - per capita: purchasing power parity -
$15,000 (1998 est.)
GDP ■ composition by sector;
agriculture: 4%
industry: 30%
services: 66% (1997 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .5% (1998 est.)
Labor force: 79,395 (including 1 5, 01 8 unemployed,
1996)
Labor force - by occupation; agriculture 7%,
industry 23%, services 70% (1999 est.)
Unemployment rate: 15% (1994)
Budget;
revenues: $B01. 3 million
expenditures: $735.3 million, including capital
expenditures of $52 million (1996 est.)
Industries; nickel mining and smelting
Industrial production growth rate; NA%
Electricity - production; 1 .52 billion kWh (1 998)
Electricity - production by source:
fossil fuel: 65.79%
hydro:34.21%
nuclear: 0%
other: 0P/o{im)
Electricity - consumption; 1.41 4 billion kWh (1998)
Electricity ■ exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products; vegetables; beef, deer,
other livestock products
Exports; $381 million (f.o.b., 1998)
Exports - commodities: ferronickels, nickel ore, fish
Exports - partners: Japan 36%, France 30%, US
14%, Taiwan 9%, Australia 7% (1997)
Imports: $922 million (c.i.f., 1998)
Imports - commodities: foods, machinery and
equipment, fuels, minerals
Imports - partners: France 41%, Australia 13%,
New Zealand 7%, Japan 5% (1998)
Debt - external: $79 million (1998 est.)
Economic aid - recipient: $770 million from France
(1998)
Currency: 1 Comptoirs Francais du Pacifique franc
(CFPF) = 100 centimes
Exchange rates: Comptoirs Francais du Pacifique
francs (CFPF) per US$1 - 117.67 (January 2000),
111.93 (1999), 107.25 (1998), 106.11 (1997), 93.00
(1996), 90.75 (1995); note - linked at the rate of 18.18
to the French franc
Fiscal year: calendar year
I Communications
Telephones • main lines in use: 44,000 (1995)
Telephones - mobile cellular: 825 (1995)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1, FM 5, shortwave
0(1998)
Radios: 107,000(1997)
Television broadcast stations: 6 (plus 25
low-power repeaters) (1997)
Televisions: 52,000(1997)
Internet Service Providers (ISPs); 1 (1999)
I transport af j "
Railways: 0 km
Highways;
total: 5,562 km
paved: 975 km
unpaved: 4,587 km (1993)
Ports and harbors: Mueo, Noumea, Thio
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 1 ,261 GRT/
1,600 DWT
ships by type: cargo 1 (1999 est.)
Airports; 28 (1999 est.)
Airports - with paved runways;
total: 5
over 3,047 m:1
91410 1,523 m: 3
under 914 m:1 (1999 est.)
Airports - with unpaved runways;
total: 23
914 to 1,523 m: 12
under 914 m: 1 1 (1 999 est.)
Heliports: 6 (1999 est.)
I; Military
Military branches: French Armed Forces (Army,
Navy, Air Force, Gendarmerie); Police Force
Military expenditures - dollar figure: $1 92.3
million (1996)
Military expenditures - percent of GDP: 5.3%
(1996)
Military - note: defense is the responsibility of
Background: Switzerland''s independence and
neutrality have long been honored by the major
European powers and Switzerland was not involved in
either of the two World Wars. The political and
economic integration of Europe over the past half
century, as well as Switzerland''s role in many UN and
international organizations, may be rendering
obsolete the country''s concern for neutrality.','6eb7e1811cd5d8179f0a7a1d76ed4dc37edca84127d63453347456027bc2a27a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f8f7557347daf82d414ce11c64c8ecbebe52400d61d7fd1f0067148720abbc',2000,'FR','France','introduction',361,'P T r an s n a 1 1 on a I I s s u e s
Disputes ■ international: Matthew and Hunter
Islands claimed by France and Vanuatu
357
Background: Following independence from France
in 1956, President Habib BOURGiUBA estabiished a
strict one-party state. He dominated the country for 31
years, repressing islamic fundamentaiism and
estabiishing rights for women unmatched by any other
Arab nation. In recent years, Tunisia has taken a
moderate, non-aiigned stance in its foreign relations.
Domesticaliy, it has sought to diffuse rising pressure
for a more open political society.
1 Geography
Location: Northern Africa, bordering the
Mediterranean Sea, between Aigeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
fofa/; 163,610 sq km
/arrd; 155,360 sq km
water: 8,250 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
total: 1 ,424 km
border counfr/es; Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
contiguous zone: 24 nm
territorial sea: t2nm
Climate: temperate in north with mild, rainy winters
and hot, dry summers; desert in south
Terrain: mountains in north; hot, dry central plain;
semiarid south merges into the Sahara
Elevation extremes:
lowest point: Shaft al Gharsah -17 m
highest point: Jaba\\ ash Shanabi 1,544 m
Natural resources: petroleum, phosphates, iron
ore, lead, zinc, salt, arable land
Land use:
arable land: t9%
permanent crops: 13%
permanent pastures: 20%
forests and woodland: 4%
ofber;44%(1993est.)
Irrigated land: 3,850 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: toxic and
hazardous waste disposal is ineffective and presents
human health risks; water pollution from raw sewage;
limited natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Consenration
Geography ■ note: strategic location in central
Mediterranean
I People
Population: 9,593,402 (July 2000 est.)
Age structure:
0-14 years: 30% (male 1 ,469,048; female 1 ,375,782)
15-64 years: 64% (male 3,080,631 ; female
3,089,244)
65 years and over: 6% (male 290,388; female
288,309) (2000 est.)
Population growth rate: 1.17% (2000 est.)
Birth rate: 1 7.38 births/1 ,000 population (2000 est.)
Death rate: 4.98 deaths/1,000 population
(2000 est.)
Net migration rate: -0.7 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1. OB male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1.02 male(s)Aemale (2000 est.)
Infant mortality rate: 30.09 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73.69 years
ma/e; 72.14 years
female: 75.36 years (2000 est.)
Total fertility rate: 2.04 children born/woman
(2000 est.)
Nationality:
rrourr; Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1%
Religions: Muslim 98%, Christian 1%, Jewish and
other 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
Literacy:
definition: age 15 and over can read and write
total population: 66.7%
male: 78.6%
female: 54.6% (1 995 est.)
I '' G 0 V eFn me n t
Country name:
conventional long form: Republic of Tunisia
conventional short form: Tunisia
local long form: Al Jumhuriyah at Tunisiyah
/oca/ short form; Tunis
Data code: TS
Government type: republic
Capital: Tunis
Administrative divisions: 23 governorates; Al Kaf,
Al Mahdiyah, Al Munastir, Al Qasrayn, Al Qayrawan,
Atyanah, Bajah, Banzart, Bin ''Arus, Jundubah,
Madanin, Nabul, Qabis, Qafsah, Qibili, Safaqis, Sidi
Bu Zayd, Silyanah, Susah, Tatawin, Tawzar, Tunis,
Zaghwan
Independence: 20 March 1956 (from France)
National holiday: National Day, 20 March (1956)
Constitution: 1 June 1959; amended 12 July 1988
Legal system: based on French civil law system and
Islamic law; some judicial review of legislative acts in
the Supreme Court in joint session
Suffrage: 20 years of age; universal
Executive branch:
chief of state: President Zine El Abidine BEN ALI
(since 7 November 1987)
head of government: Prime Minister Hamed KAROUl
(since NA November 1999)
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
five-year term; election last held 24 October 1 999
(next to be held NA 2004); prime minister appointed
by the president
election results: President Zine El Abidine BEN ALI
reelected for a third term without opposition; percent
of vote - Zine El Abidine BEN ALI nearly 100%
Legislative branch: unicameral Chamber of
Deputies or Majlis al-Nuwaab (163 seats; members
elected by popular vote to serve five-year terms)
elections: last held NA October 1 999 (next to be held
NA2004)
election results: percent of vote by party - NA; seats
by party - NA; note - the government changed the
electoral code to guarantee that the opposition won
seats
Tunisia (continued)
Judicial branch; Court of Cassation (Cour de
Cassation)
Political parties and leaders: Constitutional
Democratic Rally Party or RCD [President BEN All
(official ruling party)]; Movement of Democratic
Socialists or MDS [leader NAj; five other political
parties are legal, including the Communist Party
Political pressure groups and leaders: the Islamic
fundamentalist party, Al Nahda (Renaissance), is
outlawed
International organization participation; ABEDA,
ACCT, AfDB, AFESD, AL, AMF, AMU, BSEC
(observer), CCC, ECA, FAO, G-77, IAEA, IBRD,
ICAO, ICC, ICFTU, ICRM, IDA, IDB, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, lOM, ISO, ITU, MIPONUH, NAM, OAS
(observer), OAU, OIC, OPCW, OSCE (partner), UN,
UN Security Council (temporary), UNCTAD,
UNESCO, UNHCR, UNIDO, UNMIBH, UNMIK, UPU,
WFU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Noureddine MEJDOUB
chancery: 1515 Massachusetts Avenue NW,
Washington, DC 20005
telephone: m (202) 862-1850
Diplomatic representation from the US;
chief of mission: Ambassador Robin L. RAPHEL
embassy: 144 Avenue de la Liberte, 1002
Tunis-Belvedere
mailing address: use embassy street address
fe/eptone; [2161(1)782-566
FAX; [21 61(1)789-719
Flag description: red with a white disk in the center
bearing a red crescent nearly encircling a red
five-pointed star; the crescent and star are traditional
symbols of Islam
1 Economy
Economy - overview: Tunisia has a diverse
economy, with important agricultural, mining, energy,
tourism, and manufacturing sectors. Governmental
control of economic affairs while still heavy has
gradually lessened over the past decade with
increasing privatization, simplification of the tax
structure, and a prudent approach to debt. Real
growth averaged 5.0% in the 1990s, and inflation is
slowing. Growth in tourism and increased trade have
been key elements in this steady growth. Tunisia''s
association agreement with the European Union
entered into force on 1 March 1998, the first such
accord between the EU and Mediterranean countries
to be activated. Under the agreement Tunisia will
gradually remove barriers to trade with the EU over
the next decade. Broader privatization, further
liberalization of the investment code to increase
foreign investment, and improvements in government
efficiency are among the challenges for the future.
GDP; purchasing power parity - $52.6 billion
(1999 est.)
GDP - real growth rate: 6% (1999 est.)
GDP - per capita: purchasing power parity - $5,500
(1999 est.)
GDP - composition by sector:
agriculture: 12%
industry: 28%
services: 60% (1998 est.)
Population below poverty line: 14.1% (1990 est.)
Household income or consumption by percentage
share:
lowest 10%: 2.3%
highest f0%; 30.7% (1990)
Inflation rate (consumer prices): 2.7% (1999 est.)
Labor force: 3 million (1997 est.)
note: shortage of skilled labor
Labor force - by occupation; services 55%,
industry 23%, agriculture 22% (1995 est.)
Unemployment rate: 16.5% (1999 est.)
Budget:
revenues; $5.1 billion
expenditures: $5.8 billion, including capital
expenditures to $1.6 billion (1999 est.)
Industries: petroleum, mining (particularly
phosphate and iron ore), tourism, textiles, footwear,
food, beverages
Industrial production growth rate; 8% (1998 est.)
Electricity - production: 7.94 billion kWh (1998)
Electricity - production by source:
fossil fuel: 99.5%
hydro: 0.5%
nuclear: 0%
other; 0% (1998)
Electricity ■ consumption: 7.549 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity • imports: 165 million kWh (1998)
Agriculture - products: olives, grain, dairy
products, tomatoes, citrus fruit, beef, sugar beets,
dates, almonds
Exports: $5.8 billion (f.o.b., 1999 est.)
Exports - commodities: textiles, mechanical
goods, phosphates and chemicals, agricultural
products, hydrocarbons
Exports - partners: France 27%, Italy 22%,
Germany 15%, Belgium 6%, Libya 4% (1998)
Imports: $8.3 billion (c.i.f., 1999 est.)
Imports - commodities: machinery and equipment,
hydrocarbons, chemicals, fuel, food
Imports - partners: France 27%, Italy 20%,
Germany 12%, Spain 4%, Belgium 4%, US 4% (1 998)
Debt - external: $12.1 billion (1999 est.)
Economic aid - recipient: $933.2 million (1995);
note - ODA, $90 million (1998 est.)
Currency; 1 Tunisian dinar (TD) = 1 ,000 miiiimes
Exchange rates: Tunisian dinars (TD) per US$1 -
1.2455 (January 2000), 1.2546 (December 1999),
1.1387 (1998), 1.1059 (1997), 0.9734 (1996), 0.9458
(1995)
Fiscal year: calendar year','a7d86692a2d10939e9ef82c8a7f6bbc60b199f92eda5be2041f6d8db13142b4e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5840534de6e92ad8f27c0ea5ec7defa3ff839c9ecdae9cd43b0c715dd77b96f3',2000,'NZ','New Zealand','introduction',362,'Background: The British colony of New Zealand
became an independent dominion in 1907 and
supported the UK miiitariiy in both Worid Wars. New
Zealand withdrew from a number of defense aiiiances
during the 1970s and 1980s. in recent years the
government has sought to address iongstanding
native Maori grievances.
Background: Not until 1993, 33 years after
independence from France, did Niger hold its first free
and open elections. A 1995 peace accord ended a
five-year Tuareg insurgency in the north. Coups in
1 996 and 1 999 were followed by the creation of a
National Reconciliation Council that effected a
transition to civilian rule in December 1 999.
I Geography
Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1 .267 million sq km
/and; 1,266,700 sq km
water: 300 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,697 km
border cour)trles: Algeria 956 km, Benin 266 km,
Burkina Faso 628 km, Chad 1 ,175 km, Libya 354 km,
Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in
extreme south
Terrain: predominately desert plains and sand
dunes; flat to rolling plains in south; hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Greboun 1 ,944 m
Natural resources: uranium, coal, iron ore, tin,
phosphates, gold, petroleum
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 7%
forests and woodland: 2%
other: 88% (1993 est.)
Irrigated land: 660 sq km (1993 est.)
Natural hazards: recurring droughts
Environment - current issues: overgrazing; soil
erosion; deforestation; desertification; wildlife
populations (such as elephant, hippopotamus, giraffe,
and lion) threatened because of poaching and habitat
destruction
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Law of the Sea
Geography - note: landlocked
f People
Population: 10,075,511 (July 2000 est.)
Age structure:
0-14 years: 48% (male 2,461 ,391 ; female 2,373,617)
15-64 years: 50% (male 2,445,369; female
2,563,839)
65 years and over: 2% (male 1 21 ,570; female
109,725) (2000 est.)
Population growth rate: 2.75% (2000 est.)
Birth rate: 51 .45 births/1 ,000 population (2000 est.)
Death rate: 23.17 deaths/1,000 population
(2000 est.)
Net migration rate: -0.75 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1.03 male(s)/fema!e
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1.11 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 1 24.9 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 41 .27 years
male: 41 .43 years
female: 41.11 years (2000 est.)
Total fertility rate: 7.16 children born/woman
(2000 est.)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christians
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 13.6%
maie: 20.9%
fema/e; 6.6% (1995 est.)
I Government
Country name:
conventional long form: Republic of Niger
conventional short form: Niger
local long form: Republique du Niger
local short form: Niger
Data code: NG
Government type: republic
Capital: Niamey
Administrative divisions: 7 departments
(departements, singular - departement), and 1 capital
district* (capitals district); Agadez, Diffa, Dosso,
Maradi, Niamey*, Tahoua, Tillaberi, Zinder
Independence: 3 August 1960 (from France)
National holiday: Republic Day, 18 December
(1958)
Constitution: the constitution of January 1993 was
revised by national referendum on 12 May 1996 and
again by referendum on 18 Juiy 1999
Legal system : based on French civil law system and
customary law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Mamadou TANDJA (since 22
December 1999); note - the president is both chief of
state and head of government
head of government: President Mamadou TANDJA
(since 22 December 1999); note - the president is
both chief of state and head of government; Prime
Minister Hama AMADOU (since 31 December 1999)
was appointed by the president and shares some
executive responsibilities with the president
note: President Ibrahim BARE was assassinated on 9
April 1999; subsequent elections held under the
nine-month provisional government of Major Daouda
Mallam WANKE
cabinet: 24-member cabinet appointed by President
TANDJA
elections: president elected by popular vote for a
five-yearterm; last held 24 November 1999 (next to be
held NA 2004)
eiection resuits: Mamadou TANDJA elected
president; percent of vote - Mamadou TANDJA 60%,
Mahamadou ISSOUFOU 40%
Legislative branch: unicameral National Assembly
(83 seats, members elected by popular vote for
five-year terms)
eiections: last held 24 November 1999 (next to be
held NA2004)
eiection results: percent of vote by party - NA; seats
by party - MNSD-Nassara 38, CDS-Rahama 17,
PNDS-Tarayya 16, RDP-Jama''a 8, ANDPS-Zaman
Lahia 4
Judicial branch: State Court or Courd''Etat; Court of
Appeal or Cour d''Appel
Political parties and leaders: Democratic Rally of
the People-Jama''a or RDP-Jama''a [Hamid
ALGABiDj; Democratic and Social
Convention-Rahama or CDS-Rahama [Mahamane
363
Nigor (continued)
OUSMANE]; Movement for Development and
Progress-Allwali or MDP-Alkwali [Mai Manga
BOUCAR, chairman]; National Movement for a
Developing Society-Nassara or MNSD-Nassara
[Tandja MAMADOU, chairman]; National Union of
Independents for Democratic Renewal or UNIRD
[Moutari MOUSSA]; Nigerien Alliance for Democracy
and Social Progress-Zaman Lahiya or
ANDPS-Zaman Lahiya [Moumouni Adamou
DJERMAKOYE]; Nigerien Democratic Front-Mutunci
or FDN-Mutunci [Ide OUMAROU]; Nigerien Party for
Democracy and Socialism-Tarayya or PNDS-Tarayya
[Mahamadou ISSOUFOU]; Nigerien Social Democrat
Party-Alheri or PSDN-Alheri [Malam Adji WAZIRI];
Party for People''s Dignity-Daraja or PDP-Daraja [Ali
TALBA, chairman]; Union of Democratic Patriots and
Progressives-Chamoua or UPDP-Chamoua
[Professor Andre'' SALIFOU, chairman]; Union for
Democracy and Social Progress-Amana or
UDPS-Amana [Mohamed ABDULLAHI]; Union of
Popular Forces for Democracy and Progress-Sawaba
or UFPDP-Sawaba [Djibo BAKARY]; Workers''
Movement Party-Albarka or PMT-Albarka [Omar Idi
ANGO]
International organization participation: ACCT,
ACP, AfDB, CCC, EGA, ECOWAS, Entente, FAO, FZ,
G-77, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IDB,
IFAD, IFC, IFRCS, ILO, IMF, Intelsat, Interpol, IOC,
ITU, MIPONUH, NAM, OAU, OIC, OPCW, UN,
UNCTAD, UNESCO, UNIDO, UPU, WADB, WAEMU,
WCL, WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US;
chief of mission: Ambassador Joseph DIATTA
chancery: 2204 R Street NW, Washington, DC 20008
telephone: [1] (202) 483-4224 through 4227
Diplomatic representation from the US:
chief of mission: Ambassador Barbro
OWENS-KIRKPATRICK
embassy: Rue Des Ambassades, Niamey
mailing address: B. P. 11201, Niamey
telephone: [227] 72 26 61 through 72 26 64
FAY; [227] 73 31 67
Flag description: three equal horizontal bands of
orange (top), white, and green with a small orange
disk (representing the sun) centered in the white band;
similar to the flag of India, which has a blue spoked
wheel centered in the white band','df4d72b1d629d703b1543517c1133d95f7fd18da5dd74f6e94f18ae2ea7f0512','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c05623ee68faf9032862ea1dac4a09fb56d6365f7426f8789cc6afcb90675ec0',2000,'NO','Norway','introduction',373,'3.1%, precision production 13.8%, operators,
fabricators 26.9%
Unemployment rate: 14% (residents)
Budget:
revenues: $221 million
expenditures: $213 million, including capital
expenditures of $17.7 million (1996)
Industries: tourism, construction, garments,
handicrafts
Industrial production growth rate: NA%
Electricity - production: NA kWh
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%
Electricity - consumption: NA kWh
Electricity - exports: NA kWh
Electricity - imports: NA kWh
Agriculture - products: coconuts, fruits,
vegetables; cattle
Exports: $1 billion (1998)
Exports - commodities: garments
Exports - partners: US
Imports: $NA
Imports - commodities: food, construction
equipment and materials, petroleum products
Imports - partners: US, Japan
Debt - external: $NA
Economic aid - recipient: $21.1 million (1995)
Currency: 1 United States dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October - 30 September
I Communications
Telephones - main lines in use: 15,000 (1995)
Telephones ■ mobile cellular: 1 ,200 (1 995)
Telephone system:
domestic: NA
international: satellite earth stations - 2 Intelsat
(Pacific Ocean)
Radio broadcast stations: AM 2, FM 3, shortwave
1 (1998)
Radios: NA
Television broadcast stations: 1 (on Saipan and
one station planned for Rota; in addition, two cable
services on Saipan provide varied programming from
satellite networks) (1997)
Televisions: NA
Internet Service Providers (ISPs): NA
I Transportation
Railways: 0 km
Highways:
total: 362 km (1991 est.)
paved: NA km
unpaved: NA km
Waterways: none
Ports and harbors: Saipan, Tinian
Merchant marine: none (1999 est.)
Airports: 6 (1999 est.)
Background: Despite its neutrality, Norway was not
able to avoid occupation by Germany in World War II.
In 1949, neutrality was abandoned and Norway
became a member of NATO. Discovery of oil and gas
in adjacent waters in the late 1 960s boosted Norway''s
economic fortunes. The current focus is on containing
spending on the extensive welfare system and
planning for the time when petroleum reserves are
depleted. In referenda held in 1972 and 1994, Norway
rejected joining the EU.
r . " '' G e o grayiTf
Location: Northern Europe, bordering the North Sea
and the North Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total: 324,220 sq km
land: 307,860 sq km
wafer; 16,360 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
fofa/;2,515km
border countries: Finland 729 km, Sweden 1,619 km,
Russia 167 km
Coastline: 21,925 km (includes mainland 3,419 km,
large islands 2,413 km, long fjords, numerous small
islands, and minor indentations 16,093 km)
Maritime claims:
contiguous zone: 1 0 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: temperate along coast, modified by North
Atlantic Current; colder interior; rainy year-round on
west coast
Terrain: glaciated; mostly high plateaus and rugged
mountains broken by fertile valleys; small, scattered
plains; coastline deeply indented by fjords; arctic
tundra in north
372
Norway (continued)
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Galdhopiggeh 2,469 m
Natural resources: petroleum, copper, natural gas,
pyrites, nickel, iron ore, zinc, lead, fish, timber,
hydropower
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 27%
other; 70% (1993 est.)
Irrigated land: 970 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution; acid
rain damaging forests and adversely affecting lakes,
threatening fish stocks; air pollution from vehicle
emissions
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: about two-thirds mountains;
some 50,000 islands off its much indented coastline;
strategic location adjacent to sea lanes and air routes
in North Atlantic; one of most rugged and longest
coastlines in world; Norway is the only NATO member
having a land boundary with Russia
f ~ P e 0 pi e
Population: 4,481,162 (July 2000 est.)
Age structure:
0-14 years: 20% (male 459,608; female 434,809)
15-64 years: 65% (male 1,472,974; female
1,430,526)
65 years and over: 1 5% (male 283,741 ; female
399,504) (2000 est.)
Population growth rate: 0.5% (2000 est.)
Birth rate: 12.79 bir1hs/1 ,000 population (2000 est.)
Death rate: 9.89 deaths/1 ,000 population
(2000 est.)
Net migration rate: 2. 1 3 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.06 male(s)/femate
under 15 years: 1.06 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over. 0.71 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 3.98 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.65 years
male: 75.73 years
female: 81 .77 years (2000 est.)
Total fertility rate: 1.81 children born/woman
(2000 est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Norwegian (Nordic, Alpine, Baltic),
Lapps (Sami) 20,000
Religions: Evangelical Lutheran 86% (state church),
other Protestant and Roman Catholic 3%, other 1%,
none and unknown 10% (1997)
Languages: Norwegian (official)
note: small Lapp- and Finnish-speaking minorities
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: NA%
female: NA%
I " ■
Country name:
conventional long form: Kingdom of Norway
conventional short form: Norway
local long form: Kongeriket Norge
local short form: Norge
Data code: NO
Government type: constitutional monarchy
Capital; Oslo
Administrative divisions: 19 provinces (fylker,
singular - fylke); Akershus, Aust-Agder, Buskerud,
Finnmark, Hedmark, Hordaland, More og Romsdal,
Nordland, Nord-Trondelag, Oppland, Oslo, Ostfold,
Rogaland, Sogn og Fjordane, Sor-Trondelag,
Telemark, Troms, Vest-Agder, Vestfold
Dependent areas: Bouvet Island, Jan Mayen,
Svalbard
Independence: 7 June 1905 Norway declared the
union with Sweden dissolved; 26 October 1905
Sweden agreed to the repeal of the union
National holiday: Constitution Day, 17 May (1814)
Constitution; 17 May 1814, modified in 1884
Legal system: mixture of customary law, civil law
system, and common law traditions; Supreme Court
renders advisory opinions to legislature when asked;
accepts compulsory ICJ jurisdiction, with reservations
Suffrage; 18 years of age; universal
Executive branch;
chief of state: King HARALD V (since 17 January
1991); Heir Apparent Crown Prince HAAKON
MAGNUS, son of the monarch (born 20 July 1973)
head of government: Prime Minister Jens
STOLTENBERG (since 17 March 2000)
cabinet: State Council appointed by the monarch with
the approval of the Parliament
elections: none; the monarch is hereditary; following
parliamentary elections, the leader of the majority
party or leader of a majority coalition is usually
appointed prime minister by the monarch with the
approval of the Parliament
Legislative branch: modified unicameral
Parliament or Storting which, for certain purposes,
divides itself into two chambers (165 seats; members
are elected by popular vote by proportional
representation to serve four-year terms)
elections: last held 15 September 1997 (next to be
held NA September 2001)
election results: percent of vote by party - Labor Party
35%, Center Party 7.9%, Consen/ative Party 14.3%,
Christian People''s Party 13.7%, Socialist Left Party
6%, Progress Party 15.3%, Liberal Party 4.4%, other
parties 1 .6%; seats by party - Labor Party 65, Center
Party 1 1 , Conservative Party 23, Christian People''s
Party 25, Socialist Left Party 9, Progress Party 25,
Liberal Party 6, other parties 1
note: for certain purposes, the Parliament divides
itself into two chambers and elects one-fourth of its
membership to an upper house or Lagting
Judicial branch: Supreme Court or Hoyesterett,
justices appointed by the monarch
Political parties and leaders: Center Party [Johan
J. JAKOBSEN); Christian People''s Party [Valgerd
HAUGLANDj; Conservative Party [Jan PETERSEN);
Labor Party [Thorbjorn JAGLANDj; Liberal Party [Lars
SPONHEIM]; Norwegian Communist Party [Kare
Andre NILSEN); Progress Party [Carl I. HAGEN]; Red
Electoral Alliance [Erling FOLIWORDj; Socialist Left
Party [Kristin HALVORSEN]
International organization participation: AfDB,
AsDB, Australia Group, BIS, CBSS, CCC, CE, CERN,
EAPC, EBRD, ECE, EFTA, ESA, FAO, lADB, IAEA,
IBRD, ICAO, ICC, ICFU, ICRM, IDA, lEA, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, lOM, ISO, ITU, MINURSO, NAM
(guest), NATO, NC, NEA, NIB, NSG, OECD, OPCW,
OSCE, PCA, UN, UNCTAD, UNESCO, UNHCR,
UNIDO, UNMIBH, UNMIK, UNMOP, UNTSO, UPU,
WEU (associate), WHO, WlPO, WMO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Tom Erik VRAALSEN
chancery: 2720 34th Street NW, Washington, DC
20008
fe/ephone; [11(202) 333-6000
FAX; [11(202) 337-0870
consulate(s) general: Houston, Miami, Minneapolis,
New York, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador David B. HERMELIN
embassy: Drammensveien 18, 0244 Oslo
mailing address: PSC 69, Box 1000, APO AE 09707
telephone: [47] [22) 44 85 50
FAX; [47] (22) 43 07 77
Flag description: red with a blue cross outlined in
white that extends to the edges of the flag; the vertical
part of the cross is shifted to the hoist side in the style
of the Dannebrog (Danish flag)
I c oTiTolrry ’ ■ \\
Economy - overview: The Norwegian economy is a
prosperous bastion of welfare capitalism, featuring a
combination of free market activity and government
intervention. The government controls key areas.
373
Norway (continued)
such as the vital petroleum sector (through
large-scale state enterprises), and extensively
subsidizes agriculture, fishing, and areas with sparse
resources. The extensive welfare system helps propel
public sector expenditures to more than 50% of GDP.
A major shipping nation, with a high dependence on
international trade, Norway is basically an exporter of
raw materials and semiprocessed goods. The country
is richly endowed with natural resources - petroleum,
hydropower, fish, forests, and minerals - and is highly
dependent on its oil production and international oil
prices. Only Saudi Arabia exports more oil than
Norway. Norway imports more than half its food
needs. Oslo opted to stay out of the EU during a
referendum in November 1 994. Growth was a meager
0.8% in 1999 because of weak private consumption
and anemic investment activity in the oil and other
sectors. Growth should pick up in 2000, perhaps to
2.7%. Despite their high per capita income and
generous welfare benefits, Norwegians worry about
that time in the next two decades when the oil and gas
begin to run out.
GDP: purchasing power parity - $1 1 1 .3 billion
(1999 est.)
GDP - real growth rate: 0.8% (1999 est.)
GDP • per capita: purchasing power parity -
$25,100 (1999 est.)
GDP ■ composition by sector:
agriculture: 2.2%
industry: 26.3%
services; 71 .5% (1998)
Population beiow poverty line: NA%
Household income or consumption by percentage
share:
lowest /0%;4.1%
highest /0%; 21 .2% (1991)
Inflation rate (consumer prices): 2.8% (1999 est.)
Labor force: 2.7 million (1999 est.)
Labor force - by occupation: services 74%,
industry 22%, agriculture, forestry, and fishing 4%
(1995)
Unemployment rate: 2.9% (1999 est.)
Budget:
revenues: $69.7 billion
expenditures: billion, including capital
expenditures of $NA (2000 est.)
Industries: petroleum and gas, food processing,
shipbuilding, pulp and paper products, metals,
chemicals, timber, mining, textiles, fishing
Industrial production growth rate: 0.7%
(1999 est.)
Electricity - production: 1 15.485 billion kWh (1998)
Electricity - production by source:
fossil fuel: 0.58%
hydro; 99.16%
nuclear: 0%
ofher; 0.26% (1998)
Electricity - consumption: 1 1 1 .001 billion kWh
(1998)
Electricity - exports: 4.4 billion kWh (1998)
Electricity - imports: 8 billion kWh (1998)
Agriculture ■ products: barley, other grains,
potatoes; beef, milk; fish
Exports: $47.3 billion (f.o.b., 1999 est.)
Exports - commodities: petroleum and petroleum
products, machinery and equipment, metals,
chemicals, ships, fish
Exports - partners: EU 77% (UK 17%, Germany
12%, Netherlands 10%, Sweden 10%, France 8%),
US 7% (1998)
Imports: $38.6 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment,
chemicals, metals, foodstuffs
Imports - partners: EU 69% (Sweden 15%,
Germany 14%, UK 10%, Denmark 7%), US 7%,
Japan 4% (1998)
Debt - external: $0 (Norway is a net external
creditor)
Economic aid - donor: ODA, $1 .4 billion (1 998)
Currency: 1 Norwegian krone (NKr) = 100 oere
Exchange rates: Norwegian kroner (NKr) per
US$1 - 8.01 29 (January 2000), 7.7992 (1 999), 7.5451
(1998), 7.0734 (1997), 6.4498 (1996), 6.3352 (1995)
Fiscal year: calendar year
Background: In 1970, QABOOS bin Said Al Said
ousted his father and has ruled as sultan ever since.
His extensive modernization program has opened the
country to the outside worid and has preserved a
long-standing political and military reiationship with
Britain. Oman''s moderate, independent foreign poiicy
has sought to maintain good relations with ail Middle
Eastern countries.
o"g7''a''p''hy~ ”
Location: Middle East, bordering the Arabian Sea,
Guif of Oman, and Persian Gulf, between Yemen and
UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
fofa/;212,460sq km
/and; 212,460 sqkm
wafer; 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
fofa/; 1,374 km
border countries: Saudi Arabia 676 km, UAE 410 km,
Yemen 288 km
Coastiine: 2,092 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: dry desert; hot, humid along coast; hot, dry
interior; strong southwest summer monsoon (May to
September) in far south
Terrain: vast central desert plain, rugged mountains
in north and south
Eievation extremes:
lowest point: Arabian Sea 0 m
highest point: Jaba\\ Shams 2,980 m
Natural resources: petroleum, copper, asbestos,
some marble, limestone, chromium, gypsum, natural
gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 0%
of/ier;95%(1993est.)
Irrigated land: 580 sqkm (1993 est.)
Natural hazards: summer winds often raise large
sandstorms and dust storms in interior; periodic
droughts
Environment - current issues: rising soil salinity;
beach pollution from oil spills; very limited natural
fresh wafer resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Musandam
Peninsula adjacent to Strait of Hormuz, a vital transit
point for world crude oil
.
Population: 2,533,389
note: includes 527,078 non-nationals (July 2000 est.)
Age structure:
O-Uyears: 41% (male 531,137; female 511,051)
15-64 years: 57% (male 875,625; female 555,895)
65 years and over: 2% (male 31 ,400; female 28,281 )
(2000 est.)
Population growth rate: 3.46% (2000 est.)
Birth rate: 38.08 births/1,000 population (2000 est.)
Death rate: 4.16 deaths/1,000 population
(2000 est.)
Net migration rate: 0.65 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .58 male(s)/female
65 years and over: 1.11 male(s)/female
total population: 1.31 male(s)flemale (2000 est.)
Infant mortality rate: 23.28 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .78 years
male: 69.66 years
female: 74 years (2000 est.)
Total fertility rate: 6.08 children born/woman
(2000 est.)
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: approaching 80%
male: NA%
female: NA%
I GoverTimeht
Country name:
conventional long form: Sultanate of Oman
conventional short form: Oman
local long form: Saltanat Uman
local short form: Uman
Data code: MU
Government type: monarchy
Capital: Muscat
Administrative divisions: 6 regions (mintaqat,
singular - mintaqah) and 2 governorates* (muhafazat,
singular - muhafazah) Ad Dakhiliyah, Al Batinah, Al
Wusta, Ash Sharqiyah, Az Zahirah, Masqat,
Musandam*, Zufar*; note - the US Embassy in Oman
says that Masqat is a governorate
Independence: 1650 (expulsion of the Portuguese)
National holiday: National Day, 18 November
(1940)
Constitution: none; note - on 6 November 1996,
Sultan QABOOS issued a royal decree promulgating
a new basic law which, among other things, clarifies
the royal succession, provides for a prime minister,
bars ministers from holding interests in companies
doing business with the government, establishes a
bicameral legislature, and guarantees basic civil
liberties for Omani citizens
Legal system: based on English common law and
Islamic law; ultimate appeal to the monarch; has not
accepted compulsory ICJ jurisdiction
Suffrage: in Oman''s most recent elections in 1997,
limited to approximately 50,000 Omanis chosen by
the government to vote in elections for the Majlis
ash-Shura
Executive branch:
chief of state: Sultan and Prime Minister QABOOS bin
Said Al Said (since 23 July 1970); note - the monarch
is both the chief of state and head of government
head of government: Sultan and Prime Minister
QABOOS bin Said Al Said (since 23 July 1 970); note -
the monarch Is both the chief of state and head of
Background: The separation in 1947 of British india
into the Muslim state of Pakistan (with two sections
West and East) and iargely Hindu india was never
satisfactoriiy resolved. A third war between these
countries in 1971 resuited in East Pakistan seceding
and becoming the separate nation of Bangiadesh. A
dispute over the state of Kashmir is ongoing. In
response to Indian nuclear weapons testing, Pakistan
conducted its own tests in 1998.
f d e 0 g ’r a p h y
Location: Southern Asia, bordering the Arabian Sea,
between India on the east and iran and Afghanistan
on the west and China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area ■ comparative: slightiy less than twice the size
of California
Land boundaries:
total: 6,774 km
border counfr/es; Afghanistan 2,430 km, China 523
km, India 2,912 km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly hot, dry desert; temperate in
northwest; arctic in north
Terrain: flat Indus plain in east; mountains in north
and northwest; Baiochistan plateau in west
Elevation extremes;
lowest point: Indian Ocean 0 m
highest point: K2 {Ml Godwin-Austen) 8,611 m
Natural resources: land, extensive natural gas
reserves, limited petroleum, poor quality coai, iron
ore, copper, salt, limestone
Land use:
arable land: 27%
permanent crops: 1%
permanent pastures: 6%
forests and woodland: 5%
other; 61 %(1 993 est.)
Irrigated land: 1 71 ,1 00 sq km (1 993 est.)
Natural hazards; frequent earthquakes,
occasionally severe especially in north and west;
flooding aiong the Indus after heavy rains (July and
August)
Environment - current issues: water pollution from
raw sewage, industrial wastes, and agricultural runoff;
limited natural fresh water resources; a majority of the
population does not have access to potable water;
deforestation; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Consen/ation
Geography - note: controls Khyber Pass and Bolan
Pass, traditional invasion routes between Central Asia
and the Indian Subcontinent
P e 0 p Xe
Population: 141,553,775 (July 2000 est.)
Age structure:
0-14 years: 41% (male 29,880,574; female
28,145,247)
15-64 years: 55% (male 39,751 ,222; female
37,981,378)
65 years and over: 4% (male 2,856,305; female
2,939,049) (2000 est.)
Population growth rate: 2.17% (2000 est.)
Birth rate: 32.11 births/1,000 population (2000 est.)
Death rate: 9.51 deaths/1,000 population
(2000 est.)
Net migration rate: -0.9 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.05 male(s)/female (2000 est.)
Infant mortality rate: 82.49 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 61 .07 years
male: 60.27 years
female: 61 .91 years (2000 est.)
Total fertility rate: 4.56 children born/woman
(2000 est.)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India at the time of
partition and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy;
definition: age 15 and over can read and write
total population: 37.8%
male: 50%
female: 24.4% (1995 est.)','ec453ae17e61b619a1a4f3a72cfed9b138db6ba42fc4823a4a68ec890db33f56','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf05001e37ebb07c6e80733397668fe43e9ce1ea68c34508c116361cc470b8f3',2000,'AR','Argentina','introduction',390,'permanent pastures: 21 %
forests and woodland: 66%
of/7er;10%(1993est.)
Irrigated land: 12,800 sq km (1993 est.)
Natural hazards: earthquakes, tsunamis, flooding,
landslides, mild volcanic activity
Environment ■ current Issues: deforestation (some
the result of illegal logging); overgrazing of the slopes
of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers
and coastal waters from municipal and mining wastes
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: shares control of Lago Titicaca,
world''s highest navigable lake, with Bolivia
Background; After a dozen years of military rule,
Peru returned to democratic leadership in 1980. In
recent years, bold reform programs and significant
progress in curtailing guerrilla activity and drug
trafficking have resulted in solid economic grovirth.
Location: Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00 W
Map references: South America
Area;
total: 1 ,285,220 sq km
land: 1.26 million sq km
water: 5,220 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
total: 5,536 km
border countries: Bolivia 900 km, Brazil 1 ,560 km,
Chile 160 km, Colombia 1,496 km (est.), Ecuador
1,420 km
Coastline; 2,414 km
Maritime claims;
continental shelf: 200 nm
territorial sea: 200 nm
Climate; varies from tropical in east to dry desert in
west; temperate to frigid in Andes
Terrain: western coastal plain (costa), high and
rugged Andes in center (sierra), eastern lowland
jungle of Amazon Basin (selva)
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum,
timber, fish, iron ore, coal, phosphate, potash,
hydropower
Land use:
arable land: 3%
permanent crops: 0%
I'' ■ ’ " P e 0 p fe , ’ . ■ ‘
Population: 27,012,899 (July 2000 est.)
Age structure:
0-14 years: 35% (male 4,776,074; female 4,628,899)
15-64 years: 61% (male 8,224,829; female
8,119,751)
65 years and over: 4% (male 579,465; female
683,881) (2000 est.)
Population growth rate: 1 .75% (2000 est.)
Birth rate: 24.48 births/1,000 population (2000 est.)
Death rate: 5.84 deaths/1,000 population
(2000 est.)
Net migration rate: -1.1 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
af birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1.01 male(s)/female (2000 est.)
Infant mortality rate: 40.6 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.01 years
male: 67.63 years
female: 72.5 years (2000 est.)
Total fertility rate: 3.04 children born/woman
(2000 est.)
Nationality;
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic 90%
Languages; Spanish (official), Quechua (official),
Aymara
Literacy:
definition: age 15 and over can read and write
391
P6ru (continued)
total population: 88.7%
male: 94.5%
female: 83% (1995 est.)
I Government
Country name:
conventional long form: Republic of Peru
conventional short form: Peru
local long form: Republica del Peru
local short form: Peru
Data code: PE
Government type: constitutional republic
Capital: Lima
Administrative divisions: 24 departments
(departamentos, singular - departamento) and 1
constitutional province* (provincia constitucional);
Amazonas, Ancash, Apurimac, Arequipa, Ayacucho,
Cajamarca, Callao*, Cusco, Huancavelica, Huanuco,
lea, Junin, La Libertad, Lambayeque, Lima, Loreto,
Madre de Dios, Moquegua, Pasco, Piura, Puno, San
Martin, Tacna, Tumbes, Ucayali
note; the 1979 constitution mandated the creation of
regions (regiones, singular - region) to function
eventually as autonomous economic and
administrative entities; so far, 12 regions have been
constituted from 23 of the 24 departments -
Amazonas (from Loreto), Andres Avelino Caceres
(from Huanuco, Pasco, Junin), Arequipa (from
Arequipa), Chavin (from Ancash), Grau (from
Tumbes, Piura), Inca (from Cusco, Madre de Dios,
Apurimac), La Libertad (from La Libertad), Los
Libertadores-Huari (from lea, Ayacucho,
Huancavelica), Mariategui (from Moquegua, Tacna,
Puno), Nor Oriental del Maranon (from Lambayeque,
Cajamarca, Amazonas), San Martin (from San
Martin), Ucayali (from Ucayali); formation of another
region has been delayed by the reluctance of the
constitutional province of Callao to merge with the
department of Lima; because of inadequate funding
from the central government and organizational and
political difficulties, the regions have yet to assume
major responsibilities; the 1993 constitution retains
the regions but limits their authority; the 1993
constitution also reaffirms the roles of departmental
and municipal governments
Independence: 28 July 1821 (from Spain)
National holiday: Independence Day, 28 July
(1821)
Constitution: 31 December 1993
Legal system: based on civil law system; has not
accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Alberto Kenyo FUJIMORI
Fujimori (since 28 July 1990); note - the president is
both the chief of state and head of government;
additionally there are two vice presidents
head of government: President Alberto Kenyo
FUJIMORI Fujimori (since 28 July 1990); note - the
president is both the chief of state and head of
government; additionally there are two vice presidents
note: Prime Minister Alberto BUSTAMANTE (since 13
October 1999) does not exercise executive power;
this power is in the hands of the president
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
five-year term; election last held 9 April 1 995 (next to
be held 9 April 2000)
election results: President FUJIMORI reelected;
percent of vote - Alberto FUJIMORI 64.42%, Javier
PEREZ de CUELLAR 21 .80%, Mercedes
CABANILLAS 4.1 1%, Other 9.67%
Legislative branch: unicameral Democratic
Constituent Congress or Congresso Constituyente
Democratico (120 seats; members are elected by
popular vote to serve five-year terms)
elections: last held 9 April 1 995 (next to be held 9 April
2000)
election results: percent of vote by party - C90/NM
52.1%, UPP 14%, other parties 33.9%; seats by
party - C90/NM 67, UPP 17, APRA 8, FIM 6,
CODE-Pais Posible 5, AP 4, PPC 3, Renovation Party •
3, lU 2, OBRAS 2, other parties 3
Judicial branch: Supreme Court of Justice or Corte
Suprema de Justicia, judges are appointed by the
National Council of the Judiciary
Political parties and leaders; American Popular
Revolutionary Alliance or APRA [Luis ALVA Castro);
Change 90-New Majority or C90/NM [Alberto
FUJIMORI]; Civic Works Movement or OBRAS
[Ricardo BELMONT]; Democratic Coordinator or
CODE-Pais Posible [Jose BARBA Caballero and
Alejandro TOLEDO]; Independent Agrarian
Movement or MIA [leader NA]; Independent
Moralizing Front or FIM [Fernando OLIVERA Vega];
Peru 2000 [Alberto FUJIMORI]; coalition of C90/NM
and Vamos Vecino; Popular Action Party or AP [Juan
DIAZ Leon]; Popular Christian Party or PPC [Luis
BEDOYA Reyes]; Renovation Party [Rafael REY
Rey]; Union for Peru or UPP [Javier PEREZ de
CUELLAR]; United Left or lU [leader NA]; Vamos
Vecino or VV [leader NA]
Political pressure groups and leaders: leftist
guerrilla groups include Shining Path [Abimael
GUZMAN Reynoso (imprisoned), Gabriel MACARIO
(top leader at-large)]; Tupac Amaru Revolutionary
Movement or MRTA [Victor POLAY (imprisoned),
Hugo AVALLENEDA Valdez (top leader at-large)]
International organization participation; APEC,
CAN, CCC, ECLAC, FAO, G-11, G-15, G-19, G-24,
G-77, lADB, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM,
IDA, IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, lOM, ISO
(correspondent), ITU, LAES, LAIA, NAM, OAS,
OPANAL, OPCW, PCA, RG, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WlPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Alfonso RIVERO
Monsalve
chancery: 1700 Massachusetts Avenue NW,
Washington, DC 20036
telephone: [1] (202) 833-9860 through 9869
FAX; [1] (202) 659-8124
consulate(s) general: Chicago, Houston, Los
Angeles, Miami, New York, Paterson (New Jersey),
San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador John HAMILTON
embassy; Avenida Encalada, Cuadra 17, Monterrico,
Lima
mailing address: P. 0. Box 1995, Lima 1; American
Embassy (Lima), APO AA 34031-5000
fe/epbone; [51] (1)434-3000
FAX; [51] (1)434-3037
Flag description: three equal, vertical bands of red
(hoist side), white, and red with the coat of arms
centered in the white band; the coat of arms features
a shield bearing a llama, cinchona tree (the source of
quinine), and a yellow cornucopia spilling out gold
coins, all framed by a green wreath
Background: The Philippines were ceded by Spain
to the US in 1898 following the Spanish-American
War. They attained their independence in 1946 after
being occupied by the Japanese in World War II. The
21 -year rule of Ferdinand MARCOS ended in 1986
when a widespread popular rebellion forced him into
exile. In 1992, the US closed down its last military
bases on the islands. A quarter-century-old guerrilla
war with Muslim separatists on the island of
Mindanao, which had claimed 120,000 lives, ended
with a treaty in 1996.
i Geography
Location; Southeastern Asia, archipelago between
the Philippine Sea and the South China Sea, east of
Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
/and.- 298,170 sq km
water: 1 ,830 sq km
Area - comparative: slightiy larger than Arizona
Land boundaries: 0 km
Coastiine: 36,289 km
Maritime ciaims; measured from claimed
archipelagic baselines
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: irregular polygon extending up to 1 00
nm from coastline as defined by 1 898 treaty; since late
1970s has also claimed polygonal-shaped area in
South China Sea up to 285 nm in breadth
Climate: tropical marine; northeast monsoon
(November to April); southwest monsoon (May to
October)
Terrain: mostly mountains with narrow to extensive
coastal lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel,
cobalt, silver, gold, salt, copper
Land use:
arable land: 19%
permanent crops: 12%
permanent pastures: 4%
forests and woodland: 46%
other: 19% (1993 est.)
Irrigated land; 15,800 sq km (1993 est.)
Natural hazards: astride typhoon belt, usually
affected by 1 5 and struck by five to six cyclonic storms
per year; landslides; active volcanoes; destructive
earthquakes; tsunamis
Environment - current issues; uncontrolled
deforestation in watershed areas; soil erosion; air and
water pollution in Manila; increasing pollution of
coastal mangrove swamps which are important fish
breeding grounds
Environment - international agreements;
party to: Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Desertification
I People
Population: 81 ,159,644 (July 2000 est.)
Age structure:
0-14 years: 37% (male 15,344,555; female
14,807,320)
15-64 years: 59% (male 23,777,245; female
24,285,565)
65 years and over: 4% (male 1 ,31 2,646; female
1,632,313) (2000 est.)
Population growth rate: 2.07% (2000 est.)
Birth rate: 27.85 births/1,000 population (2000 est.)
Death rate: 6.13 deaths/1,000 population
(2000 est.)
Net migration rate: -1.02 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.Q8 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 29.52 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 67.48 years
male: 64.65 years
female: 70.46 years (2000 est.)
Total fertility rate: 3.48 children born/woman
(2000 est.)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Christian Malay 91 .5%, Muslim
Malay 4%, Chinese 1 .5%, other 3%
Religions: Roman Catholic 83%, Protestant 9%,
Muslim 5%, Buddhist and other 3%
Languages: Pilipino (official, based on Tagalog),
English (official)
Literacy:
definition: age 15 and over can read and write
total population: 94.6%
male: 95%
female: 94.3% (1995 est.)','9809c086bb7644f64494321142ee66a25872663bd94b5f044c50cfbe7c19ee72','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cdaa7645626e13b9af9f534d1a8fe01ee3236b25d9d10fcefbf794ad25a9750',2000,'UA','Ukraine','introduction',407,'Background; The defeat of the Russian Empire in
Worid War I ied to the seizure of power by the
communists and the formation of the USSR. The
brutai rule of Josef STALIN (1924-53) strengthened
Russian dominance of the Soviet Union at a cost of
tens of miliions of lives. The Soviet economy and
society stagnated in the foiiowing decades untii
General Secretary Mikhail GORBACHEV (1985-91)
introduced glasnost (openness) and perestroika
(restructuring) in an attempt to modernize
communism, but his initiatives inadvertentiy reieased
forces that by December 1 991 broke up the USSR into
15 independent republics. Since then, Russia has
struggled in its efforts to buiid a democratic poiitical
system and market economy to repiace the strict
sociai, poiitical, and economic controis of the
communist period.
P Geog''rVphy
Location: Northern Asia (that part west of the Urais
is sometimes included with Europe), bordering the
Arctic Ocean, between Europe and the North Pacific
Ocean
Geographic coordinates; 60 00 N, 100 00 E
Map references; Asia
Area:
total: 17,075,200 sq km
land: 16,995,800 sq km
water: 79,400 sq km
Area - comparative: slightiy less than 1 .8 times the
size of the US
Land boundaries:
fofa/;19,917km
border countries: Azerbaijan 284 km, Beiarus 959 km,
China (southeast) 3,605 km, China (south) 40 km,
Estonia 294 km, Finiand 1,313 km, Georgia 723 km,
Kazakhstan 6,846 km. North Korea 19 km, Latvia 217
km, Lithuania (Kaiiningrad Oblast) 227 km, Mongolia
3,441 km, Norway 167 km, Poiand (Kaiiningrad
Obiast) 206 km, Ukraine 1,576 km
Coastline: 37,653 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: ranges from steppes in the south through
humid continental in much of European Russia;
subarctic in Siberia to tundra climate in the polar north;
winters vary from cool along Black Sea coast to frigid
in Siberia; summers vary from warm in the steppes to
cool along Arctic coast
Terrain: broad plain with low hills west of Urals; vast
coniferous forest and tundra in Siberia; uplands and
mountains along southern border regions
Elevation extremes;
lowest point: Caspian Sea -28 m
highest point: Gora El''brus 5,633 m
Natural resources: wide natural resource base
including major deposits of oil, natural gas, coal, and
many strategic minerals, timber
note: formidable obstacles of climate, terrain, and
distance hinder exploitation of natural resources
Land use;
arable land: 8%
permanent crops: 0%
permanent pastures: 4%
forests and woodland: 46%
other 42% (1993 est.)
Irrigated land: 40,000 sq km (1993 est.)
Natural hazards: permafrost over much of Siberia is
a major impediment to development; volcanic activity
in the Kuril Islands; volcanoes and earthquakes on the
Kamchatka Peninsula
Environment - current issues: air pollution from
heavy industry, emissions of coal-fired electric plants,
and transportation in major cities; industrial,
municipal, and agricultural pollution of inland
waterways and sea coasts; deforestation; soil erosion;
soil contamination from improper application of
agricultural chemicals; scattered areas of sometimes
intense radioactive contamination; ground water
contamination from toxic waste
Environment - international agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulphur 94,
Climate Change-Kyoto Protocol
Geography - note: largest country in the world in
terms of area but unfavorably located in relation to
major sea lanes of the world; despite its size, much of
the country lacks proper soils and climates (either too
cold or too dry) for agriculture
I People
Population; 146,001,176 (July 2000 est.)
Age structure;
0-14years: 18% (male 13,493,610; female
12,971,546)
15-64 years: 69% (male 48,983,755; female
52,140,022)
65 years and over: 13% (male 5,802,129; female
12,610,114) (2000 est.)
Population growth rate: -0.38% (2000 est.)
Birth rate: 9.02 births/1 ,000 population (2000 est.)
Death rate: 13.8 deaths/1 ,000 population
(2000 est.)
Net migration rate; 1.02 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.46 male(s)/female
total population: 0.8& male(s)/female (2000 est.)
Infant mortality rate: 20.33 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 67. 1 9 years
male: 61 .95 years
female: 72.69 years (2000 est.)
Total fertility rate: 1.25 children born/woman
(2000 est.)
Nationality;
noun: Russian(s)
adjective: Russian
Ethnic groups; Russian 81 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1 .2%, Bashkir 0.9%,
Byelorussian 0.8%, Moldavian 0.7%, other 8.1%
Religions; Russian Orthodox, Muslim, other
Languages: Russian, other
Literacy;
definition: age 1 5 and over can read and write
total population: 98%
male: 100%
female: 97% (1 989 est.)
412
Russia (continued)
f Government
Country name:
conventional long form: Russian Federation
conventional short form: Russia
local long form: Rossiyskaya Federatsiya
local short form: Rossiya
former: Russian Soviet Federative Socialist Republic
Data code: RS
Government type: federation
Capital: Moscow
Administrative divisions: 49 oblasts (oblastey,
singular - oblast), 21 republics* (respublik, singular -
respublika), 10 autonomous okrugs**(avtonomnykh
okrugov, singular - avtonomnyy okrug), 6 krays***
(krayev, singular - kray), 2 federal cities (singular -
gorod)****, and 1 autonomous
oblast*****(avtonomnaya oblast''); Adygeya
(Maykop)*, Aginskiy Buryatskiy (Aginskoye)**, Altay
(Gorno-Altaysk)*, Altayskiy (Barnaul)***, Amurskaya
(Blagoveshchensk), Arkhangel''skaya,
Astrakhanskaya, Bashkortostan (Ufa)*,
Belgorodskaya, Bryanskaya, Buryatiya (Ulan-Ude)*,
Chechnya (Groznyy)*, Chelyabinskaya, Chitinskaya,
Chukotskiy (Anadyr'')**, Chuvashiya (Cheboksary)*,
Dagestan (Makhachkala)*, Evenkiyskiy (Tura)**,
Ingushetiya (Nazran'')*, Irkutskaya, Ivanovskaya,
Kabardino-Balkariya (Nal''chik)*, Kaliningradskaya,
Kalmykiya (Elista)*, Kaluzhskaya, Kamchatskaya
(Petropavlovsk-Kamchatskiy),
Karachayevo-Cherkesiya (Cherkessk)*, Kareliya
(Petrozavodsk)*, Kemerovskaya, Khabarovskiy***,
Khakasiya (Abakan)*, Khanty-Mansiyskiy
(Khanty-Mansiysk)**, Kirovskaya, Komi (Syktyvkar)*,
Koryakskiy (Palana)**, Kostromskaya,
Krasnodarskiy***, Krasnoyarskiy***, Kurganskaya,
Kurskaya, Leningradskaya, Lipetskaya,
Magadanskaya, Mariy-El (Yoshkar-Ola)*, Mordoviya
(Saransk)*, Moskovskaya, Moskva (Moscow)****,
Murmanskaya, Nenetskiy (Nar''yan-Mar)**,
Nizhegorodskaya, Novgorodskaya, Novosibirskaya,
Omskaya, Orenburgskaya, Orlovskaya (Orel),
Penzenskaya, Permskaya, Komi-Permyatskiy
(Kudymkar)**, Primorskiy (Vladivostok)***,
Pskovskaya, Rostovskaya, Ryazanskaya, Sakha
(Yakutsk)*, Sakhalinskaya (Yuzhno-Sakhalinsk),
Samarskaya, Sankt-Peterburg (Saint Petersburg)****,
Saratovskaya, Severnaya Osetiya-Alaniya
(Vladikavkaz)*, Smolenskaya, Stavropol''skiy***,
Sverdlovskaya (Yekaterinburg), Tambovskaya,
Tatarstan (Kazan'')*, Taymyrskiy (Dudinka)**,
Tomskaya, Tul''skaya, Tverskaya, Tyumenskaya,
Tyva (Kyzyl)*, Udmurtiya (Izhevsk)*, Ul''yanovskaya,
Ust''-Ordynskiy Buryatskiy (Ust''-Ordynskiy)**,
Vladimirskaya, Volgogradskaya, Vologodskaya,
Voronezhskaya, Yamalo-Nenetskiy (Salekhard)**,
Yaroslavskaya, Yevreyskaya*****; note - when using
a place name with an adjectival ending ''skaya'' or
''skiy,'' the word Oblast'' or Avonomnyy Okrug or Kray
should be added to the place name
note; the autonomous republics of Chechnya and
Ingushetiya were formerly the autonomous republic of
Checheno-Ingushetia (the boundary between
Chechnya and Ingushetia has yet to be determined);
administrative divisions have the same names as their
administrative centers (exceptions have the
administrative center name following in parentheses)
Independence: 24 August 1991 (from Soviet Union)
National holiday: Independence Day, 12 June
(1990)
Constitution: adopted 12 December 1993
Legal system: based on civil law system; judicial
review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Vladimir Vladimirovich
PUTIN (since 7 May 2000); note - President YEL''TSIN
resigned on 31 December 1999, naming Vladimir
PUTIN as Acting President until new elections were
held on 26 March 2000
head of government: Acting Premier Mikhail
Mikhaylovich KASYANOV (since 7 May 2000);
Deputy Premiers Viktor Borisovich KHRISTENKO
(since 31 May 1999), Ilya Iosifovich KLEBANOV
(since 31 May 1999), Nikolay Pavlovich KOSHMAN
(since 15 October 1999), Valentina Ivanovna
MATVIYENKO (since 22 September 1998), Valdimir
Nikolayevich SHCHERBAK (since 25 May 1999),
Sergey Kuzhugetovich SHOYGU (since 10 January
2000)
cabinet: Ministries of the Government or
"Government" composed of the premier and his
deputies, ministers, and other agency heads; all are
appointed by the president
note: there is also a Presidential Administration (PA)
that provides staff and policy support to the president,
drafts presidential decrees, and coordinates policy
among government agencies; a Security Council also
reports directly to the president
elections: president elected by popular vote for a
four-year term; election last held 26 March 2000 (next
to be held NA 2004); note - no vice president; if the
president dies in office, cannot exercise his powers
because of ill health, is impeached, or resigns, the
premier succeeds him; the premier serves as acting
president until a new presidential election is held,
which must be within three months; premier appointed
by the president with the approval of the Duma
election results: Vladimir Vladimirovich PUTIN
elected president; percent of vote - PUTIN 52,9%,
Gennadiy Aadreyevich ZYUGANOV 29.2%, Grigoriy
Alekseyevich YAVLINSKIY 5.8%
Legislative branch: bicameral Federal Assembly or
Federalnoye Sobraniye consists of the Federation
Council or Sovet Federatsii (178 seats, filled ex officio
by the top executive and legislative officials in each of
the 89 federal administrative units - oblasts, krays,
republics, autonomous okrugs and oblasts, and the
federal cities of Moscow and Saint Petersburg;
members serve four-year terms) and the State Duma
or Gosudarstvennaya Duma (450 seats, half elected
by proportional representation from party lists winning
at least 5% of the vote, and half from single-member
constituencies; members are elected by direct popular
vote to serve four-year terms)
elections: State Duma - last held 19 December 1999
(next to be held NA December 2003)
election results: State Duma - percent of vote
received by parties clearing the 5% threshold entitling
them to a proportional share of the 225 party list
seats - Communist Party of the Russian Federation
(KPRF) 24.29%, Unity 23.32%, Fatherland-All Russia
(OVR) 13.33%, Union of Right Forces 8.52%, Liberal
Democratic Party (Zhirinovsky Bloc) 5.98%, Yabloko
5.93%; seats by party - Communist Party of the
Russian Federation (KPRF) 90, Unity 82, People''s
Deputies faction 57, Fatherland-All Russia (OVR) 45,
Russia''s Regions 42, Agro-industrial faction 39, Union
of Right Forces 32, Yabloko 21, Liberal Democratic
Party of Russia 17, independents 16, repeat election
required 8, vacant 1
Judicial branch: Constitutional Court, judges are
appointed for life by the Federation Council on the
recommendation of the president; Supreme Court,
judges are appointed for life by the Federation Council
on the recommendation of the president; Superior
Court of Arbitration, judges are appointed for life by
the Federation Council on the recommendation of the
president
Political parties and leaders: Agro-industrial
faction [leader NA]; Communist Party of the Russian
Federation or KPRF [Gennadiy Andreyevich
ZYUGANOV]; Fatherland-All Russia or OVR
[Yevgeniy Maksimovich PRIMAKOV, Yuriy
Mikhailovich LUZHKOV]; Liberal Democratic Party of
Russia [Vladimir Volfovich ZHIRINOVSKIY]; People''s
Deputies faction [leader NA]; Russia''s Regions
[leader NA]; Union of Right Forces [Sergey
Vladilenovich KIRIYENKO]; Unity [Sergey
Kuzhugetovich SHOYGU]; Yabloko Bloc [Grigoriy
Alekseyevich YAVLINSKIY]
note: some 150 political parties, blocs, and
movements registered with the Justice Ministry as of
the 19 December 1998 deadline to be eligible to
participate in the 1 9 December 1 999 Duma elections;
of these, 36 political organizations actually qualified to
run slates of candidates on the Duma party list ballot,
6 parties cleared the 5% threshold to win a
proportional share of the 225 party seats in the Duma,
8 other organizations hold seats in the Duma: Bloc of
Nikolayev and Academician Fedorov, Congress of
Russian Communities, Movement in Support of the
Army, Our Home Is Russia, Party of Pensioners,
Russian All-People''s Union, Russian Socialist Party,
and Spiritual Heritage; primary political blocs include
pro-market democrats ■ (Yabloko Bloc and Union of
Right Forces), anti-market and/or ultranationalist
(Communist Party of the Russian Federation and
Liberal Democratic Party of Russia)
Political pressure groups and leaders: NA
International organization participation: APEC,
BIS, BSEC, CBSS, CCC, CE, CERN (observer), CIS,
EAPC, EBRD, ECE, ESCAP, G- 8, IAEA, IBRD,
ICAO, ICRM, IDA, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, lOM (observer), ISO,
413
Russia (continued)
ITU, LAIA (observer), MINURSO, MONUC, NAWI
(guest), NSG, OAS (observer), OPCW, OSCE, PCA,
PFP, UN, UN Security Council, UNAMSIL, UNCTAD,
UNESCO, UNHCR, UNIDO, UNIKOM, UNITAR,
UNMIBH, UNMIK, UNMOP, UNOMIG, UNTAET,
UNTSO, UPU, WFTU, WHO, WlPO, WMO, WToO,
WTrO (applicant), ZC
Diplomatic representation in the US:
chief of mission: Ambassador Yuriy Viktorovich
USHAKOV
chancery: 2650 Wisconsin Avenue NW, Washington,
DC 20007
telephone: [1] (202) 298-5700 through 5704
FAY; [1] (202) 298-5735
consulate(s) general: New York, San Francisco, and
Seattle
Diplomatic representation from the US;
chief of mission: Ambassador James F. COLLINS
embassy: Novinskiy Bul''var 19/23, Moscow
mailing address: APO AE 09721
telephone: [7] (095) 252-24-51 through 59
FAX; [7] (095) 956-42-61
consutate(s) general: St. Petersburg, Vladivostok,
Yekaterinburg
Flag description: three equal horizontal bands of
white (top), blue, and red','ffd34b5bce77b043d4c6b4d18d28699766fca323b484f28bdd5d19aa1936a9b2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ccfc2e57f84deb4da0db7860317244aa8acad225d374cc7a303e1a24a9ef9da',2000,'VC','Saint Vincent and the Grenadines','introduction',415,'Background: New Zealand occupied the German
protectorate of Western Samoa at the outbreak of
World War I in 1914. It continued to administer the
islands as a mandate and then as a trust territory until
1962, when the islands became the first Polynesian
nation to reestablish independence in the 20th
century. The country dropped the “Western” from its
name in 1997.
.
forests and woodland: 47%
other: 10%
Irrigated land; NA sq km
Natural hazards: occasional typhoons; active
volcanism
Environment - current issues; soil erosion
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Climate Change-Kyoto
Protocol
Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates; 13 35 S, 172 20 W
Map references; Oceania
Area:
total: 2,860 sq km
land: 2,850 sq km
water: 10 sq km
Area - comparative; slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline; 403 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; rainy season (October to March),
dry season (May to October)
Terrain; narrow coastal plain with volcanic, rocky,
rugged mountains in interior
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili 1,857 m
Natural resources: hardwood forests, fish,
hydropower
Land use;
arable land: 19%
permanent crops: 24%
permanent pastures: 0%
|v " ''p e 0 p^Te"'' " " ''■
Population: 179,466 (July 2000 est.)
Age structure;
0-14 years: 33% (male 30,288; female 29,323)
15-64 years: 61% (male 69,566; female 40,402)
65 years and over: 6% (male 4,623; female 5,264)
(2000 est.)
Population growth rate; -0.22% (2000 est.)
Birth rate: 15.59 births/1 ,000 population (2000 est.)
Death rate: 6.24 deaths/1,000 population
(2000 est.)
Net migration rate: -1 1 .59 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
af birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .72 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1.39 male(s)/female (2000 est.)
Infant mortality rate: 32.75 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 69.2 years
male: 66.48 years
female: 72.06 years (2000 est.)
Total fertility rate: 3.5 children born/woman
(2000 est.)
427
Samoa (continued)
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Christian 99.7% (about one-haif of
popuiation associated with the London Missionary
Society; inciudes Congregationai, Roman Cathoiic,
Methodist, Latter-Day Saints, Seventh-Day Adventist)
Languages: Samoan (Polynesian), Engiish
Literacy:
definition: age 15 and over can read and write
total population: 97%
mate: 97%
fema/e; 97% (1971 est.)
1 Government
Country name:
conventional long form: Independent State of Samoa
conventional short form: Samoa
former; Western Samoa
Data code: WS
Government type: constitutional monarchy under
native chief
Capital: Apia
Administrative divisions: 1 1 districts; A''ana,
Aiga-i-le-Tai, Atua, Fa''asaleieaga, Gaga''emauga,
Gagaifomauga, Palauii, Satupa''itea, Tuamasaga,
Va''a-o-Fonoti, Vaisigano
Independence: 1 January 1962 (from New
Zealand-administered UN trusteeship)
National holiday: National Day, 1 June (1962)
Constitution: 1 January 1962
Legal system: based on English common law and
local customs; judicial review of legislative acts with
respect to fundamental rights of the citizen; has not
accepted compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state: Chief Susuga MALIETOA Tanumafili II
(cochief of state from 1 January 1962 until becoming
sole chief of state 5 April 1 963)
head of government: Prime Minister TUILA''EPA
Sailele Malielegaoi (since 24 November 1998); note -
TUILA''EPA senred as deputy prime minister since
1992; he assumed the prime ministership in
November 1998 when former Prime Minister
TOFILAU Eti Alesana resigned in poor health; the post
of deputy prime minister is currently vacant
cabinet: Cabinet consists of 12 members, appointed
by the chief of state with the prime minister''s advice
elections: upon the death of Chief Susuga MALIETOA
Tanumafili II, a new chief of state will be elected by the
Legislative Assembly to serve a five-year term; prime
minister appointed by the chief of state with the
approval of the Legislative Assembly
Legislative branch: unicameral Legislative
Assembly or Fono (49 seats - 47 elected by Samoans,
2 elected by non-Samoans; only chiefs (matai) may
stand for election to the Fono; members serve
five-year terms)
elections: last held 26 April 1 996 (next to be held by
NA April 2001)
election results: percent of vote by party - HRPP
45.1 7%, SNDP 27.1%, independents 23.7%; seats by
party - HRPP 25, SNDP 13, independents 1 1
Judicial branch: Supreme Court; Court of Appeal
Political parties and leaders: Human Rights
Protection Party or HRPP [TUILA''EPA Sailele
Malielegaoi, chairman]; Samoa All People''s Party or
SAPP [Matatumua MAIMOAGAj; Samoan National
Development Party or SNDP [TAPUA Tamasese Efi,
chairman) (opposition); Samoan Progressive
Conservative Party [LEOTA Ituau Ale]
International organization participation: ACP,
AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO, ICFTU,
ICRM, IDA, IFAD, IFC, IFRCS, IMF, IMO, Intelsat
(nonsignatory user), IOC, ITU, OPCW, Sparteca,
SPC, SPF, UN, UNCTAD, UNESCO, UPU, WHO,
. WlPO, WMO
Diplomatic representation in the US:
chief of mission: Ambassador Tuiloma Neroni SLADE
chancery: 800 Second Avenue, Suite 400D, New
York, NY 10017
telephone: [1] (212) 599-6196, 6197
FAX; [1] (212) 599-0797
Diplomatic representation from the US:
chief of mission: Ambassador Carol MOSELEY
BRAUN (Ambassador to New Zealand and Samoa,
resides in Wellington, New Zealand)
embassy: 5th floor. Beach Road, Apia
mailing address: P. 0. Box 3430, Apia
telephone: [685] 21631
FAX: [685] 22030
Flag description: red with a blue rectangle in the
upper hoist-side quadrant bearing five white
five-pointed stars representing the Southern Cross
constellation','57d09d83d40b365ce2f4d3743e0ac239eea5825fda04b0109cfe268f289326e7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b2c41ecbe83d415d0cfdcf7ed358ce57ad986d7decfcd167348f960d66c9651',2000,'MY','Malaysia','introduction',423,'Background: In 1 91 8 the Slovenes joined the Serbs
and Croats in forming a new nation, renamed
Yugosiavia in 1929. After Worid War II, Slovenia
became a republic of the renewed Yugoslavia, which
though communist, distanced itself from Moscow''s
rule. Dissatisfied with the exercise of power of the
majority Serbs, the Slovenes succeeded in
establishing their independence in 1991 . Historical
ties to Western Europe make Slovenia a candidate for
future membership in the EU.','5a7bd1d7377a2c8b2a33a3b85f0ebedaf72d6615800f87164c09b778a820e65c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3adcc0392defab07eece7e104e4b7002e5c6bfde33803b3cf18d07da07cf80da',2000,'ZA','South Africa','introduction',434,'Background: A spring 2000 decision by the
International Hydrographic Organization delimited a
fifth world ocean from the southern portions of the
Atlantic Ocean, Indian Ocean, and Pacific Ocean. The
new ocean extends from the coast of Antarctica north
to 60 degrees south latitude which coincides with the
Antarctic Treaty Limit. The Southern Ocean is now the
fourth-largest of the world''s five oceans (after the
Pacific Ocean, Atlantic Ocean, and Indian Ocean but
larger than the Arctic Ocean).','03b61e656a15582527741611e15d48126b6730051cfd7f7d404fcb36066438b7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d3c35587786aa5ed4d400590fdc023b59ab77c025e598fd5b7eea732a21e49d',2000,'SR','Suriname','introduction',441,'Background: Independence from the Netherlands
was granted in 1975. Five years later the civilian
government was replaced by a military regime that
soon declared a socialist republic. It continued to rule
through a succession of nominally civilian
administrations until 1987, when international
pressure finally brought about a democratic election.','dccdbe8898e5e560c7cb355b43239cfe0101554a250bcfa2fed95e7c646f88db','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bff26bf133c147d4dff463ff815031cac64e6b8810f0be419d5502d0bfa501c',2000,'ZW','Zimbabwe','introduction',457,'Background: Shortly after independence,
Tanganyika and Zanzibar merged to form the nation of
Tanzania in 1964. One-party rule came to an end In
1995 with the first democratic elections held In the
country since the 1970s.
1^" . . '' . Ge''og''r''aphy
Location: Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,087 sq km
land: 886,037 sq km
water: 59,050 sq km
note: includes the Islands of Mafia, Pemba, and
Zanzibar
Area - comparative: slightly larger than twice the
size of California
Land boundaries:
total: 3,402 km
border countries: Burundi 451 km, Kenya 769 km,
Malawi 475 km, Mozambique 756 km, Rwanda 217
km, Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims:
exclusive economic zone: 200 nm
femfor/a/sea;12nm
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau;
highlands in north, south
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower, tin, phosphates,
iron ore, coal, diamonds, gemstones, gold, natural
gas, nickel
485
Tanzania (continued)
Land use;
arable land: 3%
permanent crops: tJo
permanent pastures: 40%
forests and woodland: 38%
other: 18% (1993 est.)
Irrigated land: 1,500 sq km (1993 est.)
Natural hazards: the tsetse fly; flooding on the
central plateau during the rainy season; drought
Environment - current issues: soli degradation;
deforestation; desertification; destruction of coral
reefs threatens marine habitats; recent droughts
affected marginal agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: Kilimanjaro is highest point in
Africa
Background: French Togoland became Togo in
1 960. Despite the facade of muitiparty ruie instituted in
the eariy 1990s, the government continues to be
dominated by the military, which has maintained its
power almost continuously since 1 967.
r Geography ~
Location: Western Africa, bordering the Bight of
Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area:
total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1 ,647 km
border countries: Benin 644 km, Burkina Faso 126
km, Ghana 877 km
I Coastline: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
Climate: tropical; hot, humid in south; semiarid in
north
Terrain: gently rolling savanna in north; central hills;
southern plateau; low coastal plain with extensive
lagoons and marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Agou 986 m
Natural resources: phosphates, limestone, marble,
arable land
Land use:
arable land: 38%
permanent crops: 7%
permanent pastures: 4%
forests and woodland: 17%
other: 34% (1993 est.)
Irrigated land: 70 sq km (1993 est.)
Natural hazards: hot, dry harmattan wind can
reduce visibility in north during winter; periodic
droughts
Environment - current issues: deforestation
attributable to slash-and-burn agriculture and the use
of wood for fuel; recent droughts affecting agriculture
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
I: People
Population: 5,018,502
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would othemvise be
expected (July 2000 est.)
Age structure:
0-14years:A6% (male 1,161,610; female 1,153,877)
15-64 years: 51 % (male 1 ,254,437; female
1,327,306)
65 years and over: 3% (male 53,101; female 68,171)
(2000 est.)
Population growth rate: 2.7% (2000 est.)
Birth rate: 38.02 births/1 ,000 population (2000 est.)
Death rate: 11.18 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.16 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 71 .55 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 54.69 years
male: 52.75 years
female: 56.7 years (2000 est.)
Total fertility rate: 5.5 children born/woman
(2000 est.)
Nationality:
noun: Togolese (singular and plural)
ady''ecf/ve.’Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 70%, Christian 20%,
Muslim 10%
Languages: French (official and the language of
commerce). Ewe and Mina (the two major African
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 51 .7%
male: 67%
female: 37% (1995 est.)
i Government
Country name:
conventional long form; Togolese Republic
conventional short form: Togo
local long form: Republique Togolaise
local short form: none
former: French Togoland
Data code: TC
Government type: republic under transition to
multiparty democratic rule
Capital: Lome
Administrative divisions: 5 regions (regions,
singular - region); De La Kara, Des Plateaux, Des
Savanes, Du Centre, Maritime
Independence: 27 April 1960 (from
French-administered UN trusteeship)
National holiday: Independence Day, 27 April
(1960)
Constitution: multiparty draft constitution approved
by High Council of the Republic Uuly 1 992; adopted
by public referendum 27 September 1992
Legal system: French-based court system
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: President Gen. Gnassingbe EYADEMA
(since 14 April 1967)
head of government: Prime Minister Eugene Koffi
ADOBOLI (since NA May 1999)
cabinet: Council of Ministers appointed by the
president and the prime minister
elections: president elected by popular vote for a
five-year term; election last held 21 June 1 998 (next to
be held NA 2003); prime minister appointed by the
president
491
Togo (continued)
election results: Gnassingbe EYADEMA reelected
president; percent of vote - Gnassingbe EYADEMA
52.13%, Gilchrist OLYMPIO 34.12%, other 13.75%
Legislative branch; unicameral National Assembly
(81 seats; members are elected by popular vote to
serve five-year terms)
elections: last held 21 March 1999 (next due to be
held NA2004)
election results: percent of vote by party - NA; seats
by party - RPT 77, independents 2, vacant 2
note; Togo''s main opposition parties boycotted the
election because of EYADEMA''s alleged
manipulation of 1 998 presidential polling; since March
of 1999, opposition parties have entered into
negotiations with the president over the establishment
of an independent electoral commission and a new
round of legislative elections for sometime in 2000
Judicial branch: Court of Appeal or Cour d'' Appel;
Supreme Court or Cour Supreme
Political parties and leaders: Action Committee for
Renewal or CAR [Yawovi AGBOYIBO]; Coordination
des Forces Nouvelles or CFN [Joseph KOFFIGOH];
Democratic Convention of African Peoples or CDPA
[Leopold GNININVI]; Party for Democracy and
Renewal or PDR [Zarifou AYEVA]; Patriotic
Pan-African Convergence or CPP [Edem KODJO);
Rally of the Togolese People or RPT [President Gen.
Gnassingbe EYADEMA]; Union of Forces for Change
or UFC [Gilchrist OLYMPIO (in exile), Jeane-Pierre
FABRE, general secretary in Togo]; Union of
Independent Liberals or ULI [Jacques AMOUZO]
note: Rally of the Togolese People or RPT, led by
President EYADEMA, was the only party until the
formation of multiple parties was legalized 12 April
1991
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, Entente, FAO, FZ,
G-77, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, IFAD,
IFC, IFRCS, ILO, IMF, IMO, Intelsat, Interpol, IOC,
ITU, MINURSO, MIPONUH, NAM, OAU, OIC, OPCW,
UN, UNCTAD, UNESCO, UNIDO, UPU, WADB,
WAEMU, WCL, WFTU, WHO, WlPO, WMO, WToO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Akoussoulelov
BODJONA
chancery: 2208 Massachusetts Avenue NW,
Washington, DC 20008
fe/eptone;[1](202) 234-4212
FAX; [1] (202) 232-3190
Diplomatic representation from the US;
chief of mission: Ambassador Brenda Brown
SCHOONOVER
embassy: Rue Pelletier Caventou and Rue Vauban,
Lome
mailing address: B. P. 852, Lome
telephone: [228] 21 77 17, 21 29 91 through 21 29 94
FAX; [228] 21 79 52
Flag description: five equal horizontal bands of
green (top and bottom) alternating with yellow; there is
a white five-pointed star on a red square in the upper
hoist-side corner; uses the popular pan-African colors
of Ethiopia
E c 0 n 0 m y
Economy - overview: This small sub-Saharan
economy is heavily dependent on both commercial
and subsistence agriculture, which provides
employment for 65% of the labor force. Cocoa, coffee,
and cotton together generate about 30% of export
earnings. Togo is self-sufficient in basic foodstuffs
when harvests are normal, with occasional regional
supply difficulties. In the industrial sector, phosphate
mining is by far the most important activity, although it
has suffered from the collapse of world phosphate
prices and increased foreign competition. Togo
serves as a regional commercial and trade center.
The government''s decade-long effort, supported by
the World Bank and the IMF, to implement economic
reform measures, encourage foreign investment, and
bring revenues in line with expenditures has stalled.
Political unrest, including private and public sector
strikes throughout 1992 and 1993, jeopardized the
reform program, shrunk the tax base, and disrupted
vital economic activity. The 12 January 1994
devaluation of the currency by 50% provided an
important impetus to renewed structural adjustment;
these efforts were facilitated by the end of strife in
1994 and a return to overt political calm. Progress
depends on following through on privatization,
increased openness in government financial
operations (to accommodate increased social service
outlays), and possible downsizing of the military, on
which the regime has depended to stay in place. Lack
of aid, along with depressed cocoa prices, generated
a 1% fall in GDP in 1998, with growth resuming in
1999. Assuming no deterioration of the political
atmosphere, growth should rise to 5% a year in
2000-01.
GDP: purchasing power parity - $8.6 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita; purchasing power parity - $1 ,700
(1999 est.)
GDP - composition by sector:
agriculture: 42%
industry: 21%
services: 37% (1997)
Population below poverty line: 32% (1987-89 est.)
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (1999 est.)
Labor force: 1 .538 million (1 993 est.)
Labor force - by occupation: agriculture 65%,
industry 5%, services 30% (1998 est.)
Unemployment rate; NA%
Budget:
revenues: $232 million
expenditures: $252 million, including capital
expenditures of $NA (1997 est.)
Industries: phosphate mining, agricultural
processing, cement; handicrafts, textiles, beverages
Industrial production growth rate: NA%
Electricity - production: 90 million kWh (1998)
Electricity - production by source:
fossil fuel: 93.33%
hydro; 6.67%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 434 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 350 million kWh (1998)
note: imports electricity from Ghana
Agriculture - products: coffee, cocoa, cotton,
yams, cassava (tapioca), corn, beans, rice, millet,
sorghum; livestock; fish
Exports: $400 million (f.o.b., 1999)
Exports - commodities: cotton, phosphates,
coffee, cocoa
Exports - partners: Canada, Philippines, Ghana,
France (1998)
Imports: $450 million (f.o.b., 1999)
Imports - commodities: machinery and equipment,
foodstuffs, petroleum products
Imports - partners: Ghana, France, Cote d''Ivoire,
China (1998)
Debt - external: $1 .3 billion (1 997)
Economic aid - recipient: $201.1 million (1995)
Currency: 1 CommunauteFinanciereAfricaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
615.70 (1999) 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
note: since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year','2e38fa440d8a759422d7f8df95267f607bb7d79d0de7f59c711c5ef2ae554617','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9670994a8e24e3593b22018aa2c7ff143e7b324a6c5dd640dac251cbe7d99184',2000,'TO','Tonga','introduction',463,'Background: The archipelago of "The Friendly
Islands" was united into a Polynesian kingdom in
1845. It became a constitutional monarchy in 1875
and a British protectorate in 1900. Tonga acquired its
independence in 1 970 and became a member of the
Commonwealth of Nations. It remains the only
monarchy in the Pacific.','5fea385bfda2649bbb5cdf3e7bea4db064b5d655e7d3075ec04cb7bf5a685cff','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e17fa71810dd62ef36cb30e6f75ec66e1bb0675cf53b02fffb00de4445723f',2000,'VU','Vanuatu','introduction',477,'Background; Venezuela was one of the three
countries that emerged from the collapse of Gran
Colombia in 1830 (the others being Colombia and
Ecuador). For most of the first half of the 20th century,
Venezuela was ruled by generally benevolent military
strongmen, who promoted the oil industry and allowed
for some social reforms. Democratically elected
governments have held sway since 1959. Current
concerns include: drug-related conflicts along the
Colombian border, increasing internal drug
consumption, overdependence on the petroleum
industry with its price fluctuations, and irresponsible
mining operations which are endangering the rain
forest and indigenous peoples.
. “GVogTapTy
Location; Northern South America, bordering the
Caribbean Sea and the North Atlantic Ocean,
between Colombia and Guyana
Geographic coordinates; 8 00 N, 66 00 W
Map references; South America, Central America
and the Caribbean
Area;
fofa/;912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area - comparative; slightly more than twice the
size of California
Land boundaries;
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050
km, Guyana 743 km
Coastline; 2,800 km
Maritime claims;
contiguous zone: 1 5 nm •
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; tropical; hot, humid; more moderate in
highlands
Terrain; Andes Mountains and Maracaibo Lowlands
in northwest; central plains (llanos); Guiana Highlands
in southeast
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Natural resources; petroleum, natural gas, iron ore,
gold, bauxite, other minerals, hydropower, diamonds
Land use;
arable land: 4%
permanent crops: tVo
permanent pastures: 20%
forests and woodland: 34%
of/7er;41%(1993 est.)
Irrigated land; 1 ,900 sq km (1993 est.)
Natural hazards; subject to floods, rockslides, mud
slides; periodic droughts
Environment - current issues; sewage pollution of
Lago de Valencia; oil and urban pollution of Lago de
Maracaibo; deforestation; soil degradation; urban and
industrial pollution, especially along the Caribbean
coast
Environment - international agreements;
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Marine Dumping
Geography - note; on major sea and air routes
linking North and South America
f e
Population; 23,542,649 (July 2000 est.)
Age structure;
0-14 years: 33% (male 3,967,544; female 3,721 ,658)
15-64 years: 63% (male 7,406,086; female
7,355,923)
65 years and over: 4% (male 499, 1 02; female
592,336) (2000 est.)
Population growth rate; 1.6% (2000 est.)
Birth rate; 21 .09 births/1 ,000 population (2000 est.)
Death rate; 4.94 deaths/1 ,000 population
(2000 est.)
Net migration rate; -0.19 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate: 26.17 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73.07 years
ma/e; 70.05 years
female: 76.31 years (2000 est.)
Total fertility rate: 2.51 children born/woman
(2000 est.)
Nationality;
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab,
German, African, indigenous people
Religions: nominally Roman Catholic 96%,
Protestant 2%
Languages: Spanish (official), numerous indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 91 .8%
fema/e;90.3% (1995 est.)
F™ 0 V e r n ni ’e ri t
Country name;
conventional long form: Bolivarian Republic of
Venezuela
conventional short form: Venezuela
local long form: Republics Bolivariana de Venezuela
local short form: Venezuela
Data code: VE
Government type: federal republic
Capital: Caracas
Administrative divisions; 23 states (estados,
singular - estado),1 federal district* (distrito federal),
and 1 federal dependency** (dependencia federal);
Amazonas, Anzoategui, Apure, Aragua, Barinas,
Bolivar, Carabobo, Cojedes, Delta Amacuro,
Dependencias Federates**, Distrito Federal*, Falcon,
Guarico, Lara, Merida, Miranda, Monagas, Nueva
Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas,
Yaracuy, Zulia
note: the federal dependency consists of 1 1 federally
controlled island groups with a total of 72 individual
islands
Independence: 5 July 181 1 (from Spain)
National holiday: Independence Day, 5 July (1811)
Constitution: 30 December 1999
Legal system: based on organic laws as of July
1999; open, adversarial court system; has not
accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Hugo CHAVEZ Frias (since 3
February 1999); note - the president is both the chief
of state and head of government
head of government: President Hugo CHAVEZ Frias
(since 3 February 1999); note - the president is both
the chief of state and head of government
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
six-year term; election last held 6 December 1998
(next to be held 28 May 2000 under new constitution)
election results: Hugo CHAVEZ Frias elected
president; percent of vote - 57%
note: government coalition - Patriotic Pole or Polo
Patriotico consists of MVR, MAS, and PPT
531
Venezuela (continued)
Legislative branch: unicameral National Assembly
or Asamblea Nacional; under the 1999 constitution,
the bicameral Congress of the Republic has been
replaced by a unicameral National Assembly; the total
number of seats in the new National Assembly has not
yet been determined, but members will be elected by
popular vote to serve five-year terms; three seats will
be reserved for the indigenous peoples of Venezuela
elections: election for deputies to the new National
Assembly are scheduled to be held in May 2000
election results: NA; elections to be held in May 2000
Judicial branch: Supreme Tribunal of Justice or
Tribuna Suprema de Justicia, magistrates are elected
by the National Assembly for a single 12-year term
Political parties and leaders: Democratic Action or
AD [leader NA]; Fifth Republic Movement or MVR
[leader NA]; Homeland for All or PPT [leader NA];
Movement Toward Socialism or MAS [leader NA];
National Convergence or Convergencia [leader NA];
Radical Cause or La Causa R [leader NA]; Social
Christian Party or COPEi [ieader NA]
Political pressure groups and leaders:
FEDECAMARAS, a conservative business group;
VECiNOS groups; Venezuelan Confederation of
Workers or CTV (labor organization dominated by the
Democratic Action)
International organization participation: CAN,
Caricom (observer), CCC, CDS, ECLAC, FAO, G- 3,
G-11, G-15, G-19, G-24, G-77, lADB, IAEA, IBRD,
ICAO, ICC, ICFTU, ICRM, IFAD, IFC, IFRCS, IHO,
ILO, IMF, IMO, Intelsat, Interpol, IOC, lOM, ISO, ITU,
LAES, LAIA, MINURSO, NAM, OAS, OPANAL,
OPCW, OPEC, PCA, RG, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNIKOM, UNU, UPU, WCL, WFTU,
WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Alfredo TORO Hardy
chancery: 1099 30th Street NW, Washington, DC
20007
fe/eptone;[1] (202) 342-2214
FAX; [1] (202) 342-6820
consulate(s) general: Boston, Chicago, Houston,
Miami, New Orleans, New York, San Francisco, and
San Juan (Puerto Rico)
Diplomatic representation from the US:
c/j/efofrrr/ss/on; Ambassador John Francis MAISTO
embassy: Calle F con Caile Suapure, Colinas de Valle
Arriba, Caracas 1060
mailing address: P. 0. Box 62291 , Caracas 1060-A;
APO AA 34037
fe/eptorre; [58] (2) 975-6411
FAX; [58] (2) 975-6710
Flag description; three equal horizontal bands of
yellow (top), blue, and red with the coat of arms on the
hoist side of the yellow band and an arc of seven white
five-pointed stars centered in the blue band
I Economy
Economy - overview: Venezuelan officials estimate
the economy contracted 7.2% in 1999. A steep
downturn in international oil prices during the first half
of the year fueled the recession, and spurred the
CHAVEZ administration to abide by OPEC-led
production cuts in an effort to raise world oil prices.
The petroleum sector dominates the economy,
accounting for roughly a third of GDP, around 80% of
export earnings, and more than half of government
operating revenues. Higher oil prices during the
second half 1999 took pressure off the budget and
currency; the bolivar is widely believed to be
overvaiued by as much as 50%. Despite higher oil
prices, the economy remains in the doldrums,
possibly due to investor uncertainty over President
CHAVEZ''S reform agenda. Implementing legislation
for the new constitution will not be passed until the
second half of 2000, after a new legislature is elected.
With the president''s economic cabinet attempting to
reconcile a wide range of views, the country''s
economic reform program has largely stalled. The
government is seeking international assistance to
finance reconstruction after massive flooding and
landslides in December 1999 caused an estimated
$15 billion to $20 billion in damage.
GDP: purchasing power parity - $182.8 billion
(1999 est.)
GDP ■ real growth rate: -7.2% (1999 est.)
GDP - per capita: purchasing power parity - $8,000
(1999 est.)
GDP • composition by sector:
agriculture: 4%
industry: 63%
services: 33% (1997 est.)
Population beiow poverty line: 67% (1997 est.)
Household income or consumption by percentage
share:
lowest 10%; 1.5%
highest 10%; 35.6% (1995)
Inflation rate (consumer prices); 20% (1999)
Labor force: 9.9 million (1999)
Labor force - by occupation: services 64%,
industry 23%, agriculture 13% (1997 est.)
Unemployment rate: 18% (1999 est.)
Budget:
revenues: $26.4 billion
expenditures: $27 billion, including capital
expenditures of $NA (2000 est.)
Industries: petroleum, iron ore mining, construction
materials, food processing, textiies, steel, aluminum,
motor vehicle assembly
Industrial production growth rate: 0.5%
(1995 est.)
Electricity - production: 70.39 billion kWh (1998)
Electricity - production by source:
fossil fuel: 25.46%
hydro; 74.54%
nuclear: 0%
other:
Electricity - consumption: 65.463 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: corn, sorghum, sugarcane,
rice, bananas, vegetables, coffee; beef, pork, milk,
eggs; fish
Exports: $20.9 billion (f.o.b., 1999)
Exports - commodities: petroleum, bauxite and
aluminum, steel, chemicals, agricultural products,
basic manufactures (1998)
Exports - partners: US and Puerto Rico 57%,
Colombia, Brazil, Japan, Germany, Netherlands, Italy
(1999)
Imports: $11.8 billion (f.o.b., 1999)
Imports - commodities: raw materials, machinery
and equipment, transport equipment, construction
materials (1999)
Imports - partners: US 53%, Japan, Colombia,
Italy, Germany, France, Brazil, Canada (1999)
Debt -external: $32 billion (1999)
Economic aid - recipient: $35 million with more
assistance iikely as a result of flooding (1999)
Currency: 1 bolivar (Bs) = 100 centimes
Exchange rates: bolivares (Bs) per US$1 - 652.333
(January 2000), 605.717 (1999), 547.556 (1998),
488.635 (1997), 417.333 (1996), 176.843 (1995)
Fiscal year: calendar year
I Communications
Telephones - main lines in use; 2.6 million (1998)
Telephones - mobile cellular; 2 million (1998)
Telephone system; modern and expanding
domestic: domestic satellite system with 3 earth
stations; recent substantial improvement in telephone
service in rural areas; substantial increase in
digitalization of exchanges and trunk lines; installation
of a national inter-urban fiber-optic network capable of
digital multimedia services
international: 3 submarine coaxial cables; satellite
earth stations - 1 1ntelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador,
Peru, and Bolivia in the construction of an
international fiber-optic network
Radio broadcast stations: AM 201 , FM NA (20 in
Caracas), shortwave 11 (1998)
Radios: 10.75 million (1997)
Television broadcast stations; 66 (plus 45
repeaters) (1997)
Televisions: 4.1 million (1997)
Internet Service Providers (ISPs): 1 1 (1 999)','8ef9dd6cca49c82133ad31f66057b1f691abc4ad04c06a3391db4a6244218837','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b8b8eb2ddf5e5ca06b2184adbd08e4cdfe3c0135cba8e7f07814450ea61cb38',2000,'SO','Somalia','introduction',493,'Background: The territory of Northern Rhodesia
was administered by the South Africa Company from
1891 untii takeover by the UK in 1923. During the
1920s and 1930s, advances in mining spurred
deveiopment and immigration. The name was
changed to Zambia upon independence in 1964. in
the 1980s and 1990s, declining copper prices and a
prolonged drought hurt the economy. Elections in
1 991 brought an end to one-party rule, but the
subsequent vote in 1996 saw blatant harassment of
opposition parties.
I '' " G e''o ’g r a p"h y
Location: Southern Africa, east of Angola
Geographic coordinates: 15 00 S, 30 00 E
Map references: Africa
Area:
fofa/;752,614sq km
land: 740,724 sq km
water: 1 1 ,890 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1,110 km. Democratic
Republic of the Congo 1,930 km, Malawi 837 km,
Mozambique 419 km, Namibia 233 km, Tanzania 338
km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; modified by altitude; rainy season
(October to April)
Terrain: mostly high plateau with some hills and
mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: unnamed location in Mafinga Hills
2,301 m
Natural resources: copper, cobalt, zinc, lead, coal,
emeralds, gold, silver, uranium, hydropower
Land use:
arable land: 7% ■
permanent crops: 0%
permanent pastures: 40%
forests and woodland: 39%
of/?er;14%(1993 est.)
Irrigated land: 460 sq km (1993 est.)
Natural hazards: tropical storms (November to
April)
Environment - current issues: air pollution and
resulting acid rain in the mineral extraction and
refining region; poaching seriously threatens
rhinoceros and elephant populations; deforestation;
soil erosion; desertification; lack of adequate water
treatment presents human health risks
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: landlocked
I pTo pie
Population: 9,582,418
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 48% (male 2,290,559; female 2,270,945)
15-64 years: 50% (male 2,369,317; female
2,413,070)
65 years and oven 2% (male 105,443; female
133,084) (2000 est.)
Population growth rate: 1.95% (2000 est.)
Birth rate: 41 .9 births/1 ,000 population (2000 est.)
Death rate: 22.08 deaths/1,000 population
(2000 est.)
Net migration rate: -0.33 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.99 male(s)4emale (2000 est.)
Infant mortality rate: 92.38 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 37.24 years
male: 37.08 years
female: 37.41 years (2000 est.)
Total fertility rate: 5.62 children born/woman
(2000 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1.1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars -
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 1 5 and over can read and write English
total population: 78.2%
male: 85.6%
female: 71 .3% (1 995 est.)
f Government
Country name:
conventional long form: Republic of Zambia
conventional short form: Zambia
former: Northern Rhodesia
Data code: ZA
Government type: republic
Capital: Lusaka
Administrative divisions: 9 provinces; Central,
Copperbelt, Eastern, Luapula, Lusaka, Northern,
North-Western, Southern, Western
Independence: 24 October 1964 (from UK)
National holiday: Independence Day, 24 October
(1964)
Constitution: 2 August 1991
Legal system: based on English common law and
customary law; judicial review of legislative acts in an
ad hoc constitutional council; has not accepted
compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Frederick CHILUBA (since 2
November 1991); Vice President Christen TEMBO
(since 2 December 1 997); note - the president is both
the chief of state and head of government
head of government: President Frederick CHILUBA
(since 2 November 1991); Vice President Christen
TEMBO (since 2 December 1997); note - the
president is both the chief of state and head of','625e411e02f443d8c859af70fcd38f63d63cfb9ecce98cced6f404f3bfc0bf0a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a8f2984f47a00fa1ab94618290582ca37bc2f2b81bccce1155574bbb626775b',2000,'UY','Uruguay','space',512,'100
tons, gross register
cubic meters of permanently
enclosed space
2.831 684 7
tons, long (deadweight)
avoirdupois ounces
35,840
tons, long (deadweight)
avoirdupois pounds
2,240
tons, long (deadweight)
kilograms
1,016.046 909 8
tons, long (deadweight)
long hundredweights
20
tons, long (deadweight)
metric tons
1.016 046 908 8
tons, long (deadweight)
short hundredweights
22.4
tons, long (deadweight)
short tons
1.12
tons, metric
avoirdupois pounds
2,204.623
tons, metric
kilograms
1,000
tons, metric
long hundredweights
19.684130 3
tons, metric
long tons
0.984 206 5
tons, metric
quintals
10
tons, metric
short hundredweights
22.046 23
tons, metric
short tons
1.102 311 3
tons, metric
troy ounces
32,150.75
tons, net register
cubic feet of permanently enclosed
space for cargo and passengers
100
tons, net register
cubic meters of permanently enclosed
space for cargo and passengers
2.831 684 7
tons, shipping
cubic feet of permanently enclosed
cargo space
42
636
Appendix E: Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply By
tons, shipping
cubic meters of permanently
enclosed cargo space
1.189 307 574
tons, short
avoirdupois pounds
2,000
tons, short
kilograms
907.184 74
tons, short
long hundredweights
17.857 14
tons, short
long tons
0.892 857 1
tons, short
metric tons
0.907 184 74
tons, short
short hundredweights
20
townships (US)
sections
36
townships (US)
square kilometers
93.239 572
townships (US)
square statute miles
36
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
square feet
27,878,400
miles, square statute
square meters
2,589,988.110 336
miles, square statute
square yards
3,097,600
yards
centimeters
91.44
yards
feet
3
yards
inches
36
yards
meters
0.9144
yards
miles
0.000 56818
yards, cubic
bushels
21.696 227
yards, cubic
cubic feet
27
yards, cubic
cubic inches
46,656
yards, cubic
cubic meters
0.764 554 857 984
yards, cubic
gallons
201.974 0
yards, cubic
liters
764.554 857984
yards, cubic
pecks
86.784 91
yards, square
acres
0.000 206 611 6
yards, square
hectares
0.000083 612 736
yards, square
square centimeters
8,361.273 6
yards, square
square feet
9
yards, square
square inches
1,296
yards, square
square meters
0.836127 36
yards, square
square miles
0.000000 322 8306
Note: At this time, oniy three countries - Burma, Liberia, and the US - have not adopted the International System of Units
(SI, or metric system) as their official system of weights and measures. Although use of the metric system has been
sanctioned by law in the US since 1866, it has been slow In displacing the American adaptation of the British Imperial
System known as the US Customary System. The US is the only Industrialized nation that does not mainly use the metric
system in its commercial and standards activities, but there is increasing acceptance in science, medicine, government, and
many sectors of industry.
637
Appendix F:
Cross-Reference List of Country Data Codes
FIPS 1 0-4: Countries, Dependencies, Areas of Special Sovereignty, and Their Principal Administrative Divisions (FiPS PUB 10-4) is
maintained by the Office of the Geographer and Giobai issues (Department of State) and pubiished by the National Institute
of Standards and Technology (Department of Commerce). These two-character alphabetic codes are included in the text of
the Factbook in the Data code entry under the Government category. FIPS 1 0-4 codes are intended for general use
throughout the US Government, especially in activities associated with the mission of the Department of State and national
defense programs.
ISO 31 66: Codes for the Representation of Names of Countries (ISO 3166) is prepared by the International Organization for
Standardization. ISO 31 66 includes two- and three-character alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with international organizations that have adopted that standard. Except for
the numeric codes, ISO 31 66 codes have been adopted in the US as FIPS 1 04-1 : American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of Special Sovereignty for Information interchange.
Internet;
This is a provisional compilation that generally agrees with the ISO 3166 two-character alphabetic codes.
Entity
FIPS 10-4
ISO 3166
Internet
Comment
UY
UY
URY
858
UY
I
Appendix F; Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
5611 W
Montreal [US Consulate General, US Mission to the
International Civil Aviation Organization (ICAO)]','ab55994b6849c774ce2ec1ca46154d90d926c6e5794e89124120a6a86f9f1edd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('201010cad1fc75896fe37f52c47ecbf754bafd44fe3824ea8643f23351a44f0e',2000,'AF','Afghanistan','space',513,'AF
AF
AFG
004
AF
34 31 N
6912E
Kaduna
37 00N
73 OOE
Valletta [US Embassy]
37 00N
73 OOE
675
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Wales [region]','2d477b8daf45d357098b7fd07bfbe1ee778b2880d035c79e64a46c240efef765','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94af84f11593cd4ac59f6f8b700796b72d4ae5bdcca747f4f46d2ca9ca3a3b5',2000,'AL','Albania','space',514,'AL
AL
ALB
008
AL
41 20 N
19 50E
Tirane (see Tirana)
41 20 N
19 50E
Tirol [region]
Austria, Italy
47 00 N
11 00 E
Tobago [island]','6274645b8b400620a5ebb8851da6a347755d03a699783470381e4faec4f05ddc','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b18d31badd1270d95007f598f858218dd9415950f30f542a208954d7af82947',2000,'DZ','Algeria','space',515,'AG
DZ
DZA
012
DZ
3647N
2 03E
AIhucemas, Penon de
35 43N
043W
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Oranjestad Aruba 12 33N 7006W
Oresund (The Sound)
Atlantic Ocean
12 40E
Orkney Islands','3b866419bd7b6ad2365d79b44f59c13fe78fc03a1129380062f2654d1765c8d2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3efed9b5e2aebcf301269e73528e52aa467886f9673f3bb1025b4da4fbf19dbc',2000,'AS','American Samoa','space',516,'AQ
AS
ASM
016
AS
1420 S
170 00 W
Edinburgh [US Consulate General]
1413S
169 35 W
Maputo [US Embassy]
1416S
170 42 W
Palawan [island]
1103S
171 15W
Swan Islands
1418S
170 42 W
Tyrol, South [region]','4f0da5d025651bd9a85faffa2667648336221e31397790062bee0148bb340c60','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a772d5e41382d9159f75e9839b1aa5afb860bd835fd22244ceef35f014e7eb0',2000,'AO','Angola','space',517,'AO
AO
AGO
024
AO
5 33S
1212E
Cabot Strait
Atlantic Ocean
4720N
59 30W
Caicos Islands
8 48S
1314E
Lubumbashi
Democratic Republic of the Congo
11 40 S
2728E
Lusaka [US Embassy]','4684a01660bde7a8ca6276f200e6d0ada9ac73deb2028cd0fc917de626ceb271','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9d8280b0bd74692ab6b01ccc93ccc6aab92cc087ec9cbc87a36a52db082f02c',2000,'AQ','Antarctica','space',518,'AY
AQ
ATA
010
AQ
ISO defines as the territory south of 60
degrees south latitude
66 30S
139 00 E
Aden
71 00 S
7000W
Alexandria
67 DOS
163 00 E
Balochistan [region]
49 30W
Berlin [US Branch Office]
62 56S
60 34W
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Denmark Strait Atiantic Ocean 67 00 N 24 00 W
D''Entrecasteaux Islands
Papua New/ Guinea
9 30S
150 40 E
Desolation Islands (Isles Kerguelen)
French Southern and Antarctic Lands
69 30 E
Devils Island (He du Diable)
68 48S
9035W
Philip Isiand
7330S
12 00E
Quemoy [island]
Taiwan
24 27N
11823E
Quito [US Embassy]
79 30 S
162 00 W
Roseau
80 00 S
180 00 E
Ross Island
81 30 S
175 00 W
Ross Sea
Antarctica, Southern Ocean
76 00S
175 00 W
Rota [island]
179 55 W
Senyavin Islands
Federated States of Micronesia
158 00 E
Seoul [US Embassy]
South Korea
37 34N
127 00 E
61 00 S
45 00W
South Ossetia [region]
62 00S
59 00W
South Tyrol [region]
66 30 S
139 00 E
Thailand, Gulf of
Pacific Ocean
10 00N
101 00 E
Thessaloniki [US Consulate General]
99 00 W
Tiberias, Lake','7eefc0ee876cf6af86e68c92e5350084340c307020d30e1c75677c8cf60434c5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31180f82c1a1f8b26492db1b93ebea537ba77aa1f013252b45702d484b935285',2000,'AG','Antigua and Barbuda','space',519,'AC
AG
ATG
028
AG
14 34N
90 44W
Antipodes Islands
1738N
6148W
Barcelona [US Consulate General]
1655N
6219W
Red Sea
Indian Qcean
20 00N
38 00E
Revillagigedo Island
61 51 W
Saint Lawrence, Gulf of
Atlantic Ocean
48 00N
62 00W
Saint Lawrence Island','e152a09cb20a9ec1aa2747204843eb48475c6e8a99fba15e03e0c6bdfdb7f179','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66c57459452f8b501bca05563b8654cb1e5166baaa34a6c74170728b17a1e542',2000,'AR','Argentina','space',520,'AR
AR
ARG
032
AR
3436S
5827W
Bujumbura [US Embassy]
35 00N
63 00 W
Panama [US Embassy]','f8491232e30e9ce258c532430f604c09a4672be49966629148a5d7ae5a39b738','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('068330762cd5a15a0793762328f1e5968c5a5d26658e98a5e5129061143eda28',2000,'AW','Aruba','space',521,'AA
AW
ABW
533
AW
Ashmore and Cartier Islands
AT
—
—
—
—
ISO includes with Australia
.Mcth. Antilles
.WWW y* . utiaoeioupe irv
r: (B.S.) / ^
Montserrat fDOMirilCA
<”■*■1 vgrttalque (ni.)
ST. VmCEMTAMD *811 UJCIA
irfeoREMADiNES* Uearbados
IBarranquIlla
COSTA RIC^
Isla del Coco
(COSTA RICA)
, ^Bogota
''.COLOMBIA^
t -of-Spatn
^ niDAD AUD
rOBAQO
l^eorgetown
l^^^^ramaribo
French Quiana
n (FKATICE)
ISLANDS
(ECUADOR)
Arqulpilago de
Fernando de Noronha \\
(BRAZIL) 1','25978fa3767e944cea84bad35e6520461c96008d08dd91918f1f09763b1c573c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afbfc4f8ddce50c6e15c209b072d9d79caf0704c8378da5ddfb787dc1582c547',2000,'AU','Australia','space',522,'AS
AU
AUS
036
AU
ISO includes Ashmore and Cartier
Islands, Coral Sea Islands
1012S
142 16 E
Banks Island
27 28S
153 02 E
Britain (see Great Britain)
3517S
149 08 E
Canton (Guangzhou)
2315S
155 32 E
Caucasus [region]
Russia
42 00N
45 00E
Cayenne
10 25S
105 39 E
Christmas Island (Kiritimati) [Pacific Ocean]
31 30 S
159 00 E
Louisiade Archipelago
30 07 S
147 24 E
Maddalena, Isola
3749S
144 58 E
Mellila
31 56 S
115 50 E
Pescadores [islands]
Taiwan
23 30 N
119 30 E
Peshawar [US Consulate]
33 52S
151 13 E
T Tahiti [island]
43 00S
147 00 E
Tasman Sea
Pacific Ocean
430S
168 00 E
Taymyr Peninsula (Poluostrov Taymyr)
Russia
76 00 N
104 00 E
Tbilisi [US Embassy]
802696AI (R02106) 4-00
120 ^ 110
’ Edmonton /
C A
D A
Wasl/ingJon
Norlh |jo.l<o{n
South Ipakot.i
lacramento /^Carson Clty''~ — -
^ ® /\\ Nevada
yCal/fornia \\ /
\\ / \\as Vegas
Vv "''v''-''
y**- N^Los Angeles \\
/ • \\ \\ A Arizona
Wyonting
^C^eyenne j
Denver
Colorado
fowa
Nef; raska \\ ®
Lincoln^ 1 Des Moines
Phoenix I NewMoxifO
''*©1 1 iMtrhie^ \\ Albany\\j''''''''*i!^*°"
XW''iscUn, i / l^NewYorli ^fe^dence
- A Madison / Vlans^g — '' — \\ '' A
''''v-t;; - 1 / f*^’^^''isvlvania
va Apicago^i - I i PhlladelpwW%p»-^ - \\
Moines C \\ I Indiana! ^ \\
~~'' Y niinot^ 1. - ^ A CoImn^5-^\\viju^''''^*''''''"^^ \\
D.C. \\
® “1 / y% M
Jefferson Cit^ Frankfort \\
Missouri l\\^-4 ''~''''T~"^^ttale^l^yj
_ - — .1 ^ - @Nashvllle Norih\\Caro!ina
1 I Indiana!
Oklahoma City Arkansas
■ / Tennessee
< Memphis _ _ —
,A,..mSvSouiM
Ceegia
North
Atbintic
® State c^pitSl A .Heposnio
Scale 1:27,000,000 \\ /
I Albers Equal-Area Projection \\j
standard parallels 28‘^30''N''and 45®j6''iS
/ 0 500 Kilomete^ (r j /
/ I- ^ ''■ - r-^N / S
/ 0 V500 Miles
Lord Howe
Island
(AUSTL.)
SOUTH
PACIFIC
OCEA,N
KERMADEC
ISLANDS
(rt.z.)
Canberra ^
(Jreat AustnlUn
Bight
Tasman Sea
HEW
ZEALAHD''
^ Wellington
/CHATHAM ISLANDS
(H.Z.)
SNARES ISLANDS
(«.Z.)
AUCIOAND
ISLANDS ^
yBOUNTY ISLANDS
/ <«.zo
riPODES ISLANDS y
(MX) /
Macquarie
Island
(AUSTL.)
lERN OCEAN
Antarctic.Circle (66°33'')
April 2000
April 2000
Alegre
(S)
TRISTAN DA CUNHA (St. Helena)
Cough Island
• (St. Helena)
South Georgia and the
South Sandwich Island^
(administered by U.K.,
claimed by ARQErmriA)
.0U7H ORKNEY
ISLANDS
(AUSTL.r
r rv I r j L.
Lord Horn
'' island .
(Aum.)
OCEAN -
KERMADEC
ISLANDS
<ri.z.)
(Treat Australian
Bigkt
i Adelaide Canberra^
Tasman Sea
nEW
ZEALATID*
^Wellington
/CHATHAM ISLANDS
(ri.z.)
SNARES ISLANDS
(M.Z.)
AUCKLAND
ISLANDS ✓
(ri.z.)
/OUNTY ISLANDS
(Pi.Z.)
TIPODES ISLANDS y
(n.Z.) /
Macquarie
Island
(AUSTL.)
CEAN
Antarctic.Circle (66‘^3'')
April 2000
Ro55 5ea
^Serbia and Montenegro have asserted the formation
of a joint independent state, but this entity has
not been formally recognized as a state by the
United States.
ice shelf
^Nineteen of 26 Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the United States have
reserved the right to do so) and they do not
recognize the claims of the other nations.
Boundary representation is not necessarily authoritative,
802683AI (R00349) 4-00','2464bc5a75bdaad5fd630cc9de9033ae2748a09a40ef0a8fe1ee41999edc3027','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4df99aaf0f54cb1cea4c322252de948a395e73095e7501f911dcc71667b1c19',2000,'AT','Austria','space',523,'AU
AT
AUT
040
AT
47 48N
13 02E
Samar [island]
4812N
1622E
Vientiane [US Embassy]
Laos
17 58N
102 36 E
Vilnius [US Embassy]','23cf0c15fb82a0dc15b995bde1bc3549b4795ef33996cffd6971601f672603ba','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdd28dc03687218de6b48378e366fdeee2c49886056eb88aee9bfcd5e58fc5d1',2000,'AZ','Azerbaijan','space',524,'AJ
AZ
AZE
031
AZ
The Bahamas
BF
BS
BHS
044
BS
4023N
49 51 E
Baku [US Embassy]
40 23N
49 51 E
Baky (see Baku)
4023N
4951 E
Balabac Strait
Pacific Ocean
7 35N
117 00 E
Balearic Islands
40 00''N
46 40E
Nagoya [US Consulate]
39 20 N
45 20 E
N''Djamena [US Embassy]','38253d98efe5fd8ad03867aa9f5f667ff4333447bf0e99ec339a9b3961ca0b87','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72965975faed410012446a0cecb6ee60102db484cfae1d09c4473405e67da2c9',2000,'BH','Bahrain','space',525,'BA
BH
BHR
048
BH
Baker Island
FQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
2613N
50 35E
Manaus [US Consular Agency]','059ecf848f224009c1a2c22cafaed1b15b8039cc25fa987e33084e395442bb2e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6841600821d39c3e14aaf00e44bcbbd0a2338a45a12344b39c6efc28865f79b0',2000,'BD','Bangladesh','space',526,'BG
BD
BGD
050
BD
90 25 E
Dhofar [region]
Cman
5410E
Diego Garcia [island]
British Indian Ccean Territory
7 20S
72 25E
Diego Ramirez [islands]
24 00 N
90 00 E
East Siberian Sea
Arctic Ccean
East Timor (Portuguese Timor)','f833c3f5e6478d816806f72514ba57bd7462fd0fdac30d87fee4197561e10bfc','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71d0de6ce78d315b5237f98227c235b05cacefb4543b940645b9cbb68b46393',2000,'BB','Barbados','space',527,'BB
BB
BRB
052
BB
Bassas da India
BS
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
13 06N
59 37W
Brisbane','8e52029c8a22f90583bb20b0102a235c9aab168457090cd94742f9bff5ae5454','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e86484795d48f32cf3bcc69781e5674410cbc97dcc636d6c775e1c03de810c02',2000,'BY','Belarus','space',528,'BO
BY
BLR
112
BY
53 00 N
Bengal, Bay of
Indian Ocean
15 00N
Bering Sea
Pacific Ocean
60 00 N
175 00 W
Bering Island
Russia
55 00 N
166 30 E
Bering Strait
Pacific Ocean
Ham
169 00 W
Berkner Island
53 00N
28 00E
C Cabinda [province]
53 54 N
Minorca Island (Isla de Menorca)','a8daa3d1c51a7462db2bc050227e32a03847fe79d8e9e84d9603cc9d9f8a7256','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faf7087470aaa79a40050758673ddf9628939769447e0b0ff1aa5618c1978005',2000,'BE','Belgium','space',529,'BE
BE
BEL
056
BE
638
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
51 13 N
425 E
Aozou Strip
50 SON
420 E
Bubiyan [island]','96bfb1b0c52e7b1ff049f2b069d7d852871d039934a82e822ec66eb844553e17','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acb38bc5d76b8bfefbae352975f8d9495283e422584a2077e6220dff96bcd4b5',2000,'BZ','Belize','space',530,'BH
BZ
BLZ
084
BZ
8812W
Belle Isle, Strait of
Atlantic Ocean
Bellingshausen Sea
Southern Ocean
Belmopan
1715N
88 46 W
Belorussia
1715N
88 45W
British Solomon Islands','f015b2cdb8fa252fe1523af7f92ae170c45572cdde76c117c514d896ec3808b6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e3e5311f3815f925edca68cbbcdee586a74e453cec4645d1adb88b3789bd5f',2000,'BJ','Benin','space',531,'BN
BJ
BEN
204
BJ
621 N
2 26E
Courantyne River
Guyana, Suriname
557N
57 06W
Crete [island]
9 30N
215E
Daito Islands
6 29N
2 37E
Portuguese East Africa','32385442fc7aff32f65e1454b65c3adcb6eabd086a4455299649c7c6c1fb2dfb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3223d71604074d192ebfb7da56474c8cacba5854d5d4d6458a7fb47dbca6bd3',2000,'BM','Bermuda','space',532,'BD
BM
BMU
060
BM
3217N
64 46W
Hanoi [US Embassy]
Vietnam
2102N
105 51 E
Harare [US Embassy]','cbdd50d688ce63c0c850d10f1faa95333ebaa3e26d34949394d4765bf2ec2a81','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b945f1423e7c8e3bb7e761ec1d0553897f52e286e171b0dfc56befb7cce5fcfa',2000,'BA','Bosnia and Herzegovina','space',533,'BK
BA
BIH
070
BA
44 00N
18 00E
Bosporus [strait]
Atlantic Ocean
41 00 N
29 00 E
Bothnia, Gulf of
Atlantic Ocean
63 00 N
20 00E
Bougainville [island]
44 00N
18 00E
Hispaniola [island]
Dominican Repubiic, Haiti
1845 N
71 00 W
Ho Chi Minh City
Vietnam
1045N
106 40 E
Hokkaido [island]
43 52N
18 25E
Sarawak [state]','a312a0399078de04e2b4be15f8c4d28f824ca28e723bddde5573b7ae864d8ca2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18111ca9172bef3c157f88f1c4f6da40accd4ea51309ed162e22833cf28a2af3',2000,'BW','Botswana','space',534,'BC
BW
BWA
072
BW
22 00 S
24 00 E
Beijing [US Embassy]
24 45S
25 55 E
Galapagos Islands (Archipielago de Colon)','76606767b7ce68b2af86cce4f5172b921eec3b0ad00bf63e65e0855f30d48a12','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8fb56fc3b317b4e485701f49c8fded80e2577b57d10800d8004baa6cace3ffc',2000,'BV','Bouvet Island','space',535,'BV
BV
BVT
074
BV
" (NORWAY)
NORWEGIAN CLAIM
undefined limit
/
PRINCE EDWARD ISLANDS
(SOUTH AFRICA) \\
r ARQBNTlTiA
SOUTH ^
SHtTLWO
tSLANDS- \\
Novolazia revskaW*^
i£l-biRUSSlA) / \\
1 ^tea of ^
J^nlargement
nayer Maitri
lAMY) (INDIA)
Queen Maud Land
CHILEAN i
CLAIM I
South
Bellingshausen
i 5ca j
^Weddell Sea
. ~--/nnr
M|jley(U.K,)
X\\^&ano II
Syo^(JAPAN)
t^^^»^oIodezhnaya
^ \\ Enderby \\)
A; ^ Mawson
French^outherrK^
and Antar^toHCands
(FJAfia)^
KERGUELEN
Amundsen-Scott
A (U.S.) -
Marie Byrd--
hong ShanfCHlNi^
Progress (RUSSIA)?
I Vostok
(RUSSIA)
\\ Pacific
\\
''''^Oceah.
\\
Argentina, Brazil, Chile, Chint; Poland,
Russia, South Korea, ''Uruguay each have
a station on King George Island.
X Amuniisen
^ 5ea
Artufo
(CHIL^
^speranza
^^^QENTINA)
m -m Marambio
average niinimctm
exletit of set iee
A Scoft
" — S£5/e
WcMiFrdo
ATerra l^ova
(ITALY^
Vi^ria Urnrf
Amer_y Ice Shel^
''•JDaVislAUSTRAUA)
, Mirnyy
[(RUSSIA)
vfshackleton
)S ke shelf
rj Casey
rWSTRALlA)
Heard Island and \\
McDonald Islands \\
(AUSTRALIA) \\
Indian
Ocean
Dun\\ont d''Urville
X (F^CE)
BALLENY
- --ISLANDS
Southern
CLAIM
,<X £rah^
Antarctic
/Peninsui^
Southern
- . Ocean
CHATHAM ISLANDS
(NEW ZEALAND)
Campbell
Island
(MEW ZEALAND)
HEW
ZEALAMD.
Macquarie Isl
'' (AUSTRALIA)
AUCKLAND ISLj^DS
y (NEW ZEAL''AfiD)
iso
tt ^SNARES ISLANDS
- (NEW ZEALAND)
FRENCH
CLAIM
South
Pacific''
Ocean
Wellington
802699AI (R02207) 4-00
lARCTIC REGION
-
150
N o r Pacific
/Ocean
{</''•* 180 ■- ^
r I
HBS
Petropavlovsk-
Kamchatsjciy /
Bering Sea
'' J '''' \\ JA
^^-^.^ccupled by th/SovletUnion In 1945, V /-
a^mWstered byRussla, claimed by lapan. t
Kh^arovsk
I AVhitehojrf^^
, ■ ■ •■'' / '' Dawst
r /Watson
^ / Late
^chorage / \\
Valdez \\
UMITED SWES
Fairbanks
Provident i^i^^adyr''
Ben''ll^
Stra/I ^ / \\
y “X — ii - - Xr
Barrow Jt-crajcmlnimiim
Oymyakon
sVerkhoyansk''
•>/.!
/ / Inu^
-on _ Mwiataise-irisa _ i
Hudioti 1
to
-.1 ®
Arctic
Ocean/
\\ I /
10\\C ^SoVv isotherm,
RUSSIA
y Ism
DIksonV
Kara
, Sea
C\\ ■)''Aro&
\\ V
Davis Strait
Longydarbye|
^ ^albard
(MQRWAY)','c9b27341b351c2e795abd14b3debc6fc1f2b77e617f7af718a8d331c9baedf23','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30e6e77077b774f63b2495d501f3f47b6d978adf177edc0e78f44661eaabc534',2000,'BR','Brazil','space',536,'BR
BR
BRA
076
BR
48 29 W
Belep Islands (lies Belep)
15 47S
47 55W
Bratislava [US Embassy]
3 51 S
32 25W
Fernando Po [island] (see Bioko)
343S
38 SOW
Fort-de-France
308S
60 01 W
Manchukuo
20 30S
28 51 W
Mas a Tierra (Robinson Crusoe Island)
. 30 04 S
51 11 W
Port-of-Spain [US Embassy]
803S
34 54W
Redonda [island]
22 54S
4314W
Rio de Oro
351 S
33 49 W
Rockali [isiand]
0 23N
29 23 W
Saint Peter Port
12 59S
38 31 W
Salzburg
23 32S
46 37W
Sao Pedro e Sao Paulo, Penedos de [rocks]
0 23N
2923W
Sao Tiago [island]
Cape Verde
15 05N
2340W
Sao Tome [island]
20 31 S
29 20 W
Tripoli
, La Paz'' .
BOLIVIA
C SantaCniz* - r
Belo
Horizonte ,
lY Rio lie laneiro
t _ Si2.PmlV_.irti
_ _Anlarcti^ircle_(66;53''}_ _ HERN OCEAN
\\rqulpilago de
ando de Noronha
(BRAZIL)
Martin Vaz
. (BRAZIL)
Ascension
(St. Helena)
SOUTH
ATLANTIC
OCEAN
St. Helena
(St. Helena)
WAMIBIA .
Windhoek j^TCTOWAriA
Tl. Gaborone .*^1
^aputo
pibane
SziLAliD
TRISTAN DA CUNHA (St. Helena)
Cough Island
'' (St. Helena)
South Geor^ and the
South Sandwich Islands
(administered by U.K., A
claimed by ARQCfmriA) ’
''south ORKNEY
ISLANDS
Port Elizabeth
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
SOUTHERN OCEAN
Hong hong
Hanoi *r-^A-.. R A R ^
fGutfaf/f^
I Tpnkm L„.. J Hainan — 7- ••
IL . Dao
^KHue nuucEL''
. '' - BUMS
f^'' \\ WV..3 -
Macau S*A.R. Luzon $tndt
SA.lt ~ : * \\ V
Philippine
• Sea'' ■••''-"•
MtKthefn * •
Mntana. , *;
Islands
. (U.S.)
Wake Island
• - ro.s.) p
^Saipan
1^ South china
mCAMBODlA|B i
im '' -■ .
jiian^i sphatly'' . '' '' ''
^ IStMiDg '' t
Bandar Seri .
Begawan^
BRunci^ifl
L^. miumims
Guam *
Hagdtna
(Agana)
FEDERATED STATES OF MICROriESIA
MARSHALL','f27a260b7b05229ca6acc70aba35ddef6686b9491a41fa3035a89a4630cc853f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69a3b0dd5dcea5b976e2034ca8aa2ea41d3b2105e820a2b1c212624171f609f9',2000,'IO','British Indian Ocean Territory','space',537,'10
10
lOT
086
10
British Virgin Islands
VI
VG
VGB
092
VG
Brunei
BX
BN
BRN
096
BN
6 00S
71 30 E
Channel Islands
Guernsey, Jersey
49 20 N
2 20W
Charlotte Amalie
Virgin Islands
18 21 N
64 56W
Chatham Islands
6 00S
71 30 E
Okhotsk, Sea of
Pacific Ocean
53 00N
150 00 E
Okinawa [island group]','a3b1601fad3cb599f6fa428be1d292d02500e69200c02e1759fe3bd710b4f320','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc4c4e8c9ab3cb3426cd595924507e7d0db2ede7ac2acb96d4af4d21767b40fe',2000,'BF','Burkina Faso','space',538,'UV
BF
BFA
854
BF
Burma
BM
MM
MMR
104
MM
ISO uses the name Myanmar
1 31 W
Outer Mongolia
13 00N
200W
Ural Mountains
Kazakhstan, Russia
60 00 N
60 OOE
Ussuri River
China, Russia
48 28N
135 02 E
Vaduz','abd5e15384a7c54f3386079d36f078f69d283022138f5e897bb059d35f94c669','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60144fd91953dbd417db637ac4409c7e9038e6c7db4de6b4c48a017765506905',2000,'KH','Cambodia','space',539,'CB
KH
KHM
116
KH
103 50 E
Anglo-Egyptian Sudan
13 00N
105 00 E
Kanton Island
11 33 N
104 55 E
Phoenix Isiands','04a85fdd8925180c4b60d48666f13d8e1c570615674ac23acadb033e4681fa7b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3db44de09a7577badc2ff32c0c89cd5870f4dea1e916185c4db20f3814004b2e',2000,'CM','Cameroon','space',540,'CM
CM
CMR
120
CM
9 42E
Douglas
Man, Isle of
54 09N
428W
Dover, Strait of
Atlantic Ccean
1 30 E
Drake Passage
Atlantic Ccean, Southern Ccean
60 00 W
Dubai [US Consulate General]
SOON
12 00E
French Guinea
3 52N
11 31 E
Yap Islands
Federated States of Micronesia
9 30N
138 00 E
Yaren','90df620935875d5ca473362bc4072ec00c2a7ff07855762ff0189d8a98abab98','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c51b40abd5210ed41028fa1ce833b420f1fe79f27939cd90936fff6ac6fcf2',2000,'CA','Canada','space',541,'CA
CA
CAN
124
CA
Cape Verde
CV
CV
CPV
132
CV
79 30 N
90 00 W
652
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Azad Kashmir
68 00N
70 00 W
Baghdad [US Embassy temporarily suspended;
US Interests Section located in Poland''s embassy
in Baghdad]
7515N
121 30 W
Banks Islands (lies Banks)
51 03 N
11405W
Appendix H; Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
California, Gulf of Pacific Ocean 28 00N 112 00 W
Campbell Island
87 00 W
Dhahran [US Consulate General]
103 00 W
Ellesmere Island
80 00 Wj
658
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Ellice Islands
44 39N
63 36W
Halmahera [island]
45 31 N
73 34W
Moravia [region]
Czech Republic
49 30 N
17 00E
Moravian Gate
Czech Republic
49 35N
17 50E
Moroni
52 00 N
56 00W
Niamey [US Embassy]
45 20 N
73 58W
Ouagadougou [US Embassy]
4620N
6320W
Prince Edward Islands
76 30N
119 00 W
Principe [island]
52 00N
72 00W
Queen Charlotte Islands
53 00N
132 00 W
Queen Elizabeth Islands
78 00N
95 00W
Queen Maud Land [claimed by Norway]
43 55 N
59 50 W
Safety Islands (lies du Salut)
4712N
60 09 W
Saint Paul Island
43 39 N
79 23 W
Torres Strait
Pacific Ocean
10 25S
142 10 E
Torshavn
4916N
123 07 W
Vancouver Island
49 45N
126 00 W
Van Diemen Strait (Osumi Strait)
Pacific Ocean
31 00 N
131 OOE
Vatican City [US Embassy]
Holy See
41 54 N
12 27E
Velez de la Gomera, Penon de','5fd5ee53ac68600dfacdc5fc7cb79adf7acff47a8fe663f2054b276a60bacaf0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deed53cc6243284185b614c483a563b4c33a93a4cd9b85673900950a1f73676e',2000,'KY','Cayman Islands','space',542,'CJ
KY
CYM
136
KY
19 20N
Georgetown
The Gambia
13 30N
14 47W
Georgetown [US Embassy]
81 20 W
Grand Turk','5c38f21d14cc3f2ce716fb74d8b3f6c9bcb42efc6e6d4479499f8b7beb766a4d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2462b66deb08079966e933622b35cac0445b739bc34833407a5d01497cc90c84',2000,'CF','Central African Republic','space',543,'CT
CF
CAF
140
CF
422 N
18 35E
Banjul [US Embassy]
The Gambia
1328N
16 39W
Banks Island
7 00N
21 00 E
Ceuta','a57cfc4e207e40486643a5ec2dbe217ea80a39078d5f7e1e869b9d4adec9eb7f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73850d96e11b62141af83ca77d5a50704b5e1cc0e601f8f83a4f6a6b8f619bcd',2000,'CL','Chile','space',544,'Cl
CL
CHL
152
CL
24 30 S
6915W
Athens [US Embassy]
56 SOS
68 43W
Diomede Islands
Russia [Big Diomede], United States
[Little Diomede]
65 47 N
169 00 W
Diu
109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ccean
129 00 E
Eastern Samoa
55 59 S
6716W
Horne, lies de
33 00 S
80 00 W
Jubal, Strait of
Indian Ocean
2740N
33 55 E
Judaea [region]
Israel, West Bank
31 35 N
35 00E
Jutland [region]
33 38S
78 52W
Mascarene Islands
Mauritius, Reunion
2100S
57 00E
Maseru [US Embassy]
27 07S
109 22 W
Passion, lie de la
Clipperton Island
1017N
109 13 W
Pashtunistan [region]
Afghanistan, Pakistan
32 00N
69 00 E
Peking (see Beijing)
33 38S
78 52 W
Rocas, Atol das
2628S
105 00 W
Salisbury (see Harare)
26 21 S
79 52W
San Andres y Providencia, Archipielago
80 05W
San Jose [US Embassy]
33 27S
70 40W
Santo Antao [island]
Cape Verde
17 05N
25 low
Santo Domingo [US Embassy]','f64cb10ccfe22c4a40add380fa3b8af453500c0931d6dbbaa0bb48069c8c0b16','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('603bf111281bfded387bddb1cbf0d998ac7e64b725a49aaba7c00f7a8184c9b3',2000,'CN','China','space',545,'CH
CN
CHN
156
CN
see also Taiwan
39 56 N
11624E
Beirut [US Embassy]
11316E
Canton Island (Kanton Island)
39 39 N
104 04 E
Chennai (Madras) [US Consulate General]
35 00N
105 00 E
China, Republic of
Taiwan
23 30N
105 00 E
Chisinau [US Embassy]
Moldova
wmmm
28 50 E
ChoiseuI [island]
23 06 N
11316 E,
Guantanamo Bay [US Naval Base]
19 00N
109 30 E
Halifax [US Consulate General]
42 00N
11300E
Ionian Isiands
Russia [de facto]
44 00N
124 00 E
Manchuria
44 00N
124 00 E
Manila [US Embassy]
39 56N
116 24 E
Peiagian Islands (Isole Pelagie)
31 14 N
121 28 E
Shenyang [US Consulate General]
41 48 N
12327 E
Shetland Islands
42 00N
86 00 E
Sint Eustatius [island]
Netherlands Antilles
17 29N
62 58W
Sint Maarten [island]
Netherlands Antilles
18 04N
63 04W
Skagerrak [strait]
Atlantic Ocean
5745N
9 00E
Skopje [US Embassy]
The Former Yugoslav Republic of Macedonia
41 59 N
21 26 E
Slavonia [region]
32 00N
90 00E
Tbilisi (see Tbilisi)','8de9138fb5d6176e699e70926dbf5a85a8076356d790308ef96144592d09794d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66d5c864f3dddfc1e2abd7fe8b798275e17d66c94e3f36c7571729ae1ced5a17',2000,'CX','Christmas Island','space',546,'KT
CX
CXR
162
CX
Clipperton Island
IP
—
—
—
—
ISO includes with French Polynesia
18 44N
6419W
Severnaya Zemlya (Northland) [island group]
Russia
79 30N
98 00E
Shaba [region]
Democratic Republic of the Congo
8 00S
27 00E
Shag Island
(AUSTRALIA) ”
Denpasar ^
5rbtUml«fc''^ <£
Sumba
Cocos
(Keeling)
Islands ''
(AUSTRALIA)
Indian Ocean
y<^H^^East Timor
■^upangi^Tlw
^ pl>
Ashmore and
Cartier Islands
(MJSTRAL1A)
''•ffi CTulfof
Carpentaria
Scale 1:32,000,000 at 5°N
Mercator Projection
Boundary representation is not necessarily authoritative.
Names In Vietnam are shown without diacritical marks.
100','4f33bb1308620184cf00d74f1aa1fcb3a4f2e2afaf4fd58ce4a19984e3d7cc07','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7a9d0e41c24a90e453fcb1827ec08931e1c01f022e0be7fa6ee5564b581d760',2000,'CC','Cocos (Keeling) Islands','space',547,'CK
cc
CCK
166
CC
12 30S
96 50E
Colombo [US Embassy]
12 SOS
96 50 E
Kerguelen, lies
French Southern and Antarctic Lands
49 SOS
69 30 E
Kermadec Islands
1210S
96 55 E
West Korea Strait (Western Channel)
Pacific Ocean
34 40N
129 00 E
West Pakistan','4a768b8f23520dd29d9ee34784d881c98e42b4782ff31a2ac1fcdc8e60151c3e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed7daf8ab9f508f668591c97ee739126471be8419be79470e99bc0af939fae13',2000,'CO','Colombia','space',548,'CO
CO
COL
170
CO
10 59N
74 48W
Bashi Channel
Pacific Ocean
22 00N
121 00 E
Basilan Strait
Pacific Ocean
6 49N
122 05 E
Basque Provinces
4 36N
74 05W
Bohemia [region]
Czech Republic
50 00N
14 30E
Bombay (see Mumbai)
4 00N
90 30W
Malta Channel
Atlantic Ocean
5644N
2653E
Malvinas, Islas
Falkland Islands (Islas Malvinas)
51 45 S
59 00W
Mamoutzou
13 32N
80 03W
Roosevelt Island
■■■EESEHI
8130W
San Bernardino Strait
Pacific Ocean
124 10 E
San Felix, Isla
14 25N
8016W
Serranilla Bank
15 51 N
79 46W
Settlement, The','df6193ca5e8c9b10dfa9c66a4f77d697ceebedad5c1b2655359264d69d573743','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da993a564dec0785a52b099fd8c7c990d4bc9c3e4a3883f3d04c26cc1222fd34',2000,'KM','Comoros','space',549,'CN
KM
COM
174
KM
Congo, Democratic Republic of the
CG
ZR
ZAR
180
ZR
formeriy Zaire
Congo, Republic of the
CF
CG
COG
178
CG
44 25E
Ankara [US Embassy]
Turkey
32 52E
Annobon [Island]
11 41 S
4316E
Mortlock Islands (Nomoi Islands)
Federated States of Micronesia
530 N
153 40 E
Moscow [US Embassy]
Russia
37 35E
Mount Pinatubo','efda5714da8df09b482538a55574a928ac0ce8fcfa014586c84fa3693a4fe2b9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10831e014e5abfb0215939a7bdad8a4a14f5a0b2069d4642d0d25f94653ab5f',2000,'CK','Cook Islands','space',550,'CW
CK
COK
184
CK
Coral Sea Islands
CR
—
—
—
—
ISO includes with Australia
21 12 S
159 46 W
Axel Heiberg Island
10 53S
165 49 W
Danish Straits
Atlantic Ocean
58 00 N
1100E
Danish West Indies
Virgin Islands
18 20N
64 50W
Danzig (Gdansk)
10 53S
165 49 W
Pusan [US Consulate]
South Korea
35 06N
129 03 E
Pyongyang
North Korea
39 01 N
125 45 E
Q
Quebec [US Consulate General]
(n.2.)
SOCIETY
ISLANDS
(Pr. POly.)
S’ •
J’apeete »•.)> .
'' v
ARCHIPEL DES TUAMOTU
(Fr. Poly.)
,rren.ch Polynesia \\
\\ (FRAIiQE) . \\
V .... Tropic of Capricorn\\ (23°27'')
, flES TUBUAI
\\ (fr. POly.)
Adamstown* ntcalm Islands
(U.K.)
Easter Island
(CHILE)
^ Isla Sala y Cdmez
(CHILE)
Antarc^^ircl£j66^''L
ncAiec
*Le6n
Mexico* • A
Puebla ‘
DOMimCAT!
g-^HUBUC
on Island
>rfCE)
GuatenilS^^^^
San Salvadom
ELSALWmOR
rgpuzE
nQelmopanf
Teguci^M
Britiah Virgin /
Islands f ’ -
Angullta (U.K.)
/sT. Klfrs AMD M
<^ArmpuA Arm barbuda
/ V Quadeloupe (TR.)''
Caribbean Sea','18a6d0e07631397b696db238716b1f7f69112bc3a0596dac516b287f68aece16','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edfb8adc6481dae27b2f583d9e707f482f182258d706a7561aecbf0810d6582b',2000,'CR','Costa Rica','space',551,'CS
CR
CRI
188
CR
Cote d''Ivoire
IV
Cl
CIV
384
Cl
5 32 N
8704W
Cocos Islands
956N
84 05W
San Juan','4da7ba8d1c1d788b50b4e4ad29cbca8696c485a498a42514db13937ba1261b4a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3be4232eea4ba348a7c19f820a03fe2554f52f536bde5744b3525048f18f7baa',2000,'HR','Croatia','space',552,'HR
HR
HRV
191
HR
4300N
17 00E
Daman (Damao)
42 24N
18 31 E
Pribilof Islands
4527N
18 00E
Society Islands (lies de la Societe)
45 48N
15 58E
Zaire
Democratic Republic of the Congo
15 00S
Zanzibar [island]
Tanzania
610S
3911 E
Zion, Mount
Israel, Jordan
31 46 N
3514E
Zurich','9e44eff64bb4430a8faecaad7e55634c440763656378fb8a92240e1c5a8b2edf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80788fa41830d166bf775142f3a2bd8f635b4bae46098d195394fe90a64d9719',2000,'CU','Cuba','space',553,'CU
CU
CUB
192
CU
20 00 N
75 08 W
Guatemala [US Embassy]
23 08N
82 22W
Hawaii
21 40 N
82 50 W
K
Kabul [US Embassy now closed]
21 40 N
82 50W
Pleasant Island
21 40 N
82 50W
Yucatan Peninsula','289b9b7973f777b08da64ad26c70fee28914e090e885001c1b21dae0eed7ea79','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9294c383532637bcdc877e07cfcbb20eec1afa4787e499509595d9ad2c9f5b25',2000,'CY','Cyprus','space',554,'CY
CY
CYP
196
CY
Czech Republic
EZ
CZ
CZE
203
CZ
3510N
33 22E
Leipzig [US Consulate General]
35 ION
33 22E
Nightingale Island
Saint Helena
37 25S
12 SOW
Nomoi Islands (Mortlock Islands)
Federated States of Micronesia
5 30N
153 40 E
North Atlantic Ocean
Atlantic Ocean
30 00 N
45 00W
North Channel
Atlantic Ocean
55 ION
540W
North Frisian Islands
Denmark, Germany
54 50N
812E
North Island','6b88d034c112f7b3db2d8874d31584c69010d82f2358821b7fbd84ea2509a53e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7c0f37cffed0422435b130cbd1bd8d4dc761f9d723d3c8d7b39c213082ae999',2000,'DK','Denmark','space',555,'DA
DK
DNK
208
DK
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
55 ION
15 00E
Bosnia
55 40N
12 35E
Coral Sea
Pacific Ocean
15 00S
150 00 E
Corfu [island]
56 00 N
915E
Juventud, Isla de la (Isle of Youth)','c62201c7991082969de283e5499bf4d383cb878095e79e65ee3c46bccee20c38','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e598678eaaec7b485d0f79e9682cf11b42bafb30ea6923dd71e5f0c9993a0a54',2000,'DJ','Djibouti','space',556,'DJ
DJ
DJI
262
DJ
11 SON
4300E
Agalega Islands
11 SON
4315E
Dnieper [river] (Dnyapro, Dnepr, Dnipro)
Belarus, Russia, Ukraine
46 SON
3218E
Dniester [river] (Nistru, Dnister)
Moldova, Ukraine
3017E
Dodecanese [islands]
11 SON
43 OOW
French Sudan
11 SON
43 00E
French Togoland','d66a89841fedaf423bc7976dd15fb8ac8d3de6c6f6c6ce9a6d0b2152cf2ac9e6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ec372c41e241e0ea555341dc38bcda1bb7cc977a2fb2d1c760e3c32e6bd9ed9',2000,'DO','Dominican Republic','space',557,'DR
DO
DOM
214
DO
East Timor
—
TP
TMP
626
TP
FIPS includes with Indonesia
18 28N
69 54W
Sao Paulo [US Consulate General]','d1c0bc0df58f8b8c88d2313b0522e383f9f2f27d237cbf40f7ab42973be5e531','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01ada19ce11bf80b043a82e06ee5ea80352cc377619a86c2f6f9d2f72d4fb672',2000,'EC','Ecuador','space',558,'EC
EC
ECU
218
EC
OOON
90 30W
Commander Islands (Komandorskiye Ostrova)
Russia
55 DON
167 00 E
Conakry [US Embassy]
OOON
90 SOW
Galilee [region]
213S
79 54v\\
660
Appendix H; Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
H
Ha''apai Group
013S
78 30W
R
Rabat [US Embassy]','461a5d238b51a812469a4b5bd865d9e66bdf28b1bb3a26fbcd237c0a23a0390c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1baa6b350a24cf9f160ed0ae8adfbf61342c95f85a980893201910dace1c6656',2000,'EG','Egypt','space',559,'EG
EG
EGY
818
EG
31 12 N
29 54E
Algiers [US Embassy]
30 03N
31 15 E
Calcutta [US Consulate General]
3013N
33 09 E
Gilbert Islands
30 20N
32 23 E
Great Britain
30 02N
32 54E
Mogadishu
29 30N
34 00E
Singapore [US Embassy]
29 55 N
32 33E
Suez, Gulf of
Indian Ocean
28 ION
33 27E
Sulu Archipelago','cf66b54ca5a9b724fd93ce63dca88029f3b623c984f43393e4e945707fbc9d4d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69e59b3c80848ce382e8841f92e805ff51401e756071aa6bb187e6dca0b14a7e',2000,'SV','El Salvador','space',560,'ES
SV
SLV
222
SV
13 42N
8912W
Santa Cruz
Bolivia
1748S
63 low
Santa Cruz Islands','367ba1817c57c4357e4ea371e0920b56529046478ce20ea635bcf1c04eb20752','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6797b567922441391b0d2bf03b7514df1558e1eb52d0c3ac79b3044a2bedca99',2000,'GQ','Equatorial Guinea','space',561,'EK
GO
GNQ
226
GO
5 36E
Antananarivo [US Embassy]
842 E
Biscay, Bay of
Atlantic Ocean
44 00N
400W
Bishkek [US Embassy]
059 N
9 33E
Enderbury Island
3 SON
842 E
Finland, Gulf of
Atlantic Ocean
60 00 N
2700E
Florence [US Consulate General]
345 N
8 47E
Malacca, Strait of
Indian Ocean
2 30N
101 20 E
Malagasy Republic
1 30 N
10 00E
Riyadh [US Embassy]
2 00N
1000E
Spanish Morocco','910cd67cf19ca3092f34caca9152b5596a1d4b97bf3d4e67514889f2c657d1de','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f64b6b14180094bf2417ce76bc8c25a19ce3c892abe30196e579729f67533b3',2000,'ET','Ethiopia','space',562,'ET
ET
ETH
231
ET
Europa Island
EU
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
Falkland Islands (Islas Malvinas)
FA
FK
FLK
238
FK
SOON
38 00E
Acapulco
9 02N
38 42E
Adelie Land (Terre Adelie) [claimed by France]','9af364a253b661f71af9568298d5b9160179368cea4f1c5399a952c7b957dd52','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21fd4fed8960fad3e961ba67948e4cec7cd2d1663caba71d4c7745f9cd472a4a',2000,'FO','Faroe Islands','space',563,'FO
FO
FRO
234
FO
62 01 N
646W
Tashkent (see Tashkent)
» (DENMARK)
SHETLAND
ISLANDS^
ORKNEY ''
ISIANDSk^ ''
WORWJ
Berg^
I
Stavangeri
North
Atlantic
Ocean
iku
fer 1 inM'' ,■*
Sf’
UmUANIA J
* snsSAr''^
Ei.sluh
Guernsey (U.K.)„ ^
Jersey (U.K.)«>
.Bornholm^ ^ \\
*'' pa^r^aw^r
"» ''■
lurakovac
ijurakovac)
Lapusntk
Malisevo
Qrahova^
•Prizren
Republic boundary
Autonomous province
boundary
Province capital
Railroad
802690AI (R02194) 4-00
- Road
Airport
Scale 1:1, 060, 000
Lambert Conformal Conic Projection,
standard parallels 38°N and 47''N
0 20 Kilometers
•SS&r
IDDLE EAST
Arabian Sea
Socotra
(YEMEM)
0ulf of Aden
Golan Heights is Israeli-occupied Syria. i
West Bank and Gaza Strip are Israeli-occupied with current \\
status subject to the Israeli-Palestinian Interim Agreement -- \\
permanent status to be determined through further negotiation. I
Israel proclaimed Jerusalem as its capital in 1 950, but the US, like
nearly all other countries, maintains its Embassy In Tel Aviv.
802691 Al {R02107) 4-00
Tropic of Cancer
North
Pacific
■(^Sn^Bsssi^is^
c^aaoBss®,*
ijaianiffi®
.jjijyftrfMtniigli
wwssises''i&^s
EoanBZiM^
ItMiia!)
Tropic of Capricorn
Ocean
tWngmarf
UAUSTRALIA)]
802697AI (R0211 1)4-00
JOUTH AMERICA
Islalde ,
San A wres
Caribbean Sea
|UA . (COLO 1BIA)
fua ‘ ,
Martinique (FRAMCE) ^ 60
I ST. LUCIA j
. K ST. ViriCEFiTAIID. ^BARBADOS
“r THEQREKADmES
V > QRETIADA#
Cartagen^ /7f
Isla de Malpelo
(COLOMBIA)
Pdtt-jof-Spain
^ IrKi^lur
Paramaribo
North
Atlantic
Ocean
W:^eKniTHv
iiliSli
-s:.t,A V.''
5 o utK I
P sicific
Ocean
Mil
\\ Isla San Ambroslo
Isla San Felix ''\\ ‘
ARCHIPI^LAGO \\
/UAN FERNAnDEz]
(CHILE) . \\
CHIIfl
Cerrv Aconcagua // ‘ yW
(highest point in ^
South America, 6962 m) VVTV^
Va I pa ra i
V/w‘ n
Santiaeo^
Concepcidnjy
mm
iS
Santos
l^lorianopolis
itMf
-m#
/uRUQUAYf’
Montevideo
r Peninsula ifaldes
ffowesi pectin
South Americ^ -40 w)
Comodoro Rivadavia
Scale 1:35,000,000
Azimuthal Equal-Area Projection
0 500 Kilometers
I '' i'' ''i '' ■'' - ^ - 1
0 500 Miles
\\ Boundary representation is
\\ not necessarily authoritative.
falkland Islands
(Islas Malvinas)
(administered by U.K.,
claimed by ARGEHTiHA)
South.
Atlantic
Ocean
South Georgia and the
South Sandwich Islands
(administered by U.K.,
4 claimed by ARQEMTIMA)
802687AI (R02108) 4-00
mr-^rnyfl^
<^/.f Hg"«"
-
Kao-hsiuniVr Taiwan
Naha^ ^
Tropic of Cancer
'' * BONIN .
O /SMNDS,
VOLMNO .
ISLANDS .
Hong Kong S.A.R.
Pratas j <
* Ijfond iLiuron /
‘ BAet/VAN ISLANDS
^^BanglKili,
'' '' ''(''''r - At\\.Hue '' '' PARACEL
CKTID ''vS r''S^Da Nang 4* J
T Nakhon t^''.; * n^t
RatchasimaK . A ,1^ l/KTN AM
South
Philippine
Sea
I ISLANDS
'''' (irfDIA) ..J&^\\y1
4, ms ^W„a
MI/Mfiro \\ M
, J.-AL^:o.E^Hrr
*/W I Ciulfof ^ I
NICOBAR ^ iM
^ISMNDS Phuket
*a<e.« Clumiel ^ N^''^’Vv
Banda Aceh''^^i!^''
. Xl-''J.N %,\\*V I
Pulau Nla^^ \\ A 1 ^
''iW . P. H I L rf’PTJT^-
io»3i«inh Sea ■■\\ -. ''t A, ’’"■''''‘''’''iM^''^Mr-
^ ^ *‘V .* ^PpIpppp^^
SPRATLY , NotosV^ ".Ji
''ISLAlVDS.
» . •
pg^an de Oro
pMALAYSIA
l^ala Lumpur
,o __ Zan boang^
Bandar Serl^^^^''’^'''''' '' «?. ?
Begawan .0«^-,^.,/^ , •
''N«Kineapore
^oM^MQAPORE
ir iuTl / ''
V ''P<^nH!ana^ > /
FED. J TATES OF
^Koror MICllOMESIA
North
Pacific
Ocean
''■''I ''% V''”!
fe-4|r '' ff / r ^
V*hi. i''*k\\i^'' ■£) 4 W-iA B_^armasi;^jr •? d''iiP^i£ r-n*.
Pontianak . ^
KEPULAUAN
MENTAWAI
TanTvmiearang
TeluRfewne
java Sea UjungpandaAttj
^arta I -1^ D O IjmiE''* O''- I A Sanaa Sea ^
5eljt Suncla 4^marang>-_~ Madura
KEPULAUAN
^ ARU','aa479be0ec3785aa1593fdb145e3778bbadf2279cba10a023ef973060cfd571c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('264ce594d1c2e7559f9ecb353b8bc46aaf5c2b10c2e18137407f4f1ccb51c490',2000,'FJ','Fiji','space',564,'FJ
FJ
FJI
242
FJ
18 20S
178 30 E
Lefkosa (see Nicosia)
12 30S
177 30 E
Ryukyu Islands
1808S
178 25 E
Sverdlovsk (see Yekaterinburg)
Russia
5650N
6039E
Swains Island
18 00S
178 OOE
Vladivostok [US Consulate General]
Russia
43 ION
131 56 E
Volcano Islands','81834b546223bf5c562014abc97ee738c401a22280f81038e1f7e9abb8c06b9d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea929535b01296ec641452061eff105526aff7827cbfcda55e6e7abee0792276',2000,'FR','France','space',565,'FR
FR
FRA
250
FR
France, Metropolitan
FX
FXX
249
FX
ISO limits to the European part of
France, excluding French Guiana,
French Polynesia, French Southern
and Antarctic Lands, Guadeloupe,
Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon,
44 SON
0 34W
Borneo [island]
Brunei, Indonesia, Malaysia
0 30N
11400E
Bornholm [island]
42 00N
9 00E
Cosmoledo Group (Atoll de Cosmoledo)
4318N
5 24E
Martin Vaz, llhas
48 52 N
2 20E
Pascua, Isia de (Easter Island)
48 35N
745 E
Stuttgart','8759500dd178eec2ebc47c6c879a02ed3868b9996617f806527abc81b9408408','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffbf7df1e4833633f1969c76f70703ae9a50c8bf59348b1e94030b9a7ee77aa4',2000,'GF','French Guiana','space',566,'FG
GF
GUF
254
GF
4 56N
52 20W
Cebu [US Consular Agency]
517N
52 35W
Devon Island
5 20N
52 37W
Sahel
Burkina Faso, Cape Verde, Chad, The Gambia,
Guinea-Bissau, Mali, Mauritania, Niger, Senegal
15 00N
8 00W
Saigon (see Ho Chi Minh City)
Vietnam
10 45N
106 40 E
Saint Brandon (Cargados Carajos Shoals)','a70901a25c799d8538bc36141c806cb464d7354789b86713573c26aebacaa6c4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1405f5549966c87b010540bf7003fb6565c3543cb7f0740ec57ce3b6a765781',2000,'PF','French Polynesia','space',567,'FP
PF
PYF
258
PF
ISO includes Clipperton Island
French Southern and Antarctic
Lands
FS
TF
ATF
260
FIPS 1 0-4 does not include the French-
claimed portion of Antarctica (Terre
Adelie)
23 20 S
151 00 W
Avarua
16 30S
151 45 W
Bordeaux
134 58 W
Gaspar Strait
Pacific Ocean
107 00 E
Geneva [US Consular Agency, US Mission to European
Office of the UN and Other International Organizations]
900S
139 30 W
Marseille [US Consulate General]
17 32S
149 34 W
Paramaribo [US Embassy]
17 00S
150 00 W
Socotra [island]
17 37S
149 27 W
Taipei
Taiwan
25 03N
121 30 E
Taiwan Strait
Pacific Ocean
24 00N
11900E
Tallinn [US Embassy]
19 00S
142 00 W
Tubuai Islands (lies Tubual)
23 00 S
150 00 W
Tunb al Kubra [island]
Iran
2614N
5519E
Tunb as Sughra [island]
Iran
2614N
55 09 E
Tunis [US Embassy]','4c1bd58cf82bb5d3e0737886b721f6d9fb98bdd0eb8ea2cc024cbf74daf662c6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fd24ff49e72f109c0ffb14b1ef7d51a3bd7382a15c5fafd5bf6885c6cf07450',2000,'GA','Gabon','space',568,'GB
GA
GAB
266
GA
The Gambia
GA
GM
GMB
270
GM
Gaza Strip
GZ
—
—
—
—
0 23N
927 E
Ligurian Sea
Atlantic Ocean
43 30N
9 00E
Lilongwe [US Embassy]','0488f13129dc9f87f2f4ded28ef38173bad229fbbc9466db58468c56b9cac995','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7531970c089af588f63f88c523681a9b9bdc0e111e25fa5f9d8af7f33d5914f9',2000,'GE','Georgia','space',569,'GG
GE
GEO
268
GE
43 00N
41 00 E
Abu Dhabi [US Embassy]
42 20N
44 00E
672
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
South Pacific Ocean
Pacific Ocean
30 00S
130 00 W
South Sandwich Islands
41 43 N
4449E
Tegucigalpa [US Embassy]
44 49E
Tien Shan [mountains]
China, Kyrgyzstan
80 00 E
Tierra del Fuego
Argentina, Chile
54 00 S
69 00 W
Tijuana [US Consulate General]','74711da2f171f36abf8e9af8a7aa5a01295cbbf26ecc38381c6abfe3af3a0e0d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77986bc183ae72e8889dadb808d3b1987b5158937367c1f4556ebd95efaef7d4',2000,'DE','Germany','space',570,'GM
DE
DEU
276
DE
48 SON
11 30 E
Beagle Channel
Atlantic Ocean
54 53 S
68 low
Bear Island (see Bjornoya)
Svalbard
74 26N
19 05E
Beaufort Sea
Arctic Ocean
73 00 N
140 00 W
Bechuanaland
52 31 N
13 24E
Berlin, East
52 SON
13 33E
Berlin, West
52 SON
12 20E
Bern [US Embassy]
48 00 N
815E
Black Rock
50 44N
7 05E
Bophuthatswana
53 44N
7 25E
East Germany (German Democratic Republic)
52 00 N
13 00E
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ccean
34 00 N
129 00 E
East Pakistan
50 07 N
8 40E
Franz Josef Land [islands]
Russia
81 00 N
55 00 E
Freetown [US Embassy]
13 00E
German Southwest Africa
51 00 N
9 00E
53 33N
9 59E
Hamilton [US Consulate General]
51 19 N
12 20E
Lemnos [island]
11 35 E
Musandam Peninsula
Oman, United Arab Emirates
56 24 E
Muscat [US Embassy]
51 00 N
13 00E
Schleswig-Holstein [region]
54 31 N
9 33E
Scopus, Mount
Israel, West Bank
3148N
3514E
Scotia Sea
Atlantic Ocean, Southern Ocean
56 00S
40 00 W
Appendix H: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Scotland [region] United Kingdom 57 00 N 4 00 W
Scott Island
48 46N
911 E
Sucre
Bolivia
19 02S
6517W
Suez Canal
51 00 N
11 00 E
Thurston Island
53 22N
520E
West Island','e0e30b37fc3e712f80d357e02b317de773abb3b57ecbb81f098e10413602b93c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2d5786fddf2386fc309347c8bfcd1d3eac129dfc6bb1d7ca8b18c972093e18e',2000,'GH','Ghana','space',571,'GH
GH
GHA
288
GH
533N
013W
Adamstown
Pitcairn Islands
25 04 S
130 05 W
Adana [US Consulate]
Turkey
37 01 N
3518E
Addis Ababa [US Embassy]
2 00W
Golan Heights [region]
Syria
33 00N
35 45E
Good Hope, Cape of','e2aac3816434c48b3ec11218296be96bef77da2d1dd4f36db0d7c1762f9675a9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c93def0855f8e2511ba18d21e1a39a006dda63b070d1b0989832cf5364574622',2000,'GI','Gibraltar','space',572,'Gl
Gl
GIB
292
Gl
Glorioso Islands
GO
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
3611 N
5 22W
Gibraltar, Strait of
Atlantic Ocean
35 57N
5 36W
GIdl Pass','e27d7f0d03112d63aa5ca1fdbfc3f44e7d7979b771fac467d23c2b9e93a75aff','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36cd4cc29c97bd5232a0f3ecaa61c1d27e2ad5345cfd51a3421c3aecc092f2b6',2000,'GR','Greece','space',573,'GR
GR
GRC
300
GR
38 00 N
25 00E
Aegean Sea
Atlantic Ocean
38 SON
25 00E
Afars and Issas, French Territory of the (FTAI)
24 42 E
Andros Island
The Bahamas
77 57W
Anegada Passage
Atlantic Ocean
6340W
Angkor Wat [ruins]
2344E
Attu Island
3940N
1945E
Corinth
3756N
22 56E
Corisco [island]
Equatoriai Guinea
0 55N
919E
Corn Islands (Islas del Maiz)
3515N
24 45E
Crimea [region]
37 00N
2510E
Czechoslovakia
Czech Republic, Slovakia
49 00N
18 00E
D Dahomey
27 05E
Dodoma
Tanzania
611 S
Doha [US Embassy]
38 30N
20 30E
Ionian Sea
Atlantic Ocean
38 30N
18 00E
Irian Jaya [province]
39 54N
25 21 E
Leningrad (see Saint Petersburg)
Russia
59 55 N
3015E
Lesser Sunda Islands
3915N
2615E
Leyte [island]
36 ION
28 00 E
Rhodesia
37 48N
2644E
Sanaa [US Embassy]
40 38 N
22 56 E
Thimphu','836999840659c5116d57bd70dd76a0a5eaddc4a6321e964bf63af649aa691370','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('051bfacd270e20c42851c1fe7d1ac1be6358c44a3ab90441b3c2e1bc6c79b31a',2000,'GL','Greenland','space',574,'GL
GL
GRL
304
GL
6411 N
51 44W
Gold Coast
6411 N
5144W
Nyasaland
(DEMMARK) /
P^miut .
(Fred^kshabU
(Godth^.^) «-W
I Labrador
* Sea
Tasiilaq N
(Animass»tk!^''
Bi0rn0ya .
^reenLina (morway)
Denmark Strait
Norwegian
I Sea
Reykjavi''lO
\\ North Atlantic Ocean\\^^^^
\\ Scale \\ -39, 000,000/
Azimuthal Equal-Area Projection
0 500 Kilometers
I ^ - 1
0 500 Miles
The Arctic region is often defined as that area where the
average temperature for the warmest month is below t0°C.
30''
( /riKUAPI
Faroe
TdrshavHj^ Islands
''W (DEMMARK)
SWEII^Eri ^j*''*^*
Arkhangelsk]
ytske M''Jizhniy i
^ Ladoga Novgorod
St. Petersbu^ MOSCOW _ 4
\\ Saratov^
QERMAriY^
■^Wareai^
hi lAKI '' I
\\,-Sn/y C^ograd
/Kharki^ /
^^Rostov
s^^iriEy^^
^0 Black Sea
802698AI (R02112) 4-00
Ntirwcctan Svalbard
(MORWAY)^
P 80 100 ^20
■¥mNZ fOSEKf / \\ \\
^ LAND/ Arctic Ocean \\
mm.
PetroWv^^
Kamcn^i^
4 occupied by the Soviet Union In 1 945.
''«K. administered by Russia,
claimed by Japan. ''
jfeCJtafcnXr
.casern- ’
. .. ■■ ''
1 Zhcngihou ''■A
Arabian
Mumbai >■
(Bombay)
u _ I
Hong Kong SlA.R.''.
S^Macau S.A.R. 1 — ^
^Philippine
LAKSHADWEEP ■
(IMDIA)
i‘K,rwM
I . C h c n n a i
\\ ; s ‘•Jiji^^D(Madras)
^diMf
VC''S.
ANDAMAN d
ISLANDS 9
(IHDIA) A Andani.-ui
SPRATLY •■., ''
ISLANDS ,-'' ..
\\SRI LAHKA
Ho Chi Minh
City
maldiveS/74
5?MaIe
0 0
Scale 1:48,000,000
Azimuthal Equal-Area Projection
Bandar Seri
Begaw^
Ug^AYSIA ^
\\^^la Lumpur . MA
...^ingapore
ft^^irSQ AFORE
802694AI (R02105) 4-00
/I I ''
a r i b b.e a
North
‘ Pacific
St. Pctersbui^
f B/M/M
ISLANDS
Key We^
iv''i ’ Santa Clar^ .''
miC BAHAMAS)
^ ■ Cay Lotos ,
.(TMC BAHAMAS)
>%/lACGED
WSLAND
X^ANCE
(THC BAIMMAS)
MEXtCO
CENTRAL AMERICA AND THE CARIBBEAN
Adris-tic
Sea
Autonomous province
boundary
Inter-Entity Boundary
Line (lEBL)
(Dayton agreement line)
Scale I. -3, 550, 000
lamben Conformal Conic Projection,
standard parallel dO''N and 3d N
Strait of
Otranto
802695A! (R02110) 4-00
Jan Mayen
Serbia and Montenegro have asserted the fbiTnatlon
of a {oint Independent state, but tttis en^ has
not been formally recognized as a state by the
United States.
‘ F.YR.O.M. ''The Former Yugoslav RepubSc of Macedonia
GreenUnd
/ Sea.
- j V / s trL
Norwegian Sea
- i£pt!C_ _Cirde','243b0ad8b64db6bab640456e60e5c21b094db5a3607cefdd6780647cedb22cf9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('644f3f121c5bddad192e862984142e48c20e7e579ffa9169ef3bde023964008d',2000,'GD','Grenada','space',575,'GJ
GD
GRD
308
GD
61 40 W
Grytviken
12 03N
61 45 W
Saint George''s Channel
Atlantic Ocean
52 00 N
6 00W
Saint Helier
12 20N
6130W
Southern Rhodesia','d82b5bd7ab9fe456044cdb2c19b0792221cc8ec6edc8d406a0fd18695b123c61','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c63148cfb1d06e29a9e89fe1b609b005af94cc73c947643182e24e9cf4dde3e7',2000,'GP','Guadeloupe','space',576,'GP
GP
GLP
312
GP
16 00N
6144W
Basseterre
18 04N
63 04W
Saint Martin (Sint Maarten)
Netherlands Antilles
18 04N
63 04 W
Saint Paul Island','8953b1d597502b1d6eff0c3d30f10f73fe0ca1f96f3d6d7ad125b6db4b2e22e7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3d6084e83f04b1abcf875ade75f276213f0da89f059d0874ef9327c8ef6675a',2000,'GU','Guam','space',577,'GO
GU
GUM
316
GU
13 28N
144 45 E
Ajaccio
France (Corsica)
41 55 N
8 44E
Akmola (see Astana)
13 28N
144 45 E
Hague, The [US Embassy]','fc803982d6735833689bbae27f8d185c30aab63261e7e0f27a9c0cc4db8c63a4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aaba66aeb17679db70405bdba7927375a39c88535babd276622850586477454',2000,'GT','Guatemala','space',578,'GT
GT
GTM
320
GT
14 38N
90 31 W
Guinea, Gulf of
Atlantic Ocean
3 00N
2 30 0
Guayaquil [US Consulate General]','5415be94ad7c679e0a544ac647999f9995ef0cdcfb96705ca913316d17660114','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3077a22b61f13b1b46939790b48956fb3b44e41feb5c61a2b1908dd50e09deb',2000,'GG','Guernsey','space',579,'GK
—
—
—
—
ISO includes with the United Kingdom
640
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
49 43N
212W
Aleutian Islands
United States (Alaska)
52 00N
176 00 W
Alexander Archipelago
United States (Alaska)
57 00N
134 00 W
Alexander Island
49 27N
2 32W
Saint Petersburg [US Consulate General]
Russia
59 55 N
3015E
Saint-Pierre
49 26N
2 21 W
Saxony [region]','3eb48729f16b30b9b248357a0364eadef6aa7ffd385d790cc091949b22455f54','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06733df60339f79138e3062040623c19cbe599a98bac01ed118bed2c7d10367f',2000,'GN','Guinea','space',580,'GV
GN
GIN
324
GN
9 31 N
1343W
Congo (Brazzaville)
Republic of the Congo
100S
15 00E
Congo (Leopoldville)
Democratic Republic of the Congo
OOON
25 00E
Con Son [Islands]
Vietnam
8 43N
106 36 E
Cook Strait
Pacific Ocean
41 15 S
174 30 E
Copenhagen [US Embassy]
11 00 N
10 OOW
French Indochina
Cambodia, Laos, Vietnam
15 00N
107 00 E
French Morocco
Moroao
32 00 N
5 OOW
French Somaliland','47ad04bf7f1cca5b79b4445e2e203fbd30cc86f121b6d361de6ff49990c760e8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e94dfb2af662790e0b4f9418d86677ecb766d92caa8d6023f7584397ef7ed565',2000,'GW','Guinea-Bissau','space',581,'PU
GW
GNB
624
GW
11 25 N
16 20W
Bikini Atoll
11 51 N
15 35W
Bjornoya (Bear Island)
Svalbard
74 26N
19 05E
Black Forest
12 00N
15 00W
Portuguese Timor (East Timor)','e75051b6982b141247096d9376f75682833ac0df386b9c54048d67d4a813687b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('314dd85e3123a4a5374685d95de028f17f992521fcd6037df294ca4ac7237a31',2000,'GY','Guyana','space',582,'GY
GY
GUY
328
GY
SOON
59 00W
British Honduras
6 59N
58 23 W
Etorofu (Iturup) [Island]
Russia [de facto]
44 55N
147 40 E
F
Farquhar Group (Atoll de Farquhar)
58 low
German Democratic Republic (East Germany)','9440b0723891255579d3b04597d884130a3c0fd50507b8cfaf3a166c034561b1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d4bc37f1c5b0c903bc930667c957ea23d188bfd41f7af98fbc0bf2eaac617e7',2000,'HM','Heard Island and McDonald Islands','space',583,'HM
HM
HMD
334
HM
Holy See (Vatican City)
VT
VA
VAT
336
VA
5306S
73 30E
Hejaz [region]
53 06S
73 30E
Mecca
53 00 S
72 30E
Shag Rocks','d9dff9fad88deda8b2191a734cb1ae56c1f7facbbe9f5d5bcd82b3f7750d8bde','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8469567adbfcec0873948d1f7c1f178795e9abad3e41246a83b2058237573a7f',2000,'HN','Honduras','space',584,'HO
HN
HND
340
HN
17 25S
83 56W
Sydney [US Consulate General]
14 06N
8713W
Tehran [US post not maintained; representation
by Swiss Embassy]
Iran
35 40N
51 26 E
Tel Aviv [US Embassy]','3136aeaa02261e35ec2d8db647c09a16e6e882f7aac405b1d837a0492bb6bcc3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('024cbea084fc3cd80794f1d23c489ad060b0d4d175a017eee6dbbea6d1c79f68',2000,'HK','Hong Kong','space',585,'HK
HK
HKG
344
HK
Howland Island
HQ
—
—
—
—
ISO includes with the US Minor
Outiying Islands
2215N
11410E
Honiara
Burma, Thailand
22 24 N
114 10E
New York, New York [US Mission to the
United Nations (USUN)]
2217N
114 09 E
Victoria','9a9f99f3e8d8ec9428c3c3d71f88dc351cf3b79ff325b2d110409f1c720dafea','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b917a52ffb27a98a54bd6114e23a8e3a7271d690df599bf13adc5258b1abb077',2000,'IN','India','space',586,'IND
356
IN
11 SON
72 30E
651
Appendix H; Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Amirante Isles (Les Amirantes)
92 45E
Andaman Sea
Indian Ocean
10 00N
95 00 E
Andorra la Vella
2316N
77 24E
Biafra [region]
18 58N
72 50E
Bonaire [island]
Netherlands Antilles
1210N
6815W
Bonifacio, Strait of
Atlantic Ocean
41 01 N
1400E
Bonin Islands
22 32N
8822E
Calgary [US Consulate General]
13 04N
8016E
Chesterfield Islands (lies Chesterfield)
20 ION
73 00E
Damascus [US Embassy]
Syria
33 30N
3618E
Danger Islands (see Pukapuka Atoll)
2042N
70 59E
Djibouti [US Embassy]
74 00E
Godthab (Nuuk)
32 42N
74 52E
Jammu and Kashmir [region]
India, Pakistan
34 00N
76 00 E
Japan, Sea of
Pacific Ocean
40 00N
135 00 E
Jars, Plain of
Laos
19 27N
103 10 E
Java [island]
Indian Ocean
Bolivia
Latitude
(deg min)
48 48N
48 27 N
45 00N
15 36N
13 00N
1730N
34 05N
53 53N
50 26N
1 57 S
18 00N
29 03S
1309N
418S
41 DON
1 52 N
47 00N
36 00N
3441 N
5749N
67 20 N
6 58N
39 00N
40 00N
37 00N
34 00N
7 20N
42 30N
2218N
1020N
6 07S
50 03N
3 ION
44 20N
36 00 N
46 ION
2920N
54 00N
9 05N
3300N
5026N
54 00N
10 00N
7 00N
6 27N
31 35 N
10 00N
16 30S
Longitude
(deg min)
11700E
135 06 E
132 24 E
32 32E
105 00 E
56 00 E
71 10 E
908E
30 31 E
30 04E
7648W
167 58 E
61 14 W
1518E
75 00E
157 20 W
28 50E
23 00E
135 10 E
152 23 W
37 00E
158 13 E
124 00 E
127 00 E
127 30 E
129 00 E
134 29 E
2100E
114 10E
99 00E
105 24 E
19 58E
101 42 E
146 00 E
8400E
152 00 E
47 59 E
86 00 E
167 20 E
131 00 E
30 31 E
62 00W
7300E
7600E
324 E
7418E
73 00E
68 09W
663
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
La Perouse Strait
Pacific Ocean
45 45N
142 00 E
Laptev Sea
Arctic Ocean
126 00 E
Las Palmas
13 04N
8016E
Madrid [US Embassy]
817N
Minsk [US Embassy]
72 50E
Munich [US Consulate General]
28 36 N
7712E
New Guinea
Indonesia, Papua New Guinea
5 DOS
140 00 E
New Hebrides
SOON
93 30 E
Nicosia [US Embassy]
27 50 N
88 30 E
Sinai Peninsula','f44a5073fc19001bbcfedea73699c7803b50e7a30215ef3d05ef34bc27167a65','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f9131035d8a1beda4b51a9b69d4156250d180d4ce2ced47aefb2ca8c3e3be5e',2000,'ID','Indonesia','space',587,'ID
ID
IDN
360
ID
Iran
IR
IR
IRN
364
IR
8 20S
115 00 E
Bali Sea
Indian Ocean
745 S
11530E
Balintang Channel
Pacific Ocean
1949N
121 40 E
Balintang Islands
2 00S
Celebes Sea
Pacific Ocean
3 00N
122 00 E
Celtic Sea
Atlantic Ocean
51 00 N
6 30W
Central African Empire
5 00S
120 00 E
Dutch Guiana
Easter Island (Isla de Pascua)
1 00 N
128 00 E
Hamburg [US Consulate General]
5 00S
138 00 E
Irish Sea
Atlantic Ocean
53 30N
520W
Iron Gate
Romania, Serbia and Montenegro
44 41 N
22 31 E
Islamabad [US Embassy]
610S
106 48 E
Jamestown
Saint Helena
15 56S
5 44W
Jammu
7 30S
11000E
Java Sea
Pacific Ocean
5 00S
11000E
Jeddah (see Jiddah)
OOON
115 00 E
Kamaran [island]
9 00S
120 00 E
Lesvos [island]
335 N
9840E
Mediterranean Sea
Atlantic Ocean
36 00N
15 00E
Melbourne [US Consulate General]
28 00 E
Mombasa
3 30N
102 30 E
Naxcivan [region]
5 00S
120 00 E
Netherlands Guiana
900S
126 00 E
Port-Vila
2 00S
28 00E
Spitsbergen [island]
Svalbard
78 00N
20 00E
Stanley
Falkland Islands (Islas Malvinas)
5142S
5741 W
Stockholm [US Embassy]
000 N
102 00 E
Sumba [island]
10 00S
120 00 E
Sunda Islands (Soenda Isles)
Indonesia, Malaysia
2 00S
110 00 E
Sunda Strait
Indian Ocean
6 00S
105 45 E
Surabaya [US Consulate General]
715S
112 45 E
Surigao Strait
Pacific Ocean
1015N
125 23 E
Surinam
9 00S
125 00 E
Timor Sea
Pacific Ocean
11 00 S
128 00 E
Tinian [island]','6ab9e8b5be2e14560f9fb2faaf32c4c73963392b8a1a6866e721af27f3ef8014','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('650184faf4781b18abd1401a0ea07a424ead397173a2ea05f9c244e2fbd53e05',2000,'IQ','Iraq','space',588,'IZ
IQ
IRQ
368
IQ
3321 N
4425E
Baki (see Baku)
3300N
44 00E
Messina, Strait of
Atlantic Ocean
3815N
15 35E
Mexico [US Embassy]','c655dbadd5275bff41ad943fabaf4c5921d503aa52b2129652ffdd9b7fbb1b48','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf0d0413a957819a432317e0f28878e1c533201ba7dfd61bd441721187d40347',2000,'IE','Ireland','space',589,'El
IE
IRL
372
IE
53 20 N
615W
Durban [US Consulate General]
53 00N
8 00W
Elba [island]','12aa58334429e5e99cabfcf4572a051c28b83a18ef85d44ce366f7fe10e11724','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b78ba59c0dbdc8851505d5e5c95b16ad18eb8735637f4572503e565c101c86b',2000,'IL','Israel','space',590,'IS
IL
ISR
376
IL
32 54N
3520E
659
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Galleons Passage
Atlantic Ocean
60 55 W
Gambler Islands (lies Gambler)
32 SON
35 00E
Haiphong
Vietnam
20 52N
10641 E
Hainan Dao [isiand]
30 30N
34 55E
Negros [island]
32 05N
34 48E
Terre Adelie (Adelie Land) [claimed by France]
35 35E
Tibet (Xizang)','98ae6398d56d3de090a8b830e956f7f74850baa65f7c8cd21e9bc562a832bfb3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c26b415974d46de8c404320c21eda6e70633d799ca99ea64b959893567a05ff2',2000,'IT','Italy','space',591,'IT
IT
ITA
380
IT
1017E
Ellef Ringnes Island
38 SON
15 00E
Epirus, Northern
Albania, Greece
40 00N
20 30E
Espana
43 46N
11 15E
Florida, Straits of
Atlantic Ocean
25 00 N
79 45W
former Soviet Union (FSU)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,
44 25N
8 57E
George Town
41 13 N
09 24 E
Madeira Islands
45 28 N
912E
Minami-tori-shima (Marcus Island)
40 50 N
1415E
Nassau [US Embassy]
The Bahamas
25 05 N
77 21 W
Natuna Besar Islands
38 07N
1321 E
Palestine
Israel, West Bank
32 00N
3515E
Palikir
Federated States of Micronesia
6 55N
158 08 E
Paik Strait
Indian Ocean
10 00N
79 45E
Pamirs [mountains]
China, Tajikistan
38 00 N
73 00 E
Pampas [region]
36 47 N
12 00E
Papeete
35 40 N
12 40E
Peleliu (Beliliou) [island]
41 54 N
12 29E
Roncador Cay
40 00N
9 00E
Sargasso Sea
Atlantic Ocean
30 00N
55 00W
Sark [Island]
37 30 N
14 00E
Sicily, Strait of
Atlantic Ocean
1120E
Sidra, Gulf of
Atlantic Ocean
18 00E
Sikkim [state]
46 30N
10 30E
South Vietnam
Vietnam
12 DON
108 00 E
South Yemen (People''s Democratic Republic of Yemen)
45 04N
740 E
Turkish Straits
Atlantic Ocean
40 40N
28 00E
Turkmeniya
43 25N
11 OOE
Tutuila [island]
46 30N
1030E
Tyrrhenian Sea
Atlantic Ocean
40 00N
12 OOE
Udorn (Udon Than!) [US Consulate]','7a8389b86c1190857b405cccf358578957fe344192c0e451f601640dd600f925','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0024690f870321a37a7689a403fcdf8fe0d9537a5b07cc88db52959e317e9af4',2000,'JP','Japan','space',592,'JA
JP
JPN
392
JP
Jarvis Island
DQ
—
—
—
ISO includes with the US Minor
Outlying Islands
27 00 N
140 10 E
Bonn [US Embassy]
43 00N
1700E
Dakar [US Embassy]
33 35N
130 24 E
Funafuti
44 00N
143 00 E
Holland
36 00N
138 00 E
Hormuz, Strait of
Indian Ocean
26 34N
5615E
Horn, Cape (Cabo de Hornos)
3420N
133 30 E
Inner Mongolia (Nei Mongol)
141 20 E
J
Jakarta [US Embassy]
2416N
154 00 E
Mariana Islands
Guam, Northern Mariana Islands
Marlon Island
154 00 E
Mindanao [island]
35 ION
136 55 E
Naha [US Consulate General]
2613N
12740 E
Nairobi [US Embassy]
30 00 N
140 00 E
Naples [US Consulate General]
26 SON
128 00 E
Oman, Gulf of
Indian Ocean
24 SON
58 30E
Ombai Strait
Pacific Ocean
8 SOS
125 00 E
1
Oran
34 40N
135 30 E
Oslo [US Embassy]
20 20 N
136 00 E
Paris [US Embassy, US Mission to the Organization
for Economic Cooperation and Deveiopment (OECD),
US Observer Mission to the UN Educationai, Scientific,
and Cuifural Organization (UNESCO)]
26 30 N
128 00 E
Saba [island]
Netherlands Antilles
17 38N
63 low
Sabah [state]
24 30 N
124 00 E
Sakhalin Island (Ostrov Sakhalin)
Russia
51 00 N
143 00 E
Sala y Gomez, Isla
43 03N
141 21 E
Sapudi Strait
Pacific Ocean
7 05S
114 10E
Sarajevo [US Embassy]
3345N
133 30E
Shikotan [island]
Russia [de facto]
4347N
146 45 E
Siam
35 42N
139 46 E
Tonkin, Gulf of
Pacific Ocean
20 00 N
108 00 E
Toronto [US Consulate General]
25 00N
141 OOE
Vostok Island','73060a65f6bcf840a758b0b8d9d756b6988a2691d3341f8998abff854429b32c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b58301ecdc1806207f11a4f5f4690e13d5fc81c6a7595f601802d46b7dc07e5',2000,'JE','Jersey','space',593,'JE
—
—
—
—
ISO includes with the United Kingdom
Johnston Atoll
JQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
237W
Saint John''s','db5fb5ff9a69cefaa689e4f3cb200b7f071c74572dc7efe0d35a916079ae7047','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98435a54806ab36248e16d3dce169846afd168396b2c62c8a996f253e5341cac',2000,'JO','Jordan','space',594,'JO
JO
JOR
400
JO
Juan de Nova Island
JU
—
—
—
—
ISO includes with the Miscellaneous
. (French) Indian Ocean Islands
31 57 N
Amsterdam [US Consulate General]
36 00E
Transkei','debf50c2845743ca9123b9f688839fa618ec3da183a4fd2572725a2834c92ee1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20059f18e9133900adf1b9607f384bad2562174b40309702222f5badf369e452',2000,'KZ','Kazakhstan','space',595,'KZ
KZ
KAZ
398
KZ
51 ION
7130E
Aland Islands
4315N
76 57E
Almaty [US Embassy]
4315N
76 57E
Alofi
51 ION
71 30 E
Arab, Shatt al [river]
Iran, Iraq
29 57 N
48 34E
Arabian Sea
Indian Ocean
15 00N
65 00E
Arafura Sea
Pacific Ocean
9 00S
133 00 E
Aral Sea
Kazakhstan, Uzbekistan
45 00N
60 00 E
Argun River
China, Russia
53 20 N
121 28 E
Ascension Island
Saint Helena
7 57S
14 22W
Ashgabat [US Embassy]
51 ION
71 30 E
Asuncion [US Embassy]','a7075162e50cdf69b86911ba9283f237c918ce301518b72b29d34199f54c716f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd1ff956fc72b67c24fa14e41039be3dc0b5c6e2c9c2314478ee0e89bc0deaf',2000,'KE','Kenya','space',596,'KE
KE
KEN
404
KE
Kingman Reef
KQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
39 40 E
Mona Passage
Atlantic Ocean
67 45W
1 17S
36 49 E
Nampo-shoto [islands]','ae94b4632cf8a020894fd1a2bff1d1751eb22a677a205310318c63c34b42ed3a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d334240cc0b7fdf1ee046eaa727e6f79fd94671287dd00e774957ce6b8db6a1e',2000,'KI','Kiribati','space',597,'KR
Kl
KIR
296
Kl
Korea, North
KN
KP
PRK
408
KP
Korea, South
KS
KR
KQR
410
KR
0 52S
169 35 E
Bandar Seri Begawan [US Embassy]
Brunei
452S
11455E
Banda Sea
Pacific Ocean
5 00S
128 00 E
Bangkok [US Embassy]
171 40 W
Cape Town [US Consulate General]
1 52 N
157 20 W
Chukchi Sea
Arctic Ocean
69 00N
171 00 W
Ciskei
3 OSS
171 05 W
Enewetak Atoll (Eniwetok Atoll)
1 25 N
173 00 E
Goa [state]
2 49S
171 40 W
Karachi [US Consulate General]
Moldova
Atlantic Ocean
0 52S
169 35 E
Ocean Island (Kure Island)
330S
172 00 W
Pines, Isle of (Isla de la Juventud)
1 25 N
173 00 E
Tatar Strait
Pacific Ocean
50 00N
141 00 E
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Tashkent [US Embassy]
10 06S
152 23 W
Vrangelya, Ostrov (Wrangel Island)
Russia
71 14 N
179 36 W
Wake Atoll
Wake Island
1917N
166 36 E
Wakhan Corridor (see Vakhan)
iLES MARQUISES
(Ft. Poly.)','3c519425d3216299e0d8749034c52dd9275c4253595b511c9f74175a86625fc8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7a2153055267da7cf79290a3e605581acb31dc503464284d826091ef1dcae3',2000,'KG','Kyrgyzstan','space',598,'KG
KG
KGZ
417
KG
Laos
LA
LA
LAO
418
LA
42 54N
74 36E
Bishop Rock
42 54N
7436E
Fukuoka [US Consulate]','8c229d805ce18a45367a72b05eef8777673e9c47a37875da4a442cfdf4e5c365','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5161bec8b70112c8eb44de13ccdf3b536adaed505d0db33470c0264eccb1198f',2000,'LB','Lebanon','space',599,'LE
LB
LBN
422
LB
33 53 N
35 30 E
Belau (Palau Islands)
35 51 E
Tripoli [US post not maintained;
representation by Belgian Embassy]','2e14356b8665c3ad1710e5a8132778d1f78cd920f2a53f6dcb93878b584b4d39','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe484c16910eed5c17b8d0c442d2534fbe618c47b958d155f3a9fd5385235ebe',2000,'LS','Lesotho','space',600,'LT
LS
LSO
426
LS
29 30 S
28 30 E
Batan Islands
29 28S
27 30E
Matamoros [US Consulate]','953f75fa9b992a89e82f2d7fa7fc93972d8aa345739940377f0b4e4a46058ba1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffc001b09b9abc8016ad20af8601c25ed5243bd1f93929d8bef382c5180ae55c',2000,'LR','Liberia','space',601,'LI
LR
LBR
430
LR
641
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 31 66
Internet
Comment
10 47W','a60fbc8ed6212cac0e006a6c8bcd6a3bc0743e4b3360d68a18fd482b8bcc4c2e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4657c7ce1f3cf3af9334a1081c573ef559a66993b33332c251fb753bb706f036',2000,'LY','Libya','space',602,'LY
LY
LBY
434
LY
32 54 N
1311 E
Tristan da Cunha Group
Saint Helena
37 04S
1219W
Trobriand Islands','5ab07ab67c8ee2ab4e6c5901852ca6efeb013f0e93a7c4ead586d191117904c4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48c25c949a300f24e5d867581ea52eb1f13966aa17f66ae9793ebf8c46f18640',2000,'LU','Luxembourg','space',603,'LU
LU
LUX
442
LU
Macau
MC
MO
MAC
446
MO
Macedonia, The Former Yugosiav
Republic of
MK
MK
MKD
807
MK
49 45N
Luzon [island]','c1bf90375aab16f293f867f3cba49990be3ef8a5af9d57a39b07dd4fb4d2f7d6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41da277e95af54bd3b43b2f3061c5605589b021e53ce15367c6efdd285b15086',2000,'MG','Madagascar','space',604,'MA
MG
MDG
450
MG
Maiawi
Ml
MW
MWI
454
MW
18 52S
47 30E
Antigua [island]
20 00 S
4700E
Male','9de53295d3bf5bd13cc18c05be904f1a7f13f9a10071c8758d058e78f384fcd6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8292fa82bad53b834ae58795b721eac9d092c9f7b87fc44da98e9d0b34bd96c9',2000,'MY','Malaysia','space',605,'MY
MY
MYS
458
MY
5 26N
100 16 E
George Town
The Bahamas
23 30 N
George Town
Russia [de facto]
5 23N
100 15 E
Pentland Firth
Atlantic Ocean
58 44N
313W
Perim [isiand]
5 20N
117 10E
Sable Island
2 30N
11330E
Sardinia [island]','63457814215e6725fc971482d30dfd3bce4c99155fd101c5f46b96d202a376f8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ce04edc1569cafd2a8c0d600cca44babbaed75eea829a287fe9a6159620dbc8',2000,'ML','Mali','space',606,'ML
ML
MLI
466
ML
Maita
MT
MT
MLT
470
MT
Man, isle of
IM
—
—
—
—
ISO includes with the United Kingdom
12 39N
800W
Banaba (Ocean Island)
17 00N
400W
French Territory of the Afars and Issas (FTAI)','8959df70c8ec068ae52279f8aef39896a3be5b8784e28f846dc0f7bfd1d6c9b5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e369e89caf0819cd0b39c0779772f72f40286b7382113c379f83fb4e88cf17a',2000,'MH','Marshall Islands','space',607,'RM
MH
MHL
584
MH
11 35 N
165 23 E
Bilbao
11 30 N
162 15 E
England [region]
1130N
162 15 E
Eolie, Isole
7 05N
171 08 E
664
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Makassar Strait
Pacific Ocean
2 00S
11730E
Malabo
8 00N
167 00 E
Rangoon [US Embassy]
Burma
1647N
9610E
Ratak Chain
9 00N
171 00 E
Recife [US Consulate]','f8ec6647879b1d59a2b7f1bcedcdb9c350dc5dccb6a9670a52189dd6943726a9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaefe868d093a4eeb4d8d5cae10378bed34f7ee595949e257537ac1a052faf1a',2000,'MU','Mauritius','space',608,'MP
MU
MUS
480
MU
1025S
5640E
Agana (see Hagatna)
16 25S
59 38 E
Caroline Islands
Federated States of Micronesia, Palau
7 30N
148 00 E
Caribbean Sea
Atlantic Ocean
15 00N
73 00W
Carpentaria, Gulf of
Pacific Ocean
MOOS
139 00 E
Casablanca [US Consulate General]
2010S
57 30E
Port Moresby [US Embassy]
19 42S
63 25 E
Rome [US Embassy, US Mission to the UN Agencies for
Food and Agricuiture (FODAG)]
16 25S
59 38 E
Saint Christopher [island]','a405244514cb7922988ecdf41e38e1b7cab421f6f0ce6121000c70031f53f00e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2b6b4e7f71bcbc3178567acecbdb2d4cde72b09dfbe613a1e2dc56935eb00e5',2000,'MX','Mexico','space',609,'MX
MX
MEX
484
MX
Micronesia, Federated
States of
FM
FM
FSM
583
FM
Midrvay Islands
MQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
Miscellaneous (French)
ISO includes Bassas Indian Ocean da
India, Europa Islands Island, Glorioso
Islands, Juan de Nova Island, Tromelin
Island
Moldova
MD
MD
MDA
498
MD
16 51 N
99 55W
Accra [US Embassy]
31 44 N
106 29 W
656
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Cluj-Napoca [US Branch Office]
20 40 N
103 20 W
Guadalcanal [island]
2911 N
11817W
Guangzhou [US Consulate General]
29 04N
11058W
Herzegovina
25 53 N
9730W
Mata-Utu
2313N
106 25 W
Mbabane [US Embassy]
Swaziland
2618S
31 06 E
McDonald Islands
20 58N
89 37W
Mesopotamia
19 24N
99 09 W
Mexico, Gulf of
Atlantic Ocean
25 00N
90 00W
Middle Congo
Republic of the Congo
1 00 S
15 00E
Appendix H; Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Milan [US Consulate General]
100 19 W
Montevideo [US Embassy]
27 SON
99 31 W
Nuuk (Godthab)
11245W
Reykjavik [US Embassy]
32 32N
11701 W
Timor [island]
19 30N
89 00 W
Yucatan Channel
Atlantic Ocean
21 45 N
85 45 W
Yugoslavia
Bosnia and Herzegovina, Croatia, The Former
Yugoslav Republic of Macedonia, Serbia and
Montenegro, Slovenia
Z
Zagreb [US Embassy]
Monterre^l
1M
Baton-, K ,
^Imf Mexico
THE^ BAHAMAS
^ Nassai^ "
, ^ -V
Hawaii
N idway ^ ^
I: lands^
US) ''hx.
North Pacific Ocean
Scale 1:34,000,000
Tropic of Cancer
( (R02419) 1
802685AI 4-00
m
C^ok''lslands
. • i.. \\
s. • french PoJynie«nr
\\ ^ (FMMCE) • •
j Scale 1:85,000,000 310”
Miller Cylindrical Projection
0 500 1000 Kilometers
0 500 1000 Miles
-45 ''F.Y.R.O.M.- The Former Yugoslav Republic of Macedonia
Serbia and Montenegro have asserted the formation
of a joint Independent state, but this entity has
not been formally recognized as a state by the
United States.
Boundary representation Is not necessarily authoritative.
I i I 1’
1 1:00 2:00 3:00
Add time zone number to local time to obtain U
Subtract time zone number from UTC to obtain !
i
m
South Qeoi
South Sand
(administei
^laimed by i
10:
^ and the
tdch Islands
id by U.K.
LRQCtmnA)
30
» Cough tsiand
(St. Helena)
Coordinated Universal Time (UTC)
formeriy |
Greenwich Mean Time (GMT)
Sun
I • 12:00 •
(number Indicates standard time
In zone when It Is 1 2 noon, UTC)
Md time zone number to local time to obtain UTC.
Subtract time zone number from UTC to obtain local time.
EAST Subtract time zone number from local time to obtain UTC.
Add time zone number to UTC to obtain local time.
Physical Map of the World, April 2000
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily/ AZORES Island / island group
★ Capital
Scale 1:35,000.000
Robinson Projection
stnndnrd fjarnllels 3S°N and 35 "S
afCat^123''27‘)
FRANZJOSEP
LAND -
Svalbard
(MORWAY)
Barents Sea
4
h - . e S'',,,, -ijvyj-''
*^.V
@
Caledonia^
(FRAnCE) ^
Noumea
Norfolk
Island
{AUSTL. )
Lord Hoive
HEW
ZEALAND ir
VVellington
Christchurch
CHATHAM ISiUiNDS
S ■ W.Z.):
SMARTS ISLANDS
m.z.)
llOUffnr ISLANDS
{fi.Z4 ;
fAf''Ai’OOESiSLANbs y
... mi.) -'' /
Campbell
F
Barrow
6iitf of Alaska
,le6o
*CuadaUilara
Honolulu
HAWAIIAN
ISLANDS
(U.S.)
iSLAS
REVILLACICEDO
(MEXICO)
Acapuica
Political Map of the World, April 2000
Clipperton island
(HWICE)
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily/ AZORES Island / island group
''A Capital
Scale 1 :35,000,000
Robinson Projection
standard parallels 38 °N and 38*5
»ril 2000
SEVERNAYA
ZEMLYA
Laptev 5ea
NEW SIBERI.
Arkhangel''sk
RUSSIA
St. Petersburg
1 Yaroslavl^
L 4, Moscow
Nizhniy
^ Novgorod
Voronezh
Saratov
HAirfE
Vcw
Khariw^
IbteY* V- ^''k*
Volgograd
HAWAIIAN
iS^I^ ^
Johnstcm Atoll
^f(U^.) ^
iSMS -
REVILLACtCEDO
(MEXICO)
Guadalajara \\
Guatenia
San Salv
ELSAl
CUpperton Island
(TRAMCE)
. Kingman Reef (U.S.)
* Palmyra Atoll (U.S.)
4 Kirltimatl
(Christmas Island)
(KIRIBATI)
Equator
ISLANDS
(ECUADOR)','179c366d78eccba565b96fe9ad7f6390b386ac0480f3e68f4d29b3ff3ac0169f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04b05f24a292a5e0b259d60a66d92a153733e1fa41db95e0a618cfea557ecba5',2000,'MN','Mongolia','space',610,'MG
MN
MNG
496
MN
Montenegro*
MW
—
—
—
—
see footnote at end of table
105 00 E
Pacific Islands, Trust Territory of the
Marshaii Islands, Federated States of
Micronesia, Northern Mariana Islands, Palau
10 00N
155 00 E
Pagan [island]
Northern Mariana Isiands
18 08N
145 47 E
Pago Pago
47 55N
106 53 E
Ullung-do [island]
South Korea
37 29N
130 52 E
Unimak Pass [strait]
Pacific Ocean
5420N
164 50 W
Union of Soviet Socialist Republics (USSR)
Armenia, Azerbaijan, Belarus, Estonia,
Georgia,Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
United Arab Republic (UAR)
Egypt, Syria
Upper Volta','ca263557b207a9d4ae5a249d870ab31d6f48e9353781e3aeb2bdd0e6160a953a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5748ff3525434c54fe6cbc1eac0a1c2dafd04ad4b7606f4c35387535c7c529bc',2000,'MS','Montserrat','space',611,'MH
MS
MSR
500
MS
1644N
6214W
Ponape (Pohnpei) [island]
Federated States of Micronesia
6 55N
158 15 E
Ponta Delgada [US Consulate]','bf8714ffb6bbbf69d14562198622f9ebb61408d67394f183aa88a7c94cfaccfc','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2ac693fa69a05cbb298d04b5b1d9c9cd3a6ea34a97cd7ad99a0cefb67201495',2000,'MA','Morocco','space',612,'MO
MA
MAR
504
MA
33 39 N
7 35W
Castries
34 02N
6 51 W
Ralik Chain
32 DON
7 00W
Spanish North Africa
Spain (Ceuta, Islas Chafarinas, Melilla, Penon de
AIhucemas, Penon de Velez de la Gomera)
3515N
400W
Spanish Sahara
35 48N
545W
Tarawa [island]','486dd697d42c976ee7695e165bf324b6c8cf97d811a593c90cb0ca567d4adad0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1294bae77b7ff38cd1427078918f736ab59495d23acbdae94aff370192506d13',2000,'MZ','Mozambique','space',613,'MZ
MZ
MOZ
508
MZ
25 58 S
32 35E
Marcus Island (Minami-tori-shima)
1815S
3500E
Portuguese Guinea','18884f6195e32ce31ae72a6cda804a42e7b9e389f69fcc4f28cbcb8a145fea6f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30682627f406819a727fcb92eb984b6f64c4268d7f220402e9167e861a0fdf15',2000,'NA','Namibia','space',614,'WA
NA
NAM
516
NA
22 00 S
17 00E
Germany, Federal Republic of
22 00S
1700E
Southern Grenadines
22 59 S
1431 E
Warsaw [US Embassy]
17 06E
Windward Passage
Atlantic Ocean
20 00N
73 50W
Wrangel island (Ostrov Vrangelya)
Russia
71 14 N
179 36 W
Y
Yalu River
China, North Korea
3955N
12420 E
Yamoussoukro
Cote d''Ivoire
6 49N
517W
Yangon (see Rangoon)
Burma
16 47N
9610E
Yaounde [US Embassy]','21b128fc96c162d8edd24e7b01b1baf8f3a2597041c783d968da3e36d4d7aaa1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56f2d1f97afe43a46a87e313ae49576cba9a3fbadace8966a1b2a9a2f388475a',2000,'NR','Nauru','space',615,'NR
NR
NRU
520
NR
Navassa Island
BQ
—
—
—
—
0 32S
166 55 E
Plymouth
0 32S
166 55 E
Yekaterinburg (Sverdlovsk) [US Consulate General]
Russia
56 50 N
60 39E
Yellow Sea
Pacific Ocean
36 00N
123 00 E
Yemen (Aden) [People''s Democratic Republic of Yemen]','d1c9028832deb11e43614180aff9a91e489eac3d9e90247e7919fb6ccb6706e3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c60ba1bee0191d57bd224213cfad722770bca442af71b2ddd83806fc50f030f',2000,'NP','Nepal','space',616,'NP
NP
NPL
524
NP
27 43 N
8519E
Kattegat [strait]
Atlantic Ocean
57 00 N
11 00 E
Kauai Channel
Pacific Ocean
21 45 N
158 50 W
Keeling Islands','78f0b7a23a38c13f8f10bed12b4bb7be26a5ea80adffd5363b0fe2e77c55b199','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('600794ef7dfafae3c2e86ba56148f712e9c0848f6d3f56ee2628f1653132a0d1',2000,'NL','Netherlands','space',617,'NL
NL
NLD
528
NL
Netherlands Antilles
NT
AN
ANT
530
AN
52 22 N
Amsterdam Island (He Amsterdam)
French Southern and Antarctic Lands
37 52S
77 32E
Amundsen Sea
Southern Ocean
72 30S
11200W
Amur River
China, Russia
52 56 N
141 10 E
Anatolia [region]
Turkey
35 00 E
Andaman Islands
52 05N
418E
Haifa
52 30 N
545 E
Hong Kong [US Consulate General]
53 26N
530E
West Germany (Federal Republic of Germany)','b0ca4bf3336cad28e8ce7b54dbbb7ec5db5a105994cbef78a5788f1418dfebe7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79f3763d13e718fe373d2f5a722fa8377d8d9e9693fb1a4b1a9a6e526a22edb3',2000,'NC','New Caledonia','space',618,'NC
NC
NCL
540
NC
19 45S
163 40 E
Belfast [US Consulate General]
19 52S
158 15 E
Chiang Mai [US Consulate General]
167 00 E
Luanda [US Embassy]
2216S
166 27 E
Novaya Zemlya [islands]
Russia
74 00N
5700E
Nubia','2c38d1f2597c030b3941a3565b7afc22924c881a9a0f85868d9e877f70abb1ab','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('992d460f2da2a9a46ab2407a51e5a8c56f96421212c720634778d01144358657',2000,'NZ','New Zealand','space',619,'NZ
NZ
NZL
554
NZ
642
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
49 41 S
178 43 E
Antwerp [European Logistical Support Office]
174 46 E
Auckland Islands
51 00 S
166 30 E
Australes, lies (lies Tubuai)
4743S
174 00 E
Brasilia [US Embassy]
52 33S
169 09 E
Canal Zone
44 00S
176 30 W
Chechnya (Chechnia)
Russia
4315N
45 40E
Cheju-do [island]
Korea, South
33 20 N
126 30 E
Cheju Strait
Pacific Ocean
34 00N
126 30 E
Chengdu [US Consulate General]
29 50 S
17815\\A
662
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Kerulen River
Khabarovsk
Khanka, Lake
Khartoum [US Embassy]
Khmer Republic
Khuriya Muriya Islands (Kurla Murla Islands)
Khyber Pass
Kiel Canal (Nord-Ostsee Kanal)
Kiev [US Embassy]
Kigali [US Embassy]
Kingston [US Embassy]
Kingston
Kingstown
Kinshasa [US Embassy]
Kirghiziya
Kiritimati (Christmas Island)
Kishinev (see Chisinau)
Kithira Strait
Kobe
Kodiak Island
Kola Peninsula (Kol''skiy Poluostrov)
Kolonia [US Embassy]
Korea Bay
39 00S
176 00 E
North Korea
North Korea
40 00 N
127 00 E
North Pacific Ocean
Pacific Ocean
30 00 N
165 00 W
North Sea
Atlantic Ocean
56 00N
4 00E
North Vietnam
Vietnam
23 00N
106 00 E
North Yemen (Yemen Arab Republic)
43 00 S
171 00 E
South Korea
South Korea
3700N
127 30 E
South Orkney Islands
41 28 S
174 51 E
West Frisian Islands','2e68281d9c9b7031b56eed7144f4e8d82dcfd1b134e4c4cb5cdddb2bb326ef18','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c48ce642d16117f672dac2ce98fe9b7db5295d7cb8a7bd3e8d2700b3af5efaa',2000,'NI','Nicaragua','space',620,'NU
Nl
NIC
558
Nl
1215N
8300W
Corocoro Island
Guyana, Venezuela
3 38N
66 50W
Corsica (Corse) [island]
1215N
83 00 V\\
Ma]orca Island (Isla de Mallorca)
12 09N
8617W
Manama [US Embassy]','600ab459e4ec5d7a1a54f0f267024cba2dd45122e73055b1f88b075f5292d19d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5d9327a42f9ff1b157d60183380497d3b2392e2b301d7dc35ed08a88c8aa287',2000,'NG','Nigeria','space',621,'Nl
NG
NGA
566
NG
912N
711 E
Abyssinia
5 SON
Big Diomede Island
Russia
65 46 N
169 06 W
Bijagos, Arquipelago dos
10 33N
7 27E
Kailas Range
China, India
30 00 N
82 00E
Kalimantan [region]','bca62bcea65121f864644872ebb1c4cf76c6e48e714648aacf131101be8098cf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f03d4fdbc32d8acb0bc59a46f5d1737de01344c88fd522c71ca247e3582a4aa4',2000,'NF','Norfolk Island','space',622,'NF
NF
NFK
574
NF
29 02S
167 56 E
Byelorussia
29 08S
167 57 E
Philippine Sea
Pacific Ocean
20 00N
134 00 E
Phnom Penh [US Embassy]','da09ffa583fe36c242bceeca54585a46777d85fd72e3b434abea457fc326350f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8355f6d61e9b8965163165a22d8beb81ee377d349ef04bd5f213b265bd01a49',2000,'MP','Northern Mariana Islands','space',623,'CQ
MP
MNP
580
MP
145 24 E
Atacama [region]
1410N
145 12 E
Rotuma [island]
1512N
145 45 E
Sakishima Islands
15 00N
145 38 E
Tiran, Strait of
Indian Ocean
28 00 N
34 27E
Tirana [US Embassy]','42dcdba84e7636dd7662231e38abada52f02323dd7fbd3b29cfd5e901091d1af','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abed7f6b9e90773030e03ade6404a9ac287952c83d1166eaee9f93d1d3506e23',2000,'NO','Norway','space',624,'NO
NO
NOR
578
NO
59 55 N
1045 E
Osumi Strait (Van Diemen Strait)
Pacific Ocean
31 DON
131 00 E
Otranto, Strait of
Atlantic Ocean
40 00 N
19 00E
Ottawa [US Embassy]','285ee483874043d967a7f6abba4caffbd80e99bee3b92d1bceb132078d79acea','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bcf1052310dbe8ae65465909bd2d032ba3be20b782bdb502f6a4ce8e9c4a44a',2000,'OM','Oman','space',625,'MU
OM
OMN
512
OM
Afghanistan, Pakistan
Atlantic Ocean
23 37 N
58 35 E
Muscat and Oman
21 00 N
57 00E
Myanma, Myanmar
Burma
22 00 N
98 00 E
Nagorno-Karabakh [region]','9c9d1f4b578462127a261bfc5ec605968c80b77e72980d220a87143315152d7c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76972e3906715b88b581ae13a6f55411326ecb1a54bd81d97571ccd14b72b3de',2000,'PK','Pakistan','space',626,'PK
PK
PAK
586
PK
34 30N
74 00E
Azores [islands]
28 DON
63 00E
Baltic Sea
Atlantic Ocean
57 00N
19 00E
Bamako [US Embassy]
33 42N
7310E
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Islas Malvinas
Falkland Islands (Islas Malvinas)
51 45 S
59 00 W
Istanbul [US Consulate General]
Turkey
41 01 N
28 58 E
Istrian Peninsula
Croatia, Slovenia
45 00N
14 00E
Italian East Africa
Eritrea, Ethiopia, Somalia
SOON
38 00E
Italian Somaliland
24 52 N
67 03 E
Kara Sea
Arctic Ocean
76 00N
80 00 E
Karakoram Pass
China, India
35 30N
77 50 E
Karelian Isthmus
Russia
60 25 N
30 00 E
Karimata Strait
Pacific Ocean
2 05S
108 40 E
Kashmir [region]
India, Pakistan
34 00 N
76 00 E
Katanga [region]
Democratic Republic of the Congo
10 00S
26 00 E
Kathmandu [US Embassy]
34 01 N
71 33 E
668
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Peter 1 Island
30 00N
70 00E
West Siberian Plain
Russia
60 00N
75 00E
Western Channel (West Korea Strait)
Pacific Ocean
34 40N
129 00 E
Western Samoa','5808a7080a89e232bcf6234b606f44c4e7e13531dc183484aeb9fd8fd9684089','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93eee0b51b967db01d23a0771a5f46e081aff331443aed567aea21b09698d0d1',2000,'PW','Palau','space',627,'PS
PW
PLW
585
PW
Palmyra Atoll
LQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
134 30 E
Belem [US Consular Agency]
Serbia and Montenegro
7 01 N
134 15E
Pemba Island
Tanzania
7 31 S
39 25 E
Penang Island
La -l a •. Y
Singapore ^
it^nOAPOIH
Jakarta . Java Sea 1
I Celebes Sea ''
^Palikir
Equator
^ ISLAMDS
''7^ SI
I . »
^Majuro
^Tarawa
Yaren ’^riAURU
District
Oiristmas Island
(AUSIL.)
Ashmore and
Cartiee Islands
(AUSTL.)
tPM
BaniJa 5ea 1/ ^
a->; ■ . y
^
''"^East Timor Arafura
: Sea
Timor ^ .
Sea
f Bismarck Sea
riEWQlifl^^ SOLOMOM
\\ ISLANDS
^ A V b| ^ « . vL ''
-PoX^^. ° '' Honlara*iV
rrl
Baker Isl
K I R
r Ti
f ''*(/ -Port
diarof
Carpentaria
I (23^^.
Coral
Islands ^ ''
^ (Aum.) ••/“ '' (■“i
.''■ Mew \\L
i Caledonla^jt ♦
•'' iniAMCE) *
. Noumea^
Funafuti* :
TUVALU ‘I
hi JJ
VANUATU ''0-\\
O'' . 7
Alice Springs','04174a7d5dc72ea5a692b2a93eb57c4fa9762043fc2b17172465452895556b9c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06b7578994b383c22f2aeb1b26e943b2d15f07232b991b77f53515818d9b3373',2000,'PA','Panama','space',628,'PM
PA
PAN
591
PA
9 00N
79 45 W
Canary Islands
8 58N
79 32W
Panama Canai
9 00N
79 45W
Panama, Guif of
Pacific Ocean
SOON
79 SOW
Panay [isiand]','94c280061e382f46af63d99c28c0cde7862182c2a26cab592eeca0013d23278c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c161300054a120bad383d638ecbe4f5131a89a5d32fb36d44e4da30309749de5',2000,'PG','Papua New Guinea','space',629,'PP
PG
PNG
598
PG
Paracel Islands
PF
—
—
—
—
210S
147 00 E
Adriatic Sea
Atlantic Ocean
42 30N
16 00E
Aegean Islands
5 00S
150 00 E
Bismarck Sea
Pacific Ocean
4 00S
148 00 E
Bissau [US Embassy]
6 00S
155 00 E
Bougainville Strait
Pacific Ocean
6 40S
156 10 E
Bounty Islands
4 30S
154 10 E
Greenland Sea
Arctic Ocean
500W
Grenadines, Northern
11 00 S
153 00 E
Loyalty Islands (lies Loyaute)
6 00S
150 00 E
New Delhi [US Embassy]
9 30S
147 10 E
Porto Alegre [US Consulate]
6 00S
155 00 E
Solomon Islands, southern
8 38S
151 04 E
Trucial Coast','aaca6b3deed6879aceb18e5bd1570c85011527d0fd90e29450459811e4e943e5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc56866f978b09f2c876ab5428b9e42adf84edc408a494bfad8cabc24be99fd',2000,'PE','Peru','space',630,'PE
PE
PER
604
PE
12 03S
77 03W
Lincoln Sea
Arctic Ocean
56 00 W
Line Islands
Jarvis Island, Kingman Reef, Kiribati,
Palmyra Atoll
0 05N
157 00 W
Lisbon [US Embassy]','19717f1928662ca227e9b26c979f75f588e43be470e16bd337f3d01f224b7827','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef0eba8a43e1ea70fa5a094aeaa468ca6e50266f820759e52540bbe7093cd6c8',2000,'PH','Philippines','space',631,'RP
PH
PHL
608
PH
Pitcairn Islands
PC
PN
PCN
612
PN
1910N
121 40 E
Baffin Bay
Arctic Ocean
73 00N
6600W
Baffin Island
19 55N
122 10 E
Balkan Peninsula
Albania, Bosnia and Herzegovina, Bulgaria,
Croatia, Greece, Romania, Serbia and
Montenegro, Slovenia, The Former Yugoslav
Republic of Macedonia, Turkey (European part)
42 00N
23 00E
Balleny Islands
20 SON
121 50 E
Bavaria (Bayern)
Celebes [island]
10 50N
124 50 E
Liancourt Rocks [claimed by Japan]
South Korea
3715N
131 50 E
Libreville [US Embassy]
16 00N
121 00 E
Luzon Strait
Pacific Ocean
121 00 E
Lyakhov Islands
Russia
138 00 E
M Macao
Macau
22 ION
11333E
Macedonia
The Former Yugoslav Republic of Macedonia
41 50 N
22 00E
Macquarie Island
14 35N
121 00 E
Manipa Strait
Pacific Ocean
320 S
127 23 E
Mannar, Gulf of
Indian Ocean
8 30N
79 00E
Manua Islands
125 00 E
Mindoro [island]
121 05 E
Mindoro Strait
Pacific Ocean
12 20N
120 40 E
Minicoy Island
120 21 E
Mozambique Channel
Indian Ocean
19 00S
41 00 E
Mumbai [US Consulate General]
10 00N
123 00 E
Netherlands East Indies
9 30N
11830E
Palermo
11 15N
122 30 E
Pantelleria, Isola di
12 00N
125 00 E
Samaria [region]
West Bank
3215N
3510E
Samoa Islands
American Samoa, Samoa
MOOS
171 00 W
Samos [island]
BOON
121 00 E
Sulu Sea
Pacific Ocean
8 00N
12000 E
Sumatra [island]','8e5308bb6f1a49e96019d11bb1d70b4924d55f2f3ecd248ce54cdfb371240e06','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('784711a9507eacee250c1c8b305f245fd9f557d483eaacc1027fccb405ba3d85',2000,'PL','Poland','space',632,'PL
PL
POL
616
PL
5423N
1840E
Dao Bach Long Vi [island]
Vietnam
20 08N
107 44 E
Dardanelles [strait]
Atlantic Ocean
4015N
2625E
Dar es Salaam [US Embassy]
Tanzania
648 S
3917E
Davis Strait
Atlantic Ocean
67 00N
57 00W
Dead Sea
Israel, Jordan, West Bank
32 30N
35 30E
Deception Island
52 25N
16 55E
Prague [US Embassy]
Czech Republic
40 55N
21 00 E
Praia [US Embassy]
Cape Verde
14 55N
23 31 W
Pretoria [US Embassy]
5215N
21 00 E
Washington, DC [US Mission to the Organization
of American States (OAS)]','16b1d78627a80b12b615593d276722d3cd8f3bb641e12fba1a097a4a4b47d3c4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8884ab160aed425f10b75d53a378484fec5a6cd6d327d959d926ead40c36502f',2000,'PT','Portugal','space',633,'PO
PT
PRT
620
PT
38 30N
28 00W
Azov, Sea of
Atlantic Ocean
49 00N .
36 00E
B
Bab el Mandeb [strait]
Indian Ocean
12 40N
43 20E
Babuyan Channel
Pacific Ocean
1844N
121 40 E
Babuyan Islands
38 43N
9 08W
L]ubl]ana [US Embassy]
32 40 N
16 45W
Madras (see Chennai)
3744N
2540W
Port-au-Prince [US Embassy]','23bf4100e2fe11b5d5b1028d56c0923f11e6b7bece9ff1e33cbcda4b058a7fab','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d2e65cd626070beaeefe5fedb490459cfca7616fba30fc95d72792a54ee91f5',2000,'QA','Qatar','space',634,'QA
QA
OAT
634
QA
Reunion
RE
RE
REU
638
RE
2517N
Donets Basin
Russia, Ukraine
4815N
38 30 E
Douala','64ffa4e44c4728cee90e22c82781dd169efb8bbcde90a4cacba55bb94c40ea68','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a030510fa3256bccdfd79d46ff22f59421cb400f16a0a804fca5ffd4d8eeccd',2000,'RO','Romania','space',635,'RO
RO
ROM
642
RO
Russia
RS
RU
RUS
643
RU
44 26N
26 06E
Budapest [US Embassy]
4647N
23 36E
Cochin China [region]
Vietnam
1100N
107 00 E
Coco, Isla del
46 30 N
24 00 E
Trindade, llha de','495e378d7e2537989f30886ddbaf9ed364e5b78d2b288c6a8031531a4c98062d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23abf77f4ce7507c824afaf2a4d9a7a1c498159ce0cf9f1a44cc6435a53871cc',2000,'KN','Saint Kitts and Nevis','space',636,'SC
KN
KNA
659
KN
1718N
62 43W
653
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Bastia
France (Corsica)
42 42N
9 27E
Basutoland
17 09N
62 35 Wl
Appendix H; Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
New Britain [island]
17 20N
6245W
Saint Christopher and Nevis
17 20N
62 45W
Saint-Denis
Reunion
20 52 S
55 28 E
Saint George''s [US Embassy]','22bd6a8ab97ef73c3373abe8079233ac7c3b7824c20d10de5cc6f7626724755d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ac3d3ac7bdb6d48015dede4160201cba961393e3642f46245effcc1b626105a',2000,'PM','Saint Pierre and Miquelon','space',637,'SB
PM
SPM
666
PM
4646N
5611 W
Saint Thomas [island]
Virgin Islands
18 21 N
64 55W
Saint Vincent Passage
Atlantic Ocean
13 30N
61 00 W
Saipan [island]','5e39d54b37eee529cf31df9fa1cfc6cd75ad1da9f1eea0a287410036dbd4d8db','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e26b22003624e5558ffa7cde623d272244a2de12d11c7e0d27664e13bdcfd651',2000,'VC','Saint Vincent and the Grenadines','space',638,'VC
VC
VCT
670
VC
61 12 W
Grenadines, Southern
Democratic Republic of the Congo
12 45N
61 15 W
Northern Ireland','d99d4c4fa502bff8eb9bc02f9f41b083bc48a06c106ad817abe5b1094447dac4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62c8668cfe30e780825450eab37e2be4e05e9be002bf23da5992a4bb6527ca6e',2000,'WS','Samoa','space',639,'WS
WS
WSM
882
WS
13 50S
171 44 N
Aqaba, Gulf of
Indian Ocean
29 00 N
34 30E
Aqmola (see Astana)
13 35S
172 20 W
Wetar Strait
Pacific Ocean
8 20S
126 30 E
White Sea
Arctic Ocean
65 30N
38 00 E
Willemstad
Netherlands Antilles
68 56W
Windhoek [US Embassy]','1f2c19c3f34c2b606134ed590728aeb0ba5b7183297d6c7b400937b3b3fe8233','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fc182a58dd2786da2b75c18855910207f2cf6f0408105822d70e93e3ad732f2',2000,'SM','San Marino','space',640,'SM
SM
SMR
674
SM
SaoTome and Principe
TP
ST
STP
678
ST
4356N
12 25E
San Salvador [US Embassy]','dbefe27d158d308e69f886c4851e1ec3847af47db590b8532fa93ca5f76fbdea','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6213e03b64d7df52c8cbe54f20dc46fbd87977fecebcd36533c71f09143a2730',2000,'SA','Saudi Arabia','space',641,'SA
SA
SAU
682
SA
50 08E
Dhaka [US Embassy]
2430N
38 30E
Helsinki [US Embassy]
21 SON
3912E
Jerusalem [US Consulate General]
Israel, West Bank
31 47 N
3514E
Jiddah [US Consulate General]
21 30 N
3912E
Johannesburg [US Consulate General]
21 27 N
3949E
Medan [US Consulate General]
24 38N
46 43 E
Road Town
British Virgin Islands
18 27N
64 37W
Robinson Crusoe Isiand (Mas a Tierra)','fa535f0d46453851fc85c4ce030fe59c963309a6e522db5a6e88d34b423eadfb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b93b67b49bcaf31385a6f86f5c759ca0597d041774e26aa8f51c4c4f55c68e3c',2000,'SN','Senegal','space',642,'SG
SN
SEN
686
SN
Serbia*
SR
—
—
—
—
see footnote at end of table
Serbia and Montenegro*
—
—
—
—
—
see footnote at end of table
1440N
1726W
Dalmatia [region]','0056b3399f846824ffd5215832612681cf7a9baca8bdedd26ef1a5a952cfd80a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70eedaa15aa1843e4b5f624de3b471c0bd5e98c0ee26d762aa17d3cda7b1d8ad',2000,'SC','Seychelles','space',643,'SE
SC
SYC
690
SC
925 S
4622E
Alderney [island]
7 01 S
52 45E
Amami Strait
Pacific Ocean
28 40N
129 30 E
Amindivi Islands
6 DOS
5310E
Amman [US Embassy]
9 46S
46 34E
Astana (Akmola)
943S
47 35E
Cotonou [US Embassy]
1010S
51 10 E
Fernando de Noronha
441 S
55 30 E
Maiz, Islas del (Corn Islands)
4 38S
55 27 E
Vienna [US Embassy, US Mission to International
Organizations in Vienna (UNVIE)]','aaf5c1fc839eafb66fd9642beb314daf5272a82dacb38be4183949a53a62e3aa','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b37ff9722dc144082142c5a99086c6be892691638f4b333c1a8aca143e924bf8',2000,'SG','Singapore','space',644,'SN
SG
SGP
702
SG
643
Appendix F: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS 10-4
ISO 3166
Internet
Comment
1 17N
103 51 E
Singapore Strait
Pacific Ocean
1 15N
104 00 E
Sinkiang (Xinjiang)','f1a6581a5a02ad8fa454b00c908b4a71e528c9f35f9368a2e9381692f5af2ebf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5728912a2702673a1a1a7482b225f158866f978f0f8f3b529d30df99392eac30',2000,'SK','Slovakia','space',645,'LO
SK
SVK
703
SK
48 09 N
17 07E
Brazzaville [US Embassy]
Republic of the Congo
416S
1517E
Bridgetown [US Embassy]','040c91289337957029243647ecc12c0c50ac70ec5fbe33836163417aded59183','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42de133509427943472bf6677d1f678d56376fa46e5fde61a75b0fad1f7bb044',2000,'SI','Slovenia','space',646,'SI
SI
SVN
705
SI
46 03N
14 31 E
Lobamba
Swaziland
26 27 S
31 12 E
Lombok Strait
Indian Ocean
8 30S
11550E
Lome [US Embassy]','e66976db4b8226ba77fab777eaf6267a8516ad9f9a4b309d6c2b3506ab426c6e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a31d5381dd0c2ac7d843143b57529df9a9aa7b1aee0cb406c7e4f8cb8cafb1ce',2000,'SB','Solomon Islands','space',647,'BP
SB
SLB
090
SB
8 00S
159 00 E
British Somaliland
Somalia-
10 00N
49 00 E
Brussels [US Embassy, US Mission to European
Union (USEU), US Mission to the North Atlantic
Treaty Organization (USNATO)]
121 00 E
Christmas Island [Indian Ocean]
9 32S
160 12 E
Guadalupe, Isla de
926 S
159 57 E
Honshu [isiand]
1100S
166 15 E
Santiago [US Embassy]
8 00S
159 00 E
Solomon Sea
Pacific Ocean
8 00S
153 00 E
Songkhia','0ac5c6f5c5388dcefcd6f20cc19971ed5462feb575facd253af6023cdda4655f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a609f157a1a81acffc2ac8c65e03741418d83eb6ed550af2e1bc3acc9edc7d8d',2000,'SO','Somalia','space',648,'SO
SO
SOM
706
SO
49 00 E
Iturup (see Etorofu)
Russia [de facto]
147 40 E
Ivory Coast
Cote d''Ivoire
5 00W
Iwo Jima [island]
2 04N
45 22 E
Moldavia [region]
Moldova, Romania
47 00 N
29 00 E
Moluccas (Spice Islands)','9a22f7ecb016ef3b5de57f7890987b6489c235a2665231ff885581903abd4a09','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fc6cc3b8fab9000b1cff7e2a243e8dc38f6e8e28245b38adf2943803cad5b80',2000,'ZA','South Africa','space',649,'SF
ZA
ZAF
710
ZA
South Georgia and the South
Sandwich Islands
SX
GS
SGS
239
GS
Southern Ocean
—
—
—
—
—
2912S
26 07E
Boa Vista [island]
Cape Verde
16 05N
22 SOW
Bogota [US Embassy]
26 30 S
25 30E
Bora-Bora [island]
33 55 S
18 22E
Caracas [US Embassy]
Venezuela
10 30N
66 56W
Cargados Carajos Shoals
33 00S
27 00 E
Ciudad Juarez [US Consulate General]
29 55 S
30 56 E
Dushanbe [US Embassy]
34 24 S
18 30E
Goteborg
2615S
28 00 E
Juan de Fuca, Strait of
Pacific Ocean
4818N
124 00 W
Juan Fernandez, Isla de
46 51 S
3752E
Marmara, Sea of
Atlantic Ocean
4040N
2815E
Marquesas Islands (lies Marquises)
25 45S
2810E
Prevlaka peninsula
46 35S
38 00E
Prince Patrick Island
3215S
2815E
Transylvania [region]
23 00S
31 OOE
Verde Island Passage
Pacific Ocean
13 34N
120 51 E
Victoria','4f9fa245782e4f309ecef9358b4900053ab03014ed7c03c74a76353356323a37','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5287d4450de7ffca22f43599efa466ac0d0e0db075b30f6713b8f4d8d2bd0bc',2000,'ES','Spain','space',650,'SP
ES
ESP
724
ES
Spratly Islands
PG
—
—
—
—
3513N
353W
Alma-Ata (see Almaty)
39 30N
3 00E
Balearic Sea (Iberian Sea)
Atlantic Ocean
40 30N
2 00E
Bali [island]
41 23 N
211 E
Barents Sea
Arctic Ocean
74 00N
36 00 E
Barranquilla
43 DON
230W
Bass Strait
Pacific Ocean
3920S
145 30 E
Basse-Terre
258W
Bioko [island]
28 00 N
15 30W
Canberra [US Embassy]
2 00E
Cato Island
35 53 N
519W
Ceylon
3512N
2 26W
Chagos Archipelago (Oil Islands)
4000N
400W
Essequibo [region] [claimed by Venezuela]
15 24W
Lau Group
40 24N
3 41 W
Magellan, Strait of
Atlantic Ocean
54 00S
71 00 W
Maghreb
Algeria, Libya, Mauritania, Morocco, Tunisia
30 00 N
5 00E
Mahe Island
39 30N
3 00E
Ma]uro [US Embassy]
39 30 N
300 E
Malpelo, Isla de
3519N
2 58W
Merida [US Consulate]
40 00 N
4 00E
Mitia Pass
3511 N
418W
Venda','91816fa507e5934be6290ad527ab76adf9304598be3971531d58eabffbd4d425','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d97cac84579915d152f174dd039e4fd46ced191f3fe221e724bb980c0efd3cb0',2000,'LK','Sri Lanka','space',651,'CE
LK
LKA
144
LK
7 00N
81 00 E
Chafarinas, Islas
6 56N
79 51 E
Colon, Archipielago de (Galapagos Islands)','53ed081ceefeb844ee13ffe59f03e3b12ea20e663e3feba7b129418221fb2bb8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('713836eea1b655370c8fef9c4b4e9a57de320c6113557d9ee44ef077c882a693',2000,'SR','Suriname','space',652,'NS
SR
SUR
740
SR
Svalbard
SV
SJ
SJM
744
SJ
ISO includes Jan Mayen
Swaziland
WZ
SZ
SWZ
748
SZ
4 00N
56 00 W
Dutch West Indies
Netherlands Antilles
52 05N
418E
Dzungarian Gate
China, Kazakhstan
45 25 N
82 25E
East China Sea
Pacific Ccean
30 00 N
126 00 E
East Frisian Islands
4 00N
56 00 W
Nevis [island]
5 50N
5510W
Parece Vela [island]
4 00N
56 00W
Suva [US Embassy]','cba0733cd2114d2c1d4df395e1fa897571ea234137d01af473a0d8eb304dcbbf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af5717175330643ad7d4cddba620b44b0e78416dc0fc965be43f3a7380f01386',2000,'SE','Sweden','space',653,'SW
SE
SWE
752
SE
57 43N
11 58 E
Gotland [Island]
57 30N
18 33E
Gough Island
Saint Helena
9 45W
Grand Banks
Atlantic Ocean
55 48W
Grand Cayman [island]
59 20N
18 03E
Strasbourg [US Consulate General]','db3aa7bd63add4ead0005e278b5eab53509170055e76df3841eca0c11623cf30','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb1e7fa602de6dd727aac7e1d6e6ceab4a82359d39438e509134bdd24aea16b',2000,'CH','Switzerland','space',654,'SZ
CH
CHE
756
CH
Syria
SY
SY
SYR
760
SY
Taiwan
TW
TW
TWN
158
TW
46 57N
7 26E
Bessarabia [region]
Romania, Moldova, Ukraine
47 00N
28 30 E
Bhopal
4612N
610E
Genoa
47 23N
8 32E
676
I^NTARCTipl^ON
■ Year-round research station
Scale 1:68,000,000
Azimuthal Equal-Area Projection
/ 0 500 1000 Kilometers
Nineteen of 26 Antarctic consultative nations have made
no claims to Antarctic territory (although Russia and the
United States have reserved the right to do so) and they do
not recognize the claims of the other nations.
Georgia and the
"South Sandwi^sh Islands
(administered b)*,U.K.,
clairne^by ARCEt^NAV
Port Elizabeth
South] Atlantic
!
Ocean
BRITISH
CLAIM ^
-...Falkland Islands /
llslas Malvinas) /
(administered by U.k.,
claimed by''ARCENfiNA)
ARGENTINE \\
CLAIM^^'' \\
ScotaSci j^(ARQEMTmA)
/> SOUTH ORKNEY
Southern
Ocean
SANAE
(soujm
AFRICA)','e4a663866a1f148828d59523e9c10df8234875327575abca903d4d3d5b1bfb01','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e55ab5fd0321dd5237ee49b142b3202ae607ffddb4607cb2c272c19a5dbdfd',2000,'TJ','Tajikistan','space',655,'Tl
TJ
TJK
762
TJ
Tanzania
TZ
TZ
TZA
834
TZ
38 35 N
68 48 E
Dutch Antilles
Netherlands Antilles
52 05N
418E
Dutch East Indies','d5747dddb94b73a41e0778f8c7f7cc68ab1105733423c35a422883fb2af76b15','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a209bcce52d4a10b7bed43b94a2f0695d34394ecc383c8eadbf4b0789601d834',2000,'TH','Thailand','space',656,'TH
TH
THA
764
TH
1345N
100 31 E
Bangui [US Embassy]
18 47N
98 59 E
Chihli, Gulf of (see Bo Hai)
Pacific Ocean
38 30N
120 00 E
China, People''s Republic of
15 00N
100 00 E
Siberia [region]
Russia
60 00 N
100 00 E
Sibutu Passage
Pacific Ocean
4 50N
119 35 E
Sicily [island]
712N
100 36 E
Sound, The (Oresund)
Atlantic Ocean
55 50N
12 40E
South Atlantic Ocean
Atlantic Ocean
30 00S
15 00W
South China Sea
Pacific Ocean
10 00N
11300E
South Georgia [island]
1726N
10246 E
Ulaanbaatar [US Embassy]','1cd00264664127017dc426df6411dd542525e9b7fc572ee33ca543d469fa8622','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da5a4afe29ce8a942579b9e7ee2726d4dd83512457514f799b12e7d93b2c662',2000,'TG','Togo','space',657,'TO
TG
TGO
768
TG
SOON
1 10E
French West Indies
Guadeloupe, Martinique
16 SON
62 OOW
Friendly Islands
6 08N
1 13E
London [US Embassy]','be83fea562317f29aa00c17fcd928006c90ebde1ee588c17db7a225f10a0d212','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc3afc19472b46019f2a2e2a2ddc06ee93a6ccdc1e4c9dd4d521d83374670f9d',2000,'TO','Tonga','space',658,'TN
TO
TON
776
TO
20 00 S
175 OOW
Frisian Islands
Denmark, Germany, Netherlands
53 35N
640 E
Frunze (see Bishkek)
19 42S
174 29 W
Habomai Islands
Russia [de facto]
4330N
146 10 E
Hadhramaut [region]
21 OSS
175 12 W
Nuevo Laredo [US Consulate]','864ff12159c0516ee1b8672e5bf93e9132cfeef6b148f3cb6d81c554cd182cfa','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b94193861059dca7f30b15925356b84a692e58910fd68c3c2d16b84819519f7',2000,'TT','Trinidad and Tobago','space',659,'TD
TT
no
780
TT
Tromelin Island
TE
—
—
—
—
ISO includes with the Miscellaneous
(French) Indian Ocean Islands
1039N
61 31 W
Porto-Novo
11 15N
60 40W
Tokyo [US Embassy]','1c357c36afed5de09f9830e62ea5383cdf4e046679bfe6e56fa7a9f51d848c7b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db01ef7c30ea9e414d4ae107377b13edc95c78f1edd3da51a1e0fe196e91942',2000,'TM','Turkmenistan','space',660,'TX
TM
TKM
795
TM
37 57N
58 23 E
Ashkhabad (see Ashgabat)
58 23 E
Asmara [US Embassy]
40 00N
60 00 E
Turks Island Passage
Atlantic Ocean
21 40 N
71 00 W
Tuscany [region]','e1445ea66f3f668af89e269061eeb7d77fe9c6f1bc9ded1b1b5fc6af3c1d7f28','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eae81dd1058dfad1b95611bc5770ccb3747c7b2d834791c5a0cc5e936a342356',2000,'TC','Turks and Caicos Islands','space',661,'TK
TC
TCA
796
TC
21 56 N
71 58 W
Cairo [US Embassy]
21 28 N
71 08 W
Great Australian Bight
Indian Ocean
35 00 S
130 00 E
Great Belt (Store Baelt)
Atlantic Ocean
11 00 E
Great Bitter Lake','5ddf83a6e96f8c329cb5e5199217c9718ba258955d4d1f221f7571f2ef189133','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('660815f51811afc885d973a0628a332b1ec6f38c03167dcb4f27c523aa065ad7',2000,'TV','Tuvalu','space',662,'TV
TV
TUV
798
TV
800S
178 00 E
Elobey, Islas de
8 SOS
179 12 E
Fundy, Bay of
Atlantic Ocean
45 00N
66 OOW
Futuna Islands (Hoorn Islands/lles de Horne)','ba6155fc8ae5d26dac1cf1966d545661dbfdfd6465d1b9ca2c3c1f764cbfc43b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67595f7ca5056f527d20f527008300b7766c9401b506fc40055057b69e27ae6b',2000,'UA','Ukraine','space',663,'UP
UA
UKR
804
UA
45 00N
34 00E
Crimean Peninsula
45 00N
34 00E
Crooked Island Passage
Atlantic Ocean
22 55 N
74 35W
Crozet Islands (lies Crozet)
French Southern and Antarctic Lands
46 30S
51 00 E
Curacao [US Consulate General]
Netherlands Antilles
1211 N
69 00W
Cyclades [islands]','37963729b663a400ad8ea57d1297fed452d47196912ffb8bb09e16597b0f2bc7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fda801f0f611bbd01789987a618188cdfcfe69ceeafc4c79797433f71cd7e497',2000,'AE','United Arab Emirates','space',664,'TC
AE
ARE
784
AE
24 28N
5422E
Abu Musa [island]
Iran
25 52N
55 03E
Abuja [US Embassy Branch Office]
5518E
Dubayy (see Dubai)
5518E
Dublin [US Embassy]
24 00N
54 00 E
Trucial Oman
24 00N
54 00E
Trucial States
24 00N
54 00 E
Truk Islands
Federated States of Micronesia
7 25N
151 47 E
Tsugaru Strait
Pacific Ocean
41 35 N
141 00 E
674
Appendix H; Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Tuamotu Islands (lies Tuamotu)','103fa4ee71365b842c1edb1c1b237418b786c9ca865305a6203bf6dadc9fd24c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68692ef458ac5a256f791fd18d122fb80c479549df278e9c20b2ae3c6df482a9',2000,'GB','United Kingdom','space',665,'UK
GB
GBR
826
UK/GB
ISO includes Guernsey, Isle of Man,
54 35 N
5 55W
Belgian Congo
Democratic Republic of the Congo
OOON
25 00E
Belgrade
Serbia and Montenegro
20 30 E
Belize City [US Embassy]
49 52 N
6 27W
Bismarck Archipelago
54 00N
200W
British East Africa
Kenya, Tanzania, Uganda
1 00 N
38 00E
British Guiana
55 57 N
313W
Eire
52 30N
1 SOW
English Channel
Atlantic Ocean
5020N
1 OOW
Eniwetok Atoll (see Enewetak Atoll)
54 00N
2 00W
Great Channel
Indian Ocean
6 25N
94 20 E
Greater Sunda Islands
Brunei, Indonesia, Malaysia
2 00S
11000E
Green Islands
51 30 N
010W
Longyearbyen
Svalbard
7813N
15 33E
Lord Howe Island
54 40N
6 45W
Northern Rhodesia
3 00W
Osaka-Kobe [US Consulate General]
57 35N
13 48W
Rodrigues [island]
60 30 N
130W
Shikoku [island]
52 30 N
330W
Wallis Islands','c8f7b6af36b126bd4db98432578452f15de3080cca29637091498ac2b125c15c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd539872df0798b7eca0019c917ee563f0f4f90c579ae34034439e798ad04c88',2000,'US','United States','space',666,'US
US
USA
840
US
United States Minor Outlying
Islands
UM
UMI
581
UM
ISO includes Baker Island, Howland
Island, Jarvis Island, Johnston Atoll,
Kingman Reef, Midway Islands,
Palmyra Atoll, Wake Island
65 00N
153 00 W
Alaska, Gulf of
Pacific Ocean
58 00N
145 00 W
Aldabra Islands (Groupe d’Aldabra)
172 57 E
Auckland [US Consulate General]
20 00N
157 45 W
Heard Island
Russia
Federated States of Micronesia
Pacific Ocean
North Korea
South Korea
Pacific Ocean
40 43 N
74 01 W
Newfoundland [island]
21 SON
158 00 W
Ocean Island (Banaba)
28 25 N
178 20 W
Ogaden [region]
Ethiopia, Somalia
700 N
46 00E
Oil Islands (Chagos Archipelago)
57 00N
170 00 W
Prince Edward Island
55 35N
131 06 W
669
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Revillagigedo Islands
49 30N
67 00W
Saint Lawrence Seaway
Atlantic Ocean
4915N
67 00W
Saint Martin [island]
5711 N
170 16 W
670
Appendix H: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Saint Paul Island (He Saint-Paul)
French Southern and Antarctic Lands
3843S
7729E
Saint Peter and Saint Paul Rocks
(Penedos de Sao Pedro e Sao Paulo)
38 53N
77 02W
Weddell Sea
Southern Ocean
72 00S
45 00 W
Wellington [US Embassy]','a1fa75fef18283312f0d29552861f740ae07f4f8d60f74ba03cd8d79f31a6a6c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7801d65afd95ad6271efc7c30f2f30c4f01394dd7bcfb256a745b085fa37d64a',2000,'UZ','Uzbekistan','space',667,'uz
UZ
UZB
860
UZ
Formosa [island]
Taiwan
23 SON
121 00 E
Formosa Strait (see Taiwan Strait)
Pacific Ocean
24 00N
119 00 E
Fortaleza [US Consular Agency]
41 20 N
6918E
Tasmania [island]
6918E
Transjordan','e5d37bb3e5c212bb2ade75bdfa06e04c4395b0380bfb256b871397f428362c24','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2733ea5860447d44fbd9021f8e4630b4436dd1e2ef9319d4ac7f039ba09612f8',2000,'VU','Vanuatu','space',668,'NH
vu
VUT
548
VU
Venezuela
VE
VE
VEN
862
UE
Vietnam
VM
VN
VNM
704
VN
Virgin Islands
VQ
VI
VIR
850
VI
Virgin Islands (UK)
—
—
—
—
—
see British Virgin Islands
Virgin Islands (US)
—
—
—
—
—
see Virgin Islands
V/ake Island
WQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
14 DOS
167 30 E
Barbuda [island]
16 00S
167 00 E
New Siberian Islands
Russia
75 00 N
142 00 E
New Territories
17 44S
168 19 E
Poznan','c31443464914be434445025a6585b481512004d61fdc9cd296ae310f13565868','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc5d10e444c5b5e5ab8f16a4cd41ef3272d983c475a185bd10decdbbbee939c0',2000,'WF','Wallis and Futuna','space',669,'WF
WF
WLF
876
WF
West Bank
WE
—
—
—
—
1419S
178 05 W
G
Gaborone [US Embassy]
1419S
178 05 W
Horn of Africa
Djibouti. Eritrea, Ethiopia, Somalia
8 00N
48 00E
Hudson Bay
Arctic Ocean
60 00 N
86 00W
Hudson Strait
Arctic Ocean
62 00N
71 00 W
Hunter Island
New Caledonia, Vanuatu
2224S
172 06 E
Iberian Peninsuia
Portugal, Spain
40 00N
5 00W
Inaccessible Island
Saint Helena
3717S
1240W
Indochina
Cambodia, Laos, Vietnam
15 00N
107 00 E
Inland Sea
13 57S
171 56 W
Matsu [Island]
Taiwan
2613N
11956E
Matthew Island
New Caledonia, Vanuatu
2220S
171 20 E
Mazatlan
1317S
176 low
Walvis Bay','75d62ef6267cfd9973df4bf4f02029d417505e2beeb383b821152e3aa1cfc5d3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdf0dba37852060fdf5ef3de6c342d5112fbaf99c954a2cfa259a2d03171b4fe',2000,'EH','Western Sahara','space',670,'Wl
EH
ESH
732
EH
Western Samoa
—
—
—
—
—
see Samoa
World
the Factbook uses the W data code
from DIAM 65-18 Geopolitical Data
Elements and Related Features, Data
Standard No. 3, December 1994,
published by the Defense Intelligence
Agency
2345N
15 45W
Rio Muni
2430N
1300W
Spice Islands (Moluccas)','01f680595f43d585705acc0f1c909974790987f1647bfdb047f7c9e3439c376c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80ea36cb0c42cc24ee4ce4628ecad12f418ea27b1fe97ac0bcd7d68502afe7c1',2000,'YE','Yemen','space',671,'YM
YE
YEM
887
YE
Yugoslavia*
—
YU
YUG
891
YU
see footnote at end of table
Zaire
—
—
—
—
—
see Democratic Republic of the Congo
1246N
45 01 E
Aden, Gulf of
Indian Ocean
12 30N
48 00E
Admiralty Island
United States (Alaska)
5744N
134 20 W
Admiralty Islands
15 DON
5000E
Hagatna (Agana)
1521 N
42 34E
Kamchatka Peninsula (Poluostrov Kamchatka)
Russia
56 00 N
160 00 E
Kampala [US Embassy]
15 00N
44 00E
Northeast Providence Channel
Atlantic Ocean
25 40N
77 09W
Northern Epirus
Albania, Greece
40 00N
20 30 E
Northern Grenadines
12 39N
43 25E
Perouse Strait, La
Pacific Ocean
44 45N
142 00 E
Persia
Iran
32 00N
53 00E
Persian Gulf
Indian Ocean
27 00 N
51 00 E
Perth [US Consulate General]
15 21 N
4412E
San Ambrosio, Isla
12 30N
54 00E
Sofia [US Embassy]
14 00N
48 00E
South-West Africa
14 00N
46 00 E
Yemen Arab Republic
15 00N
44 00E
Yemen, North [Yemen Arab Republic]
15 00N
44 00E
Yemen (Sanaa) [Yemen Arab Republic]
15 00N
44 00E
Yemen, People''s Democratic Republic of
14 00N
46 00E
Yemen, South [Peopie''s Democratic Republic of Yemen]
14 00N
46 00E
Yerevan [US Embassy]','5e1df774a338b7997c0644b44d109a5ba23663c993e01655c7e467fc5adef07d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd704428c6387120fd7918f9b2672f42f19c2b7ed0df2f096092b928668a7f8c',2000,'ZM','Zambia','space',672,'ZA
ZM
ZWB
894
ZM
15 25S
2817E
Luxembourg [US Embassy]
15 00S
30 00E
Northwest Passages
Arctic Ocean
74 40N
100 00 W
Norwegian Sea
Atlantic Ocean
66 00 N
6 00E
Nouakchott [US Embassy]
15 00S
30 00 E
Rhodesia, Southern','0f6913c25809913218c972c3bb0fff5ad8d22d0388301ae8f9a72b048bdeb584','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925b680960d625d4c33b55395741fe440f3513a35a2e42135d89c33d519c3e8d',2000,'ZW','Zimbabwe','space',673,'Zl
ZW
ZWE
716
ZW
•Serbia and Montenegro have asserted the formation of a joint independent state, but this entity has not been formally recognized as a state by the US; the US view is
that the Socialist Federal Republic of Yugoslavia (SFRY) has dissolved and that none of the successor republics represents its continuation.
645
Appendix G:
Cross-Reference List of Hydrographic Data Codes
IHO 23-4th:
Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1 986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IHO 23-3rd;
Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1 953, published by the International Hydrographic Organization
ACICM49-1;
Chart of Limits of Seas and Oceans, revised January 1 958, published by the Aeronautical Chart and Information Center
(AGIO), United States Air Force; note— AGIO is now part of the National Imagery and Mapping Agency (NIMA)
DIAM 65-18:
Geopoliticat Data Elements and Related Features, Data Standard No. 4, Defense Intelligence Agency Manual 65-18,
December 1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal Information Processing
Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always directly
comparable because of differences in the customers, needs, and requirements of the individual organizations. Even the
number of principal water bodies varies from organization to organization. Facfboo/r users, for example, find the Atlantic Ocean
and Pacific Ocean entries useful, but none of the following standards include those oceans in their entirety. Nor is there any
provision for combining codes or overcodes to aggregate water bodies. The recently delimited Southern Ocean is not included.
Principal Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
IHO
ACIC
DIAM
23-4th
23-3rd*
M49-1
65-18
Arctic Ocean
9
17
A
5A
Atlantic Ocean
—
—
—
—
North Atlantic Ocean
1
23
B
1A
South Atlantic Ocean
4
32
G
2A
Baltic Sea
2
1
B26
7B
Indian Ocean
5
45
F
6A
Mediterranean Sea
3.1
28
B11
—
Eastern Mediterranean
3.1.2
28 B
—
8E
Western Mediterranean
3.1.1
28 A
—
8W
Pacific Ocean
—
—
—
—
North Pacific Ocean
7
57
D
3A
South Pacific Ocean
8
61
E
4A
South Ghina and Eastern Archipelagic Seas
6
49, 48
D18plus others
3U plus others
Oceans and Seas of the World With
Hydrographic Codes by Institution
IHO
23-4th
IHO
23-3rd*
ACIC
M49-1
DIAM
65-18
ARCTIC OCEAN
9
17
A
5A
East Siberian Sea
9.1
11
A6
5S
Laptev Sea
9.2
10
A5
5P
Kara Sea
9.3
9
A4
5K
Barents Sea
9.4
7
A2
5B
White Sea
9.5
8
A3
5W
North Greenland Sea
9.6
—
—
—
646
I
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M49-1
DIAM
65-18
Norwegian Sea
9.7
6
B30
5N
Iceland Sea
9.8
—
—
—
Davis Strait
9.9
15
B2
IV
Hudson Strait
9.10
16A
A15
1U
Hudson Bay
9.11
16
A10
1H
Baffin Bay
9.12
14A
A12
IP
Lincoln Sea
9.13
17A
A13
5L
Northwest Passages (Northwest Passage,
Northwestern Passages)
9.14
14
A9
5T
Beaufort Sea
9.15
13
A8
5U
Chukchi Sea
9.16
12
A7
5C
James Bay
—
—
All
—
Kane Basin
—
—
A14
—
ATLANTIC OCEAN (see North Atlantic Ocean
and South Atlantic Ocean)
—
—
—
—
BALTIC SEA
2
1
B26
7B
Gulf of Bothnia
2.1
1(a)
B29
7T
Gulf of Finland
2.2
1(b)
B28
7F
Gulf of Riga
2.3
1(c)
B27
7H
The Sound
2.4
2
—
—
The Great Belt
2.5
2
—
—
The Little Belt
2.6
2
—
—
Kattegat
2.7
2
B25
7K
INDIAN OCEAN
5
45
F
6A
Mozambique Channel
5.1
45 A
FI
6Z
Gulf of Suez
5.2
35
F5
6W
Gulf of Aqaba
5.3
36
—
6Q
Red Sea
5.4
37
F4
6E
Gulf of Aden
5.5
38
F3
6D
Persian Gulf (Gulf of Iran)
5.6
41
F7
6P
Gulf of Oman
5.7
40
F6
6M
Arabian Sea
5.8
39
F2
6R
Laccadive Sea (Lakshadweep Sea)
5.9
42
F9
6L
Gulf of Mannar
5.10
—
F8
—
Palk Strait and Palk Bay
5.11
—
—
—
Bay of Bengal
43
F10
6B
Andaman Sea (Burma Sea)
5.13
44
F11
6N
Strait of Malacca (Malacca Strait)
5.14
46(a)
FI 2
6C
Great Australian Bight
5.15
62
F21
6G
Suez Canal
—
—
—
6U
MEDITERRANEAN REGION
3
—
—
—
Mediterranean Sea
3.1
28
B11
—
Mediterranean Sea, Western Basin
3.1.1
28 A
—
8W
Strait of Gibraltar
3.1.1.1
28(a)
B7
8S
Alboran Sea
3.1. 1.2
28(b)
—
8Y
647
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
IHO
ACIC
DIAM
23-4th
23-23rd*
M49-1
65-18
Balearic Sea (Balear Sea, Iberian Sea)
3.1. 1.3
28(c)
B9
8J
Ligurian Sea (Ligure Sea)
3.1. 1.4
28(d)
BIO
8L
Tyrrhenian Sea (Tirreno Sea)
3.1. 1.5
28(e)
B12
8T
Mediterranean Sea, Eastern Basin
3.1.2
28 B
—
8E
Adriatic Sea
3.1. 2.1
28(g)
B14
8D
Strait of Sicily (Strait of Sicilia)
3.1. 2.2
—
—
—
Ionian Sea
3.1. 2.3
28(f)
B13
8N
Aegean Sea
3.1. 2.4
28(h)
B15
8G
Sea of Marmara
3.2
29
B16
8M
Black Sea
3.3
30
B17
8B
Sea of Azov
3.4
31
B18
8Z
Gulf of Lion (Gulf of Lions)
—
—
B8
8X
Aral Sea
—
—
—
8R
Bosporus
—
—
—
8P
Caspian Sea
—
—
—
8C
Dardanelles
—
—
—
8U
NORTH ATLANTIC OCEAN
1
23
B
1A
Skagerrak
1.1
3
B24
IS
North Sea
1.2
4
B23
IN
Inner Seas off the West Coast of Scotland
1.3
18
—
IK
Irish Sea and Saint Georges Channel
1.4
19
B22
1R, IQ
Bristol Channel
1.5
20
B21
1C
Celtic Sea
1.6
21 A
—
—
English Channel
1.7
21
B20
IE
Bay of Biscay
1.8
22
B19
IB
Canarias Sea
1.9
—
—
—
Gulf of Guinea
1.10
34
C4
1G
Caribbean Sea
1.11
27
B6
IX
Gulf of Mexico
1.12
26
B5
1M
Bay of Fundy
1.13
25
B4
IF
Gulf of Saint Lawrence
1.14
24
B3
IT
Labrador Sea
1.15
15 A
—
1L
Greenland Sea
1.16
5
A1
5G
Denmark Strait
—
—
B1
ID
Lake Erie
—
—
—
9E
Lake Huron
—
—
—
9H
Lake Michigan
—
—
—
9M
Lake Ontario
—
—
—
9N
Lake Superior
—
—
—
9S
Panama Canal
—
—
—
1J
Saint Lawrence Seaway
—
—
—
9L
NORTH PACIFIC OCEAN
7
57
D
3A
Philippine Sea
7.1
56
D26
3P
Taiwan Strait (Formosa Strait)
7.2
—
D17
3F
East China Sea (Tung Hai)
7.3
50
D13
3E
Yellow Sea (Huang Hai, Hwang Hai)
7.4
51
D14
3Y
648
Appendix G; Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M49-1
DIAM
65-18
Bo Hai (Bo Sea, Gulf of Chihli)
7.5
—
D16
3X
Liaodong Wan (Liaodong Gulf)
7.6
—
—
—
Inland Sea of Japan (Seto Naikai)
7.7
53
—
3N
Sea of Japan (Japan Sea)
7.8
52
Dll
3J
Gulf of Tartary
7.9
—
DIO
—
Sea of Okhotsk
7.10
54
D8
3Q
Bering Sea
7.11
55
D6
5D
Anadyrskiy Zaliv (Anadyrskiy Gulf)
7.12
—
—
5Y
Gulf of Alaska
7.13
58
D4
5F
Coastal Waters of Southeast Alaska and
7.14
59
D3
5E
British Columbia
Gulf of California
7.15
60
D2
3L
Gulf of Panama
7.16
—
D1
—
Amurskiy Liman
—
—
D27
—
Bering Strait
—
—
D7
5R
Bristol Bay
—
—
D5
—
Korea Bay
—
—
D15
3R
Korea Strait
—
—
D12
—
Sakhalinskiy Zaliv
—
—
D28
3B
Zaliv Shelikhova (Zaliv Shelekhova)
—
—
D9
3K
Luzon Strait
—
—
—
31
Tatar Strait
—
—
—
3D
PACIFIC OCEAN (see North Pacific Ocean
—
—
—
—
1 and South Pacific Ocean)
SOUTH ATLANTIC OCEAN
4
32
C
2A
Rio de la Plata
4.1
33
Cl
2R
Drake Passage
—
—
C5
2D
Golfo San Matlas
—
—
C2
2M
Golfo San Jorge
—
—
C3
2J
Scotia Sea
—
—
C6
2S
Weddell Sea
—
—
C7
2W
SOUTH CHINA AND EASTERN
6
49 and 48
D18 plus Others
3U plus others
1 ARCHIPELAGIC SEAS
South China Sea (Nan Hai)
6.1
49
D18
3U
Gulf of Tonkin
6.2
—
D19
3G
Gulf of Thailand (Gulf of Siam)
6.3
47
D20
3T
Natuna Sea
6.4
—
—
—
Singapore Strait
6.5
46(b)
—
3Z
Sunda Strait
6.6
—
—
—
Java Sea (Jawa Sea)
6.7
48 (n)
FI 3
4J
Makassar Strait (Makasar Strait)
6.8
48 (m)
El
4M
Bali Sea
6.9
48(1)
FI 4
4L
Flores Sea
6.10
48®
FI 6
4F
Sumba Strait
6.11
—
—
—
Savu Sea (Sawu Sea)
6.12
48(0)
FI 5
6S
649
Appendix G: Cross-Reference List of Hydrographic Data Codes (continued)
IHO
23-4th
IHO
23-23rd*
ACIC
M4g-i
DIAM
65-18
Timor Sea
6.13
48 (i)
F19
6T
Joseph Bonaparte Gulf
6.14
—
F20
—
Gulf of Carpentaria
6.15
—
E4
4P
Arafura Sea
6.16
48(h)
E3
4U
Aru Sea
6.17
—
—
—
Banda Sea
6.18
48(g)
E2
4B
Teluk Bone (Gulf of Bone, Gulf of Boni)
6.19
48 (k)
FI 7
4E
Ceram Sea (Seram Sea)
6.20
oo
D25
4Q
Gulf of Berau
6.21
—
—
—
Halmahera Sea
6.22
48(e)
D24
3H
Molucca Sea (Molukka Sea, Maluku Sea)
6.23
48(c)
D23
3M
Teluk Tomini (Gulf of Tomini)
6.24
48(d)
F18
3V
Sulawesi Sea
6.25
—
—
—
Mindanao Sea
6.26
—
—
—
Sulu Sea
6.27
48(a)
D21
3S
Celebes Sea
—
48 (b)
D22
3C
SOUTH PACIFIC OCEAN
8
61
E
4A
Bismarck Sea
8.1
66
E6
4K
Solomon Sea
8.2
65
E7
4S
Torres Strait
8.3
—
E5
—
Coastal Waters of Great Barrier Reefs
8.4
—
—
—
Coral Sea
8.5
64
E9
4C
Tasman Sea
8.6
63
E10
4T
Bass Strait
8.7
62 A
F22
6F
Amundsen Sea
—
—
E12
4D
Bellingshausen Sea
—
—
E13
4G
Cook Strait
—
—
E8
—
Ross Sea
—
—
Ell
4R
* The letters after the numbers are subdivisions, not footnotes.
Appendix H:
Cross-Reference List of Geographic Names
This list indicates where various geographic names— political or geographical portions of larger entities— Geographic Names (BGN). Additional information is
including the location of all United States Foreign can be found in The World Factbook. Spellings are included in brackets.
Service Posts, alternate names, former names, and normally those approved by the US Board on
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Abidjan [US Embassy]
Cote d''Ivoire
519N
4 02W
Abkhazia [region]
17 SOS
31 03 E
Hatay [province]
Turkey
36 30N
3615E
Havana [US post not maintained; representation by US
Interests Section (USiNT) of the Swiss Embassy]
20 00 S
30 00 E
Rhodesia, Northern
20 00 S
30 00 E
Riga [US Embassy]
1750S
105 00 W
Salvador de Bahia [US Consular Agency]
20 00S
30 00E
Soviet Union
Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
Spanish Guinea','7618e6bb41eeaaa56e3955433d4c3a6dec28731a91d4750861f893c36b109813','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4e69c1383a76bf2fb8d47067e5130e81b629d7679a1163c9161dcc5e8c9fa04',2000,'GS','South Georgia and the South Sandwich Islands','space',674,'41 48 W
Black Sea
Atlantic Ocean
43 00 N
35 00 E
654
Appendix H; Cross-Reference List of Geographic Names (continued)
Latitude
Longitude
Name
Entry in The World Factbook
(deg min)
(deg min)
Bloemfontein
5415S
36 45 W
Guadalajara [US Consulate General]
53 33S
42 02W
Shanghai [US Consulate General]
5415S
36 45W
South Island
5745S
26 30 W
South Shetland Islands','0f9961028f6999e4ce02c5fea23997afcb979c578df8ec6b896d7504d52569d7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd886a90adedd2851057d8f776020c17786de8ed9e6176920f05196a4076dc15',2000,'KR','Korea, Republic of','space',675,'Korea Strait
Koror [US Embassy]
Kosovo [region]
Kowloon
Kra, Isthmus of
Krakatoa [volcano]
Krakow [US Consulate General]
Kuala Lumpur [US Embassy]
Kunashiri (Kunashir) [island]
Kunlun Mountains
Kuril Islands
Kuwait [US Embassy]
Kuznetsk Basin
Kwa]alein Atoll
Kyushu [island]
Kyyiv (see Kiev)
Labrador
Laccadive Islands
Laccadive Sea
Lagos [US Embassy]
Lahore [US Consulate General]
Lakshadweep (Laccadive Islands)
La Paz [US Embassy]
Entry in The World Factbook
China, Mongolia
Russia
China, Russia','901195227c07f9bb5aa07f59852406bc607606c8da1a47d5f59880486c50756f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f1e959666c5f509076270c638a8d08763e3032b803d53413d48317e52f5609c',2000,'ST','Sao Tome and Principe','space',676,'1 38 N
725 E
Prussia [region]
Germany, Poland, Russia
5300 N
14 00E
Pukapuka Atoll
012N
6 39E
Sapporo [US Consulate General]','e5f6e2cae1108c3660f64e8c225d45591ac8dee649e21035fc22d4a0bf298c53','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

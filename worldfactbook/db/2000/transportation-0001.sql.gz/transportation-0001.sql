SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28d7e0dd0d2fe4430d7f8ff70e235ca6d40f06942afd0b3ca4d63f89f755b4b7',2000,'EH','Western Sahara','transportation',15,'Railways
totai
broad gauge
duai gauge
narrow gauge
standard gauge
Highways
total
paved
unpaved
Waterways
Pipelines
xxviii
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports - with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports - with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 91 4 m
Heliports
Transportation ■ note','2dc22171d088fdb1c6ed0e3d18b8e27a3852fc953a4de546c3a76af54aac840f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22038966d1d80c82ac3250ea8250536acd3730beef5fc8396ac312f809c955fa',2000,'AD','Andorra','transportation',24,'Railways: 0 km
Highways:
total: 350 km
paved; 150 km
unpaved: 200 km
Ports and harbors: Aunu''u (new construction),
Auasi, Faleosao, Ofu, Pago Pago, Ta''u
Merchant marine: none (1999 est.)
Airports: 4 (1999 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:t
under 914 m:t (1999 est.)
Airports - with unpaved runways:
total: 2
under 914 m; 2 (1999 est.)
Railways: 0 km
Highways;
total: 269 km
paved: 198 km
unpaved: 71 km (1 994 est.)
Ports and harbors: none
Airports: none
I Military
Military - note: defense is the responsibility of
France and Spain
r t r a n s n a t i 0 n a j Issues
Disputes ■ international: none
Background: Civil war has been the norm in Angola
since independence from Portugal in 1975. A 1994
peace accord between the government and the
National Union for the Total Independence of Angola
(UNITA) provided for the integration of former UNITA
insurgents into the government and armed forces. A
national unity government was installed in April of
1997, but serious fighting resumed in late 1998,
rendering hundreds of thousands of people homeless.
Up to 1 .5 million lives may have been lost in fighting
over the past quarter century.
f Q e 0 g r a p h y
Location: Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Democratic
Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1 ,246,700 sq km
land: 1 ,246,700 sq km
wafer; 0 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo
2,51 1 km (of which 220 km is the boundary of
discontiguous Cabinda Province), Republic of the
Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime ciaims:
exclusive economic zone: 200 nm
territorial sea: 12 m
Ciimate: semiarid in south and along coast to
Luanda; north has cool, dry season (May to October)
and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast
interior plateau
Elevation extremes:
/owesfpo/r)f.''Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Naturai resources: petroleum, diamonds, iron ore,
phosphates, copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes
periodic flooding on the plateau
Environment - current issues: overuse of pastures
and subsequent soil erosion attributable to population
pressures; desertification; deforestation of tropical
rain forest, in response to both international demand
for tropical timber and to domestic use as fuel,
resulting in loss of biodiversity; soil erosion
contributing to water pollution and siltation of rivers
and dams; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Desertification, Law of the Sea
signed, but not ratified: Climate Change
Geography - note: Cabinda is separated from rest
of country by the Democratic Republic of the Congo
Railways:
total: 2,952 km (inland, much of the track is unusable
because of land mines still in place from the civil war)
narrow gauge: 2,798 km 1.067-m gauge; 154 km
0.600-m gauge (1997)
Highways;
total: 76,626 km
paved; 19,156 km
unpaved: 57,470 km (1997 est.)
Waterways: 1 ,295 km navigable
Pipelines: crude oil 179 km
Ports and harbors: Ambriz, Cabinda, Lobito,
Luanda, Malongo, Namibe, Porto Amboim, Soyo
Merchant marine;
total: 9 ships (1 ,000 GRT or over) totaling 39,305
GRT/63,067 DWT
ships by type: cargo 8, petroleum tanker 1 (1 999 est.)
Airports: 249 (1999 est.)
Airports - with paved runways:
total: 32
over 3,047 m: A
2,438 to 3,047 m: 8
1, 524 to 2,437 m-A2
914 to 1,523 m: 7
under 914 m: 1 (1999 est.)
Airports - with unpaved runways:
total: 217
over 3,047 m: 2
2,438 to 3,047m: 5
1,524 to 2,437 m: 31
914 to 1,523 m: 98
under 914 m: 83 (1 999 est.)','fba6b8f1afc10aaf1ed17ea967784361688d00cd32b59991660461d510cf5294','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b226e6ca6183950612dfcaeb65db2ec4232da3d6d37c82280711885d731eb6f5',2000,'AI','Anguilla','transportation',35,'Railways: 0 km
Highways:
total: 279 km
paved: 253 km
unpaved: 26 km (1 998 est.)
Ports and harbors: Blowing Point, Road Bay
Merchant marine: none (1 999 est.)
Airports: 3 (1999 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m:t (1999 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (1999 est.)
I Military
Military - note: defense is the responsibility of
the UK','8e964d37f28c38cf87a338a5529e85310d73b5e053e887dc138009769dd43f4f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4c9d605d778c9a7165421b1abbf28735c68e3825ce9b0308f14a5665b9bd650',2000,'GP','Guadeloupe','transportation',41,'Railways:
total: Tl km
narrow gauge: 64 km 0.760-m gauge; 13 km 0.61 0-m
gauge (used almost exclusively for handling
sugarcane)
Highways:
total: 250 km (1996 est.)
paved: NA km
unpaved: NA km
Ports and harbors: Saint John''s
Merchant marine:
total: 607 ships (1 ,000 GRT or over) totaling
3,528,944 GRT/4,590,590 DWT
ships by type: bulk 17, cargo 385, chemical tanker 9,
combination bulk 2, container 149, liquified gas 3,
petroleum tanker 2, refrigerated cargo 12, roll-on/
roll-off 28 (1999 est.)
note: a flag of convenience registry: Germany owns
10 ships, Slovenia 2, and Cyprus 2 (1998 est.)
Airports: 3 (1999 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:t
under 914 m:‘{ (1999 est.)
Airports • with unpaved runways:
total: 1
under 914 01:1 (1999 est.)
i Military
Military branches: Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda Police
Force (includes Coast Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Transnationaf issues
Disputes - international: none
Illicit drugs: considered a minortransshipment point
for narcotics bound for the US and Europe; more
significant as a drug-money-laundering center
f Arctic Ocean','802aa481b5b27f196bc27ae12409e36e2b466b6595c3bbd222e4e110f5426e61','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39c7be8fc00aa806888e562c1b6ccc3ce76adbcb18d1cad26c9d6a522f462113',2000,'AQ','Antarctica','transportation',48,'Ports and harbors: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
28
Atlantic Ocean (continued)
Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint Petersburg (Russia),
Stockholm (Sweden)
Transportation - note; Kiel Canal and Saint
Lawrence Seaway are two Important waterways
I transnational Issues
Disputes - international; some maritime disputes
(see littoral states)','d76dad5a780ab3396ceeb3f0f8b82c811fbfeee67bc1228f941399c2dd81b2e2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50c46c3e12402643e3693c41dbde16e819b3eb26ac5518ea971b79fdf7c59567',2000,'AU','Australia','transportation',49,'Indian Ocean
Lord Howe islartd and
Macquarie island not shown.
Tasmania
I n t r 0 due t i o n
Background; Australia became a commonwealth of
the British Empire in 1 901 . It was able to take
advantage of its natural resources to rapidly develop
its agricultural and manufacturing industries and to
make a major contribution to the British effort in World
Wars I and II. Long-term concerns include pollution,
particularly depletion of the ozone layer, and
management and conservation of coastal areas,
especially the Great Barrier Reef. A referendum to
change Australia''s status, from a commonwealth
headed by the British monarch to an independent
republic, was defeated in 1999.
f GeogrsTphy
Location; Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates; 27 00 S, 133 00 E
Map references; Oceania
Area:
total: 7,686,850 sq km
/and; 7,61 7,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area - comparative; slightly smaller than the US
Land boundaries: 0 km
Coastline; 25,760 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: t2 nm
Climate; generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile plain
in southeast
Elevation extremes;
lowest point: Lake Eyre -15 m
highest point: Mount Kosciuszko 2,229 m
Natural resources; bauxite, coal, iron ore, copper,
tin, silver, uranium, nickel, tungsten, mineral sands,
lead, zinc, diamonds, natural gas, petroleum
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 54%
forests and woodland: 1 9%
other: 2t% (1993 est.)
Irrigated land; 21,070 sq km (1993 est.)
Natural hazards: cyclones along the coast; severe
droughts
Environment - current issues; soil erosion from
overgrazing, industrial development, urbanization,
and poor farming practices; soil salinity rising due to
the use of poor quality water; desertification; clearing
for agricultural purposes threatens the natural habitat
of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral
reef in the world, is threatened by increased shipping
and its popularity as a tourist site; limited natural fresh
water resources
Environment - international agreements;
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Desertification
Geography • note: world''s smallest continent but
sixth-largest country; population concentrated along
the eastern and southeastern coasts; regular, tropical,
invigorating, sea breeze known as "the Doctor" occurs
along the west coast in the summer
I: ^
fa- . ~
Population; 19,169,083 (July 2000 est.)
Age structure:
0-14 years: 21 % (male 2,052,095; female 1 ,954,543)
15-64 years: 67% (male 6,458,083; female
6,322,475)
65 years and over: 12% (male 1 ,040,950; female
1,340,937) (2000 est.)
Population growth rate: 1.02% (2000 est.)
Birth rate: 13.08 births/1 ,000 population (2000 est.)
Death rate: 7.12 deaths/1 ,000 population
(2000 est.)
Net migration rate; 4.26 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate; 5.04 deaths/1,000 live births
(2000 est.)
29
Australia (continued)
Life expectancy at birth:
total population: 79.75 years
male: 76.9 years
female: 82.74 years (2000 est.)
Totai fertility rate: 1 .79 children born/woman
(2000 est.)
Nationality:
noun: Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Anglican 26.1%, Roman Catholic 26%,
other Christian 24.3%, non-Christian 11%
Languages: English, native languages
Literacy:
definition: age 15 and over can read and write
total population: 1 00%
male: 100%
female: 100% (1980 est.)
Railways:
total: 3,380 km
standard gauge: 150 km 1.435-m gauge (connects
Cerrejon coal mines to maritime port at Bahia de
Portete)
narrow gauge: 3,230 km 0.91 4-m gauge (1,830 km in
use) (1995)
Highways;
fofa/: 115,564 km
paved; 13,868 km
unpaved: 101,696 km (1997 est.)
Waterways: 18,140 km, navigable by river boats
(April 1996)
Pipelines: crude oil 3,585 km; petroleum products
1 ,350 km; natural gas 830 km; natural gas liquids 1 25
km
Ports and harbors: Bahia de Portete, Barranquilla,
Buenaventura, Cartagena, Leticia, Puerto Bolivar,
San Andres, Santa Marta, Tumaco, Turbo
Merchant marine;
total 1 3 ships (1 ,000 GRT or over) totaling 51 ,343
GRT/67,168 DWT
ships by type: bulk 4, cargo 5, container 1 ,
multi-functional large load carrier 1 , petroleum tanker
2(1999 est.)
Airports: 1,101 (1999 est.)
Airports - with paved runways:
total 90
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 37
914 to 1,523 m: 35
under 914 m: 7 (1999 est.)
Airports - with unpaved runways;
total 1,011
2,438 to 3,047 m:1
1,524 to 2,437 m: 62
914 to 1,523 m: 330
under 914 m: 618(1 999 est.)
Railways:
total: 34 km
standard gauge: 34 km 1 .435-m gauge (all electrified)
(1996 est.)
Highways;
total: 1 ,831 km
paved: 1 ,831 km
unpaved; 0 km (1997)
Ports and harbors: Hong Kong
Merchant marine:
total: 271 ships (1 ,000 GRT or over) totaling
7,942,646 GRT/13,101 ,275 DWT
ships by type: barge carrier 1 , bulk 1 57, cargo 28,
chemical tanker 5, combination bulk 2, container 53,
liquified gas 5, multi-functional large load carrier 2,
petroleum tanker 14, short-sea passenger 1, vehicle
carrier 3 (1999 est.)
note: a flag of convenience registry; includes ships
from 13 countries among which are UK 16, South
Africa 3, China 9, Japan 6, Bermuda 2, Germany 3,
Canada 2, Cyprus 1 , Belgium 1 , and Norway 1
(1998 est.)
Airports: 3 (1999 est.)
Airports - with paved runways;
total: 3
over 3,047 m: 2
1,524 to 2,437 m:1 (1999 est.)
Heliports: 2 (1999 est.)
I Military
Military branches: Hong Kong garrison of China''s
People''s Liberation Army (PLA) including elements of
the PLA Ground Forces, PLA Navy, and PLA Air
Force; these forces are under the direct leadership of
the Central Military Commission in Beijing and under
administrative control of the adjacent Guangzhou
Military Region
Military manpower - military age: 18 years of age
Military manpower - availability;
males age 15-49:2,012,203 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,51 6,533 (2000 est.)
Military manpower - reaching military age
annually:
males: 46,485 (2000 est.)
223
Hong Kong (continued)
Military expenditures - dollar figure: $NA; note -
separate budget for Hong Kong not established by
Geographic coordinates: 0 48 N, 176 38 W
Map references: Oceania
Area:
total: 1 .6 sq km
land: 1 ,6 sq km
water: 0 sq km
Area - comparative: about three times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 6.4 km
Maritime claims:
exclusive economic zone: 200 nm
femtor/a/ sea; 1 2 nm
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low-lying, nearly level, sandy, coral island
surrounded by a narrow fringing reef; depressed
central area
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: unnamed location 3 m
Natural resources: guano (deposits worked until
late 1800s)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 5%
other: 95%
Irrigated land; 0 sq km (1998)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Geography - note: almost totally covered with
grasses, prostrate vines, and low-growing shrubs;
small area of trees in the center; primarily a nesting,
roosting, and foraging habitat for seabirds, shorebirds,
and marine wildlife
I People
Population; uninhabited
note; American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the war; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; visited annually by US Fish and Wildlife
Service (July 2000 est.)
f Government
Country name:
conventional long form: none
conventional short form: Howland Island
Data code; HQ
Dependency status: unincorporated territory of the
US; administered from Washington, DC, by the Fish
and Wildlife Service of the US Department of the
Interior as part of the National Wildlife Refuge system
Flag description; the flag of the US is used
I Economy
Economy ■ overview: no economic activity
I Transportation
Ports and harbors: none; offshore anchorage only;
note - there is one boat landing area along the middle
of the west coast
Airports: airstrip constructed in 1937 for scheduled
refueling stop on the round-the-world flight of Amelia
EARHART and Fred NOONAN - they left Lae, New
Guinea, for Howland Island, but were never seen
again; the airstrip is no longer serviceable
Transportation - note: Earhart Light is a day
beacon near the middle of the west coast that was
partially destroyed during World War II, but has since
been rebuilt; named in memory of famed aviatrix
Amelia EARHART
f Military
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
f transnational issues
Disputes - international; none
224
I Introduction
Background; Hungary was part of the polyglot
Austro-Hungarian Empire, which collapsed in Worid
War i. it fell under communist rule following World War
II. A revolt in 1 956 and an announced withdrawal from
the Warsaw Pact was met with massive military
intervention by Moscow. In the more open
GORBACHEV years, Hungary led the movement to
dissolve the Warsaw Pact and steadily shifted toward
multiparty democracy and a market-oriented
economy. Following the collapse of the USSR in 1 991 ,
Hungary developed close political and economic ties
to Western Europe. It joined NATO in 1 999 and is a
frontrunner in a future expansion of the EU.
I ^
Location; Central Europe, northwest of Romania
Geographic coordinates; 47 00 N, 20 00 E
Map references; Europe
Area;
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area - comparative; slightly smaller than Indiana
Land boundaries;
total: 2,009 km
trorder countries: Austria 366 km, Croatia 329 km,
Romania 443 km, Serbia and Montenegro 151 km (all
with Serbia), Slovakia 515 km, Slovenia 102 km,
Ukraine 103 km
Coastline; 0 km (landlocked)
Maritime claims; none (landlocked)
Climate; temperate; cold, cloudy, humid winters;
warm summers
Terrain; mostly flat to rolling plains; hills and low
mountains on the Slovakian border
Elevation extremes;
lowest point: Jlsza River 78 m
highest point: Kekes 1,014 m
Natural resources; bauxite, coal, natural gas, fertile
soils, arable land
Land use;
arable land:
permanent crops: 3.6%
permanent pastures: 12.4%
forests and woodland: 19%
other: 14% (1999)
Irrigated land; 2,060 sq km (1993 est.)
Environment ■ current issues; the approximation
of Hungary''s standards in waste management, energy
efficiency, and air, soil, and water pollution with
environmental requirements for EU accession will
require large investments
Environment - international agreements;
party to: Mr Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94,
Antarctic-Environmental Protocol, Law of the Sea
Geography - note; landlocked; strategic location
astride main land routes between Western Europe
and Balkan Peninsula as well as between Ukraine and
Mediterranean basin
Population; 1 0,1 38,844 (July 2000 est.)
Age structure;
0-14 years: 1 7% (male 878,661 ; female 834,607)
15-64 years: 68% (male 3,407,368; female
3,535,818)
65 years and over: 15% (male 548,672; female
933,718) (2000 est.)
Population growth rate; -0.33% (2000 est.)
Birth rate; 9.26 births/1,000 population (2000 est.)
Death rate; 13.34 deaths/1,000 population
(2000 est.)
Net migration rate; 0.73 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female (2000 est.)
Infant mortality rate; 9.1 5 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 71 .37 years
male: 67 years
female: 76.05 years (2000 est.)
Total fertility rate; 1 .25 children born/woman
(2000 est.)
Nationality;
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups; Hungarian 89.9%, Roma 4%,
German 2.6%, Serb 2%, Slovak 0.8%, Romanian
0.7%
Religions; Roman Catholic 67.5%, Calvinist 20%,
Lutheran 5%, atheist and other 7.5%
Languages; Hungarian 98.2%, other 1 .8%
Literacy;
definition: age 15 and over can read and write
total population: 99%
male: 99%
fema/e; 98% (1980 est.)
I””''"’”''" ^G (TyTrirm FfTt "
Country name;
conventional long form: Republic of Hungary
conventional short form: Hungary
local long form: Magyar Koztarsasag
local short form: Magyarorszag
Data code; HU
Government type; parliamentary democracy
Capital; Budapest
Administrative divisions; 19 counties (megyek,
singular - megye), 20 urban counties* (singular -
megyei varos), and 1 capital city** (fovaros);
Bacs-Kiskun, Baranya, Bekes, Bekescsaba*,
Borsod-Abauj-Zemplen, Budapest**, Csongrad,
Debrecen*, Dunaujvaros*, Eger*, Fejer, Gyor*,
Gyor-Moson-Sopron, Hajdu-Bihar, Heves,
Hodmezovasarhely*, Jasz-Nagykun-Szolnok,
Kaposvar*, Kecskemet*, Komarom-Esztergom,
Miskolc*, Nagykanizsa*, Nograd, Nyiregyhaza*,
Pecs*, Pest, Somogy, Sopron*,
Szabolcs-Szatmar-Bereg, Szeged*, Szekesfehervar*,
Szolnok*, Szombathely*, Tatabanya*, Tolna, Vas,
Veszprem, Veszprem*, Zala, Zalaegerszeg*
Independence; 1001 (unification by King Stephen I)
National holiday; Saint Stephen''s Day, 20 August
(commemorates the coronation of King Stephen I in
1000 AD)
Constitution; 18 August 1949, effective 20 August
1 949, revised 1 9 April 1 972; 1 8 October 1 989 revision
ensured legal rights for individuals and constitutional
checks on the authority of the prime minister and also
established the principle of parliamentary oversight;
1997 amendment streamlined the judicial system
225
Hungary (continued)
Legal system: rule of law based on Western model
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Arpad GONCZ (since 3
August 1 990; previously interim president since 2 May
1990)
head of government: Prime Minister Viktor ORBAN
(since6 July 1998)
cabinet: Council of Ministers elected by the National
Assembly on the recommendation of the president
elections: president elected by the National Assembly
for a five-year term; election last held 19 June 1995
(next to be held before August 2000); prime minister
elected by the National Assembly on the
recommendation of the president
election results: Arpad GONCZ reelected president; a
total of 335 votes were cast by the National Assembly,
Arpad GONCZ received 259; Viktor ORBAN elected
prime minister; percent of legislative vote - NA
Legislative branch: unicameral National Assembly
or Orszaggyules (386 seats; members are elected by
popular vote under a system of proportional and direct
representation to serve four-year terms)
elections: last held on 1 0 and 24 May 1 998 (next to be
held May/June 2002)
election results: percent of vote by party (5% or more
of the vote required for parliamentary representation
in the first round) - MSZP 32.0%, FIDESZ 28.2%,
FKGP 13.8%, SZDSZ 7.9%, MIEP 5.5%, MMP 4.1%,
MDF 2.8%, KDNP 2.3%, MDNP 1 .5%; seats by party -
MSZP 134, FIDESZ 148, FKGP 48, SZDSZ 24, MDF
17, MIEP 14, independent 1; note - the MDF won 17
single-member district seats; seating as of 1 999 by
party - MSZP 135, FIDESZ 146, FKGP 48, SZDSZ 24,
MDF 17, MIEP 12, independents 3, and 1 empty seat
to be filled in a byelection
Judicial branch: Constitutional Court, judges are
elected by the National Assembly for nine-year terms
Political parties and leaders: Alliance of Free
Democrats or SZDSZ [Balint MAGYAR, chairman);
Christian Democratic People''s Party or KDNP [Gyorgy
GICZY, president]; Hungarian Civic Party or FIDESZ
[Laszio KOVER, chairman]; Hungarian Democratic
Forum or MDF [Ibolya DAVID, chairman]; Hungarian
Democratic People''s Party or MDNP [Erzsebet
PUSZTAI, chairman]; Hungarian Justice and Life
Party or MIEP [Istvan CSURKA, chairman];
Hungarian Socialist Party or MSZP [Laszio KOVACS,
chairman]; Hungarian Workers'' Party or MMP [Gyula
THURMER, chairman]; Independent Smallholders or
FKGP [Jozsef TORGYAN, president]
International organization participation: ABEDA,
Australia Group, BIS, CCC, CE, CEI, CERN, EAPC,
EBRD, ECE, EU (applicant), FAO, G- 9, IAEA, IBRD,
ICAO, ICFTU, ICRM, IDA, lEA, IFC, IFRCS, ILO, IMF,
IMO, Inmarsat, Intelsat, Interpol, IOC, lOM, ISO, ITU,
NAM (guest), NATO, NEA, NSG, OAS (observer),
OECD, OPCW, OSCE, PCA, PFP, UN, UNCTAD,
UNESCO, UNFICYP, UNHCR, UNIDO, UNIKOM,
UNMIBH, UNMIK, UNOMIG, UNU, UPU, WEU
(associate), WFTU, WHO, WlPO, WMO, WToO,
WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Geza JESZENSZKY
chancery: 3910 Shoemaker Street NW, Washington,
DC 20008
telephone: [1] (202) 362-6730
FAX: [1] (202) 966-8135
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US:
chief of mission: Ambassador Peter F. TUFO
embassy: y. 1054 SzabadsagTer 12, Budapest
mailing address: pouch: American Embassy
Budapest, Department of State, Washington, DC
20521-5270
telephone: [36] (1) 475-4400, 475-4703 (after hours)
FAX; [36] (1)475-4764
Flag description: three equal horizontal bands of
red (top), white, and green
Railways:
total: 7, me km
broad gauge: 36 km 1.524-m gauge
226
Hungary (continued)
standard gauge: 7,394 km 1 .435-m gauge (2,270 km
electrified; 1 ,236 km double track)
narrow gauge: 176 km 0.760-m gauge (1998)
note: Hungary and Austria jointly manage the
cross-border standard-gauge railway between Gyor,
Sopron, Ebenfurt (Gysev railroad) a distance of about
101 km in Hungary and 65 km in Austria
Highways;
fofa/; 188,203 km
paved: 81 ,680 km (including 438 km of expressways)
unpaved: 106,523 km (1998 est.)
Waterways: 1 ,373 km permanently navigable (1 997)
Pipelines: crude oil 1,204 km; natural gas 4,387 km
(1991)
Ports and harbors: Budapest, Dunaujvaros
Merchant marine;
fofa/; 2 ships (1,000 GRT or over) totaling 12,949
GRT/14,550 DWT
ships by type: cargo 2 (1 999 est.)
Airports: 43 (1999 est.)
Airports - with paved runways:
total: 1 6
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m-A (1999 est.)
Airports • with unpaved runways;
total: 27
2,438 to 3,047 m: 8
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 7 (1 999 est.)
Heliports; 5 (1999 est.)
I Military
Military branches: Ground Forces, Air Force,
Border Guard
Military manpower - military age; 18 years of age
Military manpower - availability:
males age 15-49:2,588,865 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,062,565 (2000 est.)
Military manpower - reaching military age
annually;
males: 67,160 (2000 est.)
Military expenditures - dollar figure: $732.2
million (FY99)
Military expenditures - percent of GDP: 1 .4%
(FY99)
f Transnational Issues
Disputes - international: ongoing Gabcikovo Dam
dispute with Slovakia
Illicit drugs: major transshipment point for
Southwest Asian heroin and cannabis and transit
point for South American cocaine destined for
Western Europe; limited producer of precursor
chemicals, particularly for amphetamines and
methamphetamines
Railways: 0 km
Highways:
total: 80 km
paved: 53 km
unpaved: 27 km
Ports and harbors: none; loading jetties at Kingston
and Cascade
Merchant marine: none (1999 est.)
Airports: 1{1999est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m; 1 (1999 est.)','6a2c5d7b76b429ad65f5e8348358c3b35cb0e63ec95e53d9af37c67b6d6c9bcb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7411f761218821a4dfeeb1a81fa73744a8ec0486d2561657acc11f58f38cd246',2000,'BS','Bahamas','transportation',61,'Railways: 0 km
Highways:
total: 2,693 km
paved: 1 ,546 km
unpaved: 1 ,1 47 km (1 997 est.)
Ports and harbors: Freeport, Matthew Town,
Nassau
Merchant marine:
total: 1 ,075 ships (1 ,000 GRT or over) totaling
28,630,674 GRT/44,1 1 1 ,353 DWT
ships by type: bulk 201 , cargo 233, chemical tanker
41 , combination bulk 15, combination ore/oil 25,
container 59, liquified gas 35, livestock carrier 1 ,
passenger 68, passenger/cargo 1 , petroleum tanker
177, rail car carrier 1 , refrigerated cargo 129, roll-on/
roll-off 51 , short-sea passenger 1 2, specialized tanker
3, vehicle carrier 23 (1999 est.)
note: a flag of convenience registry; includes ships
from 49 countries among which are Norway 177,
Greece 1 41 , UK 1 1 3, US 61 , Denmark 39, Finland 27,
Japan 25, Sweden 24, France 22, and Italy 22
(1998 est.)
Airports: 62 (1999 est.)
Airports - with paved runways:
total: 33
over 3,047 m: 2
2,438 to 3,047 m: 2
1,824to2,437 m-A3
914 to 1,523 m: 12
under 914 m: 2 (IQQde^.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:1
914 to 1,523 m:7
under 914 m: 21 (1999 est.)
Heliports: 1 (1999est.)','1ce37a60a303538e96d1d9b9a7cdd3561061f3bf21b1abc0ac13e4d0e582fd2e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89060fc4947989bf000f815cb76964618d58426fefebdefa29647f61cf45f548',2000,'LC','Saint Lucia','transportation',71,'Ports and harbors: none; offshore anchorage oniy
M i i i t a r y
Military - note: defense is the responsibiiity of','797d6fa7c7f7262b8d9525992fdaf40c95724f4179a57c068aaddd66617f84b3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea022de5bbb9fcd89943a4b3932a74e9dfcd9102b908f9dc4f8f626e69a3f05',2000,'BY','Belarus','transportation',79,'Railways:
total: 3,437 km (2,446 km electrified; 2,563 km double
track)
standard gauge: 3,437 km 1 .435-m gauge (1998)
Highways:
total: 145,850 km
paved; 117,701 km (including 1,682 km of
expressways)
unpaved; 28, 149 km (1998)
Waterways: 2,043 km (1 ,528 km in regular
commercial use)
Pipelines: crude oil 161 km; petroleum products
1 ,167 km; natural gas 3,300 km
Ports and harbors: Antwerp (one of the world''s
busiest ports), Brugge, Gent, Hasselt, Liege, Mens,
Namur, Oostende, Zeebrugge
Merchant marine;
total: 22 ships (1 ,000 GRT or over) totaling 35,075
GRT/57,347 DWT
ships by type: cargo 7, chemical tanker 8, petroleum
tanker 7 (1999 est.)
Airports: 42 (1999 est.)
Airports - with paved runways;
total: 2A
over 3,047 m:0
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m; 6 (1999 est.)
Airports - with unpaved runways;
total: 18
914 to 1,523 m: 2
under 914 m: 18 {1099 est.)
Heliports: 1 (1999 est.)
Railways:
total: 1 ,021 km (electrified 795 km; operating as diesel
or steam until grids are repaired)
standard gauge: 1 ,021 km 1.435-m gauge (1995);
note - some segments still need repair and/or
reconstruction
Highways:
total: 21 ,846 km
paved: 1 1 ,425 km
unpaved: 10,421 km (1996 est.)
note: roads need maintenance and repair
Waterways: NA km; iarge sections of the Sava
biocked by downed bridges, siit, and debris
Pipeiines: crude oil 174 km; natural gas 90 km
(1992); note - pipelines now disrupted
Ports and harbors: Bosanska Gradiska, Bosanski
Brod, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava none of which are fully
operational), Orasje
Merchant marine: none (1999 est.)
Airports: 27 (1999 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: A
1,524 to 2,437 m: 2
under 914 m: 3 (1 999 est.)
Airports - with unpaved runways:
tofa/;18
1,524 to 2,437 m:1
914 to 1,523 m: 7
under 914 m: 10 (1999 est.)
Heliports: 4 (1999 est.)
Railways:
total: 971 km
narrow gauge: 971 km 1.067-m gauge (1995)
Highways:
total: 18,482 km
paved: 4,343 km
urrpaved; 14,139 km (1996 est.)
Ports and harbors; none
Airports: 92 (1999 est.)
Airports - with paved runways:
total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
total: 82
1,524 to 2,437 m: 4
914 to 1,523 m: 57
under 914 m: 21 (1999 est.)','f3f2a9d8c5c7a38ac87ee21c6f30bea3884929ba3c07845f0130c21ef2236dd7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2316b230d503f1f221a0d9fe41af40eaf5ef1d28c772dba1ae301925c568e790',2000,'IO','British Indian Ocean Territory','transportation',92,'Railways:
total: 13 km (private line)
narrow gauge: 13 km 0.61 0-m gauge
Highways:
total: 1,150 km
paved: 399 km
unpaved: 751 km (1996 est.)
Waterways: 209 km; navigable by craft drawing less
than 1 .2 m
Pipelines: crude oil 1 35 km; petroleum products 41 8
km; natural gas 920 km
Ports and harbors: Bandar Seri Begawan, Kuala
Belait, Muara, Seria, Tutong
Merchant marine:
total: 7 ships (1 ,000 GRT or over) totaling 348,476
GRT/340,635 DWT
ships by type: liquified gas 7 (1 999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1 999 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1999 est.)
Heliports: 3 (1999 est.)
Railways:
totai: 4,294 km
standard gauge: 4,049 km 1.435-m gauge (2,710 km
electrified; 917 km double track)
narrow gauge: 245 km 0.760-m gauge (1998)
Highways;
total: 36,759 km
paved; 33,81 8 km (including 319 km of expressways)
unpaved: 2,941 km (1998 est.)
Waterways: 470 km (1987)
76
Bulgaria (continued)
Pipelines; petroleum products 525 km; natural gas
1,500 km (1999)
Ports and harbors: Burgas, Lorn, Nesebur, Ruse,
Varna, Vidin
Merchant marine:
total: 85 ships (1 ,000 GRT or over) totaling 947,71 1
GRT/1 ,449,41 6 DWT
ships by type: bulk 43, cargo 18, chemical tanker 4,
container 2, passenger/cargo 1 , petroleum tanker 7,
rail car carrier 2, refrigerated cargo 1 , roll-on/roll-off 5,
short-sea passenger 1 , specialized tanker 1
(1999 est.)
Airports; 216 (1999 est.)
Airports - with paved runways;
fofa/;129
over 3,047 m: t
2,438 to 3,047 m: to
1,524 to 2,437 m:t 5
914 to 1,523 m:t
under 914 m: 93 (1 999 est.)
Airports ■ with unpaved runways:
total: 87
1,524 to 2,437 m: 2
914 to 1,523m: to
under 914 m: 75 (1 999 est.)
I . . MlTTtTr''y
Military branches: Army, Navy, Air and Air Defense
Forces, Border Troops, infernal Troops, Railway and
Construction Troops
Military manpower - military age: 19 years of age
Military manpower - availability;
males age 15-49; 1,913,857 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1,599,379 (2000 est.)
Military manpower - reaching military age
annually;
males: 57, 46t (2000 est.)
Military expenditures - dollar figure: $379 million
(FY99)
Military expenditures - percent of GDP: 2.7%
(FY99)
Military - note: the Bulgarian Ministry of Defense
has begun a new downsizing, modernization, and
reform program (PLAN 2004) that wili resuit in the
adoption of a smaller force structure of around 50,000
personnel, based upon a Rapid Reaction Force and
two additional corps headquarters, all with
subordinate brigades','0ad715817fab52762471994a4b7775285c986abf6459b79ee8410cecc3ed7c83','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2f6f9bcb4cf6ae056fa3a2d73fd8eec593e23f1e79a3061a2bbdd310aa9c7fc',2000,'ET','Ethiopia','transportation',96,'Railways:
total: 622 km (517 km from Ouagadougou to the Cote
d''Ivoire border and 105 km from Ouagadougou to
Kaya)
narrow gauge: 622 km 1 .000-m gauge (1 995 est.)
Highways:
total: 12,506 km
paved; 2,001 km
unpaved: 10,505 km (1996 est.)
Ports and harbors: none
Airports: 33 (1999 est.)
Airports - with paved runways:
total: 2
over 3,047 m:t
2,438 to 3,047 m:t (1999 est.)
Airports - with unpaved runways:
total: 31
2,438 to 3,047 m:t
1,524 to 2,437 m:t
914 to 1,523 m: 13
under 914 m: 16 (1999 est.)
I Military"
Military branches: Army, Air Force, National
Gendarmerie, Nationai Police, People''s Militia
Military manpower ■ availability:
males age 15-49: 2,500,962 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,282,483 (2000 est.)
Military expenditures - dollar figure: $66 million
(FY96)
Military expenditures - percent of GDP: 2%
(FY96)
I t r a n s n a t i 0 rTa f I s s u e s
Disputes - international: none
|Burma
I n t r 0 d u c t i on
Background: Despite multiparty elections in 1990
that resulted in the main opposition party winning a
decisive victory, the military junta ruling the country
refused to hand over power. Key opposition leader
and Nobel Peace Prize recipient AUNG San Suu Kyi,
under house arrest from 1989 to 1995, continues to
have her activities restricted; her supporters are
routinely harassed or jailed.
I - ^ g V a p h y "
Location: Southeastern Asia, bordering the
Andaman Sea and the Bay of Bengal, between
Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,876 km
79
Burma (continued)
border countries: Bangladesh 193 km, China 2,185
km, India 1 ,463 km, Laos 235 km, Thailand 1 ,800 km
Coastline; 1,930 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
ferr/tor/a/ sea; 12 nm
Climate: tropical monsoon; cloudy, rainy, hot, humid
summers (southwest monsoon, June to September);
less cloudy, scant rainfall, mild temperatures, lower
humidity during winter (northeast monsoon,
December to April)
Terrain; central lowlands ringed by steep, rugged
highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, antimony,
zinc, copper, tungsten, lead, coal, some marble,
limestone, precious stones, natural gas, hydropower
Land use;
arable land: t5%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 49%
other 34% (1993 est.)
Irrigated land; 10,680 sq km (1 993 est.)
Natural hazards: destructive earthquakes and
cyclones; flooding and landslides common during
rainy season (June to September); periodic droughts
Environment - current issues; deforestation;
industrial pollution of air, soil, and water; inadequate
sanitation and water treatment contribute to disease
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near major
Indian Ocean shipping lanes
i; People
Population: 41,734,853
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 30% (male 6,341 ,546; female 6,086,650)
15-64 years: 65% (male 13,565,379; female
13,764,242)
65 years and over: 5% (male 885,583; female
1,091 ,453) (2000 est.)
Population growth rate: 0.64% (2000 est.)
Birth rate: 20.61 births/1 ,000 population (2000 est.)
Death rate: 1 2.35 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1 .85 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 maie(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.9d male(s)/female (2000 est.)
Infant mortality rate; 75.3 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 54.91 years
male: 53.6 years
female: 56.29 years (2000 est.)
Totai fertiiity rate: 2.37 children born/woman
(2000 est.)
Nationality:
noun: Burmese (singuiar and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Mon 2%, Indian 2%, other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%, animist 1%, other
2%
Languages; Burmese, minority ethnic groups have
their own languages
Literacy:
definition: age 15 and over can read and write
total population: 83. 1 %
male: 88.7%
ferrra/e; 77.7% (1995 est.)
note: these are official statistics; estimates of
functional literacy are likely closer to 30% (1 999 est.)
G 0 V e r n m e n t
Country name:
conventional long form: Union of Burma
conventional short form: Burma
local long form: Pyidaungzu Myanma Naingngandaw
(translated by the US Government as Union of
Myanma and by the Burmese as Union of Myanmar)
local short form: Myanma Naingngandaw
former: Socialist Republic of the Union of Burma
Data code: BM
Government type: military regime
Capital: Rangoon (regime refers to the capital as
Yangon)
Administrative divisions; 7 divisions* (yin-mya,
singular - yin) and 7 states (pyine-mya, singular -
pyine); Chin State, Ayeyarwady*, Bago*, Kachin
State, Kayin State, Kayah State, Magway*,
Mandalay*, Mon State, Rakhine State, Sagaing*,
Shan State, Tanintharyi*, Yangon*
Independence: 4 January 1948 (from UK)
National holiday: Independence Day, 4 January
(1948)
Constitution: 3 January 1974 (suspended since 18
September 1988); national convention started on 9
January 1993 to draft a new constitution; chapter
headings and three of 15 sections have been
approved
Legal system: does not accept compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch;
chief of state: Prime Minister and Chairman of the
State Peace and Development Council Gen. THAN
SHWE (since 23 April 1 992); note - the prime minister
is both the chief of state and head of government
head of government: Prime Minister and Chairman of
the State Peace and Development Council Gen.
THAN SHWE (since 23 April 1992); note - the prime
minister is both the chief of state and head of
Raiiways: 0 km
Highways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1996 est.)
Waterways: several rivers are accessible to coastal
shipping
Ports and harbors: Bissau, Buba, Cacheu, Farim
Merchant marine: none (1999 est.)
Airports: 30 (1999 est.)
Airports ■ with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m:1
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
total: 27
1,524 to 2,437 m:1
914 to 1,523 m: 4
under 914 m: 22 (1 999 est.)
Railways: 0 km
Highways:
total: 320 km
paved; 21 8 km
unpaved: 102 km (1996 est.)
Ports and harbors: Santo Antonio, Sao Tome
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 43,587
GRT/34,802 DWT
432
Sao Tome and Principe (continued)
ships by type: cargo 4, container 1 , refrigerated cargo
1 , roii-on/roil-off 3 (1 999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:-\\
914 to 1,523 m:1 (1999 est.)
I Military
Miiitary branches: Army, Navy, Security Poiice
Miiitary manpower - avaiiabiiity:
males age 15-49: 32,933 (2000 est.)
Military manpower ■ fit for military service:
males age 15-49: 17,391 (2000 est.)
Military expenditures ■ dollar figure: $1 miiiion
(FY94)
Military expenditures - percent of GDP: 1 .5%
(FY94)
I T r a n Tn a t i 0 n a i i s s u e s
Disputes - international: none
Background: In 1902 Abdul al-Aziz Ibn SAUD
captured Riyadh and set out on a 30-year campaign to
unify the Arabian peninsula. In the 1930s, the
discovery of oil transformed the country. Following
Iraq''s invasion of Kuwait in 1990, Saudi Arabia
accepted the Kuwaiti royal family and 400,000
refugees while allowing Western and Arab troops to
deploy on its soil for the liberation of Kuwait the
following year. A burgeoning population, aquifer
depletion, and an economy largely dependent on
petroleum output and prices are all major
governmental concerns.
I GTo''giTarp hy
Location: Middle East, bordering the Persian Gulf
and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total: 1 ,960,582 sq km
land: 1 ,960,582 sq km
water: 0 sq km
Area - comparative: slightly more than one-fifth the
size of the US
Land boundaries:
fofa/;4,415 km
border countries: Iraq 814 km, Jordan 728 km, Kuwait
222 km, Oman 676 km, Qatar 60 km, UAE 457 km,
Yemen 1 ,458 km
Coastline: 2,640 km
Maritime claims:
contiguous zone: 1 8 nm
continental shelf: not specified
fem''for/a/sea;12nm
Climate: harsh, dry desert with great extremes of
temperature
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,133 m
Natural resources: petroleum, natural gas, iron ore,
gold, copper
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1%
of/)er;41%(1993est.)
Irrigated land: 4,350 sq km (1993 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: desertification;
depletion of underground water resources; the lack of
perennial rivers or permanent water bodies has
prompted the development of extensive seawater
desalination facilities; coastal pollution from oil spills
Environment - international agreements:
party to: Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: extensive coastlines on Persian
Gulf and Red Sea provide great leverage on shipping
(especially crude oil) through Persian Gulf and Suez
Canal
Population: 22,023,506
note: includes 5,360,526 non-nationals (July
2000 est.)
Age structure:
0-14 years: 43% (male 4,781 ,695; female 4,607,038)
15-64 years: 55% (male 7,093,567; female
4,969,848)
65 years and over: 2% (male 309,638; female
261 ,720) (2000 est.)
Population growth rate: 3.28% (2000 est.)
Birth rate: 37.47 births/1,000 population (2000 est.)
Death rate: 6.02 deaths/1,000 population
(2000 est.)
Net migration rate: 1 .36 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .43 male(s)/female
65 years and over: 1.18 male(s)/female
total population: 1 .24 male(s)/female (2000 est.)
Infant mortality rate: 52.9 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 67.77 years
ma/e; 66.11 years
female: 69.51 years (2000 est.)
Total fertility rate: 6.3 children born/woman
(2000 est.)
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
433
Saudi Arabia (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 62.8%
male: 71 .5%
female: 50.2% (1995 est.)','060d723560b31afed3e2a3f00ea209f1bad031803f8df13766e3085df8c0f074','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ed500d0fc208dc007bc6d1446d6e3c4873e0a0a91ab0098effd3d959f48542e',2000,'HN','Honduras','transportation',119,'Railways:
total: 65,650 km (including 5,400 km of provincial
"local" rails)
standard gauge: 62,050 km 1.435-m gauge (12,150
km electrified; 20,250 km double track)
narrow gauge: 3,600 km 0.750-m gauge local
industrial lines (1998 est.)
note: a new total of 68,000 km has been estimated for
early 1999
Highways:
total: 1 .21 million km
paved: 271 ,300 km (with at least 24,474 km of
expressways)
unpaved: 938,700 km (1998 est.)
Waterways: 1 1 0,000 km navigable (1 999)
Pipelines: crude oil 9,070 km; petroleum products
560 km; natural gas 9,383 km (1998)
Ports and harbors: Dalian, Fuzhou, Guangzhou,
Haikou, Huangpu, Lianyungang, Nanjing, Nantong,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shantou,
Tianjin, Xiamen, Xingang, Yantai, Zhanjiang
Merchant marine:
total: 1 ,746 ships (1 ,000 GRT or over) totaling
16,637,023 GRT/24,552,567 DWT
ships by type: barge carrier 2, bulk 325, cargo 840,
chemical tanker 21 , combination bulk 1 1 , combination
ore/oil 1, container 125, liquified gas 20,
multi-functional large load carrier 5, passenger 8,
passenger/cargo 46, petroleum tanker 251 ,
refrigerated cargo 24, roll-on/roll-off 21 , short-sea
passenger 43, specialized tanker 2, vehicle carrier 1
(1999 est.)
Airports: 206 (1996 est.)
Airports - with paved runways:
total: 192
over 3,047 m: 16
2,438 to 3,047 m: 65
1,524 to 2,437 m: 90
914 to 1,523 m: 13
under 914 m; 6 (1996 est.)
Airports - with unpaved runways:
fofa/;14
1,524 to 2, 437 m: 8
914 to 1,523 m: 5
under 914 m:1 (1996 est.)
Railways: 24 km to serve phosphate mines
Highways;
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Flying Fish Cove
Merchant marine: none (1 999 est.)
Airports: 1 (1999est.)
Airports ■ with paved runways:
total: 1
1,524 to 2,437 m:1 (1999 est.)','b97cf20fcca8a4fcb2da8b94c0d09684c7ecb8152f46ecf918acc2b60c1bfc94','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab684505ed79ef81593f48bf99fe451d369caf9ee3fb92e4537ac38809b2946e',2000,'CK','Cook Islands','transportation',157,'Railways:
total: 950 km
narrow gauge: 950 km 1.067-m gauge (260 km
electrified)
Highways:
total: 37,273 km
paved: 7,827 km
unpaved: 29,446 km (1998 est.)
Waterways; about 730 km, seasonally navigable
Pipelines: petroleum products 176 km
Ports and harbors: Caldera, Golfito, Moin, Puerto
Limon, Puerto Quepos, Puntarenas
Merchant marine: none (1999 est.)
Airports: 155 (1999 est.)
Airports • with paved runways;
total: 28
2,438 to 3,047 m: 2
1,524 to 2,437 m:1
914 to 1,523 m: 18
under 914 m: 7 (1 999 est.)
Airports - with unpaved runways;
tofa/.-127
914 to 1,523 m: 29
under 914 m: 98 (1999 est.)
Ports and harbors: none; offshore anchorage only;
note - there is one boat landing area in the middle of
the west coast and another near the southwest corner
of the island
Transportation - note: there is a day beacon near
the middle of the west coast
Mil it a r y
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Ports and harbors: Johnston Island
Airports: 1 (1 999 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (1999 est.)','7d676b4e6f1f4d5029654f4cfcaf9af8916aa196cc9f1fb24a7390c51b180f39','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17ac7c04886df94f79c30cf03626664839fcde0fdcb66ac47d3f35bd08872f0e',2000,'FR','France','transportation',158,'Raiiways:
total: 660 km
narrow gauge: 660 km 1 .000-meter gauge; 25 km
double track (1995 est.)
Highways:
total: 50,400 km
paved: 4,889 km
unpaved: 45, 5M km (1996 est.)
124
Cote d''Ivoire (continued)
Waterways: 980 km navigable rivers, canals, and
numerous coastal lagoons
Ports and harbors: Abidjan, Aboisso, Dabou,
San-Pedro
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,200 GRT/
1,500 DWT
ships by type: petroleum tanker 1 (1 999 est.)
Airports: 36 (1999 est.)
Airports - with paved runways:
total: 7
over 3,047 m: t
2,438 to 3,047 m: 2
1,524 to 2,437m: 4 {tm est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m: 8
914 to 1,523 m: 12
under 914 m: 9 (1999 est.)
I" Military
Military branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Republican Guard
(includes Presidential Guard), Sapeur-Pompier
(Military Fire Group)
Military manpower ■ military age: 1 8 years of age
Military manpower ■ availability:
males age 15-49: 3,743,353 (2000 est.)
Military manpower ■ fit for military service:
males age 15-49: 1 ,952,882 (2000 est.)
Military manpower - reaching military age
annually:
males: 182,936 (2000 est.)
Military expenditures - dollar figure: $94 million
(FY96)
Military expenditures - percent of GDP: 1 %
(FY96)
I t r a n s n a t i 0 n a I Issues
Disputes - international: none
Illicit drugs: illicit producer of cannabis, mostly for
local consumption; minor transshipment point for
Southwest and Southeast Asian heroin to Europe and
occasionally to the US, and for Latin American
cocaine destined for Europe
Background: In 1918, the Croats, Serbs, and
Slovenes formed a kingdom known after 1929 as
Yugoslavia. Following World War II, Yugoslavia
became an independent communist state under the
strong hand of Marshal TITO. Although Croatia
declared its independence from Yugoslavia in 1 991 , it
took four years of sporadic, but often bitter, fighting
before occupying Serb armies were mostly cleared
from Croatian lands. Under UN supervision the last
Serb-held enclave in eastern Slavonia was returned to
Croatia in 1998.
r . . . . . e o''g'''''' a’ TlT y
Location: Southeastern Europe, bordering the
Adriatic Sea, between Bosnia and Herzegovina and
Railways: 0 km (1995)
Highways:
fofa/; 1,817 km
paved: 727 km
unpaved: 1 ,090 km (1 995 est.)
Waterways: 460 km, navigable by small oceangoing
vessels and river and coastal steamers; 3,300 km
navigable by native craft
Ports and harbors: Cayenne, Degrad des Cannes,
Saint-Laurent du Maroni
Merchant marine: none (1999 est.)
Airports: 11 (1999 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 {1 999 est.)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 2
under 914 m: 5(1 999 est.)
i Military
Military branches: French Forces, Gendarmerie
Military manpower - availability:
males age 15-49: 48,445 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 31 ,367 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
Railways:
total: 649 km (Gabon State Railways or OCTRA)
standard gauge: 649 km 1 .435-m gauge; single track
(1994)
Highways:
total: 7,670 km
paved: 629 km (including 30 km of expressways)
unpaved: 7,041 km (1996 est.)
Waterways: 1 ,600 km perennially navigable
Pipelines: crude oil 270 km; petroleum products 14
km
Ports and harbors: Cap Lopez, Kango, Lambarene,
Libreville, Mayumba, Owendo, Port-Gentil
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 2,41 9 GRT/
3,205 DWT
ships by type: cargo 1 (1 999 est.)
Airports: 61 (1999 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m: 1
2,438 to 3,047 m:-\\
180
Gabon (continued)
1,524 to 2, 437 m: 8
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways;
total: 50
1,524 to 2,437 m: 9
914 to 1,523 m: 16
under 914 m: 25 (1999 est.)
M i I i f a r^
Military branches: Army, Navy, Air Force,
Republican Guard (charged with protecting the
president and other senior officials). National
Gendarmerie, National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 278,251 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 143,278 (2000 est.)
Military manpower - reaching military age
annually;
mates; 11,291 (2000 est.)
Military expenditures - dollar figure: $91 million
(FY96)
Military expenditures - percent of GDP: 1 .6%
(FY96)
|i~Tf a n sTa t i o^nTl I s s Fe s
Disputes " international: maritime boundary
dispute with Equatorial Guinea because of disputed
sovereignty over islands in Corisco Bay
Background; The Gambia gained its independence
from the UK in 1 965; it formed a short-lived federation
of Senegambia with Senegal between 1 982 and 1 989.
In 1 991 the two nations signed a friendship and
cooperation treaty. A military coup in 1994 overthrew
the president and banned political activity, but a new
1996 constitution and presidential elections, followed
by parliamentary balloting in 1997, have completed a
nominal return to civilian rule. The Gambia recently
emerged from its isolation to accept a non-permanent
seat on the UN Security Council during 1998-99,
1^ Geo g f a p
Location: Western Africa, bordering the North
Atlantic Ocean and Senegal
Geographic coordinates: 13 28 N, 16 34 W
Map references; Africa
Area;
total: 1 1 ,300 sq km
land: 10,000 sq km
water 1 ,300 sq km
Area - comparative; slightly less than twice the size
of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline; 80 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
ferr/tor/a/ sea; 12 nm
Climate; tropical; hot, rainy season (June to
November); cooler, dry season (November to May)
Terrain: flood plain of the Gambia river flanked by
some low hills
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources; fish
Land use:
arable land: 18%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 28%
ofher;45% (1993 est.)
Irrigated land: 150 sq km (1993 est.)
Natural hazards: rainfall has dropped by 30% in the
last 30 years
Environment ■ current issues; deforestation;
desertification; water-borne diseases prevalent
Environment ■ international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: almost an enclave of Senegal;
smallest country on the continent of Africa
Population; 1,367,124 (July 2000 est.)
Age structure:
0-14 years: 45% (male 31 1 ,293; female 308,570)
15-64 years: 52% (male 352,765; female 358,258)
65 years and over: 3% (male 1 9,099; female 1 7,1 39)
(2000 est.)
Population growth rate; 3.2% (2000 est.)
Birth rate: 42.28 blrths/l ,000 population (2000 est.)
Death rate: 13.21 deaths/1 ,000 population
(2000 est.)
Net migration rate: 2.97 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.11 male(s)/female
total population: 1 male(s)/female (2000 est.)
181
Gambia, Tha (continued)
Infant mortality rate: 79.29 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 53.2 years
male: 51 .29 years
female: 55.16 years (2000 est.)
Total fertility rate: 5.76 children born/woman
(2000 est.)
Nationality:
noun: Gambian(s)
adjective: Gambian
Ethnic groups: African 99% (Mandinka 42%, Fula
18%, Wolof 16%, Jola 10%, Serahuli 9%, other 4%),
non-African 1%
Religions: Muslim 90%, Christian 9%, indigenous
beliefs 1%
Languages: English (official), Mandinka, Wolof,
Fula, other indigenous vernaculars
Literacy:
definition: age 1 5 and over can read and w/rite
total population: 38.6%
male: 52.8%
fema/e; 24.9% (1995 est.)
Railways;
total: 2,548 km
standard gauge: 1 ,565 km 1.435-m gauge (36 km
electrified; 23 km double track)
narrow gauge: 961 km 1.000-m gauge; 22 km
0.750-m gauge (a rack type railway for steep grades)
Highways;
total: 117,000 km
paved: 107,406 km (including 470 km of
expressways)
unpaved: 9,594 km (1996 est.)
Waterways: 80 km; system consists of three coastal
canals; including the Corinth Canal (6 km) which
crosses the Isthmus of Corinth connecting the Gulf of
Corinth with the Saronic Gulf and shortens the sea
voyage from the Adriatic to Peiraiefs (Piraeus) by 325
km; and three unconnected rivers
Pipelines: crude oil 26 km; petroleum products 547
km
Ports and harbors: Alexandroupolis, Elefsis,
Irakleion (Crete), Kavala, Kerkyra, Chalkis,
Igoumenitsa, Lavrion, Patrai, Peiraiefs (Piraeus),
Thessaloniki, Volos
Merchant marine;
total: 779 ships (1 ,000 GRT or over) totaling
24,744,872 GRT/43,734,138 DWT
ships by type: bulk 273, cargo 60, chemical tanker 22,
combination bulk 5, combination ore/oil 8, container
43, liquified gas 5, multi-functional large load carrier 1 ,
passenger 12, passenger/cargo 2, petroleum tanker
245, refrigerated cargo 3, roll-on/roll-off 19, short-sea
passenger 75, specialized tanker 4, vehicle carrier 2
(1999 est.)
Airports: 80 (1999 est.)
Airports - with paved runways:
total: 64
over 3,047 m: 6
196
Groece (continued)
2,438 to 3,047 m:t5
1,524 to 2,437 m:t8
914 to 1,523 m: 17
under 914 m: 8 (1999 est.)
Airports - with unpaved runways;
tofa/;16
over 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m: 12 (1999 est.)
Heliports: 2 (1999 est.)
I Military
Military branches: Hellenic Army, Hellenic Navy,
Heilenic Air Force, National Guard, Police
Military manpower - military age: 21 years of age
Military manpower - availability;
males age 15-49; 2,674,571 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 2,043,414 (2000 est.)
Military manpower - reaching military age
annually;
males: 78,448 (2000 est.)
Military expenditures - dollar figure: $4.04 billion
(FY98 est.)
Military expenditures - percent of GDP: NA%
I transnational Issues
Disputes - international: complex maritime, air, and
territorial disputes with Turkey in Aegean Sea; Cyprus
question with Turkey; dispute with The Former
Yugoslav Republic of Macedonia over its name
Illicit drugs; a gateway to Europe for traffickers
smuggling cannabis and heroin from the Middle East
and Southwest Asia to the West and precursor
chemicals to the East; some South American cocaine
transits or is consumed in Greece
iGreentand
I (part of the Kingdom of Denmark)
k'':
Background: The world''s largest island, about 84%
ice-capped, Greenland was granted self-government
in 1978 by the Danish parliament. The law went into
effect the following year.
I ~ '' G e oT^arpTh y
Location: Northern North America, island between
the Arctic Ocean and the North Atlantic Ocean,
northeast of Canada
Geographic coordinates; 72 00 N, 40 00 W
Map references: Arctic Region
Area:
fofa/;2,175,600 sq km
land: 2,175,600 sq km (341,700 sq km ice-free,
1,833,900 sq km ice-covered) (est.)
Area - comparative: slightly more than three times
the size of Texas
Land boundaries; 0 km
Coastline: 44,087 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: arctic to subarctic; cool summers, cold
winters
Terrain: flat to gradually sloping icecap covers all but
a narrow, mountainous, barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnb\\om 3,700 m
Natural resources: zinc, lead, iron ore, coal,
molybdenum, gold, platinum, uranium, fish, seals,
whales
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 %
forests and woodland: 0%
other: 99% [1993 est.)
Irrigated land: NA sq km
Natural hazards: continuous permafrost over
northern two-thirds of the island
Environment - current issues; protection of the
arctic environment; preservation of the Inuit traditional
way of life, including whaling; note - Greenland
participates actively in Inuit Circumpolar Conference
(ICC)
Geography ■ note: dominates North Atlantic Ocean
between North America and Europe; sparse
population confined to small settlements along coast;
world''s second largest ice cap
I" People
Population: 56,309 (July 2000 est.)
Age structure;
0-14 years: 27% (male 7,71 8; female 7,483)
15-64 years: 68% (male 20,860; female 17,272)
65 years and over: 5% (male 1 ,332; female 1 ,644)
(2000 est.)
Population growth rate: 0.09% (2000 est.)
Birth rate: 16.85 births/1,000 population (2000 est.)
Death rate: 7.55 deaths/1 ,000 population (2000 est.)
Net migration rate: -8.38 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1.21 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 .13 male(s)/female (2000 est.)
Infant mortality rate: 1 8.26 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 68.07 years
male: 64.52 years
female: 71 .69 years (2000 est.)
Total fertility rate: 2.45 children born/woman
(2000 est.)
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 87% (Eskimos and
Greenland-born whites), Danish and others 13%
Religions; Evangelical Lutheran
197
Greenland (continued)
Languages: Eskimo dialects, Danish, Greenlandic
(an Inuit dialect)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
note: similar to Denmark proper
Railways: 0 km
Highways:
total: 885 km
paved: 675 km
unpaved: 210 km
note: there is another 685 km of roads classified
non-public, including roads located on federal
government installations
Ports and harbors: Apra Harbor
Merchant marine: none (1 999 est.)
Airports: 5 (1999 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m:1
914 to 1,523 m: 1 (1999 est.)
Airports - with unpaved runways:
total: 1
under 914 m:1 (1999 est.)
Railways;
total: 884 km (102 km privately owned)
narrow gauge: 884 km 0.91 4-m gauge (single track)
Highways;
fofa/;13,100 km
paved: 3,616 km (including 140 km of expressways)
unpaved: 9,484 km (1996 est.)
Waterways: 260 km navigable year round; additional
730 km navigable during high-water season
Pipelines: crude oil 275 km
Ports and harbors: Champerico, Puerto Barrios,
Puerto Quetzal, San Jose, Santo Tomas de Castilla
Merchant marine: none (1999 est.)
Airports: 477 (1999 est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 3
1,524 to 2,437 m:1
914 to 1,523 m: 5
under 914 m; 2 (1999 est.)
206
Guatomala (continued)
Airports - with unpaved runways:
total: 466
2,438 to 3,047 m:t
1,524 to 2,437 m: 9
914 to 1,523 m: 124
under 914 m: 332 (1 999 est.)
f M i i i t a r y
Miiitary branches: Army, Navy, Air Force
Miiitary manpower - miiitary age: 18 years of age
Miiitary manpower - avaiiability:
males age 15-49: 3,000,599 (2000 est.)
Miiitary manpower - fit for military service:
males age 15-49: 1 ,959,050 (2000 est.)
Military manpower - reaching military age
annually:
males: 137,607 (2000 est.)
Military expenditures - dollar figure: $124 million
(FY98)
Military expenditures - percent of GDP: 0.7%
(FY98)
I f r a n s n a t i 0 ri a 1 issues
Disputes - international: territory in Belize claimed
by Guatemala; precise alignment of boundary in
dispute
Illicit drugs: transit country for cocaine shipments;
minor producer of illicit opium poppy and cannabis for
the international drug trade; active eradication
program in 1996 effectively eliminated the cannabis
crop; proximity to Mexico makes Guatemala a major
staging area for drugs (cocaine shipments)
(Guernsey
^(British crown dependency)
L^J
0 2.5 5 km
6 2‘5
5„l Bumou
Alderney
English
Channel
Guernsey^
Lihou y
Island ^
‘^T^PETEm
J PORT f
pSt. Sampson
"^Herm
‘•jethou sarft
Brechou-^y \\
Little SarlP.
I Introduction
Background: The island of Guernsey and the other
Channel Islands represent the last remnants of the
medieval Dukedom of Normandy, which held sway in
both France and England. The islands were the only
British soil occupied by German troops in World War
F . ''"GebgTaph''y"''
Location: Western Europe, islands In the English
Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total: 194 sq km
land: 194 sq km
wafer; 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and
some other smaller islands
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 12 nm
ferr/''for/a/sea;3 nm
Climate: temperate with mild winters and cool
summers; about 50% of days are overcast
Terrain: mostly level with low hills In southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: NA
Geography - note: large, deepwater harbor at Saint
Peter Port
I"''” . p e o''p''re''“
Population: 64,080 (July 2000 est.)
Age structure:
0-14years: 16% (male 5,302; female 5,167)
15-64 years: 67% (male 21 ,171 ; female 21,523)
65 years and over: 1 7% (male 4,480; female 6,437)
(2000 est.)
Population growth rate: 0.42% (2000 est.)
Birth rate: 10.17 births/1 ,000 population (2000 est.)
Death rate: 9.85 deaths/1,000 population
(2000 est.)
Net migration rate: 3.9 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate: 5.07 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth :
total population: 79.65 years
male: 76.65 years
female: 82.75 years (2000 est.)
Total fertility rate: 1 .35 children born/woman
(2000 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy:
definition: NA
total population: HA%
male: NA%
female: NA%
I Government
Country name:
conventional long form: Bailiwick of Guernsey
conventional short form: Guernsey
Data code: GK
Dependency status: British crown dependency
Government type: NA
Capital: Saint Peter Port
Administrative divisions: none (British crown
dependency)
Independence: none (British crown dependency)
National holiday: Liberation Day, 9 May (1945)
Constitution: unwritten; partly statutes, partly
common law and practice
207
GusrnSOy (continued)
Legal system: English law and local statute; justice
is administered by the Royal Court
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952)
head of government: Lieutenant Governor Sir John
COWARD (since NA 1994) and Bailiff De Vic G.
CAREY (since NA)
cab/nef; Advisory and Finance Committee appointed
by the Assembly of the States
elections: none; the monarch is hereditary; lieutenant
governor appointed by the monarch; bailiff appointed
by the monarch
Legislative branch: unicameral Assembly of the
States (59 voting members - 12 councilors serving
six-year terms, half elected every three years; 33
deputies elected from multi- or single-member
districts every four years; 10 representatives from
parish authorities; 2 representatives from Aldenay; the
bailiff and deputy bailiff; and 2 non-voting members -
the Attorney General and the Solicitor General both
appointed by the monarch
elections: last held 20 April 1994 (next to be held NA
2000)
election results: percent of vote - NA; seats - all
independents
Judicial branch: Royal Court
Political parties and leaders: none; all
independents
International organization participation: none
Diplomatic representation In the US: none (British
crown dependency)
Diplomatic representation from the US: none
(British crown dependency)
Flag description: white with the red cross of Saint
George (patron saint of England) extending to the
edges of the flag and a yellow equal-armed cross of
William the Conqueror superimposed on the Saint
George cross
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: Saint Peter Port, Saint
Sampson
Merchant marine: none (1999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 2
914 to 1,523 m:1
under 914 m:1 (1999 est.)
Railways:
total: 1 ,086 km
standard gauge: 279 km 1 .435-m gauge
narrow gauge: 807 km 1.000-m gauge (includes 662
km in common carrier service from Kankan to
Conakry)
Highways:
total: 30,500 km
paved: 5,033 km
unpaved: 25,467 km (1996 est.)
Waterways: 1 ,295 km navigable by shallow-draft
native craft
Ports and harbors: Boke, Conakry, Kamsar
Merchant marine: none (1999 est.)
Airports: 15 (1999 est.)
Airports - with paved runways;
total: 5
over 3,047 m: 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 8 (1999 est.)
Airports - with unpaved runways;
total: 10
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m:1 (1999 est.)
Railways: 0 km
Highways:
tofa/.- 2,784 km
paved: 2,187 km
unpaved: 597 km (1987 est.)
Ports and harbors: Le Port, Points des Galets
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 28,264 GRT/
44,885 DWT
ships by type: chemical tanker 1 (1 999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914to 1,523m:1 (1999 est.)
408
Reunion (continued)
I Military
Military branches: French forces (Army, Navy, Air
Force, and Gendarmerie)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 187,423 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 95,854 (2000 est.)
Military manpower - reaching military age
annually:
males: 6,037 (2000 est.)
Military - note: defense is the responsibility of
I transnational Is^es
Disputes - international: none
Background: Soviet occupation following World War
II led to the formation of a communist Peoples
Republic in 1 947 and the abdication of the king. The
decades-long rule of President Nicolae CEAUSESCU
became increasingiy draconian through the 1 980s. He
was overthrown and executed in late 1989. Former
communists dominated the government untii 1996
when they were swept from power. Much economic
restructuring remains to be carried out before
Romania can achieve its hope of joining the EU.
Location: Southeastern Europe, bordering the Black
Sea, between Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
fofa/;237,500sqkm
land: 230,340 sq km
wafer;7,160sqkm
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km,
Moldova 450 km, Serbia and Montenegro 476 km (all
with Serbia), Ukraine (north) 362 km, Ukraine (east)
169 km
Coastline: 225 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nrr\\
Climate: temperate; cold, cloudy winters with
frequent snow and fog; sunny summers with frequent
showers and thunderstorms
Terrain: central Transylvanian Basin is separated
from the Plain of Moldavia on the east by the
Carpathian Mountains and separated from the
Walachian Plain on the south by the Transylvanian
Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining),
timber, natural gas, coal, iron ore, salt, arable land,
hydro power
Land use:
arable land: 41%
permanent crops: 3%
permanent pastures: 21 %
forests and woodland: 29%
other: 6% (1993 est.)
Irrigated land: 31 ,020 sq km (1993 est.)
Natural hazards: earthquakes most severe in south
and southwest; geologic structure and climate
promote landslides
Environment - current issues: soil erosion and
degradation; water pollution; air pollution in south from','f7f706e639f5f4e0ebd6769e819ff290db029b2128dca20e2ffb46ce9f382dbc','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc89369a7f72d621d9de15203d166fb99f8564869ac0283477c1ead77685afdb',2000,'FR','France','transportation',159,'industrial effluents; contamination of Danube delta
wetlands
Environment - international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: controls most easily traversable
land route between the Balkans, Moldova, and
Railways: 0 km
Highways:
total: 1 ,040 km
paved: 320 km
unpaved: 720 km (1 996 est.)
Ports and harbors: Kingstown
Merchant marine:
total: 825 ships (1 ,000 GRT or over) totaling
7,253,092 GRT/1 0,894,566 DWT
ships by type: barge carrier 1 , bulk 142, cargo 400,
chemical tanker 31 , combination bulk 1 0, combination
ore/oil 5, container 47, liquified gas 5, livestock carrier
5, multi-functional large load carrier 3, passenger 3,
petroleum tanker 60, refrigerated cargo 41 , roll-on/
roll-off 51 , short-sea passenger 12, specialized tanker
8, vehicle carrier 1 (1999 est.)
426
Raiiways:
total: 2,168 km
standard gauge: 471 km 1.435-m gauge
narrow gauge: 1 ,687 km 1 .000-m gauge
dual gauge: 10 km 1 .000-m and 1 .435-m gauges
(three rails)
Highways;
tofa/; 23,100 km
paved: 18,226 km
unpaved: 4,874 km (1996 est.)
Pipelines: crude oil 797 km; petroleum products 86
km; natural gas 742 km
Ports and harbors; Bizerte, Gabes, La Goulette,
Sfax, Sousse, Tunis, Zarzis
Merchant marine:
total: 1 6 ships (1 ,000 GRT or over) totaling 1 51 ,084
GRT/1 59,576 DWT
ships by type: bulk 2, cargo 5, chemical tanker 3,
liquified gas 1 , petroleum tanker 1 , short-sea
passenger 3, specialized tanker 1 (1999 est.)
Airports: 32 (1999 est.)
Airports - with paved runways:
total: 15
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 3
914 to 1,523 m:3{im est.)
Airports - with unpaved runways;
total: 17
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 7 (1 999 est.)
t Military
Miiitary branches: Army, Navy, Air Force,
paramiiitary forces. National Guard
Military manpower - military age: 20 years of age
Military manpower - availability;
males age 15-49: 2,669,934 (2000 est.)
Military manpower ■ fit for military service:
males age 15-49: 1 ,523,849 (2000 est.)
Military manpower - reaching military age
annually:
mates; 102,464 (2000 est.)
500
Tunisia (continued)
Military expenditures - dollar figure; $356 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
Transnatio n^ fs s Fe s
Disputes - international; maritime boundary
dispute with Libya; Malta and Tunisia are discussing
the commercial exploitation of the continental shelf
between their countries, particularly for oil exploration
Turkish remnants of the Ottoman Empire. Soon
thereafter the country instituted secular laws to
replace traditional religious fiats. In 1945 Turkey
joined the UN and in 1 949 it became a member of
NATO. Turkey seized the northern portion of Cyprus
in 1974 to prevent a Greek takeover of the island;
relations between the two countries remain strained.
Periodic military offensives against Kurdish terrorists
have dislocated part of the population in southeast
Turkey and have drawn international condemnation.
I Geography
Location; southwestern Asia (that part west of the
Bosporus is sometimes included with Europe),
bordering the Black Sea, between Bulgaria and
Georgia, and bordering the Aegean Sea and the
Mediterranean Sea, between Greece and Syria
Geographic coordinates; 39 00 N, 35 00 E
Map references: Middle East
Area:
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 2,627 km
border countries: Armenia 268 km, Azerbaijan 9 km,
Bulgaria 240 km, Georgia 252 km, Greece 206 km,
Iran 499 km, Iraq 331 km, Syria 822 km
Coastline; 7,200 km
Maritime claims;
exclusive economic zone: in Black Sea only: to the
maritime boundary agreed upon with the former
USSR
territorial sea: 6 nm in the Aegean Sea; 1 2 nm in Black
Sea and In Mediterranean Sea
Climate: temperate: hot, dry summers with mild, wet
winters; harsher in interior
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: antimony, coal, chromium,
mercury, copper, borate, sulfur, iron ore, arable land,
hydropower
Land use;
arable land: 32%
permanent crops: A%
permanent pastures: 1 6%
forests and woodland: 26%
other; 22% (1993 est.)
Irrigated land: 36,740 sq km (1993 est.)
Natural hazards: very severe earthquakes,
especially in northern Turkey, along an arc extending
from the Sea of Marmara to Lake Van
Environment - current issues: water pollution from
dumping of chemicals and detergents; air pollution,
particuiarly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
Environment - international agreements;
party to: K\\\\ Pollution, Antarctic Treaty, Biodiversity,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Environmental Modification
Geography - note: strategic location controlling the
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean Seas
Feopie ^
Population: 65,666,677 (July 2000 est.)
Age structure:
0-14 years: 29% (male 9,722,217; female 9,375,920)
15-64 years: 65% (male 21 ,671 ,638; female
20,966,110)
65 years and over: 6% (male 1 ,81 1 ,599; female
2,119,193) (2000 est.)
501
Turkoy (continued)
Population growth rate: 1 .27% (2000 est.)
Birth rate: 1 8.65 births/1 ,000 population (2000 est.)
Death rate: 5.96 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: t. 05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 1 .02 male(s)/female (2000 est.)
Infant mortality rate: 48.9 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.97 years
male: 68.63 years
female: 73.41 years (2000 est.)
Total fertility rate: 2.16 children born/woman
(2000 est.)
Nationality:
rroun; Turk(s)
ady''ecf/Ve; Turkish
Ethnic groups: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(Christian and Jews)
Languages: Turkish (official), Kurdish, Arabic,
Armenian, Greek
Literacy:
definition: age 15 and over can read and write
total population: 82.3%
male: 91 .7%
fema/e; 72.4% (1995 est.)
517
United Kingdom (continued)
Geographic coordinates; 54 00 N, 2 00 W
Map references: Europe
Area:
total: 244,820 sq km
land: 241 ,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland Islands
Area - comparative: slightly smaller than Oregon
Land boundaries;
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime ciaims;
continental shelf: as defined in continental shelf
orders or in accordance with agreed upon boundaries
exclusive fishing zone: 200 nm
temMa/ sea; 12 nm
Ciimate: temperate; moderated by prevailing
southwest winds over the North Atlantic Current; more
than one-half of the days are overcast
Terrain: mostly rugged hills and low mountains; level
to rolling plains in east and southeast
Elevation extremes;
lowest point: Fenland -4 m
highest point: Ben Nevis 1 ,343 m
Natural resources: coal, petroleum, natural gas, tin,
limestone, iron ore, salt, clay, chalk, gypsum, lead,
silica, arable land
Land use;
arable land: 25%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 10%
often 19% (1993 est.)
Irrigated land: 1,080 sq km (1993 est.)
Natural hazards; NA
Environment - current issues; sulfur dioxide
emissions from power plants contribute to air
pollution; some rivers polluted by agricultural wastes;
and coastal waters polluted because of large-scale
disposal of sewage at sea
Environment - internationai agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: lies near vital North Atlantic sea
lanes; only 35 km from France and now linked by
tunnel under the English Channel; because of heavily
indented coastline, no location is more than 125 km
from tidal waters','242acefbaa06d5e4c7dac76a5ec607d9d87e2ff2bb5ba82907b77e9e06cd3d25','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9cdc3ac053d7d382c54d007feac6ad7dad5582e8defa3a572f3b0b9d913fd22',2000,'SI','Slovenia','transportation',160,'Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total: 56,538 sq km
/arrcf; 56,41 Osq km
wafer 128 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
fofa/;2,197 km
border countries: Bosnia and Herzegovina 932 km,
Hungary 329 km, Serbia and Montenegro 266 km
(241 km with Serbia; 25 km with Montenegro),
Slovenia 670 km
Coastline: 5,790 km (mainland 1,778 km, islands
4,012 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: 12 nm
Climate: Mediterranean and continental; continental
climate predominant with hot summers and cold
winters; mild winters, dry summers along coast
Terrain: geographically diverse; flat plains along
Hungarian border, low mountains and highlands near
Adriatic coastline and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1 ,830 m
Natural resources: oil, some coal, bauxite,
low-grade iron ore, calcium, natural asphalt, silica,
mica, clays, salt, hydropower
Land use:
arable land: 21%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 38%
of/ier;19%(1993est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: frequent and destructive
earthquakes
Environment - current issues: air pollution (from
metallurgical plants) and resulting acid rain is
damaging the forests; coastal pollution from industrial
and domestic waste; widespread casualties and
destruction of infrastructure in border areas affected
by civil strife
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Hazardous Wastes,
Law of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Desertification
Geography ■ note: controls most land routes from
Western Europe to Aegean Sea and Turkish Straits
1^ People
Population: 4,282,21 6 (July 2000 est.)
Age structure:
0-14 years: 18% (male 396,484; female 376,267)
15-64 years: 67% (male 1,445,101; female
1,420,159)
65 years and over: 1 5% (male 238,853; female
405,352) (2000 est.)
Population growth rate: 0.93% (2000 est.)
Birth rate: 12.82 births/1 ,000 population (2000 est.)
Death rate: 1 1 .51 deaths/1 ,000 population
(2000 est.)
Net migration rate: 7.98 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 7.35 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73.67 years
male: 70.04 years
female: 77.51 years (2000 est.)
125
Croatia (continued)
Total fertility rate: 1 .94 children born/woman
(2000 est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic groups: Croat 78.1%, Serb 12.2%, Muslim
0.9%, Hungarian 0.5%, Slovenian 0.5%, Czech 0.4%,
Albanian 0.3%, Montenegrin 0.3%, Roma 0.2%,
others 6.6% (1991)
Religions: Roman Catholic 76.5%, Orthodox 11.1%,
Muslim 1 .2%, Protestant 0.4%, others and unknown
10.8% (1991)
Languages: Croatian 96%, other 4% (including
Italian, Hungarian, Czech, Slovak, and German)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 99%
fema/e; 95% (1991 est.)','80ccac733e1f03b77cd072f2775718cb0c35b55e5dce7cce9da5504f7ff0a393','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e4cbfb3632ae46f1fbc90f7ba1a3b0df24b98317b8c2e92ba315bacb5adca9c',2000,'CU','Cuba','transportation',169,'Railways:
total: 4,807 km
standard gauge: 4,807 km 1.435-m gauge (147 km
electrified)
note: a large amount of track is in private use by sugar
plantations
Highways:
total: 60,858 km
paved: 29,820 km (including 638 km of expressway)
unpaved: 31 ,038 km (1 997 est.)
Waterways: 240 km
Ports and harbors: Cienfuegos, Havana,
Manzanillo, Mariel, Matanzas, Nuevitas, Santiago de
Merchant marine:
total: 15 ships (1,000 GRT or over) totaling 63,269
GRT/90,228 DWT
Ships by type: bulk 1 , cargo 7, liquified gas 1 ,
petroleum tanker 1 , refrigerated cargo 5 (1999 est.)
Airports: 170 (1999 est.)
Airports - with paved runways:
total: 77
over 3,047 m: 7
2,438 to 3,047 m:0
1,524 to 2,437 m: 15
914 to 1,523 m:M
under 91 4 m: 35 {1 999 est.)
Airports - with unpaved runways:
total: 93
914 to 1,523 m: 32
under 914 m:81 (1999 est.)
Railways: 0 km
Highways:
total: 780 km
paved: 393 km
unpaved: 387 km (1996 est.)
Ports and harbors: Portsmouth, Roseau
Merchant marine: none (1999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways:
total: 2
914 to f,523m; 2 (1999 est.)
r Military
Military branches: Commonwealth of Dominica
Police Force (includes Special Service Unit, Coast
Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','c9d70bde7c4cf246c6bcdcb631638b92ca169aaea9bd13d0bee70977a4ce8e0a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('723678e7aa74eabf5fdcde670dc5e72399abfcb9a0f90cd0a55987697578d2b2',2000,'PE','Peru','transportation',179,'Railways:
total: 602 km (single track; note - some sections
abandoned, unusable, or operating at reduced
capacity)
narrow gauge: 602 km 0.91 4-m gauge
Highways:
total: 10,029 km
paved: 1 ,986 km (including 327 km of expressways)
unpaved: 8,043 km (1997 est.)
Waterways: Rio Lempa partially navigable
Ports and harbors: Acajutia, Puerto Cutuco, La
Libertad, La Union, Puerto El Triunfo
Merchant marine: none (1999 est.)
Airports: 85 (1999 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
1,524to2,437m:\\
914to1,523m:2(m9est)
Airports - with unpaved runways:
total: 81
914 tot, 523 m:M
under 914 m: 64 (1999 est.)
Heliports: 1 (1999est.)
I Military
Military branches: Army, Navy, Air Force
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49; 1,428,974 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 906,656 (2000 est.)
Military manpower • reaching military age
annually:
ma/es; 67,1 81 (2000 est.)
Military expenditures - dollar figure: $105 million
(FY98)
Military expenditures • percent of GDP: 0.9%
(FY98)
f f r a n s n a t i 0 n a f Issues
Disputes - international: the Honduras-EI Salvador
Border Protocol ratified by Honduras in May 1999
established a framework for a long-delayed border
demarcation, which is currently underway; with
respect to the maritime boundary in the Golfo de
Fonseca, the ICJ referred to the line determined by
the 1900 Honduras-Nicaragua Mixed Boundary
Commission and advised that some tripartite
resolution among El Salvador, Honduras and
Nicaragua likely would be required
Illicit drugs: transshipment point for cocaine;
marijuana produced for local consumption; domestic
drug abuse on the rise
[Equatorial Guinea
K
Background: Composed of a mainland portion and
five inhabited islands. Equatorial Guinea has been
ruled by ruthless leaders who have badly
mismanaged the economy since independence from
1 90 years of Spanish rule in 1 968. Although nominally
a constitutional democracy since 1991, the 1996
presidential and 1 999 legislative elections were widely
seen as being flawed.
I'' Geography
Location: Western Africa, bordering the Bight of
Biafra, between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,051 sq km
land: 28,051 sq km
wafer; 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands
are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: oil, petroleum, timber, small
unexploited deposits of gold, manganese, uranium
Land use:
arable land: 5%
permanent crops: 4%
permanent pastures: 4%
forests and woodland: 46%
ofter;41%(1993est.) .
152
Equatorial Guinea (continued)
Irrigated land: NAsqkm
Natural hazards: violent w/indstorms, flash floods
Environment - current issues: tap water Is not
potable; desertification
Environment - international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Law of the Sea, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: insular and continental regions
rather widely separated
p People
Population: 474,214 (July 2000 est.)
Age structure:
0-14years:43% (male 101,724; female 100,787)
15-64 years: 54% (male 121,290; female 132,581)
65 years and over: 3% (male 7,960; female 9,872)
(2000 est.)
Population growth rate: 2,47% (2000 est.)
Birth rate: 38.13 births/1 ,000 population (2000 est.)
Death rate: 13.4 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 94.83 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 53.56 years
male: 51 .53 years
female: 55.65 years (2000 est.)
Total fertility rate: 4.94 children born/woman
(2000 est.)
Nationality:
noun: Equatorial Guinean(s) or Equatogulnean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 1 5 and over can read and write
total population: 78.5%
male: 89.6%
female: 68.1 % (1 995 est.)
r Government
Country name:
conventional long form: Republic of Equatorial','bdb5960e21a5219643194c050adf0363986a2c83e87522311112c8d3a70ec5fe','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b86e37978e6db57b0461c94e81594c38103842afa552e2693807c151aeb1b4ae',2000,'GN','Guinea','transportation',180,'conventional short form: Equatorial Guinea
local long form: Republica de Guinea Ecuatorial
local short form: Guinea Ecuatorial
former: Spanish Guinea
Data code: EK
Government type: republic
Capital: Malabo
Administrative divisions: 7 provinces (provincias,
singular - provincia); Annobon, Bioko Norte, Bioko
Sur, Centro Sur, Kie-Ntem, Litoral, Wele-Nzas
Independence: 12 October 1968 (from Spain)
National holiday: Independence Day, 12 October
(1968)
Constitution: approved by national referendum 17
November 1991; amended January 1995
Legal system: partly based on Spanish civil law and
tribal custom
Suffrage: 18 years of age; universal adult
Executive branch:
chief of state: President Brig. Gen. (Ret.) Teodoro
OBIANG NGUEMA MBASOGO (since 3 August 1 979
when he seized power in a military coup)
head of government: Prime Minister Seraf in Seriche
DOUGAN (since NA April 1996); First Vice Prime
Minister and Agriculture Minister Miguei OYONO
NDONG (since NA January 1998); Second Vice
Prime Minister for Internal Affairs Demetrio Eio
NDONG NZE FUMU (since NA January 1998)
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote to a
seven-year term; election last held 25 February 1 996
(next to be held NA February 2003); prime minister
and vice prime ministers appointed by the president
election results: President Teodoro OBIANG
NGUEMA MBASOGO reelected with 98% of popular
vote in elections marred by widespread fraud
Legislative branch: unicameral House of People''s
Representatives or Camara de Representantes del
Pueblo (80 seats; members directly elected by
popular vote to serve five-year terms)
elections: last held 7 March 1999 (next to be held NA
2004)
election results: percent of vote by party - PDGE80%,
UP 6%, CPDS 5%; seats by party - PDGE 75, UP 4
and CPDS 1
note: opposition parties have refused to take up their
seats in the House to protest widespread irregularities
in the 1999 legislative elections
Judicial branch: Supreme Tribunal
Political parties and leaders: Convergence Party
for Social Democracy or CPDS [Placido Miko
ABOGO]; Democratic Party for Equatorial Guinea or
PDGE (ruling party) [Augustin Nse NFUMU]; Party for
Progress of Equatoriai Guinea or PPGE [Severo
MOTO]; Popular Action of Equatorial Guinea or APGE
[Miguel Esono EMAN]; Popular Union or UP [Fabian
MUSA, general secretary]; Progressive Democratic
Alliance or ADP [Victorino Bolekia BONAY, mayor of
Maiabo]
International organization participation: ACCT,
ACP, AfDB, BDEAC, CEEAC, ECA, FAO, FZ, G-77,
IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Intelsat, Interpol, IOC, ITU, NAM, OAS
(observer), OAU, OPCW, UDEAC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WlPO, WToO, WTrO
(applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Pastor Micha ONDO
BILE
chancery: 1712 1 Street NW, Suite 410, Washington,
DC 20006
telephone: [1] (202) 296-4174
FAX; [1] (202) 296-4195
Diplomatic representation from the US:
chief of mission: Ambassador John M. YATES .
note: the US does not have an embassy in Equatorial
Guinea (embassy closed September 1995); US
relations with Equatorial Guinea are handled through
the US Embassy in Yaounde, Cameroon; the US
State Department is considering opening a Consulate
Agency in Malabo
Flag description: three equal horizontal bands of
green (top), white, and red with a blue isosceles
triangle based on the hoist side and the coat of arms
centered in the white band; the coat of arms has six
yellow six-pointed stars (representing the mainland
and five offshore islands) above a gray shield bearing
a silk-cotton tree and below which is a scroll with the
motto UNIDAD, PAZ, JUSTICIA (Unity, Peace,
Justice)
|r " Economy
Economy ■ overview: The discovery and
exploitation of large oil reserves have contributed to
dramatic economic growth in recent years. Forestry,
farming, and fishing are also major components of
GDP. Subsistence farming predominates. Although
pre-independence Equatorial Guinea counted on
cocoa production for hard currency earnings, the
deterioration of the rural economy under successive
brutal regimes has diminished potential for
agriculture-led growth. A number of aid programs
sponsored by the World Bank and the IMF have been
cut off since 1 993 because of the government''s gross
corruption and mismanagement. Businesses, for the
most part, are owned by government officials and their
family members. Undeveloped natural resources
include titanium, iron ore, manganese, uranium, and
alluvial gold. The country responded favorably to the
devaluation of the CFA franc in January 1 994. Boosts
in production, along with high world oil prices, should
further stimulate growth in 2000-2001 .
GDP: purchasing power parity - $960 million
(1999 est.)
GDP - real growth rate: 15% (1999 est.)
GDP - per capita: purchasing power parity - $2,000
(1999 est.)
GDP - composition by sector:
agriculture: 20%
industry: 60%
services: 20% (1 998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
153
Equatorial Guinea (continued)
highest 10%: m%
Inflation rate (consumer prices): 6% (1999 est.)
Labor force: NA
Unemployment rate: 30% (1998 est.)
Budget:
revenues: $47 million
expenditures: $43 million, including capital
expenditures of $7 million (1996 est.)
Industries: petroleum, fishing, sawmilling, natural
gas
Industrial production growth rate: 7.4%
(1994 est.)
Electricity - production: 21 million kWh (1998)
Electricity - production by source:
fossil fuel: 85.71%
hydro: 14.29%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 20 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1 998)
Agricuiture - products: coffee, cocoa, rice, yams,
cassava (tapioca), bananas, palm oil nuts; livestock;
timber
Exports: $555 million (f.o.b., 1999)
Exports - commodities: petroleum, timber, cocoa
Exports - partners: US 62%, Spain 1 7%, China 9%,
France 3%, Japan 3%, (1997)
Imports: $300 million (f.o.b., 1999)
Imports - commodities: petroleum, manufactured
goods and equipment
Imports - partners: US 35%, France 15%, Spain
10%, Cameroon 10%, UK 6% (1997)
Debt - external: $290 million (1999 est.)
Economic aid - recipient: $33.8 million (1995)
Currency: 1 Communaute Financiers Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
61 5.70 (1 999), 589.95 (1 998), 583.67 (1 997), 51 1 .55
(1996), 499.15 (1995)
note; since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: 1 April - 31 March
I Communicafions
Telephones - main lines in use: 3,000 (1995)
Telephones - mobile cellular: 0 (1 995)
Telephone system: poor system with adequate
government sen/ices
domestic: NA
international: international communications from Bata
and Malabo to African and European countries;
satellite earth station - 1 1ntelsat (Indian Ocean)
Radio broadcast stations: AM 0, FM 2, shortwave
4(1998)
Radios: 180,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 4,000(1997)
internet Service Providers (ISPs): NA
f Transportation
Railways:
total: 0 km
Highways:
total: 2,880 km
paved: 0 km
unpaved: 2,880 km (1996 est.)
Ports and harbors: Bata, Luba, Malabo
Merchant marine:
total: 1 1 ships (1 ,000 GRT or over) totaling 25,907
GRT/26,812 DWT
ships by type: cargo 8, passenger 2, passenger/cargo
1 (1999 est.)
Airports: 3 (1999 est.)
Airports - with paved runways;
total: 2
2,438 to 3,047 m:1
1,524 to 2,437 m:1 (1999 est.)
Airports - with unpaved runways;
total: 1
under 914 m:1 (1999 est.)
t Military
Military branches: Army, Navy, Air Force, Rapid
Intervention Force, National Police
Military manpower - availability;
males age 15-49: 105,420 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 53,564 (2000 est.)
Military expenditures • dollar figure: $3 million
(FY97/98)
Military expenditures - percent of GDP; 0.6%
(FY97/98)
Railways:
total: 317 km
narrow gauge: 317 km 0.950-m gauge (1 999)
note: links Ak''ordat and Asmara with the port of
Massawa; nonoperational since 1 978 except for about
a 5 km stretch that was reopened in Massawa in 1 994;
rehabilitation of the remainder and of the rolling stock
is under way
Highways:
total: 4,010 km
paved: 874 km
unpaved: 3,136 km (1996 est.)
Ports and harbors: Assab (Aseb), Massawa
(Mits''iwa)
Merchant marine:
total: 5 ships (1 ,000 GRT or over) totaling 16,069
GRT/1 9,549 DWT
ships by type: bulk 1 , cargo 1 , liquified gas 1 ,
petroleum tanker 1, roll-on/roll-off 1 (1999 est.)
Airports: 21 (1999 est.)
Airports - with paved runways:
total: 3
over 3,047 m: 2
2,438 to 3,047 m: 1 (1999 est.)
Airports - with unpaved runways;
total: 13
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 6
under 914 m; 2 (1999 est.)','bff220a12e2e0187e9404cca7eaad9e0281d4a3892469d5c5fea9fb956ea7078','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c4842399fe842e29127df6fc7ac299fd8024aba6f02278a49ab38224d45d1c1',2000,'JE','Jersey','transportation',195,'Railways:
total: 597 km; note - belongs to the
government-owned Fiji Sugar Corporation
narrow gauge: 597 km 0.61 0-m gauge (1995)
Highways:
total: 3,440 km
paved: 1 ,692 km
unpaved: 1 ,748 km (1996 est.)
Waterways: 203 km; 1 22 km navigable by motorized
craft and 200-metric-ton barges
Ports and harbors: Labasa, Lautoka, Levuka,
Savusavu, Suva
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 1 1 ,870
GRT/1 4,787 DWT
ships by type: chemical tanker 2, passenger 1 ,
petroleum tanker 1 , roll-on/roll-off 1 , specialized
tanker 1 (1999 est.)
Airports: 25 (1999 est.)
167
Fiji (continued)
Airports - with paved runways;
total: 3
over 3,047 m:t
1,524 to 2,437 m:t
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways;
total: 22
914 to 1,523 m: 5
under 914 m: 17 (1999 est.)','e3533423ab17076da2a2d5dd0e4ccc63ad11afbec19d70c442f70c387fbf3871','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('700b09089cd0f2dcb73c5f688fcbe96162404c09fd9c18dc47dfe37669aaf6ad',2000,'ES','Spain','transportation',219,'Railways:
total: NA km; 1 .000-m gauge system in dockyard area
only
Highways:
total: 49.9 km
paved: 49.9 km
unpaved: 0 km
Pipelines: 0 km
Ports and harbors: Gibraltar
Merchant marine:
total: 26 ships (1 ,000 GRT or over) totaling 477,1 83
GRT/752,644 DWT
ships by type: bulk 1 , cargo 2, chemical tanker 2,
container 4, multi-functional large load carrier 1 ,
passenger 1 , petroleum tanker 1 3, roll-on/roll-off 2
(1999 est.)
Airports: 1 (1999est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:t (1999 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1 999 est.)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (1999 est.)','9ad3ca9d8184262582350f7fea303e4b8160fa3426a6ca362632582352b48f62','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c23be4c1a48e0470f74fe951de490d8c03891d38a72223dd8be58c50cf3c40a5',2000,'DK','Denmark','transportation',226,'Railways: 0 km
Highways:
total: 1 ,040 km
paved: 638 km
unpaved: A02 km (1996 est.)
Ports and harbors: Grenville, Saint George''s
Merchant marine: none (1999 est.)
Airports: 3 (1999 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:1
914 to 1,523 m:1
under 914 m:1 (1999 est.)
200
Gronada (continued)
I Military
Military branches: Royal Grenada Police Force
(includes Special Service Unit), Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
I Transnational Issues
Disputes - international: none
Illicit drugs: small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
[Guadeloupe
k (overseas department
tot France)
I n f r 0 d u c t i 0 n
Background: Guadeloupe has been a French
possession since 1635. The island of Saint-Martin is
divided with the Netherlands (whose southern portion
is named Sint Maarten and is part of the Netherlands
Antilles).
Location: Caribbean, islands in the eastern
Caribbean Sea, southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the
Caribbean
Area:
total: 1 ,780 sq km
land: 1 ,706 sq km
wafer; 74 sq km
note: Guadeloupe is an archipelago of nine inhabited
islands, including Basse-Terre, Grande-Terre,
Marie-Galante, La Desirade, lies des Saintes (2),
Saint-Barthelemy, lies de la Petite Terre, and
Saint-Martin (French part of the island of Saint Martin
Area - comparative: 10 times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border countries: Netherlands Antilles (Sint Maarten)
10.2 km
Coastline: 306 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical tempered by trade winds;
moderately high humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation;
most of the seven other islands are volcanic in origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Soufriere 1 ,467 m
Natural resources: cultivable land, beaches and
climate that foster tourism
Land use:
arable land: 14%
permanent crops: 4%
permanent pastures: 14%
forests and woodland: 39%
other: 29% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: hurricanes (June to October);
Soufriere is an active volcano
Environment - current issues: NA','b993824f7123cdd0018d6af8a5640d29791b8d4e64ad467fab7fbe4301327f21','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57b49aaa93939883c1480c09133bdd4b60dbb325a97400e1f8c3c14da68c7995',2000,'GY','Guyana','transportation',233,'Railways:
total: 187 km (all dedicated to ore transport)
standard gauge: 139 km 1 .435-m gauge
narrow gauge: 48 km 0.91 4-m gauge
Highways:
total: 7,970 km
paved: 590 km
unpaved: 7,380 km (1996 est.)
Waterways: 5,900 km total of navigable waterways;
Berbice, Demerara, and Essequibo Rivers are
navigable by oceangoing vessels for 1 50 km, 1 00 km,
and 80 km, respectively
Ports and harbors: Bartica, Georgetown, Linden,
New Amsterdam, Parika
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,023 GRT/
1,972 DWT
ships by type: cargo 1 (1 999 est.)
Airports: 51 (1999 est.)
214
Guyana (continued)
Airports ■ with paved runways:
total: 5
1,524 to 2, 437 m: 2
914to1,523m:1
under 914 m: 2 {1 999 est.)
Airports - with unpaved runways:
total: 46
1,524 to 2,437 m: 2
914 to 1,523 m:7
under 914 m: 37 (1 999 est.)
I Military
Miiitary branches: Guyana Defense Force (GDF;
includes Ground Forces, Coast Guard, and Air
Corps), Guyana People''s Militia (GPM), Guyana
National Service (GNS), Guyana Police Force
Military manpower - avaiiabiiity:
males age f 5-49; 203,742 (2000 est.)
Miiitary manpower - fit for miiitary service:
males age 15-49: 153,530 (2000 est.)
Miiitary expenditures - doilar figure: $7 million
(FY94)
Military expenditures - percent of GDP: 1 .7%
(FY94)
I transnational issues
Disputes - internationai: all of the area west of the
Essequibo River claimed by Venezuela; Suriname
claims area between New (Upper Courantyne) and
Courantyne/Kutari [Koetari] Rivers (all headwaters of
the Courantyne)
Illicit drugs: transshipment point for narcotics from
South America - primarily Venezuela - to Europe and
the US; producer of cannabis
I Introduction
Background: One of the poorest countries in the
Western Hemisphere, Haiti has been plagued by
political violence for most of its history. Over three
decades of dictatorship followed by military rule ended
in 1990 when Jean-Bertrand ARISTIDE was elected
president. Most of his term was usurped by a military
takeover, but he was able to return to office in 1 994
and oversee the installation of a close associate to the
presidency in 1996.
I . . " G''e''o g''r a''p h y" ''
Location: Caribbean, western one-third of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the
Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
wafer; 190 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 275 km
border countries: Dominican Republic 275 km
Coastline: 1,771 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; semiarid where mountains in east
cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Seile 2,680 m
Natural resources: bauxite, copper, calcium
carbonate, gold, marble, hydropower
Land use:
arable land: 20%
permanent crops: 1 3%
permanent pastures: 18%
forests and woodland: 5%
other; 44% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding and earthquakes;
periodic droughts
Environment - current issues: extensive
deforestation (much of the remaining forested land Is
being cleared for agriculture and used as fuel); soil
erosion; Inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation
signed, but not ratified: Hazardous Wastes, Nuclear
Test Ban
Geography - note: shares island of Hispaniola with
Dominican Republic (western one-third is Haiti,
eastern two-thirds is the Dominican Republic)
I People
Population: 6,867,995
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 41% (male 1,430,018; female 1,393,665)
15-64 years: 55% (male 1 ,814,964; female
1,945,165)
65 years and over: 4% (male 1 38,533; female
145,650) (2000 est.)
Population growth rate: 1 .39% (2000 est.)
Birth rate: 31 .97 births/1 ,000 population (2000 est.)
Death rate: 15.13 deaths/1,000 population
(2000 est.)
Net migration rate: -2.97 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 97.1 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 49.21 years
male: 47.46 years
female: 51 .06 years (2000 est.)
Total fertility rate: 4.5 children born/woman
(2000 est.)
Nationality:
noun: Haitian(s)
215
Haiti (continued)
adjective: Haitian
Ethnic groups: black 95%, mulatto plus white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%, other
1%), none 1%, other 3% (1982)
note: roughly one-half of the population also practices
Voodoo
Languages: French (official). Creole (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 45%
male: 48%
femate; 42.2% (1995 est.)
If ''Government
Country name:
conventional long form: Republic of Haiti
conventional short form: Haiti
local long form: Republique d''Haiti
/oca/ short form; Haiti
Data code: HA
Government type: elected government
Capital: Port-au-Prince
Administrative divisions: 9 departments
(departements, singular - departement); Artibonite,
Centre, Grand''Anse, Nord, Nord-Est, Nord-Ouest,
Quest, Sud, Sud-Est
Independence: 1 January 1804 (from France)
National holiday: Independence Day, 1 January
(1804)
Constitution: approved March 1987; suspended
June 1988, with most articles reinstated March 1989;
in October 1991 , government claimed to be observing
the constitution; return to constitutional rule, October
1994
Legal system: based on Roman civil law system;
accepts compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Rene Garcia PREVAL (since
7 February 1996)
head of government: Prime Minister
Jacques-Edouard ALEXIS (since NA March 1999);
ALEXIS was appointed by President PREVAL, filling
the post that had been vacant since the resignation of
Rosny SMARTH in June 1997
cabinet: Cabinet chosen by the prime minister in
consultation with the president
elections: president elected by popular vote for a
five-year term; election last held 17 December 1995
(next to be held by December 2000); prime minister
appointed by the president, ratified by the Congress
election results: Rene Garcia PREVAL elected
president; percent of vote - Rene Garcia PREVAL
88%, Leon JEUNE 2.5%, Victor BENOIT 2.3%
Legislative branch: bicameral National Assembly or
Assemblee Nationale consists of the Senate (27
seats; members serve six-year terms; one-third
elected every two years) and the Chamber of
Deputies (83 seats; members are elected by popular
vote to serve four-year terms)
elections: Senate - last held 25 June 1995, with
reruns on 13 August and runoffs on 17 September,
and an election for nine seats 6 April 1 997 but results
were disputed; next election for two-thirds of Senate
postponed until May 2000; Chamber of Deputies - last
held 25 June 1995, with reruns on 13 August and
runoffs on 17 September (next Senate and Chamber
of Deputies elections postponed until May 2000)
election results: Senate - percent of vote by party -
NA; seats by party - OPL 7, FL-leaning 7,
independents 3, vacant 10; Chamber of Deputies -
percent of vote by party - NA; seats by party - OPL 32,
antineoliberal bloc 24, minor parties and
independents 22, vacant 5
Judicial branch: Supreme Court or Cour de
Cassation
Political parties and leaders: Alliance for the
Liberation and Advancement of Haiti or ALAH
[Reynold GEORGES]; Assembly of Progressive
National Democrats or RDNP [Leslie MANIGAT];
Confederation for Democratic Unity or KID [Evans
PAUL]; Democratic Consultation Group coalition or
ESPACE [Evans PAUL] composed of the following
parties: Confederation for Democratic Unity
KONAKOM, PANPRA, Generation 2004, and Haiti
Can or Ayiti Kapab; Generation 2004 [Claude
ROUMAIN]; Haiti Can or Ayiti Kapab [Ernst
VERDIEU]; Haitian Christian Democratic Party or
PDCH [Fritz PIERRE]; Haitian Democratic Party or
PADEMH [Clark PARENT]; Lavalas Family or FL
[Jean-Bertrand ARISTIDE]; Mobilization for National
Development or MDN [Hubert DE RONCERAY];
Movement for National Reconstruction or MRN [Rene
THEODORE]; Movement for the Installation of
Democracy in Haiti or MIDH [Marc BAZIN]; Movement
for the Organization of the Country or MOP [Gesner
COMEAU and Jean MOLIERE]; National Alliance for
Democracy and Progress [leader NA]; National
Congress of Democratic Movements or KONAKOM
[Victor BENOIT]; National Front for Change and
Democracy or FNCD [Evans PAUL and Turneb
DELPE]; National Progressive Revolutionary Party or
PANPRA [Serge GILLES]; Open the Gate Party or
PLB [Renaud BERNARDIN]; Struggling People''s
Organization or OPL [Gerard PIERRE-CHARLES];
Union of Patriotic Democrats or UPD [Rockefeller
GUERRE]
Political pressure groups and leaders:
Autonomous Haitian Workers or CATH;
Confederation of Haitian Workers or CTH; Federation
of Workers Trade Unions or FOS; National Popular
Assembly or APN; Papaye Peasants Movement or
MPP; Popular Organizations Gathering Power or
PROP; Roman Catholic Church
International organization participation: ACCT,
ACP, Caricom (observer), CCC, ECLAC, FAO, G-77,
lADB, IAEA, IBRD, ICAO, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat, Interpol, IOC, lOM,
ITU, LAES, OAS, OPANAL, OPCW, PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU,
WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador (vacant); Charge
d''Affaires Louis Harold JOSEPH
chancery: 231 1 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 332-4090
FAX; [1] (202) 745-7215
consulate(s) general: Boston, Chicago, Miami, New
York, and San Juan (Puerto Rico)
Diplomatic representation from the US:
chief of mission: Ambassador (vacant); Charge
d''Affairs Les ALEXANDER to be temporary chief of
mission until new ambassador is confirmed
embassy; 5 Harry Truman Boulevard, Port-au-Prince
mailing address: P. 0. Box 1761, Port-au-Prince
telephone: [509] 22-0354, 22-0368, 22-0200, 22-0612
FAX; [509] 23-1641
Flag description: two equal horizontal bands of blue
(top) and red with a centered white rectangle bearing
the coat of arms, which contains a palm tree flanked
by flags and two cannons above a scroll bearing the
motto L''UNION FAIT LA FORCE (Union Makes
Strength)
^
Economy - overview: About 80% of the population
lives in abject poverty. Nearly 70% of all Haitians
depend on the agriculture sector, which consists
mainly of small-scale subsistence farming and
employs about two-thirds of the economically active
work force. The country has experienced little job
creation since President PREVAL took office in
February 1996, although the informal economy is
growing. Failure to reach agreements with
international sponsors have denied Haiti badly
needed budget and development assistance. Meeting
aid conditions in 2000 will be especially challenging in
the face of mounting popular criticism of reforms.
GDP: purchasing power parity - $9.2 billion
(1999 est.)
GDP - real growth rate: 2.4% (1999 est.)
GDP - per capita: purchasing power parity - $1 ,340
(1999 est.)
GDP - composition by sector:
agriculture: 32%
industry: 20%
serv/ces; 48% (1998 est.)
Population below poverty line: 80% (1998 est.)
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 9% (1999 est.)
Labor force: 3.6 million (1995)
note: shortage of skilled labor, unskilled labor
abundant (1998)
Labor force - by occupation: agriculture 66%,
services 25%, industry 9%
Unemployment rate: 70%; widespread
underemployment; more than two-thirds of the labor
force do not have formal jobs (1999)
216
Haiti (continued)
Budget:
revenues: $323 million
expenditures: $363 million, including capital
expenditures of $NA (FY97/98 est.)
Industries: sugar refining, flour milling, textiles,
cement, tourism, light assembly industries based on
imported parts
Industrial production growth rate: 0.6%
(1997 est.)
Electricity - production: 728 million kWh (1998)
Electricity - production by source:
fossil fuel: 55.63%
hydro; 41 .62%
nuclear: 0%
other: 2.75% (1998)
Electricity - consumption: 677 million kWh (1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: coffee, mangoes,
sugarcane, rice, corn, sorghum; wood
Exports: $322 million (f.o.b., 1999)
Exports - commodities: manufactures, coffee, oils,
mangoes
Exports - partners: US 86%, EU 11% (1998)
Imports: $762 million (c.i.f., 1999)
Imports - commodities: food, machinery and
transport equipment, fuels
Imports - partners: US 60%, EU 12% (1998)
Debt - external: $1 billion (1997 est.)
Economic aid - recipient: $730.6 million (1995)
Currency: 1 gourde (G) = 100 centimes
Exchange rates: gourdes (G) per US$1 - 18.262
(January 2000), 1 7.965 (1 999), 1 6.505 (1998), 1 7.31 1
(1997), 15.093 (1996), 16.160 (1995)
Fiscal year: 1 October - 30 September
1^ Communication g~"™''
Telephones - main lines in use: 60,000 (1995)
Telephones - mobile cellular: 0 (1 995)
Telephone system: domestic facilities barely
adequate; international facilities slightly better
domestic: coaxial cable and microwave radio relay
trunk service
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations: AM 41 , FM 26,
shortwave 0 (1999)
Radios: 415,000(1997)
Television broadcast stations: 2 (plus a cable TV
service) (1997)
Televisions: 38,000(1997)
Internet Service Providers (ISPs): 6 (1 999)
p Transportation
Railways:
total: 40 km (single track; privately owned industrial
line) - closed in early 1990s
narrow gauge: 40 km 0.760-m gauge
Highways:
tofa/;4,160km
paved: 1 ,01 1 km
urrpaved; 3,149 km (1996 est.)
Waterways: NEGL; less than 100 km navigable
Ports and harbors: Cap-Haitien, Gonaives, Jacmel,
Jeremie, Les Cayes, Miragoane, Port-au-Prince,
Port-de-Paix, Saint-Marc
Merchant marine: none (1999 est.)
Airports: 13 (1999 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m:-[
1, 524 to 2,437 m:t
914 to 1,523 m; 1 (1 999 est.)
Airports - with unpaved runways;
total: to
914 to 1,523 m: 5
under 914 m: 5 {1999 est.)
Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force
have been demobilized but still exist on paper until
constitutionally abolished
Military manpower - military age; 18 years of age
Military manpower - availability:
males age 15-49: 1 ,579,897 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 857,666 (2000 est.)
Military manpower • reaching military age
annually:
males: 83,863 (2000 est.)
Military expenditures • dollar figure; $NA ; note -
mainly for police and security activities
Military expenditures - percent of GDP: NA%
Military - note: the Haitian Armed Forces have been
demobilized and replaced by the Haitian National
Police
I T r a fi s n a H 0 n a l I sli ule s^~^
Disputes - international: claims US-administered
Navassa Island
Illicit drugs; major Caribbean transshipment point
for cocaine en route to the US and Europe
Location; Southern Africa, islands in the Indian
Ocean, about two-thirds of the way from Madagascar
to Antarctica
Geographic coordinates; 53 06 S, 72 31 E
Map references: Antarctic Region
Area:
total; 41 2 sq km
/and; 41 2 sq km
wafer; 0 sq km
Area - comparative: slightly more than 2 times the
size of Washington, DC
Land boundaries; 0 km
Coastline; 101.9 km
Maritime claims;
exclusive fishing zone: 200 nm
territorial sea; 3 nm
Climate; antarctic
Terrain: Heard Island - bleak and mountainous, with
a quiescent volcano; McDonald Islands - small and
rocky
Elevation extremes:
lowest point: Southern Ocean 0 m
highest point: Big Ben 2,745 m
Natural resources; none
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land; 0sqkm(1993)
Natural hazards: Heard Island is dominated by a
dormant volcano called Big Ben
Environment - current issues: NA
Geography - note: primarily used for research
stations','7013d9c7e734c0325de3710b2a66cc3cc81f80a741d42b87ee91572e56ea5a57','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17f11aaca808b80ed0dec1d2ddbd63718a18ef993306e5fe218ecad97d1a953d',2000,'CN','China','transportation',235,'Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of China
I Transnational Issues
Disputes - internationai: none
illicit drugs: a hub for Southeast Asian heroin trade;
transshipment and money-laundering center;
increasing indigenous amphetamine abuse
S e ''o g rap h y
Location: Oceania, island in the North Pacific
Ocean, about one-half of the way from Hawaii to
Railways; 0 km
Highways:
fofa/;21,716 km
paved: 9,673.5 km
unpaved: 12,042.5 km (1998 est.)
Waterways; about 4,587 km, primarily Mekong and
tributaries; 2,897 additional km are sectionally
navigable by craft drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 2,370 GRT/
3,000 Dm
ships by type: cargo 1 (1 999 est.)
Airports: 52 (1999 est.)
Airports - with paved runways;
total: 9
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 4 {m9 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m:1
914 to 1,523 m:n
under 914 m: 25 {1 999 est.)
Railways:
total: 399 km (mostly unusable because of damage in
civil war)
standard gauge: 31 7 km 1 .435-m
narrow gauge: 82 km (1999)
Highways:
total: 7,300 km
paved: 6,200 km
unpaved; 1,100 km (1999 est.)
Pipelines: crude oil 72 km (none In operation)
Ports and harbors: Antilyas, Batroun, Beirut,
Chekka, El Mina, Ez Zahrani, Jbail, Jounie, Naqoura,
Sidon, Tripoli, Tyre
Merchant marine:
total: 68 ships (1 ,000 GRT or over) totaling 346,029
GRT/536,861 DWT
ships by type: bulk 8, cargo 44, chemical tanker 1 ,
combination bulk 1 , combination ore/oil 1 , container 4,
livestock carrier 4, roll-on/roll-off 2, vehicle carrier 3
(1999 est.)
Airports: 9 (1999 est.)
Airports - with paved runways:
total:?
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m:1
under 914 m:1 (1999 est.)
Airports ■ with unpaved runways:
total: 2
914 to 1,523 m:1
under 914 m; 1 (1 999 est.)
I Military
Military branches: Lebanese Armed Forces (LAF;
includes Army, Navy, and Air Force)
Military manpower - availability:
males age 15-49: 957,729 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 592,264 (2000 est.)
Military expenditures - dollar figure: $500 million
(FY98)
Military expenditures - percent of GDP: 4%
(FY98)
t: transnational Issues
Disputes - international: Israeli troops in southern
Lebanon since June 1982; Syrian troops in northern,
central, and eastern Lebanon since October 1976
Illicit drugs: inconsequential producer of hashish;
some heroin processing mostly in the Bekaa valley; a
Lebanese/Syrian eradication campaign started in the
early 1990s has practically eliminated the opium and
cannabis crops
283
Background; Basutoland was renamed the
Kingdom of Lesotho upon independence from the UK
in 1966. Constitutional government was restored In
1993 after 23 years of military rule.
r '' G e 0 g”r a p h y
Location: Southern Africa, an enclave of South
Africa
Geographic coordinates; 29 30 S, 28 30 E
Map references; Africa
Area;
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries;
total: 909 km
border countries: South Africa 909 km
Coastline; 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot,
wet summers
Terrain: mostly highland with plateaus, hills, and
mountains
Elevation extremes;
/owesfpo/rrf; junction of the Orange and Makhaleng
Rivers 1 ,400 m
highest point: Thaba’na Ntlenyana 3,482 m
Natural resources; water, agricultural and grazing
land, some diamonds and other minerals
Land use;
arable land: 11%
permanent crops: 0%
permanent pastures: 66%
forests and woodland: 0%
other: 23% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards; periodic droughts
Environment - current issues: population pressure
forcing settlement in marginal areas results in
overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls,
stores, and redirects water to South Africa
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Marine Life Conservation, Ozone
Layer Protection
signed, but not ratified: Endangered Species, Law of
the Sea, Marine Dumping
Geography - note: landlocked; surrounded by','52795e77e0346fe9cb72792116bf949bfb4bdfe30ab4043bcd1a2852fe0bb3b6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e24ab1609e52b22a1b90ab9b5de8a121c50915255062b75b28a0cdae989a5bcb',2000,'IS','Iceland','transportation',236,'0 50 100 km
6 50
100 mi
Greenland Sea
Grimsey^
r-^Raufarhofn
\\ r\\-rY
’ Husavfk )
^ ^ Akureyri*
^ f
Seydhlsfjordhur*^
■jr
% StraumS
^REYKJAVIK
>^6fn
Hornafjordur
Keflavfl^Q
.ak^jordhur
Vestmannaeyjari-^--X[J^_>^
Surtsey
North Atlantic Ocean
I Introduction
Background: Settled by Norwegians and Celtic
(Scottish and Irish) immigrants during the late 9th and
10th centuries, Iceland boasts the world''s oldest
parliament, the Althing, established in 930.
Independent for over 300 years, Iceland was
subsequently ruled by Norway and Denmark. Limited
home rule was granted in 1874 and complete
independence attained in 1944. Literacy, longevity,
income, and social cohesion are first-rate by world
standards.
f . G e o''g''r''a p h y''"
Location: Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean,
northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area;
fofa/; 1 03,000 sq km
land: 100,250 sq km
wafer; 2,750 sq km
Area - comparative: slightly smaller than Kentucky
Land boundaries; 0 km
Coastline; 4,988 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: temperate; moderated by North Atlantic
Current; mild, windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain
peaks, icefields; coast deeply indented by bays and
fiords
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,1 1 9 m
Natural resources: fish, hydropower, geothermal
power, diatomite
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 1 %
other: 76% (1993 est.)
Irrigated land: NAsqkm
Natural hazards; earthquakes and volcanic activity
Environment - current issues; water pollution from
fertilizer runoff; inadequate wastewater treatment
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: k\\r Pollution-Persistent
Organic Pollutants, Environmental Modification,
Marine Life Conservation
Geography - note: strategic location between
Greenland and Europe; westernmost European
country; more land covered by glaciers than in all of
continental Europe
I People
Population: 276,365 (July 2000 est.)
Age structure:
0-14 years: 28% (male 33,1 1 9; female 31 ,222)
15-64 years: 65% (male 90,599; female 88,982)
65 years and over: 1 2% (male 1 4,555; female
17,888) (2000 est.)
Population growth rate: 0.57% (2000 est.)
Birth rate: 14.86 births/1 ,000 population (2000 est.)
Death rate: 6.87 deaths/1 ,000 population (2000 est.)
Net migration rate: -2.3 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1.06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 3.58 deaths/1,000 live births
(2000 est.)
Life expectancy at birth;
total population: 79.39 years
ma/e; 77.19 years
female: 81 .77 years (2000 est.)
Total fertility rate: 2.03 children born/woman
(2000 est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups; homogeneous mixture of
descendants of Norwegians and Celts
Religions: Evangelical Lutheran 91%, other
Protestant and Roman Catholic, none (1997)
Languages; Icelandic
Literacy:
definition: age 15 and over can read and write
total population: 99.9% (1 997 est.)
male: NA%
female: NA%
227
ICGland (continued)
I Government
Country name;
conventional long form: Republic of Iceland
conventional short form: Iceland
local long form: Lyoveldio Island
/oca/ short form; Island
Data code: 1C
Government type: constitutional republic
Capital: Reykjavik
Administrative divisions: 23 counties (syslar,
singular - sysla) and 14 independent towns*
(kaupstadhir, singular - kaupstadhur); Akranes*,
Akureyri*, Arnessysla, Austur-Bardhastrandarsysla,
Austur-Hunavatnssysla, Austur-Skaftafellssysla,
Borgarfjardharsysla, Dalasysla, Eyjafjardharsysla,
Gullbringusysla, Hafnarfjordhur*, Husavik*,
Isafjordhur*, Keflavik*, Kjosarsysla, Kopavogur*,
Myrasysla, Neskaupstadhur*,
Nordhur-lsafjardharsysla, Nordhur-Mulasys-la,
Nordhur-Thingeyjarsysla, Olafsfjordhur*,
Rangarvallasysla, Reykjavik*, Saudharkrokur*,
Seydhisfjordhur*, Siglufjordhur*, Skagafjardharsysla,
Snaefellsnes-og Hnappadalssysla, Strandasysla,
Sudhur-Mulasysla, Sudhur-Thingeyjarsysla,
Vesttmannaeyjar*, Vestur-Bardhastrandarsysla,
Vestur-Hunavatnssysla, Vestur-lsafjardharsysla,
Vestur-Skaftafellssysla
Independence: 17 June 1944 (from Denmark)
National holiday: Anniversary of the Establishment
of the Republic, 17 June (1944)
Constitution: 1 6 June 1 944, effective 1 7 June 1 944
Legal system: civil law system based on Danish
law; does not accept compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Olafur Ragnar GRIMSSON
(since 1 August 1996)
head of government: Prime Minister David
ODDSSON (since 30 April 1991)
cabinet: Cabinet appointed by the president
elections: president elected by popular vote for a
four-year term; election last held 29 June 1996 (next
to be held NA June 2000); prime minister appointed by
the president
election results: Olafur Ragnar GRIMSSON elected
president; percent of vote - 41 .4%
Legislative branch: unicameral Parliament or
Althing (63 seats; members are elected by popular
vote to serve four-year terms)
elections: last held on 8 May 1 999 (next to be held by
April 2003)
election results: percent of vote by party - NA; seats
by party - NA
Judicial branch: Supreme Court or Haestirettur,
justices are appointed for life by the president
Political parties and leaders: Independence Party
(conservative) or IP [David ODDSSON]; National
Awakening (People''s Revival Party) or PR [Johanna
SIGURDARDOTTIRj; People''s Alliance (left socialist)
or PA [Margret FRIMANNSDOHIRj; People''s
Movement (centrist) [leader NA]; Progressive Party
(liberal) or PP [Halldor ASGRIMSSON]; Social
Democratic Party or SDP [Sighvatur
BJORGVINSSON]; Women''s Party or WL [Kristin
ASTGEIRSDOTTIR]
International organization participation; Australia
Group, BIS, CBSS, CCC, CE, EAPC, EBRD, ECE,
EFTA, FAO, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM,
IDA, lEA (observer), IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, ISO, ITU, NATO, NC,
NEA, NIB, OECD, OPCW, OSCE, PCA, UN,
UNCTAD, UNESCO, UNMIBH, UNMIK, UNU, UPU,
WEU (associate), WHO, WlPO, WMO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Jon-Baldvin
HANNIBALSSON
chancery: Suite 1200, 1156 15th Street NW,
Washington, DC 20005
/e/ep/ione;[1] (202) 265-6653
FAX: [1] (202) 265-6656
consulate(s) general: New York
Diplomatic representation from the US;
chief of mission: Ambassador Barbara GRIFFITHS
embassy: Laufasvegur21, Reykjavik
mailing address: US Embassy, PSC 1 003, Box 40,
FPO AE 09728-0340
/e/ep/7one;[354] 5629100
FAX- [354] 5629118
Flag description: blue with a red cross outlined in
white that extends to the edges of the flag; the vertical
part of the cross is shifted to the hoist side in the style
of the Dannebrog (Danish flag)
f . . ''
Economy - overview: Iceland''s Scandinavian-type
economy is basically capitalistic, yet with an extensive
welfare system, low unemployment, and remarkably
even distribution of income. The economy depends
heavily on the fishing industry, which provides 70% of
export earnings and employs 12% of the work force. In
the absence of other natural resources (except for
abundant hydrothermal and geothermal power),
Iceland''s economy is vulnerable to changing world fish
prices. The economy remains sensitive to declining fish
stocks as well as to drops in world prices for its main
exports: fish and fish products, aluminum, and
ferrosilicon. The center-right government plans to
continue its policies of reducing the budget and current
account deficits, limiting foreign borrowing, containing
inflation, revising agricultural and fishing policies,
diversifying the economy, and privatizing state-owned
industries. The government remains opposed to EU
membership, primarily because of Icelanders'' concern
about losing control over their fishing resources.
Iceland''s economy has been diversifying into
manufacturing and service industries in the last
decade, and new developments in software production,
biotechnology, and financial services are taking place.
The tourism sector is also expanding, with the recent
trends in ecotourism and whale-watching. Growth is
likely to slow in 2000, to a still respectable 3.5%.
GDP: purchasing power parity - $6.42 billion
(1999 est.)
GDP - real growth rate: 4.5% (1999 est.)
GDP - per capita: purchasing power parity -
$23,500 (1999 est.)
GDP - composition by sector:
agriculture: 15% (includes fishing 13%)
industry: 2t%
services: 64% (1998 est.)
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 .9% (1 999 est.)
Labor force: 131,000(1999)
Labor force - by occupation: manufacturing
12.9%, fishing and fish processing 1 1 .8%,
construction 1 0.7%, other services 59.5%, agriculture
5.1% (1999)
Unemployment rate: 2.4% (1999 est.)
Budget:
revenues: $NA
expenditures: $3 billion, including capital
expenditures of $146 million (1999 est.)
Industries: fish processing; aluminum smelting,
ferrosilicon production, geothermal power; tourism
Industrial production growth rate: NA%
Electricity - production: 6.187 billion kWh (1998)
Electricity - production by source;
fossil fuel: 0.06%
hydro: 89.BB%
nuclear: 0%
ofoer; 10.06% (1998)
Electricity - consumption: 5.754 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity ■ imports: 0 kWh (1998)
Agriculture - products: potatoes, turnips; cattle,
sheep; fish
Exports: $1.9 billion (f.o.b., 1998)
Exports - commodities: fish and fish products 70%,
animal products, aluminum, diatomite and ferrosilicon
Exports - partners: EU 65% (UK 19%, Germany
15%, France 7%, Denmark 6%), US 13%, Japan 5%
(1998)
Imports: $2.4 billion (f.o.b., 1998)
Imports - commodities: machinery and equipment,
petroleum products; foodstuffs, textiles
Imports - partners: EU 56% (Germany 12%, UK
10%, Norway 9%, Denmark 8%, Sweden 6%), US
11% (1998)
Debt - external: $2.6 billion (1999)
Economic aid - recipient: $NA
Currency: 1 Icelandic krona (IKr) = 100 aurar
Exchange rates: Icelandic kronur (IKr) per US$1 -
72.334 (January 2000), 72.352 (1 999), 70.958 (1 998),
70.904 (1997), 66.500 (1996), 64.692 (1995)
Fiscal year: calendar year
Ports and harbors: none; offshore anchorage only
Airports: 1 (1 999 est.)
Airports - with unpaved runways;
total: 1
914 to 1,523 m:t (1999 est.)
I M i I i t aVy
Military - note: defense is the responsibility of','9c2bc12cdf51eb52267683232633b373e0c425181b090a100f8cab4d15d55353','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9066eb35e0ce788999a6e9a55945ed62e20abd2cb2ef3b6ec06d72f0bfc033d0',2000,'IQ','Iraq','transportation',247,'Railways:
total: 1 ,947 km
broad gauge: 1 ,947 km 1 .600-m gauge (38 km
electrified; 485 km double track) (1998)
Highways:
total: 92,500 km
paved: 87,043 km (including 1 15 km of expressways)
unpaved: 5,457 km (1999 est.)
Waterways: 700 km (limited for commercial traffic)
(1998)
Pipelines: natural gas 225 km (1998)
Ports and harbors: Arklow, Cork, Drogheda,
Dublin, Foynes, Galway, Limerick, New Ross,
Waterford
Merchant marine:
fofa/;31 ships (1,000 GRT or over) totaling 100,639
GRT/1 15,793 DWT
ships by type: bulk 1 , cargo 27, container 2, short-sea
passenger 1 (1999 est.)
Airports: 44 (1999 est.)
Airports - with paved runways:
fofa/;17
over 3,047 m: 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 7 {1999 est.)
Airports - with unpaved runways:
total: 27
914 to 1,523 m: 2
under 914 m: 25 (1 999 est.)','518893562e966571ff7945fedc3cadd3c5b2a39286c3e22923baa77d20aac59a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f75e24bed4b86479d0e0b54c15015ea14cf3399091c4b4dbcb0d492345a04f6',2000,'TN','Tunisia','transportation',257,'Railways:
total: 370 km
standard gauge: 370 km 1 ,435-m gauge; note - 207
km belong to the Jamaica Railway Corporation in
common carrier service, but are no longer operational;
the remaining track is privately owned and used to
transport bauxite
Highways:
total: 18,700 km
paved: 13,100 km
unpaved: 5,600 km (1997 est.)
Pipelines: petroleum products 10 km
Ports and harbors: Alligator Pond, Discovery Bay,
Kingston, Montego Bay, Ocho Rios, Port Antonio,
Rocky Point, Port Esquivel (Longswharf)
Merchant marine:
total: 1 ship (1 ,000 GRT or over) totaling 1 ,930 GRT/
3,065 DWT
ships by type: petroleum tanker 1 (1 999 est.)
Airports: 36 (1999 est.)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 2
1,524 to 2,437 m:t
914 to 1,523 m: 3
under 914 m: 5(1 999 est.)
Airports - with unpaved runways:
total: 25','b81f06c491bf0efd0eb27f0569bbbc8b70112862e31c56ad903cadeb05707231','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c2fe49d2f91e13c184ed4cd0e51ff07f28ac9564cceb029acf007e492f71660',2000,'NO','Norway','transportation',259,'f T r a n s n aTi o n a I issues
Disputes ■ international: none
Background; While retaining its time-honored
culture, Japan rapidly absorbed Western technology
during the late 19th and early 20th centuries. After its
devastating defeat in World War II, Japan recovered
to become the second most powerful economy in the
world and a staunch ally of the US. While the emperor
retains his throne as a symbol of national unity, actual
power rests in networks of powerful politicians,
bureaucrats, and business executives. The economy
experienced a major slowdown in the 1 990s following
three decades of unprecedented growth,
I”'' G''eo^''ra''p''hT
Location: Eastern Asia, island chain between the
North Pacific Ocean and the Sea of Japan, east of the
Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references; Asia
Area;
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto),
Daito-shoto, Minami-jima, Okino-tori-shima, Ryukyu
Islands (Nansei-shofo), and Volcano Islands
(Kazan-retto)
Area - comparative: slightly smaller than California
Land boundaries; 0 km
Coastline; 29,751 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 1 2 nm; between 3 nm and 1 2 nm in the
international straits - La Perouse or Soya, Tsugaru,
Osumi, and Eastern and Western Channels of the
Korea or T sushima Strait
Climate: varies from tropical in south to cool
temperate in north
Terrain; mostly rugged and mountainous
Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources,
fish
Land use:
arable land: 11%
permanent crops: 1%
permanent pastures: 2%
forests and woodland: 67%
other: 19% {im est.)
Irrigated land: 27,820 sq km (1993 est.)
Natural hazards: many dormant and some active
volcanoes; about 1 ,500 seismic occurrences (mostly
tremors) every year; tsunamis
Environment - current issues; air pollution from
power plant emissions results in acid rain; acidification
of lakes and resen/oirs degrading water quality and
threatening aquatic life; Japan is one of the largest
consumers of fish and tropical timber, contributing to
the depletion of these resources in Asia and
elsewhere
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography ■ note: strategic location in northeast
Asia
I''''""" People
Population: 126,549,976 (July 2000 est.)
Age structure:
0-14 years: 15% (male 9,575,637; female 9,105,713)
15-64 years: 68% (male 43,363,054; female
42,980,253)
65 years and over: 17% (male 9,024,015; female
12,501,304) (2000 est.)
Population growth rate: 0.18% (2000 est.)
Birth rate: 9.96 births/1 ,000 population (2000 est.)
Death rate: 8.15 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 3.91 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 80.7 years
male: 77.51 years
female: 84.05 years (2000 est.)
251
Japan (continued)
Total fertility rate; 1 .41 children born/woman
(2000 est.)
Nationaiity:
noun: Japanese (singular and plural)
ad/ecf/Ve; Japanese
Ethnic groups: Japanese 99.4%, other 0.6%
(mostly Korean)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy;
definition: age 1 5 and over can read and write
total population: 99% (1970 est.)
male: NA%
female: NA%','c820470ab9810a2065e7e124e78ee6d5df0a257183274b025abfcb19c77ec3be','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9fa3228ec3da7fe6621a2f571ca026af8e331ea604c97e7116c9a33ab5a7856',2000,'JO','Jordan','transportation',263,'Railways;
total: 677 km
narrow gauge: 677 km 1 .050-m gauge (2000)
Highways:
total: 8,000 km
paved: 8,000 km
unpaved: 0 km (2000 est.)
Pipelines: crude oil 209 km; note - may not be in use
Ports and harbors: Al ''Aqabah
Merchant marine;
total: 7 ships (1 ,000 GRT or over) totaling 42,746
GRT/59,100 DWT
258
Jordan (continued)
ships by type: bulk 2, cargo 2, container 1 , livestock
carrier 1, roll-on/roll-off 1 (1999 est.)
Airports: 20 (1999 est.)
Airports - with paved runways:
total:
over 3,047 m:Q
2,438 to 3,047 m: 4
under 914 m; 3 (1999 est.)
Airports - with unpaved runways:
total: 4
1,524 to 2,437 m:1
914 to 1,523 m:1
under 914 m: 2 (1999 est.)
Heiiports: 1 (1 999 est.)
I M rriT aTy
Military branches: Jordanian Armed Forces (JAF;
includes Royal Jordanian Land Force, Royal Naval
Force, and Royal Jordanian Air Force): Badiya
(irregular) Border Guards; Ministry of the Interior''s
Public Security Force (falls under JAF only in wartime
or crisis situations)
Miiitary manpower - miiitary age: 1 8 years of age
Miiifary manpower - availability:
males age 15-49: 1 ,399,138 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 993,730 (2000 est.)
Military manpower • reaching military age
annually:
mates; 55,742 (2000 est.)
Military expenditures - dollar figure: $608.9
million (FY98)
Military expenditures - percent of GDP: 7.8%
(FY98)
I transnational Issues
Disputes - international: none
I '' Geography
Location: Southern Africa, island in the Mozambique
Channel, about one-third of the way between
Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total: 4.4 sq km
tend; 4.4 sqkm
water: Osq km
Area • comparative: about seven times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to depth the of
exploitation
exclusive economic zone: 200 nm
tem''torte/ sea; 12 nm
Climate; tropical
Terrain: low and flat
Elevation extremes;
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other
fertilizers
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other: 10%
Irrigated land; 0 sq km (1993)
Natural hazards; periodic cyclones
Environment - current issues: NA
Geography - note: wildlife sanctuary
I P e 0 p fe
Population: no indigenous population
note: there is a small military garrison (July 2000 est.)','8e989ab51a6ca55f370a7eb1bb2f6ab94caa2861ac1c3bb71a1f7fc4470366ac','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('630946856f32bc84b548377dc3236add1a6d53b5f5cb0ec213d6508494f696ad',2000,'KZ','Kazakhstan','transportation',266,'Railways:
total: 14,400 km in common carrier service; does not
include industrial lines
broad gauge: 14,400 km 1.520-m gauge (3,299 km
electrified) (1997)
Highways:
tofa/;119,390km
paved: 103,272 km
unpaved: 16,118 km (1998 est.)
Waterways: 3,900 km on the Syrdariya (Syr Darya)
and Ertis (Irtysh)
Pipelines: crude oil 2,850 km; refined products
1 ,500 km; natural gas 3,480 km (1 992)
Ports and harbors: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Pavlodar,
Semey (Semipalatinsk)
Airports: 10 (1997 est.)
Airports - with paved runways:
total: 9
over 3,047 m: A
2,438 to 3,047 m: 3
1,524 to 2,437m: 2 {^997 est.)
Airports - with unpaved runways:
total: 1
9f4 to 1,523 m; 1 (1997 est.)
t Military
Military branches: General Purpose Forces (Army),
Air Force, Border Guards, Navy, Republican Guard
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 4,477,455 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 3,572,688 (2000 est.)
Military manpower - reaching military age
annually:
males: 158,838 (2000 est.)
Military expenditures - dollar figure: $322 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
i T r an snaticinal Issues
Disputes - international: Caspian Sea boundaries
are not yet determined among Azerbaijan, Iran,
Kazakhstan, Russia, and Turkmenistan; Russia
leases approximately 6,000 sq km of territory
enclosing the Baykonur Cosmodrome
Illicit drugs: significant illicit cultivation of cannabis
and limited cultivation of opium poppy and ephedra
(for the drug ephedrone); limited government
eradication program; cannabis consumed largely in
the CIS; used as transshipment point for illicit drugs to
Russia, North America, and Western Europe from
Southwest Asia','7dd530a2909d02c245890894277ac385799e905f47944adbd61f8efb23ce9bd4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08956c43ac8aa55fb99e2fb305702f6970fcc1fb6be4480993c0eb4cbd9494ed',2000,'JP','Japan','transportation',279,'Railways: Okm
Highways;
total: 4,450 km
paved: 3,590 km
unpaved: 860 km (1999 est.)
Pipelines; crude oil 877 km; petroleum products 40
km; natural gas 165 km
Ports and harbors: Ash Shu''aybah, Ash Shuwaykh,
Kuwait, Mina'' ''Abd Allah, Mina'' al Ahmadi, Mina'' Su''ud
Merchant marine:
total: 48 ships (1 ,000 GRT or over) totaling 2,506,448
GRT/4,040,921 DWT
ships by type: bulk 1 , cargo 9, container 6, liquified
gas 7, livestock carrier 4, petroleum tanker 21
(1999 est.)
Airports: 7 (1999 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047m: 2 est.)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m:t
914 to 1,523 m:1
under 914 m:1 (1999 est.)
Heliports: 2 (1999 est.)','832a38a41213a6dd1e51e9b73bec43b6833e04848dc3e185eff7b19180299cb0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('065745a25c0bb68f23956f96fca4c107b10afad002b312ccecf807b2327d2746',2000,'ZA','South Africa','transportation',288,'I People
Population: 2,143,141
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 40% (male 426,556; female 421 ,563)
15-64 years: 56% (male 575,580; female 61 9,280)
65 years and over: 4% (male 42,274; female 57,888)
(2000 est.)
Population growth rate: 1.65% (2000 est.)
Birth rate: 31.74 birlhs/1,000 population (2000 est.)
Death rate: 14.59 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.64 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 82.97 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 50.79 years
male: 49.78 years
female: 51 .84 years (2000 est.)
Total fertility rate: 4.15 children born/woman
(2000 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans, Asians,
and other 0.3%,
Religions; Christian 80%, indigenous beliefs 20%
Languages; Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy;
definition: age 15 and over can read and write
total population: 71 .3%
male: 81.1%
female: 62.3% (1995 est.)
Railways;
tofa/;21,431 km
narrow gauge: 20,995 km 1 .067-m gauge (9,087 km
electrified); 436 km 0.61 0-m gauge (1995)
Highways:
tofa/; 534,131 km
paved: 63,027 km (including 2,032 km of
expressways)
unpaved: 471 ,1 04 km (1 998 est.)
Pipelines: crude oil 931 km; petroleum products
1 ,748 km; natural gas 322 km
Ports and harbors: Cape Town, Durban, East
London, Mosselbaai, Port Elizabeth, Richards Bay,
Saldanha
Merchant marine:
total: 9 ships (1 ,000 GRT or over) totaling 274,797
GRT/270,837 DWT
ships by type: container 6, petroleum tanker 2, roll-on/
roll-off 1 (1999 est.)
Airports: 744 (1999 est.)
Airports - with paved runways:
fofa/;143
over 3,047 m: 9
2,438 to 3,047 m: 4
1,524 to 2,437 m: 40
914 to 1,523 m: 73
under 914 m:M (1999 est.)
Airports - with unpaved runways:
total: 601
1,524 to 2,437 m: 33
914 to 1,523 m: 303
under 914 m;265 (1999 est.)
South Africa (continued)
I Military
Military branches: South African National Defense
Force or SANDF (includes Army, Navy, Air Force, and
Medical Services), South African Police Service or
SAPS
Military manpower - military age: 1 8 years of age
Military manpower - availability:
mates age 15-49: 1 1 ,345,031 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 6,901 ,252 (2000 est.)
Military manpower - reaching military age
annually:
mates; 460,91 7 (2000 est.)
Military expenditures - dollar figure: $2 billion
(FY99/00)
Military expenditures - percent of GDP: 1 .5%
(FY99/00)
Military - note: the National Defense Force
continues to integrate former military, black
homelands forces, and ex-opposition forces
I fra n s n a t i 0 n a i issues
Disputes - international: Swaziland has asked
South Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long ago part
of the Swazi Kingdom
Illicit drugs: transshipment center for heroin and
cocaine; cocaine consumption on the rise; world''s
largest market for illicit methaqualone, usually
imported illegally from India through various east
African countries; illicit cultivation of marijuana
I South Georgia
|and the South
ISandwich islands
^(overseas territory of the UK,
iaiso claimed by Argentina)
Shag Rocks
are not shown.
0 100 200 km
0 100 200 ml
South Georgia
Bird oV. \\
Island
South
Atlantic Ocean
Clerke^
Rocks
Traversay o
Islands \\
South
Scotia Sea
Sandwich Saunders 1°
Montagu 1.0
Bristol 1.^
Administered by O.K.,
claimed by ARGENTINA.
Southern''
Thule
Location: Southern South America, islands in the
South Atlantic Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total: 4,065 sq km
land: 4,066 sqkm
water: 0 sq km
note: includes Shag Rocks, Gierke Rocks, Bird Island
Area - comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: NAkm
Maritime claims:
exclusive fishing zone: 200 nm
fem''forte/ sea; 1 2 nm
Climate: variable, with mostly westerly winds
throughout the year interspersed with periods of calm;
nearly all precipitation falls as snow
Terrain: most of the islands, rising steeply from the
sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered
mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget (South Georgia) 2,915 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (largely covered by permanent ice and
snow with some sparse vegetation consisting of
grass, moss, and lichen)
Irrigated land: 0 sq km (1993)
Natural hazards: the South Sandwich Islands have
prevailing weather conditions that generally make
them difficult to approach by ship; they are also
subject to active volcanism
Environment - current issues: NA
Geography - note: the north coast of South Georgia
has several large bays, which provide good
anchorage; reindeer, introduced early in this century,
live on South Georgia
Ports and harbors: Grytviken
Airports: none
M i i i t a r y
Miiitary - note: defense is the responsibility of the
UK','05b21b2eacd8b65f6a1283896a9577db60a9e1607c6e1ee4ad497653d2e66887','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83726dc6f3f64f9ac07a3cd4e4172a11988789162ed93227aa11b03acd7eb21b',2000,'EG','Egypt','transportation',294,'Railways:
note: Libya has had no railroad in operation since
1965, all previous systems having been dismantled;
current plans are to construct a 1 .435-m standard
gauge line from the Tunisian frontier to Tripoii and
Misratah, then iniand to Sabha, center of a
mineral-rich area, but there has been littie progress;
other pians made jointiy with Egypt wouid establish a
raii iine from As Sailum, Egypt, to Tobruk with
completion originaiiy set for mid-1994; Libya signed
contracts with Bahne of Egypt and Jez Sistemas
Ferroviarios in 1 998 for the supply of crossings and
pointwork
Highways:
total: 83,200 km
paved: 47,590 km
urtpaved; 35,610 km (1996 est.)
Waterways: none
Pipelines: crude oil 4,383 km; petroleum products
443 km (includes liquefied petroleum gas or LPG 256
km); natural gas 1 ,947 km
Ports and harbors: Al Khums, Banghazi, Darnah,
Marsa al Burayqah, Misratah, Ra''s Lanuf, Tobruk,
Tripoli, Zuwarah
Merchant marine:
total: 27 ships (1 ,000 GRT or over) totaling 401 ,303
GRT/656,632 DWT
ships by type: cargo 9, chemical tanker 1 , liquified gas
3, petroieum tanker 6, roli-on/roli-off 4, short-sea
passenger 4 (1999 est.)
Airports: 142 (1999 est.)
Airports - with paved runways:
total: 59
over 3,047 m: 24
2,438 to 3,047 m:0
1,524 to 2, 437 m: 22
914 to 1,523 m: 5
under 91 4 m:2
Airports - with unpaved runways:
total: 83
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 15
914 to 1,523 m: 42
under 914 m: 1 9 (1 999 est.)
L Military
Military branches: Army, Navy, Air and Air Defense
Command
Military manpower - military age: 17 years of age
Military manpower - availability:
mates age 15-49; 1,415,305 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 841 ,039 (2000 est.)
Military manpower - reaching military age
annually:
males: 62,200 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','c350f840f76a6b3af60d4daad079568c1ce93e9992bd8c8c59b6aaef745bde85','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c900701c6acaabb7997d6d8724d2f411168bbfd237a5d3496c45df194dea3810',2000,'CH','Switzerland','transportation',300,'Railways:
total: 2,002 km
broad gauge: 2, 1X2 km 1.524-m gauge (122 km
electrified) (1994)
Highways:
total: 71 ,375 km
paved: 64,951 km (including 417 km of expressways)
unpaved: 6,424 km (1998 est.)
Waterways: 600 km perennially navigable
Pipelines: crude oil, 105 km; natural gas 760 km
(1992)
Ports and harbors: Kaunas, Klaipeda
Merchant marine:
total: 52 ships (1 ,000 GRT or over) totaling 31 6,31 9
GRT/351,700 DWT
ships by type: cargo 23, combination bulk 1 1 ,
petroleum tanker 2, rail car carrier 1 , refrigerated
cargo 11, roll-on/roll-off 1, short-sea passenger 3
(1999 est.)
Airports: 96 (1994 est.)
Airports - with paved runways:
total: 25
over 3,047 m: 3
2,438 to 3,047m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 14 (1994 est.)
Airports - with unpaved runways:
total: 71
2,438 to 3,047 m:1
1,524''to 2,437 m:1
914 to 1,523 m: 8
under 914 m: 63 (1 994 est.)','f11c4e353fd5bd1d532db485d244a1e97665a194117f805904c451a832b04739','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('978d9da93bc56a5b8398a52a776e31d72d8bcbb6a225207b85751e6372ec1387',2000,'MV','Maldives','transportation',319,'Railways:
total: 729 km (linked to Senegal''s rail system through
Kayes)
narrow gauge: 729 km 1.000-m gauge
Highways:
total: 16,100 km
paved: 1 ,827 km
unpaved: 13,273 km (1996 est.)
Waterways: 1 ,81 5 km navigable
Ports and harbors: Koulikoro
Airports: 28 (1999 est.)
Airports - with paved runways:
total: 6
2,438 to 3,047 m:^
914 to 1,523 m; 2 (1999 est.)
Airports - with unpaved runways:
total: 22
2,438 to 3,047 m:1
1,524 to 2,437 m: 3
914 to 1,523 m: 8
under 914 m: 10 (1999 est.)
Railways: 0 km
Highways:
fofa/; 1,742 km
paved: 1 ,677 km
unpaved: 65 km (1997 est.)
Ports and harbors: Marsaxiokk, Valletta
Merchant marine:
total: 1 ,484 ships (1 ,000 GRT or over) totaling
28,083,952 GRT/46,772,146 DWT
ships by type: bulk 431, cargo 424, chemical tanker
54, combination bulk 16, combination ore/oil 14,
container 64, liquified gas 2, livestock carrier 3,
multi-functional large load carrier 4, passenger 7,
petroleum tanker 331 , refrigerated cargo 44, roll-on/
roll-off 48, short-sea passenger 21 , specialized tanker
5, vehicle carrier 16 (1999 est.)
note: a flag of convenience registry; includes ships
from 49 countries among which includes Greece 445,
Russia 51 , Switzerland 45, Italy 44, Norway 40,
Croatia 26, Turkey 35, Germany 32, Georgia 23, and
Monaco 24 (1998 est.)
Airports: 1 (1 999 est.)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (1 999 est.)
Railways:
total: 68.5 km (43.5 km electrified)
Highways:
total: 800 km
paved: 800 km
unpaved: 0 km (1999)
Ports and harbors: Castletown, Douglas, Peel,
Ramsey
Merchant marine:
total: 144 ships (1 ,000 GRT or over) totaling
4,333,826 GRT/7,254,867 DWT
ships by type: bulk 23, cargo 6, chemical tanker 1 3,
combination bulk 3, container 20, liquified gas 13,
petroleum tanker 44, refrigerated cargo 2, roll-on/
roll-off 15, vehicle carrier 5 (1999 est.)
note: a flag of convenience registry; UK owns 8 ships,
Denmark 1 , Sweden 1 , Belgium 1 , and Netherlands 1
(1998 est.)
Airports: 1 (1 999 est.)
Airports - with paved runways;
total: 1
1,524 to 2,437 m:t (1999 est.)','903c1458e8348b8e2d366ecded29a4ec8faee372d5cc4adfe29d31a7aac384ca','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44663797d679912de1ba1d68552703a6f6ed65d6dd238a02d6d1fd1dec7db7cd',2000,'MH','Marshall Islands','transportation',324,'Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks
Ports and harbors: Majuro
Merchant marine:
total: 143 ships (1 ,000 GRT or over) totaling
6,801,336 GRT/1 1, 785,065 DWT
ships by type: bulk 48, cargo 8, chemical tanker 5,
combination bulk 1, container 19, liquified gas 2,
multi-functional large load carrier 1 , petroleum tanker
58, vehicle carrier 1 (1999 est.)
note: a flag of convenience registry; includes the ships
of Canada 1 , China 1 , Germany 1 , Japan 1 , and US 7
(1998 est.)
Airports: 16 (1999 est.)
Airports - with paved runways:
total: 4
1,524 to 2, 437 m: 3
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
total: 12
914 to 1.523 m: 7
under 914 m; 5 (1999 est.)','3a0c1133ba2fd331d0554b0804339277ec85c5e7b798e7f3724b38a79449b6a6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a2295ad8f1e7009a4e80913d981fb6cdf23b8213dc859aa030a617d8f9b48f8',2000,'MR','Mauritania','transportation',330,'Raiiways:
total: 704 km (singie track); note - owned and
operated by government mining company
standard gauge: 704 km 1.435-m gauge (1995)
Highways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1996 est.)
Waterways: mostiy ferry traffic on the Senegai River
Ports and harbors: Bogue, Kaedi, Nouadhibou,
Nouakchott, Rosso
Merchant marine: none (1999 est.)
Airports: 26 (1999 est.)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
tofa/;18
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 9
under 914 m; 2 (1999 est.)
Railways: 0 km
Highways:
tofa/; 1,910 km
paved: 1 ,834 km (including 36 km of expressways)
unpaved: 76 km (1998 est.)
Ports and harbors: Port Louis
Merchant marine:
total: 12 ships (1 ,000 GRT or over) totaiing 126,358
GRT/1 73,079 DWT
ships by type: cargo 3, combination buik 2, container
4, liquified gas 1, refrigerated cargo 2 (1999 est.)
note: a fiag of convenience registry; India owns 1 ship
(1998 est.)
Airports: 5 (1999 est.)
Airports - with paved runways:
total: 2
over 3,047 m:t
914 to 1,523 m:t (1999 est.)
Airports - with unpaved runways:
total: 3
914 to 1,523 m:1
under 914 m; 2 (1999 est.)
I Military
Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF, Special
Support Units or SSU, and National Coast Guard)
Military manpower - availability:
males age 15-49: 338,856 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 171,183 (2000 est.)
Military expenditures - dollar figure: $11 million
(FY97/98)
Military expenditures ■ percent of GDP: 0.3%
(FY97/98)
Railways:
total: 4,095 km
standard gauge: 4,095 km 1 .435-m gauge (1 ,377 km
partially electrified since 1992)
note: during to the 1999 Kosovo conflict, the Serbian
rail system suffered significant damage due to bridge
destruction; many rail bridges have been rebuilt, but
the bridge over the Danube at Novi Sad was still down
in early 2000; however, a by-pass is available;
Montenegrin rail lines remain intact
Highways:
total: 48,603 km
paved: 28,822 km (including 560 km of expressways)
unpaved: 19,781 km (1998 est.)
note: because of the 1999 Kosovo conflict, many road
bridges were destroyed; since the end of the conflict
in June 1999, Serbia has had a rapid reconstruction
program to either reconstruct bridges or build by-pass
routes
Waterways: 587 km; Danube River runs through
Serbia connecting Europe with the Black Sea; in early
2000 the river was obstructed at Novi Sad due to a
pontoon bridge; a canal system in north Serbia is
available to by-pass damage, however, lock size is
limited (1999)
Pipelines: crude oil 415 km; petroleum products 1 30
km; natural gas 2,1 10 km
Ports and harbors: Bar, Belgrade, Kotor, Novi Sad,
Pancevo, Tivat, Zelenika
Airports: 48 (Serbia 43, Montenegro 5) (1999 est.)
Airports - with paved runways:
total: (Serbia 16, Montenegro 3)
over 3,047 m: 2 (Serbia 2, Montenegro 0)
2,438 to 3,047 m: 5 (Serbia 3, Montenegro 2)
1,524 to 2,437 m: 5 (Serbia 4, Montenegro 1 )
914 to 1,523 m: 2 (Serbia 2, Montenegro 0)
under 914 m: 5 (Serbia 5, Montenegro 0) (1 999 est.)
Airports - with unpaved runways:
total: 29 (Serbia 27, Montenegro 2)
1,524 to 2,437 m: 2 (Serbia 2, Montenegro 0)
914 to 1,523 m: 13 (Serbia 12, Montenegro 1)
under 914 m: 14 (Serbia 13, Montenegro 1)
(1999 est.)
Heliports: 2 (1999 est.)
Railways: 0 km
Highways:
total: 280 km
paved: 176 km
unpaved: 104 km (1996 est.)
Ports and harbors: Victoria
Merchant marine: none (1999 est.)
Airports: 14 (1999 est.)
Airports - with paved runways:
total: 6
1,524 to 2,437 m:1
914 to 1,523 m: 3
under 914 m: 2 (1999 est.)
Airports - with unpaved runways:
total: 8
914 to 1,523 m: 4
under 914 m; 4 (1999 est.)','c48236f1944ed48d6efa2050d672712832e4961a3df6a12237f4f7a88425fac5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3bef5e712acca236cd60c41721e80a681aa91e1dcd10dea659a06ac1b050386',2000,'YT','Mayotte','transportation',340,'Railways:
total: 31 ,048 km
standard gauge: 30,958 km 1.435-m gauge (246 km
electrified)
narrow gauge: 90 km 0.91 4-m gauge (1998 est.)
Highways:
total: 323,977 km
paved: 96,221 km (including 6,335 km of
expressways)
unpaved: 227,756 km (1997 est.)
Waterways: 2,900 km navigable rivers and coastal
canals
Pipelines: crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1,400 km
Ports and harbors: Acapulco, Altamira,
Coatzacoalcos, Ensenada, Guaymas, La Paz, Lazaro
Cardenas, Manzanillo, Mazatlan, Progreso, Salina
Cruz, Tampico, Topolobampo, Tuxpan, Veracruz
Merchant marine:
total: 46 ships (1 ,000 GRT or over) totaling 633,21 9
GRT/970,947 DWT
ships by type: bulk 2, cargo 1 , chemical tanker 4,
liquified gas 4, petroleum tanker 29, roll-on/roll-off 3,
short-sea passenger 3 (1999 est.)
Airports: 1,806 (1999 est.)
Airports ■ with paved runways:
total: 233
over 3,047 m: 10
2,438 to 3,047 m: 28
1,524 to 2,437 m: 87
914 to 1,523 m: 81
under 914 m: 27 (1 999 est.)
Airports - with unpaved runways:
total: 1 ,573
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 83
914 to 1,523 m: 473
under 914 m: 1 ,035 (1 999 est.)
Heliports: 2 (1999 est.)
( M iT 1 1 a r y
Military branches: National Defense Secretariat
(includes Army and Air Force), Navy Secretariat
(includes Naval Air and Marines)
Military manpower - military age: 18 years of age
note: starting in 2000, females will be allowed to
volunteer for military service
Military manpower - availabiiity:
mates age 15-49; 26,171,141 (2000 est.)
Military manpower ■ fit for military service:
males age 15-49: 19,022,012 (2000 est.)
Miiitary manpower - reaching military age
annually:
mates; 1,073,809 (2000 est.)
Military expenditures - dollar figure: $4 billion
(FY99)
Military expenditures - percent of GDP: 1 %
(FY99)','2c463151b2c450d7e5c18d7bcdbf32e339374fbffed23a467713002467e526da','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78da0fc8aad2627d0d22f1acb9bbff834b80ad5a58e337a3265ecf4eb52e99c6',2000,'ID','Indonesia','transportation',345,'Railways: 0 km
Highways;
total: 240 km
paved: 42 km
unpaved: 198 km (1996 est.)
Ports and harbors: Colonia (Yap), Kolonia
(Pohnpei), Lele, Moen
Merchant marine: none (1999 est.)
Airports: 6 (1999 est.)
Airports - with paved runways:
total: 5
1,524 to 2,437 m: 4
914 to 1,523 m:1 {1999 est.)
Airports - with unpaved runways;
total: 1
914 to 1,523 m;1 (1999 est.)
Railways:
total: 38.6 km
narrow gauge: 38.6 km 1 .000-m gauge
note: there is a 83 km mass transit system with 48
stations
Highways:
total: 3,122 km
paved: 3,038 km (including 150 km of expressways)
unpaved: 8A km (1998)
Ports and harbors: Singapore
Merchant marine:
total: 891 ships (1 ,000 GRT or over) totaling
21,808,813 GRT/34,783,544 DWT
ships by type: bulk 140, cargo 121 , chemical tanker
66, combination bulk 6, combination ore/oil 6,
container 162, liquified gas 26, livestock carrier 2,
multi-functional large load carrier 3, petroleum tanker
294, refrigerated cargo 6, roll-on/roll-off 10, short-sea
passenger 1 , specialized tanker 1 2, vehicle carrier 36
(1999 est.)
note: a flag of convenience registry; includes ships
from 22 countries among which are Japan 41 ,
Denmark 35, Sweden 28, Thailand 28, Hong Kong 26,
Germany 1 9, Taiwan 1 9, and Indonesia 1 1 (1 998 est.)
Airports: 9 (1999 est.)
Airports ■ with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m:1
under 914 m:1 (1999 est)
Heliports: 1 (1 999 est)','7ff216dc5b0a66d7d20f6c5741af90845a9f2e74362ebf85eba612a894665e56','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a70d59191128061ea210a67175f26332103bf078ccd7316dc9553f6fad65ee6a',2000,'MZ','Mozambique','transportation',355,'Railways:
total: 2,382 km
narrow gauge: 2,382 km 1.067-m gauge; single track
(1995)
Highways;
total: 63,258 km
paved: 5,250 km
unpaved: 58,008 km (1997 est.)
Ports and harbors: Luderitz, Walvis Bay
Merchant marine: none (1999 est.)
Airports: 135 (1999 est.)
Airports - with paved runways;
total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m:t5
914to 1,523 m: 3 [1999 est.)
Airports - with unpaved runways:
fofa/;113
2,438 to 3,047 m: 2
1,524 to 2,437 m: 21
914 to 1,523 m: 69
under 914 m: 21 (1 999 est.)
Unemployment rate: 0%
Budget:
revenues: $23.4 million
expenditures: $64.8 million, including capital
expenditures of $NA (FY95/96)
Industries: phosphate mining, financial senrices,
coconut products
Industrial production growth rate: NA%
Electricity - production: 30 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other 0% (1998)
347
Nauru (continued)
Electricity - consumption: 28 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: coconuts
Exports: $25.3 million (f.o.b., 1991)
Exports - commodities: phosphates
Exports ■ partners: Australia, NZ
Imports: $21.1 million (c.i.t., 1991)
Imports - commodities: food, fuel, manufactures,
building materials, machinery
Imports - partners: Australia, UK, NZ, Japan
Debt - external: $33.3 million
Economic aid - recipient: $2.25 million from
Australia (FY96/97 est.)
Currency: 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A) per US$1 -
1 .5207 (January 2000), 1 .5497 (1 999), 1 .5888 (1 998),
1.3439 (1997), 1.2773 (1996), 1.3486 (1995)
Fiscal year: 1 July - 30 June
I Communications
Teiephones - main iines in use: 2,000 (1994)
Teiephones - mobiie ceiluiar: 450 (1994)
Telephone system: adequate local and
international radiotelephone communications
provided via Australian facilities
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 0, shortwave
0(1998)
Radios: 7,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 500(1997)
internet Service Providers (iSPs): NA
I transportation
Railways:
total: 3.9 km; note - used to haul phosphates from the
center of the island to processing facilities on the
southwest coast
Highways:
total: 30 km
paved: 24 km
unpaved: 6 km (1998 est.)
Ports and harbors: Nauru
Merchant marine: none (1999 est.)
Airports: 1 (1999 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 est.)
Railways:
fofa/; 2,481 km (519 km electrified)
narrow gauge: 2,481 km 1.067-m (1999)
Highways:
total: 34,901 km
paved: 31,271 km (including 538 km of expressways)
unpaved: 3,630 km (1998 est.)
Pipelines: petroleum products 3,400 km; natural gas
1,800 km (1999)
Ports and harbors: Chi-lung (Keelung), Hua-lien,
Kao-hsiung, Su-ao, T''ai-chung
Merchant marine:
total: 1 75 ships (1 ,000 GRT or over) totaling
4,944,166 GRT/7,710,891 DWT
ships by type: bulk 45, cargo 33, combination bulk 1 ,
container 69, petroleum tanker 17, refrigerated cargo
8, roll-on/roll-off 2 (1999 est.)
Airports: 38 (1999 est.)
Airports - with paved runways:
total: 35
over 3,047 m: 8
2,438 to 3,047 m: 9
1,524 to 2,437 m: 8
914 to 1,523 m: 7
under 914 m; 3 (1999 est.)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m:1
under 914 m: 2 (1999 est.)
Heliports: 2 (1999 est.)','d7ce13ed3d57de3245f0f53470ab7d358cf849d5b9e2656ba44c6246c23f06b6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23365d5b5c98d0900a097f825c4096c391914885121a7f776bb968959bd9d73e',2000,'NZ','New Zealand','transportation',367,'Railways;
tofa/;3,913km
narrow gauge: 3,913 km 1.067-m gauge (519 km
electrified) (1999)
Highways:
total: 92,200 km
paved: 53,568 km (including at least 144 km of
expressways)
unpaved: 38,632 km (1996 est.)
Waterways: 1 ,609 km; of little importance to
Pipelines: petroleum products 160 km; natural gas
1,000 km; liquefied petroleum gas or LPG 150 km
Ports and harbors: Auckland, Christchurch,
Dunedin, Tauranga, Wellington
Merchant marine;
total: 1 0 ships (1 ,000 GRT or over) totaling 1 02,461
GRT/133,418 DWT
ships by type: bulk 4, cargo 1 , petroleum tanker 2, rail
car carrier 1 , roll-on/roll-off 2 (1 999 est.)
Airports: 111 (1999 est.)
Airports ■ with paved runways;
total: 44
over 3,047 m: 2
2,438 to 3,047 m:1
1,524 to 2,437 m: 10
914 to 1,523 m: 28
under 914 m: 3(1 999 est.)
Airports - with unpaved runways;
total: 67
1,524 to 2,437 m:1
914 to 1,523 m: 23
under 914 m: 43 (1 999 est.)
Highways;
fofa/; 16,382 km
paved; 1,818 km
unpaved: 14,564 km (1998 est.)
Waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil 56 km
Ports and harbors: Bluefields, Corinto, El Bluff,
Puerto Cabezas, Puerto Sandino, Rama, San Juan
del Sur
Merchant marine: none (1999 est.)
Airports: 182 (1999 est.)
Airports - with paved runways:
total: 1 1
over 3,047 m:t
2,438 to 3,047 m:t
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m; 3 (1999 est.)
Airports - with unpaved runways:
total: 171
1,524 to 2,437 m:1
914 to 1,523 m: 23
under 914 m: 144 (1999 est.)
Railways: 0 km
Highways:
fofa/; 10,100 km
paved: 798 km
unpaved: 9,302 km (1996 est.)
Waterways: the Niger is navigable 300 km from
Niamey to Gaya on the Benin frontier from
mid-December through March
Ports and harbors: none
Airports: 27 (1999 est.)
Airports ■ with paved runways;
total: 9
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
under 914 m:1 (1999 est.)
Airports - with unpaved runways;
total: 18
1,524 to 2,437 m:1
914 to 1,523 m: 15
under 914 m: 2 (1999 est.)
Ports and harbors: none; offshore anchorage only
Airports: 1 (1999 est.)
Airports • with unpaved runways:
total: 1
under 914 m:1 (1999 est.)','4b11a05027a62a861d98db984754dd8efe0ebdf3ea350cde2ebd98a3bcbbbb30','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e58597aae355fde5feb6e7bdefc1373876c07907bea35d6b6306d8a5efa500ed',2000,'PW','Palau','transportation',378,'Railways; 0 km
Highways;
total: 61 km
paved: 36 km
unpaved: 25 km
Ports and harbors: Koror
Merchant marine: none (1999 est.)
Airports: 3 (1999 est.)
Airports ■ with paved runways:
total: 1
1,524 to 2,437m:1(19m est)
Airports - with unpaved runways:
total: 2
1,524 to 2, 437 m: 2 (1999 est.)
I M flit ary
Military branches: NA
Military expenditures - dollar figure; $NA
Military expenditures - percent of GDP; NA%
Military - note: defense is the responsibility of the
US; under a Compact of Free Association between
Palau and the US, the US military is granted access to
the islands for 50 years
; T r a n s n a t i 0 n a i Issues
Disputes - international: none
I Palmyra Atoll
I (territory of the US)
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to American','629d0ab90cd8e99c74d6f183600c0f166bc666de1e4c0deea1a104b83d70c3bc','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('294a160eccd59d08859712732d30332b9db7e75de6d85ba1c9b09c862ae52d3b',2000,'WS','Samoa','transportation',379,'Geographic coordinates; 5 52 N, 162 06 W
Map references: Oceania
Area;
total: 1 1 .9 sq km
land: 1 1 .9 sq km
water: 0 sq km
Area - comparative: about 20 times the size of The
Mall in Washington, DC
Land boundaries; 0 km
Coastline; 14.5 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial, hot, and very rainy
Terrain: very low
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 2 m
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 100%
other: 0%
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current Issues; NA
Geography - note: about 50 islets covered with
dense vegetation, coconut trees, and balsa-like trees
up to 30 meters tall','251a51b605b9cbf932c586697d2107ad89f2a5a4104f7336323bf88102097a1d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17c4a525181ed213a82ad9ed3e0158bffb2058f581cc2ac188bf5267bcf3bd69',2000,'AR','Argentina','transportation',389,'Railways:
total: 971 km
standard gauge: 441 km 1.435-m gauge
narrow gauge: 60 km 1.000-m gauge
note: there are 470 km of various gauges that are
privately owned
Highways:
total: 29,500 km
paved: 15,000 km
unpaved: 14,500 km (1999)
Waterways: 3,100 km
Ports and harbors: Asuncion, Villeta, San Antonio,
Encarnacion
Merchant marine:
total: 21 ships (1 ,000 GRT or over) totaling 30,287
GRT/32,510 DWT
ships by type: cargo 1 5, chemical tanker 1 , petroleum
tanker 4, roll-on/roll-off 1 (1999 est.)
Airports: 937 (1999 est.)
Airports - with paved runways:
total: 10
over 3,047 m: 3
1,524 to 2, 437 m: 3
914 to 1,523 m: 4 {1999 est.)
Airports - with unpaved runways:
total: 927
over 3,047 m:1
390
Paraguay (continued)
1,524 to 2,437 m: 29
914 to 1,523 m: 346
under 914 m: 551 (1999 est.)
I M ill t a r y
Military branches: Army, Navy (includes Naval Air
and Marines), Air Force
Military manpower - military age; 17 years of age
Military manpower - availability;
males age 15-49: 1 ,349,800 (2000 est.)
Military manpower - fit for military service;
males age 15-49: 974,313 (2000 est.)
Military manpower - reaching military age
annually:
males: 56,701 (2000 est.)
Military expenditures - dollar figure; $125 million
(FY98)
Military expenditures - percent of GDP: 1 .4%
(FY98)
I t r a nTn atlonal Issues''
Illicit drugs: illicit producer of cannabis, most or all of
which is consumed in South America; transshipment
country for Bolivian cocaine headed for Southern
Cone markets and Europe and a limited amount to the
US','3324d4416db049fe2bca2fe655e60ac15ef43f6eb4e579e0a19d48cda797a49b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd671f744fbbf9923d0466904854033b4136d6fe2c330bdf35ac2b982ef6df7a',2000,'MX','Mexico','transportation',397,'Railways:
totai: 2,850 km
broad gauge: 2,576 km 1 .668-m gauge (623 km
electrified; 426 km double track)
narrow gauge: 274 km 1.000-m gauge (1998)
Highways:
totai: 68,732 km
paved: 59,1 10 km (including 797 km of expressways)
unpaved: 9,622 km (1999 est.)
Waterways: 820 km navigable; relatively
unimportant to national economy, used by
shallow-draft craft limited to 300 metric-ton or less
cargo capacity
Pipelines: crude oil 22 km; petroleum products 58
km; natural gas 700 km
note: the secondary lines for the natural gas pipeline
that will be 300 km long have not yet been built
Ports and harbors: Aveiro, Funchal (Madeira
Islands), Horta (Azores), Leixoes, Lisbon, Porto,
Ponta Delgada (Azores), Praia da Vitoria (Azores),
Setubal, Viana do Castelo
Merchant marine:
total: 151 ships (1 ,000 GRT or over) totaling
1,061,202 GRT/1 ,601, 267 DWT
ships by type: bulk 13, cargo 80, chemical tanker 14,
container 8, liquified gas 8, multi-functional large load
carrier 1 , petroleum tanker 10, refrigerated cargo 1,
roll-on/roll-off 6, short-sea passenger 5, vehicle carrier
5(1999 est.)
note: Portugal has created a captive register on
Madeira for Portuguese-owned ships; ships on the
Madeira Register (MAR) will have taxation and
crewing benefits of a flag of convenience (1998 est.)
Airports: 66 (1999 est.)
Airports - with paved runways:
totai: 40
over 3,047 m: 5
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 18
under 914 m; 5 (1 999 est.)
Airports - with unpaved runways:
total: 26
914 to 1,523 m:1
under 914 m: 25 (1 999 est.)','2e5214543442192d78ae8e6fccae28b78ac09726c4d15b56481dc951f1fef199','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9f6c4729d2726ea092ea50460d65877d7e54b71ab0acc24b8425181e58c56fe',2000,'UA','Ukraine','transportation',405,'. ~
Population: 22,411,121 (July 2000 est.)
Agestnictare:
0-14 1t% (mate 2,1 1 1,320; famMe 2,015,347)
15-64 ymrs: 68% (male 7,597,^; female
7,707,498)
65 years and over: 14% (male 1 ,237,368; female
1,741,630) (2000 est.)
Population growth rate: -0.21% (2000 est.)
Birth rate: 10.76 births/1,000 population (2000_est.)
Death rate: 12.29 deaths/1,000 population
(2000 est.)
Net migration rate: -0.6 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 19.84 deaths/1 ,000 live births
(2000 est.)
Life expe^ancy at birth:
total population: 69.93 years
mate; 66.1 years
female: 73.99 years (2000 est.)
409
Romania (continued)
Total fertility rate: 1 .35 children born/woman
(2000 est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.5%, Hungarian 7.1%,
Roma 1 .8%, German 0.5%, Ukrainian 0.3%, other
0.8% (1992)
Religions: Romanian Orthodox 70%, Roman
Cathoiic 6% (of which 3% are Uniate), Protestant 6%,
unaffiiiated 18%
Languages: Romanian, Hungarian, German
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 95% (1992 est.)
Railways;
total: 1 50,000 km; note - 87,000 km in common carrier
service; 63,000 km serve specific industries and are
not available for common carrier use
broad gauge: 150,000 km 1.520-m gauge (January
1997 est.)
Highways:
total: 948,000 km (including 416,000 km which serve
specific industries or farms and are not maintained by
governmental highway maintenance departments)
414
Russia (continued)
paved: 336,000 km
unpaved: 6^2,000 km (including 411,000 km of
graveled or some other form of surfacing and 201 ,000
km of unstabilized earth) (1995 est.)
Waterways: total navigable routes in general use
1 01 ,000 km; routes with navigation guides serving the
Russian River Fleet 95,900 km; routes with night
navigational aids 60,400 km; man-made navigable
routes 16,900 km (January 1994 est.)
Pipelines: crude oil 48,000 km; petroleum products
15,000 km; natural gas 140,000 km (June 1993 est.)
Ports and harbors: Arkhangel''sk, Astrakhan'',
Kaliningrad, Kazan'', Khabarovsk, Kholmsk,
Krasnoyarsk, Moscow, Murmansk, Nakhodka,
Nevel''sk, Novorossiysk, Petropavlovsk-Kamchatskiy,
St. Petersburg, Rostov, Sochi, Tuapse, Vladivostok,
Volgograd, Vostochnyy, Vyborg
Merchant marine:
total: 695 ships (1 ,000 GRT or over) totaling
3,920,923 GRT/4,867,676 DWT
ships by type: barge carrier 1 , bulk 1 9, cargo 379,
chemical tanker 4, combination bulk 21 , combination
ore/oil 3, container 25, multi-functional large load
carrier 1, passenger 35, passenger/cargo 3,
petroleum tanker 149, refrigerated cargo 26, roll-on/
roll-off 22, short-sea passenger 7 (1 999 est.)
Airports: 2,517 (1994 est.)
Airports - with paved runways:
total: m
over 3,047 m: 5A
2,438 to 3,047 m: 202
1,524 to 2,437 m:m
914 to 1,523 m:m
under 914 m: 151 (1994 est.)
Airports - with unpaved runways:
total: 1,887
over 3,047 m: 25
2,438 to 3,047 m: 45
1,524 to 2,437 m: 184
914 to 1,523 m: 221
under 914 m: 1 ,392 (1 994 est.)
I" Military
Military branches: Ground Forces, Navy, Air Force,
Strategic Rocket Forces
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 38,825,1 13 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 30,294,374 (2000 est.)
Military manpower - reaching military age
annually:
ma/es; 1,195,916 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
I Transnational Issues
Disputes - international: dispute over at least two
small sections of the boundary with China remain to
be settled, despite 1 997 boundary agreement; islands
of Etorofu, Kunashiri, and Shikotan and the Habomai
group occupied by the Soviet Union in 1945, now
administered by Russia, claimed by Japan; Caspian
Sea boundaries are not yet determined among
Azerbaijan, Iran, Kazakhstan, Russia, and
Turkmenistan; Estonian and Russian negotiators
reached a technical border agreement in December
1996 which has not been ratified; draft treaty
delimiting the boundary with Latvia has not been
signed; has made no territorial claim in Antarctica (but
has reserved the right to do so) and does not
recognize the claims of any other nation; 1 997 border
agreement with Lithuania not yet ratified
Illicit drugs: limited cultivation of illicit cannabis and
opium poppy and producer of amphetamines, mostly
for domestic consumption; government has active
eradication program; increasingly used as
transshipment point for Southwest and Southeast
Asian opiates and cannabis and Latin American
cocaine to Western Europe, possibly to the US, and
growing domestic market; major source of heroin
precursor chemicals
Background: In 1959, three years before
independence, the majority ethnic group, the Hutus
overthrew the ruling Tutsi king. Over the next several
years thousands of Tutsis were killed, and some
1 50,000 driven into exile in neighboring countries. The
children of these exiles later formed a rebel group, the
Rwandan Patriotic Front (RPF) and began a civil war
in 1990. The war, along with several political and
economic upheavals, exacerbated ethnic tensions
culminating in April 1994 in a genocide in which
roughly 800,000 Tutsis and moderate Hutus were
killed. The Tutsi rebels defeated the Hutu regime and
ended the genocide in July 1 994, but approximately 2
million Hutu refugees - many fearing Tutsi retribution -
fled to neighboring Burundi, Tanzania, Uganda, and
Zaire, now called the Democratic Republic of the
Congo (DROC). Since then most of the refugees have
returned. Despite substantial international assistance
and political reforms - including Rwanda''s first ever
local elections held in March 1999 - the country
continues to struggle to boost investment and
agricultural output and to foster reconciliation. A
series of massive population displacements, a
nagging Hutu extremist insurgency, and Rwandan
involvement in two wars over the past four years in the
neighboring DROC continue to hinder Rwanda''s
efforts.
. GeTgT''ilp''Fy"''
Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,338 sq km
land: 24,948 sq km
water: 1 ,390 sq km
Area - comparative: slightly smaller than Maryland
415
Rwanda (continued)
Land boundaries;
total: 893 km
border countries: Burundi 290 km, Democratic
Republic of the Congo 217 km, Tanzania 217 km,
Uganda 169 km
Coastline; 0 km (landlocked)
Maritime claims; none (landlocked)
Climate; temperate; two rainy seasons (February to
April, November to January); mild in mountains with
frost and snow possible
Terrain; mostly grassy uplands and hills; relief is
mountainous with altitude declining from west to east
Elevation extremes;
lowest point: Rusizi River 950 m
highest point: Wean Karisimbi 4,519 m
Natural resources; gold, cassiterite (tin ore),
wolframite (tungsten ore), methane, hydropower,
arable land
Land use;
arable land: 35%
permanent crops: t3%
permanent pastures: 1 8%
forests and woodland: 22%
other; 12% (1993 est.)
Irrigated land; 40 sq km (1993 est.)
Natural hazards; periodic droughts; the volcanic
Birunga mountains are in the northwest along the
border with Democratic Republic of the Congo
Environment - current issues; deforestation
results from uncontrolled cutting of trees for fuel;
overgrazing; soil exhaustion; soil erosion; widespread
poaching
Environment • international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Nuclear Test
Ban
signed, but not ratified: Law of the Sea
Geography - note; landlocked; predominantly rural
population
L People
Population; 7,229,129
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 43% (male 1 ,558,730; female 1 ,548,175)
15-64 years: 54% (male 1,943,268; female
1,971,542)
65 years and over: 3% (male 83,699; female
123,715) (2000 est.)
Population growth rate; 1 .14% (2000 est.)
Birth rate; 34.78 births/1 ,000 population (2000 est.)
Death rate; 20.95 deaths/1 ,000 population
(2000 est.)
Net migration rate; -2.46 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate; 120.06 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth;
total population: 39.34 years
male: 38.58 years
female: 40.13 years (2000 est.)
Total fertility rate; 5.07 children born/woman
(2000 est.)
Nationality;
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups; Hutu 84%, Tutsi 15%, Twa
(Pygmoid) 1%
Religions; Roman Catholic 65%, Protestant 9%,
Muslim 1%, indigenous beliefs and other 25%
Languages; Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy;
definition: age 15 and over can read and write
total population: 60.5%
male: 69.8%
female: 51 .6% (1995 est.)','4a6eb89e3084278229f5a2f712d514e60e00b9837b57d39c5c9cf6358ae915df','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7464d64bd197eb6847b132d9f364869edfea60609d13eee3706209be25c5b0d',2000,'VC','Saint Vincent and the Grenadines','transportation',414,'(continued)
note: a flag of convenience registry; includes ships
from 20 countries among which are Croatia 17,
Slovenia 7, China 5, Greece 5, DAE 3, Norway 2,
Japan 2, and Ukraine 2 (1998 est.)
Airports; 6 (1999 est.)
Airports - with paved runways:
total: 5
914 to 1,523 m: 3
under 914 m; 2 (1999 est.)
Airports - with unpaved runways;
total: 1
under 914 m:1 (1999 est.)
I Mifitary
Military branches; Royal Saint Vincent and the
Grenadines Police Force (includes Special Service
Unit), Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
l^transnational Issues
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe','da9063e4d2fb97c0d74feefe3d725260662f52b2cf7d747b2f65b28db9babc4b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cbb046a7c8a1199a3c17b03dd065d207d03956e0615a4488124ddda8219b4b7',2000,'IT','Italy','transportation',420,'Railways: 0 km; note - there is a 1 .5 km cable
railway connecting the city of San Marino to Borgo
Maggiore
Highways:
total: 220 km
paved: NA km
unpaved: NA km
Ports and harbors: none
Airports: none
430
San Marino (continued)
I Military
Military branches: Voluntary Military Force, Police
Force
Military expenditures - dollar figure: $700,000
(FY98)
Military expenditures - percent of GDP: NA%
I T r a n s n a t i 0 n a i 1 s s u e s
Disputes - internationai: none
iSao Tome
land Principe
I
I ~ I’ll t rod''ll c tiornr"
Background: Discovered and claimed by Portugal in
the iate 15th century, the islands'' sugar-based
economy gave way to coffee and cocoa in the 1 9th
century - all grown with plantation slave labor, a form
of which lingered into the 20th century. Although
independence was achieved in 1975, democratic
reforms were not instituted until the late 1980s. The
first tree elections were held in 1991 .
I G e o^g r''a p h y’"”
Location: Western Africa, islands In the Gulf of
Guinea, straddling the Equator, west of Gabon
Geographic coordinates; 1 00 N, 7 00 E
Map references; Africa
Area:
total: 1 ,001 sq km
land: 1 ,001 sq km
water: 0 sq km
Area - comparative: more than five times the size of
Washington, DC
Land boundaries; 0 km
Coastline; 209 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: t2nm
Climate: tropical; hot, humid; one rainy season
(October to May)
Terrain: volcanic, mountainous
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources; fish, hydropower
Land use:
arable land: 2%
permanent crops: 36%
permanent pastures: 1%
forests and woodland: 0%
other; 61% (1993 est.)
Irrigated land: 100 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: deforestation; soil
erosion and exhaustion
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Ship Pollution
signed, but not ratified: none of the selected
agreements
I People
Population: 159,883 (July 2000 est.)
Age structure;
0-14 years: 48% (male 38,588; female 37,624)
15-64 years: 48% (male 37,216; female 39,959)
65 years and over: 4% (male 2,961 ; female 3,535)
(2000 est.)
Population growth rate: 3.16% (2000 est.)
Birth rate: 42.98 births/1,000 population (2000 est.)
Death rate: 7.76 deaths/1,000 population
(2000 est.)
Net migration rate: -3.62 mlgrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 50.41 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 65.25 years
male: 63.84 years
female: 66.7 years (2000 est.)
Total fertility rate: 6.08 children born/woman
(2000 est.)
Nationality;
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups; mestico, angolares (descendants of
Angolan slaves), forros (descendants of freed slaves),
servicais (contract laborers from Angola,
Mozambique, and Cape Verde), tongas (children of
servicais born on the islands), Europeans (primarily
Portuguese)
Religions: Christian 80% (Roman Catholic,
Evangelical Protestant, Seventh-Day Adventist)
Languages: Portuguese (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 73%
male: 85%
fema/e; 62% (1991 est.)
Country name:
conventional long form: Democratic Republic of Sao
Tome and Principe
conventional short form: Sao Tome and Principe
431
Sao Tome and Principe (continued)
local long form: Republica Democratica de Sao T ome
e Principe
local short form: Sao Tome e Principe
Data code: TP
Government type: repubiic
Capital: Sao Tome
Administrative divisions: 2 provinces; Principe,
Sao Tome
note: Principe has had seif-government since 29 Aprii
1995
Independence: 12 Juiy 1975 (from Portugal)
National holiday: Independence Day, 12 July
(1975)
Constitution: approved March 1990; effective 10
September 1990
Legal system: based on Portuguese legal system
and customary la\\w; has not accepted compulsory ICJ
• jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Miguel TROVOADA (since 4
April 1991)
head of government: Prime Minister Guilherma
Posser da COSTA (since 30 December 1998)
cabinet: Council of Ministers appointed by the
president on the proposal of the prime minister
elections: president elected by popular vote for a
five-year term; election last held 30 June and 21 July
1996 (next to be held NA July 2001); prime minister
chosen by the National Assembly and approved by
the president
election results: Miguel TROVOADA reelected
president in Sao Tome''s second multiparty
presidential election; percent of vote - Miguel
TROVOADA 52.74%, Manuel Pinto da COSTA
47.26%
Legislative branch: unicameral National Assembly
or Assembleia Nacional (55 seats; members are
elected by direct popular vote to serve five-year terms)
elections: last held 8 November 1 998 (next to be held
NA November 2003)
election results: percent of vote by party -
MLSTP-PSD 56%, PCD 14.5%, ADI 29%; seats by
party - MLSTP-PSD 31 , AD1 1 6, PCD 8
Judicial branch: Supreme Court, judges are
appointed by the National Assembly
Political parties and leaders: Christian Democratic
Front or FDC [Alphonse Dos SANTOS]; Democratic
Opposition Coalition or CODO [leader NA];
Independent Democratic Action or ADI [Carlos
NEVES]; Movement for the Liberation of Sao Tome
and Principe-Social Democratic Party or MLSTP-PSD
[Manuel Pinto Da COSTA]; Party for Democratic
Convergence or PCD [Armindo AGUIAR, secretary
general]; other small parties
International organization participation: ACCT,
ACP, AfDB, CEEAC, ECA, FAO, G-77, IBRD, ICAO,
ICRM, IDA, IFAD, IFRCS, ILO, IMF, IMO, Intelsat
(nonsignatory user), Interpol, IOC, lOM (observer),
ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO,
UPU, WHO, WlPO, WMO, WToO, WTrO
(applicant)
Diplomatic representation in the US: Sao Tome
and Principe does not have an embassy in the US, but
does have a Permanent Mission to the UN, headed by
First Secretary Domingos Augusto FERREIRA,
located at 122 East 42nd Street, Suite 1604, New
York, NY 10168, telephone [1] (212) 317-0533
Diplomatic representation from the US: the US
does not have an embassy in Sao Tome and Principe;
the Ambassador to Gabon is accredited to Sao Tome
and Principe on a nonresident basis and makes
periodic visits to the islands
Flag description: three horizontal bands of green
(fop), yellow (double width), and green with two black
five-pointed stars placed side by side in the center of
the yellow band and a red isosceles triangle based on
the hoist side; uses the popular pan-African colors of
Railways:
total: 2,750 km
standard gauge: 2,423 km 1 .435-m gauge
narrow gauge: 327 km 1.050-m gauge (2000)
Highways:
total: 36,377 km
paved: 26,299 km (including 877 km of expressways)
unpaved: 10,078 km (1999 est.)
Waterways: 870 km; minimal economic importance
Pipelines: crude oil 1 ,304 km; petroleum products
515 km
Ports and harbors: Baniyas, Jablah, Latakia,
Tartus
Merchant marine:
total: 137 ships (1,000GRT or over) totaling 429,005
GRT/626,069 DWT
ships by type: bulk 1 1 , cargo 120, livestock carrier 5,
roll-on/roll-off 1 (1999 est.)
Airports: 104 (1999 est.)
Airports - with paved runways:
total: 24
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m:1
under 914 m; 2 (1999 est.)
Airports - with unpaved runways:
total: 80
1,524 to 2, 437 m: 3
914 to 1,523 m: 14
under 914 m: 63 (1999 est.)
Heliports: 2 (1999 est.)','ccda9668200c9e55f2ebd90f4cde5e81515e2d536d47d8fb86db6123b204390e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('404f570b783d4963e307bf785f34a2cf21c749ecd99a7d728b1b2c4de8fdd8c7',2000,'SO','Somalia','transportation',428,'Railways: 0 km
Highways:
tofa/; 22, 100 km
paved: 2,608 km
unpaved; 19,492 km (1996 est.)
Pipelines: crude oil 15 km
Ports and harbors: Bender Cassim (Boosaaso),
Berbera, Chisimayu (Kismaayo), Merca, Mogadishu
Merchant marine: none (1999 est.)
Airports: 61 (1999 est.)
Airports - with paved runways:
total:!
over 3,047 m: 4
2,438 to 3,047 m.-t
1,524 to 2,437 m:t
91 4 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
total: 54
2,438 to 3,047 m: 3
1,524 to 2,437 m: 12
914 to 1,523 m: 29
under 914 m: 10 (1999 est.)','d65853a2daf2bd52ef15563c9ea175d71f35c4e4b673c6461fbde40747705a2a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35417674633a2642bbdd4005459be1da3c2b137def16356ef4fe5cbc9b19b3f4',2000,'PH','Philippines','transportation',437,'Ports and harbors; none
Airports: 4 (1999 est.)
Airports - with paved runways:
total: 1
914 to 1,523 m;1 (1999 est.)
Airports - with unpaved runways;
total: 3
914 to 1,523 m:1
under 914 m; 2 (1999 est.)','aa10e195b5b1dd1cc8a6eddd7613d054865ab69e041c01aa7706c86d496425e4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98294408e8b1ef266432a369d4f73842a52cf92330771e7e221af9862274d22d',2000,'ZW','Zimbabwe','transportation',460,'Railways:
total: 3,940 km
narrow gauge: 3,940 km 1 .000-m gauge (99 km
double track)
Highways:
total: 64,600 km
paved: 62,985 km
unpaved: 1 ,615 km (1996 est.)
Waterways: 3,999 km principal waterways; 3,701
km with navigable depths of 0.9 m or more throughout
the year; numerous minor waterways navigable by
shallow-draft native craft
Pipelines: petroleum products 67 km; natural gas
350 km
Ports and harbors: Bangkok, Laem Chabang,
Pattani, Phuket, Sattahip, Si Racha, Songkhia
Merchant marine:
total: 299 ships (1 ,000 GRT or over) totaling
1 ,834,809 GRT/2,949,558 DWT
ships by type: bulk 39, cargo 135, chemical tanker 3,
combination bulk 1, container 13, liquified gas 19,
multi-functional large load carrier 3, passenger 1 ,
petroleum tanker 63, refrigerated cargo 13, roll-on/
roll-off 2, short-sea passenger 2, specialized tanker 5
(1999 est.)
Airports: 106 (1999 est.)
Airports • with paved runways:
total: 5Q
over 3,047 m: 6
2,438 to 3,047 m:tt
1,524 to 2,437 m:t7
914 to 1,523 m: 18
under 914 m;4 (1999 est.)
Airports - with unpaved runways:
total: 50
1,524 to 2,437 m:1
914 to 1,523 m: 18
under 914 m: 33 (1999 est.)
Heliports: 3 (1999 est.)
Railways;
total: 525 km (1995)
narrow gauge: 525 km 1 .000-m gauge
Highways:
fofa/;7,520km
paved: 2,376 km
unpaved: 5,144 km (1996 est.)
Waterways: 50 km Mono river
492
Togo (continued)
Ports and harbors: Kpeme, Lome
Merchant marine;
total: 2 ships (1 ,000 GRT or over) totaling 56,332
GRT/97,443 DWT
ships by type: bulk 1 , cargo 1 (1 999 est.)
Airports; 9 (1999 est.)
Airports - with paved runways;
total: 2
2,438 to 3,047 m: 2 {m2 est.)
Airports - with unpaved runways;
total:!
914 to 1,523 m: 5
under 914 m: 2 {1222 est.)
p Military
Miiitary branches: Army, Navy, Air Force,
Gendarmerie
Military manpower - availability:
males age 15-49: 1,131 ,451 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 593,589 (2000 est.)
Military expenditures - dollar figure: $27 million
(FY96)
Military expenditures - percent of GDP: 2%
(FY96)
I transnatfonallssues~
Disputes - international; none
Illicit drugs: transit hub for Nigerian heroin and
cocaine traffickers
iTokelau
((territory of New Zealand)
*
* *
☆
0 :
K) 40km
0
20 40 mi
^Atafu
South Pacific Ocean
i 1
Nukunonu''^--
Fakaofo ''''
I n t rod it c t i 0 n
Background: Originally settled by Polynesian
emigrants from surrounding island groups, the
Tokelau Islands were made a British protectorate in
1889. They were transferred to New Zealand
administration in 1925.
r GeoTgTrphT™''
Location: Oceania, group of firee islands in the
South Pacific Ocean, about one-half of the way from
Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
fofa/;10sqkm
/arrd.''IOsqkm
wafer; 0 sq km
Area - comparative: about 17 times the size of The
Mall in Washington, DC
Land boundaries; 0 km
Coastline; 101 km
Maritime claims;
exclusive economic zone: 200 nm
ferr;''for/a/sea:12nm
Climate: tropical; moderated by trade winds (April to
November)
Terrain: low-lying coral atolls enclosing large
lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other; 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards; lies in Pacific typhoon belt
Environment - current issues: very limited natural
resources and overcrowding are contributing to
emigration to New Zealand
I People
Population; 1 ,458 (July 2000 est.)
Age structure;
0-14 years: NA
15-64 years: NA
65 years and over: HA
Population growth rate: -0.89% (2000 est.)
Birth rate; NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noon; Tokelauan(s)
adjf''ecf/ve.''Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages; Tokelauan (a Polynesian language),
English
17 " ~ Gov eTn in e~n t
Country name:
conventional long form: none
conventional short form: Tokelau
Data code: TL
Dependency status; territory of New Zealand;
note - Tokelauans are drafting a constitution,
developing institutions and patterns of
self-government as Tokelau moves toward free
association with Wellington
Government type: NA
Capital; none; each atoll has its own administrative
center
Administrative divisions; none (territory of New
Zealand)
Independence: none (territory of New Zealand)
National holiday: Waitangi Day, 6 February (1840)
(Treaty of Waitangi established British sovereignty
over New Zealand)
Constitution: administered under the Tokelau
Islands Act of 1948, as amended in 1970
Legal system: British and local statutes
Suffrage: 21 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1 952); the UK and New Zealand are represented by
Administrator Lindsay WATT (since NA March 1993)
head of government: AW\\ Faipule FALIMATEAO
(since NA 1997)
493
Tokelau (continued)
cabinet: the Council of Faipule, consisting of three
elected leaders, one from each atoll; functions as a
cabinet
elections: none; the monarch is hereditary;
administrator appointed by the Minister of Foreign
Affairs and Trade in New Zealand; the head of
government is chosen from the Council of Faipule and
serves a one-year term
Legislative branch: unicameral General Fono (45
seats - 15 from each of the three atolls; members
chosen by each atoll''s Council of Elders or Taupulega
to serve three-year terms); note - the Tokelau
Amendment Act of 1996 confers legislative power on
the General Fono
Judicial branch: Supreme Court in New Zealand
exercises civil and criminal jurisdiction
Political parties and leaders: none
International organization participation: SPC,
WHO (associate)
Diplomatic representation in the US: none
(territory of New Zealand)
Diplomatic representation from the US: none
(territory of New Zealand)
Flag description: the flag of New Zealand is used
Railways: 0 km
Highways:
total: NA km
paved: NA km
unpaved: NA km
Ports and harbors: none; offshore anchorage only
Merchant marine: none (1999 est.)
Airports: none; lagoon landings by amphibious
aircraft from Samoa','ca474c0c7fdb7aee1f06d23440da5d5180da662cfed7a6bbcdeb87cee8f074e7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba273bd6b1ca5c9cf3ddff45d5ce55ea176bfdb00faf8177faabc80b8a57aa7',2000,'OM','Oman','transportation',469,'Railways: 0 km
Highways:
total: 1 ,088 km
paved; 1,088 km
unpaved: 0 km (1 998 est.)
Pipelines: crude oil 830 km; natural gas, including
natural gas liquids, 870 km
Ports and harbors: ''Ajman, Al Fujayrah, Das Island,
Khawr Fakkan, Mina'' Jabal ''Ali, Mina'' Khalid, Mina''
Rashid, Mina'' Saqr, Mina'' Zayid, Umm al Qaywayn
Merchant marine:
total: 68 ships (1 ,000 GRT or over) totaling 1 ,107,442
GRT/1 ,795,235 DWT
ships by type: bulk 1 , cargo 1 8, chemical tanker 3,
container 8, liquified gas 1 , livestock carrier 1 ,
passenger 1 , petroleum tanker 27, roll-on/roll-off 7,
specialized tanker 1 (1999 est.)
Airports: 40 (1999 est.)
Airports - with paved runways:
total: 22
over 3,047 m: 8
2,438 to 3,047 m: 3
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 4 [1999 est.)
Airports - with unpaved runways:
tofa/;18
over 3,047 m:1
2,438 to 3,047 m:1
1,524 to 2,437 m: 4
914 to 1,523 m: 9
under 914 m: 3 (1 999 est.)
Heliports: 2 (1999 est.)
f i t a Fy —
Military branches: Army, Navy, Air Force, Air
Defense, paramilitary (includes Federal Police Force)
Military manpower - military age: 1 8 years of age
Military manpower - availability:
males age 15-49: 785,253
note: includes non-nationals (2000 est.)
Military manpower - fit for military service:
males age 15-49: 422,826 (2000 est.)
Military manpower - reaching military age
annually:
ma/es; 24,506 (2000 est.)
Military expenditures - dollar figure: $2.1 billion
(FY99)
Military expenditures - percent of GDP: 4.8%
(FY99)
f t r a n s n a 1 1 0 n a I I s s u”e s
Disputes • international: location and status of
boundary with Saudi Arabia is not final, de facto
boundary reflects 1974 agreement; no defined
boundary with most of Oman, but Administrative Line
in far north; claims two islands in the Persian Gulf
occupied by Iran; LesserTunb (called Tunb as Sughra
In Arabic by UAE and Jazireh-ye Tonb-e Kuchek in
Persian by Iran) and Greater Tunb (called Tunb al
Kubra in Arabic by UAE and Jazireh-ye Tonb-e
Bozorg in Persian by Iran); claims island in the
Persian Gulf jointly administered with Iran (called Abu
Musa in Arabic by UAE and Jazireh-ye Abu Musa in
Persian by Iran) - over which Iran has taken steps to
exert unilateral control since 1992, including access
restrictions and a military build-up on the island; the
UAE has garnered significant diplomatic support in
the region in protesting these Iranian actions
Illicit drugs: growing role as heroin transshipment
and money-laundering center due to its proximity to
southwest Asian producing countries and the bustling
free trade zone in Dubai','bd3747d24b8b67dc16d049f1bb80c06293505f709a3e561bdedf258f409459ea','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf8ef700bf466c11800206b44d13c8c41fcdad071c7507d5f50e4b527c6da987',2000,'GB','United Kingdom','transportation',470,'I n t r 0 d u c t i o n
Background: Great Britain, the dominant industrial
and maritime power of the 1 9th century, played a
leading role in developing parliamentary democracy
and in advancing literature and science. At its zenith,
the British Empire stretched over one-fourth of the
earth''s surface. The first half of the 20th century saw
the UK''s strength seriously depleted in two World
Wars, The second half witnessed the dismantling of
the Empire and the UK rebuilding itself into a modern
and prosperous European nation. The UK currently Is
weighing the degree of its integration with continental
Europe. A member of the EU, it chose to remain
outside of the EMU for the time being. Constitutional
reform is also a significant issue in the UK. Regional
assemblies with varying degrees of power opened in
Scotland, Wales, and Northern Ireland in 1999.
f" Geography’
Location: Western Europe, islands including the
northern one-sixth of the island of Ireland between the
North Atlantic Ocean and the North Sea, northwest of','66d2e7e6e19b9bb49d2f37fae22d1dd9be77bff90ffd312bc2800a2cd9e09ee1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da90b246750b098acbf37e5b61396568aa33eab1cd53d8e2254cf3968e6b578d',2000,'VU','Vanuatu','transportation',475,'Railways; 0 km
Highways:
total: 1 ,070 km
paved: 256 km
unpaved: 814 km (1996 est.)
Ports and harbors: Forari, Port-Vila, Santo (Espiritu
Santo)
Merchant marine:
total: 78 ships (1 ,000 GRT or over) totaling 1 ,266,634
GRT/1 ,61 8,877 DWT
ships by type: bulk 27, cargo 24, chemical tanker 3,
combination bulk 2, container 1 , liquified gas 4,
petroleum tanker 2, refrigerated cargo 9, vehicle
carrier 6 (1999 est.)
note: a flag of convenience registry; includes ships
from 15 countries among which are ships of Japan 28,
India 10, US 10, Greece 3, Hong Kong 3, Australia 2,
Canada 1 , China 1 , and France 1 (1998 est.)
Airports: 32 (1999 est.)
Airports - with paved runways;
total: 3
2,438 to 3,047 m:1
1,524 to 2,437 m:1
914 to 1,523 m:1 (1999 est.)
Airports - with unpaved runways:
total: 29
1,524 to 2,437 m:1
914 to 1,523 m: 11
under 914 m: 17 (1999 est.)
Railways:
total: 584 km (248 km privately owned)
standard gauge: 564 km 1.435-m gauge
Highways:
total: 96,155 km
paved: 32,308 km
unpaved: 63,647 km (1997 est.)
Waterways: 7,100 km; Rio Orinoco and Lago de
Maracaibo accept oceangoing vessels
Pipelines: crude oil 6,370 km; petroleum products
480 km; natural gas 4,010 km
Ports and harbors: Amuay, Bajo Grande, El
Tablazo, La Guaira, La Salina, Maracaibo, Matanzas,
Palua, Puerto Cabello, Puerto la Cruz, Puerto Ordaz,
Puerto Sucre, Punta Cardon
532
Venezuela (continued)
Merchant marine;
total: 34 ships (1 ,000 GRJ or over) totaling 488,584
GRT/888,764 DWT
ships by type: bulk 5, cargo 10, combination bulk 1 ,
liquified gas 2, passenger/cargo 1 , petroleum tanker
7, roll-on/roll-off 7, short-sea passenger 1 (1999 est.)
Airports: 366 (1999 est.)
Airports - with paved runways:
total: t22
over 3,047 m: 5
2,438 to 3,047 m: to
1,524 to 2,437 m: 32
914 to 1,523 m: 53
under 914 m: 17 (1 999 est.)
Airports - with unpaved runways:
total: 244
1,524 to 2,437 m: 10
914 to 1,523 m: 93
under 914 m: 141 (1999 est.)
Heliports: 1 (1 999 est.)','32911f6f2f3b81c2a9d7f14479f6e6236e5ab175f79c96f4cf7a711509c224a2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b62af315671000f0208c7f355230dbb54d9a1f99e006cfd3f3321e27eaa2199',2000,'MP','Northern Mariana Islands','transportation',485,'Ports and harbors: none; two offshore anchorages
for large ships
Airports: 1 (1999 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:-{ (1999 est.)
Transportation - note: formerly an importanf
commercial aviation base, now occasionally used by
US military, some commercial cargo planes, and for
emergency landings','41542576d692440ffc8a594b96a567cb06823fc0e14a2e175cf7fe1043e3e9a8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6915e617182eb2397c631b2529757fb39165ba3b5b1c7c086d7ce03502c2151',2000,'KG','Kyrgyzstan','terrorism',140,'@Kyrgyzstan:Geography
Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent States
Area:
total: 198,500 sq km
land: 191,300 sq km
water: 7,200 sq km
Area - comparative: slightly smaller than South Dakota
Land boundaries:
total: 3,878 km
border countries: China 858 km, Kazakhstan 1,051 km, Tajikistan 870
km, Uzbekistan 1,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan; subtropical in
southwest (Fergana Valley); temperate in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys and basins
encompass entire nation
Elevation extremes:
lowest point: Kara-Darya 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydropower; significant deposits of gold
and rare earth metals; locally exploitable coal, oil, and natural gas;
other deposits of nepheline, mercury, bismuth, lead, and zinc
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 44%
forests and woodland: 4%
other: 45% (1993 est.)
note: Kyrgyzstan has the world''s largest natural growth walnut forest
Irrigated land: 9,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: water pollution; many people get their
water directly from contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil salinity from
faulty irrigation practices
Environment - international agreements:
party to: Biodiversity, Desertification, Hazardous Wastes
signed, but not ratified: none of the selected agreements
Geography - note: landlocked
@Kyrgyzstan:People
Population: 4,685,230 (July 2000 est.)
Age structure:
0-14 years: 36% (male 843,038; female 825,519)
15-64 years: 58% (male 1,337,268; female 1,393,397)
65 years and over: 6% (male 107,405; female 178,603) (2000 est.)
Population growth rate: 1.43% (2000 est.)
Birth rate: 26.29 births/1,000 population (2000 est.)
Death rate: 9.15 deaths/1,000 population (2000 est.)
Net migration rate: -2.81 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 77.08 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 63.37 years
male: 59.06 years
female: 67.9 years (2000 est.)
Total fertility rate: 3.22 children born/woman (2000 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kirghiz 52.4%, Russian 18%, Uzbek 12.9%, Ukrainian
2.5%, German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%, other 5%
Languages: Kirghiz (Kyrgyz) - official language, Russian - official
language
note: in March 1996, the Kyrgyzstani legislature amended the
constitution to make Russian an official language, along with Kirghiz,
in territories and work places where Russian-speaking citizens
predominate
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
@Kyrgyzstan:Government
Country name:
conventional long form: Kyrgyz Republic
conventional short form: Kyrgyzstan
local long form: Kyrgyz Respublikasy
local short form: none
former: Kirghiz Soviet Socialist Republic
Data code: KG
Government type: republic
Capital: Bishkek
Administrative divisions: 6 oblastlar (singular - oblast) and 1 city*
(singular - shaar); Bishkek Shaary*, Chuy Oblasty (Bishkek),
Jalal-Abad Oblasty, Naryn Oblasty, Osh Oblasty, Talas Oblasty,
Ysyk-Kol Oblasty (Karakol)
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center name
following in parentheses)
Independence: 31 August 1991 (from Soviet Union)
National holiday: National Day, 2 December; Independence Day, 31
August (1991)
Constitution: adopted 5 May 1993
note: amendment proposed by President AKAYEV and passed in a national
referendum on 10 February 1996 significantly expands the powers of the
president at the expense of the legislature
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Askar AKAYEV (since 28 October 1990)
head of government: Prime Minister Jumabek IBRAIMOV (since NA December
1998)
cabinet: Cabinet of Ministers appointed by the president on the
recommendation of the prime minister
elections: president elected by popular vote for a five-year term;
elections last held 24 December 1995 (next to be held November or
December 2000); prime minister appointed by the president
election results: Askar AKAYEV reelected president; percent of vote -
Askar AKAYEV 75%; note - elections were held early which gave the two
opposition candidates little time to campaign; AKAYEV may have
orchestrated the "deregistration" of two other candidates, one of whom
was a major rival
Legislative branch: bicameral Supreme Council or Zhogorku Kenesh
consists of the Assembly of People''s Representatives (70 seats;
members are elected by popular vote to serve five-year terms) and the
Legislative Assembly (35 seats; members are elected by popular vote to
serve five-year terms)
elections: Assembly of People''s Representatives - last held 5 February
1995 (next to be held 20 February 2000); Legislative Assembly - last
held 5 February 1995 (next to be held 20 February 2000)
election results: Assembly of People''s Representatives - percent of
vote by party - NA; seats by party - NA; note - not all of the 70
seats were filled at the 5 February 1995 elections; as a result,
run-off elections were held at later dates; the assembly meets twice
yearly; Legislative Assembly - percent of vote by party - NA; seats by
party - NA; note - not all of the 35 seats were filled at the 5
February 1995 elections; as a result, run-off elections were held at
later dates
note: the legislature became bicameral for the 5 February 1995
elections
Judicial branch: Supreme Court, judges are appointed for 10-year terms
by the Supreme Council on recommendation of the president;
Constitutional Court; Higher Court of Arbitration
Political parties and leaders: Agrarian Party ; Agrarian
Party of Kyrgyzstan ; Banner National Revival Party or
ASABA ; Communist Party of Kyrgyzstan or PKK
; Democratic Movement of Kyrgyzstan or
DDK ; Dignity Party ;
Fatherland or Alta Mekel Party ; Justice Party
; Kyrgyzstan Erkin Party (Democratic Movement of
Free Kyrgyzstan) or ErK ; Movement for the
People''s Salvation ; Mutual Help Movement or
Ashar ; National Unity Democratic Movement or DDNE
; Peasant Party ; Republican Popular
Party of Kyrgyzstan ; Social Democratic Party or
PSD
Political pressure groups and leaders: Council of Free Trade Unions;
Kyrgyz Committee on Human Rights ; National Unity
Democratic Movement; Union of Entrepreneurs
International organization participation: AsDB, CIS, EAPC, EBRD, ECE,
ECO, ESCAP, FAO, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO,
IMF, Intelsat, Interpol, IOC, IOM (observer), ISO (correspondent),
ITU, NAM (observer), OIC, OPCW, OSCE, PCA, PFP, UN, UNAMSIL, UNCTAD,
UNESCO, UNIDO, UNMIK, UPU, WFTU, WHO, WIPO, WMO, WToO, WTrO, WTrO
(applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Bakyt ABDRISAYEV
chancery: 1732 Wisconsin Avenue NW, Washington, DC 20007
telephone: (202) 338-5141
FAX: (202) 338-5139
Diplomatic representation from the US:
chief of mission: Ambassador Anne M. SIGMUND
embassy: 171 Prospect Mira, 720016 Bishkek
mailing address: use embassy street address
telephone: (3312) 22-29-20, 22-27-77
FAX: (3312) 22-35-51
Flag description: red field with a yellow sun in the center having 40
rays representing the 40 Kirghiz tribes; on the obverse side the rays
run counterclockwise, on the reverse, clockwise; in the center of the
sun is a red ring crossed by two sets of three lines, a stylized
representation of the roof of the traditional Kirghiz yurt
@Kyrgyzstan:Economy
Economy - overview: Kyrgyzstan is a small, poor, mountainous country
with a predominantly agricultural economy. Cotton, wool, and meat are
the main agricultural products and exports. Industrial exports include
gold, mercury, uranium, and electricity. Kyrgyzstan has been one of
the most progressive countries of the former Soviet Union in carrying
out market reforms. Following a successful stabilization program,
which lowered inflation from 88% in 1994 to 15% for 1997, attention is
turning toward stimulating growth. Much of the government''s stock in
enterprises has been sold. Drops in production had been severe since
the breakup of the Soviet Union in December 1991, but by mid-1995
production began to recover and exports began to increase. Pensioners,
unemployed workers, and government workers with salary arrears
continue to suffer. Foreign assistance played a substantial role in
the country''s economic turnaround in 1996-97. The government has
adopted a series of measures to combat such severe problems as
excessive external debt, inflation, inadequate revenue collection, and
the spillover from Russia''s economic disorders. Kyrgyzstan had
moderate growth in 1999 of 3.4% with a similar rate expected for 2000.
GDP: purchasing power parity - $10.3 billion (1999 est.)
GDP - real growth rate: 3.4% (1999 est.)
GDP - per capita: purchasing power parity - $2,300 (1999 est.)
GDP - composition by sector:
agriculture: 45%
industry: 20%
services: 35% (1999 est.)
Population below poverty line: 40% (1993 est.)
Household income or consumption by percentage share:
lowest 10%: 2.7%
highest 10%: 26.2% (1993)
Inflation rate (consumer prices): 37% (1999 est.)
Labor force: 1.7 million
Labor force - by occupation: agriculture and forestry 55%, industry
15%, services 30% (1999 est.)
Unemployment rate: 6% (1998 est.)
Budget:
revenues: $225 million
expenditures: $308 million, including capital expenditures of $11
million (1996 est.)
Industries: small machinery, textiles, food processing, cement, shoes,
sawn logs, refrigerators, furniture, electric motors, gold, rare earth
metals
Industrial production growth rate: -3.4% (1999 est.)
Electricity - production: 12.206 billion kWh (1998)
Electricity - production by source:
fossil fuel: 10.78%
hydro: 89.22%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 11.102 billion kWh (1998)
Electricity - exports: 1.1 billion kWh (1998)
Electricity - imports: 850 million kWh (1998)
Agriculture - products: tobacco, cotton, potatoes, vegetables, grapes,
fruits and berries; sheep, goats, cattle, wool
Exports: $515 million (1999 est.)
Exports - commodities: cotton, wool, meat, tobacco; gold, mercury,
uranium, hydropower; machinery; shoes
Exports - partners: Germany 37%, Kazakhstan 17%, Russia 16%,
Uzbekistan 8%, China 3% (1998)
Imports: $590 million (1999 est.)
Imports - commodities: oil and gas, machinery and equipment,
foodstuffs
Imports - partners: Russia 24%, Uzbekistan 14%, Kazakhstan 9%, Germany
6%, China 5% (1998)
Debt - external: $1.1 billion (1999 est.)
Economic aid - recipient: $329.4 million (1995)
Currency: 1 Kyrgyzstani som (KGS) = 100 tyiyn
Exchange rates: soms (KGS) per US$1 - 46.235 (January 2000), 39.008
(1999), 20.838 (1998), 17.362 (1997), 12.810 (1996), 10.822 (1995)
Fiscal year: calendar year
@Kyrgyzstan:Communications
Telephones - main lines in use: 357,000 (1995)
Telephones - mobile cellular: NA
Telephone system: poorly developed; about 100,000 unsatisfied
applications for household telephones
domestic: principally microwave radio relay; one cellular provider,
probably limited to Bishkek region
international: connections with other CIS countries by landline or
microwave radio relay and with other countries by leased connections
with Moscow international gateway switch and by satellite; satellite
earth stations - 1 Intersputnik and 1 Intelsat; connected
internationally by the Trans-Asia-Europe (TAE) fiber-optic line
Radio broadcast stations: AM 12 (plus 10 repeater stations), FM 14,
shortwave 2 (1998)
Radios: 520,000 (1997)
Television broadcast stations: NA (repeater stations throughout the
country relay programs from Russia, Uzbekistan, Kazakhstan, and
Turkey) (1997)
Televisions: 210,000 (1997)
Internet Service Providers (ISPs): NA
@Kyrgyzstan:Transportation
Railways:
total: 370 km in common carrier service; does not include industrial
lines
broad gauge: 370 km 1.520-m gauge (1990)
Highways:
total: 18,500 km
paved: 16,854 km (including 140 km of expressways)
unpaved: 1,646 km (1996 est.)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or Rybach''ye)
Airports: 54 (1994 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 9
under 914 m: 1 (1994 est.)
Airports - with unpaved runways:
total: 40
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 32 (1994 est.)
@Kyrgyzstan:Military
Military branches: Army, Air and Air Defense, Security Forces
(internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,172,899 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 951,395 (2000 est.)
Military manpower - reaching military age annually:
males: 48,551 (2000 est.)
Military expenditures - dollar figure: $12 million (FY99)
Military expenditures - percent of GDP: 1% (FY99)
@Kyrgyzstan:Transnational Issues
Disputes - international: territorial dispute with Tajikistan on
southwestern boundary in Isfara Valley area; periodic target of
Islamic terrorists from Uzbekistan and Tajikistan
Illicit drugs: limited illicit cultivator of cannabis and opium poppy,
mostly for CIS consumption; limited government eradication program;
increasingly used as transshipment point for illicit drugs to Russia
and Western Europe from Southwest Asia
______________________________________________________________________
LAOS
@Laos:Introduction
Background: In 1975 the communist Pathet Lao took control of the
government, ending a six-century-old monarchy. Initial closer ties to
Vietnam and socialization were replaced with a gradual return to
private enterprise, an easing of foreign investment laws, and the
admission into ASEAN in 1997.
@Laos:Geography
Location: Southeastern Asia, northeast of Thailand, west of Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area - comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km, China 423 km,
Thailand 1,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to November); dry season
(December to April)
Terrain: mostly rugged mountains; some plains and plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum, tin, gold, gemstones
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
other: 40% (1993 est.)
Irrigated land: 1,250 sq km (1993 est.)
note: rainy season irrigation - 2,169 sq km; dry season irrigation -
750 sq km (1998 est.)
Natural hazards: floods, droughts, and blight
Environment - current issues: unexploded ordnance; deforestation; soil
erosion; a majority of the population does not have access to potable
water
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Environmental
Modification, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography - note: landlocked
@Laos:People
Population: 5,497,459 (July 2000 est.)
Age structure:
0-14 years: 43% (male 1,191,608; female 1,173,144)
15-64 years: 54% (male 1,447,788; female 1,500,016)
65 years and over: 3% (male 85,028; female 99,875) (2000 est.)
Population growth rate: 2.5% (2000 est.)
Birth rate: 38.29 births/1,000 population (2000 est.)
Death rate: 13.35 deaths/1,000 population (2000 est.)
Net migration rate: 0 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 94.8 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 53.09 years
male: 51.22 years
female: 55.02 years (2000 est.)
Total fertility rate: 5.21 children born/woman (2000 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao Theung (upland) 22%, Lao
Soung (highland) including the Hmong ("Meo") and the Yao (Mien) 9%,
ethnic Vietnamese/Chinese 1%
Religions: Buddhist 60% (in October 1999, the regime proposed a
constitutional amendment making Buddhism the state religion; the
National Assembly is expected to vote on the amendment sometime in
2000), animist and other 40%
Languages: Lao (official), French, English, and various ethnic
languages
Literacy:
definition: age 15 and over can read and write
total population: 57%
male: 70%
female: 44% (1999 est.)
@Laos:Government
Country name:
conventional long form: Lao People''s Democratic Republic
conventional short form: Laos
local long form: Sathalanalat Paxathipatai Paxaxon Lao
local short form: none
Data code: LA
Government type: Communist state
Capital: Vientiane
Administrative divisions: 16 provinces (khoueng, singular and plural),
1 municipality* (kampheng nakhon, singular and plural), and 1 special
zone** (khetphiset, singular and plural); Attapu, Bokeo, Bolikhamxai,
Champasak, Houaphan, Khammouan, Louangnamtha, Louangphabang, Oudomxai,
Phongsali, Salavan, Savannakhet, Viangchan*, Viangchan, Xaignabouli,
Xaisomboun**, Xekong, Xiangkhoang
Independence: 19 July 1949 (from France)
National holiday: National Day, 2 December (1975) (proclamation of the
Lao People''s Democratic Republic)
Constitution: promulgated 14 August 1991
Legal system: based on traditional customs, French legal norms and
procedures, and Socialist practice
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President KHAMTAI Siphandon (since 26 February 1998);
note - currently the position of vice president is vacant; Vice
President OUDOM Khattiya died on 9 December 1999 and a replacement has
not yet been named
head of government: Prime Minister SISAVAT Keobounphan (since 26
February 1998); Senior Deputy Prime Minister BOUN-NHANG Vorachith
(since 20 April 1996); Deputy Prime Ministers CHOUMMALI Saygnasone
(since 26 February 1998), SOMSAVAT Lengsavad (since 26 February 1998)
cabinet: Council of Ministers appointed by the president, approved by
the National Assembly
elections: president elected by the National Assembly for a five-year
term; election last held 21 December 1997 (next to be held NA 2002);
prime minister appointed by the president with the approval of the
National Assembly for a five-year term
election results: KHAMTAI Siphandon elected president; percent of
National Assembly vote - NA
Legislative branch: unicameral National Assembly (99 seats; members
elected by popular vote to serve five-year terms; note - by
presidential decree, on 27 October 1997, the number of seats increased
from 85 to 99)
elections: last held 21 December 1997 (next to be held NA 2002)
election results: percent of vote by party - NA; seats by party - LPRP
or LPRP-approved (independent, non-party members) 99
Judicial branch: People''s Supreme Court, the president of the People''s
Supreme Court is elected by the National Assembly on the
recommendation of the National Assembly Standing Committee, the vice
president of the People''s Supreme Court and the judges are appointed
by the National Assembly Standing Committee
Political parties and leaders: Lao People''s Revolutionary Party or
LPRP ; other parties proscribed
Political pressure groups and leaders: noncommunist political groups
proscribed; most opposition leaders fled the country in 1975
International organization participation: ACCT, AsDB, ASEAN, CP,
ESCAP, FAO, G-77, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF,
Intelsat (nonsignatory user), Interpol, IOC, ITU, NAM, OPCW, PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WToO, WTrO
(observer)
Diplomatic representation in the US:
chief of mission: Ambassador VANG Rattanavong
chancery: 2222 S Street NW, Washington, DC 20008
telephone: (202) 332-6416
FAX: (202) 332-4923
Diplomatic representation from the US:
chief of mission: Ambassador Wendy Jean CHAMBERLIN
embassy: Rue Bartholonie, B. P. 114, Vientiane
mailing address: American Embassy, Box V, APO AP 96546
telephone: (21) 212581, 212582, 212585
FAX: (21) 212584
Flag description: three horizontal bands of red (top), blue (double
width), and red with a large white disk centered in the blue band
@Laos:Economy
Economy - overview: The government of Laos - one of the few remaining
official communist states - began decentralizing control and
encouraging private enterprise in 1986. The results, starting from an
extremely low base, were striking - growth averaged 7% in 1988-96.
Since mid-1996, however, reform efforts have slowed, and the economy
has suffered as a result. Because Laos depends heavily on its trade
with Thailand, it was further damaged by the regional financial crisis
beginning in 1997. From June 1997 to June 1999 the Lao kip lost 87%,
and reached a crisis point in September 1999 when it fluctuated
wildly, falling from 3,500 kip to the dollar to 9,000 kip to the
dollar in a matter of weeks. Now that the currency has stabilized,
however, the government seems content to let the current situation
persist, despite 140% inflation in 1999 and limited foreign exchange
reserves. A landlocked country with a primitive infrastructure, Laos
has no railroads, a rudimentary road system, and limited external and
internal telecommunications. Electricity is available in only a few
urban areas. Subsistence agriculture accounts for half of GDP and
provides 80% of total employment. For the foreseeable future the
economy will continue to depend on aid from the IMF and other
international sources; Japan is currently the largest bilateral aid
donor; aid from the former USSR/Eastern Europe has been cut sharply.
As in many developing countries, deforestation and soil erosion will
hamper efforts to attain a high rate of GDP growth.
GDP: purchasing power parity - $7 billion (1999 est.)
GDP - real growth rate: 5.2% (1999 est.)
GDP - per capita: purchasing power parity - $1,300 (1999 est.)
GDP - composition by sector:
agriculture: 51%
industry: 22%
services: 27% (1999 est.)
Population below poverty line: 46.1% (1993 est.)
Household income or consumption by percentage share:
lowest 10%: 4.2%
highest 10%: 26.4% (1992)
Inflation rate (consumer prices): 140% (1999 est.)
Labor force: 1 million - 1.5 million
Labor force - by occupation: agriculture 80% (1997 est.)
Unemployment rate: 5.7% (1997 est.)
Budget:
revenues: $202.7 million
expenditures: $385.1 million, including capital expenditures of $NA
(FY97/98 est.)
Industries: tin and gypsum mining, timber, electric power,
agricultural processing, construction, garments
Industrial production growth rate: 7.5% (1999 est.)
Electricity - production: 1.34 billion kWh (1998)
Electricity - production by source:
fossil fuel: 2.99%
hydro: 97.01%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 514 million kWh (1998)
Electricity - exports: 782 million kWh (1998)
Electricity - imports: 50 million kWh (1998)
Agriculture - products: sweet potatoes, vegetables, corn, coffee,
sugarcane, tobacco, cotton; tea, peanuts, rice; water buffalo, pigs,
cattle, poultry
Exports: $271 million (f.o.b., 1999 est.)
Exports - commodities: wood products, garments, electricity, coffee,
tin
Exports - partners: Vietnam, Thailand, Germany, France, Belgium
Imports: $497 million (f.o.b., 1999 est.)
Imports - commodities: machinery and equipm','55b5cc2db06a1300dea5f411238390120ad807080fe78d4e3a02bb2570726a48','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('149faa596edbc3c0674ec495685734a29a54bcc22d18459865c18ec67017ea53',2000,'KG','Kyrgyzstan','terrorism',141,'ent, vehicles, fuel
Imports - partners: Thailand, Japan, Vietnam, China, Singapore, Hong
Kong
Debt - external: $2.32 billion (1997 est.)
Economic aid - recipient: $345 million (1999 est.)
Currency: 1 new kip (NK) = 100 at
Exchange rates: new kips (NK) per US$1 - 7,674.00 (January
2000),7,102.03 (1999), 3,298.33 (1998), 1,259.98 (1997), 921.02
(1996), 804.69 (1995)
note: as of September 1995, a floating exchange rate policy was
adopted
Fiscal year: 1 October - 30 September
@Laos:Communications
Telephones - main lines in use: 20,000 (1995)
Telephones - mobile cellular: 1,600 (1997)
Telephone system: service to general public is poor but improving,
with over 20,000 telephones currently in service and an additional
48,000 expected by 2001; the government relies on a radiotelephone
network to communicate with remote areas
domestic: radiotelephone communications
international: satellite earth station - 1 Intersputnik (Indian Ocean
region)
Radio broadcast stations: AM 12, FM 1, shortwave 4 (1998)
Radios: 730,000 (1997)
Television broadcast stations: 4 (1999)
Televisions: 52,000 (1997)
Internet Service Providers (ISPs): NA
@Laos:Transportation
Railways: 0 km
Highways:
total: 21,716 km
paved: 9,673.5 km
unpaved: 12,042.5 km (1998 est.)
Waterways: about 4,587 km, primarily Mekong and tributaries; 2,897
additional km are sectionally navigable by craft drawing less than 0.5
m
Pipelines: petroleum products 136 km
Ports and harbors: none
Merchant marine:
total: 1 ship (1,000 GRT or over) totaling 2,370 GRT/3,000 DWT
ships by type: cargo 1 (1999 est.)
Airports: 52 (1999 est.)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 4 (1999 est.)
Airports - with unpaved runways:
total: 43
1,524 to 2,437 m: 1
914 to 1,523 m: 17
under 914 m: 25 (1999 est.)
@Laos:Military
Military branches: Lao People''s Army (LPA; includes militia element),
Lao People''s Navy (LPN; includes riverine element), Air Force,
National Police Department
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,275,184 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 686,803 (2000 est.)
Military manpower - reaching military age annually:
males: 62,243 (2000 est.)
Military expenditures - dollar figure: $77 million (FY96/97)
Military expenditures - percent of GDP: 4.2% (FY96/97)
@Laos:Transnational Issues
Disputes - international: parts of the border with Thailand are
indefinite
Illicit drugs: world''s third-largest illicit opium producer (estimated
cultivation in 1999 - 21,800 hectares, a 16% decrease over 1998;
estimated potential production in 1999 - 140 metric tons, about the
same as in 1998); potential heroin producer; transshipment point for
heroin and methamphetamines produced in Burma; illicit producer of
cannabis
______________________________________________________________________','46dab32f6587cbb99937e195d15ef7834f7e108d5de639ecf185a5de77974fba','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10a927a1737f8fd9a9e84e13999290359f296a3c6a11db9b72920aa272f46b12',2000,'LV','Latvia','terrorism',142,'@Latvia:Introduction
Background: After a brief period of independence between the two World
Wars, Latvia was annexed by the USSR in 1940. It reestablished its
independence in 1991 following the breakup of the Soviet Union.
Although the last Russian troops left in 1994, the status of the
Russian minority (some 30% of the population) remains of concern to
Moscow. Latvia continues to revamp its economy for eventual
integration into various Western European political and economic
institutions.
@Latvia:Geography
Location: Eastern Europe, bordering the Baltic Sea, between Estonia
and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area:
total: 64,589 sq km
land: 64,589 sq km
water: 0 sq km
Area - comparative: slightly larger than West Virginia
Land boundaries:
total: 1,150 km
border countries: Belarus 141 km, Estonia 339 km, Lithuania 453 km,
Russia 217 km
Coastline: 531 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Gaizinkalns 312 m
Natural resources: minimal; amber, peat, limestone, dolomite,
hydropower, arable land
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 46%
other: 14% (1993 est.)
Irrigated land: 160 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: air and water pollution because of a
lack of waste conversion equipment; Gulf of Riga and Daugava River
heavily polluted; contamination of soil and groundwater with chemicals
and petroleum products at military bases
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change, Endangered
Species, Hazardous Wastes, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent Organic Pollutants,
Climate Change-Kyoto Protocol
@Latvia:People
Population: 2,404,926 (July 2000 est.)
Age structure:
0-14 years: 17% (male 212,483; female 203,417)
15-64 years: 68% (male 777,289; female 849,967)
65 years and over: 15% (male 116,575; female 245,195) (2000 est.)
Population growth rate: -0.84% (2000 est.)
Birth rate: 7.8 births/1,000 population (2000 est.)
Death rate: 14.88 deaths/1,000 population (2000 est.)
Net migration rate: -1.32 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.85 male(s)/female (2000 est.)
Infant mortality rate: 15.71 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 68.41 years
male: 62.48 years
female: 74.62 years (2000 est.)
Total fertility rate: 1.13 children born/woman (2000 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 56.5%, Russian 30.4%, Byelorussian 4.3%,
Ukrainian 2.8%, Polish 2.6%, other 3.4%
Religions: Lutheran, Roman Catholic, Russian Orthodox
Languages: Lettish (official), Lithuanian, Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 99% (1989 est.)
@Latvia:Government
Country name:
conventional long form: Republic of Latvia
conventional short form: Latvia
local long form: Latvijas Republika
local short form: Latvija
former: Latvian Soviet Socialist Republic
Data code: LG
Government type: parliamentary democracy
Capital: Riga
Administrative divisions: 26 counties (singular - rajons) and 7
municipalities*: Aizkraukles Rajons, Aluksnes Rajons, Balvu Rajons,
Bauskas Rajons, Cesu Rajons, Daugavpils*, Daugavpils Rajons, Dobeles
Rajons, Gulbenes Rajons, Jekabpils Rajons, Jelgava*, Jelgavas Rajons,
Jurmala*, Kraslavas Rajons, Kuldigas Rajons, Leipaja*, Liepajas
Rajons, Limbazu Rajons, Ludzas Rajons, Madonas Rajons, Ogres Rajons,
Preilu Rajons, Rezekne*, Rezeknes Rajons, Riga*, Rigas Rajons, Saldus
Rajons, Talsu Rajons, Tukuma Rajons, Valkas Rajons, Valmieras Rajons,
Ventspils*, Ventspils Rajons
Independence: 6 September 1991 (from Soviet Union)
National holiday: Independence Day, 18 November (1918)
Constitution: the 1991 Constitutional Law which supplements the 1922
constitution, provides for basic rights and freedoms
Legal system: based on civil law system
Suffrage: 18 years of age; universal for Latvian citizens
Executive branch:
chief of state: President Vaira VIKE-FREIBERGA (since 8 July 1999)
head of government: Prime Minister Andris BERZINS (since 5 May 2000)
cabinet: Council of Ministers nominated by the prime minister and
appointed by the Parliament
elections: president elected by Parliament for a four-year term
(amended from a three-year term on 4 December 1997); election last
held 17 June 1999 (next to be held by NA June 2003); prime minister
appointed by the president
election results: Vaira VIKE-FREIBERGA elected as a compromise
candidate in second phase of balloting, second round (after five
rounds in first phase failed); percent of parliamentary vote - Vaira
VIKE-FREIBERGA 53%, Valdis BIRKAVS 20%, Ingrida UDRE 9%
Legislative branch: unicameral Parliament or Saeima (100 seats;
members are elected by direct popular vote to serve four-year terms -
amended from three-year terms on 4 December 1997)
elections: last held 3 October 1998 (next to be held NA October 2002)
election results: percent of vote by party - People''s Party 21%, LC
18%, TSP 14%, TB/LNNK 14%, Social Democrats 13%, New Party 8%; seats
by party - People''s Party 24, LC 21, TSP 16, TB/LNNK 17, Social
Democrats 14, New Party 8
Judicial branch: Supreme Court, judges'' appointments are confirmed by
Parliament
Political parties and leaders: Anticommunist Union or PA [P.
MUCENIEKS]; Association of Latvian Social Democrats [Juris BOJARS,
Janis ADAMSONS]; Christian Democrat Union or LKDS ;
Christian People''s Party or KTP (formerly People''s Front of Latvia or
LTF) ; Democratic Party "Saimnieks" or DPS [Ziedonis
CEVERS, chairman]; For Fatherland and Freedom or TB ,
merged with LNNK; Green Party or LZP ; Latvian
Liberal Party or LLP ; Latvian National Conservative Party
or LNNK ; Latvian National Democratic Party or LNDP
; Latvian Social-Democratic Workers Party (Social
Democrats) or LSDSP ; Latvian Socialist Party or LSP
; Latvian Unity Party or LVP ;
Latvia''s Way or LC ; National Harmony Party or TSP
; New Party ; "Our Land" or MZ [M.
DAMBEKALNE]; Party for the Defense of Latvia''s Defrauded People
; Party of Russian Citizens or LKPP [V. SOROCHIN, V.
IVANOV]; Political Association of the Underprivileged or MPA [B.
PELSE, V. DIMANTS, J. KALNINS]; Political Union of Economists or TPA
; People''s Party
International organization participation: BIS, CBSS, CCC, CE, EAPC,
EBRD, ECE, EU (applicant), FAO, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA,
IFC, IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user), Interpol,
IOC, IOM (observer), ISO (correspondent), ITU, NSG, OAS (observer),
OPCW, OSCE, PFP, UN, UNCTAD, UNESCO, UNIDO, UPU, WEU (associate
partner), WHO, WIPO, WMO, WTrO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Aivis RONIS
chancery: 4325 17th Street NW, Washington, DC 20011
telephone: (202) 726-8213, 8214
FAX: (202) 726-6785
Diplomatic representation from the US:
chief of mission: Ambassador James H. HOLMES
embassy: Raina Boulevard 7, LV-1510, Riga
mailing address: American Embassy Riga, PSC 78, Box Riga, APO AE 09723
telephone: 721-0005
FAX: 782-0047
Flag description: three horizontal bands of maroon (top), white
(half-width), and maroon
@Latvia:Economy
Economy - overview: In 1999 Latvia, a transitional economy,
experienced zero GDP growth as it continued to feel the impact of the
August 1998 Russian financial crisis. Latvia officially joined the
World Trade Organization (WTrO) in February 1999 - the first Baltic
state to join - band was invited at the Helsinki EU Summit in December
1999 to begin accession talks in early 2000. Unemployment reached 9.6%
in 1999, up from 9.2% in 1998 and 6.7% in 1997. Privatization of large
state-owned utilities, especially the energy sector, faced more delays
in 1999, but is expected to accelerate in the next two years. Latvia
projects 3.5% GDP growth, 3% inflation, and a 2% fiscal deficit in
2000. Preparing for EU membership by 2003 remains a top foreign policy
priority.
GDP: purchasing power parity - $9.8 billion (1999 est.)
GDP - real growth rate: 0% (1999 est.)
GDP - per capita: purchasing power parity - $4,200 (1999 est.)
GDP - composition by sector:
agriculture: 8%
industry: 29%
services: 63% (1998)
Population below poverty line: NA%
Household income or consumption by percentage share:
lowest 10%: 4.3%
highest 10%: 22.1% (1993)
Inflation rate (consumer prices): 3.2% (1999 est.)
Labor force: 1.4 million (1997)
Labor force - by occupation: agriculture and forestry 16%, industry
41%, services 43% (1990)
Unemployment rate: 9.6% (1999 est.)
Budget:
revenues: $1.33 billion
expenditures: $1.27 billion, including capital expenditures of $NA
(1998 est.)
Industries: buses, vans, street and railroad cars, synthetic fibers,
agricultural machinery, fertilizers, washing machines, radios,
electronics, pharmaceuticals, processed foods, textiles; dependent on
imports for energy, raw materials, and intermediate products
Industrial production growth rate: -5% (1999 est.)
Electricity - production: 4.766 billion kWh (1998)
Electricity - production by source:
fossil fuel: 29.58%
hydro: 70.42%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 4.882 billion kWh (1998)
Electricity - exports: 400 million kWh (1998)
Electricity - imports: 850 million kWh (1998)
Agriculture - products: grain, sugar beets, potatoes, vegetables;
beef, milk, eggs; fish
Exports: $1.9 billion (f.o.b., 1999)
Exports - commodities: wood and wood products, machinery and
equipment, metals, textiles, foodstuffs
Exports - partners: Germany 16%, UK 14%, Russia 12%, Sweden 10% (1998)
Imports: $2.8 billion (f.o.b., 1998)
Imports - commodities: machinery and equipment, chemicals, fuels
Imports - partners: Germany 17%, Russia 12%, Finland 10%, Sweden 7%
(1998)
Debt - external: $212 million (1998)
Economic aid - recipient: $96.2 million (1995)
Currency: 1 Latvian lat (LVL) = 100 santims
Exchange rates: lats (LVL) per US$1 - 0.583 (January 2000),0.585
(1999), 0.590 (1998), 0.581 (1997), 0.551 (1996), 0.528 (1995)
Fiscal year: calendar year
@Latvia:Communications
Telephones - main lines in use: 748,000 (1997)
Telephones - mobile cellular: 175,348 (1999)
Telephone system: inadequate but is being modernized to provide an
international capability independent of the Moscow international
switch; more facilities are being installed for individual use
domestic: expansion underway in intercity trunk line connections,
rural exchanges, and mobile systems; still many unsatisfied subscriber
applications
international: international connections are now available via cable
and a satellite earth station at Riga, enabling direct connections for
most calls (1998)
Radio broadcast stations: AM 8, FM 56, shortwave 1 (1998)
Radios: 1.76 million (1997)
Television broadcast stations: 74 (1998)
Televisions: 1.22 million (1997)
Internet Service Providers (ISPs): 11 (1999)
@Latvia:Transportation
Railways:
total: 2,412 km
broad gauge: 2,379 km 1.520-m gauge (271 km electrified) (1992)
narrow gauge: 33 km 0.750-m gauge (1994)
Highways:
total: 59,178 km
paved: 22,843 km
unpaved: 36,335 km (1998 est.)
Waterways: 300 km perennially navigable
Pipelines: crude oil 750 km; refined products 780 km; natural gas 560
km (1992)
Ports and harbors: Daugavpils, Liepaja, Riga, Ventspils
Merchant marine:
total: 14 ships (1,000 GRT or over) totaling 58,699 GRT/64,043 DWT
ships by type: cargo 4, petroleum tanker 4, refrigerated cargo 6 (1999
est.)
Airports: 50 (1994 est.)
Airports - with paved runways:
total: 36
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 27 (1994 est.)
Airports - with unpaved runways:
total: 14
2,438 to 3,047 m: 2
914 to 1,523 m: 2
under 914 m: 10 (1994 est.)
@Latvia:Military
Military branches: Ground Forces, Navy, Air and Air Defense Forces,
Security Forces, Border Guard, Home Guard (Zemessardze)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 590,236 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 463,254 (2000 est.)
Military manpower - reaching military age annually:
males: 18,239 (2000 est.)
Military expenditures - dollar figure: $60 million (FY99)
Military expenditures - percent of GDP: 0.9% (FY99)
@Latvia:Transnational Issues
Disputes - international: draft treaty delimiting the boundary with
Russia has not been signed; ongoing talks over maritime boundary
dispute with Lithuania (primary concern is oil exploration rights)
Illicit drugs: transshipment point for opiates and cannabis from
Central and Southwest Asia to Western Europe and Scandinavia and Latin
American cocaine and some synthetics from Western Europe to CIS;
limited production of illicit amphetamines, ephedrine, and ecstasy for
export
______________________________________________________________________','41ad01ab149e1962a2fb474d32ef7087b9f9fa78cb2f2ea4df792eb3bdb34765','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa9d28a5f33648783eb5cc17aa81431028933b009c453e91b356b7cda0bd28c',2000,'LB','Lebanon','terrorism',143,'@Lebanon:Introduction
Background: Lebanon has made progress toward rebuilding its political
institutions and regaining its national sovereignty since 1991 and the
end of the devastating 16-year civil war. Under the Ta''if Accord - the
blueprint for national reconciliation - the Lebanese have established
a more equitable political system, particularly by giving Muslims a
greater say in the political process while institutionalizing
sectarian divisions in the government. Since the end of the war, the
Lebanese have conducted several successful elections, most of the
militias have been weakened or disbanded, and the Lebanese Armed
Forces (LAF) have extended central government authority over about
two-thirds of the country. Hizballah, the radical Shi''a party, retains
its weapons. Foreign forces still occupy areas of Lebanon. Israel
maintains troops in southern Lebanon and continues to support a proxy
militia, the Army of South Lebanon (ASL), along a narrow stretch of
territory contiguous to its border. Syria maintains about 25,000
troops in Lebanon based mainly in Beirut, North Lebanon, and the Bekaa
Valley. Syria''s troop deployment was legitimized by the Arab League
during Lebanon''s civil war and in the Ta''if Accord. Damascus justifies
its continued military presence in Lebanon by citing the continued
weakness of the LAF, Beirut''s requests, and the failure of the
Lebanese Government to implement all of the constitutional reforms in
the Ta''if Accord.
@Lebanon:Geography
Location: Middle East, bordering the Mediterranean Sea, between Israel
and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area - comparative: about 0.7 times the size of Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet winters with hot, dry
summers; Lebanon mountains experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda'' 3,088 m
Natural resources: limestone, iron ore, salt, water-surplus state in a
water-deficit region, arable land
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 1%
forests and woodland: 8%
other: 61% (1993 est.)
Irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment - current issues: deforestation; soil erosion;
desertification; air pollution in Beirut from vehicular traffic and
the burning of industrial wastes; pollution of coastal waters from raw
sewage and oil spills
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification, Marine Dumping,
Marine Life Conservation
Geography - note: Nahr al Litani only major river in Near East not
crossing an international boundary; rugged terrain historically helped
isolate, protect, and develop numerous factional groups based on
religion, clan, and ethnicity
@Lebanon:People
Population: 3,578,036 (July 2000 est.)
Age structure:
0-14 years: 28% (male 508,936; female 489,122)
15-64 years: 65% (male 1,115,457; female 1,226,448)
65 years and over: 7% (male 108,706; female 129,367) (2000 est.)
Population growth rate: 1.38% (2000 est.)
Birth rate: 20.26 births/1,000 population (2000 est.)
Death rate: 6.42 deaths/1,000 population (2000 est.)
Net migration rate: 0 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 29.3 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 71.25 years
male: 68.87 years
female: 73.74 years (2000 est.)
Total fertility rate: 2.08 children born/woman (2000 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Muslim 70% (5 legally recognized Islamic groups - Shi''a,
Sunni, Druze, Isma''ilite, Alawite or Nusayri), Christian 30% (11
legally recognized Christian groups - 4 Orthodox Christian, 6
Catholic, 1 Protestant), Jewish NEGL%
Languages: Arabic (official), French, English, Armenian widely
understood
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)
@Lebanon:Government
Country name:
conventional long form: Lebanese Republic
conventional short form: Lebanon
local long form: Al Jumhuriyah al Lubnaniyah
local short form: Lubnan
Data code: LE
Government type: republic
Capital: Beirut
Administrative divisions: 5 governorates (mohafazat, singular -
mohafazah); Beyrouth, Ech Chimal, Ej Jnoub, El Bekaa, Jabal Loubnane
Independence: 22 November 1943 (from League of Nations mandate under
French administration)
National holiday: Independence Day, 22 November (1943)
Constitution: 23 May 1926, amended a number of times
Legal system: mixture of Ottoman law, canon law, Napoleonic code, and
civil law; no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Suffrage: 21 years of age; compulsory for all males; authorized for
women at age 21 with elementary education
Executive branch:
chief of state: President Emile LAHUD (since 24 November 1998)
head of government: Prime Minister Salim al-HUSS (since 4 December
1998)
cabinet: Cabinet chosen by the prime minister in consultation with the
president and members of the National Assembly; the current Cabinet
was formed in 1998
elections: president elected by the National Assembly for a six-year
term; election last held 15 October 1998 (next to be held NA 2004);
prime minister and deputy prime minister appointed by the president in
consultation with the National Assembly; by custom, the president is a
Maronite Christian, the prime minister is a Sunni Muslim, and the
speaker of the legislature is a Shi''a Muslim
election results: Emile LAHUD elected president; National Assembly
vote - 118 votes in favor, 0 against, 10 abstentions
Legislative branch: unicameral National Assembly or Majlis Alnuwab
(Arabic) or Assemblee Nationale (French) (128 seats; members elected
by popular vote on the basis of sectarian proportional representation
to serve four-year terms)
elections: last held 18 August-15 September 1996 (next to be held NA
2000)
election results: percent of vote by party - NA; seats by party - NA
(one-half Christian and one-half Muslim)
Judicial branch: four Courts of Cassation (three courts for civil and
commercial cases and one court for criminal cases); Constitutional
Council (called for in Ta''if Accord) rules on constitutionality of
laws; Supreme Council (hears charges against the president and prime
minister as needed)
Political parties and leaders: political party activity is organized
along largely sectarian lines; numerous political groupings exist,
consisting of individual political figures and followers motivated by
religious, clan, and economic considerations
International organization participation: ABEDA, ACCT, AFESD, AL, AMF,
CCC, ESCWA, FAO, G-24, G-77, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol,
IOC, ISO (correspondent), ITU, NAM, OAS (observer), OIC, PCA, UN,
UNCTAD, UNESCO, UNHCR, UNIDO, UNRWA, UPU, WFTU, WHO, WIPO, WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador Dr. Farid ABBOUD
chancery: 2560 28th Street NW, Washington, DC 20008
telephone: (202) 939-6300
FAX: (202) 939-6324
consulate(s) general: Detroit, New York, and Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador David SATTERFIELD
embassy: Antelias, Beirut
mailing address: P. O. Box 70-840, Beirut; PSC 815, Box 2, FPO AE
09836-0002
telephone: (4) 543600, 542600, 544133, 544130, 544131
FAX: (4) 544136
Flag description: three horizontal bands of red (top), white (double
width), and red with a green and brown cedar tree centered in the
white band
@Lebanon:Economy
Economy - overview: The 1975-91 civil war seriously damaged Lebanon''s
economic infrastructure, cut national output by half, and all but
ended Lebanon''s position as a Middle Eastern entrepot and banking hub.
Peace has enabled the central government to restore control in Beirut,
begin collecting taxes, and regain access to key port and government
facilities. Economic recovery has been helped by a financially sound
banking system and resilient small- and medium-scale manufacturers,
with family remittances, banking services, manufactured and farm
exports, and international aid as the main sources of foreign
exchange. Lebanon''s economy has made impressive gains since the launch
of "Horizon 2000," the government''s $20 billion reconstruction program
in 1993. Real GDP grew 8% in 1994 and 7% in 1995 before Israel''s
Operation Grapes of Wrath in April 1996 stunted economic activity.
Real GDP grew at an average annual rate of less than 3% per year for
1997 and 1998 and only 1% in 1999. During 1992-98, annual inflation
fell from more than 100% to 5%, and foreign exchange reserves jumped
to more than $6 billion from $1.4 billion. Burgeoning capital inflows
have generated foreign payments surpluses, and the Lebanese pound has
remained relatively stable. Progress also has been made in rebuilding
Lebanon''s war-torn physical and financial infrastructure. Solidere, a
$2-billion firm, is managing the reconstruction of Beirut''s central
business district; the stock market reopened in January 1996; and
international banks and insurance companies are returning. The
government nonetheless faces serious challenges in the economic arena.
It has had to fund reconstruction by tapping foreign exchange reserves
and boosting borrowing. Reducing the government budget deficit is a
major goal of the LAHUD government. The stalled peace process and
ongoing violence in southern Lebanon could lead to wider hostilities
that would disrupt vital capital inflows. Furthermore, the gap between
rich and poor has widened in the 1990''s, resulting in grassroots
dissatisfaction over the skewed distribution of the reconstruction''s
benefits and leading the government to shift its focus from rebuilding
infrastructure to improving living conditions.
GDP: purchasing power parity - $16.2 billion (1999 est.)
GDP - real growth rate: 1% (1999 est.)
GDP - per capita: purchasing power parity - $4,500 (1999 est.)
GDP - composition by sector:
agriculture: 12%
industry: 27%
services: 61% (1998 est.)
Population below poverty line: 28% (1999 est.)
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4.5% (1999 est.)
Labor force: 1.3 million (1999 est.)
note: in addition, there are as many as 1 million foreign workers
(1997 est.)
Labor force - by occupation: services 62%, industry 31%, agriculture
7% (1997 est.)
Unemployment rate: 18% (1997 est.)
Budget:
revenues: $4.9 billion
expenditures: $8.36 billion, including capital expenditures of $NA
(1999 est.)
Industries: banking; food processing; jewelry; cement; textiles;
mineral and chemical products; wood and furniture products; oil
refining; metal fabricating
Industrial production growth rate: NA%
Electricity - production: 9.7 billion kWh (1998)
Electricity - production by source:
fossil fuel: 90.72%
hydro: 9.28%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 9.629 billion kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 608 million kWh (1998)
Agriculture - products: citrus, grapes, tomatoes, apples, vegetables,
potatoes, olives, tobacco; sheep, goats
Exports: $866 million (f.o.b., 1999 est.)
Exports - commodities: foodstuffs and tobacco, textiles, chemicals,
metal and metal products, electrical equipment and products, jewelry,
paper and paper products
Exports - partners: Saudi Arabia 12%, UAE 10%, France 9%, Syria 7%, US
7%, Kuwait 4%, Jordan, Turkey (1998)
Imports: $5.7 billion (f.o.b., 1999 est.)
Imports - commodities: foodstuffs, machinery and transport equipment,
consumer goods, chemicals, textiles, metals, fuels, agricultural foods
Imports - partners: Italy 12%, France 10%, US 9%, Germany 9%,
Switzerland 6%, Japan, UK, Syria (1998)
Debt - external: $8.8 billion (1999 est.)
Economic aid - recipient: $3.5 billion (pledges 1997-2001)
Currency: 1 Lebanese pound = 100 piasters
Exchange rates: Lebanese pounds per US$1 - 1,507.5 (January 2000),
1,507.8 (1999), 1,516.1 (1998), 1,539.5 (1997), 1,571.4 (1996),
1,621.4 (1995)
Fiscal year: calendar year
@Lebanon:Communications
Telephones - main lines in use: 330,000 (1995)
Telephones - mobile cellular: 120,000 (1995)
Telephone system: telecommunications system severely damaged by civil
war; rebuilding well underway
domestic: primarily microwave radio relay and cable
international: satellite earth stations - 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean) (erratic operations); coaxial cable to Syria;
microwave radio relay to Syria but inoperable beyond Syria to Jordan;
3 submarine coaxial cables
Radio broadcast stations: AM 20, FM 22, shortwave 4 (1998)
Radios: 2.85 million (1997)
Television broadcast stations: 28 (1997)
Televisions: 1.18 million (1997)
Internet Service Providers (ISPs): 19 (1999)
@Lebanon:Transportation
Railways:
total: 399 km (mostly unusable because of damage in civil war)
standard gauge: 317 km 1.435-m
narrow gauge: 82 km (1999)
Highways:
total: 7,300 km
paved: 6,200 km
unpaved: 1,100 km (1999 est.)
Pipelines: crude oil 72 km (none in operation)
Ports and harbors: Antilyas, Batroun, Beirut, Chekka, El Mina, Ez
Zahrani, Jbail, Jounie, Naqoura, Sidon, Tripoli, Tyre
Merchant marine:
total: 68 ships (1,000 GRT or over) totaling 346,029 GRT/536,861 DWT
ships by type: bulk 8, cargo 44, chemical tanker 1, combination bulk
1, combination ore/oil 1, container 4, livestock carrier 4,
roll-on/roll-off 2, vehicle carrier 3 (1999 est.)
Airports: 9 (1999 est.)
Airports - with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (1999 est.)
Airports - with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (1999 est.)
@Lebanon:Military
Military branches: Lebanese Armed Forces (LAF; includes Army, Navy,
and Air Force)
Military manpower - availability:
males age 15-49: 957,729 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 592,264 (2000 est.)
Military expenditures - dollar figure: $500 million (FY98)
Military expenditures - percent of GDP: 4% (FY98)
@Lebanon:Transnational Issues
Disputes - international: Israeli troops in southern Lebanon since
June 1982; Syrian troops in northern, central, and eastern Lebanon
since October 1976
Illicit drugs: inconsequential producer of hashish; some heroin
processing mostly in the Bekaa valley; a Lebanese/Syrian eradication
campaign started in the early 1990s has practically eliminated the
opium and cannabis crops
______________________________________________________________________','99ac2183bad4b846062f03bf7c896f2bbd2cc407b2c6ab4ec8658bbda0291768','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ad0a51f3a1c8247fd2f8fa5e9ab4e1648408a8aeaf766c159d9adb5d3f3c2c',2000,'LS','Lesotho','terrorism',144,'@Lesotho:Introduction
Background: Basutoland was renamed the Kingdom of Lesotho upon
independence from the UK in 1966. Constitutional government was
restored in 1993 after 23 years of military rule.
@Lesotho:Geography
Location: Southern Africa, an enclave of South Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot, wet summers
Terrain: mostly highland with plateaus, hills, and mountains
Elevation extremes:
lowest point: junction of the Orange and Makhaleng Rivers 1,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing land, some diamonds
and other minerals
Land use:
arable land: 11%
permanent crops: 0%
permanent pastures: 66%
forests and woodland: 0%
other: 23% (1993 est.)
Irrigated land: 30 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current issues: population pressure forcing settlement
in marginal areas results in overgrazing, severe soil erosion, and
soil exhaustion; desertification; Highlands Water Project controls,
stores, and redirects water to South Africa
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Marine Life
Conservation, Ozone Layer Protection
signed, but not ratified: Endangered Species, Law of the Sea, Marine
Dumping
Geography - note: landlocked; surrounded by South Africa
@Lesotho:People
Population: 2,143,141
note: estimates for this country explicitly take into account the
effects of excess mortality due to AIDS; this can result in lower life
expectancy, higher infant mortality and death rates, lower population
and growth rates, and changes in the distribution of population by age
and sex than would otherwise be expected (July 2000 est.)
Age structure:
0-14 years: 40% (male 426,556; female 421,563)
15-64 years: 56% (male 575,580; female 619,280)
65 years and over: 4% (male 42,274; female 57,888) (2000 est.)
Population growth rate: 1.65% (2000 est.)
Birth rate: 31.74 births/1,000 population (2000 est.)
Death rate: 14.59 deaths/1,000 population (2000 est.)
Net migration rate: -0.64 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 82.97 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 50.79 years
male: 49.78 years
female: 51.84 years (2000 est.)
Total fertility rate: 4.15 children born/woman (2000 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans, Asians, and other 0.3%,
Religions: Christian 80%, indigenous beliefs 20%
Languages: Sesotho (southern Sotho), English (official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 71.3%
male: 81.1%
female: 62.3% (1995 est.)
@Lesotho:Government
Country name:
conventional long form: Kingdom of Lesotho
conventional short form: Lesotho
former: Basutoland
Data code: LT
Government type: parliamentary constitutional monarchy
Capital: Maseru
Administrative divisions: 10 districts; Berea, Butha-Buthe, Leribe,
Mafeteng, Maseru, Mohales Hoek, Mokhotlong, Qacha''s Nek, Quthing,
Thaba-Tseka
Independence: 4 October 1966 (from UK)
National holiday: Independence Day, 4 October (1966)
Constitution: 2 April 1993
Legal system: based on English common law and Roman-Dutch law;
judicial review of legislative acts in High Court and Court of Appeal;
has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: King LETSIE III (since 7 February 1996); note - King
LETSIE III formerly occupied the throne from November 1990 to February
1995, while his father was in exile
head of government: Prime Minister Pakalitha MOSISILI (since 23 May
1998)
cabinet: Cabinet
elections: none; according to the constitution, the leader of the
majority party in the assembly automatically becomes prime minister;
the monarch is hereditary, but, under the terms of the constitution
which came into effect after the March 1993 election, the monarch is a
"living symbol of national unity" with no executive or legislative
powers; under traditional law the college of chiefs has the power to
determine who is next in the line of succession, who shall serve as
regent in the event that the successor is not of mature age, and may
even depose the monarch
Legislative branch: bicameral Parliament consists of the Senate (33
members - 22 principal chiefs and 11 other members appointed by the
ruling party) and the Assembly (80 seats; members elected by popular
vote for five-year terms); note - number of seats in the Assembly rose
from 65 to 80 in the May 1998 election
elections: last held 23 May 1998 (next to be held in 2000; date to be
determined by Interim Political Authority)
election results: percent of vote by party - LCD 61%; seats by party -
LCD 79, BNP 1
note: results contested; opposition parties claimed the election was
fraudulent and staged a coup; Southern African Development Community
(SADC) forces intervened in September 1998 and restored order; the
Interim Political Authority (IPA) was set up in December 1998 to
create a new electoral system and conduct new elections within 18
months
Judicial branch: High Court, chief justice appointed by the monarch;
Court of Appeal; Magistrate''s Court; customary or traditional court
Political parties and leaders: Basotho National Party or BNP [Maj.
Gen. Justine Metsing LEKHANYA]; Basotholand Congress Party or BCP
[Molapo QHOBELA, leader (currently suspended), Ntsukunyane MPHANYA,
secretary general]; Lesotho Congress for Democracy or LCD [Dr.
Pakalitha MOSISILI, leader; Shakhane MOKHEHLE, secretary general] -
the governing party; United Democratic Party or UDP ;
Marematlou Freedom Party or MFP and Setlamo Alliance ;
National Progressive Party or NPP ; Sefate
Democratic Party or SDP
International organization participation: ACP, AfDB, C, CCC, ECA, FAO,
G-77, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, Intelsat
(nonsignatory user), Interpol, IOC, ITU, NAM, OAU, OPCW, SACU, SADC,
UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Lebohang Kenneth MOLEKO
chancery: 2511 Massachusetts Avenue NW, Washington, DC 20008
telephone: (202) 797-5533 through 5536
FAX: (202) 234-6815
Diplomatic representation from the US:
chief of mission: Ambassador Katherine H. PETERSON
embassy: 254 Kingsway, Maseru West (Consular Section)
mailing address: P. O. Box 333, Maseru 100, Lesotho
telephone: 312666
FAX: 310116
Flag description: divided diagonally from the lower hoist side corner;
the upper half is white, bearing the brown silhouette of a large
shield with crossed spear and club; the lower half is a diagonal blue
band with a green triangle in the corner
@Lesotho:Economy
Economy - overview: Small, landlocked, and mountainous, Lesotho''s only
important natural resource is water. Its economy is based on
subsistence agriculture, livestock, and remittances from miners
employed in South Africa. The number of such mine workers has declined
steadily over the past several years. In 1996 their remittances added
about 33% to GDP compared with the addition of roughly 67% in 1990. A
small manufacturing base depends largely on farm products which
support the milling, canning, leather, and jute industries.
Agricultural products are exported primarily to South Africa. Proceeds
from membership in a common customs union with South Africa form the
majority of government revenue. Although drought has decreased
agricultural activity over the past few years, completion of a major
hydropower facility in January 1998 now permits the sale of water to
South Africa, generating royalties that will be an important source of
income for Lesotho. The pace of parastatal privatization has increased
in recent years. Civil disorder in September 1998 destroyed 80% of the
commercial infrastructure in Maseru and two other major towns. Most
firms were not covered by insurance, and the rebuilding of small and
medium business has been a significant challenge in terms of both
economic growth and employment levels. Output dropped 10% in 1998 and
recovered slowly in 1999.
GDP: purchasing power parity - $4.7 billion (1998 est.)
GDP - real growth rate: -10% (1998 est.)
GDP - per capita: purchasing power parity - $2,240 (1998 est.)
GDP - composition by sector:
agriculture: 14%
industry: 42%
services: 44% (1997 est.)
Population below poverty line: 49.2% (1993 est.)
Household income or consumption by percentage share:
lowest 10%: 0.9%
highest 10%: 43.4% (1986-87)
Inflation rate (consumer prices): 8% (1998 est.)
Labor force: 689,000 economically active
Labor force - by occupation: 86% of resident population engaged in
subsistence agriculture; roughly 35% of the active male wage earners
work in South Africa
Unemployment rate: substantial unemployment and underemployment
affecting more than half of the labor force (1999 est.)
Budget:
revenues: $507 million
expenditures: $487 million, including capital expenditures of $170
million (FY96/97 est.)
Industries: food, beverages, textiles, handicrafts; construction;
tourism
Industrial production growth rate: 19.7% (1995)
Electricity - production: 0 kWh (1998)
Electricity - production by source:
fossil fuel: 0%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 209 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 209 million kWh (1998)
Agriculture - products: corn, wheat, pulses, sorghum, barley;
livestock
Exports: $235 million (f.o.b., 1998 est.)
Exports - commodities: manufactures 75% (clothing, footwear, road
vehicles), wool and mohair, food and live animals (1998)
Exports - partners: South African Customs Union 65%, North America 34%
(1998)
Imports: $700 million (f.o.b., 1998 est.)
Imports - commodities: food; building materials, vehicles, machinery,
medicines, petroleum products (1995)
Imports - partners: South African Customs Union 90%, Asia 7% (1997)
Debt - external: $675 million (1998 est.)
Economic aid - recipient: $123.7 million (1995)
Currency: 1 loti (L) = 100 lisente; note - maloti (M) is the plural
form of loti
Exchange rates: maloti (M) per US$1 - 6.12439 (January 2000), 6.10948
(1999), 5.52828 (1998), 4.60796 (1997), 4.29935 (1996), 3.62709
(1995); note - the Basotho loti is at par with the South African rand
Fiscal year: 1 April - 31 March
@Lesotho:Communications
Telephones - main lines in use: 18,000 (1995)
Telephones - mobile cellular: 0 (1995)
Telephone system: rudimentary system
domestic: consists of a few landlines, a small microwave radio relay
system, and a minor radiotelephone communication system
international: satellite earth station - 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 2, shortwave 1 (1998)
Radios: 104,000 (1997)
Television broadcast stations: 1 (2000)
Televisions: 54,000 (1997)
Internet Service Providers (ISPs): 1 (1999)
@Lesotho:Transportation
Railways:
total: 2.6 km; note - owned by, operated by, and included in the
statistics of South Africa
narrow gauge: 2.6 km 1.067-m gauge (1995)
Highways:
total: 4,955 km
paved: 887 km
unpaved: 4,068 km (1996 est.)
Ports and harbors: none
Airports: 29 (1999 est.)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 2 (1999 est.)
Airports - with unpaved runways:
total: 25
914 to 1,523 m: 4
under 914 m: 21 (1999 est.)
@Lesotho:Military
Military branches: Lesotho Defense Force (LDF; includes Army and Air
Wing), Royal Lesotho Mounted Police (RLMP)
Military manpower - availability:
males age 15-49: 503,751 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 271,098 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: The Lesotho Government in 1999 began an open debate
on the future structure, size, and role of the armed forces,
especially considering the Lesotho Defense Force''s (LDF) history of
intervening in political affairs.
@Lesotho:Transnational Issues
Disputes - international: none
______________________________________________________________________','7557471e4cf151a7adf5f60c473772c568268f0993024febb3d0c186b44d4a01','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93bbe737e3b799d23f145ae29d89a27bdf4bab5e0f9b9162ef4d5bfbea1ddbc2',2000,'LR','Liberia','terrorism',145,'@Liberia:Introduction
Background: Seven years of civil strife were brought to a close in
1996 when free and open presidential and legislative elections were
held. President TAYLOR now holds strong executive power with no real
political opposition. The years of fighting coupled with the flight of
most businesses has disrupted formal economic activity. A still
unsettled domestic security situation has slowed the process of
rebuilding the social and economic structure of this war-torn country.
@Liberia:Geography
Location: Western Africa, bordering the North Atlantic Ocean, between
Cote d''Ivoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716 km, Sierra Leone
306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot days and cool to
cold nights; wet, cloudy summers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber, diamonds, gold, hydropower
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 18%
other: 19% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: dust-laden harmattan winds blow from the Sahara
(December to March)
Environment - current issues: tropical rain forest subject to
deforestation; soil erosion; loss of biodiversity; pollution of
coastal waters from oil residue and raw sewage
Environment - international agreements:
party to: Desertification, Endangered Species, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94
signed, but not ratified: Biodiversity, Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping, Marine Life Conservation
@Liberia:People
Population: 3,164,156 (July 2000 est.)
Age structure:
0-14 years: 43% (male 681,136; female 680,501)
15-64 years: 54% (male 826,751; female 867,402)
65 years and over: 3% (male 54,334; female 54,032) (2000 est.)
Population growth rate: 1.94% (2000 est.)
Birth rate: 47.22 births/1,000 population (2000 est.)
Death rate: 16.58 deaths/1,000 population (2000 est.)
Net migration rate: -11.22 migrant(s)/1,000 population (2000 est.)
note: by the end of 1999, all Liberian refugees, who had fled the
domestic strife, were assumed to have returned
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 1.01 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 134.63 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 51.02 years
male: 49.6 years
female: 52.49 years (2000 est.)
Total fertility rate: 6.43 children born/woman (2000 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95% (including Kpelle, Bassa,
Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai, and
Bella), Americo-Liberians 2.5% (descendants of immigrants from the US
who had been slaves), Congo People 2.5% (descendants of immigrants
from the Caribbean who had been slaves)
Religions: indigenous beliefs 40%, Christian 40%, Muslim 20%
Languages: English 20% (official), some 20 ethnic group languages, of
which a few can be written and are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 38.3%
male: 53.9%
female: 22.4% (1995 est.)
note: these figures are increasing because of the improving school
system
@Liberia:Government
Country name:
conventional long form: Republic of Liberia
conventional short form: Liberia
Data code: LI
Government type: republic
Capital: Monrovia
Administrative divisions: 13 counties; Bomi, Bong, Grand Bassa, Grand
Cape Mount, Grand Gedeh, Grand Kru, Lofa, Margibi, Maryland,
Montserrado, Nimba, River Cess, Sinoe
Independence: 26 July 1847
National holiday: Independence Day, 26 July (1847)
Constitution: 6 January 1986
Legal system: dual system of statutory law based on Anglo-American
common law for the modern sector and customary law based on unwritten
tribal practices for indigenous sector
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Charles Ghankay TAYLOR (since 2 August
1997); note - the president is both the chief of state and head of','798879f575add4126ae665265b5612c6fe1c06b1267467533b4bc3d842873784','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

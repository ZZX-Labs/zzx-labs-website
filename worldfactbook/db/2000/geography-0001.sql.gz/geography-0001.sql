SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d998618727ace4feddbed7a0c5b963d40556cb5bbf3699423b3a35adb632d19f',2000,'EH','Western Sahara','geography',12,'Location
Geographic coordinates
Map references
Area
total
land
water
Area - comparative
Land boundaries
total
border countries
Coastline
Maritime claims
contiguous zone
continental shelf
exclusive economic zone
exclusive fishing zone
extended fishing zone
territorial sea
Climate
Terrain
Elevation extremes
lowest point
highest point
Natural resources
Land use
arable land
permanent crops
permanent pastures
forests and woodland
other
Irrigated land
Natural hazards
Environment - current issues
Environment • international agreements
party to
signed, but not ratified
Geography - note
I People
Population
Age structure
0-14 years
15-64 years
65 years and over
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
Life expectancy at birth
total population
male
female
Total fertility rate
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People - note','d3fe168de30cf742bb1f95a585ce2d9105065c2fdb8fad0a2e4e03d74d9d400f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5bfe44efe63371605683e0a284ff259b30ce20d7005b23e9b2145a8c38083c0',2000,'DZ','Algeria','geography',22,'Location; Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates; 14 20 S, 170 00 W
Map references; Oceania
Area;
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area - comparative; slightly larger than
Washington, DC
Land boundaries; 0 km
Coastline; 116 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; tropical marine, moderated by southeast
trade winds; annual rainfall averages about 3 m; rainy
season from November to Aprii, dry season from May
to October; little seasonal temperature variation
Terrain; five volcanic islands with rugged peaks and
limited coastal plains, two coral atolls (Rose Island,
Swains Island)
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources; pumice, pumicite
8
American Samoa (continued)
Land use;
arable land: 5%
permanent crops: 1 0%
permanent pastures: 0%
forests and woodland: 70%
of/ier;15%(1993 esf.)
Irrigated land; NAsqkm
Natural hazards; typhoons common from December
to March
Environment - current issues; limited naturai fresh
water resources; the water division of the government
has spent substantiai funds in the past few years to
improve water catchments and pipelines
Geography - note; Pago Pago has one of the best
natural deepwater harbors in the South Pacific Ocean,
sheltered by shape from rough seas and protected by
peripheral mountains from high winds; strategic
location in the South Pacific Ocean
r"'' PTopiT"
Population; 65,446 (July 2000 est.)
Age structure;
0-14 years: 39% (male 13,071; female 12,304)
15-64 years: 56% (male 18,358; female 18,597)
65 years and over: 5% (male 1 ,631 ; female 1 ,485)
(2000 est.)
Population growth rate; 2.53% (2000 est.)
Birth rate; 25.81 births/1 ,000 population (2000 est.)
Death rate; 4.26 deaths/1 ,000 population
(2000 est.)
Net migration rate; 3.74 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1 .1 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate; 1 0.63 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 75.12 years
male: 70.66 years
female: 79.84 years (2000 est.)
Total fertility rate; 3.6 children born/woman
(2000 est.)
Nationality;
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups; Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%, other 5%
Religions; Christian Congregationalist 50%, Roman
Catholic 20%, Protestant and other 30%
Languages; Samoan (closely related to Hawaiian
and other Polynesian languages), English
note: most people are bilingual
Literacy;
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
f " '' G o''v e r n ''m‘e n r
Country name;
conventional long form: Territory of American Samoa
conventional short form: American Samoa
abbreviation: AS
Data code; AQ
Dependency status; unincorporated and
unorganized territory of the US; administered by the
Office of Insular Affairs, US Department of the Interior
Government type; NA
Capital; Pago Pago
Administrative divisions; none (territory of the US);
there are no first-order administrative divisions as
defined by the US Government, but there are three
districts and two islands* atthe second order; Eastern,
Manu''a, Rose Island*, Swains Island*, Western
Independence; none (territory of the US)
National holiday; TerritorialFlagDay,17April(1900)
Constitution; ratified 1966, in effect 1967
Legal system; NA
Suffrage; 18 years of age; universal
Executive branch;
chief of state: President William Jefferson CLINTON
of the US (since 20 January 1993) and Vice President
Albert GORE, Jr. (since 20 January 1993)
head of government: Governor Tauese P. SUNIA
(since 3 January 1 997) and Lieutenant Governor
Togiola TULAFONO (since 3 January 1 997)
cabinet: NA
elections: US president and vice president elected on
the same ticket for four-year terms; governor and
lieutenant governor elected on the same ticket by
popular vote for four-year terms; election last held 3
November 1996 (next to be held 7 November 2000)
election results: Tauese P. SUNIA elected governor;
percent of vote - Tauese P. SUNIA (Democrat) 51 %,
Peter REID (independent) 49%
Legislative branch; bicameral Fono or Legislative
Assembly consists of the House of Representatives
(21 seats - 20 of which are elected by popular vote
and 1 is an appointed, nonvoting delegate from
Swains Island; members serve two-year terms) and
the Senate (18 seats; members are elected from local
chiefs and serve four-year terms)
elections: House of Representatives - last held NA
November 1 998 (next to be held NA November 2000);
Senate - last held 3 November 1996 (next to be held
7 November 2000)
election results: House of Representatives - percent
of vote by party - NA; seats by party - NA; Senate -
percent of vote by party - NA; seats by party - NA
note: American Samoa elects one delegate to the US
House of Representatives; election last held 3
November 1 998 (next to be held 7 November 2000);
results - Eni R. F. H. FALEOMAVAEGA (Democrat)
reelected as delegate for a sixth term
Judicial branch; High Court (chief justice and
associate justices are appointed by the US Secretary
of the Interior)
Political parties and leaders; Democratic Party
[leader NA]; Republican Parly [leader NA]
International organization participation; ESCAP
(associate), Interpol (subbureau), IOC, SPC
Diplomatic representation in the US; none
(territory of the US)
Diplomatic representation from the US; none
(territory of the US)
Flag description; blue, with a white triangle edged
in red that is based on the outer side and extends to
the hoist side; a brown and white American bald eagle
flying toward the hoist side is carrying two traditional
Samoan symbols of authority, a staff and a war club
Economy - overview; This is a traditional
Polynesian economy in which more than 90% of the
land is communally owned. Economic activity is
strongly linked to the US, with which American Samoa
conducts the great bulk of its foreign trade. Tuna
fishing and tuna processing plants are the backbone
of the private sector, with canned tuna the primary
export. Transfers from the US Government add
substantially to American Samoa''s economic
well-being. Attempts by the government to develop a
larger and broader economy are restrained by
Samoa''s remote location, its limited transportation,
and its devastating hurricanes. Tourism, a developing
sector, may be held back by the current financial
difficulties in East Asia.
GDP; purchasing power parity - $1 50 million
(1995 est.)
GDP - real growth rate; NA%
GDP ■ per capita; purchasing power parity - $2,600
(1995 est.)
GDP ■ composition by sector;
agriculture: NA%
industry: NA%
services: NA%
Popuiation beiow poverty line; NA%
Household income or consumption by percentage
share;
lowest 10%: m%
highest 10%: NA%
Inflation rate (consumer prices); NA%
Labor force; 13,949(1996)
Labor force - by occupation; government 33%,
tuna canneries 34%, other 33% (1990)
Unemployment rate; 1 2% (1 991 )
Budget;
revenues; $121 million (37% in local revenue and
63% in US grants)
expenditures: $127 million, including capital
expenditures of $NA (FY96/97)
Industries; tuna canneries (largely dependent on
foreign fishing vessels), handicrafts
Industrial production growth rate; NA%
Electricity - production; 125 million kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity - consumption; 1 1 6 million kWh (1 998)
9
American Samoa (continued)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, coconuts,
vegetables, taro, breadfruit, yams, copra, pineapples,
papayas; dairy products, livestock
Exports: $313 million (1996)
Exports - commodities: canned tuna 93%
Exports - partners: US 99.6%
Imports: $471 million (1996)
Imports ■ commodities: materials for canneries
56%, food 8%, petroleum products 7%, machinery
and parts 6%
Imports - partners: US 62%, Japan 9%, NZ 7%,
Australia 11%, Fiji 4%, other 7%
Debt - external: $NA
Economic aid - recipient: $NA; note ■ important
financial support from the US
Currency: 1 US dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October - 30 September','ec08cf71b2f8712e3ab0a81612a37a305377771c593eb6c6fc2568fc32d62868','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b659f68e650be9e8703c23d0b857103e3077611d787bff961390a8efb79d30c1',2000,'AD','Andorra','geography',27,'Location: Southwestern Europe, between France
and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 468 sq km
land: 468 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries:
total: 120.3 km
border countries: France 56.6 km, Spain 63.7 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm,
dry summers
Terrain: rugged mountains dissected by narrow
valleys
Elevation extremes:
lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water,
timber, iron ore, lead
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 45%
forests and woodland: 35%
other 16% (1998 est.)
Irrigated land: NAsqkm
Natural hazards: snowslides, avalanches
Environment - current issues: deforestation;
overgrazing of mountain meadows contributes to soil
erosion; air pollution; waste water treatment and solid
waste disposal
Environment - international agreements:
party to: Hazardous Wastes
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked','be7f9bad3bb9d8c5256c3e19fb798574d74fb02aa5427e1b6f18794a590d5554','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f40470233c0eeb6774a2700f2c67728849332c4cf93716d4ad0b10efeb4106e',2000,'AI','Anguilla','geography',33,'Location: Caribbean, island in the Caribbean Sea,
east of Puerto Rico
Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the
Caribbean
Area:
total: 91 sq km
land: 91 sq km
water: 0 sq km
Area - comparative: about half the size of
Washington, DC
Land boundaries; 0 km
Coastline; 61 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: tropical; moderated by northeast trade
winds
Terrain: flat and low-lying island of coral and
limestone
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: 0%
permanent crops: 0%
14
Anguilla (continued)
permanent pastures: 0%
forests and woodland: 0%
other: 100% (mostly rock with sparse scrub oak, few
trees, some commercial salt ponds)
Irrigated land: NAsqkm
Natural hazards: frequent hurricanes and other
tropical storms (July to October)
Environment - current issues: supplies of potable
water sometimes cannot meet increasing demand
largely because of poor distribution system
f People
Population: 1 1 ,797 (July 2000 est.)
Age structure:
0-14years:26% (male 1,565; female 1,519)
15-64 years: 67% (male 4,040; female 3,839)
65 years and over: 7% (male 369; female 465)
(2000 est.)
Population growth rate: 2.93% (2000 est.)
Birth rate: 15.34 births/1 ,000 population (2000 est.)
Death rate: 5.76 deaths/1 ,000 population
(2000 est.)
Net migration rate: 19.75 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.79 male(s)/temale
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 25.44 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.11 years
male: 73.22 years
female: 79.09 years (2000 est.)
Total fertility rate: 1 .8 children born/woman
(2000 est.)
Nationality:
r70ur7;Anguillan(s)
adjective: Anguillan
Ethnic groups: black
Religions: Anglican 40%, Methodist 33%,
Seventh-Day Adventist 7%, Baptist 5%, Roman
Catholic 3%, other 12%
Languages: English (official)
Literacy:
definition: age 12 and over can read and write
total population: 95%
mate: 95%
fema/e; 95% (1984 est.)
I Government
Country name:
conventional long form: none
conventional short form: Anguilla
Data code: AV
Dependency status: overseas territory of the UK
Government type: NA
Capital: The Valley
Administrative divisions: none (overseas territory
of the UK)
Independence: none (overseas territory of the UK)
National holiday: Anguilla Day, 30 May
Constitution: Anguilla Constitutional Order 1 April
1982; amended 1990
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952); represented by Governor Alan HOOLE (since
1 November 1995)
head of government: Chief Minister Hubert HUGHES
(since 16 March 1994)
cabinet: Executive Council appointed by the governor
from among the eiected members of the House of
Assembly
elections: none; the monarch is hereditary; governor
appointed by the monarch; chief minister appointed by
the governor from among the members of the House
of Assembly
Legislative branch: unicameral House of Assembly
(1 1 seats total, 7 elected by direct popular vote, 2 ex
officio members and 2 appointed; members serve
five-year terms)
elections: last held 4 March 1999 (next to be held 10
March 2004)
election results: percent of vote by party - NA; seats
by party - ANA 2, AUP 2, ADP 2, independent 1
Judicial branch: High Court (judge provided by
Eastern Caribbean Supreme Court)
Political parties and leaders; Anguilla Democratic
Party or ADP [Victor BANKS]; Anguilla National
Alliance or ANA [Osbourne FLEMING); Anguilla
United Party or AUP [Hubert HUGHES]
International organization participation; Caricom
(associate), CDB, Interpol (subbureau), OECS
(associate), ECLAC (associate)
Diplomatic representation in the US; none
(overseas territory of the UK)
Diplomatic representation from the US: none
(overseas territory of the UK)
Flag description; blue, with the flag of the UK In the
upper hoist-side quadrant and the Anguillan coat of
arms centered in the outer half of the flag; the coat of
arms depicts three orange dolphins in an interlocking
circular design on a white background with blue wavy
water below','3a2556610864fc5afcc3badb8904d9fa088c1750491dbd8ca2ec366ad444f881','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('923c96811b0b66f33c8b728d832d69ad046ecb012bf76d0713b1df11758a96c6',2000,'AG','Antigua and Barbuda','geography',38,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area:
total: 442 sq km (Antigua 281 sq km; Barbuda 1 61 sq
km)
land: 442 sq km
water: 0 sq km
note: includes Redonda
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: mostly low-lying limestone and coral
islands, with some higher volcanic areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fosters
tourism
Land use:
arable land: 13%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 1 1 %
other: 32% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hurricanes and tropical storms
(July to October); periodic droughts
Environment - current issues: water
management - a major concern because of limited
natural fresh water resources - is further hampered by
the clearing of trees to increase crop production,
causing rainfall to run off quickly
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements','2324d43a89c36483bdc8aaf3cf26a7f99070bdda3293f13957f831eba7325e0a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c276678923530afc6d114fde13e2ce5e2ce9133a9108d8764097f4ce39a466',2000,'AQ','Antarctica','geography',46,'Location: Caribbean, island in the Caribbean Sea,
north of Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the
Caribbean
Area:
tofa/;193 sq km
land: ^93 sq km
water: 0 sq km
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastiine: 68.5 km
Maritime ciaims:
territorial sea; 12 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes:
towesfpo/rrf; Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources: NEGL; white sandy beaches
Land use:
arable land: 7% aloe plantations included (0.01%)
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other 93% (1993 est.)
Irrigated land: 0.01 sq km
Natural hazards: lies outside the Caribbean
hurricane belt
Environment - current issues: NA
Location: body of water between Africa, Europe, the
Southern Ocean, and the Western Hemisphere
Geographic coordinates; 0 00 N, 25 00 W
Map references; World
Area:
total: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea,
Davis Strait, Denmark Strait, part of the Drake
Passage, Gulf of Mexico, Mediterranean Sea, North
Sea, Norwegian Sea, almost all of the Scotia Sea, and
other tributary water bodies
Area - comparative: slightly less than 6.5 times the
size of the US
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop off
the coast of Africa near Cape Verde and move
westward into the Caribbean Sea; hurricanes can
occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in
Labrador Sea, Denmark Strait, and Baltic Sea from
October to June; clockwise warm-water gyre (broad,
circular system of currents) in the northern Atlantic,
counterclockwise warm-water gyre in the southern
Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline
for the entire Atlantic basin
i Government
Data code: none; the US Government has not
approved a standard for hydrographic codes - see the
Cross-Reference List of Hydrographic Data Codes
appendix','a8f757c780973debe8c0a5c82c557ece10961b0a07343ce153caab1e7ed94da8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3468849a8f568c43a049f8536575d17a0dd387c8d43acc7800356c4db9f12271',2000,'AZ','Azerbaijan','geography',55,'Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-Araks
Lowriand) (much of it below sea level) with Great
Caucasus Mountains to the north, Qarabag Yayiasi
(Karabakh Upiand) in west; Baku lies on Abseron
Yasaqiigi (Apsheron Peninsula) that juts into Caspian
Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore,
nonferrous metals, alumina
Land use:
arable tend: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 1 1 %
other 41 %(1 993 est.)
Irrigated land: 10,000 sq km (1993 est.)
Natural hazards: droughts; some lowland areas
threatened by rising levels of the Caspian Sea
Environment - current issues: local scientists
consider the Abseron Yasaqiigi (Apsheron Peninsula)
(including Baku and Sumqayit) and the Caspian Sea
to be the ecologically most devastated area in the
world because of severe air, water, and soil pollution;
soil pollution results from the use of DDT as a
pesticide and also from toxic defoliants used in the
production of cotton
Environment - international agreements:
party to: Climate Change, Desertification,
Endangered Species, Marine Dumping, Ozone Layer
Protection
signed, but not ratified: Biodiversity
Geography - note: landlocked
Location: Southwestern Asia, bordering the Caspian
Sea, between Iran and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent
States
Area:
total: 86,600 sq km
/arrd; 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous
Republic and the Nagorno-Karabakh region; the
region''s autonomy was abolished by Azerbaijani
Supreme Soviet on 26 November 1991
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2, Ot 3 km
border countries: Armenia (with Azerbaijan-proper)
566 km, Armenia (with Azerbaijan-Naxcivan exclave)
221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km, Russia 284
km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800
km, est.)
Maritime claims: none (landlocked)','c819e464784f0c4d440d7973a815d59a55c7d4a0e8586ea9d05e1f533680aeac','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b0440e57185c86a1279a043216bfff1d8353562a777b2f307b57c31ad25802d',2000,'BH','Bahrain','geography',64,'Location: Middle East, archipelago In the Persian
Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total: 620 sq km
land: 620 sq km
water: 0 sq km
Area - comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: extending to boundaries to be
determined
territorial sea: 12 nm
Climate: arid; mild, pleasant winters; very hot, humid
summers
Terrain: mostly low desert plain rising gently to low
central escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Oabal ad Dukhan 122 m
Natural resources: oil, associated and
nonassociated natural gas, fish
Land use:
arable land: 1%
38
Bahrain (continued)
permanent crops: t%
permanent pastures: 6%
forests and woodland: 0%
ote92%(1993 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: periodic droughts; dust storms
Environment - current issues: desertification
resulting from the degradation of limited arable land,
periods of drought, and dust storms; coastal
degradation (damage to coastlines, coral reefs, and
sea vegetation) resulting from oil spills and other
discharges from large tankers, oil refineries, and
distribution stations; no natural fresh wafer resources
so that groundwater and sea water are the only
sources for all water needs
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: close to primary Middle Eastern
petroleum sources; strategic location in Persian Gulf
which much of Western world''s petroleum must transit
to reach open ocean
f Peopfe
Population; 634,137
note: includes 228,424 non-nationals (July 2000 est.)
Age structure:
0-14 years: 30% (male 96,240; female 93,846)
15-64 years: 67% (male 252,767; female 173,072)
65 years and over: 3% (male 9,270; female 8,942)
(2000 est.)
Population growth rate: 1 .78% (2000 est.)
Birth rate: 20.61 births/1 ,000 population (2000 est.)
Death rate: 3.89 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1.12 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .46 male(s)/female
65 years and over: 1 .04 male(s)/female
total population: 1.3 male(s)/female (2000 est.)
Infant mortality rate: 20.48 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 72.98 years
male: 70.58 years
female: 75.45 years (2000 est.)
Total fertility rate: 2.82 children born/woman
(2000 est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 63%, Asian 19%, other
Arab 10%, Iranian 8%
Religions: Shi''a Muslim 75%, Sunni Muslim 25%
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 15 and over can read and write
total population: 85.2%
mate: 89.1%
female: 79.4% (1995 est.)
E Government
Country name:
conventional long form: State of Bahrain
conventional short form: Bahrain
local long form: Dawlat al Bahrayn
local short form: Al Bahrayn
Data code: BA
Government type: traditional monarchy
Capital: Manama
Administrative divisions: 12 municipalities
(manatiq, singular - mintaqah); Al Hadd, Al Manamah,
Al Mintaqah al Gharbiyah, Al Mintaqah al Wusta, Al
Mintaqah ash Shamaliyah, Al Muharraq, Ar Rifa'' wa al
Mintaqah al Janubiyah, Jidd Hafs, Madinat Hamad,
Madinat ''Isa, Juzur Hawar, Sitrah
note: all municipalities administered from Manama
Independence: 15 August 1971 (from UK)
National holiday: National Day, 16 December
(1971)
Constitution: 26 May 1973, effective 6 December
1973
Legal system: based on Islamic law and English
common law
Suffrage: none
Executive branch;
chief of state: Amir HAMAD bin Isa Al Khalifa (since 6
March 1999); Heir Apparent Crown Prince SALMAN
bin Hamad (son of the monarch, bom 21 October
1969)
head of government: Prime Minister KHALIFA bin
Salman Al Khalifa (since NA 1971)
cabinet: Cabinet appointed by the monarch
elections: none; the monarch is hereditary; prime
minister appointed by the monarch
Legislative branch; unicameral National Assembly
was dissolved 26 August 1975 and legislative powers
were assumed by the Cabinet; appointed Advisory
Council established 16 December 1992
Judicial branch: High Civil Appeals Court
Political parties and leaders: political parties
prohibited
Political pressure groups and leaders: Shi''a
activists have fomented unrest sporadically since late
1994, demanding the return of an elected National
Assembly and an end to unemployment; several
small, clandestine leftist and Islamic fundamentalist
groups are active
International organization participation: ABEDA,
AFESD, AL, AMF, ESCWA, FAO, G-77, GCC, IBRD,
ICAO, ICRM, IDB, IFC, IFRCS, IHO, ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, ISO (correspondent),
ITU, NAM, OAPEC, OIC, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WlPO, WMO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Dr. Muhammad ABD
AL-GHAFFAR Abdallah
chancery: 3502 International Drive NW, Washington,
DC 20008
fe/ephone; [1] (202) 342-0741
FAX; [1] (202) 362-2192
consulate(s) general: New York
Diplomatic representation from the US;
chief of mission: Ambassador Johnny YOUNG
embassy: Building Number 979, Road 3119 (next to
Al-Ahli Sports Club), Block 31 1 , Zinj District, Manama
mailing address: American Embassy Manama, PSC
451, FPO AE 09834-5100; International Mail;
American Embassy, Box 26431 , Manama
telephone: [973] 273-300
FAX: [973] 272-594
Flag description: red with a white serrated band
(eight white points) on the hoist side
I Economy
Economy - overview: In Bahrain, petroleum
production and processing account for about 60% of
export receipts, 60% of government revenues, and
30% of GDP. Economic conditions have fluctuated
with the changing fortunes of oil since 1985, for
example, during and following the Gulf crisis of
1990-91. With its highly developed communication
and transport facilities, Bahrain is home to numerous
multinational firms with business in the Gulf. A large
share of exports consists of petroleum products made
from imported crude. Construction proceeds on
several major industrial projects. Unemployment,
especially among the young, and the depletion of both
oil and underground water resources are major
long-term economic problems.
GDP: purchasing power parity - $8.6 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity - $1 3,700
(1999 est.)
GDP ■ composition by sector:
agriculture: 1%
industry: 46%
services: 53% (1996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
/owesf 10%; NA%
highest 10%: NA%
Inflation rate (consumer prices); 0.5% (1998 est.)
Labor force: 295,000 (1 998 est.)
note: 44% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force - by occupation: industry, commerce,
and service 79%, government 20%, agriculture 1%
(1997 est.)
Unemployment rate: 15% (1998 est.)
Budget:
revenues: $1 .5 billion
expenditures: $1 .9 billion, including capital
expenditures of $NA (1998)
39
Bahrain (continued)
Industries: petroleum processing and refining,
aluminum smelting, offshore banking, ship repairing;
tourism
Industrial production growth rate: 3.4% (1995)
Electricity - production: 4.77 billion kWh (1998)
Electricity - production by source:
fossil fuel: tOQJo
hydro: 0%
nuclear: 0%
other: 0% (1998)
Eiectricity - consumption: 1 .09 billion kWh (1 999)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: fruit, vegetables; poultry,
dairy products; shrimp, fish
Exports: $3.3 billion (f.o.b., 1998)
Exports - commodities: petroleum and petroleum
products 61%, aluminum 7%
Exports - partners: India 1 8%, Japan 11%, Saudi
Arabia 8%, South Korea 7%, UAE 5% (1997)
Imports: $3.5 billion (f.o.b., 1998)
Imports - commodities: nonoil 59%, crude oil 41%
Imports - partners: Saudi Arabia 45%, US 1 0%, UK
6%, Japan 5%, Germany 4% (1997)
Debt ■ external: $2 billion (1997)
Economic aid - recipient: $48.4 million (1995)
Currency: 1 Bahraini dinar (BD) = 1 ,000 fils
Exchange rates: Bahraini dinars (BD) per US$1 -
0.3760 (fixed rate)
Fiscal year: calendar year
I Communications
Telephones • main lines in use: 141,000 (1995)
Telephones - mobile cellular: 130,000 (1999 est.)
Telephone system: modern system; good domestic
services and excellent international connections
domestic: modern fiber-optic integrated services;
digital network with rapidly growing use of mobile
cellular telephones
international: tropospheric scatter to Qatar and UAE;
microwave radio relay to Saudi Arabia; submarine
cable to Qatar, UAE, and Saudi Arabia; satellite earth
stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian
Ocean) and 1 Arabsat
Radio broadcast stations: AM 2, FM 3, shortwave
0(1998)
Radios: 338,000(1997)
Television broadcast stations: 4 (1997)
Televisions: 275,000(1997)
Internet Service Providers (ISPs): 3 (1999)
I transportation
Railways: 0 km
Highways:
fota/; 3,164 km
paved: 2,433 km
unpaved: 731 km (1 998 est.)
rrofe; there is a paved causeway connecting Bahrain
to Saudi Arabia
Pipelines: crude oil 56 km; petroleum products 16
km; natural gas 32 km
Ports and harbors: Manama, Mina'' Salman, Sitrah
Merchant marine:
total: 8 ships (1 ,000 GRT or over) totaling 22B,273
GRT/304,654 DWT
ships by type: bulk 2, cargo 3, container 2, petroleum
tanker 1 (1999 est.)
Airports: 3 (1999 est.)
Airports - with paved runways:
total: 2
over 3,047 m: 2 (1999 est.)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m; 1 (1999 est.)
Heliports: 1 (1 999 est.)
I Military ^
Military branches: Ground Force, Navy, Air Force,
Coast Guard, Police Force
Military manpower - military age: 1 5 years of age
Military manpower - availability:
males age 15-49; 221,109 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 121,442 (2000 est.)
Military manpower - reaching military age
annually:
males: 5,699 (2000 est.)
Military expenditures • dollar figure: $31 8 million
(FY99)
Military expenditures - percent of GDP: 5.2%
(FY99)
( T r a li'' s n a f i o n a~l f s sue s
Disputes - international: the territorial dispute with
Qatar over the Hawar Islands and the maritime
boundary dispute with Qatar are currently before the
International Court of Justice (ICJ)
North Pacific Ocean
F . G e 0 g r alpFy . . . ''
Location: Oceania, atoll in the North Pacific Ocean,
about one-half of the way from Hawaii to Australia
Geographic coordinates: 0 13 N, 176 31 W
Map references: Oceania
Area:
total: 1 .4 sq km
land: 1 ,4 sq km
water: 0 sq km
Area - comparative: about 2.5 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: equatorial; scant rainfall, constant wind,
burning sun
Terrain: low, nearly level coral island surrounded by
a narrow fringing reef
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 8 m
Natural resources: guano (deposits worked until
1891)
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1993)
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime hazard
Environment - current issues: no natural fresh
water resources
Geography - note: treeless, sparse, and scattered
vegetation consisting of grasses, prostrate vines, and
low growing shrubs; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds, and marine
wildlife
40
Baker Island (continued)
I — Peopre ™
Population; uninhabited
note; American civilians evacuated in 1942 after
Japanese air and naval attacks during World War II;
occupied by US military during World War II, but
abandoned after the w/ar; public entry is by
special-use permit from US Fish and Wildlife Service
only and generally restricted to scientists and
educators; a cemetery and remnants of structures
from early settlement are located near the middle of
the west coast; visited annually by US Fish and
Wildlife Service (July 2000 est.)
|~ G oTTTnlm e ^
Countrv name:
conventional long form: none
conventional short form: Baker Island
Data code; FQ
Dependency status: unincorporated territory of the
US; administered from Washington, DC by the Fish
and Wildlife Service of the US Department of the
Interior as part of the National Wildlife Refuge system
Legal system; NA
Flag description: the flag of the US is used
Economy ■ overview: no economic activity
I ™ fT a n s p 0 r t a 1 1 0 n
Ports and harbors: none; offshore anchorage only;
note - there is one boat landing area along the middle
of the west coast
Airports: 1 abandoned World War II runway of 1 ,665
m, completely covered with vegetation and unusable
Transportation - note: there is a day beacon near
the middle of the west coast
f Military
Military - note; defense is the responsibility of the
US; visited annually by the US Coast Guard
I TTaliTirFt i 0 n a I Ts ^ e s
Disputes - international: none
Background; Bangladesh came into existence in
1971 when Bengali East Pakistan seceded from its
union with West Pakistan. A third of this desperateiy
poor country annually floods during the monsoon rainy
season, hampering normal economic development.
1^ ~~Q eography ” ^
Location; Southern Asia, bordering the Bay of
Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
total: 144,000 sq km
/and; 133,910 sq km
water: 10,090 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries;
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline; 580 km
Maritime claims;
contiguous zone: 18 nm
continental shelf: up to the outer limits of the
continental margin
exclusive economic zone: 200 nm
femfona/ sea; 12 nm
Climate: tropical; cool, dry winter (October to
March); hot, humid summer (March to June); cool,
rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Keokradong 1 ,230 m
Natural resources: natural gas, arable land, timber
Land use;
arable land: 73%
permanent crops: 2%
permanent pastures: 5%
forests and woodland: 15%
of/ier;5%(1993est.)
Irrigated land: 31 ,000 sq km (1993 est.)
Natural hazards: droughts, cyclones; much of the
country routinely flooded during the summer monsoon
season
Environment - current issues: many people are
landless and forced to live on and cultivate
flood-prone land; limited access to potable water;
water-borne diseases prevalent; water pollution
especially of fishing areas results from the use of
commercial pesticides; Intermittent water shortages
because of falling water tables In the northern and
central parts of the country; soil degradation;
deforestation; severe overpopulation
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
, '' '' p*g p I -
Population; 129,194,224 (July 2000 est.)
Age structure:
0-14 years: 36% (male 24,055,675; female
22,918,354)
15-64 years: 60% (male 39,924,040; female
37,992,459)
65 years and over: 4% (male 2,342,134; female
1,961,562) (2000 est.)
Population growth rate; 1 .59% (2000 est.)
Birth rate: 25.44 births/1 ,000 population (2000 est.)
Death rate: 8.73 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.77 migrant(s)/1 ,000
population (2000 est.)
Sex ratio;
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 1.19 male(s)/female
total population: 1.05 male(s)/female (2000 est.)
Infant mortality rate: 71 .66 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 60.1 6 years
male: 60.4 years
female: 59.91 years (2000 est.)
Total fertility rate: 2.85 children born/woman
(2000 est.)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladesh
Ethnic groups: Bengali 98%, Biharis 250,000,
tribals less than 1 million
Religions: Muslim 88.3%, Hindu 10.5%, other 1.2%
Languages: Bangia (official), English
Literacy:
definition: age 1 5 and over can read and write
total population: 38.1%
male: 49.4%
female: 26.1% (1995 est.)
41
Bangladesh (continued)','557019b019453fdc95560f22a76c385c1e3f675a44fb052430bc8470008e1add','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67bb40bd5e93429b068cda08e239df5fbe4f10b73dabb4d8bf07fc607d20bbcc',2000,'BY','Belarus','geography',74,'Location: Eastern Europe, east of Poland
Geographic coordinates; 53 00 N, 28 00 E
Map references: Commonwealth of Independent
States
Area;
total: 207,600 sq km
land: 207,600 sq km
wafer; 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
total: 3,098 km
border countries: Latvia 141 km, Lithuania 502 km,
Poland 605 km, Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate; cold winters, cool and moist summers;
transitional between continental and maritime
Terrain: generally flat and contains much marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small
quantities of oil and natural gas
Land use;
arable land: 29%
permanent crops: 1%
permanent pastures: 15%
forests and woodland: 34%
other; 21% (1993 est.)
Irrigated land: 1 ,000 sq km (1993 est.)
Natural hazards; NA
Environment - current issues: soil pollution from
pesticide use; southern part of the country
contaminated with fallout from 1986 nuclear reactor
accident at Chornobyl'' in northern Ukraine
Environment - international agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Biodiversity, Endangered
Species, Environmental Modification, Hazardous
Wastes, Marine Dumping, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change, Law of the
Sea
Geography - note: landlocked
Location: Southeastern Europe, bordering the
Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area:
fofa/;51,129sq km
/arrd.- 51,129 sq km
water: 0 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1 ,459 km
border countries: Croatia 932 km, Serbia and
Montenegro 527 km (312 km with Serbia, 215 km with
Montenegro)
Coastline: 20 km
Maritime ciaims: NA
Ciimate: hot summers and cold winters; areas of
high elevation have short, cool summers and long,
severe winters; mild, rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese,
forests, copper, chromium, lead, zinc, hydropower
Land use:
arable land: 14%
permanent crops: 5%
permanent pastures: 20%
forests and woodland: 39%
other; 22% (1 993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: destructive earthquakes
Environment - current issues: air pollution from
metallurgical plants; sites for disposing of urban waste
are limited; widespread casualties, water shortages,
and destruction of infrastructure because of the
1992-95 civii strife
Environment • international agreements:
party to: Air Pollution, Law of the Sea, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: within Bosnia and Herzegovina''s
recognized borders, the country is divided into a joint
Bosniak/Croat Federation (about 51% of the territory)
and the Bosnian Serb-led Republika Srpska [RS]
(about 49% of the territory): the region called
Herzegovina is contiguous to Croatia and traditionally
has been settled by an ethnic Croat majority','ca5c70648a48df33d58713ef81496c690a918008e7c6e1fbe5e76de70920d951','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55a37d05953083c168783a872566a24414904705ed85d49d03e7dafb8500c891',2000,'NO','Norway','geography',84,'Location: Eastern South America, bordering the
Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00 W
Map references; South America
Area;
total: 8,51 1 ,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha,
Atol das Rocas, llha da Trindade, llhas Martin Vaz,
and Penedos de Sao Pedro e Sao Paulo
Area - comparative; slightly smaller than the US
Land boundaries:
fofa/;14,691 km
border countries: Argentina 1 ,224 km, Bolivia 3,400
km, Colombia 1,643 km, French Guiana 673 km,
Guyana 1,119 km, Paraguay 1,290 km, Peru 1,560
km, Suriname 597 km, Uruguay 985 km, Venezuela
2,200 km
Coastline; 7,491 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
ferr/fona/sea:12nm
Climate; mostly tropical, but temperate in south
67
Brazil (continued)
Terrain: mostly flat to rolling lowlands in north; some
plains, hills, mountains, and narrow coastal belt
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, Iron ore,
manganese, nickel, phosphates, platinum, tin,
uranium, petroleum, hydropower, timber
Land use;
arable land: 5%
permanent crops: t%
permanent pastures: 22%
forests and woodland: 58%
ofher; 14% (1993 est.)
Irrigated land: 28,000 sq km (1993 est.)
Natural hazards: recurring droughts in northeast;
floods and occasional frost in south
Environment - current issues; deforestation In
Amazon Basin destroys the habitat and endangers
the existence of a multitude of plant and animal
species indigenous to the area; air and water pollution
in Rio de Janeiro, Sao Paulo, and several other large
cities; land degradation and water pollution caused by
improper mining activities
note: President CARDOSO in September 1999
signed into force an environmental crime bill which for
the first time defines pollution and deforestation as
crimes punishable by stiff fines and jail sentences
Environment - international agreements;
party to; Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: largest country in South
America; shares common boundaries with every
South American country except Chile and Ecuador
I People
Population: 172,860,370
note: Brazil took an intercensal count in August 1996
which reported a population of 157,079,573; that
figure was about 5% lower than projections by the US
Census Bureau, which is close to the implied
underenumeration of 4.6% for the 1991 census;
estimates for this country explicitly take into account
the effects of excess mortality due to AIDS; this can
result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates,
and changes in the distribution of population by age
and sex than would otherwise be expected (July
2000 est.)
Age structure:
0-14 years: 29% (male 25,607,074; female
24,670,960)
15-64 years: 66% (male 55,793,005; female
57,598,489)
65 years and over: 5% (male 3,727,91 2; female
5,462,930) (2000 est.)
Population growth rate: 0.94% (2000 est.)
Birth rate: 1 8.84 births/1 ,000 population (2000 est.)
Death rate: 9.37 deaths/1,000 population
(2000 est.)
Net migration rate: -0.03 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate; 38.04 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 62.94 years
male: 58.54 years
female: 67.56 years (2000 est.)
Total fertility rate: 2.13 children born/woman
(2000 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white (includes Portuguese,
German, Italian, Spanish, Polish) 55%, mixed white
and black 38%, black 6%, other (includes Japanese,
Arab, Amerindian) 1%
Religions: Roman Catholic (nominal) 80%
Languages: Portuguese (official), Spanish, English,
French
Literacy;
definition: age 15 and over can read and write
total population: 83.3%
male: 83.3%
female: 83.2% (1995 est.)','d5e9a541fc4c2a07dc6bb7e9630c303be4483b6174e90576b4fa6aa33c69aa11','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ed132a21d5f51b1947505468496405e58ee84591df05bbc0cef8f7dd483ce7e',2000,'CM','Cameroon','geography',103,'Location: Western Africa, bordering the Bight of
Biafra, between Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 4,591 km
border countries: Centra] African Republic 797 km,
Chad 1 ,094 km. Republic of the Congo 523 km.
Equatorial Guinea 189 km, Gabon 298 km, Nigeria
1,690 km
Coastline: 402 km
Maritime claims;
territorial sea: 50 nm
Climate: varies with terrain, from tropical along coast
to semiarid and hot in north
Terrain: diverse, with coastal plain in southwest,
dissected plateau in center, mountains in west, plains
in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Fako 4,095 m
Natural resources: petroleum, bauxite, iron ore,
timber, hydropower
Land use;
arable land: 13%
permanent crops: 2%
permanent pastures: 4%
forests and woodland: 78%
other: 3% (1993 est.)
Irrigated land: 210 sq km (1993 est.)
Natural hazards: recent volcanic activity with
release of poisonous gases
Environment - current issues: water-borne
diseases are prevalent; deforestation; overgrazing;
desertification; poaching; overfishing
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: Nuclear Test Ban
Geography - note: sometimes referred to as the
hinge of Africa','18d789135aab9773a2a48a59c4d60cc8beca29daacd46f7c8920f77418723bd8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4744ea4c3d0d5d0ce4353f3dbd2ef70bd99f3be2cc354abb75acaef2a37ade',2000,'AU','Australia','geography',121,'Location: Middle America, atoll in the North Pacific
Ocean, 1 ,1 20 km southwest of Mexico
Geographic coordinates; 10 17 N, 109 13 W
Map references: World
Area:
total: 7 sq km
land: 7 sq km
water: 0 sq km
Area - comparative: about 12 times the size of The
Mall in Washington, DC
Land boundaries; 0 km
Coastline: 11.1km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, humid, average temperature 20-32
degrees C, rains May-October
Terrain: coral atoll
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
ofher; 100% (all coral)
Irrigated land: 0sqkm(1993)
Natural hazards: subject to tornadoes
Environment - current issues: NA
Geography - note: reef about 8 km in circumference
Location: Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela,
and bordering the North Pacific Ocean, between
Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America, Central America
and the Caribbean
Area:
tofa/.- 1,138,910 sq km
land: 1 ,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador Cay,
Serrana Bank, and Serranilla Bank
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,004 km
border countries: Brazil 1 ,643 km, Ecuador 590 km,
Panama 225 km, Peru 1 ,496 km (est.), Venezuela
2,050 km
Coastline: 3,208 km (Caribbean Sea 1,760 km.
North Pacific Ocean 1 ,448 km)
108
Colombia (continued)
Maritime ciaims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: t2 nm
Climate; tropical along coast and eastern plains;
cooler in highlands
Terrain: flat coastal lowlands, central highlands, high
Andes Mountains, eastern lowland plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado del Huila 5,750 m
Natural resources: petroleum, natural gas, coal,
iron ore, nickel, gold, copper, emeralds, hydropower
Land use:
arable land: A%
permanent crops: i%
permanent pastures: 39%
forests and woodland: 48%
of/7er;8%(1993 est.)
Irrigated land: 5,300 sq km (1993 est.)
Natural hazards; highlands subject to volcanic
eruptions; occasional earthquakes; periodic droughts
Environment - current issues; deforestation; soil
damage from overuse of pesticides; air pollution,
especially in Bogota, from vehicle emissions
Environment • international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Consen/ation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Antarctic-Environmental
Protocol, Law of the Sea, Marine Dumping
Geography - note: only South American country
with coastlines on both North Pacific Ocean and
Caribbean Sea
f” "
Population: 39,685,655 (July 2000 est.)
Age structure;
0-14 years: 32% (male 6,463,195; female 6,310,723)
15-64 years: S2% (male 12,206,095; female
12,854,682)
65 years and over: 5% (male 832,986; female
1,017,974) (2000 est.)
Population growth rate: 1.68% (2000 est.)
Birth rate: 22.85 births/1 ,000 population (2000 est.)
Death rate: 5.73 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.33 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 24.7 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 70.28 years
male: 66.43 years
female: 74.27 years (2000 est.)
Total fertility rate: 2.69 children born/woman
(2000 est.)
Nationality;
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions; Roman Catholic 90%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 91 .3%
male: 91 .2%
female: 91 .4% (1995 est.)
I ~§~o V e"r rTSTe n t^
Country name;
conventional long form: Republic of Colombia
conventional short form: Colombia
local long form: Republica de Colombia
local short form: Colombia
Data code; CO
Government type: republic; executive branch
dominates government structure
Capital; Bogota
Administrative divisions: 32 departments
(departamentos, singular - departamento) and 1
capital district* (distrito capital); Amazonas, Antioquia,
Arauca, Atlantico, Bolivar, Boyaca, Caldas, Caqueta,
Casanare, Cauca, Cesar, Choco, Cordoba,
Cundinamarca, Guainia, Guaviare, Huila, La Guajira,
Magdalena, Meta, Narino, Norte de Santander,
Putumayo, Quindio, Risaralda, San Andres y
Providencia, Distrito Capital de Santa fe de Bogota*,
Santander, Sucre, Tolima, Valle del Cauca, Vaupes,
Vichada
Independence; 20 July 1810 (from Spain)
National holiday: Independence Day, 20 July
(1810)
Constitution: 5 July 1 991
Legal system: based on Spanish law; a new
criminal code modeled after US procedures was
enacted in 1992-93; judicial review of executive and
legislative acts; accepts compulsory ICJ jurisdiction,
with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Andres PASTRANA (since 7
August 1998); Vice President Gustavo BELL Lemus
(since 7 August 1 998); note - the president is both the
chief of state and head of government
head of government: President Andres PASTRANA
(since 7 August 1998); Vice President Gustavo BELL
Lemus (since 7 August 1998); note - the president is
both the chief of state and head of government
cabinet: Cabinet
elections: president elected by popular vote for a
four-year term; election last held 31 May 1 998 (next to
be held NA May 2002); vice president elected by
popular vote for a four-year term in a new procedure
that replaces the traditional designation of vice
presidents by newly elected presidents; election last
held 31 May 1 998 (next to be held NA May 2002)
election results: no candidate received more than
50% of the total vote, therefore, a run-off election to
select a president from the two leading candidates
was held 21 June 1998; Andres PASTRANA elected
president; percent of vote - 50.3%; Gustavo BELL
elected vice president; percent of vote - 50.3%
Legislative branch: Bicameral Congress or
Congreso consists of the Senate or Senado (102
seats; members are elected by popular vote to serve
four-year terms) and the House of Representatives or
Camara de Representantes (1 63 seats; members are
elected by popular vote to serve four-year terms)
elections: Senate - last held NA March 1 998 (next to
be held NA March 2002); House of Representatives -
last held NA March 1998 (next to be held NA March
2002)
election results: Senate - percent of vote by party - PL
50%, PSC 24%, smaller parties (many aligned with
conservatives) 26%; seats by party - PL 58, PSC 28,
smaller parties 16; House of Representatives -
percent of vote by party - PL 52%, PSC 17%, other
31%; seats by party - PL 98, PSC 52, indigenous
parties 2, others 11
Judicial branch: Supreme Court of Justice or Corte
Suprema de Justical, highest court of criminal law,
judges are selected from the nominees of the Higher
Council of Justice for eight-year terms; Council of
State, highest court of administrative law, judges are
selected from the nominees of the Higher Council of
Justice for eight-year terms; Constitutional Court,
guards integrity and supremacy of the constitution,
rules on constitutionality of laws, amendments to the
constitution, and international treaties
Political parties and leaders; Democratic
Alliance-April 1 9 Movement or AD/M-1 9 is a coalition
of small leftist parties and dissident liberals and
conservatives [Carlos Franco ECHAVARRIA, Antonio
NAVARRO Wolff, Otty PATINO, Carlos Alonso
LUCIOj; Liberal Party or PL [Jose Fernando
BAUTISTA]; New Democratic Force or NDF [leader
NAj; Patriotic Union or UP is a legal political party
formed by Revolutionary Armed Forces of Colombia
or FARC and Colombian Communist Party or PCC
[Aida ABELLAj; Social Consen/ative Party or PSC [Dr.
Eugenio MERLANO de la Ossa]
Political pressure groups and leaders: two largest
insurgent groups active in Colombia - National
Liberation Army or ELN; and Revolutionary Armed
Forces of Colombia or FARC
International organization participation; BCIE,
CAN, Caricom (observer), CCC, CDB, ECLAC, FAO,
G- 3, G-11, G-24, G-77, lADB, IAEA, IBRD, ICAO,
ICC, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, IHO, ILO,
IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM, ISO,
ITU, LAES, LAIA, NAM, OAS, OPANAL, OPCW,
109
Colombia (continued)
PCA, RG, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UNU, UPU, WCL, WFTU, WHO, WlPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Luis Alberto MORENO
Mejia
chancery.'' 21 18 Leroy Place NW, Washington, DC
20008
fe/ep/7one;[1](202) 387-8338
FAX: [1] (202) 232-8643
consuiate(s) general, Boston, Chicago, Houston, Los
Angeles, Miami, New Orleans, New York, San
Francisco, San Juan (Puerto Rico), and Washington,
DC
consulate(s): Atlanta
Diplomatic representation from the US:
chief of mission: Ambassador Curtis Warren
KAMMAN
embassy: Calle 22D-BIS, numbers 47-51 , Apartado
Aereo 3831
mailing address: APO AA 34038
fe/ep/7one;[57](1)315-0811
FAY; [571(1)315-2197
Flag description: three horizontal bands of yellow
(top, double-width), blue, and red; similar to the flag of
Ecuador, which is longer and bears the Ecuadorian
coat of arms superimposed in the center
Location: Southern Europe, an enclave of Rome
(Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
Area - comparative: about 0.7 times the size of The
Mall in Washington, DC
Land boundaries:
total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (September
to mid-May) with hot, dry summers (May to
September)
Terrain: lowhili
Elevation extremes:
towesfpo/nf; unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
ofoer; 100% (urban area)
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues: NA
Environment ■ international agreements:
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental
Modification
Geography - note: urban; landlocked; enclave of
Rome, Italy; world''s smallest state; outside the
Vatican City, 13 buildings in Rome and Castel
Gandolfo (the pope''s summer residence) enjoy
extraterritorial rights
Location: Middle America, bordering the Caribbean
Sea, between Guatemala and Nicaragua and
bordering the North Pacific Ocean, between El
Salvador and Nicaragua
Geographic coordinates; 1 5 00 N, 86 30 W
Map references: Central America and the
Caribbean
Area;
tofa/.- 112,090 sq km
land: 1 1 1 ,890 sq km
water: 200 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,520 km
border countries: Guatemala 256 km, El Salvador 342
km, Nicaragua 922 km
Coastline: 820 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: natural extension of territory or to
200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; subtropical in lowlands, temperate in
mountains
Terrain: mostly mountains in interior, narrow coastal
plains
Honduras (continued)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, goid, silver, copper,
lead, zinc, iron ore, antimony, coai, fish, hydropower
Land use:
arable land: 15%
permanent crops: 3%
permanent pastures: 1 4%
forests and woodland: 54%
other; 14% (1993 est.)
Irrigated land: 740 sq km (1993 est.)
Natural hazards: frequent, but generally mild,
earthquakes; damaging hurricanes and floods along
Caribbean coast
Environment - current issues: urban population
expanding; deforestation results from logging and the
clearing of land for agricultural purposes; further land
degradation and soil erosion hastened by
uncontrolled development and improper land use
practices such as farming of marginal lands; mining
activities polluting Lago de Yojoa (the country''s
largest source of fresh water) as well as several rivers
and streams with heavy metals; severe Hurricane
Mitch damage
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
f P e 0 p I e
Population: 6,249,598
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 43% (male 1 ,361 ,259; female 1 ,303,041 )
15-64 years: 54% (male 1 ,665,406; female
1,699,680)
65 years and over: 3% (male 1 04,469; female
115,743) (2000 est.)
Population growth rate: 2.52% (2000 est.)
Birth rate: 32.65 births/1 ,000 population (2000 est.)
Death rate: 5.31 deaths/1 ,000 population
(2000 est.)
Net migration rate: -2.17 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 31 .29 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 69.93 years
male: 67.91 years
female: 72.06 years (2000 est.)
Total fertility rate: 4.26 children born/woman
(2000 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant minority
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 15 and over can read and write
total population: 72.7%
male: 72.6%
fema/e; 72.7% (1995 est.)
f "Government
Country name:
conventional long form: Republic of Honduras
conventional short form: Honduras
local long form: Republica de Honduras
local short form: Honduras
Data code: HO
Government type: democratic constitutional
republic
Capital: Tegucigalpa
Administrative divisions: 18 departments
(departamentos, singular - departamento); Atlantida,
Choluteca, Colon, Comayagua, Copan, Cortes, El
Paraiso, Francisco Morazan, Gracias a Dios, Intibuca,
Islas de la Bahia, La Paz, Lempira, Ocotepeque,
Olancho, Santa Barbara, Valle, Yoro
Independence: 15 September 1821 (from Spain)
National holiday: Independence Day, 15
September (1821)
Constitution: 11 January 1982, effective 20 January
1982; amended 1995
Legal system: rooted in Roman and Spanish civil
law with increasing influence of English common law;
recent judicial reforms include abandoning
Napoleonic legal codes in favor of the oral adversarial
system; accepts ICJ jurisdiction, with reservations
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: President Carlos Roberto FLORES
Facusse (since 27 January 1 998); note - the president
is both the chief of state and head of government
head of government: President Carlos Roberto
FLORES Facusse (since 27 January 1 998); note - the
president is both the chief of state and head of
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 15 N, 1 14 10 E
Map references: Southeast Asia
Area:
total: 1 ,092 sq km
land: 1 ,042 sq km
water: 50 sq km
Area - comparative: six times the size of
Washington, DC
Land boundaries:
total: 30 km
border countries: China 30 km
Coastline: 733 km
Maritime ciaims:
territorial sea: 3 nm
Ciimate: tropical monsoon; cool and humid in winter,
hot and rainy from spring through summer, warm and
sunny in fall
Terrain: hilly to mountainous with steep slopes;
lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Ja\\ Mo Shan 958 m
Natural resources: outstanding deepwater harbor,
feldspar
Land use:
arable land: 6%
permanent crops: 1%
permanent pastures: 1 %
forests and woodland: 20%
other; 72% (1 997 est.)
Irrigated land: 20sqkm(1997est.)
Natural hazards: occasional typhoons
Environment - current issues: air and water
pollution from rapid urbanization
Geography - note: more than 200 islands
Location: Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total: 477 sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and
Tinian
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastiine: 1 ,482 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate: tropical marine; moderated by northeast
trade winds, little seasonal temperature variation; dry
season December to June, rainy season July to
October
Terrain: southern islands are limestone with level
terraces and fringing coral reefs; northern islands are
volcanic
Elevation extremes:
lowest point: Pacific Ocean 0 m
370
Northern Mariana Islands (continued)
highest point: unnamed location on Agrihan 965 m
Natural resources; arable land, fish
Land use:
arable land: 21%
permanent crops: 0%
permanent pastures: 1 9%
forests and woodland: 0%
other: 60%
Irrigated land; NA sq km
Natural hazards: active volcanoes on Pagan and
Agrihan; typhoons (especially August to November)
Environment - current issues: contamination of
groundwater on Saipan may contribute to disease;
clean-up of landfill; protection of endangered species
conflicts with development
Geography - note: strategic location in the North
Pacific Ocean
P People
Population; 71 ,912 (July 2000 est.)
Age structure;
0-14 years: 24% (male 8,652; female 8,377)
15-64 years: 75% (male 25,441 ; female 28,233)
65 years and over: 1 % (male 591 ; female 61 8)
(2000 est.)
Population growth rate: 3.75% (2000 est.)
Birth rate: 20.86 births/1 ,000 population (2000 est.)
Death rate: 2.41 deaths/1 ,000 population
(2000 est.)
Net migration rate: 19.06 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1.06 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate: 5.79 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 75.54 years
male: 72.45 years
female: 78.82 years (2000 est.)
Total fertility rate: 1.76 children born/woman
(2000 est.)
Nationality;
noun: NA
adjective: NA
Ethnic groups: Chamorro, Carolinians and other
Micronesians, Caucasian, Japanese, Chinese,
Korean
Religions: Christian (Roman Catholic majority,
although traditional beliefs and taboos may still be
found)
Languages; English, Chamorro, Carolinian
note: 86% of population speaks a language other than
English at home
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 97%
female: 96% (1960 est.)','b04232b8e871d0d3358f8d31c18073ef39b727e266eb7de19ece34cac17afc5c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b455246540766ddaa059e08ef62b8af63e59d669cb9bf7841d623589f406fc3',2000,'CK','Cook Islands','geography',151,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total: 240 sq km
land: 240 sq km
wafer; 0 sq km
Area - comparative: 1 .3 times the size of
Washington, DC .
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly
islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use:
arable land: 9%
permanent crops: 1 3%
permanent pastures: 0%
forests and woodland: 0%
of/7er;78%(1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons (November to March)
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea
signed, but not ratified: Climate Change-Kyoto
Protocol
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Nicaragua and Panama
Geographic coordinates: 1 0 00 N, 84 00 W
Map references: Central America and the
Caribbean
Area;
fofa/;51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; tropical and subtropical; dry season
(December to April); rainy season (May to November);
cooler in highlands
Terrain: coastal plains separated by rugged
mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use;
arable land: 6%
120
Costa Rica (continued)
permanent crops: 5% ''
permanent pastures: 46%
forests and woodland: 31 %
other: 12% (1993 est.)
Irrigated land; 1,200 sq km (1993 est.)
Natural hazards; occasional earthquakes,
hurricanes along Atlantic coast; frequent flooding of
lowlands at onset of rainy season; active volcanoes
Environment - current issues; deforestation,
largely a result of the clearing of land for cattle
ranching; soil erosion; water pollution (rivers);
fisheries protection; solid waste management
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Location: Western Europe, island in the English
Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area:
fofa/;116sq km
/and; 116 sq km
water: 0 sq km
Area - comparative: about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: 3 nm
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills
along north coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: arable land
Land use:
arable land: 66%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 34%
irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
254
JorSGy (continued)
Geography - note: largest and southernmost of
Channel Islands; about 30% of population
concentrated in Saint Helier
I People
Population: 88,915 (July 2000 est.)
Age structure:
0-14 years: 18% (male 8,140; female 7,563)
15-64 years: 68% (male 30,036; female 30,329)
65 years and over: 14% (male 5,454; female 7,393)
(2000 est.)
Population growth rate: 0.52% (2000 est.)
Birth rate: 1 1 .65 births/1 ,000 population (2000 est.)
Death rate: 9.26 deaths/1 ,000 popuiation
(2000 est.)
Net migration rate: 2.81 migrant(s)/1 ,000
popuiation (2000 est.)
Sex ratio:
at birth: 1.11 maie(s)/female
under 15 years: 1 .08 maie(s)/female
15-64 years: 0.99 male(s)/femaie
65 years and over: 0.74 maie(s)/female
total population: 0.96 male(s)/femaie (2000 est.)
Infant mortality rate: 5.71 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.48 years
male: 76.07 years
female: 81 .07 years (2000 est.)
Total fertility rate: 1 .56 children born/woman
(2000 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
Reiigions: Anglican, Roman Catholic, Baptist,
Congregationai New Church, Methodist, Presbyterian
Languages: Engiish (officiai), French (officiai),
Norman-French diaiect spoken in country districts
Literacy:
definition: NA
total: NA
male: NA
female: NA
I Government
Country name:
conventional long form: Baiiiwick of Jersey
conventional short form: Jersey
Data code: JE
Dependency status: British crown dependency
Government type: NA
Capital: Saint Helier
Administrative divisions: none (British crown
dependency)
Independence: none (British crown dependency)
National holiday: Liberation Day, 9 May (1945)
Constitution: unwritten; partly statutes, partly
common law and practice
Legal system: English law and local statute
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: Queen ELiZABETH li (since 6 February
1952)
head of government: Lieutenant Governor and
Commander in Chief Sir Michael WILKES (since NA
1995) and Bailiff Philip Martin BAILHACHE (since NA
1995)
cabinet: committees appointed by the Assembly of the
States
elections: none; the monarch is hereditary; lieutenant
governor and bailiff appointed by the monarch
Legislative branch: unicameral Assembly of the
States (55 voting members - 12 senators, 12
constables or heads of parishes, 29 deputies; all
elected for six-year terms, half elected every third
year; the bailiff and the deputy bailiff; and 3 non-voting
members - the Dean of Jersey, the Attorney General
and the Solicitor General all appointed by the monarch
elections: last held NA (next to be held NA)
election results: percent of vote - NA; seats -
independents 52
Judicial branch: Royal Court, judges elected by an
electoral college and the bailiff
Political parties and leaders: none; all
independents
Diplomatic representation in the US: none (British
crown dependency)
Diplomatic representation from the US: none
(British crown dependency)
Flag description: white with a diagonal red cross
extending to the corners of the flag and in the upper
quadrant, surmounted by a yellow crown, a red shield
holding the three lions of England in yellow
I E c"b n 0 m y"
Economy - overview: The economy is based
largeiy on international financial services, agricuiture,
and tourism. Potatoes, cauliflower, tomatoes, and
especially flowers are important export crops, shipped
mostly to the UK. The Jersey breed of dairy cattie is
known woridwide and represents an important export
income earner. Milk products go to the UK and other
EU countries. In 1 996 the finance sector accounted for
about 60% of the island''s output. Tourism, another
mainstay of the economy, accounts for 24% of GDP.
In recent years, the government has encouraged light
industry to iocate in Jersey, with the result that an
electronics industry has developed alongside the
traditionai manufacturing of knitwear. Aii raw material
and energy requirements are imported, as well as a
large share of Jersey''s food needs. Light taxes and
death duties make the island a popular tax haven.
GDP: purchasing power parity - $2.2 biiiion
(1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$24,800 (1999 est.)
GDP - composition by sector:
agriculture: 5%
industry: 2%
serv/ces; 93% (1996)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 4.7% (1998)
Labor force: 57,050(1996)
Unemployment rate: 0.7% (1998 est.)
Budget:
revenues: $666.9 million
expenditures: %61S.5 miiiion, inciuding capitai
expenditures of $128.4 miiiion (1996 est.)
Industries: tourism, banking and finance, dairy
Industrial production growth rate: NA%
Electricity - production: 266 million kWh
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0%
Electricity - consumption: 467 million kWh (1995)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 201 million kWh (from France)
(1995)
Agriculture - products: potatoes, cauliflower,
tomatoes; beef, dairy products
Exports: $NA
Exports ■ commodities: light industrial and
electrical goods, foodstuffs, textiles
Exports ■ partners: UK
Imports: $NA
Imports ■ commodities: machinery and transport
equipment, manufactured goods, foodstuffs, mineral
fuels, chemicals
Imports - partners: UK
Debt -external: none
Economic aid ■ recipient: none
Currency: 1 Jersey pound = 100 pence
Exchange rates: Jersey pounds per US$1 - 0.6092
(January 2000), 0.61 80 (1 999), 0.6037 (1998), 0.61 06
(1997), 0.6403 (1996), 0.6335 (1995); the Jersey
pound is at par with the British pound
Fiscal year: 1 April - 31 March
I 1: 0 nTm^ n i c a i i 0 n s
Telephones - main lines in use: NA
Telephones - mobile cellular: NA
Telephone system:
domestic: NA
international: 3 submarine cables
Radio broadcast stations: AM NA, FM 1 ,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Internet Service Providers (ISPs): NA
I transportation
Railways: 0 km
Highways:
tofa/; 577 km (1995)
paved: NA km
unpaved: NA km
255
JorSOy (continued)
Ports and harbors: Gorey, Saint Aubin, Saint Heiier
Merchant marine: none (1999 est.)
Airports: 1 (1 999 est.)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:t (1999 est.)
IRA (N-Z-)-
f;“’ ” 1 n t7 0 dh c Fl b iT
Background: The Gilbert Islands were granted
self-rule by the UK in 1971 and complete
independence in 1979 under the new name of Kiribati.
The US relinquished all claims to the sparsely
inhabited Phoenix and Line Island groups in a 1979
treaty of friendship with Kiribati.
p '' g7''o g r a fTh y*
Location; Oceania, group of islands in the Pacific
Ocean, straddling the equator, about one-half of the
way from Hawaii to Australia; note - on 1 January
1995, Kiribati unilaterally moved the International
Date Line from the middle of the country to include its
easternmost islands and make it the same day
throughout the country
Geographic coordinates: 1 25 N, 173 00 E
Map references; Oceania
Area;
total: 7 M sq km
/and; 717 sq km
water: 0 sq km
note: includes three island groups - Gilbert Islands,
Line Islands, Phoenix Islands
Area - comparative; four times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone: 200 nm
ferrifor/a/ sea; 12 nm
Climate: tropical; marine, hot and humid, moderated
by trade winds
Terrain: mostly low-lying coral atolls surrounded by
extensive reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources; phosphate (production
discontinued in 1979)
265
Kiribati (continued)
Land use;
arable land: 0%
permanent crops: 51 %
permanent pastures: 0%
forests and woodland: 3%
other: 46% (1993 est.)
Irrigated land; NAsqkm
Natural hazards; typhoons can occur any time, but
usually November to March; occasional tornadoes;
low-level of some of the islands make them very
sensitive to sea-level rise
Environment - current issues; heavy pollution In
lagoon of south Tarawa atoll due to heavy migration
mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note; 20 of the 33 islands are
inhabited; Banaba (Ocean Island) in Kiribati is one of
the three great phosphate rock islands in the Pacific
Ocean - the others are Makatea in French Polynesia,
and Nauru','aae333a64e86a98b2ab6a0b9f3186a3ec3c31cffc4d1db8f461bfa591ad33f29','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b45eaac385892ea2552ab75cc327aa4ce5e58c9c024a2618a6bb99f707e98483',2000,'CU','Cuba','geography',164,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, south of Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
tofa/; 110,860 sq km
/and; 110,860 sq km
water: 0 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at Guantanamo Bay
29 km
note: Guantanamo Naval Base is leased by the US
and thus remains part of Cuba
Coastline: 3,735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; dry
season (November to April); rainy season (May to
October)
Terrain: mostly flat to rolling plains, with rugged hills
and mountains in the southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore, copper,
manganese, salt, timber, silica, petroleum, arable land
Land use:
arable land: 24%
permanent crops: 7%
permanent pastures: 27%
forests and woodland: 24%
of/ier;18%(1993est.)
Irrigated land: 9,100 sq km (1993 est.)
Natural hazards: the east coast is subject to
hurricanes from August to October (in general, the
country averages about one hurricane every other
year); droughts are common
Environment - current issues: pollution of Havana
Bay; overhunting threatens wildlife populations;
deforestation
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Antarctic-Environmental
Protocol, Climate Change-Kyoto Protocol. Marine Life
Conservation
Geography - note: largest country in Caribbean
Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total: 78,866 sq km
land: n,27& sq km
water: 1 ,590 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1 ,881 km
border countries: ^ustna 362 km, Germany 646 km,
Poland 658 km, Slovakia 215 km
Coastline: 0 km (landlocked)
Maritime ciaims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: Bohemia in the west consists of rolling
plains, hills, and plateaus surrounded by low
mountains; Moravia in the east consists of very hilly
country
Elevation extremes:
lowest point: Elbe River 115m
highest point: Snezka 1 ,602 m
Natural resources: hard coal, soft coal, kaolin, clay,
graphite, timber
Land use:
arable land:
permanent crops: 2%
permanent pastures: 1 1 %
forests and woodland: 34%
offier12%(1993est.)
Irrigated land: 240sqkm(1993est.)
Natural hazards: flooding
Environment - current issues: air and water
pollution in areas of northwest Bohemia and in
northern Moravia around Ostrava present health risks;
acid rain damaging forests
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked; strategically located
astride some of oldest and most significant land routes
in Europe; Moravian Gate is a traditional military
corridor between the North European Plain and the
Danube in central Europe
Location: Eastern Africa, bordering the Gulf of Aden
and the Red Sea, between Eritrea and Somalia
Geographic coordinates: 1 1 30 N, 43 00 E
Map references: Africa
Area:
fofa/; 22,000 sq km
/and; 21,980 sq km
wafer; 20 sq km
Area - comparative; slightly smaller than
Massachusetts
Land boundaries;
total: 508 km
border countries: Eritrea 113 km, Ethiopia 337 km,
Somalia 58 km
Coastline: 314 km
Maritime claims;
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: ^2 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by
central mountains
Elevation extremes;
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
of/;er;91%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: earthquakes; droughts; occasional
cyclonic disturbances from the Indian Ocean bring
heavy rains and flash floods
Environment - current issues: inadequate
supplies of potable water; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near world''s
busiest shipping lanes and close to Arabian oilfields;
terminus of rail traffic into Ethiopia; mostly wasteland','5113ae1ee9e363a231e52ef579679a34ac03090e8b2179a8c5d5d7000fbff722','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83cfbf6a937047967fd16dd7de3b7ec451f77df7ce103e837ee8e6df796500d5',2000,'PE','Peru','geography',175,'r .
Location: Northern Africa, bordering the
Mediterranean Sea, between Libya and the Gaza Strip
Geographic coordinates: 27 00 N, 30 00 E
Map references; Africa
Area;
total: 1 ,001 ,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area - comparative: slightly more than three times
the size of New Mexico
Land boundaries:
total: 2,689 km
border countries: Gaza Strip 1 1 km, Israel 255 km,
Libya 1,150 km, Sudan 1,273 km
Electricity - consumption: 8.981 billion kWh (1 998)
Electricity ■ exports: 0 kWh (1998)
Electricity ■ imports: 0 kWh (1998)
Agriculture - products; bananas, coffee, cocoa,
rice, potatoes, manioc (tapioca), plantains,
sugarcane; cattle, sheep, pigs, beef, pork, dairy
products; balsa wood; fish, shrimp
Exports: $4.1 billion (f.o.b., 1999)
Exports - commodities: petroleum, bananas,
shrimp, coffee, cocoa, cut flowers, fish
Exports - partners: US 39%, Colombia 7%, Italy
6%, Peru 5%, Chile 3% (1998)
Imports: $2.8 billion (c.i.f., 1999)
Imports - commodities: machinery and equipment,
raw materials, fuels; consumer goods
Imports - partners: US 39%, Colombia 11%, Japan
9%, Venezuela 5%, Mexico 3% (1998)
Debt - external: $15.3 billion (1999)
Economic aid - recipient: $695.7 million (1995)
Currency: 1 sucre (SI) = 100 centavos
Exchange rates: sucres (SI) per US$1 - 24,860.7
(January 2000), 11,786.8 (1999), 5,446.6 (1998),
3,988.3 (1997), 3,189.5 (1996), 2,564.5 (1995)
Fiscal year: calendar year
t Communications
Telephones - main lines in use: 748,000 (1995)
Telephones - mobile cellular; 49,776 (1995)
Telephone system:
cfomesf/crfacilities generally inadequate and
unreliable
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean)
Radio broadcast stations; AM 392, FM 27,
shortwave 29 (1998)
Radios: 4.15 million (1997)
Television broadcast stations; 15 (including one
station on the Galapagos Islands) (1997)
Televisions: 1.55 million (1997)
Internet Service Providers (ISPs): 8 (1999)
I transportation
Railways:
total: 81 2 km (single track)
narrow gauge: 812 km 1 .067-m gauge
Highways:
fofa/;43,197 km
paved: 8,165 km
unpaved: 35,032 km (1999 est.)
Waterways: 1,500 km
Pipelines: crude oil 800 km; petroleum products
1,358 km
Ports and harbors: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar, San Lorenzo
Merchant marine:
total: 29 ships (1 ,000 GRT or over) totaling 233,1 51
GRT/388,750 DWT
ships by type: chemical tanker 2, liquified gas 1 ,
passenger 4, petroleum tanker 22 (1 999 est.)
Airports: 182 (1999 est.)
Coastline: 2,450 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 m
Climate: desert; hot, dry summers with moderate
winters
Terrain: vast desert plateau interrupted by Nile
valley and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
147
Egypt (continued)
Natural resources; petroleum, natural gas, Iron ore,
phosphates, manganese, limestone, gypsum, talc,
asbestos, lead, zinc
Land use;
arable land: 2%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
often 98% (1993 est.)
Irrigated land; 32,460 sq km (1993 est.)
Natural hazards; periodic droughts; frequent
earthquakes, flash floods, landslides, volcanic activity;
hot) driving windstorm called khamsin occurs in
spring; dust storms, sandstorms
Environment - current issues; agricultural land
being lost to urbanization and windblown sands;
increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs,
beaches, and marine habitats; other water pollution
from agricultural pesticides, raw sewage, and
industrial effluents; very limited natural fresh water
resources away from the Nile which is the only
perennial water source; rapid growth in population
overstraining natural resources
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography ■ note; controls Sinai Peninsula, only
land bridge between Africa and remainder of Eastern
Hemisphere; controls Suez Canal, shortest sea link
between Indian Ocean and Mediterranean Sea; size,
and juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics
I People
Population; 68,359,979 (July 2000 est.)
Age structure;
0-14 years: 35% (male 12,260,343; female
11,701,253)
15-64 years: 51% (male 21,111,615; female
20,714,511)
65 years and over: 4% (male 1 , 1 31 ,760; female
1,440,497) (2000 est.)
Population growth rate; 1 .72% (2000 est.)
Birth rate; 25.38 births/1 ,000 population (2000 est.)
Death rate; 7.83 deaths/1,000 population
(2000 est.)
Net migration rate; -0.35 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate; 62.32 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 63.33 years
male: 61 .29 years
female: 65.47 years (2000 est.)
Total fertility rate; 3.15 children born/woman
(2000 est.)
Nationality;
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups; Eastern Hamitic stock (Egyptians,
Bedouins, and Berbers) 99%, Greek, Nubian,
Armenian, other European (primarily Italian and
French) 1%
Religions; Muslim (mostly Sunni) 94%, Coptic
Christian and other 6%
Languages; Arabic (official), English and French
widely understood by educated classes
Literacy;
definition: age 15 and over can read and write
total population: 51 .4%
male: 63.6%
fema/e; 38.8% (1995 est.)
|r" ^ G o 7 e r n m e iTi "
Country name;
conventional long form: Arab Republic of Egypt
conventional short form: Egypt
local long form: Jumhuriyat Misr al-Arabiyah
local short form: Misr
former: United Arab Republic (with Syria)
Data code; EG
Government type; republic
Capital; Cairo
Administrative divisions; 26 governorates
(muhafazat, singular - muhafazah); Ad Daqahliyah, Al
Bahr al Ahmar, Al Buhayrah, Al Fayyum, Al
Gharbiyah, Al Iskandariyah, Al Isma''iliyah, Al Jizah, Al
Minufiyah, Al Minya, Al Qahirah, Al Qalyubiyah, Al
Wadi al Jadid, Ash Sharqiyah, As Suways, Aswan,
Asyut, Ban! Suwayf, Bur Sa''id, Dumyat, Janub Sina'',
Kafr ash Shaykh, Matruh, Qina, Shamal Sina'', Suhaj
Independence; 28 February 1922 (from UK)
National holiday; Anniversary of the Revolution, 23
July (1952)
Constitution; 11 September 1971
Legal system; based on English common law,
Islamic law, and Napoleonic codes; judicial review by
Supreme Court and Council of State (oversees
validity of administrative decisions); accepts
compulsory ICJ jurisdiction, with reservations
Suffrage; 1 8 years of age; universal and compulsory
Executive branch;
chief of state: President Mohammed Hosni
MUBARAK (since 14 October 1981)
head of government: Prime Minister Atef OBEID
(since 5 October 1999)
cabinet: Cabinet appointed by the president
elections: president nominated by the People''s
Assembly for a six-year term, the nomination must
then be validated by a national, popular referendum;
national referendum last held 26 September 1999
(next to be held NA October 2005); prime minister
appointed by the president
election results: national referendum validated
President MUBARAK''S nomination by the People''s
Assembly to a fourth term
Legislative branch; bicameral system consists of
the People''s Assembly or Majlis al-Sha''b (454 seats;
444 elected by popular vote, 10 appointed by the
president; members serve five-year terms) and the
Advisory Council or Majlis al-Shura - which functions
only in a consultative role (264 seats; 176 elected by
popularvote, 88 appointed by the president; members
serve NA-year terms)
elections: People''s Assembly - last held 29 November
1 995 (next to be held NA November 2000); Advisory
Council - last held 7 June 1995 (next to be held NA)
election results: People''s Assembly - percent of vote
by party - NDP 72%, Independents 25%, opposition
3%; seats by party ■ NDP 317, independents 114,
NWP 6, NPUG 5, Nasserist Arab Democratic Party 1 ,
LSP 1 ; Advisory Council - percent of vote by party -
NDP 99%, Independents 1%; seats by party - NA
Judicial branch; Supreme Constitutional Court
Political parties and ieaders; Democratic Unionist
Party [Mohammed ''Abd-al-Mun''im TURK]; Green
Party [Kamal KIRAHj; Misr al-Fatah Party (Young
Egypt Party) [leader NA]; Nasserist Arab Democratic
Party [Dia'' al-din DAWUD]; National Democratic Party
or NDP [President Mohammed Hosni MUBARAK,
leader] - governing party; National Progressive
Unionist Grouping or NPUG [Khalid MUHI AL-DIN];
New Wafd Party or NWP [Fu''ad SIRAJ AL-DIN];
Social Justice Party [Muhammad ''ABDAL-''AL];
Socialist Labor Party or SLP [Ibrahim SHUKRI];
Socialist Liberal Party or LSP [Mustafa Kamal
MURAD]; Umma Party [Ahmad al-SABAHI]
note: formation of political parties must be approved
by government
Political pressure groups and leaders; despite a
constitutional ban against religious-based parties, the
technically illegal Muslim Brotherhood constitutes
MUBARAK''S potentially most significant political
opposition; MUBARAK tolerated limited political
activity by the Brotherhood for his first two terms, but
has moved more aggressively in the past six years to
block its influence; trade unions and professional
associations are officially sanctioned
International organization participation; ABEDA,
ACC, ACCT (associate), AfDB, AFESD, AL, AMF,
BSEC (observer), CAEU, CCC, EBRD, ECA,
ESCWA, FAO, G-15, G-19, G-24, G-77, IAEA, IBRD,
ICAO, ICC, ICRM, IDA, IDB, IFAD, IFC, IFRCS, IHO,
ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM,
ISO, ITU, MINURSO, MONUC, NAM, OAPEC, OAS
(observer), OAU, OIC, OSCE (partner), PCA, UN,
UNAMSIL, UNCTAD, UNESCO, UNIDO, UNITAR,
UNMIBH, UNMIK, UNMOP, UNOMIG, UNRWA,
UNTAET, UPU, WFTU, WHO, WlPO, WMO, WToO,
WTrO
Diplomatic representation in the US;
chief of mission: ^mbassador Nabil FAHMY
148
Egypt (continued)
chancery: 3521 International Court NW, Washington,
DC 20008
telephone: [t]{202) 895-5400
FAY; [1] (202) 244-4319, 5131
consulate(s) general: Chicago, Houston, New York,
and San Francisco
Diplomatic representation from the US;
chief of mission: Ambassador Daniel C. KURTZER
embassy: (North Gate) 8, Kamel El-Din Saiah Street,
Garden City, Cairo
mailing address: Unit 64900, APO AE 09839-4900
telephone: [20] (2) 3557371
FAY; [20] (2) 3573200
Flag description: three equal horizontal bands of
red (top), white, and black with the national emblem (a
shield superimposed on a golden eagle facing the
hoist side above a scroll bearing the name of the
country in Arabic) centered in the white band; similar
to the flag of Yemen, which has a plain white band;
also similar to the flag of Syria, which has two green
stars, and to the flag of Iraq, which has three green
stars (plus an Arabic inscription) in a horizontal line
centered in the white band
I Econo m~y
Economy • overview: A series of IMF
arrangements - coupled with massive external debt
relief resulting from Egypt''s participation in the Gulf
war coalition • helped Egypt improve its
macroeconomic performance during the 1990s.
Through sound fiscal and monetary policies, Cairo
tamed Inflation, slashed budget deficits, and built up
foreign reserves. Although the pace of structural
reforms - such as privatization and new business
legislation - has been slower than the IMF envisioned,
Egypt''s steps toward a more market-oriented
economy have prompted increased foreign
investment. Lower combined hard currency inflows -
from tourism, worker remittances, oil revenues, and
Suez Canal tolls - in 1 998 and the first half of 1 999
resulted in pressure on the Egyptian pound and
sporadic dollar shortages, but external payments
were not in crisis. Despite ample reserves, the Central
Bank did not provide sufficient hard currency to
commercial banks and Cairo restricted imports for a
short period; these developments confirmed to some
investors and currency traders that government
financial operations lack sufficient coordination and
openness. Monetary pressures have since eased,
however, with the continued oil price recovery starting
in mid-1999 and a moderate rebound in tourism,
increased gas exports are a major plus factor in future
growth.
GDP: purchasing power parity - $200 billion
(1999 est.)
GDP - real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $3,000
(1999 est.)
GDP - composition by sector:
agriculture: 17%
industry: 32%
serv/ces; 51% (1999)
Population beiow poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: 3.9%
highest 10%; 26.7% (1991)
Inflation rate (consumer prices): 3.7% (1999)
Labor force: 1 9 million (1999 est.)
Labor force - by occupation: agriculture 40%,
services 38%, industry 22% (1990 est.)
Unemployment rate: 1 1 .8% (1 999 est.)
Budget:
revenues: $20.7 billion
expenditures: $22.3 billion, including capital
expenditures of $NA (FY98/99)
Industries: textiles, food processing, tourism,
chemicals, petroleum, construction, cement, metals
Industrial production growth rate: 5% (1999 est.)
Electricity - production: 57.8 billion kWh (1998)
Electricity - production by source:
fossil fuel: 78.72%
hydro: 21. 28%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 53.754 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: cotton, rice, corn, wheat,
beans, fruits, vegetables; cattle, water buffalo, sheep,
goats; fish
Exports: $4,6 billion (f.o.b., 1999 est.)
Exports ■ commodities: crude oil and petroleum
products, cotton, textiles, metal products, chemicals
Exports ■ partners: EU 47%, US 14%, Turkey 8%
(1998)
Imports: $15.8 billion (f.o.b., 1999 est.)
Imports - commodities; machinery and equipment,
foodstuffs, chemicals, wood products, fuels
Imports - partners: EU 42%, US 16%, Japan 5%
(1998)
Debt - external; $30 billion (1999 est.)
Economic aid - recipient: ODA, $2.25 billion (1 999)
Currency: 1 Egyptian pound = 100 piasters
Exchange rates: Egyptian pounds per US$1 -
market rate - 3.4050 (January 2000), 3.4050 (1999),
3.3880 (1998), 3.3880 (1997), 3.3880 (1996), 3.3900
(1995)
Fiscal year: 1 July - 30 June
I’ Com m"u n i c a t i o n s
Telephones - main lines in use: 3.168 million
(1996)
Telephones - mobile cellular; 380,000 (1 999)
Telephone system: large system by Third World
standards but inadequate for present requirements
and undergoing extensive upgrading; Internet access
available
domestic: principal centers at Alexandria, Cairo, Al
Mansurah, Ismailia, Suez, and Tanta are connected
by coaxial cable and microwave radio relay
international: satellite earth stations - 2 Intelsat
(Atlantic Ocean and Indian Ocean), 1 Arabsat, and 1
Inmarsat; 5 coaxial submarine cables; tropospheric
scatter to Sudan; microwave radio relay to Israel; a
participant in Medarabtel and a signatory to Project
Oxygen (a global submarine fiber-optic cable system)
Radio broadcast stations: AM 42 (plus 15 repeater
stations), FM 14, shortwave 3 (1999)
Radios: 20.5 million (1997)
Television broadcast stations: 51 (September
1995)
Televisions: 7.7 million (1997)
Internet Service Providers (ISPs): 31 (1999)
I Transportation
Raiiways;
total: 4,955 km
standard gauge: 4,955 km 1,435-m gauge (42 km
electrified; 1 ,560 km double track)
Highways:
total: 64,000 km
paved: 49,984 km
unpaved: 14,016 km (1996 est.)
Waterways: 3,500 km (including the Nile, Lake
Nasser, Alexandria-Cairo Waterway, and numerous
smaller canals in the delta); Suez Canal, 193.5 km
(including approaches), used by oceangoing vessels
drawing up to 16.1 m of water
Pipelines: crude oil 1,171 km; petroleum products
596 km; natural gas 460 km
Ports and harbors: Alexandria, Al Ghardaqah,
Aswan, Asyut, Bur Safajah, Damietta, Marsa Matruh,
Port Said, Suez
Merchant marine;
total: 1 80 ships (1 ,000 GRT or over) totaling
1,348,148 GRT/2,01 4,483 DWT
ships by type: bulk 25, cargo 63, container 1 , liquified
gas 1 , passenger 57, petroleum tanker 14, roll-on/
roll-off 16, short-sea passenger 3 (1999 est.)
Airports: 90 (1999 est.)
Airports - with paved runways;
total: 71
over 3,047 m: 12
2,438 to 3,047 m: 38
1,524 to 2,437 m: 18
914 to 1,523 m: 3
under 914 m; 4 (1999 est.)
Airports - with unpaved runways;
total: 19
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 9 (1 999 est.)
Heliports: 2 (1999 est.)
f Military
Military branches: Army, Navy, Air Force, Air
Defense Command
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 18,164,353 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,766,949 (2000 est.)
149
Egypt (continued)
Military manpower - reaching military age
annualiy;
males: 704,373 (2000 est.)
Military expenditures - dollar figure; $3.28 billion
(FY95/96)
Military expenditures - percent of GDP: 8.2%
(FY95/96)','233b6fd040dbd4afbecdfcc5e152f3952812b12f48bed820da363149d4ae3c4e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f300f594ede32a246f618301bce3b6a878f88fb5c9283b3e9e4ccff8d80ca331',2000,'FR','France','geography',187,'Location: Southern South America, islands in the
South Atlantic Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and West
Falkland and about 200 small islands
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 200 nm
exclusive fishing zone: 200 nm
terr/''tonal sea; 1 2 nm
Climate: cold marine; strong westerly winds, cloudy,
humid; rain occurs on more than half of days in year;
occasional snow all year, except in January and
February, but does not accumulate
Terrain: rocky, hilly, mountainous with some boggy,
undulating plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
162
Falkland Islands (Islas Malvinas) (continued)
highest point: Mount Usborne 705 m
Natural resources: fish, wildlife
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 99%
forests and woodland: 0%
other: 1% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: strong winds persist throughout
the year
Environment - current issues; NA
Geography - note: deeply Indented coast provides
good natural harbors; short growing season
i People
Population: 2,826 (July 2000 est.)
Age structure:
0-14 years; NA
15-64 years: NA
65 years and over: tiA
Population growth rate: 2.44% (2000 est.)
Birth rate:- NA births/1,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate; NA migrant(s)/1 ,000 popuiation
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality;
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions; primarily Anglican, Roman Catholic,
United Frpe Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages; English
I Government
Country name;
conventional long form: none
conventional short form: FaMand isiands (islas
Malvinas)
Data code: FA
Dependency status: overseas territory of the UK,
also claimed by Argentina
Government type; NA
Capital: Stanley
Administrative divisions: none (overseas territory
of the UK; also claimed by Argentina)
Independence: none (overseas territory of the UK;
also claimed by Argentina)
National holiday: Liberation Day, 14 June (1982)
Constitution: 3 October 1985; amended 1997
Legal system: English common iaw
Suffrage: 1 8 years of age; universal
Executive branch;
chief of state: Queen ELIZABETH II (since 6 February
1952)
head of government: Governor Donald LAMONT
(since NA May 1999); Chief Executive A. M. GURR
(since NA); Financial Secretary D. F. HOWATT (since
NA)
cabinet: Executive Council; three members elected by
the Legislative Council, two ex officio members (chief
executive and the financial secretary), and the governor
elections: none; the monarch is hereditary; governor
appointed by the monarch
Legislative branch; unicameral Legislative Council
(1 0 seats - 2 ex officio, 8 eiected by popular vote,
members serve four-year terms)
elections: last held 9 October 1997 (next to be held
NA October 2001)
election results: percent of vote - NA; seats -
independents 8
Judicial branch: Supreme Court, chief justice is a
nonresident
Political parties and leaders; none; all
independents
International organization participation; iCFTU
Diplomatic representation in the US: none
(overseas territory of the UK; also claimed by
Argentina)
Diplomatic representation from the US; none
(overseas territory of the UK; aiso claimed by
Argentina)
Flag description: blue with the flag of the UK In the
upper hoist-side quadrant and the Falkland Island
coat of arms in a white disk centered on the outer half
of the flag; the coat of arms contains a white ram
(sheep raising is the major economic activity) above
the sailing ship Desire (whose crew discovered the
islands) with a scroll at the bottom bearing the motto
DESIRE THE RIGHT
If E ^ "o n b m y
Economy - overview: The economy was formerly
based on agriculture, mainly sheep farming, but today
fishing contributes the bulk of economic activity. In
1 987 the government began selling fishing licenses to
foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees total more
than $40 million per year, which goes to support the
island''s health, education, and welfare system. Squid
accounts for 75% of the fish taken. Dairy farming
supports domestic consumption; crops furnish winter
fodder. Exports feature shipments of high-grade wool
to the UK and the sale of postage stamps and coins.
To encourage tourism, the Faikland Isiands
Development Corporation has built three lodges for
visitors attracted by the abundant wildlife and trout
fishing. The islands are now self-financing except for
defense. The British Geoiogicai Survey announced a
200-mile oil exploration zone around the islands in
1993, and early seismic surveys suggest substantial
reserves capable of producing 500,000 barrels per
day; to date no exploitable site has been identified. An
agreement between Argentina and the UK in 1995
seeks to defuse licensing and sovereignty conflicts
that would dampen foreign interest in exploiting
potential oil reserves.
GDP: purchasing power parity - $NA
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $NA
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 3.6% (1998)
Labor force: 1,100 (est.)
Labor force - by occupation: agriculture 95%
(mostly sheepherding and fishing)
Unemployment rate: full employment; labor
shortage
Budget:
reverrues; $66.1 million
expenditures: $66.8 million, including capital
expenditures of $NA (FY97/98 est.)
Industries: wool and fish processing; sale of stamps
and coins
Industrial production growth rate; NA%
Electricity - production: 12 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 11 million kWh (1998)
Electricity ■ exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture ■ products: fodder and vegetable
crops; sheep, dairy products
Exports; $7.6 million (1995)
Exports - commodities: wool, hides, meat
Exports - partners: UK, Japan
Imports: $24.7 million (1995)
Imports - commodities: fuel, food and drink,
building materials, clothing
Imports - partners; UK, Japan
Debt - external: $NA
Economic aid - recipient: $1 .7 million (1995)
Currency; 1 Falkland pound = 100 pence
Exchange rates: Falkland pound per US$1 - 0.6092
(January 2000), 0.61 80 (1 999), 0.6037 (1998), 0.61 06
(1997), 0.6403 (1996), 0.6335 (1995); note - the
Falkland pound is at par with the British pound
Fiscal year: 1 April - 31 March
I Communications
Telephones - main lines in use; NA
Telephones - mobile cellular: NA
Telephone system;
domestic: government-operated radiotelephone and
private VHF/CB radiotelephone networks provide
effective service to almost all points on both islands
international: satellite earth station - 1 1ntelsat
(Atlantic Ocean) with links through London to other
countries
163
Falkland Islands (Islas Malvinas)
(continued)
Radio broadcast stations: AM 1 , FM 7, shortwave
0(1998)
Radios: 1,000(1997)
Television broadcast stations: 2 (operated by the
British Forces Broadcasting Sen/ice) (1997)
Televisions: 1,000(1997)
Internet Service Providers (ISPs): NA
I transportation
Railways: 0 km
Highways:
total: 348 km
paved: 83 km
unpaved: 265 km
Ports and harbors: Stanley
Merchant marine: none (1999 est.)
Airports: 5 (1999 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:-\\
under 914 m:t (1999 est.)
Airports - with unpaved runways:
total: 3
under 914 m: 3 [1999 est.)
I Military
Military branches: British Forces Falkland Islands
(includes Army, Royal Air Force, Royal Navy, and
Royal Marines), Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
UK
i: Transnational Issues
Disputes - international: claimed by Argentina
iFaroe Islands j .1 . J
I (part of the Kingdom
lof Denmark) \\ I _ |
Background: The population of the Faroe Islands is
largely descended from Viking settlers who arrived in
the 9th century. The islands have been connected
politically to Denmark since the 14th century. A high
degree of self-government was attained in 1948.
I Q-g a p"h "y
Location: Northern Europe, island group between
the Norwegian Sea and the north Atlantic Ocean,
about one-half of the way from Iceland to Norway
Geographic coordinates: 62 00 N, 7 00 W
Map references: Europe
Area:
total: 1 ,399 sq km
land: 1 ,399 sq km
water: 0 sq km (some lakes and streams)
Area - comparative: eight times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
Climate: mild winters, cool summers; usually
overcast; foggy, windy
Terrain: rugged, rocky, some low peaks; cliffs along
most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales, hydropower
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
ofter;94%(1996)
Irrigated land: Osqkm
Natural hazards: NA
Environment - current issues: NA
Geography - note: archipelago of 17 inhabited
islands and one uninhabited island, and a few
uninhabited islets; strategically located along
important sea lanes in northeastern Atlantic;
precipitous terrain limits habitation to small coastal
lowlands
I People
Population: 45,296 (July 2000 est.)
Age structure:
0-14 years: 23% (male 5,233; female 5,163)
15-64 years: 63% (male 15,270; female 13,382)
65 years and over: 1 4% (male 2,788; female 3,460)
(2000 est.)
Population growth rate: 0.83% (2000 est.)
Birth rate: 13.58 births/1 ,000 population (2000 est.)
Death rate: 8.7 deaths/1 ,000 population (2000 est.)
Net migration rate: 3.38 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1 .14 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1.06 male(s)/female (2000 est.)
Infant mortality rate: 6.94 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.43 years
male: 74.96 years
female: 81 .92 years (2000 est.)
Total fertility rate: 2.32 children born/woman
(2000 est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
note: similar to Denmark proper
f Government
Country name:
conventional long form: none
conventional short form: Faroe Islands
local long form: none
local short form: Foroyar
Data code: FO
Dependency status: part of the Kingdom of
Denmark; self-governing overseas administrative
division of Denmark since 1948
Government type: NA
Capital: Torshavn
164
Faroe Islands (continued)
Administrative divisions: none (part of the
Kingdom of Denmark; self-governing overseas
administrative division of Denmark)
Independence: none (part of the Kingdom of
Denmark; seif-governing overseas administrative
division of Denmark)
National holiday: Birthday of the Queen, 16 April
(1940)
Constitution: 5 June 1953 (Danish constitution)
Legal system: Danish
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen MARGRETHE II of Denmark
(since 14 January 1972), represented by High
Commissioner Bente KLINTE, chief administrative
officer (since NA)
head of government: Prime Minister Anfinn
KALLSBERG (since 9 May 1998)
cabinet: Landsstyri eiected by the Faroese Parliament
elections: the monarch is hereditary; high
commissioner appointed by the monarch; following
legislative eiections, the leader of the party that wins
the most seats is usually elected prime minister by the
Faroese Parliament; eiection last held 30 April 1998
(next to be held NA 2002)
election results: Anfinn KALLSBERG elected prime
minister; percent of parliamentary vote - NA
Legislative branch: unicameral Faroese Parliament
or Logting (32 seats; members are elected by popular
vote on a proportional basis from the seven
constituencies to serve four-year terms)
elections: last held 30 April 1 998 (next to be held by
NA July 2002)
election results: percent of vote by party - Republican
Party 23.8%, People''s Party 21,3%, Social
Democratic Party 21 .9%, Coalition Party (Union Party,
Labor Front, Home Rule Party) 18%; seats by party -
Republican Party 8, People''s Party 8, Social
Democratic Party 7, Coalition Party 6, other parties 3
note: election of 2 seats to the Danish Parliament was
last held on 1 1 March 1 998 (next to be held by NA
2002): results - percent of vote by party - NA; seats by
party - Social Democratic Party 1, People''s Party 1
Judicial branch: none
Political parties and leaders: Center Party [Tordur
NICLASEN]; Christian People''s Party [Niels Pauli
DANIELSEN]; Home Rule Party [Helena Dam A.
NEYSTABO]; Labor Front [leader NA]; People''s Party
[Oli BRECKMANNj; Republican Party [Finnbogi
ISAKSON]; Social Democratic Party [Joannes
EIDESGAARDj; The Faroese Party [Olavur
CHRISTIANSEN]; Union Party [Edmund JOENSEN]
International organization participation: NC, NIB
Diplomatic representation in the US: none
(self-governing overseas administrative division of
Denmark)
Diplomatic representation from the US: none
(self-governing overseas administrative division of
Denmark)
Flag description: white with a red cross outlined in
blue that extends to the edges of the flag; the vertical
part of the cross is shifted to the hoist side in the style
of the Dannebrog (Danish flag)
f Economy
Economy - overview: After the severe economic
troubles of the early 1 990s, brought on by a drop in the
vital fish catch, the Faroe Islands have come back in
the last few years, with unemployment down to 5% in
mid-1 998. Nevertheless, the almost total dependence
on fishing means the economy remains extremeiy
vulnerable. The Faroese hope to broaden their
economic base by building new fish-processing
plants. Oil finds close to the Faroese area give hope
for deposits in the immediate area, which may lay the
basis to sustained economic prosperity. The Faroese
are supported by a substantial annual subsidy from
Denmark.
GDP: purchasing power parity - $700 million
(1996est.)
GDP - real growth rate: 6% (1996 est.)
GDP - per capita: purchasing power parity -
$16,000(1996 est.)
GDP - composition by sector:
agriculture: 20%
industry: 16%
services: 64% (1 996 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.8% (1996 est.)
Labor force: 20,500 (1 996 est.)
Labor force - by occupation: largely engaged in
fishing, manufacturing, transportation, commerce
Unemployment rate: 5% (1998 est.)
Budget:
revenues: $467 million
expenditures: $468 miliion, including capital
expenditures of $1 1 miliion (1996 est.)
Industries: fishing, shipbuilding, construction,
handicrafts
Industrial production growth rate: NA%
Electricity - production: 186 million kWh (1 998)
Electricity - production by source:
fossil fuel: 53.76%
hydro: 45.7%
nuclear: 0%
of/rer; 0.54% (1998)
Electricity - consumption: 173 million kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: milk, potatoes, vegetables;
sheep; salmon, other fish
Exports: $362 million (f.o.b., 1995)
Exports - commodities: fish and fish products 92%,
animal feedstuffs, transport equipment (ships)
Exports - partners: Denmark 31 %, UK 25%,
Germany 9%, France 7%, Spain 6%, US 2% (1996)
Imports: $315.6 miiiion (c.i.f., 1995)
Imports - commodities: machinery and transport
equipment 17.0%, consumer goods 33%, raw
materials and semi-manufactures 26.9%, fuels
1 1 .4%, fish and sait 6.7%
Imports - partners: Denmark 33%, Norway 18%,
UK 8% Germany 9%, Sweden 5%, US 2% (1996)
Debt - external: $767 million (1995 est.)
Economic aid - recipient: $150 million (annuai
subsidy from Denmark) (1995)
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: Danish kroner (DKr) per US$1 -
7.336 (January 2000), 6.976 (1999), 6.701 (1998),
6.604 (1997), 5.799 (1966), 5.602 (1995)
Fiscal year: calendar year
I l^ommunications
Telephones - main lines in use: 22,000 (1995)
Telephones - mobile cellular: 2,558 (1995)
Telephone system: good international
communications; good domestic facilities
domestic: digitalization was to have been completed
in 1998
international: satellite earth stations - 1 Orion; 1
fiber-optic submarine cable linking the Faroe Islands
with Denmark and Iceland
Radio broadcast stations: AM 1 , FM 13, shortwave
0(1998)
Radios: 26,000(1997)
Television broadcast stations: 7 (plus 51
low-power repeaters) (September 1995)
Televisions: 15,000(1997)
Internet Service Providers (ISPs): NA
I T r a ¥ s p 0 r t a t i o ii
Railways: 0 km
Highways:
total: 458 km
paved: 450 km
unpaved: 8 km (1995 est.)
Ports and harbors: Torshavn, Klaksvik, Tvoroyrl,
Runavik, Fuglafjorour
Merchant marine:
total: 6 ships (1 ,000 GRT or over) totaling 22,853
GRT/1 3,481 DWT
ships by type: cargo 2, petroleum tanker 1 ,
refrigerated cargo 1, roll-on/roll-off 1, short-sea
passenger 1 (1999 est.)
Airports: 1 (1999est.)
Airports - with paved runways:
total: 1
914 to 1,523 m:1 (1999 est.)
I f j { 3 r y''
Military branches: no organized native military
forces; only a small Police Force and Coast Guard are
maintained
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
Location: south of Africa, islands in the southern
indian Ocean, about equidistant between Africa,
Antarctica, and Austraiia; note - French Southern and
Antarctic Lands inciudes ile Amsterdam, lie
Saint-Paul, lies Crozet, and lies Kerguelen in the
southern Indian Ocean, along with the
French-claimed sector of Antarctica, "Adelie Land";
the US does not recognize the French claim to "Adelie
Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total: 7,781 sq km
/and; 7,781 sq km
water: 0 sq km
note; includes Ile Amsterdam, lie Saint-Paul, lies
Crozet and lies Kerguelen; excludes "Adelie Land"
claim of about 500,000 sq km in Antarctica that is not
recognized by the US
Area - comparative: slightly less than 1 .3 times the
size of Delaware
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone: 200 nm from lies
Kerguelen only
territorial sea: 12 nm
Climate: antarctic
Terrain: volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on lies Kerguelen 1 ,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: lie Amsterdam and lie Saint-Paul
are extinct volcanoes
Environment - current issues: NA
Geography - note: remote location in the southern
Indian Ocean
Location: Central Asia, northwest of China
Geographic coordinates: 48 00 N, 68 00 E
Map references: Commonwealth of Independent
States
Area:
tofa/; 2,71 7,300 sq km
land: 2,669,800 sq km
wafer; 47,500 sq km
Area - comparative: slightly less than four times the
size of Texas
Land boundaries:
total: 12,012 km
border counfr/es; China 1,533 km, Kyrgyzstan 1,051
km, Russia 6,846 km, Turkmenistan 379 km,
Uzbekistan 2,203 km
Coastline: 0 km (landlocked)
note: Kazakhstan borders the Aral Sea, now split into
two bodies of water (1 ,070 km), and the Caspian Sea
(1,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot summers,
arid and semiarid
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western Siberia to
oases and desert in Central Asia
Elevation extremes:
lowest point: Vpadina Kaundy -1 32 m
highest point: Khan Tangiri Shyngy (Pik Khan-Tengri)
6,995 m
Natural resources: major deposits of petroleum,
natural gas, coal, iron ore, manganese, chrome ore,
nickel, cobalt, copper, molybdenum, lead, zinc,
bauxite, gold, uranium
Land use:
arable land: 12%
permanent crops: f\\%
permanent pastures: 57%
forests and woodland: 4%
ofber;16%(1996est.)
Irrigated land: 22,000 sq km (1996 est.)
Natural hazards: earthquakes in the south, mud
slides around Almaty
Environment - current issues: radioactive or toxic
chemical sites associated with its former defense
industries and test ranges are found throughout the
country and pose health risks for humans and
animals; industrial pollution is severe in some cities;
because the two main rivers which flowed into the Aral
Sea have been diverted for irrigation, it is drying up
and leaving behind a harmful layer of chemical
pesticides and natural salts; these substances are
then picked up by the wind and blown into noxious
dust storms; pollution in the Caspian Sea; soil
pollution from overuse of agricultural chemicals and
salination from poor infrastructure and wasteful
irrigation practices
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: landlocked
f People
Population: 1 6,733,227 (July 2000 est.)
Age structure:
0-14 years: 27% (male 2,332,284; female 2,260,730)
15-64 years: 65% (male 5,320,938; female
5,638,710)
65 years and over: 8% (male 398,225; female
782,340) (2000 est.)
Population growth rate: -0.05% (2000 est.)
Birth rate: 1 6.78 births/1 ,000 population (2000 est.)
Death rate: 10.56 deaths/1 ,000 population
(2000 est.)
Net migration rate: -6.7 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate: 59.39 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 63. 1 9 years
maie: 57.73 years
female: 68.93 years (2000 est.)
Total fertility rate: 2.03 children born/woman
(2000 est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 46%, Russian
34,7%, Ukrainian 4.9%, German 3.1%, Uzbek 2.3%,
Tatar 1.9%, other 7,1% (1996)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq, state language) 40%,
Russian (official, used in everyday business) 66%
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
maie: 99%
female: 96% (1 989 est.)
Location: Northern Africa, bordering the North
Atlantic Ocean, between Senegal and Western
Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total: 1 ,030,700 sq km
land: 1 ,030,400 sq km
water: 300 sq km
Area - comparative: slightly larger than three times
the size of New Mexico
Land boundaries:
fofa/; 5,074 km
border countries: Mgena 463 km, Mali 2,237 km,
Senegal 813 km. Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara;
some central hills
Elevation extremes:
lowest point: Sebkha de Ndrhamcha -3 m
highest point: Kediet Ijill 910 m
Natural resources: iron ore, gypsum, fish, copper,
phosphate
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 38%
forests and woodland: 4%
often 58% (1993 est.)
Irrigated land: 490 sq km (1993 est.)
Natural hazards: hot, dry, dust/san','40d59162e69dc8a03d2f33ebe742278a3030d3a326292826ef3f942985cfcfaa','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e25929fcc10a97de6aa4ad093fc025fba430a7493c2301824a58f25bd265607',2000,'FR','France','geography',188,'d-laden sirocco
wind blows primarily in March and April; periodic
droughts
Environment - current issues: overgrazing,
deforestation, and soil erosion aggravated by drought
are contributing to desertification; very limited natural
fresh water resources away from the Senegal which is
the only perennial river
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: most of the population
concentrated in the cities of Nouakchott and
Nouadhibou and along the Senegal River in the
southern part of the country
i. People
Population: 2,667,859 (July 2000 est.)
Age structure:
0-14 years: 46% (male 617,077; female 614,961)
15-64 years: 52% (male 677,238; female 697,524)
65 years and over: 2% (male 25,417; female 35,642)
(2000 est.)
Population growth rate: 2.94% (2000 est.)
Birth rate: 43.36 births/1 ,000 population (2000 est.)
Death rate: 13.97 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 78.15 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 50.76 years
male: 48.7 years
female: 52.87 years (2000 est.)
Total fertility rate: 6.29 children born/woman
(2000 est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
320
Mauritania (continued)
Ethnic groups: mixed Maur/black 40%, Maur 30%,
black 30%
Reiigions: Muslim 100%
Languages; Hasanlya Arabic (official), Pular,
Soninke, Wolof (official), French
Literacy;
definition: age 15 and over can read and write
total population: 37.7%
male: 49.6%
female: 26.3% (1 995 est.)
I Go vernment
Country name:
conventional long form: Islamic Republic of
Location: Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area - comparative: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1 ,561 km,
Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of
sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore air
currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of
rocky or sandy surfaces rising to small mountains in
south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 1 9%
forests and woodland: 0%
other: 81%
Irrigated land: NAsqkm
Natural hazards: hot, dry, dust/sand-laden sirocco
wind can occur during winter and spring; widespread
harmattan haze exists 60% of time, often severely
restricting visibility
Environment - current issues: sparse water and
lack of arable land
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements','0299e59697e919c807d336831d7488dbac3651c829490108bc81f0dd38be7dc5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57fb63ff46f243d892b96f012511bdc88194e28d37312c5d5dea0d2c1098e94d',2000,'DK','Denmark','geography',189,'f transiiationai Issues
Disputes - international: none
165
I introduction
Background: Fiji became independent in 1 970, after
nearly a century as a British colony. Democratic rule
was interrupted by two military coups in 1 987, caused
by concern over a government perceived as
dominated by the Indian community (descendants of
contract laborers brought to the islands by the British
in the 19th century). A 1990 constitution favored
native Melanesian control of Fiji, but led to heavy
Indian emigration; the population loss resulted in
economic difficulties, but ensured that Melanesians
became the majority. Amendments enacted in 1997
made the constitution more equitable. Free and
peaceful elections in 1999 resulted in a government
led by an Indo-Fijian. Fiji has been a major contributor
to UN peacekeeping missions in various parts of the
world.
r Geography
Location: Oceania, island group in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','99d83c15afebe6bfd9bb7192607a61f55bd2b55def5ec9404b1b305ee37927a7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('272e69a12a68c9a9c660a7b73fb94e881d8c3ac6a4abffaac3cb2f21dd97eaf3',2000,'NZ','New Zealand','geography',190,'Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
total: 18,270 sq km
/and; 1 8,270 sq km
water: 0 sq km
Area - comparative: slightly smaller than New
Location: Oceania, islands in the South Pacific
Ocean, southeast of Austraiia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,670 sq km
wafer; 10 sq km
note: inciudes Antipodes isiands, Auckland Islands,
Bounty Islands, Campbell Island, Chatham Islands,
and Kermadec Islands
Area - comparative: about the size of Coiorado
Land boundaries: 0 km
Coastiine: 15,134 km
Maritime ciaims:
continental shelf: 200 nm or to the edge of the
continentai margin
exclusive economic zone: 200 nm
territorial sea: t2nm
Ciimate: temperate with sharp regionai contrasts
Terrain: predominately mountainous with some
iarge coastai plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Cook 3,764 m
Natural resources: natural gas, iron ore, sand, coai,
timber, hydropower, gold, limestone
Land use:
arable land: 9%
permanent crops: 5%
permanent pastures: 50%
forests and woodland: 28%
of/ier;8%(1993est.)
Irrigated land: 2,850 sq km (1993 est.)
Natural hazards: earthquakes are common, though
usually not severe; volcanic activity
Environment - current issues: deforestation; soii
erosion; native flora and fauna hard-hit by species
introduced from outside
Environment - international agreements:
party to; Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: CWmaie Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: about 80% of the population
lives in cities
Location: Middle America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Costa Rica and Honduras
Geographic coordinates: 1 3 00 N, 85 00 W
Map references: Central America and the
Caribbean
Area;
total: 129,494 sq km
land: 120,254 sq km
water: 9,240 sq km
Area - comparative: slightly smaller than the state
of New York
Land boundaries;
total: 1 ,231 km
border countries: Costa Rica 309 km, Honduras 922
km
Coastline: 910 km
Maritime claims;
contiguous zone: 25-nm security zone
continental shelf: natural prolongation
territorial sea: 200 nm
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to
central interior mountains; narrow Pacific coastal plain
interrupted by volcanoes
360
Nicaragua (continued)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten,
lead, zinc, timber, fish
Land use:
arable land: 9%
permanent crops: 1 %
permanent pastures: 46%
forests and woodland: 27%
other: 17% (1993 est.)
Irrigated land: 880 sq km (1993 est.)
Natural hazards: destructive earthquakes,
volcanoes, landslides, and occasionally severe
hurricanes
Environment - current issues: deforestation; soil
erosion; water pollution; Hurricane Mitch damage
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Nuclear Test Ban,
Ozone Layer Protection, Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea
^
Population: 4,812,569 (July 2000 est.)
Age structure:
0-14 years: 40% (male 971 ,580; female 936,888)
15-64 years: 57% (male 1 ,372,169; female
1,392,861)
65 years and over: 3% (male 60,539; female 78,532)
(2000 est.)
Population growth rate: 2.2% (2000 est.)
Birth rate: 28.26 births/1 ,000 population (2000 est.)
Death rate: 4.9 deaths/1 ,000 population (2000 est.)
Net migration rate: -1 .35 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years; 0.99 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 34.79 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 68.74 years
male: 66.81 years
fema/e; 70.77 years (2000 est.)
Totai fertility rate: 3.27 children born/woman
(2000 est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
Religions: Roman Catholic 85%, Protestant
Languages: Spanish (official)
note: English and indigenous languages on Atlantic
coast
Literacy:
definition: age 15 and over can read and write
total population: 65.7%
male: 64.6%
female: 66.6% (1995 est.)
F Government
Country name:
conventional long form: Republic of Nicaragua
conventional short form: Nicaragua
local long form: Republics de Nicaragua
local short form: Nicaragua
Data code: NU
Government type: republic
Capital: Managua
Administrative divisions: 15 departments
(departamentos, singular - departamento), 2
autonomous regions* (regiones autonomistas,
singular - region autonomists); Boaco, Carazo,
Chinandega, Chontales, Esteli, Granada, Jinotega,
Leon, Madriz, Managua, Masaya, Matagalpa, Nueva
Segovia, Rio San Juan, Rivas, Atlantico Norte*,
Atlantico Sur*
Independence: 15 September 1821 (from Spain)
National holiday: Independence Day, 15
September (1821)
Constitution: 9 January 1987, with reforms in 1995
and 2000
Legal system: civil law system; Supreme Court may
review administrative acts
Suffrage: 1 6 years of age; universal
Executive branch:
chief of state: President Arnoldo ALEMAN Lacayo (1 0
January 1997); Vice President Enrique BOLANOS
Geyer (10 January 1997); note - the president is both
chief of state and head of government
head of government: President Arnoido ALEMAN
Lacayo (10 January 1997); Vice President Enrique
BOLANOS Geyer (10 January 1997); note - the
president is both chief of state and head of
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total: 748 sq km
/and; 71 8 sq km
water: 30 sq km
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; modified by trade winds; warm
season (December to May), cool season (May to
December)
Terrain: most islands have limestone base formed
from uplifted coral formation; others have limestone
overlying volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island 1 ,033
m
Natural resources: fish, fertile soil
494
Tonga (continued)
Land use:
arable land: 24%
permanent crops: 43%
permanent pastures: 6%
forests and woodland: 1 1 %
other: 16% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: cyclones (October to April);
earthquakes and volcanic activity on Fonuafo''ou
Environment - current issues: deforestation
results as more and more land is being cleared for
agriculture and settlement; some damage to coral
reefs from starfish and indiscriminate coral and shell
collectors; overhunting threatens native sea turtle
populations
Environment - international agreements:
party to: Biodiversity, Ciimate Change,
Desertification, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Czone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: archipelago of 170 islands (36
inhabited)
I People
Population: 102,321 (July 2000 est.)
Age structure:
0-14 years: 41 .52% (male 21 ,633; female 20,850)
15-64 years: 54.43% (male 27,41 9; female 28,274)
65 years and over: 4.05% (male 1 ,877; female 2,268)
(2000 est.)
Population growth rate: 1 .91% (2000 est.)
Birth rate: 24.92 births/1 ,000 population (2000 est.)
Death rate: 5.86 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.09 male(s)/female (2000 est.)
Infant mortality rate: 14.45 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 67.94 years
male: 65.54 years
female: 70.45 years (2000 est.)
Total fertility rate: 3.2 children born/woman
(2000 est.)
Nationality:
noun;Tongan(s)
adjective: Tongar\\
Ethnic groups: Polynesian, Europeans about 300
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.5%
male: 98.4%
female: 98.7% (1 996 est.)
I Government
Country name:
conventional long form: Kingdom of Tonga
conventional short form: Tonga
former: Friendly Islands
Data code: TN
Government type: hereditary constitutional
monarchy
Capital: Nuku''alofa
Administrative divisions: three island groups;
Ha''apal, Tongatapu, Vava''u
Independence: 4 June 1 970 (emancipation from UK
protectorate)
National holiday: Emancipation Day, 4 June (1 970)
Constitution: 4 November 1875, revised 1 January
1967
Legal system: based on English law
Suffrage: 21 years of age; universal
Executive branch:
chief of state: King Taufa''ahau TUPCU IV (since 16
December 1965)
head of government: Prime Minister Baron VAEA
(since 22 August 1991) and Deputy Prime Minister S.
Langi KAVALIKU (since 22 August 1991)
cabinet: Cabinet appointed by the monarch
note: there is also a Privy Council that consists of the
monarch and the Cabinet
elections: none; the monarch is hereditary; prime
minister and deputy prime minister appointed for life
by the monarch
Legislative branch: unicameral Legislative
Assembly or Fale Alea (30 seats - 12 reserved for
cabinet ministers sitting ex officio, nine for nobles
selected by the countiys 33 nobles, and nine elected
by popular vote; members serve three-year terms)
elections: last held NA March 1999 (next to be held
NA2002)
election results: percent of vote - pro-democratic
40%; seats - pro-democratic 5, traditionalist 4
Judicial branch: Supreme Court, judges are
appointed by the monarch; Privy Council with the
addition of the chief justice of the Supreme Court sits
as the Court of Appeal
Political parties and leaders: Human Rights and
Democracy Movement [Huliki WATAB, chairman,
Viliami FUKOFUKA, president, ''Akilisi POHIVA, vice
presidentj
International organization participation: ACP,
AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO, ICFTU,
ICRM, IDA, IFAD, IFC, IFRCS, IHO, IMF, Intelsat
(nonsignatory user), Interpoi, IOC, ITU, Sparteca,
SPC, SPF, UN, UNCTAD, UNESCO, UNIDO, UPU,
WHO, WMO, WTrO (applicant)
Diplomatic representation in the US: Tonga does
not have an embassy in the US; Ambassador Akosita
FiNEANGANOFO, resides in London; address:
Embassy of the Kingdom of Tonga, do Tonga High
Commission, 36 Molyneux Street, London W1 H 6AB,
teiephone [44] (1 71 ) 724-5828, FAX [44] (1 71 )
723-9074
consulate(s) general: San Francisco
Diplomatic representation from the US: the US
does not have an embassy in Tonga; the ambassador
to Fiji is accredited to Tonga
Flag description: red with a bold red cross on a
white rectangie in the upper hoist-side corner
j; Economy
Economy - overview: The economy''s base is
agriculture, which contributes 30% to GDP. Squash,
■ coconuts, bananas, and vanilla beans are the main
crops, and agricuitural exports make up two-thirds of
total exports. The country must import a high proportion
of its food, mainly from New Zealand. The industrial
sector accounts for only 1 0% of GDP. Tourism is the
primary source of hard currency earnings. The country
remains dependent on sizabie externai aid and
remittances to offset its trade deficit. The government is
emphasizing the development of the private sector,
especiaily the encouragement of investment.
GDP: purchasing power parity - $238 million
(1998 est.)
GDP - real growth rate: -0.3% (1998 est.)
GDP ■ per capita: purchasing power parity - $2,200
(1998 est.)
GDP - composition by sector:
agriculture: 30%
industry: 10%
serv/ces; 60% (1997)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3.2% (1998 est.)
Labor force: 36,665 (1994)
Labor force - by occupation: agriculture 65%
(1997 est.)
Unemployment rate: 1 1 .8% (FY93/94)
Budget:
revenues: $49 million
expenditures: $120 million, including capital
expenditures of $75 miilion (FY96/97 est.)
Industries: tourism, fishing
Industrial production growth rate: 1 .9%
(FY95/96)
Electricity - production: 35 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% {1998)
Electricity - consumption: 33 million kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: squash, coconuts, copra,
bananas, vanilla beans, cocoa, coffee, ginger, black
pepper; fish
Exports: $8 million (f.o.b., 1998)
Exports - commodities: squash, fish, vanilla beans
495
Tonga (continued)
Exports - partners: Japan 53%, US 18%, NZ 6%,
Australia 6%(1997est.)
Imports: $69 million (f.o.b., 1998)
Imports - commodities: foodstuffs, machinery and
transport equipment, fuels, chemicals
Imports - partners: NZ 30%, Australia 19%, US
11%, UK 11%, Japan 3% (1997 est.)
Debt - external: $62 million (1 998)
Economic aid - recipient: $38.8 million (1995)
Currency: 1 pa''anga (T$) = 100 seniti
Exchange rates: pa''anga (T$) per US$1 - 1 .6250
(November 1999), 1.4921 (1998), 1.2635 (1997),
1.2323 (1996), 1.2709 (1995)
Fiscal year: 1 July - 30 June
I Communications
Teiephones - main lines in use: 7,000 (1995)
Teiephones - mobile ceiluiar: 114(1 995)
Telephone system:
domestic: NA
international: satellite earth station - 1 1ntelsat (Pacific
Ocean)
Radio broadcast stations: AM 1 , FM 2, shortwave
1 (1998)
Radios: 61,000(1997)
Television broadcast stations: 1 (1997)
Televisions: 2,000(1997)
Internet Service Providers (ISPs): 1 (1999)
I Transportation
Railways: 0 km
Highways:
total: 680 km
paved; 184 km
unpaved: 496 km (1996 est.)
Ports and harbors: Neiafu, Nuku''alofa, Pangai
Merchant marine:
total:? ships (1,000 GRT or over) totaling 17,760
GRT/25,948 DWT
ships by type: bulk 1 , cargo 2, liquified gas 2,
petroleum tanker 1 , roll-on/roll-off 1 (1999 est.)
Airports: 6 (1999 est.)
Airports - with paved runways:
total: 1
2,438 to 3,047 m:1 (1999 est.)
Airports - with unpaved runways:
total: 5
1,524 to 2,437 m:t
914 to 1,523 m: 2
under 914 m; 2 (1999 est.)
Location; Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
northeast of Venezuela
Geographic coordinates; 1 1 00 N, 61 00 W
Map references: Centrai America and the
Caribbean
Area:
total: 5,126 sq km
land: 5,128 sq km
water: 0 sq km
Area - comparative: siightiy smaller than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime ciaims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the outer edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low
mountains
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 15%
permanent crops: 9%
permanent pastures: 2%
forests and woodland: 46%
other; 28% (1993 est.)
Irrigated land: 220 sq km (1993 est.)
Natural hazards; outside usual path of hurricanes
and other tropical storms
Environment - current issues: water pollution from
agricultural chemicals, industrial wastes, and raw
sewage; oil pollution of beaches; deforestation; soil
erosion
Environment ■ international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes He Uvea (Wallis Island), He Futuna
(Futuna Island), He Alofi, and 20 islets
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; hot, rainy season (November to
April); cool, dry season (May to October); rains
2,500-3,000 mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 5%
permanent crops: 20%
permanent pastures: 0%
forests and woodland: 0%
ofter;75%(1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: deforestation (only
small portions of fhe original forests remain) largely as
a result of the continued use of wood as the main fuel
source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone
to erosion; there are no permanent settlements on
Alofi because of the lack of natural fresh water
resources
Geography - note: both island groups have fringing
reefs
i People
Population: 1 5,283 (July 2000 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: HA
Population grovirth rate: NA%
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Infant mortality rate: NA deaths/1 ,000 live births
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
Nationality:
noun.’ WaHisian(s), Futunan(s), or Wallis and Futuna
Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 100%
Languages: French, Wallisian (indigenous
Polynesian language)
Literacy:
definition: age 15 and over can read and write
total population: 50%
male: 50%
fema/e; 50% (1969 est.)','d417a0c7c9348bdfa1c0d3f78fc3701f632d2adbceca43b9706584049a9fa3cb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f36c1e1f27f8d9b44f62703181d8bda2253771698d9eb00948354c6f37bceb2d',2000,'JE','Jersey','geography',191,'Land boundaries: 0 km
Coastiine: 1,129 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to the depth of
exploitation; rectilinear shelf claim added
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold, copper,
offshore oil potential, hydropower
Land use:
arable land: 10%
permanent crops: 4%
permanent pastures: 1 0%
forests and woodland: 65%
of/jer;11%(1993est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: cyclonic storms can occur from
November to January
Environment - current issues: deforestation; soil
erosion
Environment - international agreements:
party to: Biodiversity, Ciimate Change, Climate
Change-Kyoto Protocoi, Desertification, Endangered
Species, Law of the Sea, Marine Life Consen/ation,
Nuclear Test Ban, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography • note: includes 332 islands of which
approximately 110 are inhabited
Land boundaries:
total: 1 ,334 km
border countries: Austria 330 km, Croatia 670 km,
Italy 232 km, Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
Climate: Mediterranean climate on the coast,
continental climate with mild to hot summers and cold
winters in the plateaus and valleys to the east
Terrain: a short coastal strip on the Adriatic, an
alpine mountain region adjacent to Italy and Austria,
mixed mountain and valleys with numerous rivers to
the east
Elevation extremes:
towesfpo/nf; Adriatic Sea 0 m
highest point: T riglav 2,864 m
Natural resources: lignite coal, lead, zinc, mercury,
uranium, silver, hydropower
Land use:
arable land: 12%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 54%
other: 7% (1 996 est.)
Irrigated land: 20sqkm(1993es1.)
Natural hazards: flooding and earthquakes
Environment - current issues: Sava River polluted
with domestic and industrial waste; pollution of coastal
waters with heavy metals and toxic chemicals; forest
damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid
rain
Environment • international agreements:
party to: Air Pollution, Air Pollution-Sulphur 94,
Biodiversity, Climate Change, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Location: Central Europe, east of France, north of','82b04cd4237fe0c9676676ca62eb2507398e4336bf202db25688055d55e4536e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19b091f44f2486b9bd0e56c506a291020df93b3d4a8bc082abedf81a9f5ec014',2000,'PF','French Polynesia','geography',208,'Location: Oceania, archipelago in the South Pacific
Ocean, about one-half of the way from South America
to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total: 4,167 sq km (1 18 isiands and atolls)
land: 3,660 sq km
water: 507 sq km
Area - comparative: slightly less than one-third the
size of Connecticut
Land boundaries: 0 km
Coastiine: 2,525 km
Maritime ciaims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate: tropical, but moderate
Terrain: mixture of rugged high islands and low
islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Oiohena 2,241 m
Natural resources: timber, fish, cobalt, hydropower
Land use:
arable land: 1%
permanent crops: 6%
permanent pastures: 5%
forests and woodland: 31 %
often 57% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: occasional cyclonic storms in
January
Environment - current issues: NA
Geography - note: includes five archipelagoes;
Makatea in French Polynesia is one of the three great
phosphate rock islands in the Pacific Ocean - the
others are Banaba (Ocean Island) in Kiribati and','2bc4ef56eab09ebb65ac10738a8178fe46594b9eef22ce312cb380b9dc4c9627','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('881d9a9e30ccfad5fb9019dc44fe740e58d12cf21c13c0353d0e950c71e4139b',2000,'GH','Ghana','geography',214,'Location: Western Africa, bordering the Gulf of
Guinea, between Cote d''Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total: 238,540 sq km
land: 230,020 sq km
water: 8,520 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,093 km
border countries: Burkina Faso 548 km, Cote d''Ivoire
668 km, Togo 877 km
Coastline: 539 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; warm and comparatively dry along
southeast coast; hot and humid in southwest; hot and
dry in north
Terrain: mostly low plains with dissected plateau in
south-central area
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial diamonds,
bauxite, manganese, fish, rubber, hydropower
Land use:
arable land: 12%
permanent crops: 7%
permanent pastures: 22%
forests and woodland: 35%
ofher;24% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: dry, dusty, harmattan winds occur
from January to March; droughts
Environment - current issues: recent drought in
north severely affecting agricultural activities;
deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations;
water pollution; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Law of the Sea, Nuclear Test Ban,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: Lake Volta is the world''s largest
artificial lake; northeasterly harmattan wind (January
to March)','678b9bfe5b6fdbe4d8544e67489256f660950abbaf0b02c07ab6bd0bd9501345','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb8751668859326fd7b2799f3501b919305764280f93469b992fb2b768733925',2000,'ES','Spain','geography',222,'Location: Southern Africa, group of islands in the
Indian Ocean, northwest of Madagascar
Geographic coordinates: 1 1 30 S, 47 20 E
Map references: Africa
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes He Glorieuse, lie du Lys, Verte Rocks,
Wreck Rock, and South Rock
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other; 100% (all lush vegetation and coconut palms)
Irrigated land: 0 sq km (1993)
Natural hazards: periodic cyclones
Environment - current issues: NA','4655ec4f08ab54cbbb130ad090ecfa0cf4792ac59b47dbcb842484d25bb83351','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dac5b5d65d07b5c3c5457bc1e1cee0bc1f39b4bb60f5aa97fe9c0c3b2aa46f83',2000,'IQ','Iraq','geography',244,'Location: Middle East, bordering the Persian Gulf,
between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total: 437,072 sq km
land: 422, sq km
wafer; 4,910 sq km
Area - comparative: slightly more than twice the
size of Idaho
Land boundaries:
total: 3,631 km
border countries: Iran 1,458 km, Jordan 181 km,
Kuwait 242 km, Saudi Arabia 814 km, Syria 605 km,
Turkey 331 km
Coastline: 58 km
Maritime claims:
continental shelf: not specified
territorial sea: 12 nm
Climate: mostly desert; mild to cool winters with dry,
hot, cloudless summers; northern mountainous
regions along Iranian and Turkish borders experience
cold winters with occasionally heavy snows that melt
in early spring, sometimes causing extensive flooding
in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along
Iranian border in south with large flooded areas;
mountains along borders with Iran and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Haji Ibrahim 3,600 m
Natural resources: petroleum, natural gas,
phosphates, sulfur
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 9%
forests and woodland: 0%
other: 79% (1993 est.)
Irrigated land: 25,500 sq km (1993 est.)
Natural hazards: dust storms, sandstorms, floods
Environment - current issues: government water
control projects have drained most of the inhabited
marsh areas east of An Nasiriyah by drying up or
diverting the feeder streams and rivers; a once sizable
population of Shi''a Muslims, who have inhabited these
areas for thousands of years, has been displaced;
furthermore, the destruction of the natural habitat
poses serious threats to the area''s wildlife
populations; inadequate supplies of potable water;
development of Tigris-Euphrates Rivers system
contingent upon agreements with upstream riparian
Turkey; air and water pollution; soil degradation
(salination) and erosion; desertification
Environment ■ international agreements:
party to: Law of the Sea, Nuclear Test Ban
signed, but not ratified: Environmental Modification','683f5f2905eb8fbc648c103aec432568d10618464742135f7a1f0b7f33e60113','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0017631cbe0b1c6e188f7ea5b9f95440c8ab120aefce913a0b05cc630c5953fe',2000,'TN','Tunisia','geography',255,'Location: Caribbean, island in the Caribbean Sea,
south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the
Caribbean
Area:
total: 10,990 sq km
land: 10,830 sq km
wafer; 160 sq km
Area - comparative; slightly smaller than
Connecticut
permanent pastures: 24%
forests and woodland: 17%
other: 39% (1993 est.)
Irrigated land: 350 sq km (1993 est.)
Natural hazards: hurricanes (especiaiiy Juiy to
November)
Environment - current issues: heavy rates of
deforestation; coastai waters poliuted by industriai
waste, sewage, and oii spilis; damage to corai reefs;
air poliution in Kingston resuits from vehicie emissions
Environment - international agreements;
party to: Biodiversity, Ciimate Change, Ciimate
Change-Kyoto Protocoi, Desertification, Endangered
Species, Law of the Sea, Marine Dumping, Marine
Life Conservation, NuciearTest Ban, Ozone Layer
Protection, Ship Poilution, Wetlands, Whaling
signed, but not ratified: none of the seiected
agreements
Geography - note: strategic iocation between
Cayman Trench and Jamaica Channel, the main sea
ianes for Panama Canai','11dcc459962c33ba340d64f7f53ca6de8664c3ba8c104b84ec43722a2931da80','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b088b0dea1884866d3175f68e5e447ef55de053b5e7274c92cc93c81e1024771',2000,'KE','Kenya','geography',268,'Location: Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
water 13,400 sq km
Area - comparative: slightly more than twice the
size of Nevada
Land boundaries:
total: 3,446 km
border countries: Ethiopia 830 km, Somalia 682 km,
Sudan 232 km, Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: varies from tropical along coast to arid in
interior
Terrain: low plains rise to central highlands bisected
by Great Rift Valley; fertile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: gold, limestone, soda ash, salt
barites, rubies, fluorspar, garnets, wildlife,
hydropower
262
Konya (continued)
Land use;
arable land: 7%
permanent crops: 1 %
permanent pastures: 37%
forests and woodland: 30%
o?/7er25%(1993est.)
Irrigated land: 660sqkm(1993est.)
Natural hazards: recurring drought in northern and
eastern regions; flooding during rainy seasons
Environment - current issues: water pollution from
urban and industrial wastes; degradation of water
quaiity from increased use of pesticides and fertiiizers;
deforestation; soil erosion; desertification; poaching
Environment - international agreements;
party to: Biodiversity, Ciimate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Ship Poiiution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the Kenyan Highlands comprise
one of the most successful agricultural production
regions in Africa; glaciers on Mt. Kenya; unique
physiography supports abundant and varied wildlife of
scientific and economic value
I P e 0 p I e
Population; 30,339,770
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 43% (male 6,566,424; female 6,419,034)
15-64 years: 54% (male 8,284,71 9; female
8,238,121)
65 years and over: 3% (male 366,200; female
465,272) (2000 est.)
Population growth rate: 1 .53% (2000 est.)
Birth rate: 29.35 births/1 ,000 population (2000 est.)
Death rate: 1 4.08 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.02 male(s)/female
/5-64 years; 1.01 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate: 68.74 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 47.98 years
ma/e; 46.95 years
female: 49.04 years (2000 est.)
Total fertility rate: 3.66 children born/woman
(2000 est.)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Meru 6%, other
African 15%, non-African (Asian, European, and
Arab) 1%
Religions: Protestant 38%, Roman Catholic 28%,
indigenous beliefs 26%, Muslim 7%, other 1%
Languages; English (official), Kiswahili (official),
numerous indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 78. 1 %
male: 86.3%
female: 70% (1995 est.)
I Government
Country name:
conventional long form: Republic of Kenya
conventional short form: Kenya
former: British East Africa
Data code: KE
Government type; republic
Capital: Nairobi
Administrative divisions: 7 provinces and 1 area*;
Central, Coast, Eastern, Nairobi Area*, North Eastern,
Nyanza, Rift Valley, Western
Independence: 12 December 1963 (from UK)
National holiday: Independence Day, 12 December
(1963)
Constitution: 12 December 1963, amended as a
republic 1964; reissued with amendments 1979,
1983, 1986, 1988, 1991, 1992, and 1997
Legal system: based on English common law, tribal
law, and Islamic law; judicial review in High Court;
accepts compulsory ICJ jurisdiction, with
reservations; constitutional amendment of 1982
making Kenya a de jure one-party state repealed in
1991
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Daniel Toroitich arap MOI
(since 14 October 1978); note - the president is both
the chief of state and head of government
head of government: President Daniel Toroitich arap
MOI (since 14 October 1978); note - the president is
both the chief of state and head of government
cabinet: Cabinet appointed by the president
elections: president elected by popular vote from
among the members of the National Assembly for a
five-year term; election last held 29 December 1997
(next to be held by early 2003); vice president
appointed by the president
election results: President Daniel Toroitich arap MOI
reelected; percent of vote - Daniel T. arap MOI
(KANU) 40.6%, Mwai KIBAKI (DP) 31.5%, Raila
ODINGA (NDP) 1 1 .1%, Michael WAMALWA
(FORD-K) 8.4%, Charity NGILU (SDP) 7.8%
Legislative branch; unicameral National Assembly
or Bunge (222 seats, 12 appointed by the president.
210 members elected by popular vote to serve
five-year terms)
elections: last held 29 December 1 997 (next to be
held between 1 December 2002 and 30 April 2003)
election results: percent of vote by party - NA; seats
by party - KANU 107, FORD-A 1, FORD-K 17,
FORD-People 3, DP 39, NDP 21 , SDP 15, SAFINA 5,
smaller parties 2; seats appointed by the president -
KANU 6, FORD-K 1 , DP 2, SDP 1 , NDP 1 , SAFINA 1
Judicial branch: Court of Appeal, chief justice is
appointed by the president; High Court
Political parties and leaders: Democratic Party of
Kenya or DP [Mwai KIBAKI]; Forum for the
Restoration of Democracy-Asili or FORD-A [Martin
SHIKUKU, chairman]; Forum for the Restoration of
Democracy-Kenya or FORD-K [Michael Kijana
WAMALWA]; Forum for the Restoration of
Democracy-People or FORD-People [Raymond
MATIBA]; Kenya African National Union or KANU
[President Daniel Toroitich arap MOI] - the governing
party; National Development Party or NDP [Raila
ODINGA, president. Dr. Charles MARANGA,
secretary general]; SAFINA [Farah M/\\ALIM,
chairman, Mghanga MWANDAWIRO, secretary
general]; Social Democratic Party or SDP [Anyang
N''YANGO, secretary general]
Political pressure groups and leaders: human
rights groups; labor unions; Muslim organizations;
National Convention Executive Council or NCEC, a
proreform coalition of political parties and
nongovernment organizations [Kivutha KIBWANA];
Protestant National Council of Churches of Kenya or
NCCK [Mutava MUSYIMI]; Roman Catholic and other
Christian churches; Supreme Council of Kenyan
Muslims or SUPKEM [Shaykh Abdul Gafur
al-BUSAIDY, chairman]
International organization participation; ACP,
AfDB, C, CCC, EADB, ECA, FAO, G-77, IAEA, IBRD,
ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, IGAD,
ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM,
ISO, ITU, MINURSO, MONUC, NAM, OAU, OPCW,
UN, UNAMSIL, UNCTAD, UNESCO, UNIDO,
UNIKOM, UNMIBH, UNMIK, UNMOP, UNU, UPU,
WCL, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
c/r/ef of m/ss/on; Ambassador Samuel K. CHEMAI
(recalled in November 1999)
chancery: 2249 R Street NW, Washington, DC 20008
telephone: [1] [202) 387-6101
FAX; [1] (202) 462-3829
consulate(s) general: Los Angeles and New York
Diplomatic representation from the US:
chief of mission: Ambassador Johnnie CARSON
embassy: US Embassy, Mombasa Road, Nairobi
mailing address: P. 0. Box 301 37, Box 21 A, Unit
64100, APO AE 09831
telephone: [254] (2) 537-800
FAX; [254] (2) 537-810
Flag description: three equal horizontal bands of
black (top), red, and green; the red band is edged in
white; a large warrior''s shield covering crossed spears
is superimposed at the center
263
Konya (continued)
I Economy
Economy - overviewf Kenya is well placed to serve
as an engine of growth in East Africa, but its economy
is stagnating because of poor management and
uneven commitment to reform. In 1993, the
government of Kenya implemented a program of
economic liberalization and reform that included the
removal of import licensing, price controls, and foreign
exchange controls. With the support of the World
Bank, IMF, and other donors, the reforms led to a brief
turnaround in economic performance following a
period of negative growth in the early 1990s. Kenya''s
real GDP grew 5% in 1995 and 4% in 1996, and
inflation remained under control. Growth slowed in
1997-99 however. Political violence damaged the
tourist industry, and Kenya''s Enhanced Structural
Adjustment Program lapsed due to the government''s
failure to maintain reform or address public sector
corruption. A new economic team was put in place in
1 999 to revitalize the reform effort, strengthen the civil
service, and curb corruption, but wary donors
continue to question the government''s commitment to
sound economic policy. Long-term barriers to
development include electricity shortages, the
government''s continued and inefficient dominance of
key sectors, endemic corruption, and the country''s
high population growth rate.
GDP: purchasing power parity - $45.1 billion
(1999 est.)
GDP - real growth rate: 1 .5% (1 999 est.)
GDP - per capita: purchasing power parity - $1 ,600
(1999 est.)
GDP - composition by sector:
agriculture: 26%
industry: 18%
serv/ces; 56% (1999 est.)
Population below poverty line: 42% (1992 est.)
Household income or consumption by percentage
share:
towesf f0%;1.2%
highest 10%: 47.7% {m2}
Inflation rate (consumer prices): 6% (1999 est.)
Labor force: 9.2 million (1998 est.)
Labor force - by occupation: agriculture 75%-80%
Unemployment rate: 50% (1998 est.)
Budget:
revenues: $2.91 billion
expenditures: $2.97 billion, including capital
expenditures of $NA (2000 est.)
Industries: small-scale consumer goods (plastic,
furniture, batteries, textiles, soap, cigarettes, flour),
agricultural products processing; oil refining, cement;
tourism
Industrial production growth rate: 1% (1999 est.)
Electricity - production: 4.23 billion kWh (1998)
Electricity - production by source:
fossil fuel: 8.27%
hydro: 82.74%
nuclear: 0%
ofher; 8.99% (1998)
Electricity - consumption: 4.078 billion kWh (1 998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 144 million kWh (1998)
Agriculture - products: coffee, tea, corn, wheat,
sugarcane, fruit, vegetables; dairy products, beef,
pork, poultry, eggs
Exports: $2.2 billion (f.o.b., 1999 est.)
Exports - commodities: tea, coffee, horticultural
products, petroleum products (1995)
Exports - partners: Uganda 16%, UK 13%,
Tanzania 13%, Egypt 5%, Germany 5% (1998)
Imports: $3.3 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and
transportation equipment, petroleum products, iron
and steel
Imports - partners: UK 12%, UAE 9%, US 8%,
Japan 8%, Germany 6%, India 4% (1998)
Debt - external: $6.5 billion (1 998)
Economic aid - recipient: $457 million (1997)
Currency: 1 Kenyan shilling (KSh) = 100 cents
Exchange rates: Kenyan shillings (KSh) per US$1 -
73.943 (December 1999), 70.326 (1999), 60.367
(1998), 58.732 (1997), 57.115 (1996), 51.430 (1995)
Fiscal year: 1 July - 30 June
I "'' C 0 in m u n Fc a t i o iTs ^
Telephones • main lines in use: 290,000 (1998)
Telephones - mobile cellular: 6,000 (1 999)
Telephone system: unreliable; little attempt to
modernize
domestic: trunks are primarily microwave radio relay;
data commonly transferred by a very small aperature
terminal (VSAT)
international: satellite earth stations - 4 Intelsat
Radio broadcast stations: AM 24, FM 8, shortwave
6(1999)
Radios: 3.07 million (1997)
Television broadcast stations: 8 (1997)
Televisions: 730,000(1997)
Internet Service Providers (ISPs): 7 (1999)
[■ t r a n Fp b rlFT i o n
Railways:
tofa/; 2,778 km
narrow gauge: 2,778 km 1 .000-m gauge
note: the line connecting Nairobi with the port of
Mombasa is the most important in the country
Highways:
total: 63,800 km
paved: 8,868 km
unpaved: 54,932 km (1996 est.)
Waterways: part of the Lake Victoria system is within
the boundaries of Kenya
Pipelines: petroleum products 483 km
Ports and harbors: Kisumu, Lamu, Mombasa
Merchant marine:
total: 2 ships (1 ,000 GRT or over) totaling 4,893 GRT/
6,255 DWT
ships by type: petroleum tanker 1 , roll-on/roll-off 1
(1999 est.)
Airports: 230 (1999 est.)
Airports - with paved runways:
total: 21
over 3,047 m: 4
2,438 to 3,047 m:1
1,524 to 2,437 m: 2
914 to 1,523 m: 14 {1999 est.)
Airports - with unpaved runways:
total: 209
2,438 to 3,047 m:1
1,524 to 2,437 m: 14
914 to 1,523 m: 110
under 914 m: 84 (1999 est.)
I M i I i t a r V
Military branches: Army, Navy, Air Force,
paramilitary General Service Unit of the Police
Military manpower - availability:
mates age 15-49:7,482,095 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 4,631 ,987 (2000 est.)
Military expenditures - dollar figure: $1 97 million
(FY98/99)
Military expenditures - percent of GDP: 1 .9%
(FY98/99)
I f r a n s n a it i 0 n a i Issues
Disputes - international: administrative boundary
with Sudan does not coincide with international
boundary
Illicit drugs: widespread harvesting of small, wild
plots of marijuana and qat (chat); transit country for
South Asian heroin destined for Europe and,
sometimes. North America; Indian methaqualone also
transits on way to South Africa
264
I Geography
Location: Oceania, reef in the North Pacific Ocean,
about one-haif of the way from Hawaii to American','e6142e3a36604c4d848876aaf0e4d2b24e9e22d73d60e3b870a3dd4df7b56b7c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06a198046f66b178e3208c98e2f7acf5e65962daa71c9d0a80b3990daf00d20',2000,'WS','Samoa','geography',269,'Geographic coordinates; 6 24 N, 162 24 W
Map references; Oceania
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area ■ comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries; 0 km
Coastiine; 3 km
Maritime ciaims:
exclusive economic zone: 200 nm
femtoria/ sea; 12 nm
Climate; tropical, but moderated by prevailing winds
Terrain; low and nearly level
Elevation extremes;
lowest point: Pacific Ocean 0 m
h/ghesfpo/nf; unnamed location 1 m
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other; 100%
Irrigated land; 0sqkm(1996)
Natural hazards: wet or awash most of the time,
maximum elevation of about 1 meter makes Kingman
Reef a maritime hazard
Environment - current issues; none
Geography - note: barren coral atoll with deep
interior lagoon; closed to the public
I People
Population: uninhabited (July 2000 est.)
I G 0 V e r n m eh t
Country name:
conventional long form: none
conventional short form: Kingman Reef
Data code; KQ
Dependency status: unincorporated territory of the
US; administered from Washington, DC by the US
Navy; however, it is awash the majority of the time, so
it is not usable and is uninhabited
Flag description: the flag of the US is used
Economy - overview: no economic activity
I Transport a TTo n ^
Ports and harbors: none; offshore anchorage only
Airports; lagoon was used as a halfway station
between Hawaii and American Samoa by Pan
American Airways for flying boats in 1 937 and 1 938
1^'' . M flTt a''^r y ''■ ■''
Military - note: defense is the responsibility of the
US
I t7¥1iT nTtl 0 n a t I s s u eT^^
Disputes - international; none
Ikiribati
0 400 800 km
MARSHALL
. ISUNDS','df5e1dcea66cbafaedd15fe8a5388be81049b4fa82528700d6e83efe3468351f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('310fd27c8bd27c03330a472b415cb33326c327b0434fcc6e76374fa2e2cfaf79',2000,'US','United States','geography',270,'(Hawaii) ^
° Johnston Atoll
(U.S.)
North Pacific Ocean
Kingman Palmyra Atoll
[Equator ^','3bdd0c5598d8f1878334ee33f19e451c22a6e4139c08e98b3467d7b8ca2fb5cd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf884bc360c3f76e9a25cd9a36a889455a2f9ca7f7016d5a44ce5914e7879bec',2000,'KI','Kiribati','geography',271,'(Gilbert
Islands)
Howland 1. (U.s.}
\\ Baker I. (U.s.)
_ Kiiplmati
Jarvis 1.’ (Chrisirnas I.)
Rawaki
^(Phoenix
Islands)
(U^.)
SOLOMON
ISLANDS
Tokelau South Pacific Ocean
- Cook Is. .
.{N.2.) *
■VANUATU
**• French.
American Polynesia *‘
Samoa (U.S.) (|:r.)','20e18ef0ed97e40c24596973c8a740e27849c03209823c2556df9ce8b0f80f6a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06fd03749fdf20da36e2b82043eb11f910137117f3c635c33c494ef848cda9e',2000,'JP','Japan','geography',277,'Location: Eastern Asia, southern half of the Korean
Peninsula bordering the Sea of Japan and the Yellow
Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
fatal: 98,480 sq km
/and; 98,190 sq km
water: 290 sq km
Area - comparative: slightly larger than Indiana
Land boundaries:
total: 238 km
border countries: North Korea 238 km
Coastiine: 2,413 km
Maritime ciaims:
contiguous zone: 24 nm
continental shelf: not specified
exclusive economic zone: 200 nm
territorial sea: 1 2 nm; between 3 nm and 1 2 nm in the
Korea Strait
Climate: temperate, with rainfall heavier in summer
than winter
Terrain: mostly hills and mountains; wide coastal
plains in west and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1 ,950 m
Natural resources: coal, tungsten, graphite,
molybdenum, lead, hydropower potential
Land use:
arable land: 19%
permanent crops: 2%
permanent pastures: 1%
forests and woodland: 65%
ofher; 13% (1993 est.)
Irrigated land: 13,350 sq km (1993 est.)
Natural hazards: occasional typhoons bring high
winds and floods; low-level seismic activity common in
southwest
Environment - current issues: air pollution in large
cities; water pollution from the discharge of sewage
and industrial effluents; drift net fishing
Environment - international agreements:
party to; Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol','2f306add4e981be84659c1c6c43333c5700c1ea875038fed26ba9d08978700c8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4fd1e1c2a99627e5b631a954ec5f812b1306fc1784a413b2168e6747ccf86fb',2000,'CN','China','geography',282,'Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Commonwealth of Independent
States
Area:
total: 1 98,500 sq km
land: 1 91 ,300 sq km
water: 7,200 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 44%
forests and woodland: 4%
other: 45% (1993 est.)
note: Kyrgyzstan has the world''s largest natural
growth walnut forest
Irrigated land; 9,000 sq km (1993 est.)
Natural hazards; NA
Environment ■ current issues: water pollution;
many people get their water directly from
contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil
salinity from faulty irrigation practices
Environment - internationai agreements:
party to: Biodiversity, Desertification, Hazardous
Wastes
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
Location: Southeastern Asia, group of reefs and
islands in the South China Sea, about two-thirds of the
way from southern Vietnam to the southern','9d883c9f255074c62c05a3e5baa549d8bca6bd6df384f10f3bab74095b40e107','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9bd0097882f450684815c7cc027e0c7935667919bd7277d89a34bd84281a900',2000,'EG','Egypt','geography',293,'Location: Northern Africa, bordering the
Mediterranean Sea, between Egypt and Tunisia
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area:
total: 1 ,759,540 sq km
land: 1 ,759,540 sq km
water: 0 sq km
Area - comparative: slightly larger than Alaska
Land boundaries:
total: 4,383 km
border countries: Algeria 982 km, Chad 1 ,055 km,
Egypt 1 ,1 50 km, Niger 354 km, Sudan 383 km,
Tunisia 459 km
Coastline: 1,770 km
Maritime claims;
territorial sea: 12 nm
note: Gulf of Sidra closing line - 32 degrees 30
minutes north
Climate: Mediterranean along coast; dry, extreme
desert interior
Terrain: mostly barren, flat to undulating plains,
plateaus, depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use;
arable land: 1%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other; 91% (1993 est.)
Irrigated land: 4,700 sq km (1993 est.)
Natural hazards; hot, dry, dust-laden ghibli is a
southern wind lasting one to four days in spring and
fall; dust storms, sandstorms
Environment - current issues; desertification; very
limited natural fresh water resources; the Great
Manmade River Project, the largest water
development scheme in the world, is being built to
bring water from large aquifers under the Sahara to
coastal cities
Environment - international agreements:
party to: Climate Change, Desertification, Marine
Dumping, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Biodiversity, Law of the Sea
r People
Population: 5,115,450
note: includes 1 62,669 non-nationals (July 2000 est.)
Age structure:
0-14 years: 36% (male 938,476; female 899,139)
15-64 years: 60% (male 1 ,595,306; female
1,485,069)
65 years and over: 4% (male 97,770; female 99,690)
(2000 est.)
Population growth rate; 2.42% (2000 est.)
Birth rate: 27.68 births/1 ,000 population (2000 est.)
Death rate: 3.51 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1.06 male(s)/female (2000 est.)
Infant mortality rate: 30.08 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 75.45 years
male: 73.34 years
female: 77.66 years (2000 est.)
Total fertility rate: 3.71 children born/woman
(2000 est.)
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
288
Libya (continued)
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 15 and over can read and write
total population: 76.2%
male: 87.9%
female: 63% (1 995 est.)
" Govern nnTn t
Country name:
conventional long form: Socialist People''s Libyan
Arab Jamahiriya
conventional short form: Libya
local long form: M Jumahiriyah al Arabiyah al Libiyah
ash Shabiyah al Ishtirakiyah
local short form: r\\one
Data code: LY
Government type: Jamahiriya (a state of the
masses) in theory, governed by the populace through
local councils; in fact, a military dictatorship
Capital: Tripoli
Administrative divisions: 25 municipalities
(baladiyat, singular - baladiyah); Ajdabiya, Al
''Aziziyah, Al Fatih, Al Jabal al Akhdar, Al Jufrah, Al
Khums, Al Kufrah, An Nuqat al Khams, Ash Shati'',
Awbari, Az Zawiyah, Banghazi, Darnah, Ghadamis,
Gharyan, Misratah, Murzuq, Sabha, Sawfajjin, Suit,
Tarabulus, Tarhunah, Tubruq, Yafran, Zlitan
rjofe.''the 25 municipalities may have been replaced
by 13 regions
Independence: 24 December 1951 (from Italy)
National holiday: Revolution Day, 1 September
(1969)
Constitution: 11 December 1969, amended 2
March 1977
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no
constitutional provision for judicial review of legislative
acts; has not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: Revolutionary Leader Col. Muammar
Abu Minyar al-QADHAFI (since 1 September 1969);
note - holds no official title, but is de facto chief of state
head of government: Secretary of the General
People''s Committee (Premier) Mubarak
al-SHAMEKH (since 2 March 2000)
cabinet: General People''s Committee established by
the General People''s Congress
elections: national elections are indirect through a
hierarchy of people''s committees; head of
government elected by the General People''s
Congress; election last held NA (next to be held NA)
election results: Mubarak al-SHAMEKH elected head
of government; percent of General People''s Congress
vote ■ NA
Legislative branch: unicameral General People''s
Congress (NA seats; members elected indirectly
through a hierarchy of people''s committees)
Judicial branch: Supreme Court
Political parties and leaders: none
Political pressure groups and leaders: various
Arab nationalist movements with almost negligible
memberships may be functioning clandestinely, as
well as some Islamic elements
International organization participation: ABEDA,
AfDB, AFESD, AL, AMF, AMU, CAEU, CCC, ECA,
FAO, G-77, IAEA, IBRD. ICAO, ICRM, IDA, IDB,
IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, ISO, ITU, MONUC, NAM, OAPEC,
OAU, OIC, OPEC, PCA, UN, UNCTAD, UNESCO,
UNIDO, UPU, WFTU, WHO, WlPO, WMO, WToO
Diplomatic representation in the US: Libya does
not have an embassy in the US
Diplomatic representation from the US: the US
suspended all embassy activities in Tripoli on 2 May
1980
Flag description: plain green; green is the
traditional color of Islam (the state religion)
Economy - overview: The socialist-oriented
economy depends primarily upon revenues from the
oil sector, which contributes practically all export
earnings and about one-quarter of GDP. These oil
revenues and a small population give Libya one of the
highest per capita GDPs in Africa, but little of this
income flows down to the lower orders of society. In
this statist society, import restrictions and inefficient
resource allocations have led to periodic shortages of
basic goods and foodstuffs. The nonoil manufacturing
and construction sectors, which account for about
20% of GDP, have expanded from processing mostly
agricultural products to include the production of
petrochemicals, iron, steel, and aluminum. Climatic
conditions and poor soils severely limit farm output,
and Libya imports about 75% of its food requirements.
Higher oil prices in 1999 led to an increase in export
revenues and helped to stimulate the economy.
Following the suspension of UN sanctions in 1999,
Libya has been trying to increase its attractiveness to
foreign investors, and several foreign companies have
visited in search of contracts.
GDP: purchasing power parity - $39.3 billion
(1999 est.)
GDP - real growth rate: 2% (1999 est.)
GDP - per capita: purchasing power parity - $7,900
(1999 est.)
GDP - composition by sector:
agriculture: 7%
industry: 47%
services: 46% (1 997 est.)
Population below poverty line: NA%
Household Income or consumption by percentage
share:
/owesf f0%;NA%
highest 10%: NA%
Inflation rate (consumer prices): 18% (1999 est.)
Labor force: 1 .2 million (1 997 est.)
Labor force ■ by occupation: services and
government 54%, industry 29%, agriculture 17%
(1997 est.)
Unemployment rate: 30% (1998 est.)
Budget:
revenues: $3.6 billion
expenditures: $5.1 billion, including capital
expenditures of $NA (1 998 est.)
Industries: petroleum, food processing, textiles,
handicrafts, cement
Industrial production growth rate: NA%
Electricity - production: 16.92 billion kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 15.736 billion kWh
(1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: wheat, barley, olives, dates,
citrus, vegetables, peanuts; beef, eggs
Exports: $6.6 billion (f.o.b., 1998 est.)
Exports - commodities: crude oil, refined
petroleum products, natural gas
Exports ■ partners: Italy 40%, Germany 1 7%, Spain
12%, France 4%, Sudan 4%, UK 3% (1997)
Imports: $7 billion (f.o.b., 1998 est.)
Imports - commodities: machinery, transport
equipment, food, manufactured goods
Imports ■ partners: Italy 23%, Germany 12%, UK
9%, France 7%, Tunisia 5%, Belgium 4% (1997)
Debt • external: $4 billion (1 998 est.)
Economic aid - recipient: $8.4 million (1995)
Currency: 1 Libyan dinar (LD) = 1 ,000 dirhams
Exchange rates: Libyan dinars (LD) per US$1 -
0.4687 (January 2000), 0.461 6 (1 999), 0.3785 (1998),
0.3891 (1997), 0.3651 (1996), 0.3532 (1995); official
rate: 0.45 (December 1998)
Fiscal year: calendar year
I C 0 mliru n I ca 1 1 0 n s
Telephones - main lines in use: 318,000 (1995)
Telephones - mobile cellular: NA
Telephone system: telecommunications system is
being modernized; mobile cellular telephone system
became operational in 1996
domestic: microwave radio relay, coaxial cable,
cellular, tropospheric scatter, and a domestic satellite
system with 14 earth stations
international: satellite earth stations - 4 Intelsat, NA
Arabsat, and NA Intersputnik; submarine cables to
France and Italy; microwave radio relay to T unisia and
Egypt; tropospheric scatter to Greece; participant in
Medarabtel (1999)
Radio broadcast stations: AM 17, FM 4, shortwave
3(1998)
Radios: 1.35 million (1997)
Television broadcast stations: 12 (plus one
low-power repeater) (1997)
Televisions: 730,000(1997)
internet Service Providers (ISPs): NA
289
Libya (continued)','f51a355b16f1f799e7169154de3a8210fb03bdc5dd54f3fe1002e269f213ff8b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf7f55734f918e4ae0303fbcda7f95075e4907c96d43d6764ed14cb6f0b7f69',2000,'LI','Liechtenstein','geography',297,'Location: Central Europe, between Austria and
Flag description: two equal horizontal bands of blue
(top) and red with a gold crown on the hoist side of the
blue band
I Economy
Economy - overview: Despite its smali size and
limited naturai resources, Liechtenstein has
deveioped into a prosperous, highly industrialized,
free-enterprise economy with a vital financial service
sector and iiving standards on a par with the urban
areas of its large European neighbors. Low business
taxes - the maximum tax rate is 18% - and easy
incorporation rules have induced about 73,700
holding or so-called letter box companies to estabiish
nominal offices in Liechtenstein, providing 30% of
state revenues. The country participates in a customs
union with Switzerland and uses the Swiss franc as its
nationai currency, it imports more than 90% of its
energy requirements. Liechtenstein has been a
member of the European Economic Area (an
organization serving as a bridge between European
Free Trade Association (EFTA) and EU) since May
1995. The government is working to harmonize its
economic policies with those of an integrated Europe.
GDP: purchasing power parity - $730 million
(1998 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$23,000 (1998 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 0.5% (1997 est.)
Labor force: 22,891 of which 1 3,847 are foreigners;
8,231 commute from Austria and Switzeriand to work
each day
Labor force - by occupation: industry, trade, and
building 45%, services 53%, agriculture, fishing,
forestry, and horticulture 2% (1997 est.)
Unemployment rate: 1 .8% (February 1999)
Budget:
revenues: $424.2 million
expend/fures; $414.1 million, including capital
expenditures of $NA (1998 est.)
Industries: electronics, metal manufacturing,
textiles, ceramics, pharmaceuticals, food products,
precision instruments, tourism
291
Liechtenstein (continued)
Industrial production growth rate; NA%
Electricity - production: 150 million kWh (1995)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity -consumption: NAkWh
Electricity - exports: NA kWh
Electricity - imports; NA kWh
Agriculture - products: wheat, barley, corn,
potatoes; livestock, dairy products
Exports: $2.47 billion (1996)
Exports - commodities: small specialty machinery,
dental products, stamps, hardware, pottery
Exports - partners: ELI and EFTA countries 60.57%
(Switzerland 15.7%) (1995)
Imports: $917.3 million (1996)
Imports - commodities: machinery, metal goods,
textiles, foodstuffs, motor vehicles
Imports - partners: EU countries, Switzerland
(1996)
Debt - external; $0(1996)
Economic aid - recipient: none
Currency: 1 Swiss franc, franken, or franco (SFR) =
100 centimes, rappen, or centesimi
Exchange rates: Swiss francs, franken, or f ranch!
(SFR) per US$1 - 1 .5878 (January 2000), 1 .5022
(1999), 1.4498 (1998), 1.4513 (1997), 1.2360 (1996),
1.1825(1995)
Fiscal year: calendar year
f Communications
Telephones - main lines in use: 19,000 (1995)
Telephones - mobile cellular; NA
Telephone system: automatic telephone system
domestic: NA
international: linked to Swiss networks by cable and
microwave radio relay
Radio broadcast stations: AM 0, FM 4, shortwave
0(1998)
Radios: 21,000(1997)
Television broadcast stations: NA (linked to Swiss
networks) (1997)
Televisions: 12,000(1997)
Internet Service Providers (ISPs): 1 1 5
(Liechtenstein and Switzerland) (1999)
I Transportation
Railways:
total: 18.5 km; note - owned, operated, and included
in statistics of Austrian Federal Railways
standard gauge: ''\\Q.5 km 1.435-m gauge (electrified)
Highways:
total: 250 km
paved: 250 km
unpaved: 0 km
Ports and harbors: none
Airports; none
''l" . Military
Miiitary - note: defense is the responsibility of','d2ddcbd59bb10f7f717d90ba6dbc96b933657749ca27c022726206a4da6b72ba','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e9c0a19b4e3f8ab160b82c074632ba0e79eece898d3914227a1c61aba76bb5',2000,'CH','Switzerland','geography',298,'Geographic coordinates: 47 10 N, 9 32 E
Map references: Europe
Area:
total: 160 sq km
land: 160 sq km
water: 0 sq km
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries:
total: 76 km
border countries: Austria 35 km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with
frequent snow or rain; cool to moderately warm,
cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine
Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Grauspitz 2,599 m
Natural resources: hydroelectric potential, arable
land
Land use:
arable land: 24%
Liechtenstein (continued)
permanent crops: 0%
permanent pastures: 16%
forests and woodland: 35%
ofher;25%(1993est.)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Law of the Sea
Geography - note: along with Uzbekistan, one of
only two doubly landlocked countries in the world;
variety of microclimatic variations based on elevation
f —— p e Q p f e
Population: 32,207 (July 2000 est.)
Age structure:
0-14 years: 18% (male 2,970; female 2,988)
15-64 years: 71 % (male 1 1 .379; female 1 1 ,370)
65 years and over: 11% (male 1 ,393; female 2,1 07)
(2000 est.)
Population growth rate: 1 .02% (2000 est.)
Birth rate: 1 1 .83 births/1 ,000 population (2000 est.)
Death rate: 6.64 deaths/1 ,000 population
(2000 est.)
Net migration rate: 5.03 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 5.07 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.81 years
ma/e; 75.1 6 years
female: 82.47 years (2000 est.)
Total fertility rate: 1 .49 children born/woman
(2000 est.)
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 87.5%, Italian, Turkish,
and other 12.5%
Religions: Roman Catholic 80%, Protestant 7.4%,
unknown 7.7%, other 4.9% (1996)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 1 0 and over can read and write
total population: 1 00%
male: 100%
female: 100% (1981 est.)
I GoverrTment
Country name:
conventional long form: Principality of Liechtenstein
conventional short form: Liechtenstein
local long form: Fuerstentum Liechtenstein
local short form: Liechtenstein
Data code: LS
Government type: hereditary constitutional
monarchy
Capital: Vaduz
Administrative divisions: 11 communes
(Gemeinden, singular - Gemeinde); Balzers, Eschen,
Gamprin, Mauren, Planken, Ruggell, Schaan,
Schellenberg, Triesen, Triesenberg, Vaduz
Independence: 23 January 1719 Imperial
Principality of Liechtenstein established; 1 2 July 1 806
established independence from the Holy Roman
Empire
National holiday: Assumption Day, 15 August
Constitution: 5 October 1921
Legal system: local civil and penal codes; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage: 20 years of age; universal
Executive branch:
chief of state: Prince HANS ADAM II (since 13
November 1989, assumed executive powers 26
August 1984); Heir Apparent Prince ALOIS von und
zu Liechtenstein, son of the monarch (born 11 June
1968)
head of government: Head of Government Mario
FRICK (since 15 December 1993) and Deputy Head
of Government Michael RITTER (since 2 February
1997)
cabinet: Cabinet elected by the Diet; confirmed by the
monarch
elections: none; the monarch is hereditary; following
legislative elections, the leader of the majority party in
the Diet is usually appointed the head of government
by the monarch and the leader of the largest minority
party in the Diet is usually appointed the deputy head
of government by the monarch
Legislative branch: unicameral Diet or Landtag (25
seats; members are elected by direct popular vote
under proportional representation to serve four-year
terms)
elections: last held on 2 February 1997 (next to be
held by NA 2001)
election results: percent of vote by party - VU 50.1 %,
FBPL 41 .3%, FL 8.5%; seats by party - VU 13, FBPL
10, FL2
Judicial branch: Supreme Court or Oberster
Gerichtshof; Superior Court or Obergericht
Political parties and leaders: Fatherland Union or
VU [Dr. Oswald KRANZj; Progressive Citizens'' Party
or FBPL [Norbert SEEGER]; The Free List or FL
[Christel HILTI, Hansjorg HILTI, Helen MARKER,
HugoRISCH, Margrit WILLE]
International organization participation: CE,
EBRD, ECE, EFTA, IAEA, iCRM, IFRCS, Intelsat,
Interpol, IOC, ITU, OPCW, OSCE, PCA, UN,
UNCTAD, UPU, WCL, WlPO, WTrO
Diplomatic representation in the US:
Liechtenstein does not have an embassy in the US,
but is represented by the Swiss embassy in routine
diplomatic matters
Diplomatic representation from the US: the US
does not have an embassy in Liechtenstein, but the
US Ambassador to Switzerland is also accredited to
) t r a h s ha t i oh a i Issues
Disputes - international; claims 1 ,600 sq km of land
in the Czech Republic confiscated from its royal family
in 1918; the Czech Republic insists that restitution
does not go back before February 1948, when the
communists seized power
I Lithuania
Background: Independent between the two World
Wars, Lithuania was annexed by the USSR in 1940. In
March of 1990, Lithuania became the first of the
Soviet republics to declare its independence, but this
proclamation was not generally recognized until
September of 1991 (following the abortive coup in
Moscow). The last Russian troops withdrew in 1993.
Lithuania subsequently has restructured its economy
for eventual integration into Western European
institutions.
Location: Eastern Europe, bordering the Baltic Sea,
between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area;
total: 65,200 sq km
land: 65,200 sq km
water: 0 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 1 ,273 km
border countries: Belarus 502 km, Latvia 453 km,
Poland 91 km, Russia (Kaliningrad) 227 km
Coastline: 99 km
Maritime claims;
fem''tora/ sea; 1 2 nm
Climate: transitional, between maritime and
continental; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile
soil
Elevation extremes;
lowest point: Baltic Sea 0 m
h/ghesfpo/rrf; Juozapines/Kalnas 292 m
Natural resources: peat, arable land
292
Lithuania (continued)
Land use:
arable land: 35%
permanent crops: 1 2%
permanent pastures: 7%
forests and woodland: 31 %
of/jer15%(1993est.)
Irrigated land: 430sqkm(1993est.)
Natural hazards: NA
Environment - current issues: contamination of
soii and groundwater with petroieum products and
chemicais at miiitary bases
Environment - international agreements:
party to: Biodiversity, Ciimate Change, Hazardous
Wastes, Ozone Layer Protection, Ship Poiiution,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Population: 3,620,756 (July 2000 est.)
Age structure:
0-14 years; 19% (male 357,712; female 342,796)
15-64 years: 67% (male 1,177,732; female
1,259,682)
65 years and over: 14% (male 163,470; female
319,364) (2000 est.)
Population growth rate: -0.29% (2000 est.)
Birth rate: 9.77 births/1 ,000 population (2000 est.)
Death rate: 12.87 deaths/1,000 population
(2000 est.)
Net migration rate: 0.16 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.51 male(s)/female
total population: 0.88 male(s)/female (2000 est.)
Infant mortality rate: 14.67 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 69.09 years
male: 63.07 years
female: 75.41 years (2000 est.)
Total fertility rate: 1 .34 children born/woman
(2000 est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 80.6%, Russian 8.7%,
Polish 7%, Byelorussian 1 .6%, other 2.1 %
Religions: Roman Catholic (primarily), Lutheran,
Russian Orthodox, Protestant, evangelical Christian
Baptist, Muslim, Jewish
Languages: Lithuanian (official), Polish, Russian
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99%
female: 98% (1989 est.)
f Government ""
Country name:
conventional long form: Republic of Lithuania
conventional short form: Lithuania
local long form: Lietuvos Respublika
local short form: Lietuva
former: Lithuanian Soviet Socialist Republic
Data code: LH
Government type: parliamentary democracy
Capital: Vilnius
Administrative divisions: 44 regions (rajonai,
singular - rajonas) and 11 municipalities*: Akmenes
Rajonas, Alytaus Rajonas, Alytus*, Anyksciu Rajonas,
Birstonas*, Birzu Rajonas, Dmskininkai*, Ignalinos
Rajonas, Jonavos Rajonas, Joniskio Rajonas,
Jurbarko Rajonas, Kaisiadoriu Rajonas, Kaunas'',
Kauno Rajonas, Kedainiu Rajonas, Kelmes Rajonas,
Klaipeda*, Klaipedos Rajonas, Kretingos Rajonas,
Kupiskio Rajonas, Lazdiju Rajonas, Marijampole*,
Marijampoles Rajonas, Mazeikiu Rajonas, Moletu
Rajonas, Neringa* Pakruojo Rajonas, Palanga*,
Panevezio Rajonas, Panevezys*, Pasvalio Rajonas,
Plunges Rajonas, Prienu Rajonas, Radviliskio
Rajonas, Raseiniu Rajonas, Rokiskio Rajonas, Sakiu
Rajonas, Salcininku Rajonas, Siauliai*, Siauliu
Rajonas, Silales Rajonas, Silutes Rajonas, Sirvintu
Rajonas, Skuodo Rajonas, Svencioniu Rajonas,
Taurages Rajonas, Telsiu Rajonas, Traku Rajonas,
Ukmerges Rajonas, Utenos Rajonas, Varenos
Rajonas, Vilkaviskio Rajonas, Vilniaus Rajonas,
Vilnius*, Zarasu Rajonas
Independence: 6 September 1991 (from Soviet
Union)
National holiday: Statehood Day, 16 February
(1918)
Constitution: adopted 25 October 1992
Legal system: based on civil law system; no judicial
review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Valdas ADAMKUS (since 26
February 1998)
head of government: Premier Andrius KUBILIUS
(since 12 November 1999)
cabinet: Council of Ministers appointed by the
president on the nomination of the premier
elections: president elected by popular vote for a
five-year term; election last held 21 December 1 997
and 5 January 1998 (next to be held NA 2003);
premier appointed by the president on the approval of
the Parliament
election results: Valdas ADAMKUS elected president;
percent of vote - Valdas ADAMKUS 50.4%, Arturas
PAULAUSKAS 49.6%
Legislative branch: unicameral Parliament or
Seimas (141 seats, 71 members are directly elected
by popular vote, 70 are elected by proportional
representation; members serve four-year terms)
elections: last held 20 October and 10 November
1 996 (next to be held NA October 2000)
election results: percent of vote by party - NA; seats
by party - TS 69, LKDP 15, LCS 15, LDDP 12, LSDP
10, DP 2, independents 12, others 6
Judicial branch: Supreme Court, judges appointed
by the Parliament; Court of Appeal, judges appointed
by the Parliament
Political parties and leaders: Christian Democratic
Party or LKDP [Algirdas SAUDARGAS, chairman];
Democratic Labor Party of Lithuania or LDDP
[Ceslovas JURSENAS, chairman]; Democratic Party
or DP [Lydie WURTH-POLFER, president]; Homeland
Unionbonservative Party or TS [Vytautas
LANDSBERGIS, chairman]; Lithuanian Center Union
or LCS [Romualdas OZOLAS, chairman]; Lithuanian
Farmer''s Party or LUP (previously Farmers'' Union)
[Albinas VAIZMUZIS, chairman]; Lithuanian
Nationalist Union or LTS [Rimantas SMETONA,
chairman]; Lithuanian Polish Union orLLS [Rsztardas
MACIEKIANIEC, chairman]; Lithuanian Social
Democratic Party or LSDP [Aloyzas SAKALAS,
chairman]
Political pressure groups and leaders: Lithuanian
Future Forum
International organization participation: BIS,
CBSS, CCC, CE, EAPC, EBRD, ECE, EU (applicant),
FAO, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IFC,
IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user),
Interpol, IOC, lOM, ISO (correspondent), ITU, OPCW,
OSCE, PFP, UN, UNCTAD, UNESCO, UNMIBH,
UNMIK, UPU, WEU (associate partner), WHO, WlPO,
WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Stasys
SAKALAUSKAS
chancery: 2622 16th Street NW, Washington, DC
20009
telephone: [1] {202) 234-5860
FAX; [1] (202) 328-0466
consulate(s) general: Chicago and New York
Diplomatic representation from the US:
chief of mission: Ambassador Keith C. SMITH
embassy: Akmenu 6, 2600 Vilnius
mailing address: American Embassy, Viinius, PSC
78, BoxV, APOAE 09723
telephone: [370] {2) 226-031
FAX; [370] (6) 706-084
Flag description: three equal horizontal bands of
yellow (top), green, and red
Economy - overview: Lithuania, the Baltic state that
has conducted the most trade with Russia, faced its
own economic and financial crisis in 1999 as a result
of the government''s wrongfooted economic policies
and its inadequate response to the August 1998
Russian financial crisis. Preliminary figures indicate
3% negative GDP growth, 10% unemployment - the
highest level since independence in 1991 - and a
budget deficit estimated at between 8 and 9% of GDP.
The policies that Prime Minister KUBILIUS
implemented upon taking the helm in November 1 999
293
Lithuania (continued)
underscore a commitment to fiscal restraint, economic
stabilization, and accelerated reforms. The austere
2000 budget in based on a 2% GDP growth forecast,
3% inflation, and a 2.8% budget deficit. Lithuania was
invited at the Helsinki EL) summit in December 1999
to begin ED accession talks in early 2000.
Privatization of the large state-owned utilities,
particularly in the energy sector, and reducing the high
current account deficit remain challenges for the
coming year.
GDP: purchasing power parity - $17.3 billion
(1999 est.)
GDP - real growth rate: -3% (1999 est.)
GDP - per capita: purchasing power parity - $4,800
(1999 est.)
GDP - composition by sector:
agriculture: )0%
industry: 32%
serv/ces; 58% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 3.4%
highest 10%: 28% (1993)
Inflation rate (consumer prices): 0.3% (1999 est.)
Labor force: 1.8 million
Labor force ■ by occupation: industry 30%,
agriculture 20%, services 50% (1997 est.)
Unemployment rate: 10% (1999)
Budget:
revenues: $1 .5 billion
expenditures: $1 .7 billion, including capital
expenditures of $NA (1997 est.)
Industries: metal-cutting machine tools, electric
motors, television sets, refrigerators and freezers,
petroleum refining, shipbuilding (small ships),
furniture making, textiles, food processing, fertilizers,
agricultural machinery, optical equipment, electronic
components, computers, amber
Industrial production growth rate: -14%
(1999 est.)
Electricity - production: 15.58 billion kWh (1998)
Electricity - production by source:
fossil fuel: 13.09%
hydro: 4.3%
nuclear: 82.81%
other; 0% (1998)
Electricity - consumption: 7.829 billion kWh (1 998)
Electricity - exports: 7 billion kWh (1998)
Electricity - imports: 340 million kWh (1998)
Agriculture - products: grain, potatoes, sugar
beets, flax, vegetables; beef, milk, eggs; fish
Exports: $3.3 billion (f.o.b., 1999)
Exports - commodities: machinery and equipment
19%, mineral products 19%, textiles and clothing
19%, chemicals 10%, foodstuffs (1998)
Exports - partners: Russia 17.4%, Germany 15.8%,
Latvia 12.7%, Denmark 5.9%, Belarus 5.2% (1999)
Imports: $4.5 billion (f.o.b., 1999)
Imports - commodities: machinery and equipment
30%, mineral products 16%, chemicals 9%, textiles
and clothing 9%, foodstuffs (1998)
Imports - partners: Russia 20.4%, Germany 1 6.5%,
Denmark 3.8%, Belarus 2.2%, Latvia 2% (1999)
Debt - external: $NA
Economic aid - recipient: $228.5 million (1995)
Currency: 1 Lithuanian litas = 100 centas
Exchange rates: litai per US$1 - 4.000 (fixed rate
since 1 May 1994)
Fiscal year: calendar year','365ab1fc719d76d4f665dbbd95ce1df47f8b29267adaef0b4829f36bada54039','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1661e6b0f0af1211f47188691cf0addfe2a08b76ad50341b2bcf4161706c2a68',2000,'MY','Malaysia','geography',309,'Location: Southeastern Asia, peninsula and
northern one-third of the island of Borneo, bordering
Indonesia and the South China Sea, south of Vietnam
Geographic coordinates; 2 30 N, 1 12 30 E
Map references: Southeast Asia
Area;
total: 329,750 sq km
land: 328,550 sq km
wafer; 1 ,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries;
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1 ,782 km,
Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km.
East Malaysia 2,607 km)
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation; specified boundary in the South China
Sea
exclusive economic zone: 200 nm
territorial sea: ^2 nm
Climate: tropical; annual southwest (April to
October) and northeast (October to February)
monsoons
Terrain: coastal plains rising to hills and mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, copper.
permanent crops: 12%
permanent pastures: 0%
forests and woodland: 68%
of/ier;17%(1993est.)
Irrigated land: 2,941 sq km (1998 est.)
Natural hazards; flooding, landslides
Environment - current issues: air pollution from
industrial and vehicular emissions; water pollution
from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
Environment - international agreements;
party to: Biodiversity. Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, T ropical Timber 83, T ropical Timber 94,
Wetlands
signed, but not ratified: CWmate Change-Kyoto
Protocol
Geography - note: strategic location along Strait of
Malacca and southern South China Sea
Location: Southeastern Europe, eastern Alps
bordering the Adriatic Sea, between Austria and','d3ce955a71a9cc956275f3241bc25eabedf8b0be2ae1078052654294b246e5c6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da816e470c417187e4f29edd91e847712130eb6a63d34b767b9475d13553141',2000,'MV','Maldives','geography',316,'Location: Western Africa, southwest of Algeria
Geographic coordinates: 17 00 N, 4 00 W
Map references: Africa
Area;
total: 1 .24 million sq km
land: 1 .22 million sq km
water: 20,000 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries;
total: 7,243 km
border counfr/es; Algeria 1,376 km, Burkina Faso
1,000 km, Guinea 858 km, Cote d''Ivoire 532 km,
Mauritania 2,237 km, Niger 821 km, Senegal 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry February to
June; rainy, humid, and mild June to November; cool
and dry November to February
Terrain: mostly flat to rolling northern plains covered
by sand; savanna in south, rugged hills in northeast
Elevation extremes:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155 m
Natural resources: gold, phosphates, kaolin, salt,
limestone, uranium, hydropower
310
Mali (continued)
note: bauxite, iron ore, manganese, tin, and copper
deposits are known but not exploited
Land use;
arable land: 2.%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 6%
of/ier67%(1993 est.)
Irrigated land: 780 sq km (1993 est.)
Natural hazards; hot, dust-laden harmattan haze
common during dry seasons; recurring droughts
Environment - current issues: deforestation; soil
erosion; desertification; inadequate supplies of
potable water; poaching
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
Geography - note: landlocked
I People
Population: 10,685,948 (July 2000 est.)
Age structure:
0-14 years: 47% (male 2,537,586; female 2,508,782)
15-64 years: 50% (male 2,524,969; female
2,781,762)
65 years and over: 3% (male 1 56,447; female
176,402) (2000 est.)
Population growth rate: 2.98% (2000 est.)
Birth rate: 49.23 births/1 ,000 population (2000 est.)
Death rate: 19.1 deaths/1,000 population
(2000 est.)
Net migration rate: -0.37 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate; 123.25 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 46.66 years
male: 45.5 years
female: 47.85 years (2000 est.)
Total fertility rate: 6.89 children born/woman
(2000 est.)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups; Mande 50% (Bambara, Malinke,
Soninke), Peu1 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 1 5 and over can read and write
total population: 31%
male: 39.4%
female: 23.1 % (1 995 est.)
I Government
Country name;
conventional long form: Republic of Mali
conventional short form: Mali
local long form: Republique de Mali
local short form: Mali
former. French Sudan and Sudanese Republic
Data code; ML
Government type: republic
Capital: Bamako
Administrative divisions: 8 regions (regions,
singular - region); Gao, Kayes, l^dal, Koulikoro,
Mopti, Segou, Sikasso, Tombouctou
Independence: 22 September 1960 (from France)
National holiday; Anniversary of the Proclamation
of the Republic, 22 September (1960)
Constitution; adopted 12 January 1992
Legal system: based on French civit law system and
customary law; judicial review of legislative acts in
Constitutional Court (which was formally established
on 9 March 1994); has not accepted compulsory ICJ
jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state: President Alpha Oumar KONARE
(since 8 June 1992)
head of government: Prime Minister Ibrahim
Boubacar KEITA (since March 1994)
cabinet: Council of Ministers appointed by the prime
minister
elections: president elected by popular vote for a
five-year term; election last held 11 May 1997 (next to
be held NA May 2002); prime minister appointed by
the president
election results: Alpha Oumar KONARE reelected
president; percent of vote - Alpha Oumar KONARE
95.9%, Mamadou DIABY4.1%
Legislative branch: unicameral National Assembly
or Assemblee Nationale (147 seats; members are
elected by popular vote to serve five-year terms)
elections: last held 20 July and 3 August 1 997 (next to
be held in two rounds in 2002); note - much of the
opposition boycotted the election
election results: percent of vote by party - NA; seats
by party - ADEMA 130, PARENA 8, CDS 4, UDD 3,
PDP2
Judicial branch: Supreme Court (Cour Supreme)
Political parties and leaders; Alliance for
Democracy or ADEMA [Ibrahim Boubacar KEITA,
party chairman]; Block of Alternative for the Renewal
of Africa or BARA [Yoro DiAKITEj; Democratic and
Social Convention or CDS [Mamadou Bakary
SANGARE, chairman]; Movement for the
Independence, Renaissance and integration of Africa
or MIRIA [Mohamed Lamine TRAORE, Mouhamedou
DICKO]; National Congress for Democratic Initiative
or CNID [Mountaga TALL, chairman]; Party for
Democracy and Progress or PDP [Me Idrissa
TRAORE]; Party for National Renewal or PARENA
[Yoro DIAKITE, chairman; Tiebile DRAME, secretary
general]; Rally for Democracy and Labor or RDT [All
GNANGADO]; Rally for Democracy and Progress or
RDP [Almamy SYLLA, chairman]; Sudanese Union/
African Democratic Rally or US/RDA [Mamadou
Bamou TOURE, secretary general]; Union of
Democratic Forces for Progress or UFDP [Youssouf
TOURE, secretary general]; Union for Democracy and
Development or UDD [Moussa Balia COULIBALY]
Political pressure groups and leaders: Patriotic
Movement of the Ghanda Koye or MPGK; United
Movement and Fronts of Azawad or MFUA
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, FAO, FZ, G-77,
IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IDB, IFAD,
IFC, IFRCS, ILO, IMF, Intelsat, Interpol, IOC, lOM,
ITU, MIPONUH, MONUC, NAM, OAU, OIC, OPCW,
UN, UN Security Council (temporary), UNCTAD,
UNESCO, UNIDO, UPU, WADB, WAEMU, WCL,
WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Cheick Oumar
DIARRAH
chancery: 21 30 R Street NW, Washington, DC 20008
telephone: [1] (202) 332-2249, 939-8950
FAX; [1] (202) 332-6603
Diplomatic representation from the US;
chief of mission: Ambassador Michael
RANNEBERGER
embassy: Rue Rochester NY and Rue Mohamed V,
Bamako
mailing address: B. P. 34, Bamako
telephone: [223] 22 54 70
FAX; [223] 22 3712
Flag description: three equal vertical bands of
green (hoist side), yellow, and red; uses the popular
pan-African colors of Ethiopia
I ^ Economy
Economy - overview: Mali is among the poorest
countries in the world, with 65% of its land area desert
or semidesert. Economic activity is largely confined to
the riverine area irrigated by the Niger. About 10% of
the population is nomadic and some 80% of the labor
force is engaged in farming and fishing. Industrial
activity is concentrated on processing farm
commodities. Mali is heavily dependent on foreign aid
and vulnerable to fluctuations in world prices for
cotton, its main export. In 1997, the government
continued its successful implementation of an
IMF-recommended structural adjustment program
that is helping the economy grow, diversify, and attract
foreign investment. Mali''s adherence to economic
reform, and the 50% devaluation of the African franc
in January 1994, has pushed up economic growth.
Several multinational corporations increased gold
mining operations in 1996-98, and the government
anticipates that Mali will become a major
Sub-Saharan gold exporter in the next few years.
Annual growth should remain in the 5-6% range in
2000-01 , and inflation should drop under 3%.
311
Mali (continued)
GDP: purchasing power parity - $8.5 biliion
(1999 est.)
GDP ■ real growth rate: 5% (1999 est.)
GDP - per capita: purchasing power parity - $820
(1999 est.)
GDP - composition by sector:
agriculture: 46%
industry: 2t%
services: 33%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 3% (1999 est.)
Labor force: NA
Labor force - by occupation: agriculture and
fishing 80% (1998 est.)
Unemployment rate: NA%
Budget:
revenues: $730 million
expenditures: $770 million, including capital
expenditures of $320 million (1997 est.)
Industries: minor local consumer goods production
and food processing; construction; phosphate and
gold mining
Industrial production growth rate; 0.6%
(1995 est.)
Electricity - production: 310 million kWh (1998)
Electricity - production by source;
fossil fuel: 38.71%
hydro: 61. 29%
nuclear: 0%
ote-0%(1998)
Electricity - consumption: 288 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: cotton, millet, rice, corn,
vegetables, peanuts; cattle, sheep, goats
Exports: $640 million (f.o.b., 1999 est.)
Exports - commodities: cotton 50%, gold, livestock
(1998 est.)
Exports - partners: Thailand 20%, Italy 20%, China
9%, Brazil 5%, Franc Zone (1997)
Imports: $650 million (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment,
construction materials, petroleum, foodstuffs, textiles
Imports - partners: Cote d''Ivoire 1 9%, France 1 7%,
other Franc Zone and EU countries (1997)
Debt - external: $3.1 billion (1998)
Economic aid - recipient: $596.4 million (1995)
Currency: 1 Communaute Financiers Africaine franc
(CFAF) = 100 centimes
Exchange rates: Communaute Financiers Africaine
francs (CFAF) per US$1 - 647.25 (January 2000),
615.70 (1999), 589.95 (1998), 583.67 (1997), 511.55
(1996), 499.15 (1995)
nofe; since 1 January 1999, the CFAF is pegged to
the euro at a rate of 655.957 CFA francs per euro
Fiscal year: calendar year
Location: Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area;
total: 316 sq km
land: 316 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size
of Washington, DC
Land boundaries; 0 km
Coastline; 140 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 25 nm
territorial sea: 12 nm
Climate: Mediterranean with mild, rainy winters and
hot, dry summers
Terrain: mostly low, rocky, flat to dissected plains;
many coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Ja''Dmeyek 253 m (near Dingli)
Natural resources: limestone, salt, arable land
Land use:
arable land: 38%
312
Malta (continued)
permanent crops: 3%
permanent pastures: 0%
forests and woodland: 0%
other: 59% (m3 est.)
Irrigated land: 10 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: very limited natural
fresh water resources; increasing reiiance on
desaiination
Environment ■ international agreements:
party to: Air Poiiution, Ciimate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Poiiution, Wetlands
signed, but not ratified: Biodiversity, Ciimate
Change-Kyoto Protocol
Geography - note: the country comprises an
archipelago, with oniy the three largest islands (Malta,
Ghawdex or Gozo, and Kemmuna or Comino) being
inhabited; numerous bays provide good harbors
I P e 0 p I e ~
Population: 391 ,670 (July 2000 est.)
Age structure:
0- 14 years: 20% (male 41 ,046; female 38,273)
15-64 years: 57% (male 132,692; female 131,532)
65 years and over: 1 3% (male 20,091 ; female
28,036) (2000 est.)
Population growth rate: 0.74% (2000 est.)
Birth rate: 12.75 births/1 ,000 popuiation (2000 est.)
Death rate: 7.7 deaths/1 ,000 population (2000 est.)
Net migration rate: 2.39 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 5.94 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.94 years
male: 75.49 years
female: 80.62 years (2000 est.)
Total fertility rate: 1 .92 children born/woman
(2000 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 91%
Languages: Maltese (official), English (official)
Literacy:
definition: age 1 0 and over can read and write
total population: 88%
male: 88%
ferr7a/e;88%(1985)
r G o" V e r n m e n f
Country name:
conventional long form: Republic of Malta
conventional short form: Malta
local long form: Repubblika ta* Malta
local short form: Malta
Data code: MT
Government type: parliamentary democracy
Capital: Valletta
Administrative divisions: none (administered
directly from Valletta)
Independence: 21 September 1964 (from UK)
National holiday: Independence Day, 21
September (1964)
Constitution: 1 964 constitution substantially
amended on 13 December 1974
Legal system: based on English common law and
Roman civil law; has accepted compulsory ICJ
jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Guido DE MARCO (since 4
April 1999)
head of government: Prime Minister Eddie FENECH
ADAMI (since 6 September 1998); Deputy Prime
Minister Lawrence GONZE (since 4 May 1999)
cabinet: Cabinet appointed by the president on the
advice of the prime minister
elections: president elected by the House of
Representatives for a five-year term; election last held
NA April 1999 (next to be held by NA April 2004);
following legislative elections, the leader of the
majority party or leader of a majority coalition is
usually appointed prime minister by the president for
a five-year term; the deputy prime minister is
appointed by the president on the advice of the prime
minister
election results: Guido DE MARCO elected president;
percent of House of Representatives vote - NA
Legislative branch: unicamerai House of
Representatives (usually 65 seats; note - additional
seats are given to the party with the largest popular
vote to ensure a legislative majority; current total: 65
seats; members are elected by popular vote on the
basis of proportional representation to serve five-year
terms)
elections: last held 5 September 1 998 (next to be held
by September 2003)
election results: percent of vote by party - PN 51 .8%,
MLP 46.9%, AD 1 .2%; seats by party - PN 35, MLP 30
Judicial branch: Constitutional Court, judges are
appointed by the president on the advice of the prime
minister; Court of Appeal, judges are appointed by the
president on the advice of the prime minister
Political parties and leaders: Alternativa
Demokratika/Alliance for Social Justice or AD [Harry
VASSALLOj; Malta Labor Party or MLP [Alfred
SANT]; Nationalist Party or PN [Edward FENECH
ADAMI]
International organization participation: C, CCC,
CE, EBRD, ECE, EU (applicant). FAO, G-77, IAEA,
IBRD, ICAO, ICFTU, ICRM, IFAD, IFRCS, ILO, IMF,
IMO, Inmarsat, Intelsat, Interpol, IOC, lOM (observer),
ISO (correspondent), ITU, NAM, OPCW, OSCE, PCA,
UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO,
WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
c/)/ef of m/ss/on; Ambassador George SALIBA
chancery: 2017 Connecticut Avenue NW,
Washington, DC 20008
telephone: [1 ] (202) 462-361 1 , 361 2
FAX; [1] (202) 387-5470
consulate(s): New York
Diplomatic representation from the US:
c/)/ef of m/ss/on; Ambassador Kathryn Haycock
PROFFin
embassy: 3rd Floor, Development House, Saint Anne
Street, Floriana, Malta
mailing address: P. 0. Box 535, Valletta
telephone: [356] 235960
FAX; [356] 243229
Flag description: two equal vertical bands of white
(hoist side) and red; in the upper hoist-side corner is a
representation of the George Cross, edged in red
| E c 0 n 0 m y
Economy - overview: Major resources are
limestone, a favorable geographic location, and a
productive labor force. Malta produces only about
20% of its food needs, has limited freshwater supplies,
and has no domestic energy sources. The economy is
dependent on foreign trade, manufacturing (especially
electronics and textiles), and tourism; the state-owned
Malta drydocks employs about 3,800 people. In 1 999,
over 1 million tourists visited the island. Per capita
GDP of $13,800 places Malta in the ranks of the less
affluent EU countries. The island is divided politically
over the question of joining the EU. The sizable
budget deficit remains a key concern.
GDP: purchasing power parity - $5.3 billion
(1999 est.)
GDP - real growth rate: 4% (1999 est.)
GDP - per capita: purchasing power parity -
$13,800 (1999 est.)
GDP - composition by sector:
agriculture: 3%
industry: 26%
services: 71% (1997 est.)
Population beiow poverty iine: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
infiation rate (consumer prices): 1 .8% (1999 est.)
Labor force: 143,700 (October 1997)
Labor force - by occupation: industry 24%,
sen/ices 71%, agriculture 5% (1999 est.)
Unemployment rate: 5.5% (September 1999)
Budget:
revenues; $1.32 billion
expenditures: $1 .76 billion, including capital
expenditures of $NA (1998 est.)
313
Malta (continued)
Industries: tourism; electronics, ship building and
repair, construction; food and beverages, textiles,
footwear, clothing, tobacco
Industrial production growth rate: NA%
Electricity - production: 1 .62 billion kWh (1998)
Electricity - production by source:
fossil fuel: tOOVo
hydro: 0%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 1 .507 billion kWh (1 998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: potatoes, cauliflower,
grapes, wheat, barley, tomatoes, citrus, cut flowers,
green peppers; pork, milk, poultry, eggs
Exports: $1.8 billion (f.o.b., 1998)
Exports - commodities: machinery and transport
equipment, manufactures
Exports - partners: France 20.7%, US 18.1%,
Germany 12.6%, UK 7.7%, Italy 4.8% (1998)
Imports: $2.7 billion (f.o.b., 1998)
Imports - commodities: machinery and transport
equipment, manufactured goods; food, drink, and
tobacco
Imports - partners: Italy 19.3%, France 17.8%, UK
12.4%, Germany 10.5%, US 8.9% (1998)
Debt - external: $130 million (1997)
Economic aid - recipient: $NA
Currency: 1 Maltese lira (LM) = 100 cents
Exchange rates: Maltese liri (LM) per US$1 - 0.4086
(January 2000), 0.3994 (1 999), 0.3885 (1 998), 0.3857
(1997), 0.3604 (1996), 0.3529 (1995)
Fiscal year: 1 April - 31 March
Location: Western Europe, island in the Irish Sea,
between Great Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total: 572 sq km
land: 572 sq km
water: 0 sq km
Area - comparative: slightly more than three times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
exclusive fishing zone: 1 2 nm
territorial sea; 12 nm
Climate: cool summers and mild winters; temperate;
overcast about one-third of the time
Terrain: hills in north and south bisected by central
valley
Elevation extremes:
lowest point: Irish Sea 0 m
highest point: SnaeteW 621 m
Natural resources: none
Land use:
arable land: 9%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 6%
other: 39% (includes 25% mountain and heathland)
Irrigated land: 0 sq km
Natural hazards: NA
314
Man, IslO of (continued)
Environment - current issues: waste disposal
(both household and industrial); transboundary air
pollution
Geography - note: one small islet, the Calf of Man,
lies to the southwest, and is a bird sanctuary
I People
Population: 73,1 17 (July 2000 est.)
Age structure:
0-14 years; 18% (male 6,520; female 6,277)
15-64 years: 65% (male 23,904; female 23,674)
65 years and over: 17% (male 5,078; female 7,664)
(2000 est.)
Population growth rate: 0.52% (2000 est.)
Birth rate: 1 1 .69 births/1 ,000 population (2000 est.)
Death rate: 1 1 .98 deaths/1 ,000 population
(2000 est.)
Net migration rate: 5.47 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years; 1.01 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate; 6.54 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.47 years
male: 74.09 years
female: 81 .04 years (2000 est.)
Total fertility rate: 1 .64 children born/woman
(2000 est.)
Nationality:
rrour?; Manxman (men), Manxwoman (women)
adjective: Manx
Ethnic groups; Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
f Government
Country name;
conventional long form: none
conventional short form: Isle of Man
Data code: IM
Dependency status: British crown dependency
Government type: parliamentary democracy
Capital: Douglas
Administrative divisions; there are 24 local
authorities each with its own elections
Independence: none (British crown dependency)
National holiday: Tynwald Day, 5 July
Constitution; unwritten; note - The Isle of Man
Constitution Act, 1961 , does not embody the Manx
Constitution
Legal system: English common law and Manx
statute
Suffrage: 18 years of age; universal
Executive branch;
chief of state: Lord of Mann Queen ELIZABETH II
(since 6 February 1952), represented by Lieutenant
Governor His Excellency Sir Timothy DAUNT (since
27 October 1995)
head of government: Chief Minister Donald GELLING
(since 3 December 1996)
cabinet: Council of Ministers
elections: the monarch is hereditary; lieutenant
governor appointed by the monarch for a five-year
term; the Chief Minister is elected by the Tynwald;
election last held 3 December 1996 (next to be held
NA 2001)
election results: Donald GELLING elected chief
minister by the Tynwald
Legislative branch: bicameral Tynwald consists of
the Legislative Council (a 10-member body composed
of the Lord Bishop of Sodor and Man, a nonvoting
attorney general, and 8 others named by the House of
Keys) and the House of Keys (24 seats; members are
elected by popular vote to serve five-year terms)
elections: House of Keys - last held 21 November
1996 (next to be held NA November 2001)
election results: House of Keys - percent of vote by
party - NA; seats by party - independents 24
Judicial branch: High Court of Justice, justices are
appointed by the Lord Chancellor of England on the
nomination of the lieutenant governor
Political parties and leaders; there is no party
system; members sit as independents
International organization participation; none
Diplomatic representation in the US: none (British
crown dependency)
Diplomatic representation from the US; none
(British crown dependency)
Flag description: red with the Three Legs of Man
emblem (Trinacria), in the center; the three legs are
joined at the thigh and bent at the knee; in order to
have the toes pointing clockwise on both sides of the
flag, a two-sided emblem is used
r . .
Economy - overview: Offshore banking,
manufacturing, and tourism are key sectors of the
economy. The government''s policy of offering
incentives to high-technology companies and financial
institutions to locate on the island has paid off in
expanding employment opportunities in high-income
industries. As a result, agriculture and fishing, once
the mainstays of the economy, have declined in their
shares of GDP. Banking and other services now
contribute the great bulk of GDP. Trade is mostly with
the UK. The Isle of Man enjoys free access to EU
markets.
GDP: purchasing power parity - $1 .2 billion
(1998 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity -
$16,000 (1998 est.)
GDP - composition by sector:
agricultu','f926c7bbcbc048d8095ea45bee8b8750bb0551b6467f5263e793dbfc5b2eaa7e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab8f130257d734710f6836c2417c245357d66110c2e05cef23e0f7e62c60967d',2000,'MV','Maldives','geography',317,'re: 1%
industry: 10%
services: 89% (1999 est.)
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices); 2% (1999 est.)
Labor force: 36,61 0 (1 998)
Labor force - by occupation: agriculture, forestry
and fishing 3%, manufacturing 11%, construction
10%, transport and communication 8%, wholesale
and retail distribution 1 1 %, professional and scientific
sen/ices 18%, public administration 6%, banking and
finance 18%, tourism 2%, entertainment and catering
3%, miscellaneous services 10%
Unemployment rate: 0.7% (July 1999)
Budget:
revenues; $81 6 million
expenditures: $504 million, including capital
expenditures of $NA (FY99/00 est.)
Industries: financial sen/ices, light manufacturing,
tourism
Industrial production growth rate: 3.2% (1996/97)
Electricity - production: 329 million kWh (1999)
Electricity ■ production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1999)
Electricity ■ consumption; 287 million kWh (1999)
Electricity - exports: NA kWh
Electricity - imports; NA kWh
Agriculture - products; cereals, vegetables; cattle,
sheep, pigs, poultry
Exports: $NA
Exports - commodities: tweeds, herring,
processed shellfish, beef, lamb
Exports - partners: UK
Imports; $NA
Imports - commodities: timber, fertilizers, fish
Imports - partners; UK
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 Manx pound = 100 pence
Exchange rates: Manx pounds per US$1 - 0.6092
(January 2000), 0.61 80 (1 999), 0.6037 (1 998), 0.61 06
(1997), 0.6403 (1996), 0.6335 (1995); the Manx
pound is at par with the British pound
Fiscal year: 1 April - 31 March
I" Communications
Telephones - main lines in use: 51,000 (1999)
Telephones - mobile cellular; NA
Telephone system;
domestic: landline, telefax, mobile cellular telephone
system
international: fiber-optic cable, microwave radio relay,
satellite earth station, submarine cable
315
Man, Isle of (continued)
Radio broadcast stations: AM1 , FM1 , shortwave
0(1998)
Radios; NA
Teievision broadcast stations; 0 (receives
broadcasts from the UK and satellite) (1999)
Televisions: 27,490(1999)
Internet Service Providers (ISPs): NA','52b0edb4f0b45bd5c54de0370b9febbfcb77f8137c46cbc6da2e955eef34100a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd713cee001e826e863baa7a882b508ed2e48add16fbcab1558085b5fe29d2a7',2000,'MH','Marshall Islands','geography',322,'Location: Oceania, group of atolls and reefs in the
North Pacific Ocean, about one-half of the way from
Hawaii to Papua New Guinea
Geographic coordinates; 9 00 N, 168 00 E
Map references: Oceania
Area:
tofa/;181.3sq km
/and.- 181 .3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak, and
Kwajalein
Area - comparative: about the size of Washington,
DC
Land boundaries; 0 km
Coastline: 370.4 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: wet season from May to November; hot and
humid; islands border typhoon belt
Terrain: low coral limestone and sand islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: phosphate deposits, marine
products, deep seabed minerals
Land use:
arable land: 0%
permanent crops: 60%
permanent pastures: 0%
forests and woodland: 0%
other: 40%
Irrigated land; NA sq km
Natural hazards: occasional typhoons
Environment - current issues: inadequate
supplies of potable water
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: two archipelagic island chains of
30 atolls and 1 ,1 52 islands; Bikini and Enewetak are
former US nuclear test sites; Kwajalein, the famous
World War II battleground, is now used as a US
missile test range
Location: Caribbean, island in the Caribbean Sea,
north of Trinidad and Tobago
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 1,100 sq km
land: 1 ,060 sq km
water: 40 sq km
Area - comparative: slightly more than six times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; moderated by trade winds; rainy
season (June to October); vulnerable to devastating
cyclones (hurricanes) every eight years on average;
average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline;
dormant volcano
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1,397 m
Natural resources: coastal scenery and beaches,
cultivable land
Land use:
arable land: 8%
permanent crops: 8%
permanent pastures: 17%
forests and woodland: 44%
other 23% (1993 est.)
Irrigated land: 40 sq km (1 993 est.)
Natural hazards: hurricanes, flooding, and volcanic
activity (an average of one major natural disaster
every five years)
Environment - current issues: NA','20feffa34d45f8175c81963d06027f7b75b07bcec0676eb4cfbc0633fb2fdc67','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ccc896aa08ccc5b88ad9b6214a7cc67243304eed61087e68e7a6795ffeff5df',2000,'MR','Mauritania','geography',327,'conventional short form: Mauritania
local long form; Al Jumhuriyah al Islamiyah al
Muritaniyah
local short form: Muritaniyah
Data code: MR
Government type: republic
Capital; Nouakchott
Administrative divisions: 12 regions (regions,
singular - region) and 1 capital district*; Adrar,
Assaba, Brakna, Dakhlet Nouadhibou, Gorgol,
Guidimaka, Hodh Ech Chargui, Hodh El Gharbi,
Inchiri, Nouakchott*, Tagant, Tiris Zemmour, Trarza
Independence: 28 November 1960 (from France)
National holiday: Independence Day, 28 November
(1960)
Constitution: 12 July 1991
Legal system: a combination of Shari''a (Islamic law)
and French civil law
Suffrage; 18 years of age; universal
Executive branch:
chief of state: President Col. Maaouya Quid Sid
Ahmed TAYA (since 12 December 1984)
head of government: Prime MinisterCheikel Afia Quid
Mohamed KHOUNA (since 16 November 1998)
cabinet: Council of Ministers
elections: president elected by popular vote for a
six-year term; election last held 12 December 1997
(next to be held NA December 2003); prime minister
appointed by the president
election results: President Col. Maaouya Quid Sid
Ahmed TAYA reelected with 90.9% of the vote
Legislative branch; bicameral legislature consists
of the Senate or Majlis al-Shuyukh (56 seats; 1 7 up for
election every two years; members elected by
municipal leaders to serve six-year terms) and the
National Assembly or Majlis al-Watani (79 seats;
members elected by popular vote to serve five-year
terms)
elections: Senate - last held 1 7 April 1 998 (next to be
held NA 2001); National Assembly - last held 1 1 and
1 8 October 1 996 (next to be held NA 2001 )
election results: Senate - percent of vote by party -
NA; seats by party - NA; National Assembly - percent
of vote by party - NA; seats by party - PRDS 71 , AC 1 ,
independents and other 7
Judicial branch: three-tier system: lower, appeals,
and Supreme Court (Cour Supreme)
Political parties and leaders: Action for Change or
AC [Messoud Quid BOULKHEIR]; Assembly for
Democracy and Unity or RDU [Ahmed Quid SIDI
BABAj; Democratic and Social Republican Party or
PRDS (ruling party) [President Col. Maaouya Quid Sid
Ahmed TAYAj; National Avant-Garde Party or PAN
[Khattry Quid JIDDOUj; Popular Social and
Democratic Union or UPSD [Mohamed Mahmoud
Quid MAH]; Union of Democratic Forces-New Era or
UFD/NE [Ahmed Quid DADDAH]
note: parties legalized by constitution passed 12 July
1991 , however, politics continue to be tribally based
Political pressure groups and leaders: General
Confederation of Mauritanian Workers or CGTM
[Abdallahi Quid MOHAMED, secretary general];
Mauritanian Workers Union or UTM [Mohamed Ely
Quid BRAHIM, secretary general]; B''athists; Arab
nationalists; Islamists
International organization participation; ABEDA,
ACCT (associate), ACP, AfDB, AFESD, AL, AMF,
AMU, CAEU, CCC, ECA, ECOWAS, FAO, G-77,
IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, IHO
(pending member), ILO, IMF, IMO, Intelsat, Interpol,
IOC, ITU, NAM, OAU, OIC, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WlPO, WMO, WToO,
WTrO
Diplomatic representation in the US;
c/7/ef of m/ssfon; Ambassador Ahmed Ben Khalifa
BENJIDDOU
chancery: 2129 Leroy Place NW, Washington, DC
20008
telephone: [t] {202) 232-5700
FAX; [1] (202) 319-2623
Diplomatic representation from the US:
chief of mission: Ambassador Timberlake FOSTER
embassy: Rue Abdallahi Ould Oubeid, Nouakchott
mailing address: B. P. 222, Nouakchott
telephone: [222] (2) 526-60, 526-63
FAX; [222] (2) 51 5-92
Flag description: green with a yellow five-pointed
star above a yellow, horizontal crescent; the closed
side of the crescent is down; the crescent, star, and
color green are traditional symbols of Islam
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: World
Area:
total: 1 ,860 sq km
land: 1 ,850 sq km
wafer lOsq km
note: includes Agalega Islands, Cargados Carajos
Shoals (Saint Brandon), and Rodrigues
Area - comparative: almost 1 1 times the size of
Washington, DC
Land boundaries; 0 km
Coastline: 177 km
Maritime claims;
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical, modified by southeast trade winds;
warm, dry winter (May to November); hot, wet, humid
summer (November to May)
Terrain: small coastal plain rising to discontinuous
mountains encircling central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
Natural resources: arable land, fish
Land use;
arable land: 49%
permanent crops: 3%
permanent pastures: 3%
forests and woodland: 22%
other: 23% (1993 est.)
irrigated land: 170 sq km (1993 est.)
Natural hazards: cyclones (November to April);
almost completely surrounded by reefs that may pose
maritime hazards
Environment - current issues: water pollution
Environment ■ international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Location: Southeastern Europe, bordering the
Adriatic Sea, between Albania and Bosnia and
Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
tofa/.- 102,350 sq km (Serbia 88,412 sq km;
Montenegro 13,938 sq km)
/and; 102,136 sq km (Serbia 88,412 sq km;
Montenegro 13,724 sq km)
water: 214 sq km (Serbia 0 sq km; Montenegro 214 sq
km)
Area - comparative: slightly smaller than Kentucky
(Serbia is slightly larger than Maine; Montenegro is
slightly smaller than Connecticut)
Land boundaries:
totai: 2,246 km
border countries: Albania 287 km (1 1 4 km with
Serbia, 173 km with Montenegro), Bosnia and
Herzegovina 527 km (31 2 km with Serbia, 21 5 km with
Montenegro), Bulgaria 318 km (with Serbia), Croatia
(north) 241 km (with Serbia), Croatia (south) 25 km
(with Montenegro), Hungary 151 km (with Serbia),
The Former Yugoslav Republic of Macedonia 221 km
(with Serbia), Romania 476 km (with Serbia)
note: the internal boundary between Montenegro and
Serbia is 21 1 km
Coastline: 199 km (Montenegro 199 km, Serbia 0
km)
Maritime claims: NA
Climate: in the north, continental climate (cold
winters and hot, humid summers with well distributed
rainfall); central portion, continental and
Mediterranean climate; to the south, Adriatic climate
along the coast, hot, dry summers and autumns and
relatively cold winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to the
southeast, ancient mountains and hills; to the
southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper,
lead, zinc, nickel, gold, pyrite, chrome, hydro power
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: destructive earthquakes
Environment - current Issues: pollution of coastal
waters from sewage outlets, especially in
tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava
which flows into the Danube
Environment • international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography - note: controls one of the major land
routes from Western Europe to Turkey and the Near
East; strategic location along the Adriatic coast','e6d611caa186db7e2eeefc3b62b89684748161256d2534acebf01b986a13232b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9910ab1985629ac5d1b22b09726541bb2cef7dbae4fb5f94163662a27214622c',2000,'ID','Indonesia','geography',347,'Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Honolulu to Tokyo
Geographic coordinates: 28 13 N, 177 22 W
Map references; Oceania
Area;
total: 6.2 sq km
land: 6.2 sq km
water: 0 sq km
note: includes Eastern Island, Sand Island, and Spit
Island
Area ■ comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries; 0 km
Coastline: 15 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: subtropical, but moderated by prevailing
easterly winds
Terrain: low, nearly level
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 13 m
Natural resources: wildlife, terrestrial and aquatic
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0 sq km (1998)
Natural hazards; NA
Environment - current issues: NA
Geography - note: a coral atoll managed as a
national wildlife refuge and open to the public for
wildlife-related reoreation in the form of wildlife
observation and photography, sport fishing,
snorkeling, and scuba diving
330
Midway Islands (continued)
I People
Population: no indigenous inhabitants (July
2000 est.)
I Governmenf
Country name:
conventional long form: none
conventional short form: Midway isiands
Data code: MQ
Dependency status: unincorporated territory of the
US; formerly administered from Washington, DC, by
the US Navy, under Navai Facilities Engineering
Command, Pacific Division; this faciiity has been
operationaliy dosed since 10 September 1993; on 31
October 1996, through a presidential executive order,
the jurisdiction and control of the atoll was transferred
to the Fish and Wildlife Service of the US Department
of the Interior as part of the National Wildlife Refuge
system
Capital: none; administered from Washington, DC
Flag description: the flag of the US is used
I i c oil 0 m y
Economy - overview: The economy is based on
providing support services for the national wildlife
refuge activities located on the islands. All food and
manufactured goods must be imported.
I ~ ” t r a n s p 0 r t a t i 0 rl
Highways:
total: 32 km
paved: NA km
unpaved: NA km
Pipelines: 7.8 km
Ports and harbors: Sand Island
Airports: 3 (1999 est.)
Airports - with paved runways:
total: 2
1, 524 to 2, 437 m: 2 (m9 est.)
Airports - with unpaved runways:
total: 1
914 tot, 523 m-A (1999 est.)
I Military
Military - note: defense is the responsibility of the
US
I Transnational Issues
Disputes - international: none
Background: Formerly ruled by Romania, Moldova
became part of the Soviet Union at the close of World
War II. Although independent from the USSR since
1991 , Russian forces have remained on Moldovan
territory east of the Nistru (Dnister) River supporting
the Slavic majority population (mostly Ukrainians and
Russians) who have proclaimed a "Transnistria"
republic.
F —
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Commonwealth of Independent
States
Area:
total: 33,843 sq km
land: 33,371 sq km
water: 472 sq km
Area - comparative: slightly larger than Maryland
Land boundaries:
total: 1 ,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black
Sea
Elevation extremes:
lowest point: Nistru River 2 m
highest point: Dealul Balanesti 430 m
Natural resources: lignite, phosphorites, gypsum,
arable land
Land use:
arable land: 53%
permanent crops: 1 4%
permanent pastures: 1 3%
forests and woodland: 13%
other; 7% (1993 est.)
Irrigated land: 3,1 10 sq km (1993 est.)
Natural hazards: landslides (57 cases in 1998)
Environment - current issues: heavy use of
agricultural chemicals, including banned pesticides’
such as DDT, has contaminated soil and
groundwater; extensive soil erosion from poor farming
methods
Environment - international agreements:
party to; Air Pollution, Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: A\\r Pollution-Persistent
Organic Pollutants
Geography - note: landlocked','4fec2f048afaa20e1788d67549378f66e42eafdd6a01206787a46db47b3f4a20','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaaf39f5458ec7975d4d1ad8aaae19188f15deceb84e97c9516d6d73cf811a04',2000,'MZ','Mozambique','geography',351,'Location: Southern Africa, bordering the
Mozambique Channei, between South Africa and
Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total: 801 ,590 sq km
land: 784,090 sq km
water: 17,500 sq km
Area - comparative: slightiy less than twice the size
of Caiifornia
Land boundaries:
fofa/.- 4,571 km
border countries: Malawi 1,569 km. South Africa 491
km, Swaziland 105 km, Tanzania 756 km, Zambia 41 9
km, Zimbabwe 1 ,231 km
Coastline: 2,470 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center,
high plateaus in northwest, mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas,
hydropower
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 56%
forests and woodland: 1 8%
ofter: 22% (1993 est.)
Irrigated land: 1,180 sq km (1993 est.)
Natural hazards: severe droughts and floods occur
in central and southern provinces; devastating
cyclones
Environment - current issues: a long civil war and
recurrent drought in the hinterlands have resulted in
increased migration of the population to urban and
coastal areas with adverse environmental
consequences; desertification; poliution of surface
and coastal waters
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
t People
Population: 19,104,696
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected; the 1997 Mozambican census reported a
population of 16,099,246 (July 2000 est.)
Age structure:
0-14 years: 43% (male 4,079,240; female 4,122,578)
15-64 years: 54% (male 5,123,1 78; female
5,262,618)
65 years and over: 3% (male 21 5,41 2; female
301,670) (2000 est.)
Population growth rate: 1 .47% (2000 est.)
Birth rate: 37.99 births/1,000 population (2000 est.)
Death rate: 23.29 deaths/1,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.99 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate: 1 39.86 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 37.52 years
male: 38.34 years
female: 36.68 years (2000 est.)
Total fertility rate: 4.93 children born/woman
(2000 est.)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
(Shangaan, Chokwe, Manyika, Sena, Makua, and
others), Europeans 0.06%, Euro-Africans 0.2%,
Indians 0.08%
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: Portuguese (official), indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 40.1%
male: 57.7%
female: 23.3% (1995 est.)
Location: Oceania, island in the South Pacific
Ocean, south of the Marshali Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references; Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area - comparative: about 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nm
Climate: tropicai; monsoonai; rainy season
(November to February)
Terrain: sandy beach rises to fertile ring around
raised coral reefs with phosphate piateau in center
Elevation extremes;
lowest point: Pacific Ocean 0 m
highest point: unnamed iocation along plateau rim
61 m
Natural resources; phosphates
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
often 100% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: periodic droughts
346
Nauru (continued)
Environment - current issues: limited natural fresh
water resources, roof storage tanks collect rainwater,
but mostly dependent on a single, aging desalination
plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and New Zealand
consortium - has left the central 90% of Nauru a
wasteland and threatens limited remaining land
resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping
signed, but not ratified: none of the selected
agreements
Geography - note: Nauru is one of the three great
phosphate rock islands in the Pacific Ocean - the
others are Banaba (Ocean Island) in Kiribati and
Makatea in French Polynesia; only 53 km south of
Equator
I p''e o p I e ^
Population: 11,845 (July 2000 est.)
Age structure:
0-14 years; 40.99% (male 2,494; female 2,361)
15-64 years: 57.37% (male 3,383; female 3,41 3)
65 years and over: 1 .64% (male 97; female 97)
(2000 est.)
Population growth rate: 2.05% (2000 est.)
Birth rate: 27.86 births/1,000 population (2000 est.)
Death rate: 7.34 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 10.9 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 60.84 years
male: 57.35 years
female: 64.5 years (2000 est.)
Total fertility rate: 3.71 children born/woman
(2000 est.)
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages: Nauruan (official, a distinct Pacific
Island language), English widely understood, spoken,
and used for most government and commercial
purposes
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
I Government
Country name:
conventional long form: Republic of Nauru
conventional short form: Nauru
former: Pleasant Island
Data code: NR
Government type: republic
Capital: no official capital; government offices in
Yaren District
Administrative divisions: 14 districts; Aiwo,
Anabar, Anetan, Anibare, Baiti, Boe, Buada,
Denigomodu, Ewa, ljuw, Meneng, Nibok, Uaboe,
Yaren
Independence: 31 January 1968 (from the
Australia-, New Zealand-, and UK-administered UN
trusteeship)
National holiday: Independence Day, 31 January
(1968)
Constitution: 29 January 1968
Legal system: acts of the Nauru Parliament and
British common law
Suffrage: 20 years of age; universal and compulsory
Executive branch:
chief of state: President Rene HARRIS (since NA
1999); note - the president is both the chief of state
and head of government
head of government: President Rene HARRIS (since
NA 1 999); note - the president is both the chief of state
and head of government
cabinet: Cabinet appointed by the president from
among the members of Parliament
elections: president elected by Parliament for a
three-year term; election last held 27 April 1 999 (next
to be held NA2002)
election results: Rene HARRIS elected president;
percent of Parliament vote - NA
note; former President Bernard DOWIYOGO was
deposed in a no-confidence vote
Legislative branch: unicameral Parliament (18
seats; members elected by popular vote to serve
three-year terms)
elections: last held 8 February 1997 (next to be held
NA February 2000)
election results: percent of vote - NA; seats -
independents 18
Judicial branch: Supreme Court
Political parties and leaders: loose multiparty
system; Democratic Party [Kennan ADEANG]; Nauru
Party (informal) [Bernard DOWIYOGO]
International organization participation: AsDB, C,
ESCAP, ICAO, Intelsat (nonsignatory user), Interpol,
IOC, ITU, OPCW, Sparteca, SPC, SPF, UN,
UNESCO, UPU, WHO
Diplomatic representation in the US: Nauru does
not have an embassy in the US, but will open a UN
office early in 2000 at 800 2nd Avenue, New York,
New York
consulate(s): Agana (Guam)
Diplomatic representation from the US: the US
does not have an embassy in Nauru; the US
Ambassador to Fiji is accredited to Nauru
Flag description: blue with a narrow, horizontal,
yellow stripe across the center and a large white
12-pointed star below the stripe on the hoist side; the
star indicates the country''s location in relation to the
Equator (the yellow stripe) and the 12 points
symbolize the 12 original tribes of Nauru
I E co n 6 m y
Economy - overview: Revenues of this tiny island
come from exports of phosphates, but reserves are
expected to be exhausted in the year 2000.
Phosphates have given Nauruans one of the highest
per capita incomes in the Third World, with estimates
of GDP varying widely. Few other resources exist,
thus most necessities must be imported, including
fresh water from Australia. The rehabilitation of mined
land and the replacement of income from phosphates
are serious long-term problems. Substantial amounts
of phosphafe income are invested in trust funds to
help cushion the transition. The government also has
been borrowing heavily from the trusts to finance fiscal
deficits. To cut costs the government has called for a
freezing of wages, a reduction of over-staffed public
service departments, privatization of numerous
government agencies, and closure of some overseas
consulates. In recent years Nauru has encouraged
the registration of offshore banks and corporations.
Tens of billions of dollars have been channeled
through their accounts.
GDP: purchasing power parity - $100 million
(1993 est.)
GDP - real growth rate: NA%
GDP ■ per capita: purchasing power parity -
$10,000 (1993 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -3.6% (1993)
Labor force - by occupation: employed in mining
phosphates, public administration, education, and','4cd48633659d03d9537c280971999a96416ebd033898bacae492a22d56115950','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5115257937f1ebdc98819a41ca21205664640b26fc855b662207b6d44d0503eb',2000,'NL','Netherlands','geography',357,'Location: Caribbean, two island groups in the
Caribbean Sea - one includes Curacao and Bonaire
north of Venezuela and the other is east of the Virgin
Islands
Geographic coordinates: 1 2 1 5 N, 68 45 W
Map references: Central America and the
Caribbean
Area:
total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part of the island
of Saint Martin)
Area - comparative: more than five times the size of
Washington, DC
Land boundaries:
total: 10.2 km
border courrfr/es; Guadeloupe (Saint Martin) 10.2 km
Coastline: 364 km
Maritime claims:
exclusive fishing zone: 12 nm
territorial sea: t2 nm
Climate: tropical; ameliorated by northeast trade
winds
Terrain: generally hilly, volcanic interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao only), salt
(Bonaire only)
Land use:
arable land: 10%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 90% (1993est.)
Irrigated land: NA sq km
Natural hazards: Curacao and Bonaire are south of
Caribbean hurricane belt and are rarely threatened;
Sint Maarten, Saba, and Sint Eustatius are subject to
hurricanes from July to October
Environment - current issues: NA
t iP e 0 p I e
Population: 210,134 (July 2000 est.)
Age structure:
0-U years: 25% (male 27,320; female 26,230)
15-64 years: 67% (male 66,653; female 73,81 3)
65 years and over: 8% (male 6,701 ; female 9,41 7)
(2000 est.)
Population growth rate: 1 .01% (2000 est.)
Birth rate: 16.94 births/1,000 population (2000 est.)
Death rate: 6.42 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.42 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.92 male(s)/female (2000 est.)
Infant mortality rate: 1 1 .74 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 74.72 years
male: 72.56 years
female: 76.99 years (2000 est.)
Total fertility rate: 2.09 children born/woman
(2000 est.)
Nationality:
noun: Netherlands Antillean(s)
adjective: Netherlands Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white. East Asian
Religions: Roman Catholic, Protestant, Jewish,
Seventh-Day Adventist
Languages: Dutch (official), Papiamento (a
Spanish-Portuguese-Dutch-English dialect)
predominates, English widely spoken, Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 99% (1981 est.)','a06fbbf58225fd16f719379cbfc9a888464a6a206f24ef9b7513e2225d36ab0a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eff14bc8218b03c114ff478596496630bf16d15da3b54f8089899a5b0e8667e9',2000,'PH','Philippines','geography',383,'Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 55%
forests and woodland: 32%
of/?er;7% (1993 est.)
Irrigated land: 670 sq km (1993 est.)
Natural hazards: local flooding in southeast (early
September to June); poorly drained plains may
become boggy (early October to June)
Environment - current issues: deforestation (an
estimated 2 million hectares of forest land were lost
from 1958-85); water pollution; inadequate means for
waste disposal present health risks for many urban
residents
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography - note: landlocked; lies between
Argentina, Bolivia, and Brazil
Geographic coordinates: 8 38 N, 1 1 1 55 E
Map references; Southeast Asia
Area;
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea
mounts scattered over an area of nearly 41 0,000 sq
km of the central South China Sea
Area - comparative; NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims; NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4
m
Natural resources: fish, guano, undetermined oil
and natural gas potential
Land use;
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: typhoons; serious maritime hazard
because of numerous reefs and shoals
Environment - current issues: NA
Geography - note: strategically located near several
primary shipping lanes in the central South China Sea;
includes numerous small islands, atolls, shoals, and
coral reefs','975973ca89bc3e8991ab1830ad32949ce9f6a039af38ea32d88bab16f55182b9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f1d5b4dfff69ae16d0094b1a8131f487b7d17a27bdce637c31aaa20fbe2d0f9',2000,'MX','Mexico','geography',395,'Location: Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references; Europe
Area;
total: 92,391 sq km
land: 91 ,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
Area - comparative: slightly smaller than Indiana
400
Portugsl (continued)
Land boundaries:
fofa/; 1,214 km
border countries: Spain 1 ,214 km
Coastline: 1,793 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
femfor/a/sea;12nm
Climate: maritime temperate; cool and rainy in north,
warmer and drier in south
Terrain: mountainous north of the Tagus River,
rolling plains in south
Elevation extremes:
/oivesfpo/nf; Atlantic Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto) on llha
do Pico in the Azores 2,351 m
Natural resources: fish, forests (cork), tungsten,
iron ore, uranium ore, marble, arable land, hydro
power
Land use:
arable land: 26%
permanent crops: 9%
permanent pastures: 9%
forests and woodland: 36%
other 20% (1 993 est.)
Irrigated land: 6,300 sq km (1993 est.)
Natural hazards: Azores subject to severe
earthquakes
Environment - current issues: soil erosion; air
pollution caused by industrial and vehicle emissions;
water pollution, especially in coastal areas
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: An Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol,
Environmental Modification, Nuclear Test Ban
Geography - note: Azores and Madeira Islands
occupy strategic locations along western sea
approaches to Strait of Gibraltar
Population: 10,048,232 (July 2000 est.)
Age structure:
0-14years: 17% (male 880,501; female 834,062)
15-64 years: 68% (male 3,319,143; female
3,468,009)
65 years and over: 1 5% (male 628, 1 01 ; female
918,416) (2000 est.)
Population growth rate: 0.18% (2000 est.)
Birth rate: 1 1 .49 births/1 ,000 population (2000 est.)
Death rate: 10.2 deaths/1,000 population
(2000 est.)
Net migration rate: 0.5 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.92 male(s)/female (2000 est.)
Infant mortality rate: 6.05 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 75.75 years
male: 72.24 years
female: 79.49 years (2000 est.)
Total fertility rate: 1 .47 children born/woman
(2000 est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock;
citizens of black African descent who immigrated to
mainland during decolonization number less than
100,000
Religions: Roman Catholic 94%>, Protestant (1 995)
Languages: Portuguese
Literacy:
definition: age 1 5 and over can read and write
total population: 87.4%
male: NA%
female: NA%
I'' G oV^Fn m''lrnT''
Country name:
conventional long form: Portuguese Republic
conventional short form: Portugal
local long form: Republica Portuguesa
local short form: Portugal
Data code: PC
Government type: parliamentary democracy
Capital: Lisbon
Administrative divisions: 18 districts (distritos,
singular - distrito) and 2 autonomous regions*
(regioes autonomas, singular - regiao autonoma);
Aveiro, Acores (Azores)*, Beja, Braga, Braganca,
Castelo Branco, Coimbra, Evora, Faro, Guarda,
Leiria, Lisboa, Madeira*, Portalegre, Porto, Santarem,
Setubal, Viana do Castelo, Vila Real, Viseu
Independence: 1 1 40 (independent republic
proclaimed 5 October 1910)
National holiday: Day of Portugal, 1 0 June (1 580)
Constitution: 25 April 1976, revised 30 October
1982, 1 June 1989, 5 November 1992, and 3
September 1997
Legal system: civil law system; the Constitutional
Tribunal reviews the constitutionality of legislation;
accepts compulsory ICJ jurisdiction, with reservations
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Jorge SAMPAIO (since 9
March 1996)
head of government: Prime Minister Antonio Manuel
de Oliviera GUTERRES (since 28 October 1995)
cabinet: Council of Ministers appointed by the
president on the recommendation of the prime
minister
note: there is also a Council of State that acts as a
consultative body to the president
elections: president elected by popular vote for a
five-year term; election last held 1 4 January 1 996
(next to be held NA January 2001); following
legislative elections, the leader of the majority party or
leader of a majority coalition is usually appointed
prime minister by the president
election resu/fs; Jorge SAMPAIO elected president;
percent of vote - Jorge SAMPAIO (Socialist) 53.8%,
Anibal CAVACO SILVA (Social Democrat) 46.2%
Legislative branch: unicameral Assembly of the
Republic or Assembleia da Republica (230 seats;
members are elected by popular vote to serve
four-year terms)
elections: last held 10 October 1999 (next to be held
by NA October 2003)
election results: percent of vote by party - PSP 43.9%,
PSD 32.3%, CDU 9%, PP 8.3%, The. Left Bloc 2.4%;
seats by party - PSP 113, PSD 83, CDU 17, PP 15,
The Left Bloc 2
Judicial branch: Supreme Court or Supremo
Tribunal de Justica, judges appointed for life by the
Conselho Superior da Magistratura
Political parties and leaders: Popular Party or f P
[Paulo PORTASj; Portuguese Communist Part/United
Democratic Coalition or PCP/CDU [Carlos
CARVALHASj; Portuguese Socialist Party or PSP
[Antonio GUTERRES]; Social Democratic Party or
PSD [Jose Manuel DURAO BARROSOj; The Left
Bloc [Francisco LOUCA]
International organization participation: AfDB,
Australia Group, BIS, CCC, CE, CERN, EAPC, EBRD,
ECE, ECLAC, EIB, EMU, EU, FAC, lADB, IAEA,
IBRD, ICAO, ICC, ICFTU, ICRM, IDA, lEA, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, lOM, ISO, ITU, LAIA (observer),
MINURSO, NAM (guest), NATO, NEA, NSG, OAS
(observer), OECD, OPCW, OSCE, PCA, UN,
UNCTAD, UNESCO, UNIDO, UNMIBH, UNMIK,
UNMOP, UPU, WCL, WEU, WFTU, WHO, WlPO,
WMO, WToO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Joao Alberto Bacelar
DA ROCKA PARIS
chancery: 2125 Kalorama Road NW, Washington, DC
20008
fe/ephone; [11(202)328-8610
FAX; [1] (202) 462-3726
consulate(s) general: Boston, New York, Newark
(New Jersey), and San Francisco
consulate(s): Los Angeles, New Bedford
(Massachusetts), Providence (Rhode Island)
Diplomatic representation from the US:
chief of mission: Ambassador Gerald S. MCGOWAN
embassy: Avenida das Forcas Armadas, 1 600 Lisbon
mailing address: PSC 83, APO AE 09726
telephone: [351] (21) 727-3300
FAX; [351] (21) 726-9109
consulate(s): Ponta Delgada (Azores)
Flag description: two vertical bands of green (hoist
side, two-fifths) and red (three-fifths) with the
Portuguese coat of arms centered on the dividing line
PortUQdl (continued)','e1e933e35c13d8e8503916331e89766834c7bc5a715b30d25e1f6399c4fc797e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61ab7d0061342aa7b87377c53c6f8161ab349e74b85627c2d3d28095a4257bee',2000,'HR','Croatia','geography',424,'Geographic coordinates: 46 00 N, 15 00 E
Map references: Europe
Area:
total: 20,253 sq km
land: 20,253 sq km
water: 0 sq km
Area - comparative: slightly smaller than New','6881d1907318105693b8c921f2279d11751b5800d4b5d93efcbe06cecac273d1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1806c6f14a4e0c9647bed665b75602c704869c6f3b4a70a917a9b64a323a13c8',2000,'SO','Somalia','geography',426,'Location: Eastern Africa, bordering the Gulf of Aden
and the Indian Ocean, east of Ethiopia
Geographic coordinates; 10 00 N, 49 00 E
Map references: Africa
Area:
total: 637,657 sq km
land: 627,337 sq km
water; 10,320 sq km
Area - comparative: slightly smaller than Texas
Land boundaries;
total: 2,366 km
border countries: Djibouti 58 km, Ethiopia 1 ,626 km,
Kenya 682 km
Coastline; 3,025 km
Maritime claims:
territorial sea: 200 nm
Climate: principally desert; December to February -
northeast monsoon, moderate temperatures in north
and very hot in south; May to October - southwest
monsoon, torrid in the north and hot in the south,
irregular rainfall, hot and humid periods (tangambili)
between monsoons
Terrain: mostly flat to undulating plateau rising to
hills in north
Elevation extremes;
lowest point: Indian Ocean 0 m
454
Somalia (continued)
highest point: Shimbiris 2,41 6 m
Natural resources; uranium and largely unexploited
reserves of iron ore, tin, gypsum, bauxite, copper, salt
Land use;
arable land: 2%
permanent crops: 0%
permanent pastures: 69%
forests and woodland: 26%
of/ier; 3% (1993 est.)
Irrigated land; 1,800 sq km (1993 est.)
Natural hazards; recurring droughts; frequent dust
storms over eastern plains in summer; floods during
rainy season
Environment - current issues; famine; use of
contaminated water contributes to human health
problems; deforestation; overgrazing; soil erosion;
desertification
Environment - international agreements;
party to: Endangered Species, Law of the Sea
signed, but not ratified: Marine Dumping, Nuclear
Test Ban
Geography - note; strategic location on Horn of
Africa along southern approaches to Bab el Mandeb
and route through Red Sea and Suez Canal
Population; 7,253,''137
note: this estimate was derived from an official census
taken in 1975 by the Somali Government; population
counting in Somalia is complicated by the large
number of nomads and by refugee movements in
response to famine and clan warfare (July 2000 est.)
Age structure;
0-14years:AA% (male 1,610,945; female 1 ,608,209)
15-64 years: 53% (male 1,938,263; female
1,892,752)
65 years and over: 3% (male 90,717; female
112,251) (2000 est.)
Population growth rate; 2.9% (2000 est.)
Birth rate; 47.7 births/1 ,000 population (2000 est.)
Death rate; 1 8.69 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over. 0.81 male(s)/female
total population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate; 125.77 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth;
total population: 46.23 years
ma/e; 44.66 years
female: 47.85 years (2000 est.)
Total fertility rate; 7.18 children born/woman
(2000 est.)
Nationality;
noun: Somali(s)
adjective: Somali
Ethnic groups; Somali 85%, Bantu, Arabs 30,000
Religions; Sunni Muslim
Languages; Somali (official), Arabic, Italian, English
Literacy;
definition: age 1 5 and over can read and write
total population: 24%
male: 36%
female: 1 4% (1 990 est.)
I Go vernment
fj '' - .
Country name;
conventional long form: none
conventional short form: Somalia
former: Somali Republic, Somali Democratic Republic
Data code; SO
Government type; none
Capital; Mogadishu
Administrative divisions; 18 regions (plural - NA,
singular - gobolka); Awdal, Bakool, Banaadir, Bari,
Bay, Galguduud, Gedo, Hiiraan, Jubbada Dhexe,
Jubbada Hoose, Mudug, Nugaai, Sanaag,
Shabeellaha Dhexe, Shabeellaha Hoose, Sool,
Togdheer, Woqooyi Galbeed
Independence; 1 July 1 960 (from a merger of British
Somaliland, which became independent from the UK
on 26 June 1960, and Italian Somaliland, which
became independent from the Italian-administered
UN trusteeship on 1 July 1960, to form the Somali
Republic)
National holiday; NA
Constitution; 25 August 1 979, presidential approval
23 September 1979
Legal system; NA
Suffrage; 1 8 years of age; universal
Executive branch; Somalia has no functioning
government; the United Somali Congress (USC)
ousted the regime of Major General Mohamed SIAD
Barre on 27 January 1991; the present political
situation is one of anarchy, marked by interclan
fighting and random banditry
Legislative branch; unicameral People''s Assembly
or Golaha Shacbiga
note: not functioning
Judicial branch; (not functioning); note - following
the breakdown of national government, most regions
have reverted to Islamic law with a provision for
appeal of all sentences
Political parties and ieaders; none
Political pressure groups and leaders; numerous
clan and subclan factions are currently vying for power
International organization participation; ACP,
AfDB, AFESD, AL, AMF, CAEU, ECA, FAO, G-77,
IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS,
IGAD, ILO, IMF, IMO, Intelsat, Interpol. IOC, lOM
(observer), ITU, NAM, OAU, OIC, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WFTU, WHO,
WlPO, WMO, WTrO (observer)
Diplomatic representation in the US; Somalia
does not have an embassy in the US (ceased
operations on 8 May 1991)
Diplomatic representation from the US; the US
does not have an embassy in Somalia; US interests
are represented by the US Embassy in Nairobi at Moi
Avenue and Haile Selassie Avenue; maii address: P.
0. Box 30137, Unit 64100, Nairobi; APO AE 09831;
telephone: [254] (2) 334141; FAX [254] (2) 340838
Flag description: light blue with a large white
five-pointed star in the center; design based on the
flag of the UN (Italian Somaliiand was a UN trust
territory)
Government - note: While chaos and clan fighting
continue in most of Somalia, some orderly
government has been established in the northern part.
In May 1991 , the elders of clans in former British
Somaliiand established the independent Republic of
Somaliiand, which, although not recognized by any
government, maintains a stable existence, aided by
the overwhelming dominance of the ruling clan and
the economic infrastructure left behind by British,
Russian, and American military assistance programs.
Neighboring Puntland has also made strides towards
reconstructing legitimate, representative government.
In February 1996, the EU agreed to finance the
reconstruction of the port of Berbers; since then, other
aid pro]ects have been assumed by the EU and by a
non-governmental Italian organization.
I'' . E^c^ n 0 m y
Economy - overview: One of the world''s poorest
and least developed countries, Somaiia has few
resources. Moreover, much of the economy has been
devastated by the civil war. Agriculture is the most
important sector, with livestock accounting for about
40% of GDP and about 65% of export earnings.
Nomads and semi-nomads, who are dependent upon
livestock for their livelihood, make up a large portion of
the population. After livestock, bananas are the
principal export; sugar, sorghum, corn, arid fish are
products for the domestic market. The small industrial
sector, based on the processing of agricultural
products, accounts for 10% of GDP; most facilities
have been shut down because of the civil strife.
Moreover, in 1999, ongoing civil disturbances in
Mogadishu and outlying areas interfered with any
substantial economic advance and with international
aid arrangements.
GDP: purchasing power parity - $4.3 billion
(1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $600
(1999 est.)
GDP ■ composition by sector:
agriculture: 59%
Industry: 10%
services: 31% (1995 est.)
Population below poverty line; NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 3.7 million (very few are skilled
laborers)(1993 est.)
Labor force - by occupation: agriculture (mostly
pastoral nomadism) 71%, industry and services 29%
Somalia (continued)
Unemployment rate: NA%
Budget;
revenues: $NA
expenditures: $NA, including capital expenditures of
$NA
Industries: a few small industries, including sugar
refining, textiles, petroleum refining (mostly shut
down)
Industrial production growth rate; NA%
Eiectricity - production: 265 million kWh (1998)
Electricity - production by source;
fossil fuel: ^00%
hydro: 0%
nuclear: 0%
other: Q%{m8)
Eiectricity - consumption: 246 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, sorghum, corn,
sugarcane, mangoes, sesame seeds, beans; cattle,
sheep, goats; fish
Exports: $187 million (f.o.b., 1998 est.)
Exports - commodities: livestock, bananas, hides,
fish (1997)
Exports - partners: Saudi Arabia 57%, UAE 15%,
Italy 12%, Yemen 8% (1997)
Imports: $327 million (f.o.b., 1998 est.)
Imports - commodities: manufactures, petroleum
products, foodstuffs, construction materials (1995)
Imports ■ partners: Djibouti 20%, Kenya 1 1 %,
Belarus 1 1 %, India 1 0%, Saudi Arabia 9%, Brazil 9%
(1997)
Debt - external: $2.6 billion (1997 est.)
Economic aid - recipient: $191.5 million (1 995)
Currency: 1 Somali shilling (So. Sh.) = 100 cents
Exchange rates: Somali shillings (So. Sh.) per
US$1 - 2,620 (January 1999), 7,500 (November
1997 est.), 7,000 (January 1996 est.), 5,000 (1
January 1 995), 2,61 6 (1 July 1 993), 4,200 (December
1992)
note.'' the Republic of Somaliland, a self-declared
independent country not recognized by any foreign
government, issues its own currency, the Somaliland
shilling (So. Sh.)
Fiscal year: NA
Location: Southern Africa, between South Africa
and Zambia
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total: 390,580 sq km
land: 386,670 sq km
wafer; 3,91 Osq km
Area - comparative: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique
1,231 km. South Africa 225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy
season (November to March)
Terrain: mostly high plateau with higher central
plateau (high veld); mountains in east
Elevation extremes:
towesfpo/nf; junction of the Runde and Save rivers
162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos,
gold, nickel, copper, iron ore, vanadium, lithium, tin,
platinum group metals
Land use:
arable land: 7%
permanent crops: 0%
permanent pastures: 1 3%
forests and woodland: 23%
other; 57% (1 993 est.)
Irrigated land: 1 ,930 sq km (1 993 est.)
Natural hazards: recurring droughts; floods and
severe storms are rare
Environment - current issues: deforestation; soil
erosion; land degradation; air and water pollution; the
black rhinoceros herd - once the largest concentration
of the species in the world - has been significantly
reduced by poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
_ , ^ ^ ^
Population: 11,342,521
note: estimates for this oountry explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 39.64% (male 2,274,128; female
2,222,277)
15-64 years: 56.82% (male 3,251 ,860; female
3,192,888)
65 years and over: 3.54% (male 204,028; female
197,340) (2000 est.)
Population growth rate: 0.26% (2000 est.)
Birth rate: 25 births/1,000 population (2000 est.)
Death rate: 22.43 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
note: there is a small but steady flow of Zimbabweans
into South Africa in search of better paid employment
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 1 .03 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 62.25 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 37.78 years
ma/e; 39.18 years
female: 36.34 years (2000 est.)
Total fertility rate: 3.34 children born/woman
(2000 est.)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 71%, Ndebele
16%, other 11%), white 1%, mixed and Asian 1%
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 1 5 and over can read and write English
total population: 85%
male: 90%
ferr)a/e;80%(1995est.)','9a5adfb7b937384fd362f598d7abf3b11292b03c03425e1670c5780e59c6e82b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7541607eee04c61230f7d638578194f036cd8cf521f7e8dcbde825a2cb5e2c0b',2000,'ZA','South Africa','geography',431,'Location: Southern Africa, at the southern tip of the
continent of Africa
Geographic coordinates; 29 00 S, 24 00 E
Map references: Africa
Area:
tofa/; 1,219,912 sq km
/and; 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island
and Prince Edward Island)
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 4,750 km
bordercounto''es; Botswana 1,840 km, Lesotho 909
km, Mozambique 491 km, Namibia 855 km,
Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime ciaims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly semiarid; subtropical along east
coast; sunny days, cool nights
South Africa (continued)
Terrain: vast interior piateau rimmed by rugged hiiis
and narrow coastai piain
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal,
iron ore, manganese, nickel, phosphates, tin,
uranium, gem diamonds, platinum, copper, vanadium,
salt, natural gas
Land use:
arable land: 10%
permanent crops: 1%
permanent pastures: 67%
forests and woodland: 7%
of/7er;15%(1993 est.)
Irrigated land: 12,700 sq km (1993 est.)
Natural hazards; prolonged droughts
Environment - current issues: lack of important
arterial rivers or lakes requires extensive water
conservation and control measures; growth in water
usage threatens to outpace supply; pollution of rivers
from agricultural runoff and urban discharge; air
pollution resulting in acid rain; soil erosion;
desertification
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: South Africa completely
surrounds Lesotho and almost completely surrounds
Swaziland
Location: body of water between 60 degrees south
latitude and Antarctica
Geographic coordinates: 65 00 S, 0 00 E
(nominally), but the Southern Ocean has the unique
distinction of being a large circumpolar body of water
totally encircling the continent of Antarctica; this ring of
water lies between 60 degrees south latitude and the
coast of Antarctica, and encompasses 360 degrees of
longitude
Map references: Antarctic Region
Area;
total: 20.327 million sq km
note: includes Amundsen Sea, Bellingshausen Sea,
part of the Drake Passage, Ross Sea, a small part of
the Scotia Sea, Weddell Sea, and other tributary water
bodies
Area - comparative: slightly more than twice the
size of the US
Coastline: 17,968 km
Climate: sea temperatures vary from about 10
degrees Centigrade to -2 degrees Centigrade;
cyclonic storms travel eastward around the continent
and frequently are intense because of the
temperature contrast between ice and open ocean;
the ocean area from about latitude 40 south to the
Antarctic Circle has the strongest average winds
found anywhere on Earth; in winter the ocean freezes
outward to 65 degrees south latitude in the Pacific
sector and 55 degrees south latitude in the Atlantic
sector, lowering surface temperatures well below 0
degrees Centigrade; at some coastal points intense
persistent drainage winds from the interior keep the
shoreline ice-free throughout the winter
Terrain: the Southern Ocean is deep, 4,000 to 5,000
meters over most of its extent with only limited areas
of shallow water; the antarctic continental shelf is
generally narrow and unusually deep - its edge lying
at depths of 400 to 800 meters (the global mean is 1 33
meters); the Antarctic ice pack grows from an average
minimum of 2.6 million square kilometers in March to
about 18.8 million square kilometers in September,
better than a sevenfold increase in area; the Antarctic
Circumpolar Current (21 ,000 km in length) moves
perpetually eastward; it is the world''s largest ocean
current, transporting 130 million cubic meters of
water per second - 1 00 times the flow of all the world''s
rivers
Elevation extremes;
lowest point: -7,235 m at the southern end of the
South Sandwich Trench
highest point: sea level 0 m
Natural resources: probable large and possible
giant oil and gas fields on the continental margin,
manganese nodules, possible placer deposits, sand
and gravel, fresh water as icebergs, squid, whales,
and seals - none exploited; krill, fishes
Natural hazards: huge icebergs with drafts up to
several hundred meters; smaller bergs and iceberg
fragments; sea ice (generally 0.5 to 1 meter thick) with
sometimes dynamic short-term variations and with
large annual and interannual variations; deep
continental shelf floored by glacial deposits varying
widely over short distances; high winds and large
waves much of the year; ship icing, especially
May-October; most of region is remote from sources
of search and rescue
Environment - current issues: increased solar
ultraviolet radiation resulting from the antarctic ozone
hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and
damaging the DNA of some fish; illegal, unreported,
and unregulated fishing in recent years, especially the
landing of an estimated five to six’ times more
Patagonian toothfish than the regulated fishery, which
is likely to affect the sustainability of the stock; large
amount of incidental mortality of seabirds resulting
from long-line fishing for toothfish
note: the now-protected fur seal population is making
a strong comeback after severe overexploitation in the
18th and 19th centuries
Environment - international agreements: the
Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition,
it is subject to these agreements specific to the region:
International Whaling Commission (prohibits
commercial whaling south of 40 degrees south [south
of 60 degrees south between 50 degrees and 130
degrees west]); Convention on the Conservation of
Antarctic Seals (limits sealing); Convention on the
460
Southern Ocean (continued)
Conservation of Antarctic Marine Living Resources
(regulates fishing)
note: many nations (including the US) prohibit mineral
resource exploration and exploitation south of the
fluctuating Polar Front (Antarctic Convergence) which
is in the middle of the Antarctic Circumpolar Current
and serves as the dividing line between the very cold
polar surface waters to the south and the warmer
waters to the north
Geography - note: the major chokepoint is the
Drake Passage between South America and
Antarctica; the Polar Front (Antarctic Convergence) is
the best natural definition of the northern extent of the
Southern Ocean; it is a distinct region at the middle of
the Antarctic Circumpolar Current that separates the
very cold polar surface waters to the south from the
warmer waters to the north; the Front and the Current
extend entirely around Antarctica, reaching south of
60 degrees south near New Zealand and near 48
degrees south in the far South Atlantic coinciding with
the path of the maximum westerly winds
I Government
Data code: none; the US Government has not
approved a standard for hydrographic codes - see the
Cross-Reference List of Hydrographic Data Codes
appendix
I rco n o''my''
Economy - overview: Fisheries in 1 998-1 999 (1
July to 30 June) landed 1 1 9,898 metric tons, of which
85% was krill and 14% Patagonian toothfish.
International agreements were adopted in late 1 999 to
reduce illegal, unreported, and unregulated fishing,
which in the 1998-1999 season landed five to six
times more Patagonian toothfish than the regulated
fishery. In the 1998-1999 antarctic summer 10,013
tourists, most of them seaborne, visited the Southern
Ocean and Antarctica, compared to 9,604 the
previous year. Nearly 16,000 tourists are expected
during the 1999-2000 season.
I Transportation
Ports and harbors: McMurdo, Palmer, and offshore
anchorages in Antarctica
note: tew ports or harbors exist on the so.uthern side
of the Southern Ocean; ice conditions limit use of most
of them to short periods in midsummer; even then
some cannot be entered without icebreaker escort;
most antarctic ports are operated by government
research stations and, except in an emergency, are
not open to commercial or private vessels; vessels in
any port south of 60 degrees south are subject to
inspection by Antarctic Treaty observers
Transportation - note: Drake Passage offers
alternative to transit through the Panama Canal
Location: Southwestern Europe, bordering the Bay
of Biscay, Mediterranean Sea, North Atlantic Ocean,
and Pyrenees Mountains, southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
total: 504,782 sq km
land: 499,542 sq km
water: 5,240 sq km
note: includes Balearic Islands, Canary Islands, and
five places of sovereignty (plazas de soberania) on
and off the coast of Morocco - Ceuta, Melilla, Islas
Chafarinas, Penon de AIhucemas, and Penon de
Velez de la Gomera
Area - comparative: slightly more than twice the
size of Oregon
Land boundaries:
tofa/; 1,917.8 km
border countries: Andorra 63.7 km, France 623 km,
Gibraltar 1 .2 km, Portugal 1 ,214 km, Morocco (Ceuta)
6.3 km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Maritime claims:
contiguous zone: 24 nm
461
Spain (continued)
exclusive economic zone: 200 nm (applies only to the
Atlantic Ocean)
terr/foria/ sea; 12 nm
Climate: temperate; clear, hot summers in interior,
more moderate and cloudy along coast; cloudy, cold
winters in interior, partly cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded
by rugged hills; Pyrenees in north
Elevation extremes:
/owes? po/nf; Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary
Islands 3,718 m
Natural resources: coal, lignite, iron ore, uranium,
mercury, pyrites, fluorspar, gypsum, zinc, lead,
tungsten, copper, kaolin, potash, hydropower, arable
land
Land use:
arable land: 30%
permanent crops: 9%
permanent pastures: 21 %
forests and woodland: 32%
other: 8% (1993 est.)
Irrigated land: 34,530 sq km (1993 est.)
Natural hazards: periodic droughts
Environment - current issues: pollution of the
Mediterranean Sea from raw sewage and effluents
from the offshore production of oil and gas; water
quality and quantity nationwide; air pollution;
deforestation; desertification
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping.
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Desertification
Geography ■ note: strategic location along
approaches to Strait of Gibraltar
Population: 39,996,671 (July 2000 est.)
Age structure:
0-14 years: 15% (male 3,046,379; female 2,866,712)
15-64 years: 68% (male 13,702,947; female
13,618,766)
65 years and over: 17% (male 2,830,607; female
3,931,260) (2000 est.)
Population grovrth rate: 0.11% (2000 est.)
Birth rate: 9.22 births/1 ,000 population (2000 est.)
Death rate: 9.03 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.88 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 4.99 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.79 years
male: 75.32 years
female: 82.49 years (2000 est.)
Total fertility rate: 1 .15 children born/woman
(2000 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 99%, other 1%
Languages: Castilian Spanish (official) 74%,
Catalan 17%, Galician 7%, Basque 2%
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: NA%
female: NA%','5a1bfda64dabb0b789912b284599948bf040b0d89d4ccb3cd4fb7dd6e22097a3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a88f8c3122789884b31b98b227599516bc85a21f9a254f900c923f780acb30ca',2000,'SR','Suriname','geography',442,'Location: Northern South America, bordering the
North Atlantic Ocean, between French Guiana and','c0a0885b01b1a745b37f8ab18e10fdb72d8d2d07eb19f2951d3d194c03e6aa71','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01aee3f7d8d9257a8e8511b2722aaead068a41f431841b96837b8fb5a53656ae',2000,'GY','Guyana','geography',443,'Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
fofa/;1 63,270 sq km
/and; 161 ,470 sq km
water: 1 ,800 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
total: 1 ,707 km
border countries: Brazil 597 km, French Guiana 510
km, Guyana 600 km
Coastline: 386 km
Maritime ciaims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with
swamps
Elevation extremes:
lowest point: unnamed location in the coastal plain -2
m
/j/g/resfpo/nf; Wilhelmina Gebergte 1 ,286 m
Natural resources: timber, hydropower, fish, kaolin,
shrimp, bauxite, gold, and small amounts of nickel,
copper, platinum, iron ore
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 96%
other: A% (1993est.)
Irrigated land: 600sqkm(1993est.)
Natural hazards: NA
Environment - current issues: deforestation as
timber is cut for export; pollution of inland waterways
by small-scale mining activities
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered
Species, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: mostly tropical rain forest; great
diversity of flora and fauna that, for the most part, is
increasingly threatened by new development;
relatively small population, most of which lives along
the coast','d1b2563bf7386dc9358dd0671f9f933d7c699cf6fa322ce87ebfa11e5a8fd925','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('516d1b995d902cac15720ba49b2e72d6c1e696a71a0dfd85bbf7e9cbb28aa111',2000,'IT','Italy','geography',447,'Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area:
total: 41 ,290 sq km
land: 39,770 sq km
water: 1 ,520 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1 ,852 km
border countries: Austria 164 km, France 573 km,
Italy 740 km, Liechtenstein 41 km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, but varies with altitude; cold,
cloudy, rainy/snowy winters; cool to warm, cloudy,
humid summers with occasional showers
Terrain: mostly mountains (Alps in south. Jura in
northwest) with a central plateau of rolling hills, plains,
and large lakes
Elevation extremes:
lowest point: Lake Maggiore 195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber,
salt
Land use:
arable land: 10%
permanent crops: 2%
permanent pastures: 28%
forests and woodland: 32%
other; 28% (1993 est.)
Irrigated land: 250 sq km (1993 est.)
Natural hazards: avalanches, landslides, flash
floods
Environment • current issues: air pollution from
vehicle emissions and open-air burning; acid rain;
water pollution from increased use of agricultural
fertilizers; loss of biodiversity
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol, Law of the Sea
Geography - note: landlocked; crossroads of
northern and southern Europe; along with
southeastern France and northern Italy, contains the
highest elevations in Europe','d7f479ff3bcdc048a67bc2682f2f15584576a9182b0ad290cacc3929a894cd47','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e69f839e848634575655c2305a2f6008d2b4c93e9aa4be946e78733d4e0073e8',2000,'TO','Tonga','geography',464,'Location: Oceania, archipelago in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','dba2c3f5cc9763816183b4cbb380a2ba67479dfface76994e5a899d532e5e760','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89d93e933979cd810c213600d25ad20302dd91c4aa68626567819831411ea0a7',2000,'MP','Northern Mariana Islands','geography',487,'Location: Oceania, islands in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','e0b14fbea7a6600686b865ca0f5eac39b8c110a5a9fda69667701ce167afead3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

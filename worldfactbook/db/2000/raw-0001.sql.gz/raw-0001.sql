SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc1cfac225a280a6ca9b21b7fbb92184573aa65d2c45a81e3a47ea0597b8ff88',2000,'','','raw',1,'i
The Central Intelligence Agency (CIA) publishes The World
Factbook in printed, CD, and Internet versions. US Government
officials may obtain information about availability of the Factbook
from their own organizations or through liaison channels to the
CIA. Other users may obtain sales information about printed
copies and CDs from the following:
Superintendent of Documents
P. 0. Box 371954
Pittsburgh, PA 15250-7954
Telephone: [1](202) 512-1800
FAX: [1] (202) 512-2250
http://www.access.gpo.gov/su_docs/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The Internet version may be accessed through the following
World-Wide Web uniform resource locator (URL):
http://www.cia.gov
Printed by Printing & Photography Group
Central
Intelligence
Agency
The
World
Factbook
2000
In general, information available as of 1 January
2000 was used in the preparation of this edition.
The World Factbook is prepared by the Central
Intelligence Agency for the use of US Government
officials, and the style, format, coverage, and
content are designed to meet their specific
requirements. Information is provided by Antarctic
Information Program (National Science
Foundation), Bureau of the Census (Department of
Commerce), Bureau of Labor Statistics (Department
of Labor), Central Intelligence Agency, Council of
Managers of National Antarctic Programs, Defense
Intelligence Agency (Department of Defense),
Department of State, Fish and Wildlife Sen/ice
(Department of the Interior), Maritime Administration
(Department of Transportation), National Imagery
and Mapping Agency (Department of Defense),
Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs
(Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on
Geographic Names (Department of the Interior), and
other public and private sources.
The Factbookis in the public domain. Accordingly, it
may be copied freely without permission of the
Central Intelligence Agency (CIA). The official seal
of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50
U.S.C. section 403m). Misuse of the official seal of
the CIA could result in civil and criminal penalties.
Comments and queries are welcome and may be
addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Telephone: [1](703) 482-0623
FAX: [1] (703) 482-1739
DISTRIBUTION STATEMENT A
Approved for Public Release
Distribution Unlimited
20001227 010
A Brief History of Basic Intelligence and
The World Factbook
The Intelligence Cycle is the process by which information
is acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data
that may be fragmentary, contradictory, unreliable,
ambiguous, deceptive, or wrong. Intelligence is information
that has been collected, integrated, evaluated, analyzed, and
interpreted. Finished intelligence is the final product of the
Intelligence Cycle ready to be delivered to the policymaker.
The three types of finished inteiiigence are: basic, current,
and estimative. Basic inteiiigence provides the fundamental
and factuai reference materiai on a country or issue. Current
intelligence reports on ne\\w developments. Estimative
intelligence judges probable outcomes. The three are
mutually supportive: basic intelligence is the foundation on
which the other two are constructed; current intelligence
continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of
country and issue prospects for guidance of basic and current
intelligence. The World Factbook, The President''s Daily Brief,
and the National Intelligence Estimates are examples of the
three types of finished intelligence.
The United States has carried on foreign intelligence
activities since the days of George Washington but only since
World War II have they been coordinated on a
governmentwide basis. Three programs have highlighted the
development of coordinated basic intelligence since that time:
(1) the Joint Army Navy Intelligence Studies (JANIS), (2) the
National Intelligence Survey (NIS), and (3) The World
Factbook.
During World War II, intelligence consumers realized that
the production of basic intelligence by different components of
the US Government resulted in a great duplication of effort
and conflicting information. The Japanese attack on Pearl
Harbor in 1 941 brought home to leaders in Congress and the
executive branch the need for integrating departmental
reports to national policymakers. Detailed and coordinated
information was needed not only on such major powers as
Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and
Marines had to launch amphibious operations against many
islands about which information was unconfirmed or
nonexistent. Intelligence authorities resolved that the United
States should never again be caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train
(Office of Naval Intelligence - ONI), and Gen. William J.
Donovan (Director of the Office of Strategic Services - OSS)
decided that a joint effort should be initiated. A steering
committee was appointed on 27 April 1943 that
recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JAH\\S). JANIS was
the first interdepartmental basic intelligence program to fulfill
the needs of the US Government for an authoritative and
coordinated appraisal of strategic basic intelligence. Between
April 1943 and July 1947, the board published 34 JANIS
studies. JANIS performed well in the war effort, and
numerous letters of commendation were received, including a
statement from Adm. Forrest Sherman, Chief of Staff, Pacific
Ocean Areas, which said, "JANIS has become the
indispensable reference work for the shore-based planners."
The need for more comprehensive basic intelligence in
the postwar world was well expressed in 1946 by George S.
Pettee, a noted author on national security. He wrote in The
Future of American Secret Intelligence (Infantry Journal
Press, 1946, page 46) that world leadership in peace requires
even more elaborate intelligence than in war. "The conduct of
peace involves all countries, all human activities - not just the
enemy and his war production."
The Central Intelligence Agency was established on 26
July 1947 and officially began operating on 18 September
1947. Effective 1 October 1947, the Director of Central
Intelligence assumed operational responsibility for JANIS. On
13 January 1948, the National Security Council issued
Intelligence Directive (NSCID) No. 3, which authorized the
National Intelligence Survey (NIS) program as a peacetime
replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced,
government agencies had to develop more comprehensive
gazetteers and better maps. The US Board on Geographic
Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the
maps.
The Hoover Commission''s Clark Committee, set up in
1954 to study the structure and administration of the CIA,
reported to Congress in 1955 that: "The National Intelligence
Survey is an invaluable publication which provides the
essential elements of basic intelligence on all areas of the
world. . . . There will always be a continuing requirement for
keeping the Survey up-to-date." The Factbookwas created as
an annual summary and update to the encyclopedic NIS
studies. The first classified Factbookwas published in August
1962, and the first unclassified version was published in June
1 971 . The N IS program was terminated in 1 973 except for the
Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with
sales through the US Government Printing Office (GPO). The
1996 edition was printed by GPO and 1 997 edition was
reprinted by G PO. The year 2000 marks the 53rd anniversary
of the establishment of the Central Intelligence Agency and
the 57th year of continuous basic intelligence support to the
US Government by The World Factbook and its two
predecessor programs.
Contents
Page
Page
Page
Notes and Definitions
vii','0fffa60a4b4984c127060e18d3d6752e29e696180b0e920c24dc93724a8838c6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70387265079ee09707efe4ca8ffe264e1d2f9903188bc37c36ebfde119a2a397',2000,'BT','Bhutan','raw',2,'57
Europa Island
162
Johnston Atoll
256
Bolivia
59
F
Falkland Islands (Islas Malvinas)
162','dcf3810addd1019299440974108c1ed70eca4146bdbc3ae000b08adbdd2b3aa6','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3070f9af0f877c1d7dd910f9029dd77e408e0f49030bb825dfdca37006e57b7',2000,'PF','French Polynesia','raw',3,'176
Korea, North
267
Brunei
73
French Southern and Antarctic Lands
178
Korea, South
270','9e4494d1dfe1503e17cfbb34c1dd09180ff29e1824acee2595ed85b0c1c6b443','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('672c23bfb3677e051ac7409ea16737eca6672f6dab3b19f388b4af036896b9fb',2000,'US','United States','raw',4,'521
Notes and Definitions
In addition to the updating of information, the following changes have been made
in this edition of The World Factbook. There is a new ‘country profile’ on the
Southern Ocean. The name Wake Atoll has been officially changed back to Wake
Island. There are new entries on Internet Service Providers (ISPs),
Telephones - main lines in use, and Teiephones - mobiie ceiluiar. The
Background entry, which was introduced in the 1999 edition, has now been
completed for over 200 countries. The terms and abbreviations used in the
Environment - current issues entry are now explained in the Notes and
Definitions section of the prefatory material.
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years, 65
years and over). The age structure of a population affects a nation’s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
Agriculture ■ products: This entry is a rank ordering of major crops and products
starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports - with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces). For airports with more than one
runway, only the longest runway is included according to the following five groups -
(1 ) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437 m, (4) 91 4 to 1 .523 m,
and (5) under 91 4 m. Only airports with usable runways are included in this listing.
Not all airports have facilities for refueling, maintenance, or air traffic control.
Airports - with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces). For airports with
more than one runway, only the longest runway is included according to the
following five groups - (1 ) over 3,047 m, (2) 2,438 to 3,047 m, (3) 1 ,524 to 2,437
m, (4) 914 to 1 ,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control.
Appendixes: This section includes Facfbook-related material by topic.
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
VII
Notes and Definitions (continued)
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
Area - comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and current
issues and may include a statement about one or two key future trends.
Birth rate: This entry gives the average annual number of births during a year per
1 ,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the level of fertility and the age structure of the
population.
Budget: This entry includes revenues, total expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
Capital: This entry gives the location of the seat of government.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the telephone, radio, television, and Internet service provider entries.
Communications - note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country map: Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
Country name: This entry includes all forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italiana), local short form (Italia), former (Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
Currency: This entry identities the national medium of exchange and its basic
subunit.
Data code: This entry gives the official US Government digraph that precisely
identifies every land entity without overlap, duplication, or omission. AF, for
example, is the data code for Afghanistan. This two-letter country code is a
standardized geopolitical data element promulgated in the Federal Information
Processing Standards Publication (FIPS) 10-4 by the National Institute of
viii
Notes and Definitions (continued)
Standards and Technology at the US Department of Commerce and maintained
by the Office of the Geographer and Global Issues at the US Department of State.
The data code is used to eliminate confusion and incompatibility in the collection,
processing, and dissemination of area-specific data and is particularly useful for
interchanging data between databases. Appendix F cross-references various
country data codes and Appendix G cross-references various hydrographic data
codes.
Data codes - country: This information is presented in Appendix F:
Cross-Reference List of Country Data Codes which includes the US
Government approved Federal Information Processing Standards (FIPS) codes,
the International Organization for Standardization (ISO) codes, and Internet codes
for land entities.
Data codes - hydrographic: This information is presented in Appendix G:
Cross-Reference List of Hydrographic Data Codes which includes the
International Hydrographic Organization (IHO) codes. Aeronautical Chart and
Information Center (ACIC; now a part of the National Imagery and Mapping
Agency or NIMA) codes, and Defense Intelligence Agency (DIA) codes for
hydrographic entities. The US Government has not yet approved a standard for
hydrographic data codes similar to the FIPS 1 0-4 standard for country data codes.
Date of information: in general, information available as of 1 January 2000, was
used in the preparation of this edition.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show
a rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt - external: This entry gives the total amount of public foreign financial
obligations.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
184 independent states, including 181 of the 188 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, former Yugoslavia, and the
US itself). In addition, the US has diplomatic relations with 3 independent states
that are not in the UN - Holy See, Switzerland, and Tuvalu.
Diplomatic representation from the US: This entry includes the chief of mission,
embassy a66ress, mailing address, telephone number, FAYnumber, branchoffice
locations, consulate genera/ locations, and consulate locations.
Diplomatic representation in the US: This entry includes the chief of the foreign
mission, chancery address, telephone number, FAY number, consulate general
locations, consulate locations, honorary consulate general locations, and
honorary consulate locations.
IX
Notes and Definitions (continued)
Disputes - international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Economic aid - donor: This entry refers to net official development assistance
(ODA) from OECD nations to developing countries and multilateral organizations.
ODA is defined as financial assistance that is concessional in character, has the
main objective to promote economic development and welfare of the less
developed countries (LDCs), and contains a grant element of at least 25%. The
entry does not cover other official flows (OOF) or private flows.
Economic aid - recipient: This entry, which is subject to major problems of
definition and statistical coverage, refers to the net inflow of Official Development
Finance (ODF) to recipient countries. The figure includes assistance from the
World Bank, the IMF, and other international organizations and from individual
nation donors. Formal commitments of aid are included in the data. Omitted from
the data are grants by private organizations. Aid comes in various forms including
outright grants and loans. The entry thus is the difference between new inflows
and repayments.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e„ land, labor, and capital.
Economy - overview: This entry briefly describes the type of economy. Including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Electricity - consumption: This entry consists of total electricity generated
annually plus imports and minus exports, expressed in kilowatt hours. The
discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss In transmission and
distribution.
Electricity - exports: This entry is the total exported electricity in kilowatt hours.
Electricity - imports: This entry is the total Imported electricity in kilowatt hours.
Electricity - production: This entry is the annual electricity generated expressed
in kilowatt hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted for as
loss in transmission and distribution.
Electricity - production by source: This entry indicates the percentage share of
annual electricity production of each energy source. These are fossil fuel, hydro,
nuclear, and other (solar, geothermal, and wind).
Elevation extremes: This entry includes both the highest point and the towest
point.
X
Notes and Definitions (continued)
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state” refers to a people politically organized into a sovereign state with a definite
territory. “Dependencies" and "areas of speciai sovereignty" refer to a broad
category of poiitical entities that are associated in some way with an independent
state. "Country" names used in the table of contents or for page headings are
usualiy the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a totai of 267 separate
geographic entities in The Worid Factbook\\ha\\ may be categorized as foliows:
INDEPENDENT STATES
191 Afghanistan, Albania, Algeria, Andorra, Angoia, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Beiize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazii.Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugosiav Repubiic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelies,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezueia, Vietnam, Yemen,
Zambia, Zimbabwe
OTHER
1 Taiwan
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald Islands,','b98fb60f267f1ce1f2eea58175606393a4eaec2d5c0ac61452c2787b10cbe5b1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ac837cb310f66b9822eb567db1f0ca729424e8af9c082ff759e3f96601a9a8a',2000,'VU','Vanuatu','raw',5,'529
Venezueia
531
Vietnam
533
Virgin Isiands
536
W
Wake isiand
537
Waiiis and Futuna
538
West Bank
540','404b7a6eef4c5727abd133156daa837123312f86bb2b2d052f05727e0ae3e2cd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eaf4df6269e0f38d5f46158715aad079798c60835db4a0c97394e6a714b907e',2000,'EH','Western Sahara','raw',6,'542
Worid
544
Y
OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
267 Total
Environment - current issues: This entry lists the most pressing and important
environmental problems. The following terms and abbreviations are used
throughout the entry:
acidification - the lowering of soil and water pH due to acid precipitation and
deposition; this process disrupts ecosystem nutrient flows and may kill freshwater
fish and plants dependent on more neutral or alkaline conditions (see acid rain).
acid rain - characterized as containing harmful levels of sulfur dioxide; acid rain
is damaging and potentially deadly to the earth''s fragile ecosystems; acidity is
measured using the pH scale where 7 is neutral, values greater that 7 are
considered alkaline, and anything measured below 5.6 is considered acid
precipitation; note - a pH of 2.4 (the acidity of vinegar) has been measured in
rainfall in New England.
asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic.
biodiversity - also biological diversity; many species, diverse in form and
function, at the genetic, organism, community, and ecosystem level; loss of
biodiversity reduces an ecosystem’s ability to recover from natural or man-induced
disruption.
catchments - assemblages used to capture and retain rainwater and runoff; an
important water management technique in areas with limited freshwater
resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless insecticide
that has toxic effects on most animals; the use of DDT was banned in the US in
1972,
defoliants - chemicals which cause plants to lose their leaves artificially; often
used in agricultural practices for weed control, and may have detrimental impacts
on human and ecosystem health,
deforestation - the destruction of vast areas of forest (e.g., unsustainable
forestry practices, agricultural and range land clearing, and the over exploitation of
wood products for use as fuel) without planting new growth.
desertification - the spread of desert-like conditions in arid or semi-arid areas,
due to overgrazing, loss of agriculturally productive soils, or climate change.
dredging - in general, the practice of deepening an existing waterway; more
specifically, a technique used for collecting bottom-dwelling marine organisms
(e.g., shellfish) or harvesting coral, often causing significant destruction of reef and
ocean-floor ecosystems.
xii
Notes and Definitions (continued)
drift-net fishing - done with a net, miies in extent, that is generaiiy anchored to
a boat and left to float with the tide; often results in an over harvesting and waste
of large populations of non-commercial marine species (by-catch) by its effect of
“sweeping the ocean clean”.
ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
effluents - waste materials, such as smoke or sewage, which are released into
the environment, subsequently polluting it.
endangered species - a species that is threatened with extinction either by
direct hunting or habitat destruction.
freshwater - water with very low soluble mineral content; sources include
lakes, streams, rivers, glaciers, and underground aquifers.
groundwater - water sources found below the surface of the earth often in
naturally occurring reservoirs in permeable rock strata; the source for wells and
natural springs.
Highlands Water Project - a series of dams constructed jointly by Lesotho and
South Africa to redirect Lesotho''s abundant water supply into a rapidly growing
area in South Africa; while it is the largest infrastructure project in southern Africa,
it is also the most costly and controversial; objections to the project include claims
that it forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 125,000 Inuits of Russia,
Alaska, Canada, and Greenland in international environmental issues; a panel
convenes every three years to determine the focus of the ICC; the most current
concerns are long-range transport of pollutants, sustainable development, and
climate change.
metallurgical plants - industries which specialize in the science, technology,
and processing of metals; these plants produce highly concentrated and toxic
wastes which can contribute to pollution of ground water and air when not properly
disposed.
noxious substances - injurious, very harmful to living beings,
overgrazing - the grazing of animals on plant material faster than it can
naturally regrow leading to the permanent loss of plant cover, a common effect of
too many animals grazing limited range land.
ozone shield - a layer of the atmosphere composed of ozone gas (O3) that
resides approximately 25 miles above the Earth''s surface and absorbs solar
ultra-violet radiation that can be harmful to living organisms.
poaching - the illegal killing of animals or fish, a great concern with respect to
endangered or threatened species.
pollution - the contamination of a healthy environment by man-made waste,
potable water - water that is drinkable, safe to be consumed,
salination - the process through which fresh (drinkable) water becomes salt
(undrinkable) water; hence, desalination is the reverse process.
siltation - occurs when water channels and reservoirs become clotted with silt
and mud, a side effect of deforestation and soil erosion.
slash-and-burn agriculture - a rotating cultivation technique in which trees are
cut down and burned in order to clear land for temporary agriculture; the land is
used until its productivity declines at which point a new plot is selected and the
process repeats; this practice is sustainable while population levels are low and
time is permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences for the','f21622a52c781f35a64ad7000dcba2cc63039c6e932b72af28651a4d1f2dced3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38e570cf19e5d07f690f9353924cb6535a63fd1d9dba8dbc3af8d5d722a1e144',2000,'ZW','Zimbabwe','raw',7,'550
Taiwan
552
IV
Page
Appendixes A: Abbreviations 555
B: United Nations System 564
C: International Organizations and Groups 565
D: Selected International Environmental Agreements 617
E: Weights and Measures 625
F: Cross-Reference List of Country Data Codes 638
G: Cross-Reference List of Hydrographic Data Codes 646
H: Cross-Reference List of Geographic Names 651
Reference Maps Africa
Antarctic Region
Arctic Region
Asia
Central Africa
Central America and the Caribbean
Central Balkan Region
Commonwealth of Independent States
Europe
Kosovo
Middle East
North America
Oceania
Physical Map of the World
Political Map of the World
South America
Southeast Asia
Standard Time Zones of the World','4c6a597023d0969b5d9c312d1fbf96583440649d00ddd15c50830aa14e00a4f2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5baf46d64c0e801a58ca85430e2aaadd4754889aad8f46324da104c020d82f27',2000,'NF','Norfolk Island','raw',8,'2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
16 France - Bassas da India, Clipperton Island, Europa Island, French
Guiana, French Polynesia, French Southern and Antarctic Lands, Glorioso
Islands, Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis
and Futuna
xi
Notes and Definitions (continued)
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
15 UK - Anguilla, Bermuda, British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Jersey,
Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South Georgia and
the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island, Guam, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island, Northern
Mariana Islands, Palmyra Atoll, Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','1eede8f58551ce5de8b1a91f87a0c0a6f2901e8bc22089de8269a773f85bce70','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5dcb9d0c36f7815bf4378bbf2390b4f2de4b48b6945e92ab516441d4462eb1e',2000,'','','raw',1,'Physical Map of the World, April 2000
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Capital
FRANZ JOSEF
LAND _ j
SEVERNAYA
_ ZEMLYA
Scale 1:35,000,000
Robinson Projection
standard parallels 38°N and 38°S
QUEEN ELIZABETH
ISLANDS
.ongyearl
NEW SIBERIAN ISLANDS
Kara. Sea
Svalbard
(NORWAY)
NOVAYA
ZEMLYA
Banks
Island','a39e4e5280682267acac035b6141a64edcb4b47b61d3f7d94bfbd92c3c6404b8','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b626aec698f618e215984bfc1f9f10ab8fce9163857c8628a6a7e00acb1940b7',2000,'DK','Denmark','raw',2,'Copenhagen''
Novosibirsk
Edmonton
Dublin \\
IRELAND kji^qdoi
ALEUTIAN ISLANDS
(U.S.)
Samara
BELARU:
Tetropavlovsk-Kamchatskiy
Astana
Sakhalin
Island of
Newfoundland','d277468e6b3d02be3b7f8322d7c300877175b19556c7d4e5169640bb93dd5984','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0ea1c0ab4b642d401bc266bf903517f77c94a26e4ffc59f8ed9aa30fb72de23',2000,'FR','France','raw',3,'lO MANIA
Buchare
Montreal
St. Pierre
and Miquelon
(FRANCE)
Minneapoli:
occupied by the SOVIET UNION in 1945,
administered by RUSSIA, claimed by JAPAN
■0T Marino','926b74e605179c344a5f9f8dd140ee9199f8fead1956c08d3adf87f261a23dc5','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('919d1c7d4979f34f9bc5953dfd01e406c6a853c45bfb6f7b50d6832a70df7b5e',2000,'ES','Spain','raw',4,'PORTUG?
3RTH KOREA
P''yongyang
N SOUTH
KOR,EA
PuSan
Ankara
TURKEY
Tashkent
TAKLA MAKAN
Yerev
TURKMENISTAI
Wm
uWTrVPrJj
lath Valley
BALEARIC
ISLANDS
(SP.)
G''REgCE
ilKISTAN
AZORES
(PORT.)
MFQibraltardJ.K.
• Aleppo
SYRIA
Nicosi.
Kabul^
''AFGHANISTAN
''UN I SI A
Yokohama
,s IRAQ
★
Baghdad
Chinese line
Beirut','f7d3124daa602277aea8b6bd99f09293ec02c23a8f6ca1f0ee66c2069a753af9','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe552a2be951312ca352df3364b0b709e360dba97bd783a3b6ec774c4121936c',2000,'BM','Bermuda','raw',5,'(U.K.)
Mt. Everest
(highest point in Asia
and the world, 8848 m)
ISRAEL,
lerusalei
MORO''
CANARY ISLANDS
Chongqing''
fe-CNEP,','a69cb78222a071b108f3d1febbb2a8c42acdc27388a2995310c003c461f7dbc2','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd9c9fe8eba8c2aa9a595f1433373db7b8adfdf32faaf2a2df45f012f383fef7',2000,'BH','Bahrain','raw',6,'* OMAN i''ll
Manama Doha L
! * Abt! Qhabi
QATAR UNITED ARAB .
ARABIA EM,RATES
. OMAN
Miami
Western
Sahara
Marcus Island
(JAPAN)
BANGLAtSsii/
★ r\\
Calcutta. Dhaka
Muscat
Ahmadabad
Jiddah
Honolulu
BURMA','61bb37917d6f493448bf1d56edbd0fc229e31f9cebe72da17d22e0f09dc0c0fd','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae21461be282d0529f545a40f9ab0058e43d68749db886f5b8dfa4abdf504e4e',2000,'MR','Mauritania','raw',7,'4 Hainan
- Dao
Mumbai 1
(Bombay)
Northern
Mariana
Islands
,u.s.)
Saipan
Hagatfia
(Agana)*','4708b080edbf782e69f27495f86d8469ce72e68fbdf739e32929692ec73c9100','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8adf91c0d1df1959ba7090484662e0a6d6ab81ec564fb5a430a2db0083f0f162',2000,'GU','Guam','raw',8,'(U.S.)
Nouakchott
1 ’.!
Rangoon
IAMAICA
f y tfcJET vTI BELIZE
JBflfcV j/fBcImopan
GMft fllBifaa - HONDURAS
uatemala*
an Salvador 8 *','fc0ac92778bcc6d6d1c665980bab6f5ee974a0f0dd515fdbbb310ea9a76c70d1','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c364654d783502afd4803acfd4019349f9fcf0b9764dad83b421d4f68a897cc7',2000,'SV','El Salvador','raw',9,'Manag
\\RBUDA
Domi
PARACEL
ISLANDS
Tombouctou
Johnston Atoll
(U.S.)
THAILAN
CAPE VERDE
★
Praia','8e0db632622aceda93a8a7366a7785e940a8d025624a090961d92bf59815d1d4','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('085e2bb58f66c3522bad0b9d3c0915221dfbcc9bfdc16dcafda9286fb2e7693d',2000,'TD','Chad','raw',10,'IETNAM
mm
BURKIN
* SENEGAL
Banjul Dt 1 -
THE GAMBIA
B i s s a
GUINEA-BISSAU GUINEA
LunaktyiS^TV^ jH£
Freetown *
SIERRA
LEONE
Monrovia*','6c18f30f44926e4e00fe31eeb381841e7bda6072ced55998ae75d67aa698c35e','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46819abe12e73b810ef3c8081b5ad2f0a18cdc255c80b36a6a1c7ca9c136e8d2',2000,'NI','Nicaragua','raw',11,';ambodia
Socotra
(YEMEN)
MARSHALL
ISLANDS
WmmQm
.,»’ ''(C
COTE
D''IVOIRE qh,
Yamoussoukro
BENIN NIGERIA
TOGO * Abu l a
LAKSHADWEEP
(INDIA)
FEDERATED STATES OF MICRONESIA
Clipperton Island
(FRANCE)
COSTA R1C
Koror','d3448c5dde949b4f013ad8667557dd5ec276f3d1dcb0fe83c7005b7b4b855f71','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f72c40112066fedebd7e33dfd7a8542497b9ce402cc5bec93636d3b0fccf4048',2000,'ET','Ethiopia','raw',12,'Colombo
CENTRAL
AFRICAN REPUBLIC
NICOBAR
ISLANDS
(INDIA)
Kingman Reef (U.S.)
Palmyra Atoll (U.S.)
Bandar Seri
Begawan
BRUNEI I
SRI
LANKA
rANA ★
SURINAM!
Porto
Novo','6c16dd4dfcbfb62f68894e2a3c16f75d3d86d36a06c88a15d1f3632722442e11','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b464a15cb3aabf94674b85d380ee07f3fd1fcd4b8473854bb5b6ae07ff2cd44c',2000,'GQ','Equatorial Guinea','raw',13,'MBIA
Penedos de
Pedro e Sdo Paulo
(BRAZIL)
Kiritimati
(Christmas Island)
Tarawa
Mogadishu
Howland Island (U.s.)
^Singapore
SINGAPOR1
SAO TOME
Baker Isl
(KIRIBATI)
Sao Tome ★
DEMOCRATIC 4 LJKW jj (
REFUBLlC RWAriDA * KiSal1
* Bujumbura
OF THE CONGO Burundi
Nairobi x
— Mt. Kilimanjaro
^(highest point in Africa, 5895 m)
Jarvis
Island
(U.s.)
Yaren NAURU
District','e377cb8e2e553db88a1c9b639c540060ffab1e5cd50143abede65c1e59718328','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('518d0d81443a95f80d77a603ed5db1ff8c80f49012aca412e13d191a25340f8d',2000,'GA','Gabon','raw',14,'ECUADi
Annobon
(EQUA. GUI.
Arquipelago de
Fernando de Noronha
(BRAZIL)
.Victoria
British Indian
Ocean Territory
(U.K.)
PAPUA
NEW GUINEA
SOLOMON
ISLANDS
TANZANIA','6f9ab4ce17c8a73296420a1880b206d4b7f25e74d5ade49529a3bd92625c3116','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eb277a7e46a72aa78b9d41e71f29874925b43b142989f2cd4ff34e6cc46aa91',2000,'YT','Mayotte','raw',15,'listered by FRANCE,
ned by COMOROS)
. SAMOA
a * A P ia I
Mata-Utu * * /
E) Pago Pago /
American /
Samoa /
Piiue (U - S '' ) /
(n.zl) rf /
Ashmore and
Cartier Islands
Hi (AUSTL.)
J I xS ‘ Salvador
Lilongwi','e5544bca759d940cf1007785decd1a8d3cb5cd54847ca2291d4dcf16e3b3b826','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('404abba9c475aa7c7e5e46b7544221a5a5a73f4a97d501e8464412d3bc4d11e9',2000,'CK','Cook Islands','raw',16,'(N.Z.)
St. Helena
(St. Helena)
Tromelin Island
(FRANCE)
ARCHIPEL DES TUAMOTU
(Fr. Poly.)
La Paz
BOLIVIA','e8b4b3bb1353c127f1352f5a94aff0f1a28007b8d3e9c680e34b6aa62712b253','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1776b52119fffd15fe8ea9c5902d8eb7c0780fc1c62549eeb581b472f5c0f86a',2000,'ZW','Zimbabwe','raw',17,'Martin Vaz
(BRAZIL)
% NAMIBIA
Windhoek
New \\fL
Caledonia
(FRANCE)
Noumea''
Bassas
da India
(FRANCE)
Nuku''alofa','6579f329acf8eb5da23f225be6bc2998ec5bc37bfbe6268330a3f8b37c40bd1a','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed4f82387fc729884551e0a9cc2e13123a96a5e5d92112a31954e4449b79db86',2000,'PY','Paraguay','raw',18,'Europa Island
(FRANCE)
Alice Springs
ILES TUBUAI
(Fr. Poly.)
Pitcairn Islands
(U.K.)
Adamstown
Isla San Felix
(CHILE) /s i a $ an
(CHILE
Isla Sala y Gomez
(CHILE)
St. Helena
Lake Eyre
(lowest point in
Australia, -15 m)
Easter Island
(CHILE)
Norfolk
Island
(AUSTL.)
Brisbane
KERMADEC
ISLANDS
(N.Z.)* J
lZILAND','c13b7c7a77d0c26f116c4c6d0e7ad16f1c833aea234f9e81d791d52432d3c6b2','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14c876a487ebf9fe156fab37cfe1561ed6949a6b83226a8fb76d1f248ff5eed8',2000,'LS','Lesotho','raw',19,'SOUTH
GREAT VICTORIA
DESERT
AFRICA
CHILE e
URUGUA
Canberra Z Sydney
ARCHIPIELAGO
JUAN FERNANDEZ
(CHILE)
Montevideo
Mount Kosciuszko
(highest point in
Australia, 2229m) +
Melbourne,
ARGENTIN
lie Amsterdam
(Fr. S. and Ant. Lands)
RISTAN DA CUNHA (St. Helena)
NEW
ZEALAND
Well!
tie Saint-Paul
(Fr. S. and Ant. Lands)
Gough Island
(St. Helena)
Tasmania
Southern and Antarctic Lands
(FRANCE)
Frenci
Peninsula Valdes
west point in South America,
-40 m)
:hatham islands
(N.Z.)
ILES CROZET
(Fr. S. and Ant. Lands)
PRINCE EDWARD
ISLANDS
(SOUTH AFRICA)
BOUNTY ISLANDS
(N.Z.)
IPODES ISLANDS
(N.Z.) /
Falkland Islands
(Islas Malvinas)
(administered by U.K.,
claimed by ARGENTINA)
SNARES ISLANDS
(N.Z.)
AUCKLAND
ISLANDS if
(N.Z.)
ILES KERGUELEN
(Fr. S. and Ant. Lands)
Heard Island and
^ McDonald Islands
(AUSTL.)
Campbell
Island
(N.Z.)','5eb53060b4a287e005f149a777122bfd8ad6c272ee6d67506290989ebee9f240','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08d1b93744ead6d4bc7238066ddeadd384cd8e3ca6af3092285e4c91ed97247b',2000,'BV','Bouvet Island','raw',20,'(NORWAY)
Macquarie
Island
(AUSTL.)
South Georgia and the
South Sandwich Islands
(administered by U.K.,
claimed by ARGENTINA)
SOUTH ORKNEY
ISLANDS
April 2000
Amery let
Bellingshausen Sea
''Serbia and Montenegro have asserted the formation
of a joint independent state, but this entity has
not been formally recognized as a state by the
United States.
Amundsen Sea
Ronne li
Nineteen of 26 Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the United States have
reserved the right to do so) and they do not
recognize the claims of the other nations.
Vinson Massif
(highest point in Antarctica, 5140 m)
Labrador
Tropic of Cancer (23°27'')
Tropic of Cancer (23°27'')
Milwaukee Deep
leepest point of the
Tropic of Capricorn \\ (23°27'')
Tropic of Capricorn (23°27''
Great Australian
/
Antarcticj3ircle (66°33'')
Antarctic Circle (66°33'')
802701 Al (R00349) 4-00','291e1f8dcc1797ad06a6f79fa9b3e2bd0dbc99f32cfe8c69ab1901adb8b43e68','internet-archive','factbook2000','txt','1f85156002d17655d2d3c35982196416838c4bd832f23a199ca25017fd2e51af','https://archive.org/download/factbook2000/factbook/reference/Low%20res%20PDF/low802701_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('223a8c43bea91f17d1678bdfc09fafb2165f87c7b1631d16d616d4073434603c',2000,'','','raw',1,'The Project Gutenberg EBook of The 2000 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2000 CIA World Factbook
Author: United States. Central Intelligence Agency.
Posting Date: December 27, 2008 [EBook #3672]
Release Date: January, 2003
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2000 CIA WORLD FACTBOOK ***
Produced by Martin M. Pedersen
This etext was prepared by Martin M. Pedersen, as taken from
the CIA''s online version of the book published at the address:
http://www.odci.gov/cia/publications/factbook/guide.html Note
the original book includes maps and other graphics. These are
not included in the Project Gutenberg edition. The tables may
not correctly align due to limitations of HTML conversion, but
are otherwise intact. It is past experience that the CIA does
not maintain past versions of The Factbook online. Hopefully,
the Project Gutenberg edition will be useful to you for a long
time in the future.
The CIA World Factbook 2000
TABLE OF CONTENTS
Countries are listed in alphabetical order.
Notes and appendixes follow the country listings.','3342c4129f9280276e9463b667502abe503c767656efdd9da919c6246a75a9cd','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82bc97d6527e0d82ca02424d906ef5e7148f398b3d48e7d8388c47822a634b57',2000,'ZW','Zimbabwe','raw',2,'Notes and Definitions
Appendixes
Appendix A: Abbreviations
Appendix B: United Nations System
Appendix C: International Organizations and Groups
Appendix D: Selected International Environmental Agreements
Appendix E: Weights and Measures
Appendix F: Cross-Reference List of Country Data Codes
Appendix G: Cross-Reference List of Hydrographic Codes
Appendix H: Cross-Reference List of Geographic Names
History
Contributors and Copyright Information
Purchase Information','2f1b752aa64e74780a1aba6fd9eb62da8e2b9ba4c2843a2124b0ab6a3f47d852','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3a7fc5e6711acc83f47e1e2640c9f9d9b6d802eec6462a1eb1d20dcf9fb4f7f',2000,'AF','Afghanistan','raw',3,'@Afghanistan:Introduction
Background: Afghanistan was invaded and occupied by the Soviet Union
in 1979. The USSR was forced to withdraw 10 years later by
anti-communist mujahidin forces supplied and trained by the US, Saudi
Arabia, Pakistan, and others. Fighting subsequently continued among
the various mujahidin factions, but the fundamentalist Islamic Taliban
movement has been able to seize most of the country. In addition to
the continuing civil strife, the country suffers from enormous
poverty, a crumbling infrastructure, and widespread live mines.
@Afghanistan:Geography
Location: Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 652,000 sq km
land: 652,000 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, chromite,
talc, barites, sulfur, lead, zinc, iron ore, salt, precious and
semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in Hindu Kush mountains;
flooding
Environment - current issues: soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification
Environment - international agreements:
party to: Desertification, Endangered Species, Environmental
Modification, Marine Dumping, Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
Geography - note: landlocked
@Afghanistan:People
Population: 25,838,797 (July 2000 est.)
Age structure:
0-14 years: 42.37% (male 5,598,403; female 5,371,054)
15-64 years: 54.86% (male 7,362,961; female 6,839,914)
65 years and over: 2.77% (male 378,741; female 337,724) (2000 est.)
Population growth rate: 3.54% (2000 est.)
note: this rate reflects the continued return of refugees from Iran
Birth rate: 41.82 births/1,000 population (2000 est.)
Death rate: 18.01 deaths/1,000 population (2000 est.)
Net migration rate: 11.54 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.08 male(s)/female
65 years and over: 1.12 male(s)/female
total population: 1.06 male(s)/female (2000 est.)
Infant mortality rate: 149.28 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 45.88 years
male: 46.62 years
female: 45.1 years (2000 est.)
Total fertility rate: 5.87 children born/woman (2000 est.)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek 6%, Hazara 19%, minor
ethnic groups (Aimaks, Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic languages
(primarily Uzbek and Turkmen) 11%, 30 minor languages (primarily
Balochi and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 31.5%
male: 47.2%
female: 15% (1999 est.)
@Afghanistan:Government
Country name:
conventional long form: Islamic State of Afghanistan; note - the
self-proclaimed Taliban government refers to the country as Islamic
Emirate of Afghanistan
conventional short form: Afghanistan
local long form: Dowlat-e Eslami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Data code: AF
Government type: no functioning central government, administered by
factions
Capital: Kabul
Administrative divisions: 30 provinces (velayat, singular - velayat);
Badakhshan, Badghis, Baghlan, Balkh, Bamian, Farah, Faryab, Ghazni,
Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Konar,
Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Oruzgan, Paktia, Paktika,
Parvan, Samangan, Sar-e Pol, Takhar, Vardak, Zabol
note: there may be two new provinces of Nurestan (Nuristan) and Khowst
Independence: 19 August 1919 (from UK control over Afghan foreign
affairs)
National holiday: Victory of the Muslim Nation, 28 April; Remembrance
Day for Martyrs and Disabled, 4 May; Independence Day, 19 August
Constitution: none
Legal system: a new legal system has not been adopted but all factions
tacitly agree they will follow Shari''a (Islamic law)
Suffrage: NA; previously males 15-50 years of age
Executive branch: on 27 September 1996, the ruling members of the
Afghan Government were displaced by members of the Islamic Taliban
movement; the Islamic State of Afghanistan has no functioning
government at this time, and the country remains divided among
fighting factions
note: the Taliban have declared themselves the legitimate government
of Afghanistan; however, the UN still recognizes the government of
Burhanuddin RABBANI; the Organization of the Islamic Conference has
left the Afghan seat vacant until the question of legitimacy can be
resolved through negotiations among the warring factions; the country
is essentially divided along ethnic lines; the Taliban controls the
capital of Kabul and approximately two-thirds of the country including
the predominately ethnic Pashtun areas in southern Afghanistan;
opposing factions have their stronghold in the ethnically diverse
north
Legislative branch: non-functioning as of June 1993
Judicial branch: non-functioning as of March 1995, although there are
local Shari''a (Islamic law) courts throughout the country
Political parties and leaders: Harakat-i-Islami (Islamic Movement)
; Harakat-Inqilab-i-Islami (Islamic
Revolutionary Movement) ; Hizbi
Islami-Gulbuddin (Islamic Party) ; Hizbi
Islami-Khalis (Islamic Party) ; Hizbi
Wahdat-Akbari faction (Islamic Unity Party) ;
Ittihad-i-Islami Barai Azadi Afghanistan (Islamic Union for the
Liberation of Afghanistan) ; Jabha-i-Najat-i-Milli
Afghanistan (Afghanistan National Liberation Front) [Sibghatullah
MOJADDEDI]; Mahaz-i-Milli-Islami (National Islamic Front) [Sayed
Ahamad GAILANI]; Taliban (Religious Students Movement) [Mohammad
OMAR]; United Islamic Front for the Salvation of Afghanistan comprised
of Jumbesh-i-Melli Islami (National Islamic Movement) [Abdul Rashid
DOSTAM]; Jamiat-i-Islami (Islamic Society) [Burhanuddin RABBANI and
Ahmad Shah MASOOD]; and Hizbi Wahdat-Khalili faction (Islamic Unity
Party)
Political pressure groups and leaders: Afghan refugees in Pakistan,
Australia, US, and elsewhere have organized politically; Mellat
(Social Democratic Party) ; Peshawar, Pakistan-based groups
such as the Coordination Council for National Unity and Understanding
in Afghanistan or CUNUA ; tribal elders represent
traditional Pashtun leadership; Writers Union of Free Afghanistan or
WUFA
International organization participation: AsDB, CP, ECO, ESCAP, FAO,
G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
Intelsat, IOC, IOM (observer), ITU, NAM, OIC, OPCW, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO, WMO, WToO
Diplomatic representation in the US:
note: embassy operations suspended 21 August 1997
chief of mission: Ambassador (vacant)
chancery: 2341 Wyoming Avenue NW, Washington, DC 20008
telephone: (202) 234-3770
FAX: (202) 328-3516
consulate(s) general: New York
Diplomatic representation from the US: the US embassy in Kabul has
been closed since January 1989 due to security concerns
Flag description: three equal horizontal bands of green (top), white,
and black with a gold emblem centered on the three bands; the emblem
features a temple-like structure with Islamic inscriptions above and
below, encircled by a wreath on the left and right and by a bolder
Islamic inscription above, all of which are encircled by two crossed
scimitars
note: the Taliban uses a plain white flag
@Afghanistan:Economy
Economy - overview: Afghanistan is an extremely poor, landlocked
country, highly dependent on farming and livestock raising (sheep and
goats). Economic considerations have played second fiddle to political
and military upheavals during two decades of war, including the nearly
10-year Soviet military occupation (which ended 15 February 1989).
During that conflict one-third of the population fled the country,
with Pakistan and Iran sheltering a combined peak of more than 6
million refugees. In early 1999, 1.2 million Afghan refugees remained
in Pakistan and about 1.4 million in Iran. Gross domestic product has
fallen substantially over the past 20 years because of the loss of
labor and capital and the disruption of trade and transport. The
majority of the population continues to suffer from insufficient food,
clothing, housing, and medical care. Inflation remains a serious
problem throughout the country. International aid can deal with only a
fraction of the humanitarian problem, let alone promote economic
development. The economic situation did not improve in 1998-99, as
internal civil strife continued, hampering both domestic economic
policies and international aid efforts. Numerical data are likely to
be either unavailable or unreliable. Afghanistan was by far the
largest producer of opium poppies in 1999, and narcotics trafficking
is a major source of revenue.
GDP: purchasing power parity - $21 billion (1999 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $800 (1999 est.)
GDP - composition by sector:
agriculture: 53%
industry: 28.5%
services: 18.5% (1990)
Population below poverty line: NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 8 million (1997 est.)
Labor force - by occupation: agriculture 68%, industry 16%, services
16% (1980 est.)
Unemployment rate: 8% (1995 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: small-scale production of textiles, soap, furniture,
shoes, fertilizer, and cement; handwoven carpets; natural gas, oil,
coal, copper
Electricity - production: 430 million kWh (1998)
Electricity - production by source:
fossil fuel: 41.86%
hydro: 58.14%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 510 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 110 million kWh (1998)
Agriculture - products: opium poppies, wheat, fruits, nuts, karakul
pelts; wool, mutton
Exports: $80 million (does not include opium) (1996 est.)
Exports - commodities: opium, fruits and nuts, handwoven carpets,
wool, cotton, hides and pelts, precious and semi-precious gems
Exports - partners: FSU, Pakistan, Iran, Germany, India, UK, Belgium,
Luxembourg, Czech Republic
Imports: $150 million (1996 est.)
Imports - commodities: capital goods, food and petroleum products;
most consumer goods
Imports - partners: FSU, Pakistan, Iran, Japan, Singapore, India,
South Korea, Germany
Debt - external: $5.5 billion (1996 est.)
Economic aid - recipient: US provided about $70 million in
humanitarian assistance in 1997; US continues to contribute to
multilateral assistance through the UN programs of food aid,
immunization, land mine removal, and a wide range of aid to refugees
and displaced persons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (Af) per US$1 - 4,700 (January 2000), 4,750
(February 1999), 17,000 (December 1996), 7,000 (January 1995), 1,900
(January 1994), 1,019 (March 1993), 850 (1991); note - these rates
reflect the free market exchange rates rather than the official
exchange rate, which was fixed at 50.600 afghanis to the dollar until
1996, when it rose to 2,262.65 per dollar, and finally became fixed
again at 3,000.00 per dollar in April 1996
Fiscal year: 21 March - 20 March
@Afghanistan:Communications
Telephones - main lines in use: 31,200 (1983); note - there were
21,000 main lines in use in Kabul in 1998
Telephones - mobile cellular: NA
Telephone system:
domestic: very limited telephone and telegraph service; in 1997,
telecommunications links were established between Mazar-e Sharif,
Herat, Kandahar, Jalalabad, and Kabul through satellite and microwave
systems
international: satellite earth stations - 1 Intelsat (Indian Ocean)
linked only to Iran and 1 Intersputnik (Atlantic Ocean region);
commercial satellite telephone center in Ghazni
Radio broadcast stations: AM 7 (6 are inactive; the active station is
in Kabul), FM 1, shortwave 1 (broadcasts in Pushtu, Dari, Urdu, and
English) (1999)
Radios: 167,000 (1999)
Television broadcast stations: at least 10 (one government run central
television station in Kabul and regional stations in nine of the 30
provinces; the regional stations operate on a reduced schedule; also,
in 1997, there was a station in Mazar-e Sharif reaching four northern
Afghanistan provinces) (1998)
Televisions: 100,000 (1999)
Internet Service Providers (ISPs): NA
@Afghanistan:Transportation
Railways:
total: 24.6 km
broad gauge: 9.6 km 1.524-m gauge from Gushgy (Turkmenistan) to
Towraghondi; 15 km 1.524-m gauge from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu Darya
Highways:
total: 21,000 km
paved: 2,793 km
unpaved: 18,207 km (1998 est.)
Waterways: 1,200 km; chiefly Amu Darya, which handles vessels up to
about 500 DWT
Pipelines: petroleum products - Uzbekistan to Bagram and Turkmenistan
to Shindand; natural gas 180 km
Ports and harbors: Kheyrabad, Shir Khan
Airports: 46 (1999 est.)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 2 (1999 est.)
Airports - with unpaved runways:
total: 32
2,438 to 3,047 m: 5
1,524 to 2,437 m: 13
914 to 1,523 m: 3
under 914 m: 11 (1999 est.)
Heliports: 3 (1999 est.)
@Afghanistan:Military
Military branches: NA; note - the military does not exist on a
national basis; some elements of the former Army, Air and Air Defense
Forces, National Guard, Border Guard Forces, National Police Force
(Sarandoi), and tribal militias still exist but are factionalized
among the various groups
Military manpower - military age: 22 years of age
Military manpower - availability:
males age 15-49: 6,401,980 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 3,432,236 (2000 est.)
Military manpower - reaching military age annually:
males: 244,958 (2000 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
@Afghanistan:Transnational Issues
Disputes - international: support to Islamic militants worldwide by
some factions; question over which group should hold Afghanistan''s
seat at the UN
Illicit drugs: world''s largest illicit opium producer, surpassing
Burma (potential production in 1999 - 1,670 metric tons; cultivation
in 1999 - 51,500 hectares, a 23% increase over 1998); a major source
of hashish; increasing number of heroin-processing laboratories being
set up in the country; major political factions in the country profit
from drug trade
______________________________________________________________________','29e89b79f3191654b9112e10cbeca01e620ace03831d6b48ccf08c9c193809fd','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58d9ac2053915968780be2dd3ec4585bfd82309907ca7a7968baa6ad8e0f8bce',2000,'AL','Albania','raw',4,'@Albania:Introduction
Background: In 1990 Albania ended 44 years of xenophobic communist
rule and established a multiparty democracy. The transition has proven
difficult as corrupt governments have tried to deal with severe
unemployment, the collapse of a fraudulent nationwide investment
scheme, widespread gangsterism, and massive refugee influxes from
neighboring Kosovo.
@Albania:Geography
Location: Southeastern Europe, bordering the Adriatic Sea and Ionian
Sea, between Greece and Serbia and Montenegro
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area:
total: 28,748 sq km
land: 27,398 sq km
water: 1,350 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km, The Former Yugoslav Republic of
Macedonia 151 km, Serbia and Montenegro 287 km (114 km with Serbia,
173 km with Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf: 200-m depth or to the depth of exploitation
territorial sea: 12 nm
Climate: mild temperate; cool, cloudy, wet winters; hot, clear, dry
summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,753 m
Natural resources: petroleum, natural gas, coal, chromium, copper,
timber, nickel, hydropower
Land use:
arable land: 21%
permanent crops: 5%
permanent pastures: 15%
forests and woodland: 38%
other: 21% (1993 est.)
Irrigated land: 3,410 sq km (1993 est.)
Natural hazards: destructive earthquakes; tsunamis occur along
southwestern coast
Environment - current issues: deforestation; soil erosion; water
pollution from industrial and domestic effluents
Environment - international agreements:
party to: Biodiversity, Climate Change, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected agreements
Geography - note: strategic location along Strait of Otranto (links
Adriatic Sea to Ionian Sea and Mediterranean Sea)
@Albania:People
Population: 3,490,435 (July 2000 est.)
Age structure:
0-14 years: 30% (male 545,329; female 507,589)
15-64 years: 63% (male 1,056,583; female 1,141,664)
65 years and over: 7% (male 104,086; female 135,184) (2000 est.)
Population growth rate: 0.26% (2000 est.)
Birth rate: 19.47 births/1,000 population (2000 est.)
Death rate: 6.5 deaths/1,000 population (2000 est.)
Net migration rate: -10.36 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 41.33 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 71.57 years
male: 68.75 years
female: 74.59 years (2000 est.)
Total fertility rate: 2.37 children born/woman (2000 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greeks 3%, other 2% (Vlachs, Gypsies,
Serbs, and Bulgarians) (1989 est.)
note: in 1989, other estimates of the Greek population ranged from 1%
(official Albanian statistics) to 12% (from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%, Roman Catholic 10%
note: all mosques and churches were closed in 1967 and religious
observances prohibited; in November 1990, Albania began allowing
private religious practice
Languages: Albanian (Tosk is the official dialect), Greek
Literacy:
definition: age 9 and over can read and write
total population: 93% (1997 est.)
male: NA%
female: NA%
@Albania:Government
Country name:
conventional long form: Republic of Albania
conventional short form: Albania
local long form: Republika e Shqiperise
local short form: Shqiperia
former: People''s Socialist Republic of Albania
Data code: AL
Government type: emerging democracy
Capital: Tirana
Administrative divisions: 36 districts (rrethe, singular - rreth) and
1 municipality* (bashki); Berat, Bulqize, Delvine, Devoll (Bilisht),
Diber (Peshkopi), Durres, Elbasan, Fier, Gjirokaster, Gramsh, Has
(Krume), Kavaje, Kolonje (Erseke), Korce, Kruje, Kucove, Kukes,
Kurbin, Lezhe, Librazhd, Lushnje, Malesi e Madhe (Koplik), Mallakaster
(Ballsh), Mat (Burrel), Mirdite (Rreshen), Peqin, Permet, Pogradec,
Puke, Sarande, Shkoder, Skrapar (Corovode), Tepelene, Tirane (Tirana),
Tirane* (Tirana), Tropoje (Bajram Curri), Vlore
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center name
following in parentheses)
Independence: 28 November 1912 (from Ottoman Empire)
National holiday: Independence Day, 28 November (1912)
Constitution: a new constitution was adopted by popular referendum on
28 November 1998; note - the opposition Democratic Party boycotted the
vote
Legal system: has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal and compulsory
Executive branch:
chief of state: President of the Republic Rexhep MEIDANI (since 24
July 1997)
head of government: Prime Minister Ilir META (since 29 October 1999)
cabinet: Council of Ministers nominated by the prime minister and
approved by the president
elections: president elected by the People''s Assembly for a five-year
term; election last held 24 July 1997 (next to be held NA 2002); prime
minister appointed by the president
election results: Rexhep MEIDANI elected president; People''s Assembly
vote by number - total votes 122, for 110, against 3, abstained 2,
invalid 7
Legislative branch: unicameral People''s Assembly or Kuvendi Popullor
(155 seats; most members are elected by direct popular vote and some
by proportional vote for four-year terms)
elections: last held 29 June 1997 (next to be held NA 2001)
election results: percent of vote by party - PS 53.36%, PD 25.33%, PSD
2.5%, PBDNJ 2.78%, PBK 2.36%, PAD 2.85%, PR 2.25%, PLL 3.09%, PDK
1.00%, PBSD 0.84%; seats by party - PS 101, PD 27, PSD 8, PBDNJ 4, PBK
3, PAD 2, PR 2, PLL 2, PDK 1, PBSD 1, PUK 1, independents 3
Judicial branch: Supreme Court, chairman of the Supreme Court is
elected by the People''s Assembly for a four-year term
Political parties and leaders: Albanian Republican Party or PR [Fatmir
MEHDIU]; Albanian Socialist Party or PS (formerly the Albania Workers
Party) ; Albanian United Right or DBSH (includes
PBK, Albanian Republican Party or PRS, AND PDD) ;
Christian Democratic Party or PDK ; Democratic Alliance
or PAD ; Democratic Party or PD ;
Democratic Party of the Right or PDD ; Liberal Union
Party ; Movement of Legality Party or PLL ;
National Front (Balli Kombetar) or PBK ; Party of
National Unity or PUK ; Right National Front [Hysni
SELFO]; Social Democratic Party or PSD ; Unity for
Human Rights Party or PBDNJ ; note - Teodar LACO
of the Liberal Union Party was leader of the Social Democratic Union
of Albania or PBSD
International organization participation: BSEC, CCC, CE, CEI, EAPC,
EBRD, ECE, FAO, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Intelsat (nonsignatory user), Interpol, IOC, IOM, ISO,
ITU, OIC, OPCW, OSCE, PFP, UN, UNCTAD, UNESCO, UNIDO, UNOMIG, UPU,
WFTU, WHO, WIPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Petrit BUSHATI
chancery: 2100 S Street NW, Washington, DC 20008
telephone: (202) 223-4942
FAX: (202) 628-7342
Diplomatic representation from the US:
chief of mission: Ambassador Joseph LIMPRECHT
embassy: Rruga Elbasanit 103, Tirana
mailing address: American Embassy, Tirana, Department of State,
Washington, DC 20521-9510
telephone: (42) 47285 through 47289
FAX: (42) 32222
Flag description: red with a black two-headed eagle in the center
@Albania:Economy
Economy - overview: An extremely poor country by European standards,
Albania is making the difficult transition to a more open-market
economy. The economy rebounded in 1993-95 after a severe depression
accompanying the collapse of the previous centrally planned system in
1990 and 1991. However, a weakening of government resolve to maintain
stabilization policies in the election year of 1996 contributed to
renewal of inflationary pressures, spurred by the budget deficit which
exceeded 12%. The collapse of financial pyramid schemes in early 1997
- which had attracted deposits from a substantial portion of Albania''s
population - triggered severe social unrest which led to more than
1,500 deaths, widespread destruction of property, and an 8% drop in
GDP. The new government, installed in July 1997, has taken strong
measures to restore public order and to revive economic activity and
trade. The economy continues to be bolstered by remittances of some
20% of the labor force that works abroad, mostly in Greece and Italy.
These remittances supplement GDP and help offset the large foreign
trade deficit. Most agricultural land was privatized in 1992,
substantially improving peasant incomes. In 1998, Albania recovered
the 8% drop in GDP of 1997 and pushed ahead by 7% in 1999.
International aid has helped defray the high costs of receiving and
returning refugees from the Kosovo conflict.
GDP: purchasing power parity - $5.6 billion (1999 est.)
GDP - real growth rate: 8% (1999 est.)
GDP - per capita: purchasing power parity - $1,650 (1999 est.)
GDP - composition by sector:
agriculture: 54%
industry: 25%
services: 21% (1998)
Population below poverty line: 19.6% (1996 est.)
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 0.5% (1999 est.)
Labor force: 1.692 million (including 352,000 emigrant workers and
261,000 domestically unemployed) (1994 est.)
Labor force - by occupation: agriculture 49.5%, industry and services
50.5%
Unemployment rate: 14% (October 1997) officially, but may be as high
as 28%
Budget:
revenues: $393 million
expenditures: $676 million, including capital expenditures of $NA
(1997 est.)
Industries: food processing, textiles and clothing; lumber, oil,
cement, chemicals, mining, basic metals, hydropower
Industrial production growth rate: 7% (1999 est.)
Electricity - production: 5.15 billion kWh (1998)
Electricity - production by source:
fossil fuel: 2.91%
hydro: 97.09%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 5.29 billion kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 500 million kWh (1998)
Agriculture - products: wheat, corn, potatoes, vegetables, fruits,
sugar beets, grapes; meat, dairy products
Exports: $242 million (f.o.b., 1999 est.)
Exports - commodities: textiles and footwear; asphalt, metals and
metallic ores, crude oil; vegetables, fruits, tobacco
Exports - partners: Italy 63%, Greece 12%, Germany 6%, Netherlands,
Belgium, US (1998)
Imports: $925 million (f.o.b., 1999 est.)
Imports - commodities: machinery and equipment, foodstuffs, textiles,
chemicals
Imports - partners: Italy 43%, Greece 29%, Turkey 4%, Germany 4%,
Bulgaria, The Former Yugoslav Republic of Macedonia (1998)
Debt - external: $820 million (1998)
Economic aid - recipient: EU pledged $100 million to share with The
Former Yugoslav Republic of Macedonia (1999)
Currency: 1 lek (L) = 100 qintars
Exchange rates: leke (L) per US$1 - 135.31 (December 1999), 137.69
(1999), 150.63 (1998), 148.93 (1997), 104.50 (1996), 92.70 (1995)
Fiscal year: calendar year
@Albania:Communications
Telephones - main lines in use: 42,000 (1995)
Telephones - mobile cellular: 3,100 (1999)
Telephone system:
domestic: obsolete wire system; no longer provides a telephone for
every village; in 1992, following the fall of the communist
government, peasants cut the wire to about 1,000 villages and used it
to build fences
international: inadequate; international traffic carried by microwave
radio relay from the Tirana exchange to Italy and Greece
Radio broadcast stations: AM 16, FM 3, shortwave 2 (1999)
Radios: 810,000 (1997)
Television broadcast stations: 13 (1999)
Televisions: 405,000 (1997)
Internet Service Providers (ISPs): 2 (1999)
@Albania:Transportation
Railways:
total: 670 km
standard gauge: 670 km 1.435-m gauge (1996)
Highways:
total: 18,000 km
paved: 5,400 km
unpaved: 12,600 km (1998 est.)
Waterways: 43 km plus Albanian sections of Lake Scutari, Lake Ohrid,
and Lake Prespa (1990)
Pipelines: crude oil 145 km; petroleum products 55 km; natural gas 64
km (1991)
Ports and harbors: Durres, Sarande, Shengjin, Vlore
Merchant marine:
total: 6 ships (1,000 GRT or over) totaling 10,907 GRT/16,101 DWT
ships by type: cargo 6 (1999 est.)
Airports: 10 (1999 est.)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 (1999 est.)
Airports - with unpaved runways:
total: 7
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 3 (1999 est.)
Heliports: 1 (1999 est.)
@Albania:Military
Military branches: Army, Navy, Air and Air Defense Forces, Interior
Ministry Troops, Border Guards
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 856,820 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 701,194 (2000 est.)
Military manpower - reaching military age annually:
males: 35,508 (2000 est.)
Military expenditures - dollar figure: $42 million (FY99)
Military expenditures - percent of GDP: 1.5% (FY99)
@Albania:Transnational Issues
Disputes - international: the Albanian Government supports protection
of the rights of ethnic Albanians outside of its borders but has
downplayed them to further its primary foreign policy goal of regional
cooperation; Albanian majority in Kosovo seeks independence from
Serbian Republic; Albanians in The Former Yugoslav Republic of
Macedonia claim discrimination in education, access to public-sector
jobs, and representation in government
Illicit drugs: increasingly active transshipment point for Southwest
Asian opiates, hashish, and cannabis transiting the Balkan route and -
to a far lesser extent - cocaine from South America destined for
Western Europe; limited opium and cannabis production; ethnic Albanian
narcotrafficking organizations active and rapidly expanding in Europe
______________________________________________________________________','f2417f235912927a1fd55a0fc57fee174425c7b53c5684a056c41f589b182bca','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85ddab3d56c33fca0fb61b7e47a9065ba0a5baf1caaa8b5063daaa694ac7f42f',2000,'DZ','Algeria','raw',5,'@Algeria:Introduction
Background: After a century of rule by France, Algeria became
independent in 1962. The surprising first round success of the
fundamentalist FIS (Islamic Salvation Front) party in December 1991
balloting caused the army to intervene, crack down on the FIS, and
postpone the subsequent elections. The FIS response has resulted in a
continuous low-grade civil conflict with the secular state apparatus,
which nonetheless has allowed elections featuring pro-government and
moderate religious-based parties. FIS''s armed wing, the Islamic
Salvation Army, dissolved itself in January 2000 and many armed
insurgents surrendered under an amnesty program designed to promote
national reconciliation. Nevertheless, some residual fighting
continues. Other concerns include large-scale unemployment and the
need to diversify the petroleum-based economy.
@Algeria:Geography
Location: Northern Africa, bordering the Mediterranean Sea, between
Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
Area - comparative: slightly less than 3.5 times the size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km, Mauritania 463 km,
Morocco 1,559 km, Niger 956 km, Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
exclusive fishing zone: 32-52 nm
territorial sea: 12 nm
Climate: arid to semiarid; mild, wet winters with hot, dry summers
along coast; drier with cold winters and hot summers on high plateau;
sirocco is a hot, dust/sand-laden wind especially common in summer
Terrain: mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore, phosphates,
uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 13%
forests and woodland: 2%
other: 82% (1993 est.)
Irrigated land: 5,550 sq km (1993 est.)
Natural hazards: mountainous areas subject to severe earthquakes; mud
slides
Environment - current issues: soil erosion from overgrazing and other
poor farming practices; desertification; dumping of raw sewage,
petroleum refining wastes, and other industrial effluents is leading
to the pollution of rivers and coastal waters; Mediterranean Sea, in
particular, becoming polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Environmental Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Nuclear Test Ban
Geography - note: second-largest country in Africa (after Sudan)
@Algeria:People
Population: 31,193,917 (July 2000 est.)
Age structure:
0-14 years: 35% (male 5,591,044; female 5,389,046)
15-64 years: 61% (male 9,582,864; female 9,381,088)
65 years and over: 4% (male 577,875; female 672,000) (2000 est.)
Population growth rate: 1.74% (2000 est.)
Birth rate: 23.14 births/1,000 population (2000 est.)
Death rate: 5.3 deaths/1,000 population (2000 est.)
Net migration rate: -0.47 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 41.97 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 69.65 years
male: 68.34 years
female: 71.02 years (2000 est.)
Total fertility rate: 2.8 children born/woman (2000 est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less than 1%
Religions: Sunni Muslim (state religion) 99%, Christian and Jewish 1%
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 15 and over can read and write
total population: 61.6%
male: 73.9%
female: 49% (1995 est.)
@Algeria:Government
Country name:
conventional long form: Democratic and Popular Republic of Algeria
conventional short form: Algeria
local long form: Al Jumhuriyah al Jaza''iriyah ad Dimuqratiyah ash
Shabiyah
local short form: Al Jaza''ir
Data code: AG
Government type: republic
Capital: Algiers
Administrative divisions: 48 provinces (wilayas, singular - wilaya);
Adrar, Ain Defla, Ain Temouchent, Alger, Annaba, Batna, Bechar,
Bejaia, Biskra, Blida, Bordj Bou Arreridj, Bouira, Boumerdes, Chlef,
Constantine, Djelfa, El Bayadh, El Oued, El Tarf, Ghardaia, Guelma,
Illizi, Jijel, Khenchela, Laghouat, Mascara, Medea, Mila, Mostaganem,
M''Sila, Naama, Oran, Ouargla, Oum el Bouaghi, Relizane, Saida, Setif,
Sidi Bel Abbes, Skikda, Souk Ahras, Tamanghasset, Tebessa, Tiaret,
Tindouf, Tipaza, Tissemsilt, Tizi Ouzou, Tlemcen
Independence: 5 July 1962 (from France)
National holiday: Anniversary of the Revolution, 1 November (1954)
Constitution: 19 November 1976, effective 22 November 1976; revised 3
November 1988, 23 February 1989, and 28 November 1996; note -
referendum approving the revisions of 28 November 1996 was signed into
law 7 December 1996
Legal system: socialist, based on French and Islamic law; judicial
review of legislative acts in ad hoc Constitutional Council composed
of various public officials, including several Supreme Court justices;
has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Abdelaziz BOUTEFLIKA (since 28 April 1999)
head of government: Prime Minister Ahmed BENBITOUR (since 2 December
1999)
cabinet: Council of Ministers appointed by the prime minister
elections: president elected by popular vote for a five-year term;
election last held 15 April 1999 (next to be held NA April 2004);
prime minister appointed by the president
election results: Abdelaziz BOUTEFLIKA elected president; percent of
vote - Abdelaziz BOUTEFLIKA 70%; note - six of the seven candidates
withdrew sighting persistent electoral fraud
Legislative branch: bicameral Parliament consists of the National
People''s Assembly or Al-Majlis Ech-Chaabi Al-Watani (380 seats;
members elected by popular vote to serve four-year terms) and the
Council of Nations (144 seats; one-third of the members appointed by
the president, two-thirds elected by indirect vote; members serve
six-year terms; created as a result of the constitutional revision of
November 1996)
elections: National People''s Assembly - last held 5 June 1997 (next to
be held NA 2001); elections for two-thirds of the Council of Nations -
last held 25 December 1997 (next to be held NA 2003)
election results: National People''s Assembly - percent of vote by
party - RND 40.8%, MSP 18.2%, FLN 16.8%, Nahda Movement 8.9%, FFS 5%,
RCD 5%, PT 1.1%, Republican Progressive Party 0.8%, Union for
Democracy and Freedoms 0.3%, Liberal Social Party 0.3%, independents
2.8%; seats by party - RND 156, MSP 69, FLN 62, Nahda Movement 34, FFS
20, RCD 19, PT 4, Republican Progressive Party 3, Union for Democracy
and Freedoms 1, Liberal Social Party 1, independents 11; Council of
Nations - percent of vote by party - NA%; seats by party - RND 80, FLN
10, FFS 4, MSP 2 (remaining 48 seats appointed by the president, party
breakdown NA)
Judicial branch: Supreme Court (Cour Supreme)
Political parties and leaders: Algerian Democratic Front or FAD
; Algerian National Front or ANF ;
Algerian Renewal Party or PRA ;
Democratic National Rally or RND ; Islamic
Salvation Front or FIS (outlawed April 1992) [Ali BELHADJ, Dr. Abassi
MADANI, Rabeh KEBIR (self-exile in Germany)]; Liberal Social Party
; Movement for Democracy in Algeria or MDA [Ahmed Ben
BELLA]; Movement for Loyalty and Justice [Ahmed Taleb IBRAHIMI,
president; Movement of a Peaceful Society or MSP [Mahfoud NAHNAH,
chairman]; Nahda Movement or Al Nahda ;
National Liberation Front or FLN [Boualem BENHAMOUDA, secretary
general]; National Party for Solidarity and Development or PNSD [Rabah
BENCHERIF]; National Republican Alliance or ANR ; Rally
for Culture and Democracy or RCD ;
Republican Progressive Party ; Social Democratic
Movement or MDS ; Socialist Forces Front or FFS
;
Union for Democracy and Freedoms ; Workers Party or
PT
note: the government established a multiparty system in September 1989
and, as of 31 December 1990, over 50 legal parties existed; a new
party law was enacted in March 1997
International organization participation: ABEDA, AfDB, AFESD, AL, AMF,
AMU, CCC, ECA, FAO, G-15, G-19, G-24, G-77, IAEA, IBRD, ICAO, ICFTU,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, IOM (observer), ISO, ITU, MONUC, NAM, OAPEC,
OAS (observer), OAU, OIC, OPCW, OPEC, OSCE (partner), UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UPU, WCL, WHO, WIPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Idriss JAZAIRY
chancery: 2118 Kalorama Road NW, Washington, DC 20008
telephone: (202) 265-2800
FAX: (202) 667-2174
Diplomatic representation from the US:
chief of mission: Ambassador Cameron R. HUME
embassy: 4 Chemin Cheikh Bachir El-Ibrahimi, Algiers
mailing address: B. P. Box 549, Alger-Gare, 16000 Algiers
telephone: (2) 69-11-86, 69-12-55, 69-18-54, 69-38-75
FAX: (2) 69-39-79
Flag description: two equal vertical bands of green (hoist side) and
white with a red, five-pointed star within a red crescent; the
crescent, star, and color green are traditional symbols of Islam (the
state religion)
@Algeria:Economy
Economy - overview: The hydrocarbons sector is the backbone of the
economy, accounting for roughly 52% of budget revenues, 25% of GDP,
and over 95% of export earnings. Algeria has the fifth-largest
reserves of natural gas in the world and is the second largest gas
exporter; it ranks fourteenth for oil reserves. Algiers'' efforts to
reform one of the most centrally planned economies in the Arab world
stalled in 1992 as the country became embroiled in political turmoil.
Burdened with a heavy foreign debt, Algiers concluded a one-year
standby arrangement with the IMF in April 1994 and the following year
signed onto a three-year extended fund facility which ended 30 April
1998. Some progress on economic reform, Paris Club debt reschedulings
in 1995 and 1996, and oil and gas sector expansion contributed to a
recovery in growth since 1995. Still, the economy remains heavily
dependent on volatile oil and gas revenues. The government has
continued efforts to diversify the economy by attracting foreign and
domestic investment outside the energy sector, but has had little
success in reducing high unemployment and improving living standards.
GDP: purchasing power parity - $147.6 billion (1999 est.)
GDP - real growth rate: 3.9% (1999 est.)
GDP - per capita: purchasing power parity - $4,700 (1999 est.)
GDP - composition by sector:
agriculture: 12%
industry: 51%
services: 37% (1997 est.)
Population below poverty line: 23% (1999 est.)
Household income or consumption by percentage share:
lowest 10%: 2.8%
highest 10%: 26.8% (1995)
Inflation rate (consumer prices): 4.2% (1999 est.)
Labor force: 9.1 million (2000 est.)
Labor force - by occupation: government 29.5%, agriculture 22%,
construction and public works 16.2%, industry 13.6%, commerce and
services 13.5%, transportation and communication 5.2% (1989)
Unemployment rate: 30% (1999 est.)
Budget:
revenues: $15.5 billion
expenditures: $15.1 billion, including capital expenditures of $NA
(1999 est.)
Industries: petroleum, natural gas, light industries, mining,
electrical, petrochemical, food processing
Industrial production growth rate: 7% (1999 est.)
Electricity - production: 21.38 billion kWh (1998)
Electricity - production by source:
fossil fuel: 99.77%
hydro: 0.23%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 19.882 billion kWh (1998)
Electricity - exports: 313 million kWh (1998)
Electricity - imports: 312 million kWh (1998)
Agriculture - products: wheat, barley, oats, grapes, olives, citrus,
fruits; sheep, cattle
Exports: $13.7 billion (f.o.b., 1999 est.)
Exports - commodities: petroleum, natural gas, and petroleum products
97%
Exports - partners: Italy 21.2%, US 15.0%, France 12.9%, Spain 10.3%,
Brazil 5.9%, Netherlands 5.5% (1998)
Imports: $9.3 billion (f.o.b., 1999 est.)
Imports - commodities: capital goods, food and beverages, consumer
goods
Imports - partners: France 29.5%, Italy 9.8%, US 7.2%, Spain 6.8%,
Germany 6.2%, Canada 4.1% (1998)
Debt - external: $30 billion (1999 est.)
Economic aid - recipient: $897.5 million (1994)
Currency: 1 Algerian dinar (DA) = 100 centimes
Exchange rates: Algerian dinars (DA) per US$1 - 69.046 (January 2000),
66.574 (1999), 58.739 (1998), 57.707 (1997), 54.749 (1996), 47.663
(1995)
Fiscal year: calendar year
@Algeria:Communications
Telephones - main lines in use: 1.176 million (1995)
Telephones - mobile cellular: 33,500 (1999)
Telephone system:
domestic: good service in north but sparse in south; domestic
satellite system with 12 earth stations (20 additional domestic earth
stations are planned)
international: 5 submarine cables; microwave radio relay to Italy,
France, Spain, Morocco, and Tunisia; coaxial cable to Morocco and
Tunisia; participant in Medarabtel; satellite earth stations - 2
Intelsat (1 Atlantic Ocean and 1 Indian Ocean), 1 Intersputnik, and 1
Arabsat
Radio broadcast stations: AM 25, FM 1, shortwave 8 (1999)
Radios: 7.1 million (1997)
Television broadcast stations: 18 (not including low-power stations)
(1999)
Televisions: 3.1 million (1997)
Internet Service Providers (ISPs): 1 (1999)
@Algeria:Transportation
Railways:
total: 4,820 km (301 km electrified; 215 km double track)
standard gauge: 3,664 km 1.435-m gauge (301 km electrified; 215 km
double track)
narrow gauge: 1,156 km 1.055-m gauge (1996)
Highways:
total: 104,000 km
paved: 71,656 km (including 640 km of expressways)
unpaved: 32,344 km (1996 est.)
Pipelines: crude oil 6,612 km; petroleum products 298 km; natural gas
2,948 km
Ports and harbors: Algiers, Annaba, Arzew, Bejaia, Beni Saf, Dellys,
Djendjene, Ghazaouet, Jijel, Mostaganem, Oran, Skikda, Tenes
Merchant marine:
total: 78 ships (1,000 GRT or over) totaling 940,196 GRT/1,094,104 DWT
ships by type: bulk 9, cargo 27, chemical tanker 7, liquified gas 11,
petroleum tanker 5, roll-on/roll-off 13, short-sea passenger 5,
specialized tanker 1 (1999 est.)
Airports: 137 (1999 est.)
Airports - with paved runways:
total: 51
over 3,047 m: 8
2,438 to 3,047 m: 25
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m: 1 (1999 est.)
Airports - with unpaved runways:
total: 86
2,438 to 3,047 m: 3
1,524 to 2,437 m: 23
914 to 1,523 m: 41
under 914 m: 19 (1999 est.)
Heliports: 1 (1999 est.)
@Algeria:Military
Military branches: National Popular Army, Navy, Air Force, Territorial
Air Defense, National Gendarmerie
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 8,523,257 (2000 est.)
Military manpower - fit for military service:
males age 15-49: 5,220,318 (2000 est.)
Military manpower - reaching military age annually:
males: 373,547 (2000 est.)
Military expenditures - dollar figure: $1.3 billion (FY94)
Military expenditures - percent of GDP: 2.7% (FY94)
@Algeria:Transnational Issues
Disputes - international: part of southeastern region claimed by Libya
______________________________________________________________________','f241dd897e207faddde67b7ac8efd39c3688eca694db11725a903b4d61ad8dfe','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74b00f53dfd2fff4b24fbbf78ba5a93f3770f2258710f93c5f4a648209b92ea5',2000,'AS','American Samoa','raw',6,'@American Samoa:Introduction
Background: Settled as early as 1000 B. C., Samoa was "discovered" by
European explorers in the 18th century. International rivalries in the
latter half of the 19th century were settled by an 1899 treaty in
which Germany and the US divided the Samoan archipelago. The US
formally occupied its portion - a smaller group of eastern islands
with the excellent harbor of Pago Pago - the following year.
@American Samoa:Geography
Location: Oceania, group of islands in the South Pacific Ocean, about
one-half of the way from Hawaii to New Zealand
Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area:
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area - comparative: slightly larger than Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine, moderated by southeast trade winds; annual
rainfall averages about 3 m; rainy season from November to April, dry
season from May to October; little seasonal temperature variation
Terrain: five volcanic islands with rugged peaks and limited coastal
plains, two coral atolls (Rose Island, Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use:
arable land: 5%
permanent crops: 10%
permanent pastures: 0%
forests and woodland: 70%
other: 15% (1993 est.)
Irrigated land: NA sq km
Natural hazards: typhoons common from December to March
Environment - current issues: limited natural fresh water resources;
the water division of the government has spent substantial funds in
the past few years to improve water catchments and pipelines
Geography - note: Pago Pago has one of the best natural deepwater
harbors in the South Pacific Ocean, sheltered by shape from rough seas
and protected by peripheral mountains from high winds; strategic
location in the South Pacific Ocean
@American Samoa:People
Population: 65,446 (July 2000 est.)
Age structure:
0-14 years: 39% (male 13,071; female 12,304)
15-64 years: 56% (male 18,358; female 18,597)
65 years and over: 5% (male 1,631; female 1,485) (2000 est.)
Population growth rate: 2.53% (2000 est.)
Birth rate: 25.81 births/1,000 population (2000 est.)
Death rate: 4.26 deaths/1,000 population (2000 est.)
Net migration rate: 3.74 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 10.63 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 75.12 years
male: 70.66 years
female: 79.84 years (2000 est.)
Total fertility rate: 3.6 children born/woman (2000 est.)
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic groups: Samoan (Polynesian) 89%, Caucasian 2%, Tongan 4%, other
5%
Religions: Christian Congregationalist 50%, Roman Catholic 20%,
Protestant and other 30%
Languages: Samoan (closely related to Hawaiian and other Polynesian
languages), English
note: most people are bilingual
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 98%
female: 97% (1980 est.)
@American Samoa:Government
Country name:
conventional long form: Territory of American Samoa
conventional short form: American Samoa
abbreviation: AS
Data code: AQ
Dependency status: unincorporated and unorganized territory of the US;
administered by the Office of Insular Affairs, US Department of the
Interior
Government type: NA
Capital: Pago Pago
Administrative divisions: none (territory of the US); there are no
first-order administrative divisions as defined by the US Government,
but there are three districts and two islands* at the second order;
Eastern, Manu''a, Rose Island*, Swains Island*, Western
Independence: none (territory of the US)
National holiday: Territorial Flag Day, 17 April (1900)
Constitution: ratified 1966, in effect 1967
Legal system: NA
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President William Jefferson CLINTON of the US (since
20 January 1993) and Vice President Albert GORE, Jr. (since 20 January
1993)
head of government: Governor Tauese P. SUNIA (since 3 January 1997)
and Lieutenant Governor Togiola TULAFONO (since 3 January 1997)
cabinet: NA
elections: US president and vice president elected on the same ticket
for four-year terms; governor and lieutenant governor elected on the
same ticket by popular vote for four-year terms; election last held 3
November 1996 (next to be held 7 November 2000)
election results: Tauese P. SUNIA elected governor; percent of vote -
Tauese P. SUNIA (Democrat) 51%, Peter REID (independent) 49%
Legislative branch: bicameral Fono or Legislative Assembly consists of
the House of Representatives (21 seats - 20 of which are elected by
popular vote and 1 is an appointed, nonvoting delegate from Swains
Island; members serve two-year terms) and the Senate (18 seats;
members are elected from local chiefs and serve four-year terms)
elections: House of Representatives - last held NA November 1998 (next
to be held NA November 2000); Senate - last held 3 November 1996 (next
to be held 7 November 2000)
election results: House of Representatives - percent of vote by party
- NA; seats by party - NA; Senate - percent of vote by party - NA;
seats by party - NA
note: American Samoa elects one delegate to the US House of
Representatives; election last held 3 November 1998 (next to be held 7
November 2000); results - Eni R. F. H. FALEOMAVAEGA (Democrat)
reelected as delegate for a sixth term
Judicial branch: High Court (chief justice and associate justices are
appointed by the US Secretary of the Interior)
Political parties and leaders: Democratic Party ;
Republican Party
International organization participation: ESCAP (associate), Interpol
(subbureau), IOC, SPC
Diplomatic representation in the US: none (territory of the US)
Diplomatic representation from the US: none (territory of the US)
Flag description: blue, with a white triangle edged in red that is
based on the outer side and extends to the hoist side; a brown and
white American bald eagle flying toward the hoist side is carrying two
traditional Samoan symbols of authority, a staff and a war club
@American Samoa:Economy
Economy - overview: This is a traditional Polynesian economy in which
more than 90% of the land is communally owned. Economic activity is
strongly linked to the US, with which American Samoa conducts the
great bulk of its foreign trade. Tuna fishing and tuna processing
plants are the backbone of the private sector, with canned tuna the
primary export. Transfers from the US Government add substantially to
American Samoa''s economic well-being. Attempts by the government to
develop a larger and broader economy are restrained by Samoa''s remote
location, its limited transportation, and its devastating hurricanes.
Tourism, a developing sector, may be held back by the current
financial difficulties in East Asia.
GDP: purchasing power parity - $150 million (1995 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $2,600 (1995 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): NA%
Labor force: 13,949 (1996)
Labor force - by occupation: government 33%, tuna canneries 34%, other
33% (1990)
Unemployment rate: 12% (1991)
Budget:
revenues: $121 million (37% in local revenue and 63% in US grants)
expenditures: $127 million, including capital expenditures of $NA
(FY96/97)
Industries: tuna canneries (largely dependent on foreign fishing
vessels), handicrafts
Industrial production growth rate: NA%
Electricity - production: 125 million kWh (1998)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 116 million kWh (1998)
Electricity - exports: 0 kWh (1998)
Electricity - imports: 0 kWh (1998)
Agriculture - products: bananas, coconuts, vegetables, taro,
breadfruit, yams, copra, pineapples, papayas; dairy products,
livestock
Exports: $313 million (1996)
Exports - commodities: canned tuna 93%
Exports - partners: US 99.6%
Imports: $471 million (1996)
Imports - commodities: materials for canneries 56%, food 8%, petroleum
products 7%, machinery and parts 6%
Imports - partners: US 62%, Japan 9%, NZ 7%, Australia 11%, Fiji 4%,
other 7%
Debt - external: $NA
Economic aid - recipient: $NA; note - important financial support from
the US
Currency: 1 US dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October - 30 September
@American Samoa:Communications
Telephones - main lines in use: 10,000 (1994)
Telephones - mobile cellular: 1,200 (1994)
Telephone system:
domestic: good telex, telegraph, facsimile and cellular telephone
services; domestic satellite system with 1 Comsat earth station
international: satellite earth station - 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1, shortwave 0 (1998)
Radios: 57,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 14,000 (1997)
Internet Service Providers (ISPs): NA
@American Samoa:Transportation
Railways: 0 km
Highways:
total: 350 km
paved: 150 km
unpaved: 200 km
Ports and harbors: Aunu''u (new construction), Auasi, Faleosao, Ofu,
Pago Pago, Ta''u
Merchant marine: none (1999 est.)
Airports: 4 (1999 est.)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (1999 est.)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (1999 est.)
@American Samoa:Military
Military - note: defense is the responsibility of the US
@American Samoa:Transnational Issues
Disputes - international: none
______________________________________________________________________','b9a0ca9dcbaebc9d5ed9c47a2b529fd7f23ed58a69b6575f42622e6bfd96c690','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02131facd22516a4a425675efd2fef0df721139fde81faa6a2fb73e05d7993b5',2000,'AD','Andorra','raw',7,'@Andorra:Introduction
Background: Long isolated and impoverished, mountainous Andorra has
achieved considerable prosperity since World War II through its
tourist industry. Many immigrants (legal and illegal) are attracted to
the thriving economy with its lack of income taxes.
@Andorra:Geography
Location: Southwestern Europe, between France and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 468 sq km
land: 468 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of Washington, DC
Land boundaries:
total: 120.3 km
border countries: France 56.6 km, Spain 63.7 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm, dry summers
Terrain: rugged mountains dissected by narrow valleys
Elevation extremes:
lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water, timber, iron ore, lead
Land use:
arable land: 4%
permanent crops: 0%
permanent pastures: 45%
forests and woodland: 35%
other: 16% (1998 est.)
Irrigated land: NA sq km
Natural hazards: snowslides, avalanches
Environment - current issues: deforestation; overgrazing of mountain
meadows contributes to soil erosion; air pollution; waste water
treatment and solid waste disposal
Environment - international agreements:
party to: Hazardous Wastes
signed, but not ratified: none of the selected agreements
Geography - note: landlocked
@Andorra:People
Population: 66,824 (July 2000 est.)
Age structure:
0-14 years: 15% (male 5,382; female 4,883)
15-64 years: 72% (male 25,463; female 22,837)
65 years and over: 13% (male 4,160; female 4,099) (2000 est.)
Population growth rate: 1.22% (2000 est.)
Birth rate: 10.58 births/1,000 population (2000 est.)
Death rate: 5.27 deaths/1,000 population (2000 est.)
Net migration rate: 6.9 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1.01 male(s)/female
total population: 1.1 male(s)/female (2000 est.)
Infant mortality rate: 4.08 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 83.46 years
male: 80.56 years
female: 86.56 years (2000 est.)
Total fertility rate: 1.25 children born/woman (2000 est.)
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%, Andorran 33%, Portuguese 11%, French 7%,
other 6% (1998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castilian
Literacy:
definition: NA
total population: 100%
male: NA%
female: NA%
@Andorra:Government
Country name:
conventional long form: Principality of Andorra
conventional short form: Andorra
local long form: Principat d''Andorra
local short form: Andorra
Data code: AN
Government type: parliamentary democracy (since March 1993) that
retains as its heads of state a coprincipality; the two princes are
the president of France and bishop of Seo de Urgel, Spain, who are
represented locally by coprinces'' representatives
Capital: Andorra la Vella
Administrative divisions: 7 parishes (parroquies, singular -
parroquia); Andorra la Vella, Canillo, Encamp, La Massana,
Escaldes-Engordany, Ordino, Sant Julia de Loria
Independence: 1278 (was formed under the joint suzerainty of France
and Spain)
National holiday: Mare de Deu de Meritxell, 8 September (1278)
Constitution: Andorra''s first written constitution was drafted in
1991; approved by referendum 14 March 1993; came into force 4 May 1993
Legal system: based on French and Spanish civil codes; no judicial
review of legislative acts; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: French Coprince Jacques CHIRAC (since 17 May 1995),
represented by Mr. Frederic de SAINT-SERNIN (since NA); Spanish
Coprince Episcopal Monseigneur Joan MARTI Alanis (since 31 January
1971), represented by Mr. Nemesi MARQUES OSTE (since NA)
head of government: Executive Council President Marc FORNE Molne
(since 21 December 1994)
cabinet: Executive Council or Govern designated by the Executive
Council president
elections: Executive Council president elected by the General Council
and formally appointed by the coprinces for a four-year term; election
last held 16 February 1997 (next to be held NA 2001)
election results: Marc FORNE Molne elected executive council
president; percent of General Council vote - 64%
Legislative branch: unicameral General Council of the Valleys or
Consell General de las Valls (28 seats; members are elected by direct
popular vote, 14 from a single national constituency and 14 to
represent each of the 7 parishes; members serve four-year terms)
elections: last held 16 February 1997 (next to be held NA February
2001)
election results: percent of vote by party - UL 57%, AND 21%, IDN 7%,
ND 7%, other 8%; seats by party - UL 16, AND 6, ND 2, IDN 2, UPO 2
Judicial branch: Tribunal of Judges or Tribunal de Batlles; Tribunal
of the Courts or Tribunal de Corts; Supreme Court of Justice of
Andorra or Tribunal Superior de Justicia d''Andorra; Supreme Council of
Justice or Consell Superior de la Justicia; Fiscal Ministry or
Ministeri Fiscal; Constitutional Tribunal or Tribunal Constitucional
Political parties and leaders: Liberal Party of Andorra (Partit
Liberal d''Andorra) or PLA ; Liberal Union or UL [Francesc
CERQUEDA]; National Democratic Group or AND ;
National Democratic Initiative or IDN ; New
Democracy or ND ; Unio Parroquial d''Ordino or
UPO
note: there are two other small parties
International organization participation: CCC, CE, ECE, ICRM, IFRCS,
Interpol, IOC, ITU, OSCE, UN, UNESCO, WHO, WIPO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador Juli MINOVES-TRIQUELL (also Permanent
Representative to the UN)
chancery: 2 United Nations Plaza, 25th Floor, New York, NY 10017
telephone: (212) 750-8064
FAX: (212) 750-6630
Diplomatic representation from the US: the US does not have an embassy
in Andorra; the US Ambassador to Spain is accredited to Andorra; US
interests in Andorra are represented by the Consulate General''s office
in Barcelona (Spain); mailing address: Paseo Reina Elisenda, 23, 08034
Barcelona, Spain; telephone: (3493) 280-2227; FAX: (3493) 205-7705
Flag description: three equal vertical bands of blue (hoist side),
yellow, and red with the national coat of arms centered in the yellow
band; the coat of arms features a quartered shield; similar to the
flags of Chad and Romania, which do not have a national coat of arms
in the center, and the flag of Moldova, which does bear a national
emblem
@Andorra:Economy
Economy - overview: Tourism, the mainstay of Andorra''s tiny,
well-to-do economy, accounts for roughly 80% of GDP. An estimated 9
million tourists visit annually, attracted by Andorra''s duty-free
status and by its summer and winter resorts. Andorra''s comparative
advantage has recently eroded as the economies of neighboring France
and Spain have been opened up, providing broader availability of goods
and lower tariffs. The banking sector, with its "tax haven" status,
also contributes substantially to the economy. Agricultural production
is limited by a scarcity of arable land, and most food has to be
imported. The principal livestock activity is sheep raising.
Manufacturing consists mainly of cigarettes, cigars, and furniture.
Andorra is a member of the EU Customs Union and is treated as an EU
member for trade in manufactured goods (no tariffs) and as a non-EU
member for agricultural products.
GDP: purchasing power parity - $1.2 billion (1996 est.)
GDP - real growth rate: NA%
GDP - per capita: purchasing power parity - $18,000 (1996 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Population below poverty line: NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1.62% (1998)
Labor force: 30,787 salaried employees (1998)
Labor force - by occupation: agriculture 1%, industry 21%, services
72%, other 6% (1998)
Unemployment rate: 0%
Budget:
revenues: $385 million
expenditures: $342 million, including capital expenditures of $NA
(1997)
Industries: tourism (particularly skiing), cattle raising, timber,
tobacco, banking
Industrial production growth rate: NA%
Electricity - production: 116 million kWh (1998)
Electricity - production by source:
fossil fuel: NA%
hydro: NA%
nuclear: NA%
other: NA%
Electricity - consumption: NA kWh (1998 est.)
Electricity - exports: NA kWh
Electricity - imports: NA kWh; note - imports electricity from Spain
and France
Agriculture - products: small quantities of tobacco, rye, wheat,
barley, oats, vegetables; sheep
Exports: $58 million (f.o.b., 1998)
Exports - commodities: tobacco products, furniture
Exports - partners: France 34%, Spain 58% (1998)
Imports: $1.077 billion (c.i.f., 1998)
Imports - commodities: consumer goods, food, electricity
Imports - partners: Spain 48%, France 35%, US 2.3% (1998)
Debt - external: $NA
Economic aid - recipient: none
Currency: 1 French franc (F) = 100 centimes; 1 peseta (Pta) = 100
centimos; the French and Spanish currencies are used
Exchange rates: euros per US$1 - 0.9867 (January 2000), 0.9386 (1999);
French francs (F) per US$1 - 5.65 (January 1999), 5.8995 (1998),
5.8367 (1997), 5.1155 (1996), 4.9915 (1995); Spanish pesetas (Ptas)
per US$1 - 143.39 (January 1999), 149.40 (1998), 146.41 (1997), 126.66
(1996), 124.69 (1995)
Fiscal year: calendar year
@Andorra:Communications
Telephones - main lines in use: 31,980 (1997)
Telephones - mobile cellular: 8,618 (1997)
Telephone system:
domestic: modern system with microwave radio relay connections between
exchanges
international: landline circuits to France and Spain
Radio broadcast stations: AM 0, FM 15, shortwave 0 (1998)
Radios: 16,000 (1997)
Television broadcast stations: 0 (1997)
Televisions: 27,000 (1997)
Internet Service Providers (ISPs): NA
@Andorra:Transportation
Railways: 0 km
Highways:
total: 269 km
paved: 198 km
unpaved: 71 km (1994 est.)
Ports and harbors: none
Airports: none
@Andorra:Military
Military - note: defense is the responsibility of France and Spain
@Andorra:Transnational Issues
Disputes - international: none
______________________________________________________________________','5fea84b0d142481097e282090fac8a1d508ca32a82dc76c739e9484bf9dfb1b7','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199587fdd4412bfdd67189e7490701d5637fc2e60d1f2d39581ac170a2873852',2000,'AO','Angola','raw',8,'@Angola:Introduction
Background: Civil war has been the norm in Angola since independence
from Portugal in 1975. A 1994 peace accord between the government and
the National Union for the Total Independence of Angola (UNITA)
provided for the integration of former UNITA insurgents into the
government and armed forces. A national unity government was installed
in April of 1997, but serious fighting resumed in late 1998, rendering
hundreds of thousands of people homeless. Up to 1.5 million lives may
have been lost in fighting over the past quarter century.
@Angola:Geography
Location: Southern Africa, bordering the South Atlantic Ocean, between
Namibia and Democratic Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo 2,511 km (of which
220 km is the boundary of discontiguous Cabinda Province), Republic of
the Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: semiarid in south and along coast to Luanda; north has cool,
dry season (May to October) and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore, phosphates, copper,
feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes periodic flooding on
the plateau
Environment - current issues: overuse of pastures and subsequent soil
erosion attributable to population pressures; desertification;
deforestation of tropical rain forest, in response to both
international demand for tropical timber and to domestic use as fuel,
resulting in loss of biodiversity; soil erosion contributing to water
pollution and siltation of rivers and dams; inadequate supplies of
potable water
Environment - international agreements:
party to: Biodiversity, Desertification, Law of the Sea
signed, but not ratified: Climate Change
Geography - note: Cabinda is separated from rest of country by the
Democratic Republic of the Congo
@Angola:People
Population: 10,145,267 (July 2000 est.)
Age structure:
0-14 years: 43% (male 2,215,706; female 2,172,106)
15-64 years: 54% (male 2,792,313; female 2,692,790)
65 years and over: 3% (male 124,404; female 147,948) (2000 est.)
Population growth rate: 2.15% (2000 est.)
Birth rate: 46.89 births/1,000 population (2000 est.)
Death rate: 25.01 deaths/1,000 population (2000 est.)
Net migration rate: -0.34 migrant(s)/1,000 population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.02 male(s)/female (2000 est.)
Infant mortality rate: 195.78 deaths/1,000 live births (2000 est.)
Life expectancy at birth:
total population: 38.31 years
male: 37.11 years
female: 39.56 years (2000 est.)
Total fertility rate: 6.52 children born/woman (2000 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%, mestico
(mixed European and Native African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic 38%, Protestant 15%
(1998 est.)
Languages: Portuguese (official), Bantu and other African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 28% (1998 est.)
@Angola:Government
Country name:
conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Data code: AO
Government type: transitional government, nominally a multiparty
democracy with a strong presidential system
Capital: Luanda
Administrative divisions: 18 provinces (provincias, singular -
provincia); Bengo, Benguela, Bie, Cabinda, Cuando Cubango, Cuanza
Norte, Cuanza Sul, Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda
Sul, Malanje, Moxico, Namibe, Uige, Zaire
Independence: 11 November 1975 (from Portugal)
National holiday: Independence Day, 11 November (1975)
Constitution: 11 November 1975; revised 7 January 1978, 11 August
1980, 6 March 1991, and 26 August 1992
Legal system: based on Portuguese civil law system and customary law;
recently modified to accommodate political pluralism and increased use
of free markets
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Jose Eduardo DOS SANTOS (since 21 September
1979); note - the president is both chief of state and head of','2797ba201036d3e9519f4d1f379a860f74ee7ac4aaec8c6b90101712b5b153ee','internet-archive','theciaworldfactb03672gut','txt','666db95559066f29ad448dd2c60f1d4e95c656e35c05bec72ef15711af73e012','https://archive.org/download/theciaworldfactb03672gut/3672.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04fd50fa89dda4938959aec5088f7955dfeac12c659d4ca2dc2d0a0af643499c',2000,'','','raw',1,'Physical Map of the World, April 2000
AUSTRALIA Independent state
Bermuda Dependency or area of special sovereignty
Sicily / AZORES Island / island group 150 120 90 60 30 0 30 60 90 120 150 180
Capital ARCTIC OCEAN ARCTIC OCEAN FRANZ JOSEF
ARCTIC OCEAN
LAND SEVERNAYA
ZEMLYA
Scale 1:35,000,000 Ellesmere
QUEEN ELIZABETH Island
Robinson Projection Longyearbyen
Greenland Sea Svalbard NOVAYA Kara Sea Laptev Sea NEW SIBERIAN ISLANDS
standard parallels 38°N and 38°S ISLANDS (NORWAY) ZEMLYA
Banks
Barents Sea
Beaufort Sea
Island Baffin Greenland East Siberian Sea Wrangel
Barrow Bay (DENMARK) Island
Victoria
Island Baffin Jan Mayen
(NORWAY)
Norwegian Chukchi
Island Sea
Sea
Arctic Circle (66°33'') Arctic Circle (66°33'')
U. S. Great NORWAY White Sea
Mt. McKinley Bear Lake Denmark ICELAND S I B E R I A
Davis SWEDEN
TAINS
(highest point in North America, 6194 m)
+ Nuuk (Godthåb) Strait Reykjavík
Faroe
Strait Islands Gulf FINLAND Yakutsk
R U S S I A
Tórshavn (DEN.) of
Anchorage Great
Slave Lake Bothnia
Whitehorse Helsinki
UN
Oslo
60 Hudson Stockholm St. Petersburg
60
MO
Gulf of Alaska Bay Rockall Tallinn EST.
(U.K.) Bering Sea
Baltic - Nizhniy
ROCK
CANADA UNITED North Riga LAT. Yekaterinburg
Sea Novgorod
Labrador DENMARK Moscow
Sea Copenhagen LITH.
Omsk Novosibirsk Lake Sea of
Sea Belfast RUSSIA Vilnius Baikal
Minsk
L
Edmonton Okhotsk
URA
S Dublin
LAND
Isle of
POLAND Samara ALEUTIAN ISLANDS
Man (U.K.)
Amsterdam Hamburg BELARUS
TIA N IS Lake
Winnipeg IRELAND KINGDOM Warsaw Irkutsk Petropavlovsk-Kamchatskiy (U.S.)
ALEU
NETH.
Y
Berlin Astana Sakhalin
Island of London Kiev
Brussels GERMANY
Newfoundland Celtic Guernsey(U.K.) Prague A
LT
Vancouver Sea BELGIUM Luxembourg CZECH REP. UKRAINE Kharkiv AY
Jersey (U.K.)
LUX. SLOVAKIA Khabarovsk
Lake
Gulf of
Paris Bratislava
Vienna MOLDOVA KAZAKHSTAN M
T Ulaanbaatar KURIL
M O U NT A I N S
St. Lawrence LIECH. S
Superior Lake FRANCE SWITZ. AUSTRIA Budapest Chisinau
¸ Lake Balkhash . ISLANDS
)
Seattle S
Huron Bern L P Ljubljana HUNGARY
ROMANIA Sea of Gora El''brus','327eaf7f2dd9b6bc82491f3d252cfea2aed8e5e40cf6c72426b1ba58fe5aa5a8','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00b1bafc1625f65d4a96688b29d75f45bf67e4a73203ac378b924e61be16b34b',2000,'MN','Mongolia','raw',2,'Ottawa Montréal St. Pierre Bay of A SLOVENIA Odesa Azov (highest point in Europe, Aral
Minneapolis Lake and Miquelon Biscay Milan SAN Zagreb
CROATIA Belgrade
Bucharest 5633 m) Sea
Michigan RT occupied by the SOVIET UNION in 1945,
Toronto Lake Ontario
(FRANCE)
MONACO MARINO BOS. & HERZ.
SE
Serbia CAU
Caspian DE administered by RUSSIA, claimed by JAPAN
Black Sea
NORTH ITALY Sarajevo Mont. Sofia + C AS Ürümqi I Sapporo
UNITED OB
Detroit Marseille GEORGIA
US
MT Sea
Boston Corsica Podgorica BULGARIA UZBEKISTAN G
S.
Bishkek Shenyang
NORTH
ANDORRA T''bilisi (lowest point in
NS (FR.) VATICAN
Skopje ·Istanbul
Chicago AI CITY
Rome ALB. Europe, -28 m)
KYRGYZSTAN Sea of
Lake Erie NT Madrid Barcelona Tirana ARMENIA AZERBAIJAN Beijing
PACIFIC
U PORTUGAL NORTH KOREA Japan
Denver O New York THE FORMER YUGOSLAV
Ankara Tashkent
M
Philadelphia SPAIN Sardinia
REPUBLIC OF MACEDONIA
Yerevan Baku TURKMENISTAN TAKLA MAKAN
P''yongyang
PACIFIC
BALEARIC
Lisbon
)
GREECE ·Izmir TURKEY Dushanbe
NORTH
(IT.)
ISLANDS Tianjin
OCEAN
San Francisco STATES LA
CH
I AN
Washington, D.C. AZORES
(PORT.)
(SP.)
Sicily Athens ¯
Ashgabat TAJIKISTAN DESERT
Seoul JAPAN
OCEAN
Death Valley A
PP Algiers Tunis MALTA
(IT.)
Aleppo Indian
Yellow SOUTH Tokyo
ATLANTIC
(lowest point in Gibraltar(U.K.)
North America, -86 m) A
Ceuta (SP.) Valletta Nicosia Mashhad claim
KOREA -','1cebec7cfa74abc6cf14c64251e43a89fe71d5e24d5b2f2a746d933921d68023','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6e1daa7d14262dff54f2eb1d14cf0896f9a073d532ca22c6fdc55782a5f5ee1',2000,'CN','China','raw',3,'+
SYRIA Tehran
¯ Kabul Sea Osaka
Melilla TUNISIA Crete Pusan Yokohama
Los Angeles Atlanta E MADEIRA
Casablanca
(SP.)
Mediterranean Sea (GR.) CYPRUS
Beirut
LEB.
Damascus IRAQ Chinese line
Dallas G ISLANDS Rabat AFGHANISTAN Islamabad
Tijuana','34e14949215fac8a9197fe26334e9b44c9f57514d848a16f263413cabe19da93','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6420a3636b0d9a653926dd1d61371b9be68a6098b24290f30595d6b181e0a9fe',2000,'BM','Bermuda','raw',4,'(U.K.) OCEAN D (PORT.)
Tripoli Alexandria ISRAEL Amman
Baghdad
IRAN
¯ ¯ ¯ of control
Lahore
H
IM Mt. Everest
NA
Shanghai
I
Jerusalem + Dead Sea (lowest point in Asia, -408 m) (highest point in Asia Chengdu
MOROCCO Wuhan
R
JORDAN AL
M
D S
and the world, 8848 m)
Houston Cairo
30 AY 30
PO
CANARY ISLANDS KUWAIT New
-
Chongqing East China
L A N
(SP.)
ALGERIA Kuwait AS
(JA
I C
Delhi NEPAL BHUTAN Sea
- S','be71b0752bba0cd6f5956c63168a58041e687879db077dac8173cadcc1de7d60','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc33115411d545b25027b2cf89a667672b2431325ff328b5a5b8d3ac482ca204',2000,'PK','Pakistan','raw',5,'PA
+
LIBYA Midway
N
- -
HO
Persian
IS
Laayoune
SAUDI Kathmandu
)
T
Thimphu
)
THE Okinawa
(El Aaiún)
EGYPT BAHRAIN Gulf Islands
AN
Miami OMAN -
TO
Kanpur
N
Gulf of Mexico Manama
-
BAHAMAS Western Doha (U.S.)
AP
Monterrey Taipei
U
Riyadh Abu Dhabi Marcus Island
Y
(J
L A
Nassau Sahara ¯
Karachi BANGLADESH U
K
(JAPAN)
Tropic of Cancer (23°27'') Havana QATAR UNITED ARAB R
Y Tropic of Cancer (23°27'')
EMIRATES Muscat
Red Dhaka','c2b041f4efbac7541059f04a901e489aca686988115f8ab784c2ea81c115095c','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08819a75837c0969cc039f1f5580f52e4db6ad940386999c004418107e2ecbf0',2000,'MX','Mexico','raw',6,'Turks and Milwaukee Deep
ARABIA - -
Ahmadabad Calcutta Taiwan
A T
Caicos Islands (deepest point of the Sea Hong Kong
Honolulu','85fa967f6d6a9bd713f2abd3509bd809c463034e1e8f0823c606dd7eece22720','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b725a3935788111081c190de308c5ffc2697ef3df41d684a1638c8bf9b2f153',2000,'CU','Cuba','raw',7,'(U.K.) Atlantic Ocean, -8605 m)
British Virgin
S A H A R A D E S E R T Jiddah
KH
A LI
OMAN BURMA Hanoi Macau S.A.R. Luzon Strait
HAWAIIAN
INDIA S.A.R.
L
Guadalajara
Port-au- DOMINICAN
Islands
B'' A LAOS Philippine
D -
(U.K.) RU Gulf of Wake Island
ISLANDS Cayman Is. REPUBLIC Anguilla (U.K.)','512797b11fa2765559103fa9e06efe8758f70fac10cdf5718523f1986ec05f18','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8141637162cfbe221ed83ec094202ed4d809ebb1ed28bbddd7747172ff8243e3',2000,'MR','Mauritania','raw',8,'H
Mexico (U.K.) Prince +
Vientiane Tonkin Hainan (U.S.)
NC
(U.S.) Puebla ST. KITTS AND NEVIS Nouakchott Mumbai Northern
ISLAS JAMAICA
Kingston Navassa HAITI Santo Puerto
MALI (Bombay) - -
Hyderabad
Dao
Sea Mariana
ANA TRE','08e9f5c5ff74ea749f4d44494237dfb24ae24c31f14f88099741d26b3cd82e8e','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c406cf383c4c1425217def67c0911aee810aaf884c564cf490e51f6bf8dafc32',2000,'BZ','Belize','raw',9,'M I
REVILLAGIGEDO
Domingo Rico
ANTIGUA AND BARBUDA Rangoon Islands
Belmopan Bay of PARACEL','feda1c2f70eb4bde067c91e82bd83f8995b782abfa1350bf3f0fbbd426856812','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b77d149f29cc971c5a2db841fc6522279dde0f89f686995ac82ca7e6d4eeea4e',2000,'NE','Niger','raw',10,'(MEXICO) Island Guadeloupe (FR.)
Johnston Atoll (U.S.)
(U.S.) Tombouctou ERITREA (U.S.)
CAPE VERDE Khartoum Sanaa THAILAND ISLANDS
Saipan
(U.S.) GUATEMALA HONDURAS
Tegucigalpa Caribbean Sea
Montserrat DOMINICA
Dakar CHAD Asmara
YEMEN Bengal VIETNAM Manila
Arabian
(U.K.)
Martinique (FR.)
Guatemala Praia SENEGAL Niamey Bangkok Hagåtña
South China
RI
ST. VINCENT AND ST. LUCIA
Banjul Bangalore (Agana)
San Salvador Aruba Bamako BURKINA
SUDAN ANDAMAN','50c5d9692deaee86654ad380edaffa8cb5c48c3be6eb997cde665d141e507699','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b16218ca6887a45800ffac61ad49b647f403715b3edbd7b51e5d2bbfc29f416d',2000,'PH','Philippines','raw',11,'A
THE GRENADINES BARBADOS
NICARAGUA FASO
Sea Guam
M
EL SALVADOR (NETH.)
THE GAMBIA Lac ''Assal ISLANDS CAMBODIA
Neth. Antilles DJIBOUTI Gulf of Aden Chennai
Sea
(lowest point in Africa, (INDIA) (U.S.)
Managua (NETH.)
GRENADA Bissau Ouagadougou N''Djamena -155 m) Djibouti Socotra (Madras) + Challenger Deep
PHIL
(YEMEN) Ho Chi Minh City
Maracaibo Port-of-Spain
GUINEA-BISSAU GUINEA Phnom Penh (world''s greatest ocean depth, -10924 m) MARSHALL
Clipperton Island
San José
Caracas TRINIDAD AND
Conakry
BENIN NIGERIA Addis LAKSHADWEEP Andaman
Sea Gulf of FEDERATED STATES OF MICRONESIA ISLANDS
I P PI
TOBAGO Ababa EY
(INDIA)
Thailand SPRATLY
(FRANCE) COSTA RICA Panama CÔTE Abuja
Freetown TOGO LL ISLANDS
NE TR
D''IVOIRE GHANA
VA
S
PANAMA SIERRA Laccadive Koror
VENEZUELA Georgetown
LEONE
Yamoussoukro CENTRAL ETHIOPIA Colombo NICOBAR Palikir Majuro
E
Kingman Reef (U.S.) Medellín Lomé Lagos Sea ISLANDS
Isla del Coco Paramaribo AFRICAN REPUBLIC SRI Bandar Seri
E
GUYANA Monrovia Accra Porto- (INDIA) PALAU
D
(COSTA RICA)','2659a9d3e59587180984d811be7f02bfb5152617b5afba00a487ab79381c20df','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc4ac54a13682e89d433e0bcb53fc526326fdd5d551afbdc429f18b161875671',2000,'SO','Somalia','raw',12,'NC
Palmyra Atoll (U.S.) French Guiana Abidjan Begawan
T
CAMEROON LANKA
RIF
LIBERIA Novo Bangui
H
Isla de (FRANCE) BRUNEI
N
Malpelo Bogotá SURINAME Cayenne Male Kuala
Cali Malabo Medan Lumpur Celebes Sea
A
EQUATORIAL GUINEA Yaoundé MALDIVES
COLOMBIA M A L A Y S I A
AT
Penedos de Gulf of Guinea UGANDA
Kiritimati Tarawa
GRE
(Christmas Island) São Pedro e São Paulo
SAO TOME AND PRINCIPE Mogadishu Singapore Howland Island (U.S.)
Kampala
(KIRIBATI) Equator Quito
(BRAZIL)
Equator São Tome Libreville REP. OF KENYA SINGAPORE Equator Baker Island (U.S.)
0 0
Jarvis GALAPAGOS GABON THE DEMOCRATIC Nairobi Yaren NAURU
Island ECUADOR Annobon CONGO RWANDA Kigali District
ISLANDS Belém Arquipélago de Lake
(U.S.) Guayaquil Fernando de Noronha (EQUA. GUI.) REPUBLIC Mt. Kilimanjaro K I R I B A T I
(ECUADOR) Manaus Victoria + (highest point in Africa, 5895 m)
I N D O N E S I A
(BRAZIL) Brazzaville Bujumbura Bismarck Sea
Fortaleza Victoria
Kinshasa
OF THE CONGO BURUNDI British Indian
PAPUA','80a8cf339b9a2be9f336ac9d6305278ac44211c1ef7c2d318aba64948ff48130','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('484aac4f29c5678426dd38b87c423e3892c4b2ceb1f1d5b28bf50d7539509e53',2000,'AO','Angola','raw',13,'Lake Ocean Territory Jakarta Java Sea Banda Sea
PE
JA
(Cabinda)
Tanganyika TANZANIA Dar es Salaam (U.K.)
NEW GUINEA SOLOMON
V
K I R I B A T I
RU
Diego ISLANDS
A
Bandung Surabaya
ÎLES MARQUISES Ascension Luanda SEYCHELLES Garcia
T
R Funafuti
-C
Indian Ocean, -7258 m)
Lima COMOROS SAMOA
N
(Keeling) Islands Ashmore and Wallis and
Grea
INDIAN
Salvador Lilongwe
Mayotte Apia
Cartier Islands
Coral Futuna
SOUTH
(AUSTL.)
T
D
ZAMBIA (administered by FRANCE, Gulf of Mata-Utu
t
Cook Islands E
R
claimed by COMOROS) (AUSTL.)
Lago St. Helena Namibe MALAWI Carpentaria (FRANCE) Pago Pago
E
Tromelin Island
(N.Z.) S Titicaca Brasília Sea
Barrier
N
ARCHIPEL DES TUAMOTU (St. Helena) (FRANCE)
ST
Lusaka Juan de Nova FIJI American
C
La Paz Samoa
SOUTH PACIFIC ATLANTIC OCEAN','70d5a242f2a673eff3626db697324ebac59ec73883e6d4cb626428b9293643f6','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2828789bb606bc32553b2a873bd3fd9723514a6446719b8e67614f0aff6a90a',2000,'BR','Brazil','raw',14,'(St. Helena) E Arafura
(Fr. Poly.)
PERU Lake
NC East Timor
Sea Port Honiara TUVALU Tokelau
HI
Christmas Island H (N.Z.)
E
Lubumbashi +
MID-INDIAN
Nyasa Moroni Glorioso Islands Timor Moresby
A
(AUSTL.)
RIDG
LE
(deepest point of the
(FRANCE)
Cocos Sea','b03b706dd8b41b415dd72c9f264be3c539eea27146dec18fc763da4f8a23ca01','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20508aad28287f93eababbeed5849fb5758d08c3ad5b9da9d24c67c9c2705091',2000,'VU','Vanuatu','raw',15,'(Fr. Poly.) Island (FR.)
H
Papeete BOLIVIA (U.S.)
TY E A
SOCIETY Niue
ISLANDS Harare MOZAMBIQUE Antananarivo Re
ef
Coral Sea Port-Vila (N.Z.)
Suva
ALT
Belo Islands
ZIMBABWE Mozambique Port
OCEAN
NA
Horizonte
OCEAN
OC
(Fr. Poly.) (AUSTL.)
IP
Martin Vaz Saint-
CH
ATA C
F r e n c h P o l y n e s i a Channel Louis
L AN','d99552269554d20432c53e6d8145a021d88e942968515965fab0c86b964414fd','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abcfa7b396a824f6f0a7251469ea8e4f307dd41c6f886a24d6936721784634b1',2000,'TO','Tonga','raw',16,'A
Reunion
AMA
Windhoek (FRANCE)
(FRANCE)
NG
PARAGUAY Rio de Janeiro KALAHARI (FRANCE)
Noumea
TO
Tropic of Capricorn (23°27'') Walvis Bay Europa Island Tropic of Capricorn (23°27'')
N
DESERT (FRANCE)
DESERT
São Paulo Alice Springs
DESER
ÎLES TUBUAI Gaborone
R
Asunción
A U S T R A L I A
(Fr. Poly.) Pitcairn Islands Pretoria
ID
Adamstown Isla San Felíx Maputo G
(U.K.) Isla Sala y Gómez (CHILE)
St. Helena Johannesburg E
SOUTH
M I
(CHILE)
Isla San Ambrosio Mbabane
T
Easter Island (CHILE) SWAZILAND
Lake Eyre
Norfolk KERMADEC
H
LESOTHO (lowest point in Brisbane
(U.K.)
C
Island
(CHILE)
PACIFIC ISLANDS
N
Pôrto Australia, -15 m)
D - A GREAT VICTORIA
SOUTH Maseru
+ (AUSTL.)
E
Alegre (N.Z.)
R
DESERT
T
30 30
Durban','ae8aa0e99e007572180010658f8b58c418adb8e7f08b4809ced15c9dc60eb081','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97b001609da142969e1ec9e3dc4f07de8dfef9ec0518050652b551c75a49936a',2000,'CL','Chile','raw',17,'Córdoba AFRICA OCEAN
C
+
Perth
E
Lord Howe
D
Cerro Aconcagua
T L A N T I C
Island
A
(highest point in South America,','d40e0d9aa888698cdb637a917cab2581b9e2ffcca524d98cf3ef876dde7e6911','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbdbce89b33e8176fa27f56005b8476fbfd9385bbb771a699ff1239c1ec32e5d',2000,'UY','Uruguay','raw',18,'M
(AUSTL.)
R
6962 m)
Santiago
E
Buenos Aires Cape
K
ARCHIPIÉLAGO Canberra Sydney
Town
JUAN FERNÁNDEZ Montevideo Mount Kosciuszko
(CHILE)
ARGENTINA Île Amsterdam Great Australian
(highest point in
Auckland
ANDE
Australia, 2229m) +
(Fr. S. and Ant. Lands) Melbourne
TRISTAN DA CUNHA (St. Helena)
Bight NEW
Île Saint-Paul
(Fr. S. and Ant. Lands)
Tasman Sea ZEALAND
Gough Island
S
(St. Helena)
R I
Tasmania Wellington
+
Peninsula Valdés French Southern and Antarctic Lands
D G
(lowest point in South America,
(FRANCE) Christchurch
PATAGONIA
-40 m)
CHATHAM ISLANDS
(N.Z.)
E
PRINCE EDWARD ÎLES CROZET
Falkland Islands (Fr. S. and Ant. Lands) SNARES ISLANDS BOUNTY ISLANDS
ISLANDS
(Islas Malvinas) (N.Z.) (N.Z.)
(SOUTH AFRICA)
(administered by U.K., ÎLES KERGUELEN AUCKLAND ANTIPODES ISLANDS
claimed by ARGENTINA) (Fr. S. and Ant. Lands) ISLANDS (N.Z.)
(N.Z.)
Stanley Heard Island and
Bouvet Island Campbell
Punta Arenas McDonald Islands Island
(NORWAY)
(AUSTL.) (N.Z.)
Macquarie
Island
Scotia Sea South Georgia and the
South Sandwich Islands (AUSTL.)
(administered by U.K.,
claimed by ARGENTINA)
60
Drake 60
Passage SOUTH ORKNEY
ISLANDS
SOUTHERN OCEAN
SOUTHERN OCEAN
Antarctic Circle (66°33'') SOUTHERN OCEAN Antarctic Circle (66°33'')
Amery Ice
Shelf April 2000
Bellingshausen Sea Weddell Sea a
Serbia and Montenegro have asserted the formation
Amundsen Sea of a joint independent state, but this entity has
not been formally recognized as a state by the
Ross Sea Ross Sea United States.
b
Ronne Ice Shelf
Vinson Massif
+
Antarctica b Nineteen of 26 Antarctic consultative nations
have made no claims to Antarctic territory
Ross (highest point in Antarctica, 5140 m)
Ross Ice Shelf (although Russia and the United States have
Ice Shelf reserved the right to do so) and they do not
recognize the claims of the other nations.
150 120 90 60 30 0 30 60 90 120 150 180
Boundary representation is not necessarily authoritative.
802701AI (R00349) 4-00','12bd4da0aab54054988d48a667e3874c3881cc91fc0bf7bfba6931db6a770021','internet-archive','ciaworldfactbook2000','pdf','a3822b080d7975bceee2b96e0bfec956ed9ad7648210786f9c74c52587158899','https://archive.org/download/ciaworldfactbook2000/factbook/reference/Low%20res%20PDF/low802701.pdf','pdftotext') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

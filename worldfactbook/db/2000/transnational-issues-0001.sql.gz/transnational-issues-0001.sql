SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1a7beae612397923b90f2aeb3597dde8f4c3e9e25a51eeae41bc4e5c8aa4adf',2000,'EH','Western Sahara','transnational-issues',17,'Disputes - international
Illicit drugs
Background: Afghanistan was invaded and
occupied by the Soviet Union in 1 979. The USSR was
forced to withdraw 10 years later by anti-communist
mujahidin forces supplied and trained by the US,
Saudi Arabia, Pakistan, and others. Fighting
subsequently continued among the various mujahidin
factions, but the fundamentalist Islamic Taliban
movement has been able to seize most of the country.
In addition to the continuing civil strife, the country
suffers from enormous poverty, a crumbling
infrastructure, and widespread live mines.
Location: Southern Asia, north and west of
Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 652,000 sq km
land: 652,000 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan
2,430 km, Tajikistan 1 ,206 km, Turkmenistan 744 km,
Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot
summers
Terrain: mostly rugged mountains; plains in north
and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal,
copper, chromite, talc, barites, sulfur, lead, zinc, iron
ore, salt, precious and semiprecious stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other; 39% (1 993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in
Hindu Kush mountains; flooding
Environment - current issues: soil degradation;
overgrazing; deforestation (much of the remaining
forests are being cut down for fuel and building
materials); desertification
Environment - international agreements:
party to: Desertification, Endangered Species,
Environmental Modification, Marine Dumping,
Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation
Geography - note: landlocked
^ ^ e o''pT e
Population: 25,838,797 (July 2000 est.)
Age structure:
0-14 years: 42.37% (male 5,598,403; female
5,371,054)
15-64 years: 54.86% (male 7,362,961 ; female
6,839,914)
65 years and over: 2.77% (male 378,741 ; female
337,724) (2000 est.)
Population growth rate: 3.54% (2000 est.)
note: this rate reflects the continued return of refugees
from Iran
Birth rate: 41 .82 births/1 ,000 population (2000 est.)
Death rate: 18.01 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 1 .54 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 .12 male(s)/female
total population: 1.06 male(s)/female (2000 est.)
Infant mortality rate: 149.28 deaths/1,000 live
births (2000 est.)
Life expectancy at birth:
total population: 45.88 years
male: 46.62 years
female: 45.1 years (2000 est.)
Total fertility rate: 5.87 children born/woman
(2000 est.)
Nationality:
nom; Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek
6%, Hazara 19%, minor ethnic groups (Aimaks,
Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%,
other 1%
Languages: Pashtu 35%, Afghan Persian (Dari)
50%, Turkic languages (primarily Uzbek and
T urkmen) 11%, 30 minor languages (primarily Balochi
and Pashai) 4%, much bilingualism
Literacy:
definition: age 1 5 and over can read and write
total population: 31 .5%
male: 47.2%
fema/e; 15% (1999 est.)
|r G over rim e n t
Country name:
conventional long form: Islamic State of Afghanistan;
note - the self-proclaimed Taliban government refers
to the country as Islamic Emirate of Afghanistan
conventional short form: Afghanistan
local long form: Dowlat-e Esiami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Data code: AF
Government type: no functioning central
government, administered by factions
Capital: Kabul
Administrative divisions: 30 provinces (velayat,
singular - velayat); Badakhshan, Badghis, Baghlan,
Baikh, Bamian, Farah, Faryab, Ghazni, Ghowr,
Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa,
Konar, Kondoz, Laghman, Lowgar, Nangarhar,
Nimruz, Oruzgan, Paktia, Paktika, Parvan,
Samangan, Sar-e Pol, Takhar, Vardak, Zabol
note; there may be two new provinces of Nurestan
(Nuristan) and Khowst
Independence: 1 9 August 1 91 9 (from UK control
over Afghan foreign affairs)
National holiday: Victory of the Muslim Nation,
28 April; Remembrance Day for Martyrs and
Disabled, 4 May; Independence Day, 19 August
Constitution: none
Legal system: a new legal system has not been
adopted but all factions tacitly agree they will follow
Shari''a (Islamic law)
Suffrage: NA; previously males 15-50 years of age
Executive branch: on 27 September 1996, the
ruling members of the Afghan Government were
displaced by members of the Islamic Taliban
movement; the Islamic State of Afghanistan has no
functioning government at this time, and the country
remains divided among fighting factions
note; the Taliban have declared themselves the
legitimate government of Afghanistan; however, the
UN still recognizes the government of Burhanuddin
RABBANI; the Organization of the Islamic Conference
has left the Afghan seat vacant until the question of
legitimacy can be resolved through negotiations
among the warring factions; the country is essentially
divided along ethnic lines; the Taliban controls the
capital of Kabul and approximately two-thirds of the
country including the predominately ethnic Pashtun
areas in southern Afghanistan; opposing factions
have their stronghold in the ethnically diverse north
1
Afghanistan (continued)
Legislative branch: non-functioning as of June 1993
Judicial branch: non-functioning as of March 1995,
aithough there are local Shari''a (Islamic law) courts
throughout the country
Political parties and leaders: Harakat-i-lslami
(Islamic Movement) [Mohammed Asif MOHSENI];
Harakat-Inqilab-i-lslami (Islamic Revolutionary
Movement) [Mohammad Nabi MOHAMMADI]; Hizbi
Islami-Gulbuddin (Islamic Party) [Guibuddin
HIKMATYAR faction]; Hizbi Islami-Khalis (Islamic
Party) [Yunis KHALiS faction]; Hizbi Wahdat-Akbari
faction (Islamic Unity Party) [Mohammad Akbar
AKBARi]; Ittihad-i-lslami Barai Azadi Afghanistan
(Islamic Union for the Liberation of Afghanistan)
[Abdui Rasul SAYYAF]; Jabha-i-Na]at-i-Milli
Afghanistan (Afghanistan National Liberation Front)
[Sibghatullah MOJADDEDI]; Mahaz-i-Milli-lslami
(National Islamic Front) [Sayed Ahamad GAILANi];
Taliban (Religious Students Movement) [Mohammad
OMAR]; United Islamic Front for the Salvation of
Afghanistan comprised of Jumbesh-i-Melli Islami
(National Islamic Movement) [Abdul Rashid
DOSTAM]; Jamiat-i-lslami (Islamic Society)
[Burhanuddin RABBANi and Ahmad Shah MASOOD];
and Hizbi Wahdat-Khaliii faction (Isiamic Unity Party)
[Abdul Karim KHALiLI]
Political pressure groups and leaders: Afghan
refugees in Pakistan, Australia, US, and elsewhere
have organized politicaliy; Meilat (Sociai Democratic
Party) [leader NA]; Peshawar, Pakistan-based groups
such as the Coordination Council for National Unity
and Understanding in Afghanistan or CUNUA [Ishaq
GAILANI]; tribal elders represent traditional Pashtun
leadership; Writers Union of Free Afghanistan or
WUFA [A. Rasul AMIN]
International organization participation: AsDB,
CP, ECO, ESCAP, FAC, G-77, IAEA, IBRD, ICAO,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, Intelsat,
IOC, lOM (observer), ITU, NAM, OIC, OPCW, UN,
UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WMO, WToO
Diplomatic representation in the US:
note: embassy operations suspended 21 August 1 997
chief of mission: Ambassador (vacant)
chancery: 2341 Wyoming Avenue NW, Washington,
DC 20008
telephone: [m202) 234-3770
FAX; [1] (202) 328-3516
consulate(s) general: New York
Diplomatic representation from the US: the US
embassy in Kabui has been closed since January
1989 due to security concerns
Flag description: three equal horizontal bands of
green (top), white, and black with a goid emblem
centered on the three bands; the emblem features a
temple-like structure with Islamic inscriptions above
and below, encircled by a wreath on the left and right
and by a bolder Islamic inscription above, all of which
are encircied by two crossed scimitars
note: the Taiiban uses a plain white flag','2e53f7507d819a6f9648d47b4f9d77bf6ebc2b55577524c277aa53f6f3596c7f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8ac8b10291b3856acf791e3083bd37f6dbe981d8f99f46bb782f3b5fdabb531',2000,'AD','Andorra','transnational-issues',26,'Disputes - international: none
Background: Long isolated and impoverished,
mountainous Andorra has achieved considerable
prosperity since World War II through its tourist
industry. Many immigrants (legal and illegal) are
attracted to the thriving economy with its lack of
income taxes.','57a39cb8c6d9131e36538c81436a7d494eeff2883a500f124a12a7d4599ab03d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adf41c84f4f4a5dbf7d7af6bca288329fe79966a4de7f309f19da47780d81503',2000,'AI','Anguilla','transnational-issues',32,'Disputes - international: none
Illicit drugs: increasingly used as a transshipment
point for cocaine and heroin destined for Western
Europe and other African states
Disputes ■ international: none
fAntarctica
Location: continent mostly south of the Antarctic
Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
tofa/.- 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72
million sq km ice-covered) (est.)
note: fifth-largest continent, following Asia, Africa,
North America, and South America, but larger than
Australia and the subcontinent of Europe
Area - comparative: slightly less than 1 .5 times the
size of the US
Land boundaries: 0 km
note: see entry on International disputes
Coastline: 17,968 km
Maritime claims: none, but see the Disputes -
international entry
Climate: severe low temperatures vary with latitude,
elevation, and distance from the ocean; East
Antarctica is colder than West Antarctica because of
its higher elevation; Antarctic Peninsula has the most
moderate climate; higher temperatures occur in
January along the coast and average slightly below
freezing
Terrain: about 98% thick continental ice sheet and
2% barren rock, with average elevations between
2,000 and 4,000 meters; mountain ranges up to 5,140
meters; ice-free coastal areas Include parts of
southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo
Sound; glaciers form ice shelves along about half of
the coastline, and floating ice shelves constitute 11%
of the area of the continent
Elevation extremes:
lowest point: Southern Ocean 0 m
highest point: Vmson Massif 5,140 m
Natural resources: none presently exploited; iron
ore, chromium, copper, gold, nickel, platinum and
other minerals, and coal and hydrocarbons have been
found in small, uncommercial quantities
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (ice 98%, barren rock 2%)
Irrigated land: 0 sq km (1993)
Natural hazards: katabatic (gravity-driven) winds
blow coastward from the high interior; frequent
blizzards form near the foot of the plateau; cyclonic
storms form over the ocean and move clockwise along
the coast; volcanism on Deception Island and isolated
areas of West Antarctica; other seismic activity rare
and weak
Environment ■ current issues: in 1998, NASA
satellite data showed that the antarctic ozone hole
was the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased
ultraviolet light coming through the hole damages the
DNA of icefish, an antarctic fish lacking hemoglobin;
ozone depletion earlier was shown to harm one-celled
antarctic marine plants
Geography - note: the coldest, windiest, highest (on
average), and driest continent; during summer, more
solar radiation reaches the surface af the South Pole
than is received at the Equator in an equivalent period;
mostly uninhabitable
Disputes - international: Antarctic Treaty defers
claims (see Antarctic T reaty Summary in Government
type entry); sections (some overlapping) claimed by
Argentina, Australia, Chile, France (Adelie Land),
New Zealand (Ross Dependency), Norway (Queen
Maud Land), and UK; the US and most other nations
do not recognize the territorial claims of other nations
and have made no claims themselves (the US
reserves the right to do so); no formal claims have
been made in the sector between 90 degrees west
and 150 degrees west','7171e3dd48999343e6e21db519be3079381f7d8c1bf6c42a9d6fcec8d2dc75bd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64a0f02d8df516db35a7b751177c4d70b5d97ae2b6c51e9a3ec98008e8b7ca92',2000,'AG','Antigua and Barbuda','transnational-issues',37,'Background: The islands of Antigua and Barbuda
became an independent state within the British
Commonwealth of Nations in 1981 . Some 3,000
refugees fleeing a volcanic eruption on nearby
Montserrat have settled in Antigua and Barbuda since
1995.','4a2f0fe128c626fdd45fef4ea6c38945de3dbe17cef9dc3ccbcda253bcc183fb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77964db0f15027134e490e455b960afd1c00f55e1205871381942a5fe9f64955',2000,'BS','Bahamas','transnational-issues',62,'Disputes - international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for US and Europe; banking industry
vulnerable to money laundering','a579058c00fd3f87f06f6fc07ee4fe9bec160436fb3a91be39f1813f95de920c','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29c5cbaa6a1dcda4d4d52489db07322e929644633f06c56e498c8a258cf77c72',2000,'BH','Bahrain','transnational-issues',63,'Background: Bahrain''s small size and central
location among Persian Gulf countries require it to
play a delicate balancing act in foreign affairs among
its larger neighbors. Possessing minimal oil reserves,
Bahrain has turned to petroleum processing and
refining, and has transformed itself into an
international banking center. The new amir is pushing
economic and political reforms, and has worked to
improve relations with the Shi''a community.','ad22aaa16c4b3aa2cd6118ec2527d6c361944c0466bc87d9fb12ea2174c4ad67','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6ffde2e41af3a6e0c18381407b6560021dd07aecff127beb765f59291f68eb7',2000,'BY','Belarus','transnational-issues',72,'Background: After seven decades as a constituent
Disputes - internationai: ciaimed by Madagascar repubiic of the USSR, Beiarus attained its
independence in 1991. It has retained cioser poiiticai
and economic ties to Russia than any of the other
former Soviet repubiics. Belarus and Russia signed a
treaty on a two-state union on 8 December 1999
envisioning greater political and economic integration
but, to date, neither side has actively sought to
implement the accord.
Disputes - International: none
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for the domestic market;
transshipment point for illicit drugs to and via Russia,
and to the Baltics and Western Europe
0 20 40 km
0 20 40 mi
f Introduction
Background: Belgium became independent from
the Netherlands in 1830 and was occupied by
Germany during World Wars I and II. It has prospered
in the past half century as a modern, technologically
advanced European state and member of NATO and
the EU. Tensions between the Dutch-speaking
Flemings of the north and the French-speaking
Walloons of the south have led in recent years to
constitutional amendments granting these regions
formal recognition and autonomy.
I Geography
Location: Western Europe, bordering the North Sea,
between France and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
total: 30,510 sq km
land: 30,230 sq km
water: 280 sq km
Area - comparative: about the size of Maryland
Land boundaries:
total: 1 ,385 km
border countries: France 620 km, Germany 167 km,
Luxembourg 148 km, Netherlands 450 km
Coastline: 66 km
Maritime claims:
continental shelf: median line with neighbors
exclusive fishing zone: median line with neighbors
(extends about 68 km from coast)
territorial sea: 12 nm
Climate: temperate; mild winters, cool summers;
rainy, humid, cloudy
Terrain: fiat coastal plains in northwest, central
rolling hills, rugged mountains of Ardennes Forest in
southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
48
Bolgium (continued)
Natural resources; coal, natural gas
Land use:
arable land: 24%
permanent crops: 1 %
permanent pastures: 20%
forests and woodland: 21 %
other: 34%
Irrigated land; NAsqkm
Natural hazards: flooding Is a threat in areas of
reclaimed coastal land, protected from the sea by
concrete dikes
Environment - current issues: the environment is
exposed to intense pressures from human activities:
urbanization, dense transportation network, industry,
intense animal breeding and crop cultivation; air and
water pollution also have repercussions for
neighboring countries; uncertainties regarding federal
and regional responsibilities (now resolved) have
impeded progress in tackling environmental
challenges
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulphur 85,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Ciimate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Air Pollution-Volatile Organic
Compounds, Climate Change-Kyoto Protocol
Geography - note; crossroads of Western Europe;
majority of West European capitals within 1 ,000 km of
Brussels which is the seat of both the EU and NATO
F^VpTe .
Population: 1 0,241 ,506 (July 2000 est.)
Age structure;
0- 14 years: 1 8% (male 91 9,445; female 877,896)
15-64 years: 66% (male 3,386,193; female
3,334,081)
65 years and over: 1 6% (male 701 ,842; female
1,022,049) (2000 est.)
Population growth rate: 0.18% (2000 est.)
Birth rate: 10.91 births/1,000 population (2000 est.)
Death rate: 1 0.1 3 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0.98 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.% male(s)/female (2000 est.)
Infant mortality rate: 4.76 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.8 years
male: 74.47 years
female: 81 .3 years (2000 est.)
Total fertility rate: 1.61 children born/woman
(2000 est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 58%, Walloon 31%, mixed
or other 11%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Dutch 58%, French 32%, German 1 0%,
legally bilingual
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: NA%
female: NA%
p Gov eTiTiriTn t
Country name:
conventional long form: Kingdom of Belgium
conventional short form: Beigium
local long form: Royaume de Belgique/Koninkrijk
Belgie
local short form: Belgique/Belgie
Data code: BE
Government type: federal parliamentary
democracy under a constitutional monarch
Capital: Brussels
Administrative divisions: 10 provinces (French:
provinces, singular - province; Flemish: provincien,
singular - provincie); Antwerpen, Brabant Wallon,
Hainaut, Liege, Limburg, Luxembourg, Namur,
Oost-Vlaanderen, Vlaams Brabant, West-Vlaanderen
note: the Brussels Capital Region is not included
within the 10 provinces
Independence: 4 October 1830 (from the
Netherlands)
National holiday; National Day, 21 July (ascension
of King LEOPOLD I to the throne in 1831)
Constitution: 7 February 1831, last revised 14 July
1993; parliament approved a constitutional package
creating a federal state
Legal system; civil law system influenced by English
constitutional theory; judicial review of legislative acts;
accepts compulsory 1C J jurisdiction, with reservations
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: King ALBERT II (since 9 August 1993);
Heir Apparent Prince PHILIPPE, son of the monarch
head of government: Prime Minister Guy
VERHOFSTADT (since 13 July 1999)
cabinet: Council of Ministers appointed by the
monarch and approved by Parliament
elections: none; the monarch is hereditary; prime
minister appointed by the monarch and then approved
by Parliament
note: government coalition - VLD, PRL, PS, SP,
AGALEV, and ECOLO
Legislative branch; bicameral Parliament consists
of a Senate or Senaat in Dutch, Senat in French (71
seats; 40 members are directly elected by popular
vote, 31 are indirectly elected; members serve
four-year terms) and a Chamber of Deputies or Kamer
van Volksvertegenwoordigers in Dutch, Chambre des
Representants in French (150 seats; members are
directly elected by popular vote on the basis of
proportional representation to serve four-year terms)
elections: Senate and Chamber of Deputies - last held
1 3 June 1 999 (next to be held in NA 2003)
election results: Senate - percent of vote by party -
VLD 15.4%, CVP 14.7%, PRL 10.6%, PS 9.7%, VB
9.4%, SP 8.9%, ECOLO 7.4%, AGALEV 7.1%, PSC
6.0%, VU 5.1%; seats by party - VLD 1 1 , CVP 10, PS
1 0, PRL 9, VB 6, SP 6, ECOLO 6, AGALEV 5, PSC 5,
VU 3; Chamber of Deputies - percent of vote by party -
VLD 14.3%, CVP 14.1%, PS 10.2%, PRL 10.1%, VB
9.9%, SP 9.5%, ECOLO 7.4%, AGALEV 7.0%, PSC
5.9%, VU 5.6%; seats by party - VLD 23, CVP 22, PS
19, PRL 18, VB 15, SP 14, ECOL0 11, PSC 10,
AGALEV 9, VU 8, FN 1
note: as a result of the 1993 constitutional revision
that furthered devolution into a federal state, there are
now three levels of government (federal, regional, and
linguistic community) with a complex division of
responsibilities; this reality leaves six governments
each with its own legislative assembly; for other
acronyms of the listed parties see Political parties and
leaders
Judicial branch: Supreme Court of Justice or Hof
van Cassatie in Dutch, Cour de Cassation in French,
judges are appointed for life by the Belgian monarch
Political parties and leaders; AGALEV (Flemish
Greens) [Wilfried BERVOETSj; ECOLO
(Francophone Greens) [no president]; Flemish
Christian Democrats or CVP (Christian People''s
Party) [Stefaan DE CLERCK, president]; Flemish
Liberal Democrats or VLD [Karel DE GUCHT,
president]; Flemish Socialist Party or SP [Patrick
JANSSENS, president]; Francophone Christian
Democrats or PSC (Social Christian Party) [Joelle
MILQUET, president]; Francophone Democratic Front
or FDF [Olivier MAINGAIN, president]; Francophone
Liberal Reformation Party or PRL [Daniel DUCARME,
president]; Francophone Socialist Party or PS [Elio Dl
RUPO, president]; National Front or FN [Dr. FERET];
Vlaams Blok or VB [Frank VANHECKE]; Volksunie or
VU [Geert BOURGEOIS, president]; other minor
parties
Political pressure groups and leaders; Christian
and Socialist Trade Unions; Federation of Belgian
Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and
the legal and medical professions; various
organizations represent the cultural interests of
Flanders and Wallonia; various peace groups such as
the Flemish Action Committee Against Nuclear
Weapons and Pax Christ!
International organization participation: ACCT,
AfDB, AsDB, Australia Group, Benelux, BIS, CCC,
CE. CERN, EAPC, EBRD, ECE, EIB, EMU, ESA, EU,
FAO, G- 9, G-10, lADB, IAEA, IBRD, ICAO, ICC,
ICFTU, ICRM, IDA, lEA, IFAD, IFC, IFRCS, IHO, ILO,
IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM, ISO,
49
Bsigium (continued)
ITU, NATO, NEA, NSG, OAS (observer), OECD,
OPCW, OSCE, PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNMIK, UNMOGIP, UNMOP,
UNRWA, UNTSO, UPU, WADB (nonregional), WCL,
WEU, WHO, WlPO, WMO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Alexis REYN
chancery: 3330 Garfield Street NW, Washington, DC
20008
teiephone:[t]{202) 333-6900
FAX; [1] (202) 333-3079
consulate(s) general: Atlanta, Chicago, Los Angeles,
and New York
Diplomatic representation from the US;
chief of mission: Ambassador Paul CEJAS
embassy: 27 Boulevard du Regent, B-1000 Brussels
mailing address: PSC 82, Box 002, APO AE 0971 0
fe/ep/7one;[32](2) 508-2111
FAX; [32] (2)511-2725
Flag description: three equal vertical bands ot black
(hoist side), yellow, and red; the design was based on
the flag ot France
Disputes - international: disputes with Serbia over
Serbian populated areas of Bosnia and Herzegovina
Illicit drugs: minor transit point for marijuana and
opiate trafficking routes to Western Europe
64
Background: Formerly the British protectorate of
Bechuanaland, Botswana adopted its new name upon
independence in 1966. The economy, closely tied to
South Africa''s, is dominated by cattle raising and
mining.
f - 3 pYy''
Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
wafer; 15,000 sq km
Area - comparative: siightly smaller than Texas
Land boundaries:
fofa/;4,013 km
border countries: Namibia 1,360 km. South Africa
1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominantly flat to gently rolling tableland;
Kalahari Desert in southwest
Elevation extremes:
towesfpo/nf; junction of the Limpopo and Shashe
Rivers 51 3 m
highest poinblsodWo Hiils 1,489 m
Natural resources: diamonds, copper, nickel, salt,
soda ash, potash, coal, iron ore, silver
Land use:
arable land: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 47%
offjer;6%(1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: periodic droughts; seasonal
August winds blow from the west, carrying sand and
dust across the country, which can obscure visibility
Environment - current issues: overgrazing;
desertification; limited fresh water resources
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, NuciearTest Ban, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; population
concentrated in eastern part of the country
I '' P e oT^r e "
Population: 1,576,470
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would othenwise be
expected (July 2000 est.)
Age structure:
0- 14 years: 41 % (male 321 ,766; female 31 8,304)
15-64 years: 55% (male 417,734; female 453,947)
65 years and over: 4% (male 26,436; female 38,283)
(2000 est.)
Population growth rate: 0.76% (2000 est.)
Birth rate: 29.63 births/1 ,000 population (2000 est.)
Death rate: 22.08 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 61 .68 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 39.27 years
male: 38.63 years
female: 39.93 years (2000 est.)
Total fertility rate: 3.8 children bom/woman
(2000 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Batswana 95%, Kalanga, Basarwa,
and Kgalagadi 4%, white 1%
Religions: indigenous beliefs 50%, Christian 50%
Languages: English (official), Setswana
Literacy:
definition: age 15 and over can read and write
total popuiation: 69.8%
male: 80.5%
female: 59.9% (1995 est.)
Country name:
conventional long form: Republic of Botswana
conventional short form: Botswana
former: Bechuanaland
Data code: BC
Government type: parliamentary republic
Capital: Gaborone
Administrative divisions: 1 0 districts and four town
councils*; Central, Chobe, Francistown*, Gaborone*,
Ghanzi, Kgalagadi, Kgatleng, Kweneng, Lobatse*,
Ngamiland, North-East, Selebi-Pikwe*, South-East,
Southern
Independence: 30 September 1966 (from UK)
National holiday: Independence Day, 30
September (1966)
Constitution: March 1965, effective 30 September
1966
Legal system: based on Roman-Dutch law and local
customary law; judicial review limited to matters of
interpretation; has not accepted compulsory iCJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Festus MOGAE (since 1 April
1998) and Vice President Seretse Ian KHAMA (since
NA April 1 998); note - the president is both the chief of
state and head of government; vice president KHAMA
is on a one-year leave of absence, effective 1 January
2000, but retains the title of vice president
head of government: President Festus MOGAE
(since 1 April 1998) and Vice President Seretse Ian
KHAMA (since NA April 1998); note - the president is
both the chief of state and head of government; vice
president KHAMA is on a one-year leave of absence,
effective 1 January 2000, but retains the title of vice
president
cabinet: Cabinet appointed by the president
elections: president elected by the National Assembly
for a five-year term; election last held 1 6 October 1 999
(next to be held NA October 2004); vice president
appointed by the president
eiection resuits: Festus MOGAE elected president;
percent of National Assembly vote - 61.3%
Legislative branch: bicameral Parliament consists
of the House of Chiefs (a largely advisory 1 5-member
body consisting of the chiefs of the eight principal
tribes, four elected subchiefs, and three members
selected by the other 12) and the National Assembly
(44 seats, 40 members are directly elected by popular
vote and 4 appointed by the majority party; members
serve five-year terms)
elections: National Assembly - elections last held 16
October 1999 (next to be held NA October 2004)
election results: percent of vote by party - BDP 61 .3%,
other 38.7%; seats by party - BDP 33, other 7
Judicial branch: High Court; Court of Appeal
Political parties and leaders: Botswana
Democratic Party or BDP [Festus MOGAE]; Botswana
National Front or BNF [Kenneth KOMAj; Botswana
Congress Party or BCP [Michael DINGAKEj;
65
Botswana (continued)
Botswana People''s Party or BPP [Knight MARIPE]
note: main parties are: BDP, BNF, BCP; other minor
parties joined forces in 1 999 to form the Botswana
Alliance Movement or BAM [Kenneth KOMA,
chairman] but did not capture any parliamentary
seats; the BAM parties are: the United Action Party
[Ephraim Lepetu SETSHWAELO], the Social
Democratic Union, the Independence Freedom Party
[Motsamai MPHO], and the Botswana Progressive
Union [Gideon KAELO]
International organization participation: ACP,
AfDB, C, CCC, EGA, FAO, G-77, IBRD, ICAO, iCFTU,
iCRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, Intelsat,
Interpol, IOC, ISO, ITU, NAM, OAU, OPCW, SACU,
SADC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL,
WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Kgosi SEEPAPITSO IV
chancery; 1531-1533 New Hampshire Avenue NW,
Washington, DC 20036
fe/ephone;[1] (202) 244-4990
FAX; [1] (202) 244-4164
Diplomatic representation from the US:
ch/ef of m/ss/on; Ambassador John E. LANGE
embassy: address NA, Gaborone
mailing address: P. 0. Box 90, Gaborone
fe/ephone; [267] 353982
FAX; [267] 356947
Flag description: light blue with a horizontal
white-edged black stripe in the center
Disputes ■ international: dispute with Namibia over
uninhabited Kasikili (Sidudu) Island in Linyanti
(Chobe) River resolved by the ICJ in favor of
Botswana (13 December 1999); at least one other
island in Linyanti River is contested
66
|Bouvet Island
l (temtory of Norway)
0 1 2 km
0 1 2 mi
South Atlantic Ocean
I . . gTo graph y "
Location: Southern Africa, island in the South
Atiantic Ocean, south-southwest of the Cape of Good
Hope (South Africa)
Geographic coordinates; 54 26 S, 3 24 E
Map references; Antarctic Region
Area:
total: 58.5 sq km
land: 58.5 sq km
wafer; 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; maximum eievation about 800 m;
coast is mostiy inaccessible
Elevation extremes;
lowest point: Southern Ocean 0 m
highest point: unnamed location 780 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (93% ice)
Irrigated land: 0sqkm(1993)
Natural hazards: NA
Environment - current issues; NA
Geography - note: covered by glacial ice; declared
a nature resen/e
I People
Population: uninhabited (July 2000 est.)
telephone-{375] 223434, 223517
FAX-1375] 261944, 272339
established-^ December 1991
effective— 2t December 1991
a/m— to coordinate intercommonwealth
relations and to provide a mechanism for the
orderly dissolution of the USSR
members— (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
Commonwealth of Nations
see Commonwealth (C)
Communaute Economique de I''Afrique de
I''Ouest (CEAO)
see West African Economic Community (CEAO)
Communaute Economique des Etats de
I''Afrique Centrale (CEEAC)
see Economic Community of Central African States (CEEAC)
Communaute Economique des Pays des
Grands Lacs (CEPGL)
see Economic Community of the Great Lakes Countries (CEPGL)
communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the
Soviet model; most of the original and the successor states are no longer communist; see centrally planned
economies
Conference on Security and Cooperation in
Europe (CSCE)
see Organization for Security and Cooperation in Europe (OSCE)
Conseil Europeenne pour la Recherche
Nucleaire (CERN)
see European Organization for Nuclear Research (CERN)
Contadora Group (CG)
established 5 January 1983 (on the Panamanian island of Contadora) to reduce tensions and conflicts in Central
America; members included Colombia, Mexico, Panama, Venezuela; has evolved into the Rio Group (RG)
Cooperation Council for the Arab States of
the Gulf
see Gulf Cooperation Council (GCC)
574
I
Appendix C: International Organizations and Groups (continued)
575
Appendix C: International Organizations and Groups (continued)
countries in transition a new term used by the international Monetary FUND (IMF) for the middle group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
28 countries in transition: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech
Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of
Macedonia, Moldova, Mongolia, Poland, Romania, Russia, Serbia and Montenegro, Slovakia, Slovenia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan; note— this group is identical to the group traditionally referred to as the "former
USSR/Eastern Europe" except for the addition of Mongolia
members— (145) Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bangladesh, Belarus, Belgium, Bermuda, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cameroon, Canada, Cape Verde, Central African Republic, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Egypt, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guyana, Haiti, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liberia, Libya,
Lithuania, Luxembourg, Macau, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
developed countries (DCs) the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and
less developed countries (LDCs); includes the market-oriented economies of the mainly democratic nations in the
Organization for Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and the
European ministates; also known as the First World, high-income countries, the North, industrial countries; generally
have a per capita GDP in excess of $1 0,000 although four OECD countries and South Africa have figures well under
$10,000 and two of the excluded OPEC countries have figures of more than $10,000; the 35 DCs are: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy
See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Mexico, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; nofe— similar to the new
International Monetary Fund (IMF) term "advanced economies” which adds Hong Kong, South Korea, Singapore,
and Taiwan but drops Malta, Mexico, South Africa, and Turkey
developing countries a new term used by the International Monetary FUND (IMF) for the bottom group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently publi','644983967219eb0639112d0d09951a0e7d2f38b65012b98a591397c30b58c0be','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('607d00ec06b4d1ee46552fd8a6d0c262141c39518fa5b6018df92d0e013695a6',2000,'BY','Belarus','transnational-issues',73,'shed IMF statistics include the following
126 developing countries: Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique, Namibia,
Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa,
Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; nofe— this category would
presumably also cover the following 46 other countries that are traditionally included in the more comprehensive
group of "less developed countries": American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands,
Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia,
Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Jersey, North Korea, Macau, Isle of
Man, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands,
Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and
Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
Customs Cooperation Council (CCC)
nofe— also known as World Customs
Organization (WCO)
address— Rue du Marche 30, B-1210 Brussels,','aaef6288d45739ab762fa51bfce5a00dedff22b854e42df019f71db3ba2c413f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f57527f90af607b96e8d3d200e19321f2a4e1a768a56ee8cc93f2448ab766cec',2000,'IO','British Indian Ocean Territory','transnational-issues',94,'Disputes - international: possibly involved in a
complex dispute over the Spratly Islands with China,
Malaysia, Philippines, Taiwan, and Vietnam; in 1984,
Brunei established an exclusive fishing zone that
encompasses Louisa Reef in the southern Spratly
Islands, but has not publicly claimed the island
74
Bulgaria B
I ri Tf 0 d u c f i 0 n
Background; Having fought on the losing side in
both World Wars, Bulgaria fell within the Soviet sphere
of influence and became a People''s Republic in 1946.
Communist domination ended in 1991 with the
dissolution of the USSR, and Bulgaria began the
contentious process of moving toward political
democracy and a market economy while combating
inflation, unemployment, corruption, and crime. Today,
reforms and democratization keep Bulgaria on a path
toward eventual integration into the EU and NATO.
I . ~G e "o g r a p h y" " '' “
Location; Southeastern Europe, bordering the Black
Sea, between Romania and Turkey
Geographic coordinates; 43 00 N, 25 00 E
Map references; Europe
Area;
tofa/;110,910sq km
/and; 11 0,550 sq km
water: 360 sq km
Area - comparative; slightly larger than Tennessee
Land boundaries;
total: 1 ,808 km
border countries: Greece 494 km, The Former
Yugoslav Republic of Macedonia 148 km, Romania
608 km, Serbia and Montenegro 318 km (all with
Serbia), Turkey 240 km
Coastline; 354 km
Maritime claims;
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate; temperate; cold, damp winters; hot, dry
summers
Terrain; mostly mountains with lowlands in north and
southeast
Elevation extremes;
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources; bauxite, copper, lead, zinc, coal,
timber, arable land
Land use;
arable land: 43%
permanent crops: 2%
permanent pastures: 14%
forests and woodland: 38%
other: 3% est.)
Irrigated land; 12,370 sq km (1993 est.)
Natural hazards; earthquakes, landslides
Environment - current issues; air pollution from
industrial emissions; rivers polluted from raw sewage,
heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical
plants and industrial wastes
Environment - international agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur 94, Climate
Change-Kyoto Protocol
Geography - note; strategic location near Turkish
Straits; controls key land routes from Europe to Middle
East and Asia
1“ '' ""Pe 0 pie"""
Population; 7,796,694 (July 2000 est.)
Age structure;
0- 14 years: 1 6% (male 623,285; female 591 ,655)
15-64 years: 68% (male 2,610,573; female
2,685,190)
65 years and over: 16% (male 546,029; female
739,962) (2000 est.)
Population growth rate; -1.16% (2000 est.)
Birth rate; 8.06 births/1,000 population (2000 est.)
Death rate; 14.63 deaths/1,000 population
(2000 est.)
Net migration rate; -5.06 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate; 1 5.1 3 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 70.91 years
male: 67.45 years
female: 74.56 years (2000 est.)
Total fertility rate; 1.13 children born/woman
(2000 est.)
Nationality;
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups; Bulgarian 83%, Turk 8.5%, Roma
2.6%, Macedonia, Armenian, Tatar, Gagauz,
Circassian, others (1998)
Religions; Bulgarian Orthodox 83.5%, Muslim 13%,
Roman Catholic 1 .5%, Jewish 0.8%, Uniate Catholic
0.2%, Protestant, Gregorian-Armenian, and other 1%
(1998)
Languages; Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy;
definition: age 15 and over can read and write
total population: 98%
male: 99%
fema/e; 98% (1999)
p Gov e r n m e n t
Country name;
conventional long form: Republic of Bulgaria
conventional short form: Bulgaria
Data code; BU
Government type; parliamentary democracy
Capital; Sofia
Administrative divisions; 9 provinces (oblasti,
singular - oblast); Burgas, Grad Sofiya, Khaskovo,
Lovech, Montana, Plovdiv, Ruse, Sofiya, Varna
Independence; 22 September 1908 (from Ottoman
Empire)
National holiday; Independence Day, 3 March
(1878)
Constitution; adopted 12 July 1991
Legal system; civil law and criminal law based on
Roman law; accepts compulsory ICJ jurisdiction
Suffrage; 18 years of age; universal
Executive branch;
chief of state: President Petar STOYANOV (since 22
January 1 997); Vice President Todor KAVALDZHIEV
(since 22 January 1997)
head of government: Chairman of the Council of
Ministers (Prime Minister) Ivan KOSTOV (since 19
May 1997); Deputy Prime Minister PeturZHOTEV
(since 21 December 1999)
cabinet: Council of Ministers elected by the National
Assembly
elections: president and vice president elected on the
same ticket by popular vote for five-year terms;
election last held 27 October and 3 November 1996
(next to be held NA 2001 ); chairman of the Council of
Ministers (prime minister) nominated by the president;
deputy prime ministers nominated by the prime
minister
eiection resuits: Petar STOYANOV elected president;
percent of vote - Petar STOYANOV 59.73%
Legislative branch; unicameral National Assembly
or Narodno Sobranie (240 seats; members elected by
popular vote to serve four-year terms)
elections: last held 19 April 1997 (next to be held NA
2001)
eiection results: percent of vote by party - UtdDF 52%,
BSP 22%, ANS 7%, Euro-left 5.5%, BBB 4.95%; seats
by party - UtdDF 137, BSP 58. ANS 19, Euro-left 14,
75
Bulgaria (continued)
BBB 12; note - seating as of May 1997: UtdDF 126,
DL 58, ANS 19, Euro-left 17, PU 1 1 , independents 9
Judicial branch: Supreme Court, chairman
appointed for a seven-year term by the president;
Constitutional Court, 12 justices appointed or elected
for nine-year terms
Political parties and leaders; Alliance for National
Salvation or ANS (coalition led mainly by Movement
for Rights and Freedoms or DPS) [Ahmed DOGAN];
Bulgarian Business Bloc or BBB [Georgi GANCHEV];
Bulgarian Socialist Party or BSP [Georgi
PURVANOV, chairman]; Democratic Left of DL
[leader NA); Euro-left [Aleksandur TOMOVj;
Movement for Rights and Freedoms or DPS (member
of LDU) [Ahmed DOGAN]; People''s Union or PU
[Anastasiya MOZER]; Union of Democratic Forces or
UtdDF (an alliance of pro-democratic parties) [Ivan
KOSTOV]
Political pressure groups and leaders; agrarian
movement; Bulgarian Agrarian National Union -
United or BZNS; Bulgarian Democratic Center;
Confederation of Independent Trade Unions of
Bulgaria or CITUB; Democratic Alliance for the
Republic or DAR; Gergiov Den; Internal Macedonian
Revolutionary Organization or IMRO; New Union for
Democracy or NUD; "Nikoia Petkov" Bulgarian
Agrarian National Union; Podkrepa Labor
Confederation; numerous regional, ethnic, and
national interest groups with various agendas
International organization participation; ACCT,
BIS, BSEC, CCC, CE, CEI, CERN, EAPC, EBRD,
ECE, EU (applicant), FAO, G- 9, IAEA, IBRD, ICAO,
ICFU, ICRM, IFC, IFRCS, IHO (pending member),
ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, lOM,
ISO, ITU, NAM (guest), NSG, OAS (observer),
OPCW, OSCE, PCA, PFP, UN, UNCTAD, UNESCO,
UNIDO, UNMIBH, UNMIK, UNMOP, UPU, WEU
(associate partner), WFTU, WHO, WlPO, WMO,
WToO, WTrO, ZC
Diplomatic representation in the US;
c/i/ef of m/ss/on; Ambassador Philip DIMITROV
charrce/y; 1621 22nd Street NW, Washington, DC
20008
telephone: [1] (202) 387-0174, 387-0365, 483-1386
FAX; [1] (202) 234-7973
consulate(s): New York
Diplomatic representation from the US:
chief of mission: Ambassador Richard MILES
embassy: 1 Saborna Street, Sofia
mailing address: American Embassy Sofia,
Department of State, Washington, DC 20521-5740
telephone: [359] (2) 980-52-41 through 48
FAX; [359] (2) 981-89-77
Flag description: three equal horizontal bands of
white (top), green, and red; the national emblem
formerly on the hoist side of the white stripe has been
removed - it contained a rampant lion within a wreath
of wheat ears below a red five-pointed star and above
a ribbon bearing the dates 681 (first Bulgarian state
established) and 1944 (liberation from Nazi control)
Illicit drugs: majorEuropeantransshIpmentpointfor
Southwest Asian heroin and, to a iesser degree.
South American cocaine for the European market;
limited producer of precursor chemicals
I ''inTtroduct jo''ll”
Background: Independence from France came to
Burkina Faso (formerly Upper Volta) in 1960.
Governmental Instability during the 1970s and 1980s
was followed by multiparty elections in the early
1990s. Several hundred thousand farm workers
migrate south every year to Cote d''Ivoire and Ghana.
1"”“ "Geo''gTaphT
Location; Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area - comparative: slightly larger than Colorado
Land boundaries;
total: 3,t 92 km
border countries: Benin 306 km, Cote d''Ivoire 584 km,
Ghana 548 km, Mali 1,000 km, Niger 628 km, Togo
126 km
Coastline; 0 km (landlocked)
Maritime claims; none (landlocked)
Climate: tropical; warm, dry winters; hot, wet
summers
Terrain; mostly flat to dissected, undulating plains;
hills in west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources; manganese, limestone, marble;
small deposits of gold, antimony, copper, nickel,
bauxite, lead, phosphates, zinc, silver
Land use;
arable land: 13%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 50%
other: 1 5% (t 993 est.)
Irrigated land: 200 sq km (1993 est.)
Natural hazards: recurring droughts
Environment - current issues: recent droughts and
desertification severely affecting agricultural activities,
population distribution, and the economy;
overgrazing; soil degradation; deforestation
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Life Conservation, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea, Nuclear
Test Ban
Geography - note: landlocked
Population: 11,946,065
note: estimates for this country explicitiy take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortaiity and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (Juiy 2000 est.)
Age structure:
0-14 years: 48% (male 2,866,361 ; female 2,822,990)
15-64 years: 49% (male 2,808,797; female
3,097,048)
65 years and over: 3% (male 1 49,474; female
201 ,395) (2000 est.)
Population growth rate: 2.71% (2000 est.)
Birth rate: 45.26 births/1 ,000 population (2000 est.)
Death rate: 17.04 deaths/1 ,000 population
(2000 est.)
Net migration rate; -1.1 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: t. 03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.74 maie(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 108.53 deaths/1 ,000 live
births (2000 est.)
life expectancy at birth:
total population: 46.73 years
male: 46.29 years
female: 47.18 years (2000 est.)
Total fertility rate: 6.44 children born/woman
(2000 est.)
Nationality;
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups; Mossi over 40%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
Religions: indigenous beliefs 40%, Muslim 50%,
Christian (mainly Roman Catholic) 10%
Languages: French (official), native African
languages belonging to Sudanic family spoken by
90% of the population
Literacy;
definition: age 15 and over can read and write
77
Burkina Faso (continued)
total population: 1 9.2%
male: 29.5%
fema/e; 9.2% (1995 est.)
i Government
Country name:
conventional long form: none
conventional short form: Burkina Faso
former: Upper Volta
Data code: UV
Government type: parliamentary
Capital: Ouagadougou
Administrative divisions: 30 provinces; Bam,
Bazega, Bougouriba, Boulgou, Boulkiemde,
Ganzourgou, Gnagna, Gourma, Houe, Kadiogo,
Kenedougou, Komoe, Kossi, Kouritenga, Mouhoun,
Namentenga, Naouri, Oubritenga, Oudalan, Passore,
Poni, Sanguie, Sanmatenga, Seno, Sissili, Soum,
Sourou, Tapoa, Yatenga, Zoundweogo
note: a new electoral code was approved by the
National Assembly in January 1997; the number of
administrative provinces was increased from 30 to 45
(Bale, Bam, Banwa, Bazega, Bougouriba, Boulgou,
Boulkiemde, Comoe, Ganzourgou, Gnagna, Gourma,
Houet, loba, Kadiogo, Kenedougou, Komandjari,
Kompienga, Kossi, Koupelogo, Kouritenga,
Kourweogo, Leraba, Loroum, Mouhoun, Nahouri,
Namentenga, Nayala, Naumbiel, Oubritenga,
Oudalan, Passore, Poni, Samentenga, Sanguie,
Seno, Sissili, Soum, Sourou, Tapoa, Tuy, Yagha,
Yatenga, Ziro, Zondomo, Zoundweogo), however, this
change has not yet been approved by the US Board
on Geographic Names
Independence: 5 August 1960 (from France)
National holiday: Anniversary of the Revolution, 4
August (1983)
Constitution: 2 June 1 991 approved by referendum;
11 June 1991 formally adopted
Legal system: based on French civil law system and
customary law
Suffrage: universal
Executive branch:
chief of state: President Captain Blaise COMPAORE
(since 15 October 1987)
head of government: Prime Minister Kadre Desire
OUEDRAOGO (since 6 February 1996)
cabinet: Council of Ministers appointed by the
president on the recommendation of the prime
minister
elections: president elected by popular vote for a
seven-year term; the president may serve unlimited
terms; election last held 15 November 1998 (next to
be held NA 2005); prime minister appointed by the
president with the consent of the legislature
election results: Blaise COMPAORE reelected
president with 88% percent of the vote, with 56% of
voter turnout
note: despite his reelection. President COMPAORE
faces a growing political crisis due to his mishandling
of an investigation into the assassination of a
newspaper editor and pressure for political reform
Legislative branch: bicameral; consists of a
National Assembly or Assembles des Deputes
Populaires (ADP) (1 1 1 seats; members are elected by
popular vote to serve five-year terms) and the purely
consultative Chamber of Representations or Chambre
des Representants (178 seats; members are
appointed to serve three-year terms)
elections: National Assembly election last held 1 1
May 1 997 (next to be held NA 2002)
election results: percent of vote by party - NA; seats
by party - CDP 1 01 , PDP 6, RDA 2, ADF 2
Judicial branch: Supreme Court; Appeals Court
Political parties and leaders: African Democratic
Rally or RDA [Gerard Kango OUEDRAOGO, Clement
SANOU]; Alliance for Democracy and Federation or
ADF [Herman YAMEOGO]; Congress for Democracy
and Progress or CDP [Din Salif SAWADAGO]; Group
for Progressive Democrats or GDP [Issa
TIENDREBEOGO]; Movement for Tolerance and
Progress or MTP [Noyabtigungu Congo KABORE];
Party for African Independence or PAI [leader NA];
Party for Democracy and Progress or PDP [Joseph
KI-ZERBO]; Party for Progress and Social
Development or PPDS [leader NA); Union of Greens
for the Development of Burkina Faso or UVDB [Ram
OVEDRAGO]
Political pressure groups and leaders: Burkinabe
General Confederation of Labor or CGTB; Burkinabe
Movement for Human Rights or HBDHP; Group of 14
February; National Confederation of Burkinabe
Workers or CNTB; National Organization of Free
Unions or ONSL; watchdog/political action groups
throughout the country in both organizations and
communities
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, Entente, FAO, FZ,
G-77, IAEA, IBRD, ICAO. ICC, ICFTU, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, ILO, IMF, Intelsat, Interpol,
IOC, ITU, NAM, OAU, OIC, OPCW, PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU, WADB, WADB
(regional), WAEMU, WCL, WFTU, WHO, WlPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Bruno ZIDOUEMBA
chancery: 2340 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 332-5577
FAX; [11(202) 667-1882
Diplomatic representation from the US:
chief of mission: Ambassador Jimmy J. KOLKER
embassy: Avenue Raoul Follerau, Ouagadougou
mailing address: 01 B. P. 35, Ouagadougou
telephone: [226] 306723 through 306725
FAX; [226] 303890
Flag description: two equal horizontal bands of red
(top) and green with a yellow five-pointed star in the
center; uses the popular pan-African colors of','73873060a3324b396b6c849752daeae482d990bf497c0ac0f67256aebdee668e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eeb3e7a7d3488c84107348b39b2dec043547f3059922698dd3014accb959422',2000,'ET','Ethiopia','transnational-issues',101,'Disputes - international; offshore islands and
sections of the boundary with Vietnam are in dispute;
maritime boundary with Vietnam not defined; parts of
border with Thailand are indefinite; maritime boundary
with Thailand not clearly defined
Illicit drugs: transshipment site for Golden Triangle
heroin; possible money laundering; narcotics-related
corruption reportedly involving some in the
government, military, and police; possible small-scale
opium, heroin, and amphetamine production; large
producer of cannabis for the international market
Disputes ■ internationai: none
212
Background; Guyana achieved independence from
the UK in 1966 and became a republic in 1970. In
1989 Guyana launched an Economic Recovery
Program, w/hich marked a dramatic reversal from a
state-controlled, socialist economy towards a more
open, free market system. Results through the first
decade have proven encouraging.
I G e (TgTa pTiY”
Location: Northern South America, bordering the
North Atlantic Ocean, between Suriname and
Venezuela
Geographic coordinates; 5 00 N, 59 00 W
Map references: South America
Area;
total: 2U, 970 sqkm
/and; 196,850 sqkm
wafer; 18,120 sq km
Area - comparative: slightly smaller than Idaho
Land boundaries:
total: 2,462 km
border countries: Brazil 1 ,1 1 9 km, Suriname 600 km,
Venezuela 743 km
Coastline; 459 km
Maritime claims:
continental shelf: 200 nm or to the outer edge of the
continental margin
exclusive fishing zone: 200 nm
fernfor/a/sea;12nm
Climate: tropical; hot, humid, moderated by
northeast trade winds; two rainy seasons (May to
mid-August, mid-November to mid-January)
Terrain: mostly rolling highlands; low coastal plain;
savanna in south
Elevation extremes:
/owesf po/nf; Atlantic Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources; bauxite, gold, diamonds,
hardwood timber, shrimp, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 6%
forests and woodland: 84%
of/rer; 8% (1993 est.)
Irrigated land; 1 ,300 sq km (1 993 est.)
Natural hazards: flash floods are a constant threat
during rainy seasons
Environment - current issues: water pollution from
sewage and agricultural and industrial chemicals;
deforestation
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
pVopi e“^''
Population: 697,286
note: estimates for this country explicitly take Into
account the effects of excess mortality due to AIDS;
this can result In lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 29% (male 102,463; female 98,492)
15-64 years: 66% (male 232,857; female 229,598)
65 years and over: 5% (male 15,170; female 18,706)
(2000 est.)
Population growth rate: -0.1% (2000 est.)
Birth rate: 17.94 births/1,000 population (2000 est.)
Death rate; 8.42 deaths/1 ,000 population
(2000 est.)
Net migration rate: -10.48 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 .01 male(s)ilemale (2000 est.)
Infant mortality rate: 39.07 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 64.04 years
male: 61 .08 years
female: 67.15 years (2000 est.)
Total fertility rate: 2.11 children born/woman
(2000 est.)
Nationality;
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 51%, black 30%, mixed
14%, Amerindian 4%, white and Chinese 1%
Religions: Christian 50%, Hindu 33%, Muslim 9%,
other 8%
Languages: English, Amerindian dialects. Creole,
Hindi, Urdu
Literacy:
definition: age 15 and over has ever attended school
totai popuiation: 98. 1 %
male: 98.6%
fema/e; 97.5% (1995 est.)
f™ ~ ~gTv e r n nTeli t
Country name;
conventional long form: Co-operative Republic of
telephone-{25t] (1) 51 72 00
FAX-^251](1)51 4416
established— 29 Aprii 1958
aim— to promote economic deveiopment as a
regionai commission of the UN''s Economic and
Social Council
members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda,
Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania,
Togo, Tunisia, Uganda, Zambia, Zimbabwe
associate members— (2) France, UK
Economic Commission for Asia and the Far
East (ECAFE)
see Economic and Social Commission for Asia and the Pacific (ESCAP)
Economic Commission for Europe (ECE)
address— Palais des Nations, CH-121 1 Geneva
10, Switzerland
fe/ephone-[41](22)9174444
F/4X-[41] (22) 917 0505
established— 28 March 1947
aim— to promote economic development as a
regional commission of the UN''s Economic and
Social Council
members— (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Hungary, Iceland, Ireland, Israel, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia
Economic Commission for Latin America
(ECLA)
see Economic Commission for Latin America and the Caribbean (ECLAC)
Economic Commission for Latin America
and the Caribbean (ECLAC)
address— Edificio Naciones Unidas, Avenida
Dag Hammarskjold, Casilla 179 D, Santiago,','320699ebd5d0ffa211a6b6ae3a400deb6c202d6edf28325a0a48c90ba6cc6f02','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1b8d58942bda43650494f4e6e6e0aa6c8bb9b96bc0c5a3dc394ca146252262e',2000,'CM','Cameroon','transnational-issues',102,'Background: The former French Cameroon and
part of British Cameroon merged in 1961 to form the
present country. Cameroon has generally enjoyed
stability, which has permitted the development of
agriculture, roads, and railways, as well as a
petroleum industry. Despite movement toward
democratic reform, political power remains firmly in
the hands of an ethnic oligarchy.','a94ec5a500ab27c6acbe8391bf5a0048ac70e295e47731687c0a25b37a8d2398','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00aa087607b3ea95cd99ba208bc475e7a4291179383f590c8fade080fa874593',2000,'HN','Honduras','transnational-issues',117,'Disputes - international: Bolivia has wanted a
sovereign corridor to the South Pacific Ocean since
the Atacama area was lost to Chile in 1884; dispute
with Bolivia over Rio Lauca water rights; territorial
claim in Antarctica (Chilean Antarctic Territory)
partially overlaps Argentine and British claims
Illicit drugs: a growing transshipment country for
cocaine destined for the US and Europe; economic
prosperity has made Chile more attractive to
traffickers seeking to launder drug profits; imported
precursors passed on to Bolivia; domestic cocaine
consumption is rising
iChina
I (also see separate Hong Kong, Macau, and Taiwan entries)','7af8b6983f1c61d3c6fb08e8006987b249e005c1287ba0feb605776cbd816072','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a951753758f5bebfcf6f7c826e2c7f2435626075703cd54de3b73520d7c11dee',2000,'AU','Australia','transnational-issues',120,'Disputes - international: none
Clipperton Island
; (possession of France)
o
Disputes - international: none
Holy See
(Vatican City)
Background: Popes in their secular role ruled much
of the Italian peninsula, including Rome, for more than
a thousand years, until 1870. Disputes between a
series of popes and Italy were resolved in 1929 by
three Lateran Treaties, which established the
independent state of Vatican City out of the former
Papal States and granted Roman Catholicism special
status in Italy. In 1984, a concordat between the
Vatican and Italy modified certain of the earlier treaty
provisions, including the primacy of Roman
Catholicism as the Italian state religion. Present
concerns of the Holy See include the failing health of
Pope John Paul II, who turns 80 on 20 May 2000,
interreligious dialogue and reconciliation, and the
adjustment of church doctrine in an era of rapid
change. About 1 billion people worldwide profess the
Catholic faith.','842dfbda26fd4e3b878cf04a4a5c5f4323bd6d7a27a2ce7ada4e132648ed084f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d235f4d6ffa2ef6084f0c10dd6d95ce16d5c29155d8109e8afc123a816a86e65',2000,'CG','Congo','transnational-issues',148,'Disputes - internationai: most of the Congo river
boundary with the Democratic Republic of the Congo
is indefinite (no agreement has been reached on the
division of the river or its islands, except in the Stanley
Pool/Pool Malebo area)','c125ebb4bc99645adaaf4654690bc05a68c5a318f1f50f560cdbf2cf29393f50','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4f75e2825d13d53f8a6711aa7583dc97ee7934cb49bf33c60d3c68c05ed4e46',2000,'CK','Cook Islands','transnational-issues',149,'(self-governing in free
association with
New Zealand)
Rakahanga.
Pukapuka ^ Manihiki
■ Nassau
Island
” Suwarrow
South Pacific Ocean
Palmerston ,
Ailutaki,^
Manuae
Takutea -, .Mitiaro
Atiu ''Mauke
0 iM aookiti
0 ISO 300 mi
Rarotonga
★AVARUA
''Mangaia
Disputes - international: none
Background: Costa Rica is a Central American
success story: since the late 19th century, only two
brief periods of violence have marred Its democratic
development. Although still a largely agricultural
country, it has achieved a relatively high standard of
living. Land ownership is widespread. Tourism is a
rapidly expanding industry.
Disputes - international: none
Illicit drugs: transshipment country for cocaine and
heroin from South America; illicit production of
cannabis on small, scattered plots; domestic cocaine
consumption has risen
122
Background: Close ties to France since
independence in 1 960, diversification of agriculture for
export, and encouragement of foreign investment
have made Cote d''Ivoire the most prosperous of the
tropical African states. About 20% of the popuiation
are \\«orkers from neighboring countries. On 25
December 1 999, a military coup - the first ever in Cote
d''Ivoire''s history - overthrew the government. The
new regime has promised to return the country to
democratic ruie in 2000.
I Geography
Location: Western Africa, bordering the North
Atiantic Ocean, between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area:
total: 322,460 sq km
/arrd; 31 8,000 sq km
water: 4,460 sq km
Area - comparative: slightiy larger than New Mexico
Land boundaries:
total: 3, t to km
border countries: Burkina Faso 584 km, Ghana 668
km, Guinea 610 km, Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
continental shelf: 200 nm
exclusive economic zone: 200 nm
ferr/tor/a/ sea; 12 nm
Climate: tropical along coast, semiarid in far north;
three seasons - warm and dry (November to March),
hot and dry (March to May), hot and wet (June to
October)
Terrain: mostly flatto undulating plains; mountains in
northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: petroleum, diamonds,
manganese, iron ore, cobalt, bauxite, copper,
hydropower
Land use:
arable land: 8%
permanent crops: 4%
permanent pastures: 41 %
forests and woodland: 22%
ofher;25%(1993 est.)
Irrigated land: 680 sq km (1993 est.)
Natural hazards: coast has heavy surf and no
natural harbors; during the rainy season torrential
flooding is possible
Environment - current issues: deforestation (most
of the country''s forests - once the largest in West
Africa - have been cleared by the timber industry);
water pollution from sewage and industrial and
agricultural effluents
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Population: 15,980,950
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
grovrth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure:
0-14 years: 46.45% (male 3,726,388; female
3,696,462) ''
15-64 years: 51 .36% (male 4,222,333; female
3,985,249)
65 years and over: 2.19% (male 175,606; female
174,912) (2000 est.)
Population growth rate: 2.58% (2000 est.)
Birth rate: 40.78 births/1,000 population (2000 est.)
Death rate: 16.57 deaths/1,000 population
(2000 est.)
Net migration rate: 1.6 migrant(s)/1,000 population
(2000 est.)
note: after Liberia''s civil war started in 1 990, more
than 350,000 refugees fled to Cote d''Ivoire; by the end
of 1999 all Liberian refugees were assumed to have
returned; the 2000 rate reflects labor in migration
Sex ratio:
at birth: 1 .03 male(s)/fema!e
under 15 years: 1. 01 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1 male(s)/female
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 95.06 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 45.1 5 years
male: 43.72 years
female: 40.63 years (2000 est.)
Total fertility rate: 5.8 children born/woman
(2000 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic groups: Baoule 23%, Bate 18%, Senoufou
15%, Malinke 11%, Agni, Africans from other
countries (mostly Burkinabe and Malians, about 3
million), non-Africans 130,000 to 330,000 (French
30,000 and Lebanese 100,000 to 300,000)
Religions: Muslim 60%, Christian 22%, indigenous
18% (some of these are also numbered among the
Christians and Muslims)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 1 5 and over can read and write
total population: 48.5%
male: 57%
female: 40%
I Government
Country name:
conventional long form: Republic of Cote d''Ivoire
conventional short form: Cote d''Ivoire
local long form: Republique de Cote d''Ivoire
local short form: Cote d''Ivoire
former: Ivory Coast
Data code: IV
Government type: republic; multiparty presidential
regime established 1960
Capital: Yamoussoukro
note: although Yamoussoukro has been the capital
since 1983, Abidjan remains the administrative
center; the US, like other countries, maintains its
Embassy in Abidjan
Administrative divisions: 50 departments
(departements, singular - departement); Abengourou,
Abidjan, Aboisso, Adzope, Agboville, Agnibilekrou,
Bangolo, Beoumi, Biankouma, Bondoukou,
Bongouanou, Bouafle, Bouake, Bouna, Boundiali,
Dabakala, Daloa, Danane, Daoukro, Dimbokro, Divo,
Duekoue, Ferkessedougou, Gagnoa, Grand-Lahou,
Guiglo, Issia, Katiola, Korhogo, Lakota, Man,
Mankono, Mbahiakro, Odienne, Oume, Sakassou,
San-Pedro, Sassandra, Seguela, Sinfra, Soubre,
Tabou, Tanda, Tingrela, Tiassale, Touba, Toumodi,
Vavoua, Yamoussoukro, Zuenoula
note: Cote d''Ivoire may have a new administrative
structure consisting of 58 departments; the following
additional departments have been reported but not yet
confirmed by the US Board on Geographic Names
(BGN); Adiake'', Ale''pe'', Dabon, Grand Bassam,
Jacqueville, Tiebissou, Toulepleu, Bocanda
Independence: 7 August (1960) (from France)
National holiday: National Day, 7 August
Constitution: 3 November 1 960; has been amended
numerous times, last time July 1998
123
Cote d''Ivoire (continued)
Legal system: based on French civil law system and
customary law; judicial review in the Constitutional
Chamber of the Supreme Court; has not accepted
compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state: Gen. Robert GUEI (since 25 December
1 999); note - took power following a military coup
against the government of former President Henri
Konan BEDIE; president is both chief of state and
head of government
head of government: Gen. Robert GUEI (since 25
December 1999); note - took power following a
military coup against the government of former
President Henri Konan BEDIE; president is both chief
of state and head of government
cabinet: Council of Ministers appointed by the
president
eiections: prior to the coup, president elected by
popular vote for a five-year term; election last held 22
October 1995 (next was scheduled to be held by
October 2000); prime minister appointed by the
president
election results: results of the last election prior to the
coup were: Henri Konan BEDIE elected president;
percent of vote - Henri Konan BEDIE 95.25%
Legislative branch: unicameral National Assembly
or Assemblee Nationale (175 seats; members are
elected by direct popular vote to serve five-year terms)
elections: elections last held 27 November 1 995 (next
to be held NA)
election results: percent of vote by party - NA; seats
by party -PDC1 150, RDR13, FPI12
note: a Senate will be created in the next election
Judicial branch: Supreme Court (Cour Supreme)
Political parties and leaders: Democratic Parly of
Cote d''Ivoire or PDCI [Jean Konan BANNY, acting
head]; Ivorian Popular Front or FPI [Laurent
GBAGBOj; Ivorian Worker''s Party or PIT [Francis
WODlEj; Rally of the Republicans or RDR [Henriette
DAGRI-DIABATEj; over 20 smaller parties
International organization participation: ACP,
AfDB, CCC, ECA, ECOWAS, Entente, FAO, FZ,
G-24, G-77, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM,
IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO, Intelsat,
Interpol, IOC, ISO (correspondent), ITU, NAM, OAU,
OPCW, UN, UNCTAD, UNESCO, UNIDO, UPU,
WADB, WADB (regional), WAEMU, WCL, WFTU,
WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Koffi Moise
KOUMOUE-KOFFI
chancery: 3421 Massachusetts Avenue NW,
Washington, DC 20007
fe/ephone; [11(202)797-0300
Diplomatic representation from the US:
chief of mission: Ambassador George MU
embassy: 5 Rue Jesse Owens, Abidjan
mailing address: Ot B. P. 1712, Abidjan
telephone: [225] 21 09 79, 21 46 72
FAY,'' [225] 22 32 59
Flag description: three equal vertical bands of
orange (hoist side), white, and green; similar to the
flag of Ireland, which is longer and has the colors
reversed - green (hoist side), white, and orange; also
similar to the flag of Italy, which is green (hoist side),
white, and red; design was based on the flag of
Disputes - international: none
Disputes - international: none
G e 0 g r a p h y
Location: Oceania, atoll in the North Pacific Ocean,
about one-third of the way from Hawaii to the Marshaii
Isiands
Geographic coordinates: 16 45 N, 169 30 W
Map references: Oceania
Area:
total: 2.8 sq km
land: 2.8 sq km
water: 0 sq km
Area ■ comparative: about 4.7 times the size of The
Maii in Washington, DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 m
Climate: tropical, but generally dry; consistent
northeast trade winds with little seasonal temperature
variation
Terrain: mostly flat
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Summit Peak 5 m
Natural resources: NA; guano deposits worked until
depletion about 1890
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other; 100%
Irrigated land: 0sqkm(1998)
Natural hazards: NA
Environment - current issues: no natural fresh
water resources
Geography - note: strategic location in the North
Pacific Ocean; Johnston Island and Sand Island are
natural islands, which have been expanded by coral
dredging; North Island (Akau) and East Island (Hikina)
are manmade islands formed from coral dredging;
closed to the public; former US nuclear weapons test
site; site of Johnston Atoll Chemical Agent Disposal
System (JACADS); some low-growing vegetation
r People
Population: no indigenous inhabitants
note: there is an average of 1 , 1 00 US military and
civilian contractor personnel present (January 2000 est.)
Disputes - international: none
256
Background: For most of its history since
independence from British administration in 1946,
Jordan was ruled by King HUSSEIN (1953-1999). A
pragmatic ruler, he successfully navigated competing
pressures from the major powers (US, USSR, and
UK), various Arab states, Israel, and a large internal
Palestinian population, through several wars and
coup attempts. In 1989 he resumed parliamentary
elections and gradually permitted political
liberalization; in 1994 a formal peace treaty was
signed with Israel.
I " G''e 0 g''r a''pTf . ''
Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
fofa/:89,213sqkm
land: 88,884 sq km
water: 329 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
fofa/; 1,619 km
border countries: Iraq 181 km, Israel 238 km, Saudi
Arabia 728 km, Syria 375 km. West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 nm
Climate: mostly arid desert; rainy season in west
(November to April)
Terrain: mostly desert plateau in east, highland area
in west; Great Rift Valley separates East and West
Banks of the Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1 ,734 m
Natural resources: phosphates, potash, shale oil
Land use:
arable land: 4%
permanent crops: 1%
permanent pastures: 9%
forests and woodland: 1%
other; 85% (1 993 est.)
Irrigated land: 630sqkm(1993est.)
Natural hazards: NA
Environment - current issues: limited natural fresh
water resources; deforestation; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
I''”"'' . -p-— . .
Population: 4,998,564 (July 2000 est.)
Age structure:
0-14 years: 38% (male 968,579; female 925,987)
15-64 years: 59% (male 1,568,615; female
1,374,303)
65 years and over: 3% (male 79,748; female 81 ,332)
(2000 est.)
Population growth rate: 3.1% (2000 est.)
Birth rate: 26.24 births/1,000 population (2000 est.)
Death rate: 2.63 deaths/1,000 popuiation
(2000 est.)
Net migration rate: 7.4 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.14 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .1 male(s)/female (2000 est.)
Infant mortality rate: 21 .1 1 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.36 years
male: 74.94 years
female: 79.93 years (2000 est.)
Total fertility rate: 3.44 children born/woman
(2000 est.)
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1 %, Armenian
1%
Religions: Sunni Muslim 96%, Christian 4%
(1997 est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 1 5 and over can read and write
total population: 86.6%
male: 93.4%
fema/e; 79.4% (1995 est.)
I G overnment
Country name:
conventional long form: Hashemite Kingdom of','6ec9216102f914d5108ab1d0ec3234cd57eba827e605fc2614cdd5fff74fdeed','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebea6497bc391269ef22364169aa0c16fb1e2fa5e30524ff4631ed7e923499c9',2000,'CU','Cuba','transnational-issues',171,'Disputes - international: US Naval Base at
Guantanamo Bay is leased to US and only mutual
agreement or US abandonment of the area can
terminate the lease
Illicit drugs: territorial waters and air space serve as
transshipment zone for cocaine bound for the US and
Europe; established the death penalty for certain
drug-related crimes in 1999
130
I introduction
Background: Independence from the UK was
approved in 1960 with constitutional guarantees by
the Greek Cypriot majority to the Turkish Cypriot
minority. In 1974 a Greek-sponsored attempt to seize
the government was met by miiitary intervention from
Turkey, which soon controlied almost 40% of the
Island. In 1983 the Turkish-held area declared itself
the Turkish Republic of Northern Cyprus, but it is
recognized only by Turkey. Cyprus talks resumed in
December 1 999 to prepare the ground for a
comprehensive settlement.
I Geography ~
Location: Middle East, island in the Mediterranean
Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total: 9,250 sq km (of which 3,355 sq km are in the ‘
Turkish Cypriot area)
land: 9,240 sq km
wafer lOsq km
Area - comparative: about 0.6 times the size of
Connecticut
Land boundaries: 0 km
Coastline: 648 km
Maritime ciaims:
continental shelf: 200-m depth or to the depth of
exploitation
territorial sea: t2nm
Climate: temperate, Mediterranean with hot, dry
summers and cool, winters
Terrain: central plain with mountains to north and
south; scattered but significant plains along southern
coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
fM£fhesfpo/nf;Olympus 1,951 m
Natural resources: copper, pyrites, asbestos,
gypsum, timber, salt, marble, clay earth pigment
Land use:
arable land: 12%
permanent crops: 5%
permanent pastures: 0%
forests and woodland: 1 3%
of/rer; 70% (1993 est.)
Irrigated land: 390 sq km (1993 est.)
Natural hazards: moderate earthquake activity
Environment ■ current issues: water resource
problems (no natural reservoir catchments, seasonal
disparity in rainfall, sea water Intrusion to island''s
largest aquifer, increased salination in the north);
water pollution from sewage and industrial wastes;
coastal degradation; loss of wildlife habitats from
urbanization
Environment - international agreements;
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
f P e 0 p iT
Population: 758,363 (July 2000 est.)
Age structure:
0-14 years: 23% (male 91 ,075; female 86,832)
15-64 years: 66% (male 252,252; female 247,464)
65 years and over: 11% (male 35,149; female
45,591) (2000 est.)
Population growth rate; 0.6% (2000 est.)
Birth rate: 1 3.27 births/1 ,000 population (2000 est.)
Death rate: 7.68 deaths/1,000 population
(2000 est.)
Net migration rate: 0.44 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2000 est.)
Infant mortality rate: 8.07 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.71 years
male: 74.43 years
female: 79.1 years (2000 est.)
Total fertility rate: 1 .95 children born/woman
(2000 est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 78% (99.5% of the Greeks
live in the Greek Cypriot area; 0.5% of the Greeks live
in the Turkish Cypriot area), T urkish 1 8% (1 .3% of the
Turks live in the Greek Cypriot area; 98.7% of the
Turks live in the Turkish Cypriot area), other 4%
(99.2% of the other ethnic groups live in the Greek
Cypriot area; 0.8% of the other ethnic groups live in
the Turkish Cypriot area)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 15 and over can read and write
total population: 94%
male: 98%
fema/e;91% (1987 est.)
|; Govern m e n t
Country name;
conventional long form: Republic of Cyprus
conventional short form: Cyprus
note; the Turkish Cypriot area refers to itself as the
"Turkish Republic of Northern Cyprus" (TRNC)
Data code; CY
Government type: republic
note: a disaggregation of the two ethnic communities
inhabiting the island began after the outbreak of
communal strife in 1963; this separation was further
solidified following the Turkish intervention in July
1 974 following a Greek junta-based coup attempt,
which gave the Turkish Cypriots de facto control in the
north; Greek Cypriots control the only internationally
recognized government; on 15 November 1983
Turkish Cypriot "President" Rauf DENKTASH
declared independence and the formation of a
"Turkish Republic of Northern Cyprus" (TRNC), which
has been recognized only by Turkey; both sides
publicly call for the resolution of intercommunal
differences and creation of a new federal system
(Greek Cypriot position) or confederate system
(Turkish Cypriot position) of government
Capital; Nicosia
note: the Turkish Cypriot area''s capital is Lefkosa
(Nicosia)
Administrative divisions: 6 districts; Famagusta,
Kyrenia, Larnaca, Limassol, Nicosia, Paphos; note -
Turkish Cypriot area''s administrative divisions include
■ Kyrenia, all but a small part of Famagusta, and small
parts of Lefkosa (Nicosia) and Larnaca
Cyprus (continued)
Independence: 16 August 1960 (from UK)
note; Turkish Cypriot area proclaimed self-rule on 13
February 1975 from Republic of Cyprus
National holiday: Independence Day, 1 October;
note - Turkish Cypriot area celebrates 15 November
as Independence Day
Constitution: 16 August 1960; negotiations to
create the basis for a new or revised constitution to
govern the island and to better relations between
Greek and Turkish Cypriots have been held
intermittently; in 1975 Turkish Cypriots created their
own constitution and governing bodies within the
“Turkish Federated State of Cyprus," which was
renamed the "Turkish Republic of Northern Cyprus" in
1983; a new constitution for the Turkish Cypriot area
passed by referendum on 5 May 1985
Legal system: based on common law, with civil law
modifications
Suffrage: 1 8 years of age; universal
Executive branch:
c/7/ef of sfafe; President GlafcosCLERIDES (since 28
February 1993); note - the president is both the chief
of state and head of government; post of vice
president is currently vacant; under the 1960
constitution, the post is reserved for a Turkish Cypriot
head of government: President Glafcos CLERIDES
(since 28 February 1993); note - the president is both
the chief of state and head of government; post of vice
president is currently vacant; under the 1960
constitution, the post is reserved for a Turkish Cypriot
cabinet: Council of Ministers appointed jointly by the
president and vice president
elections: president elected by popular vote for a
five-year term; election last held 15 February 1998
(next to be held NA February 2003)
election results: Glafcos CLERIDES reelected
president; percent of vote - Glafcos CLERIDES
50.8%, George lAKOVOU 49.2%
note: Rauf R. DENKTASH has been "president" of the
Turkish Cypriot area since 13 February 1975
("president" elected by popular vote for a five-year
term); elections last held 1 5 and 22 April 1 995 (next to
be held NA April 2000); results - Rauf R. DENKTASH
reelected president; pecent of vote - Rauf R.
DENKTASH 62.5%, Dervis EROGLU 37.5%; Dervis
EROGLU has been "prime minister" of the Turkish
Cypriot area since 1 6 August 1 996; there is a Council
of Ministers (cabinet) in the Turkish Cypriot area
Legislative branch: unicameral - Greek Cypriot
area: House of Representatives or Vouli Antiprosopon
(80 seats; 56 assigned to the Greek Cypriots, 24 to
Turkish Cypriots; note - only those assigned to Greek
Cypriots are filled; members are elected by popular
vote to serve five-year terms); Turkish Cypriot area:
Assembly of the Republic or Cumhuriyet Meclisi (50
seats; members are elected by popular vote to serve
five-year terms)
elections: Greek Cypriot area: last held 26 May 1996
(next to be held May 2001); Turkish Cypriot area: last
held 6 December 1998 (next to be held December
2003)
election results: Greek Cypriot area: House of
Representatives - percent of vote by party - DISY
34.5%, AKEL (Communist) 33.0%, DIK0 16.4%,
EDEK 8.1 %, KED 3.7%, others 4.3%; seats by party -
DISY 20, AKEL (Communist) 19, DIKO 10, EDEK 5,
KED 2; Turkish Cypriot area: Assembly of the
Republic - percent of vote by party - UBP 40.3%, DP
22.6%, TKP 15.4%, CTP 13.4%, UDP 4.6%, YBH
2.5%, BP 1 .2%: seats by party - UBP 24, DP 1 3, TKP
7, CTP 6
Judicial branch: Supreme Court, judges are
appointed by the Supreme Council of Judicature
note: there is also a Supreme Court in the Turkish
Cypriot area
Political parties and leaders: Greek Cypriot area:
Democratic Party or DIKO [Spyros KYPRIANOUj;
Democratic Rally or DISY [Nikos ANASTASIADHISj;
Ecologists [Yeoryios PERDHIKISj; New Horizons
[Nikolaos KOUTSOU, secretary general]; Restorative
Party of the Working People or AKEL (Communist
Party) [Dimitrios CHRISTOFIASj; United Democratic
Union of Cyprus or EDEK [Vassos LYSSARIDISj;
United Democrats Movement or EDI (formerly Free
Democrats Movement or KED) [George VASSILIOUj;
Turkish Cypriot area: Communal Liberation Party or
TKP [Mustafa AKINCI]; Democratic Party or DP
[Serdar DENKTASH]; National Birth Party or UDP
[Enver EMINj; National Unity Party or UBP [Dervis
EROGLU]; Our Party or BP [Okyay SADIKOGLU];
Patriotic Unity Movement or YBH [Ozker OZGUR];
Republican Turkish Party or CTP [Mehmet ALI
TALAT]
Political pressure groups and leaders;
Confederation of Cypriot Workers or SEK (pro-West);
Confederation of Revolutionary Labor Unions or
Dev-ls; Federation of Turkish Cypriot Labor Unions or
Turk-Sen; Pan-Cyprian Labor Federation or PEG
(Communist controlled)
International organization participation: C, CCC,
CE, EBRD, ECE, EU (applicant), FAG, G-77, IAEA,
IBRD, ICAG, ICC, ICFTU, IDA, IFAD, IFC, IFRCS
(associate), IHG, ILG, IMF, IMG, Inmarsat, Intelsat,
Interpol, IGC, IGM, ISG, ITU, NAM, GAS (observer),
GPCW, GSCE, PCA, UN, UNCTAD, UNESCG,
UNIDG, UPU, WCL, WFTU, WHG, WIPG, WMG,
WToG, WTrG
Diplomatic representation in the US;
chief of mission: Ambassador Erato
KGZAKGU-MARCGULLIS
chancery: 221 1 R Street NW, Washington, DC 20008
telephone: [1] (202) 462-5772
FAX; [1] (202) 483-6710
consulate(s) general: New York
note: representative of the Turkish Cypriot area in the
US is Ahmet ERDENGIZ; office at 1 667 K Street NW,
Washington, DC; telephone [1] (202) 887-6198
Diplomatic representation from the US:
chief of mission: Ambassador Donald K. BANDLER
embassy: corner of Metochiou and Ploutarchou
Streets, Engomi, Nicosia
mailing address: P. G. Box 4536, FPG AE 09836
telephone: [357] (2) 776400
FAX; [357] (2) 780944
Flag description: white with a copper-colored
silhouette of the island (the name Cyprus is derived
from the Greek word for copper) above two green
crossed olive branches in the center of the flag; the
branches symbolize the hope for peace and
reconciliation between the Greek and Turkish
communities
note: the Turkish Cypriot flag has a horizontal red
stripe at the top and bottom between which is a red
crescent and red star on a white field
Disputes - international: none
Illicit drugs: transshipment point for narcotics bound
for the US and Europe; minor cannabis producer;
banking industry is vulnerable to money laundering
142
Background: A legacy of unsettled, mostly
non-representative, rule for much of the 20th century
was brought to an end In 1996 when free and open
elections ushered in a new government.
i: Geography
Location: Caribbean, eastern two-thirds of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, east of Haiti
Geographic coordinates: 1 9 00 N, 70 40 W
Map references: Central America and the
Caribbean
Area:
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
Area - comparative: slightiy more than twice the
size of New Hampshire
Land boundaries:
total: 275 km
border countries: Haiti 275 km
Coastiine: 1,288 km
Maritime ciaims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 6 nm
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation in rainfall
Terrain: rugged highlands and mountains with fertile
valleys interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, sliver
Land use:
arable land: 2t%
permanent crops: 9%
permanent pastures: 43%
forests and woodland: 12%
often 15% (1993 est.)
Irrigated land: 2,300 sq km (1993 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding; periodic droughts
Environment - current issues: water shortages;
soil eroding into the sea damages coral reefs;
deforestation; Hurricane Georges damage
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Marine
Dumping, Marine Life Conservation, Nuclear Test
Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Law of the Sea
Geography - note: shares island of Hispaniola with
Haiti (eastern two-thirds is the Dominican Republic,
western one-third is Haiti)
[ . . . ''^pTo'' p i e '' .
Population: 8,442,533 (July 2000 est.)
Age structure:
0- 14 years: 34% (male 1 ,486,902; female 1 ,422,977)
15-64 years: 61 % (male 2,609,934; female
2,518,330)
65 years and over: 5% (male 192,254; female
212,136) (2000 est.)
Population growth rate: 1.64% (2000 est.)
Birth rate: 25.15 births/1 ,000 population (2000 est.)
Death rate: 4.72 deaths/1,000 population
(2000 est.)
Net migration rate: -4.04 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1. 05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .03 male(s)/female (2000 est.)
Infant mortality rate: 35.93 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total popuiation: 73.2 years
ma/e; 71 .12 years
female: 75.38 years (2000 est.)
Total fertility rate: 3 children born/woman
(2000 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: white 16%, black 11%, mixed 73%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
totai population: 82.1%
maie: 82%
femaie: 82.2% (1995 est.)','60bec373fdd15695723382e9ebd7aafa55813780fa652bf462c2cbb119fe3329','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41688e1826088cb1ba68c08d83ed22ffe4688f9fad9f9175ccf9bad991f30612',2000,'PE','Peru','transnational-issues',176,'Disputes - international: Egypt asserts Its claim to
the "Hala''ib Triangle,” a barren area of 20,580 sq km
under partial Sudanese administration that is defined
by an administrative boundary which supersedes the
treaty boundary of 1899
Illicit drugs: a transit point for Southwest Asian and
Southeast Asian heroin and opium moving to Europe,
Africa, and the US; popular transit stop for Nigerian
couriers
r '' . . . . rn rr 0 d u c t i 0 li permanent pastures: 29%
forests and woodland: 5%
Background: El Salvador achieved independence other: 31 % (1 993 est.)
from Spain in 1 821 and from the Central American irrigated land: 1 ,200 sq km (1 993 est.)
Federation in 1839. A 12-year civil war, which cost the Natural hazards; known as the Land of Volcanoes;
lives of some 75,000 people, was brought to a close in frequent and sometimes very destructive earthquakes
1 992 when the government and leftist rebels signed a and volcanic activity
treaty that provided for military and political reforms. Environment - current issues: deforestation; soil
,, . - . — - - - — . . - erosion; water pollution; contamination of soils from
. Geography disposal of toxic wastes; Hurricane Mitch damage
Location: Middle America, bordering the North Environment ■ international agreements:
Pacific Ocean, between Guatemala and Honduras to: Biodiversity, Climate Change, Climate
Geographic coordinates: 13 50 N, 88 55 W Change-Kyoto Protocol, Desertification, Endangered
Map references: Central America and the Species, Hazardous Wastes, Nuclear Test Ban,
Caribbean Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
total: 21 ,040 sq km Geography ■ note; smallest Central American
land: 20,720 sq km country and only one without a coastline on Caribbean
water: 320 sq km
Area - comparative: slightly smaller than
Massachusetts','f1ddd0cf27db63f749692af2810a939ec8accafeb68ac38ed6dd6ad4f4a2d309','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eed997d3abcbfb3464b1a49cb25c85f5075d7722f7cac6f590d44f1b5d80ccb',2000,'GN','Guinea','transnational-issues',181,'Disputes - international: exclusive maritime
economic zone boundary dispute with Cameroon is
presently before the ICJ; maritime boundary dispute
with Gabon because of disputed sovereignty over
islands in Corisco Bay; maritime boundary dispute
with Nigeria and Cameroon because of disputed
jurisdiction over oil-rich areas in the Gulf of Guinea
Background: Eritrea was awarded to Ethiopia in
1952 as part of a federation. Ethiopia''s annexation of
Eritrea as a province 1 0 years later sparked a 30-year
struggle for independence that ended in 1991 with
Eritrean rebels defeating governmental forces;
independence was overwhelmingly approved in a
1993 referendum. A border war with Ethiopia that
erupted in 1998 remains unresolved.
f Geography
Location: Eastern Africa, bordering the Red Sea,
between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
Area - comparative: slightly larger than
Pennsylvania
Land boundaries:
total: 1 ,630 km
border countries: Djibouti 113 km, Ethiopia 912 km,
Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea
1,151 km, islands in Red Sea 1,083 km
Maritime claims: NA
Climate: hot, dry desert strip along Red Sea coast;
cooler and wetter in the central highlands (up to 61 cm
of rainfall annually); semiarid in western hills and
lowlands; rainfall heaviest during June-September
except in coastal desert
Terrain: dominated by extension of Ethiopian
north-south trending highlands, descending on the
east to a coastal desert plain, on the northwest to hilly
terrain and on the southwest to flat-to-rolling plains
Elevation extremes;
lowest point: near Kulul within the Denakil depression
-75 m
154
Eritroa (continued)
highest point: Soira 3,01 8 m
Natural resources: gold, potash, zinc, copper, salt,
possibly oil and natural gas, fish
Land use:
arable land: 12%
permanent crops:
permanent pastures: 49%
forests and woodland: 6%
other; 32% (1998 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts and locust
storms
Environment - current issues: deforestation;
desertification; soil erosion; overgrazing; loss of
infrastructure from civil warfare
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species
signed, but not ratified: none of the selected
agreements
Geography - note: strategic geopolitical position
along world''s busiest shipping lanes; Eritrea retained
the entire coastline of Ethiopia along the Red Sea
upon de jure independence from Ethiopia on 24 May
1993
I . . . . "People
Population: 4,135,933 (July 2000 est.)
Age structure:
0-14 years: 43% (male 888,573; female 883,939)
15-64 years: 54% (male 1 ,104,082; female
1,122,683)
65 years and over: 3% (male 69,51 8; female 67, 1 38)
(2000 est.)
Population growth rate: 3.86% (2000 est.)
Birthrate: 42.71 births/1 ,000 population (2000 est.)
Death rate: 1 2.3 deaths/1 ,000 population
(2000 est.)
Net migration rate: 8.22 migrant(s)/1 ,000
population (2000 est.)
note: according to the UNHCR, about 1 50,000
Eritrean refugees in Sudan have registered for
voluntary repatriation, following the restoration of
diplomatic relations between Eritrea and Sudan in
January 2000
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1 .04 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 76.66 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 55.79 years
male: 53.36 years
female: 58.29 years (2000 est.)
Total fertility rate: 5.93 children born/woman
(2000 est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and
Kunama, Tigrinya, other Cushitic languages
Literacy:
definition: NA
total population: 25%
male: NA%
female: NA%','1190aa1a6397d7a496ac40010a6a3c616f21886432d90ca6ba9dad4a7063fd23','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcde6d20f89d6aba5f573e38b6d2017c8cd7b578d28ac750473cc9e3dff38aa3',2000,'JE','Jersey','transnational-issues',197,'Disputes - international; none
Background; Ruled by Sweden from the 1 2th to the
19th centuries and by Russia from 1809, Finland
finally won its independence in 1917. During World
War II, it was able to successfully defend its freedom
and fend off invasions by the Soviet Union and
Germany. In the subsequent half century, the Finns
have made a remarkable transformation from a farm/
forest economy to a diversified modern industrial
economy; per capita income is now on par with
Western Europe. As a member of the European
Union, Finland was the only Nordic state to join the
euro system at its initiation in January 1999.
i GeogfapTiy
Location; Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, and Gulf of Finland, between
Sweden and Russia
Geographic coordinates; 64 00 N, 26 00 E
Map references; Europe
Area;
total: 337,030 sq km
land: 305,470 sq km
water: 31 ,560 sq km
Area - comparative; slightly smaller than Montana
Land boundaries;
total: 2, m km
border countries: Norway 729 km, Sweden 586 km,
Russia 1,313 km
Coastline; 1 ,126 km (excludes islands and coastal
indentations)
Maritime claims;
contiguous zone: 6 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 1 2 nm
territorial sea: 12 nm (in the Gulf of Finland - 3 nm)
Climate; cold temperate; potentially subarctic, but
comparatively mild because of moderating influence
of the North Atlantic Current, Baltic Sea, and more
than 60,000 lakes
Terrain; mostly low, flat to rolling plains interspersed
with lakes and low hills
Elevation extremes;
lowest point: Baltic Sea 0 m
/7/g/7esfpo;nf.''Haltiatunturi 1,328 m
Natural resources; timber, copper, zinc, iron ore,
silver
Land use;
arable land: 8%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 76%
other: 16% (1993 est.)
Irrigated land; 640 sq km (1993 est.)
Natural hazards; NA
Environment - current issues; air pollution from
manufacturing and power plants contributing to acid
rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife
populations
Environment - international agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: /<\\r Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note; long boundary with Russia;
Helsinki is northernmost national capital on European
continent; population concentrated on small
southwestern coastal plain
Disputes - international: none
170
Background; Although ultimately a victor in World
Wars I and II, France suffered extensive losses in its
empire, wealth, manpower, and rank as a dominant
nation-state. Since 1958, it has constructed a
presidential democracy resistant to the instabilities
experienced in earlier parliamentary democracies. In
recent years, its reconciliation and cooperation with
Germany have proved central to the economic
integration of Europe, including the advent of the euro
in January 1 999. Today, France is at the forefront of
European states seeking to exploit the momentum of
monetary union to advance the creation of a more
unified and capable European defense and security
apparatus.
r Geography . .
Location: Western Europe, bordering the Bay of
Biscay and English Channel, between Belgium and
Spain, southeast of the UK; bordering the
Mediterranean Sea, betwepn Italy and Spain
Geographic coordinates: 46 00 N, 2 00 E
Map references: Europe
Area:
tofa/.’ 547,030 sq km
land: 545,630 sq km
water: 1 ,400 sq km
note: includes only metropolitan France, but excludes
the overseas administrative divisions
Area - comparative: slightly less than twice the size
of Colorado
Land boundaries:
total: 2,889 km
border counfr/es; Andorra 56.6 km, Belgium 620 km,
Germany 451 km, Itaiy 488 km, Luxembourg 73 km,
Monaco 4.4 km, Spain 623 km, Switzerland 573 km
Coastline; 3,427 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm (does not apply to
the Mediterranean)
territorial sea: ^2 nm
Climate: generally cool winters and mild summers,
but mild winters and hot summers aiong the
Mediterranean
Terrain: mostly flat plains or gently rolling hills in
north and west; remainder is mountainous, especiaiiy
Pyrenees in south, Alps in east
Elevation extremes:
lowest point: Rhone River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: coal, iron ore, bauxite, fish,
timber, zinc, potash
Land use;
arable land: 33%
permanent crops: 2%
permanent pastures: 20%
forests and woodland: 27%
other: ^8% (1993 est.)
Irrigated land: 16,300 sq km (1995 est.)
Natural hazards; flooding; avalanches
Environment - current issues: some forest
damage from acid rain (major forest damage occurred
as a result of severe December 1999 windstorm); air
pollution from industrial and vehicle emissions; wafer
pollution from urban wastes, agricultural runoff
Environment • international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Poliution-Sulphur 85, Air Pollution-Suiphur 94, Air
Pollution-Voiatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: largest West European nation;
occasional strong, cold, dry, north-to-northwesterly
wind known as mistral
I People
Population: 59,329,691 (July 2000 est.)
Age structure:
0-14 years: 1 9% (male 5,719,502; female 5,448,608)
15-64 years: 65% (male 19,345,269; female
19,322,902)
65 years and over: 16% (male 3,849,783; female
5,643,627) (2000 est.)
Population growth rate; 0.38% (2000 est.)
Birth rate: 1 2.27 births/1 ,000 population (2000 est.)
Death rate: 9.14 deaths/1,000 population
(2000 est.)
Net migration rate: 0.66 migranf(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 4.51 deaths/1,000 live births
(2000 est.)
Life expectancy at birth;
total population: 78.76 years
male: 74.85 years
female: 82.89 years (2000 est.)
Total fertility rate: 1 .75 children born/woman
(2000 est.)
Nationality;
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 90%, Protestant 2%,
Jewish 1%, Muslim (North African workers) 1%,
unaffiliated 6%
Languages; French 100%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1 980 est.)
I " Government
Country name;
conventional long form: French Republic
conventional short form: France
local long form: Republique Francaise
local short form: France
Data code: FR
Government type; republic
Capital; Paris
Administrative divisions; 22 regions (regions,
singular - region); Alsace, Aquitaine, Auvergne,
Basse-Normandie, Bourgogne, Bretagne, Centre,
Champagne-Ardenne, Corse, Franche-Comte,
Haute-Normandie, Ile-de-France,
Languedoc-Roussillon, Limousin, Lorraine,
Midi-Pyrenees, Nord-Pas-de-Calais, Pays de la Loire,
Picardie, Poitou-Charentes, Provence-Alpes-Cote
d''Azur, Rhone-Alpes
note: metropolitan France is divided into 22 regions
(including the "territorial collectivity" of Corse or
Corsica) and is subdivided into 96 departments; see
separate entries for the overseas departments
(French Guiana, Guadeloupe, Martinique, Reunion)
and the overseas territorial collectivities (Mayotte,
Saint Pierre and Miquelon)
Dependent areas: Bassas da India, Clipperton
Island, Europa Island, French Polynesia, French
Southern and Antarctic Lands, Glorioso Islands, Juan
de Nova Island, New Caledonia, Tromelin Island,
Land boundaries:
total: 1 ,006 km
border countries: Egypt 255 km, Gaza Strip 51 km,
Jordan 238 km, Lebanon 79 km, Syria 76 km. West
Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
Climate: temperate; hot and dry in southern and
eastern desert areas
Terrain: Negev desert in the south; low coastal plain;
centrai mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: copper, phosphates, bromide,
potash, clay, sand, sulfur, asphalt, manganese, small
amounts of natural gas and crude oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland: 6%
of/7er66%(1993est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: sandstorms may occur during
spring and summer
Environment ■ current issues: limited arable land
and natural fresh water resources pose serious
constraints; desertification; air poliution from industrial
and vehicle emissions; groundwater pollution from
industrial and domestic waste, chemical fertilizers,
and pesticides
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Marine Life Conservation
Geography - note: there are 231 Israeli settlements
and civilian land use sites in the West Bank, 42 in the
Israeli-occupied Golan Heights, 24 in the Gaza Strip,
and 29 in East Jerusalem (August 1999 est.)
Population: 5,842,454
note: includes about 171,000 Israeli settlers In the
West Bank, about 20,000 in the Israeli-occupied
Golan Heights, about 6,500 in the Gaza Strip, and
about 172,000 in East Jerusalem (July 2000 est.)
Age structure:
0-14 years: 28% (male 825,443; female 787,1 59)
15-64 years: 63% (male 1 ,831 ,142; female
1,820,424)
65 years and over: 9% (male 248,695; female
329,591) (2000 est.)
Population growth rate: 1 .67% (2000 est.)
Birth rate: 1 9.32 births/1 ,000 population (2000 est.)
Death rate: 6.22 deaths/1 ,000 population
(2000 est.)
Net migration rate: 3.63 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 7.9 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 78.57 years
male: 76.57 years
female: 80.67 years (2000 est.)
Total fertility rate: 2.6 children born/woman
(2000 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 80.1% (Europe/
America-born 32.1%, Israel-born 20.8%, Africa-born
14.6%, Asia-born 12.6%), non-Jewish 19.9% (mostly
Arab) (1996 est.)
Religions: Jewish 80.1%, Muslim 14.6% (mostly
Sunni Muslim), Christian 2.1%, other 3,2% (1996 est.)
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female: 93% (1992 est.)
Country name:
conventional long form: State of Israel
conventional short form: Israel
local long form: Medinat Yisra''el
local short form: Yisra''el
Data code: IS
Government type: parliamentary democracy
Capital: Jerusalem
note: Israel proclaimed Jerusalem as its capital in
1 950, but the US, like nearly all other countries,
maintains its Embassy in Tel Aviv
Administrative divisions: 6 districts (mehozot,
singular - mehoz); Central, Haifa, Jerusalem,
Northern, Southern, Tel Aviv
Independence: 14 May 1948 (from League of
Nations mandate under British administration)
National holiday: Independence Day, 1 4 May 1 948;
note - Israel declared independence on 14 May 1948,
but the Jewish calendar is lunar and the holiday may
occur in April or May
243
IsrSCi (continued)
Constitution: no formal constitution; some of the
functions of a constitution are filled by the Declaration
of Establishment (1948), the Basic Laws of the
parliament (Knesset), and the Israeli citizenship law
Legal system: mixture of English common law,
British Mandate regulations, and, in personal matters,
Jewish, Christian, and Muslim legal systems; in
December 1985, Israel informed the UN Secretariat
that it would no longer accept compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
ch/ef of state; President EzerWEIZMAN (since 13
May 1993)
head of government: Prime Minister Ehud BARAK
(since 6 July 1999)
cabinet: Cabinet selected by prime minister and
approved by the Knesset
elections: president elected by the Knesset for a
five-year term; election last held 4 March 1998 (next to
be held NA March 2003); prime minister elected by
popular vote for a four-year term; election last held 1 7
May 1999 (next to be held NA May 2003); note - in
March 1992, the Knesset approved legislation,
effective in 1 996, which allowed for the direct election
of the prime minister; under the new law, each voter
casts two ballots - one for the direct election of the
prime minister and one for a party in the Knesset; the
candidate that receives the largest percentage of the
popular vote then works to form a coalition with other
parties to achieve a parliamentary majority of 61
seats; finally, the candidate must submit his or her
cabinet to the Knesset for approval and this must be
done within 45 days of the election; in contrast to the
old system, under the new law, the prime minister''s
party need not be the single-largest party in the
Knesset
election results: Ezer WEIZMAN reelected president
by the 1 20-member Knesset with a total of 63 votes,
other candidate, Shaul AMOR, received 49 votes
(there were seven abstentions and one absence);
Ehud BARAK elected prime minister; percent of vote -
Ehud BARAK 56.08%, Binyamin NETANYAHU
43.92%
note: government coalition - One Israel, Shas,
MERETZ, Yisra''el Ba''Aliya, Center Party, National
Religious Party
Legislative branch: unicameral Knesset or
parliament (120 seats; members elected by popular
vote to serve four-year terms)
elections: last held 17 May 1999 (next to be held NA
May 2003)
election results: percent of vote by party - One Israel
20.2%, Likud Party 14.1%, Shas 13%, MERETZ
7.6%, Yisra''el Ba''Aliya 5.1%, Shinui 5%, Center Party
5%, Nationai Religious Party 4.2%, United Torah
Judaism 3.7%, United Arab List 3.4%, National Union
3%, Hadash 2.6%, Yisra''el Beiteinu 2.6%, Baled
1 .9%, One Nation 1 .9%, Democratic Movement NA
(party formed after election, members elected under
Yisra''el Ba''Aliya list); seats by party - One Israel 26,
Likud Party 19, Shas 17, MERETZ 10, Yisra''el
Ba''Aliya 4, Shinui 6, Center Party 6, National
Religious Party 5, United Torah Judaism 5, United
Arab List 5, National Union 4, Hadash 3, Yisra''el
Beiteinu 4, Democratic Movement 2 (party formed
after election, members elected under Yisra''el
Ba''Aliya list), Balad 2, One Nation 2
Judicial branch: Supreme Court, appointed for iife
by the president
Political parties and leaders: Balad [Azmi
BISHARA]; Center Party [Yitzhak MORDECHAIj;
Democratic Movement [Roman BRONFMAN];
Gesher [David LEVI); Hadash [Muhammad BARAKA];
Labor Party [Ehud BARAK]; Likud Party [Ariel
SHARON]; MERETZ [Yossi SARID]; Moledet
[Rehavam ZEEVl]; National Democratic Alliance
(Balad) [leader NA]; National Religious Party [Yitzhak
LEVY]; National Union [Rehavam ZEEVl] (includes
Herut, Tekuma, Yisre''el Beiteinu and Moledet); One
Israel [Ehud BARAK] (includes Labor, Gesher, and
Meimad); One Nation [Amir PERETZ]; Shas [Eliyahu
YISHAi]; Shinui [Tommy LAPID]; Third Way [Avigdor
KAHALANI]; Tzomet [Rafael EITAN]; United Arab List
[Abd al-Malik DAHAMSHAH]; United Torah Judaism
[Meir PORUSH]; Yisra''el Ba''Aliya [Natan
SHARANSKY]; Yisra''el Beiteinu [Avigdor
LIEBERMAN]
Political pressure groups and leaders: Gush
Emunim, Israeli nationalists advocating Jewish
settlement on the West Bank and Gaza Strip; Peace
Now supports territorial concessions in the West Bank
and is critical of government''s Lebanon policy
International organization participation; BSEC
(observer), CCC, CE (observer), CERN (observer),
EBRD, ECE, FAO, lADB, IAEA, IBRD, ICAO, ICC,
ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, lOM, ISO, ITU, OAS
(observer), OPCW, OSCE (partner), PCA, UN,
UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WHO,
WlPO, WMO, WToO, WTrO
Diplomatic representation in the US;
chief of mission: Ambassador David iVRY
chancery; 3514 International Drive NW, Washington,
DC 20008
telephone: [t] (202) 364-5500
FAX: [1] (202) 364-5610
consulate(s) general: Atlanta, Boston, Chicago,
Houston, Los Angeles, Miami, New York,
Philadelphia, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Martin S. INDYK
embassy: 71 Hayarkon Street, Tel Aviv
mailing address: PSC 98, Unit 7228, APO AE 09830
fe/ephone;[972](3)519-7575
FAX; [972] (3) 517-3227
consulate(s) genera/; Jerusalem; note - an
independent US mission, established in 1928, whose
members are not accredited to a foreign government
Flag description: white with a blue hexagram
(six-pointed linear star) known as the Magen David
(Shield of David) centered between two equal
horizontal blue bands near the top and bottom edges
of the flag
Disputes - international: significant progress has
been made with Croatia toward resolving a maritime
border dispute over direct access to the sea in the
Adriatic; Italy and Slovenia made progress in
resolving bilateral issues
Illicit drugs: minor transit point for Southwest Asian
heroin bound for Western Europe, and for precursor
chemicals
452
Solomon Islands (continued)
of/7er;9%(1993est.)
Irrigated land: NAsqkm
Natural hazards: typhoons, but they are rarely
destructive; geologically active region virith frequent
earth tremors; volcanic activity
Environment - current issues: deforestation; soil
erosion; much of the surrounding coral reefs are dead
or dying
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Whaling
signed, but not ratified: CWmate Change-Kyoto
Protocol
I People
Population: 466,194 (July 2000 est.)
Age structure:
0-14 years: AA% (male 105,024; female 101,065)
15-64 years: 53% (male 124,627; female 121,358)
65 years and over: 3% (male 6,935; female 7,1 85)
(2000 est.)
Population growth rate: 3.04% (2000 est.)
Birth rate: 34.79 births/1 ,000 population (2000 est.)
Death rate: 4.35 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/temale
15-64 years: 1 .03 male(s)/female
65 years and over: 0.97 male(s)/female
total population: 1.03 male(s)/female (2000 est.)
Infant mortality rate: 25.26 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .28 years
male: 68.86 years
female: 73.81 years (2000 est.)
Total fertility rate: 4.8 children born/woman
(2000 est.)
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 93%, Polynesian 4%,
Micronesian 1.5%, European 0.8%, Chinese 0.3%,
other 0.4%
Religions: Anglican 34%, Roman Catholic 19%,
Baptist 1 7%, •■''Uhited (Methodist/Presbyterian) 11%,
Seventh-Day Adventist 10%, other Protestant 5%,
indigenous beliefs 4%
Languages: Melanesian pidgin in much of the
country is lingua franca, English spoken by 1%-2% of
population
/70fe; 120 indigenous languages
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Disputes - international: none','ab5cd8b51ae939209ac5969969d644953752470a602268855b35b041dfae2b7d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b791691aff737562022e2b654ee369c001931aa21e4e3a2cf67ef23ca2c3adb6',2000,'WF','Wallis and Futuna','transnational-issues',199,'note: the US does not recognize claims to Antarctica
Independence: 486 (unified by Clovis)
National holiday: National Day, Taking of the
Bastille, 14 July (1789)
Constitution: 28 September 1958, amended
concerning election of president in 1962, amended to
171
FranCG (continued)
comply with provisions of EC Maastricht Treaty in
1992; amended to tighten immigration laws 1993
Legal system: civil law system with indigenous
concepts; review of administrative but not legislative
acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Jacques CHiRAC (since 17
May 1995)
head of government: Prime Minister Lionel JOSPIN
(since 3 June 1997)
cabinet: Council of Ministers appointed by the
president on the suggestion of the prime minister
elections: president eiected by popuiar vote for a
seven-year term; election iast heid 23 April and 7 May
1995 (next to be held by May 2002); prime minister
nominated by the National Assembly majority and
appointed by the president
election results: Jacques CHiRAC elected president;
percent of vote, second baliot - Jacques CHIRAC
(RPR) 52.64%, Lionel JOSPIN (PS) 47.36%
Legislative branch: bicameral Parliament or
Pariement consists of the Senate or Senat (321 seats -
296 for metropolitan France, 13 for overseas
departments and territories, and 12 for French
nationais abroad; members are indirectiy eiected by
an electoral college to serve nine-year terms; elected
by thirds every three years) and the National Assembly
or Assemblee Nationale (577 seats; members are
elected by popular vote under a single-member
majoritarian system to serve five-year terms)
elections: Senate - last held 27 September 1 998 (next
to be held September 2001 ); National Assembly - last
held 25 May-1 June 1997 (next to be held NA May
2002)
election results: Senate - percent of vote by party -
NA; seats by party - RPR 99, UDC 52, DL 47, PS 78,
PCF 1 6, other 29; National Assembly - percent of vote
by party - NA; seats by party - PS 245, RPR 1 40, DDF
1 09, PCF 37, PRS 1 3, MEI 8, MDC 7, LDI-MPF 1 , FN
1 , various left 9, various right 7
Judicial branch: Supreme Court of Appeals or Cour
de Cassation, judges are appointed by the president
from nominations of the High Council of the Judiciary;
Constitutional Council or Conseil Constitutionnel,
three members appointed by the president, three
members appointed by the president of the National
Assembly, and three appointed by the president of the
Senate; Council of State or Conseil d''Etat
Political parties and ieaders: Citizens Movement
or MdC [Jean Pierre CHEVENEMENT]; Democratic
Force or FD [leader NA]; Ecology Gereration or GE
[Brice LALONDEj; French Communist Party or PCF
[Robert HUE]; Independent Ecological Movement or
MEI [Jenevieve ANDUEZA]; Left Radical Party or
PRG (previously Radical Socialist Party or PRS and
the Left Radical Movement or MRG) [Jean-Michel
BAYLET]; Liberal Democracy or DL (originally
Republican Party or PR) [Alain MADELIN]; Movement
for France or LDI-MPF [Philippe DEVILLIERS];
National Center of Independents and Peasants or
CNIP [Jean PERRIN]; National Front or FN
[Jean-Marie LE PEN]; National Front-National
Movement [Bruno MEGRET]; Popular Party for
French Democracy or PPDF [Herve de CHARETTE];
Radical Party or RRRS [Thierry CORNILLET]; Rally
for the Republic or RPR [Michelle ALLIOT-MARIE];
Reformers'' Movement or MR [Jean-Pierre SOISSON];
Socialist Party or PS [Francois HOLLANDE]; The
Greens (Les Verts) [Jean-Luc BENNAHMIAS]; The
Right (La Droite) [Charles MILLON]; Union for French
Democracy or UDF (coalition of UDC, FD, RRRS,
PPDF) [Francois LEOTARD]; Union of the Center or
UDC [leader NA]
Political pressure groups and leaders:
Communist-controlled labor union (Confederation
Generale du Travail) or CGT, nearly 2.4 million
members (claimed); independent labor union or Force
Ouvriere, 1 million members (est.); independent
white-collar union or Confederation Generale des
Cadres, 340,000 members (claimed); National
Council of French Employers (Conseil National du
Patronat Francais) or CNPF or Patronat;
Socialist-leaning labor union (Confederation
Francaise Democratique du Travail) or CFDT, about
800,000 members (est.)
International organization participation: ACCT,
AfDB, AsDB, Australia Group, BDEAC, BIS, CCC,
CDB (non-regional), CE, CERN, EAPC, EBRD, ECA
(associate), ECE, ECLAC, EIB, EMU, ESA, ESCAP,
EU, FAO, FZ, G- 5, G- 7, G-10, lADB, IAEA, IBRD,
ICAO, ICC, ICFTU, ICRM, IDA, lEA, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Inmarsat, InOC, Intelsat,
Interpol, IOC, lOM, ISO, ITU, MINURSO, MIPONUH,
MONUC, NAM (guest), NATO, NEA, NSG, OAS
(observer), OECD, OPCW, OSCE, PCA, SPC, UN,
UN Security Council, UNCTAD, UNESCO, UNHCR,
UNIDO, UNIFIL, UNIKOM, UNITAR, UNMIBH,
UNMIK, UNOMIG, UNRWA, UNTSO, UNU, UPU,
WADB (nonregional), WCL, WEU, WFTU, WHO,
WlPO, WMO, WToO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Francois V. BUJON DE
L''ESTANG
chancery: 4101 Reservoir Road NW, Washington, DC
20007
fe/ep/)one.''[1] (202) 944-6000
FAX; [1] (202) 944-6166
consulate(s) general: Manta, Boston, Chicago,
Houston, Los Angeles, Miami, New Orleans, New
York, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Felix G. ROHATYN
embassy: 2 Avenue Gabriel, 75382 Paris Cedex 08
mailing address: PSC 1 16, APO AE 09777
telephone: [33] (1) 43-12-22-22
FAX; [33] (1)42 66 97 83
consulate(s) general: Marseille, Strasbourg
Flag description: three equal vertical bands of blue
(hoist side), white, and red; known as the French
Tricouleur (T ricolor); the design and colors are similar
to a number of other flags, including those of Belgium,
Chad, Ireland, Cote d''Ivoire, and Luxembourg; the
official flag for all French dependent areas
Disputes - international: Madagascar claims
Bassas da India, Europa Island, Glorloso Islands,
Juan de Nova Island, and Tromelin Island; Comoros
claims Mayotte; Mauritius claims Tromelin Island;
territorial dispute between Suriname and French
Guiana; territorial claim in Antarctica (Adelie Land);
Matthew and Hunter Islands east of New Caledonia
claimed by France and Vanuatu
Illicit drugs: transshipment point for and consumer
of South American cocaine and Southwest Asian
heroin
173','41860912e936d96cb245e0640c43fbc2bf22e5a64ab4663eb1c4c7b7277aecda','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95844d0efb82c769edbd706a077c503df4af7b2605733242f22a39dae50dfc1e',2000,'GF','French Guiana','transnational-issues',201,'f (overseas department
I of France)
Background: First settled by the French in 1604,
French Guiana was the site of notorious penal
settlements until 1951 . The European Space Agency
launches its communication satellites from Kourou.
f Geography
Location: Northern South America, bordering the
North Atlantic Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total: 91 ,000 sq km
land: 89,150 sq km
water: 1 ,850 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
tofa/; 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 nm
femMa/ sea; 12 nm
Climate: tropical; hot, humid; little seasonal
temperature variation
Terrain: low-lying coastal plains rising to hills and
small mountains
Elevation extremes:
towesfpo/nf; Atlantic Ocean 0 m
highest point: Bellevue de I''lnini 851 m
Natural resources: bauxite, timber, gold (widely
scattered), cinnabar, kaolin, fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 90%
other 10% (1996 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: high frequency of heavy showers
and severe thunderstorms; flooding
Environment - current issues: NA
Geography - note: mostly an unsettled wilderness','417df522a37d0359230d5bdb343bc769955e2c8208eb55939561d58d0b78c2d1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab9b90f422e7030e8a535d19f9ac11a6418edd8c9060fd65762d08d7f95961be',2000,'FR','France','transnational-issues',204,'Disputes - international: Suriname claims area
between Riviere Litani and Riviere Marouini (both
headwaters of the Lawa)
Illicit drugs: small amount of marijuana grown for
iocai consumption; minor transshipment point to
Europe
175
Disputes - international: "Adelie Land" claim in
Antarctica is not recognized by the US
178
iGabon
t-
i . I n trod u c t i 0 n
i-
Background; Ruled by autocratic presidents since
independence from France in 1960, Gabon
introduced a multiparty system and a new constitution
in the early 1990s that allowed for a more transparent
electoral process and for reforms of governmental
institutions. A small population, abundant natural
resources, and foreign private investment have
helped make Gabon one of the more prosperous
black African countries.
f . G eTg r''a p . .
Location; Western Africa, bordering the Atlantic
Ocean at the Equator, between Republic of the Congo
and Equatorial Guinea
Geographic coordinates; 1 00 S, 1 1 45 E
Map references; Africa
Area;
total: 267,667 sq km
land: 257,667 sq km
wafer; 1 0,000 sq km
Area - comparative; slightly smaller than Colorado
Land boundaries;
total: 2,551 km
border countries: Cameroon 298 km. Republic of the
Congo 1 ,903 km. Equatorial Guinea 350 km
Coastline; 885 km
Maritime claims;
contiguous zone: 24 nm
exclusive economic zone: 200 nm
ferrifor/a/sea;12nm
Climate; tropical; always hot, humid
Terrain; narrow coastal plain; hilly interior; savanna
in east and south
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1 ,575 m
Natural resources; petroleum, manganese,
uranium, gold, timber, iron ore, hydropower
Land use;
arable land: 1%
permanent crops: 1%
permanent pastures: 18%
forests and woodland: 77%
of/7er;3%(1993 est.)
Irrigated land; 40 sq km (1993 est.)
Natural hazards; NA
Environment - current issues; deforestation;
poaching
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
r’ . pV^p i e .
Population; 1,208,436
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would othenwise be
expected (July 2000 est.)
Age structure;
0-14 years: 33% (male 201 ,737; female 200,764)
15-64 years: 61 % (male 371 ,359; female 364,982)
65 years and over: 6% (male 34,478; female 35, 1 1 6)
(2000 est.)
Population growth rate; 1.08% (2000 est.)
Birth rate; 27.6 births/1,000 population (2000 est.)
Death rate; 1 6.83 deaths/1 ,000 population
(2000 est.)
Net migration rate; 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate; 96.3 deaths/1,000 live births
(2000 est.)
Life expectancy at birth;
totai popuiation: 50.08 years
male: 48.94 years
female: 51 .26 years (2000 est.)
Total fertility rate; 3.73 children born/woman
(2000 est.)
Nationality;
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups; Bantu tribes including four major
tribal groupings (Fang, Eshira, Bapounou, Bateke),
other Africans and Europeans 154,000, including
6,000 French and 1 1 ,000 persons of dual nationality
Religions; Christian 55%-75%, Muslim less than
1%, animist
Languages; French (official). Fang, Myene, Bateke,
Bapounou/Eschira, Bandjabi
Literacy;
definition: age 15 and over can read and write
totai population: 63.2%
male: 73.7%
female: 53.3% (1 995 est.)
I ^ Government
Country name;
conventional long form: Gabonese Republic
conventional short form: Gabon
local long form: Republique Gabonaise
local short form: Gabon
Data code; GB
Government type; republic; multiparty presidential
regime (opposition parties legalized in 1990)
Capital; Libreville
Administrative divisions; 9 provinces; Estuaire,
Haut-Ogooue, Moyen-Ogooue, Ngounie, Nyanga,
Ogooue-lvindo, Ogooue-Lolo, Ogooue-Maritime,
Woleu-Ntem
Independence; 17 August 1960 (from France)
National holiday; Independence Day, 17 August
(1960) (Gabon granted full independence from
France)
Constitution; adopted 14 March 1991
Legal system; based on French civil law system and
customary law; judicial review of legislative acts in
Constitutional Chamber of the Supreme Court;
compulsory ICJ jurisdiction not accepted
Suffrage; 21 years of age; universal
Executive branch;
chief of state: President El Hadj Omar BONGO (since
2 December 1967)
head of government: Prime Minister Jean-Francois
NTOUTOUME-EMANE (since 23 January 1999)
cabinet: Council of Ministers appointed by the prime
minister in consultation with the president
elections: president elected by popular vote for a
seven-year term; election last held 6 December 1998
(next to be held NA 2005); prime minister appointed
by the president
election resuits: President El Hadj Omar BONGO
reelected; percent of vote - El Hadj Omar BONGO
66.6%, Pierre MAMBOUNDOU 16.5%, Fr. Paul
M''BA-ABESSOLE 13.4%
Legislative branch; bicameral legislature consists
of the Senate (91 seats) and the National Assembly or
Assembles Nationals (120 seats); members are
elected by direct popular vote to serve five-year terms
elections: National Assembly - last held 15 and 29
December 1 996 (next to be held NA December 2001 );
Senate - last held 26 January and 9 February 1997
(next to be held in January 2002)
eiection resuits: National Assembly - percent of vote
by party - NA; seats by party - PDG 89, PGP 9, RNB
6, CLR 3, UPG 2, USG 2, independents 4, others 5;
Senate - percent of vote by party - NA; seats by party -
PDG 53, RNB 20, PGP 4, ADERE 3, RDP 1 , CLR 1 ,
independents 9
179
Gabon (continued)
Judicial branch: Supreme Court or Cour Supreme
consisting of three chambers - Judicial,
Administrative, and Accounts; Constitutional Court;
Courts of Appeal; Court of State Security; County
Courts
Political parties and leaders: African Forum for
Reconstruction or FAR [leader NA]; Circle of Liberal
Reformers or CLR [General Jean Boniface ASSELE];
Democratic and Republican Alliance or ADERE
[Divungui-di-Ndinge DIDJOB]; Gabonese Democratic
Party or PDG, former sole party [Simplice Nguedet
MANZELA, secretary general]; Gabonese Party for
Progress or PGP [Pierre-Louis AGONDJO-OKAWE,
president]; Gabonese People''s Union or UPG [Pierre
MAMBOUNDOU]; Gabonese Socialist Union or USG
[leader NA]; National Rally of Woodcutters
(Bucherons) or RNB [Fr. Paul M''BA-ABESSOLE];
People''s Unity Party or PUP [Louis Gaston MAYILA];
Rally for Democracy and Progress or RDP [leader
NA]; Social Democratic Party or PSD [Pierre Claver
MAGANGA-MOUSSAVOU]
International organization participation: ACCT,
ACP, AfDB, BDEAC, CCC, CEEAC, ECA, FAO, FZ,
G-24, G-77, IAEA, IBRD, ICAO, ICFTU, IDA, IDB,
IFAD, IFC, IFRCS (associate), ILO, IMF, IMO,
Inmarsat, Intelsat, Interpol, IOC, ITU, NAM, OAU,
OIC, OPCW, UDEAC, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WHO, WlPO, WMO, WToO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Paul
BOUNDOUKOU-UTHA
chancery: Suite 200, 2034 20th Street NW,
Washington, DC 20009
telephone: [t] {202) 797-mo
FAX; [1] (202) 332-0668
consulate(s): New York
Diplomatic representation from the US:
chief of mission: Ambassador James V. LEDESMA
embassy: Boulevard de la Mer, Libreville
mailing address: B. P. 4000, Libreville
telephone: [241] 76 20 03 through 76 20 04, 74 34 92
FAX; [241] 74 55 07
Flag description: three equal horizontal bands of
green (top), yellow, and blue
Disputes - international: remaining legal Issues
(restitution) arising from World War II and its aftermath
Illicit drugs: source of precursor chemicals for
South American cocaine processors; transshipment
point for and consumer of Southwest Asian heroin,
Latin American cocaine, and European-produced
synthetic drugs
Disputes - international: claimed by Madagascar
Disputes - international: none
[Guam
( (territory of the US)
0 6 12 km
6 6 12 mi
t
^^treef
reef J
X''Qojf
Cabras
Apra Island
Harbor...,.,^==^=^^
*r$^amunin<
*hagAtn^
(Agara^
y
yAgal
North
1 reef
Pacific
\\
J
Ocean
\\.Merjzo J
Cocos
Island
f ” I ril r 6 d u c t i d li"
t: .
Background: Guam was ceded to the US by Spain
in 1 898. Captured by the Japanese in 1 941 , it was
retaken by the US three years later. The military
installation on the island is one of the most
strategically important US bases in the Pacific.
. g7a p |,y
Location: Oceania, island in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area:
fota/; 541.3 sq km
/and; 541.3 sq km
wafer; 0 sq km
Area - comparative: three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; generally warm and humid,
moderated by northeast trade winds; dry season from
January to June, rainy season from July to December;
little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs;
relatively flat coralline limestone plateau (source of
most fresh water), with steep coastal cliffs and narrow
coastal plains in north, low-rising hilis in center,
mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped),
tourism (especially from Japan)
Land use:
arable land: 11%
permanent crops: 11%
permanent pastures: 1 5%
forests and woodland: 18%
other: 45% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: frequent squalls during rainy
season; relatively rare, but potentially very destructive
typhoons (especially in August)
Environment - current issues: extirpation of native
bird population by the rapid proliferation of the brown
tree snake, an exotic species
Geography - note: largest and southernmost island
in the Mariana Islands archipelago; strategic location
in western North Pacific Ocean
I People
Population: 1 54,623 (July 2000 est.)
Age structure:
0-14 years: 34.9% (male 28,233; female 25,727)
15-64 years: 59.09% (male 48,126; female 43,238)
65 years and over: 6.01 % (male 4,680; female 4,61 9)
(2000 est.)
Population growth rate: 1 .67% (2000 est.)
Birth rate: 26.1 9 births/1 ,000 population (2000 est.)
Death rate: 4.16 deaths/1 ,000 population
(2000 est.)
Net migration rate: -5.35 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.14 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1 .1 male(s)/female (2000 est.)
Infant mortality rate: 6.83 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77.78 years
male: 75.51 years
female: 80.37 years (2000 est.)
Total fertility rate: 3.96 children born/woman
(2000 est.)
Nationality:
noun: Guamanian(s)
adjective: Guamanian
Ethnic groups: Chamorro 47%, Filipino 25%, white
10%, Chinese, Japanese, Korean, and other 18%
Religions: Roman Catholic 85%, other 15%
(1999 est.)
Languages: English, Chamorro, Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1990 est.)
r Government
Country name:
conventional long form; Territory of Guam
conventional short form: Guam
Data code: GQ
203
Guam (continued)
Dependency status: organized, unincorporated
territory of the US with poiicy reiations between Guam
and the US under the jurisdiction of the Office of
Insuiar Affairs, US Department of the interior
Government type: NA
Capital: Hagatna (Agana)
Administrative divisions: none (territory of the US)
Independence: none (territory of the US)
National holiday: Guam Discovery Day (first Monday
in March) (1521); Liberation Day, 21 Juiy (1944)
Constitution: Organic Act of 1 August 1950
Legal system: modeled on US; US federal laws
apply
Suffrage: 18 years of age; universal; US citizens, but
do not vote in US presidential elections
Executive branch:
chief of state: President William Jefferson CLINTON
of the US (since 20 January 1 993); Vice President
Albert GORE, Jr. (since 20 January 1993)
head of government: Governor Carl GUTIERREZ
(since 8 November 1994) and Lieutenant Governor
Madeleine BORDALLO (since 8 November 1994)
cabinet: executive departments; heads appointed by
the governor with the consent of the Guam legislature
elections: US president and vice president elected on
the same ticket for a four-year term; governor and
lieutenant governor elected on the same ticket by
popular vote for four-year terms; election last held 3
November 1998 (next to be held NA November 2002)
election resu/fs; Carl GUTIERREZ reelected
governor; percent of vote - Carl GUTIERREZ
(Democrat) 53.2%, Joseph ADA (Republican) 46.8%
Legislative branch: unicameral Legislature (15
seats; members are elected by popular vote to serve
two-year terms)
elections: last held 3 November 1 998 (next to be held
NA November 2000)
election results: percent of vote by party - NA; seats
by party - Republican 12, Democratic 3
note: Guam elects one delegate to the US House of
Representatives; election last held 3 November 1998
(next to be held NA November 2000); results - Robert
UNDERWOOD was reelected as delegate; percent of
vote by party - NA; seats by party - Democratic 1
Judicial branch: Federal District Court (judge is
appointed by the president); Territorial Superior Court
(judges appointed for eight-year terms by the governor)
Political parties and leaders: Democratic Party
(party of the Governor) [leader NAj; Republican Party
(controls the legislature) [leader NA]
International organization participation: ESCAP
(associate), Interpol (subbureau), IOC, SPC
Diplomatic representation in the US: none
(territory of the US)
Diplomatic representation from the US: none
(territory of the US)
Flag description: territorial flag is dark blue with a
narrow red border on all four sides; centered is a
red-bordered, pointed, vertical ellipse containing a
beach scene, outrigger canoe with sail, and a palm
tree with the word GUAM superimposed in bold red
letters; US flag is the national flag
Disputes - international: none
204
1 n trod u c t ion
Background: Guatemala was freed of Spanish
colonial rule in 1 821 . During the second half of the
20th century, it experienced a variety of military and
civilian governments as well as a 36-year guerrilla
war. In 1996, the government signed a peace
agreement formally ending the conflict, which had led
to the death of more than 100,000 people and had
created some 1 million refugees.
I” . G e o g r apTi y "
Location; Middle America, bordering the Caribbean
Sea, between Honduras and Belize and bordering the
North Pacific Ocean, between Ei Salvador and Mexico
Geographic coordinates; 15 30 N, 90 15 W
Map references: Central America and the
Caribbean
Area;
total: 108,890 sq km
land: 108,430 sq km
wafer; 460 sq km
Area - comparative: siightly smaller than
Tennessee
Land boundaries:
tofa/; 1,687 km
border countries: Belize 266 km, El Salvador 203 km,
Honduras 256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: t2 nm
Climate; tropical; hot, humid in lowlands; cooler in
highlands
Terrain; mostly mountains with narrow coastal plains
and rolling iimestone plateau (Peten)
Elevation extremes;
/owesfpo/nf; Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,21 1 m
Natural resources: petroleum, nickel, rare woods,
fish, chicle, hydropower
Land use;
arable land: 12%
permanent crops: 5%
permanent pastures: 24%
forests and woodland: 54%
other; 5% (1993 est.)
Irrigated land: 1,250 sq km (1993 est.)
Natural hazards: numerous volcanoes in
mountains, with occasional violent earthquakes;
Caribbean coast subject to hurricanes and other
tropical storms
Environment - current issues: deforestation; soil
erosion; water pollution; Hurricane Mitch damage
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Ciimate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Wetiands
signed, but not ratified: Antarctic-Environmental
Protocol
Geography - note: no natural harbors on west coast
. .
Population: 12,639,939 (July 2000 est.)
Age structure;
0-14 years: 42% (male 2,735,107; female 2,622,412)
15-64 years: 54% (male 3,41 1 ,575; female
3,413,932)
65 years and over: 4% (male 21 3,791 ; female
243,122) (2000 est.)
Population growth rate: 2.63% (2000 est.)
Birth rate: 35.05 births/1,000 population (2000 est.)
Death rate: 6.92 deaths/1 ,000 population
(2000 est.)
Net migration rate: -1.89 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/femaie
65 years and over: 0.88 male(s)/female
totai population: 1 .01 male(s)/female (2000 est.)
Infant mortality rate: 47.03 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 66. 1 8 years
maie: 63.53 years
female: 68.96 years (2000 est.)
Total fertility rate: 4.66 chiidren bom/woman
(2000 est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish
or assimilated Amerindian - in local Spanish called
Ladino), approximately 56%, Amerindian or
predominantly Amerindian, approximately 44%
Religions: Roman Catholic, Protestant, indigenous
Mayan beliefs
Languages: Spanish 60%, Amerindian languages
40% (more than 20 Amerindian languages, including
Quiche, Cakchiquel, Kekchi, Mam, Garifuna, and
Xinca)
Literacy:
definition: age 1 5 and over can read and write
totai population: 55.6%
mate: 62.5%
female: 48.6% (1995 est.)
p Government
Country name:
conventional long form: Republic of Guatemala
conventional short form: Guatemala
local long form: Republica de Guatemala
local short form: Guatemala
Data code; GT
Government type: constitutional democratic
republic
Capital; Guatemala
Administrative divisions: 22 departments
(departamentos, singular - departamento); Alta
Verapaz, Baja Verapaz, Chimaltenango, Chiquimula,
El Progreso, Escuintia, Guatemala, Huehuetenango,
Izabal, Jalapa, Jutiapa, Peten, Quetzaltenango,
Quiche, Retaihuleu, Sacatepequez, San Marcos,
Santa Rosa, Solola, Suchitepequez, Totonicapan,
Zacapa
Independence: 15 September 1821 (from Spain)
National holiday; Independence Day, 15
September (1821)
Constitution: 31 May 1985, effective 14 January
1986
note: suspended 25 May 1 993 by former President
SERRANO; reinstated 5 June 1 993 following ouster of
president; amended November 1993
Legal system; civil law system; judicial review of
legislative acts; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal (active duty
members of the armed forces may not vote)
Executive branch:
chief of state: President Alfonso Antonio PORTILLO
Cabreras (since 14 January 2000); Vice President
Juan Francisco REYES Lopez (since 14 January
2000); note - the president is both the chief of state
and head of government
head of government: President Alfonso Antonio
PORTILLO Cabreras (since 14 January 2000); Vice
President Juan Francisco REYES Lopez (since 14
January 2000); note - the president is both the chief of
state and head of government
cabinet: Council of Ministers named by the president
elections: president elected by popular vote for a
four-year term; election last held 7 November 1999;
runoff held 26 December 1999 (next to be held NA
November 2003)
election results: Alfonso Antonio PORTILLO
Cabreras elected president; percent of vote - Alfonso
205
GuatGmala (continued)
Antonio PORTILLO Cabreras (FRG) 68%, Oscar
BERGER Perdomo(PAN) 32%
Legislative branch: unicameral Congress of the
Republic or Congreso de la Republica (113 seats;
members are elected by popular vote to serve
four-year terms)
elections: last held on 7 November 1999 (next to be
held in November 2003)
election results: percent of vote by party - NA; seats
by party - FRG 63, PAN 37, ANN 9, DOG 2, UD/LOV
1,PLP1
note: for the 7 November 1 999 election, the number of
congressional seats was increased from 80 to 1 1 3
Judicial branch: Supreme Court of Justice or Corte
Suprema de Justicia; additionally the Court of
Constitutionality is presided over by the president of
the Supreme Court, judges are elected for a five-year
term by Congress
Political parties and leaders: Christian Democratic
Party or DCG [Vinicio CEREZO Arevalo); Democratic
Union or UD [Jose CHEA Urruela]; Green Party or
LOV [leader NA]; Guatemalan National Revolutionary
Union or URNG [Jorge SOTO); Guatemalan
Republican Front or FRG [Efrain RIOS Montt);
National Advancement Party or PAN [Hector
CIFUENTESj; New Guatemalan Democratic Front or
FDNG [Rafael ARRIAGA Martinez]; New Nation
Alliance or ANN [leader NA]; Progressive Liberator
Party or PLP [leader NA]
Political pressure groups and leaders: Agrarian
Owners Group or UNAGRO; Alliance Against
Impunity or AAI; Committee for Campesino Unity or
CUC; Coordinating Committee of Agricultural,
Commercial, Industrial, and Financial Associations or
CACIF; Mutual Support Group or GAM
International organization participation: BCIE,
CACM, CCC, ECLAC, FAO, G-24, G-77, lADB, IAEA,
IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, Intelsat, Interpol, IOC, lOM, ISO
(correspondent), ITU, LAES, LAIA (observer), NAM,
OAS, OPANAL, OPCW, PCA, UN, UNCTAD,
UNESCO, UNIDO, UNU, UPU, WCL, WFTU, WHO,
WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador (vacant)
chancery: 2220 R Street NW, Washington, DC 20008
fe/eptone;[1] (202) 745-4952
FAX; [1] (202) 745-1908
consutate(s) general: Chicago, Houston, Los
Angeles, Miami, New York, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Prudence BUSHNELL
embassy: 7-01 Avenida de la Reforma, Zone 10,
Guatemala City
mailing address: APO AA 34024
fe/ephorre; [502] (2) 31-15-41
FAX: [502] (2) 33-48-77
Flag description: three equal vertical bands of light
blue (hoist side), white, and light blue with the coat of
arms centered in the white band; the coat of arms
includes a green and red quetzal (the national bird)
and a scroll bearing the inscription LIBERTAD 15 DE
SEPTIEMBRE DE 1821 (the original date of
independence from Spain) all superimposed on a pair
of crossed rifles and a pair of crossed swords and
framed by a wreath
Disputes - international: none
208
Background: Independent from France since 1958,
Guinea did not hoid democratic elections untii 1993
when Gen. Lansana CONTE (head of the miiitary
government) was elected president in disputed
balloting. Security ciampdowns continue, aithough not
as severe as in earlier decades. Reelected in 1998,
the president faced growing criticism in 1999 for his
jailing of a major opposition leader and widespread
economic maiaise. Unrest in Sierra Leone also
continued to threaten Guinea''s stability.
I ’ . . ’ G e''o''gTrliirh y '' . . ”
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Sierra
Leone
Geographic coordinates: 1 1 00 N, 1 0 00 W
Map references: Africa
Area:
total: 245,857 sq km
land: 245,857 sq km
wafer; 0 sq km
Area - comparative: slightiy smaller than Oregon
Land boundaries:
total: 3,399 km
border countries: Cote d''Ivoire 61 0 km,
Guinea-Bissau 386 km, Liberia 563 km, Mali 858 km,
Senegal 330 km. Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Climate: generally hot and humid; monsoonal-type
rainy season (June to November) with southwesteriy','0f70a4042d610cda1592c2356bfec6643170062e47c9f59e9de7bd0ce3cb9a2d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c3f72b59d9f55d21129f6b234187c3479982a83c4c78722fed77a66c3829210',2000,'FR','France','transnational-issues',205,'winds; dry season (December to May) with
northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: bauxite, iron ore, diamonds,
gold, uranium, hydropower, fish
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 22%
forests and woodland: 59%
other: 17% (1993 est.)
Irrigated land: 930 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season
Environment - current issues: deforestation;
inadequate supplies of potable water; desertification;
soil contamination and erosion; overfishing,
overpopulation in forest region
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
. .
Population: 7,466,200 (July 2000 est.)
Age structure:
0-14 years; 43.38% (male 1,614,789; female
1,623,691)
15-64 years: 53.95% (male 1 ,966,929; female
2,060,877)
65 years and over: 2.68% (male 82,376; female
11 7,538) (2000 est.)
Population growth rate: 1.95% (2000 est.)
Birth rate: 40.08 births/1,000 population (2000 est.)
Death rate; 1 7.86 deaths/1 ,000 population
(2000 est.)
Net migration rate: -2.68 migrant(s)/1,000
population (2000 est.)
note: over the years Guinea has received several
hundred thousand refugees from the civil wars in
Liberia and Sierra Leone; by the end of 1999 all
Liberian refugees were assumed to have returned;
refugees from Sierra Leone are assumed to be
returning
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 1 30.98 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 45.56 years
ma/e; 43.1 6 years
female: 48.02 years (2000 est.)
Total fertility rate: 5.46 children bom/woman
(2000 est.)
Nationality:
noun: Guinean(s)
adjective: Guinean
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou
20%, smaller ethnic groups 10%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official), each ethnic group has
its own language
Literacy:
definition: age 15 and over can read and write
total population: 35.9%
male: 49.9%
fema/e; 21 .9% (1995 est.)
1“'' " Government
Country name:
conventional long form: Republic of Guinea
conventional short form: Guinea
local long form: Republique de Guinea
local short form: Guinea
former: French Guinea
Data code; GV
Government type: republic
Capital; Conakry
Administrative divisions: 4 administrative regions
(regions administrative, singular - region
administrative) and 1 special zone (zone speciale)*;
Conakry*, Guinea, Guinee-Forestiere, Haute-Guinee,
Moyen-Guinee
Independence: 2 October 1958 (from France)
National holiday: Anniversary of the Second
Republic, 3 April (1984)
Constitution: 23 December 1 990 (Loi
Fundamentale)
Legal system: based on French civil law system,
customary law, and decree; legal codes currently
being revised; has not accepted compulsory ICJ
jurisdiction
Suffrage; 1 8 years of age; universal
Executive branch;
chief of state: President Lansana CONTE (head of
military government since 5 April 1984, elected
president 19 December 1993)
head of government: Prime Minister Lamine SIDIME
(since 8 March 1999)
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
five-year term; candidate must receive a majority of
the votes cast to be elected president; election last
held 14 December 1998 (next to be held NA
December 2003); the prime minister appointed by the
president
election results: Lansana CONTE reelected
president; percent of vote - Lansana CONTE (PUP)
56.1%, Mamadou Boye BA (UNR-PRP) 24.6%, Alpha
CONDE (RPG) 16.6%,
Legislative branch: unicameral People''s National
Assembly or Assemblee Nationale Populaire (114
seats; members are elected by direct popular vote to
serve five-year terms)
209
Guinoa (continued)
elections: last held 1 1 June 1 995 (next to be held NA
2000)
election results: percent of vote by party - NA; seats
by party - PUP 71 , RPG 1 9, PRP 9, UNR 9, UPG 2,
PDG1,UNPG1,PDG-RDA1, other 1
Judicial branch: Court of Appeal or Cour d''Appel
Political parties and leaders: Democratic Party of
Guinea or PDG-AST [Marcel CROS]; Democratic
Party of Guinea-African Democratic Rally or
PDG-RDA [El Had] Ismael Mohamed Gassim
GUSHEIN]; Party for Unity and Progress or PUP
[Lansana CONTE] - the governing party; Party for
Renewal and Progress or PRP [Siradiou DIALLO);
Rally for the Guinean People or RPG [Alpha CONDE);
Union for Progress of Guinea or UPG [Jean-Marie
DORE, secretary-general]; Union for the New
Republic or UNR [Mamadou Boye BA]
International organization participation: ACCT,
ACP, AfDB, CCC, ECA, ECOWAS, FAO, G-77, IBRD,
ICAO, ICFTU, ICRM, IDA, IDB, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Intelsat, Interpol, IOC, lOM (observer),
ISO (correspondent), ITU, MINURSO, NAM, OAU,
OIC, OPCW, UN, UNCTAD, UNESCO, UNIDO, UPU,
WCL, WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Mohamed Aly THIAM
chancery: 2tt2 Leroy Place NW, Washington, DC
20008
fe/eptone;[1](202) 483-9420
FAX; [1] (202) 483-8688
Diplomatic representation from the US:
chief of mission: Ambassador Joyce E. LEADER
embassy: Rue Ka 038, Conakry
mailing address: B. P. 603, Conakry
telephone: [224] 41 1 5 20, 41 1 5 21 , 41 1 5 23
FAX; [224] 41 15 22
Flag description: three equal vertical bands of red
(hoist side), yellow, and green; uses the popular
pan-African colors of Ethiopia; similar to the flag of
Rwanda, which has a large black letter R centered In
the yellow band
Disputes - international; none
210
iGuinea-Bissau H ]
Background; In 1 994, 20 years after independence
from Portugal, the country''s first multiparty legislative
and presidential elections \\were held. An army uprising
that triggered a bloody civil war in 1998, created
hundreds of thousands of displaced persons. The
president was ousted by a military junta in May 1 999.
An interim government turned over power in February
2000 when opposition leader Koumba YALLA took
office following two rounds of transparent presidential
elections. Guinea-Bissau''s transition back to
democracy will be complicated by a crippled economy
devastated by civil war and the military''s predilection
for governmental meddling.
r ’ GToiTVphy ■
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Geographic coordinates; 1 2 00 N, 1 5 00 W
Map references; Africa
Area;
fofa/;36,120sqkm
land: 28,000 sq km
water: 8,120 sq km
Area - comparative: slightly less than three times
the size of Connecticut
Land boundaries;
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline; 350 km
Maritime ciaims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate: tropical; generally hot and humid;
monsoonal-type rainy season (June to November)
with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain; mostly low coastal plain rising to savanna in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast
corner of the country 300 m
Natural resources: fish, timber, phosphates,
bauxite, unexploited deposits of petroleum
Land use;
arable land: UJo
permanent crops: 1%
permanent pastures: 38%
forests and woodland: 38%
ote''12%(1993 est.)
Irrigated land: 17 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season; brush fires
Environment - current issues: deforestation; soil
erosion; overgrazing; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Wetlands
signed, but not ratified: none of the selected
agreements
I''-”"’’ “’’“nPeopTe ''
Population: 1 ,285,715 (July 2000 est.)
Age structure;
0-14 years: 42% (male 271 ,100; female 272,304)
15-64 years: 55% (male 335,150; female 370,667)
65 years and over: 3% (male 1 6,574; female 1 9,920)
(2000 est.)
Population growth rate: 2.4% (2000 est.)
Birth rate: 39.63 births/1 ,000 population (2000 est.)
Death rate: 1 5.62 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 1 12.25 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 49.04 years
male: 46.77 years
female: 51 .37 years (2000 est.)
Total fertility rate: 5.27 children bom/woman
(2000 est.)
Nationality:
noun: Guinean (s)
adjective: Guinean
Ethnic groups: African 99% (Balanta 30%, Fula
20%, Manjaca 14%, Mandinga 13%, Papel 7%),
European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 1 5 and over can read and write
total population: 53.9%
male: 67.1%
fema/e;40.7% (1997 est.)
I Government
Country name;
conventional long form: Republic of Guinea-Bissau
conventional short form: Guinea-Bissau
local long form: Republica da Guine-Bissau
local short form: Guine-Bissau
former: Portuguese Guinea
Data code: PU
Government type: republic, multiparty since
mid-1991
Capital; Bissau
Administrative divisions: 9 regions (regioes,
singular - regiao); Bafata, Biombo, Bissau, Bolama,
Cacheu, Gabu, Oio, Quinara, Tombali
note: Bolama may have been renamed Bolama/
Bijagos
Independence: 24 September 1973 (unilaterally
declared by Guinea-Bissau); 10 September 1974
(recognized by Portugal)
National holiday: Independence Day, 24
September (1973)
Constitution: 1 6 May 1 984, amended 4 May 1 991 , 4
December 1991,26 February 1 993, 9 June 1 993, and
1996
Legal system; NA
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Koumba YALLA (since 18
February 2000)
head of government: Prime Minister Caetana
N''TCHAMA (since NA February 2000)
cabinet: NA
elections: president elected by popular vote for a
five-year term; election last held 28 November 1999
and 1 6 January 2000 (next to be held NA 2004); prime
minister appointed by the president after consultation
with party leaders in the legislature
election results: Koumba YALLA elected president;
percent of vote, second ballot - Koumba YALLA
(PRS) 72%, Malan Bacai SANHA (PAIGC) 28%
Legislative branch: unicameral National People''s
Assembly or Assembleia Nacional Popular (100
seats; members are elected by popular vote to serve
a maximum of four years)
elections: last held 28 November 1999 (next to be
held by NA 2003)
election results: percent of vote by party - NA; seats
by party - PRS 37, RGB 27, PAIGC 25, 1 1 remaining
seats went to 5 of the remaining 1 0 parties that fielded
candidates
Judicial branch: Supreme Court or Supremo
Tribunal da Justica, consists of nine justices who are
appointed by the president and serve at his pleasure,
final court of appeals in criminal and civil cases;
Regional Courts, one in each of nine regions, first
court of appeals for sectoral court decisions, hear all
211
Guinea-Bissau (continued)
felony cases and civil cases valued at over $1 ,000; 24
Sectoral Courts, judges are not necessarily trained
lawyers, hear civil cases under $1 ,000 and
misdemeanor criminal cases
Political parlies and leaders: African Party for the
Independence of Guinea-Bissau and Cape Verde or
PAIGC [Wlalan Bacai SANHAj; Front for the Liberation
and Independence of Guinea or FLING [Jose
Katengul M. ENDES); Guinea-Bissau Resistance-Ba
Fata Movement or RGB-MB [Domingos FERNANDES
Gomes]; Guinean Civic Forum or FCG [Antonieta
Rosa GOMES]; International League for Ecological
Protection or LIPE [Alhaje Bubacar DJALO,
president]; National Union for Democracy and
Progress or UNDP [Abubacer BALDE, secretary
general]; Party for Democratic Convergence or PCD
[Victor MANDINGA]; Social Renovation Party or PRS
[Koumba YALLA]; Union for Change or UM [Jorge
MANDINGA, president. Dr. Anne SAAD, secretary
general]; United Social Democratic Party or PUSD
[Victor Sau''de MARIA]
International organization participation; ACCT
(associate), ACP, AfDB, ECA, ECOWAS, FAO, FZ,
G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IDB, IFAD,
IFC, IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory
user), Interpol, IOC, lOM, ITU, NAM, OAU, OIC,
OPCW, UN, UNCTAD, UNESCO, UNIDO, UPU,
WADB (regional), WAEMU, WFTU, WHO, WlPO,
WMO, WToO, WTrO
Diplomatic representation in the US;
chief of mission: Ambassador Mario LOPES DA
ROSA
chancery: Suite 51 9, 1 51 1 K Street, NW, Washington,
DC 20005
fe/eptone;[1] (202) 347-3950
FAX; [1] (202) 347-3954
Diplomatic representation from the US: the US
Embassy suspended operations on 14 June 1998 in
the midst of violent conflict between forces loyal to
then President VIEIRA and military-led junta
Flag description: two equal horizontal bands of
yellow (top) and green with a vertical red band on the
hoist side; there is a black five-pointed star centered
in the red band; uses the popular pan-African colors of
Disputes - international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for the US and Europe
I n t r 0 d li c t i o n
Background: Independent from France in 1960,
Mauritania annexed the southern third of the former
Spanish Sahara (now Western Sahara) in 1976, but
relinquished it after three years of raids by the
Polisario guerrilla front seeking independence for the
territory. Opposition parlies were legalized and a new
constitution approved in 1991. Two multiparty
presidential elections since then were widely seen as
being flawed; Mauritania remains, in reality, a
one-party state. The country continues to experience
ethnic tensions between its black minority population
and the dominant Maur (Arab-Berber) populace.
Disputes - international; claimed by Madagascar
and Mauritius
498
Mediterranean Sea
La°
fe/ep/rone-433](1)49 53 28 28
FAX-[33](1)49 5329 42
esfaW/shed— NA 1919
aim— to promote free trade and private
enterprise and to represent business interests at
national and international levels
members— {Q2 national councils) Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Burkina Faso,
Cameroon, Canada, Chile, China, Colombia, Cote d''Ivoire, Cyprus, Denmark, Ecuador, Egypt, Finland, France,
Germany, Greece, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait,
Lebanon, Lithuania, Luxembourg, Madagascar, Mexico, Morocco, Netherlands, Nigeria, Norway, Pakistan, Peru,
Portugal, Saudi Arabia, Senegal, Singapore, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan,
Togo, Tunisia, Turkey, UK, US, Uruguay, Venezuela, Yugoslavia
586
Appendix C: International Organizations and Groups (continued)
members— (185) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangiadesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Buigaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Centrai African Republic, Chad, Chiie, China, Coiombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook isiands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, Ei Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Palau, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
International Committee of the Red Cross members— (25 individuals) all Swiss nationals
(ICRC)
address— ICRC, 1 9 Avenue de la Paix, CH-1 202
Geneva, Switzerland
telephone-{41] (22) 734 60 01
FAY-[41](22)73320 57
established— 17 February 1863
aim— to provide humanitarian aid in wartime
International Confederation of Free Trade
Unions (ICFTU)
address— International Trade Union House,
Boulevard Emile Jacqmain 155, B-1210
Brussels, Belgium
telephone-132] (2) 224 0211
FAX-{32] (2) 201 58 15, 203 07 56
established— UA December 1949
aim— to promote the trade union movement
International Court of Justice (ICJ) merrrbers— (15 judges) elected by the UN General Assembly and Security Council to represent all principal legal
systems
rrofe— also known as the World Court
address— Peace Palace, NL-2517 KJ The
Hague, Netherlands
fe/ep/7or7e-{31] (70) 302 23 23
FAX-{31] (70) 364 99 28
estabiished—3 February 1946 superseded
Permanent Court of International Justice
a/m— primary judicial organ of the UN
members— (206 affiliated organizations in the following 141 countries) Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bangladesh, Barbados, Basque Country, Belgium, Belize, Benin, Bermuda,
Botswana, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, El
Salvador, Eritrea, Estonia, Falkland Islands, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Holy See, Honduras, Hong Kong, Hungary,
Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Latvia,
Lebanon, Liberia, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritius, Mexico, Moldova,
Mongolia, Montserrat, Morocco, Mozambique, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania,
Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka,
Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Uganda, UK, US, Vanuatu, Venezuela, Zambia, Zimbabwe
International Civil Aviation Organization
(ICAO)
address— ICAO, 999 University Street, Montreal
H3C 5H7, Canada
telephone-{1] (51 A) 954 8219
FAX-{1] (514) 954 6077
estabiished—7 December 1944
effecf/Ve— 4 April 1947
aim— to promote international cooperation in
civil aviation; a UN specialized agency
58:
Appendix C: International Organizations and Groups (continued)
International Criminal Police Organization
(Interpol)
address-6P 6041, F-69411 Lyon CEDEX 06,
telephone-{33] (4) 72 44 70 00
FA)C-[33](4)72 44 71 63
established— tiA September 1 923 set up as the
International Criminal Police Commission; 13
June 1956 constitution modified and present
name adopted
a/m— to promote international cooperation
among police authorities in fighting crime
International Development Association (IDA)
address— 1818 H Street NW, Washington, DC
20433, US
telephone-{t] (202) 477 1234
FAX-m (202) 477 6391
established— 23 January 1960
effective— 24 September 1960
a/m— UN specialized agency and IBRD affiliate
that provides economic loans for low income
countries
International Energy Agency (lEA)
address— 9 Rue de la Federation, F-75739 Paris
CEDEX 15, France
fe/ep/7one-[33](1)40 57 65 00
FAX-[33](1)40 57 65 09
established— 15 November 1974
a/m— to promote cooperation on energy
matters, especially emergency oil sharing and
relations between oil consumers and oil
producers; established by the OECD
members— (177) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
subbureaus— (14) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Guam,
Hong Kong, Macau, Montserrat, Northern Mariana Islands, Puerto Rico, Turks and Caicos Islands, Virgin Islands
members— (160)
Parti— {26 developed countries) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Iceland,
Ireland, Italy, Japan, Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South Africa, Spain, Sweden,
Switzerland, UAE, UK, US
Part II— {134 less developed countries) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Azerbaijan,
Bangladesh, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech
Republic, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana, Greece','1fa609a676b1daab1da6711dc3323084fbf9a1a20ef4347023b81be000dfc596','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('974e594f342ed315ba121540bc9f1c08e536f494e71ed5bfe0935fb47b599d81',2000,'FR','France','transnational-issues',206,', Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone,
Slovakia, Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia,','afaee8ef3a6999efce7f4016697efe932b2a8fab32fc2678145b71c0da34c994','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fcde86e2113c1502523338710ea4f599e01ace1a0744bd750a29a177de0754c',2000,'PF','French Polynesia','transnational-issues',207,'} (overseas territory acfe
lot Fiance) |^■■■
lies
Marquises
South Pacific
Ocean
Makatea^ . "
Uturoa''*, ''^PAPEETE
Archipel des
Tuamotu
Society 1,.,. “•
Islands
'' Mataura Mururoa
lies ■ •.
Tubuai
0 ^
o q
Rikitea^
,Rapa
^ o*
I Introduction
Background: The French annexed various
Polynesian island groups during the 19th century. In
September 1995, France stirred up widespread
protests by resuming nuclear testing on the Mururoa
atoll after a three-year moratorium. The tests were
suspended in January 1996.','173d5a53a3567aa9745a760a5c5c6dca28c43075b764e79db1fc23a820ca0247','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('348a6588bf7e2877e95aeca897858941618350528c2ccc87ffaee319f9867b3f',2000,'GH','Ghana','transnational-issues',213,'Background: Formed from the merger of the British
colony of the Gold Coast and the Togoland trust
territory, Ghana in 1957 became the first country in
colonial Africa to gain its independence. A long series
of coups resulted in the suspension of the constitution
in 1981 and the banning of political parties. A new
constitution, restoring multiparty politics, was
approved in 1992.','5f5194c19aab5e7e9f1980084a372a984c6aec1f908df3a1a96c054468b00889','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c51ee9f28c9ddb87a49053c2cd548b81e38681ff431fe15c84c4ef48b9596439',2000,'ES','Spain','transnational-issues',221,'Disputes - international: source of friction between
Spain and the UK
Glorioso Islands
(possession of France)','ace2343dbd0e4ec76402d040725783631ebb6660d6041b24481b7893690b2641','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f018835c56d8f2ff320e6cc1b32f22053915bba832c74538edad74f28c61fa8b',2000,'GY','Guyana','transnational-issues',230,'conventional short form: Guyana
former: British Guiana
Data code: GY
Government type: republic within the
Commonwealth
Capital; Georgetown
Administrative divisions: 10 regions;
Barima-Waini, Cuyuni-Mazaruni, Demerara-Mahaica,
East Berbice-Corentyne, Essequibo Islands-West
Demerara, Mahaica-Berbice, Pomeroon-Supenaam,
Potaro-Siparuni, Upper Demerara-Berbice, Upper
Takutu-Upper Essequibo
Independence: 26 May 1966 (from UK)
National holiday: Republic Day, 23 February (1 970)
Constitution: 6 October 1980
Legal system: based on English common law with
certain admixtures of Roman-Dutch law; has not
accepted compulsory ICJ jurisdiction
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: President Bharrat JAGDEO (since NA
August 1999); note - assumed presidency after
resignation of President JAGAN
head of government: Prime Minister Samuel HINDS
(since NA December 1997)
cabinet: Cabinet of Ministers appointed by the
president, responsible to the legislature
elections: president elected by the majority party in the
National Assembly following legislative elections, which
must be held at least every five years; elections last
held 15 December 1997 (next to be held by January
2001); prime minister appointed by the president
Legislative branch: unicameral National Assembly
(65 seats, 53 popularly elected; members serve
five-year terms)
213
Guysna (continued)
elections: last held 15 December 1997 (next to be
held by January 2001 ; this date was part of a
negotiated settlement between the two main poiiticai
parties foliowing a dispute over the December
elections)
election results: percent of vote by party - PPP 54%,
PNC 41%, AFG 1%, TUF 1%; seats by party - PPP
29, PNC 22, AFG 1, TUF 1
Judicial branch: Supreme Court of Judicature;
Judicial Court of Appeal; High Court
Political parties and leaders: Alliance for Guyana
or AFG [Rupert ROOPNARINE]; Democratic Labor
Movement or DLM [Paul TENNASSEE]; For a Good
and Green Guyana or GGG [Hamilton GREEN];
Guyana Democratic Party or GDP [Asgar ALLY];
Guyana Labor Party or GLP [leader NA]; Guyanese
Organization for Liberty and Democracy Party or
GOLD [Anthony MEKDECI]; National Democratic
Front or NDF [Joseph BACCHUS]; National
Republican Party or NRP [Robert GANGADEEN];
People''s Democratic Movement or PDM [Llewellyn
JOHN]; People''s National Congress or PNC [Hugh
Desmond HOYTE]; People''s Progressive Party or
PPP [leader NA]; The United Force or TUF [Manzoor
NADIR]; Working People''s Alliance or WPA [leader
NA]
Political pressure groups and leaders: Civil
Liberties Action Committee or CLAC; Guyana Council
of Indian Organizations or GCIO; Trades Union
Congress or TUC
note: the GCIO and the CLAC are small and active but
not well organized
International organization participation: ACP, C,
Caricom, CCC, CDB, ECLAC, FAO, G-77, iADB,
iBRD, iCAO, ICFTU, iCRM, IDA, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Intelsat (nonsignatory user), Interpol,
IOC, ISO (subscriber), ITU, LAES, NAM, OAS,
OPANAL, OPCW, PCA, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO, WlPO, WMO,
WTrO
Diplomatic representation in the US:
ch/ef of m/ss/on: Ambassador Dr. Ali Odeen
iSHMAEL
chancery; 2490 Tracy Place NW, Washington, DC
20008
fe/ep/ione;[1](202) 265-6900
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador James F. MACK
embassy: 99-1 00 Young and Duke Streets, Kingston,
Georgetown
mailing address:?. 0. Box 10507, Georgetown
telephone: [592] (2) 54900 through 54909, 57960
through 57969
FAX; [592] (2) 59497
Flag description: green, with a red isosceles
triangle (based on the hoist side) superimposed on a
long, yellow arrowhead; there is a narrow, black
border between the red and yellow, and a narrow,
white border between the yellow and the green','11cfd18a4273292bfb716e1271264c16de7f047ae5795a0f72db3f0f202bc1bd','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61f9c673ebbbe575ab98b789c32b1033e67cda8500744e896a5f8a3ae290f787',2000,'IS','Iceland','transnational-issues',242,'Disputes - international: Iran and Iraq restored
diplomatic relations in 1990 but are still trying to work
out written agreements settling outstanding disputes
from their eight-year war concerning border
demarcation, prisoners-of-war, and freedom of
navigation and sovereignty over the Shaft al Arab
waterway; Iran occupies two islands in the Persian
Gulf claimed by the UAE: Lesser Tunb (called Tunb as
Sughra in Arabic by UAE and Jazireh-ye Tonb-e
Kuchek in Persian by Iran) and Greater Tunb (called
Tunb al Kubra in Arabic by UAE and Jazireh-ye
Tonb-e Bozorg in Persian by Iran); Iran jointly
administers with the UAE an island in the Persian Gulf
claimed by the UAE (called Abu Musa in Arabic by
UAE and Jazireh-ye Abu Musa in Persian by Iran) -
over which Iran has taken steps to exert unilateral
control since 1 992, including access restrictions and a
military build-up on the island; the UAE has garnered
significant diplomatic support in the region in
protesting these Iranian actions; Caspian Sea
boundaries are not yet determined among Azerbaijan,
Iran, Kazakhstan, Russia, and Turkmenistan
Illicit drugs: despite substantial interdiction efforts,
Iran remains a key transshipment point for Southwest
Asian heroin to Europe; domestic consumption of
narcotics remains a persistent problem and Iranian
press reports estimate that there are at least 1 .2
million drug users in the country
Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total: 373 sq km
land: 373 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
contiguous zone: 1 0 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
Climate: arctic maritime with frequent storms and
persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen/Beerenberg 2,277
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100%
Irrigated land: 0sqkm(1993)
Natural hazards: dominated by the volcano Haakon
VII Toppen/Beerenberg; volcanic activity resumed in
1970
Environment - current issues: NA
Geography - note: barren volcanic island with some
moss and grass
250
Jan Mayen (continued)
I PeopfF
Population; no indigenous inhabitants
note; there are personnei who operate the Long
Range Navigation (Loran) C base and the weather
and coastai sen/ices radio station (July 2000 est.)
I Gove r in e n t
Country name:
conventional long form: none
conventional short form: Jan Mayen
Data code: JN
Dependency status: territory of Norway;
administered from Oslo through a governor
(sysselmann) resident in Longyearbyen (Svalbard);
however, authority has been delegated to a station
commander of the Norwegian Defense
Communication Service
Flag description: the flag of Norway is used
I E c 0 n oTm y
Economy - overview: Jan Mayen is a volcanic
island with no exploitable natural resources.
Economic activity is limited to providing services for
employees of Norway''s radio and meteorological
stations located on the island.
I “c 0 nTm u n i c a t i 0 n s
Radio broadcast stations: AM NA, FM NA,
shortwave NA
note: there is one radio and meteorological station
(1998)','10912fe59681501f54b6fc7ed5ec4a533b43c7dd0901c8841f312f64babff7f3','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c368f5ea9037cbe547c284d8855f29cdd6ec323801bb8251eef1b64c4c112fde',2000,'IQ','Iraq','transnational-issues',243,'Background: Formerly part of the Ottoman Empire,
Iraq became an independent kingdom in 1932. A
"republic" was proclaimed in 1958, but in actuality a
series of military strongmen have ruled the country
since then, the late?t being SADDAM Husayn.
Territorial disputes with Iran led to an inconclusive and
costly eight-year war (1980-1988). In August 1990
Iraq seized Kuwait, but was expelled by US-led, UN
coalition forces during January-February 1991 . The
victors did not occupy Iraq, however, thus allowing the
regime to stay in control. Following Kuwait''s liberation,
the UN Security Council (UNSC) required Iraq to
scrap all weapons of mass destruction and long-range
missiles and to allow UN verification inspections. UN
trade sanctions remain in effect due to incomplete
Iraqi compliance with relevant UNSC resolutions.
Disputes - international: Northern Ireland issue
with the UK (historic peace agreement signed 1 0 April
1998); Rockall continental shelf dispute involving
Denmark, Iceland, and the UK (Ireland and the UK
have signed a boundary agreement in the Rockall
area)
Illicit drugs: transshipment point for and consumer
of hashish from North Africa to the UK and
Netherlands and of European-produced synthetic
drugs; minor transshipment point for heroin and
cocaine destined for Western Europe
242
Background: Following World War II, the British
withdrew from their mandate of Palestine, and the UN
partitioned the area into Arab and Jewish states, an
arrangement rejected by the Arabs. Subsequently, the
Israelis defeated the Arabs in a series of wars without
ending the deep tensions between the two sides. The
territories occupied by israel since the 1967 war are
not included in the Isreal country profile, unless
otherwise noted, in keeping with the framework
established at the Madrid Conference in October 1 991 ,
bilateral negotiations are being conducted between
Israel and Palestinian representatives (from the
israeli-occupied West Bank and Gaza Strip) and israel
and Syria, to achieve a permanent settiement. On 25
April 1 982, Israel withdrew from the Sinai pursuant to
the 1979 israel-Egypt Peace Treaty. Outstanding
territorial and other disputes with Jordan were resolved
in the 26 October 1 994 israel-Jordan Treaty of Peace.
f Geography
Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area - comparative: slightly smaller than New','0faabf6721997b85da0957ef64f25365397eccfc477e3d8deae67c46d20078bb','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28524d422d08b664d07c27a3364f6a1ff31eb3513c2fd57e5ba24ee387656a92',2000,'TN','Tunisia','transnational-issues',258,'Disputes - internationai: none
Illicit drugs: transshipment point for cocaine from
Central and South America to North America and
Europe; illicit cultivation of cannabis; government has
an active manual cannabis eradication program
914 to 1,523 m: 2
under 914 m: 23 (1 999 est.)
Jan Mayen
; (territory of Norway)
Location: Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast of','2f2647b128585f9e4972f2d5b6b5b5fd0d34728168adfaea8d2716d1165b57c9','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b721c9378cdaca4586742e7c99efd3eec9fe30a71c116e87c97ce8714ed7556d',2000,'JO','Jordan','transnational-issues',260,'conventional short form: Jordan
local long form:M Mamiakah al Urduniyah al
Hashimiyah
local short form: Al Urdun
former: Transjordan
Data code: JO
Government type: constitutional monarchy
Capital: Amman
Administrative divisions: 12 governorates
(muhafazat, singular - muhafazah); Ajiun, Al ''Aqabah,
Al Balqa'', Al Karak, Al Mafraq, ''Amman, At Tafilah, Az
Zarqa'', Irbid, Jarash, Ma''an, Madaba
Independence: 25 May 1946 (from League of
Nations mandate under British administration)
National holiday: Independence Day, 25 May (1 946)
Constitution: 8 January 1952
Legal system: based on Islamic law and French
codes; judicial review of legislative acts in a specially
provided High Tribunal; has not accepted compulsory
ICJ jurisdiction
Suffrage: 20 years of age; universal
Executive branch:
chief of state: King ABDALLAH bin al Hussein (since
7 February 1999); Crown Prince HAMZAH bin al
Hussein (half brother of the King, born 29 March 1 980)
head of government: Prime Minister Abdur-Rauf
RAWABDEH (since 4 March 1999)
cabinet: Cabinet appointed by the prime minister in
consultation with the monarch
elections: none; the monarch is hereditary; prime
minister appointed by the monarch
Legislative branch: bicameral National Assembly or
Majlis al-''Umma consists of the Senate (a 40-member
body appointed by the monarch from designated
categories of public figures; members serve four-year
terms) and the House of Representatives (80 seats;
members elected by popular vote on the basis of
proportional representation to serve four-year terms)
elections: House of Representatives - last held 4
November 1 997 (next to be held N A November 2001 )
election results: House of Representatives - percent
of vote by party - NA; seats by party - National
Constitutional Party 2, Arab Land Party 1,
independents 75, other 2
note; the House of Representatives has been
convened and dissolved by the monarch several
times since 1974; in November 1989 the first
parliamentary elections in 22 years were held
Judicial branch: Court of Cassation; Supreme
Court (court of final appeal)
Political parties and leaders: Al-Ahrar (Freedom)
Party [Dr. Ahmad ZO''BI, secretary general]; Arab
Ba''th Progressive Party [Mahmoud al-MA''AYTAH,
secretary general]; Arab Islamic Democratic Party
(Doa''a) [Yousif ABU BAKR, secretary general]; Arab
Jordanian Ansar Party [Muhammad MAJALI,
secretary general]; Arab Land Party [Dr. Muhammad
257
Jordan (continued)
al-''ORAN, secretary general]; Democratic Party of the
Left [Musa MA''AITAH, secretary general]; Islamic
Action Front [Abd-al-Latif ARABIYAT, secretary
general]; Jordanian Arab Constitutional Front Party
[Milhem TELL, secretary general]; Jordanian Arab
New Dawn Party [leader NA]; Jordanian Ba''th Arab
Socialist Party [Tayseer al-HOMSI, secretary
general]; Jordanian Communist Party [Ya''acoub
ZAYADIN, secretary general]; Jordanian Democratic
Popular Unity Party [Sa''eed MUSTAPFIA, secretary
general]; Jordanian Labor Party [Muhammad
KHATAYIBAH, secretary general]; Jordanian Peace
Party [Dr. Shaher KHREIS, secretary general];
Jordanian People''s Democratic Party or HASFID
[Salem NAHHAS, secretary general]; Al-Mustaqbal
(Future) Party [Suleiman ''ARAR, secretary general];
National Action Party or Haqq [Muhammad ZO''BI,
secretary general]; National Constitutional Party
[Abdul Fladi MAJALI, secretary general]; National
Democratic Public Movement Party [Muhammad
al-''AMER, secretary general]; Progressive Party
[Na''el BARAKAT, secretary general]; Al-Umma
(Nation) Party [Ahmad HNEIDI, secretary general];
The Generations [Hamad al-KHALAYLA, chairman]
Political pressure groups and leaders; Council of
Professional Association Presidents [Ahmad
al-QADIRI, chairman]; Jordanian Press Association
[Sayf al-SHARiF, president]; Muslim Brotherhood
[Abd-al-Majid DHUNAYBAT, secretary general]
International organization participation: ABEDA,
ACC, AFESD, AL, AMF, CAEU, CCC, ESCWA, FAO,
G-77, iAEA, iBRD, iCAO, ICC, ICFTU, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Intelsat,
Interpol, IOC, lOM (observer), ISO (correspondent),
ITU, NAM, OIC, OPCW, OSCE (partner), PCA, UN,
UNCTAD, UNESCO, UNIDO, UNMIBH, UNMIK,
UNMOP, UNMOT, UNOMIG, UNRWA, UNTAET,
UPU, WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Marwan Jamil
MUASHER
chancery: 3504 International Drive NW, Washington,
DC 20008
fe/eptone;[1](202) 966-2664
FAY; [1] (202) 966-3110
Diplomatic representation from the US:
chief of mission: Ambassador William BURNS
embassy: Abdoum, Amman
maiiing address: P. 0. Box 354, Amman 11118
Jordan; APO AE 09892-0200
telephone: [962] {6) 5920101
FAY; [962] (6) 5927712
Flag description: three equal horizontal bands of
black (top), white, and green with a red isosceles
triangle based on the hoist side bearing a small white
seven-pointed star; the seven points on the star
represent the seven fundamental laws of the Koran','aa12be5652216deffd85c12da5227933dbffa575cf3f326afadad2e5ee6fccd2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54c734117119253ba8b3f37d7109aff4a7be08ed0a132288bf4f8829389e2b39',2000,'JP','Japan','transnational-issues',278,'Disputes - international: Demarcation Line with
North Korea; Liancourt Rocks (Takeshima/Tokdo)
claimed by Japan
in t to d u c t i 0 n
Background: Kuwait was attacked and overrun by
Iraq on 2 August 1990. Following several weeks of
aerial bombardment, a US-led UN coalition began a
ground assault on 23 February 1991 that completely
liberated Kuwait in four days. Kuwait has spent more
than $5 billion dollars to repair oil infrastructure
damaged during 1990-91.
Location: Middle East, bordering the Persian Gulf,
between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total: 17,820 sq km
land: 17,820 sq km
wafer; 0 sq km
Area - comparative: slightly smaller than New Jersey
Land boundaries:
total: 464 km
border countries: Iraq 242 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 nm
Climate: dry desert; intensely hot summers; short,
cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural
gas
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 8%
forests and woodland: 0%
other: 92% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: sudden cloudbursts are common
from October to April; they bring inordinate amounts of
rain which can damage roads and houses; sandstorms
and dust storms occur throughout the year, but are
most common between March and August
Environment - current issues: limited natural fresh
water resources; some of world''s largest and most
sophisticated desalination facilities provide much of
the water; air and water pollution; desertification
Environment - international agreements:
party to: Climate Change, Desertification,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Nuclear Test Ban,
Ozone Layer Protection
signed, but not ratified: Biodiversity, Endangered
Species, Marine Dumping
Geography - note: strategic location at head of
Persian Gulf
I " People
Population: 1,973,572
note: includes 1,1 59,91 3 non-nationals (July 2000 est.)
Age structure:
0-14 years: 29.36% (male 295,102; female 284,327)
15-64 years: 68.32% (male 860,31 8; female 488,004)
65 years and over: 2.32% (male 29,544; female
16,277) (2000 est.)
Population growth rate: 3.44% (2000 est.)
note: this rate reflects a return to pre-Gulf crisis
immigration of expatriates
Birth rate: 22.04 births/1 ,000 population (2000 est.)
Death rate: 2.45 deaths/1 ,000 population
(2000 est.)
Net migration rate: 14.77 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .76 male(s)/female
65 years and over: 1 .82 male(s)/female
total population: 1 .5 male(s)/female (2000 est.)
Infant mortality rate: 1 1 .55 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 76.08 years
male: 75.27 years
female: 76.92 years (2000 est.)
Total fertility rate: 3.26 children born/woman
(2000 est.)
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 45%, Shi''a 40%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 78.6%
male: 82.2%
female: 74.9% (1995 est.)
272
Kuwait (continued)
I Government
Country name:
conventional long form: State of Kuwait
conventional short form: Kuwait
local long form: Dawiat al Kuwayt
local short form: Ai Kuwayt
Data code: KU
Government type: nominal constitutional monarchy
Capital: Kuwait
Administrative divisions: 5 governorates
(muhafazat, singular - muhafazah); Al Ahmadi, Al
Farwaniyah, Al ''Asimah, Al Jahra'', Hawalli
Independence: 19 June 1961 (from UK)
National holiday: National Day, 25 February (1 950)
Constitution: approved and promulgated 1 1
November 1962
Legal system: civil law system with Islamic law
significant in personal matters; has not accepted
compulsory ICJ jurisdiction
Suffrage: adult males who have been naturalized for
30 years or more or have resided in Kuwait since
before 1920 and their male descendants at age 21
note: only 1 0% of all citizens are eligible to vote; in
1996, naturalized citizens who do not meet the
pre-1920 qualification but have been naturalized for
30 years were eligible to vote for the first time
Executive branch:
chief of state: Amir JABIR al-Ahmad al-Jabir Al Sabah
(since 31 December 1977)
head of government: Prime Minister and Crown
Prince SAAD al-Abdallah al-Salim Al Sabah (since 8
February 1978); First Deputy Prime Minister SABAH
al-Ahmad al-Jabir Al Sabah (since 17 October 1992);
Second Deputy Prime Minister SALIM al-Sabah
al-Salim Al Sabah (since 7 October 1996)
cabinet: Council of Ministers appointed by the prime
minister and approved by the monarch
elections: none; the monarch is hereditary; prime
minister and deputy prime ministers appointed by the
monarch
Legislative branch: unicameral National Assembly
or Majlis al-Umma (50 seats; members elected by
popular vote to sen/e four-year terms)
elections: last held 3 July 1999 (next to be held NA
2003)
election results: percent of vote - NA; seats -
independents 50; note - all cabinet ministers are also
ex officio members of the National Assembly
Judicial branch: High Court of Appeal
Political parties and leaders: none
Political pressure groups and leaders: several
political groups act as de facto parties: Bedouins,
merchants, Sunni and Shi''a activists, and secular
leftists and nationalists
International organization participation: ABEDA,
AfDB, AFESD, AL, AMF, BDEAC, CAEU, CCC,
ESCWA, FAO, G-77, GCC, IAEA, IBRD, ICAO, ICC,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, IHO (pending
member), ILO, IMF, IMO, Inmarsat, Intelsat, Interpol,
IOC, ISO (correspondent), ITU, NAM, OAPEC, OIC,
OPCW, OPEC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WFTU, WHO, WlPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador MUHAMMAD al-Sabah
al-Salim Al SABAH
chancery: 2940 Tilden Street NW, Washington, DC
20008
feteptae.''II 1(202) 966-0702
FAX; [1] (202) 966-0517
Diplomatic representation from the US:
chief of mission: Ambassador James A. LAROCCO
embassy: Bayan, near the Bayan palace, Kuwait City
mailing address: P. 0. Box 77 Safat, 13001 Safat,
Kuwait; Unit 69000, APO AE 09880-9000
telephone: [965] 539-5307 or 539-5308
FAX; [965] 538-0282
Flag description: three equal horizontal bands of
green (top), white, and red with a black trapezoid
based on the hoist side
|r '' '' I''ic''o n 0 m''y”"™
Economy - overview: Kuwait is a small, relatively
open economy with proved crude oil reserves of about
94 billion barrels - 10% of world reserves. Petroleum
accounts for nearly half of GDP, 90% of export
revenues, and 75% of government income. Kuwait
lacks water and has practically no arable land, thus
preventing development of agriculture. With the
exception of fish, it depends almost wholly on food
imports. About 75% of potable water must be distilled
or imported. Higher oil prices reduced the budget
deficit from $5.5 billion to $3 billion in 1 999, and prices
are expected to remain relatively strong throughout
2000. The government is proceeding slowly with
reforms. It inaugurated Kuwait''s first free-trade zone in
1999 and will continue discussions with foreign oil
companies to develop fields in the northern part of the
country,
GDP: purchasing power parity - $44.8 billion
(1999est.)
GDP - real growth rate: 1.1% (1999 est.)
GDP - per capita: purchasing power parity -
$22,500(1999 est.)
GDP - composition by sector:
agriculture: 0%
industry: 55%
services: 45% (1996)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2% (1999 est.)
Labor force: 1 .3 million (1 998 est.)
note: 68% of the population in the 1 5-64 age group is
non-national (July 1998 est.)
Labor force - by occupation: government and
social services 50%, services 40%, industry and
agriculture 10% (1996 est.)
Unemployment rate: 1.8% (official 1996 est.)
Budget:
revenues; $10 billion
expenditures: $13 billion, including capital
expenditures of $NA (1999 est.)
Industries; petroleum, petrochemicals, desalination,
food processing, construction materials, salt,
construction
Industrial production growth rate; 1% (1997 est.)
Electricity - production: 26.995 billion kWh (1998)
Electricity - production by source;
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (1998)
Electricity - consumption: 25.105 billion kWh
(1998)
Electricity - exports: 0 kWh (1 998)
Electricity - imports; 0 kWh (1998)
Agriculture - products; practically no crops; fish
Exports; $13.5 billion (f.o.b., 1999 est.)
Exports - commodities: oil and refined products,
fertilizers
Exports - partners; Japan 24%, India 16%, US
13%, South Korea 11%, Singapore 8% (1997)
Imports: $8.1 billion (f.o.b., 1999 est.)
Imports - commodities; food, construction
materials, vehicles and parts, clothing
Imports - partners: US 22%, Japan 15%, UK 13%,
Germany 8%, Italy 6% (1997)
Debt - external: $9.27 billion (1 998 est.)
Economic aid ■ recipient: $27.6 million (1995)
Currency: 1 Kuwaiti dinar (KD) = 1 ,000 fils
Exchange rates: Kuwaiti dinars (KD) per US$1 -
0.3042 (January 2000), 0.3044 (1 999), 0.3047 (1 998),
0.3033 (1997), 0.2994 (1996), 0.2984 (1995)
Fiscal year; 1 July - 30 June
I C 0 nTm u n i c a tT o ri s™
Telephones - main lines in use; 41 1 ,600 (1997)
Telephones - mobile cellular; 1 50,000 (1 996)
Telephone system; the civil network suffered some
damage as a result of the Gulf war, but most of the
telephone exchanges were left intact and, by the end
of 1994, domestic and international
telecommunications had been restored to normal
operation; the quality of service is excellent
domestic: new telephone exchanges provide a large
capacity for new subscribers; trunk traffic is carried by
microwave radio relay, coaxial cable, open wire and
fiber-optic cable; a cellular telephone system operates
throughout Kuwait, and the country is well supplied
with pay telephones; approximately 15,000 Internet
subscribers in 1996
international: coaxial cable and microwave radio relay
to Saudi Arabia; linked to Bahrain, Qatar, UAE via the
Fiber-Optic Gulf (FOG) cable; satellite earth stations -
3 Intelsat (1 Atlantic Ocean, 2 Indian Ocean), 1
Inmarsat (Atlantic Ocean), and 2 Arabsat
Radio broadcast stations; AM 6, FM 1 1 , shortwave
1 (1998)
Radios: 1.175 million (1997)
Television broadcast stations; 13 (plus several
satellite channels) (1997)
Televisions: 875,000(1997)
Internet Service Providers (ISPs): 2 (1999)
273
Kuwait (continued)
Disputes - international: in November 1994, Iraq
formally accepted the UN-demarcated border with
Kuwait which had been spelled out in Security Council
Resolutions 687 (1991), 773 (1993), and 883 (1993);
this formally ends earlier claims to Kuwait and to
Bubiyan and Warbah islands; ownership of Qaruh and
Umm al Maradim islands disputed by Saudi Arabia','4a42cf2fe372e68f563e577ac31aa26aa87b2b243d38ba891c6c7d84de474264','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a49fd4cb96cca97c81a576d6b70207880efb8651a8ff8d53977d6e11649f3e5',2000,'CN','China','transnational-issues',286,'Disputes - international: territorial dispute with
Tajikistan on southwestern boundary in Isfara Valley
area; periodic target of Islamic terrorists from
Uzbekistan and Tajikistan
Illicit drugs: limited illicit cultivator of cannabis and
opium poppy, mostly for CIS consumption; limited
government eradication program; increasingly used
as transshipment point for illicit drugs to Russia and
Western Europe from Southwest Asia
276
1 n t r 0 d u c t i on
Background; In 1975 the communist Pathet Lao
took control of the government, ending a
six-century-old monarchy. Initial closerties to Vietnam
and socialization were replaced with a gradual return
to private enterprise, an easing of foreign investment
laws, and the admission into ASEAN in 1997.
1^ Geography
Location: - Southeastern Asia, northeast of Thailand,
west of Vietnam
Geographic coordinates; 18 00 N, 105 00 E
Map references: Southeast Asia
Area;
total: 236,800 sq km
/and; 230,800 sq km
water 6,000 sq km
Area - comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km,
China 423 km, Thailand 1 ,754 km, Vietnam 2,130 km
Coastline; 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to
November); dry season (December to April)
Terrain; mostly rugged mountains; some plains and
plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources; timber, hydropower, gypsum,
tin, gold, gemstones
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 3%
forests and woodland: 54%
of/rer;40%(1993 est.)
Irrigated land; 1 ,250 sq km (1993 est.)
note: rainy season irrigation - 2,169 sq km; dry
season irrigation - 750 sq km (1998 est.)
Natural hazards; floods, droughts, and blight
Environment - current issues: unexploded
ordnance; deforestation; soil erosion; a majority of the
population does not have access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Law of
the Sea, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
p
Population; 5,497,459 (July 2000 est.)
Age structure:
0-/4 years; 43% (male 1,191,608; female 1,173,144)
15-64 years: 54% (male 1,447,788; female
1,500,016)
65 years and over: 3% (male 85,028; female 99,875)
(2000 est.)
Population growth rate: 2.5% (2000 est.)
Birth rate: 38.29 births/1,000 population (2000 est.)
Death rate: 1 3.35 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2000 est.)
Sex ratio;
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.98 male(s)/female (2000 est.)
Infant mortality rate: 94.8 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 53.09 years
male: 51. 22 years
female: 55.02 years (2000 est.)
Total fertility rate: 5.21 children born/woman
(2000 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong ("Meo") and the Yao (Mien) 9%, ethnic
Vietnamese/Chinese 1%
Religions: Buddhist 60% (in October 1999, the
regime proposed a constitutional amendment making
Buddhism the state religion; the National Assembly is
expected to vote on the amendment sometime in
2000), animist and other 40%
Languages: Lao (official), French, English, and
various ethnic languages
Literacy:
deflnltlon: age 15 and over can read and write
total population: 57%
male: 70%
female: 44% (1999 est.)
f; Gove r n me nt
Country name:
conventional long form: Lao People''s Democratic
Republic
conventional short form: Laos
local long form: Sathalanalat Paxathipatai Paxaxon
Lao
local short form: none
Data code; LA
Government type: Communist state
Capital: Vientiane
Administrative divisions; 16 provinces (khoueng,
singular and plural), 1 municipality* (kampheng
nakhon, singular and plural), and 1 special zone**
(khetphlset, singular and plural); Attapu, Bokeo,
Bolikhamxai, Champasak, Houaphan, Khammouan,
Louangnamtha, Louangphabang, Oudomxal,
Phongsali, Salavan, Savannakhet, Viangchan*,
Viangchan, Xaignabouli, Xaisomboun**, Xekong,
Xiangkhoang
Independence; 19 July 1949 (from France)
National holiday; National Day, 2 December (1 975)
(proclamation of the Lao People''s Democratic
Republic)
Constitution: promulgated 14 August 1991
Legal system; based on traditional customs, French
legal norms and procedures, and Socialist practice
Suffrage; 18 years of age; universal
Executive branch:
chief of state: President KHAMTAI Siphandon (since
26 February 1 998); note - currently the position of vice
president is vacant; Vice President OUDOM Khattiya
died on 9 December 1 999 and a replacement has not
yet been named
head of government: Prime Minister SISAVAT
Keobounphan (since 26 February 1998); Senior
Deputy Prime Minister BOUN-NHANG Vorachith
(since 20 April 1996); Deputy Prime Ministers
CHOUMMALI Saygnasone (since 26 February 1998),
SOMSAVAT Lengsavad (since 26 February 1998)
cabinet: Council of Ministers appointed by the
president, approved by the National Assembly
elections: president elected by the National Assembly
for a five-year term; election last held 21 December
1 997 (next to be held NA 2002); prime minister
appointed by the president with the approval of the
National Assembly for a five-year term
election results: KHAMTAI Siphandon elected
president; percent of National Assembly vote - NA
Legislative branch: unicameral National Assembly
(99 seats; members elected by popular vote to serve
five-year terms; note - by presidential decree, on 27
October 1 997, the number of seats increased from 85
to 99)
elections: last held 21 December 1997 (next to be
held NA2002)
election results: percent of vote by party - NA; seats
by party - LPRP or LPRP-approved (independent,
non-party members) 99
Judicial branch; People''s Supreme Court, the
president of the People''s Supreme Court is elected by
277
Laos (continued)
the National Assembly on the recommendation of the
National Assembly Standing Committee, the vice
president of the People''s Supreme Court and the
judges are appointed by the National Assembly
Standing Committee
Political parties and leaders; Lao People''s
Revolutionary Party or LPRP [KHAMTAI Siphandon,
party president]; other parties proscribed
Political pressure groups and leaders;
noncommunist political groups proscribed; most
opposition leaders fled the country in 1975
International organization participation; ACCT,
AsDB, ASEAN, CP, ESCAP, FAO, G-77, IBRD, ICAO,
ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, Intelsat
(nonsignatory user), Interpol, IOC, ITU, NAM, OPCW,
PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WFU,
WHO, WlPO, WMO, WToO, WTrO (observer)
Diplomatic representation in the US;
chief of mission: Ambassador VANG Rattanavong
chancery: 2222 S Street NW, Washington, DC 20008
fe/eptone;[1] (202) 332-6416
FAX: [1] (202) 332-4923
Diplomatic representation from the US;
chief of mission: Ambassador Wendy Jean
CHAMBERLIN
embassy; Rue Bartholonie, B. P. 114, Vientiane
mailing address: American Embassy, Box V, APO AP
96546
telephone: [856] (21) 212581, 212582, 212585
FAX; [8561(21) 212584
Flag description; three horizontal bands of red
(top), blue (double width), and red with a large white
disk centered in the blue band
j Economy
Economy ■ overview; The government of Laos -
one of the few remaining official communist states -
began decentralizing control and encouraging private
enterprise in 1986. The results, starting from an
extremely low base, were striking - growth averaged
7% in 1988-96. Since mid-1996, however, reform
efforts have slowed, and the economy has suffered as
a result. Because Laos depends heavily on its trade
with Thailand, it was further damaged by the regional
financial crisis beginning in 1997. From June 1997 to
June 1999 the Lao kip lost 87%, and reached a crisis
point in September 1999 when it fluctuated wildly,
falling from 3,500 kip to the dollar to 9,000 kip to the
dollar in a matter of weeks. Now that the currency has
stabilized, however, the government seems content to
let the current situation persist, despite 1 40% inflation
in 1999 and limited foreign exchange reserves. A
landlocked country with a primitive infrastructure,
Laos has no railroads, a rudimentary road system,
and limited external and internal telecommunications.
Electricity is available in only a few urban areas.
Subsistence agriculture accounts for half of GDP and
provides 80% of total employment. For the
foreseeable future the economy will continue to
depend on aid from the IMF and other international
sources; Japan is currently the largest bilateral aid
donor; aid from the former USSR/Eastern Europe has
been cut sharply. As in many developing countries,
deforestation and soil erosion will hamper efforts to
attain a high rate of GDP growth.
GDP; purchasing power parity - $7 billion (1 999 est.)
GDP - real growth rale; 5.2% (1999 est.)
GDP - per capita; purchasing power parity - $1 ,300
(1999 est.)
GDP - composition by sector;
agriculture: 51%
industry: 22%
services: 27% (1999 est.)
Population beiow poverty iine; 46.1% (1993 est.)
Household income or consumption by percentage
share;
lowest 10%: 4.2%
highest 10%; 26.4% (1992)
Inflation rate (consumer prices); 1 40% (1 999 est.)
Labor force; 1 million - 1.5 million
Labor force - by occupation; agriculture 80%
(1997 est.)
Unemployment rate; 5.7% (1997 est.)
Budget;
revenues: $202.7 million
expenditures: $385.1 million, including capital
expenditures of $NA (FY97/98 est.)
Industries; tin and gypsum mining, timber, electric
power, agricultural processing, construction,
garments
Industrial production growth rate; 7.5%
(1999 est.)
Electricity - production; 1 .34 billion kVtfh (1 998)
Electricity • production by source;
fossil fuel: 2.99%
hydro; 97.01%
nuclear: 0%
other; 0% (1998)
Electricity - consumption; 514 million kWh (1998)
Electricity - exports; 782 million kWh (1 998)
Electricity - imports; 50 million kWh (1998)
Agriculture - products; sweet potatoes,
vegetables, corn, coffee, sugarcane, tobacco, cotton;
tea, peanuts, rice; water buffalo, pigs, cattle, poultry
Exports; $271 million (f.o.b., 1999 est.)
Exports - commodities; wood products, garments,
electricity, coffee, tin
Exports - partners; Vietnam, Thailand, Germany,
France, Belgium
Imports; $497 million (f.o.b., 1999 est.)
Imports - commodities; machinery and equipment,
vehicles, fuel
Imports - partners: Thailand, Japan, Vietnam,
China, Singapore, Hong Kong
Debt - external: $2.32 billion (1997 est.)
Economic aid - recipient: $345 million (1999 est.)
Currency: 1 new kip (NK) = 100 at
Exchange rates: new kips (NK) per US$1 - 7,674.00
(January 2000),7, 102.03 (1999), 3,298.33 (1998),
1,259.98 (1997), 921.02 (1996), 804.69 (1995)
note: as of September 1995, a floating exchange rate
policy was adopted
Fiscal year: 1 October - 30 September
Sea
Island
Fiery Cross
Reef f
"Spratly
Island
Amboyna''
Cay
West York
* Jsland
^''^Thilu Island r''Idt
Sand Cays^oaita Island ,A ''
Itu Aba Island'' • ^"^Idad Reef ^gnshan
- , ^^Namyit ** island
I _ Island
Sin Cowe-^^''y" Mischief^ ^
Island '' Reef V
Alisoi^
Reef
Pigeon Reef Half^
'' Moon ''','30f32f55c4230a34624adc3ade235e3c71a6dd0e76af4334aaaf126872e77272','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35b8974cf5bb3388586a695862f8d96fd8a692ba271cd7356fe578c42f2067ea',2000,'EG','Egypt','transnational-issues',295,'Disputes - international: maritime boundary
dispute with Tunisia; Libya claims about 19,400 sq km
in northern Niger and part of southeastern Algeria','9029b9c165918b9f00807a0337ac2a874792cd10e8535006635e4d41d54c4a0a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf0fe387963d8d11a3f8304f7bba74de9d93769e3e865aa3da97dae2113ab50',2000,'CH','Switzerland','transnational-issues',302,'Disputes • international: ongoing talks over
maritime boundary dispute with Latvia (primary
concern is oil exploration rights); 1997 border
agreement with Russia not yet ratified
Illicit drugs: transshipment point for opiates and
other illicit drugs from Southwest Asia, Latin America,
and Western Europe to Western Europe and
Scandinavia
294
I introduction
Background; Founded in 963, Luxembourg became
a grand duchy in 1815 and an independent state
under the Netherlands. It lost more than half of its
territory to Belgium in 1839, but gained a larger
measure of autonomy. Full independence was
attained in 1867. Overrun by Germany in both World
Wars, it ended its neutrality in 1948 when it entered
into the Benelux Customs Union and when it joined
NATO the following year. In 1957, Luxembourg
became one of the six founding countries of the
European Economic Community (later the European
Union) and in 1999 it joined the euro currency area.
I’ GeogTap''hy
Location: Western Europe, between France and
fe/eptone-[41](22)7304222
FA)H41] (22) 733 0395
established— 5 May 1919
a/m— to organize, coordinate, and direct
international relief actions; to promote
humanitarian activities; to represent and
encourage the development of National
Societies; to bring help to victims of armed
confiicts, refugees, and displaced people; to
reduce the vulnerability of people through
development programs
International Finance Corporation (IFC)
address— 2121 Pennsylvania Avenue NW,
Washington, DC 20433, US
telephone-{^ (202) 477 1234
FAX-[1] (202) 974 4384, 477 6391
established— 25 May 1955
effective— 2A July 1956
a/m— to support private enterprise in
international economic development; a UN
specialized agency and IBRD affiliate
International Fund for Agricultural
Development (IFAD)
address— Via dei Serafico 107, 1-00142 Rome,
fe/ep/ione-[41] (22) 734 60 01
FAX-{41] (22) 733 20 57
established— HA 1928
a/m— to promote worldwide humanitarian aid
through the International Committee of the Red
Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent
Societies (IFRCS; formerly League of Red
Cross and Red Crescent Societies or LORCS) in
peacetime
members— (69) Albania, Angola, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Bolivia, Bulgaria,
Canada, Chile, Colombia, Costa Rica, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Finland, France, Germany, Greece, Guatemala, Guinea-Bissau, Haiti, Honduras, Hungary,
Israel, Italy, Japan, Kenya, South Korea, Liberia, Lithuania, Luxembourg, Mali, Morocco, Netherlands, Nicaragua,
Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Senegal, Slovakia, South
Africa, Sri Lanka, Sudan, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Tunisia, Uganda, US, Uruguay,
Venezuela, Yemen, Zambia
observers— (47) Afghanistan, Algeria, Belarus, Belize, Bosnia and Herzegovina, Brazil, Cape Verde, Democratic
Republic of the Congo, Republic of the Congo, Cuba, Estonia, Ethiopia, Georgia, Ghana, Guinea, Holy See, India,
Indonesia, Iran, Ireland, Jamaica, Jordan, Kazakhstan, Kyrgyzstan, Latvia, Madagascar, Malta, Mexico, Moldova,
Mozambique, Namibia, NZ, Papua New Guinea, Russia, Rwanda, San Marino, Sao Tome and Principe, Slovenia,
Somalia, Spain, Turkey, Turkmenistan, Ukraine, UK, Vietnam, Yugoslavia, Zimbabwe
members— (88 national standards organizations) Albania, Algeria, Argentina, Armenia, Australia, Austria,
Bangladesh, Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada, Chile, China,
Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Ethiopia, Finland,
France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan,
Kazakhstan, Kenya, North Korea, South Korea, Libya, Luxembourg, The Former Yugoslav Republic of Macedonia,
Malaysia, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Philippines,
Poland, Portugal, Romania, Russia, Saudi Arabia, Serbia and Montenegro, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey,
Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Zimbabwe
correspor)dent members— (35) Azerbaijan, Bahrain, Barbados, Bolivia, Brunei, Cote d''Ivoire, El Salvador, Estonia,
Georgia, Guatemala, Guinea, Hong Kong, Jordan, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lithuania, Madagascar,
Malawi, Malta, Moldova, Mozambique, Nepal, Nicaragua, Oman, Papua New Guinea, Paraguay, Peru, Qatar,
Seychelles, Sudan, Turkmenistan, Uganda, UAE
subscriber members— (9) Benin, Cambodia, Democratic Republic of the Congo, Dominican Republic, Fiji, Grenada,
Guyana, Namibia, Saint Lucia
National Societies— (175 countries) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland,
France, The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zambia, Zimbabwe
592
Appendix C: International Organizations and Groups (continued)
International Telecommunication Union (ITU) members— {^88) Afghanistan, Albania, Aigeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Austraiia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangiadesh, Barbados, Belarus, Belgium, Belize, Benin,
address— Piace des Nations, CH-1211 Geneva Bhutan, Boiivia, Bosnia and Herzegovina, Botswana, Brazii, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
20, Switzerland Cambodia, Cameroon, Canada, Cape Verde, Centrai African Republic, Chad, Chiie, China, Colombia, Comoros,
telephone— {4^ ] (22) 730 6039 Democratic Repubiic of the Congo, Repubiic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
[41] (22) 733 7256, 730 5939 Republic, Denmark, Djibouti, Dominica, Dominican Repubiic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
established— May 1865 set up as the Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Internationai Telegraph Union; 9 December Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Hoiy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
1932 adopted present name Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
effective— t January 1934 Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
affiiiated with the UN— 15 November 1947 Yugoslav Republic of Macedonia, Madagascar, Maiawi, Maiaysia, Maidives, Mali, Malta, Marshall Islands,
aim— to deal with worid telecommunications Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moidova, Monaco, Mongoiia, Morocco,
issues; a UN specialized agency Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziiand, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvaiu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
International Telecommunications Sateliite members— (143) Afghanistan, Aigeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Organization (Inteisat) Bahrain, Bangladesh, Barbados, Belgium, Benin, Bhutan, Boiivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Buigaria, Burkina Faso, Cameroon, Canada, Cape Verde, Central African Repubiic, Chad, Chiie, China,
address— Intelsat, 3400 International Drive NW, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''ivoire, Croatia,
Washington, DC 20008-3098, US Cyprus, Czech Republic, Denmark, Dominican Repubiic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia,
fe/epborre— [1] (202) 944 7500 Fiji, Finiand, France, Gabon, Germany, Ghana, Greece, Guatemala, Guinea, Haiti, Hoiy See, Honduras, Hungary,
FAX''— [1] (202) 944 7890 Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea,
established— 20 August 1964 set up as the Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Maiawi, Maiaysia, Maii, Malta,
Telecommunications Sateilite Consortium; 12 Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Morocco, Mozambique,
February 1973 adopted present name Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
aim— to develop and operate a global Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal,
commercial telecommunications sateiiite system Singapore, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe
nonsignatory users— (42) Albania, Antigua and Barbuda, Belarus, Belize, Burma, Burundi, Cambodia, Cook
Islands, Cuba, Djibouti, Eritrea, The Gambia, Guinea-Bissau, Guyana, Kiribati, North Korea, Laos, Latvia, Lesotho,
Liberia, Lithuania, The Former Yugoslav Repubiic of Macedonia, Maidives, Marshali Isiands, Moidova, Nauru, Niue,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Seychelles, Sierra Leone, Siovakia,
Slovenia, Solomon Islands, Suriname, Tonga, Turkmenistan, Tuvaiu, Ukraine, Vanuatu
Islamic Development Bank (IDB) members— (5t plus the Palestine Liberation Organization) Afghanistan, Albania, Aigeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
address— P. 0. Box 5925, Jeddah 21432, Saudi Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Maiaysia,
Arabia Maidives, Maii, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra
fe/ephone— [966] (2) 6361400 Leone, Somaiia, Sudan, Suriname, Syria, Tajikistan, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen, Palestine
FAX— [966] (2) 6366871 Liberation Organization
established— 1 5 December 1 973 by deciaration
of intent
effective— 1 2 August 1 974
aim— to promote Islamic economic aid and
sociai development
593
Appendix C; International Organizations and Groups (continued)
Latin American Economic System (LAES)
note— also known as Sistema Economico
Latinoamericana (SELA)
address— SELA, Avenida Francisco de Miranda,
Torre Europa, Piso 4, Chacaito, Apartado de
Correos 17035, Caracas 1010-A, Venezueia
fe/eptone-[58] (2) 905 5111
FAX-{58] (2) 951 6953, 951 7246
established— M October 1975
a/m— to promote economic and sociai
deveiopment through regionai cooperation
members— (28) Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba,
Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and Tobago, Uruguay, Venezuela
observers— (21) Andean Promotion Corporation, China, Costa Rica, Dominican Republic, El Salvador, EEC,
Guatemala, Honduras, lADB, Inter-American Institute for Agricultural Cooperation, Italy, Nicaragua, OAS, Panama,
Portugal, Romania, Russia, Spain, Switzerland, UN Development Program, UN Economic Commission for Latin
America and the Caribbean
Latin American Integration Association
(LAIA)
no/e— also known as Asociacion
Latinoamericana de Integracion (ALADI)
address— Calle Cebollati 1461, Casilla de
Correo 577, 11000 Montevideo, Uruguay
/e/ephone-{598] (2) 400 1 1 21 , 409 59 1 5
FAX-[598] (2) 409 06 49
established— 12 August 1980
effective— 18 March 1981
a/m— to promote freer regional trade
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Paraguay, Peru, Uruguay,
Venezuela
observers— (21) China, Commission of the European Communities, Corporacion Andina de Fomento, Costa Rica,
Dominican Republic, El Salvador, Guatemala, Honduras, Inter-American Development Bank, Inter-American
Institute for Cooperation on Agriculture, Italy, Latin America Economic System, Nicaragua, Organization of American
States, Panama, Portugal, Romania, Russia, Spain, Switzerland, United Nations Development Program, United
Nations Economic Commission for Latin America and the Caribbean
League of Arab States (LAS)
see Arab League (AL)
League of Red Cross and Red Crescent
Societies (LORCS)
see International Federation of Red Cross and Red Crescent Societies (IFRCS)
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as
having no significant economic growth, per capita GDPs normally less than $1 ,000, and low literacy rates; also
known as the undeveloped countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana,
Burkina Faso, Burma, Burundi, Cape Verde, Central African Republic, Chad, Comoros, Djibouti, Equatorial Guinea,
Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali,
Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
Appendix C: International Organizations and Groups (continued)
less developed countries (LDCs) the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000 and often less than $1 ,500; however, the
group also includes a number of countries with high per capita incomes, areas of advanced technology, and rapid
rates of growth; includes the advanced developing countries, developing countries. Four Dragons (Four Tigers),
least developed countries (LLDCs), low-income countries, middle-income countries, newly industrializing
economies (NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana,
French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq,
Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya,
Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Isle of Man, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto
Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, DAE, Uganda, Uruguay,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen, Zambia,
Zimbabwe; note— similar to the new International Monetary Fund (IMF) term "developing countries" which adds
Malta, Mexico, South Africa, and Turkey but omits in its recently published statistics American Samoa, Anguilla,
British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Jersey, North Korea, Macau, Isle of Man, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint
Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and
Futuna, West Bank, Western Sahara
London Suppliers Group
see Nuclear Suppliers Group (NSG)
low-income countries
another term for those less developed countries with below-average per capita GDPs; see less developed countries
(LDCs)
Mercado Comun dei Cono Sur (Mercosur)
see Southern Cone Common Market
middie-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries
(LDCs)
Near Abroad
Russian term for the 1 4 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in
which Moscow has expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,
fe/ep/?or?e-[41](31)350 31 11
FAX-[41](31)350 31 10
established— 0 October 1874, affiliated with the
UN 15 November 1947
effective— t July 1948
a/m— to promote international postal
cooperation; a UN specialized agency
members— (189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Centrai African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands
Antilles, NZ, Nicaragua, Niger, Nigeria, Nora/ay, Oman, Overseas Territories of the UK, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member
states at the time of dissolution were Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier
members included GDR and Albania
West African Development Bank (WADB)
note— also known as Banque Ouest-Africaine
de Developpement (BOAD); is a financial
institution of WAEMU
address— 68 Avenue de la Liberation, BP 1172,
Lome, Togo
telephone-{228] 21 59 06, 21 42 44, 21 01 13
FAX-{228] 21 52 67, 21 72 69
established— tA November 1973
aim— io promote regional economic
development and integration
regional members— {8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
international/nonregional members— {5} African Development Bank, Belgium, European Investment Bank, France,','c0513748cc3cbd429131c439991fe34f22e6cb7c7ecee8f94bac20e7bec88e90','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57c82701a8de69cc31be9b061d66c0955993b01df18fd189c3dd3706e0153f55',2000,'DE','Germany','transnational-issues',303,'Geographic coordinates; 49 45 N, 6 10 E
Map references; Europe
Area;
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France 73 km,
Germany 138 km
Coastiine: 0 km (landlocked)
Maritime ciaims: none (landlocked)
Climate; modified continental with mild winters, cool
summers
Terrain: mostly gently rolling uplands with broad,
shallow valleys; uplands to slightly mountainous in the
north; steep slope down to Moselle flood plain in the
southeast
Elevation extremes;
lowest point: Moselle River 133 m
highest point: Burgplatz 559 m
Natural resources; iron ore (no longer exploited),
arable land
Land use:
arable land: 24%
permanent crops: t%
permanent pastures: 20%
forests and woodland: 21 %
other: 34%
Irrigated land: 10 sq km (including Belgium)
(1993 est.)
Natural hazards: NA
Environment - current issues: air and water
pollution in urban areas
Environment - international agreements;
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol,
Environmental Modification, Law of the Sea
Geography - note: landlocked
P e 0 p j e
Population: 437,389 (July 2000 est.)
Age structure;
0-14 years: 1 9% (male 42,375; female 40,1 09)
15-64 years: 67% (male 148,205; female 145,325)
65 years and over: 1 4% (male 24,446; female
36,929) (2000 est.)
Population growth rate: 1.27% (2000 est.)
Birth rate: 12.45 births/1,000 population (2000 est.)
Death rate: 8.91 deaths/1 ,000 population
(2000 est.)
Net migration rate: 9.21 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.97 male(s)Aemale (2000 est.)
Infant mortality rate: 4.83 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 77. 1 3 years
male: 73.84 years
female: 80.63 years (2000 est.)
Total fertility rate: 1 .7 children born/woman
(2000 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, and European
(guest and worker residents)
Religions: Roman Catholic 97%, Protestant and
Jewish 3%
Languages: Luxembourgian, German, French,
English
Literacy;
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (1980 est.)
i Government
Country name:
conventional long form: Grand Duchy of Luxembourg
conventional short form: Luxembourg
local long form: Grand-Duche de Luxembourg
local short form: Luxembourg
Data code: LU
Government type; constitutional monarchy
Capital; Luxembourg
Administrative divisions; 3 districts; Diekirch,
Grevenmacher, Luxembourg
Independence: 1839 (from the Netherlands)
National holiday: National Day, 23 June (1921)
(public celebration of the Grand Duke''s birthday)
Constitution: 1 7 October 1 868, occasional revisions
Legal system: based on civil law system; accepts
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and compulsory
Executive branch:
chief of state: Grand Duke JEAN (since 12 November
1964); Heir Apparent Prince HENRI (son of the
monarch, born 16 April 1955); note - Grand Duke
JEAN intends to abdicate in September 2000 in favor
of his oldest son. Prince HENRI
head of government: Prime Minister Jean-Claude
JUNCKER (since 1 January 1995) and Vice Prime
Minister Lydie POLFER (since 7 August 1999)
cabinet: Council of Ministers recommended by the
prime minister and appointed by the monarch
elections: none; the monarch is hereditary; prime
minister and vice prime minister appointed by the
monarch, following popular election to the Chamber of
Deputies; they are responsible to the Chamber of
Deputies
note: government coalition - CSV and DP
Legislative branch: unicameral Chamber of
Deputies or Chambre des Deputes (60 seats;
members are elected by direct popular vote to serve
five-year terms)
elections: last held 1 3 June 1 999 (next to be held by
NAJune 2004)
election results: percent of vote by party - CSV
29.79%, DP 21.58%, LSAP 23.75%, ADR 10.36%,
Green Party 9.09%, the Left 3.77%; seats by party -
CSV 19, DP 15, LSAP 13, ADR 6, Green Party 5, the
Left 2
note: the Council of State or Conseil d''Etat, which has
21 members who are appointed for life, is an advisory
body whose views are considered by the Chamber of
Deputies
Judicial branch: Superior Court of Justice or Cour
Superieure de Justice, judges are appointed for life by
the monarch; Administrative Court or Tribunale
Luxembourg (continued)
Administratin, judges are appointed for life by the
monarch
Political parties and leaders; Action Committee for
Democracy and Pension Rights or ADR [Robert
MEHLEN); Christian Social People''s Party or CSV
[Erna HENNICOT-SCHOEPGES); Democratic Party
or DP [Lydie POLFER]; Green Party [Jean HUSS);
Luxembourg Socialist Workers'' Party or LSAP [Jean
ASSELBORN]; Marxist and Reformed Communist
Party DEI LENK (the Left) [Andre HOFFMAN]; other
minor parties
Political pressure groups and leaders: ABBL
(bankers'' association); ALEBA (financial sector trade
union); Centrale Paysanne (federation of agricultural
producers); CEP (professional sector chamber);
CGFP (trade union representing civil service);
Chambre de Commerce (Chamber of Commerce);
Chambre des Metiers (Chamber of Artisans); FEDIL
(federation of industrialists); LCGP (center-right trade
union); OGBL (center-left trade union)
International organization participation: ACCT,
Australia Group, Benelux, CCC, CE, EAPC, EBRD,
ECE, EIB, EMU, EU, FAO, IAEA, IBRD, ICAO, ICC,
ICFTU, ICRM, IDA, lEA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Intelsat, Interpol, IOC, lOM, ISO, ITU, NATO,
NEA, NSG, OECD, OPCW, OSCE, PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WEU,
WHO, WlPO, WMO, W/TrO, ZC
Diplomatic representation in the US;
chief of mission: Ambassador Arlette CONZEM I US
chancery: 2200 Massachusetts Avenue NW,
Washington, DC 20006
fe/eptone;[1 1(202) 265-4171
FAX; [11(202) 328-8270
consuiate(s) general: New York and San Francisco
Diplomatic representation from the US;
chief of mission: Ambassador James C. HORMEL
embassy: 22 Boulevard Emmanuel-Servais, L-2535
Luxembourg City
mailing address: American Embassy Luxembourg,
Unit 1410, APO AE 09126-1410 (official mail);
American Embassy Luxembourg, PSC 9, Box 9500,
APO AE 09123 (personal mail)
telephone: [352] 46 01 23
FAX; [352] 4614 01
Flag description: three equal horizontal bands of
red (top), white, and light blue; similar to the flag of the
Netherlands, which uses a darker blue and is shorter;
design was based on the flag of France
I Economy
Economy - overview: The stable, high-income
economy features moderate growth, low inflation, and
low unemployment. The industrial sector, until
recently dominated by steel, has become increasingly
more diversified to include chemicals, rubber, and
other products. During the past decades, growth in the
financial sector has more than compensated for the
decline in steel. Services, especially banking, account
fora growing proportion of the economy. Agriculture is
based on small family-owned farms. Luxembourg has
especially close trade and financial ties to Belgium
and the Netherlands, and as a member of the EU,
enjoys the advantages of the open European market.
It joined with 10 other EU members to launch the euro
on 1 January 1999.
GDP: purchasing power parity - $14.7 billion
(1999 est.)
GDP - real growth rate: 4.2% (1999 est.)
GDP - per capita: purchasing power parity -
$34,200 (1999 est.)
GDP - composition by sector:
agriculture: 1%
industry: 23%
services: 76% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share;
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 1 . 1 % (1 999 est.)
Labor force: 236,400 (one-third of labor force is
foreign workers, mostly from Portugal, Italy, France,
Belgium, and Germany) (1998 est.)
Labor force - by occupation: services 83.2%,
industry 14.3%, agriculture 2.5% (1998 est.)
Unemployment rate: 2.7% (1999 est.)
Budget;
revenues: $4.73 billion
expenditures: $4.71 billion, including capital
expenditures of $NA (2000 est.)
Industries: banking, iron and steel, food processing,
chemicals, metal products, engineering, tires, glass,
aluminum
Industrial production growth rate: 1 .6%
(1999 est.)
Electricity • production; 382 million kWh (1998)
Electricity • production by source:
fossil fuel: 60.73%
hydro: 24.80%
nuclear: 0%
other: 14.41% (1998)
Electricity - consumption: 5.856 billion kWh (1 998)
Electricity - exports; 900 million kWh (1 998)
Electricity - imports: 6.4 billion kWh (1998)
Agriculture - products: barley, oats, potatoes,
wheat, fruits, wine grapes; livestock products
Exports: $7.5 billion (f.o.b., 1998)
Exports - commodities: finished steel products,
chemicals, rubber products, glass, aluminum, other
industrial products
Exports - partners: Germany 33%, France 20%,
Belgium 1 2%, UK 6%, US 5%, Netherlands 4% (1 998)
Imports: $9.6 billion (c.i.f., 1998)
Imports - commodities: minerals, metals,
foodstuffs, quality consumer goods
Imports - partners: Belgium 36%, Germany 27%,
France 12%, Netherlands 5%, US 4% (1998)
Debt - external: $NA
Economic aid - donor: ODA, $160 million (1999)
Currency: 1 Luxembourg franc (LuxF) = 100
centimes; note - centimes no longer in use
Exchange rates: euros per US$1 - 0.9867 (January
2000), 0.9386 (1999); Luxembourg francs (LuxF) per
US$1 - 34.77 (January 1999), 36.299 (1998), 35.774
(1997), 30.962 (1996), 29.480 (1995); note - the
Luxembourg franc is at par with the Belgian franc,
which circulates freely in Luxembourg
note; on 1 January 1999, the EU introduced a
common currency that is now being used by financial
institutions in some member countries at a fixed rate
of 40.3399 francs per euro; the euro will replace the
local currency in consenting countries for all
transactions in 2002
Fiscal year: calendar year
i'' Communications
Teiephones - main lines in use: 314,700 (1999)
Telephones - mobile cellular: 95,400 (1999)
Telephone system: highly developed, completely
automated and efficient system, mainly buried cables
domestic: nationwide cellular telephone system;
buried cable
international: 3 channels leased on TAT-6 coaxial
submarine cable (Europe to North America)
Radio broadcast stations; AM 2, FM 9, shortwave
2(1999)
Radios: 285,000(1997)
Television broadcast stations: 8 (1999)
Televisions: 285,000 (1998 est.)
Internet Service Providers (ISPs): 1 3 (1 999)
I f r a n s p o r t a t i o n
Railways;
total: 274 km
standard gauge: 274 km 1.435-m gauge (242 km
electrified; 178 km double track) (1998)
Highways:
tofa/;5,166 km
paved; 5,166 km (including 118 km of expressways)
unpaved: 0 km (1998 est.)
Waterways: 37 km; Moselle
Pipelines: petroleum products 48 km
Ports and harbors: Mertert
Merchant marine;
total: 48 ships (1 ,000 GRT or over) totaling 1 ,283,738
GRT/1 ,872,071 DWT
ships by type: bulk 2, chemical tanker 1 0, container 1 ,
liquified gas 18, passenger 4, petroleum tanker 6,
roll-on/roll-off 7 (1999 est.)
Airports: 2 (1999 est.)
Airports - with paved runways;
total: 1
over 3,047 m: 1 (1999 est.)
Airports ■ with unpaved runways:
total: 1
under 914 m:1 (1999 est.)
f Military
Military branches: Army; note - the new
government abolished the Gendarmerie
Military manpower - military age: 1 9 years of age
Military manpower - availability:
males age 15-49: 1 1 1 ,882 (2000 est.)
296
Luxembourg (continued)
Military manpower - fit for military service:
males age 15-49: 92,238 (2000 est.)
Military manpower - reaching military age
annually:
males: 2,563 (2000 est.)
Military expenditures - dollar figure: $1 31 million
(FY98)
Military expenditures - percent of GDP: 1%
(FY98)
t r a n s n a t i 0 n a i Issues
Disputes - international: none
Background: Colonized by the Portuguese in the
16th century, Macau was the first European
settlement in the Far East. Pursuant to an agreement
signed by China and Portugal on 13 April 1987,
Macau became the Macau Special Administrative
Region (SAR) of China on 20 December 1999. China
has promised that, under its "one country, two
systems” formula, China''s socialist economic system
will not be practiced in Macau and that Macau will
enjoy a high degree of autonomy in all matters except
foreign and defense affairs.
f ''''""~''ire"o"gTayfry ~
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 10 N, 1 13 33 E
Map references: Southeast Asia
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area - comparative: about 0.1 times the size of
Washington, DC
Land boundaries:
total: 0.34 km
border countries: China 0.34 km
Coastline: 40 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters, warm
summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 1 74 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 2%
permanent pastures: 0%
forests and woodland: 0%
other; 98% (1998 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: NA
Geography - note: essentially urban; one causeway
and two bridges connect the two islands of Coloane
and Taipa to the peninsula on mainland
. . .
Population: 445,594 (July 2000 est.)
Age structure:
0-14 years: 23% (male 53,986; female 50,379)
15-64 years: 69% (male 146,474; female 162,672)
65 years and over: 6% (male 12,932; female 19,151)
(2000 est.)
Population growth rate: 1 .83% (2000 est.)
Birth rate: 12.54 births/1 ,000 population
(2000 est.)
Death rate: 3.64 deaths/1 ,000 population
(2000 est.)
Net migration rate: 9.41 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.92 male(s)/female (2000 est.)
Infant mortality rate: 4.49 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 81.6 years
male: 78.8 years
female: 84.55 years (2000 est.)
Total fertility rate: 1 .3 children born/woman
(2000 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, Macanese (mixed
Portuguese and Asian ancestry), Portuguese, other
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1997 est.)
Languages: Portuguese, Chinese (Cantonese)
297
Macau (continued)
Literacy:
definition: age 1 5 and over can read and write
total population: 90%
male: 93%
female: 86% (1981 est.)
612
Appendix C: International Organizations and Groups (continued)
West African Economic and Monetary Union
(WAEMU)
members— (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
note— also known as Union Economique et
Monetaire Quest Africaine (UEMOA)
address— Commission de i''UEMOA, 01 BP 543,
Ouadgadougou, Burkina Faso
telephone— [226] 31 88 73 through 76
FAX-{226] 31 88 72
established— i August 1994
a/m— to increase competitiveness of members''
economic markets; to create a common market
West African Economic Community (CEAO)
note— acronym from Communaute Economique
de i’Afrique de TOuest
established on 3 June 1972 to promote regional economic development; its members were Benin, Burkina Faso,
Cote d''Ivoire, Mali, Mauritania, Niger, Senegal; it was disbanded in 1994
Western European Union (WEU)
address— Rue de la Regence 4, B-1000
Brussels, Belgium
telephone-{32]{2) 500 4411
FAX-{32]{2) 511 32 70
established— 23 October 1 954
effective— 6 May 1955
a/m— to provide mutual defense and to move
toward political unification
members— (10) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members— (6) Czech Republic, Hungary, Iceland, Norway, Poland, Turkey
associate partners— (7) Bulgaria, Estonia, Latvia, Lithuania, Romania, Slovakia, Slovenia
observers— (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank
see International Bank for Reconstruction and Development (IBRD)
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association
(IDA), and International Finance Corporation (IFC)
World Confederation of Labor (WCL)
address— Rue de Treves 33, B-1040 Brussels,','27402684147d6538b99dcd60a704e35e4c80337c0029c5e36347a22b3df2c86b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8828ef999cd2f1985c1c5c3da5260e54abac3bfba8eacaed8aae4508e5d6911f',2000,'MV','Maldives','transnational-issues',315,'Disputes • international: none
n
Background: The Sudanese Republic and Senegal
became independent of France in 1960 as the Mali
Federation. When Senegal withdrew after only a few
months, the Sudanese Republic was renamed Mali.
Rule by dictatorship was brought to a close in 1991
with a transitional government, and in 1992 when
Mali''s first democratic presidential election was held.
Since his reelection in 1997, President KONARE has
continued to push through political and economic
reforms and to fight corruption. In 1999 he indicated
he would not run for a third term.
Disputes - international: Malta and Tunisia are
discussing the commercial exploitation of the
continental shelf between their countries, particularly
for oil exploration
Illicit drugs: minor transshipment point for hashish
from North Africa to Western Europe
Man, isle of
(British crown dependency)
Background: Part of the Norwegian Kingdom of the
Hebrides until the 13th century when it was ceded to
Scotland, the isle came under the British crown in
1765. Current concerns include reviving the almost
extinct Manx Celtic language.
Disputes - international; none','7063f499ea3bb87456cec780942a3ca2c6d5d61647b82c8e57fac4b246573be2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55f75dd3525ced13c467eb5fd9b16656f1ba103a82cf07604f26fd8846ba0487',2000,'MH','Marshall Islands','transnational-issues',320,'0 ISO 300 km
0 150 300 ml
North Pacific Ocean
fjaongi
fBikar
Ujelang
^Wotho
•
^aloelap
^ ^Rongerik JJtirik
= Rongelap
^ .Mejit
^ ^Wotje
Ujae\\ ^
Q, •>= V
* ^Wamu *
Majuro
Ailingfapalap V ^
MAJURO® Miii
h ^
hlftmnrik^ ^ ioii,n tfnmf
Disputes - international: claims US territory of
Wake Island
'' Martinique
: (overseas department
(of France)
Background: Colonized by France in 1635, the
island has subsequently remained a French
possession except for three brief periods of foreign
occupation.','cd40b84b61d4cf437f01c43bcd79dd84978305adf454ee3bb259d19f476ac7b7','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12441e55c83071313da5656ca9be68dc2cf5896a1ec24276b465951d88559dee',2000,'MR','Mauritania','transnational-issues',332,'Disputes - international: none
Disputes - international: claims the Chagos
Archipelago in UK-administered British Indian Ocean
Territory; claims French-administered Tromelin Island
Illicit drugs: minor consumer and transshipment
point for heroin from South Asia; smaii amounts of
cannabis produced and consumed iocaiiy
! Mayotte
j (territorial collectivity
I of France)
Background: Mayotte was ceded to France aiong
with the other Comoros in 1843. It was the only island
in the archipeiago that voted in 1974 to retain its link
with France and forgo independence.
r : . G e''o glr''a''p h y . . . ''
Location: Southern Africa, island in the Mozambique
Channei, about one-half of the way from northern
Madagascar to northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total: 374 sq km
land: 374 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical; marine; hot, humid, rainy season
during northeastern monsoon (November to May); dry
season is cooler (May to November)
Terrain: generally undulating, with deep ravines and
ancient volcanic peaks
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: cyclones during rainy season
Environment - current issues: NA
Geography - note: part of Comoro Archipelago; 18
islands
t People
Population: 155,911 (July 2000 est.)
Age structure:
0-14 years: 47% (male 36,420; female 36,183)
15-64 years: 52% (male 44,058; female 36,613)
65 years and over: 1% (male 1 ,302; female 1 ,335)
(2000 est.)
Population growth rate: 4.76% (2000 est.)
Birth rate: 45.26 births/1 ,000 population (2000 est.)
Death rate: 9.11 deaths/1 ,000 population
(2000 est.)
Net migration rate: 1 1 .46 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .03 male(s)/femaie
under 15 years: 1.01 male(s)/femaie
15-64 years: 1 .2 male(s)/female
65 years and over: 0.98 male(s)/femaie
total population: 1.1 male(s)/female (2000 est.)
Infant mortality rate: 71 .31 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 59.45 years
male: 57.41 years
female: 61 .55 years (2000 est.)
Total fertility rate: 6.33 children born/woman
(2000 est.)
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 97%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
(official language) spoken by 35% of the population
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Disputes - international: claims Chagos
Archipelago in British Indian Ocean Territory
442
Background: Since 1991 , civil war between the
government and the Revolutionary United Front
(RUF) has resulted in tens of thousands of deaths and
the displacement of more than 2 million people (well
over one-third of the population) many of whom are
now refugees in neighboring countries. A peace
agreement, signed on 7 July 1999, offers hope that
the country will be able to rebuild its devastated
economy and infrastructure, but previous peace
efforts have failed. As of late 1999, up to 6,000 UN
peacekeepers were in the process of deploying to
bolster the peace accord.
I Geography
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Geographic coordinates: 8 30 N, 1 1 30 W
Map references: Africa
Area:
total: 71 ,740 sq km
land: 71 ,620 sq km
water: 120 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastiine: 402 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; hot, humid; summer rainy season
(May to December); winter dry season (December to
April)
Terrain: coastal belt of mangrove swamps, wooded
hill country, upland plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1 ,948 m
Natural resources: diamonds, titanium ore, bauxite,
iron ore, gold, chromite
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 31 %
forests and woodland: 28%
other: 33% (1993 est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds
blow from the Sahara (November to May);
sandstorms, dust storms
Environment - current issues: rapid population
growth pressuring the environment; overharvesting of
timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in
deforestation and soil exhaustion; civil war depleting
natural resources; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Nuclear Test Ban,
Wetlands
signed, but not ratified: Environmental Modification
I ~ ” People
Population: 5,232,624 (July 2000 est.)
Age structure:
0-14 years: A4.73% (male 1,148,264; female
1,192,533)
15-64 years: 52.1 6% (male 1 ,305,039; female
1,424,076)
65 years and over: 3. 1 1 % (male 81 ,291 ; female
81 ,421) (2000 est.)
Population growth rate: 3.67% (2000 est.)
Birth rate: 45.63 births/1 ,000 population (2000 est.)
Death rate: 1 9.58 deaths/1 ,000 population
(2000 est.)
Net migration rate: 10.61 migrant(s)/1 ,000
population (2000 est.)
note: by the end of 1 999 refugees from Sierra Leone
are assumed to be returning
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.96 maie(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 1 male(s)/female
total population: 0.94 male(s)/female (2000 est.)
Infant mortality rate: 148.66 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 45.25 years
male: 42.37 years
female: 48.21 years (2000 est.)
Total fertility rate: 6.08 children born/woman
(2000 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole 10%
(descendants of freed Jamaican slaves who were
settled in the Freetown area in the late-eighteenth
century), refugees from Liberia''s recent civil war,
small numbers of Europeans, Lebanese, Pakistanis,
and Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creole, spoken by the descendants of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 1 5 and over can read and write English,
Mende, Temne, or Arabic
total population: 31 .4%
male: 45.4%
fema/e; 18.2% (1995 est.)
Disputes - international; none
444
Background: Founded as a British trading colony in
1819, Singapore joined Malaysia in 1963, but
withdrew two years later and became independent. It
subsequently became one of the world''s most
prosperous countries, with strong international trading
links (its port is one of the world''s busiest) and with per
capita GDP above that of the leading nations of
Western Europe.
I — Q^eogYaphy
Location: Southeastern Asia, islands between
Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total: 647.5 sq km
land: 637.5 sq km
wafer; 10 sq km
Area - comparative: slightly more than 3.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastiine: 193 km
Maritime ciaims:
exclusive fishing zone: wMn and beyond territorial
sea, as defined in treaties and practice
territorial sea: 3 nm
Climate: tropical; hot, humid, rainy; no pronounced
rainy or dry seasons; thunderstorms occur on 40% of
all days (67% of days in April)
Terrain: lowland; gently undulating central plateau
contains water catchment area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 1 66 m
Natural resources: fish, deepwater ports
Land use:
arable land: 2%
permanent crops: &%
permanent pastures: 0%
forests and woodland: 5%
other; 87% (1993 est.)
Irrigated land: NAsqkm
Natural hazards: NA
Environment - current issues: industrial pollution;
limited natural fresh water resources; limited land
availability presents waste disposal problems;
seasonal smoke/haze resulting from forest fires in','2768b5d34f0e6f9d848fffbe4e49908d8918a5068fad112dbd10699d405fd51e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cca26d9f59c047d1980f9d746c0ed5684ada18e2ab6350dafcb1d7c5f4d220f',2000,'YT','Mayotte','transnational-issues',341,'Disputes - international: none
Illicit drugs: illicit cultivation of opium poppy
(cultivation in 1998 - 5,500 hectares; potential
production - 60 metric tons) and cannabis cultivation
in 1998 - 4,600 hectares; government eradication
efforts have been key in keeping illicit crop levels low;
major supplier of heroin and marijuana to the US
market; continues as the primary transshipment
country for US-bound cocaine from South America;
involved in the production and distribution of
methamphetamines; upsurge in drug-related violence
and official corruption; major drug syndicates growing
more powerful
328
iMicronesia,
IFederated
It
IStatesof
Northern
Philippine Mariana
Sea ■ Islands
(u-s.)
Guam (U.S.),''
Yap
Islands
J ■
North Pacific
Ocean
MARSHALL I
ISUNDS
Hall
Islands
.y PALIKIR
Caroline''^- I sland s _ o .\\pohnpel
Truk''^" .. Kosrae
Islands
(Chuuk)
■ Kapingamarangi
Equator
South Pacific
Ocean
SOLOMON
/■V ISLANDS
I Introduction
Background: In 1979 the Federated States of
Micronesia, a UN Trust Territory under US
administration, adopted a constitution. In 1986
Independence was attained under a Compact of Free
Association with the United States. Present concerns
include large-scale unemployment, overfishing, and
overdependence on US aid.
I Geography
Location: Oceania, island group in the North Pacific
Ocean, about three-quarters of the way from Hawaii to','709dac239247638096fb9e42f158e3c2870e8c882a36d759dd27983fa874c9e0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec1afffbb300f393856032477d1eb564dbd248ae74ddfee09d87e1d7d76706d1',2000,'ID','Indonesia','transnational-issues',342,'Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
wafer; 0 sq km
note: includes Pohnpei (Ponape), Truk (Chuuk)
Islands, Yap Islands, and Kosrae
Area - comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
exclusive economic zone: 200 nm
ferr;foria/sea;12nm
Climate: tropical; heavy year-round rainfall,
especially in the eastern islands; located on southern
edge of the typhoon belt with occasionally severe
damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls; volcanic
outcroppings on Pohnpei, Kosrae, and Truk
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point:Toto\\om79t m
Natural resources: forests, marine products,
deep-seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: typhoons (June to December)
Environment - current issues: overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: four major island groups totaling
607 islands
1^”"” "nPeo ''p''I'' e ''
Population: 133,144 (July 2000 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over; NA
Population growth rate: 3.28% (2000 est.)
Birth rate: 27.09 births/1,000 population (2000 est.)
Death rate: 5.95 deaths/1,000 population
(2000 est.)
Net migration rate: 1 1 .65 migrant(s)/1 ,000
population (2000 est.)
Infant mortality rate: 33.48 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 68.63 years
male: 66.67 years
female: 70.62 years (2000 est.)
Totai fertiiity rate: 3.83 children born/woman
(2000 est.)
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Kosrae(s), Pohnpeian(s),
Trukese, Yapese
Ethnic groups: nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%,
other and none 3%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean
Literacy:
definition: age 1 5 and over can read and write
total popuiation: 69%
male: 91%
fema/e; 88% (1980 est.)
Disputes - international: none
) Midway Islands
i (territory of the US)
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: focal point for Southeast Asian
sea routes
|: '' P e 0 p I e^'' ''
Population: 4,151,264 (July 2000 est.)
Age structure:
0-14 years: 1 8% (male 390,352; female 365,730)
15-64 years: 75% (male 1 ,520,875; female
1,590,355)
65 years and over: 7% (male 124,413; female
159,539) (2000 est.)
Population growth rate: 3.54% (2000 est.)
Birth rate: 12.79 births/1,000 population (2000 est.)
Death rate: 4.21 deaths/1,000 population
(2000 est.)
Net migration rate: 26.8 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.78 maie(s)/female
total population: 0.96 male(s)/female (2000 est.)
Infant mortality rate: 3.65 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 80.05 years
male: 77 A years
female: 83.23 years (2000 est.)
Total fertility rate: 1.16 children born/woman
(2000 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 77%, Malay 14%, Indian
7.6%, other 1.4%
Religions: Buddhist (Chinese), Muslim (Malays),
Christian, Hindu, Sikh, Taoist, Confucianist
Languages: Chinese (official), Malay (official and
national), Tamil (official), English (official)
Literacy:
definition: age 15 and over can read and write
total population: 91.1%
male: 95.9%
female: 86.3% (1995 est.)
I "'' " Gov e r n m e n t
Country name:
conventional long form: Republic of Singapore
conventional short form: Singapore
Data code: SN
Government type: parliamentary republic
Capital: Singapore
Administrative divisions: none
Independence: 9 August 1965 (from Malaysia)
National holiday: National Day, 9 August (1965)
Constitution: 3 June 1959, amended 1965 (based
on preindependence State of Singapore Constitution)
Legal system: based on English common law; has
not accepted compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal and compulsory
Executive branch:
chief of state: President Sellapan Rama (S. R.)
NATHAN (since 1 September 1999)
head of government: Prime Minister GOH ChokTong
(since 28 November 1990) and Deputy Prime
Ministers LEE Hsien Loong (since 28 November
1990) and Tony TAN Keng Yam (since 1 August
1995)
cabinet: Cabinet appointed by the president,
responsible to Parliament
elections: president elected by popular vote for a
six-year term; election last held 28 August 1999 (next
to be held NA August 2005); following legislative
elections, the leader of the majority party or the leader
of a majority coalition is usually appointed prime
minister by the president; deputy prime ministers
appointed by the president
election results: Sellapan Rama (S. R.) NATHAN
elected president unopposed
Legislative branch: unicameral Parliament (83
seats; members elected by popular vote to serve
five-year terms)
elections: last held 2 January 1 997 (next to be held by
2002)
election results: percent of vote by party - PAP 65%
(in contested constituencies), other 35%; seats by
party - PAP 81 , WP 1 , SPP 1 ; note - subsequent to the
election, there was a change in the distribution of
seats, the new distribution is as follows: PAP 80, WP
1 , SPP 1 , vacant 1
Judicial branch: Supreme Court, chief justice is
appointed by the president with the advice of the
prime minister, other judges are appointed by the
president with the advice of the chief justice; Court of
Appeals
Political parties and leaders: National Solidarity
Party or NSP [C. K. TAN]; People''s Action Party or
PAP [GOH Chok Tong, secretary general] - the
governing party; Singapore Democratic Party or SDP
[CHEE Soon Juan]; Singapore People''s Party or SPP
[CHIAM See Tong]; Workers'' Party or WP [J. B.
JEYARETNAM and LOWThia Khiang]
International organization participation: APEC,
AsDB, ASEAN, Australia Group (obsen/er), BIS, C,
CCC, CP, ESCAP, G-77, IAEA, IBRD, ICAO, ICC,
ICFTU, ICRM, IFC, IFRCS, IHO, ILO, IMF, IMO,
445
Singapore (continued)
Inmarsat, Intelsat, Interpol, IOC, ISO, ITU, NAM,
OPCW, PCA, UN, UNCTAD, UNIKOM, UPU, WHO,
WlPO, WMO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassa6or CHAN Heng Chee
chancery: 3501 International Place NW, Washington,
DC 20008
fe/eptone;[1](202) 537-3100
FAX: [1] (202) 537-0876
consulate(s): New York
Diplomatic representation from the US:
c/i/efofm/ss/on; Ambassador Steven J. GREEN
embassy: 27 Napier Road, Singapore 258508
mailing address: FPO AP 96507
te/eptone; [65] 476-91 00
FAX; [65] 476-9340
Flag description: two equal horizontal bands of red
(top) and white; near the hoist side of the red band,
there is a vertical, white crescent (closed portion is
toward the hoist side) partially enclosing five white
five-pointed stars arranged in a circle
Disputes - international: two islands in dispute with','4dbabb0fb14b1408e2f79e917a669427c4d0e640220268782838ab5beb364f77','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de69d5d7feeb7c2f325bf569bcb134fdbbe4e3504e003b6fda72f2948688eab4',2000,'MZ','Mozambique','transnational-issues',353,'Disputes - international: none
Illicit drugs: Southern African transit hub for South
American cocaine probably destined for the European
and US markets; producer of hashish and
methaqualone
[ n t r 0 d u c t i o n
Background: South Africa occupied the German
colony of Sud-West Afrika during World War I and
administered it as a mandate until after World War II
when it annexed the territory. In 1966 the Marxist
South-West Africa People''s Organization (SWAPO)
guerrilla group launched a war of independence for
the area that was soon named Namibia, but it was not
until 1988 that South Africa agreed to end its
administration in accordance with a UN peace plan for
the entire region. Independence came in 1990.
\\ '' G e 0 g r a p h y ''
Location: Southern Africa, bordering the South
Atlantic Ocean, between Angola and South Africa
Geographic coordinates; 22 00 S, 17 00 E
Map references: Africa
Area:
fofa/;825,418sqkm
/and; 825,41 8 sq km
water: 0 sq km
Area - comparative: slightly more than half the size
of Alaska
Land boundaries:
total: 3,824 km
border countries: Angola 1,376 km, Botswana 1 ,360
km. South Africa 855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along
coast; Kalahari Desert in east
Elevation extremes;
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium,
gold, lead, tin, lithium, cadmium, zinc, salt, vanadium,
natural gas, hydropower, fish
note: suspected deposits of oil, coal, and iron ore
Land use:
arabie iand: 1%
permanent crops: 0%
permanent pastures: 46%
forests and woodiand: 22%
often 31% (1993 est.)
Irrigated land: 60 sq km (1993 est.)
Natural hazards: prolonged periods of drought
Environment - current issues: very limited natural
fresh water resources; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
i People
Population: 1,771,327
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and
growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2000 est.)
Age structure;
0-14 years: 43% (male 384,900; female 375,282)
15-64 years: 53% (male 468,942; female 475,504)
65 years and over: 4% (male 28,905; female 37,794)
(2000 est.)
Population growth rate: 1 .57% (2000 est.)
Birth rate: 35.23 births/1 ,000 population (2000 est.)
Death rate: 1 9.49 deaths/1 ,000 population
(2000 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2000 est.)
Sex ratio;
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 70.88 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 42.46 years
maie: 44.33 years
female: 40.53 years (2000 est.)
Total fertility rate: 4.89 children born/woman
(2000 est.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic groups: black 87.5%, white 6%, mixed 6.5%
note: about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups are: Herero 7%, Damara 7%, Nama 5%,
Caprivian 4%, Bushmen 3%, Baster2%, Tswana
0.5%
344
Namibia (continued)
Religions: Christian 80% to 90% (Lutheran 50% at
least), indigenous beiiefs 10% to 20%
Languages: Engiish 7% (officiai), Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages: Oshivambo, Herero, Nama
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 45%
fema/e; 31% (1960 est.)
I Government
Country name:
conventional long form: Republic of Namibia
conventional short form: Namibia
Data code: WA
Government type: republic
Capital: Windhoek
Administrative divisions: 13 regions; Caprivi,
Erongo, Hardap, Karas, Khomas, Kunene,
Ohangwena, Okavango, Omaheke, Omusati,
Oshana, Oshikoto, Otjozondjupa
Independence: 21 March 1990 (from South African
mandate)
National holiday: Independence Day, 21 March
(1990)
Constitution: ratified 9 February 1990; effective 12
March 1990
Legal system: based on Roman-Dutch law and
1990 constitution
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Samuel NUJOMA (since 21
March 1990); note - the president is both the chief of
state and head of government
head of government: President Samuel NUJOMA
(since 21 March 1 990); note - the president is both the
chief of state and head of government
cabinet: Cabinet appointed by the president from
among the members of the National Assembly
elections: president elected by popular vote for a
five-year term; election last held 30 November-1
December 1999 (next to be held NA 2004)
election results: Samuel NUJOMA elected president;
percent of vote - Samuel NUJOMA 77%
Legislative branch: bicameral legislature consists
of the National Council (26 seats; two members are
chosen from each regional council to serve six-year
terms) and the National Assembly (72 seats;
members are elected by popular vote to serve
five-year terms)
elections: National Council - elections for regional
councils, to determine members of the National
Council, held 30 November-1 December 1998 (next to
be held by December 2004); National Assembly - last
held 30 November-1 December 1 999 (next to be held
by December 2004)
election results: National Council - percent of vote by
party - NA; seats by party - SWAPO 21 , DTA 4, UDF
1 ; National Assembly - percent of vote by party -
SWAPO 77%, COD 10%, DTA 9%, UDF 3%, MAG
1 %; seats by party - SWAPO 55, COD 7, DTA 7, UDF
2, MAGI,
note; the National Council is a purely advisory body
Judicial branch: Supreme Court, judges appointed
by the president
Political parties and leaders: Congress of
Democrats or COD [Ben ULENGA]; Democratic
Turnhalle Alliance of Namibia or DTA [Kafuutire
KAURA, president]; Monitor Action Group or MAG
[Kosie PRETORIUS]; South West Africa People''s
Organization or SWAPO [Sam NUJOMA]; United
Democratic Front or UDF [Justus GAROEB]
International organization participation: ACP,
AfDB, C, CCC, ECA, FAO, G-77, IAEA, IBRD, ICAO,
ICRM, IFAD, IFC, IFRCS, ILO, IMF, IMO, Intelsat,
Interpol, IOC, lOM (observer), ISO (subscriber), ITU,
NAM, OAU, OPCW, SACU, SADC, UN, UN Security
Council (temporary), UNCTAD, UNESCO, UNHCR,
UNIDO, UPU, WCL, WHO, WlPO, WMO, WToO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Leonard Nangolo
IIPUMBU
charrcery; 1605 New Hampshire Avenue NW,
Washington, DC 20009
telephone: [t] {202) 986-0540
FAX; [1] (202) 986-0443
Diplomatic representation from the US:
chief of mission: Ambassador Jeffrey A. BADER
embassy: Ausplan Building, 14 Lessen Street, Private
Bag 12029 Ausspannplatz, Windhoek
mailing address: use embassy street address
fe/eptor7e:[264](61)221601
FAX; [264] (61) 229792
Flag description: a large blue triangle with a yellow
sunburst fills the upper left section and an equal green
triangle (solid) fills the lower right section; the triangles
are separated by a red stripe that is contrasted by two
narrow white-edge borders
f ¥conomy
Economy - overview: The economy is heavily
dependent on the extraction and processing of
minerals for export. Mining accounts for 20% of GDP.
Namibia is the fourth-largest exporter of nonfuel
minerals in Africa and the world''s fifth-largest
producer of uranium. Rich alluvial diamond deposits
make Namibia a primary source for gem-quality
diamonds. Namibia also produces large quantities of
lead, zinc, tin, silver, and tungsten. Half of the
population depends on agriculture (largely
subsistence agriculture) for its livelihood, Namibia
must import some of its food. Although per capita GDP
is four times the per capita GDP of Africa''s poorer
countries, the majority of Namibia''s people live in
pronounced poverty because of large-scale
unemployment, the great inequality of income
distribution, and the large amount of wealth going to
foreigners. The Namibian economy has close links to
South Africa. GDP growth should improve in 2000-01 ,
because of gains in the diamond and fish sectors.
Agreement has been reached on the privatization of
several more enterprises in coming years, which
should stimulate long-run foreign investment.
GDP: purchasing power parity - $7.1 billion
(1999 est.)
GDP - real growth rate: 3% (1 999 est.)
GDP - per capita: purchasing power parity - $4,300
(1999 est.)
GDP - composition by sector:
agriculture: 12%
industry: 30%
services: 58% (1998 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 8.5% (1 999)
Labor force: 500,000
Labor force - by occupation: agriculture 47%,
industry 25%, services 28% (1999 est.)
Unemployment rate: 30% to 40%, including
underemployment (1997 est.)
Budget:
revenues: $883 million
expenditures: $950 million, including capital
expenditures of $NA (1 998)
Industries: meat packing, fish processing, dairy
products; mining (diamond, lead, zinc, tin, silver,
tungsten, uranium, copper)
Industrial production growth rate: 10% (1994)
Electricity • production: 1 ,1 98 billion kWh (1 999)
Electricity - production by source:
fossil fuel: 2%
hydro: 98%
nuclear: 0%
other; 0% (1999)
Electricity - consumption: 1.81 billion kWh (1999)
Electricity - exports: 56 million kWh (1999)
Electricity - imports: 890 million kWh (1999)
note: imports electricity from South Africa
Agriculture - products: millet, sorghum, peanuts;
livestock; fish
Exports: $1.4 billion (f.o.b., 1999 est.)
Exports - commodities: diamonds, copper, gold,
zinc, lead, uranium; cattle, processed fish, karakul
skins
Exports - partners: UK 43%, South Africa 26%,
Spain 14%, France 8%, Japan (1998 est.)
Imports: $1.5 billion (f.o.b., 1999 est.)
Imports - commodities: foodstuffs; petroleum
products and fuel, machinery and equipment,
chemicals
Imports - partners: South Africa 84%, Germany,
US, Japan (1995 est.)
Debt - external: $1 59 million (1 999 est.)
Economic aid - recipient: $127 million (1998)
Currency: 1 Namibian dollar (N$) = 100 cents
Exchange rates: Namibian dollars (N$) per US$1 -
6.12439 (January 2000), 6.10948 (1999), 5.52828
(1998), 4.60796 (1997), 4.29935 (1996), 3.62709
(1995)
Fiscal year: 1 April - 31 March
345
Namibia (continued)
Disputes - international: dispute with Botswana
over uninhabited Kasikili (Sidudu) isiand in Linyanti
(Chobe) River resolved by the ICJ in favor of
Botswana (13 December 1999); at ieast one other
island in Linyanti River is contested
Disputes - international: none
Q e 0 gYa p 1, ‘y
Location: Caribbean, island In the Caribbean Sea,
about one-fourth of the way from Haiti to Jamaica
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the
Caribbean
Area:
total: 5.2 sq km
land: 5.2 sq km
wafer; 0 sq km
Area - comparative: about nine times the size of
The Mall In Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime ciaims:
exclusive economic zone: 200 nm
ferr/for/a/sea;12nm
Ciimate: marine, tropical
Terrain: raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m
high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side 77
m
Natural resources: guano
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 10%
forests and woodland: 0%
other: 90%
Irrigated iand: 0 sq km (1998)
Natural hazards: NA
Environment - current issues: NA
Geography - note: strategic location 160 km south
of the US Naval Base at Guantanamo Bay, Cuba;
mostly exposed rock, but enough grassland to support
goat herds; dense stands of fig-like trees, scattered
cactus
348
Navassa Island (continued)
I People
Population: uninhabited
note: transient Haitian fishermen and others camp on
the isiand (Juiy 2000 est.)
I Government
Country name:
conventional long form: none
conventional short form: Navassa Isiand
Data code: BQ
Dependency status: unincorporated territory of the
US; administered from Washington, DC, by the Fish
and Wildlife Service, US Department of the Interior; in
September 1 996, the Coast Guard ceased operations
and maintenance of Navassa Island Light, a
46-meter-tall lighthouse located on the southern side
of the island; there has also been a private claim
advanced against the island
Flag description: the flag of the US is used
Disputes - international: involved in complex
dispute over the Spratly Islands with China, Malaysia,
Philippines, Vietnam, and possibly Brunei; Paracel
Islands occupied by China, but claimed by Vietnam
and Taiwan; claims Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai), as
does China
Illicit drugs: considered an important heroin transit
point; major problem with domestic consumption of
methamphetamines and heroin
Appendix A:
Abbreviations
ABEDA
Arab Bank for Economic Development in Africa
ACC
Arab Cooperation Council
ACCT
Agence de Cooperation Culturelle et Technique; see Agency for Cultural and
Technical Cooperation; changed name in 1 996 to Agence de la francophonie or
Agency for the French-Speaking Community
ACP Group
African, Caribbean, and Pacific Group of States
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
AG
Andean Group; see Andean Community of Nations (CAN)
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen
Oxides
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Nitrogen Oxides or Their Transboundary
Fluxes
Air Pollution-Persistent
Organic Pollutants
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Persistent Organic Pollutants
Air Pollution-Sulphur 85
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
the Reduction of Sulphur Emissions or Their Transboundary Fluxes by at Least
30%
Air Pollution-Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Air Pollution-Volatile
Organic Compounds
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AL
Arab League
ALADI
Asociacion Latinoamericana de Integracion; see Latin American Integration
Association (LAIA)
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
Ancom
Andean Common Market; see Andean Community of Nations (CAN)
Antarctic-Environmental
Protocol
Protocol on Environmental Protection to the Antarctic Treaty
ANZUS
Australia-New Zealand-United States Security Treaty
APEC
Asia-Pacific Economic Cooperation
Arabsat
Arab Satellite Communications Organization
AsDB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
Autodin
Automatic Digital Network
BAD
Banque Africaine de Developpement; see African Development Bank (AfDB)
BADEA
Banque Arabe de Developpement Economique en Afrique; see Arab Bank for
Economic Development in Africa (ABEDA)
BCIE
Banco Centroamericano de Integracion Economico; see Central American Bank
for Economic Integration (BCIE)
BDEAC
Banque de Developpment des Etats de I''Afrique Centrale; see Central African
States Development Bank (BDEAC)
Benelux
Benelux Economic Union
555
Appendix A: Abbreviations (continued)
BID
Banco Interamericano de Desarroiio; see Inter-American Development Bank (lADB)
Biodiversity
Convention on Biological Diversity
BiS
Bank for International Settlements
BOAD
Banque Ouest-Africaine de Developpement; see West African Development
Bank (WADB)
BSEC
Black Sea Economic Cooperation Zone
C
C
Commonwealth
CACM
Central American Common Market
CAEU
Council of Arab Economic Unity
CAN
Andean Community of Nations
Caribbean Community and Common Market
CB
citizen’s band mobile radio communications
CBSS
Council of the Baltic Sea States
CCC
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEAO
Communaute Economique de I''Afrique de I''Ouest; see West African Economic
Community (CEAO)
CEEAC
Communaute Economique des Etats de I''Afrique Centrale; see Economic
Community of Central African States (CEEAC)
CEI
Central European Initiative
CEMA
Council for Mutual Economic Assistance; also known as CMEA or Comecon
CEPGL
Communaute Economique des Pays des Grands Lacs; see Economic
Community of the Great Lakes Countries (CEPGL)
CERN
Conseil Europeenne pour la Recherche Nucleaire; see European Organization
for Nuclear Research (CERN)
CG
Contadora Group
c.i.f.
cost, insurance, and freight
CIS
Commonwealth of Independent States
CITES
see Endangered Species
Climate Change
United Nations Framework Convention on Climate Change
Climate Change-Kyoto
Protocol
Kyoto Protocol to the United Nations Framework Convention on Climate Change
CMEA
Council for Mutual Economic Assistance (CEMA); also known as Comecon
COCOWI
Coordinating Committee on Export Controls
Comecon
Council for Mutual Economic Assistance (CEMA); also known as CMEA
Comsat
Communications Satellite Corporation
CP
Colombo Plan
CSCE
Conference on Security and Cooperation in Europe; see Organization for
Security and Cooperation in Europe (OSCE)
CY
calendar year
D
DC
developed country
Desertification
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
DSN
Defense Switched Network
DWT
deadweight ton
556
Appendix A: Abbreviations (continued)
EADB
East African Development Bank
EAPC
Euro-Atlantic Partnership Council
EBRD
European Bank for Reconstruction and Development
EC
European Community; see European Union (EU)
ECA
Economic Commission for Africa
ECAFE
Economic Commission for Asia and the Far East; see Economic and Social
Commission for Asia and the Pacific (ESCAP)
ECE
Economic Commission for Europe
ECLA
Economic Commission for Latin America; see Economic Commission for Latin
America and the Caribbean (ECLAC)
ECLAC
Economic Commission for Latin America and the Caribbean
ECO
Economic Cooperation Organization
ECOSOC
Economic and Sociai Councii
ECOWAS
Economic Community of West African States
ECS
European Coai and Steei Community; see European Union (EU)
ECWA
Economic Commission for Western Asia; see Economic and Sociai Commission
for Western Asia (ESCWA)
EEC
European Economic Community; see European Union (EU)
EFTA
European Free Trade Association
EIB
European Investment Bank
EMU
European Monetary Union
Endangered Species
Convention on the International Trade In Endangered Species of Wild Flora and
Fauna (CITES)
Entente
Council of the Entente
Environmental
Convention on the Prohibition of Military or Any Other Hostile Use of
Modification
Environmental Modification Techniques
ESA
European Space Agency
ESCAP
Economic and Social Commission for Asia and the Pacific
ESCWA
Economic and Social Commission for Western Asia
est.
estimate
EU
European Union
Euratom
European Atomic Energy Community; see European Community (EC)
Eutelsat
European Telecommunications Satellite Organization
Ex-lm
Export-Import Bank of the United States
FAO
Food and Agriculture Organization
FAX
facsimile
f.o.b.
free on board
FLS
Front Line States
FRG
Federal Republic of Germany (West Germany); used for information dated before
3 October 1990 or CY91
FSU
former Soviet Union
FY
fiscal year
FYROM
The Former Yugoslav Republic of Macedonia
Franc Zone
FZ
Appendix A: Abbreviations (continued)
G
G-2
Group of 2
G-3
Group of 3
G-5
Group of 5
G-6
Group of 6 (not to be confused with the Big Six)
G-7
Group of 7
G-8
Group of 8
G-9
Group of 9
G-10
Group of 10
G-11
Group of 1 1
G-15
Group of 15
G-19
Group of 19
G-24
Group of 24
G-30
Group of 30
G-33
Group of 33
G-77
Group of 77
GAH
General Agreement on Tariffs and Trade; subsumed by the World Trade
Organization (WTrO) on 1 January 1995
GCC
Gulf Cooperation Council
GDP
gross domestic product
GDR
German Democratic Republic (East Germany); used for information dated before
3 October 1990 or CY91
GNP
gross national product
GRT
gross register ton
GWP
gross world product
H
Hazardous Wastes
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
HF
high-frequency
1
lADB
Inter-American Development Bank
IAEA
International Atomic Energy Agency
IBEC
International Bank for Economic Cooperation
IBRD
International Bank for Reconstruction and Development (World Bank)
ICAO
International Civil Aviation Organization
ICC
International Chamber of Commerce
ICEM
Intergovernmental Committee for European Migration; see International
Organization for Migration (lOM)
ICFTU
International Confederation of Free Trade Unions; see World Confederation of
Labor (WCL)
ICJ
International Court of Justice (World Court)
ICM
Intergovernmental Committee for Migration; see International Organization for
Migration (lOM)
ICRC
International Committee of the Red Cross
ICRM
international Red Cross and Red Crescent Movement
IDA
International Development Association
IDB
Islamic Development Bank
lEA
International Energy Agency
558
I
Appendix A; Abbreviations (continued)
IMF
IMO
Inmarsat
inOC
Intelsat
Interpol
Intersputnik
ioc ''
International Fund for Agricultural Development
International Finance Corporation
International Federation of Christian Trade Unions
International Federation of Red Cross and Red Crescent Societies
Inter-Governmental Authority on Development
Inter-Governmental Authority on Drought and Development
International Hydrographic Organization
International Investment Bank
International Labor Organization
Intergovernmental Maritime Consultative Organization; see International
Maritime Organization (IMO)
International Monetary Fund
International Maritime Organization
International Mobile Satellite Organization
Indian Ocean Commission
International Telecommunications Satellite Organization
International Criminal Police Organization
International Organization of Space Communications
International Olympic Committee
International Organization for Migration
International Organization for Standardization
International Telecommunication Union
K
kHz
kiiohertz
km
kiiometer
kW
kiiowatt
kWh
kiiowatt hour
L
LAES
Latin American Economic System
LAIA
Latin American integration Association
LAS
League of Arab States; see Arab League (AL)
Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
LDC
less developed country
LLDC
least developed country
London Convention
see Marine Dumping
LORCS
League of Red Cross and Red Crescent Societies; see internationai Federation
of Red Cross and Red Crescent Societies (iFRCS)
LOS
see Law of the Sea
M
m
meter
Marecs
Maritime European Communications Satellite
Marine Dumping
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other
Matter
Marine Life Conservation
Convention on Fishing and Conservation of Living Resources of the High Seas
MARPOL
see Ship Pollution
Medarabtel
Middle East Telecommunications Project of the International
Telecommunications Union
559
Appendix A: Abbreviations (continued)
Mercosur
Mercado Comun del Cono Sur; see Southern Cone Common Market
MHz
megahertz
MINURSO
United Nations Mission for the Referendum in Western Sahara
MINUGUA
United Nations Verification Mission in Guatemala
MIPONUH
United Nations Civilian Police Mission in Haiti
MONUA
United Nations Observer Mission in Angola
MONUC
United Nations Organization Mission in the Democratic Republic of the Congo
N
NA
not available
NACC
North Atlantic Cooperation Council; see Euro-Atlantic Partnership Council
(EAPC)
NAM
Nonaligned Movement
NATO
North Atlantic Treaty Organization
NC
Nordic Council
NEA','ba4c52615eff0d2f02779cca0986e8905038cfb3309e441ad850c1ea9b80ab5a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ee3e9e1747125fc9b8ccd38fadf0c6433f599d39d257fdc354f0bb9d6aa3914',2000,'MZ','Mozambique','transnational-issues',354,'Nuclear Energy Agency
NEGL
negligible
NIB
Nordic Investment Bank
NIC
newly Industrializing country; see newly Industrializing economy (NIE)
NIE
newly industrializing economy
nm
nautical mile
NMT
Nordic Mobile Telephone
NSG
Nuclear Suppliers Group
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and
Under Water
NZ','afc16185092616d32823cc9abd0082afb7a768517852ec536d39ace809a4df50','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bf46994893eee6abbf6f0b21f74fe5a1dcb107daebe523f1fd537f08a266934',2000,'NZ','New Zealand','transnational-issues',369,'Disputes - international: territorial claim in
Antarctica (Ross Dependency)
Background: Settied as a coiony of Spain in the
1520s, Nicaragua gained its independence in 1821 .
Violent opposition to governmentai manipuiation and
corruption spread to all classes by 1978 and resulted
in a short-iived civil war that brought the Marxist
Sandinista guerriiias to power in 1 979. Nicaraguan aid
to ieftist rebeis in El Salvador caused the US to
sponsor anti-Sandinista contra guerrillas through
much of the 1980s. Free elections in 1990 and again
in 1996 saw the Sandinistas defeated. The country
has siowly rebuilt its economy during the 1990s, but
was hard hit by Hurricane Mitch in 1998.
Disputes - international: territorial disputes with
Colombia over the Archipelago de San Andres y
Providencia and Quita Sueno Bank; with respect to
the maritime boundary question in the Golfo de
Fonseca, the ICJ referred to the line determined by
the 1900 Honduras-Nicaragua Mixed Boundary
Commission and advised that some tripartite
resolution among El Salvador, Honduras, and
Nicaragua likely would be required; maritime
boundary dispute with Honduras in the Caribbean Sea
Illicit drugs: transshipment point for cocaine
destined for the US and transshipment point for
arms-for-drugs dealing
362
Disputes - international: none
fTrinidad and
(Tobago
I n t r 0 d u c t i 0 n
Background: The islands came under British control
in the 19th century; independence was granted in
1 962. The country is one of the most prosperous in the
Caribbean thanks largeiy to petroleum and natural
gas production and processing. Tourism, mostly in
Tobago, is targeted for expansion and is growing.
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; producer of
cannabis
Tromelin Island
(possession of France)
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 15 52 S, 54 25 E
Map references: Afn''ca
Area:
total: 1 sq km
land: 1 sq km
wafer; 0 sq km
Area - comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical
Terrain: low, flat, and sandy
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
permanent pastures: 0%
forests and woodland: 0%
other: 100% (scattered bushes)
irrigated land: 0 sq km (1993)
Natural hazards: NA
Environment - current issues: NA
Geography - note: climatologically important
location for forecasting cyclones; wildlife sanctuary
0
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
ODA
official development assistance
OECD
Organization for Economic Cooperation and Development
OECS
Organization of Eastern Caribbean States
OIC
Organization of the Islamic Conference
ONUSAL
United Nations Observer Mission in El Salvador
OOF
other official flows
OPANAL
Organismo para la Proscripcion de las Armas Nucleares en la America Latina y el
Caribe; see Agency for the Prohibition of Nuclear Weapons In Latin America and
the Caribbean
OPCW
Organization for the Prohibition of Chemical Weapons
OPEC
Organization of Petroleum Exporting Countries
OSCE
Organization for Security and Cooperation in Europe
Ozone Layer Protection
Montreal Protocol on Substances That Deplete the Ozone Layer
P
PCA
Permanent Court of Arbitration
PDRY
People''s Democratic Republic of Yemen [Yemen (Aden) or South Yemen]; used
for information dated before 22 May 1990 or CY91
PFP
Partnership for Peace
560
Appendix A: Abbreviations (continued)
R
Ramsar
see Wetlands
RG
Rio Group
S
SAARC
South Asian Association for Regional Cooperation
SACU
Southern African Customs Union
SADC
Southern African Development Community
SADCC
Southern African Development Coordination Conference; see Southern African
Development Community (SADC)
SELA
Sistema Economico Latinoamericana; see Latin American Economic System
(LAES)
SPRY
Sociaiist Federal Republic of Yugoslavia; dissolved 5 December 1991
SHF
super-high-frequency
Ship Pollution
Protocol of 1978 Relating to the International Convention for the Prevention of
Pollution From Ships, 1973 (MARPOL)
Sparteca
South Pacific Regional Trade and Economic Cooperation Agreement
SPC
South Pacific Commission
SPF
South Pacific Forum
sq km
square kilometer
sq mi
square mile
T
TAT
Trans-Atlantic Telephone
Tropical Timber 83
International Tropical Timber Agreement, 1983
Tropical Timber 94
International Tropical Timber Agreement, 1994
U
UAE','47883bff0425dedf130d438bba2b555fea30fa8acf39d087bf9e0fd90d89e16b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5802db34d5c6c24d948d14293a7b0e7cb7166676262e803433aba8b0c9c49d2e',2000,'NO','Norway','transnational-issues',375,'Disputes - international: territorial claim in
Antarctica (Queen Maud Land)
374
(f^MasTrah
''Duqm
Arabian
Sea
r','fc7e32cd5c24907d101bf0ee0ab46b604f0a8a2bb61f7ce10d460e13efca0576','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bcd5d8b2d900cd9ebc852748c6e3359d8836271efdd27a6f56872879c7f6015',2000,'MX','Mexico','transnational-issues',399,'Illicit drugs: important gateway country for Latin
American cocaine entering the European market;
transshipment point for hashish from North Africa to
Europe; consumer of Southwest Asian heroin
402','e8a1f991d5b125fce19756ac9b2da2dd2ebeef00508b43b61c50c06ba7ad2af4','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7919d744b0878935e45deb0a5ff48745aa60fc7c1d8aae1b7f3a3041516e4e3',2000,'PR','Puerto Rico','transnational-issues',400,'Ifiimmonwealth associated with the US)
North Atlantic Ocean
Isla o
Deseches
r - — — —r JUAN
\\Aguadilla Arecibo
Bayam6n‘ ’carolinT^
Isla de
*. Culebra
"Fajardo ''''''
Isla
Mona
Mona
Passage
VMayaguez Puerto RiCO ’Caguas
L Guayanilla. Ponce ^ j
^ de Ponce ^ * »•
>
Isla de
Vieques
Caribbean Sea
0 10 20 km
6 10 20 mi
1^ Introduction””
Background; Discovered by Columbus in 1493, the
island was ceded by Spain to the US in 1 898 following
the Spanish-American War. A popularly elected
governor has served since 1948. In plebiscites held in
1967 and 1993, voters chose to retain commonwealth
status.
G e 0 g r a p h y ~
Location; Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, east of the','98d183b70ec5d0f2b13b7df2e0b4822db098da525af2ea270512170a52298390','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaa13e84d701539f20b4543f4b58a95c4bcf39e1a4e4aaf77da5c0e1770044ac',2000,'DO','Dominican Republic','transnational-issues',401,'Geographic coordinates; 18 15 N, 66 30 W
Map references; Central America and the
Caribbean
Area;
tofa/; 9,104 sq km
land: 8,959 sq km
water: 145 sq km
Area - comparative; slightly less than three times
the size of Rhode Island
Land boundaries; 0 km
Coastiine; 501 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate; tropical marine, mild; little seasonal
temperature variation
Terrain; mostly mountains, with coastal plain belt in
north; mountains precipitous to sea on west coast;
sandy beaches along most coastal areas
Elevation extremes;
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1,338 m
Natural resources; some copper and nickel;
potential for onshore and offshore oil
Land use;
arable land: 4%
permanent crops: 5%
permanent pastures: 26%
forests and woodland: 16%
of/ier;49%(1993 est.)
Irrigated land; 390 sq km (1993 est.)
Natural hazards; periodic droughts; hurricanes
Environment - current issues; erosion; occasional
drought causing water shortages
Geography - note; important location along the
Mona Passage - a key shipping lane to the Panama
Canal; San Juan is one of the biggest and best natural
harbors in the Caribbean; many small rivers and high
central mountains ensure land is well watered; south
coast relatively dry; fertile coastal plain belt in north
I ■ T e o”^l g- ■ : ''
Population; 3,915,798 (July 2000 est.)
Age structure;
0-14 years: 24% (male 480,100; female 457,684)
15-64 years: 66% (male 1,234,065; female
1,336,848)
65 years and over: 1 0% (male 1 74,383; female
232,718) (2000 est.)
Population growth rate; 0.56% (2000 est.)
Birth rate; 1 5.47 births/1 ,000 population (2000 est.)
Death rate; 7.74 deaths/1,000 population
(2000 est.)
Net migration rate; -2.14 migrant(s)/1,000
population (2000 est.)
Sex ratio;
at birth: 1.06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.93 male(s)/female (2000 est.)
Infant mortality rate; 9.71 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth;
total population: 75.55 years
male: 71 .05 years
female: 80.3 years (2000 est.)
Total fertility rate; 1 .9 children born/woman
(2000 est.)
Nationality;
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups; NA
Religions; Roman Catholic 85%, Protestant and
other 15%
Languages; Spanish, English
Literacy;
definition: age 15 and over can read and write
total population: 89%
male: 90%
female: 88% (1 980 est.)
I ^ ~ Govern me n t
Country name;
conventional long form: Commonwealth of Puerto
Rico
conventional shod form: Puerto Rico
Data code; RQ
Dependency status; commonwealth associated
with the US
Government type; commonwealth
Capital; San Juan
Administrative divisions; none (commonwealth
associated with the US); there are no first-order
administrative divisions as defined by the US
Government, but there are 78 municipalities
(municipios, singular - municipio) at the second order;
Adjuntas, Aguada, Aguadilla, Aguas Buenas,
Aibonito, Anasco, Arecibo, Arroyo, Barceloneta,
Barranquitas, Bayamon, Cabo Rojo, Caguas, Camuy,
Canovanas, Carolina, Catano, Cayey, Ceiba, dales,
Cidra, Coamo, Comedo, Corozal, Culebra, Dorado,
Fajardo, Florida, Guanica, Guayama, Guayanilla,
Guaynabo, Gurabo, Hatillo, Hormigueros, Humacao,
Isabela, Jayuya, Juana Diaz, Juncos, Lajas, Lares,
Las Marias, Las Piedras, Loiza, Luquillo, Manati,
Maricao, Maunabo, Mayaguez, Moca, Morovis,
Naguabo, Naranjito, Orocovis, Patillas, Penuelas,
Ponce, Quebradillas, Rincon, Rio Grande, Sabana
Grande, Salinas, San German, San Juan, San
Lorenzo, San Sebastian, Santa Isabel, Toa Alta, Toa
Baja, Trujillo Alto, Utuado, Vega Alta, Vega Baja,
Vieques, Villalba, Yabucoa, Yauco
Independence; none (commonwealth associated
with the US)
National holiday; US Independence Day, 4 July
(1776)
Constitution; ratified 3 March 1 952; approved by US
Congress 3 July 1952; effective 25 July 1952
Legal system; based on Spanish civil code
Suffrage; 18 years of age; universal; indigenous
inhabitants are US citizens but do not vote in US
presidential elections
Executive branch;
chief of state: President William Jefferson CLINTON
of the US (since 20 January 1993); Vice President
Albert GORE, Jr. (since 20 January 1993)
403
Puerto Rico (continued)
head of government: Governor Pedro ROSSELLO
(since 2 January 1993)
cabinet: NA
elections: US president and vice president elected on
the same ticket for four-year terms; governor elected
by popular vote for a four-year term; election last held
5 November 1 996 (next to be held 7 November 2000)
election results: Pedro ROSSELLO reelected
governor; percent of vote - 51 .1 %
Legislative branch: bicameral Legislative Assembly
consists of the Senate (28 seats; members are directly
elected by popular vote to serve four-year terms) and
the House of Representatives (54 seats; members are
directly elected by popular vote to serve four-year
terms)
elections: Senate - last held 5 November 1996 (next
to be held 7 November 2000); House of
Representatives - last held 5 November 1 996 (next to
be held 7 November 2000)
election results: Senate - percent of vote by party -
NA; seats by party - PNP 19, PPD 8, PIP 1 ; House of
Representatives - percent of vote by party - NA; seats
by party -PNP 37, PPD 16, PIP 1
note: Puerto Rico elects one nonvoting representative
to the US House of Representatives; elections last
held 5 November 1996 (next to be held 7 November
2000); results - percent of vote by party - NA; seats by
party - PNP 1 (Carlos Romero BARCELO)
Judicial branch: Supreme Court, justices appointed
by the governor with the consent of the Senate;
Superior Courts, justices appointed by the governor
with the consent of the Senate; Municipal Courts,
justices appointed by the governor with the consent of
the Senate
Political parties and leaders: National Democratic
Party [William MIRANDA]; National Republican Party
of Puerto Rico [Luis FERRE]; New Progressive Party
or PNP [Pedro ROSSELLO]; Popular Democratic
Party or PPD [Anibal ACEVIDA Vila]; Puerto Rican
Independence Party or PIP [Ruben BERRIOS
Martinez]
Political pressure groups and leaders: Armed
Forces for National Liberation or FALN; Armed Forces
of Popular Resistance; Boricua Popular Army (also
known as the Macheteros); Volunteers of the Puerto
Rican Revolution
International organization participation: Caricom
(observer), ECLAC (associate), FAO (associate),
ICFTU, Interpol (subbureau), IOC, WCL, WFTU,
WHO (associate)
Diplomatic representation in the US: none
(commonwealth associated with the US)
Diplomatic representation from the US: none
(commonwealth associated with the US)
Flag description: five equal horizontal bands of red
(top and bottom) alternating with white; a blue
isosceles triangle based on the hoist side bears a
large, white, five-pointed star in the center; design
based on the US flag
i Economy
Economy - overview: Puerto Rico has one of the
most dynamic economies in the Caribbean region. A
diverse industrial sector has surpassed agriculture as
the primary locus of economic activity and income.
Encouraged by duty-free access to the US and by tax
incentives, US firms have invested heavily in Puerto
Rico since the 1950s. US minimum wage laws apply.
Sugar production has lost out to dairy production and
other livestock products as the main source of income
in the agricultural sector. Tourism has traditionally
been an important source of income for the island,
with estimated arrivals of nearly 5 million tourists in
1 999. Prospects for 2000 are good, assuming
continued strength in the tourism and construction
sectors and continuation of the US boom.
GDP: purchasing power parity -$38.1 billion
(1999 est.)
GDP - real growth rate: 4.2% (1999 est.)
GDP - per capita: purchasing power parity - $9,800
(1999 est.)
GDP - composition by sector:
agriculture: 1%
industry: 45%
services: 54% (1999 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: m%
Inflation rate (consumer prices): 5.2% (1999 est.)
Labor force: 1 .3 million (1 996)
Labor force - by occupation: agriculture 3%,
industry 20%, services 77% (1999 est.)
Unemployment rate: 13% (FY97/98 est.)
Budget:
revenues: $6.7 billion
expenditures: $9.6 billion, including capital
expenditures of $NA (FY99/00)
Industries: pharmaceuticals, electronics, apparel,
food products; tourism
Industrial production growth rate: NA%
Electricity - production: 17.765 billion kWh (1998)
Electricity - production by source:
fossil fuel: 98.06%
hydro: 1 .94%
nuclear: 0%
other; 0% (1998)
Electricity - consumption: 16.521 billion kWh
(1998)
Electricity - exports; 0 kWh (1 998)
Electricity - imports: 0 kWh (1 998)
Agriculture - products: sugarcane, coffee,
pineapples, plantains, bananas; livestock products,
chickens
Exports: $34.9 billion (f.o.b., 1999)
Exports - commodities: pharmaceuticals,
electronics, apparel, canned tuna, rum, beverage
concentrates, medical equipment
Exports - partners: US 88% (1999)
Imports: $25.3 billion (c.i.f., 1999)
Imports - commodities: chemicals, machinery and
equipment, clothing, food, fish, petroleum products
Imports - partners: US 60% (1999)
Debt - external: $NA
Economic aid - recipient: $NA
Currency: 1 US dollar (US$) = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 July - 30 June
f Communications
Telephones - main lines in use: 1.196 million
(1995)
Telephones - mobile cellular: 1 71 ,000 (1995)
Telephone system: modern system, integrated with
that of the US by high-capacity submarine cable and
Intelsat with high-speed data capability
domestic: digital telephone system; cellular telephone
service
international: satellite earth station - 1 Intelsat;
submarine cable to US
Radio broadcast stations: AM 72, FM 17,
shortwave 0 (1998)
Radios: 2.7 million (1997)
Television broadcast stations: 18 (plus three
stations of the US Armed Forces Radio and T elevision
Service) (1997)
Televisions: 1.021 million (1997)
Internet Service Providers (ISPs): 18 (1999)
[ tT a n s p 0 r t a 1 1 b n
Railways;
total: 96 km
narrow gauge: 96 km 1 .000-m gauge, rural,
narrow-gauge system for hauling sugarcane; no
passenger service
Highways;
total: 14,400 km
paved: 14,400 km
unpaved; 0 km (1996 est.)
Ports and harbors: Guanica, Guayanilla,
Guayama, Playa de Ponce, San Juan
Merchant marine;
total: 1 ship (1 ,000 GRT or over) totaling 1 7,51 3 GRT/
14,976 DWT
ships by type: roll-on/roll-off 1 (1 999 est.)
Airports: 30 (1999 est.)
Airports - with paved runways;
total: 21
over 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 6 (1 999 est.)
Airports ■ with unpaved runways:
total: 9
914 to 1,523 m: 2
under 914 m: 7 (1999 est.)
Puerto Rico (continued)','d9ad95965e3866afd19cf19171a6f1810e4368195468dd590441bece5178eb27','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85246bcfb84b0371507159c275354b3337d3d6a1b2a93e284c0ddfba0725a8ad',2000,'MY','Malaysia','transnational-issues',421,'Illicit drugs: transit point for Golden T riangle heroin
going to North America, Western Europe, and the
Third World; also a money-laundering center
446
I . TiTfod "li''cTTo n '' '' permanent crops: 3%
permanent pastures: 1 7%
Background: In 1 91 8 the Slovaks joined the closely forests and woodland: 41 %
related Czechs to form Czechoslovakia. Following the other: 8% (1 993 est.)
chaos of World War II, Czechoslovakia became a Irrigated land: 800 sq km (1993 est.)
communist nation within Soviet-ruled Eastern Europe. Natural hazards: NA
Soviet influence collapsed in 1989 and
Czechoslovakia once more became free. The Slovaks
and the Czechs agreed to separate peacefully on 1
January 1993. Slovakia has experienced more
difficulty than the Czech Republic in developing a
modern market economy.
Environment • current issues: air pollution from
metallurgical plants presents human health risks; acid
rain damaging forests
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air
I"'' Geography
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Endangered
Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Antarctic-Environmental Protocol,
Climate Change-Kyoto Protocol
Geography - note: landlocked
Area - comparative: about twice the size of New - - - - - -
Hampshire s People
Land boundaries:
fofa/;1,355km
border counfr/es; Austria 91 km, Czech Republic 215
km, Hungary 515 km, Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime ciaims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: rugged mountains in the central and
northern part and lowlands in the south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovka 2,655 m
Natural resources: brown coal and lignite; small
Population: 5,407,956 (July 2000 est.)
Age structure:
0-/4 years; 19% (male 538,780; female 514,427)
15-64 years: 69% (male 1 ,854,779; female
1,880,584)
65 years and over: 12% (male 236,072; female
383,314) (2000 est.)
Population growth rate: 0.12% (2000 est.)
Birth rate: 10 births/1,000 population (2000 est.)
Death rate: 9.29 deaths/1,000 population
(2000 est.)
Net migration rate: 0.53 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
amounts of iron ore, copper and manganese ore; salt; at birth: 1 .05 male(s)/female
arable land under 1 5 years: 1 .05 male(s)/female
Land use: 15-64 years: 0.99 male(s)/female
arable land: 31 % 65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (2000 est.)
Infant mortality rate: 9.18 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 73.74 years
male: 69.71 years
female: 77.98 years (2000 est.)
Total fertility rate: 1 .25 children born/woman
(2000 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.7%, Hungarian 10.6%,
Gypsy 1 .6% (the 1 992 census figures underreport the
Gypsy/Romany community, which is about 500,000),
Czech, Moravian, Silesian 1.1%, Ruthenian and
Ukrainian 0.6%, German 0.1%, Polish 0.1%, other
0.2% (1996)
Religions: Roman Catholic 60.3%, atheist 9.7%,
Protestant 8.4%, Orthodox 4.1%, other 17.5%
Languages: Slovak (official), Hungarian
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
I Government
Country name:
conventional long form: Slovak Republic
conventional short form: Slovakia
local long form: Slovenska Republika
local short form: Slovensko
Data code: LO
Government type: parliamentary democracy
Capital: Bratislava
Administrative divisions: 8 regions (kraje,
singular - kraj); Banskobystricky, Bratislavsky,
Kosicky, Nitriansky, Presovsky, Trenciansky,
Trnavsky, Zilinsky
Independence: 1 January 1993 (Czechoslovakia
split into the Czech and Slovak Republics)
National holiday: Slovak Constitution Day, 1
September (1992); Anniversary of Slovak National
Uprising, 29 August (1944)
Constitution: ratified 1 September 1992, fully
effective 1 January 1 993; changed in September 1 998
to allow direct election of the president
Legal system: civil law system based on
Austro-Hungarian codes; has not accepted
compulsory ICJ jurisdiction; legal code modified to
comply with the obligations of Organization on
Security and Cooperation in Europe (OSCE) and to
expunge Marxist-Leninist legal theory
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Rudolf SCHUSTER (since 1 5
June 1999)
head of government: Prime Minister Mikulas
DZURINDA (since 30 October 1998)
cabinet: Cabinet appointed by the president on the
recommendation of the prime minister
447
Slovakia (continued)
elections: president elected by direct popuiar vote for
a five-year term; eiection iast held 30 May 1 999 (next
to be held NA 2004); note - following the Nationai
Council elections in September 1 998, the Constitution
was changed to allow direct eiection of the president;
foliowing National Council elections, the leader of the
majority party or the leader of a majority coalition is
usually appointed prime minister by the president
election results: Rudolf SCHUSTER won the first
direct popular election with 57% of the vote
note: government coalition - SDK, SDL, SMK, SOP
Legislative branch: unicameral National Council of
the Slovak Republic or Narodna Rada Slovenskej
Republiky (150 seats; members are elected on the
basis of proportional representation to serve four-year
terms)
elections: last held 25-26 September 1 998 (next to be
held NA September 2002)
election results: percent of vote by party - HZDS 27%,
SDK 26.3%, SDL 14.7%, SMK 9.1%, SNS 9.1%, SOP
8%; seats by party - governing coalition 93 (SDK 42,
SDL 23, SMK 15, SOP 13), opposition 57 (HZDS 43,
SNS 14)
Judicial branch: Supreme Court, judges are elected
by the National Council; Constitutional Court, judges
appointed by president from group of nominees
approved by the parliament
Political parties and leaders: Christian Democratic
Movement or KDH [Jan CARNOGURSKYj;
Coexistence [Miklos DURAY]; Democratic Party or
DS [Jan LANGOSj; Democratic Union or DU [Lubomir
HARACHj; Hungarian Christian Democratic
Movement or MKDH [Bela BUGARj; Hungarian Civic
Party or MOS [Laszio A. NAGY]; Movement for a
Democratic Slovakia or HZDS [Vladimir MECIARj;
Party of Civic Understanding or SOP [Pavol HAMZIKj;
Party of Greens in Slovakia or SZS [Ladislav
AMBROSj; Party of the Democratic Center or SDS
[Ivan MJARTANj; Party of the Democratic Left or SDL
[Jozef MIGASj; Party of the Hungarian Coalition or
SMK (includes MKDH, MOS, and Coexistence) [Bela
BUGARj; Slovak Democratic Coalition or SDK
(includes KDH, DS, DU, SSDS, SZS) [Mikulas
DZURINDAj; Slovak National Party or SNS [Anna
MALIKOVA]; Social Democratic Party of Slovakia or
SSDS [Jaroslav VOLF]; SMER [Robert FICO]
Political pressure groups and leaders:
Association of Employers of Slovakia; Association of
Towns and Villages or ZMOS; Christian Social Union;
Confederation of Trade Unions or KOZ; Metal
Workers Unions or KOVO and METALURG; Party of
Entrepreneurs and Businessmen of Slovakia
International organization participation: Australia
Group, BIS, BSEC (observer), CCC, CE, CEI, CERN,
EAPC, EBRD, ECE, EU (applicant), FAO, IAEA, IBRD,
ICAO, ICFTU, ICRM, IDA, IFC, IFRCS, ILO, IMF, IMO,
Inmarsat, Intelsat (nonsignatory user), Interpol, IOC,
lOM, ISO, ITU, NAM (guest), NSG, OPCW, OSCE,
PCA, PFP, UN, UNCTAD, UNDOF, UNESCO,
UNIDO, UNTSO, UPU, WEU (associate partner),
WFTU, WHO, WlPO, WMO, WToO, WTrO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Martin BUTORA
chancery: (temporary) Suite 250, 2201 Wisconsin
Avenue NW, Washington, DC 20007
telephone: [1] (202) 965-5161
FAX: [1] (202) 965-5166
Diplomatic representation from the US:
chief of mission: Ambassador (vacant); Charge
d''Affaires Douglas HENGEL
embassy: Hviezdoslavovo Namestie 4, 81102
Bratislava
mailing address: use embassy street address
telephone: [421] (7) 5443-0861 , 5443-3338
FAX; [421] (7) 5441-5148
Flag description: three equal horizontal bands of
white (top), blue, and red superimposed with the
Slovak cross in a shield centered on the hoist side; the
cross is white centered on a background of red and
blue
I Economy
Economy - overview: Slovakia continues the
difficult transition from a centrally planned economy to
a modern market economy. It started 1999 faced with
a sharp slowdown in GDP growth, large budget and
current account deficits, fast-growing external debt,
and persisting corruption, but made considerable
progress toward achieving macroeconomic
stabilization later in the year. Tough austerity
measures implemented in May cut the overall fiscal
deficit from 6% in 1998 to under 4% of GDP, and the
current account deficit was halved to an estimated 5%
of GDP. Slovakia was invited by the EU in December
to begin accession negotiations early in 2000. Foreign
investor interest, although rising, has not yet led to
actual deals; several credit rating agencies have
upgraded their outlook for the country. However,
Slovakia''s fiscal position remains weak; inflation and
unemployment remain high; and the government is
only now addressing the structural problems inherited
from the MECIAR period, such as large inefficient
enterprises, an insolvent banking sector and high
inter-company debts, and declining tax and social
support payments. Furthermore, the government
faces considerable public discontent over the
government''s austerity package, persistent high
unemployment - which reached an all-time high of
20% in December 1999 - rising consumer prices,
reduced social benefits, and declining living
standards. Real GDP is forecast to stagnate in 2000;
inflationary pressures will remain strong due to further
price liberalization; and little scope exists for further
fiscal consolidation in the 2000 budget, which is based
on rosier assumptions than nearly all private
forecasts.
GDP: purchasing power parity - $45.9 billion
(1999 est.)
GDP - real growth rate: 1 .9% (1 999 est.)
GDP - per capita: purchasing power parity - $8,500
(1999 est.)
GDP ■ composition by sector:
agriculture: 5%
industry: 33%
sem''ces; 62% (1998)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: 5.1%
highest 10%; 18.2% (1992)
Inflation rate (consumer prices): 14% (1999 est.)
Labor force: 3.32 million (1997)
Labor force - by occupation: industry 29.3%,
agriculture 8.9%, construction 8%, transport and
communication 8.2%, services 45.6% (1994)
Unemployment rate: 20% (1999 est.)
Budget:
revenues: $5.4 billion
expenditures: $5.8 billion, including capital
expenditures of $NA (1999 est.)
Industries: metal and metal products; food and
beverages; electricity, gas, coke, oil, nuclear fuel;
chemicals and manmade fibers; machinery; paper
and printing; earthenware and ceramics; transport
vehicles; textiles; electrical and optical apparatus;
rubber products
Industrial production growth rate: 0.9% (1998)
Electricity - production: 20.035 billion kWh (1 998)
Electricity ■ production by source:
fossil fuel: 24%
hydro: 20%
nuclear: 56%
other 0% (1999 est.)
Electricity - consumption: 23.3 billion kWh
(1999 est.)
Electricity - exports: 920 million kWh (1 999 est.)
Electricity ■ imports: 840 million kWh (1999 est.)
Agriculture - products: grains, potatoes, sugar
beets, hops, fruit; pigs, cattle, poultry; forest products
Exports: $10.1 billion (f.o.b., 1999 est.)
Exports - commodities: machinery and transport
equipment 37%; intermediate manufactured goods
30%, miscellaneous manufactured goods 13%;
chemicals 9%; raw materials 4% (1998)
Exports - partners: EU 56% (Germany 29%,
Austria 7%), Czech Republic 20%, Poland 7% (1998)
Imports: $11.2 billion (f.o.b., 1999 est.)
Imports - commodities: machinery and transport
equipment 40%; intermediate manufactured goods
18%; fuels 11%; chemicals 11%; miscellaneous
manufactured goods 10% (1998)
Imports - partners: EU 50% (Germany 26%, Italy
6%), Czech Republic 18%, Russia 10% (1998)
Debt ■ external: $10.6 billion (1999)
Economic aid - recipient: $421.9 million (1995)
Currency: 1 koruna (Sk) = 100 halierov
Exchange rates: koruny (Sk) per US$1 - 42.059
(January 2000), 41 .363 (1 999), 35.233 (1 998), 33.61 6
(1997), 30.654 (1996), 29.713 (1995)
Fiscal year: calendar year
448
Slovakia (continued)','0284d7a6e6f8b75708672d862a147f751fc09cfe48d515be857bcffb7851ad76','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ece756e9f31643ea86584ec89dd34e76a3bae9df79483749181ba6a24879a599',2000,'SO','Somalia','transnational-issues',425,'Background: Intermittent civil war has been a fact of
life in Somalia since 1977. In 1991, the northern
portion of the country declared its independence as
Somaliland; although de facto independent and
relatively stable compared to the tumultuous south, it
has not been recognized by any foreign government.
Beginning in 1993, a two-year UN humanitarian effort
(primarily in the south) was able to alleviate famine
conditions, but when the UN withdrew in 1 995, having
suffered significant casualties, order still had not been
restored.
Disputes - international; most of the southern half
of the boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute with Ethiopia
over the Ogaden','c931e18f6e10a461d7c1afc2e0ec0c3dfdb029fed22e50f2b04e40f147214d52','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1b541715f5f486d1a1264224931bbb7969e54806002260257e06becf2e5565b',2000,'ZA','South Africa','transnational-issues',430,'Background: After the British seized the Cape of
Good Hope area in 1806, many of the Dutch settlers
(the Boers) trekked north to found their own republics.
The discovery of diamonds (1867) and gold (1886)
spurred wealth and immigration and intensified the
subjugation of the native inhabitants. The Boers
resisted British encroachments, but were defeated in
the Boer War (1899-1902). The resulting Union of
South Africa operated under a policy of apartheid - the
separate development of the races. The 1990s
brought an end to apartheid politically and ushered in
black majority rule.
Disputes - international: claimed by Argentina
Southern Ocean
Disputes - internationai: Antarctic Treaty defers
claims (see Antarctic Treaty Summary in the
Antarctica entry); sections (some overlapping)
claimed by Argentina, Australia, Chile, France, New
Zealand, Norway, and UK; the US and most other
nations do not recognize the maritime claims of other
nations and have made no claims themselves (the US
reserves the right to do so); no formal claims have
been made in the sector between 90 degrees west
and 150 degrees west
Background: Spain''s powerful world empire of the
16th and 17th centuries ultimately yielded command
of the seas to England. Subsequent failure to embrace
the mercantile and industrial revolutions caused the
country to fall behind Britain, France, and Germany in
economic and political power. Spain remained neutral
in World Wars I and II, but suffered through a
devastating Civil War (1 936-39). In the second half of
the 20th century, it has played a catch-up role in the
western international community. Continuing
concerns are large-scale unemployment and the
Basque separatist movement.
Disputes ■ international: Gibraltar issue with UK;
Spain controls five places of sovereignty (plazas de
soberania) on and off the coast of Morocco - the
coastal enclaves of Ceuta and Melilla, which Morocco
contests, as well as the islands of Penon de
AIhucemas, Penon de Velez de la Gomera, and Islas
Chafarinas
Illicit drugs: key European gateway country for Latin
American cocaine and North African hashish entering
the European market; transshipment point for and
consumer of Southwest Asian heroin
Spratly Islands
Northeast Cay
Soulhvi^st Cay-^
South','d376520343b4df745efecf5e1f401e1b8f1fa86764d5f85f64e0c67cb7ce6cf2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4100e14444d6fa7b2c3ac5ac0d4fc576f2eb767e1a86991f315131e24b694423',2000,'PH','Philippines','transnational-issues',439,'Disputes - international: all of the Spratly Islands
are claimed by China, Taiwan, and Vietnam; parts of
them are claimed by Malaysia and the Philippines; in
1984, Brunei established an exclusive fishing zone,
which encompasses Louisa Reef in the southern
Spratly Islands, but has not publicly claimed the island
464
I Sri Lanka
Background: Occupied by the Portuguese in the
16th century and the Dutch in the 17th century, the
island was ceded to the British in 1802. As Ceylon it
became independent in 1948; its name was changed
in 1 972. Tensions between the Sinhaiese majority and
Tamii separatists erupted in vioience in the
mid-1980s. Tens of thousands have died in an ethnic
war that continues to fester.
S Geography
Location: Southern Asia, isiand in the Indian Ocean,
south of India
Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area:
fo/a/;65,610sqkm
land: 64,740 sq km
water: 870 sq km
Area - comparative: slightiy larger than West
Virginia
Land boundaries: 0 km
Coastiine: 1,340 km
Maritime ciaims:
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continentai margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Ciimate: tropical monsoon; northeast monsoon
(December to March); southwest monsoon (June to
October)
Terrain: mostly low, flat to rolling piain; mountains in
south-central interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutaiagaia 2,524 m
Natural resources: limestone, graphite, minerai
sands, gems, phosphates, ciay, hydropower
Land use:
arable land: 14%
permanent crops: 15%
permanent pastures: 7%
forests and woodland: 32%
other; 32% (1 993 est.)
Irrigated land: 5,500 sq km (1993 est.)
Natural hazards: occasional cyclones and
tornadoes
Environment - current issues; deforestation; soil
erosion; wildiife populations threatened by poaching
and urbanization; coastal degradation from mining
activities and increased pollution; freshwater
resources being poiiuted by industriai wastes and
sewage runoff; waste disposal; air poiiution in
Coiombo
Environment - international agreements:
party to: Biodiversity, Ciimate Change,
Desertification, Endangered Species, Environmentai
Modification, Hazardous Wastes, Law of the Sea,
Nuciear Test Ban, Ozone Layer Protection, Ship
Poiiution, Wetiands
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location near major
Indian Ocean sea ianes
f" . . PeoTTe
Population: 19,238,575
note: since the outbreak of hostiiities between the
government and armed Tamil separatists in the
mid-1980s, severai hundred thousand Tamil civilians
have fied the isiand; as of mid-1999, approximateiy
66,000 were housed in 133 refugee camps in south
India, another 40,000 iived outside the Indian camps,
and more than 200,000 Tamils have sought refuge in
the West (Juiy 2000 est.)
Age structure:
0- 14 years: 26% (male 2,605,251 ; female 2,490,41 6)
15-64 years: 67% (male 6,285,1 18; female
6,606,196)
65 years and over: 7% (male 602,470; female
649,124) (2000 est.)
Population growth rate: 0.89% (2000 est.)
Birth rate: 1 6.78 births/1 ,000 population (2000 est.)
Death rate: 6.43 deaths/1,000 popuiation
(2000 est.)
Net migration rate: -1.47 migrant(s)/1,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.93 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
Infant mortality rate; 16.51 deaths/1,000 live births
(2000 est.)
Life expectancy at birth:
total population: 71 .83 years
male: 69.33 years
female: 74.45 years (2000 est.)
Total fertility rate: 1 .98 children born/woman
(2000 est.)
Nationality;
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 74%, Tamil 18%, Moor
7%, Burgher, Malay, and Vedda 1 %
Religions: Buddhist 70%, Hindu 15%, Christian 8%,
Muslim 7% (1999)
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%
note: English is commonly used in government and is
spoken competently by about 10% of the population
Literacy;
definition: age 15 and over can read and write
total population: 90.2%
male: 93.4%
fema/e;87.2% (1995 est.)
I Government
Country name;
conventional long form: Democratic Socialist
Republic of Sri Lanka
conventional short form: Sri Lanka
former: Ceylon
Data code: CE
Government type; republic
Capital: Colombo
Administrative divisions: 8 provinces; Central,
North Central, North Eastern, North Western,
Sabaragamuwa, Southern, Uva, Western
note: North Eastern province may have been divided
in two - Northern and Eastern
Independence: 4 February 1948 (from UK)
National holiday: Independence and National Day,
4 February (1948)
Constitution: adopted 16 August 1978
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim, Sinhalese, and
customary law; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch;
chief of state: President Chandrika Bandaranaike
KUMARATUNGA (since 12 November 1994); note -
Sirimavo BANDARANAIKE is the prime minister; in Sri
Lanka the president is considered to be both the chief
of state and the head of the government, this is in
contrast to the more common practice of dividing the
roles between the president and the prime minister
when both offices exist
head of government: President Chandrika
Bandaranaike KUMARATUNGA (since 12 November
1994); note - Sirimavo BANDAR/\\NAIKE is the prime
minister; in Sri Lanka the president is considered to be
both the chief of state and the head of the
government, this is in contrast to the more common
practice of dividing the roles between the president
and the prime minister when both offices exist
cabinet: Cabinet appointed by the president in
consultation with the prime minister
elections: president elected by popular vote for a
six-year term; election last held 21 December 1999
(next to be held NA December 2005)
465
Sri Lanka (continued)
election results: Chandrika Bandaranaike
KUMARATUNGA reelected president; percent of
vote - Chandrika Bandaranaike KUMARATUNGA
(PA) 51%, Ranil WICKREMASINGHE (UNP) 42%,
other 7%
Legislative branch: unicameral Parliament (225
seats; members elected by popular vote on the basis
of a modified proportional representation system by
district to serve six-year terms)
elections: last held 1 6 August 1 994 (next to be held by
August 2000)
election results: percent of vote by party - PA 49.0%,
UNP 44.0%, SLMC 1.8%, TULF 1.7%, SLPF 1.1%,
EPDP 0.3%, UPFO.3%, PLOTE 0.1%, other 1.7%;
seats by party - PA 105, UNP 94, EPDP 9, SLMC 7,
TULF 5, PLOTE 3, SLPFI.UPFI
Judicial branch: Supreme Court, judges are
appointed by the president; Court of Appeals, judges
are appointed by the president
Political parties and leaders: All Ceylon Tamil
Congress or ACTC [leader NAj; Ceylon Workers
Congress or CLDC [leader NAj; Communist Party
[leader NAj; Communist Party/Beijing or CP/B [leader
NAj; Democratic People''s Liberation Front or DPLF
[leader NAj; Democratic United National (Lalith) Front
or DUNLF [leader NAj; Desha Vimukthi Janatha Party
or DVJP [leader NAj; Eelam People''s Democratic
Party or EPDP [leader NAj; Eelam People''s
Revolutionary Liberation Front or EPRLF [leader NAj;
Eelam Revolutionary Organization of Students or
EROS [leader NAj; Janatha Vimukthi Peramuna or
JVP [leader NAj; Lanka Socialist Party/Trotskyite or
LSSP (Lanka Sama Samaja Party) [leader NAj;
Liberal Party or LP [leader NAj; New Socialist Party or
NSSP (Nava Sama Samaja Party) [leader NAj;
People''s Alliance or PA [Chandrika Bandaranaike
KUMARATUNGA]; People''s Liberation Organization
of Tamil Eelam or PLOTE [D. SIDDHARTHANj;
People''s United Front or MEP (Mahajana Eksath
Peramuna) [Dinesh GUNAWARDENEj; Sri Lanka
Freedom Party or SLFP [Chandrika Bandaranaike
KUMARATUNGA]; Sri Lanka Muslim Congress or
SLMC [leader NA]; Sri Lanka People''s Party or SLMP
(Sri Lanka Mahajana Party) [leader NA]; Sri Lanka
Progressive Front or SLPF [leader NA]; Tamil Eelam
Liberation Organization orTELO [leader NA]; Tamil
United Liberation Front or TULF [leader NA]; United
National Party or UNP [Ranil WICKREMASINGHE];
Upcountry People''s Front or UPF [leader NA]; several
ethnic Tamil and Muslim parties, represented in either
parliament or provincial councils
Political pressure groups and leaders: Buddhist
clergy; labor unions; Liberation Tigers of Tamil Eelam
or LTTE (insurgent group fighting for a separate
state); radical chauvinist Sinhalese groups such as
the National Movement Against Terrorism; Sinhalese
Buddhist lay groups
International organization participation: AsDB,C,
CCC, CP, ESCAP, FAO, G-24, G-77, IAEA, IBRD,
ICAO, ICC, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC,
lOM, ISO, ITU, NAM, OAS (observer), OPCW, PCA,
SAARC, UN, UNCTAD, UNESCO, UNIDO, UNU,
UPU, WCL, WFTU, WHO, WlPO, WMO, WToO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Warnasena
RASAPUTRAM
chancery: 2148 Wyoming Avenue NW, Washington,
DC 20008
telephone: [1] (202) 483-4025 through 4028
FAX; [11(202)232-7181
consulate(s) general: Los Angeles
consulate(s): New York
Diplomatic representation from the US:
c/j/ef of m/ss/orr; Ambassador Shaun E. DONNELLY
embassy: 210 Galle Road, Colombo 3
mailing address: P. 0. Box 106, Colombo
telephone: [94j (1) 448007
FAX; [94] (1)437345, 446013
Flag description: yellow with two panels; the
smaller hoist-side panel has two equal vertical bands
of green (hoist side) and orange; the other panel is a
large dark red rectangle with a yellow lion holding a
sword, and there is a yellow bo leaf in each corner; the
yellow field appears as a border that goes around the
entire flag and extends between the two panels','ae69ff8c74290096104ab0bde8cdc7d8f9685202e8d0de73a96fda4d6003ecaf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11ab80515d2cc4bde87593f789e215e4a6ccfcd523edd5a33328abb96e0c8651',2000,'IT','Italy','transnational-issues',451,'Disputes - international: Golan Heights is Israeli
occupied; dispute with upstream riparian Turkey over
Turkish water development plans for the Tigris and
Euphrates rivers; Syrian troops in northern, central,
and eastern Lebanon since October 1976
Illicit drugs: a transit point for opiates and hashish
bound for regional and Western markets
|Taiwan
Entry
follows
telephone-^39] (6) 54591
FAX-139] (6) 5043463
established— HA November 1974
a/m— to promote agricultural development; a UN
specialized agency
members— {175) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Botswana, Brazii, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Coiombia, Democratic Republic of the Congo, Repubiic of the
Congo, Costa Rica, Cote d''ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, Iceiand, india, Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania,
Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Soiomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia,','6f5a8fa448be1e183197c8799f509e1e007e9e6ae6cd3a24209531042ef5e648','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef64127a97cc34dbf49b63f8e1952c3320cf4f2e284b0a3d743dc7a8d67127ad',2000,'ZW','Zimbabwe','transnational-issues',452,'|; I n t rod u c t r 0 h
Background: Tajikistan has experienced three
changes in government and a civil war since it gained
independence in 1991 when the USSR collapsed. A
peace agreement among rival factions was signed in
1997, but implementation has progressed slowly.
Nevertheless, a number of opposition political parties
have been legalized and are participating in elections,
suggesting that the country may be stabilizing
politically. Russian-led peacekeeping troops are
based throughout the country, and
Russian-commanded border guards are stationed
along the border with Afghanistan.
I ™-.. ^ ^ ^ g^f’a p b y
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent
States
Area:
fofa/: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries:
fofa/; 3,651 km
border countries: Afghanistan 1 ,206 km, China 41 4
km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landiocked)
Climate: midlatitude continental, hot summers, mild
winters; semiarid to polar in Pamir Mountains
Terrain: Pamir and Aiay mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Vaiieys in southwest
Elevation extremes:
lowest point: Syrdariya 300 m
highest point: Pik Imeni Ismail Samani 7,495 m
Natural resources: hydropower, some petroleum,
uranium, mercury, brown coal, lead, zinc, antimony,
tungsten
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 4%
other: 65% (1993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: inadequate
sanitation facilities; increasing levels of soil salinity;
industrial pollution; excessive pesticides; part of the
basin of the shrinking Aral Sea suffers from severe
overutilization of available water for irrigation and
associated pollution
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked
I People
Population: 6,440,732 (July 2000 est.)
Age structure:
0-14 years: 42% (male 1 ,362,521 ; female 1 ,336,205)
15-64 years: 54% (male 1 ,714,545; female
1,734,430)
65 years and over: 4% (male 1 26, 1 70; female
166,861) (2000 est.)
Population growth rate: 2.12% (2000 est.)
Birth rate: 33.56 births/1 ,000 population (2000 est.)
Death rate: 8.64 deaths/1 ,000 population
(2000 est.)
Net migration rate: -3.71 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.99 male(s)/female
483
Tajikistan (continued)
65 years and over: 0.76 male(s)/female
total population: 0.99 male(s)/female (2000 est.)
Infant mortality rate: 1 1 7.42 deaths/1 ,000 live
births (2000 est.)
Life expectancy at birth:
total population: 64.08 years
male: 60.95 years
female: 67.38 years (2000 est.)
Total fertility rate: 4.35 children born/woman
(2000 est.)
Nationality:
noun: Tajikistani(s)
acfyecf/ve.''Tajikistani
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian
3.5% (declining because of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
1 Government
Country name:
conventional long form: Republic of Tajikistan
conventional short form: Tajikistan
local long form: Jumhurii Tojikiston
local short form: none
former: Tajik Soviet Socialist Republic •
Data code: Tl
Government type: republic
Capital: Dushanbe
Administrative divisions: 2 oblasts (viloyatho,
singular - viloyat) and one autonomous oblast*
(viloyati mukhtori); Viloyati Mukhtori Kuhistoni
Badakhshoni* (Khorugh - formerly Khorog), Viloyati
Khatlon (Qurghonteppa - formerly Kurgan-Tyube),
Viloyati Leninobod (Khujand ■ formerly Leninabad)
note; the administrative center name follows in
parentheses
Independence: 9 September 1991 (from Soviet
Union)
National holiday: National Day, 9 September (1991)
Constitution: 6 November 1994
Legal system: based on civil law system; no judicial
review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
cWef of sfafe; President Emomali RAHMONOV (since
6 November 1994; head of state and Supreme
Assembly chairman since 19 November 1992)
head of government: Prime Minister Ogil OQILOV
(since 20 January 1999)
cabinet: Council of Ministers appointed by the
president, approved by the Supreme Assembly
elections: president elected by popular vote for a
seven-year term; election last held 6 November 1999
(next to be held NA 2006); prime minister appointed
by the president
election results: Emomali RAHMONOV elected
president; percent of vote - Emomali RAHMONOV
96%, DavlatUSMONOV4%
Legislative branch: bicameral Supreme Assembly
or Majlisi Oli (181 seats; next election 96 seats;
members are elected by popular vote to sen/e
five-year terms)
elections: last held 26 February and 12 March 1995
(next to be held 27 February and 23 March 2000)
election results: percent of vote by party - NA;
estimated seats by party - Communist Party and
affiliates 100, People''s Party 10, Party of People''s
Unity 6, Party of Economic and Political Renewal 1 ,
other 64
Judicial branch: Supreme Court, judges are
appointed by the president
Political parties and leaders: Democratic Party or
TDP [Mahmadruzi ISKANDDAROV, chairman];
Islamic Rebirth Party [Muhammadsharif
HIMMAT-ZODA, chairman); Lali Badakhshan
Movement [Atobek AMIRBEKOV); National Unity
Party - evolved from the People''s Party and Party of
People''s Unity; Party of Justice and Development
[Rahmatullo ZOIROV); People''s Democratic Party of
Tajikistan or PDPT [Abdulmajid DOSTIEVj;
Rastokhez (Rebirth) Movement [Tohiri
ABDUJABBOR); Tajik Communist Party or CPT
[Shodi SHABDOLOV]; Tajikistan Party of Economic
and Political Renewal orTPEPR [leader NA); United
Tajik Opposition or UTO [Said Abdullo NURI] - an
umbrella group including: Adolatho "Justice" Party
[Abdurahmon KARIMOV, chairman]
International organization participation: AsDB,
CCC, CIS, EAPC, EBRD. ECE, ECO, ESCAP, FAO,
IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO,
IMF, Intelsat, IOC, lOM, ITU, OIC, OPCW, OSCE, UN,
UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WlPO, WMO, WTrO (observer)
Diplomatic representation in the US: Tajikistan
does not have an embassy in the US, but does have
a permanent mission to the UN: address - 136 East
67th Street, New York, NY 10021, telephone - [1]
(212) 472-7645, FAX - [1] (212) 628-0252; permanent
representative to the UN is Rashid ALIMOV
Diplomatic representation from the US:
chief of mission: Ambassador Robert FINN
embassy; temporarily collocated with the US
Embassy in Almaty (Kazakhstan)
mailing address: use embassy street address
telephone: NA
FAX: NA
Flag description: three horizontal stripes of red
(top), a wider stripe of white, and green; a gold crown
surmounted by seven gold, five-pointed stars is
located in the center of the white stripe
Disputes - international; dispute with Maiawi over
the boundary in Lake Nyasa (Lake Malawi)
Illicit drugs: growing role in transshipment of
Southwest and Southeast Asian heroin and South
American cocaine destined for European and US
markets and of South Asian methaqualone bound for
Southern Africa
Background: A unified Thai kingdom was
established in the mid-14th century; it was known as
Siam until 1 939. Thailand is the only southeast Asian
country never to have been taken over by a European
power, A bloodless revolution in 1932 led to a
constitutional monarchy. In alliance with Japan during
World War II, Thailand became a US ally following the
conflict.
Location: Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand, southeast of
Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
/ofa/;514,000sqkm
land: 51 1 ,770 sq km
water: 2,230 sq km
Area - comparative: slightly more than twice the
size of Wyoming
Land boundaries:
total: 4.863 km
border countries: Burma 1 ,800 km, Cambodia 803
km, Laos 1 ,754 km, Malaysia 506 km
Coastline; 3,219 km
Maritime ciaims:
continental shelf: 200-m depth or to the depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: t2 nm
Climate: tropical; rainy, warm, cloudy southwest
monsoon (mid-May to September); dry, cool northeast
monsoon (November to mid-March); southern
isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east;
mountains elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gypsum, lignite,
fluorite, arable land
Land use:
arabie land: 34%
permanent crops: 6%
permanent pastures: 2%
forests and woodland: 26%
otter 32% (1993 est.)
Irrigated land: 44,000 sq km (1993 est.)
Natural hazards: land subsidence in Bangkok area
resulting from the depletion of the water table;
droughts
Environment - current issues: air pollution from
vehicle emissions; water pollution from organic and
factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
Environment - international agreements:
party to: Climate Change, Endangered Species,
Hazardous Wastes, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Biodiversity, Climate
Change-Kyoto Protocol, Law of the Sea
Geography - note: controls only land route from
Asia to Malaysia and Singapore
Disputes - international: parts of the border with
Laos are indefinite; maritime boundary with Vietnam
resolved, August 1 997; parts of border with Cambodia
are indefinite; maritime boundary with Cambodia not
clearly defined; sporadic conflict with Burma over
alignment of border
Illicit drugs: a minor producer of opium, heroin, and
marijuana; major illicit transit point for heroin en route
to the international drug market from Burma and Laos;
eradication efforts have reduced the area of cannabis
cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been reduced
by eradication efforts; also a drug money-laundering
center; minor role in amphetamine production for
regional consumption; increasing indigenous abuse of
methamphetamines and heroin
Disputes - international: none
members— (24) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
observers— (16) Commission of the European Communities, Czech Republic, Iceland, South Korea, Mexico, Poland
Appendix C; International Organizations and Groups (continued)
International Federation of Red Cross and
Red Crescent Societies (IFRCS)
note— formerly known as League of Red Cross
and Red Crescent Societies (LORCS)
address— Chemin des Crets 17, CP 372,
Petit-Saconnex, CH-1211 Geneva 19,
associate members— (A) Comoros, Cyprus, Gabon, Tuvalu
members— (174) Afghanistan, Albania, Aigeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangiadesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Repubiic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Samoa, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (161)
Category I— {22 industrialized aid contributors) Australia, Austria, Beigium, Canada, Denmark, Finland, France,
Germany, Greece, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, UK, US
Category //—(1 2 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Category III— {^27 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia,
Azerbaijan, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Repubiic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, North Korea,'' South Korea,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Nicaragua, Niger, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Phiiippines,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Uruguay, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
Appendix C: International Organizations and Groups (continued)
International Hydrographic Organization
(IHO)
note— name changed from International
Hydrographic Bureau on 22 September 1970
address— BP 445, 4 Qua! Antoine 1st, Monaco
MC 98011,CEDEX, Monaco
telephone-133] (93) 01 81 00
F/4X-[33](93) 10 81 40
established— NA June 1919
effective— NA June 1921
aim— to train hydrographic surveyors and
nautical cartographers to achieve
standardization in nautical charts and electronic
chart displays; to provide advice on nautical
cartography and hydrography; to develop the
sciences in the field of hydrography and
techniques used for descriptive oceanography
members— (68) Algeria, Argentina, Australia, Bahrain, Belgium, Brazil, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Ecuador, Egypt, Estonia,
Fiji, Finland, France, Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran, Italy, Japan, North Korea, South
Korea, Monaco, Mozambique Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Russia, Serbia and Montenegro, Singapore, South Africa, Spain, Sri Lanka,
Suriname, Sweden, Syria, Thailand, Tonga, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay,
Venezuela
membership pending— (7) Bangladesh, Bulgaria, Jamaica, Kuwait, Mauritania, Morocco, Qatar
International Investment Bank (IIB)
established on 7 July 1970; to promote economic development; members were Bulgaria, Cuba, Czechoslovakia,
East Germany, Hungary, Mongolia, Poland, Romania, USSR, Vietnam; now it is a Russian bank with a new charter
International Labor Organization (ILO)
address— International Labor Office, 4 route des
Morillons, CH-1211 Geneva 22, Switzerland
te/eptone-{41](22)799 61 11
FAX-{At] (22) 798 86 85
established— 28 June 1919 set up as part of
Treaty of Versailles; 1 1 April 1919 became
operative; 14 December 1946 affiliated with the
UN
aim— to deal with world labor issues; a UN
specialized agency
members— (173) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia
(suspended), Zambia, Zimbabwe
International Maritime Organization (IMO)
note— name changed from Intergovernmental
Maritime Consultative Organization (IMCO) on
22 May 1982
address— 4 Albert Embankment, London SE1
7SR, UK
fe/ep/Jone-[44](171)735 7611
FyiX-[44] (171) 587 3210
established— 6 March 1948 set up as the
Inter-Governmental Maritime Consultative
Organization
effective— 17 March 1958
aim— to deal with international maritime affairs;
a UN specialized agency
members— (157) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Brunei,
Bulgaria, Burma, Cambodia, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Ukraine, UAE, UK, US, Uruguay,
Vanuatu, Venezuela, Vietnam, Yemen
associate members— (2) Hong Kong, Macau
590
Appendix C: International Organizations and Groups (continued)
International Maritime Satellite Organization see International Mobile Satellite Organization (Inmarsat)
(Inmarsat) _ _
International Mobile Satellite Organization members— (86) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Bosnia and
(Inmarsat) Herzegovina, Brazil, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Costa Rica, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Egypt, Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Hungary,
nofe-^ormerly International Maritime Satellite Iceland, India, Indonesia, Iran, Iraq, Israel, Italy, Japan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia,
Organization Malaysia, Malta, Marshall Islands, Mauritius, Mexico, Monaco, Mozambique, Netherlands, NZ, Nigeria, Norway,
address— 89 City Road, London EC1Y 1AX, UK Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal,
fe/ephone— [44] (1 71 ) 728 1 000, 728 1 1 00 Serbia and Montenegro, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Tanzania,
FAX-{44] (1 71 ) 728 1 044, 728 1 1 00 Thailand, Tunisia, Turkey, Ukraine, UAE, UK, US, Vietnam
established— 3 September 1976
e/fect;Ve— 16 July 1979
a/m— to provide worldwide communications for
commercial, distress, and safety applications, at
sea, in the air, and on land _ _
International Monetary Fund (IMF) members— (1 82) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
address— 700 19th Street NW, Washington, DC Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
20431 , US Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
fe/epborre— [1] (202) 623 7000 Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
FAX— [1] (202) 623 4661 , 623 7491 , 623 4662 Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
established— 22 July 1944 Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
effective— 27 December 1945 Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
a/m— to promote world monetary stability and Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
economic development; a UN specialized Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
agency Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Ni','dc11f0c6212cfd92347739e599104e93b4ce28fb300da35bb68a8ad25b17920a','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('819b9e1e9349b489aba3d54bf7f23500168f817eeacd4bfacff3675af07dc5ae',2000,'ZW','Zimbabwe','transnational-issues',453,'caragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
International Olympic Committee (IOC) Natmal Olympic Committees— {\\99 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria,
American Samoa, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
address— Chateau deVidy,CH-1 007 Lausanne, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan,
Switzerland Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma,
teiephone—{4t] (21) 621 61 1 1 Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
FAX— [41] (21) 621 62 16, 621 63 54 China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
esfaW/s/red- 23 June 1894 Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
a/m-to promote the Olympic ideals and Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
administer the Olympic games: 2000 Summer Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Olympics in Sydney, Australia; 2002 Winter Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Olympics in Salt Lake City, United States; 2004 Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Summer Olympics in Athens, Greece Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Virgin Islands, Yemen, Yugoslavia (Serbia and Montenegro), Zambia, Zimbabwe, Palestine Liberation Organization
59-
Appendix C; International Organizations and Groups (continued)
International Organization for Migration
(lOM)
note— established as Provisional
Intergovernmental Committee for the Movement
of Migrants from Europe; renamed
Intergovernmental Committee for European
Migration (ICEM) on 15 November 1952;
renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current
name adopted 14 November 1989
address— 17 route des Morillons, CP 71 ,
CH-1211 Geneva 19, Switzerland
fe/eptor7e-[41](22)717 91 11
FAX-{A^] (22) 798 61 50
established— 5 December 1951
a/m— to facilitate orderly international emigration
and immigration
International Organization for
Standardization (ISO)
address— CP 56, 1 Rue de Varembe, CH-121 1
Geneva 20, Switzerland
fe/eptor7e-[41] (22) 749 01 11
FAX-{4t] (22) 733 34 30
established— HA February 1947
a/m— to promote the development of
international standards with a view to facilitating
international exchange of goods and services
and to developing cooperation in the sphere of
intellectual, scientific, technological and
economic activity
International Red Cross and Red Crescent
Movement (ICRM)
address— International Conference of the Red
Cross, 19 Avenue de la Paix, CH-1202 Geneva,
606
Appendix C; International Organizations and Groups (continued)
United Nations Mission for the Referendum
in Western Sahara (MINURSO)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
fe/ephone— [1] (212) 963 1234
FAY-[1] (212) 963 4879
established— 29 Aprii 1991
a/m— to supervise the cease-fire and conduct a
referendum in Western Sahara; estabiished by
the UN Security Councii
members— {29) Argentina, Austria, Bangladesh, Canada, China, Egypt, El Salvador, France, Ghana, Greece,
Guinea, Honduras, India, Ireland, Italy, Kenya, South Korea, Malaysia, Nigeria, Norway, Pakistan, Poland,. Portugal,
Russia, Sweden, Togo, US, Uruguay, Venezuela
United Nations Mission in Bosnia and
Herzegovina (UNMIBH)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{\\] (212) 963 1234
FAY-{1](212) 758 2718
established— 21 December 1995
aim— to estabiish an internationai Poiice Task
Force (IPTF) to impiement the Dayton Peace
Agreement in Bosnia and Herzegovina
members— (44) Argentina, Austria, Bangladesh, Bulgaria, Canada, Chile, Denmark, Egypt, Estonia, Fiji, Finland,
France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Ireland, Italy, Jordan, Kenya, Lithuania,
Malaysia, Nepal, Netherlands, Nigeria, Norway, Pakistan, Poland, Portugal, Romania, Russia, Senegal, Spain,
Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, US
United Nations Mission in Haiti (UNMIH)
established 23 September 1993; aim was to assist in implementing the agreement to transfer power back into the
civilian government; established by the UN Security Council; became the United Nations Support Mission in Haiti
(UNSMIH) 28 June 1996 with the aim to assist in the professionalization of the Haitian National Police; members
were Algeria, Canada, France, India, Mali, Pakistan, Togo, US; disbanded 31 July 1997
United Nations Mission in the Centrai African
Republic (MINURCA)
established NA April 1 998 to provide security in the capital as the government undertakes the necessary reforms to
provide its own security; to provide training to civilian police; members were Benin, Burkina Faso, Cameroon
Canada, Chad, Cote d''Ivoire, Egypt, France, Gabon, Mali, Portugal, Senegal, Togo, Tunisia; was disbanded 15
February 2000
United Nations Mission in Sierra Leone
(UNAMSIL)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{1] (212) 963-1234
FAX■^1](212) 758-2718
established— 22 October 1999
aim— to cooperate with the Government of
Sierra Leone and the other parties to the Peace
Agreement in the impiementation of the
agreement; to monitor the miiitary and security
situation in Sierra Leone; to monitor the
disarmament and demobiiization of combatants
and members of the Civii Defense Forces (CFD);
to assist in monitoring respect for international
humanitarian law
members— {30} Bangladesh, Bolivia, Canada, Croatia, Czech Republic, Denmark, Egypt, France, The Gambia,
Ghana, India, Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Namibia, Nepal, NZ, Nigeria, Norway, Pakistan,
Russia, Slovakia, Sweden, Thailand, Tanzania, UK, Uruguay, Zambia
607
Appendix C: International Organizations and Groups (continued)
United Nations Mission of Observers in
Prevlaka (UNMOP)
address— clo Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
tetephone-{:] (212) 963 1234
FAY-[1] (212) 758 2718
established— ] February 1996
a/m— to monitor the demiiitarization of the
Previaka peninsuia
members— (24) Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Finland, Ghana,
Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Sweden,
Switzerland, Ukraine
United Nations Mission of Observers in
Tajikistan (UNMOT)
members— (13) Austria, Bangladesh, Bulgaria, Czech Republic, Denmark, Ghana, Indonesia, Jordan, Nepal,
Nigeria, Poland, Ukraine, Uruguay
address— clo Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-[\\] (212) 963 1234
F/1X-[1](212)758 2718
established— 1 6 December 1994
a/m— to monitor and investigate vioiations of the
cease-fire of 17 September 1994 between
Tajikistan and the Tajik opposition and to assist
in the poiiticai negotiation process; estabiished
by the UN Security Councii
United Nations Monitoring and Verification
Commission (UNMOVIC)
members— (22) Australia, Austria, Belgium, Canada, China, Czech Republic, Finland, France, Germany, Indonesia,
Italy, Japan, Netherlands, Nigeria, Norway, Poland, Russia, Sri Lanka, Sweden, UK, US, Venezuela
rjofe— formeriy known as United Nations Speciai
Commission for the Eiimination of iraq''s
Weapons of Mass Destruction (UNSCOM)
address— clo United Nations, Room S-3120t-i,
New York, NY 10017, US
telephone-{t] (212) 963 3018
FAX-{t] (212) 963 3922
established— HA December 1999
a/m— to identify, account for, and eiiminate iraq''s
weapons of mass destruction and the capacity
to produce them
United Nations Observer Mission in Angola
(MONUA)
established 1 July 1997 to assist in implementation of peace agreement; oversee normalization of state
administration throughout National territory; established by UN Security Council; members were Bangladesh,
Bolivia, Brazil, Egypt, India, Jordan, Pakistan, Poland, Portugal, Romania, Russia, Senegal, Uruguay, Zambia,
Zimbabwe; terminated 26 February 1999
United Nations Observer Mission in El
Salvador (ONUSAL)
established 20 May 1 991 to verify cease-fire arrangements and to monitor the maintenance of public order pending
the organization of a new National Civil Police; established by the UN Security Council; members were Argentina,
Austria, Brazil, Canada, Chile, Colombia, France, Guyana, Ireland, Italy, Mexico, Spain, Sweden, Venezuela;
disbanded April 1995
608
Appendix C: International Organizations and Groups (continued)
United Nations Observer Mission in Georgia members— (22) Albania, Austria, Bangladesh, Czech Republic, Denmark, Egypt, France, Germany, Greece,
(UNOMIG) Hungary, Indonesia, Jordan, South Korea, Pakistan, Poland, Russia, Sweden, Switzerland, Turkey, UK, US,
World Court
see International Court of Justice (ICJ)
World Customs Organization (WCO)
see Customs Cooperation Council (CCC)
World Federation of Trade Unions (WFTU)
address— Branicka 1 1 2, 1 4701 Prague 4, Czech
Republic
fe/ep/jone-[42] (2) 44 46 21 40, 44 46 20 85, 44
46 29 61
FAX-[42](2)44461378
established— 3 October 1 945
a/m— to promote the trade union movement
members— (125 and the Palestine Liberation Organization) Afghanistan, Albania, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin, Bolivia,
Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada, Chile, Colombia, Democratic Republic Of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia,
Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia,
NZ, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico,
Reunion, Romania, Russia, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Saudi
Arabia, Senegal, Sierra Leone, Slovakia, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
613
Appendix C: International Organizations and Groups (continued)
World Food Council (WFC) established 17 December 1974; to study world food problems and to recommend solutions; ECOSOC organization;
there were 36 members selected on a rotating basis from aii regions; subsumed by the Worid Food Program and
Food and Agricuiture Organization
World Food Program (WFP) members— {3Q) selected on a rotating basis from aii regions
address— Via Cesare Giuiiio Vioia, 68/70 Parco
de Medici, 1-00148 Rome, Italy
telephone-{39] (6) 522821
FAX-[39] (6) 59602348, 52282840
established— 24 November 1961
aim— to provide food aid in support of economic
deveiopment or disaster relief; an ECOSOC
organization
World Health Organization (WHO)
address— CH-1 211 Geneva 27, Switzerland
telephone-{4-\\] (22) 791 21 11, 791 32 23
FAX-{4t] (22) 791 07 46
established— 22 July 1946
effective— 7 April 1948
aim— to deal with health matters worldwide; a
UN specialized agency
World Intellectual Property Organization
(WlPO)
address— 34 Chemin des Colombettes, Case
Postale 18, CH-1 211 Geneva 20, Switzerland
fe/eptone-[41] (22) 338 9111
FAX-{4t] (22) 733 5428
established— 1 4 July 1967
effective— 26 April 1970
aim— to furnish protection for literary, artistic,
and scientific works; a UN specialized agency
members— (191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former
Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niue, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia,
associate members— (2) Puerto Rico, Tokelau
members— (tit) Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Buigaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The
Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Sierra Leone, Singapore, Slovakia,
Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tajikistan,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
614
Appendix C: International Organizations and Groups (continued)
World Meteorological Organization (WMO) members— (^ 85) Afghanistan, Albania, Algeria, Angoia, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangiadesh, Barbados, Beiarus, Beigium, Beiize, Benin, Boiivia,
address— Case Postaie 2300, 41 Avenue Bosnia and Herzegovina, Botswana, Brazil, British Caribbean Territories, Brunei, Bulgaria, Burkina Faso, Burma,
Giuseppe-Motta, CH-121 1 Geneva 2, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Switzerland Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire,
fe/eptone— [41] (22) 730 81 1 1 Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
FAX— [41] (22) 734 23 26 Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia,
established— ^ 1 October 1 947 Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary,
effective—^ April 1951 Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
a/m— to sponsor meteorological cooperation; a South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau,
UN specialized agency The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia (suspended), Zambia, Zimbabwe
World Tourism Organization (WToO) members— (131) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Austria, Bangladesh, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
address— Calle Capitan Haya 42, 28020 Madrid, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Spain Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador, Egypt,
telephone— {34-] (1) 567 81 00 El Salvador, Equatorial Guinea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
FAX— [34] (1) 571 37 33 Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy,
established— 2 January 1975 Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
a/m— to promote tourism as a means of Lesotho, Libya, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Maldives, Mali, Malta,
contributing to economic development, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
international understanding, and peace Nicaragua, Niger, Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia,
Rwanda, San Marino, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Switzerland, Syria, Tanzania, Thailand, Togo, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members— (5) Aruba, Flanders, Macau, Madeira Islands, Netherlands Antilles
observer— {t) Holy See
members— (136) Angola, Antigua and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia. Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon,
Canada, Central African Republic. Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d’Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, EU, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Ireland, Israel. Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lesotho, Liechtenstein, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Mongolia, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Venezuela, Zambia,
observers— (6) Azerbaijan, Laos, Somalia, Sudan, Tajikistan, Turkmenistan
applicants— (3''\\) Albania, Algeria, Armenia, The Bahamas, Belarus, Cambodia, Cape Verde, China, Comoros,
Croatia, Equatorial Guinea, Georgia. Kazakhstan, Kiribati, Lithuania, The Former Yugoslav Republic of Macedonia,
Moldova, Nepal, Oman, Russia, Sao Tome and Principe, Saudi Arabia, Seychelles, Tonga, Tuvalu, Ukraine,
Uzbekistan, Vanuatu, Vietnam, Yemen, Taiwan; note— some of these countries applied to GATT and are still under
consideration for membership in WTrO; the following member of GATT had not become a member of WTrO as of 1
January 1998: Yugoslavia (suspended)
World Trade Organization (WTrO)
note— succeede','990b6596d4f849a430a333db53a7c8813d4baccc6387704aa97a0a28cf7b4d1e','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c424c5b014721a44d5ad2e8ad76fc9a2ce7b413f7c52a412e269f0769d96b89a',2000,'ZW','Zimbabwe','transnational-issues',454,'d General Agreement on Tariff
and Trade (GATT)
address— Centre William Rappard, 154 Rue de
Lausanne, CH-121 1 Geneva 21, Switzerland
fe/ep/ione-[41] (22) 739 51 11
FAX-[411(22)739 54 58
esfaW/s/red— 15 April 1994
effective— ^ January 1995
a/m— to provide a means to resolve trade
conflicts between members and to carry on
negotiations with the goal of further lowering
and/or eliminating tariffs and other trade barriers
615
Appendix C: International Organizations and Groups (continued)
Zangger Committee (ZC) members— (33) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, China, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, Norway,
established— early 1970s Poland, Portugal, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Ukraine, UK, US
a/m— to establish guidelines for the export
control provisions of the Nonproliferation of
Nuclear Weapons Treaty (NPT)
Appendix D:
Selected International
Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur
Emissions or Their Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur
Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature— ^ December 1959
entered into force— 23 June 1 961
objective-to ensure that Antarctica is used for
peaceful purposes only (such as international
cooperation in scientific research); to deter the
question of territorial claims asserted by some
nations and not recognized by others; to provide
an international forum for management of the
region; applies to land and ice shelves south of
60 degrees South latitude
parties— (44) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech
Republic, Denmark, Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy, Japan, North
Korea, South Korea, Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia,
South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay, Venezuela
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
note— abbreviated as Hazardous Wastes
opened for signature— 22 March 1989
entered into force— 5 May 1992
objective-to reduce transboundary movements
of wastes subject to the Convention to a
minimum consistent with the environmentally
sound and efficient management of such
wastes; to minimize the amount and toxicity of
wastes generated and ensure their
environmentally sound management as closely
as possible to the source of generation; and to
assist LDCs in environmentally sound
management of the hazardous and other wastes
they generate
parties— (t34) Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Burundi, Canada, Cape Verde, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Ecuador, Egypt, El
Salvador, Estonia, EU, Finland, France, The Gambia, Georgia, Germany, Greece, Guatemala, Guinea, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait, Kyrgyzstan,
Latvia, Lebanon, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Seychelles, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia
countries that have signed, but not yet ratified— {3) Afghanistan, Haiti, US
Biodiversity
see Convention on Biological Diversity
617
Appendix D: Selected International Environmental Agreements (continued)
Convention on Biological Diversity
note— abbreviated as Biodiversity
opened for signature— 5 June 1 992
entered into force— 29 December 1993
objective— to deveiop nationai strategies for the
conservation and sustainabie use of bioiogicai
diversity
parties— {tJQ) Aibania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswrana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vinpent and the Grenadines, Samoa, San Marino, Sao
Tome and Principe, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UK, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, butnotyetratified-itt) Afghanistan, Azerbaijan, Kuwait, Liberia, Libya, Malta,
Thailand, Tuvalu, UAE, US, former Yugoslavia
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
Convention on Fishing and Conservation of
Living Resources of the High Seas
note— abbreviated as Marine Lite Conservation
opened for signature— 29 April 1958
entered into force— 20 March 1966
objective-to solve through international
cooperation the problems involved in the
conservation of living resources of the high seas,
considering that because of the development of
modern technology some of these resources are
in danger of being overexploited
parties— {37} Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark,
Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra Leone, Solomon Islands, South Africa, Spain,
Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US, Venezuela, former Yugoslavia
countries that have signed, but not yet ratified— {21} Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba,
Ghana, Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka, Tunisia,','cc90870f1c6289a0063f443d0e8e333f8e9b6b1d9d7b87e6eef7ae5a00dfc6e5','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b87e3ccc212252b1a832ae8eb337067dc94a8b4e4035f765e15a1325b0fe2ad',2000,'TO','Tonga','transnational-issues',462,'0 50 100 km
0 50 100 mi
. Niuafo’ou
Tafahi
Niuatoputapu''
South Pacific Ocean
Vava''u
Group
Vava’u
Neiafu
Kao Island
0 /1-Pangai
Ha’apai Group
NUKU‘ALOFA
Tongatapu
Group
Minerva Reef not shown','d91b3176f6b8f353a9c8dfff965f8e460e4c9d87b57b283ca56ff0d6571368d2','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dad3fc74616da0e3ec51602fdddc20dc13badf31b68365e4a5dfd7c5a91248ae',2000,'VU','Vanuatu','transnational-issues',478,'Disputes - international; claims all of Guyana west
of the Essequibo River; maritime boundary dispute
with Colombia in the Gulf of Venezuela
Illicit drugs: illicit producer of opium for the
international drug trade on a small scale; however,
large quantities of cocaine and heroin transit the
country from Colombia bound for US and Europe;
important money-laundering hub; active eradication
program primarily targeting opium; increasing signs of
drug-related activities by Colombian insurgents on
border
Background: France occupied all of Vietnam by
1884. Independence was declared after World War II,
but the French continued to rule until 1954 when they
were defeated by communist forces under HO Chi
Minh, who took control of the north. US economic and
military aid to South Vietnam grew through the 1960s
in an attempt to bolster the government, but US armed
forces were withdrawn following a cease-fire
agreement in 1 973. Two years later North Vietnamese
forces overran the south. Economic reconstruction of
the reunited country has proven difficult as aging
Communist Party leaders have only grudgingly
initiated reforms necessary for a free market.
f ^ Geography
Location; Southeastern Asia, bordering the Gulf of
Thailand, Gulf of Tonkin, and South China Sea,
alongside China, Laos, and Cambodia
Geographic coordinates; 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
total: 329,560 sq km
land: 325,360 sq km
wafer; 4,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 4,639 km
border counfr/es; Cambodia 1,228 km, China 1,281
km, Laos 2,130 km
Coastline; 3,444 km (excludes islands)
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the
continental margin
exclusive economic zone: 200 nm
fern''for/a/sea;12nm
Climate: tropical in south; monsoonal in north with
hot, rainy season (mid-May to mid-September) and
warm, dry season (mid-October to mid-March)
Terrain: low, flat delta in south and north; central
highlands; hilly, mountainous in far north and
northwest
Elevation extremes;
lowest point: South China Sea 0 m
highest point: Ngoc Linh 3,143 m
Natural resources: phosphates, coal, manganese,
bauxite, chromate, offshore oil and gas deposits,
forests, hydropower
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 1%
forests and woodland: 30%
other; 48% (1993 est.)
Irrigated land: 18,600 sq km (1993 est.)
Natural hazards; occasional typhoons (May to
January) with extensive flooding
Environment - current issues: logging and
slash-and-burn agricultural practices contribute to
deforestation and soil degradation; water pollution
and overfishing threaten marine life populations;
groundwater contamination limits potable water
supply; growing urban industrialization and population
migration are rapidly degrading environment in Hanoi
and Ho Chi Minh City
Environment - international agreements;
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol, Nuclear Test Ban
f; ’ "P eTpTe"
Population: 78,773,873 (July 2000 est.)
Age structure:
0-14 years: 33% (male 13,353,828; female
12,516,289)
15-64 years: 32% (male 23,691,412; female
24,951,397)
65 years and over: 5% (male 1 ,696,708; female
2,564,239) (2000 est.)
Population growth rate: 1 .49% (2000 est.)
Birth rate: 21 .62 births/1 ,000 population (2000 est.)
533
Vietnam (continued)
Death rate: 6.26 deaths/1 ,000 population
(2000 est.)
Net migration rate: -0.51 migrant(s)/1 ,000
population (2000 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: t. 07 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.97 male(s)/female (2000 est.)
infant mortality rate: 31 .13 deaths/1 ,000 live births
(2000 est.)
Life expectancy at birth:
total population: 69.27 years
male: 66.84 years
female: 71 .87 years (2000 est.)
Total fertility rate: 2.53 children born/woman
(2000 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Vietnamese 85%-90%, Chinese 3%,
Muong, Tai, Meo, Khmer, Man, Cham
Religions: Buddhist, Taoist, Roman Catholic,
indigenous beliefs, Muslim, Protestant, Cao Dai, Hoa
Hao
Languages: Vietnamese (official), Chinese, English,
French, Khmer, tribal languages (Mon-Khmer and
Malayo-Polynesian)
Literacy:
definition: age 1 5 and over can read and write
total population: 93.7%
male: 96.5%
fema/e; 91 .2% (1995 est.)','d4ca1705aeabffe41607485a08ea272764ca22e2c863f96f2dfb15b516fc3e79','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58a67cadc5a0011434e602d5366fd49d6cdfff0353b850643877ad180aee40d5',2000,'MP','Northern Mariana Islands','transnational-issues',486,'Disputes - international: claimed by Marshall
Islands
^Wallis and Futuna
(overseas territory of France)
0 25 ^ ton
0 25 50 mi
ties
Wallis
MATA-UTI^
fie Uvea
South Pacific Ocean
lies de Horne
fie Futuna
^ggave (Leava)
^/e Alofi
F I h t rod u c t i o n
Background: Although discovered by the Dutch and
the British in the 17th and 18th centuries, it was the
French who declared a protectorate over the islands in
1842. In 1959, the inhabitants of the islands voted to
become a French overseas territory.','2f31dd5edb2aca3f138d57eb951aec737f14916cd9eca6a6167c755658c813c1','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f518e7696056b772d5e681a24d289c088924da0e252809cfee7502134fc69f8',2000,'AE','United Arab Emirates','transnational-issues',494,'UDEAC
Union Douaniere et Economique de I''Afrique Centrale; see Central African
Customs and Economic Union (UDEAC)
UEMOA
Union Economique et Monetaire Ouest Africaine; see West African Economic
and Monetary Union (WAEMU)
UHF
ultra-high-frequency
UK','9d34035fd2fede78307d1be1703a27200f61b83ab31552e5112a1afb7494eeb8','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bdc5a4c8679c60675e6ed7ca393b43d48dd35e997edfaed180f45438407f146',2000,'GB','United Kingdom','transnational-issues',495,'UN
United Nations
UNAMIR
United Nations Assistance Mission for Rwanda
UNAMSIL
United Nations Mission in Sierra Leone
UNAVEM III
United Nations Angola Verification Mission III
UNCRO
United Nations Confidence Restoration Operation in Croatia
UNCTAD
United Nations Conference on Trade and Development
UNDOF
United Nations Disengagement Observer Force
UNDP
United Nations Development Program
UNEP
United Nations Environment Program
UNESCO
United Nations Educational, Scientific, and Cultural Organization
UNFICYP
United Nations Peace-keeping Force in Cyprus
UNFPA
United Nations Fund for Population Activities; see UN Population Fund (UNFPA)
UNHCR
United Nations High Commissioner for Refugees
UNICEF
United Nations Children''s Fund
UNIDO
United Nations Industrial Development Organization
UNIFIL
United Nations Interim Force in Lebanon
UNIKOM
United Nations Iraq-Kuwait Observation Mission
561
Appendix A: Abbreviations (continued)
UNITAR
United Nations Institute for Training and Research
UNMIH
United Nations Mission in Haiti
UNMIBH
United Nations Mission in Bosnia and Herzegovina
UNMIK
United Nations Interim Administration Mission in Kosovo
UNMOGIP
United Nations Military Observer Group in India and Pakistan
UNMOP
United Nations Mission of Observers in Prevlaka
UNMOT
United Nations Mission of Observers in Tajikistan
UNMOVIC
United Nations Monitoring and Verification Commission
UNOMIG
United Nations Observer Mission in Georgia
UNOMIL
United Nations Observer Mission in Liberia
UNOMOZ
United Nations Operation in Mozambique
UNOMSIL
United Nations Mission of Observers in Sierra Leone
UNOMUR
United Nations Observer Mission Uganda-Rwanda
UNOSOM II
United Nations Operation in Somalia II
UNPREDEP
United Nations Preventive Deployment Force
UNPROFOR
United Nations Protection Force
UNRISD
United Nations Research Institute for Social Development
UNRWA
United Nations Relief and Works Agency for Palestine Refugees in the Near East
UNSCOM
United Nations Special Commission for the Elimination of Iraq''s Weapons of
Mass Destruction; see United Nations Monitoring and Verification Commission
(UNMOVIC)
UNSMIH
United Nations Support Mission in Haiti
UNTAC
United Nations Transitional Authority in Cambodia
UNTAES
United Nations Transitional Administration in Eastern Slavonia, Baranja, and
Western Sirmium
UNTAET
United Nations Transitional Administration in East Timor
UNTSO
United Nations Truce Supervision Organization
UNU
United Nations University
UPU
Universal Postal Union
US','3c74a3a13ddd5efc4a8d0d5bc639f445603000378e3423c6b14f7a56f985addf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3104e3a033522849afc864228099d64ea50ebb69ec55144c589fc385f3e05d34',2000,'US','United States','transnational-issues',496,'USSR
Union of Soviet Socialist Republics (Soviet Union); used for information dated
before 25 December 1991
USSR/EE
Union of Soviet Socialist Republics/Eastern Europe
V
VHF
very-high-frequency
VSAT
very small aperture terminal
W
WADB
West African Development Bank
WAEMU
West African Economic and Monetary Union
WCL
World Confederation of Labor
WCO
World Customs Organization; see Customs Cooperation Council
Wetlands
Convention on Wetlands of International Importance Especially As Waterfowl
Habitat
WEU
Western European Union
WFC
World Food Council
WFP
World Food Program
562
Appendix A: Abbreviations (continued)
WFTU
World Federation of Trade Unions
Whaling
International Convention for the Regulation of Whaling
WHO
World Health Organization
WlPO
World Intellectual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact
WTO
see WToO for Worid Tourism Organization or WTrO for World Trade
Organization
WToO
World Tourism Organization
WTrO
World Trade Organization
Y
YAR
Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used for information
dated before 22 May 1990 or CY91
Z
ZC
Zangger Committee
Appendix B:
United Nations System
MINURSO
MIPONUH
MONUC
UNAMSIL
UNDOF
UNFICYP
UNIFIL
UNIKOM
UNMIBH
UNMIK
UNMOGIP
UNMOP
UNMOT
UNOMIG
UNTAET
UNTSO
Military Staff Committee
IAEA
FAO
IBRD
IDA
IFC
ICAO
IFAD
ILO
IMF
IMO
ITU
UNESCO
UNIDO
UPU
WHO
WlPO
WMO
WTrO
Based on chart from the UN Chronicle
564
I
Appendix C:
International Organizations
and Groups
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid industrial development; see newly
industrializing economies (NIEs)
advanced economies
a new term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced
economies, countries in transition, and developing countries; recently published IMF statistics include the following
28 advanced economies: Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hong
Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal,
Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; nofe— this group would presumably also cover the
following seven smaller countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein, Monaco, and San
Marino which are included in the more comprehensive group of "developed countries”
African, Caribbean, and Pacific Group of
States (ACP Group)
address— Avenue Georges Henri 451, B-1200
Brussels, Belgium
telephone-{32] (2) 743 06 00
FAX-{32] (2) 735 55 73
established— 6 June 1975
a/m— to manage their preferential economic and
aid relationship with the EU
members— {7t) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia,
Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati,
Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Papua
New Guinea, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa Sudan, Suriname, Swaziland,
Tanzania, Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
African Development Bank (AfDB)
note— also known as Banque Africaine de
Developpement (BAD)
address— 01 BP 1387, Abidjan 01 , Cote d''Ivoire
telephone— [225] 20 44 44
FAX-{22Sl 21 77 53
established—^ August 1 963
a/m— to promote economic and social
development
regional members— {53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central
African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho,
Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria,
Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland,
Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members— (25) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France,
Germany, India, Italy, Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden,
Switzerland, UAE, UK, US
Agence de Cooperation Cultureiie et
Technique (ACCT)
see Agency for the French-speaking Community (ACCT)
Agence de ia francophonie (ACCT)
see Agency for the French-speaking Community (ACCT)
Agency for Culturai and Technicai
Cooperation (ACCT)
see Agency for the French-speaking Community (ACCT); acronym from Agence de Cooperation Cultureiie et
Technique
Note: The Socialist Federal Republic of Yugoslavia (SFRY) ceases to exist. None of the successor states of the former Yugoslavia, including Serbia and Montenegro,
have been permitted to participate solely on the basis of the membership of the former Yugoslavia in the United Nations General Assembly and Economic and Social
Council and their subsidiary bodies and in various United Nations specialized agencies. The United Nations, however, permits the seat and nameplate of the SFRY to
remain, permits the SFRY mission to continue to function, and continues to fly the flag of the former Yugoslavia. For a variety of reasons, a number of other organizations
have not yet taken action with regard to the membership of the former Yugoslavia. The Woild Factbook therefore continues to list Yugoslavia under international
organizations where the SFRY seat remains or where no action has yet been taken.
565
Appendix C: International Organizations and Groups (continued)
Agency for the French-Speaking Community
(ACCT)
note— formerly Agency for Cultural and
Technical Cooperation
address— Qua! Andre-Citroen, F-75015
Paris, France
telephone-{33] (1 ) 44 37 33 00
FAX-{33] (1) 45 79 14 98
established— 20 March 1970
name changed— 1996
aim— to promote cultural and technical
cooperation among French-speaking countries
members— (41) Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire,
Djibouti, Dominica, Equatorial Guinea, France, Gabon, Guinea, Haiti, Laos, Lebanon, Luxembourg, Madagascar,
Mali, Mauritius, Moldova, Monaco, Niger, Romania, Rwanda, Sao Tome and Principe, Senegal, Seychelles,
Switzerland, Togo, Tunisia, Vanuatu, Vietnam
associate members— (5) Egypt, Guinea-Bissau, Mauritania, Morocco, Saint Lucia
participating governments— {2) New Brunswick (Canada), Quebec (Canada)
Agency for the Prohibition of Nuciear
Weapons in Latin America and the Caribbean
(OPANAL)
note— acronym from Organismo para la
Proscripcion de las Armas Nucleares en la
America Latina y el Caribe (OPANAL)
at/t/ress— Temistocles 78, Col Polanco, CP
011560, Mexico City 5 DF, Mexico
telephone-{52] (5) 280 4923, 280 5064, 280
2715
FAX-[52](5) 2802965
established— 1 4 February 1 967 under the Treaty
of TIatelolco
effective— 25 April 1969 on the 11th ratification
of the treaty
a/m— to encourage the peaceful uses of atomic
energy and prohibit nuclear weapons
members— (32) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia,
Costa Rica, Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras,
Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Suriname, Trinidad and Tobago, Uruguay, Venezuela
Andean Community of Nations (CAN)
note— formerly known as the Andean Group
(AG), the Andean Parliament, and most recently
as the Andean Common Market (Ancom)
address— c/o General Secretariat of the Andean
Community, Paseo de la Republica 3895, Casilla
18-1177, Lima 18, Peru
fe/ep/7one-[51] (1) 221 2222
FAX-{51] (1) 221 3329
established— 26 May 1969; present name
established 1 October 1992
effective— 1 6 October 1 969
aim— to promote harmonious development
through economic integration
members— (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
associate member— (1) Panama
Andean Group (AG)
see Andean Community of Nations (CAN)
566
Appendix C; International Organizations and Groups (continued)
I
Arab Bank for Economic Development in
Africa (ABEDA)
nofe— also known as Banque Arabe de
Developpement Economique en Afrique
(BADEA)
address— Abdel Rahman El Mahdi Avenue, P. 0.
Box 2640, Khartoum, Sudan
telephone-{249] (11) 770498, 773646, 773709
FAX-[249](1 1)770600
established— February 1974
effecf/Ve— 1 6 September 1 974
a/m— to promote economic development
Arab Cooperation Council (ACC) members— (A) Egypt, Iraq, Jordan, Yemen
established— IB February 1989
aim— to promote economic cooperation and
integration, possibly leading to an Arab Common
Market
Arab Fund for Economic and Social members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt (suspended
Development (AFESD) from 1979 to 1988), Iraq (suspended 1993), Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar,
Saudi Arabia, Somaiia (suspended 1993), Sudan (suspended 1993), Syria, Tunisia, DAE, Yemen, Palestine
address— P. 0. Box 21923, Safat 1 3080, Kuwait Liberation Organization
telephone-{965] 4844500
FAX-[965] 4815750, 4815760, 4815770
established— 1 6 May 1 968
aim— to promote economic and sociai
development
Arab League (AL)
note— also known as League of Arab States
(LAS)
address— Midan Attahrir, Tahrir Square, P. 0.
Box 11 642, Cairo, Egypt
fe/ep/7one-(20](2)750 511
FAY-[20] (2) 740 331
established— 22 March 1945
aim— to promote economic, social, political, and
military cooperation
Arab Maghreb Union (AMU) members— (5) Algeria, Libya, Mauritania, Morocco, Tunisia
address— 27 Avenue Okba Agdal, Rabat,','d9dbdcad6c9489b306c3a8598a034c0cfb7df0aa404ab1872705d98c769ad365','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04a21f6081129fa60535d970fcb40918ea808f94e6acfa353a14503a1724466f',2000,'MA','Morocco','transnational-issues',497,'telephone-{2t2] (7) 77 26 82, 77 26 76, 77 26
68
FAX-{212] (7) 77 26 93
established— M February 1989
aim— to promote cooperation and integration
among the Arab states of northern Africa
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
members— (17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation
Organization; nofe— these are all the members of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
567
Appendix C; International Organizations and Groups (continued)
Arab Monetary Fund (AMF)
address— P. 0. Box 2818, Abu Dhabi, United
Arab Emirates
fe/ep/7one-[971] (2) 215000, 328500
FAX-{97^] (2) 326454
established— 27 Aprii 1976
effective— 2 February 1977
aim— to promote Arab cooperation,
development, and integration in monetary and
economic affairs
members— (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen,
Palestine Liberation Organization
Asia-Pacific Economic Cooperation (APEC)
address— APEC Secretariat, 438 Alexandra
Road, 14-00 Alexandra Point, 14th Floor 01/04,
Singapore 119958, Singapore
telephone-{65] 276 1880
FAX-[65] 276 1775
established— 7 November 1989
aim— to promote trade and investment in the
Pacific basin
members— (21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia,
Mexico, NZ, Papua New Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers— (8) Association of Southeast Asian Nations, Pacific Economic Cooperation Conference, South Pacific I
Forum I
Asian Development Bank (AsDB)
address— 6 ADB Avenue, Mandaluyong, 0401
METRO Manila, Philippines
fe/ep/?one-[63] (2) 711 3851
FA)<''-{63] (2) 741 7961,631 6816
established— 19 December 1966
aim— to promote regional economic cooperation
reg/ona/members— (41) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, China, Cook Islands, Fiji, I
Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia, Maldives, 1
Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Papua New Guinea, 1
Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan, Thailand, Tonga, Tuvalu, 1
Uzbekistan, Vanuatu, Vietnam 1
nonregiorial members— (16) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Italy, Netherlands, 1
Norway, Spain, Sweden, Switzerland, Turkey, UK, US 1
Asociacion Latinoamericana de Integracion
(ALADI)
see Latin American Integration Association (LAIA) 1
Association of Southeast Asian Nations
(ASEAN)
note— the ASEAN Regional Forum (ARF)
consists of the 9 ASEAN members, 2 observers,
2 consultative partners, and 8 dialogue partners:
Australia, Canada, EU, India, Japan, South
Korea, New Zealand, US
address— 70 A Jalan Sisingamangaraja, Jakarta
12110, Indonesia
teiephone-{62] (21) 7262991 , 7243372
FAX-{62] (21) 7398234, 7243504
established— 8 August 1967
aim— to encourage regional economic, social,
and cultural cooperation among the
non-Communist countries of Southeast Asia
members— (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam 1
observer— (1 ) Papua New Guinea 1
consultative partners— (2) China, Russia 1
Australia Group
established— 1984
a/m— to consult on and coordinate export
controls related to chemical and biological
weapons
members— (28) Argentina, Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, H
Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, 1
Slovakia, Spain, Sweden, Switzerland, UK, US; rrofe— may now include only 23 countries I
observer— (1) Singapore ■
568 I
Appendix C: International Organizations and Groups (continued)
Australia-New Zealand-United States members— (3) Australia, NZ, US
Security Treaty (ANZUS)
address— clo Department of Foreign Affairs and
Trade, Bag 8, Queen Victoria Terrace, Canberra
ACT 2600, Australia
fe/ep/)or7e-[61] (6) 261 91 11
FAX-{6^] (6) 261 21 51
established— ^ September 1951
effecf/Ve— -29 April 1952
aim— to implement a trilateral mutual security
agreement, although the US suspended security
obligations to NZ on 1 1 August 1986; Australia
and the US continue to hold annual meetings
Banco Centroamericano de Integracion see Central American Bank for Economic Integration (BCIE)
Economico (BCIE)
Banco Interamericano de Desarrollo (BID) see Inter-American Development Bank (lADB)
Bank for International Settlements (BIS) members— (45) Australia, Austria, Belgium, Brazil, Bulgaria, Canada, China, Croatia, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Greece, Hong Kong, Hungary, Iceland, India, Ireland, Italy, Japan, South Korea,
address— Centralbahnplatz 2, CH-4002 Basel, Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Mexico, Netherlands, Norway, Poland, Portugal,
Switzerland Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey,
telephone— {At ] (61 ) 280 80 80 UK, US, Yugoslavia (suspended)
FAX-[41] (61) 280 91 00, 280 81 00
esfaW/shed— 20 January 1930
effective— 1 7 March 1 930
aim— to promote cooperation among central
banks in international financial settlements
Banque Africaine de Developpement (BAD) see African Development Bank (AfDB)
Banque Arabe de Developpement see Arab Bank for Economic Development in Africa (ABEDA)
Economique en Afrique (BADEA)
Banque de Developpement des Etats de see Central African States Development Bank (BDEAC)
I''Afrique Centrale (BDEAC)
Banque Ouest-Africaine de Developpement see West African Development Bank (WADB)
(BOAD) _
Benelux Economic Union (Benelux) members— (2) Belgium, Luxembourg, Netherlands
note— acronym from Belgium, Netherlands, and','476a15ad6337497dc32a0a5f6f6bdce0a05b11e0188baef6649f945d3c01631f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b020fb18f053fb884dcda1173848c9aff70e9b8c2eac385190c43382a28d4ef8',2000,'LU','Luxembourg','transnational-issues',498,'address— Rue de la Regence 39, B-1000
Brussels, Belgium
fe/eptor7e-[32](2)519 3811
FAX-{32] (2) 513 42 06
established— 3 February 1958
effective— t November 1960
aim— to develop closer economic cooperation
and integration
Big Seven members— (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
TOfe— membership is the same as the Group
)f 7
5Sfabfe/)ed— NA1975 ''
3/m— to discuss and coordinate major economic
)olicies
Appendix C: International Organizations and Groups (continued)
Big Six members— {6) Canada, France, Germany, Italy, Japan, UK
note— not to be confused with the Group of 6
established— HA 1967
a/m— to foster economic cooperation
Black Sea Economic Cooperation Zone members— (t 1 ) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Turkey,
(BSEC) Ukraine
observers— (7) Austria, Egypt, Israel, Italy, Poland, Slovakia, Tunisia
address— Istinye Cad Musir Fuad Pasa Yalisi
Eski Tersame, Istinye 80860, Istanbul, Turkey
telephone-{%] (212) 229 6330
FAX-[90] (212) 229 6336
established— 25 June 1992
a/m— to enhance regional stability through
economic cooperation
Caribbean Community and Common Market members— (14) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Jamaica,
(Caricom) Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members— (3) Anguilla, British Virgin Islands, Turks and Caicos Islands
address— Caricom, P. 0. Box 10827, Bank of observers— (10) Aruba, Bermuda, Cayman Islands, Colombia, Dominican Republic, Haiti, Mexico, Netherlands
Guyana Building, 3rd floor. Avenue of the Antilles, Puerto Rico, Venezuela
Republic, Georgetown, Guyana
fe/epbone— [592] (2) 69281 through 69289
FAX-[592] (2) 66091, 67816, 57341
established— 4 July 1973
effective— 1 August 1973
a/m— to promote economic integration and
development, especially among the less
developed countries
Caribbean Development Bank (CDB) regional members— (20) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands,
Cayman Islands, Colombia, Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint
address— P. 0. Box 408, Wildey, St. Michael, Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
Barbados nonregional members— (5) Canada, China, France, Germany, Italy, UK
fe/epbone— [1 1(246)431 1600
FAX-[1] (246) 426 7269
established— October 1969
effective— 26 January 1970
a/m— to promote economic development and
cooperation
Cartagena Group see G roup of 1 1
Central African Customs and Economic members— (6) Cameroon, Central African Republic, Chad, Republic of the. Congo, Equatorial Guinea, Gabon
Union (UDEAC)
note— acronym from Union Douaniere et
Economique de I''Afrique Centrale
address— BP 969, Bangui, Central African
Republic
fe/epbone-{236] 61 09 22, 61 45 77
FAX-[236] 61 21 35
established— 6 December 1964
effective— ^ January 1966
a/m— to promote the establishment of a Central
African Common Market
Appendix C; International Organizations and Groups (continued)
Central African States Development Bank members— {9) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, France,
(BDEAC) Gabon, Germany, Kuwait
rtofe— acronym from Banque de Developpement
des Etats de I''Afrique Centrals
address— BDEAC, Place du Gouvernement, BP
1177, Brazzaville, Republic of the Congo
fe/ep/ione-[242] 81 18 85
FAX-[242]81 18 80
established— 3 December 1975
a/m— to provide loans for economic
development
Central American Bank for Economic members— {5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
Integration (BCIE) nonregional members— (4) Argentina, Colombia, Mexico, Taiwan
nofe— acronym from Banco Centroamericano
de Integracion Economico
address— Apartado Postal 772, Tegucigalpa
DC, Honduras
telephone-{504] 228 2243
FAX-{504] 228 2185
established— December 1960 signature of
Articles of Agreement; 31 May 1961 began
operations
a/m— to promote economic integration and
development
Central American Common Market (CACM) members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua; nofe— Panama, although not a member,
pursues full regional cooperation
address— c/o SIECA, Apartado Postal 1237, 4a
Avenida 10-25, Zona 14, Guatemala 01901,','bd5a607fbb79c77fd6a6c9bdf4ef19805bfcb7899d75b72dff75a855002de40b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2d8c6b25e97d45fd67ba2c5fadfc32ffce41a26d4cccfe168d219dfd34dde90',2000,'GT','Guatemala','transnational-issues',499,'fe/epbone-[502] (2) 682151, 682152, 682153,
682154
FAX-{502] (2) 681071
established— 1 3 December 1 960, collapsed in
1969, reinstated in 1991
a/m— to promote establishment of a Central
American Common Market
Central European Initiative (CEI) members— (16) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary,
Italy, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Slovakia, Slovenia, Ukraine
nofe— evolved from the Quadrilateral Initiative
and the Hexagonal Group
address— European Bank for Reconstruction
and Development, One Exchange Square,
London EC2A2EH, UK
fe/epbone-[44] (171) 338 6152
FAX-{44] (171) 338 7472
established— 1 1 November 1 989 as the
Quadrilateral Initiative, 27 July 1 991 became the
Hexagonal Initiative, NA 1992 present name
adopted
a/m— to form an economic and political
cooperation group for the region between the
Adriatic and the Baltic Seas
5:
Appendix C: International Organizations and Groups (continued)
centrally planned economies
a term applied mainly to the traditionally communist states that looked to the former USSR for leadership; most are
now evolving toward more democratic and market-oriented systems; also known formerly as the Second World or
as the communist countries; through the 1980s, this group included Albania, Bulgaria, Cambodia, China, Cuba,
Czechoslovakia, GDR, Hungary, North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia
Colombo Plan (CP)
members— (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, Fiji, India, Indonesia, Iran, Japan,
South Korea, Laos, Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Singapore, Sri Lanka,
address— Colombo Plan Bureau, P. 0. Box 596,
12 Melbourne Avenue, Colombo 4, Sri Lanka
fe/ep/?one-[94] (1) 581813, 581853, 581754
FAX-[94] (1) 581754
esfaW/s/red— NA May 1950 proposal was
adopted; 1 July 1951 commenced full operations
a/m— to promote economic and social
development in Asia and the Pacific
Thailand, US
Commission for Sociai Deveiopment
rtofe— formerly Social Commission
address— General Assembly and ECOSOC
Affairs Division, Department of General
Assembly Affairs and Conference Services,
United Nations, Room S-2950, New York, NY
10017, US
telephone-{t] (212) 963 1234
FAX-m (212) 963 5935
established— 2^ June 1946 as the Social
Commission, renamed 29 July 1966
a/m— to deal, as part of the Economic and Social
Council, with social development programs of
UN
members— (46) selected on a rotating basis from all regions
Commission on Crime Prevention and
Criminal Justice
address— Center for International Crime
Prevention, Vienna International Center, P. 0.
Box 500, A-1400 Vienna, Austria
telephone— [43] (1) 21345, extension 4272
FAX-{43] (1) 21345 5898, 21345 5841
established— 6 February 1992
a/m— to provide guidance, as part of the
Economic and Social Council, on crime
prevention and criminal justice
members— (40) selected on a rotating basis from all regions
Commission on Human Rights
address— c/o Secretariat, United Nations Office
of the High Commissioner of Human Rights,
United Nations Office at Geneva, CH-121 1
Geneva 10, Switzerland
telephone-{4-\\] (22) 917 90 00, 907 92 60
FAX-{41](22) 917 90 11
established— tS February 1946
a/m— to assist, as part of the Economic and
Social Council, with human rights programs of
UN
members— (53) selected on a rotating basis from all regions
572
Appendix C: International Organizations and Groups (continued)
Commission on Narcotic Drugs members— (53) selected on a rotating basis from all regions with emphasis on producing and processing countries
address— clo United Nations Drug Control
Programme, Treaty Implementation and Legai
Affairs Branch, R 0. Box 500, A-1400 Vienna,','dbd955c25c37e5d2d4c16fe8a98623ef91f04ce456397862a2adac611dd33e03','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6241987e9d6d350c7902e89eda0a47f8a7e8f24dfe8813a27c8bc5374145841b',2000,'AT','Austria','transnational-issues',500,'telephone— {A3] (1) 213450
FAX-{A3] (1) 21345-5885
established— February 1946
a/m— Economic and Social Council organization
dealing with illicit drugs programs of UN
Commission on Popuiation and members— (47) selected on a rotating basis from ail regions
Development
address— Division for Policy and Coordination
and ECOSOC Affairs, Department for Policy
Coordination and Sustainabie Development,
United Nations, Room 2963, New York, NY
10017, US
telephone-[\\] (212) 963 1234
FAY-[1](212) 9635935
esfaW/s/red— 10 August 1948
aim— to deal with population matters of
importance to the UN, as part of Economic and
Social Council
Commission on Science and Technology for members— (33) selected on a rotating basis from ail regions
Development
address— General Assembly and ECOSOC
Affairs Division, Department of General
Assembly Affairs and Conference Services,
United Nations, New York, NY 10017, US
telephone-{t] (212) 963 1234
FAX-[1] (212) 963 5935
established— 20 July 1992
aim— to promote international cooperation, as
part of the Economic and Social Council, in the
field of science and technology
Commission on Sustainable Development members— (53) selected on a rotating basis from all regions
address— Division for Sustainable
Development, United Nations Department for
Policy Coordination and Sustainable
Development, Room DC2-2274, New York, NY
10017, US
fe/ep/Jone-[1] (212) 963 0902
FAY-[1] (212) 963 4260
esfaW/s/red— 12 February 1993
a/m— to monitor, as part of the Economic and
Social Council, implementation of agreements
reached at the UN Conference on Environment
and Development
Appendix C; International Organizations and Groups (continued)
Commission on the Status of Women
members— (45) selected on a rotating basis from all regions
address— Division for the Advancement of
Women, Department for Economic and Sociai
Affairs, United Nations, Room DC2-1200, New
York, NY 10017, US
telephone-{^] (212) 963 3177
FAX-{^] (212) 963 3463
established— 2^ June 1946
a/m— to deal, as part of the Economic and Social
Council, with women''s rights goals of UN
Commonwealth (C)
note— also known as Commonwealth of Nations
address— c/o Commonwealth Secretariat,
Marlborough House, Pall Mall, London SW1Y
5HX, UK
telephone-{44] (171) 839 341 1 , 747 6535
FAX-144] (171) 930 0827, 839 9081
established-Ht December 1931
a/m— to foster multinational cooperation and
assistance, as a voluntary association that
evolved from the British Empire
members— (53) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei,
Cameroon, Canada, Cyprus, Dominica, Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan
(suspended), Papua New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga,
Trinidad and Tobago, Uganda, UK, Vanuatu, Zambia, Zimbabwe
special members— (1) Tuvalu
Commonwealth of Independent States (CIS)
address— Kirov Street 17, 220000 Minsk,
fe/eptone-[43](1)514 36-190
FAX-[43] (1)514 36-96
esfaW/shed— 1 January 1995
a/m— to foster the implementation of human
rights, fundamental freedoms, democracy, and
the rule of law; to act as an instrument of early
warning, conflict prevention and crisis
management; and to serve as a framework for
conventional arms control and confidence
building measures
Organization for the Prohibition of Chemical
Weapons (OPCW)
address— Johan de Wittlaan 32, NL-2517 JR
The Hague, Netherlands
telephone-{3:] (70) 416 33 00
FAX-[31]{70) 360 09 44
established— 29 April 1997
a/m— to enforce the Convention on the
Prohibition of the Development, Production,
Stockpiling and Use of Chemical Weapons and
on Their Destruction; to provide a forum for
consultation and cooperation among the
signatories of the Convention
Organization of African Unity (OAU)
address— P. 0. Box 3243, Addis Ababa, Ethiopia
telephone-{251] (1) 517700
FAX-[251] (1)512622, 517844
established— 25 May 1963
a/m— to promote unity and cooperation among
African states
Organization of American States (OAS)
address— corner of 17th Street and Constitution
Avenue NW, Washington, DC 20006, US
telephone-[1] (202) 458 3000
FAX-[1] (202) 458 3967
esfaW/s/?ed— 14 Aprii 1890 as the International
Union of American Republics; 30 April 1948
adopted present charter
effective— 13 December 1951
a/m— to promote regional peace and security as
weli as economic and social development
members— (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Hoiy See, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan, Yugoslavia (suspended)
partners for cooperation— (8) Algeria, Egypt, israel, Japan, Jordan, South Korea, Morocco, Tunisia
members— (169) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Repubiic,
Chad, Chiie, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Ei Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg,
Madagascar, Maiawi, Malaysia, Maldives, Maii, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poiand,
Portugai, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
Siovakia, Siovenia, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Tajikistan,
Tanzania, Thaiiand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (54) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Repubiic, Chad. Comoros, Democratic Repubiic of the Congo, Republic of the Congo, Cote d''ivoire, Djibouti, Egypt,
Equatoriai Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco (temporarily suspended), Mozambique, Namibia,
Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and Principe, Senegal, Seychelles, Sierra
Leone, Somaiia, South Africa. Sudan, Swaziiand, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
members— (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Boiivia, Brazii, Canada, Chiie,
Coiombia, Costa Rica, Cuba (excluded from formal participation since 1962), Dominica, Dominican Repubiic,
Ecuador, Ei Saivador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama,
Paraguay, Peru. Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago, US, Uruguay, Venezuela
observers— (45) Algeria, Angola, Austria, Belgium, Bosnia and Herzegovina, Buigaria, Croatia, Cyprus, Czech
Repubiic, Egypt, Equatorial Guinea, EU, Finland, France, Germany, Ghana, Greece, Holy See, Hungary, India,
Israei, Italy, Japan, Kazakhstan, South Korea, Latvia, Lebanon, Morocco, Netheriands, Pakistan, Poiand, Portugal,
Romania, Russia, Saudi Arabia, Spain, Sri Lanka, Sweden, Switzeriand, Thailand, Tunisia, Turkey, Ukraine, UK,','2fce7e2d78c3f596dd917a78133bfd378fcd7bc281d1c7c710dbecdf382eaa9b','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1116ec1c4a02c9043f69b094f6742086a8f3ef14a7fe3b4dd945520934d530db',2000,'BE','Belgium','transnational-issues',501,'fe/ep/)one-[32] (2) 209 9211
FAX-[32](2)109 92 92
established— December 1950
a/m— to promote international cooperation in
customs matters
576
Appendix C: International Organizations and Groups (continued)
East African Development Bank (EADB) members— (Z) Kenya, Tanzania, Uganda
address— A Nile Avenue, P. 0. Box 7128,
Kampala, Uganda
fe/ep/7one-[256] (41) 230021, 230825
FAX-{25Q] (41) 259763
established— e June 1967
effective— t December 1967
aim— to promote economic development
Economic and Social Commission for Asia
and the Pacific (ESCAP)
address— United Nations Building,
Rajadamnern Avenue, Bangkok 10200,
telephone-{32] (2) 230 62 95
FAX-{32]{2) 230 87 22
esfaW/s/red— 19 June 1920 as the International
Federation of Christian Trade Unions (IFCTU),
renamed 4 October 1968
a/m— to promote the trade union movement
members— (99 national organizations) Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, Austria,
Bangladesh, Belgium, Belize, Benin, Bolivia, Bonaire Island, Botswana, Brazil, Burkina Faso, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Cuba, Curacao, Cyprus, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana,
Gabon, The Gambia, Ghana, Grenada, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong,
Indonesia, Iran, Italy, Jamaica, Kenya, Lesotho, Liberia, Liechtenstein, Luxembourg, Madagascar, Malaysia, Mali,
Malta, Martinique, Mauritius, Mexico, Montserrat, Namibia, Netherlands, Nicaragua, Niger, Nigeria, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Martin, Saint Vincent and the Grenadines, Senegal, Seychelles, Sierra Leone, Spain, Sri Lanka,
Suriname, Switzerland, Taiwan, Tanzania, Thailand, Togo, UK, US, Uruguay, Venezuela, Vietnam, Zambia,','fe9378cc0f1ce25fa3ed563955840ef6041ee3a97bdd68d900ffedd87e1cad5d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b02c70e1f1dde5c09a534aaf688329ffd6dfcfe4b60b4f13e043bed834baf094',2000,'TH','Thailand','transnational-issues',502,'telephone-{66] (2) 2881234
FA)H66] (2) 2881000
established— 2S March 1947 as Economic
Commission for Asia and the Far East (ECAFE)
aim— to carry out the commitment of the
Economic and Social Council of the UN to
promote economic development
Economic and Social Commission for members— (12 plus the Palestine Liberation Organization) Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Oman,
Western Asia (ESCWA) Qatar, Saudi Arabia, Syria, UAE, Yemen, Palestine Liberation Organization
address— P. 0. Box 1 1 -8575, Riad El-Sohl
Square, Beirut, Lebanon
fe/epbone-{961] (10) 981301
FA)H961] (10) 981510
established— Q August 1973 as Economic
Commission for Western Asia (ECWA)
aim— to promote economic development as a
regional commission for the UN''s Economic and
Social Council
Economic and Social Council (ECOSOC) members— (54) selected on a rotating basis from all regions
address— United Nations, New York, NY 10017,
US
fe/epborje-[1] (212) 963 1234
FAY-[1] (212) 758 2718
established— 26 June 1945
effective— 24 October 1945
a/m— to coordinate the economic and social
work of the UN; includes five regional
commissions (see Economic Commission for
Africa, Economic Commission for Europe,
Economic Commission for Latin America and
the Caribbean, Economic and Social
Commission for Asia and the Pacific, Economic
and Social Commission for Western Asia) and
10 functional commissions (see Commission for
Social Development, Commission on Human
Rights, Commission on Narcotic Drugs,
Commission on the Status of Women,
Commission on Population and Development,
Statistical Commission, Commission on Science
and Technology for Development, Commission
on Sustainable Development, and Commission
on Crime Prevention and Criminal Justice)
members— (51) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma, Cambodia,
China, Fiji, France, India, Indonesia, Iran, Japan, Kazakhstan, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, Netherlands, NZ,
Pakistan, Palau, Papua New Guinea, Philippines, Russia, Samoa, Singapore, Solomon Islands, Sri Lanka,
Tajikistan, Thailand, Tonga, Turkey, Turkmenistan, Tuvalu, UK, US, Uzbekistan, Vanuatu, Vietnam
associate members— (9) American Samoa, Cook Islands, French Polynesia, Guam, Hong Kong, Macau, New
Caledonia, Niue, Northern Mariana Islands
577
Appendix C: International Organizations and Groups (continued)
Economic Commission for Africa (ECA)
address— P. 0. Box 3001-3005, Addis Ababa,','a99e432510f6b5cce112c67945b87d980668e37defa5b3f149f491cde7d94067','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2efdb453180e3a236a734d9d91733618e796f60f7cb547d73f32b549cc65f440',2000,'CL','Chile','transnational-issues',503,'telephone-{56] (2) 2102000
FAX-[56] (2) 2080252, 2081946
established— 25 February 1948 as Economic
Commission for Latin America (ECLA)
aim— to promote economic development as a
regional commission of the UN''s Economic and
Social Council
members— (41) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba, Dominica, Dominican Republic, Ecuador, El Salvador, France, Grenada, Guatemala,
Guyana, Haiti, Honduras, Italy, Jamaica, Mexico, Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Spain, Suriname, Trinidad and Tobago, UK, US,
Uruguay, Venezuela
associate members— (7) Anguilla, Aruba, British Virgin Islands, Montserrat, Netherlands Antilles, Puerto Rico,
Virgin Islands
Economic Commission for Western Asia
(ECWA)
see Economic and Social Commission for Western Asia (ESCWA)
Economic Community of Central African
States (CEEAC)
members— (1 1) Angola, Burundi, Cameroon, Central African Republic, Chad, Democratic Republic of the Congo,
Republic of the Congo, Equatorial Guinea, Gabon, Rwanda, Sao Tome and Principe
nofe— acronym from Communaute Economique
des Etats de I''Afrique Centrale
address— CEEAC, BP 2112, Libreville, Gabon
telephone-{24t] 73 35 47, 73 35 48, 73 36 77
established— 1 8 October 1 983 treaty adopted
aim— to promote regional economic cooperation
and establish a Central African Common Market
578
Appendix C: International Organizations and Groups (continued)
Economic Community of the Great Lakes
Countries (CEPGL)
members— (3) Burundi, Democratic Republic of the Congo, Rwanda
note— acronym from Communaute Economique
des Pays des Grands Lacs
address— IRAZ-CEPGL, BP 91 , Gitega, Burundi
established— 20 September 1976
a/m— to promote regional economic cooperation
and integration
Economic Community of West African States
(ECOWAS)
members— (16) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The Gambia, Ghana, Guinea, Guinea-Bissau,
Liberia, Mali, Mauritania, Niger, Nigeria, Senegal, Sierra Leone, Togo
address— 6 King George V Road, PMB 12745,
Lagos, Nigeria
telephone-{234] (1) 636839, 636841 , 636064,
630398
FAX-{23A] (1) 636822
established— 28 May 1975
a/m— to promote regionai economic cooperation
Economic Cooperation Organization (ECO)
address— No. 1 Goulbou Aliey, Kamraniyeh, R
0. Box 14155-6176, Teheran, Iran Islamic
Republic
telephone-{98] (21) 2831731, 2831733
FAX-[98] (21) 2831732
established— 27-29 January 1985
a/m— to promote regional cooperation in trade,
transportation, communications, tourism,
cultural affairs, and economic development
members— (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan,','6319b1d4d2e2483817c884566a75a625301af551ecf994f3a20c475f38674202','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('008cf5aa1f4305b37e4fd6a0af6fb634783cefbaff9609a66636d30ad916065e',2000,'UZ','Uzbekistan','transnational-issues',504,'associate member— (1) ''Turkish Republic of Northern Cyprus"
Euro-Atlantic Partnership Council (EAPC)
rrofe— began as the North Atlantic Cooperation
Council (NACC); an extension of NATO
address— c/o NATO, B-1110 Brussels, Belgium
telephone-{32]{2)728 4t 11
FAX-{32] (2) 728 45 79
established— 8 November 1991
effective— 20 December 1991
aim— to discuss cooperation on mutual political
and security issues
members— (44) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria, Canada, Czech Republic,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Italy, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Moldova, Netherlands, Norway,
Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and
Development (EBRD)
address— EBRD Headquarters, One Exchange
Square, London EC2A 2EH, UK
fe/ep/7or7e-[44] (1 71 ) 338 6000
FAX-[44] (171) 338 6100
established— 8-9 January 1990 (proposals
made); 15 April 1991 (bank inaugurated)
a/m— to facilitate the transition of seven centrally
planned economies in Europe (Bulgaria, former
Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market
economies by committing 60% of its loans to
privatization
members— (60) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank (EIB),
Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan,
South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Malta, Mexico, Moldova, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan;
rrofe— includes all 25 members of the OECD; also includes the EU as a single entity
579
Appendix C: International Organizations and Groups (continued)
European Community (or European
Communities, EC)
was established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal
and Steel Community (ESC), the European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of Europe; merged into the European Union (EU)
on 7 February 1 992; member states at the time of merger were Belgium, Denmark, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
members— (4) Iceland, Liechtenstein, Norway, Switzerland
address— Q-^ 1 Rue de Varembe, CH-121 1
Geneva 20, Switzerland
fe/eptone-(41](22)74911 11
FA>C^41] (22) 733 92 91
established—^ January 1960
effective—^ May 1960
a/m— to promote expansion of free trade
European Investment Bank (EIB)
address— Boulevard Konrad Adenauer 100,
L-2950 Luxembourg, Luxembourg
telephone— [352] 4379 3122
FAX-{352] 4379 3188, 4379 3189
established— 25 March 1957
effective— 1 January 1958
a/m— to promote economic development of the
ED and its predecessors, the EEC and the EC
members— (15) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, Sweden, UK
European Monetary Union (EMU)
rrofe— an integral part of the European Union;
also known as the European Economic and
Monetary Union
address— c/o European Commission, Rue de la
Loi 200, B-1049 Brussels, Belgium
fe/ep/7or7e-[32] (2) 299 11 11
proposed— 1-2 December 1969 at summit
conference of heads of government
signed— 7 February 1992 Maastrict Treaty
a/m— to promote a single market by creating a
single currency, the euro; time table— 2 May
1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and
stock exchanges begin using euros; 1 January
2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
members— (11) Austria, Belgium, Finland, France, Germany, Ireland, Italy, Luxembourg, Netherlands, Portugal,
Spain; note— Denmark, Sweden, and UK decided not to join, and Greece did not meet all the criteria to take part
European Organization for Nuclear Research
(CERN)
note— acronym retained from the predecessor
organization Conseil Europeenne pour la
Recherche Nucleaire
address— CH-121 1 Geneva 23, Switzerland
fe/ep/7or7e-[41] (22) 767 4101 , 767 2141
FAX-{41] (22) 785 0247
established— 1 July 1953
effective— 2d September 1954
a/m— to foster nuclear research for peaceful
purposes only
members— (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Italy, Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers— (7) EU, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific, and Cultural Organization
(UNESCO), US
Appendix C: International Organizations and Groups (continued)
58-
Appendix C: International Organizations and Groups (continued)
former USSR/Eastern Europe
(former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); these countries are in political and economic transition and may well be
grouped differently in the near future; this group of 27 countries consists of Albania, Armenia, Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, The Former Yugoslav Republic of Macedonia, Moldova, Poland, Romania, Russia, Serbia and
Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; this group is identical to the IMF
group “countries in transition" except for the IMF''s inclusion of Mongolia
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also
known as the Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are
included in the IMF''s “advanced economies" group
Four Tigers
another term for the Four Dragons; see Four Dragons
Franc Zone (FZ)
nofe— also known as Conference des Ministres
des Finances des Pays de la Zone Franc
address— c/o Banque de France, Service de la
Zone Franc, 39 Rue des Croix des Petits
Champs, F-75001 Paris, France
telephone-{33]{^)A2 22 42 92
F/AX-[33](1)42 96 04 23
established— HA 1964
a/m— to form a monetary union among countries
whose currencies are linked to the French franc
members— {t6) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo,
Cote d''Ivoire, Equatorial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo; nofe— France includes
metropolitan France, the four overseas departments of France (French Guiana, Guadeloupe, Martinique, Reunion),
the two territorial collectivities of France (Mayotte, Saint Pierre and Miquelon), and the three overseas territories of
France (French Polynesia, New Caledonia, Wallis and Futuna)
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members included
Angola, Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade
(GATT)
was established 30 October 1947 to promote the expansion of international trade on a nondiscriminatory basis;
subsumed by the World Trade Organization (Vt/TrO) on 1 January 1995; members at the time were Angola, Antigua
and Barbuda, Argentina, Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic, Chad,
Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba,
Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Egypt, El Salvador, Fiji, Finland, France, Gabon,
The Gambia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea-Bissau, Guyana, Haiti, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kenya, South Korea, Kuwait,
Lesotho, Liechtenstein, Luxembourg, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Senegal, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname,
Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE,
UK, US, Uruguay, Venezuela, Yugoslavia (suspended), Zambia, Zimbabwe
Group of 2 (G-2)
informal term that came into use about 1986; to facilitate bilateral economic cooperation between the two most
powerful economic giants Japan, US
Group of 3 (G-3)
members— (2) Colombia, Mexico, Venezuela
address— c/o Ministry of Foreign Affairs, Grupo
de los Tres, Caracas, Venezuela
established— HA September 1990
a/m— mechanism for policy coordination
Group of 5 (G-5)
members— {5) France, Germany, Japan, UK, US
established— 22 September 1985
aim— to coordinate the economic policies of five
major noncommunist economic powers
582
Appendix C; International Organizations and Groups (continued)
Group of 6 (G-6) members— {<o) Argentina, Greece, India, Mexico, Sweden, Tanzania
note— also known as Groups des Six Sur le
Desarmement; not to be confused with the Big
Six
established— 22 May 1984
aim— to achieve nuclear disarmament
Group of 7 (G-7) members— (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
rrofe— membership is the same as the Big Seven
established— 22 September 1985
aim— to facilitate economic cooperation among
the seven major noncommunist economic
powers
Group of 8 (G-8) members— (9) Canada, EU (as one member), France, Germany, Italy, Japan, Russia, UK, US
established— NA October 1975
aim— to facilitate economic cooperation among
the developed countries (DCs) that participated
in the Conference on International Economic
Cooperation (CIEC), held in several sessions
between NA December 1975 and 3 June 1977
Group of 9 (G-9) members— (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Sweden, Yugoslavia
established— t^A
a/m— to discuss matters of mutual interest on an
informal basis
Groupof 10(G-10)
rrofe— also known as the Paris Club; includes
the wealthiest members of the IMF who provide
most of the money to be loaned and act as the
informal steering committee; name persists in
spite of the addition of Switzerland on NA April
1984
address— do IMF Office in Europe, 64-66
Avenue d’lena, F-75116 Paris, France
telephone-{33] (1 ) 40 69 30 80
FAY-[33](1)4723 40 89
established— UA October 1962
a/m— to coordinate credit policy
Group of 1 1 (G-1 1 ) members— {t 1 ) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay,
Venezuela
note— also known as the Cartagena Group
established— 2t -22 June 1984, in Cartagena,
newiy industriaiizing countries (NiCs)
former term for the newiy industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NiEs)
that subgroup of the less developed countries (LDCs) that has experienced particulariy rapid industrialization of their
economies; formerly known as the newly industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea, Singapore, Taiwan), and Brazil
Appendix C: International Organizations and Groups (continued)
members— (1 13 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Ecuador, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
observers— (16) Antigua and Barbuda, Armenia, Azerbaijan, Brazil, China, Costa Rica, Croatia, Dominica,
Dominican Republic, El Salvador, Kazakhstan, Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests— (28) Australia, Austria, Bosnia and Herzegovina, Bulgaria, Canada, Finland, France, Germany, Greece,
Holy See, Hungary, Ireland, Italy, Japan, South Korea, Netherlands, NZ, Norway, Poland, Portugal, Romania,
Russia, Slovakia, Slovenia, Sweden, Switzerland, UK, US
Nordic Council (NC) members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
address— Store Strandstraede 18, PB 3043, observers— (8) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
DK-1021 Kobenhavn K, Denmark
telephone— [45] 33 96 04 00
FAX-(45]3311 18 70
established— 18 March 1952
effective— 1 2 February 1953
aim— to promote regional economic, cultural,
and environmental cooperation
Nordic investment Bank (NIB) members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
address— Fabianinkatu 34, P. 0. Box 249,
FIN-00171 Helsinki, Finland
fe/ephone— [358] (0) 18001
FAX-[358] (0) 1800210
established— 4 December 1975
effective— 1 June 1976
aim— to promote economic cooperation and
development
North a popular term for the rich industrialized countries generally located in the northern portion of the Northern
Hemisphere; the counterpart of the South; see developed countries (DCs)
North Atlantic Cooperation Council (NACC) see Euro-Atlantic Partnership Council (EAPC)
North Atlantic Treaty Organization (NATO) members— (19) Belgium, Canada, Czech Republic, Denmark, France, Germany, Greece, Hungary, Iceland, Italy,
Luxembourg, Netherlands, Norway, Poland, Portugal, Spain, Turkey, UK, US
address— B-t 110 Brussels, Belgium
fe/ephone-[32](2)707 4111
FAX-132] (2) 707 4579
established— 4 April 1949
aim— to promote mutual defense and
cooperation
Nonaligned Movement (NAM)
address— Permanent Representative of the
Republic of South Africa to the United Nations,
333 East 38th Street, 9th floor. New York, NY
10016, US
telephone-{t] (212) 213 5583
FAX-(1] (212) 692 2498
established— 1-8 September 1961
aim— to establish political and military
cooperation apart from the traditional East or
West blocs
Appendix C: International Organizations and Groups (continued)
Nuclear Energy Agency (NEA) members— {27) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Portugal,
nofe-also known as OECD Nuclear Energy Spain, Sweden, Switzerland, Turkey, UK, US
Agency
address— AEN/NEA, Le Seine St. Germain, 12
Boulevard des lies, F-92130
Issy-les-Moulineaux, France
te/ephone-[33](1)45 241010
FAX-{33] (1)45 24 11 10 •
established— 1 February 1958
aim— to promote the peaceful uses of nuclear
energy; associated with OECD
Nuclear Suppliers Group (NSG)
note— also known as the London Suppliers
Group or the London Group
address— c/o Permanent Mission of Japan to
the International Organizations in Vienna,
Andromeda Tower, 23rd floor, Donau City
Strasse 6, A-1220 Vienna, Austria
fe/ep/7one-{43] (1) 260 6300
FAX-{A3] (1) 263 6749
established-^k 1974
effective— 1975
aim— to establish guidelines for exports of
nuclear materials, processing equipment for
uranium enrichment, and technical information
to countries of proliferation concern and regions
of conflict and instability
Organlsmo para la Proscripcion de las see Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean (OPANAL)
Armas Nucleares en la America Latina y el
Caribe (OPANAL)
Organization for Economic Cooperation and members— (29) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany,
Development (OECD) Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
address— 2 Rue Andre Pascal, F-75775 Paris special member— (t) EU
CEDEX 16, France
telephon&-{33] (1 ) 45 24 82 00
FAX-{33] (1 ) 45 24 85 00, 45 24 81 76, 45 24
1815
established— 14 December 1960
effective— 30 September 1961
aim— to promote economic cooperation and
development
members— (35) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Latvia, Luxembourg, Netherlands,
NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Ukraine, UK,
US
Appendix C: International Organizations and Groups (continued)
Organization for Security and Cooperation in
Europe (OSCE)
note— formerly the Conference on Security and
Cooperation in Europe (CSCE) established 3
July 1975
address— Karntner Ring 5-7, A-1 010 Vienna,','e8938657658b3a9ec2db66f9451c7b3dddd82a9662957ed87f5c78e87b0bcc0d','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('105ddede40c9f46b72013c6baf782dfbe595cb67e5ea73a4820ee81f180786d5',2000,'CO','Colombia','transnational-issues',505,'a/m— to provide a forum for largest debtor
nations in Latin America
members— (tt) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
nonstate participants— {4) BIS, EU, IMF, OECD
Appendix C; International Organizations and Groups (continued)
Group of 15 (G-15)
nofe— byproduct of the Nonaligned Movement
address— Technical Support Facility, Ch du
Champ d''Ancier 1 7, Case Postale 326, CH-1 21 1
Geneva 19, Switzerland
fe/eptone-[41] (22) 798 4210
FAX-[41](22)798 38 49
esfaW/shed— September 1989
aim— to promote economic cooperation among
developing nations; to act as the main political
organ for the Nonaligned Movement
members— (15) Algeria, Argentina, Brazil, Egypt, India, Indonesia, Jamaica, Malaysia, Mexico, Nigeria, Peru,
Senegal, Venezuela, former Yugoslavia, Zimbabwe
Group of 19 (G-1 9)
established in NA October 1975 to represent the interests of the less developed countries (LDCs) that participated
in the Conference on International Economic Cooperation (CIEC) held in several sessions between NA December
1 975 and 3 June 1 977; members included Algeria, Argentina, Brazil, Cameroon, Democratic Republic of the Congo,
Egypt, India, Indonesia, Iran, Iraq, Jamaica, Mexico, Nigeria, Pakistan, Peru, Saudi Arabia, Venezuela, Yugoslavia,','75ced7504cff55ca782081bdadc1b6dcf5e90b129d6f957ac90877663d70dcef','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1b3ea1d542c91ba9d6f7b4ebf9affc7a68eced0220d4b105716ae3e368798b',2000,'ZM','Zambia','transnational-issues',506,'Group of 24 (G-24)
address— c/o European Commission, DGIA
General Matters and G-24 Coordination Unit,
Rue de la Loi 200, B-1049 Brussels, Belgium
telephone-{32] (2) 299 02 28
FAX-{32] (2) 296 59 59
established— t August 1989
aim— to promote the interests of developing
countries in Africa, Asia, and Latin America
within the IMF
members— (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d''Ivoire, Egypt,
Ethiopia, Gabon, Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, Sri Lanka,
Syria, Trinidad and Tobago, Venezuela, Yugoslavia
Group of 30 (G-30)
address— 1990 M Street NW, Suite 450,
Washington, DC 20036, US
telephone-{t] (202) 331 2472
FAX-[1] (202) 785 9423
established— HA 1978
aim— to discuss and propose solutions to the
world''s economic problems
members— (30) informal group of 30 leading international bankers, economists, financial experts, and business
leaders organized by Johannes Witteveen (former managing director of the IMF)
Group of 33 (G-33)
established in NA 1987 to promote solutions to international economic problems; members included the leading
economists from 13 countries
Group of 77 (G-77)
address— Office of the Chairman, United
Nations, Room S-3959, P. 0. Box 20, New York,
NY 10017, US
telephone-{t] (212) 963 3816, 963 0192, 963
4777
FAX-{t] (212) 963 3515, 963 1753
esfaW/shed— 15 June 1964 was set up; NA
October 1967 first ministerial meeting
a/m— to promote economic cooperation among
developing countries; name persists in spite of
increased membership
members— (131 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, South Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zambia, Zimbabwe, Palestine Liberation
Organization
584
Appendix C; International Organizations and Groups (continued)
Gulf Cooperation Council (GCC) members— {<o) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, DAE
note— also known as the Cooperation Council
for the Arab States of the Gulf
address— P. 0. Box 7153, Riyadh 11462, Saudi
Arabia
telephone— {%6] (1 ) 482 7777, extension 1 238
FA)H966] (1) 482 9109
established— 25 May 1981
aim— to promote regional cooperation in
economic, social, political, and military affairs
Hexagonal Group see Central European Initiative (CEI)
high-income countries another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC) members— (5) Comoros, France (for Reunion), Madagascar, Mauritius, Seychelles
address— QA Avenue Sir Guy Forget, BP7,
Quatre Bornes, Mauritius
telephone-{230] 425 9564, 425 1 652
FAX-[230] 425 1209
established— 21 December 1982
aim— to organize and promote regional
cooperation in all sectors, especially economic
industrial countries another term for the developed countries; see developed countries (DCs)
inter-American Development Bank (lADB)
note— also known as Banco Interamericano de
Desarrollo (BID)
address— 1 300 New York Avenue NW,
Washington, DC 20577, US
telephone-{1] (202) 623 1000
FAX-{1] (202) 623 3096
established— 8 April 1959
effective-30 December 1959
aim— to promote economic and social
development in Latin America
Inter-Governmental Authority on members— {7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan, Uganda
Development (IGAD)
note— formerly known as Inter-Governmental
Authority on Drought and Development (IGADD)
address— P. 0. Box 2653, Djibouti, Djibouti
telephone— [253] 354050
FAX-{253] 356994, 356284
established— 1 5-1 6 January 1 986 as the
Inter-Governmental Authority on Drought and
Development
revitalized— 21 March 1996 as the
Inter-Governmental Authority on Development
aim— to promote a social, economic, and
scientific community among its members
Inter-Governmental Authority on Drought see Inter-Governmental Authority on Development (IGAD)
and Development (IGADD)
members— (46) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan, Mexico, Netherlands, Nicaragua, Norway,
Panama, Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US,
Uruguay, Venezuela
Appendix C: International Organizations and Groups (continued)
International Atomic Energy Agency (IAEA)
address— Wagramerstrasse 5, P. 0. Box 100,
A-1400 Vienna, Austria
fe/eptone-[43] (1) 26000
FAX-443] (1) 26007
established— 2e October 1956
effective— 29 July 1957
aim— to promote peaceful uses of atomic energy
members— (129) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria, Bangladesh, Belarus,
Belgium, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso, Burma, Cambodia, Cameroon,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, Finland,
France, Gabon, Georgia, Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Latvia, Lebanon,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar,
Malaysia, Mali, Malta, Marshall Islands, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Namibia,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
International Bank for Economic
Cooperation (IBEC)
was established on 22 October 1963 to promote economic cooperation and development; members were Bulgaria,
Cuba, Czechoslovakia, GDR, Hungary, Mongolia, Poland, Romania, USSR, Vietnam; now it is a Russian bank with
a new charter
Internationai Bank for Reconstruction and
Deveiopment (IBRD)
note— also known as the World Bank
address— 1818 H Street NW, Washington, DC
20433, US
telephone-{-\\] (202) 477 1234
FAX-[1] (202) 477 6391
established— 22 July 1944
effective— 27 December 1945
aim— to provide economic development loans; a
UN specialized agency
merrtbers— (181) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Chamber of Commerce (ICC)
address— 3S Cours Albert 1st, F-75008 Paris,','ef218e2b2ca1a4c9d651d890e49e3bd4bf1dc8c08e5e99a0765285ab099682bf','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('804cbaf07bdcad1b119f9d6472fac6fc0afc9f6982f9e66e642a487f3f5f9a6d',2000,'YE','Yemen','transnational-issues',507,'598
Appendix C: International Organizations and Groups (continued)
Organization of Arab Petroieum Exporting
Countries (OAPEC)
members— {to) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, UAE
address— P. 0. Box 20501 , Safat 13066, Kuwait
telephone— {%5] 4844500
FAX-H965] 4815747
established— 9 January 1968
a/m— to promote cooperation in the petroleum
industry
Organization of Eastern Caribbean States
(OECS)
address— OECS, P. 0. Box 179, Morne Fortune,
Castries, Saint Lucia
telephone-{t] (758) 45 22537, 45 22538
FAX-{t] (758) 45 31628
established— W June 1981
effective— A July 1981
a/m— to promote political, economic, and
defense cooperation
members— (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines
associate members— (2) Anguilla, British Virgin Islands
Organization of Petroieum Exporting
Countries (OPEC)
members— (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
address— Obere Donaustrasse 93, A-1020
Vienna, Austria
fe/ep/ior)e-[43](1)21 1120
FAX-{43](1)21643 20
established— U September 1960
aim— to coordinate petroleum policies
Organization of the Isiamic Conference (OiC)
address— 6 km Makkah Al-Mukarramah Road,
P. 0. Box 178, Jeddah 2141 1 , Saudi Arabia
fe/ep/7or)e-[966] (2) 680-0800
FAX-1966] (2) 687-6568
established— 22-25 September 1969
a/m— to promote Islamic solidarity in economic,
social, cultural, and political affairs
members— (52 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia,
Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra
Leone, Somalia, Sudan, Suriname. Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen,
Palestine Liberation Organization
observers— (A) Bosnia and Herzegovina, Central African Republic, Moro National Liberation Front of the Philippines,
"Turkish Republic of Northern Cyprus"
Pacific Community
nofe— formerly known as the South Pacific
Commission (SPC)
address— BP D5, 98848 Noumea CEDEX, New
Caledonia
fe/ep/ior7e-[687] 26 20 00
FAX-46871 26 3818
established— 6 February 1947
effective— 29 July 1948
a/m— to promote regional cooperation in
economic and social matters
members— (25) American Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands, Palau, Papua
New Guinea, Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu, US, Vanuatu, Wallis and Futuna
Paris Ciub
see Group of 10
599
Appendix C: International Organizations and Groups (continued)
Partnership for Peace (PFP)
ac/c/ress— NATO Office of Information and
Press, B-1110 Brussels, Belgium
fe/ephone— {32] (2) 728 44 15
FAX-[32] (2) 728 45 79
established— January 1994
a/m— to expand and intensify political and
military cooperation throughout Europe,
increase stability, diminish threats to peace, and
build relationships by promoting the spirit of
practical cooperation and commitment to
democratic principles that underpin NATO;
program under the auspices of NATO
members— (27) Albania, Armenia, Austria, Azerbaijan, Belarus, Bulgaria, Czech Republic, Estonia, Finland,
Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, The Former Yugoslav Republic of Macedonia,
Moldova, Poland, Romania, Russia, Slovakia, Slovenia, Sweden, Switzerland, Turkmenistan, Ukraine, Uzbekistan
Permanent Court of Arbitration (PCA)
address— Peace Palace, Carnegieplein 2,
NL-2517 KJ The Hague, Netherlands
fe/ep/)one-{31] (70) 302 42 42
FAX-{3^] (70) 302 41 67
established— 29 July 1899
a/m— to facilitate the settlement of international
disputes
members— (33) Argentina, Australia, Austria, Belarus, Belgium, Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia,
Cameroon, Canada, Chile, China, Colombia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic,
Ecuador, Egypt, El Salvador, Eritrea, Fiji, Finland, France, Germany, Greece, Guatemala, Guyana, Haiti, Honduras,
Hungary, Iceland, India, Iran, Iraq, Israel, Italy, Japan, Jordan, Kyrgyzstan, Laos, Lebanon, Libya, Liechtenstein,
Luxembourg, Malta, Mauritius, Mexico, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay,
Peru, Poland, Portugal, Romania, Russia, Senegal, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Thailand, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Venezuela, Zaire, Zimbabwe
Population Commission
see Commission on Population and Development
Rio Group (RG)
nofe— formerly known as Grupo de los Ocho,
established in December 1986
aofc/ress— Ministerio de Relaciones Exteriores,
Edificio AYFRA, Piso 10, Pdte Franco y Ayolas,
Asuncion, Paraguay
telephone-{595] (21) 448409, 493872
FAX-[595] (21 ) 45091 1 , 493910
established^A 1988
a/m— to consult on regional Latin American
issues
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Panama, Paraguay, Peru, Uruguay,
Venezuela
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian
governments and command economies based on the Soviet model; the term is fading from use; see centrally
planned economies
Secretariat of the Pacific Community (SPC)
see Pacific Community
Sistema Economico Latinoamericana (SELA)
see Latin American Economic System (LAES)
Social Commission
see Commission for Social Development
socialist countries
in general, countries in which the government owns and plans the use of the major factors of production; nofe— the
term is sometimes used incorrectly as a synonym for communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the
counterpart of the North; see less developed countries (LDCs)
600
Appendix C: international Organizations and Groups (continued)
South Asian Association for Regional members— (7) Bangladesh, Bhutan, india, Maldives, Nepal, Pakistan, Sri Lanka
Cooperation (SAARC)
address— P. 0. Box 4222, Kathmandu, Nepal
telephone-1977] (1) 221785, 226350, 221792,
228029
FAX-1977] (1 ) 227033, 223991
established— 8 December 1985
aim— to promote economic, social, and cultural
cooperation
South Pacific Commission (SPC)
South Pacific Forum (SPF)
address— do Forum Secretariat, Ratu Sukuna
Road, Private Mail Bag, Suva, Fiji
telephone-{879] 312 600, 303 106
FAk-[679] 301 102, 305 573
established— 5 August 1971
aim— to promote regional cooperation in political
matters
South Pacific Regionai Trade and Economic members— (t 6) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Cooperation Agreement (Sparteca) Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
address— do forum Secretariat, Ratu Sukuna
Road GPO Box 856, Suva, Fiji
telephone-W9] 312 600, 303 106
FAX-{e79] 302 204
established-NA 1981
aim— to redress unequal trade relationships of
Australia and New Zealand with small island
economies in the Pacific region
Southern African Customs Union (SACU) members— (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
address— Director of Customs and Excise,
Ministry of Finance, Private Bag 13295,
Windhoek, Namibia
esfaW/shed— 11 December 1969
aim— to promote free trade and cooperation in
customs matters
Southern African Development Community members— (t A) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Malawi, Mauritius, Mozambique,
(SADC) Namibia, Seychelles, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
note— evolved from the Southern African
Development Coordination Conference
(SADCC)
address— Private Bag 0095, Gaborone,','76e5c14676ec8760b3e9c126315dc0303a7e768ac74cd5dcea62c5d56d3d9e64','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15979e32429048713903419746cf50f08aa86eafa1fcc7839488ec0db16f9841',2000,'BW','Botswana','transnational-issues',508,'telephone-{267] (31) 351863, 351864, 351865
FAX-[267] (31) 372848
estaW/shed— 17 August 1992
aim— to promote regional economic
development and integration
see Pacific Community (SPC)
members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
6I
Appendix C: International Organizations and Groups (continued)
Southern Cone Common Market (Mercosur)
or Southern Common Market
members— (A) Argentina, Brazil, Paraguay, Uruguay
associate member— (2) Bolivia, Chile
note— also known as Mercado Comun del Cono
Sur (Mercosur)
address— Rincon 575 PIso 12, 11000
Montevideo, Uruguay
tetephone-i596] (2) 9164590
F/4X-[598] (2) 9164591
established— 26 March 1991
aim— to Increase regional economic cooperation
Statistical Commission
members— (24) selected on a rotating basis from all regions
address— Statistics Division, Department of
Economic and Social Affairs, United Nations,
DC-2 Building, Room 2963, New York, NY
10017, US
telephone-{\\] (212) 963 1234
FAX-(1](212) 963 9851
established— 2^ June 1946
a/m— to deal with development and
standardization of national statistics of interest
to the UN, as part of the Economic and Social
Council organization
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed
countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
Union Douaniere et Economique de I''Afrique
Centrale (UDEAC)
see Central African Customs and Economic Union (UDEAC)
United Nations (UN)
address— United Nations, New York, NY 10017,
US
telephone-{t] (212) 963 1234
FAX-{1] (212) 963 4879
established— 26 June 1945
effective— 24 October 1945
a/m— to maintain international peace and
security and to promote cooperation involving
economic, social, cultural, and humanitarian
problems
members— (187 excluding Yugoslavia) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zambia, Zimbabwe; rrofe— all UN members are represented
in the General Assembly; Tuvalu will become a member in 2000
observers— (2 plus the Palestine Liberation Organization) Holy See, Switzerland, Palestine Liberation Organization
603
Appendix C: International Organizations and Groups (continued)
United Nations Deveiopment Program members— {3B) selected on a rotating basis from all regions
(UNDP)
address— Or\\e United Nations Plaza, New York,
NY 10017, US
telephone-{\\] (212) 906 5788, 906 5000
FAX-m{2^2) 906 5365
established— 22 November 1965
aim— to provide technical assistance to
stimulate economic and social development
United Nations Disengagement Observer members— (5) Austria, Canada, Japan, Poland, Slovakia
Force (UNDOF)
address— c/o Department of Peace-keeping
Operations, United Nations, Room S-3260E,
New York, NY 10017, US
telephone-{t] (212) 963 1234
FAX-[1](212) 9634879
established— 3t May 1974
aim— to observe the 1973 Arab-lsraeli
cease-fire; established by the UN Security
Council
members— (t&6) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, The Former Yugoslav Republic
of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended),
Zambia, Zimbabwe
associate members— {4) Aruba, British Virgin Islands, Macau, Netherlands Antilles
United Nations Environment Program members— {53) selected on a rotating basis from all regions
(UNEP)
United Nations Educationai, Scientific, and
Cuiturai Organization (UNESCO)
address— 7 place de Fontenoy, F-75352 Paris
07SP, France
fe/ep/ioneH33](1 ) 45 68 1 0 00
FAY-[33](1)45 67 16 90
established— 15 November 1945
effeclive-4 November 1946
aim— to promote cooperation in education,
science, and culture
address— P. 0. Box 30552, Nairobi, Kenya
telephor)e-{254] (2) 230800, 520600, 621234,
623292
FAY-[2541 (2) 226890, 623927, 623692
established— 15 December 1972
aim— to promote international cooperation on all
environmental matters
604
Appendix C: International Organizations and Groups (continued)
United Nations Generai Assembly members— (1 85) all UN members are represented In the General Assembly
address— see United Nations
established— 26 June 1945
effective— 24 October 1945
aim— to function as the primary deliberative
organ of the UN
United Nations High Commissioner for members— (53) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada, China, Colombia,
Refugees (UNHCR) Democratic Republic of the Congo, Denmark, Ethiopia, Finland, France, Germany, Greece, Holy See, Hungary,
India, Iran, Ireland, Israel, Italy, Japan, Lebanon, Lesotho, Madagascar, Morocco, Namibia, Netherlands, Nicaragua, •
address— UNHCR Headquarters, Case Postale Nigeria, Norway, Pakistan, Philippines, Poland, Russia, Serbia and Montenegro, Somalia, South Africa, Spain,
2500, Depot, CH-121 1 Geneva 2, Switzerland Sudan, Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela
fe/ephone-[41](22)739 81 11
FAX-[41](22)731 9546
established— 3 December 1949
effective— t January 1951
aim— to ensure the humanitarian treatment of
refugees and find permanent solutions to
refugee problems
United Nations Industriai Development members— (t 68) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Austria, Azerbaijan, The Bahamas,
Organization (UNIDO) Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central
address— Vienna International Center, P. 0. Box African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of fhe Congo, Republic of the
300, A-1 400 Vienna, Austria Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
telephone— {43] (1) 21 1 310 Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Finland, France, Gabon, The
FAX’— [43] (1) 23 21 56 Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
established— 17 November 1966 Honduras, Hungary, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea,
effective— 1 January 1967 South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Luxembourg, The Former
a/m— UN specialized agency that promotes Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
industrial development especially among the Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
members Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Yugoslavia (suspended), Zambia, Zimbabwe
United Nations Institute for Training and members (Board of Trustees)— (19) Argentina, Australia, Austria, Cameroon, Chile, China, Egypt, France, Germany,
Research (UNITAR) Ireland, Italy, Japan, Netherlands, Nigeria, Pakistan, Russia, South Africa, Switzerland, Thailand; rrofe— the UN
Secretary General can appoint up to 30 members
address— Palais des Nations, Bureau 1070,
CH-121 1, Geneva 10, Switzerland
telephone-141] (22) 798-58-50, 798-84-00
FAX-[41] (22) 733-13-83
esfaW/shed—l 1 December 1 963 adoption of the
resolution establishing the Institute
effective— 24 March 1965
aim— to help the UN become more effective
through training and research
605
Appendix C; International Organizations and Groups (continued)
United Nations interim Administration
Mission in Kosovo (UNMiK)
address— c/o Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-m (212) 963 1234
FAX-[1](212) 963 4879
esfaW/s/red— 10 June 1999
. a/m— to promote the estabiishment of
substantial autonomy and seif-government in
Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key
infrastructure and humanitarian and disaster
reiief
United Nations interim Force in Lebanon members— (9) Fiji, Finland, France, Ghana, India, Ireland, Italy, Nepal, Poland
(UNIFIL)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
te/epborre-jl] (212) 963 1234
FAY-[1](212) 963 4879
established— ^9 March 1978
a/m— to confirm the withdrawai of israeii forces,
and assist in reestablishing Lebanese authority
in southern Lebanon; estabiished by the UN
Security Council
United Nations Iraq-Kuwait Observation
Mission (UNiKOM)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{t] (212) 963 1234
FA)H1](212) 963 4879
established— 9 Aprii 1991
aim— to observe and monitor the demiiitarized
zone estabiished between iraq and Kuwait;
established by the UN Security Councii
United Nations Miiitary Observer Group in members— (8) Beigium, Chile, Denmark, Finland, Italy, South Korea, Sweden, Uruguay
India and Pakistan (UNMOGIP)
address— P. 0. Box 68, Rawalpindi, Pakistan
telephone-{92] (51) 564 298
FAX-{92] (51) 567 897, 565 861
established— 2A January 1949
a/m— to observe the 1949 India-Pakistan
cease-fire; established by the UN Security
Council
members— (83) Argentina, Austria, Bangladesh, Canada, China, Denmark, Fiji, Finland, France, Germany, Ghana,
Greece, Hungary, India, Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan, Poland, Romania, Russia,
Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay, Venezuela
members— (49) Argentina, Austria, Bangladesh, Belgium, Bolivia, Bulgaria, Canada, Czech Republic, Denmark,
Egypt, Estonia, Fiji, Finland, France, Germany, Ghana, Hungary, Iceland, India, Ireland, Italy, Jordan, Kenya,
Kyrgyzstan, Lithuania, Malawi, Malaysia, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Spain, Sweden, Switzerland, Tunisia, Turkey, Ukraine UK, US, Zambia,','a7b6a67d01a597f6a787c844c329f81fe9d156c2aec1b3fa0028137b41af6224','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71109efd6d36ff7d934d081bc6b59ba2100e797346f45a23a3e9531e2ca976f4',2000,'UY','Uruguay','transnational-issues',509,'address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{]] (212) 963 1234
FAX-[\\] (212) 963 4879
established— 24 August 1993
aim— to verify compliance with the cease-fire
agreement, to monitor weapons exclusion zone,
and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security
Council
United Nations Observer Mission in Liberia established 22 September 1993 to assist in the implementation of the peace agreement; established by the UN
(UNOMIL) Security Council; members were Bangladesh, Egypt, India, Kenya, Malaysia, Pakistan; disbanded September 1 997
United Nations Observer Mission established 1 993 for six months to monitor the Uganda/Rwanda border to verify that no military assistance reaches
Uganda-Rwanda (UNOMUR) Rwanda across the border; established by the UN Security Council; members were Bangladesh, Botswana, Brazil,
Hungary, Netherlands, Senegal, Slovakia, Zimbabwe; subsumed by UNAMIR
United Nations Operation in Mozambique established 1 6 December 1992 to supervise the cease-fire; established by the UN Security Council; members were
(UNOMOZ) Argentina, Austria, Bangladesh, Botswana, Brazil, Canada, Cape Verde, China, Czech Republic, Egypt,
Guinea-Bissau, Hungary, India, Ireland, Italy, Japan, Jordan, Malaysia, Netherlands, Norway, Portugal, Russia,
Spain, Sweden, US, Uruguay, Zambia; shut down operations 31 January 1995
United Nations Operation in Somalia established 24 April 1 992 to facilitate an immediate cessation of hostilities, to maintain a cease-fire in order to
(UNOSOM II) promote a political settlement, and to provide urgent humanitarian assistance; established by the UN Security
Council; members were Australia, Bangladesh, Botswana, Canada, Egypt, India, Ireland, Malaysia, Nepal, NZ,
Nigeria, Pakistan, Romania, Zimbabwe; UN peacekeepers left Somalia on 1 March 1995; some UN personnel
remain in Somalia engaged in humanitarian work
United Nations Organization Mission in the members— (24) Algeria, Bangladesh, Benin, Bolivia, Canada, Egypt, France, Ghana, India, Italy, Kenya, Libya, Mali,
Democratic Republic of the Congo (MONUC) Nepal, Pakistan, Poland, Romania, Russia, South Africa, Sweden, UK, Tanzania, Uruguay, Zambia
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
telephone-{1] (212) 963 1234
FAX-[1] (212) 963 4879
established— 30 November 1999
a/m— to establish contacts with the signatories
to the cease-fire agreement and to plan for the
observation of the cease-fire and
disengagement of forces
United Nations Peace-keeping Force in members— (10) Argentina, Australia, Austria, Canada, Finland, Hungary, Ireland, Netherlands, Slovenia, UK
Cyprus (UNFICYP)
address— Chief of Mission, P. 0. Box 1642,
Nicosia, Cyprus
telephone-{357] (2) 359 700
FAX-4357] (2) 359 753
established— 4 March 1964
aim— to serve as a peacekeeping force between
Greek Cypriots and Turkish Cypriots in Cyprus;
established by the UN Security Council
609
Appendix C: International Organizations and Groups (continued)
United Nations Population Fund (UNFPA) members— {3A) selected on a rotating basis from all regions
note— acronym retained from predecessor
organization UN Fund for Population Activities
address— 220 East 42nd Street, 19th Floor,
Room DN-1901, New York, NY 10017, US
telephone-{\\] (212) 297 5000
FAX-m (212) 557 6416
established— HA July 1967
a/m— to assist both developed and developing
countries to deal with their population problems
United Nations Preventive Deployment Force established 31 March 1 995; to monitor border activity in the Former Yugoslav Republic of Macedonia; members
(UNPREDEP) were Argentina, Bangladesh, Belgium, Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, Ghana,
Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Sweden,
Switzerland, Turkey, Ukraine, US; mandate ended 25 March 1999
United Nations Protection Force established 28 February 1 992; to create conditions for peace and security required for the negotiation of an overall
(UNPROFOR) settlement of the “Yugoslav" crisis; established by the UN Security Council; members were Bangladesh, Belgium,
Brazil, Canada, Czech Republic, Denmark, Egypt, Finland, France, Germany, Ghana, Indonesia, Ireland, Jordan,
Kenya, Malaysia, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Poland, Portugal, Russia, Spain, Sweden,
Switzerland, Ukraine, UK, US; disbanded December 1995; replaced by the Implementation Force (IFOR), which has
been replaced by the Stabilization Force (SFOR)
United Nations Relief and Works Agency for members— (tO) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria, Turkey, UK, US
Palestine Refugees in the Near East
(UNRWA)
address— P. 0. Box 700, Vienna International
Center, A-1400 Vienna, Austria
established— 8 December 1949
a/m— to provide assistance to Palestinian
refugees
United Nations Research Institute for Social members— no country members, but a Board of Directors consisting of a chairman appointed by the UN secretary
Development (UNRISD) general and 1 0 individual members
address— Palais des Nations, CH-121 1 Geneva
10, Switzerland
telephone-{At] (22) 798 84 00, 798 58 50
FAX-[41] (22) 740 07 91
established— HA 1963
a/m— to conduct research into the problems of
economic development during different phases
of economic growth
United Nations Secretariat members— the UN Secretary General and staff
address— see United Nations
established— 20 June 1945
effective— 24 October 1945
a/m— to serve as the primary administrative
organ of the UN; a Secretary General is
appointed for a five-year term by the General
Assembly on the recomrnendation of the
Security Council
610
Appendix C: International Organizations and Groups (continued)
United Nations Security Councii permanent members— (5) China, France, Russia, UK, US
nonpermanent members— (10) elected for two-year terms by the UN General Assembly; Argentina (1 999-2000),
address-c/o United Nations, Room S-3520A, Bangladesh (2000-01 ), Canada (1 999-2000), Jamaica (2000-01 ), Malaysia (1999-2000), Mali (2000-01 ), Namibia
New York, NY 1 001 7, US (1 999-2000), Netherlands (1999-2000), Tunisia (2000-01 ), Ukraine (2000-01 )
telephone-^1] (212) 963 1234
FAX-{1] (212) 758 2718
established— 20 June 1945
effective— 24 October 1945
a/m— to maintain international peace and
security
United Nations Transitionai Administration
in East Timor (UNTAET)
address— do Department of Peace-keeping
Operations, Room S-3260E, United Nations,
New York, NY 10017, US
teiephone-i1] (212) 963 1234
FAX-[1] (212) 963 4879
established— 25 October 1999
a/m— to provide security throughout the territory
of East Timor; to establish an effective
administration; to ensure the coordination and
delivery of humanitarian assistance; to support
capacity-building for self-government
established 1 2 November 1 995; aim to facilitate and supervise the Basic Agreement between the government of the
Republic of Croatia and the local Serbian community that will lead to a peaceful integration of that region into the
national state of Croatia; members were Argentina, Bangladesh, Belgium, Brazil, Czech Republic, Denmark, Egypt,
Fiji, Finland, Ghana, Indonesia, Ireland, Jordan, Kenya, Nepal, NZ, Niger, Nonvay, Pakistan, Poland, Russian,
Slovakia, Sweden, Switzerland, Tunisia, Ukraine, UK, US; disbanded 1 5 January 1 998; a UN Civilian Police Support
Group was established in December 1997 as follow-on mission to UNTAES; the support group will continue to
monitor the Croatian police in the Danube region, particularly in connection with the return of displaced people
United Nations Transitional Authority in established by the UN Security Council on 28 February 1 992 to contribute to the restoration and maintenance of
Cambodia (UNTAC) peace and to the holding of free elections; disbanded sometime after the UN-supervised election in May 1993;
members were Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brunei, Bulgaria, Cameroon, Canada,
Chile, China, Colombia, Egypt, Fiji, France, Germany, Ghana, Hungary, India, Indonesia, Ireland, Italy, Japan,
Jordan, Kenya, Malaysia, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Philippines, Poland, Russia,
Senegal, Singapore, Sweden, Thailand, Tunisia, UK, US, Uruguay
United Nations Truce Supervision members— (22) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France,
Organization (UNTSO) Ireland, Italy, Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
address— Government House, R 0. Box 490,
Jerusalem 91004, Israel
telephone-{972] (2) 673 4223
FAX-{972] (2) 673 5282, 673 4223 extension
400
established— HA June 1948
a/m— to supervise the 1948 Arab-lsraeli
cease-fire; currently supports timely deployment
of reinforcements to other peacekeeping
operations in the region as needed; initially
established by the UN Security Council
United Nations Trusteeship Councii established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 11 UN trust
territories; members were China, France, Russia, UK, US; it formally suspended operations 1 November 1 995 after
the Trust Territory of the Pacific Islands (Palau) became the Republic of Palau, a constitutional government in free
association with the US; the Trusteeship Council was not dissolved
United Nations Transitional Administration
In Eastern Slavonia, Baranja, and Western
SIrmIum (UNTAES)
members— (27) Argentina, Australia, Austria, Bangladesh, Bolivia, Brazil, Canada, Denmark, Egypt, Ghana,
Ireland, Jordan, Malaysia, Mozambique, Nepal, NZ, Pakistan, Phiiippines, Russia, Senegal, Spain, Sweden,
Thailand, UK, US, Uruguay, Zimbabwe
6
Appendix C: International Organizations and Groups (continued)
United Nations University (UNU)
address— 68-70 Jingumae 5-chome,
Shibuya-ku, Tokyo 150, Japan
fe/ep/^o^e^81](3)3499 2811
FAX-{8t] (3) 3499 2828
established— 8 December 1973
a/m— to conduct research in development,
welfare, and human survival and to train
scholars
members— (88 associated institutes in 32 countries) Argentina, Australia, Bangiadesh, Brazil, Canada, Chile, China,
Coiombia, Costa Rica, Ethiopia, France, Ghana, Guatemala, Hungary, Iceland, India, Japan, Kenya, South Korea,
Mexico, Netherlands, Nigeria, Philippines, Spain, Sri Lanka, Sudan, Switzerland, Thailand, Trinidad and Tobago,
UK, US, Venezuela
United Nations Verification Mission in
Guatemala (MINUGUA)
established on 20 January 1997; to verify fulfillment of cease-fire provisions; established by UN Security Council;
members were Argentina, Australia, Austria, Brazil, Canada, Columbia, Ecuador, Germany, Italy, Norway, Russia,
Singapore, Spain, Sweden, Ukraine, US, Uruguay, Venezuela; mandate terminated in May 1997
Universal Postal Union (UPU)
address— Bureau International de I’UPU,
Weltpoststrasse 4, CH-3000 Berne 15,
Convention on Long-Range Transboundary
Air Pollution
rrofe— abbreviated as Air Pollution
opened for signature— 13 November 1979
entered into force— 1 6 March 1983
objective-to protect the human environment
against air pollution and to gradually reduce and
prevent air pollution, including long-range
transboundary air pollution
parties— {A^} Armenia, Austria, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Malta, Moldova, Netherlands,
Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK,
US, former Yugoslavia
countries that have signed, but not yet ratified— (2) Holy See, San Marino
618
Appendix D: Selected international Environmental Agreements (continued)
parties— {] 52) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Latvia, Liberia, Liechtenstein,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (3) Ireland, Kuwait, Lesotho
Convention on the Prevention of Marine parties— {86) Afghanistan, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados, Belarus, Belgium,
Pollution by Dumping Wastes and Other Belize, Bolivia, Bosnia and Herzegovina, Brazil, Canada, Cape Verde, Chile, China, Democratic Republic of the
Matter (London Convention) Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Finland, France,
Gabon, Germany, Greece, Guatemala, Haiti, Honduras, Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan,
note— abbreviated as Marine Dumping Jordan, Kenya, Kiribati, South Korea, Kuwait, Lebanon, Liberia, Libya, Luxembourg, Malta, Mexico, Monaco,
opened for signature— 29 December 1972 Morocco, Nauru, Nepal, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
entered into force— 30 August 1 975 Philippines, Poland, Portugal, Russia, Saint Lucia, Seychelles, Slovenia, Solomon Islands, South Africa, Spain,
ob/echVe— to control pollution of the sea by Suriname, Sweden, Switzerland, Togo, Tonga, Tunisia, Tuvalu, Ukraine, UAE, UK, US, Vanuatu, former Yugoslavia
dumping and to encourage regional agreements
supplementary to the Convention
Convention on the Prohibition of Miiitary or parties— (66) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Bangladesh, Belarus,
Any Other Hostile Use of Environmental Belgium, Benin, Brazil, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark,
Modification Techniques Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea,
South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway, Pakistan, Papua New
rrofe— abbreviated as Environmental Guinea, Poland, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Modification Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden, Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay,
opened for signature — 1 0 December 1 976 Uzbekistan, Vietnam, Yemen
entered into force— 5 October 1 978 countries that have signed, but not yet ratified— {t 7) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy See,
objective— to prohibit the military or other hostile Iceland, Iran, Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria, Turkey,
use of environmental modification techniques in Uganda
order to further world peace and trust among
nations
Convention on Wetlands of International
Importance Especially as Waterfowl Habitat
(Ramsar)
/70fe— abbreviated as Wetlands
opened for signature— 2 February 1971
entered into force— 2t December 1975
objective— to stem the progressive
encroachment on and loss of wetlands now and
in the future, recognizing the fundamental
ecological functions of wetlands and their
economic, cultural, scientific, and recreational
value
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/or
Desertification, Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmentai Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
parties— (t23) Albania, Algeria, Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Canada, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Estonia, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Latvia, Lebanon, Liechtenstein,
Lithuania, Luxembourg, The Former Yugoslav Republic of Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mexico, Monaco, Mongolia, Morocco, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Norway,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Senegal,
Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Vietnam, former
Yugoslavia, Zambia
Convention on the International Trade in
Endangered Species of Wild Flora and Fauna
(CITES)
note— abbreviated as Endangered Species
opened for signature— 3 March 1973
entered into force— t July 1 975
objective— to protect certain endangered
species from overexploitation by means of a
system of import/export permits
619
Appendix D: Selected International Environmental Agreements (continued)
International Convention for the Regulation
of Whaling
nofe— abbreviated as Whaling
opened for signature— 2 December 1946
entered into force— tO November 1948
objective— to protect all species of whales from
overhunting; to establish a system of
international regulation for the whale fisheries to
ensure proper conservation and development of
whale stocks; and to safeguard for future
generations the great natural resources
represented by whale stocks
parf/es— (51) Antigua and Barbuda, Argentina, Australia, Austria, Belize, Brazil, Canada, Chile, China, Costa Rica,
Denmark, Dominica, Ecuador, Egypt, Finland, France, Germany, Grenada, Iceland, India, Ireland, Italy, Jamaica,
Japan, Kenya, South Korea, Mauritius, Mexico, Monaco, Netherlands, NZ, Norway, Oman, Panama, Peru,
Philippines, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Seychelles,
Solomon Islands, South Africa, Spain, Sweden, Switzerland, UK, US, Uruguay, Venezuela
International Tropical Timber Agreement,
1983
nofe— abbreviated as Tropical Timber 83
opened for signature— 1 8 November 1 983
entered into force— t April 1 985; this agreement
expired when the International Tropical Timber
Agreement, 1994, went into force
ob/ecf/ve— to provide an effective framework for
cooperation between tropical timber producers
and consumers and to encourage the
development of national policies aimed at
sustainable utilization and conservation of
tropical forests and their genetic resources
parties— (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France,
Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Russia, Spain, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Venezuela
International Tropical Timber Agreement,
1994
nofe— abbreviated as Tropical Timber 94
opened for signature— 26 January 1 994
entered into force— 1 January 1997
objective-4o ensure that by the year 2000
exports of tropical timber originate from
sustainably managed sources; to establish a
fund to assist tropical timber producers in
obtaining the resources necessary to reach this
objective
parties— (55) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African
Republic, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark,
Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia,
Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua New
Guinea, Peru, Philippines, Portugal, Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago,
UK, US, Venezuela
countries that have signed, but not yet ratified— {1} Ireland
Kyoto Protocol to the United Nations
Framework Convention on Climate Change
nofe— abbreviated as Climate Change-Kyoto
Protocol
opened for signature— 16 March 1998, but not
yet in force
objective— to further reduce greenhouse gas
emissions by enhancing the national programs
of developed countries aimed at this goal and by
establishing percentage reduction targets for the
developed countries
parties— (21 ) Antigua and Barbuda, The Bahamas, Bolivia, Cyprus, El Salvador, Fiji, Georgia, Guatemala, Jamaica,
Maldives, Federated States of Micronesia, Mongolia, Nicaragua, Niue, Palau, Panama, Paraguay, Trinidad and
Tobago, Turkmenistan, Tuvalu, Uzbekistan
countries that have signed, but not yet ratified— (69) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada,
Chile, China, Cook Islands, Costa Rica, Croatia, Cuba, Czech Republic, Denmark, Ecuador, Egypt, Estonia, EU,
Finland, France, Germany, Greece, Honduras, Indonesia, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Latvia, Liechtenstein, Lithuania, Luxembourg, Malaysia, Mali, Malta, Marshall Islands, Mexico, Monaco,
Netherlands, New Zealand, Niger, Norway, Papua New Guinea, Peru, Philippines, Poland, Portugal, Romania,
Russia, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Seychelles, Slovakia, Slovenia, Solomon Islands,
Spain, Sweden, Switzerland, Thailand, Ukraine, UK, US, Uruguay, Vietnam, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Appendix D: Selected International Environmental Agreements (continued)
parties— {U2) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, E','1e85850ab30e61a14d4f15b7f15157fb204914b0268effe6f6a98c87c1de7ff0','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d1895163d515481f57a15478d99fbf19b53d5930deb2c4b317a3745f5784a12',2000,'UY','Uruguay','transnational-issues',510,'cuador,
Egypt, El Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav Republic of
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Saudi Arabia, Senegal, Seychelles, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
Nuclear Test Ban see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International parties— {t09) Algeria, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Barbados, Belarus,
Convention for the Prevention of Pollution Belgium, Belize, Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China, Colombia, Cote
From Ships, 1973 (MARPOL) d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt,
Equatorial Guinea, Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
note— abbreviated as Ship Pollution Guyana, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya, North Korea,
opened for signature— M February 1978 South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Malaysia, Malta, Marshall Islands, Mauritania,
entered into force— 2 October 1 983 Mauritius, Mexico, Monaco, Morocco, Netherlands, New Zealand, Norway, Oman, Pakistan, Panama, Papua New
objective— to preserve the marine environment Guinea, Peru, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Vincent and the Grenadines, Sao
through the complete elimination of pollution by Tome and Principe, Senegal, Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Suriname,
oil and other harmful substances and the Sweden, Switzerland, Syria, Togo, Tonga, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela,
minimization of accidental discharge of such Vietnam, former Yugoslavia
substances
Protocol on Environmental Protection to the
Antarctic Treaty
note— abbreviated as Antarctic-Environmental
Protocol
opened for signature— A October 1 991
entered into force— 14 January 1998
objective— to provide for comprehensive
protection of the Antarctic environment and
dependent and associated ecosystems; applies
to the area covered by the Antarctic Treaty
Protocol to the 1979 Convention on parties— (2Q) Austria, Belarus, Bulgaria, Canada, Czech Republic, Denmark, EU, Finland, France, Germany,
Long-Range Transboundary Air Poiiution Greece, Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Spain,
Concerning the Control of Emissions of Sweden, Switzerland, Ukraine, UK, US
Nitrogen Oxides or Their Transboundary countries that have signed, but not yet ratified— {2} Belgium, Poland
Fluxes
rrote— abbreviated as Air Pollution-Nitrogen
Oxides
opened for signature— 3t October 1988
entered into force— U February 1 991
objective— to provide for the control or reduction
of nitrogen oxides and their transboundary
fluxes
parties— (28) Argentina, Australia, Belgium, Brazil, Bulgaria, Chile, China, Ecuador, Finland, France, Germany,
Greece, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain,
Sweden, UK, US, Uruguay
countries that have signed, but not yet ratified— (t 5) Austria, Canada, Colombia, Cuba, Czech Republic, Denmark,
Guatemala, Hungary, North Korea, Papua New Guinea, Romania, Slovakia, Switzerland, Turkey, Ukraine
Montreal Protocol on Substances That
Deplete the Ozone Layer
note— abbreviated as Ozone Layer Protection
openedfors/gnafore— 16 September 1987
entered into force— t January 1989
objective— to protect the ozone layer by
controlling emissions of substances that
deplete it
621
Appendix D: Selected International Environmental Agreements (continued)
Protocol to the 1979 Convention on
Long-Range Transboundary Air Poiiution
Concerning the Control of Emissions of
Voiatile Organic Compounds or Their
Transboundary Fiuxes
parties— {t9) Austria, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Flungary, Italy, Liechtenstein,
Luxembourg, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— {7) Belgium, Canada, EU, Greece, Portugal, Ukraine, US
note— abbreviated as Air Poilution-Voiatiie
Organic Compounds
opened for signature— ^ 8 November 1 991
entered into force— 29 September 1997
objective— {0 provide for the controi and
reduction of emissions of voiatiie organic
compounds in order to reduce their
transboundary fluxes so as to protect human
health and the environment from adverse effects
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
parties— (22) Austria, Canada, Croatia, Czech Republic, Denmark, EU, Finland, France, Germany, Greece, Ireland,
Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (6) Belgium, Bulgaria, Hungary, Poland, Russia, Ukraine
rtofe— abbreviated as Air Pollution-Sulphur 94
opened for signature— 1 4 June 1 994
entered into force— 5 August 1 998
objective— to provide for a further reduction in
sulfur emissions or transboundary fluxes
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
Persistent Organic Pollutants
note— abbreviated as Air Pollution-Persistent
Organic Pollutants
opened for signature— 24 June 1 998, but not yet
in force
objective-to provide for the control and
reduction of emissions of persistent organic
pollutants in order to reduce their transboundary
fluxes so as to protect human health and the
environment from adverse effects
parties— (2) Canada, Norway
countries that have signed, but not yet ratified— (34) Armenia, Austria, Belgium, Bulgaria, Croatia, Cyprus, Czech
Republic, Denmark, EU, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Liechtenstein,
Lithuania, Luxembourg, Moldova, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Ukraine, UK, US
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
parties— {2t) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Finland, France, Germany,
Hungary, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden, Switzerland, Ukraine
note— abbreviated as Air Pollution-Sulphur 85
opened for signature— 8 July 1 985
entered into force— 2 September 1987
objective— to provide for a 30% reduction in
sulfur emissions or transboundary fluxes by
1993
Ship Pollution
see Protocol of 1 978 Relating to the International Convention for the Prevention of Pollution From Ships, 1 973
(MARPOL)
622
Appendix D; Selected International Environmental Agreements (continued)
Treaty Banning Nuclear Weapon Tests in the
Atmosphere, in Outer Space, and Under
Water
note— abbreviated as Nuclear Test Ban
opened for signature— 5 August 1963
entered into force— 10 October 1963
objective— to obtain an agreement on general
and complete disarmament under strict
international control in accordance with the
objectives of the United Natioris; to put an end to
the armaments race and eliminate incentives for
the production and testing of all kinds of
weapons, including nuclear weapons
parties— (122) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas,
Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma,
Canada, Cape Verde, Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon,
Liberia, Libya, Luxembourg, Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Mongolia,
Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Romania, Russia, Rwanda, Samoa, San Marino, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Venezuela, Yemen, former Yugoslavia, Zambia
countries that have signed, but not yet ratified— (12) Algeria, Burkina Faso, Burundi, Cameroon, China, Ethiopia,
Haiti, Mali, Paraguay, Portugal, Somalia, Vietnam
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the
Sea (LOS)
note— abbreviated as Law of the Sea
opened for signature— 10 December 1982
entered into force— 1 6 November 1 994
objective— to set up a comprehensive new legal
regime for the sea and oceans; to include rules
concerning environmental standards as well as
enforcement provisions dealing with pollution of
the marine environment
parties— (132) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burma,
Cameroon, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominica, Egypt, Equatorial Guinea, EU, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, South Korea,
Kuwait, Laos, Lebanon, The Former Yugoslav Republic of Macedonia, Malaysia, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Philippines, Poland, Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden,
Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Uganda, Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen,
former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (36) Mghamsian, Bangladesh, Belarus, Bhutan, Burkina Faso,
Burundi, Cambodia, Canada, Central African Republic, Chad, Colombia, Republic of the Congo, Denmark,
Dominican Republic, El Salvador, Ethiopia, Hungary, Iran, North Korea, Lesotho, Liberia, Libya, Liechtenstein,
Luxembourg, Madagascar, Malawi, Maldives, Morocco, Nicaragua, Niger, Niue, Qatar, Rwanda, Swaziland,
Switzerland, Thailand, Tuvalu, UAE
United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in Africa
note— abbreviated as Desertification
opened for signature— 1 4 October 1 994
entered into force— 20 December 1996
objective— to combat desertification and
mitigate the effects of drought through national
action programs that incorporate long-term
strategies supported by international
cooperation and partnership arrangements
parties— (159) Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Austria, Azerbaijan,
Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji,
Finland, France, Gabon. The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Libya, Luxembourg, Madagascar, Maiawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Paraguay, Peru, Portugal,
Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo, Tonga,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, United Arab Emirates, UK, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (4) Australia, Croatia, Philippines, US
Appendix D: Selected International Environmental Agreements (continued)
United Nations Framework Convention on
Ciimate Change
note— abbreviated as Climate Change
opened for signature— 9 May 1992
entered into force— March 1994
objective— io achieve stabilization of
greenhouse gas concentrations in the
atmosphere at a low enough level to prevent
dangerous anthropogenic interference with the
climate system
parties— (181) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Libya, Liechtenstein, Lithuania, Luxembourg, The Former Yugoslav
Republic of Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, former Yugoslavia, Zambia, Zimbabwe
countries that have signed, but not yet ratified— {4} Afghanistan, Angola, Belarus, Liberia
Wetlands
see Convention on W/etlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
624
Appendix E:
Weights and Measures
Mathematical Notation
Metric interrelationships
Mathematical Power
Name
10''® or 1 ,000,000,000,000,000,000
one quintillion
10''® or 1,000,000,000,000,000
one quadrillion
10''® or 1,000,000,000,000
one trillion
10® or 1,000,000,000
one billion
10® or 1,000,000
one million
10® or 1,000
one thousand
10® or 100
one hundred
10'' or 10
ten
10®or1
one
10'' or 0.1
one-tenth
10® or 0.01
one-hundredth
10-® or 0.001
one-thousandth
10-® or 0.000 001
one-millionth
10® or 0.000 000 001
one-billionth
10''® or 0.000 000 000 001
one-trillionth
10''® or 0.000 000 000 000001
one-quadrillionth
10-''« or 0.000 000 000 000 000 001
one-quintillionth
Prefix Symbol Length, Area Volume
weight, or
capacity
exa
E
10''®
1036
10®®
peta
P
10''®
1030
10®®
tera
T
10''®
10®®
1036
giga
G
10®
10''®
10®^
mega
M
10®
10''®
10''®
hectokilo
hk
10®
10''®
10''®
myria
ma
10®
10®
10''®
kilo
k
10®
10®
10®
hecto
h
10®
10®
10®
basic unit
1 meter,
1 gram,
1 liter
1 meter®
1 meter®
dec!
d
10-''
10®
10®
centi
c
10®
10®
10-®
mini
m
10-®
10®
10-®
decimllli
dm
10-®
10®
10-''®
centimilll
cm
10®
lO-''o
10-''®
micro
u
10®
10''®
10-18
nano
n
10®
10''®
W
pico
P
10-''®
10-®®
10-3®
femto
f
10''®
10-30
10-®®
atto
a
10-18
10-36
10-®®
625
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
acres
ares
40.468 564 224
acres
hectares
0.404 685 642 24
acres
square feet
43,560
acres
square kilometers
0.004 046 856 422 4
acres
square meters
4,046.856 422 4
acres
square miles (statute)
0.001 562 50
acres
square yards
4,840
ares
square meters
100
ares
square yards
119.599
barrels, US beer
gallons
31
barrels, US beer
liters
117.347 77
barrels, US petroleum
gallons (British)
34.97
barrels, US petroleum
gallons (US)
42
barrels, US petroleum
liters
158.987 29
barrels, US proof spirits
gallons
40
barrels, US proof spirits
liters
151.41647
bushels (US)
bushels (British)
0.968 9
bushels (US)
cubic feet
1.244 456
bushels (US)
cubic inches
2,150,42
bushels (US)
cubic meters
0.035 239 07
bushels (US)
cubic yards
0.046 090 96
bushels (US)
dekaliters
3.523 907
bushels (US)
dry pints
64
bushels (US)
dry quarts
32
bushels (US)
liters
35.239 070 17
bushels (US)
pecks
4
cables
fathoms
120
cables
meters
219.456
cables
yards
240
carat
milligrams
200
centimeters
feet
0.032 808 40
centimeters
inches
0.393 700 8
centimeters
meters
0.01
centimeters
yards
0.010 93613
centimeters, cubic
cubic inches
0.061 023 744
centimeters, square
square feet
0.001 076 39
centimeters, square
square inches
0.155 000 31
centimeters, square
square meters
0.000 1
centimeters, square
square yards
0.000119 599
626
Appendix E; Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply By
chains, square surveyor''s
ares
4.046 86
chains, square surveyor''s
square feet
4,356
chains, surveyor''s
feet
66
chains, surveyor''s
meters
20.116 8
chains, surveyor''s
rods
4
cords of wood
cubic feet
128
cords of wood
cubic meters
3.624556
cords of wood
cubic yards
4.740 7
cups
liquid ounces (US)
8
cups
liters
0.236 588 2
degrees Celsius
degrees Fahrenheit
multiply by 1 .8 and add 32
degrees Fahrenheit
degrees Celsius
subtract 32 and divide by 1 .8
dekaliters
bushels
0.283 775 9
dekaliters
cubic feet
0.353146 7
dekaliters
cubic inches
610.2374
dekaliters
dry pints
18.161 66
dekaliters
dry quarts
9.080 829 8
dekaliters
liters
10
dekaliters
pecks
1.135104
drams, avoirdupois
avoirdupois ounces
0.062 55
drams, avoirdupois
grains
27.344
drams, avoirdupois
grams
1.771 845 2
drams, troy
grains
60
drams, troy
grams
3.887 934 6
drams, troy
scruples
3
drams, troy
troy ounces
0.125
drams, liquid (US)
cubic inches
'' 0.226
drams, liquid (US)
liquid drams (British)
1.041
drams, liquid (US)
liquid ounces
0.125
drams, liquid (US)
milliliters
3.696 69
drams, liquid (US)
minims
60
fathoms
feet
6
fathoms
meters
1.828 8
feet
centimeters
30.48
feet
inches
12
feet
kilometers
0.000 304 8
feet
meters
0.304 8
feet
statute miles
0.000189 39
feet
yards
0.333 333 3
627
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
feet, cubic
bushels
0.803 563 95
feet, cubic
cubic decimeters
28.316 847
feet, cubic
cubic inches
1,728
feet, cubic
cubic meters
0.028 316 846 592
feet, cubic
cubic yards
0.037 037 04
feet, cubic
dry pints
51.428 09
feet, cubic
dry quarts
25.714 05
feet, cubic
gallons
7.480 519
feet, cubic
gills
239.376 6
feet, cubic
liquid ounces
957.506 5
feet, cubic
liquid pints
59.84416
feet, cubic
liquid quarts
29.922 08
feet, cubic
liters
28.316 846 592
feet, cubic
pecks
3.214 256
feet, square
acres
0.000 022 956 8
feet, square
square centimeters
929.030 4
feet, square
square decimeters
9.290 304
feet, square
square inches
144
feet, square
square meters
0.092 903 04
feet, square
square yards
0.111 111 1
furiongs
feet
660
furiongs
inches
7,920
furlongs
meters
201.168
furlongs
statute miles
0.125
furlongs
yards
220
gallons, liquid (US)
cubic feet
0.133 680 6
gallons, liquid (US)
cubic inches
231
gallons, liquid (US)
cubic meters
0.003 785 411 784
gallons, liquid (US)
cubic yards
0.004 951 13
gallons, liquid (US)
gills (US)
32
gallons, liquid (US)
liquid gallons (British)
0.832 67
gallons, liquid (US)
liquid ounces
128
gallons, liquid (US)
liquid pints
8
gallons, liquid (US)
liquid quarts
4
gallons, liquid (US)
liters
3.785 411 784
gallons, liquid (US)
milliliters
3,785.411 784
gallons, liquid (US)
minims
61,440
gills (US)
centiliters
11.829 4
gills (US)
cubic feet
0.004 177 517
gills (US)
cubic inches
7.218 75
628
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
gills (US)
gallons
0.031 25
gills (US)
gills (British)
0.832 67
gills (US)
liquid ounces
4
gills (US)
liquid pints
0.25
gills (US)
liquid quarts
0.125
gills (US)
liters
0.118 294118 25
gills (US)
milliliters
118.29411825
gills (US)
minims
1,920
grains
avoirdupois drams
0.036 571 43
grains
avoirdupois ounces
0.002 285 71 •
grains
avoirdupois pounds
0.000142 86
grains
grams
0.064798 91
grains
kilograms
0.000 064 798 91
grains
milligrams
64.798 910
grains
pennyweights
0.042
grains
scruples
0.05
grains
troy drams
0.016 6
grains
troy ounces
0.002 083 33
grains
troy pounds
0.000173 61
grams
avoirdupois drams
0.564 383 39
grams
avoirdupois ounces
0.035 273 961
grams
avoirdupois pounds
0.002 204 622 6
grams
grains
15.432 361
grams
kilograms
0.001
grams
milligrams
1,000
grams
troy ounces
0.032 150 746 6
grams
troy pounds
0.002 679 23
hands (height of horse)
centimeters
10.16
hands (height of horse)
inches
4
hectares
acres
•2.471 053 8
hectares
square feet
107,639.1
hectares
square kilometers
0.01
hectares
square meters
10,000
hectares
square miles
0.003 861 02
hectares
square yards
11,959.90
hundredweights, long
avoirdupois pounds
112
hundredweights, long
kilograms
50.802 345
hundredweights, long
long tons
0.05
hundredweights, long
metric tons
0.050 802 345
hu','045e5538e16c1e800d55f362d10e4301b056cd407a6e08430d26bdce6498bb3f','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('715777120d7e60b3e8fbfd8d54b824252276d8a58dcf6d022fca659aa86fe20e',2000,'UY','Uruguay','transnational-issues',511,'ndredweights, long
short tons
0.056
629
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
hundredweights, short
avoirdupois pounds
too
hundredweights, short
kilograms
45.359 237
hundredweights, short
long tons
0.044 642 86
hundredweights, short
metric tons
0.045 359 237
hundredweights, short
short tons
0.05
inches
centimeters
2.54
inches
feet
0.083 333 33
inches
meters
0.025 4
inches
millimeters
25.4
inches
yards
0.027 777 78
inches, cubic
bushels
0.000 465 025
inches, cubic
cubic centimeters
16.387 064
inches, cubic
cubic feet
0.000 578 703 7
inches, cubic
cubic meters
0.000 016 387 064
inches, cubic
cubic yards
0.000 021 433 47
inches, cubic
dry pints
0.029 761 6
inches, cubic
dry quarts
0.014 880 8
inches, cubic
gallons
0.004 329 0
inches, cubic
gills
0.138 528 1
inches, cubic
liquid ounces
0.554 112 6
inches, cubic
liquid pints
0.034 632 03
inches, cubic
liquid quarts
0.017 316 02
inches, cubic
liters
0.016 387 064
inches, cubic
milliliters
16.387 064
inches, cubic
minims (US)
265.974 0
inches, cubic
pecks
0.001 86010
inches, square
square centimeters
6.451 600
inches, square
square feet
0.006 944 44
inches, square
square meters
0.000 645 16
inches, square
square yards
0.000 771 605
kilograms
avoirdupois drams
564.383 4
kiiograms
avoirdupois ounces
35.273 962
kiiograms
avoirdupois pounds
2.204 622 622
kiiograms
grains
15,432.36
kilograms
grams
1,000
1
kilograms
long tons
0.000 984 2
kilograms
metric tons
0.001
kilograms
short hundredweights
0.022 046 23
kilograms
short tons
0.001 102 31
kilograms
troy ounces
32.150 75
Appendix E; Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply By
kilograms
troy pounds
2.679 229
kilometers
meters
1,000
kilometers
statute miles
0.621 371 192
kilometers, square
acres
247.105 38
kilometers, square
hectares
100
kilometers, square
square meters
1,000,000
kilometers, square
statute miles
0.386102 16
knots (nautical mi/hr)
kilometers/hour
1.852
knots (nautical mi/hr)
statute miles/hour
1.151
leagues, nautical
kilometers
5.556
leagues, nautical
nautical miles
3
leagues, statute
kilometers
4.828 032
leagues, statute
statute miles
3
links, square surveyor''s
square centimeters
404.686
links, square surveyor''s
square inches
62.726 4
links, surveyor''s
centimeters
20.116 8
links, surveyor''s
chains
0.01
links, surveyor''s
inches
7.92
liters
bushels
0,028 377 59
liters
cubic feet
0.035 314 67
liters
cubic inches
61.023 74
liters
cubic meters
0.001
liters
cubic yards
0.001 307 95
liters
dekaliters
0.1
iiters
dry pints
1.816166
liters
dry quarts
0.908 082 98
liters
gallons
0.264172 052
liters
gills (US)
8.453 506
liters
liquid ounces
33.814 02
liters
liquid pints
2.113 376
liters
liquid quarts
1.056 688 2
liters
milliliters
1,000
liters
pecks
0.1135104
meters
centimeters
100
meters
feet
3.280 839 895
meters
inches
39.370 079
meters
kilometers
0.001
meters
millimeters
1,000
meters
statute miles
0.000 621 371
meters
yards
1.093 613298
631
Appendix E; Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
meters, cubic
bushels
28.377 59
meters, cubic
cubic feet
35.314 666 7
meters, cubic
cubic inches
61,023.744
meters, cubic
cubic yards
1.307 950 619
meters, cubic
gallons
264.172 05
meters, cubic
liters
1,000
meters, cubic
pecks
113.5104
meters, square
acres
0.000 247 105 38
meters, square
hectares
0.000 1
meters, square
square centimeters
10,000
meters, square
square feet
10.763 910 4
meters, square
square inches
1,550.0031
meters, square
square yards
1.195 990 046
microns
meters
0.000 001
microns
inches
0.000 039 4
miis
inches
0.001
mils
millimeters
0.025 4
miles, nautical
kilometers
1.852 0
miles, nautical
statute miles
1.150 779 4
miles, statute
centimeters
160,934.4
miles, statute
feet
5,280
miles, statute
furlongs
8
miles, statute
inches
63,360
miles, statute
kilometers
1,609 344
miles, statute
meters
1,609.344
miles, statute
rods
320
miles, statute
yards
1,760
miles, square nautical
square kilometers
3.429 904
miles, square nautical
square statute miles
1.325
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
sections
1
miles, square statute
square kilometers
2.589 988110 336
miles, square statute
square nautical miles
0.755 miles
miles, square statute
square rods
102,400
milligrams
grains
0.015 432 358 35
milliliters
cubic inches
0.061 023 744
milliliters
gallons
0.000 26417
milliliters
gills (US)
0.008 453 5
milliliters
liquid ounces
0.033 814 02
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
milliliters
liquid pints
0.0021134
milliliters
liquid quarts
0.001 056 7
milliliters
liters
0.001
milliliters
minims
16.230 73
millimeters
inches
0.039370 078 7
minims (US)
cubic inches
0.003 759 77
minims (US)
gills (US)
0.000 520 83
minims (US)
liquid ounces
0.002 08333
minims (US)
milliliters
0.061 61152
minims (US)
minims (British)
1.041
ounces, avoirdupois
avoirdupois drams
16
ounces, avoirdupois
avoirdupois pounds
0.062 5
ounces, avoirdupois
grains
437.5
ounces, avoirdupois
grams
28.349 523125
ounces, avoirdupois
kilograms
0.028 349 523 125
ounces, avoirdupois
troy ounces
0.911 458 3
ounces, avoirdupois
troy pounds
0.075 954 86
ounces, liquid (US)
cubic feet
0.001 044 38
ounces, liquid (US)
centiliters
2.957 35
ounces, liquid (US)
cubic inches
1.804 687 5
ounces, liquid (US)
gallons
0.007 812 5
ounces, liquid (US)
gills (US)
0.25
ounces, liquid (US)
liquid drams
8
ounces, liquid (US)
liquid ounces (British)
1.041
ounces, liquid (US)
liquid pints
0.062 5
ounces, liquid (US)
liquid quarts
0.031 25
ounces, liquid (US)
liters
0.029 573 53
ounces, liquid (US)
milliliters
29.573 529 6
ounces, liquid (US)
minims
480
ounces, troy
avoirdupois drams
17.554 29
ounces, troy
avoirdupois ounces
1.097143
ounces, troy
avoirdupois pounds
0.068 571 43
ounces, troy
grains
480
ounces, troy
grams
31.103476 8
ounces, troy
pennyweights
20
ounces, troy
troy drams
8
ounces, troy
troy pounds
0.083333 3
paces (US)
centimeters
76.2
paces (US)
inches
30
pecks (US)
bushels
0.25
633
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
pecks (US)
cubic feet
0.311 114
pecks (US)
cubic inches
537.605
pecks (US)
cubic meters
0.008 809 77
pecks (US)
cubic yards
0.011 522 74
pecks (US)
dekaliters
0.880 976 75
pecks (US)
dry pints
16
pecks (US)
dry quarts
8
pecks (US)
liters
8.809 767 5
pecks (US)
pecks (British)
0.968 9
pennyweights
grains
24
pennyweights
grams
1.555173 84
pennyweights
troy ounces
0.05
pints, dry (US)
bushels
0.015 625
pints, dry (US)
cubic feet
0.019 444 63
pints, dry (US)
cubic inches
33.600 312 5
pints, dry (US)
dekaliters
0.055 061 05
pints, dry (US)
dry pints (British)
0.968 9
pints, dry (US)
dry quarts
0.5
pints, dry (US)
liters
0.550 610 47
pints, liquid (US)
cubic feet
0.016 710 07
pints, liquid (US)
cubic inches
28.875
pints, liquid (US)
deciliters
4.731 76
pints, liquid (US)
gallons
0.125
pints, liquid (US)
gills (US)
4
pints, liquid (US)
liquid ounces
16
pints, liquid (US)
liquid pints (British)
0.832 67
pints, liquid (US)
liquid quarts
0.5
pints, liquid (US)
liters
0.473 176 473
pints, liquid (US)
milliliters
473.176 473
pints, liquid (US)
minims
7,680
points (typographical)
inches
0.013 837
points (typographical)
millimeters
0.351 459 8
pounds, avoirdupois
avoirdupois drams
256
pounds, avoirdupois
avoirdupois ounces
16
pounds, avoirdupois
grains
7,000
pounds, avoirdupois
grams
453.592 37
pounds, avoirdupois
kilograms
0.453 592 37
pounds, avoirdupois
long tons
0.000 446 428 6
pounds, avoirdupois
metric tons
0.000 453 592 37
Appendix E; Weights and Measures (continued)
Conversion Factors To Convert From
To
Multiply By
pounds, avoirdupois
quintals
0.004 535 92
pounds, avoirdupois
short tons
0.000 5
pounds, avoirdupois
troy ounces
14.583 33
pounds, avoirdupois
troy pounds
1.215 278
pounds, troy
avoirdupois drams
210.651 4
pounds, troy
avoirdupois ounces
13.165 71
pounds, troy
avoirdupois pounds
0.822 857 1
pounds, troy
grains
5,760
pounds, troy
grams
373.241 721 6
pounds, troy
kilograms
0.373 241 721 6
pounds, troy
pennyweights
240
pounds, troy
troy ounces
12
quarts, dry (US)
bushels
0.031 25
quarts, dry (US)
cubic feet
0.038 889 25
quarts, dry (US)
cubic inches
67.200 625
quarts, dry (US)
dekaliters
0.1101221
quarts, dry (US)
dry pints
2
quarts, dry (US)
dry quarts (British)
0.968 9
quarts, dry (US)
liters
1.101 221
quarts, dry (US)
pecks
0.125
quarts, dry (US)
pints, dry (US)
2
quarts, liquid (US)
cubic feet
0.03342014
quarts, liquid (US)
cubic inches
57.75
quarts, liquid (US)
deciliters
9.463 53
quarts, liquid (US)
gallons
0.25
quarts, liquid (US)
gills (US)
8
quarts, liquid (US)
liquid ounces
32
quarts, liquid (US)
liquid pints (US)
2
quarts, liquid (US)
liquid quarts (British)
0.832 67
quarts, liquid (US)
liters
0.946 352 946
quarts, liquid (US)
milliliters
946.352 946
quarts, liquid (US)
minims
15,360
quintals
avoirdupois pounds
220.462 26
quintals
kilograms
100
quintals
metric tons
0.1
rods
feet
16.5
rods
meters
5.029 2
rods
yards
5.5
rods, square
acres
0.006 25
635
Appendix E: Weights and Measures (continued)
Conversion Factors
To Convert From
To
Multiply By
rods, square
square meters
25.292 85
rods, square
square yards
30.25
scruples
grains
20
scruples
grams
1.295 978 2
scruples
troy drams
0.333
sections (US)
square kilometers
2.589 988 1
sections (US)
square statute miles
1
spans
centimeters
22.86
spans
inches
9
steres
cubic meters
1
steres
cubic yards
1.307 95
tablespoons
milliliters
14.786 76
tablespoons
teaspoons
3
teaspoons
milliliters
4.928 922
teaspoons
tablespoons
0.333 333
ton-miles, long
metric ton-kilometers
1.635169
ton-miles, short
metric ton-kilometers
1.459 972
tons, gross register
cubic feet of permanently enclosed','0e72a3bbb3e30c42bbe67e8a8f793297148d8751e3300cc65901448a52987528','internet-archive','DTIC_ADA385307','txt','974d73b9b3d0f8654a8fc8c7e51ac11d60b81444c0f036d54b51a0a3c6e27ef3','https://archive.org/download/DTIC_ADA385307/DTIC_ADA385307_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

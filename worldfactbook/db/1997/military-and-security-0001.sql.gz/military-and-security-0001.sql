SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a20d8dc9e83dea8dfd8c7ae8e22ccbd6753e60d20f227b456357e715ad0bb25',1997,'TC','Turks and Caicos Islands','military-and-security',20,'Military branches
Military manpower--military age
Military manpower--availability
males age 15-49
females age 15-49
Military manpower--fit for military service
males
females
Military manpower--reaching military age annually
males
females
Military expenditures--dollar figure
Military expenditures--percent of GDP
Military--note
Military - note: defense is the responsibility of the UK','5899e40bd265e7ac5dd4505257d0ebc433ccc0b659864e5ad41e51a46ceed450','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a412662e6e04dcf7872459a6760601e88a899288cfe61c1a6fbecf5d59107631',1997,'DE','Germany','military-and-security',25,'Military branches: NA; note - the military does not exist on a
national basis; some elements of the former Army, Air and Air Defense
Forces, National Guard, Border Guard Forces, National Police Force
(Sarandoi), and tribal militias still exist but are factionalized
among the various groups
Military manpower - military age: 22 years of age
Military manpower - availability:
males age 15-49 : 5,813,298 (1997 est.)
Military manpower - fit for military service:
males : 3,118,004 (1997 est.)
Military manpower - reaching military age annually:
males: 231,250 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy (includes Naval Air Arm), Air Force,
Medical Corps, Border Police, Coast Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 20,918,653 (1997 est.)
Military manpower - fit for military service:
males: 17,939,494 (1997 est.)
Military manpower - reaching military age annually:
males: 450,147 (1997 est.)
Military expenditures - dollar figure: $42.8 billion (1995)
Military expenditures - percent of GDP: 1.5% (1995)
Military branches: Royal Netherlands Army, Royal Netherlands Navy
(includes Naval Air Service and Marine Corps), Royal Netherlands Air
Force, Royal Constabulary
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49 : 4,160,723 (1997 est.)
Military manpower - fit for military service:
males: 3,642,218 (1997 est.)
Military manpower - reaching military age annually:
males: 95,006 (1997 est.)
Military expenditures - dollar figure: $8.2 billion (1995)
Military expenditures - percent of GDP: 2.1% (1995)
Military branches: Royal Netherlands Navy, Marine Corps, Royal
Netherlands Air Force, National Guard, Police Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 57,691 (1997 est.)
Military manpower - fit for military service:
males: 32,406 (1997 est.)
Military manpower - reaching military age annually:
males: 1,640 (1997 est.)
Military - note: defense is the responsibility of the Kingdom of the','40cfb84f3da021fd6077170b3110a06ce882feaffd2bb42afc83fe6f9b32c359','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60d602fbe1c72413faaaab8c8ae693f7a5e660d042298c62d290d6b37ba45e8b',1997,'AL','Albania','military-and-security',30,'Military branches: Army, Navy, Air and Air Defense Forces, Interior
Ministry Troops, Border Guards
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 738,082 (1997 est.)
Military manpower - fit for military service:
males: 600,403 (1997 est.)
Military manpower - reaching military age annually:
males: 31,823 (1997 est.)
Military expenditures - dollar figure: $42 million (1996)
Military expenditures - percent of GDP: 1.5% to 2.0% (1996)','ea723d7f40a627692fa5fda842f69225f92bdaf72ac21810c4d2461a16966e43','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('855a81b0396e7d78f2a8c1a29a2c5cd4160239da9785e2f242504529f632952d',1997,'DZ','Algeria','military-and-security',33,'Military branches: National Popular Army, Navy, Air Force, Territorial
Air Defense, National Gendarmerie
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 7,666,961 (1997 est.)
Military manpower - fit for military service:
males: 4,700,502 (1997 est.)
Military manpower - reaching military age annually:
males: 337,630 (1997 est.)
Military expenditures - dollar figure: $1.3 billion (1994)
Military expenditures - percent of GDP: 2.7% (1994)','15623e105ab0b3c878b9c26393bf457a577f12cca19024da207201a147563f37','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b2f2ab7686eefddbee18d7748acd90803560345750fe788ea95fd82f2509e30',1997,'AO','Angola','military-and-security',40,'Military branches: Army, Navy, Air and Air Defense Forces, National
Police Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,412,445 (1997 est.)
Military manpower - fit for military service:
males: 1,213,988 (1997 est.)
Military manpower - reaching military age annually:
males : 102,712 (1997 est.)
Military expenditures - dollar figure: $1.1 billion (1993)
Military expenditures - percent of GDP: 31% (1993)','b314ade74ba16991552a16bf1172b26424380375945e5fdf3d47df3d0e56a9f6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('723adebd80dd4f49b14daccc65967b99d71cad3b970113fc6fe8742e8598e132',1997,'AQ','Antarctica','military-and-security',46,'Military - note: the Antarctic Treaty prohibits any measures of a
military nature, such as the establishment of military bases and
fortifications, the carrying out of military maneuvers, or the testing
of any type of weapon; it permits the use of military personnel or
equipment for scientific research or for any other peaceful purposes','7ad9d9b737d13c44f1d610266cd2e4ca5fcbd0b157b45047c669612cefdfda2b','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdbe68493faa94f92ea9a008b8c7eca687543135bfaf864603603e83e4108e44',1997,'AG','Antigua and Barbuda','military-and-security',49,'Military branches: Royal Antigua and Barbuda Defense Force, Royal
Antigua and Barbuda Police Force (includes the Coast Guard)
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $1.4 million (FY90/91)
Military expenditures - percent of GDP: 1% (FY90/91)
:','3b2269814d009ade107e8b5192b252e71ade3c91c1fb1d13bbd4dde078f6884a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5950996d454ad9e877b9cd6025505dd2c8b916c5e0448ba052c9609a1b788756',1997,'AR','Argentina','military-and-security',52,'Military branches: Argentine Army, Navy of the Argentine Republic,
Argentine Air Force, National Gendarmerie, Argentine Naval Prefecture
(Coast Guard only), National Aeronautical Police Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 8,932,491 (1997 est.)
Military manpower - fit for military service:
males : 7,244,682 (1997 est.)
Military manpower - reaching military age annually:
males: 321,345 (1997 est.)
Military expenditures - dollar figure: $4.6 billion (1996)
Military expenditures - percent of GDP: 1.6% (1996)','3db581dbe27ebe9c2335e9e9f45ca8d79645c185dd9c4825a50e8ae2097fc8ac','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7ee4d64e9e5e963a9ef45c11ff7269ccffc3c763be33a398dec43d91e049764',1997,'AM','Armenia','military-and-security',55,'Military branches: Army, Air Force, Air Defense Force, Security Forces
(internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 907,579 (1997 est.)
Military manpower - fit for military service:
males: 722,715 (1997 est.)
Military manpower - reaching military age annually:
males: 30,942 (1997 est.)
Military expenditures - dollar figure: $75 million (1992)
Military expenditures - percent of GDP: NA%','47c26e6c9dc8f2073f6e06f89733ae84720c1c8e22aec463f11181a6e1f455e0','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca596f6992bf19de5a793a55193c644112cd31cec098fc42e61624d99ec60247',1997,'AU','Australia','military-and-security',63,'Military - note: defense is the responsibility of Australia; periodic
visits by the Royal Australian Navy and Royal Australian Air Force
Military branches: Australian Army, Royal Australian Navy, Royal
Australian Air Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49 : 4,863,007 (1997 est.)
Military manpower - fit for military service:
males: 4,200,090 (1997 est.)
Military manpower - reaching military age annually:
males: 127,508 (1997 est.)
Military expenditures - dollar figure: $7.9 billion (FY96/97)
Military expenditures - percent of GDP: 1.9% (FY96/97)
Military branches: French Armed Forces (Army, Navy, Air Force,
Gendarmerie); Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of France
Military branches: New Zealand Army, Royal New Zealand Navy, Royal New
Zealand Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49 : 932,982 (1997 est.)
Military manpower - fit for military service:
males: 785,440 (1997 est.)
Military manpower - reaching military age annually:
males: 26,514 (1997 est.)
Military expenditures - dollar figure: $677 million (FY96/97)
Military expenditures - percent of GDP: 1.1% (FY96/97)
Military - note: defense is the responsibility of Australia
Military branches: no regular military forces; Police Force (consists
of full-time personnel 45, part-time personnel 16)
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','ab6646bb97bb31e99003678fa32055ca422e2f41b15a8661a073f7f062979d49','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5f7867715b573c6925212a3c008ce67558f92b8b589f190147701e2c39c8cf0',1997,'AT','Austria','military-and-security',66,'Military branches: Army (includes Flying Division)
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 2,107,905 (1997 est.)
Military manpower - fit for military service:
males: 1,754,823 (1997 est.)
Military manpower - reaching military age annually:
males: 46,298 (1997 est.)
Military expenditures - dollar figure: $2.1 billion (1995)
Military expenditures - percent of GDP: 1% (1995)
Military branches: Army, Navy, Air and Air Defense Forces, Police
Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 532,578 (1997 est.)
Military manpower - fit for military service:
males: 429,419 (1997 est.)
Military manpower - reaching military age annually:
males: 16,468 (1997 est.)
Military expenditures - dollar figure: 7 billion denars (1993 est.);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%','3c6724d6af50aa614c601c8f9b9ab6f57be9dc6c51bf6e4cfe5d85564c9d7d65','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f76774ab18128612edcb3c14e0ce15b3bfc8aab70708691fba30cee3f6c8970d',1997,'AZ','Azerbaijan','military-and-security',68,'Military branches: Army, Navy, Air and Air Defense Forces, Border
Guards
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 1,982,747 (1997 est.)
Military manpower - fit for military service:
males: 1,596,087 (1997 est.)
Military manpower - reaching military age annually:
males: 69,524 (1997 est.)
Military expenditures - dollar figure: 33.5 billion manats (1994);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%','11e100c48c4ad3a0d3e40d037523eb179579fce4b5a9ef785b36bec0a237fd19','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('640cfe345c2bcbdd08ce93f1dcade274bb64ded1c343edd2ba28c70c22412e0f',1997,'TM','Turkmenistan','military-and-security',72,'Military branches: Royal Bahamas Defense Force (Coast Guard only),
Royal Bahamas Police Force
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males : NA
Military expenditures - dollar figure: $20 million (FY95/96)
Military expenditures - percent of GDP: 3.8% (FY95/96)
Military branches: Army, Air and Air Defense, Republic Security Forces
(internal and border troops), National Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,052,184 (1997 est.)
Military manpower - fit for military service:
males: 856,380 (1997 est.)
Military manpower - reaching military age annually:
males : 42,948 (1997 est.)
Military expenditures - dollar figure: 4.5 billion manats (1995); note
- conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures - percent of GDP: 3% (1995)','9fb8d3aa16ad574286f2bf022d7b2dce02db83297d4610f337a896949e09b500','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3cd17b33ca66c0f7834b4f27bcc57e704439879b53f892559cb4d39139d6c65',1997,'BH','Bahrain','military-and-security',75,'Military branches: Ground Force, Navy, Air Force, Coast Guard,
Internal Security Forces
Military manpower - military age: 15 years of age
Military manpower - availability:
males age 15-49: 216,444 (1997 est.)
Military manpower - fit for military service:
males: 119,781 (1997 est.)
Military expenditures - dollar figure: $256 million (1994)
Military expenditures - percent of GDP: 6.4% (1994)
Military - note: defense is the responsibility of the US; visited
annually by the US Coast Guard','d058cddb300a4cc9a5c8131ede02679ae0b8c1806c2cb3b2f845dc91537e7c2e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('407425c04e1a4dbfe93029c3fa99762ab440de91f526a53edc67c45e4cb52b52',1997,'BD','Bangladesh','military-and-security',78,'Military branches: Army, Navy, Air Force, paramilitary forces
(includes Bangladesh Rifles, Bangladesh Ansars, Armed Police Reserve,
Village Defense Parties, National Cadet Corps)
Military manpower - availability:
males age 15-49: 32,797,816 (1997 est.)
Military manpower - fit for military service:
males: 19,406,790 (1997 est.)
Military expenditures - dollar figure: $481 million (FY95/96)
Military expenditures - percent of GDP: 1.7% (FY95/96)','45758d37f76e1e26b2593e5be22de718863336718e9a0a6ee0243fe769b1b9da','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbd1ee290f672c191f4676fc44b6e2ca5911b6ce22d94ca538a13a1f2b54b6e1',1997,'BB','Barbados','military-and-security',81,'Military branches: Royal Barbados Defense Force (includes Ground
Forces and Coast Guard), Royal Barbados Police Force
Military manpower - availability:
males age 15-49: 71,547 (1997 est.)
Military manpower - fit for military service:
males: 49,446 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of France','9bf7b109a21b685306b448502fc316aab29115ae6d469e941a9fe0c9c62cfee1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8667fc29fb294e7b601fa21dc1f385bff30bef0ec37a9cc55440afe5bdcf64e6',1997,'BY','Belarus','military-and-security',84,'Military branches: Army, Air Force, Air Defense Force, Interior
Ministry Troops, Border Guards
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,659,236 (1997 est.)
Military manpower - fit for military service:
males: 2,083,696 (1997 est.)
Military manpower - reaching military age annually:
males: 77,496 (1997 est.)
Military expenditures - dollar figure: 2.4 trillion rubles (1997);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%','9decec1bb2c32d8747b5b0e905994cbc2ba41611814c93064af2c847c213aa67','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925cf0c51bd5d39547811e545d5dcce8e009e0ae9e5f8360bf2f629afdf877ba',1997,'BE','Belgium','military-and-security',87,'Military branches: Army, Navy, Air Force, National Gendarmerie
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49 : 2,559,951 (1997 est.)
Military manpower - fit for military service:
males: 2,122,673 (1997 est.)
Military manpower - reaching military age annually:
males : 63,005 (1997 est.)
Military expenditures - dollar figure: $4.6 billion (1995)
Military expenditures - percent of GDP: 1.7% (1995)','a505a4f7a65a1ab3d6bead816d091413743795619887e3123dae817219857adc','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('219ac909a7cbc7d2c23befa0bdf8f2487ab10727a34bbf56027e40de4fa4d6a4',1997,'GT','Guatemala','military-and-security',91,'Military branches: Belize Defense Force (includes Army, Navy, Air
Force, and Volunteer Guard), Belize National Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 54,163 (1997 est.)
Military manpower - fit for military service:
males : 32,176 (1997 est.)
Military manpower - reaching military age annually:
males : 2,471 (1997 est.)
Military expenditures - dollar figure: $8.1 million (FY95/96)
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 2,741,575 (1997 est.)
Military manpower - fit for military service:
males: 1,791,136 (1997 est.)
Military manpower - reaching military age annually:
males: 129,408 (1997 est.)
Military expenditures - dollar figure: $128.3 million (1996)
Military expenditures - percent of GDP: 0.8% (1996)','aa3a651303443e8e9e8a7d9598f9e21634beebc7c5f1956605643e384520c31f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eddb1e5c01174319cdcae53699ba0b1e9e6f9af09101ba6e3abcfb339d419aed',1997,'BJ','Benin','military-and-security',94,'Military branches: Armed Forces (includes Army, Navy, Air Force),
National Gendarmerie
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 1,261,059
females age 15-49: 1,333,966 (1997 est.)
note: both sexes are liable for military service
Military manpower - fit for military service:
males: 645,660 (1997 est.)
females: 675,243 (1997 est.)
Military manpower - reaching military age annually:
males: 64,028
females: 63,056 (1997 est.)
Military expenditures - dollar figure: $33 million (1994)
Military expenditures - percent of GDP: 3.2% (1994)','8e45acd2a291080a21ba9781df58830832923269c5b4b9ec523b8ded6b75f840','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3611bf3b690bfa178deb1a2d5ab21956c296e077c573d917fdfd7a0880592f4',1997,'BM','Bermuda','military-and-security',97,'Military branches: Bermuda Regiment, Bermuda Police Force, Bermuda
Reserve Constabulary
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the UK','78c5b499b7c51dda5111616116f8ff6c5d29fa895a46d931a81147f051cdd5ee','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5809b0bfd6d3f3ef5bfc7753f7cfba4a2983baa9a96349a6f54692ae5101c6a6',1997,'BT','Bhutan','military-and-security',100,'Military branches: Royal Bhutan Army, Palace Guard, Militia
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 455,556 (1997 est.)
Military manpower - fit for military service:
males : 243,156 (1997 est.)
Military manpower - reaching military age annually:
males: 18,290 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army (Ejercito Boliviano), Navy (Fuerza Naval
Boliviana, includes Marines), Air Force (Fuerza Aerea Boliviana),
National Police Force (Policia Nacional de Bolivia)
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49 : 1,811,952 (1997 est.)
Military manpower - fit for military service:
males: 1,178,259 (1997 est.)
Military manpower - reaching military age annually:
males: 80,606 (1997 est.)
Military expenditures - dollar figure: $145 million (1996)
Military expenditures - percent of GDP: 1.9% (1996)','f2d33664ce65d75be79ae991f165a582da018f5e4c9ffe934ff37a01c3d755d6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4ab7ecb28929c4bbafef1d7ad7ffac8afde1f81def64804f906aee0da4a404d',1997,'BA','Bosnia and Herzegovina','military-and-security',103,'Military branches: Army
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 865,763 (1997 est.)
Military manpower - fit for military service:
males: 696,202 (1997 est.)
Military manpower - reaching military age annually:
males : 23,771 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','76d5030de1733d286c509df5ac10173b0f160597d00f719d7f5f95e34237d06e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efc409d9066a722c3478f2a7d5d2def2c87ae9e5f036afb1f8cff73c8f04a19a',1997,'BW','Botswana','military-and-security',107,'Military branches: Botswana Defense Force (includes Army and Air
Wing), Botswana National Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 343,929 (1997 est.)
Military manpower - fit for military service:
males: 180,692 (1997 est.)
Military manpower - reaching military age annually:
males: 17,632 (1997 est.)
Military expenditures - dollar figure: $199 million (FY93/94)
Military expenditures - percent of GDP: 5.2% (FY93/94)','5e5309e022c6756e5b0afff4f93cf540014c80fd0ef460392a95ecee4cc9988e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec79bb279dd30788edf7db952f7a7250830aa1529b2213546f5728200f08820',1997,'BR','Brazil','military-and-security',112,'Military branches: Brazilian Army, Brazilian Navy (includes Marines),
Brazilian Air Force, Federal Police (paramilitary)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 45,876,084 (1997 est.)
Military manpower - fit for military service:
males: 30,843,947 (1997 est.)
Military manpower - reaching military age annually:
males : 1,756,732 (1997 est.)
Military expenditures - dollar figure: $6.736 billion (1994)
Military expenditures - percent of GDP: 1.1% (1994)
Military branches: Army, Navy (includes Naval Air and Marines), Air
Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 1,380,775 (1997 est.)
Military manpower - fit for military service:
males : 1,001,316 (1997 est.)
Military manpower - reaching military age annually:
males: 61,382 (1997 est.)
Military expenditures - dollar figure: $94 million (1994)
Military expenditures - percent of GDP: 0.6% (1994)','0d98375f77f033f3534e342db102f22daeae5de600e68391e8b3d4a1bbe280b8','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dad3adfaa6dc5670b6071bb2764bc55d50a62dae53bfe1ebd9f09f48282442eb',1997,'MY','Malaysia','military-and-security',119,'Military branches: Land Forces, Navy, Air Force, Royal Brunei Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 85,327 (1997 est.)
Military manpower - fit for military service:
males: 49,466 (1997 est.)
Military manpower - reaching military age annually:
males: 3,014 (1997 est.)
Military expenditures - dollar figure: $312 million (1994)
Military expenditures - percent of GDP: 6.2% (1994)
Military branches: Malaysian Army, Royal Malaysian Navy, Royal
Malaysian Air Force, Royal Malaysian Police Force, Marine Police,
Sarawak Border Scouts
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49: 5,280,741 (1997 est.)
Military manpower - fit for military service:
males: 3,201,235 (1997 est.)
Military manpower - reaching military age annually:
males: 184,351 (1997 est.)
Military expenditures - dollar figure: $2.5 billion (1997)
Military expenditures - percent of GDP: 2.6% (1997)','f01e01849272285214b78234680f34bb3bfc00c40827f73b9263410929b37145','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8453a412ace58941d0925d9f5fc3d7d90f5fa5b76eb90891df7adf895cbb7095',1997,'BG','Bulgaria','military-and-security',122,'Military branches: Army, Navy, Air and Air Defense Forces, Border
Troops, Internal Troops
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 2,052,731 (1997 est.)
Military manpower - fit for military service:
males: 1,711,729 (1997 est.)
Military manpower - reaching military age annually:
males: 62,908 (1997 est.)
Military expenditures - dollar figure: $418.6 million (1996)
Military expenditures - percent of GDP: 2.0% to 2.5% (1996)','e8e861826203f55075b42934e554c0a9b3554d90421dd5993e787c0dcc781401','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1740a1569f768637a3afb94fd38077240e3fd609b7dd7d8deba50ee221b5386d',1997,'BF','Burkina Faso','military-and-security',125,'Military branches: Army, Air Force, National Gendarmerie, National
Police, People''s Militia
Military manpower - availability:
males age 15-49: 2,219,544 (1997 est.)
Military manpower - fit for military service:
males: 1,137,882 (1997 est.)
Military expenditures - dollar figure: $104 million (1994)
Military expenditures - percent of GDP: 6.4% (1994)','8c4ee957b12db2ec0eebeb476519063c5e4a1e78c540d6fe7599479bfc063410','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8673186078348b148e489e1af2c20951c40bbf268a74a1d3928406555c1057f4',1997,'JP','Japan','military-and-security',127,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 12,037,009
females age 15-49: 11,846,381 (1997 est.)
note: both sexes liable for military service
Military manpower - fit for military service:
males : 6,434,452 (1997 est.)
females: 6,317,112 (1997 est.)
Military manpower - reaching military age annually:
males: 480,893
females: 462,314 (1997 est.)
Military expenditures - dollar figure: $135 million (FY95/96)
Military expenditures - percent of GDP: NA%
Military branches: Japan Ground Self-Defense Force (Army), Japan
Maritime Self-Defense Force (Navy), Japan Air Self-Defense Force (Air
Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 31,549,081 (1997 est.)
Military manpower - fit for military service:
males: 27,107,305 (1997 est.)
Military manpower - reaching military age annually:
males: 835,296 (1997 est.)
Military expenditures - dollar figure: $48.5 billion (FY96/97)
Military expenditures - percent of GDP: 1% (FY96/97)
Military - note: defense is the responsibility of the US; visited
annually by the US Coast Guard','8f3509b215f221fa0a9306b630099b93068281c8d50d98810469369830a66f4a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92d475c07af4be336ed2d7851c164ad0861332e99c591f6f4d9527ded8cfbf4e',1997,'BI','Burundi','military-and-security',131,'Military branches: Army (includes naval and air units), paramilitary
Gendarmerie
Military manpower - military age: 16 years of age
Military manpower - availability:
males age 15-49: 1,346,737 (1997 est.)
Military manpower - fit for military service:
males: 700,914 (1997 est.)
Military manpower - reaching military age annually:
males : 70,013 (1997 est.)
Military expenditures - dollar figure: $25 million (1993)
Military expenditures - percent of GDP: 2.6% (1993)','ee13fcee8926c83ceecc3c5b7770cd08f00e21ea47590a01407b51d62232b31a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c956d6a77a0810431a90d52d075d719e5b0db6dea9743980ab6b86d6356806c3',1997,'KH','Cambodia','military-and-security',135,'Military branches: Khmer Royal Armed Forces (KRAF) - created in 1993
by the merger of the Cambodian People''s Armed Forces and the two
noncommunist resistance armies; note - the KRAF is also known as the
Royal Cambodian Armed Forces (RCAF); Resistance forces - National Army
of Democratic Kampuchea (Khmer Rouge)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,418,916 (1997 est.)
Military manpower - fit for military service:
males: 1,348,065 (1997 est.)
Military manpower - reaching military age annually:
males: 97,361 (1997 est.)
Military expenditures - dollar figure: $160 million (1996)
Military expenditures - percent of GDP: NA%','b9d8ffbd55e99bd2eaff36ec8bee69fdd7911fa93bcdc6e94378c6f3e5be0e12','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a38285a76c05507d211930a8e0f11737d668f5921a7d46beb4e1453402bc2602',1997,'CM','Cameroon','military-and-security',138,'Military branches: Army, Navy (includes Naval Infantry), Air Force,
National Gendarmerie, Presidential Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 3,211,508 (1997 est.)
Military manpower - fit for military service:
males : 1,623,228 (1997 est.)
Military manpower - reaching military age annually:
males: 156,208 (1997 est.)
Military expenditures - dollar figure: $102 million (FY93/94)
Military expenditures - percent of GDP: NA%','d12876ee790a0162b658e2c56d74e605317b15843cd67fd890785687ff8f9fb9','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('928aa871a8e0d9028e0c0e4ebb414d89f6428b8fcea14556c2c2a814eab761f9',1997,'CA','Canada','military-and-security',141,'Military branches: Canadian Armed Forces (includes Land Forces Command
or LC, Maritime Command or MC, Air Command or AC, Communications
Command or CC, Training Command or TC), Royal Canadian Mounted Police
(RCMP)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 8,160,914 (1997 est.)
Military manpower - fit for military service:
males : 7,007,901 (1997 est.)
Military manpower - reaching military age annually:
males: 208,138 (1997 est.)
Military expenditures - dollar figure: $9 billion (FY95/96)
Military expenditures - percent of GDP: 1.6% (FY95/96)
Military branches: People''s Revolutionary Armed Forces (FARP; includes
Army and Navy), Security Service
Military manpower - availability:
males age 15-49: 78,622 (1997 est.)
Military manpower - fit for military service:
males: 44,870 (1997 est.)
Military expenditures - dollar figure: $3.4 million (1994)
Military expenditures - percent of GDP: NA%','5d77582e6feb4628ff3b07c8cc62995dfbe4673bb7380777a15f7f5f95bf8efe','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79b96c63f64c071e1b819cc624321bbef9ee6efee0ea5dfb837764300f106ffc',1997,'KY','Cayman Islands','military-and-security',144,'Military branches: Royal Cayman Islands Police Force (RCIPF)
Military - note: defense is the responsibility of the UK','2f54970a867ac3206447f81d68af66d67e3a7fbf5a36bf6bac32a2b485911632','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7a3dca53dbb4fb9828da82a92c2d41de63892ce31986fef2ded2b24457e06a1',1997,'CF','Central African Republic','military-and-security',147,'Military branches: Central African Army (includes Republican Guard),
Air Force, National Gendarmerie, Police Force
Military manpower - availability:
males age 15-49: 755,441 (1997 est.)
Military manpower - fit for military service:
males: 393,765 (1997 est.)
Military expenditures - dollar figure: $30 million (1994)
Military expenditures - percent of GDP: 2.3% (1994)','244f740005eb1ca94acd7ad621b3ffb0d8b8d2e5797a4d2e3b4e9296d91dc00a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6907c0ec7f56f2ea3816074894c9acaf011b83feee3a9637dba387ebab4b1c18',1997,'TD','Chad','military-and-security',151,'Military branches: Armed Forces (includes Ground Force, Air Force, and
Gendarmerie), Republican Guard, Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1,603,194 (1997 est.)
Military manpower - fit for military service:
males: 830,777 (1997 est.)
Military manpower - reaching military age annually:
males : 65,906 (1997 est.)
Military expenditures - dollar figure: $74 million (1994)
Military expenditures - percent of GDP: 11.1% (1994)','41aba91628387a28a2ecfb9343a7f85e17c054a0ed7ecf7c0764c50eb8820a8f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae7ca6b85b76e65d7f62c7e5576a5fb5ec97488e1f818dcad8b6bb082003cdba',1997,'CL','Chile','military-and-security',156,'Military branches: Army of the Nation, National Navy (includes Naval
Air, Coast Guard, and Marines), Air Force of the Nation, Carabineros
of Chile (National Police), Investigations Police
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 3,867,676 (1997 est.)
Military manpower - fit for military service:
males : 2,874,235 (1997 est.)
Military manpower - reaching military age annually:
males: 125,586 (1997 est.)
Military expenditures - dollar figure: $2.8 billion (1997); note -
includes earnings from CODELCO Company; may exclude costs of pensions
and internal security
Military expenditures - percent of GDP: 3.5% (1997)','4e8bb27d9886acf3dd976e110ed782e5ee7c46bf5c978f6ce70949cc86163b20','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f292b74021d02bfab167ee29d2c72f6c459e414554349a6e1867cf2f288d0c2a',1997,'CN','China','military-and-security',159,'Military branches: People''s Liberation Army (PLA), which includes the
Ground Forces, Navy (includes Marines and Naval Aviation), Air Force,
Second Artillery Corps (the strategic missile force), People''s Armed
Police (internal security troops, nominally subordinate to Ministry of
Public Security, but included by the Chinese as part of the "armed
forces" and considered to be an adjunct to the PLA in wartime)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 356,848,321 (1997 est.)
Military manpower - fit for military service:
males: 196,780,527 (1997 est.)
Military manpower - reaching military age annually:
males : 9,872,055 (1997 est.)
Military expenditures - dollar figure: the officially announced but
suspect figure is 70.2 billion yuan (1995 est.); note - conversion of
the defense budget into US dollars using the current exchange rate
could produce misleading results
Military expenditures - percent of GDP: NA%','c3368a99c5d76683a2c69764f99169aa5f54def0f312f75b10173c8e777814fb','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42c3bf6d43fd6ad06fc4971b2e503f64918cc77c0280d629d27523469b6e5cab',1997,'ID','Indonesia','military-and-security',163,'Military - note: defense is the responsibility of Australia
Military - note: defense is the responsibility of France
Military branches: Army, Navy, National Police
Military manpower - availability:
males age 15-49 : 276,923 (1997 est.)
Military manpower - fit for military service:
males: 139,531 (1997 est.)
Military expenditures - dollar figure: $14 million (FY93/94)
Military expenditures - percent of GDP: 3.8% (FY93/94)
Military branches: NA
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males : NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force, National Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 58,556,503 (1997 est.)
Military manpower - fit for military service:
males: 34,439,340 (1997 est.)
Military manpower - reaching military age annually:
males: 2,295,832 (1997 est.)
Military expenditures - dollar figure: $3.3 billion (FY97/98)
Military expenditures - percent of GDP: 1.3% (FY97/98)
Military branches: Islamic Republic of Iran regular forces (includes
Ground Forces, Navy, Air and Air Defense Forces), Revolutionary Guards
(includes Ground, Air, Navy, Qods, and Basij-mobilization-forces), Law
Enforcement Forces
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49 : 15,700,662 (1997 est.)
Military manpower - fit for military service:
males: 9,332,944 (1997 est.)
Military manpower - reaching military age annually:
males : 650,804 (1997 est.)
Military expenditures - dollar figure: according to official Iranian
data, Iran budgeted 8,283.9 billion rials for defense in 1997; note -
conversion of defense expenditures into US dollars using current
exchange rates could produce misleading results','ab62173994cd55180bbe0885afcce426f765651ec1b50cb856960e2c78690cd7','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2782046ed34dac6752f92cc08e75c996d4e79fe821cfc95c739c23e557a6bcf2',1997,'CO','Colombia','military-and-security',169,'Military branches: Army (Ejercito Nacional), Navy (Armada Nacional,
includes Marines and Coast Guard), Air Force (Fuerza Aerea
Colombiana), National Police (Policia Nacional)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 10,285,806 (1997 est.)
Military manpower - fit for military service:
males : 6,909,846 (1997 est.)
Military manpower - reaching military age annually:
males: 348,802 (1997 est.)
Military expenditures - dollar figure: $2 billion (1995)
Military expenditures - percent of GDP: 2.8% (1995)','1692821f168022625444b9c8c3803f6db4d7ca818a966305342a6d42a97eb0e6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('359eddfca7b4fb8f7ddba20bed3abde93617c1bffb76c5ba273f877f986be628',1997,'MZ','Mozambique','military-and-security',172,'Military branches: Comoran Security Force
Military manpower - availability:
males age 15-49: 125,378 (1997 est.)
Military manpower - fit for military service:
males: 74,836 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force, National Gendarmerie,
paramilitary Civil Guard, Special Presidential Division
Military manpower - availability:
males age 15-49 : 10,232,612 (1997 est.)
Military manpower - fit for military service:
males: 5,213,941 (1997 est.)
Military expenditures - dollar figure: $46 million (1990)
Military expenditures - percent of GDP: 1.5% (1990)
Military branches: Army, Navy (includes Marines), Air Force, National
Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49 : 601,771 (1997 est.)
Military manpower - fit for military service:
males : 306,757 (1997 est.)
Military manpower - reaching military age annually:
males: 26,081 (1997 est.)
Military expenditures - dollar figure: $110 million (1993)
Military expenditures - percent of GDP: 3.8% (1993)
Military - note: under the terms of a 1994 peace agreement, which
ended two years of civil strife, members of militias who supported the
three main political parties are being integrated into the military
forces
Military branches: Popular Armed Forces (includes Intervention Forces,
Development Forces, Aeronaval Forces - includes Navy and Air Force),
Gendarmerie, Presidential Security Regiment
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 3,204,200 (1997 est.)
Military manpower - fit for military service:
males: 1,903,268 (1997 est.)
Military manpower - reaching military age annually:
males: 136,216 (1997 est.)
Military expenditures - dollar figure: $29 million (1994)
Military expenditures - percent of GDP: 1% (1994)
Military branches: Army, Naval Command, Air and Air Defense Forces,
Militia
Military manpower - availability:
males age 15-49: 4,149,766 (1997 est.)
Military manpower - fit for military service:
males: 2,390,791 (1997 est.)
Military expenditures - dollar figure: $84 million (1994)
Military expenditures - percent of GDP: 5.3% (1994)','28af77e5bed9191f99ace7af3299383080f80a34a7348ba427da792f3ec8a0f0','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5951bb2d47c9cd1ae38a1f2fb9e8b828f7cee3418bd7e8e677cff3833f31c7f1',1997,'CK','Cook Islands','military-and-security',177,'Military - note: defense is the responsibility of New Zealand
Military - note: defense is the responsibility of Australia; visited
regularly by the Royal Australian Navy; Australia has control over the
activities of visitors','c4b57a57471a39e0ff5181a8409d7610848e1f3fee9b788968ca5e29dc15ec06','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35e340defa0621bba100b118b4b7947d3f6affa24d722e2a2455f3d0cf3f4cd',1997,'FR','France','military-and-security',182,'Military branches: Coast Guard, Air Section, Ministry of Public
Security Force (Fuerza Publica) note - during 1996, the Ministry of
Public Security reorganized and eliminated the Civil Guard, Rural
Assistance Guard, and Frontier Guards as separate entities; they are
now under the Ministry and operate on a geographic command basis
performing ground security, law enforcement, counternarcotics, and
national security (border patrol) functions; the Constitution
prohibits armed forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 940,666 (1997 est.)
Military manpower - fit for military service:
males: 631,426 (1997 est.)
Military manpower - reaching military age annually:
males : 34,422 (1997 est.)
Military expenditures - dollar figure: $55 million (1995)
Military expenditures - percent of GDP: 2% (1995)
Military branches: Army, Navy, Air Force, paramilitary Gendarmerie,
Presidential Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 3,478,429 (1997 est.)
Military manpower - fit for military service:
males: 1,811,508 (1997 est.)
Military manpower - reaching military age annually:
males: 164,364 (1997 est.)
Military expenditures - dollar figure: $140 million (1993)
Military expenditures - percent of GDP: 1.4% (1993)
Military branches: Army (includes Marines), Navy (includes Naval Air),
Air Force (includes Air Defense, National Gendarmerie
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,800,821 (1997 est.)
Military manpower - fit for military service:
males : 12,315,337 (1997 est.)
Military manpower - reaching military age annually:
males: 394,362 (1997 est.)
Military expenditures - dollar figure: $47.7 billion (1995)
Military expenditures - percent of GDP: 2.5% (1995)
Military - note: defense is the responsibility of the UK
Military - note: defense is the responsibility of the UK
Military - note: defense is the responsibility of the US','0f29750c03da301b9707c8b8babba2da47c9e7a0aa7dd3a905c5ae8a8679e1c1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffee5a345703926c0d798c5adf874856ee884ed1b871222117459909e094f89c',1997,'HR','Croatia','military-and-security',187,'Military branches: Ground Forces, Naval Forces, Air and Air Defense
Forces, Frontier Guard, Home Guard
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 1,190,814 (1997 est.)
Military manpower - fit for military service:
males: 946,063 (1997 est.)
Military manpower - reaching military age annually:
males: 35,464 (1997 est.)
Military expenditures - dollar figure: $1.56 billion (1996)
Military expenditures - percent of GDP: 10% (1996)','5293134d05ff1670b00a7a91cb5b9a106c8c56f12aa3eaed14caba24353e0b7a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f000dfd02de499cf98d6f0acf8b707a3b7284354af0d6d22c8d3babee181edd1',1997,'CU','Cuba','military-and-security',190,'Military branches: Revolutionary Armed Forces (FAR) includes ground
forces, Revolutionary Navy (MGR), Air and Air Defense Force (DAAFAR),
Territorial Troops Militia (MTT), and Youth Labor Army (EJT); Border
Guards (TGF), which are controlled by the Interior Ministry
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 3,053,716
females age 15-49: 3,007,277 (1997 est.)
Military manpower - fit for military service:
males : 1,896,023 (1997 est.)
females: 1,861,886 (1997 est.)
Military manpower - reaching military age annually:
males: 61,934
females: 58,648 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: roughly 4% (1995 est.)
Military - note: Moscow, for decades the key military supporter and
supplier of Cuba, cut off almost all military aid by 1993','fb3a398e43ff0f00a749358386d53b9c447fb95bf39da06c0054aea21659c77f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99289de478769bf2916d2010c4833a4142aa906b0b2a724d93142d3423504d4d',1997,'CY','Cyprus','military-and-security',193,'Military branches: Greek area: Greek Cypriot National Guard (GCNG;
includes air and naval elements); Hellenic Forces Regiment on Cyprus
(ELDYK); Greek Cypriot Police;, Turkish area: Turkish Cypriot Security
Force (TCSF), Turkish Forces Regiment on Cyprus (KTKA), Turkish
mainland army units
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 192,593 (1997 est.)
Military manpower - fit for military service:
males: 132,412 (1997 est.)
Military manpower - reaching military age annually:
males: 6,038 (1997 est.)
Military expenditures - dollar figure: $405 million (1996)
Military expenditures - percent of GDP: 5.4% (1996)
Military branches: Army, Air and Air Defense Forces, Civil Defense,
Railroad Units
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,715,759 (1997 est.)
Military manpower - fit for military service:
males: 2,068,143 (1997 est.)
Military manpower - reaching military age annually:
males : 84,516 (1997 est.)
Military expenditures - dollar figure: $1.22 billion (1996)
Military expenditures - percent of GDP: 2.2% (1996)','d28f3c44e397b17794b4f604450b83602ef509e0efdcc84c70b568d977b3844a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f81c6c2ce73691c8468d6ee018e2803ec587190a72450859b79ef109f38637',1997,'DK','Denmark','military-and-security',196,'Military branches: Royal Danish Army, Royal Danish Navy, Royal Danish
Air Force, Home Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1,333,279 (1997 est.)
Military manpower - fit for military service:
males : 1,146,099 (1997 est.)
Military manpower - reaching military age annually:
males: 33,532 (1997 est.)
Military expenditures - dollar figure: $2.9 billion (1997 est.)
Military expenditures - percent of GDP: 1.6% (1997 est.)','87a850ac2d6a864aae5559309ec9bc68f1555c4238b8e6d00d9016546fe67ece','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c725dc197498d0dc4d19f3fdfdbe26c6eab4ab17d640bfdcfe304783289f67ec',1997,'DJ','Djibouti','military-and-security',199,'Military branches: Djibouti National Army (includes Navy and Air
Force), National Security Force (Force Nationale de Securite),
National Police Force
Military manpower - availability:
males age 15-49: 103,569 (1997 est.)
Military manpower - fit for military service:
males : 60,751 (1997 est.)
Military expenditures - dollar figure: $26 million (1989)
Military expenditures - percent of GDP: NA%','03f98d09d7ae7389cff01113037ac062807526e3d7b98679a852ef9a426d1e19','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9750eac9ed76f7abbe6fb313f5bde44f41faca247ec1b5714e351e5f419ba7a8',1997,'DM','Dominica','military-and-security',202,'Military branches: Commonwealth of Dominica Police Force (includes
Special Service Unit, Coast Guard)
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','13e4f289ef3af9c380cf4585e2098a231a992329ad25319ee560448e0d4ccee2','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47fd4ac492b6f50b3dbfdcc8535e07b752aca140b28a44281ba0ad526a0c0e3d',1997,'DO','Dominican Republic','military-and-security',206,'Military branches: Army, Navy, Air Force, National Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,081,709 (1997 est.)
Military manpower - fit for military service:
males : 1,310,534 (1997 est.)
Military manpower - reaching military age annually:
males: 79,860 (1997 est.)
Military expenditures - dollar figure: $116 million (1994)
Military expenditures - percent of GDP: 1.4% (1994)
Military branches: Haitian National Police (PNH)
note: the regular Haitian Army, Navy, and Air Force have been
demobilized but still exist on paper until/unless constitutionally
abolished
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,430,855 (1997 est.)
Military manpower - fit for military service:
males: 774,835 (1997 est.)
Military manpower - reaching military age annually:
males: 71,003 (1997 est.)
Military expenditures - dollar figure: $NA; note - mainly for police
and security activities
Military expenditures - percent of GDP: NA%','eab2068d9db095ee20bff1ba4853a31024644b7f41b8cd31fbf6adb3175c28c0','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b04484da6a10c49b08bb156b70c592b884b98413284b009019913c0d0e68d6f4',1997,'EC','Ecuador','military-and-security',209,'Military branches: Army (Ejercito Ecuatoriano), Navy (Armada
Ecuatoriana, includes Marines), Air Force (Fuerza Aerea Ecuatoriana),
National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49 : 3,077,812 (1997 est.)
Military manpower - fit for military service:
males: 2,079,537 (1997 est.)
Military manpower - reaching military age annually:
males: 125,185 (1997 est.)
Military expenditures - dollar figure: $390.2 million (1996)
Military expenditures - percent of GDP: 2.1% (1996)','3500bd5f18d19814dae5fa529e30185fb0b5cb70cff2013f9716369d920c6b77','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('679b6b9696d3649d9b77427edd747f35589dd22feea5831b14ae4f36de303aca',1997,'MX','Mexico','military-and-security',213,'Military branches: Army, Navy, Air Force, Air Defense Command
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 16,942,953 (1997 est.)
Military manpower - fit for military service:
males: 10,987,037 (1997 est.)
Military manpower - reaching military age annually:
males: 672,197 (1997 est.)
Military expenditures - dollar figure: $3.28 billion (FY95/96)
Military expenditures - percent of GDP: 8.2% (FY95/96)
Military branches: Army, Navy, Air Force, National Gendarmerie,
National Guard, National Police, Presidential Guard
Military manpower - availability:
males age 15-49: 518,212 (1997 est.)
Military manpower - fit for military service:
males : 253,047 (1997 est.)
Military expenditures - dollar figure: $33 million (1995)
Military expenditures - percent of GDP: 2.5% (1995)
Military branches: National Defense (includes Army and Air Force),
Navy (includes Naval Air and Marines)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 24,518,142 (1997 est.)
Military manpower - fit for military service:
males: 17,857,361 (1997 est.)
Military manpower - reaching military age annually:
males : 1,062,640 (1997 est.)
Military expenditures - dollar figure: $1.56 billion (1997 est.)
Military expenditures - percent of GDP: 1.5% (1997 est.)','d7c0434c75139ad6aa387d41c402c01014982d8f07e73d24d0ceb0ad2e539a3e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c954d0aed218d0db1aae384904e9b33651c6eff4a8c6a6cd01967b4b5f8d68',1997,'SV','El Salvador','military-and-security',216,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,330,498 (1997 est.)
Military manpower - fit for military service:
males : 844,314 (1997 est.)
Military manpower - reaching military age annually:
males : 64,530 (1997 est.)
Military expenditures - dollar figure: $101 million (1996)
Military expenditures - percent of GDP: 0.9% (1996)','8ead300a92b74d884a75359dc7401eeb3b045745eaed4c39039d7ca25ebb16e6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebbee81397e690ffc020086e0cbaf10c20b0e6b839221828b6a2e735578044cc',1997,'NG','Nigeria','military-and-security',219,'Military branches: Army, Navy, Air Force, Rapid Intervention Force,
National Police
Military manpower - availability:
males age 15-49: 95,788 (1997 est.)
Military manpower - fit for military service:
males: 48,696 (1997 est.)
Military expenditures - dollar figure: $2.5 million (FY93/94)
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force, paramilitary Police Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 24,465,233 (1997 est.)
Military manpower - fit for military service:
males: 14,015,140 (1997 est.)
Military manpower - reaching military age annually:
males : 1,209,386 (1997 est.)
Military expenditures - dollar figure: $243 million (1995 est.)
Military expenditures - percent of GDP: less than 1% (1995 est.)','de8e4c52261d1d4527ee9c579df9c9d8495516a8a37f38a90a30016b4bcdc747','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('032e34a81fe41658aa786aa868fdcea8a236a8b76f7342499171f1ad962dbc26',1997,'SD','Sudan','military-and-security',224,'Military branches: Army, Navy, Air Force
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $40 million (1995)
Military expenditures - percent of GDP: NA%','30eeacbb4d731f76e47d912b86df5781db668ef8ad65367078bbbd949d818258','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb685d85cd66f7d270f347bf0c72ffb7ff1b6c14f4a673d526f5ce680391db45',1997,'EE','Estonia','military-and-security',228,'Military branches: Ground Forces, Navy/Coast Guard, Air and Air
Defense Force (not officially sanctioned), Maritime Border Guard,
Volunteer Defense League (Kaitseliit), Security Forces (internal and
border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 353,616 (1997 est.)
Military manpower - fit for military service:
males : 277,489 (1997 est.)
Military manpower - reaching military age annually:
males: 10,396 (1997 est.)
Military expenditures - dollar figure: $35 million (1995)
Military expenditures - percent of GDP: 1.5% (1995)','96cf0ebb5a9417a603fa627cc82c32fb922889386eb28772645d9f25fb4d0664','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08971efa21f16d2a84f8131a149452c8f335f0e4939b64565fd5650dc4c94bd2',1997,'ET','Ethiopia','military-and-security',230,'Military branches: Ground Forces, Air Force, Police
note: following the secession of Eritrea, Ethiopia''s naval facilities
remained in Eritrea''s possession; current reorganization plans do not
include a navy
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 13,257,668 (1997 est.)
Military manpower - fit for military service:
males: 6,889,800 (1997 est.)
Military manpower - reaching military age annually:
males: 605,030 (1997 est.)
Military expenditures - dollar figure: $110 million (1996)
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of France
Military branches: British Forces Falkland Islands (includes Army,
Royal Air Force, Royal Navy, and Royal Marines), Police Force
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the UK','5af0e9da24a7efe9f4de46957c15c3f1097c41e5486f0b21b8f28c3aa8cc100f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3af424fd7bc126ad45b409ebe63f822a4b4f9b4fc8e4760b96aa192c8efe125',1997,'NO','Norway','military-and-security',235,'Military branches: no organized native military forces; only a small
Police Force and Coast Guard are maintained
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of Denmark
Military branches: Norwegian Army, Royal Norwegian Navy (includes
Coast Artillery and Coast Guard), Royal Norwegian Air Force, Home
Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1,112,390 (1997 est.)
Military manpower - fit for military service:
males : 925,780 (1997 est.)
Military manpower - reaching military age annually:
males: 27,382 (1997 est.)
Military expenditures - dollar figure: $3.7 billion (1995)
Military expenditures - percent of GDP: 2.9% (1995)','416d38499f65a6e3cfe58b34ff263ba7cd6860e1d6d47f8a19dc36e3e013c2c7','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab3dc6b18ff4ed4822cd7d1b76b78357fac9722595b0aed27301e971fb202df',1997,'FJ','Fiji','military-and-security',238,'Military branches: Republic of Fiji Military Forces (RFMF; includes
army, navy, and a small air wing)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 210,048 (1997 est.)
Military manpower - fit for military service:
males : 115,766 (1997 est.)
Military manpower - reaching military age annually:
males: 8,986 (1997 est.)
Military expenditures - dollar figure: $32 million (1997)
Military expenditures - percent of GDP: 5% (1997)','d0f659a55ae4b42fc9c5f397e9db2b0b6a11727f133c887645c378c00fb8170f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc11d4260aede5130ca6f731888d52c130ca5e146f15bff25c01eff64cb499c7',1997,'FI','Finland','military-and-security',241,'Military branches: Army, Navy, Air Force, Frontier Guard (includes Sea
Guard)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49 : 1,298,576 (1997 est.)
Military manpower - fit for military service:
males: 1,068,503 (1997 est.)
Military manpower - reaching military age annually:
males: 32,985 (1997 est.)
Military expenditures - dollar figure: $1.9 billion (1995)
Military expenditures - percent of GDP: 1.6% (1995)','1fb9789c11bb5fd751f25fbacaaad50b04d491baec8cbf50c7603321062cf24f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bbe00ba532c06e09b4ef521c8ce5acc98cf4efea1bdfe7e71f30f202bae7a5d',1997,'GF','French Guiana','military-and-security',244,'Military branches: French Forces, Gendarmerie
Military manpower - availability:
males age 15-49: 44,799 (1997 est.)
Military manpower - fit for military service:
males: 29,033 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of France','c080d7035f9fbe66a5af3854b021eea46ec58d446c1d20283ebeb7a8f8be5db3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('730f5cfddfe969bcc2fd4bdc81571974c398b81f40a2f8a54dff67a27a251a7b',1997,'NR','Nauru','military-and-security',249,'Military branches: French Forces (includes Army, Navy, Air Force),
Gendarmerie
Military - note: defense is the responsibility of France
Military - note: defense is the responsibility of France
Military branches: no regular military forces; Police Force (carries
out law enforcement functions and paramilitary duties; small police
posts are on all islands)
Military manpower - availability:
males age 15-49 : NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Korean People''s Army (includes Army, Navy, Air
Force), Civil Security Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 6,928,338 (1997 est.)
Military manpower - fit for military service:
males : 4,188,070 (1997 est.)
Military manpower - reaching military age annually:
males: 200,136 (1997 est.)
Military expenditures - dollar figure: $5 billion to $7 billion (1995
est.)
Military expenditures - percent of GDP: 25% (1995 est.)
Military branches: Army, Navy, Air Force, Marine Corps, National
Maritime Police (Coast Guard)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 13,730,520 (1997 est.)
Military manpower - fit for military service:
males : 8,775,136 (1997 est.)
Military manpower - reaching military age annually:
males: 397,167 (1997 est.)
Military expenditures - dollar figure: $17.4 billion (1996)
Military expenditures - percent of GDP: 3.3% (1996)','605e273d21f4913b1b66a3d5c28d31d66b49424a3addc478c1358bab0d50307e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73ba12329b3a3fec4382bc3d0c18c15465302c63fc04c9d413d80c02ac223dc1',1997,'GA','Gabon','military-and-security',252,'Military branches: Army, Navy, Air Force, Republican Guard (charged
with protecting the president and other senior officials), National
Gendarmerie, National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 275,520 (1997 est.)
Military manpower - fit for military service:
males : 140,777 (1997 est.)
Military manpower - reaching military age annually:
males: 11,293 (1997 est.)
Military expenditures - dollar figure: $154 million (1993)
Military expenditures - percent of GDP: 2.4% (1993)','760ac9daea58b83c353d1352373c1b5590993ede808cc43fc2dc48fbb89df61c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55ca0d411a373c41372b8399f7a88a5bc8ec54cf43488d1524f9db04aa551451',1997,'GE','Georgia','military-and-security',257,'Military branches: Ground Forces, Navy, Air Force, Air Defense Forces,
National Guard, Republic Security Forces (internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,288,694 (1997 est.)
Military manpower - fit for military service:
males : 1,020,609 (1997 est.)
Military manpower - reaching military age annually:
males: 40,799 (1997 est.)
Military expenditures - dollar figure: 38.2 trillion coupons (1995);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%','5eb6cc1342cafed1adde6d0588aa6eb02e6c2856b192bb1d05a9c84a05a4bec3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb98baf240b183e984d557a0532e4674344cc315f13cba099506f19a447aeb4b',1997,'GH','Ghana','military-and-security',262,'Military branches: Army, Navy, Air Force, Police Force, Palace Guard,
Civil Defense
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 4,254,386 (1997 est.)
Military manpower - fit for military service:
males: 2,365,286 (1997 est.)
Military manpower - reaching military age annually:
males : 178,560 (1997 est.)
Military expenditures - dollar figure: $30 million (1994)
Military expenditures - percent of GDP: 0.8% (1994)','c5ffe5bf2906bcd7b9cdbb7e585a323e2a12bc43be27a36fbb524b6390c1844b','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ae01d5a97b2f69f2b5fd17094f4e06cb4401b9bb6c47088198c575849ab4ccb',1997,'GI','Gibraltar','military-and-security',265,'Military branches: British Army, Royal Navy, Royal Air Force
Military - note: defense is the responsibility of the UK
Military - note: defense is the responsibility of France
Military branches: Army, Navy, Air Force, Marines, Civil Guard,
National Police, Coastal Civil Guard
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 10,387,353 (1997 est.)
Military manpower - fit for military service:
males: 8,381,141 (1997 est.)
Military manpower - reaching military age annually:
males: 333,758 (1997 est.)
Military expenditures - dollar figure: $6.3 billion (1995)
Military expenditures - percent of GDP: 1.4% (1995)','4ffb251294b6d108da37862a485287de4895185f8dabf2e9a27e16312e4f477d','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('441236aacaa2f38c9c3a8011616423e44786c54bef6d8d8909672d59e3274f76',1997,'GR','Greece','military-and-security',268,'Military branches: Hellenic Army, Hellenic Navy, Hellenic Air Force,
National Guard, Police
Military manpower - military age: 21 years of age
Military manpower - availability:
males age 15-49: 2,677,826 (1997 est.)
Military manpower - fit for military service:
males : 2,050,740 (1997 est.)
Military manpower - reaching military age annually:
males : 80,102 (1997 est.)
Military expenditures - dollar figure: $4.9 billion (1995)
Military expenditures - percent of GDP: 4.6% (1995)','fc55500fcd98676979fa4505dc597b6d0187d4b2838b5475998c1324df85f301','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee22a571a3c22009ee19f1031895380391d5b9b5b4ab9f2c44cd43d0f046e5af',1997,'GL','Greenland','military-and-security',271,'Military manpower - military age: 16 years of age
Military manpower - reaching military age annually: 494
Military - note: defense is the responsibility of Denmark','c5146e4a7cc10aa3a100178b97af187c0cfcb0087b6c43f3ef9d973f042e06a6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c16a868fac375931b800a6e502781da7186041fb97ec9c8b307719f3c15797f',1997,'GD','Grenada','military-and-security',274,'Military branches: Royal Grenada Police Force, Coast Guard
Military manpower - availability:
males age 15-49 : NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','4dc41de497736a159130e38352e9429170e42693cb9a603d52b948b790658a81','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da6f0ec9dee7e05b219c421f6d09743c7d1c37c33930930db88aacfe20865ebb',1997,'GP','Guadeloupe','military-and-security',277,'Military branches: French Forces, Gendarmerie
Military - note: defense is the responsibility of France','0d306c27602589e57fb57fa7c8201bea385c78d6dbb120e2ec462f7ded1db796','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9056f6cf4e4ae67292fb85e5cc63eb614bd0b61347ff17f2ded2b47462642794',1997,'GN','Guinea','military-and-security',283,'Military branches: Army, Navy (acts primarily as a coast guard), Air
Force, Republican Guard, Presidential Guard, paramilitary National
Gendarmerie, National Police Force (Surete National)
Military manpower - availability:
males age 15-49: 1,684,999 (1997 est.)
Military manpower - fit for military service:
males: 850,053 (1997 est.)
Military expenditures - dollar figure: $50 million (1994)
Military expenditures - percent of GDP: 1.6% (1994)','74430148bde6238dddc4855da3c75eff4dc523173ae678b7f41433454b05be68','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d05eee481c7bf38ee8c0992a224e0914fd8b6ecca0ca74cab33a914fa1e1cd1',1997,'GW','Guinea-Bissau','military-and-security',286,'Military branches: People''s Revolutionary Armed Force (FARP; includes
Army, Navy, and Air Force), paramilitary force
Military manpower - availability:
males age 15-49 : 268,000 (1997 est.)
Military manpower - fit for military service:
males: 152,948 (1997 est.)
Military expenditures - dollar figure: $9 million (1994)
Military expenditures - percent of GDP: 4.5% (1994)','3f1b03d5dbd82032da4852aceb91e6d582b84dcb58b27984c56aea6b8dfe67ec','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a073ad36f5f0fb2aa58309526786414ce5b198df25eece8782625e09b1f3b6c7',1997,'GY','Guyana','military-and-security',289,'Military branches: Guyana Defense Force (GDF; includes Ground Forces,
Coast Guard, and Air Corps), Guyana People''s Militia (GPM), Guyana
National Service (GNS)
Military manpower - availability:
males age 15-49: 198,350 (1997 est.)
Military manpower - fit for military service:
males: 150,105 (1997 est.)
Military expenditures - dollar figure: $7 million (1994)
Military expenditures - percent of GDP: 1.7% (1994)','25be1782b4ffb2a3dff3e1bddad6b8b539f973438447cca83ac1ab4c417cb661','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2713c2c2025f2ed3b3a50c022cfc98cb48cd9d4149248da8efa62b2d949435b8',1997,'HM','Heard Island and McDonald Islands','military-and-security',293,'Military - note: defense is the responsibility of Australia
Military - note: defense is the responsibility of Italy; Swiss Papal
Guards are posted at entrances to Vatican City','af4e3e95998167ab32dc23fea0cdf5811fdefeaf9913048b6d8afe3024398e7f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('729e74833070145cccfe2110d13e7f1f55384f49cd3d4a5ffa0e0ca74d79b9ea',1997,'HN','Honduras','military-and-security',297,'Military branches: Army, Navy (includes Marines), Air Force, Public
Security Forces (FUSEP)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,370,116 (1997 est.)
Military manpower - fit for military service:
males: 816,054 (1997 est.)
Military manpower - reaching military age annually:
males : 66,304 (1997 est.)
Military expenditures - dollar figure: $42.5 million (1997)
Military expenditures - percent of GDP: about 1.5% (1997)','ca63ad27dc36258c91d36d434a5a85e46e6f722f9f4459c78f5ba1480234e365','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e0a50d43b7e6362d1644cd81b778a12438a204e61645eaa4c8af95179a8bf05',1997,'HK','Hong Kong','military-and-security',301,'Military branches: Headquarters of British Forces, Army, Royal Navy,
Royal Air Force, Royal Hong Kong Auxiliary Air Force, Royal Hong Kong
Police Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,884,488 (1997 est.)
Military manpower - fit for military service:
males: 1,427,567 (1997 est.)
Military manpower - reaching military age annually:
males: 46,601 (1997 est.)
Military expenditures - dollar figure: $207 million (FY92/93); note -
this represents 65% of the total cost of defending the colony, the
remainder being paid by the UK
Military expenditures - percent of GDP: 0.2% (FY92/93)
Military - note: defense is the responsibility of the UK until 1 July
1997, when China will assume command
Military - note: defense is the responsibility of the US; visited
annually by the US Coast Guard','3bc74f3d26d838255903b1328052cdc5b72518bf2c318d6eaabc8a4161246ce1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c85b2afd75a4fb3ed7586eb4c992571228d9133c23a1cfc524c671414d5548d',1997,'HU','Hungary','military-and-security',304,'Military branches: Ground Forces, Air and Air Defense Forces, Border
Guard, Territorial Defense
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 2,631,781 (1997 est.)
Military manpower - fit for military service:
males : 2,099,109 (1997 est.)
Military manpower - reaching military age annually:
males: 78,828 (1997 est.)
Military expenditures - dollar figure: $550 million (1996)
Military expenditures - percent of GDP: 1.5% (1996)','9c84d66c51a3212699a5b5c85d32b08e6268a6ddfad927fc3556ebef55405e03','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37525f50cca70c07a708db7760ead506553fb26a255a7b510b3f13100d2ef063',1997,'IS','Iceland','military-and-security',307,'Military branches: no regular armed forces; Police, Coast Guard; note
- Iceland''s defense is provided by the US-manned Icelandic Defense
Force (IDF) headquartered at Keflavik
Military manpower - availability:
males age 15-49: 70,833 (1997 est.)
Military manpower - fit for military service:
males: 62,601 (1997 est.)
Military expenditures - dollar figure: none','7ac667f7e383ffa4eedcad726d27c16cf98e60af20bb41bc5e5bc902a78f34ff','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e124a093e36ff1bc2026c5843570ff22bcbd961ca72225e8986d90dc66a1e2c',1997,'IN','India','military-and-security',310,'Military branches: Army, Navy, Air Force, various security or
paramilitary forces (includes Border Security Force, Assam Rifles, and
Coast Guard)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 258,172,895 (1997 est.)
Military manpower - fit for military service:
males : 151,693,072 (1997 est.)
Military manpower - reaching military age annually:
males: 10,465,427 (1997 est.)
Military expenditures - dollar figure: $8 billion (FY95/96)
Military expenditures - percent of GDP: 2.7% (FY95/96)
Military branches: National Security Service (paramilitary police
force)
Military manpower - availability:
males age 15-49 : 61,408 (1997 est.)
Military manpower - fit for military service:
males: 34,245 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','591336bfbe3f90ef8b7224b2d9730370fefb00dcb904f801a0209b10b33448e3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4db3409e7b6df4a782c6637153df8dccc66f9c0e67bacb9e9e1656d1aa086242',1997,'KW','Kuwait','military-and-security',315,'Military branches: Army, Republican Guard and Special Republican
Guard, Navy, Air Force, Air Defense Force, Border Guard Force,
Internal Security Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 5,039,332 (1997 est.)
Military manpower - fit for military service:
males : 2,825,888 (1997 est.)
Military manpower - reaching military age annually:
males: 246,404 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','08d0f8043f14bbe0fa3fc7c8b54edbd2f7ca5f438a9164e83cda22f428e44674','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94f0fc998d1844b82f573530ea9d02236165ab9603c2eabd0861a5cd638094e8',1997,'IE','Ireland','military-and-security',318,'Military branches: Army (includes Naval Service and Air Corps),
National Police (Garda Siochana)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 959,807 (1997 est.)
Military manpower - fit for military service:
males : 778,234 (1997 est.)
Military manpower - reaching military age annually:
males : 36,560 (1997 est.)
Military expenditures - dollar figure: $618 million (1994)
Military expenditures - percent of GDP: 1.3% (1994)
Military branches: Army, Royal Navy (includes Royal Marines), Royal
Air Force
Military manpower - availability:
males age 15-49: 13,829,704 (1997 est.)
Military manpower - fit for military service:
males : 11,527,058 (1997 est.)
Military expenditures - dollar figure: $35.1 billion (FY95/96)
Military expenditures - percent of GDP: 3.1% (FY95/96)','79ab9aedf5f632c06281b50777d7e133b20f829df13f46f3a703a13ec761ed56','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a600a27ad3d8c6ca4801de54f5d80171f320f906c9d43e655479db29a5b541bf',1997,'IL','Israel','military-and-security',323,'Military branches: Israel Defense Forces (includes ground, naval, and
air components), Pioneer Fighting Youth (Nahal), Frontier Guard, Chen
(women); note - historically there have been no separate Israeli
military services
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,420,066
females age 15-49 : 1,391,042 (1997 est.)
Military manpower - fit for military service:
males: 1,162,745 (1997 est.)
females: 1,134,610 (1997 est.)
Military manpower - reaching military age annually:
males: 50,744
females : 48,519 (1997 est.)
Military expenditures - dollar figure: $9.2 billion (1996)
Military expenditures - percent of GDP: about 9.8% (1996)','af1ab98a399cadd350e53a8d05f0896fc57d8cd887d48635394915bbf8baa43e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b044ab8e71b02de9e031ea9332b87429e57992ab1aa078736adc4e8d4ec8098',1997,'IT','Italy','military-and-security',326,'Military branches: Army, Navy, Air Force, Carabinieri
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 14,356,666 (1997 est.)
Military manpower - fit for military service:
males: 12,423,178 (1997 est.)
Military manpower - reaching military age annually:
males: 339,255 (1997 est.)
Military expenditures - dollar figure: $20.4 billion (1995)
Military expenditures - percent of GDP: 1.9% (1995)','1cac84b4543d74fec175e2963a19290d0152901564370b70858de2948fc594cc','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c230464c4f82adba2d1fd706e8ae35a2fae1d0ddac94193c245cf61b2eeb1b5',1997,'JM','Jamaica','military-and-security',329,'Military branches: Jamaica Defense Force (includes Ground Forces,
Coast Guard and Air Wing), Jamaica Constabulary Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 691,799 (1997 est.)
Military manpower - fit for military service:
males: 488,569 (1997 est.)
Military manpower - reaching military age annually:
males : 25,532 (1997 est.)
Military expenditures - dollar figure: $30 million (FY95/96)
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of Norway','5e41bf6ab644a140f0959d89bd83725128c1db7c4a394f47e1941deb3a9d3933','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b1355cafadb12f4391c614521cca9b20d39da0667602083e55a910e6c7cc821',1997,'JO','Jordan','military-and-security',333,'Military branches: Jordanian Armed Forces (JAF; includes Royal
Jordanian Land Force, Royal Naval Force, and Royal Jordanian Air
Force); Ministry of the Interior''s Public Security Force (falls under
JAF only in wartime or crisis situations)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,043,324 (1997 est.)
Military manpower - fit for military service:
males: 743,712 (1997 est.)
Military manpower - reaching military age annually:
males: 46,760 (1997 est.)
Military expenditures - dollar figure: $589 million (1996)
Military expenditures - percent of GDP: 8.2% (1996)
Military - note: defense is the responsibility of France
Military branches: Army, Navy, Air Force, Air Defense Force, National
Guard, Security Forces (internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 4,416,061 (1997 est.)
Military manpower - fit for military service:
males: 3,526,153 (1997 est.)
Military manpower - reaching military age annually:
males: 154,520 (1997 est.)
Military expenditures - dollar figure: 18.9 billion tenges (1995);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%','9251fc0843b520ffce9bece94f2dae6c6726253e42f1f9ff68730e59c9cc4a92','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae41fa341091e1c8cbd76cc8b84594bef2932e32ae098e8862b232c687ebe2f6',1997,'KE','Kenya','military-and-security',336,'Military branches: Army, Navy, Air Force, paramilitary General Service
Unit of the Police
Military manpower - availability:
males age 15-49 : 6,903,241 (1997 est.)
Military manpower - fit for military service:
males: 4,266,063 (1997 est.)
Military expenditures - dollar figure: $134 million (FY94/95)
Military expenditures - percent of GDP: 3.9% (FY94/95)
Military - note: defense is the responsibility of the US','4b1fb8630021f8c583a975ce704a6eef614403ec47b716a4ca82f310fcf41c3d','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c007433257865b5983e983ef95085c364ae657081d22b18d58a1d93dca7586b',1997,'SA','Saudi Arabia','military-and-security',340,'Military branches: Army, Navy, Air Force, National Guard, Ministry of
Interior Forces, Coast Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 663,032 (1997 est.)
Military manpower - fit for military service:
males: 393,541 (1997 est.)
Military manpower - reaching military age annually:
males: 18,340 (1997 est.)
Military expenditures - dollar figure: $3.5 billion (FY95/96)
Military expenditures - percent of GDP: 12.8% (FY95/96)
Military branches: Land Force (Army), Navy, Air Force, Air Defense
Force, National Guard, Coast Guard, Frontier Forces, Public Security
Force, Ministry of Interior Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 5,498,492 (1997 est.)
Military manpower - fit for military service:
males: 3,057,533 (1997 est.)
Military manpower - reaching military age annually:
males : 176,060 (1997 est.)
Military expenditures - dollar figure: $13.3 billion (1996 budget)
Military expenditures - percent of GDP: 10% (1996); note - based on
1996 budget figure','b3380ca04ceff732811abcccf0f7115958cd083d9df7b7c61cc3b35a5a05e8d4','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d5473f2103ed8bef34fa33d6335f87913dbd2bdf300da2e861ca5f2db5410c5',1997,'KG','Kyrgyzstan','military-and-security',343,'Military branches: Army, National Guard, Security Forces (internal and
border troops), Civil Defense
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,109,139 (1997 est.)
Military manpower - fit for military service:
males: 900,105 (1997 est.)
Military manpower - reaching military age annually:
males: 44,447 (1997 est.)
Military expenditures - dollar figure: 151 million soms (1995); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%
Military branches: Lao People''s Army (LPA; includes riverine naval and
militia elements), Air Force, National Police Department
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,123,934 (1997 est.)
Military manpower - fit for military service:
males: 606,542 (1997 est.)
Military manpower - reaching military age annually:
males : 54,712 (1997 est.)
Military expenditures - dollar figure: $105 million (FY92/93)
Military expenditures - percent of GDP: 8.1% (FY92/93)','ce8c0713785b517e59d1f60dd5aa26e75ed5fde233d90facd28642e68b78eaaf','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff09e0ed10fa57f7f93d56e4b25ae1406d450f13ca0e0863cee0d4a1f2e5df4b',1997,'LV','Latvia','military-and-security',346,'Military branches: Ground Forces, Navy, Air and Air Defense Forces,
Security Forces, Border Guard, Home Guard (Zemessardze)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 575,121 (1997 est.)
Military manpower - fit for military service:
males: 450,640 (1997 est.)
Military manpower - reaching military age annually:
males: 16,323 (1997 est.)
Military expenditures - dollar figure: 176 million rubles (1994); note
- conversion of defense expenditures into US dollars using the
prevailing exchange rate could produce misleading results
Military expenditures - percent of GDP: 3% to 5% (1994)','d01a529b30da95df9a0fbcfd4d3c9542d4b0d7732ea781165e2691569f956a7c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a073f4da73facdcebfe700b44b8f719019bd3d7250ddad35fc557c9fdd38581',1997,'LB','Lebanon','military-and-security',349,'Military branches: Lebanese Armed Forces (LAF; includes Army, Navy,
and Air Force)
Military manpower - availability:
males age 15-49 : 876,677 (1997 est.)
Military manpower - fit for military service:
males: 543,861 (1997 est.)
Military expenditures - dollar figure: $278 million (1994)
Military expenditures - percent of GDP: 5.5% (1994)','42c84cbf67083328f5d0c3b04bf858edd64c2f7370b971499e52ac60e43c7525','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f610dd5ed7cddd39718af2558adb40054bf4bac3d2063a1353bd10f2c87bde72',1997,'LS','Lesotho','military-and-security',353,'Military branches: Lesotho Defense Force (LDF; includes Army and Air
Wing), Lesotho Mounted Police
Military manpower - availability:
males age 15-49: 468,658 (1997 est.)
Military manpower - fit for military service:
males: 253,025 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','875322e6da7e7c812c53bfa848afc621530fa497b96718c2f0fabe91c7d31c84','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abf4b3261d34a36a1a80f1db791eb23454110845ff605b5827a37eb10ea8ab6b',1997,'LR','Liberia','military-and-security',356,'Military branches: NA; the ultimate structure of the Liberian military
force will depend on who is the victor in the ongoing civil war
Military manpower - availability:
males age 15-49 : 592,730 (1997 est.)
Military manpower - fit for military service:
males: 316,906 (1997 est.)
Military expenditures - dollar figure: $14 million (1993)
Military expenditures - percent of GDP: 2.9% (1993)','c0518b3cdd4aab0596b9a0c12bd062aa23de792791ef9b93e4265594494da2f1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5929f4857676b8e69413919bf655f4ceda514bc0a76f905be7c13ea54ca1bd2',1997,'LY','Libya','military-and-security',360,'Military branches: Army, Navy, Air and Air Defense Command
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49 : 1,211,700 (1997 est.)
Military manpower - fit for military service:
males: 721,592 (1997 est.)
Military manpower - reaching military age annually:
males: 59,216 (1997 est.)
Military expenditures - dollar figure: $1.4 billion (1994 est.)
Military expenditures - percent of GDP: 6.1% (1994 est.)','a92ee6094120f76397c6e16a90ba9679770656d020893002c79b520d776dc029','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e7eff47b69bd439b459eccf19b4c4ac89ee0dc8200ebbba9c9e2d1979c6dcbf',1997,'LT','Lithuania','military-and-security',365,'Military branches: Ground Forces, Navy, Air and Air Defense Force,
Security Forces (internal and border troops), National Guard (Skat)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 904,096 (1997 est.)
Military manpower - fit for military service:
males: 712,366 (1997 est.)
Military manpower - reaching military age annually:
males: 26,204 (1997 est.)
Military expenditures - dollar figure: $31.7 million (1996 est.)
Military expenditures - percent of GDP: 1% (1996 est.)','1285d29afe4b0e291d49576f64e2b9643566ff4bb014a84e2d1d2b5955b76824','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79b64f1b3a8fc415d000cee3c42f95d495bb408b1a819af9751e14cbe4eb9e41',1997,'LU','Luxembourg','military-and-security',368,'Military branches: Army, National Gendarmerie
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49 : 107,842 (1997 est.)
Military manpower - fit for military service:
males: 88,733 (1997 est.)
Military manpower - reaching military age annually:
males: 2,337 (1997 est.)
Military expenditures - dollar figure: $142 million (1995)
Military expenditures - percent of GDP: 0.8% (1995)
Military branches: NA
Military manpower - availability:
males age 15-49: 144,117 (1997 est.)
Military manpower - fit for military service:
males : 79,819 (1997 est.)
Military - note: defense is the responsibility of Portugal','63fc4139acdc86814817b14a5c6c4431b797c9c7ffa7389deb27a428f68ac066','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d3936900c2ea584c872202852209a81d40bad1f7273ca19dc7c317605256ed2',1997,'MW','Malawi','military-and-security',372,'Military branches: Army (includes Air Wing and Naval Detachment),
Police (includes paramilitary Mobile Force Unit)
Military manpower - availability:
males age 15-49: 2,163,056 (1997 est.)
Military manpower - fit for military service:
males: 1,106,487 (1997 est.)
Military expenditures - dollar figure: $10.4 million (FY94/95)
Military expenditures - percent of GDP: NA%','535cce0931f4f849df79fd0c56abc97627f8f5982cc794f568681a0741b58a20','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('027343b0f89aebe0ea6c191e9429d281adc7cb344e59397712107eba37a0d2af',1997,'ML','Mali','military-and-security',377,'Military branches: Army, Air Force, Gendarmerie, Republican Guard,
National Guard, National Police (Surete Nationale)
Military manpower - availability:
males age 15-49: 1,976,414 (1997 est.)
Military manpower - fit for military service:
males: 1,129,765 (1997 est.)
Military expenditures - dollar figure: $66 million (1994)
Military expenditures - percent of GDP: 2.2% (1994)','3010fddb943a1e5d4a9c17fc026786a9459591e27847202ae493ecf837bd090f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfd73a495fdad285d46ce6b429b0551df55c1d3e1a0bf2f56dcf2dca44ca62b3',1997,'MT','Malta','military-and-security',380,'Military branches: Armed Forces, Maltese Police Force
Military manpower - availability:
males age 15-49 : 99,032 (1997 est.)
Military manpower - fit for military service:
males: 78,710 (1997 est.)
Military expenditures - dollar figure: $65.5 million (FY96/97)
Military expenditures - percent of GDP: 2.7% (FY96/97)
Military - note: defense is the responsibility of the UK','b775b1d01006d5cc4cd59e468436daaa23fb64fcee38c155c74f360ff40a28fa','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82757a98b7efac911e95064782124ec90aae3b4e7b29fa37a9c873ab6f845073',1997,'MH','Marshall Islands','military-and-security',383,'Military branches: no regular military forces (a coast guard may be
established); Police Force
Military - note: defense is the responsibility of the US
Military branches: no regular armed forces; Directorate of the Nauru
Police Force
Military manpower - availability:
males age 15-49 : NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the US','6cd18bd3bf2fcaa874fa2c05ac8b21590f444fde0d6c5b790338c271bd547895','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13fa2e16c53a721b33d7e72fc2278a69780a967b93fc2596c0c3ce29c024e719',1997,'MQ','Martinique','military-and-security',386,'Military branches: French forces (Army, Navy, Air Force), Gendarmerie
Military - note: defense is the responsibility of France','15d24239e99ff16295ed57ddd6dc68eed551f56f756f2a60725a86196e3a9d61','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5f3115ce25c3271cf4f4cbf3a8287ac3851d7050e505dfc8069f29776926024',1997,'MG','Madagascar','military-and-security',389,'Military branches: National Police Force (includes the paramilitary
Special Mobile Force or SMF, Special Support Units or SSU, and
National Coast Guard)
Military manpower - availability:
males age 15-49: 333,029 (1997 est.)
Military manpower - fit for military service:
males : 169,129 (1997 est.)
Military expenditures - dollar figure: $11.2 million (FY92/93)
Military expenditures - percent of GDP: 0.4% (FY92/93)
Military branches: French forces (Army, Navy, Air Force, and
Gendarmerie)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 176,600 (1997 est.)
Military manpower - fit for military service:
males : 92,170 (1997 est.)
Military manpower - reaching military age annually:
males: 5,724 (1997 est.)
Military - note: defense is the responsibility of France
Military - note: defense is the responsibility of France','05ee0bf4f8c403430d90d733f1de65da62bb53453ba8512a91370e57ee37b9cb','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('460c9426b43fa93d87b8ee2dd04dd0c02a9328e66091734636a2bd8268006a61',1997,'FM','Micronesia, Federated States of','military-and-security',395,'Military - note: defense is the responsibility of the US
Military - note: defense is the responsibility of the US
Military branches: Ground Forces, Air and Air Defense Forces, Republic
Security Forces (internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,134,619 (1997 est.)
Military manpower - fit for military service:
males: 894,337 (1997 est.)
Military manpower - reaching military age annually:
males: 37,689 (1997 est.)
Military expenditures - dollar figure: 203 million lei (1995); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures - percent of GDP: NA%','663289b69dc290029afeee0afdbc364928d26d79a3644ba41cced42d24e2e3f6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a7a599cdda015c2040b350c8f400390fb228f603d720f6cbb8d87934ef77956',1997,'MN','Mongolia','military-and-security',400,'Military branches: Mongolian People''s Army (includes Internal Security
Forces and Frontier Guards), Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 659,173 (1997 est.)
Military manpower - fit for military service:
males: 430,482 (1997 est.)
Military manpower - reaching military age annually:
males: 27,723 (1997 est.)
Military expenditures - dollar figure: $22.8 million (1992)
Military expenditures - percent of GDP: 1% (1992)','524d22ca22e569cc5a507690532bb3d6149487865159de45e60244e053547c68','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('443e8d8fdae8c3ae57f77f194072f270fa45de13dd553fbb821a8891c302bf77',1997,'MS','Montserrat','military-and-security',403,'Military branches: Police Force
Military - note: defense is the responsibility of the UK','c5018db3d44f00e0fa4b3d582b6816410956d15bc9955cea464d9b6c9bd78bc2','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d26861e59b9ac7018494dd825b7c3ea9a53a56754f584043b2df398a1bef299',1997,'MA','Morocco','military-and-security',406,'Military branches: Royal Armed Forces (includes Army, Navy, Air Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 7,779,077 (1997 est.)
Military manpower - fit for military service:
males: 4,927,589 (1997 est.)
Military manpower - reaching military age annually:
males: 336,969 (1997 est.)
Military expenditures - dollar figure: $1.38 billion (1995)
Military expenditures - percent of GDP: 4.1% (1995)','db050142cea4885c6e090acc6a51b87b7be70f8a0f69c2e7b254daefa5bcf4b3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6afe2ff8f036209e643db7bdbe1644d71f70512a36a95f16c13c4191b31fa73',1997,'NA','Namibia','military-and-security',409,'Military branches: National Defense Force (Army), Police
Military manpower - availability:
males age 15-49: 392,228 (1997 est.)
Military manpower - fit for military service:
males: 233,336 (1997 est.)
Military expenditures - dollar figure: $64 million (FY95/96)
Military expenditures - percent of GDP: 2.1% (FY95/96)','385ecdb3368865da99ccb3417beaecd27cb25c99131b7809c557a1886b24a2ff','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a3b88b6048eee7fd67e402ce5ff9ce8bffa06331672acf85700c0a75362f33a',1997,'NP','Nepal','military-and-security',412,'Military branches: Royal Nepalese Army, Royal Nepalese Army Air
Service, Nepalese Police Force
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 5,556,791 (1997 est.)
Military manpower - fit for military service:
males: 2,888,628 (1997 est.)
Military manpower - reaching military age annually:
males: 268,085 (1997 est.)
Military expenditures - dollar figure: $36 million (FY92/93)
Military expenditures - percent of GDP: 1.2% (FY92/93)','4de246aca086372e3448d1119c102255f8eb330ff44fd812e52b056f4e98dc2f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f3eae4313c385f26514b44827195df8a7633654ad36cfb58b4266ab5946d239',1997,'NI','Nicaragua','military-and-security',416,'Military branches: Ground Forces, Navy, Air Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,027,630 (1997 est.)
Military manpower - fit for military service:
males: 632,433 (1997 est.)
Military manpower - reaching military age annually:
males : 49,552 (1997 est.)
Military expenditures - dollar figure: $27.48 million (1996)
Military expenditures - percent of GDP: 1.35% (1996)','80849bc4d50751a3478757ea71e7fd634a1ae4b90a76df7c5fd6644def43fc85','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f5a6e8b336ad2e037b074a3c255351897ff88a199d3a91491967d371346232c',1997,'NE','Niger','military-and-security',419,'Military branches: Army, Air Force, National Gendarmerie, Republican
Guard, National Police
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,983,377 (1997 est.)
Military manpower - fit for military service:
males: 1,069,743 (1997 est.)
Military manpower - reaching military age annually:
males : 95,217 (1997 est.)
Military expenditures - dollar figure: $32 million (FY92/93)
Military expenditures - percent of GDP: 1.3% (FY92/93)','03f1d5e20ebbc507a978a35bd4d58f6cefc56a563b0ed621a99e42a02c19af66','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6674e10cc99fe969c42f73ca030f9a8a32d66dc710e833eb70a56c78bab98305',1997,'NU','Niue','military-and-security',422,'Military branches: Police Force
Military - note: defense is the responsibility of New Zealand','ba7393af4a3e363544a99b96f0382947828cce1df77e7b8673685a5f87cb986c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55e669a99518dd3e8cdc4ad4025dd061f4f4ecbaecf9812008bc80da5946ca06',1997,'OM','Oman','military-and-security',428,'Military branches: Army, Navy, Air Force, paramilitary (includes Royal
Oman Police)
Military manpower - military age: 14 years of age
Military manpower - availability:
males age 15-49: 550,421 (1997 est.)
Military manpower - fit for military service:
males : 312,205 (1997 est.)
Military expenditures - dollar figure: $1.82 billion (1996)
Military expenditures - percent of GDP: 13.7% (1996)','f17835acdf8769e55ec198f58cd3bd55011db99fc295c2fa1dc196222a7feaec','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6d2696c5c1443c21ac7fac66cf1ade36b1bbd5d79c9f1d9b2a0a664df723889',1997,'PK','Pakistan','military-and-security',431,'Military branches: Army, Navy, Air Force, Civil Armed Forces, National
Guard
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 31,456,430 (1997 est.)
Military manpower - fit for military service:
males: 19,288,081 (1997 est.)
Military manpower - reaching military age annually:
males: 1,431,074 (1997 est.)
Military expenditures - dollar figure: $3.3 billion (FY96/97)
Military expenditures - percent of GDP: 5.3% (FY96/97)','e89f872d1af1eaab8b7a178c14e4284634ab25c6853c44debfa68a9515961468','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1d14a002fce938c2c094463a0832812d48c90a98a2548e8c38673900078162',1997,'PW','Palau','military-and-security',434,'Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the US
Military - note: defense is the responsibility of the US','157dd1d7aac3746875cfc006dcf769186576db3033f4b6135e4bb124bc4747f6','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('229a8b9e3fa8d5017e5e61986049fa4c7d50f8b794dbfc45f55a8dc03874cad3',1997,'PA','Panama','military-and-security',437,'Military branches: Panamanian Public Forces (PPF; includes the
National Police, National Maritime Service, National Air Service, and
Institutional Protective Service); Judicial Technical Police; note -
the Constitution prohibits armed forces
Military manpower - availability:
males age 15-49: 719,467 (1997 est.)
Military manpower - fit for military service:
males: 493,819 (1997 est.)
Military expenditures - dollar figure: $78 million (1995); note - for
police and security forces
Military expenditures - percent of GDP: NA%','0b8b9780000e1140964db6d127cb4c448fa9b5889c2cde8ef335afb7912b9296','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28289365c9a9e80f0ae66258c317db8701fdae836d2b910f6cf551226da5f7a6',1997,'PG','Papua New Guinea','military-and-security',440,'Military branches: Papua New Guinea Defense Force (includes Ground,
Naval, and Air Forces, and Special Forces Unit)
Military manpower - availability:
males age 15-49: 1,174,591 (1997 est.)
Military manpower - fit for military service:
males: 653,179 (1997 est.)
Military expenditures - dollar figure: $63 million (1997); note -
includes $12 million to cover leftover 1996 expenditures
Military expenditures - percent of GDP: NA
Military - note: occupied by China','e8fc6033c3a5044208f2c5b8ced9b760bcc9836122b0e707e7427ec95e5a9a46','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91030f245d0941e31fd79b6a630e2ea7c6788fe640053b0be1f611e0372165e5',1997,'PE','Peru','military-and-security',444,'Military branches: Army (Ejercito Peruano), Navy (Marina de Guerra del
Peru; includes Naval Air, Marines, and Coast Guard), Air Force (Fuerza
Aerea del Peru), National Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49 : 6,591,276 (1997 est.)
Military manpower - fit for military service:
males: 4,446,428 (1997 est.)
Military manpower - reaching military age annually:
males: 259,868 (1997 est.)
Military expenditures - dollar figure: $998 million (1996); note - may
not include off-budget purchases related to military modernization
program
Military expenditures - percent of GDP: 1.9% (1996)','d9708376f7788d6b4e8a4b56eec2fbd3bba3ab8d4bee4949f88449a873fa6130','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('799de1f4fcaf20188064ec39f19afddd4f35a6f3d3b04a5d5250f007b3329aba',1997,'PH','Philippines','military-and-security',447,'Military branches: Army, Navy (includes Coast Guard and Marine Corps),
Air Force
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 19,231,427 (1997 est.)
Military manpower - fit for military service:
males: 13,574,133 (1997 est.)
Military manpower - reaching military age annually:
males: 782,064 (1997 est.)
Military expenditures - dollar figure: $1.3 billion (1996)
Military expenditures - percent of GDP: 0.7% (1996)
Military - note: defense is the responsibility of the UK
Military - note: about 50 small islands or reefs are occupied by
China, Malaysia, the Philippines, Taiwan, and Vietnam','f5068fbf69a17486693f3a7e79e85d1491d8e045e1d18db74abea120991241ab','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f29723d9e2279f681a14116eb35b1016a36a30838301f4978efba0c0cacb99bf',1997,'PL','Poland','military-and-security',450,'Military branches: Army, Navy, Air and Air Defense Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 10,321,399 (1997 est.)
Military manpower - fit for military service:
males: 8,030,056 (1997 est.)
Military manpower - reaching military age annually:
males: 327,862 (1997 est.)
Military expenditures - dollar figure: $3.46 billion (1997)
Military expenditures - percent of GDP: 2.3% (1997)','e88bc8e32b8c4b391195048fe41820fd7747d38a5b0e714e835c6204e7e59b64','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b48a92d4b1c77d9442001b05bb2ee42546dcd8bdebe8a1f9ac6a579c3595be2',1997,'PT','Portugal','military-and-security',453,'Military branches: Army, Navy (includes Marines), Air Force, National
Republican Guard, Fiscal Guard, Public Security Police
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 2,543,502 (1997 est.)
Military manpower - fit for military service:
males: 2,049,806 (1997 est.)
Military manpower - reaching military age annually:
males: 80,494 (1997 est.)
Military expenditures - dollar figure: $2.07 billion (1996)
Military expenditures - percent of GDP: 1.9% (1996)','4aeba76d084622695092e7c96cb999f46ccbf42330b5393e19811a203c9d4849','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a12a283b868fc15d81e321042f664e6012ca7c56f42c425ad985acbbe75377d',1997,'PR','Puerto Rico','military-and-security',456,'Military branches: paramilitary National Guard, Police Force
Military - note: defense is the responsibility of the US','6ee49408fdc6fcd6af42d68aee6211eab032b71e27d066084f8885b96666ab02','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9098eec357a9ddb69c29aa79d5af5841ebdf6046939eb9309e16dc03514bac6',1997,'QA','Qatar','military-and-security',459,'Military branches: Army, Navy, Air Force, Public Security
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 286,178 (1997 est.)
Military manpower - fit for military service:
males: 150,398 (1997 est.)
Military manpower - reaching military age annually:
males: 5,432 (1997 est.)
Military expenditures - dollar figure: $400 million (1996 est.)
Military expenditures - percent of GDP: 3.5% (1996 est.)','aaacf1b977c90d3c97a2638612adac926a194019c9afe96d17f4e23a87a06e54','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40ef1cf10448ee678ab9a39abcfefc4a5b96f7f594dfdc0d265d6f4107930110',1997,'RO','Romania','military-and-security',462,'Military branches: Army, Navy, Air and Air Defense Forces,
Paramilitary Forces, Civil Defense
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 5,884,704 (1997 est.)
Military manpower - fit for military service:
males: 4,955,267 (1997 est.)
Military manpower - reaching military age annually:
males: 201,752 (1997 est.)
Military expenditures - dollar figure: $650 million (1996)
Military expenditures - percent of GDP: 2.5% (1996)
Military branches: Ground Forces, Navy, Air Forces, Air Defense
Forces, Strategic Rocket Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 38,449,126 (1997 est.)
Military manpower - fit for military service:
males : 29,996,967 (1997 est.)
Military manpower - reaching military age annually:
males: 1,115,858 (1997 est.)
Military expenditures - dollar figure: $NA
note : the Intelligence Community estimates that defense spending in
Russia fell by about 10% in real terms in 1996, reducing Russian
defense outlays to about one-sixth of peak Soviet levels in the late
1980s (1997 est.)
Military expenditures - percent of GDP: NA%','d37835b377eac4920485294995ac0708283dd8ff9c6600bc48cc343c5220c239','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6947bfe9eeee3d8e727f1af69a9a70a39ed0516aa515ec2b0d5e6861e752ba86',1997,'UG','Uganda','military-and-security',466,'Military branches: Army, Gendarmerie
Military manpower - availability:
males age 15-49: 1,806,832 (1997 est.)
Military manpower - fit for military service:
males: 920,343 (1997 est.)
Military expenditures - dollar figure: $112.5 million (1992)
Military expenditures - percent of GDP: 7% (1992)
Military - note: defense is the responsibility of the UK
Military branches: Army, Navy, Air Wing
Military manpower - availability:
males age 15-49: 4,466,851 (1997 est.)
Military manpower - fit for military service:
males: 2,423,556 (1997 est.)
Military expenditures - dollar figure: $56 million (FY93/94)
Military expenditures - percent of GDP: 1.7% (FY93/94)','a98efddff305e25918053606b693c578f8047a780bf4ca6069bdcb667fc70f51','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ce68524746e76783d7cedb6316a4f37b8f9bc78dd733fd143336ab4ea8a853d',1997,'KN','Saint Kitts and Nevis','military-and-security',470,'Military branches: Royal Saint Kitts and Nevis Police Force, Coast
Guard
Military manpower - availability:
males age 15-49 : NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','6bb506f636b959999adca843cdb42627b07d02c4d62e0ca21cc5355bb0dd73c8','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97bdf86db3ec1e33e40fd1e0f64212714e22f2d0f7dd6b71bbf4d093e2af44d1',1997,'VC','Saint Vincent and the Grenadines','military-and-security',474,'Military branches: Royal Saint Lucia Police Force, Coast Guard
Military manpower - availability:
males age 15-49 : NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $5 million (1991); note - for
police forces
Military expenditures - percent of GDP: 2% (1991)
Military branches: Royal Saint Vincent and the Grenadines Police
Force, Coast Guard
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','f3d564edd7beec1608733caa63395371440f4ac1b9a1a5b4b797d5a76841bad4','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c035c575577590ebed0045159a141fcbeba1343fe3f9f1757c7356363a5a2b12',1997,'SM','San Marino','military-and-security',479,'Military branches: Voluntary Military Force, Police Force
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $3.7 million (1995)
Military expenditures - percent of GDP: 1% (1995)','bd1915662e156b62a33acfedbf1da5fe46701195e491570b8a05b2b814c0bdc2','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b95861c5b37ef287b531f8edd6a9b87af5c81fc81d8f4214ccec68be9bbfe5a2',1997,'ST','Sao Tome and Principe','military-and-security',482,'Military branches: Army, Navy, Security Police
Military manpower - availability:
males age 15-49: 36,127 (1997 est.)
Military manpower - fit for military service:
males: 18,898 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','51b1b3dc1c8b8d14c3fb21d5e9f8a0e4ebb7682ef5e66fa1a2d17c11fd15f84e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e8bbaad4d74c63121e54e9174fa26d2915c4ac38115f3b8d375f3714c45f7c',1997,'SN','Senegal','military-and-security',484,'Military branches: Army, Navy, Air Force, National Gendarmerie,
National Police (Surete Nationale)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,938,693 (1997 est.)
Military manpower - fit for military service:
males: 1,012,181 (1997 est.)
Military manpower - reaching military age annually:
males: 94,397 (1997 est.)
Military expenditures - dollar figure: $81 million (1996 est.)
Military expenditures - percent of GDP: 2.1% (1996 est.)
Military branches: People''s Army (includes Ground Forces with internal
and border troops, Naval Forces, and Air and Air Defense Forces),
Civil Defense
Military manpower - military age: Montenegro - 19; Serbia - NA
Military manpower - availability:
males age 15-49: Montenegro - 187,041; Serbia - 2,734,293 (1997 est.)
Military manpower - fit for military service: Montenegro - 150,933
(1997 est.); Serbia - 2,191,041 (1997 est.)
Military manpower - reaching military age annually: Montenegro -
5,518; Serbia - NA (1997 est.)
Military expenditures - dollar figure: 6.5 billion dinars (1995 est.);
note - conversion of defense expenditures into US dollars using the
current exchange rate could produce misleading results
Military expenditures - percent of GDP: 24% (1995 est.)','1f4e2fd8bdaf3a16e69c25508dcd624766d8e3df9b5638f80debc1048c4f6817','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f87630446a998b9e8a2cd9715904b6bf1095dd5031263e87a3310138ad7eb6d',1997,'SC','Seychelles','military-and-security',487,'Military branches: Army, Coast Guard, Marines, National Guard,
Presidential Protection Unit, Police Force
Military manpower - availability:
males age 15-49: 21,860 (1997 est.)
Military manpower - fit for military service:
males : 11,030 (1997 est.)
Military expenditures - dollar figure: $13.7 million (1995)
Military expenditures - percent of GDP: NA%','3e1b0df664ed98e46b4ccd506e03dfa2a338375166eccc368fd8899299164941','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73a576edfdbc5f4ef2a628c6bd630d95c38b1696c9272f57d886ffe57fb92768',1997,'SL','Sierra Leone','military-and-security',491,'Military branches: Army, Navy, Police, Security Forces
Military manpower - availability:
males age 15-49 : 1,037,049 (1997 est.)
Military manpower - fit for military service:
males: 503,252 (1997 est.)
Military expenditures - dollar figure: $14 million (FY92/93)
Military expenditures - percent of GDP: 2.6% (FY92/93)','e996ebc47ccdc85a10f21f8400385f4a2a414de87b745b93bc624e1e7833e441','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00c8da46b311de4326ab88af7144a0c860bf0254c64e5e0facad5171c60b68ab',1997,'SG','Singapore','military-and-security',494,'Military branches: Army, Navy, Air Force, People''s Defense Force,
Police Force
Military manpower - availability:
males age 15-49: 1,034,380 (1997 est.)
Military manpower - fit for military service:
males: 756,649 (1997 est.)
Military expenditures - dollar figure: $3.64 billion (FY95/96)
Military expenditures - percent of GDP: 5.2% (FY95/96)
Military branches: Royal Thai Army, Royal Thai Navy (includes Royal
Thai Marine Corps), Royal Thai Air Force, Paramilitary Forces
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 17,076,040 (1997 est.)
Military manpower - fit for military service:
males : 10,315,765 (1997 est.)
Military manpower - reaching military age annually:
males: 591,094 (1997 est.)
Military expenditures - dollar figure: $4 billion (FY94/95)
Military expenditures - percent of GDP: 2.5% (FY94/95)','db55be336dc62cd32fe83c672c162e44a8421de9e49d646e9e8b3b8243abab1c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e078c1c369f3f0f8f99c18377542c71b771245648bb8e5065eeacd63c50e2172',1997,'SK','Slovakia','military-and-security',497,'Military branches: Army, Air and Air Defense Forces, Reserve Force
(Home Guards)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,462,052 (1997 est.)
Military manpower - fit for military service:
males : 1,118,955 (1997 est.)
Military manpower - reaching military age annually:
males: 48,245 (1997 est.)
Military expenditures - dollar figure: $423 million (1996)
Military expenditures - percent of GDP: 2.7% (1996)','440d228a84bfb114af36ab4229ac718f616d6f9d7ef35bc2b2f958946c0542d4','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea87884e4261fa453906a5bbc60a685547f54d4d6375cb169958dfd8cbb32646',1997,'SI','Slovenia','military-and-security',500,'Military branches: Slovene Defense Forces
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49 : 531,797 (1997 est.)
Military manpower - fit for military service:
males: 423,918 (1997 est.)
Military manpower - reaching military age annually:
males: 15,572 (1997 est.)
Military expenditures - dollar figure: $298 million (1996)
Military expenditures - percent of GDP: 1.5% to 1.7% (1996)','a3452623d824b70546fd0c91ebf24e4549961a1d447754427f81421c0fcb79ac','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6fc1f1380365ae6598b9d3b9492227a964ff631438fd30155b3b85c46be7ddf',1997,'SB','Solomon Islands','military-and-security',503,'Military branches: no regular military forces; Solomon Islands
National Reconnaissance and Surveillance Force; Royal Solomon Islands
Police (RSIP)
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','5eae48e88395781c1ce4bd8444feade37ea461b9a566b3c9db9907d0ad58b6a3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35a16ed4d919bcbc3593c0627de3ac34d91dacacbbfa148507f4f708945b8051',1997,'SO','Somalia','military-and-security',506,'Military branches: NA; note - no functioning central government
military forces; clan militias continue to battle for control of key
economic or political prizes
Military manpower - military age:
males: 1,615,598 years of age (1997 est.)
Military manpower - availability:
males age 15-49: 2,408,639 (1997 est.)
Military manpower - fit for military service:
males: 901,827 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','23219f7efeb5ce86f45e100ee6dbf332cc756eed91de84c6e7aa769f223f258a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('534ec6e14fd0edff5959b3720e72cb96394f3d22f6910e6ca5a41c47fda37d43',1997,'ZA','South Africa','military-and-security',509,'Military branches: South African National Defense Force or SANDF
(includes Army, Navy, Air Force, and Medical Services), South African
Police Service or SAPS
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 10,972,813 (1997 est.)
Military manpower - fit for military service:
males: 6,672,760 (1997 est.)
Military manpower - reaching military age annually:
males: 435,972 (1997 est.)
Military expenditures - dollar figure: $2.9 billion (FY95/96)
Military expenditures - percent of GDP: 2.2% (FY95/96)
Military - note: defense is the responsibility of the UK','f027680c298f5e030365561a55405ce72cb26ca1ddf8ea474df219a6bad68f25','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaac21ee760e1b3ff5344822b396c020a18a21294dfd7f2d9cb0a21b868e4838',1997,'LK','Sri Lanka','military-and-security',513,'Military branches: Army, Navy, Air Force, Police Force
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 5,066,744 (1997 est.)
Military manpower - fit for military service:
males : 3,946,315 (1997 est.)
Military manpower - reaching military age annually:
males: 184,619 (1997 est.)
Military expenditures - dollar figure: $736 million (1997)
Military expenditures - percent of GDP: 5.7% (1997)','7e81a50c2838bbb0bc94e88951e86cc40847fd23bddbe1d2f6421af4ec71ddb1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80755c6d2f46cf53a54e1b8350d895cf832e32cad7b7e9872f14813e06df9d25',1997,'ER','Eritrea','military-and-security',516,'Military branches: Army, Navy, Air Force, Popular Defense Force
Militia
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 7,437,363 (1997 est.)
Military manpower - fit for military service:
males: 4,576,117 (1997 est.)
Military manpower - reaching military age annually:
males: 341,516 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','09332a51f55dbefd756fa0419f0285cc11a20fdc61ba86b127295a9751545b3c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3002f641d631fa3c9baf61f2c63881515e446a99e1f47416ffb75892dda9dab',1997,'SR','Suriname','military-and-security',520,'Military branches: National Army (includes small Navy and Air Force
elements), Civil Police
Military manpower - availability:
males age 15-49: 121,618 (1997 est.)
Military manpower - fit for military service:
males: 71,811 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: demilitarized by treaty (9 February 1920)
Military branches: Umbutfo Swaziland Defense Force (Army), Royal
Swaziland Police Force
Military manpower - availability:
males age 15-49: 228,109 (1997 est.)
Military manpower - fit for military service:
males: 131,872 (1997 est.)
Military expenditures - dollar figure: $22 million (FY93/94)
Military expenditures - percent of GDP: NA%','9b2d19ff5cc71ef760364659585c0800cee6abd088aff52fb6e3f736dbfed07a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91ad3ea06517ab85fdf4fbebdfec2cfc178e7f15936d1221a70fad826bdaf905',1997,'SE','Sweden','military-and-security',523,'Military branches: Swedish Army, Royal Swedish Navy, Swedish Air Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 2,101,889 (1997 est.)
Military manpower - fit for military service:
males: 1,839,158 (1997 est.)
Military manpower - reaching military age annually:
males : 51,314 (1997 est.)
Military expenditures - dollar figure: $5.8 billion (FY94/95)
Military expenditures - percent of GDP: 2.5% (FY94/95)','427f6bafc6cc0096b406fab9cf680899a0bb5314142cf241d67ea3a908aa687f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5573550dc8161be057fc9e580d17c0c3e2ee79db1b847c125eddee772fd4bd',1997,'CH','Switzerland','military-and-security',526,'Military branches: Army, Air Force and Antiaircraft Command, Frontier
Guards, Fortification Guards
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 1,889,213 (1997 est.)
Military manpower - fit for military service:
males : 1,617,691 (1997 est.)
Military manpower - reaching military age annually:
males: 41,038 (1997 est.)
Military expenditures - dollar figure: $3.74 billion (1995)
Military expenditures - percent of GDP: 1.4% (1995)
Military branches: Syrian Arab Army, Syrian Arab Navy, Syrian Arab Air
Force, Syrian Arab Air Defense Forces, Police and Security Force
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 3,742,851 (1997 est.)
Military manpower - fit for military service:
males : 2,095,933 (1997 est.)
Military manpower - reaching military age annually:
males: 170,328 (1997 est.)
Military expenditures - dollar figure: $875 million (1994 est.); note
- based on official budget data that understate actual spending
Military expenditures - percent of GDP: 8% (1994 est.)','4b14c37785c8d18ec78ad38a9d7524902f0b613e899321700775efee070acd95','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f43668ee40a737a8132fedc5e07d603054d570f7fdebff784036044e5e1d213c',1997,'TJ','Tajikistan','military-and-security',528,'Military branches: Army, Air Force, Presidential National Guard,
Security Forces (internal and border troops)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 1,393,416 (1997 est.)
Military manpower - fit for military service:
males : 1,143,159 (1997 est.)
Military manpower - reaching military age annually:
males: 60,832 (1997 est.)
Military expenditures - dollar figure: 180 billion rubles (1995); note
- conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures - percent of GDP: 3.4% (1995)
Military branches: Tanzanian People''s Defense Force or TPDF (includes
Army, Navy, and Air Force), paramilitary Police Field Force Unit,
Militia
Military manpower - availability:
males age 15-49: 6,630,336 (1997 est.)
Military manpower - fit for military service:
males: 3,842,624 (1997 est.)
Military expenditures - dollar figure: $69 million (FY94/95)
Military expenditures - percent of GDP: NA%','6de0fd9057b2657d6fab96a910f536c3d8d57df634010319fb26765641c232f5','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0c51d2fc00d8b3cae0af66bf003f394570972c1f16f0bd1bfaf6f349ecaf5c6',1997,'TG','Togo','military-and-security',533,'Military branches: Army, Navy, Air Force, Gendarmerie
Military manpower - availability:
males age 15-49: 1,016,251 (1997 est.)
Military manpower - fit for military service:
males : 533,292 (1997 est.)
Military expenditures - dollar figure: $48 million (1993)
Military expenditures - percent of GDP: 2.9% (1993)','ab4c4a22991cc28aa16804ed8a6b0cc9bd28fc96fe5f36986d77b5b78b977aac','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95d378a7549ff21271b33ab8a61f5d48d0ae56e5c24781f80b07f9f6b28f9625',1997,'TO','Tonga','military-and-security',539,'Military branches: Tonga Defense Services (includes, Royal Tongan
Marines, Tongan Royal Guards, Maritime Force, Police); note - a new
Air Wing which will be subordinate to the Defense Ministry is being
developed
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','0dd8adf2801727e026383d771aa9cf66a76ff81f97b4390076ed60485c3ed390','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2515e581165111fa1ae6bf16a7aded98f335260918b53786af92e3ffc631c1af',1997,'TT','Trinidad and Tobago','military-and-security',542,'Military branches: Trinidad and Tobago Defense Force (includes Ground
Forces, Coast Guard, and Air Wing), Trinidad and Tobago Police Service
Military manpower - availability:
males age 15-49: 312,628 (1997 est.)
Military manpower - fit for military service:
males: 223,418 (1997 est.)
Military expenditures - dollar figure: $83 million (1994)
Military expenditures - percent of GDP: NA%','0578bc74255d8dd2d7b3ce24e418b44d0beaf1d0ee197e5781f9283b6afdd158','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b45c7c4e2ee3801f0dd2934ea98984851fa385c95cd4bfce1a001a5950fb21f',1997,'TN','Tunisia','military-and-security',545,'Military branches: Army, Navy, Air Force, paramilitary forces
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49 : 2,464,973 (1997 est.)
Military manpower - fit for military service:
males: 1,411,804 (1997 est.)
Military manpower - reaching military age annually:
males: 94,868 (1997 est.)
Military expenditures - dollar figure: $535 million (1995)
Military expenditures - percent of GDP: 2.8% (1995)
Military branches: Land Forces, Navy (includes Naval Air and Naval
Infantry), Air Force, Coast Guard, Gendarmerie
Military manpower - military age: 20 years of age
Military manpower - availability:
males age 15-49: 17,352,876 (1997 est.)
Military manpower - fit for military service:
males: 10,553,157 (1997 est.)
Military manpower - reaching military age annually:
males: 649,336 (1997 est.)
Military expenditures - dollar figure: $4.3 billion (1996); note -
figures do not include about $7 billion for the government''s
counterinsurgency effort
Military expenditures - percent of GDP: 3.5% (1996)','b15c05a41dd4b100ee3fd093c81b0c44bd213e8a41497e0ceca662222175ce1f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecc647854fe7c676e0d15d7056c45076233e9a2162431bdc6727513f2e2c5435',1997,'UA','Ukraine','military-and-security',549,'Military branches: Army, Navy, Air and Air Defense Forces, Internal
Troops, National Guard, Border Troops
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49: 12,408,912 (1997 est.)
Military manpower - fit for military service:
males: 9,720,351 (1997 est.)
Military manpower - reaching military age annually:
males: 366,086 (1997 est.)
Military expenditures - dollar figure: 1.35 billion hryvni (Ukrainian
Government''s forecast for 1996); note - conversion of defense
expenditures into US dollars using the current exchange rate could
produce misleading results
Military expenditures - percent of GDP: less than 2% (Ukrainian
Government''s forecast for 1996)','34e034866f2e42ce9da721a3c76ebfdee3eb5867314ae8825fd8511b0ff63e76','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e9127d2a8701ddc84a814304a6f18cf4ecd65838e62f7464da6a3f1ca3a2cae',1997,'AE','United Arab Emirates','military-and-security',552,'Military branches: Army, Navy, Air Force, paramilitary (includes
Federal Police Force)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 790,838 (1997 est.)
Military manpower - fit for military service:
males: 424,962 (1997 est.)
Military manpower - reaching military age annually:
males: 20,584 (1997 est.)
Military expenditures - dollar figure: $1.59 billion (1994)
Military expenditures - percent of GDP: 4.3% (1994)','08d7bbd6a07852a5cd75ea33264a32dd2e385ddd84ebaa9964c75c076db73fb1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3774d2d49a09844538a2ba5c0dc5c626d8b41065d1d15b9d2e6b1af36b1e158',1997,'US','United States','military-and-security',557,'Military branches: Department of the Army, Department of the Navy
(includes Marine Corps), Department of the Air Force
note: the Coast Guard falls under the Department of Transportation,
but in wartime reports to the Department of the Navy
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 69,414,007 (1997 est.)
Military manpower - fit for military service:
males: NA
Military manpower - reaching military age annually:
males: 1,864,580 (1996 est.)
Military expenditures - dollar figure: $267.2 billion (1997 est.)
Military expenditures - percent of GDP: 3.4% (1997 est.)','27d52cdc0733ec7fe1d4ec40bd542f57ae32f55c29da4d0caca2b48adee8aca3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc6249624b4dc52b949ab73be149180084cdbbfbf2af68a85c134e7eecfb5e27',1997,'UY','Uruguay','military-and-security',560,'Military branches: Army, Navy (includes Naval Air Arm, Coast Guard,
Marines), Air Force, Grenadier Guards, Coracero Guard, Police
Military manpower - availability:
males age 15-49 : 792,365 (1997 est.)
Military manpower - fit for military service:
males: 643,137 (1997 est.)
Military expenditures - dollar figure: $256 million (1994)
Military expenditures - percent of GDP: 1.5% (1994)','1088899c82129f6a021eb61ed53991bae71a0b9c96dda9bbdbff7121fd035281','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5048d7daa822c3af00fec415b82f2f165f51b328f9c02c78db236caf0c48251f',1997,'UZ','Uzbekistan','military-and-security',563,'Military branches: Army, Air and Air Defense, Security Forces
(internal and border troops), National Guard
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 5,833,862 (1997 est.)
Military manpower - fit for military service:
males: 4,748,539 (1997 est.)
Military manpower - reaching military age annually:
males: 239,978 (1997 est.)
Military expenditures - dollar figure: 164 million soms (1993); note -
conversion of defense expenditures into US dollars using the current
exchange rate could produce misleading results
Military expenditures - percent of GDP: 3.7% (1993)','c6f54bc47c4ab5e7b684444a2698fcbdbae7455d7d4faed3368d82df2f42c0a7','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dcf1853f81639d194402e4db0d68702e79beca4ef1fbffe7349d29616eb8188',1997,'VU','Vanuatu','military-and-security',566,'Military branches: no regular military forces; Vanuatu Police Force
(VPF; includes the paramilitary Vanuatu Mobile Force or VMF)
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','aca1b793799cf0aebe1c84123f925422c4bbaea14be501af87427e0b6572d64f','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c70bfce6dd2e1c68ebae898f8c24a4af79c50807fed36c91fde9e68f1cf1831e',1997,'NC','New Caledonia','military-and-security',569,'Military branches: National Armed Forces (Fuerzas Armadas Nacionales
or FAN) includes Ground Forces or Army (Fuerzas Terrestres or
Ejercito), Naval Forces (Fuerzas Navales or Armada), Air Force
(Fuerzas Aereas or Aviacion), Armed Forces of Cooperation or National
Guard (Fuerzas Armadas de Cooperacion or Guardia Nacional)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 5,997,099 (1997 est.)
Military manpower - fit for military service:
males: 4,333,497 (1997 est.)
Military manpower - reaching military age annually:
males: 238,650 (1997 est.)
Military expenditures - dollar figure: $902 million (1996)
Military expenditures - percent of GDP: 1.4% (1996)
Military branches: People''s Army of Vietnam (PAVN) (includes Ground
Forces, Navy, and Air Force)
Military manpower - military age: 17 years of age
Military manpower - availability:
males age 15-49: 19,172,473 (1996 est.)
Military manpower - fit for military service:
males: 12,123,118 (1997 est.)
Military manpower - reaching military age annually:
males : 802,154 (1997 est.)
Military expenditures - dollar figure: $544 million (1995)
Military expenditures - percent of GDP: 2.7% (1995)
Military - note: defense is the responsibility of the US
Military - note: defense is the responsibility of the US','fcac9bed8d85e5baf2fb4f16dfd0b2a20809824a94a8b66cc9b7ebeda69af9cc','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d55bda773c8a5606973f12ec4592fbd02b1c56ca23fc795a327325af5865a61f',1997,'WF','Wallis and Futuna','military-and-security',573,'Military - note: defense is the responsibility of France
Military branches: NA
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males : NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','eeef847f951ec505c80a69f3acb938d7911b5810f59384aa18c26fbfcb602d2a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f25e66a7bb3f423ae9667834b19e788d9f56fd8f0ba7f9e7e7d39a93be10d905',1997,'EH','Western Sahara','military-and-security',576,'Military branches: NA
Military manpower - availability:
males age 15-49 : NA
Military manpower - fit for military service:
males: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: no regular armed services; Western Samoa Police
Force
Military manpower - availability:
males age 15-49: NA
Military manpower - fit for military service:
males : NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: ground, maritime, and air forces at all levels of
technology
Military expenditures - dollar figure: aggregate real expenditure on
arms worldwide in 1996 remained at about the 1995 level, about
three-quarters of a trillion dollars in money terms (1996 est.)
Military expenditures - percent of GDP: roughly 2% of gross world
product (1996 est.)
______________________________________________________________________','11584a5ff4c6badd68d2e29fa7765b3880f3385cf2009d6c4c77a93288424243','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b191f03a23f3b75095987707bf53bef8fbce3bc6041864e846d7aeca293559d9',1997,'YE','Yemen','military-and-security',577,'@Yemen:Geography
Location: Middle East, bordering the Arabian Sea, Gulf of Aden, and
Red Sea, between Oman and Saudi Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen Arab Republic (YAR or
North Yemen), and the former People''s Democratic Republic of Yemen
(PDRY or South Yemen)
Area - comparative: slightly larger than twice the size of Wyoming
Land boundaries:
total: 1,746 km
border countries: Oman 288 km, Saudi Arabia 1,458 km
Coastline: 1,906 km
Maritime claims:
contiguous zone: 18 nm in the North; 24 nm in the South
continental shelf: 200 nm or to the edge of the continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: mostly desert; hot and humid along west coast; temperate in
western mountains affected by seasonal monsoon; extraordinarily hot,
dry, harsh desert in east
Terrain: narrow coastal plain backed by flat-topped hills and rugged
mountains; dissected upland desert plains in center slope into the
desert interior of the Arabian Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt, marble, small deposits
of coal, gold, lead, nickel, and copper, fertile soil in west
Land use:
arable land : 3%
permanent crops: 0%
permanent pastures: 30%
forests and woodland: 4%
other : 63% (1993 est.)
Irrigated land: 3,600 sq km (1993 est.)
Natural hazards: sandstorms and dust storms in summer
Environment - current issues: very limited natural fresh water
resources; inadequate supplies of potable water; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to : Biodiversity, Climate Change, Environmental Modification,
Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
Geography - note: controls Bab el Mandeb, the strait linking the Red
Sea and the Gulf of Aden, one of world''s most active shipping lanes
@Yemen:People
Population: 13,972,477 (July 1997 est.)
note: other estimates range as high as 16.6 million
Age structure:
0-14 years: 48% (male 3,421,216; female 3,237,594)
15-64 years : 49% (male 3,454,912; female 3,479,395)
65 years and over: 3% (male 162,600; female 216,760) (July 1997 est.)
Population growth rate: 3.57% (1997 est.)
Birth rate: 44.83 births/1,000 population (1997 est.)
Death rate: 9.17 deaths/1,000 population (1997 est.)
Net migration rate: 0 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years : 0.99 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.02 male(s)/female (1997 est.)
Infant mortality rate: 68.1 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 60.31 years
male : 58.9 years
female: 61.78 years (1997 est.)
Total fertility rate: 7.18 children born/woman (1997 est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; Afro-Arab concentrations in western
coastal locations; South Asians in southern regions; small European
communities in major metropolitan areas
Religions: Muslim including Sha''fi (Sunni) and Zaydi (Shi''a), small
numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 15 and over can read and write
total population: 38%
male: 53%
female: 26% (1990 est.)
@Yemen:Government
Country name:
conventional long form : Republic of Yemen
conventional short form: Yemen
local long form: Al Jumhuriyah al Yamaniyah
local short form: Al Yaman
Data code: YM
Government type: republic
National capital: Sanaa
Administrative divisions: 17 governorates (muhafazat, singular -
muhafazah); Abyan, Aden, Al Bayda, Al Hudaydah, Al Jawf, Al Mahrah, Al
Mahwit, Ataq, Dhamar, Hadhramaut, Hajjah, Ibb, Lahij, Ma''rib, Sa''dah,
San''a'', Ta''izz
note: there may be a new governorate for the capital city of Sanaa
Independence: 22 May 1990 Republic of Yemen was established on 22 May
1990 with the merger of the Yemen Arab Republic {Yemen (Sanaa) or
North Yemen} and the Marxist-dominated People''s Democratic Republic of
Yemen {Yemen (Aden) or South Yemen}; previously North Yemen had become
independent on NA November 1918 (from the Ottoman Empire) and South
Yemen had become independent on 30 November 1967 (from the UK)
National holiday: Proclamation of the Republic, 22 May (1990)
Constitution: 16 May 1991; amended 29 September 1994
Legal system: based on Islamic law, Turkish law, English common law,
and local tribal customary law; does not accept compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Lt. Gen. Ali Abdallah SALIH (since 22 May
1990, the former president of North Yemen, assumed office upon the
merger of North and South Yemen); Vice President Maj. Gen. Abd al-Rab
Mansur al-HADI (since NA October 1994)
head of government: Prime Minister Abd al-Aziz ABD AL-GHANI (since NA
October 1994); Deputy Prime Ministers Abd al-Wahhab al-ANISI (since NA
October 1994), Dr. Abd al-Karim Ali al-IRYANI (since NA October 1994),
Dr. Muhammad Said al-ATTAR (since NA October 1994), and Abd al-Qadir
al-BA JAMAL (since NA October 1994)
cabinet: Council of Ministers appointed by the president on the advice
of the prime minister
elections : president elected by the House of Representatives for a
five-year term; election last held 1 October 1994 (next to be held NA
1999); vice president appointed by the president; prime minister and
deputy prime ministers appointed by the president
election results: Ali Abdallah SALIH elected president; percent of
House of Representatives vote - NA
Legislative branch: unicameral House of Representatives (301 seats;
members elected by popular vote to serve four-year terms)
elections: last held 27 April 1997 (next to be held NA April 2001)
election results: percent of vote by party - NA; seats by party - GPC
189, Islaah 52, Nasserite Unionist Party 3, Baath Party 2,
independents 54, election pending 1
Judicial branch: Supreme Court
Political parties and leaders: there are over 12 political parties
active in Yemen, some of the more important are: General People''s
Congress (GPC), President Ali Abdallah SALIH; Yemeni Reform Grouping
or Islaah, Shaykh Abdallah bin Husayn al-AHMAR; Yemeni Socialist Party
(YSP), Ali Salih UBAYD; Nasserite Unionist Party, leader NA; Baath
Party, leader NA
note: following the May-July 1994 civil war, President SALIH''s General
People''s Congress and Shaykh Abdallah bin Husayn al-AHMAR''s Yemeni
Reform Grouping, or Islaah, formed a coalition government, but it is
unclear whether this coalition will continue in light of the GPC''s
landslide victory in the April 1997 legislative election; the YSP, a
loyal opposition party, boycotted the April 1997 legislative election
Political pressure groups and leaders: NA
International organization participation: ACC, AFESD, AL, AMF, CAEU,
CCC, ESCWA, FAO, G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat, Interpol, IOC, ISO (correspondent),
ITU, NAM, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO,
WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador (vacant)
chancery : Suite 705, 2600 Virginia Avenue NW, Washington, DC 20037
telephone: [1] (202) 965-4760, 4761
FAX: [1] (202) 337-2017
Diplomatic representation from the US:
chief of mission: Ambassador David G. NEWTON
embassy: Dhahr Himyar Zone, Sheraton Hotel District, Sanaa
mailing address : P. O. Box 22347, Sanaa
telephone: [967] (1) 238843 through 238852
FAX: [967] (1) 251563
Flag description: three equal horizontal bands of red (top), white,
and black; similar to the flag of Syria which has two green stars and
of Iraq which has three green stars (plus an Arabic inscription) in a
horizontal line centered in the white band; also similar to the flag
of Egypt which has a symbolic eagle centered in the white band
Military branches: Army, Navy, Air Force, paramilitary (includes
Police)
Military manpower - military age: 18 years of age
Military manpower - availability:
males age 15-49 : 3,109,553 (1997 est.)
Military manpower - fit for military service:
males: 1,753,779 (1997 est.)
Military manpower - reaching military age annually:
males: 148,864 (1997 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','464f970e0f1697d4e9afc93dcdf99967db145e529cf62fd81d086e5e2e4c461c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56382ebd0ebe46eb8a2f42ce6d250a31e49b2adadd83d506677dec1f8a392e61',1997,'ZM','Zambia','military-and-security',582,'Military branches: Army, Air Force, paramilitary forces, Police
Military manpower - availability:
males age 15-49: 1,990,403 (1997 est.)
Military manpower - fit for military service:
males: 1,051,227 (1997 est.)
Military expenditures - dollar figure: $96 million (1995)
Military expenditures - percent of GDP: 2.7% (1995)','1c988356ceed3bb93bf6549e6decc9f5612c1920067ac11b11578a564e668076','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aaa795836d19cc3764f79092ce0eb9f595150358252bfaf7d63afb4aae60471',1997,'ZW','Zimbabwe','military-and-security',586,'Military branches: Zimbabwe National Army, Air Force of Zimbabwe,
Zimbabwe Republic Police (includes Police Support Unit, Paramilitary
Police)
Military manpower - availability:
males age 15-49: 2,717,032 (1997 est.)
Military manpower - fit for military service:
males : 1,687,536 (1997 est.)
Military expenditures - dollar figure: $236 million (FY95/96)
Military expenditures - percent of GDP: 3.4% (FY95/96)
Military branches: Army, Navy (includes Marines), Air Force, Coastal
Patrol and Defense Command, Armed Forces Reserve Command, Combined
Service Forces
Military manpower - military age: 19 years of age
Military manpower - availability:
males age 15-49: 6,394,422 (1997 est.)
Military manpower - fit for military service:
males: 4,927,346 (1997 est.)
Military manpower - reaching military age annually:
males: 207,332 (1997 est.)
Military expenditures - dollar figure: $11.5 billion (FY96/97)
Military expenditures - percent of GDP: 3.6% (FY96/97)','b660fb56aa59e1bde4bbbe0636dccc1e15be049aa3ec3a2fde9a45eb256d81e3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

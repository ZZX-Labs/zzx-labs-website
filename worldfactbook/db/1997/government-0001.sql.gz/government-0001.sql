SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4e99cdbef580c5ad54fe71d5ba85ee8615a4c9a8421b9e3844036a71ec02f8b',1997,'TC','Turks and Caicos Islands','government',14,'National holiday: This entry gives the primary national day of
celebration--usually independence day.
Nationality: This entry provides the identifying terms for
citizens--noun and adjective.
Natural hazards: This entry lists potential natural disasters.
Natural resources: This entry lists a country''s mineral, petroleum,
hydropower, and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference
between the number of persons entering and leaving a country during
the year per 1,000 persons (based on midyear population). An excess of
persons entering the country is referred to as net immigration (e.g.,
3.56 migrants/1,000 population); an excess of persons leaving the
country as net emigration (e.g., -9.26 migrants/1,000 population). The
net migration rate indicates the contribution of migration to the
overall level of population change. High levels of migration can cause
problems such as increasing unemployment and potential ethnic strife
(if people are coming in) or reducing the labor force, perhaps in
certain key sectors (if people are leaving).
People: This category includes the entries dealing with the
characteristics of the people and their society.
People--note: This entry includes miscellaneous demographic
information of significance not included elsewhere.
Pipelines: This entry gives the lengths and types of pipelines for
transporting products like natural gas, crude oil, or petroleum
products.
Political parties and leaders: This entry includes a listing of
political organizations and their leaders.
Political pressure groups and leaders: This entry includes a listing
of organizations with leaders involved in politics, but not standing
for legislative election.
Population: This entry gives an estimate from the US Bureau of the
Census based on statistics from population censuses, vital statistics
registration systems, or sample surveys pertaining to the recent past,
and on assumptions about future trends. Starting with the 1993
Factbook, demographic estimates for some countries (mostly African)
have taken into account the effects of the growing incidence of AIDS
infections; in 1997 these countries were Botswana, Brazil, Burkina
Faso, Burundi, Cameroon, Central African Republic, Republic of the
Congo, Cote d''Ivoire, Ethiopia, Guyana, Haiti, Kenya, Lesotho, Malawi,
Nigeria, Rwanda, South Africa, Tanzania, Thailand, Uganda, Zaire which
is now known as Democratic Republic of the Congo, Zambia, and
Zimbabwe. The total population presents one overall measure of the
potential impact of the country on the world and within its region.
Population growth rate: The average annual percent change in the
population, resulting from a surplus (or deficit) of births over
deaths and the balance of migrants entering and leaving a country. The
rate may be positive or negative. Also known as growth rate or average
annual rate of growth. The growth rate is a factor in determining how
rapidly a country responds to the changing needs of its people in
terms of infrastructure (e.g., schools, hospitals, housing, roads),
resources (e.g., food, water, electricity), and jobs. Rapid population
growth can also be seen as threatening by neighboring countries.
Ports and harbors: This entry lists a few ports and harbors selected
on the basis of overall importance to each country. This is determined
by evaluating a number of factors (e.g., dollar value of goods
handled, gross tonnage, facilities, military significance).
Radio broadcast stations: This entry includes the total number of AM,
FM, and shortwave broadcast stations.
Radios: This entry gives the total number of radio receivers.
Railways: This entry includes the total length of the railway network
and component parts by gauge: broad, dual, narrow, standard, and
other.
Reference maps: This section includes world, regional, and special or
current interest maps.
Religions: This entry includes a rank ordering of religions starting
with the largest and sometimes includes the percent of total
population.
Sex ratio: This entry includes the number of males for each female in
five age groups-at birth, under 15 years, 15-64 years, 65 years and
over, and for the total population. Sex ratio at birth has recently
emerged as an indicator of certain kinds of sex discrimination in some
countries. For instance, high sex ratios at birth in some Asian
countries are now attributed to sex-selective abortion and infanticide
due to a strong preference for sons. This will affect future marriage
patterns and fertility patterns and could cause unrest among young
adult males who are unable to find partners. The sex ratio at birth
for the World is 1.06 (1997 est.).
Suffrage: This entry gives the age at enfranchisement and whether the
right to vote is universal or restricted.
Telephone numbers: All telephone numbers in the Factbook consist of
the country code in brackets, the city or area code (where required)
in parentheses, and the local number. The one component that is not
presented is the international access code which varies from country
to country. For example, an international direct dial telephone call
placed from the US to Madrid, Spain, would be as follows:
011 [34] (1) 577-xxxx where
011 is the international access code for station-to-station calls
(01 is for calls other than station-to-station calls),
[34] is the country code for Spain,
(1) is the city code for Madrid,
577 is the local exchange, and
xxxx is the local telephone number.
An international direct dial telephone call placed from another
country to the US would be as follows:
An international direct dial telephone call placed from another
country to the US would be as follows:
[1] is the country code for the US,
(202) is the area code for Washington, DC,
939 is the local exchange, and
xxxx is the local telephone number.
Telephone system: This entry includes a brief characterization of the
system with details on the domestic and international components. The
following terms and abbreviations are used throughout the entry:
Arabsat-Arab Satellite Communications Organization (Riyadh, Saudi
Arabia)
Autodin--Automatic Digital Network (US Department of Defense)
CB--citizen''s band mobile radio communications
cellular telephone system--the telephones in this system are radio
transceivers, each instrument having its own private radio frequency
with sufficient radiated power to reach the booster station in its
area (cell), from which the telephone signal is fed to a regular
telephone exchange
Central American Microwave System--a trunk microwave radio relay
system that links the countries of Central America and Mexico with
each other
coaxial cable--a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a
cylindrical conducting shell; a large number of telephone channels can
be made available within the insulated space by the use of a large
number of carrier frequencies
DSN--Defense Switched Network (formerly Automatic Voice Network or
Autovon); basic general--purpose, switched voice network of the
Defense Communications System (US Department of Defense)
Eutelsat--European Telecommunications Satellite Organization (Paris)
fiber-optic cable--a multichannel communications cable using a thread
of optical glass fibers as a transmission medium in which the signal
(voice, video, etc.) is in the form of a coded pulse of light
HF--high-frequency; any radio frequency in the 3,000- to 30,000-kHz
range
Inmarsat-International Mobile Satellite Organization (London);
provider of global mobile satellite communications for commercial and
distress and safety applications, at sea, in the air, and on land
Intelsat--International Telecommunications Satellite Organization
(Washington, DC)
Intersputnik--International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia
landline--communication wire or cable of any sort that is installed on
poles or buried in the ground
Marecs--Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency
Marisat--satellites of the Comsat Corporation that participate in the
Inmarsat system
Medarabtel--the Middle East Telecommunications Project of the
International Telecommunications Union (ITU), providing a modern
telecommunications network, primarily by microwave radio relay,
linking Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi
Arabia, Somalia, Sudan, Syria, Tunisia, and Yemen (initially started
in Morocco in 1970 by the Arab Telecommunications Union (ATU) and
known at that time as the Middle East Mediterranean Telecommunications
Network)
NMT--Nordic Mobile Telephone; an analog cellular telephone system that
was developed jointly by the national telecommunications authorities
of the Nordic countries (Denmark, Finland, Iceland, Norway, and
Sweden)
Orbita--a Russian television service; also the trade name of a
packet--switched digital telephone network
radiotelephone communications--the two--way transmission and reception
of sounds by broadcast radio on authorized frequencies using telephone
handsets
satellite communication system--a communication system consisting of
two or more earth stations and at least one satellite that provides
long distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system
satellite earth station--a communications facility with a microwave
radio transmitting and receiving antenna and required receiving and
transmitting equipment for communicating with satellites
satellite link--a radio connection between a satellite and an earth
station permitting communication between them, either one--way (down
link from satellite to earth station--television receive--only
transmission) or two-way (telephone channels)
SHF--super--high--frequency; any radio frequency in the 3,000- to
30,000-MHz range
SHF--super-high-frequency; any radio frequency in the 3,000- to
30,000-MHz range
Solidaridad-geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere
Statsionar--Russia''s geostationary system for satellite
telecommunications
submarine cable--a cable designed for service under water
TAT--Trans--Atlantic Telephone; any of a number of high--capacity
submarine coaxial telephone cables linking Europe with North America
telefax--facsimile service between subscriber stations via the public
switched telephone network or the international Datel network
telegraph--a telecommunications system designed for unmodulated
electric impulse transmission
telex--a communication service involving teletypewriters connected by
wire through automatic exchanges
tropospheric scatter--a form of microwave radio transmission in which
the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances
trunk network--a network of switching centers, connected by
multichannel trunk lines
UHF--ultra-high-frequency; any radio frequency in the 300- to
3,000-MHz range
VHF--very-high-frequency; any radio frequency in the 30- to 300-MHz
range
Telephones: This entry gives the total number of subscribers.
Television broadcast stations: This entry gives the total number of
separate broadcast stations plus any repeater stations.
Televisions: This entry gives the total number of television sets.
Terminology: Due to the highly structured nature of the Factbook
database, some collective generic terms have to be used. "Country
name" and "National capital", for example are used collectively to
include nations, dependent areas, uninhabited islands, areas of
special sovereignty, etc. The term "Military" is also used as an
umbrella term for various civil defense, security, and defense
activities.
Terrain: This entry contains a brief description of the topography.
Total fertility rate: This entry gives a figure for the average number
of children that would be born per woman if all women lived to the end
of their childbearing years and bore children according to a given
fertility rate at each age. The total fertility rate is a more direct
measure of the level of fertility than the crude birth rate, since it
refers to births per woman. This indicator shows the potential for
population growth in the country. High rates will also place some
limits on the labor force participation rates for women. Large numbers
of children born to women indicate large family sizes that might limit
the capacity of the families to educate their children.
Transnational Issues: This category includes only two entries at the
present time. Disputes--international and Illicit drugs--deal with
current issues going beyond national boundaries.
Transportation: This category includes the entries dealing with the
movement of people or material.
Transportation--note: This entry includes miscellaneous transportation
information of significance not included elsewhere.
Unemployment rate: This entry contains the percent of the labor force
that is without jobs. Substantial underemployment might be noted.
United Nations System: This information is presented in Appendix B:
United Nations System which is a chart, table, or text (depending on
the version of the Factbook) that shows the organization of the UN in
detail.
Waterways: This entry gives the total length and individual names of
navigable rivers, canals, and other inland bodies of water.
Weights and measures: This information is presented in Appendix E:
Weights and Measures which includes mathematical notations
(mathematical powers and names), metric interrelationships (prefix;
symbol; length, weight, or capacity; area; volume), and standard
conversion factors.
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY). The calendar year is an accounting
period of 12 months from 1 January to 31 December. The fiscal year is
an accounting period of 12 months other than 1 January to 31 December.
FY93/94 refers to the fiscal year that began in calendar year 1993 and
ended in calendar year 1994.
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates. The [2]Handbook of International Economic
Statistics, published annually in September by the Central
Intelligence Agency, contains detailed economic information for the
Organization for Economic Cooperation and Development (OECD)
countries, the successor nations to the Soviet Union, and selected
other countries. The Handbook can be obtained wherever the Factbook is
available.
References
1. http://www.odci.gov/cia/publications/hies97/index.htm
2. http://www.odci.gov/cia/publications/hies97/index.htm
______________________________________________________________________
GUIDE TO COUNTRY PROFILES (CATEGORIES, FIELDS AND SUBFIELDS)
Country name
conventional long form
conventional short form
local long form
local short form
former
Data code
Dependency status
Government type
National capital
Administrative divisions
Dependent areas
Independence
National holiday
Constitution
Legal system
Suffrage
Executive branch
chief of state
head of government
cabinet
elections
election results
Legislative branch
elections
election results
Judicial branch
Political parties and leaders
Political pressure groups and leaders
International organization participation
Diplomatic representation in the US
chief of mission
chancery
telephone
FAX
consulate(s) general
consulate(s)
honorary consulate(s)
honorary consulate(s) general
Diplomatic representation from the US
chief of mission
embassy
branch office
mailing address
telephone
FAX
consulate(s) general
consulate(s)
Flag description
Government--note','1bbd6fca0fea52e51841672e33e46c7ef3011bfc3533e7ea131348a36a0856c3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e05b41047f4f52579dab3a5f3c1c9b8f47d675ff41471f1970ae91724a97baa',1997,'CL','Chile','government',154,'head of government : President Eduardo FREI Ruiz-Tagle (since 11 March
1994); note - the president is both the chief of state and head of
cabinet: Cabinet appointed by the president
elections: president elected by popular vote for a six-year term;
election last held 11 December 1993 (next to be held NA December 1999)
election results: Eduardo FREI Ruiz-Tagle elected president; percent
of vote - Eduardo FREI Ruiz-Tagle (PDC) 58%, Arturo ALESSANDRI 24.4%,
other 17.6%
Legislative branch: bicameral National Congress or Congreso Nacional
consists of the Senate or Senado (46 seats, 38 elected by popular
vote; members serve eight-year terms - one half elected every four
years) and the Chamber of Deputies or Camara de Diputados (120 seats;
members are elected by popular vote to serve four-year terms)
elections : Senate - last held 11 December 1993 (next to be held NA
December 1997); Chamber of Deputies - last held 11 December 1993 (next
to be held NA December 1997)
election results: Senate - percent of vote by party - NA; seats by
party - Coalition of Parties for Democracy 21 (PDC 13, PS 4, PPD 3, PR
1), Union for the Progress of Chile 15 (RN 11, UDI 3, UCC 1),
right-wing independents 2; Chamber of Deputies - percent of vote by
party - Coalition of Parties for Democracy 53.95% (PDC 27.16%, PS
12.01%, PPD 11.82%, PR 2.96%), Union for the Progress of Chile 30.57%
(RN 15.25%, UDI 12.13%, UCC 3.19%); seats by party - Coalition of
Parties for Democracy 70 (PDC 37, PPD 15, PR 2, PS 15, left-wing
independent 1), Union for the Progress of Chile 47 (RN 30, UDI 15, UCC
2), right-wing independents 3; note - subsequent to the election, the
Radical Party (PR) became the Radical Social Democratic Party (PRSD)
Judicial branch: Supreme Court (Corte Suprema), judges are appointed
by the president, the president of the Supreme Court is elected by the
17-member court
Political parties and leaders: Coalition of Parties for Democracy or
CPD consists mainly of: Christian Democratic Party or PDC [Enrique
KRAUSS]; Socialist Party or PS [Camilo ESCALONA]; Party for Democracy
or PPD [Sergio BITAR]; Radical Social Democratic Party or PRSD
[Anselmo SULE]; Union for the Progress of Chile or UPP consists mainly
of three parties: National Renewal or RN [Alberto ESPINA]; Independent
Democratic Union or UDI [Jovino NOVOA]; Center Center Union or UCC
[Francisco Javier ERRAZURIZ]
Political pressure groups and leaders: revitalized university student
federations at all major universities; labor - United Labor Central or
CUT includes trade unionists from the country''s five largest labor
confederations; Roman Catholic Church
International organization participation: APEC, CCC, ECLAC, FAO, G-11,
G-77, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, IOM, ISO, ITU,
LAES, LAIA, NAM, OAS, OPANAL, PCA, RG, UN, UN Security Council
(temporary), UNCTAD, UNESCO, UNIDO, UNITAR, UNMOGIP, UNTSO, UNU, UPU,
WCL, WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador John BIEHL Del Rios
chancery: 1732 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 785-1746
FAX: [1] (202) 887-5579
consulate(s) general : Boston, Chicago, Houston, Los Angeles, Miami,
New York, Philadelphia, San Francisco, and San Juan (Puerto Rico)
Diplomatic representation from the US:
chief of mission: Ambassador Gabriel GUERRA-MONDRAGON
embassy: Avenida Andres Bello 2800, Santiago
mailing address : APO AA 34033
telephone: [56] (2) 232-2600
FAX: [56] (2) 330-3710
Flag description: two equal horizontal bands of white (top) and red;
there is a blue square the same height as the white band at the
hoist-side end of the white band; the square bears a white
five-pointed star in the center; design was based on the US flag','de005637871405390abae113465b0c39d4772e9dd2fd8f5a8a0855ced459145b','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b2a3d4a4cbe5e2a480d12bfb1bd2fd4b2da8826336b27b65e779e6121b908ad',1997,'CO','Colombia','government',167,'head of government: President Ernesto SAMPER Pizano (since 7 August
1994); note - the president is both the chief of state and head of
cabinet: Cabinet
elections : president elected by popular vote for a four-year term;
election last held 29 May 1994 (next to be held May 1998); vice
president elected by popular vote for a four-year term in a new
procedure that replaces the traditional designation of vice presidents
by newly elected presidents
election results : Ernesto SAMPER Pizano elected president; percent of
vote - no candidate received more than 50% of the total vote,
therefore, a run-off election to select a president from the two
leading candidates was held 19 June 1994; percent of vote - Ernesto
SAMPER Pizano (Liberal Party) 50.4%, Andres PASTRANA Arango
(Conservative Party) 48.6%, blank votes 1%; Humberto de la CALLE
Lombana elected vice president; percent of vote - NA
Legislative branch: bicameral Congress or Congreso consists of the
Senate or Senado (102 seats; members are elected by popular vote to
serve four-year terms) and the House of Representatives or Camara de
Representantes (161 seats; members are elected by popular vote to
serve four-year terms)
elections: Senate - last held 13 March 1994 (next to be held March
1998); House of Representatives - last held 13 March 1994 (next to be
held March 1998)
election results: Senate - percent of vote by party - NA; seats by
party - Liberal Party 59, conservatives (includes PC, MSN, and NDF)
31, other 12; House of Representatives - percent of vote by party -
NA; seats by party - Liberal Party 89, conservatives (includes PC,
MSN, and NDF) 53, AD/M-19 2, other 17
Judicial branch: Supreme Court of Justice (Corte Suprema de Justical),
highest court of criminal law, judges are selected from the nominees
of the Higher Council of Justice for eight-year terms; Council of
State, highest court of administrative law, judges are selected from
the nominees of the Higher Council of Justice for eight-year terms;
Constitutional Court, guards integrity and supremacy of the
constitution, rules on constitutionality of laws, amendments to the
constitution, and international treaties
Political parties and leaders: Liberal Party or PL [Emilio LEBOLO
Castellanos]; Conservative Party or PC [Fabio VALENCIA Cossio]; New
Democratic Force or NDF [Andres PASTRANA Arango]; Democratic Alliance
M-19 or AD/M-19 is a coalition of small leftist parties and dissident
liberals and conservatives; Patriotic Union (UP) is a legal political
party formed by Revolutionary Armed Forces of Colombia (FARC) and
Colombian Communist Party (PCC); National Salvation Movement or MSN
[Dr. Alvaro GOMEZ Hurtado]
Political pressure groups and leaders: two largest insurgent groups
active in Colombia - Revolutionary Armed Forces of Colombia or FARC;
and National Liberation Army or ELN
International organization participation: AG, CCC, CDB, ECLAC, FAO, G-
3, G-11, G-24, G-77, IADB, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA,
IFAD, IFC, IFRCS, IHO (pending member), ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, IOM, ISO, ITU, LAES, LAIA, NAM, OAS, OPANAL,
PCA, RG, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNU, UPU, WCL, WFTU, WHO,
WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Juan Carlos ESGUERRA Portocarrero
chancery: 2118 Leroy Place NW, Washington, DC 20008
telephone: [1] (202) 387-8338
FAX: [1] (202) 232-8643
consulate(s) general: Boston, Chicago, Houston, Los Angeles, Miami,
New Orleans, New York, San Francisco, San Juan (Puerto Rico), and
Washington, DC
consulate(s): Atlanta and Tampa
Diplomatic representation from the US:
chief of mission: Ambassador Myles R. R. FRECHETTE
embassy: Calle 22D-BIS, No. 47-51, Apartado Aereo 3831
mailing address : APO AA 34038
telephone: [57] (1) 315-0811
FAX: [57] (1) 315-2197
Flag description: three horizontal bands of yellow (top,
double-width), blue, and red; similar to the flag of Ecuador, which is
longer and bears the Ecuadorian coat of arms superimposed in the
center','55c202a3d5cd416d59ddc9040b4cfe1e82d6fe2ea90a0d0908870e445693150c','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('492cc59e9af407a03b8a378e4b7ae8bb502c3cf89ee9349f9ac5e9eb67a26211',1997,'CR','Costa Rica','government',179,'head of government: President Jose Maria FIGUERES Olsen (since 8 May
1994); First Vice President Rodrigo OREAMUNO Blanco (since 8 May
1994), Second Vice President Rebeca GRYNSPAN Mayufis (since 8 May
1994); note - president is both the chief of state and head of
cabinet: Cabinet selected by the president
elections: president and vice presidents elected on the same ticket by
popular vote for four-year terms; election last held 6 February 1994
(next to be held NA February 1998)
election results : Jose Maria FIGUERES Olsen elected president;
percent of vote - Jose Maria FIGUERES Olsen (PLN) 49.7%, Miquel Angel
RODRIGUEZ (PUSC) 47.5%
Legislative branch: unicameral Legislative Assembly or Asamblea
Legislativa (57 seats; members are elected by direct popular vote to
serve four-year terms)
elections: last held 6 February 1994 (next to be held NA February
1998)
election results: percent of vote by party - NA; seats by party - PLN
28, PUSC 25, minority parties 4
Judicial branch: Supreme Court (Corte Suprema), justices are elected
for eight-year terms by the Legislative Assembly
Political parties and leaders: National Liberation Party or PLN
[Rolando ARAYA]; Social Christian Unity Party or PUSC [Rafael Angel
CALDERON Fournier]; National Integration Party or PIN [Walter MUNOZ];
National Agrarian Party or PAN; People''s Party of Costa Rica or PPC
[Lenin CHACON Vargas]; Agricultural Union Party or PUAC [Juan
Guillermo BRENES Castillo]; Democratic Force Party or FD [Isaac Felipe
AZOFEIFA Bolanos]; People United [Humberto VARGAS Carbonell];
Patriotic Front Party; New Democratic Party or PDN [Rodrigo
GUTIERREZ)]
Political pressure groups and leaders: Costa Rican Confederation of
Democratic Workers or CCTD (Liberation Party affiliate); Confederated
Union of Workers or CUT (Communist Party affiliate); Authentic
Confederation of Democratic Workers or CATD (Communist Party
affiliate); Chamber of Coffee Growers; National Association for
Economic Development or ANFE; Free Costa Rica Movement or MCRL
(rightwing militants); National Association of Educators or ANDE;
Federation of Public Service Workers or FTSP
International organization participation: AG (observer), BCIE, CACM,
ECLAC, FAO, G-77, IADB, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, IOM, ISO,
ITU, LAES, LAIA (observer), NAM (observer), OAS, OPANAL, UN, UN
Security Council (temporary), UNCTAD, UNESCO, UNIDO, UNU, UPU, WCL,
WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Sonia PICADO
chancery: 2114 S Street NW, Washington, DC 20008
telephone: [1] (202) 234-2945
FAX: [1] (202) 265-4795
consulate(s) general : Albuquerque, Atlanta, Chicago, Durham, Houston,
Los Angeles, Miami, New Orleans, New York, Philadelphia, San Antonio,
San Diego, San Francisco, San Juan (Puerto Rico), and Tampa
consulate(s): Austin
Diplomatic representation from the US:
chief of mission: Ambassador Peter Jon DE VOS
embassy: Pavas Road, San Jose
mailing address: APO AA 34020
telephone: [506] 220-3939
FAX: [506] 220-2305
Flag description: five horizontal bands of blue (top), white, red
(double width), white, and blue, with the coat of arms in a white disk
on the hoist side of the red band','5a86d0e45166be6a1fb980f3223b32692b1426335fec1e5a14c5d91b71b7dc3a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4deb2ae1f8238943b28cb4606794a2848ba6254d4900be840bbf4dfe193f3aa8',1997,'DO','Dominican Republic','government',204,'head of government : President Leonel FERNANDEZ Reyna (since 16 August
1996); Vice President Jaime David FERNANDEZ Mirabal (since 16 August
1996); note - the president is both the chief of state and head of
cabinet: Cabinet nominated by the president
elections: president and vice president elected on the same ticket by
popular vote for four-year term; election last held 16 May 1996;
runoff election held 30 June 1996 (next to be held 16 May 2000)
election results: President FERNANDEZ elected to his first term;
percent of vote - Leonel FERNANDEZ (PLD) 51.25%, Jose Francisco PENA
Gomez (PRD) 48.75%
Legislative branch: bicameral National Congress or Congreso Nacional
consists of the Senate or Senado (30 seats; members are elected by
popular vote to serve four-year terms) and the Chamber of Deputies or
Camara de Diputados (120 seats; members are elected by popular vote to
serve four-year terms)
elections: Senate - last held 30 May 1994 (next to be held NA May
1998); Chamber of Deputies - last held 16 May 1994 (next to be held NA
May 1998)
election results: Senate - percent of vote by party - NA; seats by
party - PRSC 15, PLD 1, PRD 14; Chamber of Deputies - percent of vote
by party - NA; seats by party - PLD 13, PRSC 50, PRD 57
Judicial branch: Supreme Court (Corte Suprema), judges are elected by
a Council made up of legislative and executive members with the
president presiding
Political parties and leaders:
major parties: Social Christian Reformist Party or PRSC [Joaquin
BALAGUER Ricardo]; Dominican Liberation Party or PLD [Lidio CADET];
Dominican Revolutionary Party or PRD [Jose Franciso PENA Gomez];
Independent Revolutionary Party or PRI
minor parties: National Veterans and Civilian Party or PNVC [Juan Rene
BEAUCHAMPS Javier]; Liberal Party of the Dominican Republic or PLRD
[Andres Van Der HORST]; Democratic Quisqueyan Party or PQD [Elias
WESSIN Chavez]; National Progressive Force or FNP [Marino VINICIO
Castillo]; Popular Christian Party or PPC [Rogelio DELGADO Bogaert];
Dominican Communist Party or PCD [Narciso ISA Conde]; Dominican
Workers'' Party or PTD [Ivan RODRIGUEZ]; Anti-Imperialist Patriotic
Union or UPA [Ignacio RODRIGUEZ Chiappini]; Alliance for Democracy
Party or APD [Maximilano Rabelais PUIG Miller, Nelsida MARMOLEJOS,
Vicente BENGOA]; Democratic Union or UD [Fernando ALVAREZ Bogaert]
note: in 1983 several leftist parties, including the PCD, joined to
form the Dominican Leftist Front or FID; however, they still retain
individual party structures
Political pressure groups and leaders: Collective of Popular
Organizations or COP
International organization participation: ACP, Caricom (observer),
ECLAC, FAO, G-11, G-77, IADB, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA,
IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO, Intelsat, Interpol, IOC, IOM,
ITU, LAES, LAIA (observer), NAM (guest), OAS, OPANAL, PCA, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Bernardo VEGA Boyrie
chancery: 1715 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 332-6280, 6281
FAX: [1] (202) 265-8057
consulate(s) general: Boston, Chicago, Los Angeles, Mayaguez (Puerto
Rico), Miami, New Orleans, New York, Philadelphia, San Francisco, and
San Juan (Puerto Rico)
consulate(s): Charlotte Amalie (Virgin Islands), Detroit, Houston,
Jacksonville, Mobile, and Ponce (Puerto Rico)
Diplomatic representation from the US:
chief of mission: Ambassador Donna Jean HRINAK
embassy: corner of Calle Cesar Nicolas Penson and Calle Leopoldo
Navarro, Santo Domingo
mailing address: Unit 5500, APO AA 34041
telephone: [1] (809) 221-2171, 221-8100
FAX: [1] (809) 686-7437
Flag description: a centered white cross that extends to the edges,
divides the flag into four rectangles - the top ones are blue (hoist
side) and red, the bottom ones are red (hoist side) and blue; a small
coat of arms is at the center of the cross','b677a61d392b2d534b3021eadaaa5fd28b0cd005b076e7a29786f1886ac1d6c2','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d1d55219cf1e9dc9c97016b259920b7233bb3f2a8d822583d2d28b66f499ef2',1997,'GH','Ghana','government',260,'cabinet : Council of Ministers; president nominates members subject to
approval by the Parliament
elections: president and vice president elected by popular vote for
four-year terms; election last held 7 December 1996 (next to be held
NA 2000)
election results: Jerry John RAWLINGS elected president; percent of
vote - Rawlings 58.8%
Legislative branch: unicameral Parliament (200 seats; members are
elected by direct popular vote to serve four-year terms)
elections : last held 7 December 1996 (next to be held NA December
2000)
election results: percent of vote by party - NA; seats by party - NDC
126, NPP 65, PCP 5, PNC 1, to be determined 3
Judicial branch: Supreme Court
Political parties and leaders: National Democratic Congress or NDC
[Dr. Huudu YAHAYA]; New Patriotic Party or NPP [Peter Ala ADJETY];
People''s Heritage Party or PHP [Alex ERSKINE]; National Convention
Party or NCP [Sarpong Kuman Kuman]; Every Ghanian Living Everywhere or
EGLE [Ashang OKINE]; Peoples Convention Party or PCP [P. K.
DONKOS-AYIFL, acting chairman]; Peoples National Convention or PNC
[Edward MAHAMA]
International organization participation: ACP, AfDB, C, CCC, ECA,
ECOWAS, FAO, G-24, G-77, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD,
IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, IOM
(observer), ISO, ITU, MINURSO, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO,
UNIFIL, UNIKOM, UNMIBH, UNMOP, UNPREDEP, UNTAES, UNU, UPU, WCL, WFTU,
WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Designate Harry SAWYERS
chancery: 3512 International Drive NW, Washington, DC 20008
telephone: [1] (202) 686-4520
FAX : [1] (202) 686-4527
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador Edward BRYNN
embassy: Ring Road East, East of Danquah Circle, Accra
mailing address: P. O. Box 194, Accra
telephone: [233] (21) 775348
FAX: [233] (21) 775747
Flag description: three equal horizontal bands of red (top), yellow,
and green with a large black five-pointed star centered in the yellow
band; uses the popular pan-African colors of Ethiopia; similar to the
flag of Bolivia, which has a coat of arms centered in the yellow band','22f574e9d94a219ab0a33546fd8ec0a05fbf2dd7f9f4a2f46af8c729b717c5bb','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e41f388ec97d2d80c3ae9e7b8b8b6a70c68994a41e541ccec0e32db23e2d2a60',1997,'HN','Honduras','government',295,'cabinet: Cabinet
elections: president elected by popular vote for a four-year term;
election last held 28 November 1993 (next to be held NA November 1997)
election results: Carlos Roberto REINA Idiaquez elected president;
percent of vote - Carlos Roberto REINA Idiaquez (PLH) 53%, Oswaldo
RAMOS Soto (PNH) 41%, other 6%
Legislative branch: unicameral National Assembly or Asamblea Nacional
(128 seats; members are elected by popular vote to serve four-year
terms)
elections : last held on 27 November 1993 (next to be held November
1997)
election results: percent of vote by party - PNH 53%, PLH 41%, PDCH
1.0%, PINU-SD 2.5%, other 2.5%; seats by party - PLH 71, PNH 55,
PINU-SD 2
Judicial branch: Supreme Court of Justice (Corte Suprema de Justica),
judges are elected for four-year terms by the National Assembly
Political parties and leaders: Liberal Party (PLH), Carlos FLORES
Facusse, president; National Party of Honduras (PNH), Oswaldo RAMOS
Soto, president; National Innovation and Unity Party (PINU), Olban
VALLADARES, president; Christian Democratic Party (PDCH), Efrain DIAZ
Arrivillaga, president
Political pressure groups and leaders: National Association of
Honduran Campesinos (ANACH); Honduran Council of Private Enterprise
(COHEP); Confederation of Honduran Workers (CTH); National Union of
Campesinos (UNC); General Workers Confederation (CGT); United
Federation of Honduran Workers (FUTH); Committee for the Defense of
Human Rights in Honduras (CODEH); Coordinating Committee of Popular
Organizations (CCOP)
International organization participation: BCIE, CACM, ECLAC, FAO,
G-77, IADB, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Intelsat, Interpol, IOC, IOM, ITU, LAES, LAIA (observer),
MINURSO, NAM, OAS, OPANAL, PCA, UN, UNCTAD, UNESCO, UNIDO, UNMIH, UPU,
WCL, WFTU, WHO, WIPO, WMO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Roberto FLORES Bermudez
chancery: 3007 Tilden Street NW, Washington, DC 20008
telephone: [1] (202) 966-7702, 2604, 5008, 4596
FAX: [1] (202) 966-9751
consulate(s) general : Chicago, Houston, Los Angeles, Miami, New
Orleans, New York, San Francisco, and San Juan (Puerto Rico)
consulate(s): Boston, Detroit, and Jacksonville
Diplomatic representation from the US:
chief of mission: Ambassador James Francis CREAGAN (29 July 1996)
embassy : Avenida La Paz, Apartado Postal No. 3453, Tegucigalpa
mailing address: American Embassy, APO AA 34022, Tegucigalpa
telephone: [504] 36-9320, 38-5114
FAX: [504] 36-9037
Flag description: three equal horizontal bands of blue (top), white,
and blue with five blue five-pointed stars arranged in an X pattern
centered in the white band; the stars represent the members of the
former Federal Republic of Central America - Costa Rica, El Salvador,
Guatemala, Honduras, and Nicaragua; similar to the flag of El
Salvador, which features a round emblem encircled by the words
REPUBLICA DE EL SALVADOR EN LA AMERICA CENTRAL centered in the white
band; also similar to the flag of Nicaragua, which features a triangle
encircled by the word REPUBLICA DE NICARAGUA on top and AMERICA
CENTRAL on the bottom, centered in the white band','0daa91c8c605956f30ec7eda7c3488351a4b08246a47177a2534d9dcdd3e83c0','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1be1b113b15cd08fdf181adeb671b1a11b5747983bf02236195a47c1ffd326f',1997,'ID','Indonesia','government',311,'cabinet: Cabinet
elections: president and vice president elected by consensus by the
People''s Consultative Assembly for five-year terms; election last held
11 March 1993 (next to be held NA March 1998)
election results : Gen. (Ret.) SOEHARTO elected president by consensus
by the People''s Consultative Assembly; Gen. (Ret.) Try SUTRISNO
elected vice president by consensus by the People''s Consultative
Assembly
Legislative branch: unicameral House of Representatives or Dewan
Perwakilan Rakyat (DPR) (500 seats; 400 elected by popular vote, 100
are appointed military representatives; members serve five-year terms;
note - beginning with the elections in May 1997, the composition of
the DPR will change to 425 elected representatives and 75 appointed
representatives)
elections: last held 8 June 1992 (next scheduled for 29 May 1997)
election results: percent of vote by party - Golkar 68%, PPP 17%, PDI
15%; seats by party - Golkar 282, PPP 62, PDI 56
note: the People''s Consultative Assembly (Majelis Permusyawaratan
Rakyat or MPR) includes the DPR plus 500 indirectly selected members;
it meets every five years to elect the president and vice president
and to approve the broad outlines of national policy
Judicial branch: Supreme Court (Mahkamah Agung), the judges are
appointed by the president
Political parties and leaders: Golkar (de facto ruling political party
based on functional groups), HARMOKO, general chairman; Indonesia
Democracy Party (PDI - federation of former Nationalist and Christian
Parties), SOERJADI, chairman; Development Unity Party (PPP, federation
of former Islamic parties), Ismail Hasan METAREUM, chairman
International organization participation: APEC, AsDB, ASEAN, CCC, CP,
ESCAP, FAO, G-15, G-19, G-77, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, IHO, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, IOM (observer), ISO, ITU, Mekong Group, NAM, OIC, OPEC,
UN, UNCTAD, UNESCO, UNIDO, UNIKOM, UNMIBH, UNMOP, UNOMIG, UNPREDEP,
UNTAES, UPU, WCL, WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Arifin Mohamad SIREGAR
chancery: 2020 Massachusetts Avenue NW, Washington, DC 20036
telephone: [1] (202) 775-5200
FAX: [1] (202) 775-5365
consulate(s) general : Chicago, Houston, Los Angeles, New York, San
Francisco
Diplomatic representation from the US:
chief of mission: Ambassador J. Stapleton ROY
embassy: Medan Merdeka Selatan 5, Jakarta
mailing address: Unit 8129, Box 1, APO AP 96520
telephone : [62] (21) 344-2211
FAX: [62] (21) 386-2259
consulate(s) general: Surabaya
Flag description: two equal horizontal bands of red (top) and white;
similar to the flag of Monaco, which is shorter; also similar to the
flag of Poland, which is white (top) and red
Suffrage: 15 years of age; universal
Executive branch:
chief of state: supreme leader (rahbar-e moazam) and functional chief
of state - Leader of the Islamic Revolution Ayatollah Ali
Hoseini-KHAMENEI (since 4 June 1989)
head of government: President Ali Akbar HASHEMI-RAFSANJANI (since 3
August 1989); First Vice President Hasan Ebrahim HABIBI (since NA
August 1989)
cabinet: Council of Ministers selected by the president with
legislative approval
elections: supreme leader appointed for life by the Council of
Experts; president elected by popular vote for a four-year term;
election last held 11 June 1993 (next to be held 23 May 1997)
election results: Ali Akbar HASHEMI-RAFSANJANI elected president;
percent of vote - Ali Akbar HASHEMI-RAFSANJANI 63%
Legislative branch: unicameral Islamic Consultative Assembly or
Majles-e-Shura-ye-Eslami (270 seats; members elected by popular vote
to serve four-year terms)
elections: last held 8 March and 19 April 1996 (next to be held NA
March 2000)
election results: percent of vote by party - NA; seats by party - NA
Judicial branch: Supreme Court
Political parties and leaders: Iran has no political parties; the most
important political "groupings" are - Tehran Militant Clergy
Association, Secretary General Ayatollah Mohammad EMAMI-KASHANI;
Militant Clerics Association, Mehdi MAHDAVI-KARUBI and Mohammad Asqar
MUSAVI-KHOINIHA; Servants of Reconstruction (G-6), Mohammad
HASHEMI-RAFSANJANI, Hosein MARASHI
Political pressure groups and leaders: groups that generally support
the Islamic Republic include Ansar-e Hizballah, Mojahedin of the
Islamic Revolution, Muslim Students Following the Line of the Imam,
and the Islamic Coalition Association; opposition groups include the
Liberation Movement of Iran and the Nation of Iran party; armed
political groups that have been almost completely repressed by the
government include Mojahedin-e Khalq Organization (MEK), People''s
Fedayeen, Democratic Party of Iranian Kurdistan; the Society for the
Defense of Freedom
International organization participation: CCC, CP, ECO, ESCAP, FAO,
G-19, G-24, G-77, IAEA, IBRD, ICAO, ICC, ICRM, IDA, IDB, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol, IOC, IOM
(observer), ISO, ITU, NAM, OIC, OPEC, PCA, UN, UNCTAD, UNESCO, UNHCR,
UNIDO, UPU, WCL, WFTU, WHO, WMO, WToO
Diplomatic representation in the US: none; note - Iran has an
Interests Section in the Pakistani Embassy, headed by Faramarz
FATH-NEJAD; address: Iranian Interests Section, Pakistani Embassy,
2209 Wisconsin Avenue NW, Washington, DC 20007; telephone: [1] (202)
965-4990
Diplomatic representation from the US: none; note - protecting power
in Iran is Switzerland
Flag description: three equal horizontal bands of green (top), white,
and red; the national emblem (a stylized representation of the word
Allah) in red is centered in the white band; ALLAH AKBAR (God is
Great) in white Arabic script is repeated 11 times along the bottom
edge of the green band and 11 times along the top edge of the red band','3d6d65ab8dae725eb6b9bf3aaacdf6fd7117326945d26ba88000b27fbb344956','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc3653445b8ec45cf2a12919268626e3aa48a2e2cc796e710d808a6bec40fd0b',1997,'IL','Israel','government',321,'Flag description: white with a blue hexagram (six-pointed linear star)
known as the Magen David (Shield of David) centered between two equal
horizontal blue bands near the top and bottom edges of the flag','943d25d77ca47d50b0d60f68c6eb568e8a04ca326e8a19fa3ce8cd6bb1b30750','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7de9116626482dc2d69f6d40ac282eeef2c55e8ef9f8755e7abeb1b4f7c316ee',1997,'IN','India','government',374,'head of government: President Maumoon Abdul GAYOOM (since 11 November
1978); note - the president is both the chief of state and head of
cabinet: Ministry of Atolls appointed by the president; note - need
not be members of Majilis
elections : president elected by secret ballot of the Majlis for a
five-year term; election last held 1 October 1993 (next to be held NA
October 1998)
election results: President Maumoon Abdul GAYOOM reelected; percent of
Majlis vote - Maumoon Abdul GAYOOM 92.76%
Legislative branch: unicameral Citizens'' Council or Majlis (48 seats;
40 elected by popular vote, 8 appointed by the president; members
serve five-year terms)
elections: last held 2 December 1994 (next to be held NA December
1999)
election results : percent of vote - NA; seats - independents 40
Judicial branch: High Court
Political parties and leaders: although political parties are not
banned, none exist
International organization participation: AsDB, C, CCC, CP, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IDB, IFAD, IFC, IMF, IMO, Intelsat
(nonsignatory user), Interpol, IOC, ITU, NAM, OIC, SAARC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WMO, WToO, WTrO
Diplomatic representation in the US: Maldives does not have an embassy
in the US, but does have a Permanent Mission to the UN in New York,
headed by Ahmed ZAKI
Diplomatic representation from the US: the US does not have an embassy
in Maldives; the US Ambassador to Sri Lanka is accredited to Maldives
and makes periodic visits there
Flag description: red with a large green rectangle in the center
bearing a vertical white crescent; the closed side of the crescent is
on the hoist side of the flag','a3120bb8c7821f623305342128d22d7262dd913907534f1fae4dda26b69b76b8','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eafab5cf47303b2fc3c88cf5f6db0cf2ff23e01f1a963e27c3dfa509e504ae6',1997,'MX','Mexico','government',392,'National capital: Mexico
Administrative divisions: 31 states (estados, singular - estado) and 1
federal district* (distrito federal); Aguascalientes, Baja California,
Baja California Sur, Campeche, Chiapas, Chihuahua, Coahuila de
Zaragoza, Colima, Distrito Federal*, Durango, Guanajuato, Guerrero,
Hidalgo, Jalisco, Mexico, Michoacan de Ocampo, Morelos, Nayarit, Nuevo
Leon, Oaxaca, Puebla, Queretaro de Arteaga, Quintana Roo, San Luis
Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala,
Veracruz-Llave, Yucatan, Zacatecas
Independence: 16 September 1810 (from Spain)
National holiday: Independence Day, 16 September (1810)
Constitution: 5 February 1917
Legal system: mixture of US constitutional theory and civil law
system; judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 18 years of age; universal and compulsory (but not enforced)
Executive branch:
chief of state: President Ernesto ZEDILLO Ponce de Leon (since 1
December 1994); note - the president is both the chief of state and
head of government
head of government : President Ernesto ZEDILLO Ponce de Leon (since 1
December 1994); note - the president is both the chief of state and
head of government
cabinet: Cabinet appointed by the president
elections: president elected by popular vote for a six-year term;
election last held 21 August 1994 (next to be held NA 2000)
election results: Ernesto ZEDILLO Ponce de Leon elected president;
percent of vote - Ernesto ZEDILLO Ponce de Leon (PRI) 50.18%,
Cuauhtemoc CARDENAS Solorzano (PRD) 17.08%, Diego FERNANDEZ DE
CEVALLOS (PAN) 26.69%, other 6.049%
Legislative branch: bicameral National Congress or Congreso de la
Union consists of the Senate or Camara de Senadores (128 seats,
expanded from 64 seats at the last election; members are elected by
popular vote to serve six-year terms) and the Chamber of Deputies or
Camara de Diputados (500 seats; members are directly elected by
popular vote to serve three-year terms)
elections: Senate - last held 21 August 1994 (next to be held 6 July
1997 for one-quarter of the seats); Chamber of Deputies - last held 24
August 1994 (next to be held 6 July 1997)
election results: Senate - percent of vote by party - NA; seats by
party in expanded Senate - PRI 93, PRD 25, PAN 10; Chamber of Deputies
- percent of vote by party - NA; seats by party - PRI 300, PAN 119,
PRD 71, PT 10
Judicial branch: Supreme Court of Justice (Corte Suprema de Justicia),
judges are appointed by the president with consent of the Senate
Political parties and leaders: (recognized parties) Institutional
Revolutionary Party (PRI), Humberto ROQUE Villanueva; National Action
Party (PAN), Felipe CALDERON Hinojosa; Popular Socialist Party (PPS),
Indalecio SAYAGO Herrera; Democratic Revolutionary Party (PRD), Andres
Manuel LOPEZ Obrador; Cardenist Front for the National Reconstruction
Party (PFCRN), Rafael AGUILAR Talamantes; Democratic Forum Party
(PFD), Pablo Emilio MADERO; Mexican Green Ecologist Party (PVEM),
Jorge GONZALEZ Torres; Workers Party (PT), Alberto ANYA Gutierrez
Political pressure groups and leaders: Roman Catholic Church;
Confederation of Mexican Workers (CTM); Confederation of Industrial
Chambers (CONCAMIN); Confederation of National Chambers of Commerce
(CONCANACO); National Peasant Confederation (CNC); Revolutionary
Workers Party (PRT); Revolutionary Confederation of Workers and
Peasants (CROC); Regional Confederation of Mexican Workers (CROM);
Confederation of Employers of the Mexican Republic (COPARMEX);
National Chamber of Transformation Industries (CANACINTRA);
Coordinator for Foreign Trade Business Organizations (COECE);
Federation of Unions Providing Goods and Services (FESEBES)
International organization participation: AG (observer), APEC, BCIE,
BIS (pending member), Caricom (observer), CCC, CDB, EBRD, ECLAC, FAO,
G- 6, G-11, G-15, G-19, G-24, IADB, IAEA, IBRD, ICAO, ICC, ICFTU,
ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat,
Interpol, IOC, IOM (observer), ISO, ITU, LAES, LAIA, NAM (observer),
OAS, OECD, OPANAL, PCA, RG, UN, UNCTAD, UNESCO, UNIDO, UNU, UPU, WCL,
WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Jesus SILVA Herzog Flores
chancery: 1911 Pennsylvania Avenue NW, Washington, DC 20006
telephone: [1] (202) 728-1600
consulate(s) general: Atlanta, Chicago, Dallas, Denver, El Paso,
Houston, Los Angeles, Miami, New Orleans, New York, Phoenix, San
Antonio, San Diego, San Francisco, San Juan (Puerto Rico)
consulate(s): Albuquerque, Austin, Boston, Brownsville (Texas),
Calexico (California), Corpus Christi, Del Rio (Texas), Detroit, Eagle
Pass (Texas), Fresno (California), Laredo, McAllen (Texas), Midland
(Texas), Nogales (Arizona), Oxnard (California), Philadelphia,
Sacramento, St. Louis, Salt Lake City, San Bernardino, San Jose, Santa
Ana, Seattle
Diplomatic representation from the US:
chief of mission: Ambassador James R. JONES
embassy: Paseo de la Reforma 305, Colonia Cuauhtemoc, 06500 Mexico,
Distrito Federal
mailing address: P. O. Box 3087, Laredo, TX 78044-3087
telephone : [52] (5) 211-0042
FAX: [52] (5) 511-9980, 208-3373
consulate(s) general: Ciudad Juarez, Guadalajara, Monterrey, Tijuana
consulate(s): Hermosillo, Matamoros, Merida, Nuevo Laredo
Flag description: three equal vertical bands of green (hoist side),
white, and red; the coat of arms (an eagle perched on a cactus with a
snake in its beak) is centered in the white band','71579eb1c2229dce265421651e799cbe8f24d272f7ca79318076fb4653167657','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('211ffc11295a77d75b489a77bf8e549d205387e5aaa61f4a39e551147e0beef6',1997,'SA','Saudi Arabia','government',483,'head of government: King and Prime Minister FAHD bin Abd al-Aziz Al
Saud (since 13 June 1982); Crown Prince and First Deputy Prime
Minister ABDALLAH bin Abd al-Aziz Al Saud (half-brother to the king,
heir to the throne since 13 June 1982, regent from 1 January to 22
February 1996); note - the king is both the chief of state and head of
cabinet: Council of Ministers is appointed by the king and includes
many royal family members
elections: none; the king is an absolute monarch
Legislative branch: a consultative council (60 members and a chairman
appointed by the king for four-year terms)
Judicial branch: Supreme Council of Justice
Political parties and leaders: none allowed
International organization participation: ABEDA, AfDB, AFESD, AL, AMF,
BIS (pending member), CCC, ESCWA, FAO, G-19, G-77, GCC, IAEA, IBRD,
ICAO, ICC, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, ISO, ITU, NAM, OAPEC, OAS (observer), OIC,
OPEC, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WTrO
(applicant)
Diplomatic representation in the US:
chief of mission: Ambassador BANDAR bin Sultan bin Abd al-Aziz Al Saud
chancery: 601 New Hampshire Avenue NW, Washington, DC 20037
telephone: [1] (202) 342-3800
consulate(s) general : Houston, Los Angeles, and New York
Diplomatic representation from the US:
chief of mission: Ambassador Wyche FOWLER, Jr.
embassy : Collector Road M, Diplomatic Quarter, Riyadh
mailing address: American Embassy-Riyadh, Unit 61307, APO AE
09803-1307; International Mail: P. O. Box 94309, Riyadh 11693
telephone: [966] (1) 488-3800
FAX : [966] (1) 488-7360
consulate(s) general: Dhahran, Jiddah (Jeddah)
Flag description: green with large white Arabic script (that may be
translated as There is no God but God; Muhammad is the Messenger of
God) above a white horizontal saber (the tip points to the hoist
side); green is the traditional color of Islam','d5f7b7f1fb961bac1cb86fad80fcebbb9ffc73571e1fbcc6f0652a1a4edc0cb9','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb87f8be1ba65ee9ef17a07d2dfaf98e53aee01c01dd32e776fb2c8cec4857c',1997,'SL','Sierra Leone','government',489,'head of government: President Ahmad Tejan KABBAH (inaugurated 29 March
1996); note - the president is both the chief of state and head of
cabinet : Ministers of State appointed by the president with the
approval of the House of Representatives; the cabinet is responsible
to the president
elections: president elected by popular vote for a five-year term;
election held 26-27 February 1996 (next to be held NA 2001); note -
president''s tenure of office is limited to 2 five-year terms
election results : Ahmad Tejan KABBAH elected president; percent of
popular vote - NA
Legislative branch: unicameral House of Representatives (80 seats, 68
elected, 12 filled by paramount chiefs elected in separate elections;
members serve NA-year terms)
elections : last held NA February 1996 (next to be held NA)
election results: percent of vote by party - NA; seats by party - SLPP
27, UNPP 17, PDP 12, APC 5, NUP 4, DCP 3; note - first elections since
the former House of Representatives was shut down by the military coup
of 29 April 1992
Judicial branch: Supreme Court
Political parties and leaders: 15 parties registered for the February
1996 elections; National Peoples Party or NPP [Andrew TURAY];
Democratic Center Party or DCP [Abu KOROMA]; Peoples Progressive Party
or PPP [Edward KAMARA, chairman]; Coalition for Progress Party or CPP
[Geredine WILLIAMS-SARHO]; National Unity Movement or NUM; United
National Peoples Party or UNPP; Peoples Democratic Party or PDP
[Thaimu BANGURA, chairman]; All Peoples Congress or APC [S. A. T.
KOROMA, chairman]; National Republican Party or NRP; Social Democratic
Party or SDP; Peoples National Convention or PNC [I. B. KARGBO,
chairman]; National Unity Party or NUP [A. O. D. GEORGE, chairman];
Sierra Leone Peoples Party or SLPP [Paul DUNBAR, chairman]; National
Democratic Alliance or NDA; National Alliance for Democracy Party or
NADP
International organization participation: ACP, AfDB, C, CCC, ECA,
ECOWAS, FAO, G-77, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IDB, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat (nonsignatory user), Interpol, IOC,
ITU, NAM, OAU, OIC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO,
WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador John Ernest LEIGH
chancery: 1701 19th Street NW, Washington, DC 20009
telephone: [1] (202) 939-9261 through 9263
FAX: [1] (202) 483-1793
Diplomatic representation from the US:
chief of mission : Ambassador John L. HIRSCH
embassy: Corner of Walpole and Siaka Stevens Streets, Freetown
mailing address: use embassy street address
telephone: [232] (22) 226481 through 226485
FAX : [232] (22) 225471
Flag description: three equal horizontal bands of light green (top),
white, and light blue','d3d290e43c8cf42a9a3e843275036f26a180854fc7c990535b45488d807a3e15','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('830d279af9a4bf7324a00bae655b03dde2bd527d2327beafa593d4e5f109190c',1997,'SR','Suriname','government',518,'cabinet : Cabinet of Ministers appointed by the president from among
the members of the National Assembly
note: Commander in Chief of the National Army maintains significant
power
elections: president and vice president elected by the National
Assembly for five-year terms; election last held 23 May 1996; runoff
election held 5 September 1996 (next to be held NA May 2001)
election results: Jules WIJDENBOSCH elected president; percent of
legislative vote NA; National Assembly failed to elect president;
results reflect the People''s Assembly votes - Jules WIJDENBOSCH (NDP)
438, Ronald VENETIAAN (NF) 407
Legislative branch: unicameral National Assembly or Assemblee
Nationale (51 seats; members are elected by popular vote to serve
five-year terms)
elections : last held 23 May 1996 (next to be held NA May 2001)
election results: percent of vote by party - NA; seats by party - NDP
16, NF 14, BVD 5, KTPI 5, DA''91 4, Pendawa Lima 4, Alliance 3
Judicial branch: Supreme Court, justices nominated for life
Political parties and leaders: The New Front (NF), a coalition of
three parties (NPS, VHP, SPA), leader Ronald R. VENETIAAN; Progressive
Reform Party (VHP), Jaggernath LACHMON; National Party of Suriname
(NPS), Ronald VENETIAAN; Party of National Unity and Solidarity
(KTPI), Willy SOEMITA; Suriname Labor Party (SPA), Fred DERBY;
Democratic Alternative ''91 (DA ''91), a coalition of two parties (AF,
and BEP) formed in January 1991, Winston JESSURUN; Alternative Forum
(AF), Rick VAN RAVENSWAY; Party for Brotherhood and Unity in Politics
(BEP), Caprino ALLENDY; Pendawa Lima, Paul SOMOHARDJO; National
Democratic Party (NDP), Desire BOUTERSE; Progressive Workers'' and Farm
Laborers'' Union (PALU), Ir Iwan KROLIS; The Progressive Development
Alliance, a combination of three parties (DP, HPP, PVF), Frank
PLAYFAIR; Democratic Party (DP), Frank PLAYFAIR; Reformed Progressive
Party (HPP), Harry KISOENSINGH; Party of the Federation of Land
Workers PVF), Jwan SITAL; Party for Renewal and Democracy (BVD), Atta
MUNGRA; Independent Progressive Democratic Alternative (OPDA),
Joginder RAMKHILAWAN
Political pressure groups and leaders: Union for Liberation and
Democracy, Kofi AFONGPONG; Mandela Bushnegro Liberation Movement,
Leendert ADAMS; Tucayana Amazonica, Alex JUBITANA, Thomas SABAJO;
General Liberation and Development Party (ABOP), George TIRINI
International organization participation: ACP, Caricom, ECLAC, FAO,
G-77, IADB, IBRD, ICAO, ICFTU, ICRM, IFAD, IFRCS, IHO, ILO, IMF, IMO,
Intelsat (nonsignatory user), Interpol, IOC, ITU, LAES, NAM, OAS, OIC,
OPANAL, PCA, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador (vacant); Charge d''Affaires Cicyl G.
ALWART
chancery: Suite 108, 4301 Connecticut Avenue NW, Washington, DC 20008
telephone: [1] (202) 244-7488, 7490 through 7492
FAX : [1] (202) 244-5878
consulate(s) general: Miami
Diplomatic representation from the US:
chief of mission: Ambassador Dennis K. HAYS
embassy: Dr. Sophie Redmondstraat 129, Paramaribo
mailing address : P. O. Box 1821, American Embassy Paramaribo,
Department of State, Washington, DC, 20521-3390
telephone: [597] 472900, 477881, 476459
FAX: [597] 420800
Flag description: five horizontal bands of green (top, double width),
white, red (quadruple width), white, and green (double width); there
is a large yellow five-pointed star centered in the red band','04a65444b0108575ef8c7b1ba0405da7feaa5afe60f973c0a58a46186a37b115','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92617537df348052f4a0bbdf0a414daea7fbbccbaf869b643543cbdeb4975139',1997,'US','United States','government',555,'cabinet: Cabinet appointed by the president with Senate approval
elections: president and vice president elected on the same ticket by
a college of representatives who are elected directly from each state;
president and vice president serve four-year terms; election last held
5 November 1996 (next to be held 7 November 2000)
election results: William Jefferson CLINTON elected president; percent
of popular vote - William Jefferson CLINTON (Democratic Party) 49.2%,
Bob DOLE (Republican Party) 40.7%, Ross PEROT (Reform Party) 8.4%,
other 1.7%
Legislative branch: bicameral Congress consists of Senate (100 seats,
one-third are renewed every two years; two members are elected from
each state by popular vote to serve six-year terms) and House of
Representatives (435 seats; members are directly elected by popular
vote to serve two-year terms)
elections: Senate - last held 5 November 1996 (next to be held 2
November 1998); House of Representatives - last held 5 November 1996
(next to be held 2 November 1998)
election results : Senate - percent of vote by party - NA; seats by
party - Republican Party 55, Democratic Party 45; House of
Representatives - percent of vote by party - NA; seats by party -
Republican Party 227, Democratic Party 205, independent 1, vacant 2
Judicial branch: Supreme Court, justices are appointed for life by the
president with confirmation by the Senate
Political parties and leaders: Republican Party, Jim NICHOLSON,
national committee chairman; Democratic Party, Steve GROSSMAN,
national committee chairman; several other groups or parties of minor
political significance
International organization participation: AfDB, AG (observer), ANZUS,
APEC, AsDB, Australia Group, BIS, CCC, CE (observer), CP, EBRD, ECE,
ECLAC, ESCAP, FAO, G- 2, G- 5, G- 7, G- 8, G-10, IADB, IAEA, IBRD,
ICAO, ICC, ICFTU, ICRM, IDA, IEA, IFAD, IFC, IFRCS, IHO, ILO, IMF,
IMO, Inmarsat, Intelsat, Interpol, IOC, IOM, ISO, ITU, MINURSO, MTCR,
NACC, NATO, NEA, NSG, OAS, OECD, OSCE, PCA, SPC, UN, UN Security
Council, UNCTAD, UNHCR, UNIDO, UNIKOM, UNMIBH, UNMIH, UNOMIG,
UNPREDEP, UNRWA, UNTAES, UNTSO, UNU, UPU, WCL, WHO, WIPO, WMO, WToO,
WTrO, ZC
Flag description: thirteen equal horizontal stripes of red (top and
bottom) alternating with white; there is a blue rectangle in the upper
hoist-side corner bearing 50 small white five-pointed stars arranged
in nine offset horizontal rows of six stars (top and bottom)
alternating with rows of five stars; the 50 stars represent the 50
states, the 13 stripes represent the 13 original colonies; known as
Old Glory; the design and colors have been the basis for a number of
other flags including Chile, Liberia, Malaysia, and Puerto Rico','0baffc6d9500d9e057f828cd68f45bc766de0d88d0aaf9644a830379bcf20cc4','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5fa075fbab5fae863878e08842987122f9ae8d34f1e405ab0d435a09aefa354',1997,'NC','New Caledonia','government',567,'head of government: President Rafael CALDERA Rodriguez (since 2
February 1994); note - the president is both the chief of state and
head of government
cabinet: Council of Ministers appointed by the president
elections: president elected by popular vote for a five-year term;
election last held 5 December 1993 (next to be held NA December 1998)
election results : Rafael CALDERA Rodriguez elected president; percent
of vote - Rafael CALDERA Rodriguez (National Convergence) 30.45%,
Claudio FERMIN (AD) 23.59%, Oswaldo ALVAREZ PAZ (COPEI) 22.72%, Andres
VELASQUEZ (Causa R) 21.94%, other 1.3%
Legislative branch: bicameral Congress of the Republic or Congreso de
la Republica consists of the Senate or Senado (53 seats, two from each
state and the Federal District, and retired presidents; members are
elected by popular vote to serve five-year terms) and Chamber of
Deputies or Camara de Diputados (203 seats; members are elected by
popular vote to serve five-year terms)
elections: Senate - last held 5 December 1993 (next to be held NA
December 1998); Chamber of Deputies - last held 5 December 1993 (next
to be held NA December 1998)
election results: Senate - percent of vote by party - NA; seats by
party - AD 18, COPEI 15, Causa R 9, MAS 5, National Convergence 6;
note - three former presidents (2 from AD, 1 from COPEI) hold lifetime
Senate seats; Chamber of Deputies - percent of vote by party - AD
27.9%, COPEI 26.9%, MAS 12.4%, National Convergence 12.9%, Causa R
19.9%; seats by party - AD 55, COPEI 53, MAS 24, National Convergence
26, Causa R 40, other 5
Judicial branch: Supreme Court of Justice (Corte Suprema de Justicia),
magistrates are elected by both chambers in joint session
Political parties and leaders: National Convergence (Convergencia),
Jose Miguel UZCATEGUI, president, Juan Jose CALDERA, national
coordinator; Social Christian Party (COPEI), Luis HERRERA Campins,
president, and Donald RAMIREZ, secretary general; Democratic Action
(AD), Pedro PARIS Montesinos, president, and Luis ALFARO Ucero,
secretary general; Movement Toward Socialism (MAS), Gustavo MARQUEZ,
president, and Enrique OCHOA Antich, secretary general; Radical Cause
(La Causa R), Lucas MATHEUS, secretary general
Political pressure groups and leaders: FEDECAMARAS, a conservative
business group; Venezuelan Confederation of Workers (CTV, labor
organization dominated by the Democratic Action); VECINOS groups
International organization participation: AG, BCIE, Caricom
(observer), CCC, CDB, ECLAC, FAO, G- 3, G-11, G-15, G-19, G-24, G-77,
IADB, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IFAD, IFC, IFRCS, IHO, ILO,
IMF, IMO, Intelsat, Interpol, IOC, IOM, ISO, ITU, LAES, LAIA, MINURSO,
NAM, OAS, OPANAL, OPEC, PCA, RG, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UNIKOM, UNU, UPU, WCL, WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Pedro Luis ECHEVERRIA
chancery: 1099 30th Street NW, Washington, DC 20007
telephone : [1] (202) 342-2214
FAX: [1] (202) 342-6820
consulate(s) general: Boston, Chicago, Houston, Miami, New Orleans,
New York, San Francisco, and San Juan (Puerto Rico)
Diplomatic representation from the US:
chief of mission : Ambassador John Francis MAISTO
embassy: Calle F con Calle Suapure, Colinas de Valle Arriba, Caracas
1060
mailing address: P. O. Box 62291, Caracas 1060-A; APO AA 34037
telephone: [58] (2) 977-2011
FAX: [58] (2) 977-0843
Flag description: three equal horizontal bands of yellow (top), blue,
and red with the coat of arms on the hoist side of the yellow band and
an arc of seven white five-pointed stars centered in the blue band','2eb9090bd9bc59401971b4e2195cc12f2b971d3dc8b6bf7f9f57c9e8d2616955','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

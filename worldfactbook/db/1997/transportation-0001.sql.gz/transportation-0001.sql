SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b66f5a0d88e82c2a4c465d791f61aa2c11b2eb3d2c3daeeaf39cca0b1d59ceb',1997,'TC','Turks and Caicos Islands','transportation',19,'Railways
total
broad gauge
dual gauge
narrow gauge
other gauges
standard gauge
Highways
total
paved
unpaved
Waterways
Pipelines
Ports and harbors
Merchant marine
total
ships by type
Airports
Airports--with paved runways
total
over 3,047m
2,438 to 3,047m
1,524 to 2,437m
914 to 1,523m
under 914m
Airports--with unpaved runways
total
over 3,047m
2,438 to 3,047m
1,524 to 2,437m
914 to 1,523m
under 914m
Heliports
Transportation--note','142cf3dee45fa51040fb37e46585b141a5b53a147d9d616e89465322c869900a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

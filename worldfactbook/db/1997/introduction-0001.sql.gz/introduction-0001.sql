SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed4abd57b304fc8d43109e7a0a0f79a515e0e06c676ce9c5a1a59bd39dc1d77c',1997,'','','introduction',2,'A Brief History of Basic Intelligence and the World Factbook
Notes and Definitions
Guide to Country Profiles (Categories, Fields and Subfields)','25afd4e3a92aeb634c05604ead5206bd84c54b8d2bd84e073742ad85de2b8de4','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5eece356efd3f07143eb60bb403cac8d5d87753f2e8c84adaf0037e1f3ec9fd',1997,'AZ','Azerbaijan','introduction',3,'The Bahamas
Current issues: Azerbaijan continues to be plagued by an unresolved
nine-year-old conflict with Armenian separatists over its
Nagorno-Karabakh region. The Karabakh Armenians have declared
independence and seized almost 20% of the country''s territory,
creating almost 1 million Azerbaijani refugees in the process. Both
sides have generally observed a Russian-mediated cease-fire in place
since May 1994, and support the OSCE-mediated peace process, now
entering its fifth year. Nevertheless, Baku and Xankandi (Stepanakert,
Nagorno-Karabakh region) remain far apart on most substantive issues
from the placement and composition of a peacekeeping force to the
enclave''s ultimate political status, and prospects for a negotiated
settlement remain dim.
@Azerbaijan:Geography
Location: Southwestern Asia, bordering the Caspian Sea, between Iran
and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent States
Area:
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous Republic and the
Nagorno-Karabakh region; the region''s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November 1991
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2,013 km
border countries : Armenia (with Azerbaijan-proper) 566 km, Armenia
(with Azerbaijan-Naxcivan exclave) 221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with Azerbaijan-Naxcivan exclave) 179
km, Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800 km, est.)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Lowland (much of it below sea level)
with Great Caucasus Mountains to the north, Qarabag (Karabakh) Upland
in west; Baku lies on Abseron (Apsheron) Peninsula that juts into
Caspian Sea
Elevation extremes:
lowest point : Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore, nonferrous
metals, alumina
Land use:
arable land: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 11%
other : 41% (1993 est.)
Irrigated land: 10,000 sq km (1993 est.)
Natural hazards: droughts; some lowland areas threatened by rising
levels of the Caspian Sea
Environment - current issues: local scientists consider the Abseron
(Apsheron) Peninsula (including Baku and Sumqayit) and the Caspian Sea
to be the ecologically most devastated area in the world because of
severe air, water, and soil pollution; soil pollution results from the
use of DDT as a pesticide and also from toxic defoliants used in the
production of cotton
Environment - international agreements:
party to: Climate Change, Ozone Layer Protection
signed, but not ratified: Biodiversity
Geography - note: landlocked
@Azerbaijan:People
Population: 7,797,476 (July 1997 est.)
Age structure:
0-14 years: 33% (male 1,302,759; female 1,247,868)
15-64 years: 61% (male 2,315,272; female 2,446,087)
65 years and over: 6% (male 186,699; female 298,791) (July 1997 est.)
Population growth rate: 0.78% (1997 est.)
Birth rate: 22.89 births/1,000 population (1997 est.)
Death rate: 9.32 deaths/1,000 population (1997 est.)
Net migration rate: -5.75 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (1997 est.)
Infant mortality rate: 80.7 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 63.52 years
male : 59.27 years
female: 67.99 years (1997 est.)
Total fertility rate: 2.77 children born/woman (1997 est.)
Nationality:
noun : Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani Peoples 3.2%, Russian 2.5%,
Armenian 2.3%, other 2% (1995 est.)
note: almost all Armenians live in the separatist Nagorno-Karabakh
region
Religions: Muslim 93.4%, Russian Orthodox 2.5%, Armenian Orthodox
2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan; actual
practicing adherents are much lower
Languages: Azeri 89%, Russian 3%, Armenian 2%, other 6% (1995 est.)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
@Azerbaijan:Government
Country name:
conventional long form: Azerbaijani Republic
conventional short form: Azerbaijan
local long form: Azarbaycan Respublikasi
local short form : none
former: Azerbaijan Soviet Socialist Republic
Data code: AJ
Government type: republic
National capital: Baku (Baki)
Administrative divisions: 59 rayons (rayonlar; rayon - singular), 11
cities* (saharlar; sahar - singular), 1 autonomous republic** (muxtar
respublika); Abseron Rayonu, Agcabadi Rayonu, Agdam Rayonu, Agdas
Rayonu, Agstafa Rayonu, Agsu Rayonu, AliBayramli Sahari*, Astara
Rayonu, Baki Sahari*, Balakan Rayonu, Barda Rayonu, Beylaqan Rayonu,
Bilasuvar Rayonu, Cabrayil Rayonu, Calilabad Rayonu, Daskasan Rayonu,
Davaci Rayonu, Fuzuli Rayonu, Gadabay Rayonu, Ganca Sahari*, Goranboy
Rayonu, Goycay Rayonu, Haciqabul Rayonu, Imisli Rayonu, Ismayilli
Rayonu, Kalbacar Rayonu, Kurdamir Rayonu, Lacin Rayonu, Lankaran
Rayonu, Lankaran Sahari*, Lerik Rayonu, Masalli Rayonu, Mingacevir
Sahari*, Naftalan Sahari*, Naxcivan Muxtar Respublikasi**, Neftcala
Rayonu, Oguz Rayonu, Qabala Rayonu, Qax Rayonu, Qazax Rayonu, Qobustan
Rayonu, Quba Rayonu, Qubadli Rayonu, Qusar Rayonu, Saatli Rayonu,
Sabirabad Rayonu, Saki Rayonu, Saki Sahari*, Salyan Rayonu, Samaxi
Rayonu, Samkir Rayonu, Samux Rayonu, Siyazan Rayonu, Sumqayit Sahari*,
Susa Rayonu, Susa Sahari*, Tartar Rayonu, Tovuz Rayonu, Ucar Rayonu,
Xacmaz Rayonu, Xankandi Sahari*, Xanlar Rayonu, Xizi Rayonu, Xocali
Rayonu, Xocavand Rayonu, Yardimli Rayonu, Yevlax Rayonu, Yevlax
Sahari*, Zangilan Rayonu, Zaqatala Rayonu, Zardab Rayonu
Independence: 30 August 1991 (from Soviet Union)
National holiday: Independence Day, 28 May
Constitution: adopted 12 November 1995
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Heydar ALIYEV (since 18 June 1993)
head of government: Prime Minister Artur RASIZADE (since NA November
1996); First Deputy Prime Ministers Abbas ABBASOV (since NA), Samed
SADYKOV (since NA), Vahid AKHMEDOV (since NA), Elchin EFENDIYEV (since
NA)
cabinet: Council of Ministers appointed by the president and confirmed
by the National Assembly
elections: president elected by popular vote to a five-year term;
election last held 3 October 1993 (next to be held NA 1998); prime
minister and first deputy prime ministers appointed by the president
and confirmed by the National Assembly
election results: Heydar ALIYEV elected president; percent of vote -
Heydar ALIYEV 97%
Legislative branch: unicameral National Assembly or Milli Mejlis (125
seats; members serve five-year terms)
elections: last held 12 and 26 November 1995 (next to be held NA 2000)
election results: percent of vote by party - NA; seats by party - NA
Judicial branch: Supreme Court
Political parties and leaders: Azerbaijan Popular Front or APF
[Ebulfez ELCIBEY, chairman]; Musavat Party [Isa GAMBAR, chairman];
National Independence Party [Etibar MAMEDOV, chairman]; Social
Democratic Party or SDP [Araz ALIZADE, chairman]; Communist Party
[Ramiz AKHMEDOV, chairman]; People''s Freedom Party [Yunus OGUZ,
chairman]; Independent Social Democratic Party [Arif YUNUSOV and Leila
YUNOSOVA, cochairmen]; New Azerbaijan Party [Heydar ALIYEV, chairman];
Boz Gurd Party [Iskander HAMIDOV, chairman]; Azerbaijan Democratic
Independence Party [Qabil HUSEYNLI, chairman]; Islamic Party of
Azerbaijan [Ali Akram, chairman]; Ana Veten Party [Fazail AGAMALIYEV];
Azerbaijan Democratic Party [Sardar Jalaloglu MAMEDOV]; Azerbaijan
Democratic Party of Proprietors or DPOP [Makhmud MAMEDOV]; Azerbaijan
Patriotic Solidarity Party [Sabir RUSTAMHANLI]; Azerbaijan Republic
Reform Party [Fuad ASADOV]; Communist Party of Azerbaijan
(unregistered) [Sayad SAYADOV]; Equality of the Peoples Party
[Faukhraddin AYDAYEV]; Independent Azerbaijan Party [Nizami
SULEYMANOV]; Labor Party of Azerbaijan [Sabutai HAJIYEV];
Liberal-Democratic Party of Azerbaijan [Lyudmila NIKOLAYEVNA];
National Enlightenment Party [Hajy Osman EFENDIYEV]; National
Liberation Party [Panak SHAKHSEVEV]; Peasant Party [Firuz MUSTAFAYEV];
Radical Party of Azerbaijan [Malik SHARIFOV]; United Azerbaijan Party
[Kerrar ABILOV]; Vetan Adzhagy Party [Zakir TAGIYEV]
Political pressure groups and leaders: self-proclaimed Armenian
Nagorno-Karabakh Republic; Talysh independence movement; Sadval,
Lezgin movement
International organization participation: BSEC, CCC, CE (guest), CIS,
EBRD, ECE, ECO, ESCAP, FAO, IBRD, ICAO, IDA, IDB, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Intelsat, Interpol, IOC, ITU, NACC, NAM (observer),
OIC, OSCE, PFP, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO,
WTrO (observer)
Diplomatic representation in the US:
chief of mission: Ambassador Hafiz Mir Jalal PASHAYEV
chancery: (temporary) Suite 700, 927 15th Street NW, Washington, DC
20005 or P. O. Box 28790, Washington, DC 20038-8790
telephone : [1] (202) 842-0001
FAX: [1] (202) 842-0004
Diplomatic representation from the US:
chief of mission: Ambassador Richard D. KAUZLARICH
embassy: Azadliq Prospekti 83, Baku
mailing address : use embassy street address
telephone: [9] (9412) 96-03-35
FAX: [9] (9412) 96-04-69
Flag description: three equal horizontal bands of blue (top), red, and
green; a crescent and eight-pointed star in white are centered in red
band','42d7018169100351ab1419d84324ad2d7c81edfc3bd56e4f3070917b349eb440','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85578e08349902b847ba8984e6a3abd78eebf0aab96cb8097cd700146f43d2ca',1997,'KM','Comoros','introduction',4,'Congo, Democratic Republic of the
Congo, Republic of the
Historical perspective: Comoros has had difficulty in achieving
political stability, having endured 18 coups or attempted coups since
receiving independence from France in 1975.
@Comoros:Geography
Location: Southern Africa, group of islands in the Mozambique Channel,
about two-thirds of the way between northern Madagascar and northern','e2006fd5261dcc4c76f1efcfab966786a6c3e749bd2fd303375f4527b3407d60','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b0eb3c2ea976c277481025ee39007d6e1ad79d097273c589e895fb24da47dd',1997,'ET','Ethiopia','introduction',5,'Europa Island
Falkland Islands (Islas Malvinas)
Historical perspective: on 28 May 1991 the Ethiopian People''s
Revolutionary Democratic Front (EPRDF) toppled the authoritarian
government of MENGISTU Haile-Mariam and took control in Addis Ababa; a
new constitution was promulgated in December 1994 and national and
regional popular elections were held in May and June 1995
@Ethiopia:Geography
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Area - comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,311 km
border countries: Djibouti 337 km, Eritrea 912 km, Kenya 830 km,
Somalia 1,626 km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide topographic-induced variation
Terrain: high plateau with central mountain range divided by Great
Rift Valley
Elevation extremes:
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small reserves of gold, platinum, copper, potash
Land use:
arable land: 12%
permanent crops : 1%
permanent pastures: 40%
forests and woodland: 25%
other: 22% (1993 est.)
Irrigated land: 1,900 sq km (1993 est.)
Natural hazards: geologically active Great Rift Valley susceptible to
earthquakes, volcanic eruptions; frequent droughts
Environment - current issues: deforestation; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to : Biodiversity, Climate Change, Endangered Species, Ozone
Layer Protection
signed, but not ratified: Desertification, Environmental Modification,
Law of the Sea, Nuclear Test Ban
Geography - note: landlocked - entire coastline along the Red Sea was
lost with the de jure independence of Eritrea on 27 April 1993
@Ethiopia:People
Population: 58,732,577 (July 1997 est.)
Age structure:
0-14 years : 46% (male 13,492,323; female 13,444,656)
15-64 years: 51% (male 15,167,806; female 15,020,499)
65 years and over: 3% (male 745,554; female 861,739) (July 1997 est.)
Population growth rate: 2.67% (1997 est.)
Birth rate: 45.59 births/1,000 population (1997 est.)
Death rate: 17.56 deaths/1,000 population (1997 est.)
Net migration rate: -1.32 migrant(s)/1,000 population (1997 est.)
note: repatriation of Ethiopians who fled to Sudan, Kenya and Somalia
for refuge from war and famine in earlier years, is expected to
continue in 1997; entry into Ethiopia of Sudanese and Somalis fleeing
the fighting in their own countries is also continuing in 1997
Sex ratio:
at birth : 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 male(s)/female (1997 est.)
Infant mortality rate: 121.5 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 46.62 years
male : 45.48 years
female: 47.8 years (1997 est.)
Total fertility rate: 6.94 children born/woman (1997 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigrean 32%, Sidamo 9%, Shankella
6%, Somali 6%, Afar 4%, Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox 35%-40%, animist 12%,
other 3%-8%
Languages: Amharic (official), Tigrinya, Orominga, Guaraginga, Somali,
Arabic, English (major foreign language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
female : 25.3% (1995 est.)
@Ethiopia:Government
Country name:
conventional long form: Federal Democratic Republic of Ethiopia
conventional short form: Ethiopia
local long form: YeItyop''iya Federalawi Demokrasiyawi Ripeblik
local short form: YeItyop''iya
abbreviation: FDRE
Data code: ET
Government type: federal republic
National capital: Addis Ababa
Administrative divisions: 9 ethnically-based administrative regions
(astedader akababiwach, singular - astedader akababi) and 1 federal
capital*: Addis Ababa*; Afar; Amhara; Benshangul/Gumaz; Gambela;
Harar; Oromia; Somali; Southern Nations, Nationalities and Peoples;
Tigray
Independence: oldest independent country in Africa and one of the
oldest in the world - at least 2,000 years
National holiday: National Day, 28 May (1991) (defeat of Mengistu
regime)
Constitution: new constitution promulgated in December 1994
Legal system: NA
Suffrage: 18 years of age; universal
Executive branch:
chief of state : President NEGASSO Gidada (since 22 August 1995)
head of government: Prime Minister MELES Zenawi (since NA August 1995)
cabinet: Council of Ministers as provided in the December 1994
constitution; ministers are selected by the prime minister and
approved by the Council of People''s Representatives
elections : president elected by the Council of People''s
Representatives for a six-year term; election last held June 1995
(next to be held NA 2001); prime minister designated by the party in
power following legislative elections
election results: NEGASSO Gidada elected president; percent of vote by
the Council of People''s Representatives - NA
Legislative branch: bicameral Parliament consists of the Council of
the Federation or upper chamber (117 seats; members are chosen by
state assemblies to serve five-year terms) and the Council of People''s
Representatives or lower chamber (548 seats; members are directly
elected by popular vote from single-member districts to serve
five-year terms); note - the upper chamber represents the ethnic
interests of the regional governments
elections: regional and national popular elections were held in May
and June 1995 (next to be held NA 2000) and the Federal Parliamentary
Assembly assumed legislative power on 21 August 1995
election results: percent of vote - NA; seats - NA; note - EPRDF won
nearly all seats
Judicial branch: Supreme Court, judges are elected by the national
legislature
Political parties and leaders: Ethiopian People''s Revolutionary
Democratic Front or EPRDF [MELES Zenawi]
Political pressure groups and leaders: Oromo Liberation Front or OLF;
All Amhara People''s Organization; Southern Ethiopia People''s
Democratic Coalition; numerous small, ethnic-based groups have formed
since MENGISTU''S resignation, including several Islamic militant
groups
International organization participation: ACP, AfDB, CCC, ECA, FAO,
G-24, G-77, IAEA, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, IGADD, ILO,
IMF, IMO, Intelsat, Interpol, IOC, ISO, ITU, NAM, OAU, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UNU, UPU, WFTU, WHO, WMO, WToO, WTrO (observer)
Diplomatic representation in the US:
chief of mission : Ambassador BERHANE Gebre-Christos
chancery: 2134 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 234-2281, 2282
FAX: [1] (202) 328-7950
Diplomatic representation from the US:
chief of mission: Ambassador David H. SHINN (17 June 1996)
embassy : Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 550666
FAX: [251] (1) 552191
Flag description: three equal horizontal bands of green (top), yellow,
and red with a yellow pentagram and single yellow rays emanating from
the angles between the points on a light blue disk centered on the
three bands; Ethiopia is the oldest independent country in Africa, and
the colors of her flag were so often adopted by other African
countries upon independence that they became known as the pan-African
colors','6cf93e5bc492591d0a36d988994d9709546d8d07cfc41a55f40ef0079a3f4fdc','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06e8f244fb6f7f26321512458ce0fb4181f0105681dfe0716892232a2920e4f',1997,'ID','Indonesia','introduction',6,'Iran
Current issues: The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements ("the DOP"), signed in Washington on 13
September 1993, provides for a transitional period not exceeding five
years of Palestinian interim self-government in the Gaza Strip and the
West Bank. Permanent status negotiations began on 5 May 1996. Under
the DOP, Israel agreed to transfer certain powers and responsibilities
to the Palestinian Authority, which includes a Palestinian Legislative
Council elected in January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A transfer of powers and
responsibilities for the Gaza Strip and Jericho has taken place
pursuant to the Israel-PLO 4 May 1994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of the West Bank
pursuant to the Israel-PLO 28 September 1995 Interim Agreement. The
DOP provides that Israel will retain responsibility during the
transitional period for external security and for internal security
and public order of settlements and Israelis. Permanent status is to
be determined through direct negotiations which began on 5 May 1996.
@Gaza Strip:Geography
Location: Middle East, bordering the Mediterranean Sea, between Egypt
and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: 0 sq km
Area - comparative: slightly more than twice the size of Washington,
DC
Land boundaries:
total: 62 km
border countries : Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent status to be
determined through further negotiation
Climate: temperate, mild winters, dry and warm to hot summers
Terrain: flat to rolling, sand- and dune-covered coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: NEGL
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 11%
other: 26% (1993 est.)
Irrigated land: 120 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: desertification; salination of fresh
water
Environment - international agreements:
party to : none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography - note: there are 24 Israeli settlements and civilian land
use sites in the Gaza Strip (August 1996 est.)
@Gaza Strip:People
Population: 987,869 (July 1997 est.)
note: in addition, there are 5,000 Israeli settlers in the Gaza Strip
(August 1996 est.)
Age structure:
0-14 years: 51% (male 261,014; female 248,236)
15-64 years: 46% (male 225,707; female 224,483)
65 years and over: 3% (male 12,281; female 16,148) (July 1997 est.)
Population growth rate: 6.59% (1997 est.)
Birth rate: 49.85 births/1,000 population (1997 est.)
Death rate: 4.2 deaths/1,000 population (1997 est.)
Net migration rate: 20.25 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over : 0.76 male(s)/female
total population: 1.02 male(s)/female (1997 est.)
Infant mortality rate: 26 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population : 72.46 years
male: 71.12 years
female : 73.87 years (1997 est.)
Total fertility rate: 7.68 children born/woman (1997 est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%, Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%, Christian 0.7%, Jewish
0.6%
Languages: Arabic, Hebrew (spoken by Israeli settlers and many
Palestinians), English (widely understood)
Literacy: NA
@Gaza Strip:Government
Country name:
conventional long form : none
conventional short form: Gaza Strip
local long form: none
local short form: Qita Ghazzah
Data code: GZ','bd67fe890ee0037bd906b4ae1c93e0b15b70572f352db8055357ddae6dad4e63','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('220257372c13d1e18899f0424d1a940e9bfb69d7befba5f48746b927e59a76c0',1997,'RW','Rwanda','introduction',7,'Saint Helena
Current issues: following the outbreak of genocidal strife in Rwanda
in April 1994 between Tutsi and Hutu factions, more than 2 million
refugees fled to neighboring Burundi, Tanzania, Uganda and Democratic
Republic of the Congo, formerly Zaire; according to the UN High
Commission on Refugees, in 1996 and early 1997 nearly 1,300,000 Hutus
returned to Rwanda; of these, 720,000 returned from Zaire, 480,000
from Tanzania, 88,000 from Burundi, and 10,000 from Uganda
@Rwanda:Geography
Location: Central Africa, east of Democratic Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,340 sq km
land: 24,950 sq km
water: 1,390 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Democratic Republic of the Congo 217
km, Tanzania 217 km, Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February to April, November to
January); mild in mountains with frost and snow possible
Terrain: mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point : Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore), wolframite (tungsten
ore), natural gas, hydropower
Land use:
arable land: 35%
permanent crops: 13%
permanent pastures : 18%
forests and woodland: 22%
other: 12% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: periodic droughts; the volcanic Virunga mountains are
in the northwest along the border with Democratic Republic of the','dbe59c7c3b660c2a5e842d7ca3ed44e1f60c295e0fd435902b04eb92744bfcba','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8673d8087ff57edf3c59a74f81766c404903dd114cf133abed7a5f04f0783d8d',1997,'SN','Senegal','introduction',8,'Serbia and Montenegro
Current issues: Serbia and Montenegro have asserted the formation of a
joint independent state, but this entity has not been formally
recognized as a state by the US; the US view is that the Socialist
Federal Republic of Yugoslavia (SFRY) has dissolved and that none of
the successor republics represents its continuation.
@Serbia and Montenegro:Geography
Location: Southeastern Europe, bordering the Adriatic Sea, between
Albania and Bosnia and Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total: 102,350 sq km (Serbia 88,412 sq km; Montenegro 13,938 sq km)
land: 102,136 sq km (Serbia 88,412 sq km; Montenegro 13,724 sq km)
water: 214 sq km (Serbia 0 sq km; Montenegro 214 sq km)
Area - comparative: slightly smaller than Kentucky (Serbia is slightly
larger than Maine; Montenegro is slightly smaller than Connecticut)
Land boundaries:
total: 2,246 km
border countries : Albania 287 km (114 km with Serbia, 173 km with
Montenegro), Bosnia and Herzegovina 527 km (312 km with Serbia, 215 km
with Montenegro), Bulgaria 318 km (with Serbia), Croatia (north) 241
km (with Serbia), Croatia (south) 25 km (with Montenegro), Hungary 151
km (with Serbia), The Former Yugoslav Republic of Macedonia 221 km
(with Serbia), Romania 476 km (with Serbia)
note: the internal boundary between Montenegro and Serbia is 211 km
Coastline: 199 km (Montenegro 199 km, Serbia 0 km)
Maritime claims: NA
Climate: in the north, continental climate (cold winter and hot, humid
summers with well distributed rainfall); central portion, continental
and Mediterranean climate; to the south, Adriatic climate along the
coast, hot, dry summers and autumns and relatively cold winters with
heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile plains; to the
east, limestone ranges and basins; to the southeast, ancient mountain
and hills; to the southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper, lead, zinc,
nickel, gold, pyrite, chrome
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures : NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: destructive earthquakes
Environment - current issues: pollution of coastal waters from sewage
outlets, especially in tourist-related areas such as Kotor; air
pollution around Belgrade and other industrial cities; water pollution
from industrial wastes dumped into the Sava which flows into the
Danube
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography - note: controls one of the major land routes from Western
Europe to Turkey and the Near East; strategic location along the
Adriatic coast
@Serbia and Montenegro:People
Population: 11,223,853 (July 1997 est.) (Montenegro - 680,212; Serbia
- 10,543,641)
Age structure:
0-14 years : Montenegro - 22% (male 78,101; female 73,067); Serbia -
21% (male 1,146,238; female 1,066,842)
15-64 years: Montenegro - 68% (male 231,641; female 227,245); Serbia -
67% (male 3,544,055; female 3,495,673)
65 years and over: Montenegro - 10% (male 28,880; female 41,278);
Serbia - 12% (male 555,592; female 735,241) (July 1997 est.)
Population growth rate: Montenegro - 0.00%; Serbia - -0.13% (1997
est.)
Birth rate: Montenegro - 13.93 births/1,000 population; Serbia - 12.68
births/1,000 population (1997 est.)
Death rate: Montenegro - 7.33 deaths/1,000 population; Serbia - 9.64
deaths/1,000 population (1997 est.)
Net migration rate: Montenegro: -6.61 migrant(s)/1,000 population;
Serbia: -4.34 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : Montenegro - 1.09 male(s)/female; Serbia - 1.08
male(s)/female
under 15 years: Montenegro - 1.07 male(s)/female; Serbia - 1.07
male(s)/female
15-64 years: Montenegro - 1.02 male(s)/female; Serbia - 1.01
male(s)/female
65 years and over: Montenegro - 0.70 male(s)/female; Serbia - 0.76
male(s)/female
all ages : Montenegro - 0.99 male(s)/female Serbia - 0.99
male(s)/female (1997 est.)
Infant mortality rate: Montenegro - 11.50 deaths/1,000 live births;
Serbia - 17.8 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population : Montenegro - 75.96 years; Serbia - 72.9 years
male: Montenegro - 72.48 years; Serbia - 70.51 years
female: Montenegro - 79.76 Serbia - 75.47 years (1997 est.)
Total fertility rate: Montenegro - 1.80 children born/woman; Serbia -
1.76 children born/woman (1997 est.)
Nationality:
noun: Serb(s) and Montenegrin(s)
adjective: Serbian and Montenegrin
Ethnic groups: Serbs 63%, Albanians 14%, Montenegrins 6%, Hungarians
4%, other 13%
Religions: Orthodox 65%, Muslim 19%, Roman Catholic 4%, Protestant 1%,
other 11%
Languages: Serbo-Croatian 95%, Albanian 5%
Literacy: NA
@Serbia and Montenegro:Government
Country name:
conventional long form: none
conventional short form: Serbia and Montenegro
local long form: none
local short form: Srbija-Crna Gora
note : Serbia and Montenegro has self-proclaimed itself the "Federal
Republic of Yugoslavia," but the US view is that the Socialist Federal
Republic of Yugoslavia (SFRY) has dissolved and that none of the
successor republics represents its continuation
Data code: Serbia - SR; Montenegro - MW
Government type: republic
National capital: Belgrade
Administrative divisions: 2 republics (pokajine, singular - pokajina);
and 2 nominally autonomous provinces*; Kosovo*, Montenegro, Serbia,
Vojvodina*
Independence: 11 April 1992 (Federal Republic of Yugoslavia formed as
self-proclaimed successor to the Socialist Federal Republic of
Yugoslavia - SFRY)
National holiday: St. Vitus Day, 28 June
Constitution: 27 April 1992
Legal system: based on civil law system
Suffrage: 16 years of age, if employed; 18 years of age, universal
Executive branch:
chief of state: President Zoran LILIC (since 25 June 1993); note -
Slobodan MILOSEVIC is president of Serbia (since 9 December 1990);
Momir BULATOVIC is president of Montenegro (since 23 December 1990)
head of government: Prime Minister Radoje KONTIC (since 29 December
1992); Deputy Prime Ministers Jovan ZEBIC (since NA March 1993), Uros
KLIKOVAC (since 15 September 1994), and Nikola SAINOVIC (since 15
September 1995)
cabinet: Federal Executive Council
elections: president elected by the Federal Assembly for a four-year
term; election last held 25 June 1993 (next to be held NA 1997); prime
minister nominated by the president
election results : Zoran LILIC elected president; percent of
legislative vote - NA
Legislative branch: bicameral Federal Assembly or Savezna Skupstina
consists of the Chamber of Republics or Vece Republika (40 seats, 20
Serbian, 20 Montenegrin; members distributed on the basis of party
representation in the republican assemblies to serve four-year terms)
and the Chamber of Citizens or Vece Gradjana (138 seats, 108 Serbian
with half elected by constituency majorities and half by proportional
representation, 30 Montenegrin with six elected by constituency and 24
proportionally; members serve four-year terms)
elections: Chamber of Republics - last held 24 December 1996 (next to
be held NA 2000); Chamber of Citizens - last held 3 November 1996
(next to be held NA 2000)
election results : Chamber of Republics - percent of vote by party -
NA; seats by party - NA; note - seats are filled on a proportional
basis to reflect the composition of the legislatures of the republics
of Montenegro and Serbia; Chamber of Citizens - percent of vote by
party - NA; seats by party - SPS/JUL/ND 64, Zajedno 22, DPSCG 20, SRS
16, NS 8, SVM 3, other 5; note - Zajedno coalition includes SPO, DS,
GSS
Judicial branch: Federal Court or Savezni Sud, judges are elected by
the Federal Assembly; Constitutional Court, judges are elected by the
Federal Assembly
Political parties and leaders: Serbian Socialist Party or SPS (former
Communist Party) [Slobodan MILOSEVIC]; Serbian Radical Party or SRS
[Vojislav SESELJ]; Serbian Renewal Movement or SPO [Vuk DRASKOVIC,
president]; Democratic Party or DS [Zoran DJINDJIC]; Democratic Party
of Serbia or DSS [Vojislav KOSTUNICA]; Democratic Party of Socialists
of Montenegro or DPSCG [Momir BULATOVIC, president]; People''s Party of
Montenegro or NS [Milan PAROSKI]; Liberal Alliance of Montenegro
[Slavko PEROVIC]; Democratic Community of Vojvodina Hungarians or DZVM
[Sandor PALL]; League of Communists-Movement for Yugoslavia or SK-PJ
[Dragan ATANASOVSKI]; Democratic Alliance of Kosovo or LDK [Dr.
Ibrahim RUGOVA, president]; Party of Democratic Action or SDA
[Sulejman UGLJANIN]; Civic Alliance of Serbia or GSS [Vesna PESIC,
chairman]; Socialist Party of Montenegro or SP [leader NA]; Yugoslav
United Left or JUL [Mirjana MARKOVIC (MILOSEVIC''s wife)]; New
Democracy or ND [Dusan MIHAJLOVIC]; Alliance of Vojvodina Hungarians
or SVM
Political pressure groups and leaders: NA
Diplomatic representation in the US: the US and Serbia and Montenegro
do not maintain full diplomatic relations; the Embassy of the former
Socialist Federal Republic of Yugoslavia continues to function in the
US
chief of mission : Ambassador (vacant); Counselor, Charge d''Affaires
ad interim Nebojsa VUJOVIC
chancery: 2410 California St. NW, Washington, DC 20008
telephone: [1] (202) 462-6566
Diplomatic representation from the US: the US and Serbia and
Montenegro do not maintain full diplomatic relations
chief of mission: Ambassador (vacant); Chief of Mission Richard M.
MILES
embassy: Kneza Milosa 50, 11000 Belgrade
mailing address : American Embassy, Belgrade, United States Department
of State, Washington, DC 20521-5070
telephone: [381] (11) 645655
FAX: [381] (11) 645332','65674480af718d34c816e9413d91a05d5d26be6d742887efd0e70c7241db9d5b','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29c63dd850c09f13414a3e33f24e8041ea44c6d5c78a7cf80c19efa5e808db01',1997,'TJ','Tajikistan','introduction',9,'Tanzania
Current issues: Tajikistan has experienced three changes of government
since it gained independence in September 1991. The current president,
Emomali RAHMONOV, was elected in November 1994, yet has been in power
since 1992. The country is suffering through its fourth year of a
civil conflict, with no clear end in sight. Underlying the conflict
are deeply rooted regional and clan-based animosities that pit a
government consisting of people primarily from the Kulob (Kulyab),
Khujand (Leninabad), and Hisor (Hissar) regions against a secular and
Islamic-led opposition from the Gharm, Gorno-Badakhshan, and
Qurghonteppa (Kurgan-Tyube) regions. Government and opposition
representatives have held periodic rounds of UN-mediated peace talks
and agreed in September 1994 to a cease-fire which has been
periodically extended. Russian-led peacekeeping troops are deployed
throughout the country, and Russian-commanded border guards are
stationed along the Tajikistani-Afghan border.
@Tajikistan:Geography
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent States
Area:
total : 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km, China 414 km, Kyrgyzstan 870
km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild winters; semiarid
to polar in Pamir Mountains
Terrain: Pamirs and Alay Mountains dominate landscape; western Fergana
Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes:
lowest point: Syrdariya 300 m
highest point: Qullai Kommunizm 7,495 m
Natural resources: significant hydropower potential, some petroleum,
uranium, mercury, brown coal, lead, zinc, antimony, tungsten
Land use:
arable land : 6%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 4%
other: 65% (1993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: inadequate sanitation facilities;
increasing levels of soil salinity; industrial pollution; excessive
pesticides; part of the basin of the shrinking Aral Sea suffers from
severe overutilization of available water for irrigation and
associated pollution
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography - note: landlocked
@Tajikistan:People
Population: 5,945,903 (July 1997 est.)
Age structure:
0-14 years: 42% (male 1,263,725; female 1,234,730)
15-64 years : 53% (male 1,578,940; female 1,599,458)
65 years and over: 5% (male 114,118; female 154,932) (July 1997 est.)
Population growth rate: 1.18% (1997 est.)
Birth rate: 27.93 births/1,000 population (1997 est.)
Death rate: 7.74 deaths/1,000 population (1997 est.)
Net migration rate: -8.42 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.99 male(s)/female (1997 est.)
Infant mortality rate: 109.5 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 64.68 years
male : 61.55 years
female: 67.97 years (1997 est.)
Total fertility rate: 3.58 children born/woman (1997 est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian 3.5% (declining because
of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in government and
business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
@Tajikistan:Government
Country name:
conventional long form : Republic of Tajikistan
conventional short form: Tajikistan
local long form: Jumhurii Tojikistan
local short form: none
former : Tajik Soviet Socialist Republic
Data code: TI
Government type: republic
National capital: Dushanbe
Administrative divisions: 2 oblasts (viloyatho, singular - viloyat)
and one autonomous oblast* (viloyati avtonomii); Viloyati Avtonomii
Badakhshoni Kuni* (Khorugh - formerly Khorog), Viloyati Khatlon
(Qurghonteppa - formerly Kurgan-Tyube), Viloyati Leninobod (Khujand -
formerly Leninabad)
note: the administrative center name follows in parentheses
Independence: 9 September 1991 (from Soviet Union)
National holiday: National Day, 9 September (1991)
Constitution: new constitution adopted 6 November 1994
Legal system: based on civil law system; no judicial review of
legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state : President Emomali RAHMONOV (since 6 November 1994;
head of state and Assembly chairman since NA November 1992)
head of government: Prime Minister Yahyo AZIMOV (since 8 February
1996)
cabinet: Council of Ministers appointed by the president who proposes
them to the Supreme Assembly for approval
elections : president elected by popular vote for a five-year term;
election last held 6 November 1994 (next to be held NA 1999); prime
minister appointed by the president
election results: Emomali RAHMONOV elected president; percent of vote
- Emomali RAHMONOV 58%, Abdumalik ABDULLAJANOV 40%
Legislative branch: unicameral Supreme Assembly or Majlisi Oli (181
seats; members are popularly elected to serve five-year terms)
elections : last held 26 February and 12 March 1995 (next to be held
NA 2000)
election results: percent of vote by party - NA; estimated seats by
party - Communist Party and affiliates 100, People''s Party 10, Party
of People''s Unity 6, Party of Economic and Political Renewal 1, other
64
Judicial branch: Supreme Court, judges are appointed by the president
Political parties and leaders: People''s Party of Tajikistan [Abdumajid
DOSTIYEV]; National Revival Bloc [Abdumalik ABDULLOJONOV]; Tajik
Communist Party [Shodi SHABDOLOV]; Democratic Party [Jumaboy NIYAZOV,
chairman]; Islamic Renaissance Party or IRP [Mohammed Sharif
HIMMATZODA, chairman]; Rebirth (Rastokhez) [Takhir ABDUZHABOROV]; Lali
Badakhshan Society [Atobek AMIRBEK]; Tajikistan Party of Economic and
Political Renewal or TPEPR; Citizenship, Patriotism, Unity Party
[Bobokhon MAHMADOV]; Adolatho "Justice" Party [Abdurahmon KARIMOV,
chairman]
Political pressure groups and leaders: Tajikistan Opposition Movement
based in northern Afghanistan [Seyed Abdullah NURI, chairman]
International organization participation: CIS, EBRD, ECE, ECO, ESCAP,
FAO, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, Intelsat, IOC, IOM,
ITU, NACC, OIC, OSCE, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO,
WMO, WTrO (observer)
Diplomatic representation in the US: Tajikistan does not have an
embassy in the US, but has a mission at the UN: address - 136 East
67th Street, New York, NY 10021, telephone - [1] (212) 472-7645, FAX -
[1] (212) 628-0252; permanent representative to the UN is Rashid
ALIMOV
Diplomatic representation from the US:
chief of mission: Ambassador R. Grant SMITH
embassy : interim chancery, Oktyabrskaya Hotel, 105A Prospect Rudaki,
Dushanbe 734001
mailing address: use embassy street address
telephone : [7] (3772) 21-03-56
FAX: Telex (787) 20116
Flag description: three horizontal stripes of red (top), a wider
stripe of white, and green; a gold crown surmounted by seven
five-pointed gold stars is located in the center of the white stripe','c051ba0b55e107b6d95fd925d4e323eba2cc157993d1326f065846eff61d04d0','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88699a200b455b8aeabf372022def9e4487d6f213ad23fbb11d7db33905b8b5a',1997,'WF','Wallis and Futuna','introduction',10,'West Bank
Current issues: The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements ("the DOP"), signed in Washington on 13
September 1993, provides for a transitional period not exceeding five
years of Palestinian interim self-government in the Gaza Strip and the
West Bank. Permanent status negotiations began on 5 May 1996. Under
the DOP, Israel agreed to transfer certain powers and responsibilities
to the Palestinian Authority, which includes a Palestinian Legislative
Council elected in January 1996, as part of interim self-governing
arrangements in the West Bank and Gaza Strip. A transfer of powers and
responsibilities for the Gaza Strip and Jericho has taken place
pursuant to the Israel-PLO 4 May 1994 Cairo Agreement on the Gaza
Strip and the Jericho Area and in additional areas of the West Bank
pursuant to the Israel-PLO 28 September 1995 Interim Agreement. The
DOP provides that Israel will retain responsibility during the
transitional period for external security and for internal security
and public order of settlements and Israelis. Permanent status is to
be determined through direct negotiations which began on 5 May 1996.
@West Bank:Geography
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the northwest quarter of
the Dead Sea, but excludes Mt. Scopus; East Jerusalem and Jerusalem No
Man''s Land are also included only as a means of depicting the entire
area occupied by Israel in 1967
Area - comparative: slightly smaller than Delaware
Land boundaries:
total : 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, temperature and precipitation vary with altitude,
warm to hot summers, cool to mild winters
Terrain: mostly rugged dissected upland, some vegetation in west, but
barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops : 0%
permanent pastures: 32%
forests and woodland: 1%
other: 40%
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified : none of the selected agreements
Geography - note: landlocked; highlands are main recharge area for
Israel''s coastal aquifers; there are 203 Israeli settlements and
civilian land use sites in the West Bank and 26 in East Jerusalem
(August 1996 est.)
@West Bank:People
Population: 1,495,683 (July 1997 est.)
note: in addition, there are 136,000 Israeli settlers in the West Bank
and 156,000 in East Jerusalem (August 1996 est.)
Age structure:
0-14 years: 46% (male 347,152; female 329,906)
15-64 years : 51% (male 387,847; female 380,629)
65 years and over: 3% (male 21,223; female 28,926) (July 1997 est.)
Population growth rate: 4.32% (1997 est.)
Birth rate: 37.71 births/1,000 population (1997 est.)
Death rate: 4.5 deaths/1,000 population (1997 est.)
Net migration rate: 10.03 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1.02 male(s)/female (1997 est.)
Infant mortality rate: 27.5 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 72.11 years
male: 70.43 years
female: 73.88 years (1997 est.)
Total fertility rate: 5.06 children born/woman (1997 est.)
Nationality:
noun : NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%, Jewish 17%
Religions: Muslim 75% (predominantly Sunni), Jewish 17%, Christian and
other 8%
Languages: Arabic, Hebrew (spoken by Israeli settlers and many
Palestinians), English (widely understood)
Literacy: NA
@West Bank:Government
Country name:
conventional long form: none
conventional short form: West Bank
Data code: WE','0624dd1a1dc458c810cf3c8cbabe0206aeb73aeaac722d85350a810e8a71597b','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('786b2fb85d105409a2058648fdab8ca23f49ffedb1c748dc752bdabcb516d5f1',1997,'ZW','Zimbabwe','introduction',11,'______________________________________________________________________
The World Factbook is prepared by the Central Intelligence Agency for
the use of US Government officials, and the style, format, coverage,
and content are designed to meet their specific requirements.
Information was provided by the American Geophysical Union, Bureau of
the Census, Central Intelligence Agency, Defense Intelligence Agency,
Defense Nuclear Agency, Department of State, Foreign Broadcast
Information Service, Maritime Administration, National Imagery and
Mapping Agency, National Maritime Intelligence Center, National
Science Foundation (Antarctic Sciences Section), Office of Insular
Affairs, US Board on Geographic Names, US Coast Guard, and other
public and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA).
The official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn: Public Affairs Staff
Washington, DC 20505
Telephone: [1](703)482-0623
FAX: [1](703)482-1739
______________________________________________________________________
A BRIEF HISTORY OF BASIC INTELLIGENCE AND THE WORLD FACTBOOK
The Intelligence Cycle is the process by which information is
acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source that may be
fragmentary, contradictory, unreliable, ambiguous, deceptive, or
wrong. Intelligence is information that has been collected,
integrated, evaluated, analyzed, and interpreted. Finished
intelligence is the final product of the Intelligence Cycle ready to
be delivered to the policymaker.
There are three types of finished intelligence: basic, current, and
estimative. Basic intelligence is the fundamental and factual
reference material on a country or issue, current intelligence reports
on new developments, and estimative intelligence judges probable
outcomes. The three are mutually supporting because basic intelligence
is the foundation on which the other two are based, current
intelligence helps to continually update the knowledge foundation, and
estimative intelligence serves to revise overall interpretations of
country and issue prospects for both basic and current intelligence.
The World Factbook, The President''s Daily Brief, and National
Intelligence Estimates are examples of the three types of finished
intelligence.
The United States has carried on foreign intelligence activities since
the days of George Washington, but only since World War II have they
been coordinated on a governmentwide basis. Three programs have
highlighted the development of coordinated basic intelligence since
that time: (1) the Joint Army Navy Intelligence Studies (JANIS), (2)
the National Intelligence Survey (NIS), and (3) The World Factbook.
During World War II intelligence consumers realized that the
production of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought home
to Congressional and executive branch leaders the need for integrating
and coordinating departmental reports to national policymakers.
Detailed general information was needed not only on such major powers
as Germany and Japan, but also on places of little previous interest.
In the Pacific Theater, for example, the Navy and Marines had to
launch amphibious operations against many islands about which
information was unconfirmed or nonexistent. Intelligence authorities
resolved that the United States should never again be caught
unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office of
Naval Intelligence - ONI), and Gen. William J. Donovan (Director of
the Office of Strategic Services - OSS) decided that a joint effort
should be initiated. A steering committee was appointed on 27 April
1943 that recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish the Joint
Army Navy Intelligence Studies (JANIS). JANIS was the first
interdepartmental basic intelligence program and fulfilled the needs
of the US Government for an authoritative and coordinated digest of
strategic basic intelligence. Between April 1943 and July 1947, the
board published 34 JANIS studies. JANIS performed well in the war
effort, and numerous letters of commendation were received including a
statement from Adm. Forrest Sherman, Chief of Staff, Pacific Ocean
Areas, which said "JANIS has become the indispensable reference work
for the shore-based planners."
The need for even more comprehensive basic intelligence in the postwar
world was well expressed in 1946 by George S. Pettee, a noted author
on national security, when he wrote in The Future of American Secret
Intelligence (Infantry Journal Press, 1946, page 46) that world
leadership in peace requires more elaborate intelligence than war.
"The conduct of peace involves all countries, all human activities-not
just the enemy and his war production."
The Central Intelligence Agency was established on 26 July 1947 and
officially began operating 18 September 1947. Effective 1 October
1947, the Director of Central Intelligence assumed operational
responsibility for JANIS. On 13 January 1948, the National Security
Council issued Intelligence Directive (NSCID) No. 3, which officially
authorized the National Intelligence Survey (NIS) program as a
peacetime replacement for the wartime JANIS program. Before adequate
NIS sections could be produced, it was necessary to develop gazetteers
and maps for an accurate presentation of intelligence by the
contributing agencies. The US Board on Geographic Names (BGN) compiled
the names, the Department of the Interior produced the gazetteers, and
CIA produced the maps.
The Hoover Commission''s Clark Committee, set up in 1954 to study the
structure and administration of the CIA, reported to Congress in 1955
that: "The National Intelligence Survey is an invaluable publication
which provides the essential elements of basic intelligence on all
areas of the world. . . . There will always be a continuing
requirement for keeping the Survey up-to-date." The Factbook was
created as an annual summary and update to the encyclopedic NIS
studies. The first classified Factbook was published in August 1962,
and the first unclassified version was published in June 1971. The NIS
program was terminated except for the Factbook and gazetteers in 1973.
The 1975 Factbook was the first to be made available to the public
with sales through the US Government Printing Office (GPO). The 1996
edition was the first to be printed by GPO. The year 1997 marks the
50th anniversary of the establishment of the Central Intelligence
Agency and the 54th year of continuous basic intelligence support to
the US Government by The World Factbook and its two predecessor
programs.
______________________________________________________________________
NOTES AND DEFINITIONS
There have been some significant changes in this edition. A schema or
Guide to Country Profiles has been added. The new maps and flags
accompanying each country profile are in color. The country name Zaire
has been officially changed to Democratic Republic of the Congo. Congo
is now referred to as Republic of the Congo. New reference maps of the
United States, Ethnolinguistic Groups in Afghanistan, and Central
Africa have been included. Introduction is a new category with two
entries--Current issues and Historical perspective that now appear in
only a few country profiles, but will be added to all countries in the
future. The Area--comparative entry was separated from the Area entry.
The lowest point and highest point information has been removed from
the Terrain entry and put into a new entry called Elevation extremes.
The former Environment entry has been replaced by three new
entries--Natural hazards, Environment--current issues, and
Environment--international agreements. US diplomatic representation
has been renamed Diplomatic representation from the US in order to
parallel the Diplomatic representation in the US entry. The former
Airports entry has been split into three separate entries--Airports,
Airports--with paved runways, and Airports--with unpaved runways. The
Defense category has been renamed Military. The Branches entry has
been renamed Military branches. The former Manpower availability entry
has been replaced by four new entries--Military manpower--military
age, Military manpower--availability, Military manpower--fit for
military service, and Military manpower--reaching military age
annually. The former Defense expenditures entry has been replaced by
two new entries--Military expenditures--dollar figure, and Military
expenditures--percent of GDP. Transnational Issues is a new category
that now includes only two existing entries (Illicit drugs and
Disputes--international) but additional entries will be considered in
the future.
Abbreviations: This information is included in Appendix A:
Abbreviations which includes all abbreviations and acronyms used in
the Factbook with their expansions.
Administrative divisions: This entry generally gives the numbers,
designatory terms, and first-order administrative divisions as
approved by the US Board on Geographic Names (BGN). Changes that have
been reported but not yet acted on by BGN are noted.
Age structure: This entry provides the distribution of the population
according to age. Information is included by sex and age group (0-14
years, 15-64 years, 65 years and over). The age structure of a
population will affect a country''s investment pattern. Countries with
young populations (high percentage under age 15) need to invest more
in schools, while countries with older populations (high percentage
ages 65 and over) need to invest more in the health sector. The age
structure can also be used to help predict potential political issues.
For example, the rapid growth of a young adult population unable to
find employment can lead to unrest.
Agriculture--products: This entry is a rank ordering of major crops
and products starting with the most important.
Airports: This entry gives the total number of airports. The runway(s)
may be paved (concrete or asphalt surfaces) or unpaved (grass, dirt,
sand, or gravel surfaces), but must be usable. Not all airports have
facilities for refueling, maintenance, or air traffic control.
Airports--with paved runways: This entry gives the total number of
airports with paved runways (concrete or asphalt surfaces). For
airports with more than one runway, only the longest runway is
included according to the following five groups--(1) over 3,047 m, (2)
2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to 1,523 m, and (5)
under 914 m. Not all airports have facilities for refueling,
maintenance, or air traffic control. Only airports with usable runways
are included in this listing.
Airports--with unpaved runways: This entry gives the total number of
airports with unpaved runways (grass, dirt, sand, or gravel surfaces).
For airports with more than one runway, only the longest runway is
included according to the following five groups--(1) over 3,047 m, (2)
2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to 1,523 m, and (5)
under 914 m. Not all airports have facilities for refueling,
maintenance, or air traffic control. Only airports with usable runways
are included in this listing.
Appendixes: This section includes Factbook-related material by topic.
Area: This entry includes three subfields. Total area is the sum of
all land and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of all water
surfaces delimited by international boundaries and/or coastlines,
including inland water bodies (lakes, reservoirs, rivers).
Area--comparative: This entry provides an area comparison based on
total area equivalents. Most entities are compared with the entire US
or one of the 50 states based on area measurements (1990 revised)
provided by the US Bureau of the Census. The smaller entities are
compared with Washington, DC (178 sq km, 69 sq mi) or The Mall in
Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Birth rate: This entry gives the average annual number of births
during a year per 1,000 population at midyear; also known as crude
birth rate. The birth rate is usually the dominant factor in
determining the rate of population growth. It depends on both the
level of fertility and the age structure of the population.
Budget: This entry includes revenues, total expenditures, and capital
expenditures.
Climate: This entry includes a brief description of typical weather
regimes throughout the year.
Coastline: This entry gives the total length of the boundary between
the land area (including islands) and the sea.
Communications: This category deals with the means of exchanging
information and includes the radio, telephone, and television entries.
Communications--note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions,
and major amendments.
Country map: Most versions of the Factbook provide a country map in
color. The maps were produced from the best information available at
the time of preparation. Names and/or boundaries may have changed
subsequently.
Country name: This entry includes all forms of the country''s name
approved by the US Board on Geographic Names (Italy is used as an
example): conventional long form (Italian Republic), conventional
short form (Italy), local long form (Repubblica Italiana), local short
form (Italia), former (Kingdom of Italy), as well as the abbreviation.
See the Terminology note regarding the use of the term "country."
Currency: This entry identifies the local medium of exchange and its
basic subunit.
Current issues: This entry briefly characterizes major geographic,
social, political, and military developments in the past 12 months and
may include a statement about one or two key future trends. This entry
appears for only a few countries at the present time, but will be
added to all countries in the future.
Data code: This entry gives the official US Government digraph that
precisely identifies every land entity without overlap, duplication,
or omission. AF, for example, is the data code for Afghanistan. This
two-letter country code is a standardized geopolitical data element
promulgated in the Federal Information Processing Standards
Publication (FIPS) 10-4 by the National Institute of Standards and
Technology at the US Department of Commerce and maintained by the
Office of the Geographer and Global Issues at the US Department of
State. The data code is used to eliminate confusion and
incompatibility in the collection, processing, and dissemination of
area-specific data and is particularly useful for interchanging data
between databases. Appendix F cross-references various country codes
and Appendix G does the same thing for hydrographic codes. Data
codes-country: This information is presented in Appendix F:
Cross-Reference List of Country Data Codes which includes the US
Government approved Federal Information Processing Standards (FIPS),
the International Organization for Standardization (ISO), and Internet
country codes.
Data codes--hydrographic: This information is presented in Appendix G:
Cross-Reference List of Hydrographic Data Codes which includes the
International Hydrographic Organization (IHO), Aeronautical Chart and
Information Center (ACIC; now National Imagery and Mapping Agency or
NIMA), and Defense Intelligence Agency (DIA) hydrographic codes. The
US Government has not yet approved a standard for hydrographic data
codes similar to the FIPS 10-4 standard for country data codes.
Dates of information: The information cutoff date was 1 January 1997,
although a few important changes after that date have been included.
Most demographic statistics are estimates for 1997.
Death rate: This entry gives the average annual number of deaths
during a year per 1,000 population at midyear; also known as crude
death rate. The death rate, while only a rough indicator of the
mortality situation in a country, accurately indicates the current
mortality impact on population growth. This indicator is significantly
affected by the age distribution, and most countries will eventually
show a rise in the rate, in spite of continued declines in mortality
at all ages, as declining fertility results in an aging population.
Debt--external: This entry gives the total amount of public foreign
financial obligations.
Dependency status: This entry describes the formal relationship
between a nonindependent entity and a sovereign nation.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular
sovereign nation.
Diplomatic representation: The US Government has diplomatic relations
with 184 nations, including 178 of the 185 UN members (excluded UN
members are Bhutan, Cuba, Iran, Iraq, North Korea, former Yugoslavia,
and the US itself). In addition, the US has diplomatic relations with
6 nations that are not in the UN--Holy See, Kiribati, Nauru,
Switzerland, Tonga, and Tuvalu. Diplomatic representation from the US:
This entry includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office locations,
consulate general locations, and consulate locations. Diplomatic
representation in the US: This entry includes the chief of mission,
chancery address, telephone number, FAX number, consulate general
locations, consulate locations, honorary consulate general locations,
and honorary consulate locations.
Disputes--international: This entry includes a wide variety of
situations that range from traditional bilateral boundary disputes to
unilateral claims of one sort or another. Information regarding
disputes over international terrestrial and maritime boundaries has
been reviewed by the US Department of State. References to other
situations involving borders or frontiers may also be included, such
as resource disputes, geopolitical questions, or irredentist issues,
however, inclusion does not necessarily constitute official acceptance
or recognition by the US Government.
Economic aid: This entry refers to bilateral commitments of official
development assistance (ODA) and other official flows (OOF). ODA is
defined as financial assistance which is concessional in character,
has the main objective to promote economic development and welfare of
LDCs, and contains a grant element of at least 25%. OOF transactions
are also official government assistance, but with a main objective
other than economic development and with a grant element less than
25%. OOF transactions include official export credits (such as Ex-Im
Bank credits), official equity and portfolio investment, and debt
reorganization by the official sector that does not meet concessional
terms. Aid is considered to have been committed when agreements are
initialed by the parties involved and constitute a formal declaration
of intent. The entry is separated into two components--donor and
recipient.
Economy: This category includes the entries dealing with the size,
development, and management of productive resources, i.e., land,
labor, and capital.
Economy--overview: This entry briefly describes the type of economy,
including the degree of market orientation, the level of economic
development, the most important natural resources, and the unique
areas of specialization. It also characterizes major economic events
and policy changes in the most recent 12 months and may include a
statement about one or two key future macroeconomic trends.
Electricity--capacity: This entry gives the maximum designed potential
for electricity production expressed in kilowatts.
Electricity--consumption per capita: This entry gives the figure for
annual electricity generation plus net imports or minus net exports,
divided by total population for the same year expressed in kilowatt
hours.
Electricity--production: This entry gives the annual amount of
electricity actually generated expressed in kilowatt hours.
Elevation extremes: This entry includes both the highest point and the
lowest point.
Entities: Some of the nations, dependent areas, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. "Nation" refers to a people politically organized into a
sovereign state with a definite territory. "Dependent area" refers to
a broad category of political entities that are associated in some way
with a nation. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include nations, dependencies, or
other geographic entities. There are a total of 266 separate
geographic entities in The World Factbook that may be categorized as
follows:
NATIONS
184 nations that are UN members (excluding the former Yugoslavia,
which is still counted by the UN)
7 nations that are not members of the UN--Holy See, Kiribati, Nauru,
Serbia and Montenegro, Switzerland, Tonga, Tuvalu
OTHER
1 Taiwan
DEPENDENT AREAS
6 Australian dependencies--Ashmore and Cartier Islands, Christmas
Island, Cocos (Keeling) Islands, Coral Sea Islands, Heard Island and
McDonald Islands, Norfolk Island
2 Danish dependencies--Faroe Islands, Greenland
2 Dutch dependencies--Aruba, Netherlands Antilles
16 French dependencies--Bassas da India, Clipperton Island, Europa
Island, French Guiana, French Polynesia, French Southern and Antarctic
Lands, Glorioso Islands, Guadeloupe, Juan de Nova Island, Martinique,
Mayotte, New Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin
Island, Wallis and Futuna
3 New Zealand dependencies--Cook Islands, Niue, Tokelau
3 Norwegian dependencies--Bouvet Island, Jan Mayen, Svalbard
1 Portuguese dependency--Macau
16 UK dependencies--Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar,
Guernsey, Hong Kong, Jersey, Isle of Man, Montserrat, Pitcairn
Islands, Saint Helena, South Georgia and the South Sandwich Islands,','3a5e904107e76d72feafd71e2cf3134214c670c7c4be547f27e608dd972b0a2e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5f027ce70c174804d8b87ae83835cfb189f808b0aa4ea068a87027524c71681',1997,'TC','Turks and Caicos Islands','introduction',12,'14 US dependencies--American Samoa, Baker Island, Guam, Howland
Island, Jarvis Island, Johnston Atoll, Kingman Reef, Midway Islands,
Navassa Island, Northern Mariana Islands, Palmyra Atoll, Puerto Rico,
Virgin Islands, Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West
Bank, Western Sahara
OTHER ENTITIES
4 oceans--Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean
1 World
__________
266 Total
Environment--current issues: This entry lists the most pressing and
important environmental problems.
Environment--international agreements: This entry separates country
participation in international environmental agreements into two
levels--party to and signed but not ratified. Agreements are listed in
alphabetical order by the abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix D:
Selected International Environmental Agreements which includes the
name, abbreviation, date opened for signature, date entered into
force, objective, and parties by category.
Ethnic groups: This entry provides a rank ordering of ethnic groups
starting with the largest and sometimes includes the percent of total
population. Exchange rates: This entry provides the official value of
a nation''s monetary unit at a given date or over a given period of
time, as expressed in units of local currency per US dollar and as
determined by international market forces or official fiat.
Executive branch: This entry includes several subfields. Chief of
state includes the name and title of the titular leader of the country
who represents the state at official and ceremonial functions but may
not be involved with the day-to-day activities of the government. Head
of government includes the name and title of the administrative leader
who is designated to manage the day-to-day activities of the
government. Cabinet includes the official name for this body of
advisers and the method of selection for members. Elections includes
the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the
percent of vote for each candidate in the last election. In the UK,
the monarch is the chief of state, and the prime minister is the head
of government. In the US, the President is both the chief of state and
the head of government.
Exports: This entry includes three subfields. Total value is the total
US dollar amount of exports on an f.o.b. basis. Commodities is a rank
ordering of exported products starting with the most important and
sometimes includes the percent of dollar value. Partners is a rank
ordering of trading partners starting with the most important and
sometimes includes the percent of dollar value.
Fiscal year: This entry identifies the beginning and ending months for
a country''s accounting period of 12 months, which often is the
calendar year but may begin in any month. FY93/94 refers to the fiscal
year that began in calendar year 1993 and ended in calendar year 1994.
All yearly references are for the calendar year (CY) unless indicated
as a noncalendar fiscal year (FY).
Flag description: This entry provides a written flag description
produced from actual flags or the best information available at the
time the entry was written. The flags of independent nations are used
by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook provide a color flag
available at the beginning of the country entry. The flag graphics
were produced from actual flags or the best information available at
the time of preparation. The flags of independent nations are used by
their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
GDP: This entry gives the gross domestic product (GDP) or value of all
final goods and services produced within a nation in a given year. GDP
dollar estimates in the Factbook are derived from purchasing power
parity (PPP) calculations. See the note on GDP methodology for more
information.
GDP methodology: In the Economy section, GDP dollar estimates for all
countries are derived from purchasing power parity (PPP) calculations
rather than from conversions at official currency exchange rates. The
PPP method involves the use of standardized international dollar price
weights, which are applied to the quantities of final goods and
services produced in a given economy. The data derived from the PPP
method provide a better comparison of economic well-being between
countries. The division of a GDP estimate in domestic currency by the
corresponding PPP estimate in dollars gives the PPP conversion rate.
When converted at PPP rates, $1,000 will buy the same market basket of
goods in any country. Whereas PPP estimates for OECD countries are
quite reliable, PPP estimates for developing countries are often rough
approximations. Most of the GDP estimates are based on extrapolation
of PPP numbers published by the UN International Comparison Program
(UNICP) and by Professors Robert Summers and Alan Heston of the
University of Pennsylvania and their colleagues. In contrast, currency
exchange rates depend on a variety of international and domestic
financial forces that often have little relation to domestic output.
In developing countries with weak currencies the exchange rate
estimate of GDP in dollars is typically one-fourth to one-half the PPP
estimate. Furthermore, exchange rates may suddenly go up or down by
10% or more because of market forces or official fiat whereas real
output has remained unchanged. On 12 January 1994, for example, the 14
countries of the African Financial Community (whose currencies are
tied to the French franc) devalued their currencies by 50%. This move,
of course, did not cut the real output of these countries by half. One
important caution: the proportion of, say, defense expenditures as a
percentage of GDP in local currency accounts may differ substantially
from the proportion when GDP accounts are expressed in PPP terms, as,
for example, when an observer tries to estimate the dollar level of
Russian or Japanese military expenditures. Note: the numbers for GDP
and other economic data can not be chained together from successive
volumes of the Factbook because of changes in the US dollar measuring
rod, revisions of data by statistical agencies, use of new or
different sources of information, and changes in national statistical
methods and practices. For statistical series on GDP and other
economic variables, see the [1]Handbook of International Economic
Statistics available from the same sources as The World Factbook.
GDP--composition by sector: This entry gives the percentage
contribution of agriculture, industry, and services to total GDP.
GDP--per capita: This entry shows GDP on a purchasing power parity
basis divided by population as of 1 July for the same year.
GDP--real growth rate: This entry gives GDP growth on an annual basis
adjusted for inflation and expressed as a percent.
Geographic coordinates: This entry includes rounded latitude and
longitude for finding purposes of the approximate geographic center of
the country and is based on the Gazetteer of Conventional Names, Third
Edition, August 1988, US Board on Geographic Names and on other
sources.
Geographic names: This information is presented in Appendix H:
Cross-Reference List of Geographic Names which indicates where various
geographic names--including the location of all US Foreign Service
Posts, alternate names of countries, former names, and political or
geographical portions of larger entities--can be found in The World
Factbook. Spellings are normally, but not always, those approved by
the US Board on Geographic Names (BGN). Alternate names are included
in parentheses, while additional information is included in brackets.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography--note: This entry includes miscellaneous geographic
information of significance not included elsewhere.
GNP: Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income earned
by its citizens abroad, minus income earned by foreigners from
domestic production. The Factbook uses GDP rather than GNP to measure
national production.
Government: This category includes the entries dealing with the system
for the adoption and administration of public policy.
Government type: This entry gives the basic form of government (e.g.,
republic, constitutional monarchy, federal republic, parliamentary
democracy, military dictatorship).
Government--note: This entry includes miscellaneous government
information of significance not included elsewhere.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value
of all final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of helicopter takeoff and
landing sites (which may or may not have fuel or other services).
Highways: This entry includes the total length of the highway system
as well as the length of the paved and unpaved components.
Historical perspective: This entry contains a brief summary of the
background information necessary to understand the current situation
in a country. The entry appears for only a few countries at the
present time, but will be added to all countries in the future.
Illicit drugs: This entry gives information on the five categories of
illicit drugs--narcotics, stimulants, depressants (sedatives),
hallucinogens, and cannabis. These categories include many drugs
legally produced and prescribed by doctors as well as those illegally
produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana
(pot, Acapulco gold, grass, reefer), tetrahydrocannabinol (THC,
Marinol), hashish (hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa,
which comes from cacao seeds and is used in making chocolate, cocoa,
and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal,
phenobarbital), benzodiazepines (Librium, Valium), methaqualone
(Quaalude), glutethimide (Doriden), and others (Equanil, Placidyl,
Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual.
Hallucinogens are drugs that affect sensation, thinking,
self-awareness, and emotion. Hallucinogens include LSD (acid,
microdot), mescaline and peyote (mexc, buttons, cactus), amphetamine
variants (PMA, STP, DOB), phencyclidine (PCP, angel dust, hog),
phencyclidine analogues (PCE, PCPy, TCP), and others (psilocybin,
psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant
(Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis
sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia.
Narcotics are drugs that relieve pain, often induce sleep, and refer
to opium, opium derivatives, and synthetic substitutes. Natural
narcotics include opium (paregoric, parepectolin), morphine
(MS-Contin, Roxanol), codeine (Tylenol with codeine, Empirin with
codeine, Robitussan AC), and thebaine. Semisynthetic narcotics include
heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan),
methadone (Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of
the opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature dried
opium poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis
that is chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Imports: This entry includes three subfields. Total value is the total
US dollar amount of imports on a c.i.f. or f.o.b. basis. Commodities
is a rank ordering of imported products starting with the most
important and sometimes includes the percent of dollar value. Partners
is a rank ordering of trading partners starting with the most
important and sometimes includes the percent of dollar value.
Independence: This entry gives the date that sovereignty was achieved
and from what nation.
Industrial production growth rate: This entry gives the annual
percentage increase in industrial production (includes manufacturing,
mining, and construction).
Industries: This entry provides a rank ordering of industries starting
with the largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of
infants under one year old in a given year per 1,000 live births
occurring in the same year. The infant mortality rate is often used an
indicator of the level of health in a country.
Inflation rate-consumer price index: This entry furnishes the annual
percent change in consumer prices compared with the previous year''s
consumer prices.
International disputes: see Disputes--international
International organization participation: This entry lists in
alphabetical order by abbreviation those international organizations
in which the subject country is a member or participates in some other
way.
International organizations: This information is presented in Appendix
C: International Organizations and Groups which includes the name,
abbreviation, address, telephone, FAX, date established, aim, and
members by category.
Introduction: This category includes two entries--Current issues and
Historical perspective.
Irrigated land: This entry gives the number of square kilometers of
land area that is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest
court(s) and a brief description of the selection process for members.
Labor force: This entry contains the total labor force figure and a
rank ordering of component parts by occupation.
Land boundaries: This entry contains the total length of all land
boundaries and the individual lengths for each of the contiguous
border countries.
Land use: This entry contains the percentage shares of total land area
for five different types of land use. Arable land--land cultivated for
crops that are replanted after each harvest like wheat, maize, and
rice. Permanent crops--land cultivated for crops that are not
replanted after each harvest like citrus, coffee, and rubber.
Permanent pastures--land permanently used for herbaceous forage crops.
Forests and woodland--land under dense or open stands of trees.
Other--any land type not specifically mentioned above like urban
areas, roads, desert, etc.
Languages: This entry provides a rank ordering of languages starting
with the largest and sometimes includes the percent of total
population speaking that language.
Legal system: This entry contains a brief description of the legal
system''s historical roots, role in government, and acceptance of
International Court of Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure
(unicameral, bicameral, tricameral), formal name, number of seats, and
term of office. Elections includes the nature of election process or
accession to power, date of the last election, and date of the next
election. Election results includes the percent of vote and/or number
of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of
years to be lived by a group of people born in the same year, if
mortality at each age remains constant in the future. The entry
includes total population as well as the male and female components.
Life expectancy at birth is also a measure of overall quality of life
in a country and summarizes the mortality at all ages. It can also be
thought of as indicating the potential return on investment in human
capital, and is necessary for the calculation of various actuarial
measures.
Literacy: This entry includes a definition of literacy and Census
Bureau percentages for the total population, males, and females. There
are no universal definitions and standards of literacy. Unless
otherwise specified, all rates are based on the most common
definition--the ability to read and write at a specified age.
Detailing the standards that individual countries use to assess the
ability to read and write is beyond the scope of the Factbook.
Information on literacy, while not a perfect measure of educational
results, is probably the most easily available and valid for
international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the
current rapidly changing, technology-driven world.
Location: This entry identifies the country''s regional location,
neighboring countries, and adjacent bodies of water.
Map references: This entry includes the name of the Factbook reference
map on which a country may be found. The entry on Geographic
coordinates may be helpful in finding some smaller countries.
Maritime claims: This entry includes the following claims: contiguous
zone, continental shelf, exclusive economic zone, exclusive fishing
zone, extended fishing zone, none (usually for a landlocked country),
other (unique maritime claims like Libya''s Gulf of Sidra Closing Line
or North Korea''s Military Boundary Line), and territorial sea. The
proximity of neighboring states may prevent some national claims from
being extended the full distance.
Merchant marine: Merchant marine may be defined as all ships engaged
in the carriage of goods; all commercial vessels (as opposed to all
nonmilitary ships) which excludes tugs, fishing vessels, offshore oil
rigs, etc.; or a grouping of merchant ships by nationality or
register. This entry contains information in two subfields--total and
ships by type. Total includes the total number of ships (1,000 GRT or
over), total DWT for all ships, and total GRT for all ships. Ships by
type includes a listing of barge carriers, bulk cargo ships, cargo
ships, combination bulk carriers, combination ore/oil carriers,
container ships, intermodal ships, liquefied gas tankers, livestock
carriers, multifunction large-load carriers, oil tankers, passenger
ships, passenger-cargo ships, railcar carriers, refrigerated cargo
ships, roll-on/roll-off cargo ships, short-sea passenger ships,
specialized tankers, tanker tug-barges, and vehicle carriers.
Captive register is a register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships
owned in the parent country; also referred to as an offshore register,
the offshore equivalent of an internal register. Ships on a captive
register will fly the same flag as the parent country, or a local
variant of it, but will be subject to the maritime laws and taxation
rules of the offshore territory. Although the nature of a captive
register makes it especially desirable for ships owned in the parent
country, just as in the internal register, the ships may also be owned
abroad. The captive register then acts as a flag of convenience
register, except that it is not the register of an independent state.
Flag of convenience register is a national register offering
registration to a merchant ship not owned in the flag state. The major
flags of convenience (FOC) attract ships to their registers by virtue
of low fees, low or nonexistent taxation of profits, and liberal
manning requirements. True FOC registers are characterized by having
relatively few of the registered ships actually owned in the flag
state. Thus, while virtually any flag can be used for ships under a
given set of circumstances, an FOC register is one where the majority
of the merchant fleet is owned abroad. It is also referred to as an
open register.
Flag state is the nation in which a ship is registered and which holds
legal jurisdiction over operation of the ship, whether at home or
abroad. Maritime legislation of the flag state determines how a ship
is crewed and taxed and whether a foreign-owned ship may be placed on
the register.
Internal register is a register of ships maintained as a subset of a
national register. Ships on the internal register fly the national
flag and have that nationality but are subject to a separate set of
maritime rules from those on the main national register. These
differences usually include lower taxation of profits, use of foreign
nationals as crew members, and, usually, ownership outside the flag
state (when it functions as an FOC register). The Norwegian
International Ship Register and Danish International Ship Register are
the most notable examples of an internal register. Both have been
instrumental in stemming flight from the national flag to flags of
convenience and in attracting foreign-owned ships to the Norwegian and
Danish flags.
Merchant ship is a vessel that carries goods against payment of
freight; commonly used to denote any nonmilitary ship but accurately
restricted to commercial vessels only.
Register is the record of a ship''s ownership and nationality as listed
with the maritime authorities of a country; also, the compendium of
such individual ships'' registrations. Registration of a ship provides
it with a nationality and makes it subject to the laws of the country
in which registered (the flag state) regardless of the nationality of
the ship''s ultimate owner.
Military: This category includes the entries dealing with a country''s
military structure, manpower, and expenditures.
Military branches: This entry lists the names of the ground, naval,
air, marine, and other defense or military-type forces.
Military expenditures--dollar figure: This entry gives current
military expenditures in US dollars; the figure is calculated by
multiplying the estimated defense spending in percentage terms by the
gross domestic product (GDP) in purchasing power parity (PPP) terms.
The figure should be treated with caution because of different price
patterns and accounting methods among nations.
Military expenditures--percent of GDP: This entry gives current
military expenditures as an estimated percent of gross domestic
product (GDP).
Military manpower--availability: This entry gives the total numbers of
males and females age 15-49 and assumes that every individual is fit
to serve.
Military manpower--fit for military service: This entry gives the
number of males and females age 15-49 fit for military service. This
is a more refined measure of potential military manpower availability
which tries to correct for the health situation in the country and
reduces the maximum potential number to a more realistic estimate of
the actual number fit to serve.
Military manpower--military age: This entry gives the minimum age at
which an individual may volunteer for military service or be subject
to conscription.
Military manpower--reaching military age annually: This entry gives
the number of draft-age males and females entering the military
manpower pool in any given year and is a measure of the availability
of draft-age young adults.
Military--note: This entry includes miscellaneous mil','ea54be0df0d79c9285bb5bf00af680b977d6474c261ee2bdb5c4a41a6b0272b3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ec0ff355e79241b3be2b6173e4d4785caec2352741fec8f2a0dcfc584f7c4b',1997,'TC','Turks and Caicos Islands','introduction',13,'itary information
of significance not included elsewhere.
Money figures: All money figures are expressed in contemporaneous US
dollars unless otherwise indicated.
National capital: This entry gives the location of the seat of
Current issues
Historical perspective','f114a42263eecba8879f73e726643b14a32ce9db79bf483d7986e75118ce8498','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24cc5b40a3ea46285d33e6e6f4a4c5b245f279d018651f5e24dabcec80205afd',1997,'AO','Angola','introduction',38,'Current issues: Civil war has been the norm since independence from
Portugal on 11 November 1975. A cease-fire lasted from 31 May 1991
until October 1992 when the insurgent National Union for the Total
Independence of Angola (UNITA) refused to accept its defeat in
internationally monitored elections and fighting resumed throughout
much of the countryside. The two sides signed another peace accord on
20 November 1994 and the cease-fire is generally holding, but military
tensions persist and banditry is increasing. In order to bring armed
insurgents under government control the peace accord of 20 November
1994 provided for the integration of former UNITA insurgents into the
Angolan armed forces. Military integration began in June 1996 and a
Government of National Unity and Reconciliation was installed in April
1997. Efforts which began in May 1997 to extend government into
UNITA-occupied areas are proceeding slowly. The original 7,200-man UN
peacekeeping force began a phased drawdown in late 1996. All UN
peacekeepers are scheduled to depart by September 1997 but a small UN
military observer force will probably remain in Angola through 1998.
@Angola:Geography
Location: Southern Africa, bordering the South Atlantic Ocean, between
Namibia and Democratic Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1,246,700 sq km
land : 1,246,700 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo 2,511 km of which
220 km is the boundary of discontiguous Cabinda province, Republic of
the Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 20 nm
Climate: semiarid in south and along coast to Luanda; north has cool,
dry season (May to October) and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore, phosphates, copper,
feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other : 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes periodic flooding on
the plateau
Environment - current issues: the overuse of pastures and subsequent
soil erosion attributable to population pressures; desertification;
deforestation of tropical rain forest, in response to both
international demand for tropical timber and to domestic use as fuel,
resulting in loss of biodiversity; soil erosion contributing to water
pollution and siltation of rivers and dams; inadequate supplies of
potable water
Environment - international agreements:
party to: Law of the Sea
signed, but not ratified: Biodiversity, Climate Change,
Desertification
Geography - note: Cabinda is separated from rest of country by Congo
(Kinshasa)
@Angola:People
Population: 10,548,847 (July 1997 est.)
Age structure:
0-14 years: 45% (male 2,393,009; female 2,327,186)
15-64 years: 52% (male 2,793,038; female 2,753,624)
65 years and over: 3% (male 131,720; female 150,270) (July 1997 est.)
Population growth rate: 3.06% (1997 est.)
Birth rate: 44.11 births/1,000 population (1997 est.)
Death rate: 17.24 deaths/1,000 population (1997 est.)
Net migration rate: 3.69 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.88 male(s)/female
total population : 1.02 male(s)/female (1997 est.)
Infant mortality rate: 135.7 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population : 47.32 years
male: 45.12 years
female: 49.64 years (1997 est.)
Total fertility rate: 6.27 children born/woman (1997 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%, mestico
(mixed European and Native African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic 38%, Protestant 15%
(est.)
Languages: Portuguese (official), Bantu and other African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male : 56%
female: 28% (1990 est.)
@Angola:Government
Country name:
conventional long form : Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Data code: AO
Government type: transitional government, nominally a multiparty
democracy with a strong presidential system
National capital: Luanda
Administrative divisions: 18 provinces (provincias, singular -
provincia); Bengo, Benguela, Bie, Cabinda, Cuando Cubango, Cuanza
Norte, Cuanza Sul, Cunene, Huambo, Huila, Luanda, Lunda Norte, Lunda
Sul, Malanje, Moxico, Namibe, Uige, Zaire
Independence: 11 November 1975 (from Portugal)
National holiday: Independence Day, 11 November (1975)
Constitution: 11 November 1975; revised 7 January 1978, 11 August
1980, 6 March 1991, and 26 August 1992
Legal system: based on Portuguese civil law system and customary law;
recently modified to accommodate political pluralism and increased use
of free markets
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Jose Eduardo DOS SANTOS (since 21 September
1979)
head of government: Prime Minister Fernando Jose de Franca Vieira Dias
VAN DUNEM (since 8 June 1996)
cabinet: Council of Ministers appointed by the president
elections: President DOS SANTOS originally elected without opposition
under a one-party system and stood for reelection in Angola''s first
multiparty elections in 28-29 September 1992, the last elections to be
held, (next to be held NA); prime minister appointed by the president
and answerable to the Assembly
election results: DOS SANTOS received 49.6% of the total vote, making
a run-off election necessary between him and second-place Jonas
SAVIMBI; the run-off was not held and SAVIMBI''s National Union for the
Total Independence of Angola (UNITA) disputed the results of the first
election; the civil war was resumed
Legislative branch: unicameral National Assembly or Assembleia
Nacional (223 seats; members elected by proportional vote to serve
four-year terms)
elections: last held 29-30 September 1992 (next to be held NA)
election results : percent of vote by party - MPLA 54%, UNITA 34%,
others 12%; seats by party - NA
Judicial branch: Supreme Court or Tribunal da Relacao, judges of the
Supreme Court are appointed by the president
Political parties and leaders: Popular Movement for the Liberation of
Angola or MPLA [Jose Eduardo DOS SANTOS], is the ruling party and has
been in power since 1975; National Union for the Total Independence of
Angola or UNITA [Jonas SAVIMBI], is the largest opposition party and
engaged in years of armed resistance to the government
note: about a dozen minor parties participated in the 1992 elections
but won few seats and have little influence in the National Assembly
Political pressure groups and leaders: Front for the Liberation of the
Enclave of Cabinda or FLEC
note: FLEC is waging a small-scale, highly factionalized, armed
struggle for the independence of Cabinda Province
International organization participation: ACP, AfDB, CCC, CEEAC
(observer), ECA, FAO, G-77, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Intelsat, Interpol, IOC, IOM, ITU, NAM, OAS (observer),
OAU, SADC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Antonio dos Santos FRANCA "N''dalu"
chancery: 1050 Connecticut Avenue, NW, Suite 760, Washington, DC 20036
telephone: [1] (202) 785-1156
FAX : [1] (202) 785-1258
Diplomatic representation from the US:
chief of mission: Ambassador Donald K. STEINBERG
embassy: No. 32 Rua Houari Boumedienne, Miramar, Luanda
mailing address: C.P. 6484, Luanda; American Embassy, Department of
State, Washington, DC 20521-2550 (pouch)
telephone : [244] (2) 345-481, 346-418
FAX: [244] (2) 346-924
Flag description: two equal horizontal bands of red (top) and black
with a centered yellow emblem consisting of a five-pointed star within
half a cogwheel crossed by a machete (in the style of a hammer and
sickle)','85f8a83c0612d36fb04f2e2d7a4b445a78bd29c8cbef19e4cf1a52fd1b276f7a','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a500b8dfc59bd9734a7752074c5f327a7a250f674a02705ba175f6e638e2ffc4',1997,'AM','Armenia','introduction',53,'Current issues: Armenia''s leaders remain preoccupied by Armenia''s
nine-year old conflict with Azerbaijan over the Nagorno-Karabakh
enclave. Although a cease-fire has been in effect since May 1994, the
sides have not made substantial progress toward a peaceful resolution.
President TER-PETROSSIAN''s latitude on the issue may be further
constrained by his controversial reelection in September 1996. When
supporters of the main opposition candidate stormed the parliament
following the announcement of TER-PETROSSIAN''s victory, MVD forces
were called in to restore order. The subsequent political standoff
between government and opposition supporters diminished in late 1996
as the government has gradually attempted reconciliation. Despite
these political problems, the Armenian government has been pursuing
its aggressive economic reform program, although implementation of its
privatization program stalled in late 1996.
@Armenia:Geography
Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent States
Area:
total : 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566 km, Azerbaijan-Naxcivan
exclave 221 km, Georgia 164 km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold winters
Terrain: high Armenian Plateau with mountains; little forest land;
fast flowing rivers; good soil in Aras River valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper, molybdenum, zinc,
alumina
Land use:
arable land : 17%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 15%
other: 41% (1993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes; droughts
Environment - current issues: soil pollution from toxic chemicals such
as DDT; energy blockade, the result of conflict with Azerbaijan, has
led to deforestation when citizens scavenged for firewood; pollution
of Hrazdan (Razdan) and Aras Rivers; the draining of Sevana Lich, a
result of its use as a source for hydropower, threatens drinking water
supplies; restart of Metsamor nuclear power plant without adequate
(IAEA-recommended) safety and backup systems
Environment - international agreements:
party to : Biodiversity, Climate Change, Nuclear Test Ban, Wetlands
signed, but not ratified: Desertification
Geography - note: landlocked
@Armenia:People
Population: 3,433,629 (July 1997 est.)
Age structure:
0-14 years: 27% (male 476,375; female 456,723)
15-64 years: 65% (male 1,088,103; female 1,134,649)
65 years and over: 8% (male 115,135; female 162,644) (July 1997 est.)
Population growth rate: -0.33% (1997 est.)
Birth rate: 13.59 births/1,000 population (1997 est.)
Death rate: 8.6 deaths/1,000 population (1997 est.)
Net migration rate: -8.32 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.96 male(s)/female (1997 est.)
Infant mortality rate: 40.4 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 66.9 years
male: 62.69 years
female: 71.32 years (1997 est.)
Total fertility rate: 1.71 children born/woman (1997 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian 2%, other (mostly
Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had emigrated from
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female : 98% (1989 est.)
@Armenia:Government
Country name:
conventional long form: Republic of Armenia
conventional short form: Armenia
local long form : Hayastani Hanrapetut''yun
local short form: Hayastan
former : Armenian Soviet Socialist Republic; Armenian Republic
Data code: AM
Government type: republic
National capital: Yerevan
Administrative divisions: 10 provinces (marzer, singular - marz) and 1
city* (k''aghak''ner, singular - k''aghak''); Aragatsotn, Ararat, Armavir,
Geghark''unik'', Kotayk'', Lorri, Shirak, Syunik'', Tavush, Vayots'' Dzor,
Yerevan*
Independence: 28 May 1918 (First Armenian Republic); 23 September 1991
(from Soviet Union)
National holiday: Referendum Day, 21 September
Constitution: adopted by nationwide referendum 5 July 1995
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state : President Levon Akopovich TER-PETROSSIAN (since NA
October 1991); note - prior to becoming Armenia''s first president,
TER-PETROSSIAN was chairman of the Armenian Supreme Soviet since 4
August 1990
head of government: Prime Minister Robert KOCHARIAN (since 20 March
1997)
cabinet : Council of Ministers appointed by the president
elections: president elected by popular vote for a five-year term;
election last held 22 September 1996 (next to be held NA September
2001); prime minister appointed by the president
election results: Levon Akopovich TER-PETROSSIAN elected president;
percent of vote - Levon Akopovich TER-PETROSSIAN 52%, Vazgen MANUKYAN
41%
Legislative branch: unicameral National Assembly or Azgayin Zhoghov
(190 seats; members serve five-year terms)
elections: last held 5 July 1995 (next to be held NA 2000)
election results : percent of vote by party - NA; seats by party -
Republican Bloc 159 (ANM 63, DLP-Hanrapetutyun Bloc 6, Republic Party
4, CDU 3, Intellectual Armenia 3, Social Democratic Party 2,
independents 78), SWM 8, ACP 7, NDU 5, NSDU 3, DLP 1, ARF 1, other 4,
vacant 2
Judicial branch: Supreme Court; Constitutional Court
Political parties and leaders:
Republic Bloc (Hanrapetoutioun): Armenian National Movement or ANM
[Husik LAZARIAN, chairman]; Democratic Liberal Party [Orthosis
GYONJIAN, chairman]; Republican Party [Ashot NAVARSARDIAN, chairman];
Christian Democratic Union or CDU [Azat ARSHAKIAN, chairman];
Intellectual Armenia [H. TOKMAJIAN]; Social Democratic (Hnchakian)
Party [Yeghia NAJARIAN]
opposition parties: Shamiram Women''s Movement or SWM [Shoger
MATEVOSIAN]; Armenian Communist Party or ACP [Sergey BADALYAN];
National Democratic Union or NDU [Davit VARDANIAN and Vasgen
MANUKIAN]; Union of National Self-Determination or NSDU [Paruir
HAIRIKIAN, chairman]; Democratic Liberal Party or DLP [Rouben
MIRZAKHANIAN, chairman]; Armenian Revolutionary Federation or ARF
[Rouben HAKOBIAN, chairman]
International organization participation: BSEC, CCC, CE (guest), CIS,
EBRD, ECE, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFAD, IFC, IFRCS, ILO,
IMF, Intelsat, Interpol, IOC, IOM, ISO (correspondent), ITU, NACC, NAM
(observer), OSCE, PFP, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO,
WIPO, WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Ruben SHUGARIAN
chancery: 2225 R Street NW, Washington, DC 20008
telephone: [1] (202) 319-1976
FAX : [1] (202) 319-2982
consulate(s) general: Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Peter TOMSEN
embassy: 18 Gen Bagramian, Yerevan
mailing address : use embassy street address
telephone: [374] (2) 151-144, 524-661
FAX: [374] (2) 151-550
Flag description: three equal horizontal bands of red (top), blue, and
gold','ec2f385886031004204eeaf3417107f1f9ca2bbd674053aa9d293c9329ecd616','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b34db268be02bac0c1d55090fa3191e561ff8c46bac18a1546ed51d202dd619',1997,'BA','Bosnia and Herzegovina','introduction',101,'Current issues: On 21 November 1995, in Dayton, Ohio, the former
Yugoslavia''s three warring parties signed a peace agreement that
brought to a halt over three years of interethnic civil strife in
Bosnia and Herzegovina (the final agreement was signed in Paris on 14
December 1995). The Dayton Agreement, signed by Bosnian President
IZETBEGOVIC, Croatian President TUDJMAN, and Serbian President
MILOSEVIC, divides Bosnia and Herzegovina roughly equally between the
Muslim/Croat Federation and the Bosnian Serbs while maintaining
Bosnia''s currently recognized borders. In 1995-96, a NATO-led
international peacekeeping force (IFOR) of 60,000 troops served in
Bosnia to implement and monitor the military aspects of the agreement.
IFOR was succeeded by a smaller, NATO-led Stabilization Force (SFOR)
whose mission is to deter renewed hostilities. SFOR will remain in
place until June 1998. A High Representative appointed by the UN
Security Council is responsible for civilian implementation of the
accord, including monitoring implementation, facilitating any
difficulties arising in connection with civilian implementation, and
coordinating activities of the civilian organizations and agencies in
Bosnia and Herzegovina. The Bosnian conflict began in the spring of
1992 when the Government of Bosnia and Herzegovina held a referendum
on independence and the Bosnian Serbs - supported by neighboring
Serbia - responded with armed resistance aimed at partitioning the
republic along ethnic lines and joining Serb-held areas to form a
"greater Serbia." In March 1994, Bosnia''s Muslims and Croats reduced
the number of warring factions from three to two by signing an
agreement in Washington creating their joint Muslim/Croat Federation
of Bosnia and Herzegovina. The Federation, formed by the Muslims and
Croats in March 1994, is one of two entities (the other being the
Bosnian Serb-led Republika Srpska) that comprise Bosnia and
Herzegovina.
@Bosnia and Herzegovina:Geography
Location: Southeastern Europe, bordering the Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area:
total: 51,233 sq km
land: 51,233 sq km
water: 0 sq km
Area - comparative: slightly smaller than West Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km, Serbia and Montenegro 527 km (312 km
with Serbia, 215 km with Montenegro)
Coastline: 20 km
Maritime claims: NA
Climate: hot summers and cold winters; areas of high elevation have
short, cool summers and long, severe winters; mild, rainy winters
along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese, forests, copper,
chromium, lead, zinc
Land use:
arable land: 14%
permanent crops : 5%
permanent pastures: 20%
forests and woodland: 39%
other: 22% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent and destructive earthquakes
Environment - current issues: air pollution from metallurgical plants;
sites for disposing of urban waste are limited; widespread casualties,
water shortages, and destruction of infrastructure because of the
1992-95 civil strife
Environment - international agreements:
party to: Air Pollution, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography - note: within Bosnia and Herzegovina''s recognized borders,
the country is divided into a joint Muslim-Croat Federation (about 51%
of the territory) and a Serb Republic, The Republika Srpska [RS]
(about 49% of the territory); the region called Herzegovina is
contiguous to Croatia and traditionally has been settled by an ethnic
Croat majority
@Bosnia and Herzegovina:People
Population: 3,222,584 (July 1997 est.)
note: all data dealing with population is subject to considerable
error because of the dislocations caused by military action and ethnic
cleansing
Age structure:
0-14 years: 18% (male 301,637; female 284,694)
15-64 years: 70% (male 1,123,477; female 1,140,604)
65 years and over: 12% (male 145,711; female 226,461) (July 1997 est.)
Population growth rate: 5.09% (1997 est.)
Birth rate: 8.29 births/1,000 population (1997 est.)
Death rate: 13.88 deaths/1,000 population (1997 est.)
Net migration rate: 56.51 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.07 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.95 male(s)/female (1997 est.)
Infant mortality rate: 37 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 59.42 years
male : 54.58 years
female: 64.59 years (1997 est.)
Total fertility rate: 1.09 children born/woman (1997 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 40%, Muslim 38%, Croat 22% (est.)
Religions: Muslim 40%, Orthodox 31%, Catholic 15%, Protestant 4%,
other 10%
Languages: Serbo-Croatian (often called Bosnian) 99%
Literacy: NA
@Bosnia and Herzegovina:Government
Country name:
conventional long form : none
conventional short form: Bosnia and Herzegovina
local long form : none
local short form: Bosna i Hercegovina
Data code: BK
Government type: emerging democracy
National capital: Sarajevo
Administrative divisions: there are no first-order administrative
divisions approved by the US Government, but it has been reported that
the Muslim/Croat Federation is comprised of 10 cantons called by
either number or name - Goradzde (5), Livno (10), Middle Bosnia (6),
Neretva (7), Posavina (2), Sarajevo (9), Tuzla Podrinje (3), Una Sana
(1), West Herzegovina (8), Zenica Doboj (4)
Independence: NA April 1992 (from Yugoslavia)
National holiday: Republika Srpska - "Republic Day", 9 January;
Independence Day, 1 March; Bosnia - "Republic Day", 25 November
Constitution: the Dayton Agreement, signed 14 December 1995, included
a new constitution now in force
Legal system: based on civil law system
Suffrage: 16 years of age, if employed; 18 years of age, universal
Executive branch:
chief of state : Chairman of the Presidency Alija IZETBEGOVIC (since
14 September 1996); other members of the three-member rotating
presidency: Kresimir ZUBAK (since 14 September 1996 - Croat) and
Momcilo KRAJISNIK (since 14 September 1996 - Serb)
head of government: Cochairman of the Council of Ministers Haris
SILAJDZIC (since NA January 1997); Cochairman of the Council of
Ministers Boro BOSIC (since NA January 1997) NA
cabinet: Council of Ministers nominated by the council chairmen
note: president of the Muslim-Croat Federation of Bosnia and
Herzegovina: Vladimir SOLJIC (since March 1997); president of the
Republika Srpska: Biljana PLAVSIC (since September 1996)
elections: the three presidency members (one each Muslim, Croat, Serb)
are elected by direct election (first election for a two-year term,
thereafter for a four-year term); the president with the most votes
becomes the chairman; election last held 14 September 1996 (next to be
held September 1998); the cochairmen are nominated by the presidency
election results: Alija IZETBEGOVIC elected chairman of the collective
presidency with the highest number of votes; percent of vote - Alija
IZETBEGOVIC received 80% of the Muslim vote to Haris SILAJDZIC''s 14%;
Kresimir ZUBAK received 88% of the Croat vote to Ivo KOMSIC''s 11%;
Momcilo KRAJISNIK received 68% of the Serb vote to Mladen IVANIC''s 30%
Legislative branch: bicameral Parliamentary Assembly or Skupstina
consists of the National House of Representatives or Vijece Opcina (42
seats - 14 Serb, 14 Croat, and 14 Muslim; members serve NA-year terms)
and the House of Peoples or Vijece Gradanstvo (15 seats - 5 Muslim, 5
Croat, 5 Serb; members serve NA-year terms)
elections: National House of Representatives - elections last held 14
September 1996 (next to be held NA); note - the House of Peoples are
elected by the Muslim-Croat Federation''s 140-seat House of
Representatives (two-thirds) and the Bosnian Serb Republic''s 83-seat
National Assembly (one-third)
election results: National House of Representatives: two-thirds chosen
from the Muslim-Croat Federation: percent of vote by party - NA; seats
by party - SDA 16, HDZ-BiH 7, Joint List of Social Democrats 3, Party
for Bosnia and Herzegovina 2; one-third chosen from the Bosnian Serb
Republic: percent of vote by party - NA; seats by party - SDS 9, SDA
3, Democratic Patriotic Front/Union for Peace and Progress 2
note: the Muslim-Croat Federation has a House of Representatives with
140 seats: seats by party - SDA 80, HDZ-BiH 33, Party for Bosnia and
Herzegovina 11, Joint List of Social Democrats 10, other 6; the
Republika Srpska has a National Assembly with 83 seats: seats by party
- SDS 50, Democratic Patriotic Front/Union for Peace and Progress 10,
Serb Radical Party 7, SDA 6, other 10
Judicial branch: Supreme Court; Constitutional Court
Political parties and leaders: Party of Democratic Action or SDA
[Alija IZETBEGOVIC]; Croatian Democratic Union of BiH or HDZ-BiH [Bozo
RAJIC]; Serb Democratic Party or SDS [Alexander BUHA, acting
president]; Party for Bosnia [Haris SILAJDZIC]; Joint List of Social
Democrats; Democratic Patriotic Front/Union for Peace and Progress;
Civic Democratic Party or GDS [Ibrahim SPAHIC]; Croatian Peasants''
Party of BiH or HSS [Stanko STISKOVIC]; Independent Serbian Democratic
Party or NSDS [Milorad DODIK]; Liberal Bosniak Organization or LBO
[Muhamed FILIPOVIC]; Liberal Party or LS [Rasim KADIC, president];
Muslim-Bosniac Organization or MBO [Adil ZULFIKARPASIC]; Republican
Party of Bosnia and Herzegovina [Stjepan KLJUIC]; Serb Civic Council
or SGV [Mirko PEJANOVIC]; Serb Consultative Council [Ljubomir
BERBEROVIC]; Social Democratic Party or SDP (formerly the Democratic
Party of Socialists or DSS) [Zlatko LAGUMOZIJA, president]; Socialist
Party of Republika Srpska [Zivko RADISIC]; Union of Social Democrats
or SSDB [Selim BESLAGIC]; United Left of the Bosnian Serb Republic or
ULRS [Mile IVOSEVIC]; Yugoslav United Left or JUL [CAREVIC]; Social
Liberal Party [Miodrag ZIVANOVIC]; Serb Radical Party [Miodrag RAKIC];
Serb Patriotic Party [Slavko ZUPLJANIN]; Serb Homeland Party; Party of
Serbian Unity; Republik Srpska Independent Social Democrats [Branko
DOKIC, president]; Serb Party of Posavina and Krajina [Predrag
LAZAREVIC]; National Democratic Union [Fikret ABDIC]
note : 82 parties are registered for the September 1997 municipal
elections
Political pressure groups and leaders: NA
International organization participation: CE (guest), CEI, ECE, FAO,
IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, Intelsat, Interpol,
IOC, IOM (observer), ISO, ITU, NAM (guest), OIC (observer), OSCE, UN,
UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador Sven ALKALAJ
chancery: Suite 760, 1707 L Street NW, Washington, DC 20036
telephone: [1] (202) 833-3612, 3613, 3615
FAX: [1] (202) 833-2061
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador (vacant); Charge d''Affaires Robert
BEECROFT
embassy: 43 Ul. Djure Djakovica, Sarajevo
mailing address: American Embassy Sarajevo, US Department of State,
Washington, DC 20521-7130
telephone: [387] (71) 445-700
FAX: [387] (71) 659-722
Flag description: white with a large blue shield; the shield contains
white fleurs-de-lis with a white diagonal band running from the upper
hoist corner to the lower outer side
Government - note: Until declaring independence in spring 1992, Bosnia
and Herzegovina existed as a republic in the Federal Republic of
Yugoslavia. Bosnia was partitioned by fighting during 1992-95 and
governed by competing ethnic factions. Bosnia''s current governing
structures were created by the Dayton Accords, the 1995 peace
agreement which was officially signed in Paris on 14 December 1995 by
Bosnian President IZETBEGOVIC, Croatian President TUDJMAN, and Serbian
President MILOSEVIC. This agreement retained Bosnia''s exterior border
and created a joint multi-ethnic and democratic government. This
national government - based on proportional representation similar to
that which existed in the former socialist regime - is charged with
conducting foreign, economic, and fiscal policy. The Dayton Accords
also recognized a second tier of government, comprised of two entities
- a joint Muslim-Croat Federation and the Bosnian Serb Republika
Srpska (RS) - each presiding over roughly one-half the territory.
These Federation and RS governments are charged with overseeing
internal functions. As mandated by the Dayton Accords, the Bosnians on
14 September 1996 participated in the first post-war elections of
national, entity, and cantonal leaders. The Bosnians have been slow to
form and install new joint institutions. A new Federation cabinet was
sworn in 18 December 1996 and the new Bosnian central government
cabinet was confirmed on 3 January 1997.','9d1e80968c10ed8c90aeaa09ca586a2649f277d3bc10c410b4f5d78c87db2837','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd81c2ddc9b608989e83c370fb96e650d975db43d4679f3c2073405fdd679568',1997,'BI','Burundi','introduction',129,'Current issues: in a number of waves since October 1993, hundreds of
thousands of refugees have fled the ethnic violence between the Hutu
and Tutsi factions in Burundi and crossed into Rwanda, Tanzania, and
Democratic Republic of the Congo, formerly Zaire; since October 1996,
an estimated 92,000 Burundi Hutus who fled to Zaire have been forced
to return to Burundi by Tutsi rebel forces in Zaire, leaving an
estimated 35,000 still dispersed there; in Burundi, the ethnic
violence between the Hutus and the Tutsis continued in 1996, causing
an estimated additional 150,000 Burundi Hutus to flee to Tanzania,
thus raising their numbers in that country to about 250,000
@Burundi:Geography
Location: Central Africa, east of Democratic Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo 233 km, Rwanda 290
km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable altitude variation
(772 m to 2,760 m); average annual temperature varies with altitude
from 23 to 17 degrees centigrade but is generally moderate as the
average altitude is about 1,700 m; average annual rainfall is about
150 cm; wet seasons from February to May and September to November,
and dry seasons from June to August and December to January
Terrain: hilly and mountainous, dropping to a plateau in east, some
plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,760 m
Natural resources: nickel, uranium, rare earth oxides, peat, cobalt,
copper, platinum (not yet exploited), vanadium
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures : 36%
forests and woodland: 3%
other : 8% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: flooding, landslides
Environment - current issues: soil erosion as a result of overgrazing
and the expansion of agriculture into marginal lands; deforestation
(little forested land remains because of uncontrolled cutting of trees
for fuel); habitat loss threatens wildlife populations
Environment - international agreements:
party to: Endangered Species
signed, but not ratified : Biodiversity, Climate Change,
Desertification, Law of the Sea, Nuclear Test Ban
Geography - note: landlocked; straddles crest of the Nile-Congo
watershed
@Burundi:People
Population: 6,052,614 (July 1997 est.)
Age structure:
0-14 years: 47% (male 1,425,071; female 1,418,957)
15-64 years : 50% (male 1,490,426; female 1,558,362)
65 years and over: 3% (male 63,225; female 96,573) (July 1997 est.)
Population growth rate: 2.11% (1997 est.)
Birth rate: 42.33 births/1,000 population (1997 est.)
Death rate: 15.12 deaths/1,000 population (1997 est.)
Net migration rate: -6.12 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years : 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.97 male(s)/female (1997 est.)
Infant mortality rate: 100.5 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 49 years
male: 47.91 years
female : 50.12 years (1997 est.)
Total fertility rate: 6.48 children born/woman (1997 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic) 14%, Twa (Pygmy) 1%,
Europeans 3,000, South Asians 2,000
Religions: Christian 67% (Roman Catholic 62%, Protestant 5%),
indigenous beliefs 32%, Muslim 1%
Languages: Kirundi (official), French (official), Swahili (along Lake
Tanganyika and in the Bujumbura area)
Literacy:
definition: age 15 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1995 est.)
@Burundi:Government
Country name:
conventional long form: Republic of Burundi
conventional short form: Burundi
local long form: Republika y''u Burundi
local short form : Burundi
Data code: BY
Government type: republic
National capital: Bujumbura
Administrative divisions: 15 provinces; Bubanza, Bujumbura, Bururi,
Cankuzo, Cibitoke, Gitega, Karuzi, Kayanza, Kirundo, Makamba,
Muramvya, Muyinga, Ngozi, Rutana, Ruyigi
Independence: 1 July 1962 (from UN trusteeship under Belgian
administration)
National holiday: Independence Day, 1 July (1962)
Constitution: 13 March 1992; provides for establishment of a plural
political system
Legal system: based on German and Belgian civil codes and customary
law; does not accept compulsory ICJ jurisdiction
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: President Pierre BUYOYA (interim president since 27
September 1996) note - former President NTIBANTUNGANYA was overthrown
in a coup on 25 July 1996 and has taken refuge in the US ambassador''s
residence in Bujumbura; former Major (retired) Pierre BUYOYA has not
been recognized as president of Burundi by the US or most other
governments
head of government: Prime Minister Pascal-Firmin NDIMIRA (since 31
July 1996)
cabinet: Council of Ministers appointed by prime minister
elections : NA
Legislative branch: unicameral National Assembly or Assemblee
Nationale (81 seats; members are popularly elected on a proportional
basis to serve five-year terms)
elections: last held 29 June 1993 (next to be held NA 1998)
election results: percent of vote by party - FRODEBU 71%, UPRONA
21.4%; seats by party - (81 total) FRODEBU 65, UPRONA 16; other
parties won too small shares of the vote to win seats in the assembly
Judicial branch: Supreme Court or Cour Supreme
Political parties and leaders: Unity for National Progress or UPRONA
[Charles MUKASI, president]; Burundi Democratic Front or FRODEBU [Jean
MINANI, president]; Organization of the People of Burundi or RPB
[Sylvestre SINDAYIGAYA]; Socialist Party of Burundi or PSB; People''s
Reconciliation Party or PRP [Mathias HITIMANA, leader]; opposition
parties, legalized in March 1992, include Burundi African Alliance for
the Salvation or ABASA, Rally for Democracy and Economic and Social
Development or RADDES [Cyrille SIGEJEJE, chairman], and Party for
National Redress or PARENA [Jean-Baptiste BAGAZA, leader]
Political pressure groups and leaders: NA
International organization participation: ACCT, ACP, AfDB, CCC, CEEAC,
CEPGL, ECA, FAO, G-77, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, Intelsat (nonsignatory user), Interpol, IOC, ISO (subscriber),
ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO,
WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Severin NTAHOMVUKIYE
chancery: Suite 212, 2233 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 342-2574
Diplomatic representation from the US:
chief of mission: Ambassador Morris N. HUGHES, Jr. (27 June l996)
embassy : Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone : [257] (2) 23454
FAX: [257] (2) 22926
Flag description: divided by a white diagonal cross into red panels
(top and bottom) and green panels (hoist side and outer side) with a
white disk superimposed at the center bearing three red six-pointed
stars outlined in green arranged in a triangular design (one star
above, two stars below)','9ac3dd3eef620d3528ed3056478689255d4dc6866ec19c18f662cdb44dc778b9','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f55854821054b54bb9051fea8724d0b24babcf986d83479b0c7470a89ff1d2',1997,'CF','Central African Republic','introduction',145,'Current issues: in 1996 the Central African Republic experienced three
mutinies by dissident elements of the armed forces which demanded back
pay as well as political and military reforms; continuing violence in
1997 between the government and rebel military and civilian groups
over pay issues, living conditions, and lack of opposition party
representation in the government has destroyed many businesses in the
capital, reducing tax revenues and exacerbating the government''s
problems in meeting expenses
@Central African Republic:Geography
Location: Central Africa, north of Democratic Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,980 sq km
land: 622,980 sq km
water : 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total : 5,203 km
border countries: Cameroon 797 km, Chad 1,197 km, Democratic Republic
of the Congo 1,577 km, Republic of the Congo 467 km, Sudan 1,165 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet summers
Terrain: vast, flat to rolling, monotonous plateau; scattered hills in
northeast and southwest
Elevation extremes:
lowest point : Oubangui River 335 m
highest point: Mount Gaou 1,420 m
Natural resources: diamonds, uranium, timber, gold, oil
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other: 17% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hot, dry, dusty harmattan winds affect northern
areas; floods are common
Environment - current issues: tap water is not potable; poaching has
diminished its reputation as one of the last great wildlife refuges;
desertification; deforestation
Environment - international agreements:
party to : Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: landlocked; almost the precise center of Africa
@Central African Republic:People
Population: 3,342,051 (July 1997 est.)
Age structure:
0-14 years: 44% (male 738,623; female 731,163)
15-64 years : 52% (male 858,386; female 894,695)
65 years and over: 4% (male 54,848; female 64,336) (July 1997 est.)
Population growth rate: 2.01% (1997 est.)
Birth rate: 39.52 births/1,000 population (1997 est.)
Death rate: 17.94 deaths/1,000 population (1997 est.)
Net migration rate: -1.5 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years : 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.98 male(s)/female (1997 est.)
Infant mortality rate: 110.2 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 45.24 years
male: 44.4 years
female : 46.12 years (1997 est.)
Total fertility rate: 5.35 children born/woman (1997 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 34%, Banda 27%, Sara 10%, Mandjia 21%, Mboum 4%,
M''Baka 4%, Europeans 6,500 (including 3,600 French)
Religions: indigenous beliefs 24%, Protestant 25%, Roman Catholic 25%,
Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence the Christian
majority
Languages: French (official), Sangho (lingua franca and national
language), Arabic, Hunsa, Swahili
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 68.5%
female: 52.4% (1995 est.)
@Central African Republic:Government
Country name:
conventional long form: Central African Republic
conventional short form: none
local long form : Republique Centrafricaine
local short form: none
former: Central African Empire
abbreviation: CAR
Data code: CT
Government type: republic;
National capital: Bangui
Administrative divisions: 14 prefectures (prefectures, singular -
prefecture), 2 economic prefectures* (prefectures economiques,
singular - prefecture economique), and 1 commune**; Bamingui-Bangoran,
Bangui**, Basse-Kotto, Gribingui*, Haute-Kotto, Haute-Sangha,
Haut-Mbomou, Kemo-Gribingui, Lobaye, Mbomou, Nana-Mambere,
Ombella-Mpoko, Ouaka, Ouham, Ouham-Pende, Sangha*, Vakaga
Independence: 13 August 1960 (from France)
National holiday: National Day, 1 December (1958) (proclamation of the
republic)
Constitution: passed by referendum 29 December 1994; adopted 7 January
1995
Legal system: based on French law
Suffrage: 21 years of age; universal
Executive branch:
chief of state: President Ange PATASSE (since 22 October 1993)
head of government: Prime Minister Michel GBEZERA-BRIA (since January
1997)
cabinet: Council of Ministers
elections : president elected by popular vote for a 6-year term;
election last held 19 September 1993 (next to be held October 1999);
prime minister appointed by the president
election results: Ange PATASSE elected president; percent of vote -
PATASSE 52.45%, Abel GOUMBA 45.62%
Legislative branch: unicameral National Assembly or Assemblee
Nationale (85 seats; members are elected by popular vote to serve
five-year terms)
elections: last held 19 September 1993 (next to be held October 1998)
election results: percent of vote by party - NA; seats by party - MLPC
34, RDC 13, PLD 7, FPP 7, ADP 6, PSD 3, CN 3, MDREC 1, PRC 1, FC 1,
MESAN 1, independents supporting David DACKO 6, independents 2
note: the National Assembly is advised by the Economic and Regional
Council or Conseil Economique et Regional; when they sit together they
are called the Congress or Congres
Judicial branch: Supreme Court or Cour Supreme, judges appointed by
the president; Constitutional Court, judges appointed by the president
Political parties and leaders: Alliance for Democracy and Progress or
ADP [Tchapka BREDE]; Central African Democratic Assembly or RDC [Andre
KOLINGBA]; Central African Republican Party or PRC; Civic Forum or FC
[Gen. Timothee MALENDOMA]; Democratic Movement for the Renaissance and
Evolution of Central Africa or MDREC [Joseph BENDOUNGA]; Liberal
Democratic Party or PLD [Nestor KOMBO-NAGUEMON]; Movement for the
Liberation of the Central African People or MLPC [the party of the
president, Ange Felix PATASSE]; Movement for Democracy and Development
or MDD [David DACKO]; National Convention or CN [David GALIAMBO];
Patriotic Front for Progress or FPP [Abel GOUMBA]; Social Democratic
Party or PSD [Enoch Derant LAKOUE]; Social Evolution Movement of Black
Africa or MESAN [Prosper LAVODRAMA and Joseph NGBANGADIBO]
International organization participation: ACCT, ACP, AfDB, BDEAC, CCC,
CEEAC, ECA, FAO, FZ, G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, Intelsat, Interpol, IOC, ITU, NAM, OAU, OIC
(observer), UDEAC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Henri KOBA
chancery: 1618 22nd Street NW, Washington, DC 20008
telephone : [1] (202) 483-7800, 7801
FAX: [1] (202) 332-9893
Diplomatic representation from the US:
chief of mission: Ambassador Mosina H. JORDAN
embassy: Avenue David Dacko, Bangui
mailing address : B. P. 924, Bangui
telephone: [236] 61 02 00, 61 25 78, 61 02 10
FAX: [236] 61 44 94
Flag description: four equal horizontal bands of blue (top), white,
green, and yellow with a vertical red band in center; there is a
yellow five-pointed star on the hoist side of the blue band','ffcd84acef9d3c593c7de2342e173008bdbc9e1feae378a2366b2086d20603d1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44b70f91343e12a60d0ef3de9a4e7c7b2046707045ccea0d734c893623ce2e0d',1997,'TD','Chad','introduction',149,'Historical perspective: After enduring decades of civil warfare among
ethnic groups as well as invasions by Libya, Chad got started toward a
more stable state with the seizure of the government in early December
1990 by former northern guerrilla leader Idress DEBY. His transitional
government eventually suppressed armed rebellion in all quarters of
the country, settled the territorial dispute with Libya on terms
favorable to Chad, produced a democratic constitution which was
ratified by popular referendum in March 1996, held multiparty national
presidential elections in June and July 1996 (DEBY won with 67% of the
vote), and held multiparty elections to the National Assembly in
January and February 1997, in which Idress DEBY''s party, Patriotic
Salvation Movement or MPS, won a majority of the seats.
@Chad:Geography
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total: 1.284 million sq km
land: 1,259,200 sq km
water: 24,800 sq km
Area - comparative: slightly more than three times the size of
California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1,094 km, Central African Republic 1,197
km, Libya 1,055 km, Niger 1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
Elevation extremes:
lowest point : Djourab Depression 175 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but exploration under way),
uranium, natron, kaolin, fish (Lake Chad)
Land use:
arable land: 3%
permanent crops : 0%
permanent pastures: 36%
forests and woodland: 26%
other: 35% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan winds occur in north;
periodic droughts; locust plagues
Environment - current issues: inadequate supplies of potable water;
improper waste disposal in rural areas contributes to soil and water
pollution; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
Geography - note: landlocked; Lake Chad is the most significant water
body in the Sahel
@Chad:People
Population: 7,166,023 (July 1997 est.)
Age structure:
0-14 years: 44% (male 1,586,873; female 1,579,086)
15-64 years: 53% (male 1,854,645; female 1,931,519)
65 years and over: 3% (male 94,516; female 119,384) (July 1997 est.)
Population growth rate: 2.67% (1997 est.)
Birth rate: 43.85 births/1,000 population (1997 est.)
Death rate: 17.15 deaths/1,000 population (1997 est.)
Net migration rate: 0 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.04 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (1997 est.)
Infant mortality rate: 118.7 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 47.88 years
male: 45.49 years
female: 50.37 years (1997 est.)
Total fertility rate: 5.79 children born/woman (1997 est.)
Nationality:
noun : Chadian(s)
adjective: Chadian
Ethnic groups: Muslims (Arabs, Toubou, Hadjerai, Fulbe, Kotoko,
Kanembou, Baguirmi, Boulala, Zaghawa, and Maba), non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moundang, Moussei, Massa), nonindigenous
150,000 (of whom 1,000 are French)
Religions: Muslim 50%, Christian 25%, indigenous beliefs (mostly
animism) 25%
Languages: French (official), Arabic (official), Sara and Sango (in
south), more than 100 different languages and dialects
Literacy:
definition: age 15 and over can read and write in French or Arabic
total population: 48.1%
male : 62.1%
female: 34.7% (1995 est.)
@Chad:Government
Country name:
conventional long form: Republic of Chad
conventional short form: Chad
local long form : Republique du Tchad
local short form: Tchad
Data code: CD
Government type: republic
National capital: N''Djamena
Administrative divisions: 14 prefectures (prefectures, singular -
prefecture); Batha, Biltine, Borkou-Ennedi-Tibesti, Chari-Baguirmi,
Guera, Kanem, Lac, Logone Occidental, Logone Oriental, Mayo-Kebbi,
Moyen-Chari, Ouaddai, Salamat, Tandjile
Independence: 11 August 1960 (from France)
National holiday: Independence Day, 11 August (1960)
Constitution: 31 March 1995, passed by referendum
Legal system: based on French civil law system and Chadian customary
law; does not accept compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Lt. Gen. Idriss DEBY (since 4 December 1990)
head of government : Prime Minister Djimasta KOIBLA (since 9 April
1995); appointed by the president
cabinet: Council of State appointed by the president on the
recommendation of the prime minister
elections: the constitution provides for the election of a president
by direct popular vote to serve a term of five years; if no candidate
receives at least 50% of the total vote, the two candidates receiving
the most votes must stand for a second round of voting; last held 2
June and 11 July 1996 (next to be held NA 2001); the prime minister is
appointed by the president
election results: in the first round of voting none of the 15
candidates received the required 50% of the total vote; percent of
vote, first round - Lt. Gen. Idress DEBY 47.8 %; percent of vote,
second round - Lt. Gen. DEBY 69.1%, Wadal Abdelkader KAMOUGUE 30.9%;
President DEBY reappointed Prime Minister Djimasta KOIBLA
Legislative branch: unicameral National Assembly (125 seats; members
serve four-year terms); replaces the Higher Transitional Council or
the Conseil Superieur de Transition
elections: National Assembly - last held in two rounds on 5 January
and 23 February 1997, (next to be held NA 2001); in the first round of
voting on 5 January 1997 some candidates won clear victories by
receiving 50% or more of the vote; where that did not happen, the two
highest scoring candidates stood for a second round of voting
election results: percent of vote by party - NA; seats by party - MPS
65, URD 29, UNDR 15, RDP 3, others 13
Judicial branch: Supreme Court; Court of Appeal; Criminal Courts;
Magistrate Courts
Political parties and leaders: Patriotic Salvation Movement or MPS
[Maldom Bada ABBAS, chairman], originally in opposition but now the
party in power and the party of the president; National Union for
Development and Renewal or UNDR [Saleh KEBZABO, leader]; Rally for
Democracy and Progress or RDP [Lal Mahamat CHOUA, leader]; Union for
Renewal and Democracy or URD [Gen. Wadal Abdelkader KAMOUGUE, leader];
note - in mid-1996 Chad had about 60 political parties, of which these
are the most prominent in the new National Assembly
Political pressure groups and leaders: NA
International organization participation: ACCT, ACP, AfDB, BDEAC,
CEEAC, ECA, FAO, FZ, G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IDB, IFAD,
IFRCS, ILO, IMF, Intelsat, Interpol, IOC, ITU, NAM, OAU, OIC, UDEAC,
UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission : Ambassador Mahamat Saleh AHMAT
chancery: 2002 R Street NW, Washington, DC 20009
telephone: [1] (202) 462-4009
FAX: [1] (202) 265-1937
Diplomatic representation from the US:
chief of mission: Ambassador David C. HALSTED
embassy: Avenue Felix Eboue, N''Djamena
mailing address : B. P. 413, N''Djamena
telephone: [235] (51) 70-09, (51) 90-52, (51) 92-33
FAX: [235] (51) 56-54
Flag description: three equal vertical bands of blue (hoist side),
yellow, and red; similar to the flag of Romania; also similar to the
flag of Andorra, which has a national coat of arms featuring a
quartered shield centered in the yellow band; design was based on the
flag of France','c3fe43556bf1e2c8e7ddf369110c39e5c47872376ba5ce03f515336cb4663e67','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20ef102f49e8a71fdb97e1db68c041fa3ab0c1031126f847591f645f92ca1986',1997,'MZ','Mozambique','introduction',170,'Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total : 2,170 sq km
land: 2,170 sq km
water: 0 sq km
Area - comparative: slightly more than 12 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; rainy season (November to May)
Terrain: volcanic islands, interiors vary from steep mountains to low
hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kartala 2,360 m
Natural resources: negligible
Land use:
arable land: 35%
permanent crops: 10%
permanent pastures: 7%
forests and woodland : 18%
other: 30% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones and tsunamis possible during rainy season
(December to April); Mount Kartala on Grand Comore is an active
volcano
Environment - current issues: soil degradation and erosion results
from crop cultivation on slopes without proper terracing;
deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: Desertification
Geography - note: important location at northern end of Mozambique
Channel
@Comoros:People
Population: 528,893 (July 1997 est.)
Age structure:
0-14 years: 42% (male 112,404; female 111,936)
15-64 years: 55% (male 142,604; female 146,382)
65 years and over : 3% (male 7,432; female 8,135) (July 1997 est.)
Population growth rate: 3.09% (1997 est.)
Birth rate: 40.75 births/1,000 population (1997 est.)
Death rate: 9.82 deaths/1,000 population (1997 est.)
Net migration rate: 0 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 0.98 male(s)/female (1997 est.)
Infant mortality rate: 87.4 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 59.88 years
male : 57.52 years
female: 62.32 years (1997 est.)
Total fertility rate: 5.54 children born/woman (1997 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha, Sakalava
Religions: Sunni Muslim 86%, Roman Catholic 14%
Languages: Arabic (official), French (official), Comoran (a blend of
Swahili and Arabic)
Literacy:
definition: age 15 and over can read and write
total population: 57.3%
male: 64.2%
female: 50.4% (1995 est.)
@Comoros:Government
Country name:
conventional long form : Federal Islamic Republic of the Comoros
conventional short form: Comoros
local long form: Republique Federale Islamique des Comores
local short form: Comores
Data code: CN
Government type: independent republic
National capital: Moroni
Administrative divisions: three islands; Grand Comore (Njazidja),
Anjouan (Nzwani), and Moheli (Mwali)
note: there are also four municipalities named Domoni, Fomboni,
Moroni, and Mutsamudu
Independence: 6 July 1975 (from France)
National holiday: Independence Day, 6 July (1975)
Constitution: 7 June 1992
Legal system: French and Muslim law in a new consolidated code
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Mohamed TAKI Abdulkarim (since 16 March
1996)
head of government: Prime Minister Ahmed ABDOU (since 27 December
1996)
cabinet: Council of Ministers appointed by the president
elections: president elected by popular vote to a five-year term;
election last held 16 March 1996 (next to be held NA March 2001);
prime minister appointed by the president
election results: Mohamed TAKI Abdulkarim elected president; share of
vote - 64%
Legislative branch: bicameral legislature consists of the Senate (15
seats; members selected by regional councils for six-year terms) and a
Federal Assembly or Assemblee Federale (43 seats; members elected by
popular vote to serve four-year terms)
elections : last held 1 and 8 December 1996 (next to be held NA
December 2000)
election results: percent of vote by party - NA; seats by party - RND
39, RND candidate running as independent 1, FNJ 3
Judicial branch: Supreme Court or Cour Supreme), two members are
appointed by the president, two members are elected by the Federal
Assembly, one by the Council of each island, and former presidents of
the republic
Political parties and leaders: Rassemblement National pour le
Development or RND [Mohamed TAKI Abdulkarim], party of the government;
Front National pour la Justice or FNJ, Islamic party in opposition
note: under a new constitution ratified in October 1996, a two party
system was established; President Mohamed TAKI Abdulkarim called for
all parties to dissolve and join him in creating the RND; the
Constitution stipulates that only parties that win six seats in the
Federal Assembly (two from each island) are permitted to be in
opposition, but if no party accomplishes that the second most
successful party will be in opposition; in the elections of December
1996 the FNJ appeared to qualify as opposition
International organization participation: ACCT, ACP, AfDB, AL, CCC,
ECA, FAO, FZ, G-77, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF,
Intelsat (nonsignatory user), IOC, ITU, NAM, OAU, OIC, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador (vacant) Charge d''Affaires ad interim
Mahmoud M. ABOUD (ambassador to the US and Canada)
chancery: (temporary) care of the Permanent Mission of the Federal and
Islamic Republic of the Comoros to the United Nations, 336 East 45th
Street, 2nd Floor, New York, NY 10017
telephone: [1] (212) 972-8010
FAX : [1] (212) 983-4712
Diplomatic representation from the US: the US does not have an embassy
in Comoros; the ambassador to Mauritius is accredited to Comoros
Flag description: green with a white crescent in the center of the
field, its points facing downward; there are four white five-pointed
stars placed in a line between the points of the crescent; the
crescent, stars, and color green are traditional symbols of Islam; the
four stars represent the four main islands of the archipelago - Mwali,
Njazidja, Nzwani, and Mayotte (a territorial collectivity of France,
but claimed by Comoros); the design, the most recent of several, is
described in the constitution approved by referendum on 7 June 1992','4c6ed01d718375e049ef85f745fc16f84269ef70a2c5edbdc78d78fee31a22d2','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d0b41396dd0a665c547cd93f1bb4ea071582420714f141fa92c54fea845e2ea',1997,'ER','Eritrea','introduction',221,'Historical perspective: on 29 May 1991, ISAIAS Afworke, secretary
general of the Peoples'' Front for Democracy and Justice (PFDJ), which
then served as the country''s legislative body, announced the formation
of the Provisional Government in Eritrea (PGE) in preparation for the
23-25 April 1993 referendum on independence for the Autonomous Region
of Eritrea; the referendum resulted in a landslide vote for
independence which was proclaimed on 27 April 1993
@Eritrea:Geography
Location: Eastern Africa, bordering the Red Sea, between Djibouti and','adc64baf7f66e590a831f90d373224bec4112f3fe4b55ba445bdc2fee3501e82','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('929810e6d76760cd08de45ce61990c6e79ec4ced81cf0d53fdff9e4819128c42',1997,'SD','Sudan','introduction',222,'Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total : 121,320 sq km
land: 121,320 sq km
water: 0 sq km
Area - comparative: slightly larger than Pennsylvania
Land boundaries:
total: 1,630 km
border countries: Djibouti 113 km, Ethiopia 912 km, Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea 1,151 km, islands in
Red Sea 1,083 km
Maritime claims: NA
Climate: hot, dry desert strip along Red Sea coast; cooler and wetter
in the central highlands (up to 61 cm of rainfall annually); semiarid
in western hills and lowlands; rainfall heaviest during June-September
except on coastal desert
Terrain: dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
Elevation extremes:
lowest point : Kobar Sink -75 m
highest point: Soira 3,013 m
Natural resources: gold, potash, zinc, copper, salt, probably oil
(petroleum geologists are prospecting for it), fish
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 48%
forests and woodland: 20%
other : 19% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts
Environment - current issues: deforestation; desertification; soil
erosion; overgrazing; loss of infrastructure from civil warfare
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species
signed, but not ratified: none of the selected agreements
Geography - note: strategic geopolitical position along world''s
busiest shipping lanes; Eritrea retained the entire coastline of
Ethiopia along the Red Sea upon de jure independence from Ethiopia on
27 April 1993
@Eritrea:People
Population: 3,589,687 (July 1997 est.)
Age structure:
0-14 years: 43% (male 781,169; female 770,497)
15-64 years: 54% (male 963,542; female 966,083)
65 years and over: 3% (male 55,811; female 52,585) (July 1997 est.)
Population growth rate: 6.35% (1997 est.)
Birth rate: 43.96 births/1,000 population (1997 est.)
Death rate: 15.26 deaths/1,000 population (1997 est.)
Net migration rate: 34.82 migrant(s)/1,000 population (1997 est.)
note: it is estimated that between 200,000 and 350,000 Eritrean
refugees were still living in Sudan in mid-1997
Sex ratio:
at birth : 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1.06 male(s)/female
total population : 1.01 male(s)/female (1997 est.)
Infant mortality rate: 117.2 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 50.61 years
male: 48.85 years
female : 52.42 years (1997 est.)
Total fertility rate: 6.47 children born/woman (1997 est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and Kunama 40%, Afar 4%,
Saho (Red Sea coast dwellers) 3%
Religions: Muslim, Coptic Christian, Roman Catholic, Protestant
Languages: Afar, Amharic, Arabic, Italian, Tigre and Kunama, Tigrinya,
minor tribal languages
@Eritrea:Government
Country name:
conventional long form: State of Eritrea
conventional short form: Eritrea
local long form : Hagere Ertra
local short form: Ertra
former: Eritrea Autonomous Region in Ethiopia
Data code: ER
Government type: transitional government
note : following a successful referendum on independence for the
Autonomous Region of Eritrea on 23-25 April 1993, a National Assembly,
composed entirely of the Peoples'' Front for Democracy and Justice or
PFDJ, was established as a transitional legislature; a Constitutional
Commission was also established to draft a constitution; ISAIAS
Afworki was elected president by the transitional legislature pending
the promulgation of a constitution and popular elections
National capital: Asmara (formerly Asmera)
Administrative divisions: 8 provinces (singular - awraja); Akele
Guzay, Barka, Denkel, Hamasen, Sahil, Semhar, Senhit, Seraye
note: in May 1995 the National Assembly adopted a resolution stating
that the administrative structure of Eritrea, which had been
established by former colonial powers, would consist of only six
provinces when the new constitution, then being drafted, would go into
effect sometime in 1998; the new provinces, which have not been
recommended by the US Board on Geographic Names for recognition by the
US government, pending acceptable definition of the boundaries, are:
Anseba, Debub, Debubawi, Gash-Barka, Maakel, and Semanawi Keyih Bahri
Independence: 27 May 1993 (from Ethiopia; formerly the Eritrea
Autonomous Region)
National holiday: National Day (independence from Ethiopia), 24 May
(1993)
Constitution: transitional "constitution" decreed 19 May 1993; the
promulgation of a draft constitution is expected in 1998
Legal system: NA
Suffrage: NA; note - the transitional constitution of 19 May 1993 did
not provide rules for suffrage, but it seems likely that the final
version of the constitution, to be promulgated some time in 1998, will
follow the example set in the referendum of 1993 and extend suffrage
to all persons 18 years of age or older
Executive branch:
chief of state: President ISAIAS Afworki (since 8 June 1993); note -
the president is both the chief of state and head of government
head of government: President ISAIAS Afworki (since 8 June 1993); note
- the president is both the chief of state and head of government
cabinet: State Council is the collective executive authority
note: the president is head of the State Council and National Assembly
elections: president elected by the National Assembly; election last
held 8 June 1993 (next to be held NA 1997)
election results: ISAIAS Afworki elected president; percent of
National Assembly vote - ISAIAS Afworki 95%
Legislative branch: unicameral National Assembly (150 seats; term
limits not established pending new constitution)
elections: 75 members of the PFDJ Central Committee (the old Central
Committee of the EPLF) and 75 directly elected members serve as the
country''s legislative body until country-wide elections are held in
1997
Judicial branch: Judiciary
Political parties and leaders: People''s Front for Democracy and
Justice or PFDJ, the only party recognized by the government [ISAIAS
Afworki, PETROS Solomon]
Political pressure groups and leaders: Eritrean Islamic Jihad or EIJ;
Eritrean Liberation Front or ELF [ABDULLAH Muhammed]; Eritrean
Liberation Front - United Organization or ELF-UO [Mohammed Said
NAWUD]; Eritrean Liberation Front - Revolutionary Council or ELF-RC
[Ahmed NASSER]
International organization participation: ACP, AfDB, CCC, ECA, FAO,
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, IGADD, ILO, IMF, IMO, Intelsat
(nonsignatory user), ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU,
WFTU, WHO, WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador AMDEMICHAEL Berhane Khasai
chancery: 1708 New Hampshire Avenue NW, Washington, DC 20009
telephone : [1] (202) 319-1991
FAX: [1] (202) 319-1304
Diplomatic representation from the US:
chief of mission : Ambassador John HICKS
embassy: Franklin D. Roosevelt St., Asmara
mailing address: P.O. Box 211, Asmara
telephone: [291] (1) 120004
FAX : [291] (1) 127584
Flag description: red isosceles triangle (based on the hoist side)
dividing the flag into two right triangles; the upper triangle is
green, the lower one is blue; a gold wreath encircling a gold olive
branch is centered on the hoist side of the red triangle','809ccf313b171f550a2879ecc48ee5b144484f559b6c903fad7b763c3bb0b941','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6621e7d14db0ed76cb13f10edb233cc8dbe8b77d883c7d678dfd0c2bf82e109',1997,'GE','Georgia','introduction',255,'Current issues: Beset by ethnic and civil strife since independence in
1991, Georgia began to stabilize in 1994. Separatist conflicts in
Abkhazia and South Ossetia have been dormant since spring 1994,
although political settlements remain elusive. Russian peacekeepers
are deployed in both regions and a UN Observer Mission is operating in
Abkhazia. As a result of these conflicts, Georgia still has about
250,000 internally displaced people. In 1995, Georgia adopted a new
constitution and conducted generally free and fair nationwide
presidential and parliamentary elections. In 1996, the government
focused its attention to implementing an ambitious economic reform
program and professionalizing its parliament. Violence and organized
crime were sharply curtailed in 1995 and 1996, but corruption remains
rife.
@Georgia:Geography
Location: Southwestern Asia, bordering the Black Sea, between Turkey
and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent States
Area:
total: 69,700 sq km
land : 69,700 sq km
water: 0 sq km
Area - comparative: slightly smaller than South Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km, Azerbaijan 322 km, Russia 723 km,
Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on Black Sea coast
Terrain: largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhida Lowland
opens to the Black Sea in the west; Mtkvari River Basin in the east;
good soils in river valley flood plains, foothills of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek) 5,048 m
Natural resources: forests, hydropower, manganese deposits, iron ore,
copper, minor coal and oil deposits; coastal climate and soils allow
for important tea and citrus growth
Land use:
arable land : 9%
permanent crops: 4%
permanent pastures: 25%
forests and woodland: 34%
other: 28% (1993 est.)
Irrigated land: 4,000 sq km (1993 est.)
Natural hazards: NA
Environment - current issues: air pollution, particularly in Rust''avi;
heavy pollution of Mtkvari River and the Black Sea; inadequate
supplies of potable water; soil pollution from toxic chemicals
Environment - international agreements:
party to: Biodiversity, Climate Change, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Desertification
@Georgia:People
Population: 5,160,042 (July 1997 est.)
Age structure:
0-14 years: 22% (male 581,370; female 558,390)
15-64 years : 66% (male 1,640,361; female 1,766,319)
65 years and over: 12% (male 231,698; female 381,904) (July 1997 est.)
Population growth rate: -1.09% (1997 est.)
Birth rate: 11.82 births/1,000 population (1997 est.)
Death rate: 13.88 deaths/1,000 population (1997 est.)
Net migration rate: -8.83 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years : 1.04 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.91 male(s)/female (1997 est.)
Infant mortality rate: 50.1 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 64.96 years
male: 61.59 years
female : 68.49 years (1997 est.)
Total fertility rate: 1.56 children born/woman (1997 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%, Russian 6.3%, Azeri
5.7%, Ossetian 3%, Abkhaz 1.8%, other 5%
Religions: Christian Orthodox 75% (Georgian Orthodox 65%, Russian
Orthodox 10%), Muslim 11%, Armenian Apostolic 8%, unknown 6%
Languages: Armenian 7%, Azeri 6%, Georgian 71% (official), Russian 9%,
other 7%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 100%
female: 98% (1989 est.)
@Georgia:Government
Country name:
conventional long form: none
conventional short form: Georgia
local long form: none
local short form : Sak''art''velo
former: Georgian Soviet Socialist Republic
Data code: GG
Government type: republic
National capital: T''bilisi
Administrative divisions: 53 rayons (raionebi, singular - raioni), 9
cities* (k''alak''ebi, singular - k''alak''i), and 2 autonomous
republics** (avtomnoy respubliki, singular - avtom respublika);
Abashis, Abkhazia (Ap''khazet''is Avtonomiuri Respublika)** (Sokhumi),
Adigenis, Ajaria (Acharis Avtonomiuri Respublika)** (Bat''umi),
Akhalgoris, Akhalk''alak''is, Akhalts''ikhis, Akhmetis, Ambrolauris,
Aspindzis, Baghdat''is, Bolnisis, Borjomis, Chiat''ura*, Ch''khorotsqus,
Ch''okhatauris, Dedop''listsqaros, Dmanisis, Dushet''is, Gardabanis,
Gori*, Goris, Gurjaanis, Javis, K''arelis, Kaspis, Kharagaulis,
Khashuris, Khobis, Khonis, K''ut''aisi*, Lagodekhis, Lanch''khut''is,
Lentekhis, Marneulis, Martvilis, Mestiis, Mts''khet''is, Ninotsmindis,
Onis, Ozurget''is, P''ot''i*, Qazbegis, Qvarlis, Rust''avi*, Sach''kheris,
Sagarejos, Samtrediis, Senakis, Sighnaghis, T''bilisi*, T''elavis,
T''erjolis, T''et''ritsqaros, T''ianet''is, Tqibuli*, Ts''ageris,
Tsalenjikhis, Tsalkis, Tsqaltubo*, Vanis, Zestap''onis, Zugdidi*,
Zugdidis
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center name
following in parentheses)
Independence: 9 April 1991 (from Soviet Union)
National holiday: Independence Day, 26 May (1991)
Constitution: adopted 17 October 1995
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state : President Eduard Amvrosiyevich SHEVARDNADZE
(previously elected chairman of the Government Council 10 March 1992,
Council has since been disbanded; previously elected chairman of
Parliament 11 October 1992; elected president 5 November 1995); note -
the president is both the chief of state and head of government
head of government: President Eduard Amvrosiyevich SHEVARDNADZE
(previously elected chairman of the Government Council 10 March 1992,
Council has since been disbanded; previously elected chairman of
Parliament 11 October 1992; elected president 5 November 1995); note -
the president is both the chief of state and head of government
cabinet: Cabinet of Ministers
elections: president elected by popular vote for a five-year term;
election last held 5 November 1995 (next to be held NA April 2001)
election results: Eduard SHEVARDNADZE elected president; percent of
vote - Eduard SHEVARDNADZE 74%
Legislative branch: unicameral Supreme Council or Umaghiesi Sabcho
(235 seats; members are elected to serve five-year terms)
elections: last held 5 November 1995 (next to be held NA November
2000)
election results : percent of vote by party - CUG 24%, NDP 8%, All
Georgia Revival Union 7%, all other parties received less than 5%
each; seats by party - NA
Judicial branch: Supreme Court
Political parties and leaders: Citizens Union of Georgia or CUG
[Eduard SHEVARDNADZE, Zurab ZHVANIA, general secretary]; National
Democratic Party or NDP [Irina SARISHVILI-CHANTARIA]; United
Republican Party, umbrella organization for parties including the GPF
and the Charter 1991 Party [Notar NATADZE, chairman]; Georgian Popular
Front or GPF [Nodar NATADZE, chairman]; Charter 1991 Party [Tedo
PAATASHVILI]; Georgian Social Democratic Party or GSDP [Guram
MUCHAIDZE, secretary general]; All Georgia Union for Revival [Alsan
ABASHIDZE]; Christian Democratic Union or CDU [Irakli SHENGELAYA];
Democratic Georgia Union or DGU [Avtandil MARGIANI]; National
Independence Party or NIP [Irakliy TSERETELI, chairman]; Georgian
Monarchists'' Party or GMP [Temur ZHORZHOLIANI]; Greens Party; Agrarian
Party of Georgia or APG [Roin LIPARTELIANI]; United Communist Party of
Georgia or UCP [Panteleimon GIORGADZE, chairman]
Political pressure groups and leaders: supporters of ousted President
Zviad GAMSAKHURDIA (deceased 1 January 1994) remain a source of
opposition; separatist elements in the breakaway region of Abkhazia
International organization participation: BSEC, CCC, CE (guest), CIS,
EBRD, ECE, FAO, IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO,
Inmarsat, Interpol, IOC, IOM (observer), ITU, NACC, OSCE, PFP, UN,
UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Tedo JAPARIDZE
chancery: (temporary) Suite 424, 1511 K Street NW, Washington, DC
20005
telephone: [1] (202) 393-5959
FAX : [1] (202) 393-4537
Diplomatic representation from the US:
chief of mission: Ambassador William H. COURTNEY
embassy: #25 Antoneli Street, T''bilisi 380026
mailing address: use embassy street address
telephone : 995-32-989-967 or 995-32-933-803 (operator assisted)
FAX: tie-line FAX 997-0200; 933-759 or 938-951
Flag description: maroon field with small rectangle in upper hoist
side corner; rectangle divided horizontally with black on top, white
below','4a7a52646c8da29badb185250aef9b53cf8c5a1ec68782ff4e9177400a335bc9','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eedfcb051d86529fb14a46177813f50c15541b6fe89f37f3a7998c2f442c00c',1997,'IL','Israel','introduction',320,'Current issues: The territories occupied by Israel since the 1967 war
are not included in the data below, unless otherwise noted. In keeping
with the framework established at the Madrid Conference in October
1991, bilateral negotiations are being conducted between Israel and
Palestinian representatives, and Israel and Syria, to achieve a
permanent settlement between them. On 25 April 1982, Israel withdrew
from the Sinai pursuant to the 1979 Israel-Egypt Peace treaty.
Outstanding territorial and other disputes with Jordan were resolved
in the 26 October 1994 Israel-Jordan Treaty of Peace.
@Israel:Geography
Location: Middle East, bordering the Mediterranean Sea, between Egypt
and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water : 440 sq km
Area - comparative: slightly smaller than New Jersey
Land boundaries:
total: 1,006 km
border countries: Egypt 255 km, Gaza Strip 51 km, Jordan 238 km,
Lebanon 79 km, Syria 76 km, West Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf : to depth of exploitation
territorial sea: 12 nm
Climate: temperate; hot and dry in southern and eastern desert areas
Terrain: Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
Elevation extremes:
lowest point : Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: copper, phosphates, bromide, potash, clay, sand,
sulfur, asphalt, manganese, small amounts of natural gas and crude oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland : 6%
other: 66% (1993 est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: sandstorms may occur during spring and summer
Environment - current issues: limited arable land and natural fresh
water resources pose serious constraints; desertification; air
pollution from industrial and vehicle emissions; groundwater pollution
from industrial and domestic waste, chemical fertilizers, and
pesticides
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution
signed, but not ratified : Marine Life Conservation
Geography - note: there are 203 Israeli settlements and civilian land
use sites in the West Bank, 42 in the Israeli-occupied Golan Heights,
24 in the Gaza Strip, and 26 in East Jerusalem (August 1996 est.)
@Israel:People
Population: 5,534,672 (July 1997 est.)
note: includes 136,000 Israeli settlers in the West Bank, 15,000 in
the Israeli-occupied Golan Heights, 5,000 in the Gaza Strip, and
156,000 in East Jerusalem (August 1996 est.)
Age structure:
0-14 years: 28% (male 803,792; female 766,224)
15-64 years : 62% (male 1,711,668; female 1,708,700)
65 years and over: 10% (male 234,902; female 309,386) (July 1997 est.)
Population growth rate: 2.01% (1997 est.)
Birth rate: 20.16 births/1,000 population (1997 est.)
Death rate: 6.22 deaths/1,000 population (1997 est.)
Net migration rate: 6.12 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth : 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.99 male(s)/female (1997 est.)
Infant mortality rate: 8.3 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 78.21 years
male : 76.34 years
female: 80.18 years (1997 est.)
Total fertility rate: 2.74 children born/woman (1997 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 82% (Israel-born 50%,
Europe/Americas/Oceania-born 20%, Africa-born 7%, Asia-born 5%),
non-Jewish 18% (mostly Arab) (1993 est.)
Religions: Judaism 82%, Islam 14% (mostly Sunni Muslim), Christian 2%,
Druze and other 2%
Languages: Hebrew (official), Arabic used officially for Arab
minority, English most commonly used foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female : 93% (1992 est.)
@Israel:Government
Country name:
conventional long form: State of Israel
conventional short form: Israel
local long form: Medinat Yisra''el
local short form: Yisra''el
Data code: IS
Government type: republic
National capital: Jerusalem
note: Israel proclaimed Jerusalem as its capital in 1950, but the US,
like nearly all other countries, maintains its Embassy in Tel Aviv
Administrative divisions: 6 districts (mehozot, singular - mehoz);
Central, Haifa, Jerusalem, Northern, Southern, Tel Aviv
Independence: 14 May 1948 (from League of Nations mandate under
British administration)
National holiday: Independence Day, 14 May 1948 (Israel declared
independence on 14 May 1948, but the Jewish calendar is lunar and the
holiday may occur in April or May)
Constitution: no formal constitution; some of the functions of a
constitution are filled by the Declaration of Establishment (1948),
the basic laws of the parliament (Knesset), and the Israeli
citizenship law
Legal system: mixture of English common law, British Mandate
regulations, and, in personal matters, Jewish, Christian, and Muslim
legal systems; in December 1985, Israel informed the UN Secretariat
that it would no longer accept compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Ezer WEIZMAN (since 13 May 1993)
head of government : Prime Minister Binyamin NETANYAHU (since 18 June
1996)
cabinet: Cabinet selected from and approved by the Knesset
elections: president elected by the Knesset for a five-year term;
election last held 24 March 1993 (next to be held NA March 1998);
prime minister elected by popular vote for a four-year term; election
last held 29 May 1996 (next to be held NA 2000); note - in March 1992,
the Knesset approved legislation, effective in 1996, which allowed for
the direct election of the prime minister; under the new law, each
voter casts two ballots - one for the direct election of the prime
minister and one for the party in the Knesset; the candidate that
receives the largest percentage of the popular vote then works to form
a coalition with other parties to achieve a parliamentary majority of
61 seats; finally, the candidate must submit his or her cabinet to the
Knesset for approval and this must be done within 45 days of the
election; in contrast to the old system, under the new law, the prime
minister''s party need not be the single-largest party in the Knesset
election results: Ezer WEIZMAN elected president; percent of Knesset
vote - NA; Binyamin NETANYAHU elected prime minister; percent of vote
- Binyamin NETANYAHU 50.4%, Shimon PERES 49.5%
Legislative branch: unicameral Knesset or parliament (120 seats;
members elected by popular vote to serve four-year terms)
elections: last held 29 May 1996 (next to be held NA 2000)
election results: percent of vote by party - NA; seats by party -
Labor Party 34, Likud Party 32, SHAS 10, MERETZ 9, National Religious
Party 9, Yisra''el Ba''Aliya 7, Hadash-Balad 5, Third Way 4, United Arab
List 4, United Jewish Torah 4, Moledet 2; note - Likud, Tzomet, and
Gesher candidates ran on a joint list
Judicial branch: Supreme Court
Political parties and leaders:
government coalition: Likud Party, Prime Minister Binyamin NETANYAHU;
Tzomet, Rafael EITAN; Gesher, David LEVI; SHAS, Arieh DERI; National
Religious Party, Zevulun HAMMER; Yisra''el Ba''Aliya, Natan SHARANSKY;
United Jewish Torah, Meir PORUSH; Third Way, Avigdor KAHALANI;
Moledet, Rehavam ZEEVI
opposition: Labor Party, Shimon PERES; MERETZ, Yossi SARID; United
Arab List, Abd al-Malik DAHAMSHAH; Hadash-Balad, Hashim MAHAMID
Political pressure groups and leaders: Gush Emunim, Israeli
nationalists advocating Jewish settlement on the West Bank and Gaza
Strip; Peace Now supports territorial concessions in the West Bank and
is critical of government''s Lebanon policy
International organization participation: AG (observer), BSEC
(observer), CCC, CE (observer), CERN (observer), EBRD, ECE, FAO, IADB,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, IOM, ISO, ITU, OAS (observer), OSCE
(partner), PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WHO, WIPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission : Ambassador Eliahu BEN-ELISSAR
chancery: 3514 International Drive NW, Washington, DC 20008
telephone: [1] (202) 364-5500
FAX: [1] (202) 364-5610
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los Angeles,
Miami, New York, Philadelphia, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Martin S. INDYK
embassy: 71 Hayarkon Street, Tel Aviv
mailing address: PSC 98, Box 100, APO AE 09830
telephone : [972] (3) 519-7575
FAX: [972] (3) 517-3227
consulate(s) general: Jerusalem; note - an independent US mission,
established in 1928, whose members are not accredited to a foreign','b4d0a757a3bfea7be2df8f26ad1bd11428c709e7ca91107b1b03f3ca437f35a8','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d723f7eb8c2c13a596316858a242d896ce9d324dfdfce959ce1087621b7eecd',1997,'LB','Lebanon','introduction',347,'Current issues: Lebanon has made progress toward rebuilding its
political institutions and regaining its national sovereignty since
the end of the devastating 16-year civil war, which began in 1975.
Under the Ta''if Accord - the blueprint for national reconciliation -
the Lebanese have established a more equitable political system,
particularly by giving Muslims a greater say in the political process.
Since the end of the civil war, the Lebanese have formed five cabinets
and conducted two legislative elections. Most of the militias have
been weakened or disbanded. The Lebanese Armed Forces (LAF) has seized
vast quantities of weapons used by the militias during the war and
extended central government authority over about one-half of the
country. Hizballah, the radical Shi''a party, retains most of its
weapons. Foreign forces still occupy areas of Lebanon. Israel
maintains troops in southern Lebanon and continues to support a proxy
militia, the Army of South Lebanon (ASL), along a narrow stretch of
territory contiguous to its border. The ASL''s enclave encompasses this
self-declared security zone and about 20 kilometers north to the
strategic town of Jazzin. Syria maintains about 30,000 troops in
Lebanon. These troops are based mainly in Beirut, North Lebanon, and
the Bekaa Valley. Syria''s deployment was legitimized by the Arab
League during Lebanon''s civil war and in the Ta''if accord. Citing the
continued weakness of the LAF, Beirut''s requests, and failure of the
Lebanese Government to implement all of the constitutional reforms in
the Ta''if accord, Damascus has so far refused to withdraw its troops
from Lebanon.
@Lebanon:Geography
Location: Middle East, bordering the Mediterranean Sea, between Israel
and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water : 170 sq km
Area - comparative: about 0.7 times the size of Connecticut
Land boundaries:
total : 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea : 12 nm
Climate: Mediterranean; mild to cool, wet winters with hot, dry
summers; Lebanon mountains experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point : Mediterranean Sea 0 m
highest point: Jabal al Makmal 3,087 m
Natural resources: limestone, iron ore, salt, water-surplus state in a
water-deficit region
Land use:
arable land : 21%
permanent crops: 9%
permanent pastures: 1%
forests and woodland: 8%
other: 61% (1993 est.)
Irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment - current issues: deforestation; soil erosion;
desertification; air pollution in Beirut from vehicular traffic and
the burning of industrial wastes; pollution of coastal waters from raw
sewage and oil spills
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Environmental Modification, Marine Dumping,
Marine Life Conservation
Geography - note: Nahr al Litani only major river in Near East not
crossing an international boundary; rugged terrain historically helped
isolate, protect, and develop numerous factional groups based on
religion, clan, and ethnicity
@Lebanon:People
Population: 3,449,578 (July 1997 est.)
Age structure:
0-14 years: 30% (male 531,171; female 511,522)
15-64 years: 64% (male 1,036,728; female 1,150,847)
65 years and over: 6% (male 100,682; female 118,628) (July 1997 est.)
Population growth rate: 1.62% (1997 est.)
Birth rate: 22.74 births/1,000 population (1997 est.)
Death rate: 6.56 deaths/1,000 population (1997 est.)
Net migration rate: 0 migrant(s)/1,000 population (1997 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over : 0.85 male(s)/female
total population: 0.94 male(s)/female (1997 est.)
Infant mortality rate: 32.8 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population : 70.35 years
male: 67.82 years
female : 73 years (1997 est.)
Total fertility rate: 2.32 children born/woman (1997 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Islam 70% (5 legally recognized Islamic groups - Alawite or
Nusayri, Druze, Isma''ilite, Shi''a, Sunni), Christian 30% (11 legally
recognized Christian groups - 4 Orthodox Christian, 6 Catholic, 1
Protestant), Judaism NEGL%
Languages: Arabic (official), French (official), Armenian, English
Literacy:
definition: age 15 and over can read and write
total population: 92.4%
male: 94.7%
female: 90.3% (1995 est.)
@Lebanon:Government
Country name:
conventional long form: Lebanese Republic
conventional short form: Lebanon
local long form : Al Jumhuriyah al Lubnaniyah
local short form: Lubnan
Data code: LE
Government type: republic
National capital: Beirut
Administrative divisions: 5 governorates (muhafazat, singular -
muhafazah); Al Biqa'', Al Janub, Ash Shamal, Bayrut, Jabal Lubnan
Independence: 22 November 1943 (from League of Nations mandate under
French administration)
National holiday: Independence Day, 22 November (1943)
Constitution: 23 May 1926, amended a number of times
Legal system: mixture of Ottoman law, canon law, Napoleonic code, and
civil law; no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Suffrage: 21 years of age; compulsory for all males; authorized for
women at age 21 with elementary education
Executive branch:
chief of state: President Ilyas HARAWI (since 24 November 1989)
head of government : Prime Minister Rafiq al-HARIRI (since 22 October
1992)
cabinet: Cabinet chosen by the prime minister in consultation with the
members of the National Assembly; the current Cabinet was formed in
1996
elections: president elected by the National Assembly for a six-year
term; election last held 24 November 1989 (next to be held NA 1998);
note - in 1995, the National Assembly amended the Constituition to
extend the president''s term by three years; prime minister and deputy
prime minister appointed by the president in consultation with the
National Assembly; by custom, the president is a Maronite Christian,
the prime minister is a Sunni Muslim, and the speaker of the
legislature is a Shi''a Muslim
election results: Ilyas HARAWI elected president; percent of National
Assembly vote - NA
Legislative branch: unicameral National Assembly or Majlis Alnuwab
(Arabic) or Assemblee Nationale (French) (128 seats; members elected
by popular vote on the basis of sectarian proportional representation
to serve four-year terms)
elections: last held in the summer of 1996 (next to be held NA 2000)
election results: percent of vote by party - NA; seats by party - NA
(one-half Christian and one-half Muslim)
Judicial branch: four Courts of Cassation (three courts for civil and
commercial cases and one court for criminal cases)
Political parties and leaders: political party activity is organized
along largely sectarian lines; numerous political groupings exist,
consisting of individual political figures and followers motivated by
religious, clan, and economic considerations
International organization participation: ABEDA, ACCT, AFESD, AL, AMF,
CCC, ESCWA, FAO, G-24, G-77, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol,
IOC, ISO (correspondent), ITU, NAM, OIC, PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNRWA, UPU, WFTU, WHO, WIPO, WMO, WToO
Diplomatic representation in the US:
chief of mission : Ambassador (vacant); Charge d''Affaires Victor
EL-ZMETER
chancery: 2560 28th Street NW, Washington, DC 20008
telephone: [1] (202) 939-6300
FAX: [1] (202) 939-6324
consulate(s) general: Detroit, New York, and Los Angeles
Diplomatic representation from the US:
chief of mission : Ambassador Richard Henry JONES
embassy: Antelias, Beirut
mailing address: P. O. Box 70-840, Beirut; PSC 815, Box 2, FPO AE
09836-0002
telephone: [961] (1) 402200, 403300, 406650, 406651, 426183, 417774,
889926
FAX : [961] (1) 407112
Flag description: three horizontal bands of red (top), white (double
width), and red with a green and brown cedar tree centered in the
white band','7624295782417a786e2d8e57858d46ca49d55950ae169f70c310a9566d4985b1','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('406eeac6093f7722ee1daccd29fe60c0f2e336e08b73d0397011a3296b25ac12',1997,'LR','Liberia','introduction',354,'Current issues: Years of civil strife have destroyed much of Liberia''s
economic infrastructure, made civil administration nearly impossible,
and brought economic activity virtually to a halt. The deterioration
of economic conditions has been greatly exacerbated by the flight of
most business people with their expertise and capital. Civil order
ended in 1990 when President Samuel Kenyon DOE was killed by rebel
forces. In April 1996, when forces loyal to faction leaders Charles
Ghankay TAYLOR and Alhaji KROMAH attacked rival ethnic Krahn factions,
the fighting further damaged Monrovia''s dilapidated infrastructure.
Fighting waned in late May 1996, allowing West African peacekeepers to
regain control of Monrovia. The Abuja II peace accord was signed in
August 1996 replacing the Chairman of the ruling Council of State,
Wilton SANKAWULO, with Ruth PERRY. National elections were scheduled
for 30 May 1997, but long-term prospects for peace will remain poor
unless the warring factions can overcome their greed, mutual
suspicions and ethnic hatreds.
@Liberia:Geography
Location: Western Africa, bordering the North Atlantic Ocean, between
Cote d''Ivoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 111,370 sq km
land : 96,320 sq km
water: 15,050 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716 km, Sierra Leone
306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot days and cool to
cold nights; wet, cloudy summers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
Elevation extremes:
lowest point : Atlantic Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber, diamonds, gold
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 18%
other: 19% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: dust-laden harmattan winds blow from the Sahara
(December to March)
Environment - current issues: tropical rain forest subject to
deforestation; soil erosion; loss of biodiversity; pollution of rivers
from the dumping of iron ore tailings and of coastal waters from oil
residue and raw sewage
Environment - international agreements:
party to: Endangered Species, Nuclear Test Ban, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Biodiversity, Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping, Marine Life Conservation
@Liberia:People
Population: 2,602,068 (July 1997 est.)
Age structure:
0-14 years: 45% (male 584,918; female 579,728)
15-64 years: 52% (male 689,376; female 657,029)
65 years and over : 3% (male 43,868; female 47,149) (July 1997 est.)
Population growth rate: 6.92% (1997 est.)
Birth rate: 42.3 births/1,000 population (1997 est.)
Death rate: 11.53 deaths/1,000 population (1997 est.)
Net migration rate: 38.39 migrant(s)/1,000 population (1997 est.)
note: until domestic peace is restored, many Liberian refugees will
not return from exile
Sex ratio:
at birth : 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.93 male(s)/female
total population : 1.03 male(s)/female (1997 est.)
Infant mortality rate: 105.6 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 59.02 years
male : 56.43 years
female: 61.69 years (1997 est.)
Total fertility rate: 6.16 children born/woman (1997 est.)
Nationality:
noun : Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95% (including Kpelle, Bassa,
Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai, and
Bella), Americo-Liberians 5% (descendants of former slaves)
Religions: traditional 70%, Muslim 20%, Christian 10%
Languages: English 20% (official), about 20 tribal languages, of which
a few can be written and are used in correspondence
Literacy:
definition : age 15 and over can read and write
total population: 38.3%
male : 53.9%
female: 22.4% (1995 est.)
@Liberia:Government
Country name:
conventional long form: Republic of Liberia
conventional short form: Liberia
Data code: LI
Government type: republic
National capital: Monrovia
Administrative divisions: 13 counties; Bomi, Bong, Grand Bassa, Grand
Cape Mount, Grand Gedeh, Grand Kru, Lofa, Margibi, Maryland,
Montserrado, Nimba, River Cess, Sinoe
Independence: 26 July 1847
National holiday: Independence Day, 26 July (1847)
Constitution: 6 January 1986
Legal system: dual system of statutory law based on Anglo-American
common law for the modern sector and customary law based on unwritten
tribal practices for indigenous sector
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Chairman of the Council of State Ruth PERRY (since NA
August 1996); note - chairman of the Council of State is both the
chief of state and head of government
head of government : Chairman of the Council of State Ruth PERRY
(since NA August 1996); note - chairman of the Council of State is
both the chief of state and head of government
cabinet: Cabinet selected by the leaders of the major factions in the
civil war
elections: last presidential election held 15 October 1985 (next to be
held 19 July 1997); results - Samuel Kanyon DOE (NDPL) 50.9%, Jackson
DOE (LAP) 26.4%, other 22.7%
note : constitutional government ended in September 1990 when
President Samuel Kanyon DOE was killed by rebel forces; civil war
ensued and in August 1996 the Abuja II peace accord was signed by the
major warring factions; a transitional coalition government under Ruth
PERRY was formed in August 1996; presidential elections are scheduled
for 19 July 1997
Legislative branch: unicameral Transitional Legislative Assembly, the
members of which are appointed by the leaders of the major factions in
the civil war
note : the former bicameral legislature no longer exists and is
unlikely to be reconstituted soon
Judicial branch: Supreme Court
Political parties and leaders: present conditions of civil strife and
anarchy have rendered Liberia''s political parties completely
ineffectual; prior to the outbreak of warfare among armed factions the
following political parties were prominent: National Democratic Party
of Liberia or NDPL [Augustus CAINE, chairman]; Liberian Action Party
or LAP [Emmanuel KOROMAH, chairman]; Unity Party or UP [Joseph KOFA,
chairman]; United People''s Party or UPP [Gabriel Baccus MATTHEWS,
chairman]; National Patriotic Party or NPP [Charles Ghankay TAYLOR,
chairman]; Liberian Peoples Party or LPP [Dusty WOLOKOLLIE, chairman]
Political pressure groups and leaders: the following armed factions,
in accordance with the peace accord of August 1995, form the
transitional government of Liberia: Armed Forces of Liberia or AFL
(formerly a part of the national armed forces) [Lt. Gen. Hezekiah
BOWEN, leader]; National Patriotic Front of Liberia or NPFL (initiated
hostilities against Samuel DOE''s government from Cote d'' Ivoire in
December 1989) [Charles Ghankay TAYLOR, leader]; Central Revolutionary
Committee or CRC (dissident members of the NPFL in conflict with
forces loyal to Charles Ghankay TAYLOR) [Thomas J. WOEWIYU, LEADER];
Liberia Peace Council or LPC (has opposed NPLF forces in southeastern
Liberia) [Dr. George F. SAIGBE BOLEY, chairman; Octavius WALKER,
secretary-general]; United Liberation Movement of Liberia for
Democracy or ULIMO (former supporters of Samuel DOE that have split on
ethnic lines into two groups in conflict with each other: ULIMO-K
[Alhaji G. V. KROMAH, leader] and ULIMO-J [Maj. Gen. Roosevelt
JOHNSON, leader]); Lofa Defence Force or LDF (has fought the ULIMO
forces in Lofa county) [Francois MASSAQUOI, leader]; note - the
ULIMO-J forces are of the Krahn ethnic group and the ULIMO-K forces
are of the Mandingo ethnic group
International organization participation: ACP, AfDB, CCC, ECA, ECOWAS,
FAO, G-77, IAEA, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, IMO, Inmarsat, Intelsat (nonsignatory user), Interpol, IOC, IOM,
ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO,
WMO
Diplomatic representation in the US:
chief of mission: Ambassador Konah K. BLACKETT
chancery: 5201 16th Street NW, Washington, DC 20011
telephone : [1] (202) 723-0437
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission : Ambassador (vacant); Chief of Mission William MILAM
embassy: 111 United Nations Drive, Monrovia
mailing address: P. O. Box 100098, Mamba Point, Monrovia
telephone: [231] 226-370
FAX : [231] 226-148
Flag description: 11 equal horizontal stripes of red (top and bottom)
alternating with white; there is a white five-pointed star on a blue
square in the upper hoist-side corner; the design was based on the US
flag','9fe011866f884dc952094cb844b000d20152abcf0e4f345a6127eca48e0adba3','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9706d2ffff18104bafbc4435988d64ab47ab2901bbc4b90433c48af0a5108ba',1997,'CG','Congo','introduction',463,'Environment - current issues: deforestation results from uncontrolled
cutting of trees for fuel; overgrazing; soil exhaustion; soil erosion
Environment - international agreements:
party to: Biodiversity, Endangered Species, Nuclear Test Ban
signed, but not ratified : Climate Change, Desertification, Law of the
Sea
Geography - note: landlocked; predominantly rural population
@Rwanda:People
Population: 7,737,537 (July 1997 est.)
note : genocide and civil war in 1994 killed more than 1 million
Rwandans and forced more than 2 million to flee to neighboring
countries
Age structure:
0-14 years: 45% (male 1,769,247; female 1,757,957)
15-64 years: 52% (male 1,978,076; female 2,018,141)
65 years and over: 3% (male 88,556; female 125,560) (July 1997 est.)
Population growth rate: 8.24% (1997 est.)
Birth rate: 38.73 births/1,000 population (1997 est.)
Death rate: 21.06 deaths/1,000 population (1997 est.)
Net migration rate: 64.78 migrant(s)/1,000 population (1997 est.)
note: following the outbreak of genocidal strife in Rwanda in April
1994 between Tutsi and Hutu factions, more than 2 million refugees
fled to neighboring Burundi, Tanzania, Uganda, and Democratic Republic
of the Congo, formerly Zaire; according to the UN High Commission on
Refugees, in 1996 and early 1997 nearly 1,300,000 Hutus returned to
Rwanda; of these 720,000 returned from Democratic Republic of the
Congo, 480,000 from Tanzania, 88,000 from Burundi, and 10,000 from','3a2cf6e8681543b9587c33d4efafbd13fa36f107590e17d34ea9d3c7043156c0','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d322d29227dd9575d0e9d3f8ee5064cbabb8d5416523cdba8fc9f1865cbf7367',1997,'UG','Uganda','introduction',464,'Sex ratio:
at birth : 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (1997 est.)
Infant mortality rate: 118.8 deaths/1,000 live births (1997 est.)
Life expectancy at birth:
total population: 39.11 years
male : 38.64 years
female: 39.6 years (1997 est.)
Total fertility rate: 5.93 children born/woman (1997 est.)
Nationality:
noun : Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 80%, Tutsi 19%, Twa (Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant 9%, Muslim 1%, indigenous
beliefs and other 25%
Languages: Kinyarwanda (official) universal Bantu vernacular, French
(official), English (official), Kiswahili (Swahili) used in commercial
centers
Literacy:
definition: age 15 and over can read and write
total population : 60.5%
male: 69.8%
female: 51.6% (1995 est.)
@Rwanda:Government
Country name:
conventional long form: Rwandese Republic
conventional short form : Rwanda
local long form: Republika y''u Rwanda
local short form: Rwanda
Data code: RW
Government type: republic; presidential, multiparty system
National capital: Kigali
Administrative divisions: 10 prefectures (prefectures, singular -
prefecture in French; plural - NA, singular - prefegitura in
Kinyarwanda); Butare, Byumba, Cyangugu, Gikongoro, Gisenyi, Gitarama,
Kibungo, Kibuye, Kigali, Ruhengeri
Independence: 1 July 1962 (from Belgium-administered UN trusteeship)
National holiday: Independence Day, 1 July (1962)
Constitution: on 5 May 1995, the Transitional National Assembly
adopted a new constitution which included elements of the constitution
of 18 June 1991 as well as provisions of the 1993 Arusha peace accord
and the November 1994 multi-party protocol of understanding
Legal system: based on German and Belgian civil law systems and
customary law; judicial review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ jurisdiction
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: President Pasteur BIZIMUNGU (since 19 July 1994); Vice
President Maj. Gen. Paul KAGAME (since 19 July 1994)
head of government: Prime Minister Celestin RWIGEMA (since 1 September
1995)
cabinet: Council of Ministers appointed by the president
elections : current president installed by force by the Tutsi Rwandan
Patriotic Front; normally the president is elected by popular vote for
a five-year term; elections last held NA (next to be held NA); prime
minister appointed by the president
Legislative branch: unicameral Transitional National Assembly or
Assemblee Nationale de Transition (70 seats; members were
predetermined by the Arusha peace accord to serve NA-year terms)
elections: last held 26 December 1988 ( next to be held NA); note -
the Transitional National Assembly is a power-sharing body established
on 12 December 1994 following a multi-party protocol of understanding
election results: percent of vote by party - NA; seats by party - RPF
19, MDR 13, PSD 13, PL 13, PDC 6, PSR 2, PDI 2, other 2; note - the
distribution of seats was predetermined
Judicial branch: Constitutional Court, consists of the Court of
Cassation and the Council of State in joint session
Political parties and leaders: significant parties include: Rwandan
Patriotic Front or RPF [Alexis KANYARENGWE, chairman]; Democratic
Republican Movement or MDR; Liberal Party or PL; Democratic and
Socialist Party or PSD; Christian Democratic Party or PDC; Islamic
Democratic Party or PDI; Rwandan Socialist Party or PSR; National
Movement for Democracy and Development or MRND, former ruling party
Political pressure groups and leaders: Rwanda Patriotic Army or RPA,
the RPF military wing [Maj. Gen. Paul KAGAME, commander]; Rally for
the Democracy and Return (RDR)
International organization participation: ACCT, ACP, AfDB, CCC, CEEAC,
CEPGL, ECA, FAO, G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
ILO, IMF, Intelsat, Interpol, IOC, IOM (observer), ITU, NAM, OAU, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Theogene N. RUDASINGWA
chancery: (temporary) Suites C1 and C2, 2141 Wisconsin Avenue, NW,
Washington, DC 20007
telephone : [1] (202) 232-2882
FAX: [1] (202) 232-4544
Diplomatic representation from the US:
chief of mission: Ambassador Robert GRIBBIN III
embassy: Boulevard de la Revolution, Kigali
mailing address: B. P. 28, Kigali
telephone : [250] 756 01 through 03, 721 26, 771 47
FAX: [250] 721 28
Flag description: three equal vertical bands of red (hoist side),
yellow, and green with a large black letter R centered in the yellow
band; uses the popular pan-African colors of Ethiopia; similar to the
flag of Guinea, which has a plain yellow band','fbcf1dd5c462398622a063be37778808586af9f13980acf7b82a48244821a850','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

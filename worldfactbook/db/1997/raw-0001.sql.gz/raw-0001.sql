SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('013e86f7d2e3e9ce6ac8879b272eed6abee7a7e601a5a926f4237fea16c6bdae',1997,'','','raw',1,'The Project Gutenberg EBook of The 1997 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1997 CIA World Factbook
Author: United States. Central Intelligence Agency.
Posting Date: February 21, 2010 [EBook #1662]
Release Date: March, 1999
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1997 CIA WORLD FACTBOOK ***
Produced by Dr. Gregory B. Newby
The 1997 CIA World Factbook
TABLE OF CONTENTS','55f6de0d949a5fd7853166924f78da7d0bc39318381b0307da8ef286e3a7217e','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

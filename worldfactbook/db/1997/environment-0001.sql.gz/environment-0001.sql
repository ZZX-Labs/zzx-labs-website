SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c87338b08f1828360edbb8460825a2778a6a640375f75dabd91e54f77b839e3',1997,'NC','New Caledonia','environment',570,'GDP: purchasing power parity - $108.7 billion (1996 est.)
GDP - real growth rate: 9.4% (1996 est.)
GDP - per capita: purchasing power parity - $1,470 (1996 est.)
GDP - composition by sector:
agriculture: 28%
industry: 28%
services: 44% (1996 est.)
Inflation rate - consumer price index: 4.5% (1996)
Labor force:
total: 32.7 million
by occupation: agriculture 65%, industry and services 35% (1990 est.)
Unemployment rate: 25% (1995 est.)
Budget:
revenues: $4.67 billion
expenditures: $5 billion, including capital expenditures of $1.36
billion (1995 est.)
Industries: food processing, garments, shoes, machine building,
mining, cement, chemical fertilizer, glass, tires, oil
Industrial production growth rate: 14% (1996 est.)
Electricity - capacity: 5.32 million kW (1994)
Electricity - production: 11.78 billion kWh (1994)
Electricity - consumption per capita: 154 kWh (1995 est.)
Agriculture - products: paddy rice, corn, potatoes, rubber, soybeans,
coffee, tea, bananas; poultry, pigs; fish
Exports:
total value : $7.1 billion (f.o.b., 1996 est.)
commodities: crude oil, rice, marine products, coffee, rubber, tea,
garments, shoes
partners: Japan, Singapore, Taiwan, Hong Kong, France, South Korea
Imports:
total value: $11.1 billion (f.o.b., 1996 est.)
commodities: petroleum products, machinery and equipment, steel
products, fertilizer, raw cotton, grain, cement, motorcycles
partners: Singapore, South Korea, Japan, France, Hong Kong, Taiwan
Debt - external: $7.3 billion Western countries; $4.5 billion CEMA
debts primarily to Russia; $9 billion to $18 billion nonconvertible
debt (former CEMA, Iraq, Iran)
Economic aid:
recipient: ODA, $NA
note: $2.4 billion in credits and grants pledged by international
donors for 1997
Currency: 1 new dong (D) = 100 xu
Exchange rates: new dong (D) per US$1 - 11,100 (December 1996), 11,193
(1995 average), 11,000 (October 1994), 10,800 (November 1993), 8,100
(July 1991)
Fiscal year: calendar year
@Vietnam:Communications
Telephones: 800,000 (1995 est.)
Telephone system: while Vietnam''s telecommunication sector lags far
behind other countries in Southeast Asia, Hanoi has made considerable
progress since 1991 in upgrading the system; Vietnam has digitized all
provincial switch boards, while fiber-optic and microwave transmission
systems have been extended from Hanoi, Da Nang, and Ho Chi Minh City
to all provinces; the density of telephone receivers nationwide
doubled from 1993 to 1995, but is still far behind other countries in
the region; Vietnam''s telecommunications strategy aims to increase
telephone density to 30 per 1,000 inhabitants by the year 2000 and
authorities estimate that approximately $2.7 billion will be spent on
telecommunications upgrades through the end of the decade
domestic: NA
international: satellite earth stations - 2 Intersputnik (Indian Ocean
region)
Radio broadcast stations: AM NA, FM 228, shortwave 0
Radios: 7.215 million (1992 est.)
Television broadcast stations: 36 (repeaters 77)
Televisions: 2.9 million (1992 est.)
@Vietnam:Transportation
Railways:
total : 2,835 km (in addition, there are 224 km not restored to
service after war damage)
standard gauge: 151 km 1.435-m gauge
narrow gauge: 2,454 km 1.000-m gauge
other gauge: 230 km NA-m dual gauge (three rails)
Highways:
total : 106,048 km
paved: 27,466 km
unpaved: 78,582 km (1995 est.)
Waterways: 17,702 km navigable; more than 5,149 km navigable at all
times by vessels up to 1.8 m draft
Pipelines: petroleum products 150 km
Ports and harbors: Cam Ranh, Da Nang, Haiphong, Ho Chi Minh City, Hong
Gai, Qui Nhon, Nha Trang
Merchant marine:
total : 121 ships (1,000 GRT or over) totaling 534,937 GRT/863,307 DWT
ships by type: bulk 5, cargo 100, chemical tanker 1, oil tanker 9,
refrigerated cargo 5, roll-on/roll-off cargo 1
note: Vietnam owns an additional 8 ships (1,000 GRT or over) totaling
107,592 DWT operating under the registries of The Bahamas, Honduras,
Malta, Panama, and Vanuatu (1996 est.)
Airports: 48 (1994 est.)
Airports - with paved runways:
total: 36
over 3,047 m: 8
2,438 to 3,047 m : 3
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 7 (1994 est.)
Airports - with unpaved runways:
total: 12
1,524 to 2,437 m: 2
914 to 1,523 m : 5
under 914 m: 5 (1994 est.)','aff244619735ba0d5af7eff80216dc98595e8f0363a9e22a079b3fa16d7be247','internet-archive','theciaworldfactb01662gut','txt','f5ec3b7afd638df754eed0f94be2d8e962814dd9d3dc5ad428ab86262d6c5478','https://archive.org/download/theciaworldfactb01662gut/1662.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

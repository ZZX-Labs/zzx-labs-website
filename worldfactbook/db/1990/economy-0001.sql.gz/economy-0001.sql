SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4ea4ed273e2d7e71ef5c74691b45a49aa4c940505b7dbd30f586525bde81d0e',1990,'AF','Afghanistan','economy',6,'Overview: Fundamentally, Afghanistan 1s
an extremely poor, landlocked country,
highly dependent on farming (wheat espe-
cially) and livestock raising (sheep and
goats) Economic considerations, however,
have played second fiddle to political and
military upheavals, including the nine-
year Soviet military occupation (ended 15
February 1989) and the continuing bloody
civil war Over the past decade, one-third
of the population has fled the country,
with Pakistan sheltering some 3 million
refugees and Iran perhaps 2 million
1
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Afghanistan (continued)
Another 1 million have probably moved
into and around urban areas within Af-
ghanistan Large numbers of bridges,
buildings, and factories have been
destroyed or damaged by military action
or sabotage Government claims to the
contrary, gross domestic product almost
certainly is lower than 10 years ago be-
cause of the loss of labor and capital and
the disruption of trade and transport Of-
ficial claims indicate that agriculture grew
by 0 7% and industry by 3 5% 1n 1988
GDP: $3 billion, per capita $200, real
growth rate 0% (1989 est )
Inflation rate (consumer prices): over 50%
(1989 est )
Unemployment rate: NA%
Budget: revenues NA, expenditures $646 7
million, including capital expenditures of
$370 2 millon (FY87 est )
Exports: $512 million (fo b , FY88), com-
modities—natural gas 55%, fruits and
nuts 24%, handwoven carpets, wool, cot-
ton, hides, and pelts, partners—mostly
USSR and Eastern Europe
Imports: $996 million (cif , FY88); com-
modities—food and petroleum products,
partners—mostly USSR and Eastern Eu-
rope
External debt: $1 8 billion (December
1989 est )
Industrial production: growth rate 6 2%
(FY89 plan)
Electricity: 480,000 kW capacity, 1,470
million kWh produced, 100 kWh per cap-
ita (1989)
Industries: small-scale production of tex-
tiles, soap, furniture, shoes, fertilizer, and
cement, handwoven carpets; natural gas,
oil, coal, copper
Agriculture: largely subsistence farming
and nomadic animal husbandry, cash
products—wheat, fruits, nuts, karakul
pelts, wool, mutton
Illicit drugs: an illicit producer of opium
poppy and cannabis for the international
drug trade, world’s second largest opium
producer (after Burma) and a major
source of hashish
Aid: US commitments, including Ex-Im
(FY 70-88), $265 million; Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $419 million,
OPEC bilateral aid (1979-89), $57 million,
Communist countries (1970-88), $4 1 bil-
lion
Currency: afgham (plural—afghanis), |
afghan (Af) = 100 puls
Exchange rates: afghanis (Af) per US$1—
50 6 (fixed rate since 1982)
Fiscal year: 21 March-20 March','e835cb4f9a636cdd059fdab97c2606f8b271b6ed3da3eea3f82bb2a1a380672d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaf40ae9f005843f3582fbb22a7d1e51b475f0d62bb2decaf4aa1982cbec66da',1990,'AL','Albania','economy',12,'Overview: As the poorest country in Eu-
rope, Albania’s development lags behind
even the least favored areas of the Yugos-
lav economy The Stalinist-type economy
operates on the principles of central plan-
ning and state ownership of the means of
production In recent years Albania has
implemented limited economic reforms to
stimulate its lagging economy, although
they do not go nearly so far as current
reforms in the USSR and Eastern Europe
Attempts at self-reliance and a policy of
not borrowing from international lend-
ers—sometimes overlooked in recent
years—have greatly hindered the develop-
ment of a broad economic infrastructure
Albania, however, possesses considerable
mineral resources and 1s largely
self-sufficient in food Numerical estimates
of Albaman economic activity are subject
to an especially wide margin of error be-
cause the government 1s tsolated and
closemouthed
GNP: $3 8 billion, per capita $1,200, real
growth rate NA% (1989 est )
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $2 3 billion, expenditures
$2 3 billion, including capital expenditures
of NA (1989)
Exports: $378 million (f 0 b , 1987 est ),
commodities—asphalt, bitumen, petro-
leum products, metals and metallic ores,
electricity, oil, vegetables, fruits, tobacco,
partners—lItaly, Yugoslavia, FRG,
Greece, Czechoslovakia, Poland, Romania,
Bulgaria, Hungary
Imports: $255 million (f 0 b , 1987 est ),
commodities—machinery, machine tools,
iron and steel products, textiles, chemi-
cals, pharmaceuticals, partners—lItaly,
Yugoslavia, FRG, Czechoslovakia, Roma-
nia, Poland, Hungary, Bulgaria, GDR
External debt: $NA
Industrial production: growth rate NA
Electricity: 1,630,000 kW capacity, 4,725
million kWh produced, 1,440 kWh per
capita (1989)
Industries: food processing, textiles and
clothing, lumber, oil, cement, chemicals,
basic metals, hydropower
Agriculture: arable land per capita among
lowest in Europe, one-half of work force
engaged in farming, produces wide range
of temperate-zone crops and livestock,
claims self-sufficiency in grain output
Aid: none
Currency: lek (plural—leke), 1 lek (L) =
100 qintars
Exchange rates: leke (L) per US$1—8 00
(noncommercial fixed rate since 1986),
4 14 (commercial fixed rate since 1987)
Fiscal year: calendar year','242c4fed09844c7eb4a1a43c89a05de08720815a07a2a826ac0cbb16d4f5b2bd','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02fe893f9b8aa4e93eb03f44c6d1d871984e12ba454b91cf1fa101c863fc8bf2',1990,'DZ','Algeria','economy',17,'Overview: The exploitation of oil and natu-
ral gas products forms the backbone of
the economy Algeria depends on hydro-
carbons for nearly all of its export
receipts, about 30% of government reve-
nues, and nearly 25% of GDP In 1973-74
the sharp increase 1n oil prices led to a
booming economy that helped to finance
an ambitious program of industnialization
Plunging oil and gas prices, combined
with the mismanagement of Algeria’s
highly centralized economy, have brought
the nation to its most serious social and
economic crisis since independence The
government has promised far-reaching
Approved for Release: 2020/08/12 C06554432
reforms, including giving public sector
companies more autonomy, encouraging
private-sector activity, boosting gas and
nonhydrocarbon exports, and a major
overhaul of the banking and financial sys-
tems In 1988 the government started to
implement a new economic policy to dis-
mantle large state farms into privately
operated units
GDP: $54 1 billion, per capita $2,235, real
growth rate —1 8% (1988)
Inflation rate (consumer prices): 5 9%
(1988)
Unemployment rate: 19% (1988)
Budget: revenues $17 4 billion, expendi-
tures $22 0 billion, including capital ex-
penditures of $8 0 billion (1988)
Exports: $9 1 billion (fob, 1989 est ),
commodities—petroleum and natural gas
98%, partners—Netherlands, Czechoslo-
vakia, Romania, Italy, France, US
Imports: $7 8 billion (fob, 1989 est),
commodities—capital goods 35%, con-
sumer goods 36%, food 20%, partners—
France 25%, Italy 8%, FRG 8%, US 6-7%
External debt: $26 2 billion (December
1989)
Industrial production: growth rate 5 4%
(1986)
Electricity: 4,333,000 kW capacity,
14,370 million kWh produced, 580 kWh
per capita (1989)
Industries: petroleum, light industries, nat-
ural gas, mining, electrical, petrochemical,
food processing
Agriculture: accounts for 8% of GDP and
employs 24% of labor force, net importer
of food—grain, vegetable oil, and sugar,
farm production includes wheat, barley,
oats, grapes, olives, citrus, fruits, sheep,
and cattle
Aid: US commitments, including Ex-Im
(FY70-85), $1 4 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $8 2 billion, OPEC
bilateral aid (1979-89), $1 8 billion, Com-
munist countries (1970-88), $2 7 billion
Currency: Algerian dinar (plural—dinars),
1 Algerian dinar (DA) = 100 centimes
Exchange rates: Algerian dinars (DA) per
US$1—8 0086 (January 1990), 7 6086
(1989), 5 9148 (1988), 4.8497 (1987),
4 7023 (1986), 5 0278 (1985)
Fiscal year: calendar year','58d48edb9914d9a4c09d62212c301bd530ced167fb35f6f24a4f374cfe60cc97','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5405c40f118399cc647cf796d4a7d8e871ea8306ab890bd30c27b7cc70a1c7a6',1990,'WS','Samoa','economy',22,'Overview: Economic development 1s
strongly linked to the US, with which
American Samoa does 90% of its foreign
trade Tuna fishing and tuna processing
plants are the backbone of the private sec-
tor economy, with canned tuna the pri-
mary export The tuna canneries are the
second-largest employer, exceeded only by
the government Other economic activities
include meat canning, handicrafts, dairy
farming, and a slowly developing tourist
industry Tropical agricultural production
provides little surplus for export
GNP: $190 million, per capita $5,210,
real growth rate NA% (1985)
Inflation rate (consumer prices): 4 3%
(1989)
Unemployment rate: 13 4% (1986)
Budget: revenues $90 3 million, expendi-
tures $93 15 million, including capital ex-
penditures of $49 million (1988)
Exports: $288 million (fob, 1987), com-
modities—canned tuna 93%, partners—
US 99 6%
Imports: $346 million (cif, 1987), com-
modities—building materials 18%, food
17%, petroleum products 14%, partners—
US 72%, Japan 7%, NZ 7%, Australia
5%, other 9%
External debt: $NA
Industrial production: growth rate NA%
Electricity: 35,000 kW capacity, 70 mil-
lion kWh produced, 1,720 kWh per capita
(1989)
Industries: tuna canneries (largely depen-
dent on foreign supplies of raw tuna)
Agriculture: bananas, coconuts, vegetables,
taro, breadfruit, yams, copra, pineapples,
papayas
Aid: $20 1 million in operational funds
and $5 8 million in construction funds for
capital improvement projects from the US
Department of Interior (1989)
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: 1 October-30 September','a875694fd89aa0b56d5ff776cee6aa93ae19694eb343ea26efbb8d77d070e0a3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b920544e132fb71bed9996bc5ac6bc35a5f89884bdf050875e449133ee7e95',1990,'AD','Andorra','economy',27,'Overview: The mainstay of Andorra’s
economy 1s tourism An estimated 12 mil-
lion tourists visit annually, attracted by
Andorra’s duty-free status and by its sum-
mer and winter resorts Agricultural pro-
duction 1s limited by a scarcity of arable
land, and most food has to be imported
The principal livestock activity 1s sheep
raising Manufacturing consists mainly of
cigarettes, cigars, and furniture The rapid
pace of European economic integration 1s
a potential threat to Andorra’s advantages
from its duty-free status
GNP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $NA, expenditures $NA,
including capital expenditures of $NA
Exports: $0.017 million (f 0.b , 1986),
commoadities—electricity, partners—
France, Spain
Imports: $531 million (fo b, 1986), com-
modities—NA, partners—France, Spain
External debt: $NA
Industrial production: growth rate NA%
Electricity: 35,000 kW capacity, 140 mil-
lion kWh produced, 2,800 kWh per capita
(1989)
Industries: tourism (particularly skiing),
sheep, timber, tobacco, smuggling, bank-
ing
Agriculture: sheep raising, small quantities
of tobacco, rye, wheat, barley, oats, and
some vegetables
Aid: none','c2869ba37140fedb8238a1cad48bcf21cdda9c82403124ce406cdcddd17798ad','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663ff7bec4fcb35e9f6ce48e82808b9f157dcd98fef5e7205d96e8e6184866d3',1990,'AO','Angola','economy',28,'<4 300 km
Cabinda
Currency: French franc (plural—francs)
and Spanish peseta (plural—pesetas), 1
French franc (F) = 100 centimes and 1
Spanish peseta (Pta) = 100 céntimos
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985), Spanish pe- eae
setas (Ptas) per US$1—109 69 (January Atlantic
1990), 118 38 (1989), 116 49 (1988), Ocean
123 48 (1987), 140 05 (1986), 170 04
(1985)
Fiscal year: calendar year
La
Matanje
Overview: Subsistence agriculture provides
the main livelihood for 80-90% of the pop-
ulation, but accounts for only 10-20% of
GDP Oil production 1s the most lucrative
sector of the economy, contributing about
50% to GDP In recent years, however,
the impact of fighting an internal war has
severely affected the economy and food
has to be imported
GDP: $5 0 billion, per capita $600, real
growth rate 9 2% (1988 est )
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues NA; expenditures $2 7
billion, including capital expenditures of
NA (1986 est )
Exports: $2 9 billion (fob, 1989 est ),
commodities—oil, coffee, diamonds, sisal,
fish and fish products, timber, cotton,
partners—US, USSR, Cuba, Portugal,','23e3e75d358ebad17964146dc27913ade7e1db110ea4f2b354ff5848a8384297','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa8de41173c4b575d172c7ef0fc244f82435617942d61195315d22c75ff31620',1990,'BR','Brazil','economy',33,'Imports: $2 5 billion (fob, 1989 est ),
commodities—capital equipment
(machinery and electrical equipment),
food, vehicles and spare parts, textiles and
clothing, medicines, substantial mihtary
deliveries, partners—US, USSR, Cuba,
Portugal, Brazil
External debt: $3 0 billion (1989)
Industrial production: growth rate NA%
Electricity: 506,000 kW capacity, 770 mil-
hon kWh produced, 90 kWh per capita
(1989)
Industries: petroleum, mining (phosphate
rock, diamonds), fish processing, brewing,
tobacco, sugar, textiles, cement, food pro-
cessing, building construction
Agriculture: cash crops—coffee, sisal,
corn, cotton, sugar, manioc, tobacco, food
crops—cassava, corn, vegetables, plan-
tains, bananas, and other local foodstuffs,
disruptions caused by civil war and mar-
keting deficiencies require food imports
Aid: US commitments, including Ex-Im
(FY70-88), $263 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $903 million,
Communist countries (1970-88), $1 3 bil-
lion
Currency: kwanza (plural—kwanza), 1
kwanza (Kz) = 100 lwet
Exchange rates: kwanza (Kz) per US$1—
29 62 (fixed rate since 1976)
Fiscal year: calendar year
Overview: The economy, a mixture of pri-
vate enterprises of all sizes and extensive
government intervention, experienced
enormous difficulties in the late 1980s,
notably declining real growth, runaway
inflation, foreign debt obligations of more
than $100 billion, and uncertain economic
policy Government intervention includes
trade and investment restrictions, wage/
price controls, interest and exchange rate
controls, and extensive tariff barriers
Ownership of major industrta! facilities 1s
divided among private interests, the gov-
ernment, and multinational companies
Ownership in agriculture likewise 1s var-
ted, with the government intervening in
the politically sensitive issues involving
large landowners and the masses of poor
peasants In consultation with the IMF,
the Brazilian Government has initiated
several programs over the last few years
to ameliorate the stagnation and foreign
debt problems None of these has given
more than temporary relief The strategy
of the new Collor government is to
increase the pace of privatization, encour-
age foreign trade and investment, and es-
tablish a more realistic exchange rate
One long-run strength is the existence of
vast natural resources
GDP: $377 billion, per capita $2,500, real
growth rate 3% (1989 est )
Inflation rate (consumer prices): | ,765%
(1989)
Unemployment rate: 2 5% (December
1989)
39
Approved for Release: 2020/08/12 C06554432
Brazil (continued)
Budget: revenues $27 8 billion, expendi-
tures $40 1 billion, including capital ex-
penditures of $8 8 billion (1986)
Exports: $34 2 billion (1989 est ), com-
modities—coffee, metallurgical products,
chemical products, foodstuffs, iron ore,
automobiles and parts, partners—US
28%, EC 26%, Latin America 11%, Japan
6% (1987)
Imports: $18 0 billion (1989 est ); com-
modities—crude oil, capital goods, chemi-
cal products, foodstuffs, coal, partners—
Middle East and Africa 24%, EC 22%,
US 21%, Latin America 12%, Japan 6%
(1987)
External debt: $109 billion (December
1989)
Industrial production: growth rate 3 2%
(1989 est )
Electricity: 52,865,000 kW capacity,
202,280 million kWh produced, 1,340
kWh per capita (1989)
Industries: textiles and other consumer
goods, shoes, chemicals, cement, lumber,
iron ore, steel, motor vehicles and auto
parts, metalworking, capital goods, tin
Agriculture: accounts for 12% of GDP;
world’s largest producer and exporter of
coffee and orange juice concentrate and
second-largest exporter of soybeans, other
products—rice, corn, sugarcane, cocoa,
beef, self-sufficient in food, except for
wheat
Illicit drugs: illicit producer of cannabis
and coca, mostly for domestic consump-
tion, government has an active eradication
program to control cannabis and coca cul-
tivation
Aid: US commitments, including Ex-Im
(FY70-88), $2 5 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $9 5 billion, OPEC
bilateral aid (1979-89), $284 million,
Communist countries (1970-88), $1 3 bil-
lion
Currency: novo cruzado (plural—novos
cruzados); 1 novo cruzado (NCr$) = 100
centavos
Exchange rates: novos cruzados (NCr$)
per US$1—2 83392 (1989), 0 26238
(1988), 0 03923 (1987), 0 01366 (1986),
0 00620 (1985), note— 25 tourist/parallel
rate (December 1989)
Fiscal year: calendar year','b2da96952d41d22dffdb065b8de7ee0887292ef79c9fd2212a8d51da71a03266','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3844bba6bce56a1ed0e664ada148f4438090466fc4dc7858b64c16deefac4d1a',1990,'AI','Anguilla','economy',39,'Overview: Anguilla has few natural re-
sources, and the economy depends heavily
on lobster fishing, offshore banking, tour-
ism, and remittances from emigrants In
recent years the economy has benefited
from a boom in tourism Development 1s
planned to improve the infrastructure,
particularly transport and tourist facilities,
and also light industry Improvement in
the economy has reduced unemployment
from 40% in 1984 to about 5% in 1988
GDP: $23 million, per capita $3,350 (1988
est ), real growth rate 8 2% (1988)
Inflation rate (consumer prices): 4 5%
(1988 est )
Unemployment rate: 5 0% (1988 est )
Budget: revenues $9 0 million, expendi-
tures $8 8 million, including capital ex-
penditures of NA (1988 est )
Exports: $NA, commodities—lobsters and
salt, partners—NA
Imports: $NA, commodities—NA, part-
ners —-NA
External debt: $NA
Industrial production: growth rate NA%
Electricity: 3,000 kW capacity, 9 millon
kWh produced, 1,300 kWh per capita
(1988)
Industries: tourism, boat building, salt,
fishing (including lobster)
Agriculture: pigeon peas, corn, sweet pota-
toes, sheep, goats, pigs, cattle, poultry
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $33 million
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: NA','cc0376b690474d179dea7d196a71f4a09557e6d30762990a7b5fcd33f08d301b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57e3b1f1b5215e306a2acb93c211453b019703589c187e1c40c91b958006b41f',1990,'AQ','Antarctica','economy',44,'Overview: No economic activity at present
except for fishing off the coast and small-
scale tourism, both based abroad Explo1-
tation of mineral resources will be held
back by technical difficulties, high costs,
and objections by environmentalists','a64ba53b068e2714fc8335d5956fd2bd6c83e2017f6b0a693adad7393272395b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c910ed43ea10c770ca5a692bfbadedcd304d5fca34c0ce293a1438971e5fd27',1990,'AG','Antigua and Barbuda','economy',49,'Overview: The economy 1s primarily ser-
vice oriented, with tourism the most 1m-
portant determinant of economic perfor-
mance During the period 1983-87, real
GDP expanded at an annual average rate
of 8% Tourism’s contribution to GDP, as
measured by value added in hotels and
restaurants, rose from about 14% in 1983
to 17% in 1987, and stimulated growth in
other sectors—particularly in construction,
communications, and public utilities. Dur-
ing the same period the combined share of
agriculture and manufacturing declined
from 12% to less than 10% Antigua and
Barbuda ts one of the few areas in the
Caribbean experiencing a labor shortage
in some sectors of the economy
GDP: $353 5 million, per capita $5,550,
real growth rate 6 2% (1989 est )
Inflation rate (consumer prices): 7 1%
(1988 est )
Unemployment rate: 5 0% (1988 est )
Budget: revenues $77 million, expenditures
$81 million, including capital expenditures
of $13 million (1988 est )
Exports: $30 4 million (fo b., 1988 est ),
commodities—petroleum products 46%,
manufactures 29%, food and live animals
14%, machinery and transport equipment
11%, partners—Trinidad and Tobago
40%, Barbados 8%, US 0 3%
Imports: $302 | million (cif, 1988 est ),
commodittes—food and live animals, ma-
chinery and transport equipment, manu-
factures, chemicals, oil, partners—US
27%, UK 14%, CARICOM 7%, Canada
4%, other 48%
External debt: $245 4 million (1987)
Approved for Release: 2020/08/12 C06554432
Industrial production: growth rate 10%
(1987)
Electricity: 49,000 kW capacity, 90 mil-
lion kWh produced, 1,410 kWh per capita
(1989)
Industries: tourism, construction, light
manufacturing (clothing, alcohol, house-
hold appliances)
Agriculture: accounts for 4% of GDP, ex-
panding output of cotton, fruits, vegeta-
bles, and livestock sector, other crops—
bananas, coconuts, cucumbers, mangoes,
not self-sufficient in food
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $40 millon
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: 1 April-31 March
Overview: Economic activity 1s limited to
the exploitation of natural resources, in-
cluding crude oil, natural gas, fishing, and
sealing','5d81cbe9fe8b3476d093b016c439b434a0d874e6c1fb121d518a7559759d6b54','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09fbe15d7ffa6fc95eb2c45568c9b3b7d57b164118010eaf46430a055b60a319',1990,'AR','Argentina','economy',54,'Overview: Argentina 1s rich 1n natural re-
sources, and has a highly literate popula-
tion, an export-oriented agricultural sec-
tor, and a diversified industrial base
Nevertheless, the economy has encoun-
tered major problems 1n recent years,
leading to a recession in 1988-89 Eco-
nomic growth slowed to 2 0% in 1987 and
to —1 8% in 1988, a sharp decline of
—5 5% has been estimated for 1989 A
widening public-sector deficit and a multi-
digit inflation rate has dominated the
economy over the past three years, reach-
ing about 5,000% in 1989 Since 1978,
Argentina’s external debt has nearly dou-
bled to $60 billion, creating severe debt-
servicing difficulties and hurting the
country’s creditworthiness with interna-
tional lenders
GNP: $72 0 billion, per capita $2,217, real
growth rate —5 5% (1989 est )
Inflation rate (consumer prices): 4,925%
(1989)
Unemployment rate: 8 5% (1989 est )
Budget: revenues $11 5 billion, expendi-
tures $13 0 billion, including capital ex-
penditures of $0 93 billion (1988)
Exports: $9 6 billion (fo b, 1989), com-
modities—meat, wheat, corn, oilseed,
hides, wool, partners—US 14%, USSR,
Italy, Brazil, Japan, Netherlands
Imports: $4 3 billion (cif, 1989), com-
modities—machinery and equipment,
chemicals, metals, fuels and lubricants,
agricultural products, partners—US 25%,
Brazil, FRG, Bolivia, Japan, Italy, Neth-
erlands
External debt: $60 billion (December
1989)
Industrial production: growth rate —8%
(1989)
Electricity: 16,449,000 kW capacity,
46,590 million kWh produced, 1,460 kWh
per capita (1989)
Industries: food processing (especially
meat packing), motor vehicles, consumer
durables, textiles, chemicals and petro-
chemicals, printing, metallurgy, steel
Agriculture: accounts for 15% of GNP
(including fishing), produces abundant
food for both domestic consumption and
exports, among world’s top five exporters
of grain and beef, principal crops—wheat,
corn, sorghum, soybeans, sugar beets,
1987 fish catch estimated at 500,000 tons
Aid: US commitments, including Ex-Im
(FY70-88), $1 0 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $3 6 billion, Commu-
nist countries (1970-88), $718 million
Currency: austral (plural—australes), 1
austral (A) = 100 centavos
Exchange rates: australes (A) per US$1—
1,930 (December 1989), 8 7526 (1988),
2 1443 (1987), 0 9430 (1986), 0 6018
(1985)
Fiscal year: calendar year','08b603d04e59f50a926dec22a34443741422b2d24fd44a0a3069444547e1808c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f93912a204bcf8bdc84ef55ccea92d0d044d10514b076fd6e603e6af84c46fd7',1990,'AW','Aruba','economy',59,'Overview: Tourism ts the mainstay of the
economy In 1985 the economy suffered a
severe blow when Exxon closed its
refinery, a major source of employment
and foreign exchange earnings Economic
collapse was prevented by soft loans from
the Dutch Government and by a booming
tourist industry Hotel capacity expanded
by 20% between 1985 and 1987 and ts
projected to more than double by 1990
Unemployment has steadily declined from
about 20% 1n 1986 to about 3% in 1988
GDP: $620 million, per capita $10,000,
real growth rate 16 7% (1988 est )
Inflation rate (consumer prices): 4% (1988
est )
Unemployment rate: 3% (1988 est )
Budget: revenues $145 million, expendi-
tures $185 million, including capital ex-
penditures of $42 million (1988)
Exports: $47 5 million (fo b , 1988 est ),
commodities—mostly petroleum products,
partners—US 64%, EC
Imports: $296 0 million (cif, 1988 est ),
commodities—food, consumer goods,
manufactures, partners—US 8%, EC
External debt: $81 million (1987)
Industrial production: growth rate —20%
(1984)
Electricity: 310,000 kW capacity, 945 mil-
lion kWh produced, 15,120 kWh per cap-
ita (1989)
Industries: tourism, transshipment facili-
ties
Agriculture: poor quality soils and low
rainfall limit agricultural activity to the
cultivation of aloes
Aid: none
Currency: Aruban florin (plural—fiorins),
1 Aruban florin (Af) = 100 cents
Exchange rates: Aruban florins (Af ) per
US$1—1 7900 (fixed rate since 1986)
Fiscal year: calendar year
Overview: no economic activity
Overview: Economic activity 1s limited to
exploitation of natural resources, espe-
cially fish, dredging aragonite sands (The
Bahamas), and crude oil and natural gas
production (Caribbean Sea and North
Sea)','15afe08f8cf356c713c059283efd4dcf3215ad957e5b0c74ecf2c1c8faed5600','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3906faa315ea3fb48be4689a0273fd3b7e6a67ab1cc10259a5099054fa0fcfa',1990,'AU','Australia','economy',64,'Overview: Australia has a prosperous
Western-style capitalist economy, with a
per capita GNP comparable to levels in
industrialized West European countries
Rich in natural resources, Australia 1s a
major exporter of agricultural products,
minerals, metals, and fossil fuels Of the
top 25 exports, 2] are primary products,
so that, as happened during 1983-84, a
downturn in world commodity prices can
have a big impact on the economy The
government 1s pushing for increased ex-
ports of manufactured goods but competi-
tion in international markets will be se-
vere
GNP: $240 8 billion, per capita $14,300,
real growth rate 4 1% (1989 est )
Inflation rate (consumer prices): 8 0%
(1989)
Unemployment rate: 6 0% (December
1989)
Budget: revenues $76 3 billion, expendi-
tures $69 1 billion, including capital ex-
penditures of NA (FY90 est )
Exports: $43 2 billion (fo b , FY89), com-
modities—wheat, barley, beef, lamb,
dairy products, wool, coal, iron ore, part-
ners—Japan 26%, US 11%, NZ 6%,
South Korea 4%, Singapore 4%, USSR
3%
Imports: $48 6 billion (cif , FY89), com-
modittes—manufactured raw materials,
capital equipment, consumer goods, part-
ners—US 22%, Japan 22%, UK 7%, FRG
6%, NZ 4% (1984)
External debt: $111 6 billion (September
1989)
Industrial production: growth rate 5 6%
(FY88)
Electricity: 38,000,000 kW capacity,
139,000 million kWh produced, 8,450
kWh per capita (1989)
Industries: mining, industrial and trans-
portation equipment, food processing,
chemicals, steel, motor vehicles
Agriculture: accounts for 5% of GNP and
37% of export revenues, world’s largest
exporter of beef and wool, second-largest
for mutton, and among top wheat export-
ers, major crops—wheat, barley, sugar-
cane, fruit, livestock—cattle, sheep, poul-
try
Aid: donor—ODA and OOF commitments
(1970-87), $8 8 billion
Currency: Australian dollar (plural—dol-
lars), 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A)
per US$1—1 2784 (January 1990), 1 2618
(1989), 1 2752 (1988), 1 4267 (1987),
1 4905 (1986), 1 4269 (1985)
Fiscal year: 1 July-30 June','de0a070485d6f34450c1dffd7e48c68e6f93f3e586ad50af573b2fc52a7ce226','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('562f1cafd3b97b2329922a39e18861268ef67edd6a8cdabfd08ce2c553572120',1990,'AT','Austria','economy',69,'Overview: Austria boasts a prosperous and
stable capitalist economy with a sizable
proportion of nationalized industry and
extensive welfare benefits Thanks to an
excellent raw material endowment, a tech-
nically skilled labor force, and strong links
with West German industrial firms, Aus-
tria has successfully occupied specialized
niches in European industry and services
(tourism, banking) and produces almost
enough food to feed itself with only 8% of
the labor force in agriculture Living stan-
dards are roughly comparable with the
large industrial countries of Western Eu-
rope Problems for the 1990s include an
aging population and the struggle to keep
welfare benefits within budget capabilities
GDP: $103 2 billion, per capita $13,600,
real growth rate 4 2% (1989 est )
Inflation rate (consumer prices): 2.7%
(1989)
Unemployment: 4 8% (1989)
Budget: revenues $34 2 billion; expendi-
tures $39 5 billion, including capital ex-
penditures of NA (1988)
Exports: $31 2 billion (fob, 1989), com-
modities—machinery and equipment, iron
and steel, lumber, textiles, paper products,
chemicals, partners—FRG 35%, Italy
10%, Eastern Europe 9%, Switzerland 7%,
US 4%, OPEC 3%
Imports: $37 9 billion (cif, 1989); com-
modities—petroleum, foodstuffs, machin-
ery and equipment, vehicles, chemicals,
textiles and clothing, pharmaceuticals,
partners—FRG 44%, Italy 9%, Eastern
Europe 6%, Switzerland 5%, US 4%,
USSR 2%
External debt: $12 4 billion (December
1987)
Industrial production: growth rate 5 8%
(1989 est )
Electricity: 17,562,000 kW capacity,
49,290 million kWh produced, 6,500 kWh
per capita (1989)
Industries: foods, iron and steel, machines,
textiles, chemicals, electrical, paper and
pulp, tourism, mining
Agriculture: accounts for 4% of GDP (in-
cluding forestry), principal crops and ani-
mals—grains, fruit, potatoes, sugar beets,
sawn wood, cattle, pigs poultry, 80-90%
self-sufficient in food
Aid: donor—ODA and OOF commitments
(1970-87), $1 7 billion
Currency: Austrian schilling (plural—
schillings), 1 Austrian schilling (S) = 100
groschen
Exchange rates: Austrian schillings (S) per
US$1—11 907 (January 1990), 13 231
(1989), 12 348 (1988), 12 643 (1987),
15 267 (1986), 20 690 (1985)
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432
Overview: The Bahamas 1s a stable,
middle-income developing nation whose
economy 1s based primarily on tourism
and offshore banking Tourism alone pro-
vides about 50% of GDP and directly or
indirectly employs about 50,000 people or
40% of the local work force The economy
has boomed 1n recent years, aided by a
steady annual increase in the number of
tourists The per capita GDP of over
$9,800 is one of the highest in the region
GDP: $2 4 billion, per capita $9,875, real
growth rate 2 0% (1988 est )
Inflation rate (consumer prices): 4 1%
(1988)
Unemployment: 12% (1986)
Budget: revenues $555 million, expendi-
tures $702 million, including capital ex-
penditures of $138 million (1989 est )
Exports: $733 million (f o b , 1987), com-
modities—pharmaceuticals, cement, rum,
crawfish, partners—US 90%, UK 10%
Imports: $1 7 billion (cif, 1987), com-
modities—foodstuffs, manufactured goods,
mineral fuels, partners—Iran 30%, Nige-
ria 20%, US 10%, EC 10%, Gabon 10%
External debt: $1 5 billion (September
1988)
Industrial production: growth rate NA%
Electricity: 368,000 kW capacity, 857 mil-
lion kWh produced, 3,470 kWh per capita
(1989)
Industries: banking, tourism, cement, oil
refining and transshipment, salt produc-
tion, rum, aragonite, pharmaceuticals, spi-
ral weld, steel pipe
Agriculture: accounts for less than 5% of
GDP, dominated by small-scale producers,
principal products—citrus fruit, vegeta-
bles, poultry, large net importer of food
Aid: US commitments, including Ex-Im
(FY70-80), $42 million; Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $344 million
Approved for Release: 2020/08/12 C06554432
Currency: Bahamian dollar (plural—dol-
lars), 1 Bahamian dollar (B$) = 100 cents
Exchange rates: Bahamian dollar (B$) per
US$1—1 00 (fixed rate)
Fiscal year: calendar year','cd3a42a502c67ea4d4b6523fef378e2aabdfdb558f9f07d7df546b3c2178f672','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e201e6087a6b6bfe11f634f204b2f672e65aa7c90dc890b56403b9a80d7f6691',1990,'BH','Bahrain','economy',74,'Overview: The oil price decline in recent
years has had an adverse impact on the
economy Petroleum production and pro-
cessing account for about 85% of export
receipts, 60% of government revenues, and
20% of GDP In 1986 soft o1l-market con-
ditions led to a 5% drop in GDP, in sharp
contrast wit the 5% average annual
growth rate during the early 1980s The
slowdown 1n economic activity, however,
has helped to check the inflation of the
1970s The government’s past economic
diversification efforts have moderated the
severity of the downturn but failed to
offset oil and gas revenue losses
GDP: $3 5 billion, per capita $7,550
(1987), real growth rate 0% (1988)
Inflation rate (consumer prices): 0 3%
(1988)
Unemployment: 8-10% (1989)
Budget: revenues $1,136 million, expendi-
tures $1,210 million, including capital ex-
penditures of $294 million (1987)
Exports: $2 4 billion (fob, 1988 est ),
commodities—petroleum 80%, aluminum
7%, other 13%, partners—US, UAE, Ja-
pan, Singapore, Saudi Arabia
Imports: $2 5 billion (fo b , 1988 est ),
commodities—nonoil 59%, crude oil 41%,
partners—UK, Saudi Arabia, US, Japan
External debt: $1 1 billion (December
1989 est )
Industrial production: growth rate —3 1%
(1987)
Electricity: 1,652,000 kW capacity, 6,000
million kWh produced, 12,800 kWh per
capita (1989)
Industries: petroleum processing and re-
fining, aluminum smelting, offshore bank-
ing, ship repairing
Agriculture: including fishing, accounts for
less than 2% of GDP, not self-sufficient in
food production, heavily subsidized sector
produces fruit, vegetables, poultry, dairy
products, shrimp, and fish, fish catch
9,000 metric tons in 1987
23
Approved for Release: 2020/08/12 C06554432
Bahrain (continued)
Aid: US commitments, including Ex-Im
(FY70-79), $24 million, Western (non-US)
countries, ODA and OOF bilateral Com-
mitments (1970-87), $28 million, OPEC
bilateral aid (1979-89), $9 8 billion
Currency: Bahraini dinar (plural—dinars),
1 Bahraini dinar (BD) = 1,000 fils
Exchange rates: Bahraini dinars (BD) per
US3$1—0 3760 (fixed rate)
Fiscal year: calendar year
Overview: no economic activity','d74141fb3bca52d69099adccfea926ac8bf8be8311eea91e9c757906023f1804','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d19014f27d05032c90413a9417ed342af6a98dca63f95c8885cd5877642b7fe8',1990,'BD','Bangladesh','economy',80,'Overview: The economy ts based on the
output of a narrow range of agricultural
products, such as jute, which 1s the main
cash crop and major source of export
earnings Bangladesh is hampered by a
relative lack of natural resources, a rapid
25
Approved for Release: 2020/08/12 C06554432
Bangladesh (continued)
population growth of 28% a year and a
limited infrastructure, and it 1s highly vul-
nerable to natural disasters Despite these
constraints, real GDP averaged about
3 8% annually during 1985-88 One of the
poorest nations in the world, alleviation of
poverty remains the cornerstone of the
government’s development strategy The
agricultural sector contributes over 50% to
GDP and 75% to exports, and employs
over 74% of the labor force Industry ac-
counts for about 10% of GDP
GDP: $20 6 billion, per capita $180, real
growth rate 2 1% (FY89 est )
Inflation rate (consumer prices): 8-10%
(FY89 est )
Unemployment rate: 30% (FY88 est )
Budget: revenues $1 8 billion, expenditures
$3 3 billion, including capital expenditures
of $1 7 billion (FY89)
Exports: $1 3 billion (fob, FY89 est ),
commodities—jute, tea, leather, shrimp,
manufacturing, partners—US 25%, West-
ern Europe 22%, Middle East 9%, Japan
8%, Eastern Europe 7%
Imports: $3 1 billion (c1f, FY89 est ),
commodities—food, petroleum and other
energy, nonfood consumer goods, semipro-
cessed goods, and capital equipment, part-
ners—Western Europe 18%, Japan 14%,
Middle East 9%, US 8%
External debt: $10 4 billion (December
1989)
Industrial production: growth rate 5 4%
(FY89 est )
Electricity: 1,700,000 kW capacity, 4,900
million kWh produced, 40 kWh per capita
(1989)
Industries: jute manufacturing, food pro-
cessing, cotton textiles, petroleum, urea
fertilizer
Agriculture: accounts for about 50% of
GDP and 74% of both employment and
exports, imports 10% of food grain
requirements, world’s largest exporter of
jute, commercial products—yute, rice,
wheat, tea, sugarcane, potatoes, beef,
milk, poultry, shortages include wheat,
vegetable oils and cotton, fish catch
778,000 metric tons in 1986
Aid: US commitments, including Ex-Im
(FY70-87), $3 2 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1980-87), $9 5 billion, OPEC
bilateral aid (1979-89), $652 million,
Communist countries (1970-88), $1 5 bil-
lion
Currency: taka (plural—taka), 1 taka (Tk)
= 100 paise
Exchange rates: taka (Tk) per US$1—
32 270 (January 1990), 32 270 (1989),
31 733 (1988), 30 950 (1987), 30 407
(1986), 27 995 (1985)
Fiscal year: | July-30 June
26
Approved for Release: 2020/08/12 C06554432','41dceef697a9947be693c680dc448b87973eb114b5cbbc8a9abb135e865a2ed3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('588bbbfba7984c2d232942a4e967928169b1a8a20c95b1f8f63a0eb56c0ec0e6',1990,'BB','Barbados','economy',85,'Overview: A per capita income of $5,250
gives Barbados the highest standard of
living of all the small island states of the
eastern Caribbean Historically, the econ-
omy was based on the cultivation of sug-
arcane and related activities In recent
years, however, the economy has diversi-
fied into manufacturing and tourism The
tourist industry 1s now a major employer
of the labor force and a primary source of
foreign exchange A high unemployment
rate of about 19% in 1988 remains one of
the most serious economic problems facing
the country
GDP: $1 3 billion, per capita $5,250 (1988
est ), real growth rate 3 7% (1989 est )
Inflation rate (consumer prices): 4 7%
(1988)
Unemployment: 18 6% (1988)
Budget: revenues $476 million, expendi-
tures $543 million, including capital ex-
penditures of $94 million (FY86)
Exports: $173 million (fob, 1988), com-
modities—sugar and molasses, electrical
components, clothing, rum, machinery and
transport equipment, partners US 30%,
CARICOM, UK, Puerto Rico, Canada
Imports: $582 million (c1f , 1988), com-
modities—foodstuffs, consumer durables,
raw materials, crude oil, partners—US
34%, CARICOM, Japan, UK, Canada
External debt: $635 million (December
1989 est )
Industrial production: growth rate —5 4%
(1987 est )
Electricity: 132,000 kW capacity, 460 mil-
hon kWh produced, 1,780 kWh per capita
(1989)
Industries: tourism, sugar, light manufac-
turing, component assembly for export
Agriculture: accounts for 10% of GDP,
mayor cash crop 1s sugarcane, other
crops—vegetables and cotton, not self-
sufficient in food
Aid: US commitments, including Ex-Im
(FY70-84), $14 millon, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $144 million
Currency: Barbadian dollars (plural—dol-
lars); 1 Barbadian dollar (Bds$) = 100
cents
Exchange rates: Barbadian dollars (Bds$)
per US$1—2 0113 (fixed rate)
Fiscal year: 1 April-31 March','6007da1301ff478b7c0ef5c300a015681edfb186eff12db4f51d8f761d655d7d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22fd7af1d5319f14e564b6f332ab2167d1f30c87bce9e697b0f2562c12468109',1990,'MZ','Mozambique','economy',90,'Overview: no economic activity
Overview: One of the world’s poorest coun-
tries, Comoros 1s made up of several 1s-
lands that have poor transportation links,
a young and rapidly increasing population,
and few natural resources The low educa-
tional level of the labor force contributes
to a low level of economic activity, high
unemployment, and a heavy dependence
on foreign technical assistance Agricul-
ture, including fishing and forestry, 1s the
leading sector of the economy It contrib-
utes about 40% to GDP, employs 80% of
the labor force, and provides most of the
exports The country 1s not self-sufficient
in food production, and rice, the main sta-
ple, accounts for 90% of imports During
the period 1982-86 the industrial sector
grew at an annual average rate of 5 3%,
but its contribution to GDP was less than
4% 1n 1986 Despite major investment in
the tourist industry, which accounts for
about 25% of GDP, growth has stagnated
since 1983
GDP: $207 million, per capita $475, real
growth rate 0 1% (1988 est )
Inflation rate (consumer prices): 8 3%
(1986)
Unemployment rate: over 16% (1988 est )
Budget: revenues $75 2 million, expendi-
tures $77 9 million, including capital ex-
penditures of $4 8 million (1988 est )
Exports: $12 million (f 0b , 1987), com-
modities—vanulla, cloves, perfume oil, co-
pra, partners—US 53%, France 41%, Af-
rica 4%, FRG 2%
Imports: $52 million (cif , 1987), com-
modities—rice and other foodstuffs, ce-
ment, petroleum products, consumer
goods, partners—Europe 62% (France
22%, other 40%), Africa 5%, Pakistan,
Overview: no economic activity
95
Approved for Release: 2020/08/12 C06554432
Europa Island (continued)
Overview: One of Africa’s poorest coun-
tries, with a per capita GDP of little more
than $100, Mozambique has failed to ex-
ploit the economic potential of its sizable
agricultural, hydropower, and transporta-
tion resources Indeed, national output,
consumption, and investment declined
throughout the first half of the 1980s be-
cause of internal disorders, lack of govern-
ment administrative control, and a grow-
ing foreign debt A sharp increase in
foreign aid, attracted by an economic re-
form policy, has resulted in successive
years of economic growth since 1985 Ag-
ricultural output, nevertheless, is only at
about 75% of its 1981 level, and grain has
to be imported Industry operates at only
20-40% of capacity The economy depends
heavily on foreign assistance to keep
afloat
GDP: $1 6 billion, per capita less than
$110, real growth rate 5 0% (1988)
Inflation rate (consumer prices): 81 1%
(1988)
Unemployment rate: 40 0 (1988)
Budget: revenues $186 million, expendi-
tures $239 million, including capital ex-
penditures of $208 million (1988 est )
Exports: $100 million (fob, 1988), com-
modities—shrimp 48%, cashews 21%,
sugar 10%, copra 3%, citrus 3%,
partners—US, Western Europe, GDR,','f238420d57388e45e354e39f184540581625f7325ccc99335a630f6ce7f4cc66','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('150dcf4f61c23f1ec1986b990c2fd88419bc7e03bccf7e57f508d16b330cef0f',1990,'BE','Belgium','economy',96,'Overview: This small private-enterprise
economy has capitalized on its central
geographic location, highly developed
transport network, and diversified indus-
trial and commercial base Industry 1s
concentrated mainly in the populous
Flemish area 1n the north, although the
government 1s encouraging reinvestment
in the southern region of Walloon With
few natural resources Belgium must 1m-
port essential raw materials, making its
economy closely dependent on the state of
world markets In 1988 over 70% of trade
was with other EC countries During the
period 1986-88 the economy profited from
falling oil prices and a lower dollar, which
helped to improve the terms of trade Real
GDP grew by an average of 3 5% in 1986-
89, up from 1 5% 1n 1985 However, a
large budget deficit and 10% unemploy-
ment cast a shadow on the economy
GDP: $136 0 billion, per capita $13,700,
real growth rate 4 5% (1989 est )
Inflation rate (consumer prices): 3 6%
(1989 est )
Unemployment rate: 9 7% est (1989 est )
Budget: revenues $45 0 billion, expendi-
tures $55 3 billion, including capital ex-
penditures of NA (1989)
Exports: $100 3 billion (fob, 1989)
Belgium-Luxembourg Economic Union,
commodities—iron and steel, transporta-
tion equipment, tractors, diamonds, petro-
leum products, partners—EC 74%, US
5%, Communist countries 2% (1988)
Imports: $100 1 billion (cif, 1989)
Belgium-Luxembourg Economic Union,
commodities—fuels, grains, chemicals,
foodstuffs, partners—EC 72%, US 5%,
oil-exporting less developed countries 4%,
Communist countries 3% (1988)
External debt: $27 5 billion (1988)
Industrial production: growth rate 6 4%
(1988)
Electricity: 17,325,000 kW capacity,
62,780 million kWh produced, 6,350 kWh
per capita (1989)
Industries: engineering and metal prod-
ucts, processed food and beverages, chemi-
cals, basic metals, textiles, glass, petro-
leum, coal
Agriculture: accounts for 2% of GDP, em-
phasis on livestock production—beef, veal,
pork, milk, major crops are sugar beets,
fresh vegetables, fruits, grain, and
tobacco, net importer of farm products
Aid: donor—ODA and OOF commitments
(1970-87), $4 3 billion
Currency: Belgian franc (plural—francs), 1
Belgian franc (BF) = 100 centimes
Exchange rates: Belgian francs (BF) per
US$1—35 468 (January 1990), 39 404
(1989), 36 768 (1988), 37 334 (1987),
44 672 (1986), 59 378 (1985)
Fiscal year: calendar year','2e2fd81a194db6950ad2960a0c1ffbd21655200e34cc85e015673a643a4e9b45','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c59727f8e98e63300fec2809a80a4bf50e16584082adf623a591730c227e5b7d',1990,'BZ','Belize','economy',101,'Overview: The economy 1s based primarily
on agriculture and merchandising Agnri-
culture accounts for more than 30% of
GDP and provides 75% of export earnings,
while sugar, the chief crop, accounts for
almost 40% of hard currency earnings
The US, Belize’s main trading partner, 1s
assisting in efforts to reduce dependency
on sugar with an agricultural diversifica-
tion program In 1987 the drop in income
from sugar sales to the US because of
quota reductions was almost totally offset
by higher world prices for sugar
GDP: $225 6 million, per capita $1,285,
real growth rate 6% (1989 est )
Inflation rate (consumer prices): | 5%
(1988)
Unemployment rate: 14% (1988 est )
Budget: revenues $94 6 million, expendi-
tures $74 3 million, including capital ex-
penditures of $33 9 million (1988 est )
Exports: $120 million (fo b , 1988), com-
moditres—sugar, clothing, seafood, molas-
ses, citrus, wood and wood products, part-
ners—US 47%, UK, Trinidad and
Tobago, Canada (1987)
Imports: $176 million (cif , 1988), com-
modities—machinery and transportation
equipment, food, manufactured goods, fu-
els, chemicals, pharmaceuticals,
partners—US 55%, UK, Netherlands
Antilles, Mexico (1987)
External debt: $140 million (December
1988)
Industrial production: growth rate 6%
(1988)
Electricity: 34,000 kW capacity, 88 mil-
lion kWh produced, 500 kWh per capita
(1989)
Industries: sugar refining, clothing, timber
and forest products, furniture, rum, soap,
beverages, cigarettes, tourism
Agriculture: accounts for 30% of GDP (in-
cluding fish and forestry), commercial
crops include sugarcane, bananas, coca,
citrus fruits, expanding output of lumber
and cultured shrimp, net importer of basic
foods
Hlicit drugs: an illicit producer of cannabis
for the international drug trade, eradica-
tion program cut maryuana production
from 200 metric tons in 1987 to 66 metric
tons in 1989, transshipment point for co-
caine
Aid: US commitments, including Ex-Im
(FY 70-88), $94 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $194 million
Currency: Belizean dollar (plural—dol-
lars), 1 Belizean dollar (Bz$) = 100 cents
Exchange rates: Belizean dollars (Bz$) per
US$1—2 00 (fixed rate)
Fiscal year: 1 April-31 March','0dd747e8646e31812bb572361b5e3e7b5e591eaec89c0f00c9cb336873c1e746','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183666c0e178ab9cf271724fa125920723477340dd60184494852cb7d71b332d',1990,'BJ','Benin','economy',106,'Overview: Benin is one of the least devel-
oped countries in the world because of
limited natural resources and a poorly de-
veloped infrastructure Agriculture ac-
counts for almost 45% of GDP, employs
about 60% of the labor force, and gener-
ates a major share of foreign exchange
earnings The industrial sector contributes
only about 15% to GDP and employs 2%
of the work force. Persistently low prices
in recent years have limited hard currency
earnings from Benin’s major exports of
agricultural products and crude oil
GDP: $1.7 billion, per capita $335, real
growth rate 1 8% (1988)
Inflation rate (consumer prices): 4 3%
(1988)
Unemployment: NA
Budget: revenues $168 million, expend:-
tures $317 million, including capital ex-
penditures of $97 million (1989)
Exports: $226 million (fo b , 1988), com-
modities—crude oil, cotton, palm prod-
ucts, cocoa, partners—FRG 36%, France
16%, Spain 14%, Italy 8%, UK 7%
Imports: $413 million (fob, 1988); com-
modities—foodstuffs, beverages, tobacco,
petroleum products, intermediate goods,
capital goods, light consumer goods, part-
ners—France 34%, Netherlands 10%, Ja-
pan 7%, Italy 6%, US 5%
External debt: $1 0 billion (December
1989 est.)
Industrial production: growth rate —0.7%
(1988)
Electricity: 28,000 kW capacity, 24 mil-
lion kWh produced, 5 kWh per capita
(1989)
Industries: palm o1] and palm kernel oil
processing, textiles, beverages, petroleum
32
Approved for Release: 2020/08/12 C06554432
Agriculture: small farms produce 90% of
agricultural output, production is domi-
nated by food crops—corn, sorghum, cas-
sava, beans, and rice; cash crops include
cotton, palm oil, and peanuts, poultry and
livestock output has not kept up with con-
sumption
Aid: US commitments, including Ex-Im
(FY70-88), $41 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 0 billion, OPEC
bilateral aid (1979-89), $19 million, Com-
munist countries (1970-88), $101 million
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346.30
(1986), 449 26 (1985)
Fiscal year: calendar year
Overview: In 1989, despite rising oil prices,
the economic performance failed to meet
government expectations because of higher
inflationary pressures fueled by a rela-
tively poor agricultural performance Ag-
ricultural production was up only 4% fol-
lowing a 10% decline in 1988, and
manufacturing remained below the 1985
level with only a 6% increase The govern-
ment 1s continuing an economic adyust-
ment program to reduce Nigeria’s depen-
dence on oil and to help create a basis for
sustainable noninflationary growth
GNP: $30 0 billion, per capita $270, real
growth rate 4% (1989)
Inflation rate (consumer prices): 47 5%
(1989)
Unemployment rate: 7 5% (1988 est )
Budget: revenues $6.5 billion, expenditures
$7 4 billion, including capital expenditures
of $1 9 billion (1988 est )
Exports: $8 4 billion (fo b , 1989 est ),
commodities—oil 95%, cocoa, palm ker-
nels, rubber, partners—EC 51%, US 32%
Imports: $5 7 billion (cif, 1989 est ),
commodities—consumer goods, capital
equipment, chemicals, raw materials, part-
ners—EC, US
External debt: $32 billion, medium and
long-term (December 1989 est )
Industrial production: growth rate 5%
(1987 est )
Electricity: 4,737,000 kW capacity,
11,270 million kWh produced, 100 kWh
per capita (1989)
Industries: mining—crude oil, natural gas,
coal, tin, columbite, primary processing
industries—palm oil, peanut, cotton, rub-
ber, petroleum, wood, hides and skins,
manufacturing industries—textiles, ce-
ment, building materials, food products,
footwear, chemical, printing, ceramics,
steel
Agriculture: accounts for 28% of GNP
and half of labor force; inefficient small-
scale farming dominates, once a large net
exporter of food and now an importer,
cash crops—cocoa, peanuts, palm oil, rub-
ber, food crops—corn, rice, sorghum, mil-
let, cassava, yams, livestock—cattle,
sheep, goats, pigs, fishing and forestry re-
sources extensively exploited
Illicit drugs: illicit heroin and some co-
caine trafficking, marijuana cultivation for
domestic consumption and export, major
transit country for heroin en route from
Southwest Asia via Africa to Western Eu-
rope and the US, growing transit route for
cocaine from South America via West
Africa to Western Europe and the US
Aid: US commitments, including Ex-Im
(FY70-88), $662 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 9 billion,
Communist countries (1970-88), $2 2 bil-
lion
Currency: naira (plural—naira), 1 naira
(SN) = 100 kobo
Exchange rates: naira (M) per US$1—
7 6221 (December 1989), 7 3647 (1989),
4 5370 (1988), 4 0160 (1987), 1 7545
(1986), 0.8938 (1985)
Fiscal year: calendar year','5f63e43911b044af06bfeb1d9eff8832268a4666734c4043c2789cc7a5a44e72','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ed4d5cffb0413bde5dc8234ec02f3e12089be1ef00f30c8155bf71bace56e7e',1990,'BM','Bermuda','economy',111,'Overview: Bermuda enjoys one of the
highest per capita incomes 1n the world,
having successfully exploited its location
by providing luxury tourist facilities and
financial services The tourist industry at-
tracts more than 90% of its business from
North America The tndustrial sector is
small, and agriculture 1s severely limited
by a lack of suitable land About 80% of
food needs are imported
GDP: $1 3 billion, per capita $23,000, real
growth rate 2 0% (1989 est )
Inflation rate (consumer prices): 4 8%
(1988)
Unemployment: 2 0% (1988)
Budget: revenues $280 million, expendi-
tures $279 million, including capital ex-
penditures of $34 million (FY89 est )
Exports: $23 million (f 0 b ,1985), com-
modities—semutropical produce, light
manufactures, partners—US 25%, Italy
25%, UK 14%, Canada 5%, other 31%
Imports: $402 million (c.1 f , 1985), com-
modities—fuel, foodstuffs, machinery,
partners—US 58%, Netherlands Antilles
9%, UK 8%, Canada 6%, Japan 5%, other
14%
External debt: NA
Industrial production: growth rate NA%
Electricity: 134,000 kW capacity, 446 mil-
lion kWh produced, 7,680 kWh per capita
(1989)
Industries: tourism, finance, structural
concrete products, paints, pharmaceuti-
cals, ship repairing
Agriculture: accounts for less than 1% of
GDP, most basic foods must be imported,
produces bananas, vegetables, citrus fruits,
flowers, dairy products
Aid: US commitments, including Ex-Im
(FY70-81), $34 million; Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $267 million
Currency: Bermudian dollar (plural—dol-
lars); 1 Bermudian dollar (Bd$) = 100
cents
Exchange rates: Bermudian dollar (Bd$)
per US$1—1 0000 (fixed rate)
Fiscal year: | April-31 March','66613d6569057b5d779378ea01879d0bd2e587e0ba976913f03c5447548f2a3b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38ba331fd8ee4c34818763d73083734e97f334cbc3dd7a6b2eaf5925e3609641',1990,'BT','Bhutan','economy',116,'Overview: The economy 1s based on agri-
culture and forestry, which provide the
main livelihood for 90% of the population
and account for about 50% of GDP One
of the world’s least developed countries,
rugged mountains dominate and make the
building of roads and other infrastructure
difficult and expensive Bhutan’s hydro-
power potential and its attraction for tour-
ists are 1ts most important natural
resources
GDP: $273 million, per capita $199, real
growth rate 6 3% (1988 est )
Inflation rate (consumer prices): 10% (1989
est )
Unemployment: NA
Budget: revenues $99 million, expenditures
$128 million, including capital expendi-
tures of $65 million (FY89 est )
Exports: $70 9 million (f 0 b , FY89), com-
modities—cardamon, gypsum, timber,
handicrafts, cement, fruit, partners—tIndia
93%
Imports: $138 3 million (cif, FY89 est ),
commodities—fuel and lubricants, grain,
machinery and parts, vehicles, fabrics,
partners—india 67%
External debt: $70 1 million (FY89 est )
Industrial production: growth rate
—12 4% (1988 est )
Electricity: 353,000 kW capacity, 2,000
mullion kWh produced, 1,300 kWh per
capita (1989)
Industries: cement, chemical products,
mining, distilling, food processing, handi-
crafts
Agriculture: accounts for 50% of GDP,
based on subsistence farming and animal
husbandry, self-sufficient in food except
for foodgrains, other production—rice,
corn, root crops, citrus fruit, dairy, and
eggs
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $85 8 million, OPEC bilateral aid
(1979-89), $11 mullion
Currency: ngultrum (plural—ngultrum), 1
ngultrum (Nu) = 100 chetrum, note—
Indian currency 1s also legal tender
Exchange rates: ngultrum (Nu) per
US$1—16 965 (January 1990), 16 226
(1989), 13 917 (1988), 12 962 (1987),
12 611 (1986), 12 369 (1985), note—the
Bhutanese ngultrum is at par with the
Indian rupee
Fiscal year: | July-30 June
Overview: The Bolivian economy steadily
deteriorated between 1980 and 1985 as La
Paz financed growing budget deficits by
expanding the money supply and inflation
sptraled—peaking at 11,700% An austere
orthodox economic program adopted by
newly elected President Paz Estenssoro in
1985, however, succeeded 1n reducing in-
flation to between 10% and 20% annually
during 1987 and 1989, eventually restart-
36
Approved for Release: 2020/08/12 C06554432
ing economic growth President Paz Za-
mora has pledged to retain the economic
policies of the previous government 1n or-
der to keep inflation down and continue
the growth begun under his predecessor
Nevertheless, Bolivia continues to be one
of the poorest countries in Latin America,
and it remains vulnerable to price fluctua-
tions for its limited exports—mainly min-
erals and natural gas Moreover, for many
farmers, who constitute half of the
country’s work force, the main cash crop
1s coca, which 1s sold for cocaine process-
ing
GNP: $4 6 billion, per capita $660, real
growth rate 2 8% (1988)
Inflation rate (consumer prices): 15 5%
(1989)
Unemployment rate: 20 7% (1988)
Budget: revenues $2,867 million, expendi-
tures $2,867 million, including capital ex-
penditures of $663 million (1987)
Exports: $634 million (f 0 b , 1989), com-
modities—metals 45%, natural gas 32%,
coffee, soybeans, sugar, cotton, timber,
and illicit drugs, partners—US 23%, Ar-
gentina
Imports: $786 million (cif , 1989), com-
modities—food, petroleum, consumer
goods, capital goods, partners—US 15%
External debt: $5 7 billion (December
1989)
Industrial production: growth rate 8 1%
(1987)
Electricity: 817,000 kW capacity, 1,728
million kWh produced, 260 kWh per cap-
ita (1989)
Industries: mining, smelting, petroleum,
food and beverage, tobacco, handicrafts,
clothing, illicit drug industry reportedly
produces the largest revenues
Agriculture: accounts for 20% of GDP (in-
cluding forestry and fisheries), principal
commodities—coffee, coca, cotton, corn,
sugarcane, rice, potatoes, timber,
self-sufficient in food
Illicit drugs: world’s second-largest pro-
ducer of coca (after Peru) with an esti-
mated 54,000 hectares under cultivation,
government considers all but 12,000 hect-
ares illicit and subject to eradication, in-
termediate coca products and cocaine ex-
ported to or through Colombia and Brazil
to the US and other international drug
markets
Aid: US commitments, including Ex-Im
(FY70-88), $909 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1.4 billion,
Communist countries (1970-88), $340 mil-
lion
Currency: boliviano (plural—bolivianos), 1
boliviano ($B) = 100 centavos
Approved for Release: 2020/08/12 C06554432
Exchange rates: bolivianos ($B) per
US$1—2 6917 (1989), 2 3502 (1988),
2 0549 (1987), 1 9220 (1986), 0 4400
(1985)
Fiscal year: calendar year','36a00727da0eca749bff24b9f7eb9c0363e222bb0e45c0fbb7bb812097048023','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dac83b2323b1036ebfc75977d54bcaca94e8210391952d6ebe10f9ded1fb609',1990,'ZA','South Africa','economy',122,'Overview: The economy has historically
been based on cattle raising and crops
Agriculture today provides a livelihood for
over 80% of the population, but produces
only about 50% of food needs and contrib-
utes a small 5% to GDP The driving
force behind the rapid economic growth of
the 1970s and 1980s has been the mining
industry This sector, mostly on the
strength of diamonds, has gone from gen-
erating 25% of GDP in 1980 to over 50%
in 1988 No other sector has experienced
such growth, especially not that of the
agricultural sector, which 1s plagued by
erratic rainfall and poor soils The unem-
ployment rate remains a problem at 25%
A scarce resource base limits diversifica-
tion into labor-intensive industries
GDP: $1 87 billion, per capita $1,600, real
growth rate 8 4% (FY88)
Inflation rate (consumer prices): 11 45%
(1989)
Unemployment rate: 25% (1987)
Budget: revenues $1,235 million, expendi-
tures $1,080 million, including capital ex-
penditures of NA (FY90 est )
Exports: $1 3 billion (fo b , 1988), com-
modities—diamonds 88%, copper and
nickel 5%, meat 4%, cattle, animal prod-
ucts, partners—Switzerland, US, UK,
other EC-associated members of Southern
African Customs Union
Imports: $1 1 billion (c1f , 1988), com-
modities—foodstuffs, vehicles, textiles,
petroleum products,
37
Approved for Release: 2020/08/12 C06554432
Botswana (continued)
partners—Switzerland, US, UK, other
EC-associated members of Southern Afri-
can Customs Union
External debt: $700 million (December
1989 est )
Industrial production: growth rate 16 8%
(FY86)
Electricity: 217,000 kW capacity, 630 mil-
lion kWh produced, 510 kWh per capita
(1989)
Industries: livestock processing, mining of
diamonds, copper, nickel, coal, salt, soda
ash, potash, tourism
Agriculture: accounts for only 5% of GDP,
subsistence farming predominates, cattle
raising supports 50% of the population,
must import large share of food needs
Aid: US commitments, including Ex-Im
(FY70-88), $242 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 6 billion,
OPEC bilateral aid (1979-89), $43 million,
Communist countries (1970-88), $24 mil-
hon
Currency: pula (plural—pula), 1 pula (P)
= 100 thebe
Exchange rates: pula (P) per US$1—
1 8734 (January 1990), 2 0125 (1989),
1 8159 (1988), 1 6779 (1987), 1 8678
(1986), 1 8882 (1985)
Fiscal year: 1 April-31 March
Overview: Many of the white one-seventh
of the South African population enjoy 1n-
comes, material comforts, and health and
educational standards equal to those of
Western Europe In contrast, most of the
remaining population suffers from the pov-
erty patterns of the Third World, includ-
ing unemployment, lack of job skills, and
barriers to movement into higher-paying
fields Inputs and outputs thus do not
move smoothly into the most productive
employments, and the effectiveness of the
market 1s further lowered by international
constraints on dealings with South Africa
The main strength of the economy lies in
its rich mineral resources, which provide
two-thirds of exports Average growth of
2% in output in recent years falls far short
of the level needed to cut into the high
unemployment level
GDP: $83 5 billion, per capita $2,380, real
growth rate 3 2% (1988)
Approved for Release: 2020/08/12 C06554432
Inflation rate (consumer prices): 14 67%
(1989)
Unemployment rate: 22% (1988), blacks
25-30%, up to 50% in homelands (1988
est )
Budget: revenues $24 3 billion, expendi-
tures $27 3 billion, including capital ex-
penditures of $NA billion (FY91)
Exports: $21 5 billion (fo b , 1988 est ),
commodities—gold 40%, minerals and
metals 23%, food 6%, chemicals 3%, part-
ners—FRG, Japan, UK, US, other EC,','a822ea232ab4c9c06c756f7f212a45f6580422d488af95c247fba5b10e964c8e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78611f26a4ef8defea6470926913fae811a7172a94d17ca7b3b96a37b07f497b',1990,'MU','Mauritius','economy',135,'Overview: All economic activity 1s concen-
trated on the largest island of Diego Gar-
cia, where joint UK-US defense facilities
are located Construction projects and var-
1ous services needed to support the mili-
tary installations are done by military and
contract employees from the UK and US
There are no industrial or agricultural
activities on the islands
Electricity: provided by the US military
Overview: The economy 1s highly depen-
dent on the tourist industry, which gener-
ates about 21% of the national income In
1985 the government offered offshore reg-
istration to companies wishing to incorpo-
rate in the islands, and, in consequence,
41
Approved for Release: 2020/08/12 C06554432
British Virgin Islands (continued)
incorporation fees generated about $2 mil-
lion in 1987 Livestock raising 1s the most
significant agricultural activity The 1s-
lands’ crops, limited by poor soils, are un-
able to meet food requirements
GDP: $106 7 million, per capita $8,900,
real growth rate 2 5% (1987)
Inflation rate (consumer prices): 1 7% (Jan-
uary 1987)
Unemployment rate: NA%
Budget: revenues $26 2 million, expendi-
tures $25 4 million, including capital ex-
penditures of $NA (1988 est )
Exports: $2 3 million (fob, 1985), com-
modities—rum, fresh fish, gravel, sand,
fruits, animals, partners—Virgin Islands
(US), Puerto Rico, US
Imports: $72 0 million (c1f , 1985), com-
modities—building materials, automo-
biles, foodstuffs, machinery, partners—
Virgin Islands (US), Puerto Rico, US
External debt: $4 5 million (1985)
Industrial production: growth rate —4 0%
(1985)
Electricity: 13,500 kW capacity, 59 mil-
lion kWh produced, 4,870 kWh per capita
(1989)
Industries: tourism, light industry, con-
struction, rum, concrete block, offshore
financial center
Agriculture: livestock (including poultry),
fish, fruit, vegetables
Aid: NA
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: 1 April-31 March
Overview: The economy 1s based on sugar,
manufacturing (mainly textiles), and tour-
ism Despite significant expansion in other
sectors over the past decade, sugarcane
remains dominant and 1s grown on about
90% of the cultivated land area, account-
ing for 40% of export earnings The gov-
ernment’s development strategy 1s cen-
tered on industrialization (with a view to
exports), agricultural diversification, and
tourism Economic performance in 1988
was impressive, with 6 3% real growth
rate and low unemployment
GDP: $1 9 billion, per capita $1,910, real
growth rate 6 3% (1988)
Inflation rate (consumer prices): 9 2%
(1988)
Unemployment rate: 3 6% (1988)
Budget: revenues $351 million, expendi-
tures $414 million, including capital ex-
penditures of $76 million (FY87 est )
Exports: $1 0 billion (fo b, 1988), com-
modities—textiles 44%, sugar 40%, light
manufactures 10%, partners—EC and US
have preferential treatment, EC 77%, US
15%
Imports: $1 3 billion (cif, 1988), com-
modities—manufactured goods 50%, capi-
tal equipment 17%, foodstuffs 13%, petro-
leum products 8%, chemicals 7%,
partners—EC, US, South Africa, Japan
External debt: $670 million (December
1989)
Industrial production: growth rate 12 9%
(FY87)
Electricity: 233,000 kW capacity, 420 mil-
lion kWh produced, 375 kWh per capita
(1989)
Industries: food processing (largely sugar
milling), textiles, wearing apparel, chemi-
cal and chemical products, metal prod-
ucts, transport equipment, nonelectrical
machinery, tourism
Agriculture: accounts for 14% of GDP,
about 90% of cultivated land in sugar-
cane, other products—tea, corn, potatoes,
bananas, pulses, cattle, goats, fish, net
food importer, especially rice and fish
Illicit drugs: illicit producer of cannabis
for the international! drug trade
Aid: US commitments, including Ex-Im
(FY70-88), $72 million, Western (non-US)
countries (1970-87), $538 million, Com-
munist countries (1970-88), $54 million
Currency: Mauritian rupee (plural—
rupees), | Mauritian rupee (MauR) = 100
cents
Exchange rates: Mauritian rupees
(MauRs) per US$1—15 033 (January
1990), 15 250 (1989), 13 438 (1988),
12 878 (1987), 13 466 (1986), 15 442
(1985)
Fiscal year: 1 July-30 June','13a9c5f82b7a4043fd14a168d05b42092f67357e6ab8f7835458e2abfd93c2ce','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d2434c735a28122ab2c3cb7e18de5bb09ee2131b33f5dd6fde10f22c30cf6d3',1990,'MY','Malaysia','economy',139,'Overview: The economy 1s a mixture of
foreign and domestic entrepreneurship,
government regulation and welfare mea-
sures, and village tradition It 1s almost
totally supported by exports of crude oil
and natural gas, with revenues from the
petroleum sector accounting for more than
710% of GDP Per capita GDP of $9,600 1s
among the highest in the Third World,
and substantial income from overseas 1n-
vestment supplements domestic produc-
tion The government provides for all
medical services and subsidizes food and
housing
GDP: $3 3 billion, per capita $9,600, real
growth rate 2 5% (1989 est )
Inflation rate (consumer prices): 2 5%
(1989 est )
Unemployment: 2 5%, shortage of skilled
labor (1989 est )
Budget: revenues $1 2 billion (1987); ex-
penditures $1 6 billion, including capital
expenditures of NA (1989 est )
Exports: $2 07 billion (fo b , 1987), com-
modtities—crude oil, liquefied natural gas,
petroleum products, partners—Japan 55%
(1986)
Imports: $800 million (c1f , 1987), com-
modities—machinery and transport equip-
ment, manufactured goods, food, bever-
ages, tobacco, consumer goods, partners—
Singapore 31%, US 20%, Japan 6% (1986)
External debt: none
Industrial production: growth rate NA%
Electricity: 310,000 kW capacity, 890 mil-
hon kWh produced, 2,580 kWh per capita
(1989)
Industries: petroleum, hquefied natural
gas, construction
Agriculture: imports about 80% of its food
needs, principal crops and livestock 1n-
clude rice, cassava, bananas, buffaloes,
and pigs
Aid: US commitments, including Ex-Im
(FY70-87), $20 6 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $143 7 million
Currency: Bruneian dollar (plural—dol-
lars), 1 Bruneian dollar (B$) = 100 cents
Exchange rates: Bruneian dollars (BS) per
US$1—1.8895 (January 1990), 1 9503
(1989), 2 0124 (1988), 2 1060 (1987),
Approved for Release: 2020/08/12 C06554432
2 1774 (1986), 2 2002 (1985), note—the
Bruneian dollar 1s at par with the Singa-
pore dollar
Fiscal year: calendar year
Overview: In 1988-89 booming exports
helped Malaysia continue to recover from
the severe 1985-86 recession Real output
grew by 8 7% in 1988 and about 7 7% in
1989, helped by vigorous growth in manu-
facturing output and further increases in
foreign direct investment, particularly
from Japanese and Taiwanese firms facing
higher costs at home Malaysia has be-
come the world’s third-largest producer of
semiconductor devices (after the US and
Japan) and the world’s largest exporter of
semiconductor devices Inflation remained
low as unemployment stood at about 8%
of the labor force and as the government
followed prudent fiscal/monetary policies
The country 1s not self-sufficient in food,
and a majority of the rural population
subsists at the poverty level Malaysia’s
Approved for Release: 2020/08/12 C06554432
high export dependence (merchandise ex-
ports are 63% of GDP) leaves 1t vulnera-
ble to a recession in the OECD countries
or a fall in world commodity prices
GDP: $37 9 billion, per capita $2,270, real
growth rate 7 7% (1989 est )
Inflation rate (consumer prices): 3 6%
(1989 est )
Unemployment rate: 7 9% (1989 est )
Budget: revenues $8 8 billion, expenditures
$11 2 billion, including capital expendi-
tures of $2 5 billion (1989 est )
Exports: $24 billion (fo b , 1989 est ),
commodities—natural rubber, palm oil,
tin, timber, petroleum, electronics, light
manufactures, partners—Singapore, Ja-
pan, USSR, EC, Australia, US
Imports: $20 billion (fob, 1989 est ),
commodities—food, crude oil, consumer
goods, intermediate goods, capital equip-
ment, chemicals, partners—Japan, Singa-
pore, FRG, UK, Thailand, China, Austra-
ha, US
External debt: $16 3 billion (1989 est )
Industrial production: growth rate 13 6%
(1988)
Electricity: 5,600,000 kW capacity,
16,500 million kWh produced, 990 kWh
per capita (1989)
Industries: Peninsular Malaysia—rubber
and oil palm processing and manufactur-
ing, light manufacturing industry, elec-
tronics, tin mining and smelting, logging
and processing timber; Sabah—logging,
petroleum production, Sarawak—agricul-
ture processing, petroleum production and
refining, logging
Agriculture: Peninsular Malaysia—natural
rubber, palm oil, rice, Sabah—mainly
subsistence, main crops—rubber, timber,
coconut, rice, Sarawak—main crops—
rubber, timber, pepper, there 1s a deficit of
rice in all areas, fish catch of 608,000
metric tons in 1987
Aid: US commitments, including Ex-Im
(FY70-84), $170 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $3 8 billion,
OPEC bilateral aid (1979-89), $42 million
Currency: ringgit (plural—ringgits), 1
ringgit (M$) = 100 sen
Exchange rates: ringgits (M$) per US$1—
2 7038 (January 1990), 2 7087 (1989),
2 6188 (1988), 2 5196 (1987), 2 5814
(1986), 2 4830 (1985)
Fiscal year: calendar year','5331a45a72dc1ce281921a402f3f338fab78951cdaa0b620e62c483ddde87a74','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('242cc37852c523aca8eb0a8921b157c5899ee4b796cbfec28edec78e4ef4cdd2',1990,'BG','Bulgaria','economy',145,'Overview: Growth in the sluggish Bulgar-
1an economy fell to the 2% annual level in
the 1980s, and by 1989 Sofia’s foreign
debt had skyrocketed to $10 billion—giv
ing a debt service ratio of more than 40%
of hard currency earnings The
post-Zhivkov regime faces major problems
of renovating an aging industrial plant,
keeping abreast of rapidly unfolding tech-
nological developments, investing 1n addi-
tional energy capacity (the portion of elec-
tric power from nuclear energy reached
37% in 1988), and motivating workers, in
part by giving them a share tn the earn-
ings of their enterprises A major decree
of January 1989 summarized and
extended the government’s economic re-
structuring efforts, which include a parttal
decentralization of controls over produc-
tion decisions and foreign trade The new
regime promises more extensive reforms
and eventually a market economy But the
ruling group cannot (so far) bring itself to
give up ultimate control over economic
affairs exercised through the vertical Party/
ministerial command structure Reforms
have not led to improved economic perfor-
mance, in particular the provision of more
and better consumer goods A further
blow to the economy was the exodus of
310,000 ethnic Turks in mid-1989, which
caused temporary shortages of skilled la-
bor in glassware, aluminum, and other
industrial plants and in tobacco fields
GNP: $51 2 billion, per capita $5,710, real
growth rate -0 1% (1989 est )
Inflation rate (consumer prices): 12%
(1989)
Unemployment rate: NA%
Budget: revenues $26 billion, expenditures
$28 billion, including capital expenditures
of $NA billion (1988)
Exports: $20 3 billion (fo b , 1988), com-
modities—machinery and equipment
60 5%, agricultural products 14 7%, man-
ufactured consumer goods 10 6%, fuels,
minerals, raw materials, and metals 8 5%,
other 5 7%, partners—Socialist countries
82 5% (USSR 61%, GDR 5 5%, Czecho-
slovakia 4 9%), developed countries 6 8%
(FRG | 2%, Greece 1 0%), less developed
countries 10 7% (Libya 3 5%, Iraq 2 9%)
Imports: $21 0 billion (fo b , 1988), com-
modities—fuels, minerals, and raw mate-
rials 45 2%, machinery and equipment
39 8%, manufactured consumer goods
4 6%, agricultural products 3 8%, other
6 6%, partners—Socialist countries 80 5%
(USSR 57 5%, GDR 5 7%), developed
countries 15 1% (FRG 4 8%, Austnia
1 6%), less developed countries 4 4%
(Libya 1 0%, Brazil 0 9%)
External debt: $10 billion (1989)
Industrial production: growth rate 0 9%
(1988)
Electricity: 11,500,000 kW capacity,
45,000 million kWh produced, 5,000 kWh
per capita (1989)
Industries: food processing, machine and
metal building, electronics, chemicals
Agriculture: accounts for 15% of GNP,
climate and soil conditions support live-
stock raising and the growing of various
grain crops, oilseeds, vegetables, fruits and
tobacco, more than one-third of the arable
land devoted to grain, world’s
fourth-largest tobacco exporter, surplus
food producer
Aid: donor—$1 6 billion in bilateral aid to
non-Communist less developed countries
(1956-88)
Currency: lev (plural—leva), 1 lev (Lv) =
100 stotinki
Exchange rates: leva (Lv) per US$1—0 84
(1989), 0 82 (1988), 0 90 (1987), 0 95
(1986), 1 03 (1985)
Fiscal year: calendar year
Overview: One of the poorest countries in
the world, Burkina has a high population
density, few natural resources, and rela-
tively infertile soil Economic development
1s hindered by a poor communications net-
work within a landlocked country Agri-
culture provides about 40% of GDP and 1s
entirely of a subsistence nature Industry,
dominated by unprofitable government-
controlled corporations, accounted for 13%
of GDP in 1985
GDP: $1 43 billion, per capita $170, real
growth rate 7 7% (1988)
Inflation rate (consumer prices): 4 3%
(1988)
Unemployment rate: NA%
Budget: revenues $422 million, expendi-
tures $516 million, including capital ex-
penditures of $25 million (1987)
Exports: $249 million (f.0 b , 1988), com-
modities—oilseeds, cotton, live animals,
gold, partners—EC 42% (France 30%,
other 12%), Taiwan 17%, Ivory Coast 15%
(1985)
Imports: $591 million (f 0 b , 1988), com-
modities—grain, dairy products, petro-
Approved for Release: 2020/08/12 C06554432
leum, machinery, partners—EC 37%
(France 23%, other 14%), Africa 31%, US
15% (1985)
External debt: $969 million (December
1988)
Industrial production: growth rate 7 1%
(1985)
Electricity: 121,000 kW capacity, 320 mil-
lion kWh produced, 37 kWh per capita
(1989)
Industries: agricultural processing plants,
brewery, cement, and brick plants, a few
other small consumer goods enterprises
Agriculture: cash crops—peanuts, shea
nuts, sesame, cotton, food crops—
sorghum, mullet, corn, rice, livestock, not
self-sufficient in food grains
Aid: US commitments, including Ex-Im
(FY 70-88), $271 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 5 billion,
Communist countries (1970-88), $94 mil-
hon
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: CFA francs (CFAF) per
US$1—284 55 (January 1990), 319 01
(1989), 297 85 (1988), 300 54 (1987),
346 30 (1986), 449 26 (1985)
Fiscal year: calendar year
Overview: Burma 1s one of the poorest
countries in Asia, with a per capita GDP
of about $280 The government reports
negligible growth for FY88 The nation
has been unable to achieve any significant
improvement in export earnings because
of falling prices for many of 1ts major
commodity exports For rice, traditionally
the most important export, the drop in
world prices has been accompanied by
shrinking markets and a smaller volume
of sales In 1985 teak replaced rice as the
largest export and continues to hold this
position The economy 1s heavily depen-
dent on the agricultural sector, which gen-
erates about 40% of GDP and provides
employment for more than 65% of the
work force
GDP: $11 0 billion, per capita $280, real
growth rate 0 2% (FY88 est )
Inflation rate (consumer prices): 22 6%
(FY89 est )
Unemployment rate: 10 4% in urban areas
(FY87)
47
Approved for Release: 2020/08/12 C06554432
Burma (continued)
Budget: revenues $4 9 billion, expenditures
$5 0 billion, including capital expenditures
of $07 billion (FY89 est )
Exports: $311 mullion (fo b , FY88 est )
commodities—teak, rice, oilseed, metals,
rubber, gems, partners—Southeast Asia,
India, China, EC, Africa
Imports: $536 million (cif, FY88 est )
commodities—machinery, transport
equipment, chemicals, food products, part-
ners—Japan, EC, CEMA, China, South-
east Asia
External debt: $5 6 billion (December
1989 est )
Industrial production: growth rate —1 5%
(FY88)
Electricity: 950,000 kW capacity, 2,900
million kWh produced, 70 kWh per capita
(1989)
Industries: agricultural processing, textiles
and footwear, wood and wood products,
petroleum refining, mining of copper, tin,
tungsten, iron, construction materials,
pharmaceuticals, fertilizer
Agriculture: accounts for about 40% of
GDP (including fish and forestry), self-
sufficient in food, principal crops—paddy
rice, corn, oilseed, sugarcane, pulses,
world’s largest stand of hardwood trees,
rice and teak account for 55% of export
revenues, 1985 fish catch of 644 million
metric tons
Illicit drugs: world’s largest illicit producer
of opium poppy and minor producer of
cannabis for the international drug trade,
opium production ts on the increase as
growers respond to the collapse of
Rangoon’s antinarcotic programs
Aid: US commitments, including Ex-Im
(FY70-88), $158 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $3 8 billion,
Communist countries (1970-88), $424 mil-
lion
Currency: kyat (plural—kyats); 1 kyat (K)
= 100 pyas
Exchange rates: kyats (K) per US$1—
6 5188 (January 1990), 6 7049 (1989),
6 3945 (1988), 6 6535 (1987), 7 3304
(1986), 8 4749 (1985)
Fiscal year: 1 April-31 March','01730484704813166941f27711b324a40fd7a7a23aee6c585056b55e02b67277','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d746dba95a3992c6c1aedf3027e4fdb52318fdf69056d68010cf96a719de76c',1990,'BI','Burundi','economy',150,'Overview: A landlocked, resource-poor
country in an early stage of economic de-
velopment, Burundi 1s predominately agri-
cultural with only a few basic industries
Its economic health 1s dependent on the
coffee crop, which accounts for an average
90% of foreign exchange earnings each
year The ability to pay for imports there-
fore continues to rest largely on the vagar-
1es of the chmate and the international
coffee market
GDP: $1 3 billion, per capita $255, real
growth rate 2 8% (1988)
Inflation rate (consumer prices): 4 4%
(1988 est )
Unemployment rate: NA%
Budget: revenues $213 million, expendi-
tures $292 million, including capital ex-
penditures of $131 million (1988 est )
Exports: $128 mullion (fo b , 1988), com-
modities—coffee 88%, tea, hides and
skins, partners—EC 83%, US 5%, Asia
2%
Imports: $204 million (c1f , 1988), com-
modities—capital goods 31%, petroleum
products 15%, foodstuffs, consumer goods,
partners—EC 57%, Asia 23%, US 3%
External debt: $795 million (December
1989 est )
Industrial production: real growth rate
5 1% (1986)
Electricity: 51,000 kW capacity, 105 mil-
lon kWh produced, 19 kWh per capita
(1989)
Industries: light consumer goods such as
blankets, shoes, soap, assembly of imports,
public works construction, food processing
Agriculture: accounts for 60% of GDP;
90% of population dependent on subsis-
tence farming, marginally self-sufficient in
food production, cash crops—coffee, cot-
ton, tea, food crops—corn, sorghum, sweet
potatoes, bananas, mamioc, livestock—
meat, milk, hides, and skins
Aid: US commitments, including Ex-Im
(FY70-88), $68 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $10 billion, OPEC
bilateral aid (1979-89), $32 million, Com-
munist countries (1970-88), $175 million
Currency: Burundi franc (plural—francs),
1 Burundi franc (FBu) = 100 centimes
Exchange rates: Burundi francs (FBu) per
US$1—176 20 (January 1990), 158 67
(1989), 140 40 (1988), 123 56 (1987),
114 17 (1986), 120 69 (1985)
Fiscal year: calendar year','f7e8af96b1ada0b77b87dd316a4809f3f8a5e206a0a2bd6f19ea6411cee43ef8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40d0ed288193003a7fc78a0fc619a439ec0fbf02fb14c6636f566ab998c85029',1990,'TH','Thailand','economy',156,'Overview: Cambodia 1s a desperately poor
country whose economic development has
been stymied by deadly political
infighting The economy ts based on agri-
culture and related industries Over the
past decade Cambodia has been slowly
recovering from its near destruction by
war and political upheaval It still
remains, however, one of the world’s poor-
est countries, with an estimated per capita
GDP of about $130 The food situation 1s
precarious, during the 1980s famine has
been averted only through international
relief In 1986 the production level of rice,
the staple food crop, was able to meet
only 80% of domestic needs The biggest
success of the nation’s recovery program
has been in new rubber plantings and in
fishing Industry, other than rice process-
ing, 1s almost nonexistent Foreign trade is
primarily with the USSR and Vietnam
Statistical data on the economy continues
to be sparse and unreliable
GDP: $890 million, per capita $130, real
growth rate 0% (1989 est )
Unemployment rate: NA%
Budget: revenues $NA, expenditures $NA,
including capital expenditures of $NA
Inflation rate (consumer prices): NA%
Exports: $32 million (fo b , 1988), com-
modities—natural rubber, rice, pepper,
wood, partners—Vietnam, USSR, Eastern
Europe, Japan, India
Imports: $147 million (cif , 1988), com-
modities—internattonal food aid, fuels,
consumer goods, partners—Vietnam,
USSR, Eastern Europe, Japan, India
External debt: $600 million (1989)
Industrial production: growth rate NA%
Electricity: 126,000 kW capacity, 150 mil-
lion kWh produced, 21 kWh per capita
(1989)
Industries: rice milling, fishing, wood and
wood products, rubber, cement, gem min-
ing
Agriculture: mainly subsistence farming
except for rubber plantations, main
crops—rice, rubber, corn, food
shortages—rice, meat, vegetables, dairy
products, sugar, flour
Aid: US commitments, including Ex-Im
(FY 70-88), $719 million, Western (non-
US) countries (1970-85), $270 million,
Communist countries (1970-88), $950 mil-
lion
Currency: riel (plural—triels), 1 riel (CR) =
100 sen
Exchange rates: riels (CR) per US$1—218
(November 1989) 100 00 (1987), 30 00
(1986), 7 00 (1985)
Fiscal year: calendar year
Industries: based on exploitation of natural
resources, particularly marine life, miner-
als, oil and gas production, fishing, sand
and gravel aggregates, placer deposits
Overview: Thailand, one of the more ad-
vanced developing countries in Asia, en-
Joyed its second straight exceptionally
prosperous year in 1989 Real output
again rose about 11% The increasingly
sophisticated manufacturing sector bene-
fited from export-oriented investment, and
agriculture grew by 4 0% because of 1m-
Approved for Release: 2020/08/12 C06554432
proved weather The trade deficit of $5 2
billion was more than offset by earnings
from tourism ($3 9 billion), remittances,
and net capital inflows The government
has followed a fairly sound fiscal and
monetary policy, aided by increased tax
receipts from the fast-moving economy In
1989 the government approved new
projyects—roads, ports, electric power,
communications—needed to refurbish the
now overtaxed infrastructure Although
growth in 1990-91 must necessarily fall
below the 1988-89 pace, Thailand’s imme-
diate economic outlook 1s good, assuming
the continuation of prudent government
policies in the context of a private-sector-
oriented development strategy
GNP: $64 5 billion, per capita $1,160, real
growth rate 10 8% (1989 est )
Inflation rate (consumer prices): 5 4%
(1989)
Unemployment rate: 6% (1989 est )
Budget: revenues $12 | billion, expend-
tures $9 7 billion, including capital expen-
ditures of NA (FY89)
Exports: $19 9 billion (fob, 1989), com-
modities—textiles 12%, fishery products
12%, rice 8%, tapioca 8%, jewelry 6%,
manufactured gas, corn, tin, partners—
US 18%, Japan 14%, Singapore 9%,
Netherlands, Malaysia, Hong Kong,
China (1988)
Imports: $25 1 billion (c1f, 1989), com-
modities—machinery and parts 23%, pe-
troleum products 13%, chemicals 11%,
iron and steel, electrical appliances, part-
ners—Japan 26%, US 14%, Singapore
7%, FRG, Malaysia, UK (1987)
External debt: $18 5 billion (December
1989 est )
Industrial production: growth rate 12 5%
(1989)
Electricity: 7,100,000 kW capacity,
28,000 million kWh produced, 500 kWh
per capita (1989)
Industries: tourism 1s the largest source of
foreign exchange, textiles and garments,
agricultural processing, beverages,
tobacco, cement, other lhght manufactur-
ing, such as jewelry, electric appliances
and components, integrated circuits, furni-
ture, plastics, world’s second-largest tung-
sten producer and third-largest tin pro-
ducer
Agriculture: accounts for 16% of GNP
and 73% of labor force, leading producer
and exporter of rice and cassava (tapioca),
other crops—rubber, corn, sugarcane, co-
conuts, soybeans, except for wheat, self-
sufficient in food, fish catch of 2 2 million
tons (1987)
Illicit drugs: a minor producer, major 1-
licit trafficker of heroin, particularly from
Burma and Laos, and cannabis for the
international drug market, eradication
efforts have reduced the area of cannabis
cultivation and shifted some production to
neighboring countries, opium poppy culti-
vation has been affected by eradication
efforts, but unusually good weather
boosted output in 1989
Aid: US commitments, including Ex-Im
(FY 70-88), $828 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $7 0 billion,
OPEC bilateral aid (1979-89), $19 million
Currency: baht (plural—baht), | baht (B)
= 100 satang
Exchange rates: baht (B) per US$1—
25 726 (January 1990), 25 699 (1989),
25 294 (1988), 25 723 (1987), 26 299
(1986), 27 159 (1985)
Fiscal year: 1 October-30 September','61307b79bf553a841a726ab70d58e682ae260e8fed0f1f457cd313e18d843b6f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b8bc8fb3cc5ea1c1062cbe0ea02a38c5a9039e118e9cfefc818ec27c6c4e06',1990,'ET','Ethiopia','economy',161,'Overview: Over the past decade the econ-
omy has registered a remarkable perfor-
mance because of the development of an
offshore o1] industry Real GDP growth
annually averaged 10% from 1978 to
1985 In 1986 Cameroon had one of the
highest levels of income per capita in trop-
ical Africa, with oil revenues picking up
the slack as growth in other sectors soft-
ened Because of the sharp drop in oil
prices, however, the economy 1s now expe-
riencing serious budgetary difficulties and
balance-of-payments disequalibrium Ol1l
reserves currently being exploited will be
depleted 1n the early 1990s, so ways must
be found to boost agricultural and indus-
trial exports in the medium term The
Sixth Cameroon Development Plan (1986-
91) stresses balanced development and
designates agriculture as the basis of the
country’s economic future.
GDP: $12 9 billion, per capita $955, real
growth rate —8 6% (1988)
Inflation rate (consumer prices): 8 6%
(FY88)
Unemployment rate: 7% (1985)
Budget: revenues $2 17 billion, expendi-
tures $2 17 billion, including capital ex-
penditures of $833 million (FY88)
Exports: $2 0 billion (fob , 1988); com-
modities—petroleum products 56%,
Approved for Release: 2020/08/12 C06554432
coffee, cocoa, timber, manufactures, part-
ners—EC (particularly the Netherlands)
about 50%, US 3%
Imports: $2 3 billion (cif, 1988), com-
modities—machines and electrical equip-
ment, transport equipment, chemical prod-
ucts, consumer goods, partners—France
42%, Japan 7%, US 4%
External debt: $4 9 billion (December
1989 est )
Industrial production: growth rate —6 4%
(FY87)
Electricity: 752,000 kW capacity, 2,940
million kWh produced, 270 kWh per cap-
ita (1989)
Industries: crude oil products, small alu-
minum plant, food processing, light con-
sumer goods industries, sawmills
Agriculture: the agriculture and forestry
sectors provide employment for the major-
ity of the population, contributing nearly
25% to GDP and providing a high degree
of self-sufficiency in staple foods, commer-
cial and food crops include coffee, cocoa,
timber, cotton, rubber, bananas, oilseed,
grains, livestock, root starches
Aid: US commitments, including Ex-Im
(FY70-88), $400 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $3 9 billion,
OPEC bilateral aid (1979-89), $29 million,
Communist countries (1970-88), $120 mil-
hon
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: 1 July-30 June
Overview: Ethiopia is one of the poorest
and least developed countries in Africa
Its economy 1s based on subsistence agri-
culture, which accounts for about 45% of
GDP, 90% of exports, and 80% of total
employment, coffee generates over 60% of
export earnings The manufacturing sector
1s heavily dependent on inputs from the
agricultural sector The economy 1s cen-
trally planned, and over 90% of
large-scale industry 1s state run Favorable
agricultural weather largely explains the
4 5% growth in output in FY89
GDP: $6 6 billion, per capita $130, real
growth rate 4 5% (FY89 est )
Inflation rate (consumer prices): 9 6%
(FY89)
Unemployment rate: NA, shortage of
skilled manpower
Budget: revenues $1 4 billion, expenditures
$1 9 billion, including capital expenditures
of $0 7 billion (FY87)
Exports: $418 million (f ob, FY88), com-
modities—coffee 60%, hides, partners—
US, FRG, Dyibouti, Japan, PDRY,
France, Italy
Imports: $1 1 billion (c1f , FY88), com-
modities—food, fuels, capital goods, part-
ners—USSR, Italy, FRG, Japan, UK,
US, France
External debt: $2 6 billion (1988)
Industrial production: growth rate —0 2%
(FY88 est )
Electricity: 330,000 kW capacity, 700 mil-
lion kWh produced, 14 kWh per capita
(1989)
Industries: cement, textiles, food process-
ing, oil refinery
Agriculture: accounts for 45% of GDP and
1s the most important sector of the econ-
omy even though frequent droughts, poor
cultivation practices, and state economic
policies keep farm output low, famines not
uncommon, export crops of coffee and oil-
seeds grown partly on state farms, esti-
mated 50% of agricultural production at
subsistence level, principal crops and live-
stock—cereals, pulses, coffee, oilseeds, po-
tatoes, sugarcane, vegetables, hides and
skins, cattle, sheep, goats
Aid: US commitments, including Ex-Im
(FY 70-88), $471 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 6 billion;
Approved for Release: 2020/08/12 C06554432
OPEC bilateral aid (1979-89), $8 million,
Communist countries (1970-88), $2 0 bil-
lion
Currency: birr (plural—birr), 1 birr (Br) =
100 cents
Exchange rates: birr (Br) per US$1—
2 0700 (fixed rate)
Fiscal year: 8 July-7 July
Overview: The economy has remained de-
pendent on cocoa since the gained inde-
pendence nearly 15 years ago Since then,
however, cocoa production has gradually
deteriorated because of drought and mis-
management, so that by 1987 output had
fallen to less than 50% of its former lev-
els As a result, a shortage of cocoa for
export has created a serious balance-of-
payments problem Production of less 1m-
portant crops, such as coffee, copra, and
palm kernels, has also declined The value
of imports generally exceeds that of ex-
ports by a ratio of 4 to 1 The emphasis
on cocoa production at the expense of
other food crops has meant that Sao
Tome has to import 90% of food needs It
also has to import all fuels and most man-
ufactured goods Over the years, Sao
Tome has been unable to service its exter-
nal debt, which amounts to roughly 80%
of export earnings Considerable potential
exists for development of a tourist indus-
try, and the government has taken steps to
expand facilities in recent years The gov-
ernment also implemented a Five-Year
Plan covering 1986-90 to restructure the
economy and reschedule external debt ser-
vice payments 1n cooperation with the [n-
ternational Development Association and
Western lenders
GDP: $37 9 million, per capita $340, real
growth rate 1 8% (1986)
Inflation rate (consumer prices): 4 2%
(1986)
Unemployment rate: NA%
Budget: revenues $19 2 million, expendi-
tures $25 1 million, including capital ex-
penditures of $199 million (1987)
Exports: $9 1 million (fob, 1988 est),
commodities—cocoa 90%, copra, coffee,
palm oil, partners—FRG, GDR, Nether-
lands, China
Imports: $17 3 million (cif, 1988 est ),
commodities—machinery and electrical
equipment 59%, food products 32%, fuels
9%, partners—Portugal, GDR, Angola,','ba3d72d135c1eabb5a53fbd3eb52e7d457a6b348a2dce3e1fa7152b25e040eda','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf595d5e1697fac56c298245086eac7abc9a51bd3538aa31c0f1af63c907555a',1990,'CA','Canada','economy',167,'Overview: As an affluent, high-tech indus-
trial society, Canada today closely resem-
bles the US in per capita output, market-
oriented economic system, and pattern of
production Since World War II the 1m-
pressive growth of the manufacturing,
mining, and service sectors has
transformed the nation from a largely ru-
ral economy into one primarily industrial
and urban In the 1980s Canada regis-
tered one of the highest rates of growth
among the OECD nations, averaging
about 4% With its great natural
resources, skilled labor force, and modern
capital plant, Canada has excellent eco-
nomic prospects
GDP: $513 6 billion, per capita $19,600,
real growth rate 2 9% (1989 est )
54
Approved for Release: 2020/08/12 C06554432
Inflation rate (consumer prices): 5 0%
(1989)
Unemployment rate: 7 5% (1989)
Budget: revenues $79 2 billion, expendi-
tures $102 0 billion, including capital ex-
penditures of $1 8 billion (FY88 est )
Exports: $127 2 billion (fob, 1989), com-
modities—newsprint, wood pulp, timber,
grain, crude petroleum, natural gas, fer-
rous and nonferrous ores, motor vehicles,
partners—US, Japan, UK, FRG, other
EC, USSR
Imports: $116 5 billion (cif, 1989), com-
modities—processed foods, beverages,
crude petroleum, chemicals, industrial ma-
chinery, motor vehicles, durable consumer
goods, electronic computers, partners—
US, Japan, UK, FRG, other EC, Taiwan,
South Korea, Mexico
External debt: $247 billion (1987)
Industrial production: growth rate 2 3%
(1989)
Electricity: 103,746,000 kW capacity,
472,580 million kWh produced, 17,960
kWh per capita (1989)
Industries: processed and unprocessed
minerals, food products, wood and paper
products, transportation equipment, chem-
icals, fish products, petroleum and natural
gas
Agriculture: accounts for 3% of GDP, one
of the world’s major producers and ex-
porters of grain (wheat and barley), key
source of US agricultural! imports; large
forest resources cover 35% of total land
area, commercial fisheries provide annual
catch of 1 5 million metric tons, of which
75% 1s exported
Illicit drugs: illicit producer of cannabis
for the domestic drug market
Aid: donor—ODA and OOF commitments
(1970-87), $2 2 billion
Currency: Canadian dollar (plural—dol-
lars), 1 Canadian dollar (Can$) = 100
cents
Exchange rates: Canadian dollars (Can$)
per US$1—1 1714 (January 1990), 1 1840
(1989), 1 2307 (1988), 1 3260 (1987),
1 3895 (1986), 1 3655 (1985)
Fiscal year: 1 April-31 March
Overview: Cape Verde’s low per capita
GDP reflects a poor natural resource base,
a 17-year drought, and a high birth rate
The economy 1s service oriented, with
commerce, transport, and public services
accounting for 60% of GDP during the
period 1984-86 Although nearly 70% of
the population lives in rural areas, agricul-
ture’s share of GDP 1s only 16%, the
fishing and manufacturing sectors are 4%
each About 90% of food must be
imported The fishing potential of the 1s-
lands 1s not fully exploited (the fish
catch—mostly lobster and tuna—came to
only 10,000 tons in 1985) Cape Verde
annually runs a high trade deficit,
financed by remittances from emigrants,
cash grants, food aid, and foreign loans
GDP: $158 million, per capita $494, real
growth rate 6 1% (1987)
Inflation rate (consumer prices): 3 8%
(1987)
Unemployment rate: 25% (1988)
Budget: revenues $80 million, expenditures
$87 million, including capital expenditures
of $45 million (1988 est )
Exports: $8 9 million (fo b , 1987), com-
modities—fish, bananas, salt, partners—
Portugal, Angola, Algeria, Belgium/
Luxembourg, Italy
Imports: $124 million (cif , 1987), com-
modities—petroleum, foodstuffs, consumer
goods, industrial products, partners—Por-
tugal, Netherlands, Spain, France, US,
FRG
External debt: $140 million (December
1988)
55
Approved for Release: 2020/08/12 C06554432
Cape Verde (continued)
Industrial production: growth rate 0%
(1986 est )
Electricity: 14,000 kW capacity, 18 muil-
lion kWh produced, 50 kWh per capita
(1989)
Industry: fish processing, salt mining,
clothing factories, ship repair
Agriculture: accounts for 16% of GDP,
largely subsistence farming, bananas are
the only export crop, other crops—corn,
beans, sweet potatoes, coffee, growth po-
tential of agricultural sector muted by
poor soils and limited rainfall; annual food
imports required, fish catch provides for
both domestic consumption and small ex-
ports
Aid: US commitments, including Ex-Im
(FY75-88), $83 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $540 million, OPEC
bilateral aid (1979-89), $12 million, Com-
munist countries (1970-88), $36 million
Currency: Cape Verdean escudo (plural—
escudos), 1 Cape Verdean escudo (CVEsc)
= 100 centavos
Exchange rates: Cape Verdean escudos
(CVEsc) per US$1—72 31 (February
1990), 74 86 (December 1989), 72 01
(1988), 72 5 (1987), 76 56 (1986), 85 38
(1985)
Fiscal year: calendar year
Imports: $509 million (cif , 1988 est ),
commoadities—petroleum products, metals,
machinery, transport equipment, food-
stuffs, textiles and other grain, partners—
US 16%, France, Brazil
External debt: $1 6 billion (December
1988)
Industrial production: growth rate NA%
Electricity: 113,000 kW capacity, 300 mil-
lion kWh produced, 40 kWh per capita
(1989)
Industries: bauxite mining, alumina, dia-
mond mining, light manufacturing and
agricultural processing industries
Agriculture: accounts for 40% of GDP (in-
cludes fishing and forestry), mostly subsis-
tence farming, principal products—rice,
coffee, pineapples, palm kernels, cassava,
bananas, sweet potatoes, timber,
livestock—cattle, sheep and goats, not
self-sufficient in food grains
Aid: US commitments, including Ex-Im
(FY70-88), $203 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $882 million,
OPEC bilateral aid (1979-89), $120 mil-
lion, Communist countries (1970-88), $446
million
Currency: Guinean franc (plural—francs),
1 Guinean franc (FG) = 100 centimes
Exchange rates: Guinean francs (FG) per
US$1—505 00 (October 1988), 440 00
(January 1988), 440 00 (1987), 235 63
(1986), 22 47 (1985)
Fiscal year: calendar year','fad513486cb0a1644dc4468a2fd1946097145fd690048e3d9546b9936e8bc071','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8673a0760ed2365286675629996e22f865e2cfee8ce6f2821db314ec5c896eb9',1990,'KY','Cayman Islands','economy',172,'Overview: The economy depends heavily
on tourism (70% of GDP and 75% of ex-
port earnings) and offshore financial ser-
vices, with the tourist industry aimed at
the luxury market and catering mainly to
visitors from North America About 90%
of the islands’ food and consumer goods
needs must be imported The Caymanians
enjoy one of the highest standards of liv-
ing in the region
GDP: $238 million, per capita $10,000
(1989 est ), real growth rate 12% (1987
est )
Inflation rate (consumer prices): 2 4%
(1986)
Unemployment rate: NA%
Budget: revenues $46 2 million, expendi-
tures $47 0 million, including capital ex-
penditures of $9 1 million (1986)
Exports: $2 2 million (fo b , 1986 est ),
commodities—turtle products, manufac-
tured consumer goods, partners—mostly
US
Imports: $134 million (cif, 1986 est ),
commodities—foodstuffs, manufactured
goods, partners—US, Trinidad and To-
bago, UK, Netherlands Antilles, Japan
External debt: $15 million (1986)
Industrial production: growth rate NA%
Electricity: 59,000 kW capacity, 213 mil-
hon kWh produced, 8,960 kWh per capita
(1989)
Industries: tourism, banking, insurance
and finance, real estate and construction
Agriculture: minor production of vegeta-
bles, fruit, livestock, turtle farming
Aid: US commitments, including Ex-Im
(FY70-87), $26 7 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $32 2 million
Currency: Caymanian dollar (plural—dol-
lars), | Caymanian dollar (CI$) = 100
cents
Exchange rates: Caymanian dollars (CI$)
per US$1—0 835 (fixed rate)
Fiscal year: | April-31 March','3fd51a6e7108573077adc967c9db9732fce1d1f78108f21c6833c73f0bf75b66','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e0ae2c1455be19029ad286b5fc5a4fe91cf62e14e89df6cfa985bdcbb263640',1990,'CF','Central African Republic','economy',177,'Overview: The Central African Republic
(CAR) 1s one of the poorest countries in
Africa, with a per capita income of
roughly $450 in 1988 Subsistence agri-
culture, including forestry, 1s the back-
bone of the economy, with over 70% of
the population living in the countryside In
1988 the agricultural sector generated
about 40% of GDP, mining and manufac-
turing 14%, utilities and construction 4%,
and services 41% Agricultural products
accounted for about 60% of export earn-
ings and the diamond industry for 30%
Important constraints to economic devel-
opment include the CAR’s landlocked po-
sition, a poor transportation infrastruc-
ture, and a weak human resource base
Multilateral and bilateral development
assistance plays a major role in providing
capital for new investment
GDP: $1 27 billion, per capita $453, real
growth rate 2 0% (1988 est )
Approved for Release: 2020/08/12 C06554432
Inflation rate (consumer prices): — 4 2%
(1988 est )
Unemployment rate: 30% in Bangui (1988
est )
Budget: revenues $132 million, current
expenditures $305 million, including capi-
tal expenditures of $NA million (1989
est )
Exports: $138 million (fo b , 1988 est ),
commodities—diamonds, cotton, coffee,
timber, tobacco, partners—France, Bel-
gium, Italy, Japan, US
Imports: $285 million (c1f , 1988 est ),
commoadities—food, textiles, petroleum
products, machinery, electrical equipment,
motor vehicles, chemicals, pharmaceuti-
cals, consumer goods, industrial products,
partners—France, other EC, Japan, Alge-
ria, Yugoslavia
External debt: $660 million (December
1989)
Industrial production: | 9% (1987 est )
Electricity: 35,000 kW capacity, 84 mil-
lion kWh produced, 30 kWh per capita
(1989)
Industries: sawmills, breweries, diamond
mining, textiles, footwear, assembly of
bicycles and motorcycles
Agriculture: accounts for 40% of GDP,
self-sufficient in food production except
for grain, commercial crops—cotton,
coffee, tobacco, timber, food crops—ma-
nioc, yams, millet, corn, bananas
Aid: US commitments, including Ex-Im
(FY70-88), $44 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 3 billion, OPEC
bilateral aid (1979-89), $6 million, Com-
munist countries (1970-88), $38 million
Currency: Communauté Financiére Afn-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year','46bd9f6b2848838eccb9ed0f3a448741cb59dc78f1cb1d5629ad013368b3ee7d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c06cef47fbbfc48f762af85293e59e2e84ecd19d3707499a3d20c566f100925',1990,'TD','Chad','economy',182,'Overview: The climate, geographic loca-
tion, and lack of infrastructure and natu-
ral resources potential make Chad one of
the most underdeveloped countries in the
world Its economy 1s slowly recovering
from the ravaging effects of prolonged
civil war, conflict with Libya, drought,
and food shortages In 1986 real GDP
returned to its 1977 level, with cotton, the
major cash crop, accounting for 43% of
exports Over 80% of the work force 1s
employed in subsistence farming and
fishing Industry 1s based almost entirely
on the processing of agricultural products,
including cotton, sugarcane, and cattle
Chad 1s still highly dependent on foreign
aid, with its economy in trouble and many
regions suffering from shortages
GDP: $902 million, per capita $190, real
growth rate 7 0% (1988)
Inflation rate (consumer prices): — 3 0%
(1987)
Unemployment rate: NA
60
Approved for Release: 2020/08/12 C06554432
Budget: revenues $61 million, expenditures
$85 million, including capital expenditures
of NA (1988 est )
Exports: $432 million (fo b , 1988), com-
modities—cotton 43%, cattle 35%, textiles
5%, fish, partners—France, Nigeria, Ca-
meroon
Imports: $214 million (cif , 1988), com-
modities—machinery and transportation
equipment 39%, industrial goods 20%, pe-
troleum products 13%, foodstuffs 9%,
partners—US, France
External debt: $360 million (December
1989)
Industrial production: growth rate —7 0%
(1986)
Electricity: 38,000 kW capacity, 70 mil-
hon kWh produced, 14 kWh per capita
(1989)
Industries: cotton textile mills, slaughter-
houses, brewery, natron (sodium carbon-
ate)
Agriculture: accounts for 45% of GDP,
largely subsistence farming, cotton most
important cash crop, food crops include
sorghum, millet, peanuts, rice, potatoes,
manioc, livestock—cattle, sheep, goats,
camels, self-sufficient in food in years of
adequate rainfall
Aid: US commitments, including Ex-Im
(FY70-88), $178 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 2 billion,
OPEC bilateral aid (1979-89), $28 million,
Communist countries (1970-88), $71 mil-
lion
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year','ba2c81242cea7de951097fb574d5d8643273a1422549865f483cfc449095e39c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9efd3eacc7edd304f3bddd1f5ea89f0a0ad4bbbefacc8132fa38866f23e06c34',1990,'CL','Chile','economy',187,'Overview: In 1989 the economy grew at
the rate of 9 9%, reflecting substantial
growth in industry, agriculture, and con-
struction Copper accounts for nearly 50%
of export revenues, Chile’s economic well-
being thus remains highly dependent on
international copper prices Unemploy-
ment and inflation rates have declined
from their peaks in 1982 to 5 3% and
21 4%, respectively, in 1989 The major
long-term economic problem 1s how to
sustain growth in the face of political un-
certainties
GDP: $25 3 billion, per capita $1,970, real
growth rate 9 9% (1989)
Inflation rate (consumer prices): 21 4%
(1989)
Unemployment rate: 5 3% (1989)
Budget: revenues $4 9 billion, expenditures
$5 1 billion, including capital expenditures
of $0 6 billion (1986)
Exports: $7 0 billion (fo b , 1988), com-
modities—copper 48%, industrial products
33%, molybdenum, iron ore, wood pulp,
fishmeal, fruits, partners—EC 34%, US
22%, Japan 10%, Brazil 7%
Imports: $4 7 billion (f.o b , 1988), com-
modities—petroleum, wheat, capital
goods, spare parts, raw materials, part-
ners—EC 23%, US 20%, Japan 10%, Bra-
zil 9%
External debt: $16 3 billion (December
1989)
Industrial production: growth rate 7 4%
(1989)
Electricity: 4,044,000 kW capacity,
17,710 million kWh produced, 1,380 kWh
per capita (1989)
Industries: copper, other minerals, food-
stuffs, fish processing, iron and steel, wood
and wood products
Agriculture: accounts for about 8% of
GDP (including fishing and forestry), ma-
jor exporter of fruit, fish, and timber prod-
ucts, major crops—wheat, corn, grapes,
beans, sugar beets, potatoes, deciduous
fruit, livestock products—beef, poultry,
wool, self-sufficient 1n most foods, 1986
fish catch of 5 6 million metric tons net
agricultural importer
Aid: US commitments, including Ex-Im
(FY70-88), $521 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 3 billion,
Communist countries (1970-88), $386 mil-
lion
62
Approved for Release: 2020/08/12 C06554432
Currency: Chilean peso (plural—pesos), |
Chilean peso (Ch$) = 100 centavos
Exchange rates: Chilean pesos (Ch$) per
US31—296 68 (January 1990), 267 16
(1989), 245 05 (1988), 219 54 (1987),
193 02 (1986), 161 08 (1985)
Fiscal year: calendar year','c3870db0801b57eb66c4028ff858676545c65f126a2213a3a1d1851a32e031c7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fab93940ebdf33fe77a482ca1b7dc44abb479b16a94d741d745a641c278c8fa',1990,'CN','China','economy',192,'Overview: Beginning 1n late 1978 the Chi-
nese leadership has been trying to move
the economy from the sluggish Soviet-
style centrally planned economy to a more
productive and flexible economy with mar-
ket elements—but still within the frame-
work of monolithic Communist control To
this end the authorities have switched to a
system of household responsibility in agri-
culture in place of the old collectivization,
increased the authority of local officials
and plant managers in industry, permitted
a wide variety of small-scale enterprise in
services and light manufacturing, and
opened the foreign economic sector to in-
creased trade and joint ventures The most
gratifying result has been a strong spurt
in production, particularly in agriculture
in the early 1980s Otherwise, the leader-
ship has often experienced in its hybrid
system the worst results of socialism (bu-
reaucracy, lassitude, corruption) and of
capitalism (windfall gains and stepped-up
inflation) Beijing thus has periodically
backtracked, retightening central controls
at intervals and thereby undermining the
credibility of the reform process Open
inflation and excess demand continue to
plague the economy, and political repres-
sion, following the crackdown at Tianan-
men in mid-1989, has curtailed tourism,
foreign aid, and new investment by for-
eign firms Popular resistance and changes
in central policy have weakened China’s
population control program, which 1s es-
sential to the nation’s long-term economic
viability
63
Approved for Release: 2020/08/12 C06554432
China (continued)
GNP: $NA, per capita $NA, real growth
rate 4% (1989 est )
Inflation rate (consumer prices): 19 5%
(1989)
Unemployment rate: 3 0% in urban areas
(1989)
Budget: revenues $NA, expenditures $NA,
including capital expenditures of SNA
Exports: $52 5 billion (fo b, 1989), com-
modities—manufactured goods, agricul-
tural products, oilseeds, grain (rice and
corn), oil, minerals, partners—Hong Kong,
US, Japan, USSR, Singapore, FRG
(1989)
Imports: $59 1 billion (cif , 1989), com-
modities—grain (mostly wheat), chemical
fertilizer, steel, industrial raw materials,
machinery, equipment, partners—Hong
Kong, Japan, US, FRG, USSR (1989)
External debt: $51 billion (1989 est )
Industrial production: growth rate 8 0%
(1989)
Electricity: 110,000,000 kW capacity,
560,000 million kWh produced, 500 kWh
per capita (1989)
Industries: iron, steel, coal, machine build-
ing, armaments, textiles, petroleum
Agriculture: accounts for 26% of GNP,
among the world’s largest producers of
rice, potatoes, sorghum, peanuts, tea, mil-
let, barley, and pork, commercial crops
include cotton, other fibers, and oilseeds,
produces variety of livestock products, ba-
sically self-sufficient in food, fish catch of
8 million metric tons in 1986
Aid: US commitments, including Ex-Im
(FY70-87), $220 7 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $11 1 billion
Currency: yuan (plural—yuan), | yuan (¥)
= 10 jiao
Exchange rates: yuan (¥) per US$1—
47221 (January 1990), 3 7651 (1989),
3 7221 (1988), 3 7221 (1987), 3 4528
(1986), 2 9367 (1985)
Fiscal year: calendar year
External debt: $238 million (December
1988)
Industrial production: growth rate 3 4%
(1988 est )
Electricity: 16,000 kW capacity, 24 mil-
lion kWh produced, 55 kWh per capita
(1989)
Industries: perfume distillation
Agriculture: accounts for 40% of GDP,
most of population works in subsistence
69
Approved for Release: 2020/08/12 C06554432
Comoros (continued)
agriculture and fishing, plantations pro-
duce cash crops for export—vanilla,
cloves, perfume essences, and copra, prin-
cipal food crops—coconuts, bananas, cas-
sava, world’s leading producer of essence
of ylang-ylang (for perfumes) and second-
largest producer of vanilla, large net food
importer
Aid: US commitments, including Ex-Im
(FY80-88), $9 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $371 million, OPEC
bilateral aid (1979-89), $22 million, Com-
munist countries (1970-88), $18 million
Currency: Comoran franc (plural—francs),
1 Comoran franc (CF) = 100 centimes
Exchange rates: Comoran francs (CF) per
US$1—287 99 (January 1990), 319 O01
(1989), 297 85 (1988), 300 54 (1987),
346 30 (1986), 449 26 (1985), note—linked
to the French franc at 50 to 1 French
franc
Fiscal year: calendar year
Overview: The economy continues to re-
cover from the political turmoil following
the ouster of former President Marcos and
several coup attempts After two consecu-
tive years of economic contraction (1984
and 1985), the economy has since 1986
had positive growth The agricultural sec-
tor, together with forestry and fishing,
plays an important role in the economy,
employing about 50% of the work force
and providing almost 30% of GDP The
Philippines is the world’s largest exporter
of coconuts and coconut products Manu-
facturing contributed about 25% of GDP
Mayor industries include food processing,
chemicals, and textiles
GNP: $40 5 billion, per capita $625, real
growth rate 5 2% (1989)
Inflation rate (consumer prices): 10 6%
(1989)
Unemployment rate: 8 7% (1989)
Budget: $7 2 billion, expenditures $8 12
billion, including capital expenditures of
$0 97 billion (1989 est )
Exports: revenues $8 | billion (fob,
1989), commodities—electrical equipment
19%, textiles 16%, minerals and ores 11%,
farm products 10%, coconut 10%, chemi-
cals 5%, fish 5%, forest products 4%, part-
ners—US 36%, EC 19%, Japan 18%,
ESCAP 9%, ASEAN 7%
Imports: $10 5 billion (c1f , 1989), com-
modities—raw matenials 53%, capital
goods 17%, petroleum products 17%, part-
ners—US 25%, Japan 17%, ESCAP 13%,
EC 11%, ASEAN 10%, Middle East 10%
251
Approved for Release: 2020/08/12 C06554432
Philippines (continued)
External debt: $27 8 billion (1988)
Industrial production: growth rate 7 3%
(1989)
Electricity: 6,700,000 kW capacity,
25,000 million kWh produced, 385 kWh
per capita (1989)
Industries: textiles, pharmaceuticals,
chemicals, wood products, food processing,
electronics assembly, petroleum refining,
fishing
Agriculture: accounts for about one-third
of GNP and 50% of labor force, major
crops—rice, coconut, corn, sugarcane, ba-
nanas, pineapple, mango, animal prod-
ucts—pork, eggs, beef, net exporter of
farm products, fish catch of 2 million met-
ric tons annually
Illicit drugs: illicit producer of cannabis
for the international drug trade, growers
are producing more and better quality
cannabis despite government eradication
efforts
Aid: US commitments, including Ex-Im
(FY70-88), $3 2 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $6 4 bilhon, OPEC
bilateral aid (1979-89), $5 million, Com-
munist countries (1975-88), $123 million
Currency: Philippine peso (plural—pesos),
1 Philippine peso (PF) = 100 centavos
Exchange rates: Philippine pesos (P) per
US$1—22 464 (January 1990), 21 737
(1989), 21 095 (1988), 20 568 (1987),
20 386 (1986), 18 607 (1985)
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432
External debt: $95 million (1988)
Industrial production: growth rate 7 1%
(1986)
Electricity: 6,000 kW capacity, 12 million
kWh produced, 100 kWh per capita
(1989)
Industries: light construction, shirts, soap,
beer, fisheries, shrimp processing
Agriculture: dominant sector of economy,
primary source of exports, cash crops—
cocoa (90%), coconuts, palm kernels,
coffee, food products—bananas, papaya,
beans, poultry, fish, not self-sufficient in
food grain and meat
Aid: US commitments, including Ex-Im
(FY70-87), $7 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), 41 9 million
Currency: dobra (plural—dobras), 1 dobra
(Db) = 100 céntimos
Exchange rates: dobras (Db) per US$1—
122 48 (December 1988), 72 827 (1987),
36 993 (1986), 41 195 (1985)
Fiscal year: calendar year
Overview: This is a centrally planned, de-
veloping economy with extensive govern-
ment ownership and control of productive
facilities The economy 1s primarily agri-
cultural, employing about 65% of the la-
bor force and accounting for almost half
of GNP Rice 1s the staple crop, substan-
tial amounts of maize, sorghum, cassava,
and sweet potatoes are also grown The
government permits sale of surplus grain
on the open market Most of the mineral
resources are located in the north, includ-
ing coal, which is an important export
item Following the end of the war in
1975, heavy handed government measures
undermined efforts at an efficient merger
of the agricultural resources of the south
and the industrial resources of the north
The economy remains heavily dependent
on foreign aid and has received assistance
from Communist countries, Sweden, and
UN agencies Inflation, although down
from recent triple-digit levels, 1s still a
major weakness, and per capita output 1s
among the world’s lowest Since early
Approved for Release: 2020/08/12 C06554432
1989 the government has sponsored a
broad reform program that seeks to turn
more economic activity over to the private
sector
GNP: $14 2 billion, per capita $215, real
growth rate 8% (1989 est )
Inflation rate (consumer prices): 40% (1989
est )
Unemployment rate: 25% (1989 est )
Budget: revenues $3 2 billion, expenditures
$4 3 billion, including capital expenditures
of $528 million (1987 est )
Exports: $1 1 billion (fo b, 1988), com-
modities—agricultural and handicraft
products, coal, minerals, ores, partners—
USSR, Eastern Europe, Japan, Singapore
Imports: $2 5 billion (cif , 1988), com-
modities—petroleum, steel products, rail-
road equipment, chemicals, medicines,
raw cotton, fertilizer, grain, partners—
USSR, Eastern Europe, Japan, Singapore
External debt: $16 billion (1989)
Industrial production: growth rate 10%
(1989)
Electricity: 2,465,000 kW capacity, 6,730
million kWh produced, 100 kWh per cap-
ita (1989)
Industries: food processing, textiles, ma-
chine building, mining, cement, chemical
fertilizer, glass, tires, oul, fishing
Agriculture: accounts for half of GNP,
paddy rice, corn, potatoes make up 50% of
farm output, commercial crops (rubber,
soybeans, coffee, tea, bananas) and animal
products other 50%, not self-sufficient in
food staple rice, fish catch of 900,000
metric tons (1988 est )
Aid: US commitments, including Ex-Im
(FY70-74), $3 1 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $2 7 billion, OPEC
bilateral! aid (1979-89), $61 million, Com-
munist countries (1970-88), $10 9 million
Currency: new dong (plural—new dong), 1
new dong (D) = 100 xu
Exchange rates: new dong (D) per US$1—
4,000 (March 1990), 900 (1988), 225
(1987), 18 (1986), 12 (1985), note—1985-
89 figures are end of year
Fiscal year: calendar year','86a7b54957a98cdd1d139b50ab433baff889783a98585dbcfbcf1da87fc61dde','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead928c3dee3e2d41566d4dd4d5a0ff2b21d22f4900278dea33d3883a9434fb8',1990,'CX','Christmas Island','economy',198,'Overview: Phosphate mining 1s the only
significant economic activity, but in No-
vember 1987 the Australian Government
announced that the mine would be closed
because of labor unrest Plans are under
way to build a casino and hotel to develop
tourism
GDP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices): NA%
Unemployment rate: 0%
Budget: revenues $NA, expenditures $NA,
including capital expenditures of $NA
Exports: $NA, commodities—phosphate,
partners—Austraha, NZ
Imports: $NA, commodities—NA, part-
ners—NA
External debt: $NA
Industrial production: growth rate NA%
Electricity: 11,000 kW capacity, 38 mil-
lion kWh produced, 16,680 kWh per cap-
ita (1989)
Industries: phosphate extraction (near de-
pletion)
Agriculture: NA
Aid: none
Currency: Australian dollar (plural—dol-
lars), 1 Australian dollar ($A) = 100 cents
Approved for Release: 2020/08/12 C06554432
Clipperton Island
(French possession}
Exchange rates: Australian dollars ($A)
per US$1—1 2784 (January 1990), 1 2618 ees ——2km
(1989), 1 2752 (1988), 1 4267 (1987), L
*"
1 4905 (1986), 1 4269 (1985)
Fiscal year: 1 July-30 June
Overview: no economic activity','4d522a5fa132bab0c6f688c13ee5c40b8edebd68dbd2adca4c51a9f8368f720b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d1c8349629f1b677de66c5f85ad93511acd92d6dc03f77cf8a7a1fc0bda1106',1990,'CC','Cocos (Keeling) Islands','economy',203,'Overview: Grown throughout the islands,
coconuts are the sole cash crop Copra
and fresh coconuts are the major export
earners Small local gardens and fishing
contribute to the food supply, but addi-
tional food and most other necessities
must be imported from Australia
GNP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices); NA%
Unemployment: NA
Budget: revenues $NA, expenditures $NA,
including capital expenditures of $NA
Exports: $NA, commodities—copra, part-
ners—Australia
Imports: $NA, commoditres—foodstuffs,
partners—Australia
External debt: SNA
Industrial production: growth rate NA%
Electricity: NA kW capacity, NA million
kWh produced, NA kWh per capita
Approved for Release: 2020/08/12 C06554432
Industries: copra products
Agriculture: gardens provide vegetables,
bananas, pawpaws, coconuts
Aid: none
Currency: Australian dollar (plural—dol
lars), 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A)
per US$1—1 2784 (January 1990), 1 2618
(1989), 1 2752 (1988), 1 4267 (1987),
1 4905 (1986), 1 4269 (1985)
Fiscal year: 1 July-30 June','458d2be000f74457916b9d8df470c546605fa898c728918998dd71d60ca635de','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f728070e9b6ad682d9017337551f13467ebd0a58f1e735db371cae26cd57bc',1990,'CO','Colombia','economy',208,'Overview: Economic activity has slowed
gradually since 1986, but growth rates
remain high by Latin American
standards Conservative economic policies
have encouraged investment and kept 1n-
flation and unemployment under 30% and
10%, respectively The rapid development
of oil, coal, and other nontraditional in-
dustries over the past four years has
helped to offset the decline in coffee
prices—Colombia’s major export The col-
lapse of the International Coffee Agree-
ment in the summer of 1989, a trouble-
some rural insurgency, and drug-related
violence dampen prospects for future
growth
GDP: $35 4 billion, per capita $1,110, real
growth rate 3 7% (1988)
Inflation rate (consumer prices): 27% (1989
est )
Unemployment rate: 9 0% (1989 est )
Budget: revenues $4 39 billion, current
expenditures $3 93 billion, capital expen-
ditures $103 billion (1989 est )
Exports: $5 76 billion (fob, 1989 est ),
commodities—coffee 30%, petroleum
24%, coal, bananas, fresh cut flowers,
partners—US 36%, EC 21%, Japan 5%,
Netherlands 4%, Sweden 3%
Imports: $5 02 billion (cif, 1989 est),
commodities—industrial equipment,
transportation equipment, foodstuffs,
chemicals, paper products, partners—US
34%, EC 16%, Brazil 4%, Venezuela 3%,
Japan 3%
External debt: $17 5 billion (1989)
Industrial production: growth rate 2 0%
(1989 est )
Electricity: 9,250,000 kW capacity,
35,364 million kWh produced, 1,110 kWh
per capita (1989)
Industries: textiles, food processing, oil,
clothing and footwear, beverages, chemi-
cals, metal products, cement, mining—
gold, coal, emeralds, iron, nickel, silver,
salt
68
Approved for Release: 2020/08/12 C06554432
Agriculture: accounts for 22% of GDP,
crops make up two-thirds and livestock
one-third of agricultural output, climate
and soils permit a wide variety of crops,
such as coffee, rice, tobacco, corn, sugar-
cane, cocoa beans, oilseeds, vegetables,
forest products and shrimp farming are
becoming more important
INicit drugs: major illicit producer of can-
nabis and coca for the international drug
trade, key supplier of marijuana and co-
caine to the US and other international
drug markets, drug production and traf-
ficking accounts for an estimated 4% of
GDP and 28% of foreign exchange earn-
ings
Aid: US commitments, including Ex-Im
(FY 70-88), $1 6 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $2 9 billion, Commu-
nist countries (1970-88), $399 million
Currency: Colombian peso (plural—pesos),
1 Colombian peso (Col$) = 100 centavos
Exchange rates: Colombian pesos (Col$)
per US$1—439 68 (January 1990), 382 57
(1989), 299 17 (1988), 242 61 (1987),
194 26 (1986), 142 31 (1985)
Fiscal year: calendar year','38536b81a94e170aacb1cefc4b42077be6a85e5a8fd91bc7737652f9149d5413','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc8aa0e269585a4b793a30ed691a2bc49fee39c458af3c928dba7a06b2ed8fb9',1990,'CG','Congo','economy',214,'Overview: Oil has supplanted forestry as
the mainstay of the economy, providing
about two-thirds of government revenues
and exports In the early 1980s rapidly
rising oil revenues enabled Congo to fi-
nance large-scale development projects
with growth averaging 5% annually, one
of the highest rates in Africa The world
decline in oil prices, however, has forced
the government to launch an austerity
program to cope with declining receipts
and mounting foreign debts
GDP: $2 2 billion, per capita $1,000; real
growth rate — 3% (1988 est )
Inflation rate (consumer prices): 1 5%
(1988)
Unemployment rate: NA%
Budget: revenues $382 million, expendi-
tures $575 million, including capital ex-
penditures of $118 million (1988)
Exports: $912 million (f 0 b , 1987), com-
modities—crude petroleum 72%, lumber,
plywood, coffee, cocoa, sugar, diamonds,
partners—US, France, other EC
Approved for Release: 2020/08/12 C06554432
Imports: $494 4 million (c1f, 1987), com-
modities—foodstuffs, consumer goods,
intermediate manufactures, capital equip-
ment, partners—France, Italy, other EC,
US, FRG, Spain, Japan, Brazil
External debt: $4 5 billion (December
1988)
Industrial production: growth rate —5 9%
(1987)
Electricity: 133,000 kW capacity, 300 mil-
lion kWh produced, 130 kWh per capita
(1989)
Industries: crude oil, cement, sawmills,
brewery, sugar mill, palm oil, soap, ciga-
Tettes
Agriculture: accounts for 11% of GDP (in-
cluding fishing and forestry), cassava ac-
counts for 90% of food output, other
crops—rice, corn, peanuts, vegetables,
cash crops include coffee and cocoa, forest
products important export earner, imports
over 90% of food needs
Aid: US commitments, including Ex-Im
(FY70-88), $56 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $2 1 billion, OPEC
bilateral aid (1979-89), $15 million, Com-
munist countries (1970-88), $338 million
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year','7924b2cd6614c7e4bfc39b8447beefa7f64ecd3dd0cc7122540d01aa3c4f51a5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cb354fb2f64f73629ada7095cb6905222d0c2ad73bcdfda92ef248b49a9505e',1990,'CK','Cook Islands','economy',219,'Overview: Agriculture provides the eco-
nomic base The major export earners are
fruit, copra, and clothing Manufacturing
activities are limited to a fruit-processing
plant and several clothing factories Eco-
nomic development 1s hindered by the 1so-
lation of the islands from foreign markets
and a lack of natural resources and good
transportation links A large trade deficit
1s annually made up for by remittances
from emigrants and from foreign aid
Current economic development plans call
for exploiting the tourism potential and
expanding the fishing industry
GDP: $40 0 million, per capita $2,200
(1988 est ), real growth rate 5 3% (1986-88
est )
Inflation rate (consumer prices): 8 0%
(1988)
Unemployment rate: NA%
Budget: revenues $33 8 million, expendi-
tures $34 4 million, including capital ex-
penditures of $NA (1990 est )
Exports: $4 0 milhon (fob, 1988), com-
modities—copra, fresh and canned fruit,
clothing, partners—NZ 80%, Japan
Imports: $38 7 million (cif , 1988), com-
modities—foodstuffs, textiles, fuels, tim-
ber, partners—NZ 49%, Japan, Australia,
US
External debt: $NA
Industrial production: growth rate NA%
Electricity: 4,800 kW capacity, 15 millon
kWh produced, 830 kWh per capita
(1989)
Industries: fruit processing, tourism
Agriculture: export crops—copra, citrus
fruits, pineapples, tomatoes, bananas, sub-
sistence crops—yams, taro
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
89), $128 million
Currency: New Zealand dollar (plural—
dollars), 1 New Zealand dollar (NZ$) =
100 cents
Exchange rates: New Zealand dollars
(NZ$) per US$1—1 6581 (January 1990),
1 6708 (1989), 1 5244 (1988), 1 6886
(1987), 1 9088 (1986), 2 0064 (1985)
Fiscal year: | April-31 March
Overview: no economic activity','a1a021223a2e365399620cb1f68efca60be2f86c11d21b931388ffc6b4d7acd0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18320d5f34f0e5505b2249f1c321a712181468cafbe734b0348118ff6585aa6c',1990,'CR','Costa Rica','economy',224,'Overview: In 1988 the economy grew at a
3 8% rate, a drop from the 5 1% of the
previous year Gains in agricultural pro-
duction (on the strength of good coffee
and banana crops) and 1n construction,
were partially offset by declines in the
rates of growth for the industry and com-
merce sectors In 1988 consumer prices
rose by nearly 21% followed by a 10% rise
in 1989 Unemployment 1s officially re-
ported at about 6%, but much underem-
ployment remains External! debt, on a per
capita basis, 1s among the world’s highest
GDP: $4 7 billion, per capita $1,630, real
growth rate 3 8% (1988)
Inflation rate (consumer prices): 10%
(1989)
Unemployment rate: 5 5% (March 1989)
Budget: revenues $719 million, expendi-
tures $808 million, including capital ex-
penditures of $103 million (1988)
Exports: $1 3 billion (fob, 1988), com-
modities—coffee, bananas, textiles, sugar,
partners—US 75%, FRG, Guatemala,
Netherlands, UK, Japan
Imports: $1 4 billion (cif, 1988), com-
modities—petroleum, machinery, con-
sumer durables, chemicals, fertilizer, food-
stuffs, partners—US 35%, Japan,
Guatemala, FRG
External debt: $4 5 billion (1989)
Industrial production: growth rate 2 1%
(1988)
Electricity: 909,000 kW capacity, 2,928
million kWh produced, 990 kWh per cap-
ita (1989)
Industries: food processing, textiles and
clothing, construction materials, fertilizer
Agriculture: accounts for 20-25% of GDP
and 70% of exports, cash commodities—
coffee, beef, bananas, sugar, other food
crops include corn, rice, beans, potatotes,
normally self-sufficient in food except for
grain, depletion of forest resources result-
ing in lower timber output
Illicit drugs: illicit production of cannabis
on small scattered plots, transshipment
country for cocaine from South America
Aid: US commitments, including Ex-Im
(FY70-88), $1 3 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $706 million, Com-
munist countries (1971-88), $27 million
Currency: Costa Rican colén (plural—
colones), 1 Costa Rican colén (C) = 100
céntimos
Exchange rates: Costa Rican colones (C)
per US$1—84 689 (January 1990), 81 504
(1989), 75 805 (1988), 62 776 (1987),
55 986 (1986), 50 453 (1985)
Fiscal year: calendar year','30283c0da1d0315d25d64f548a349257466773d70d5d9748b4e24ae3730671c3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a4cf132558da137250ce2637a46a4aa6e11c3f9696728fb9820cb11d0f6059',1990,'CU','Cuba','economy',229,'Overview: The Soviet-style economy, cen-
trally planned and largely state owned, 1s
highly dependent on the agricultural sec-
tor and foreign trade Sugar provides
about 75% of export revenues and 1s
mostly exported to the USSR and other
CEMA countries The economy has stag-
nated since 1985 under a program that
has deemphasized material incentives in
the workplace, abolished farmers’ informal
produce markets, and raised prices of
government-supplied goods and services
Castro has complained that the ongoing
CEMA reform process has interfered with
the regular flow of goods to Cuba Re-
cently the government has been trying to
increase trade with Latin America and
China Cuba has had difficulty servicing
its foreign debt since 1982 The govern-
ment currently is encouraging foreign 1n-
vestment in tourist facilities Other invest-
ment priorities include sugar, basic foods,
and nickel The annual $4 billion Soviet
subsidy, a main prop to Cuba’s threadbare
Approved for Release: 2020/08/12 C06554432
economy, may be cut in view of the
USSR’s mounting economic problems
GNP: $20 9 billion, per capita $2,000, real
growth rate —1% (1989 est )
Inflation rate (consumer prices): NA%
Unemployment: 6% overall, 10% for
women (1989)
Budget: revenues $11 7 billion, expendi-
tures $13 5 billion, including capital ex-
penditures of $NA (1989 est )
Exports: $5 5 billion (f ob, 1988), com-
modities—sugar, nickel, shellfish, citrus,
tobacco, coffee, partners—USSR 67%,
GDR 6%, China 4% (1988)
Imports: $7 6 billion (cif, 1988), com-
modities—capital goods, industrial raw
materials, food, petroleum, partners—
USSR 71%, other Communist countries
15% (1988)
External debt: $6 8 billion (convertible
currency, July 1989)
Industrial production: 3% (1988)
Electricity: 3,991,000 kW capacity,
14,972 million kWh produced, 1,425 kWh
per capita (1989)
Industries: sugar milling, petroleum re-
fining, food and tobacco processing, tex-
tiles, chemicals, paper and wood products,
metals (particularly nickel), cement, fertil-
izers, consumer goods, agricultural ma-
chinery
Agriculture: accounts for 11% of GNP
(including fishing and forestry), key com-
mercial crops—sugarcane, tobacco, and
citrus fruits, other products—coffee, rice,
potatoes, meat, beans, world’s largest
sugar exporter, not self-sufficient in food
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $657 5 million; Communist countries
(1970-88), $13 5 billion
Currency: Cuban peso (plural—pesos), |
Cuban peso (Cu$) = 100 centavos
Exchange rates: Cuban pesos (Cu$) per
US$1—1 0000 (linked to the US dollar)
Fiscal year: calendar year','c565e187ea145ee3545548de884cd9b7b0f687da95e15fd4bd72bb4934d620e1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23b0ee9fde4a096e8a4db7fdad198a1098831f1312694b39f990ecd92640e633',1990,'CY','Cyprus','economy',234,'Overview: These data are for the area con-
trolled by the Republic of Cyprus (tnfor-
mation on the northern Turkish-Cypriot
area 1s sparse) The economy 1s small, di-
versified, and prosperous Industry con-
tributes about 28% to GDP and employs
35% of the labor force, while the service
sector contributes about 55% to GDP and
employs 40% of the labor force Rapid
growth in exports of agricultural and
manufactured products and in tourism
have played important roles in the average
6% rise in GDP 1n recent years While
this growth put considerable pressure on
prices and the balance of payments, the
inflation rate has remained low and the
balance-of-payments deficit manageable
GDP: $4 2 billion, per capita $6,100, real
growth rate 6 9% (1988 est )
Inflation rate (consumer prices): 3 9%
(1989 est )
Unemployment rate: 2 8% (1988)
Budget: revenues $1 2 billion, expenditures
$1 4 billion, including capital expenditures
of $178 million (1989 est )
Exports: $767 million (fo b , 1988), com-
modities—citrus, potatoes, grapes, wine,
cement, clothing and shoes, partners—
Middle East and North Africa 37%, UK
27%, other EC 11%, US 2%
Imports: $1 9 billion (c1 f , 1988), com-
modities—consumer goods 23%, petro-
leum and lubricants 12%, food and feed
grains, machinery, partners—EC 60%,
Middle East and North Africa 7%, US
4%
Approved for Release: 2020/08/12 C06554432
External debt: $2 8 billion (1988)
Industrial production: growth rate 6 5%
(1988)
Electricity: 620,000 kW capacity, 1,770
million kWh produced, 2,530 kWh per
capita (1989)
Industries: mining (iron pyrites, gypsum,
asbestos), manufactured products—bever-
ages, footwear, clothing, and cement—are
principally for local consumption
Agriculture: accounts for 8% of GDP and
employs 22% of labor force, major
crops—potatoes, vegetables, barley,
grapes, olives, and citrus fruits, vegetables
and fruit provide 25% of export revenues
Aid: US commitments, including Ex-Im
(FY 70-88), $272 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $223 million,
OPEC bilateral aid (1979-89), $62 million,
Communist countries (1970-88), $24 mil-
lion
Currency: Cypriot pound (plural—pounds)
and in Turkish area, Turkish lira
(plural—hras), 1 Cypriot pound (£C) =
100 cents and | Turkish lira (TL) = 100
kurus
Exchange rates: Cypriot pounds (£C) per
US$1—0 4854 (January 1990), 0 4933
(1989), 0 4663 (1988), 0 4807 (1987),
0 5167 (1986), 0 6095 (1985), in Turkish
area, Turkish liras (TL) per US$1—
2,314 7 (November 1989), 1,422 3 (1988),
857 2 (1987), 674 5 (1986), 522 0 (1985)
Fiscal year: calendar year','1da7eb90ed62dfab58d31351d78f0ae1a21b7677a925ed27e2ef62827017e861','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('734a56b9165c0f7fa82203203fcfa6c8e650edb12c705611188f8393a6d3f28e',1990,'HU','Hungary','economy',238,'Overview: Czechoslovakia 1s highly indus-
trialized and has a well-educated and
skilled labor force Its industry, transport,
energy sources, banking, and most other
means of production are state owned The
country 1s deficient, however, in energy
and many raw materials Moreover, its
aging capital plant lags well behind West
European standards Industry contributes
over 50% to GNP and construction 10%
About 95% of agricultural! land 1s in col-
lectives or state farms The centrally
planned economy has been tightly linked
80
Approved for Release: 2020/08/12 C06554432
in trade (80%) to the USSR and Eastern
Europe Growth has been sluggish, aver-
aging less than 2% in the period 1982-89
GNP per capita ranks next to the GDR as
the highest in the Communist countries
As 1n the rest of Eastern Europe, the
sweeping political changes of 1989 have
been disrupting normal channels of supply
and compounding the government’s eco-
nomic problems Czechoslovakia 1s begin-
ning the difficult transition from a com-
mand to a market economy
GNP: $123 2 billion, per capita $7,878,
real growth rate 1 0% (1989 est )
Inflation rate (consumer prices): 1 5%
(1989)
Unemployment rate: 0 9% (1987)
Budget: revenues $22 4 billion, expendi-
tures $21 9 billion, including capital ex-
penditures of $3 7 billion (1986 state bud-
get)
Exports: $24 5 billion (fo b , 1988), com-
modities—machinery and equipment
58 5%, industrial consumer goods 15 2%,
fuels, minerals, and metals 10 6%, agricul-
tural and forestry products 6 1%, other
products 15 2%, partners—USSR, GDR,
Poland, Hungary, FRG, Yugoslavia, Aus-
tria, Bulgaria, Romania, US
Imports: $23 5 billion (fo b , 1988), com-
modities—machinery and equipment
41 6%, fuels, minerals, and metals 32 2%,
agricultural and forestry products 11 5%,
industrial consumer goods 6 7%, other
products 8 0%; partners—USSR, GDR,
Poland, Hungary, FRG, Yugoslavia, Aus-
tria, Bulgaria, Romania, US
External debt: $7 4 billion, hard currency
indebtedness (1989)
Industrial production: growth rate 2 1%
(1988)
Electricity: 22,955,000 kW capacity,
85,000 million kWh produced, 5,410 kWh
per capita (1989)
Industries: iron and steel, machinery and
equipment, cement, sheet glass, motor ve-
hicles, armaments, chemicals, ceramics,
wood, paper products, footwear
Agriculture: accounts for 15% of GNP
(includes forestry), largely self-sufficient in
food production, diversified crop and live-
stock production, including grains, pota-
toes, sugar beets, hops, fruit, hogs, cattle,
and poultry; exporter of forest products
Aid: donor—$4 2 billion in bilateral aid to
non-Communist less developed countries
(1954-88)
Currency: koruna (plural—koruny), 1 ko-
runa (Ké) = 100 halefu
Exchange rates: koruny (Kés) per US$1—
17 00 (March 1990), 10 00 (1989), 5 63
(1988), 5 43 (1987), 5 95 (1986), 6 79
(1985), 6 65 (1984)
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432
Overview: Hungary’s postwar Communist
government spurred the movement from a
predominantly agricultural to an industri-
alized economy The share of the labor
force in agriculture dropped from over
50% in 1950 to under 20% 1n 1989 Agni-
culture nevertheless remains an important
sector, providing sizable export earnings
and meeting domestic food needs Indus-
try accounts for about 40% of GNP and
30% of employment Nearly three-fourths
of foreign trade is with the USSR and
Eastern Europe Low rates of growth re-
flect the inability of the Soviet-style econ-
omy to modernize capital plant and moti-
vate workers GNP grew about 1% in
1988 and declined by 1% in 1989 Since
1985 external debt has more than dou-
bled, to nearly $20 billion In recent years
Hungary has moved further than any
other East European country in experi-
menting with decentralized and market-
139
Approved for Release: 2020/08/12 C06554432
Hungary (continued)
oriented enterprises These experiments
have failed to jump-start the economy be-
cause of limitations on funds for privati-
zation, continued subsidization of insol-
vent state enterprises, and the leadership’s
reluctance to implement sweeping market
reforms that would cause additional social
dislocations in the short term
GNP: $64 6 billion, per capita $6,108, real
growth rate —1 3% (1989 est )
Inflation rate (consumer prices): 18% (1989
est )
Unemployment rate: 0.4% (1989)
Budget: revenues $14 0 billion, expendi-
tures $14 2 billion, including capital ex-
penditures of $944 million (1988)
Exports: $19 1 billion (f0.b 1988), com-
modities—capital goods 36%, foods 24%,
consumer goods 18%, fuels and minerals
11%, other 11%, partners USSR 48%,
Eastern Europe 25%, developed countries
16%, less developed countries 8% (1987)
Imports: $18 3 billion (cif , 1988), com-
modities-—machinery and transport 28%,
fuels 20%, chemical products 14%, manu-
factured consumer goods 16%, agriculture
6%, other 16%; partners—USSR 43%,
Eastern Europe 28%, less developed coun-
tries 23%, US 3% (1987)
External debt: $19 6 billion (1989)
Industrial production: growth rate 0 6%
(1988)
Electricity: 7,250,000 kW capacity,
30,300 million kWh produced, 2,870 kWh
per capita (1989)
Industries: mining, metallurgy, engineer-
ing industries, processed foods, textiles,
chemicals (especially pharmaceuticals)
Agriculture: including forestry, accounts
for about 15% of GNP and 19% of em-
ployment, highly diversified crop-livestock
farming, principal crops—wheat, corn,
sunflowers, potatoes, sugar beets,
hvestock—hogs, cattle, poultry, dairy
products, self-sufficient in food output
Aid: donor-—$1 8 billion in bilateral aid to
non-Communist less developed countries
(1962-88)
Currency: forint (plural—forints), 1 forint
(Ft) = 100 fillér
Exchange rates: forints (Ft) per US$1—
62 5 (January 1990), 59 2 (1989), 50 413
(1988), 46.971 (1987), 45 832 (1986),
50 119 (1985)
Fiscal year: calendar year','e73e63d2bfb7e9a31c0d3850b37bf5a7074dd5737ab3d0fe7877f64799c8d8f3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b04e2ab1b59afad7eb61c81e897370c74ee5480f55febfe883c71eb407c56c75',1990,'DK','Denmark','economy',244,'Overview: This modern economy features
high-tech agriculture, up-to-date small-
scale and corporate industry, extensive
government welfare measures, comfortable
living standards, and high dependence on
foreign trade Growth in output, however,
has been sluggish in 1987-89, and unem-
ployment in early 1989 stood at 9 6% of
the labor force The government 1s trying
to revitalize growth in preparation for the
economic integration of Europe in 1992
GDP: $73 7 billion, per capita $14,300,
real growth rate 1 4% (1989 est )
81
Approved for Release: 2020/08/12 C06554432
Denmark ( continued)
Inflation rate (consumer prices): 4 25%
(1989 est )
Unemployment rate: 9 6% (1989)
Budget: revenues $34 billion, expenditures
$34 billion, including capital expenditures
of $19 billion (1988)
Exports: $27 7 billion (f 0 b , 1989 est ),
commodities—meat and meat products,
dairy products, transport equipment, fish,
chemicals, industrial machinery,
partners—US 6 0%, FRG, Norway, Swe-
den, UK, other EC, Japan
Imports: $26 4 billion (cif, 1989 est ),
commodities—petroleum, machinery and
equipment, chemicals, grain and
foodstuffs, textiles, paper; partners—US
70%, FRG, Netherlands, Sweden, UK,
other EC
External debt: $41 1 billion (1989 est )
Industrial production: growth rate 0 9%
(1988)
Electricity: 11,215,000 kW capacity,
30,910 million kWh produced, 6,030 kWh
per capita (1989)
Industries: food processing, machinery and
equipment, textiles and clothing, chemical
products, electronics, construction, furni-
ture, and other wood products
Agriculture: accounts for 7% of GNP and
employs | 8% of labor force (includes
fishing), farm products account for nearly
16% of export revenues, principal prod-
ucts—meat, dairy, grain, potatoes, rape,
sugar beets, fish, self-sufficient in food
production
Aid: donor—ODA and OOF commitments
(1970-87) $4 8 billion
Currency: Danish krone (plural—kroner),
1 Damish krone (DKr) = 100 ore
Exchange rates: Danish kroner (DKr) per
US$1—6 560 (January 1990), 7 310
(1989), 6 732 (1988), 6 840 (1987), 8 091
(1986), 10 596 (1985)
Fiscal year: calendar year','65809c50d79067ece4bde6b7725a286766a08b04d22fcd93676fdeb940eb7381','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b1e6743069910236d677325f7601c8c90106bb8d91a936fd329d2eb01ce8913',1990,'DJ','Djibouti','economy',249,'Overview: The economy 1s based on service
activities connected with the country’s
strategic location and status as a free
trade zone Djibouti provides services as
both a transit port for the region and an
international transshipment and refueling
center It has few natural resources and
little industry The nation 1s, therefore,
heavily dependent on foreign assistance to
help support its balance of payments and
to finance development projects An unem-
ployment rate of over 50% continues to be
a major problem
GNP: $333 mullion, $1,070 per capita,
real growth rate —0 7% (1986)
Inflation rate (consumer prices): 8 0%
(1987)
Unemployment rate: over 50% (1987)
Budget: revenues $117 million, expendi-
tures $163 billion, including capital expen-
ditures of $52 million (1987 est )
Exports: $128 million (f 0 b, 1986), com-
modities—hides and skins, coffee (in tran-
sit), partners—Middle East 50%, Africa
43%, Western Europe 7%
Imports: $198 million (fo b , 1986), com-
modities—foods, beverages, transport
equipment, chemicals, petroleum products;
partners—EC 36%, Africa 21%, Bahrain
14%, Asia 12%, US 2%
External debt: $250 million (December
1988)
Industrial production: growth rate —1 6%
(1986)
Electricity: 110,000 kW capacity, 190 mil-
lion kWh produced, 580 kWh per capita
(1989)
Industries: limited to a few small-scale
enterprises, such as dairy products and
mineral-water bottling
Agriculture: accounts for 30% of GDP,
scanty rainfall limits crop production to
mostly fruit and vegetables, half of popu-
lation pastoral nomads herding goats,
sheep, and camels, imports bulk of food
needs
Aid: US commitments, including Ex-Im
(FY78-88), $36 million, Western (non-US)
countries, including ODA and OOF bilat-
eral commitments (1970-87), $962 mullion,
OPEC bilateral aid (1979-89), $149 mil-
lion; Communist countries (1970-88), $35
millon
Currency: Djiboutian franc (plural—
francs), 1 Dyboutian franc (DF) = 100
centimes
Exchange rates: Dj:boutian francs (DF)
per US$1—177 721 (fixed rate since 1973)
Fiscal year: calendar year','8e6408ab2fe2d494987de965523f97109d66754d63cc1ce332001400d8332297','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56818bd53987e11ce2cd73b59cd84757c4aee684c025a8da7127c9bfb2badbfe',1990,'DM','Dominica','economy',254,'Overview: The economy 1s dependent on
agriculture and thus 1s highly vulnerable
to climatic conditions Agriculture
accounts for about 30% of GDP and em-
ploys 40% of the labor force Principal
products include bananas, coconuts, citrus,
and root crops In 1988 the economy
achieved a 5 6% growth in real GDP on
the strength of a boost tn construction,
higher agricultural production, and
growth of the small manufacturing sector
based on soap and garment industries
The tourist industry remains undeveloped
because of a rugged coastline and the lack
of an international-class airport
GDP: $137 million, per capita $1,408, real
growth rate 5 6% (1988 est )
Inflation rate (consumer prices): 4 9%
(1987)
Unemployment rate: 10% (1989 est )
Budget: revenues $60 million, expenditures
$52 million, including capital expenditures
of $18 million (FY88)
Exports: $46 million (f 0 b , 1987), com-
modities—bananas, coconuts, grapefruit,
soap, galvanized sheets, partners—UK
72%, Jamaica 10%, OECS 6%, US 3%,
other 9%
Imports: $66 0 million (c1 f , 1987), com-
modities—food, oils and fats, chemicals,
fuels and lubricants, manufactured goods,
machinery and equipment, partners—US
23%, UK 18%, CARICOM 15%, OECS
15%, Japan 5%, Canada 3%, other 21%
External debt: $63 6 million (December
1987)
Industrial production: growth rate 5 9% in
manufacturing (1987)
Electricity: 7,000 kW capacity, 16 million
kWh produced, 190 kWh per capita
(1989)
Industries: agricultural processing, tour-
ism, soap and other coconut-based prod-
ucts, cigars, pumice mining
Agriculture: accounts for 30% of GDP,
principal crops—bananas, citrus fruit, co-
conuts, root crops, bananas provide the
bulk of export earnings, forestry and fish-
eries potential not exploited
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $109 million
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: 1 July-30 June','9fcc37a50ce95a54ed675602b8f916adedb33f7bcaaf3dd6c79cac4071453e80','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b169c07d8b96476581192391774b92fe231e70abc19cb86fb12dab9f0016aab',1990,'DO','Dominican Republic','economy',259,'Overview: The economy ts largely depen-
dent on the agricultural sector, which em-
ploys 50% of the labor force and provides
about half of export revenues The princi-
pal commercial crop 1s sugarcane,
followed by coffee, cocoa, and tobacco
Industry 1s based on the processing of ag-
ricultural products, durable consumer
goods, minerals, and chemicals Rapid
growth of free trade zones has established
a significant expansion of manufacturing
for export, especially wearing apparel
Over the past decade tourism has also in-
creased in importance and 1s a significant
earner of foreign exchange and a source
of new jobs Unemployment 1s officially
reported at about 25%, but underemploy-
ment may be much higher
GDP: $5 1 billion, per capita $790, real
growth rate 0 5% (1988)
Inflation rate (consumer prices): 57 6%
(1988)
Unemployment rate: 25% (1988)
Budget: revenues $413 million, expendi-
tures $522 million, including capital ex-
penditures of $218 million (1988)
Exports: $711 mullion (f ob , 1988), com-
modaities—sugar, coffee, cocoa, gold, fer-
ronickel; partners—US, including Puerto
Rico, 74%
Imports: $1 8 billion (cif , 1988), com-
modities—foodstuffs, petroleum, cotton
and fabrics, chemicals and pharmaceuti-
cals, partners—US, including Puerto
Rico, 37% (1985)
External debt: $3 6 billion (1989) est
Industrial production: growth rate 30%
(1987 est )
Electricity: 1,376,000 kW capacity; 4,000
million kWh produced, 560 kWh per cap-
ita (1989)
Industries: tourism, sugar processing, fer-
ronickel and gold mining, textiles, cement,
tobacco
Agriculture: accounts for 18% of GDP and
employs 49% of labor force, sugarcane
most important commercial crop, followed
by coffee, cotton, and cocoa, food crops—
rice, beans, potatoes, corn, bananas, ani-
mal output—<attle, hogs, dairy products,
meat, eggs, not self-sufficient in food
Aid: US commitments, including Ex-Im
(FY70-88), $1 1 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $529 million
Currency: Dominican peso (plural—pesos),
1 Dominican peso (RD$) = 100 centavos
Exchange rates: Dominican pesos per
US$1—6 3400 (January 1990), 6 3400
Approved for Release: 2020/08/12 C06554432
(1989), 6 1125 (1988), 3 8448 (1987),
2 9043 (1986), 3 1126 (1985)
Fiscal year: calendar year','4b1fd9f2dd3bec9148c118237139970fad2bb68fa8dec8a6a0a5e738343694cf','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75f3b6036c05ed3d82c3e7d174109d004310dd6c00bfa63f6531db21dbdcdc7a',1990,'EC','Ecuador','economy',262,'Overview: Ecuador continues to recover
from a 1986 drop in international oil
prices and a major earthquake in 1987
that interrupted oil exports for six months
and forced Ecuador to suspend foreign
debt payments In 1988-89 o1! exports re-
covered—accounting for nearly half of
Ecuador’s total export revenues—and
Quito resumed full interest payments on
its official debt, and partial payments on
its commercial debt The Borja adminis-
tration has pursued austere economic poli-
cies that have helped reduce inflation and
restore international reserves Ecuador
was granted an IMF standby agreement
worth $135 million in 1989, and Quito
will seek to reschedule its foreign com-
mercial debt in 1990
GDP: $9 8 billion, per capita $935, real
growth rate 0 5% (1989)
Inflation rate (consumer prices): 54%
(1989)
Unemployment rate: 14 3% (1988)
Budget: revenues $2 2 billion, expenditures
$2 7 billion, including capital expenditures
of $601 million (1988 est )
Exports: $2 2 billion (f 0 b , 1988), com-
modities—petroleum 47%, coffee,
bananas, cocoa products, shrimp, fish
products, partners—US 58%, Latin Amer-
ica, Caribbean, EC countries
Imports: $1 6 billion (fob, 1988), com-
modities—transport equipment, vehicles,
machinery, chemical, petroleum,
partners—US 28%, Latin America, Car-
ibbean, EC, Japan
External debt: $10 9 billion (1989)
Industrial production: growth rate 0 7%
(1988)
Electricity: 1,953,000 kW capacity, 5,725
million kWh produced, 560 kWh per cap-
ita (1989)
Industries: food processing, textiles, chemi-
cals, fishing, timber, petroleum
Agriculture: accounts for 18% of GDP and
35% of labor force (including fishing and
forestry), leading producer and exporter of
bananas and balsawood, other exports—
coffee, cocoa, fish, shrimp; crop produc-
tion—rice, potatoes, manioc, plantains,
sugarcane; livestock sector—cattle, sheep,
hogs, beef, pork, dairy products, net 1m-
porter of foodgrain, dairy products, and
sugar
Illicit drugs: relatively small producer of
coca following the successful eradication
campaign of 1985-87, significant transit
88
Approved for Release: 2020/08/12 C06554432
country, however, for derivatives of coca
originating in Colombia, Bolivia, and Peru
Aid: US commitments, including Ex-Im
(FY70-88), $457 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 4 billion,
Communist countries (1970-88), $64 mil-
lion
Currency: sucre (plural—sucres), 1 sucre
(S/) = 100 centavos
Exchange rates: sucres (S/) per US$1—
526 35 (1989), 301 61 (1988), 170 46
(1987), 122 78 (1986), 69 56 (1985)
Fiscal year: calendar year','a5acb04df18fff72e089c039077240e4ce17c5e7c9cea56534a46fbca1f05a7e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('313b5ac9abc42450c8c9c677fbd30fc4c49b54766ac8189d8d7493be8d9fbf88',1990,'EG','Egypt','economy',267,'Overview: Egypt has one of the largest
public sectors of all the Third World
economies, most industrial plants being
owned by the government Overregulation
holds back technical modernization and
foreign investment Even so, the economy
grew rapidly during the late 1970s and
early 1980s, but in 1986 the collapse of
world oil prices and an increasingly heavy
burden of debt servicing led Egypt to be-
gin negotiations with the IMF for
balance-of-payments support As part of
the 1987 agreement with the IMF, the
government agreed to institute a reform
program to reduce inflation, promote eco-
nomic growth, and improve its external
position The reforms have been slow in
coming, however, and the economy has
been largely stagnant for the past three
years With 1 million people being added
every eight months to Egypt’s population,
urban growth exerts enormous pressure on
the 5% of the total land area available for
agriculture
GDP: $38 3 billion, per capita $700, real
growth rate I 0% (1989 est )
Inflation rate (consumer prices): 25% (1989
est )
Unemployment rate: 15% (1989 est )
Budget: revenues $7 billion, expenditures
$11 5 billion, including capital expendi-
tures of $4 billion (FY89 est )
Exports: $2 55 billion (fo b, 1989), com-
modities—raw cotton, crude and refined
petroleum, cotton yarn, textiles,
partners—US, EC, Japan, Eastern Europe
Imports: $10 1 billion (cif, 1988), com-
modities—foods, machinery and equip-
ment, fertilizers, wood products, durable
consumer goods, capital goods, partners—
US, EC, Japan, Eastern Europe
External debt: $45 billion (December
1989)
89
Approved for Release: 2020/08/12 C06554432
Egypt (continued)
Industrial production: growth rate 2-4%
(1989 est )
Electricity: 11,273,000 kW capacity,
42,500 million kWh produced, 780 kWh
per capita (1989)
Industries: textiles, food processing, tour-
ism, chemicals, petroleum, construction,
cement, metals
Agriculture: accounts for 20% of GNP
and employs more than one-third of labor
force, dependent on irrigation water from
the Nile, world’s fifth-largest cotton ex-
porter, other crops produced include rice,
corn, wheat, beans, fruit, vegetables, not
self-sufficient in food, livestock—cattle,
water buffalo, sheep, and goats, annual
fish catch about 140,000 metric tons
Aid: US commitments, including Ex-Im
(FY70-88), $14 7 billion, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $7 8 billion,
OPEC bilateral aid (1979-89), $2 9 billion,
Communist countries (1970-88), $2 4 bil-
lion
Currency: Egyptian pound (plural—
pounds), 1 Egyptian pound (E) = 100 pias-
ters
Exchange rates: Egyptian pounds (E) per
US$1—2 5790 (January 1990), 2 5171
(1989), 2 2128 (1988), 1 SOLS (1987),
1 3503 (1986), 1 3010 (1985)
Fiscal year: 1 July-30 June
Overview: The economy experienced a
modest recovery during the period 1983-
86, after a sharp decline in the early
1980s Real GDP grew by 1 5% a year on
the strength of value added by the manu-
facturing and service sectors In 1987 the
economy expanded by 2 5% as agricul-
tural output recovered from the 1986
drought The agricultural sector accounts
for 25% of GDP, employs about 40% of
the labor force, and contributes about
66% to total exports Coffee is the major
commercial crop, contributing 60% to ex-
port earnings The manufacturing sector,
based largely on food and beverage pro-
cessing, accounts for 17% of GDP and
16% of employment Economic losses due
to guerrilla sabotage total more than $2 0
91
Approved for Release: 2020/08/12 C06554432
EI Salvador (continued)
billion since 1979 The costs of maintain-
ing a large military seriously constrain the
government’s ability to provide essential
social services
GDP: $5 5 billion, per capita $1,020
(1988), real growth rate 0 9% (1989 est )
Inflation rate (consumer prices): 16 8%
(September 1989)
Unemployment rate: 10% (1989)
Budget: revenues $688 million, expendi-
tures $725 million, including capital ex-
penditures of $112 million (1988)
Exports: $497 million (f 0 b , 1989), com-
modities—coffee 60%, sugar, cotton,
shrimp, partners—-US 49%, FRG 24%,
Guatemala 7%, Costa Rica 4%, Japan 4%
Imports: $1 1 billion (c.i f , 1989), com-
modities—petroleum products, consumer
goods, foodstuffs, machinery, construction
materials, fertilizer, partners—US 40%,
Guatemala 12%, Venezuela 7%, Mexico
71%, FRG 5%, Japan 4%
External debt: $1 7 billion (December
1989)
Industrial production: growth rate 2 9%
(1989)
Electricity: 669,000 kW capacity; 1,813
million kWh produced, 350 kWh per cap-
ita (1989)
Industries: food processing, textiles, cloth-
ing, petroleum products, cement
Agriculture: accounts for 25% of GDP and
40% of labor force (including fishing and
forestry), coffee most important commer-
cial crop, other products—sugarcane,
corn, rice, beans, oilseeds, beef, dairy
products, shrimp, not self-sufficient 1n food
Aid: US commitments, including Ex-Im
(FY70-88), $2 4 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $353 million
Currency: Salvadoran colén (plural—colo-
nes), 1 Salvadoran colén (C) = 100 cen-
tavos
Exchange rates: Salvadoran colones (C)
per US$1—5 0000 (fixed rate since 1986)
Fiscal year: calendar year','2f615917e368dc73c23fc286937b6d31a62ee37d7b58a958801c2db048f02197','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41a286adccddaa71c4eaa7fd4a902d7db96920b94eea6569be67ddab8fb5f879',1990,'GN','Guinea','economy',274,'Overview: The economy, destroyed during
the regime of former President Macias
Nguema, 1s now based on agriculture, for-
estry, and fishing, which account for about
60% of GNP and nearly all exports Sub-
sistence agriculture predominates, with
cocoa, coffee, and wood products providing
income, foreign exchange, and government
revenues There 1s little industry Com-
merce accounts for about 10% of GNP,
and the construction, public works, and
service sectors for about 34% Undevel-
oped natural resources include titanium,
iron ore, manganese, uranium, and allu-
vial gold Ol exploration is taking place
under concessions offered to US, French,
and Spanish firms
GNP: $103 million, per capita $293, real
growth rate NA% (1987)
Inflation rate (consumer prices): —6 0%
(1988 est )
Unemployment rate: NA%
Budget: revenues $23 million, expenditures
$31 million, including capital expenditures
of NA (1988)
Exports: $30 million (fo b, 1988 est ),
commodities—coffee, timber, cocoa beans,
partners—Spain 44%, FRG 19%, Italy
12%, Netherlands 11% (1987)
Imports: $50 million (cif , 1988 est ),
commodities—petroleum, food, beverages,
clothing, machinery, partners—Spain
34%, Italy 16%, France 14%, Netherlands
8% (1987)
External debt: $191 million (December
1988)
Industrial production: growth rate NA%
Electricity: 23,000 kW capacity, 60 mil-
hon kWh produced, 170 kWh per capita
(1989)
Industries: fishing, sawmilling
Agriculture: cash crops—timber and coffee
from Rio Muni, cocoa from Bioko, food
crops—rice, yams, cassava, bananas, oil
palm nuts, manioc, livestock
Aid: US commitments, including Ex-Im
(FY81-88), $11 millon, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $100 million, Com-
munist countries (1970-88), $55 million
Currency: Communauté Financiére Afri-
caine franc (plural—franes), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: 1 April-31 March
Overview: Although possessing many natu-
ral resources and considerable potential
for agricultural development, Guinea is
one of the poorest countries in the world
The agricultural sector contributes about
40% to GDP and employs more than 80%
of the work force, while industry accounts
for about 25% of GDP Guinea possesses
over 25% of the world’s bauxite reserves,
exports of bauxite and alumina accounted
for more than 80% of total exports in
1986
GDP: $2 5 billion, per capita $350, real
growth rate 5 0% (1988)
Inflation rate (consumer prices): 27 0%
(1988)
Unemployment rate: NA%
Budget: revenues $357 million, expendi-
tures $480 million, including capital ex-
penditures of $229 million (1988 est )
Exports: $553 million (f 0b, 1988 est ),
commoadities—alumina, bauxite,
diamonds, coffee, pineapples, bananas,
palm kernels, partners—US 33%, EC
33%, USSR and Eastern Europe 20%,
Overview: Indonesia 1s a mixed economy
with many socialist institutions and cen-
tral planning but with a recent emphasis
on deregulation and private enterprise
Indonesia has extensive natural wealth
but, with a large and rapidly increasing
population, 1t remains a poor country
GNP growth in 1985-89 averaged about
4%, somewhat short of the 5% rate needed
to absorb the 2 3 million workers annually
entering the labor force Agriculture, 1n-
cluding forestry and fishing, is the most
important sector, accounting for 21% of
GDP and over 50% of the labor force
The staple crop is rice Once the world’s
largest rice importer, Indonesia 1s now
nearly self-sufficient Plantation crops—
rubber and palm oil—are being encour-
aged for both export and job generation
The diverse natural resources include
crude oil, natural gas, timber, metals, and
coal Of these, the oil sector dominates the
external economy, generating more than
20% of the government’s revenues and
40% of export earnings in 1989 Japan 1s
Indonesia’s most important customer and
supplier of aid
GNP: $80 billion, per capita $430, real
growth rate 5 7% (1989 est )
Inflation rate (consumer prices): 5 5%
(1989)
Unemployment rate: 3 1% (1989 est )
Budget: revenues $20 9 billion, expendi-
tures $20 9 billion, including capital ex-
penditures of $7 5 billion (FY89)
Exports: $21 0 billion (fob, 1989 est );
commodities—petroleum and liquefied
natural gas 40%, timber 15%, textiles 7%,
rubber 5%, coffee 3%, partners—Japan
42%, US 16%, Singapore 9%, EC 11%
(1988)
Imports: $13 2 billion (fob, 1989 est ),
commodities—machinery 39%, chemical
products 19%, manufactured goods 16%,
partners—Japan 26%, EC 19%, US 13%,
Singapore 7% (1988)
External debt: $55 0 billion, medium and
long-term (1989 est )
Industrial production: growth rate 4 8%
(1988 est )
Electricity: 11,600,000 kW capacity,
38,000 million kWh produced, 200 kWh
per capita (1989)
Industries: petroleum, textiles, mining,
cement, chemical fertilizer production,
timber, food, rubber
Agriculture: subsistence food production,
small-holder and plantation production for
export; rice, cassava, peanuts, rubber, co-
coa, coffee, copra, other tropical products
Illicit drugs: illicit producer of cannabis
for the international drug trade, but not a
146
Approved for Release: 2020/08/12 C06554432
major player, government actively eradi-
cating plantings and prosecuting
traffickers
Aid: US commitments, including Ex-Im
(FY70-88), $4 2 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $19 8 billion, OPEC
bilateral aid (1979-89), $213 million,
Communist countries (1970-88), $175 mil-
hon
Currency: Indonesian rupiah (plural—ru
piahs), 1 Indonesian rupiah (Rp) = 100
sen (sen no longer used)
Exchange rates: Indonesian rupiahs (Rp)
per US$1—1,804 9 (January 1990),
1,770 1 (1989), 1,685 7 (1988), 1,643 8
(1987), 1,282 6 (1986), 1,110 6 (1985)
Fiscal year: 1 April-31 March
Overview: Since the 1979 revolution, the
banks, petroleum industry, transportation,
utilities, and mining have been national-
ized, but the new five-year plan—the first
since the revolution—passed in January
1990, calls for the transfer of many
government-controlled enterprises to the
private sector War-related disruptions,
massive corruption, mismanagement, de-
mographic pressures, and 1deological ri-
gidities have kept economic growth at de-
pressed levels Oil accounts for 90% of
export revenues A combination of war
damage and low oil prices brought a 2%
drop in GNP in 1988 GNP probably rose
slightly in 1989, considerably short of the
3 4% population growth rate in 1989
Heating oil and gasoline are rationed Ag-
riculture has suffered from the war, land
reform, and shortages of equipment and
materials The five-year plan seeks to rein-
vigorate the economy by increasing the
role of the private sector, boosting nonoil
income, and securing foreign loans The
plan 1s overly ambitious but probably will
generate some short-term relief
GNP: $97 6 billion, per capita $1,800, real
growth rate 0-1% (1989)
Inflation rate (consumer prices): 50-80%
(1989)
Unemployment rate: 30% (1989)
Budget: revenues $NA, expenditures $55 1
billion, including capital expenditures of
$11 5 billion (FY88 est )
Exports: $12 3 billion (fob, 1988), com-
modities—petroleum 90%, carpets, fruits,
nuts, hides; partners—Japan, Turkey, It-
aly, Netherlands, Spain, France, FRG
Imports: $12 0 billion (c1 f , 1988), com-
modities—machinery, military supplies,
metal works, foodstuffs, pharmaceuticals,
technical services, refined oil products,
partners—FRG, Japan, Turkey, UK, Italy
External debt: $4-5 billion (1989)
Industrial production: growth rate NA%
Electricity: 14,579,000 kW capacity,
40,000 million kWh produced, 740 kWh
per capita (1989)
Industries: petroleum, petrochemicals, tex-
tiles, cement and other building materials,
food processing (particularly sugar refining
and vegetable oil production), metal fabri-
cating (steel and copper)
Agriculture: principal products—trice,
other grains, sugar beets, fruits, nuts, cot-
ton, dairy products, wool, caviar, not self-
sufficient in food
Illicit drugs: illicit producer of opium
poppy for the domestic and international
drug trade
148
Approved for Release: 2020/08/12 C06554432
Aid: US commitments, including Ex-Im
(FY70-80), $1.0 billion; Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 5 billion, Commu-
nist countries (1970-88), $976 million,
note—aid fell sharply following the 1979
revolution
Currency: Iranian rial (plural—rials), 1
Iraman nal (IR) = 100 dinars, note—do
mestic figures are generally referred to in
terms of the toman (plural—tomans),
which equals 10 rials
Exchange rates: Iranian rials (IR) per
US$1—70 019 (January 1990), 72 015
(1989), 68 683 (1988), 71 460 (1987),
78 760 (1986), 91 052 (1985)
Fiscal year: 21 March-20 March','710a627724cc9246cdf93306b8083d8072cd5eddb2dcf03843e7838f361342fe','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c17552f29ac56a6b4997eefc1d0bebdb89f52da57223f4325c34e02f576cb618',1990,'FR','France','economy',282,'Overview: The economy is based on sheep
farming, which directly or indirectly em-
ploys most of the work force A few dairy
herds are kept to meet domestic consump-
tion of milk and milk products, and crops
grown are primarily those for providing
winter fodder Mayor sources of income
are from the export of high-grade wool to
the UK and the sale of stamps and coins
Rich stocks of fish in the surrounding wa-
ters are not presently exploited by the 1s-
landers, but development plans called for
the islands to have six trawlers by 1989
In 1987 the government began to sell
fishing licenses to foreign trawlers operat-
ing within the Falklands exclusive fishing
zone These license fees amount to more
than $25 million per year To encourage
tourism, the Falkland Islands Develop-
ment Corporation has built three lodges
for visitors who are attracted by the abun-
dant wildlife and trout fishing
GNP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices): NA%
Unemployment rate: 0%
Budget: revenues $11 million, expenditures
$11 8 million, including capital expendi-
tures of $1 2 million (FY87)
Exports: at least $14 7 million, commod-
ties—wool, hides and skins, and other,
partners—UK, Netherlands, Japan (1987
est )
Imports: at least $13 9 million, commodi-
tres—food, clothing, fuels, and machinery,
partners—UK, Netherlands Antilles (Cu-
ragao), Japan (1987 est )
External debt: $NA
Industrial production: growth rate NA%
Electricity: 9,200 kW capacity, 17 million
kWh produced, 8,700 kWh per capita
(1989)
Industries: wool processing
Agriculture: predominantly sheep farming,
small dairy herds and fodder crops
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $102 millon
Currency: Falkland pound (plural—
pounds), 1 Falkland pound (£F) = 100
pence
Exchange rates: Falkland pound (£F) per
US$1—0 6055 (January 1990), 0 6099
(1989), 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985), note—the
Falkland pound 1s at par with the British
pound
Fiscal year: 1 April-31 March
Overview: Since 1962, when France sta-
tioned military personnel in the region,
French Polynesia has changed from a sub-
sistence economy to one in which a high
proportion of the work force 1s either em-
ployed by the military or supports the
tourist industry Tourism accounts for
about 20% of GDP and 1s a primary
source of hard currency earnings
GDP: $2 24 billion, per capita $6,400, real
growth rate NA% (1986)
Inflation rate (consumer prices): | 2%
(1987)
Unemployment rate: 8% (1986 est )
Budget: revenues $431, expenditures $418,
including capital expenditures of $NA
(1986)
Exports: $75 million (f 0 b , 1987), com-
modities—coconut products 79%, mother-
of-pearl 14%, vanilla, shark meat, part-
ners—France 44%, US 21%
Imports: $767 million (cif , 1986), com-
modities—fuels, foodstuffs, equipment,
partners—France 50%, US 16%, New
Zealand 6%
External debt: $NA
Industrial production: growth rate NA%
Electricity: 72,000 kW capacity, 265 mil-
hon kWh produced, 1,350 kWh per capita
(1989)
Industries: tourism, pearls, agricultural
processing, handicrafts
Agriculture: coconut and vanilla planta-
tions, vegetables and fruit, poultry, beef,
dairy products
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $3 6 billion
Currency: Comptoirs Francais du Paci-
fique franc (plural—francs), 1 CFP franc
(CFPF) = 100 centimes
Exchange rates: Comptoirs Francais du
Pacifique francs (CFPF) per US$1—
104 71 (January 1990), 115 99 (1989),
108 30 (1988), 109 27 (1987), 125 92
(1986), 163 35 (1985), note—linked at the
rate of 18 18 to the French franc
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432
Overview: Economic activity 1s limited to
servicing meteorological and geophysical
research stations and French and other
fishing fleets The fishing catches landed
on Iles Kerguelen by foreign ships are ex-
ported to France and Reunion
Overview: The economy depends on agni-
culture, tourism, light industry, and ser-
vices It is also dependent upon France for
large subsidies and income and social
transfers Tourism ts a key industry, with
most tourists from the US In addition, an
increasingly large number of cruise ships
visit the islands The traditionally impor-
tant sugarcane crop 1s slowly being re-
placed by other crops, such as bananas
(which now supply about 50% of export
earnings), eggplant, and flowers Other
vegetables and root crops are cultivated
for local consumption, although Guade-
loupe 1s still dependent on imported food,
which comes mainly from France Light
industry consists mostly of sugar and rum
production Most manufactured goods and
fuel are imported Unemployment 1s espe-
cially high among the young
GDP: $1 1 billion, per capita $3,300, real
growth rate NA% (1987)
Inflation rate (consumer prices): 3 0%
(1987)
Unemployment rate: 25% (1983)
Budget: revenues $251 million, expendi-
tures $251 million, including capital ex-
penditures of NA (1985)
Exports: $109 milhon (f ob, 1986), com-
modities—bananas, sugar, rum,
partners—France 72%, Martinique 16%
(1984)
Imports: $792 million (cif, 1986), com-
modities—vehicles, foodstuffs, clothing
and other consumer goods, construction
materials, petroleum products, partners—
France 59% (1984)
External debt: $NA
Industrial production: growth rate NA%
Electricity: 103,000 kW capacity, 315 mil-
lion kWh produced, 920 kWh per capita
(1989)
Industries: construction, cement, rum,
Sugar, tourism
Agriculture: cash crops—bananas and sug-
arcane, other products include tropical
fruits and vegetables, livestock—cattle,
pigs, and goats, not self-sufficient in food
Aid: US commitments, including Ex-Im
(FY70-87), $4 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $7 7 billion
Currency: French franc (plural—francs), |
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Fiscal year: calendar year
Overview: The Ivory Coast 1s among the
world’s largest producers and exporters of
coffee, cocoa beans, and palm-kernel oil
Consequently, the economy 1s highly sen-
sitive to fluctuations in international prices
for coffee and cocoa and to weather condi-
tions Despite attempts by the government
to diversify, the economy 1s still largely
dependent on agriculture and related 1n-
dustries The agricultural sector accounts
for over one-third of GDP and about 80%
of export earnings and employs about 85%
of the labor force A collapse of world co-
coa and coffee prices in 1986 threw the
economy into a recession, from which the
country had not recovered by 1989
GDP: $100 billion, per capita $900, real
growth rate —6 4% (1988)
157
Approved for Release: 2020/08/12 C06554432
Ivory Coast (continued)
Inflation rate (consumer prices): 7 5%
(1988)
Unemployment rate: 14% (1985)
Budget: revenues $1 6 billion (1986), ex-
penditures $2.3 billion, including capital
expenditures of $504 million (1988 est )
Exports: $2 2 billion (f 0 b., 1988), com-
modities—cocoa 30%, coffee 20%, tropical
woods 11%, cotton, bananas, pineapples,
palm oil, cotton, partners—France, FRG,
Netherlands, US, Belgium, Spain (1985)
Imports: $1 3 billion (fob, 1988), com-
modities—manufactured goods and semi-
finished products 50%, consumer goods
40%, raw matertals and fuels 10%, part-
ners—France, other EC, Nigeria, US, Ja-
pan (1985)
External debt: $14 7 billion (1989 est )
Industrial production: growth rate 0%
(1987)
Electricity: 1,081,000 kW capacity, 2,440
million kWh produced, 210 kWh per cap-
ita (1989)
Industries: foodstuffs, wood processing, oil
refinery, automobile assembly, textiles,
fertilizer, beverage
Agriculture: most important sector, con-
tributing one-third to GDP and 80% to
exports, cash crops include coffee, cocoa
beans, timber, bananas, palm kernels, rub-
ber, food crops—corn, rice, manioc, sweet
potatoes; not selfsufficient in bread grain
and dairy products
Illicit drugs: illicit producer of cannabis on
a small scale for the international drug
trade
Aid: US commitments, including Ex-Im
(FY70-87), $344 million; Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $4 6 bilhon
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 O01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year
Iverview: Economic activity traditionally
ias been based on agriculture and the
sreeding of livestock—Mongolia has the
ughest number of livestock per person in
he world In recent years extensive min-
:ral resources have been developed with
Soviet support The mining and processing
of coal, copper, molybdenum, tin, tung-
rten, and gold account for a large part of
ndustrial production
SDP: $1 7 billion, per capita $880 (1985
2st ), average real growth rate 3 6% (1976-
35 est )
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $2 2 billion, expenditures
$2 19 billion, including capital expendi-
tures of $09 billion (1987 est )
Exports: $388 million (fob, 1985), com-
modities—livestock, animal products,
wool, hides, fluorspar, nonferrous metals,
minerals, partners—nearly all trade with
Communist countries (about 80% with
USSR)
Imports: $1 0 billion (cif , 1985), com-
modities—machinery and equipment, fu-
els, food products, industrial consumer
goods, chemicals, building materials,
sugar, tea, partners—nearly all trade with
Communist countries (about 80% with
USSR)
External debt: $NA
Industrial production: growth rate 10 9%
(1985)
Electricity: 657,000 kW capacity, 29,500
million kWh produced, 1,340 kWh per
capita (1989)
Industries: processing of animal products,
building materials, food and beverage,
mining (particularly coal)
Agriculture: accounts for 90% of exports
and provides livelihood for about 50% of
the population, livestock raising predomi-
Approved for Release: 2020/08/12 C06554432
nates (sheep, goats, horses), crops—wheat,
barley, potatoes, forage
Aid: about $500-$700 million annually
from USSR
Currency: tughrik (plural—tughriks), 1
tughrik (Tug) = 100 mongos
Exchange rates: tughriks (Tug) per
US$1—3 355 (1986-1988), 3 600 (1985)
Fiscal year: calendar year
Overview: Agriculture, dominated by ba-
nana production, is the most important
sector of the economy, providing employ-
ment for over 60% of the labor force and
270
Approved for Release: 2020/08/12 C06554432
contributing about 20% to GDP The ser-
vices sector 1s next in importance, based
mostly on a growing tourist industry The
economy continues to have a high unem-
ployment rate of 30% because of an over-
dependence on the weather-plagued ba-
nana crop as a major export earner
Government progress toward diversifying
into new industries has been relatively un-
successful.
GDP: $136 million, per capita $1,305, real
growth rate 8 4% (1988)
Inflation rate (consumer prices): 2 0%
(1988)
Unemployment rate: 30% (1989 est )
Budget: revenues $42 7 million, expendi-
tures $67 5 million, including capital ex-
penditures of $25 8 (FY88)
Exports: $63 8 million (fo b , 1986), com-
modities—bananas, eddoes and dasheen
(taro), arrowroot starch, copra, partners—
CARICOM 60%, UK 27%, US 10%
Imports: $87 3 million (c1f , 1986), com-
modities—foodstuffs, machinery and
equipment, chemicals and fertilizers, min-
erals and fuels, partners—US 37%, CA-
RICOM 18%, UK 13%
External debt: $35 million (July 1987)
Industrial production: growth rate —1 2%
(1986)
Electricity: 16,600 kW capacity, 64 mil-
lion kWh produced, 610 kWh per capita
(1989)
Industries: food processing (sugar, flour),
cement, furniture, rum, starch, sheet
metal, beverage
Agriculture: accounts for 20% of GDP and
60% of labor force; provides bulk of ex-
ports, products—bananas, arrowroot
(world’s largest producer), coconuts, sweet
potatoes, spices, small numbers of cattle,
sheep, hogs, goats, small fish catch used
locally
Aid: US commitments, including Ex-Im
(FY70-87), $11 million; Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $71 million
Currency: East Caribbean dollar (plural—
dollars); 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: 1 July-30 June
Overview: Economic progress in the West
Bank has been hampered by Israel: mili-
tary occupation and the effects of the Pal-
estinian uprising Industries using
advanced technology or requiring sizable
financial resources have been discouraged
by a lack of financial resources and Israeli
policy Capital investment has largely
gone into residential housing, not into pro-
ductive assets that could compete with
Israeli industry A major share of GNP 1s
derived from remittances of workers em-
ployed in Israel and neighboring Gulf
states Israeli reprisals against Palestinian
unrest in the West Bank since 1987 have
pushed unemployment up and lowered
living standards
GNP: $1 0 billion, per capita $1,000, real
growth rate — 15% (1988 est )
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $47 4 million, expendi-
tures $45 7 million, including capital ex-
penditures of NA (FY86)
Exports: $150 million (fo b, 1988 est ),
commodities—NA, partners—Jordan,','b4fd67989d6d6df1342c5de74f66560d1c6012d892c0f4dcefcd93243debd753','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb695c595c8a2a7da7902f46a5e4b1adc8c860321cda6478305d057f246bc8cf',1990,'FO','Faroe Islands','economy',287,'Overview: The Faroese enjoy the high
standard of living characteristic of the
Danish and other Scandinavian econo-
mies Fishing is the dominant economic
activity It employs over 25% of the labor
force, accounts for about 25% of GDP,
and contributes over 80% to export reve-
nues A handicraft industry employs about
20% of the labor force Because of cool
summers agricultural activities are limited
to raising sheep and to potato and vegeta-
ble cultivation There 1s a labor shortage,
and immigrant workers accounted for 5%
of the work force in 1989 Denmark annu-
ally subsidizes the economy, perhaps on
the order of 15% of GDP
GDP: $662 million, per capita $14,000,
real growth rate 3% (1989 est )
Inflation rate (consumer prices): 2 0%
(1988)
Unemployment rate: labor shortage
Budget: revenues $176 million, expendi-
tures $176 million, including capital ex-
penditures of NA (FY86)
Exports: $267 million (f ob , 1986), com-
modities—fish and fish products 86%, ami-
mal feedstuffs, transport equipment, part-
ners—Denmark 18%, US 14%, FRG,
France, UK, Canada
Imports: $363 million (cif, 1986), com-
modities—machinery and transport equip-
ment 38%, food and livestock 11%, fuels
10%, manufactures 10%, chemicals 5%,
partners Denmark 46%, FRG, Norway,
Japan, UK
External debt: $NA
Industrial production: growth rate NA%
Electricity: 80,000 kW capacity, 280 mil-
lion kWh produced, 5,910 kWh per capita
(1989)
Industries: fishing, shipbuilding, handi-
crafts
Agriculture: accounts for 27% of GDP and
employs 27% of labor force, principal
crops—potatoes and vegetables,
livestock—sheep, annual fish catch about
360,000 metric tons
Aid: none
Currency: Danish krone (plural—kroner),
1 Danish krone (DKr) = 100 ore
Exchange rates: Danish kroner (DKr) per
US3$1—6 560 (January 1990), 7 310
(1989), 6 732 (1988), 6 840 (1987), 8 091
(1986), 10 596 (1985)
Fiscal year: | April-31 March
Approved for Release: 2020/08/12 C06554432
Overview: Fiyi’s economy 1s primarily agri-
cultural, with a large subsistence sector
Sugar exports are a major source of for-
eign exchange and sugar processing ac-
counts for one-third of industnal output
Industry, including sugar milling, contrib-
utes 10% to GDP Fit traditionally earned
considerable sums of hard currency from
the 250,000 tourists who visited each year
In 1987, however, after two military
coups, the economy went into decline
GDP dropped by 7 8% in 1987 and by
another 2 5% in 1988, political uncertainly
created a drop in tourism, and the worst
drought of the century caused sugar pro-
duction to fall sharply In contrast, sugar
and tourism turned in strong
performances in 1989, and the economy
rebounded vigorously
GDP: $1 32 billion, per capita $1,750, real
growth rate 12 5% (1989 est )
Inflation rate (consumer prices): 11 8%
(1988)
Unemployment rate: 11% (1988)
Budget: revenues $260 million, expendi-
tures $233 million, including capital ex-
penditures of $47 million (1988)
Exports: $312 million (f 0 b , 1988), com-
modities—sugar 49%, copra, processed
fish, lumber, partners—UK 45%, Austra-
ha 21%, US 47%
Imports: $454 million (cif, 1988), com-
modities—food 15%, petroleum products,
99
Approved for Release: 2020/08/12 C06554432
Fiji (continued)
machinery, consumer goods, partners—
US 48%, NZ, Australia, Japan
External debt: $398 million (December
1989 est )
Industrial production: growth rate — 15%
(1988 est )
Electricity: 215,000 kW capacity, 330 mil-
lion kWh produced, 440 kWh per capita
(1989)
Industries: sugar, copra, tourism, gold,
silver, fishing, clothing, lumber, small cot-
tage industries
Agriculture: principal cash crop ts sugar-
cane, coconuts, cassava, rice, sweet pota-
toes, and bananas, small livestock sector
includes cattle, pigs, horses, and goats
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1980-
87), $677 million
Currency: Fijian dollar (plural—dollars), 1
Finan dollar (F$) = 100 cents
Exchange rates: Fiyian dollars (F$) per
US$i—1 4950 (January 1990), 1 4833
(1989), 1 4303 (1988), 1 2439 (1987),
1 1329 (1986), 1 1536 (1985)
Fiscal year: calendar year','f6b5d4bd52a2a07d2208e857eee9734f8a9d62426243df8565ff3fc5078d928f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2da6248b26aaef20c5df3b602c81ae0cd4e2cfd524002c5cc42e0a7ca5417de',1990,'FI','Finland','economy',292,'Overview: Finland has a highly industrial-
ized, largely free market economy, with
per capita output nearly three-fourths the
US figure Its main economic force 1s the
manufacturing sector—principally the
wood, metals, and engineering industries
Trade is important, with the export of
goods representing about 25% of GNP
Except for timber and several minerals,
Finland depends on imported raw materi-
als, energy, and some components of man-
ufactured goods Because of the climate,
agricultural development is limited to
maintaining self-sufficiency in basic com-
modities Economic prospects are gener-
ally bright, the main shadow being the
increasing pressures on wages and prices
GDP: $74 4 billion, per capita $15,000,
real growth rate 4 6% (1989 est )
Inflation rate (consumer prices): 6 5%
(1989)
Unemployment rate: 3 4% (1989)
Budget: revenues $28 3 billion, expendi-
tures $28 1 billion, including capital ex-
penditures of $NA billion (1988 est )
Exports: $22 2 billion (fo b , 1988), com-
modities—timber, paper and pulp, ships,
machinery, clothing and footwear, part-
ners—EC 44 2% (UK 13 0%, FRG
10 8%), USSR 14 9%, Sweden 14 1%, US
58%
Imports: $22 0 billion (c1 f , 1988), com-
modities—foodstuffs, petroleum and pe-
troleum products, chemicals, transport
equipment, tron and steel, machinery, tex-
tile yarn and fabrics, fodder grains, part-
ners—EC 43 5% (FRG 16 9%, UK 6 8%),
Sweden 13 3%, USSR 12 1%, US 6 3%
External debt: $5 3 billion (1989)
Industrial production: growth rate 4 3%
(1989)
Electricity: 13,324,000 kW capacity,
49,330 million kWh produced, 9,940 kWh
per capita (1989)
Industries: metal manufacturing and ship-
building, forestry and wood processing
(pulp, paper), copper refining, foodstuffs,
textiles, clothing
Agriculture: accounts for 8% of GNP (in-
cluding forestry), livestock production, es-
pecially dairy cattle, predominates, for-
estry is an important export earner and a
secondary occupation for the rural popula-
tion, main crops—cereals, sugar beets,
potatoes, 85% self-sufficient, but short of
food and fodder grains, annual fish catch
about 160,000 metric tons
Aid: donor—ODA and OOF commitments
(1970-87), $1 7 billion
Currency: markka (plural—markkaa), 1
markka (FMk) or Finmark = 100 pennia
Exchange rates: markkaa (FMk) per
US$1—4 0022 (January 1990), 4 2912
101
Approved for Release: 2020/08/12 C06554432
Finland (continued)
(1989), 4 1828 (1988), 4 3956 (1987),
5 0695 (1986), 6 1979 (1985)
Fiscal year: calendar year','a7fcd923ca6085f50bc650e73be483bd6f8bf307b4850288c06256b8bd27e168','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4836103a737bac76013b3ebc2c775bf2da10cc91f32a7e7d837831851689d6e3',1990,'WF','Wallis and Futuna','economy',294,'Overview: One of the world’s most devel-
oped economies, France has substantial
agricultural resources and a highly diver-
sified modern industrial sector Large
tracts of fertile land, the application of
modern technology, and subsidies have
combined to make it the leading agricul-
tural producer in Western Europe France
is largely self-sufficient in agricultural
products and 1s a major exporter of wheat
and dairy products The industrial sector
generates about one-third of GDP and
employs about one-third of the work force
During the period 1982-86 economic
growth was sluggish, averaging only 1 4%
annually This trend was reversed by late
1987, however, with a strong expansion of
consumer demand, followed by a surge in
investment The economy has had diffi-
culty generating enough jobs for new en-
trants into the labor force, resulting in a
high unemployment rate, but the upward
trend in growth recently pushed the job-
less rate below 10% The steadily advanc-
ing economic integration within the Euro-
pean Community 1s a major force
affecting the fortunes of the various eco-
nomic sectors
GDP: $819 6 billion, per capita $14,600,
real growth rate 3 4% (1989 est )
Inflation rate (consumer prices): 3 5%
(1989 est )
Unemployment rate: 9 7% (1989 est )
Budget: revenues $197 0 billion, expendi-
tures $213 4 billion, including capital ex-
penditures of $NA (1989 est )
Exports: $183 1 billion (fob, 1989 est ),
commodities—machinery and transporta-
tion equipment, chemicals, foodstuffs, ag-
ricultural products, iron and steel prod-
ucts, textiles and clothing, partners—FRG
15 8%, Italy 12 2%, UK 9 8%, Belgrum-
Luxembourg 8 9%, Netherlands 8 7%, US
6 7%, Spain 5 6%, Japan 1 8%, USSR
1 3% (1989 est )
Imports: $194 5 billion (cif, 1989 est ),
commodities—crude oil, machinery and
equipment, agricultural products, chem:-
cals, iron and steel products, partners—
FRG 19 4%, Italy 11 5%, Belgium-Lux-
embourg 9 2%, US 7 7%, UK 7 2%, Neth-
erlands 5 2%, Spain 4 4%, Japan 4 1%,
USSR 2 1% (1989 est )
External debt: $59 3 billion (December
1987)
Industrial production: growth rate 4 4%
(1989 est )
Electricity: 109,972,000 kW capacity,
403,570 million kWh produced, 7,210
kWh per capita (1989)
Industries: steel, machinery, chemicals,
automobiles, metallurgy, aircraft, elec-
tronics, mining, textiles, food processing,
and tourism
Agriculture: accounts for 4% of GNP (in-
cluding fishing and forestry), one of the
world’s top five wheat producers, other
principal products—beef, dairy products,
cereals, sugar beets, potatoes, wine grapes,
self-sufficient for most temperate-zone
foods, shortages include fats and oils and
tropical produce, but overall net exporter
of farm products, fish catch of 850,000
metric tons ranks among world’s top 20
countries and 1s all used domestically
Aid: donor—ODA and OOF commitments
(1970-87), $59 8 billion
Currency: French franc (plural—francs), 1
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6.9261 (1986), 8 9852 (1985)
Fiscal year: calendar year
103
Approved for Release: 2020/08/12 C06554432
France (continued)','11f3db38f17811bf4406bd870129ab20e4ac29fd5801f9b138660c661c041fc3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ac735554844d9e060e71262eb4adb7295f574e5bf0dff410ea542d8d9f94f3',1990,'GF','French Guiana','economy',300,'Overview: The economy 1s tied closely to
that of France through subsidies and 1m-
ports Besides the French space center at
Kourou, fishing and forestry are the most
important economic activities, with ex-
ports of fish and fish products (mostly
shrimp) accounting for about two-thirds of
total revenue in 1985 The large reserves
of tropical hardwoods, not fully exploited,
support an expanding sawmill industry
that provides sawn logs for export Culti-
vation of crops—rice, cassava, bananas,
and sugarcane—are limited to the coastal
area, where the population 1s largely con-
centrated French Guiana ts heavily de-
pendent on imports of food and energy
Unemployment 1s a serious problem, par-
ticularly among younger workers, with an
unemployment rate of 15%
GDP: $210 million, per capita $3,230, real
growth rate NA% (1982)
Inflation rate (consumer prices): 4 1%
(1987)
Unemployment rate: 15% (1987)
Budget: revenues $735 million, expendi-
tures $735 million, including capital ex-
penditures of NA (1987)
Exports: $37 0 million (fo b, 1986), com-
modities—shrimp, timber, rum, rosewood
essence, partners—US 41%, Japan 18%,
France 9% (1984)
Imports: $297 7 million (cif, 1986), com-
modities—food (grains, processed meat),
other consumer goods, producer goods,
petroleum, partners—France 55%, Trini-
dad and Tobago 13%, US 3% (1984)
External debt: $1 2 billion (1988)
Industrial production: growth rate NA%
Electricity: 92,000 kW capacity, 185 mil-
lion kWh produced, 1,950 kWh per capita
(1989)
Industries: construction, shrimp process-
ing, forestry products, rum, gold mining
Agriculture: some vegetables for local con-
sumption, rice, corn, manioc, cocoa, ba-
nanas, sugar
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $1 1 billion
Currency: French franc (plural—francs), 1
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Approved for Release: 2020/08/12 C06554432
Fiscal year: calendar year','9d0b070ddb1c3d5b80ca318fedc9261d3376abb420653e90e1e5e5d3d3bfc50d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0edfcd50d1924b8e2b0e3867a15c0ef3f67f28c70279d960a383e0b5f83a1fe5',1990,'GA','Gabon','economy',306,'Overview: The economy, dependent on
timber and manganese unti! the early
1970s, 1s now dominated by the oil sector
During the period 1981-85 o1l accounted
for about 46% of GDP, 83% of export
earnings, and 65% of government revenues
on average The high oil prices of the
early 1980s contributed to a substantial
increase in per capita income, stimulated
domestic demand, reinforced migration
from rural to urban areas, and raised the
level of real wages to among the highest
in Sub-Saharan Africa The three-year
slide of Gabon’s economy, which began
with falling oil prices in 1985, stabilized
in 1989 because of a near doubling of oil
prices over their 1988 lows The agricul-
tural and industrial sectors are relatively
underdeveloped, accounting for only 8%
and 10%, respectively, of GDP in 1986
GDP: $3 2 billion, per capita $3,200, real
growth rate 0% (1989)
Inflation rate (consumer prices): 3% (1989)
Unemployment rate: NA%
Budget: revenues $927 million, expendi-
tures $1 2 billion, including capital expen-
ditures of $33 million (1988)
Exports: $1 14 billion (fo b, 1989 est ),
commodities—crude oil 70%, manganese
11%, wood 12%, uranium 6%, partners—
France 53%, US 22%, FRG, Japan
Imports: $0 76 billion (cif, 1989), com-
modities—foodstuffs, chemical products,
petroleum products, construction materi-
als, manufactures, machinery, partners—
France 48%, US 2 6%, FRG, Japan, UK
External debt: $2 0 billion (October 1989)
Industrial production: growth rate 1 7%
(1986)
Electricity: 310,000 kW capacity, 980 mil-
lion kWh produced, 920 kWh per capita
(1989)
Industries: sawmills, petroleum, food and
beverages, mining of increasing impor-
tance (especially manganese and uranium)
Agriculture: accounts for 8% of GDP (in-
cluding fishing and forestry), cash crops—
cocoa, coffee, palm oil, livestock not devel-
oped, importer of food, small fishing oper-
ations provide a catch of about 20,000
metric tons, okoume (a tropical softwood)
1s the most important timber product
Aid: US commitments, including Ex-Im
(FY70-88), $64 million, Western (non-US)
countries, ODA and OOF bilateral com-
Approved for Release: 2020/08/12 C06554432
mitments (1970-87), $1 7 billion, Commu-
nist countries (1970-88), $27 million
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year
Overview: The Gambia has no important
mineral or other natural resources and has
a limited agricultural base It 1s one of the
world’s poorest countries with a per capita
income of about $250 About 75% of the
population 1s engaged 1n crop production
and livestock raising, which contributes
about 30% to GDP Small-scale manufac-
turing activity—processing peanuts, fish,
and hides—accounts for less than 10% of
GDP Tourism 1s a growing industry The
Gambia imports about 33% of its food, all
fuel, and most manufactured goods Ex-
ports are concentrated on peanut products
(over 75% of total value)
GDP: $195 million, per capita $250, real
growth rate 4 6% (FY89 est )
Inflation rate (consumer prices): 8 0%
(FY89 est )
Unemployment rate: NA%
Budget: revenues $75 million, expenditures
$67 million, including capita! expenditures
of $21 millon (FY89)
Exports: $133 million (fob, FY89), com-
modities—peanuts and peanut products,
fish, cotton lint, palm kernels, partners—
Ghana 49%, Europe 27%, Japan 12%, US
1% (1986)
Imports: $105 million (cif, FY89), com-
modities—foodstuffs, manufactures, raw
materials, fuel, machinery and transport
equipment, partners—Europe 55% (EC
39%, other 16%), Asia 20%, US 11%, Se-
negal 4% (1986)
External debt: $330 million (December
1989 est )
Industrial production: growth rate 7 3%
(FY88)
Electricity: 29,000 kW capacity, 64 mil-
lon kWh produced, 80 kWh per capita
(1989)
Industries: peanut processing, tourism,
beverages, agricultural machinery assem-
bly, woodworking, metalworking, clothing
Agriculture: accounts for 30% of GDP and
employs about 75% of the population, 1m-
ports one-third of food requirements, ma-
Jor export crop is peanuts, the principal
crops—millet, sorghum, rice, corn, cas-
sava, palm kernels; livestock—cattle,
sheep, and goats, forestry and fishing re-
sources not fully exploited
Aid: US commitments, including Ex-Im
(FY70-88), $84 million, Western (non-US)
countries, ODA and OOF bilateral com-
109
Approved for Release: 2020/08/12 C06554432
The Gambia (continued)
mitments (1970-87), $422 million, Com-
munuist countries (1970-88), $39 million
Currency: dalas: (plural—dalasi), 1 dalasi
(D) = 100 bututs
Exchange rates: dalasi (D) per US$1_—
8 3232 (December 1989), 7 5846 (1989),
6 7086 (1988), 7 0744 (1987), 6 9380
(1986), 3 8939 (1985)
Fiscal year: 1 July-30 June
Overview: Nearly half of the labor force of
the Gaza Strip 1s employed across the bor-
der by Israeli industrial, construction, and
agricultural enterprises, with worker
transfer funds accounting for 40% of
GNP in 1989 The once dominant agricul-
tural sector now contributes only 13% to
GNP, about the same as that of the con-
struction sector, and industry accounts for
7% Gaza depends upon Israel for 90% of
its imports and as a market for 80% of its
exports Unrest in the territory in 1988-89
(intifadah) has raised unemployment and
substantially lowered the incomes of the
population
GNP: $380 million, per capita $650, real
growth rate NA% (1988)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $36 6 million, expendi-
tures $32 0 million, including capital ex-
penditures of NA (1986)
Exports: $88 million, commodities—cit-
rus, partners—Israel, Egypt (1989 est.)
Imports: $260 million, commodities—
food, consumer goods, construction mate-
rials, partners—Israel, Egypt (1989 est.)
External debt: $NA
Industrial production: growth rate NA%
Electricity: power supplied by Israel
Industries: generally small family busi-
nesses that produce cement, textiles, soap,
olive-wood carvings, and mother-of-pearl
souvenirs, the Israelis have established
some small-scale modern industries in an
industrial center
Agriculture: olives, citrus and other fruits,
vegetables, beef, dairy products
Aid: none
Currency: new Israel: shekel (plural—
shekels), 1 new Israeli shekel (NIS) = 100
new agorot
Exchange rates: new Israeli shekels (NIS)
per US$1—1 9450 (January 1990), 1 9164
(1989), 1 5989 (1988), 1 5946 (1987),
1 4878 (1986), 1 1788 (1985)
Fiscal year: 1 April-March 31
Overview: The GDR 1s moving rapidly
away from its centrally planned economy
As the 1990s begin, economic integration
with West Germany appears inevitable,
beginning with the establishment of a
common currency The opening of the
border with the FRG in late 1989 and the
continuing emigration of hundreds of
thousands of skilled workers had brought
growth to a standstill by yearend 1989
Features of the old economic regime that
will quickly change (a) the collectivization
of 95% of East German farms, (b) state
ownership of nearly all transportation fa-
cilities, industrial plants, foreign trade or-
ganizations, and financial institutions, (c)
the 65% share in trade of the USSR and
other CEMA countries, and (d) the de-
tailed control over economic details exer-
cised by Party and state Once integrated
into the thriving West German economy,
the area will have to stem the outflow of
workers and renovate the obsolescent 1n-
dustrial base After an initial readjust-
ment period, living standards and quality
of output will steadily rise toward West
German levels
GNP: $159 5 billion, per capita $9,679,
real growth rate 1 2% (1989 est )
Inflation rate (consumer prices): NA
Unemployment rate: NA%
Budget: revenues $123 5 billion, expendi-
tures $123 2 billion, including capital ex-
penditures of $33 billion (1986)
Exports: $30 7 billion (f 0 b , 1988), com-
modities—machinery and transport equip-
ment 47%, fuels and metals 16%, con-
sumer goods 16%, chemical products and
building materials 13%, semimanufac-
tured goods and processed foodstuffs 8%,
partners—USSR, Czechoslovakia, Poland,
FRG, Hungary, Bulgaria, Switzerland,','5623effaafc29e8829486581255c77ff9088b23996f150b8258bbbe2b9c448f2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2818cdd1f18501b52098e9e016197ac1ea62a23b9cb4eeac3ccedff8d6de7da2',1990,'RO','Romania','economy',307,'Imports: $31 0 billion (f 0 b , 1988), com-
modities—fuels and metals 40%, machin-
ery and transport equipment 29%, chemi-
cal products and building materials 9%,
partners—CEMA countries 65%, non-
Communist 33%, other 2%
External debt: $20 6 billion (1989)
Industrial production: growth rate 2 7%
(1989 est )
Electricity: (including East Berlin)
24,585,000 kW capacity, 122,500 million
kWh produced, 7,390 kWh per capita
(1989)
Industries: metal fabrication, chemicals,
brown coal, shipbuilding, machine build-
ing, food and beverages, textiles, petro-
leum
Agriculture: accounts for about 10% of
GNP (including fishing and forestry), prin-
cipal crops—wheat, rye, barley, potatoes,
sugar beets, fruit, livestock products in-
clude pork, beef, chicken, milk, hides and
skins, net importer of food, fish catch of
193,600 metric tons in 1987
Approved for Release: 2020/08/12 C06554432
Aid: donor—$4 0 billion extended bilater-
ally to non-Communist less developed
countries (1956-88)
Currency: GDR mark (plural—marks), |
GDR mark (M) = 100 pfennige
Exchange rates: GDR marks (M) per
US$1—3 01 (1988), 3 00 (1987), 3 30
(1986), 3 70 (1985), 3 64 (1984)
Fiscal year: calendar year
Overview: West Germany, a major eco-
nomic power and a leading exporter, has a
highly urbanized and skilled population
that enjoys excellent living standards and
comprehensive social welfare benefits The
FRG 1s poor 1n natural resources, coal
being the most important mineral The
FRG’s comparative advantage lies in the
technologically advanced production
stages Thus manufacturing and services
dominate economic activity, and raw ma-
terials and semimanufactures constitute a
large proportion of imports In 1988 man-
ufacturing accounted for 35% of GDP,
113
Approved for Release: 2020/08/12 C06554432
Germany, Federal Republic of
(West Germany) (continued)
with other sectors contributing lesser
amounts The major economic problem in
1989 1s persistent unemployment of over
8% The FRG 1s well poised to take ad-
vantage of the increasing economic inte-
gration of the European Community The
dramatic opening of the boundary with
East Germany 1n late 1989 poses new eco-
nomic challenges that could tax even this
powerful economy
GDP: $945 7 billion, per capita $15,300,
real growth rate 4 3% (1989 est )
Inflation rate (consumer prices): 3 0%
(1989)
Unemployment rate: 8 4% (1989)
Budget: revenues $539 billion, expendi-
tures $563 billion, including capital expen-
ditures of $11 5 billion (1988)
Exports: $323 4 billion (f ob , 1988), com-
modities—manufactures 86 6% (including
machines and machine tools, chemicals,
motor vehicles, 1ron and steel products),
agricultural products 4 9%, raw materials
2 3%, fuels 1 3%, partners—EC 527%
(France 12%, Netherlands 9%, Italy 9%,
UK 9%, Belgium-Luxembourg 7%), other
West Europe 18%, US 10%, Eastern Eu-
rope 4%, OPEC 3% (1987)
Imports: $250 6 billion (fo b , 1988), com-
modities—manufactures 68 5%, agricul-
tural products 12 0%, fuels 9 7%, raw ma-
terials 7 1%, partners—EC 52 7% (France
12%, Netherlands 11%, Italy 10%, UK
7%, Belgium-Luxembourg 7%), other
West Europe 15%, US 6%, Japan 6%,
Eastern Europe 5%, OPEC 3% (1987)
External debt: $500 million (June 1988)
Industrial production: growth rate 3 3%
(1988)
Electricity: (including West Berlin)
110,075,000 kW capacity, 452,390 million
kWh produced, 7,420 kWh per capita
(1989)
Industries: among world’s largest produc-
ers of iron, steel, coal, cement, chemicals,
machinery, ships, vehicles, and machine
tools, electronics, food and beverages
Agriculture: accounts for about 2% of
GDP (including fishing and forestry), di-
versified crop and livestock farming; prin-
cipal crops and livestock include potatoes,
wheat, barley, sugar beets, fruit, cabbage,
cattle, pigs, poultry, net importer of food,
fish catch of 202,000 metric tons in 1987
Aid: donor—ODA and OOF commitments
(1970-87), $60.0 billion
114
Approved for Release: 2020/08/12 C06554432
Currency: deutsche mark (plural—marks),
1 deutsche mark (DM) = 100 pfennige
Exchange rates: deutsche marks (DM) per
US$1—1 6918 (January 1990), 1 8800
(1989), | 7562 (1988), 1 7974 (1987),
2 1715 (1986), 2 9440 (1985)
Fiscal year: calendar year
Overview: Industry, which accounts for
one-third of the labor force and generates
over half the GNP, suffers from an aging
capital plant and persistent shortages of
energy In recent years the agricultural
sector has had to contend with drought,
mismanagement, and shortages of inputs
Favorable weather in 1989 helped produce
a good harvest, although far below gov-
262
ernment claims The new government 1s
slowly loosening the tight central controls
of Ceausescu’s command economy It has
instituted moderate land reforms, with
close to one-third of cropland now 1n pri-
vate hands, and it has allowed changes in
prices for private agricultural output
Also, the new regime 1s permitting the
establishment of private enterprises of 20
or fewer employees in services,
handicrafts, and small-scale industry Fur-
thermore, the government has halted the
old policy of diverting food from domestic
consumption to hard currency export mar-
kets So far, the government does not
seem willing to adopt a thorough-going
market system
GNP: $79 8 billion, per capita $3,445, real
growth rate —! 5% (1989 est )
Inflation rate (consumer prices): 0% (1987)
Unemployment rate: NA%
Budget: revenues $26 billion, expenditures
$21 6 billion, including capital expendi-
tures of $13 6 billion (1987)
Exports: $11 5 billion (fob, 1988), com-
modities—machinery and equipment
34 7%, fuels, minerals and metals 24 7%,
manufactured consumer goods 16 9%, ag-
ricultural materials and forestry products
11 9%, other 11 6% (1986), partners—
USSR 27%, Eastern Europe 23%, EC
15%, US 5%, China 4% (1987)
Imports: $8 75 billion (fob , 1988), com-
modities—fuels, minerals, and metals
51 0%, machinery and equipment 26 7%,
agricultural and forestry products 11 0%,
manufactured consumer goods 4 2%
(1986), partners—Communist countries
60%, non-Communist countries 40%
(1987)
External debt: none (mid-1989)
Industrial production: growth rate 3 6%
(1988)
Electricity: 22,640,000 kW capacity,
80,000 million kWh produced, 3,440 kWh
per capita (1989)
Industries: mining, timber, construction
materials, metallurgy, chemicals, machine
building, food processing, petroleum
Agriculture: accounts for 15% of GNP
and 28% of labor force, major wheat and
corn producer, other products—sugar
beets, sunflower seed, potatoes, milk, eggs,
meat, grapes
Aid: donor—$4 3 billion in bilateral aid to
non-Communist less developed countries
(1956-88)
Currency: leu (plural—le), 1 leu (L) =
100 bant
Exchange rates: lei (L) per US$1—20 96
(February 1990), 14 922 (1989), 14 277
(1988), 14 557 (1987), 16 153 (1986),
17 141 (1985)
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432','9b1b10c1cafee42b5b29c43c0ddb6f3aaf602094a7b5fb5458b65ab65d5e3d01','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b74ed6d6d79f85af9f6d9b128a691872e7382af0bc37867492d0b09c7ec05e8a',1990,'GH','Ghana','economy',316,'Overview: Supported by substantial inter-
national assistance, Ghana has been 1m-
plementing a steady economic rebuilding
program since 1983 Good harvests in
1988 featured the 6% growth in GNP
Moves toward privatization and relaxation
of government controls continued in 1988-
89, although at a slower-than-expected
pace In 1988 service on the $2 8 billion
debt was equivalent to 75% of export
earnings As Ghana obtains concessional
loans and pays off high-interest debt, how-
ever, debt service is expected to fall below
30% of export earnings in the early 1990s
The economic rebuilding program has
both helped and harmed the manufactur-
ing sector, for example, by improving the
supply of raw materials and by increasing
competition from imports The long-term
outlook 1s favorable provided that the po-
htical structure can endure the slow pace
at which living standards are improving
and can manage the problems stemming
from excessive population growth
GNP: $5 2 billion, per capita $400, real
growth rate 6% (1988)
Inflation rate (consumer prices): 32 7%
(1988)
Unemployment rate: 26% (Apri! 1987)
Budget: revenues $769 million, expendi-
tures $749 million, including capital ex-
penditures of $179 million (1988 est )
Exports: $977 million (f 0 b, 1987), com-
modities—cocoa 60%, timber, gold, tuna,
bauxite, and aluminum, partners—US
23%, UK, other EC
Imports: $988 million (cif, 1987), com-
modities—petroleum 16%, consumer
goods, foods, intermediate goods, capital
equipment, partners—US 10%, UK, FRG,
France, Japan, South Korea, GDR
External debt: $3 0 billion (December
1989 est )
Industrial production: growth rate 0 5% in
manufacturing (1987)
Electricity: 1,172,000 kW capacity, 4,110
million kWh produced, 280 kWh per cap-
ita (1989)
115
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Ghana (continued)
Industries: mining, lumbering, hght manu-
facturing, fishing, aluminum, food process-
ing
Agriculture: accounts for more than 50%
of GDP (including fishing and forestry),
the major cash crop 1s cocoa, other princi-
pal crops—rice, coffee, cassava, peanuts,
corn, shea nuts, timber, normally
self-sufficient in food
IHicit drugs: illicit producer of cannabis
for the international drug trade
Aid: US commitments, including Ex-Im
(FY70-88), $424 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 9 billion,
OPEC bilateral aid (1979-89), $78 million,
Communist countries (1970-88), $84 mil-
hon
Currency: cedi (plural—cedis), 1 ced: (C)
= 100 pesewas
Exchange rates: cedis (C) per US$1—
301 68 (December 1989), 270 00 (1989),
202 35 (1988), 153 73 (1987), 89 20 (1986),
54 37 (1985)
Fiscal year: calendar year','d10d0ad10c2d1cbd2732a5c8b75774a7b5030d43ad6f839e5ed4faaa83eb4bb3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('259d571268c4460039ae2e3345644e30546a257c859cdd9e7791c1b495a9c79e',1990,'GI','Gibraltar','economy',321,'Overview: The economy depends heavily
on British defense expenditures, revenue
from tourists, fees for services to shipping,
and revenues from banking and finance
activities Because more than 70% of the
economy is in the public sector, changes in
government spending have a major impact
on the level of employment Construction
workers are particularly affected when
government expenditures are cut
GNP: $129 million, per capita $4,450,
real growth rate NA% (FY85)
Inflation rate (consumer prices): 4 4%
(1986)
Unemployment rate: NA%
Budget: revenues $105 million, expendi-
tures $104 million, including capital ex-
penditures of NA (FY87)
Exports: $62 2 million (1985), commodi-
tles—{principally reexports) petroleum
715%, beverages and tobacco 12%, manu-
factured goods 8%, partners—UK, Mo-
rocco, Portugal, Netherlands, Spain, US,
FRG
Imports: $147 million (1985), commod-
tzes—manvfactured goods, fuels, and
foodstuffs, partners—UK, Morocco, Por-
tugal, Netherlands, Spain, US, FRG
External debt: $NA
Industrial production: growth rate NA%
Electricity: 46,000 kW capacity, 200 mil-
lion kWh produced, 6,770 kWh per capita
(1989)
Industries: tourism, banking and finance,
construction, commerce, support to large
UK naval and air bases, transit trade and
supply depot in the port, light manufac-
turing of tobacco, roasted coffee, ice, min-
eral waters, candy, beer, and canned fish
Agriculture: NA
Aid: US commitments, including Ex-Im
(FY70-87), $0 8 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $162 5 million
Currency: Gibraltar pound (plural—
pounds), 1 Gibraltar pound (£G) = 100
pence
Exchange rates: Gibraltar pounds (£G)
per US$1—0 6055 (January 1990), 0 6099
(1989), 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985), note—the
Gibraltar pound 1s at par with the British
pound
Fiscal year: 1 July-30 June
Overview: no economic activity
Overview: After registering a robust 10%
growth in 1988, the economy slowed in
1989 because of higher prices for food and
oil imports, lower worker remittances, and
a trade dispute with India over phosphoric
acid prices that cost Rabat $500 million
To meet the foreign payments shortfall,
Rabat has been drawing down foreign ex-
change reserves Servicing the $22 billion
foreign debt, high unemployment, and
Morocco’s vulnerability to external forces
remain severe problems for the 1990s
GDP: $21 9 billion, per capita $880
(1988), real growth rate 4 5% (1989 est )
Inflation rate (consumer prices): 6% (1989)
Unemployment rate: 15% (1988)
Budget: revenues $5 1 billion, expenditures
$6 0 billion, including capital expenditures
of $1 4 bilhon (1988)
Exports: $3 1 billion (fob, 1989), com-
modities—food and beverages 30%, semi-
processed goods 23%, consumer goods
21%, phosphates 17%, partners—EC 58%,
India 7%, Japan 5%, USSR 3%, US 2%
Imports: $5 | billion (fob, 1989), com-
modities—capital goods 24%, semipro-
cessed goods 22%, raw materials 16%, fuel
and lubricants 16%, food and beverages
13%, consumer goods 10%, partners—EC
53%, US 11%, Canada 4%, Iraq 3%,
USSR 3%, Japan 2%
External debt: $22 2 billion (1989)
Industrial production: growth rate 4%
(1989 est )
Electricity: 2,140,000 kW capacity, 7,760
million kWh produced, 300 kWh per cap-
Ita (1989)
Industries: phosphate rock mining and
processing, food processing, leather goods,
textiles, construction, tourism
Agriculture: 50% of employment and 30%
of export value, not self-sufficient in food,
cereal farming and livestock raising pre-
dominate, barley, wheat, citrus fruit, wine,
vegetables, olives, fishing catch of 491,000
metric tons in 1987
Ihlicit drugs: illicit producer of cannabis,
trafficking on the increase for both domes-
tic and international drug markets, ship-
ments of cannabis mostly directed to
Western Europe, occasional transit point
for cocaine from South America destined
for Western Europe
Aid: US commitments, including Ex-Im
(FY 70-88), $1 2 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $6 3 billion, OPEC
bilateral aid (1979-89), $4 8 billion, Com-
munist countries (1970-88), $2 3 billion
Currency: Moroccan dirham (plural—dir-
hams), 1 Moroccan dirham (DH) = 100
centimes
Exchange rates: Moroccan dirhams (DH)
per US$1—8 093 (January 1990), 8 488
(1989), 8 209 (1988), 8 359 (1987), 9 104
(1986), 10 062 (1985)
Fiscal year: calendar year
Overview: This Western capitalistic econ-
omy has done well since Spain joined the
European Economic Community in 1986
With increases in real GNP of 5 5% in
1987 and about 5% in 1988 and 1989,
Spain has been the fastest growing mem-
ber of the EC Increased investment—
both domestic and foreign—has been the
most important factor pushing the eco-
nomic expansion Inflation moderated to
4 8% in 1988, but an overheated economy
caused inflation to reach an estimated 7%
in 1989 Another economic problem facing
Spain is an unemployment rate of 16 5%,
the highest in Europe
GNP: $398 7 billion, per capita $10,100,
real growth rate 4 8% (1989 est )
Inflation rate (consumer prices): 7 0%
(1989 est )
Unemployment rate: 16 5% (1989 est )
Budget: revenues $57 8 billion, expendi-
tures $66 7 billion, including capital ex-
penditures of $10 4 billion (1987)
Exports: $40 2 billion (fo b , 1988), com-
modities—foodstuffs, live animals, wood,
footwear, machinery, chemicals,
partners—EC 66%, US 8%, other devel-
oped countries 9%
Imports: $60 4 billion (cif, 1988), com-
modities—petroleum, footwear, machin-
ery, chemicals, grain, soybeans, coffee,
tobacco, iron and steel, timber, cotton,
transport equipment, partners—EC 57%,
US 9%, other developed countries 13%,
Middle East 3%
External debt: $32 7 billion (1988)
Industrial production: growth rate 3 0%
(1988)
290
Electricity: 46,589,000 kW capacity,
157,040 milhon kWh produced, 3,980
kWh per capita (1989)
Industries: textiles and apparel (including
footwear), food and beverages, metals and
metal manufactures, chemicals, shipbuild-
ing, automobiles, machine tools
Agriculture: accounts for 5% of GNP and
14% of labor force, major products—
grain, vegetables, olives, wine grapes,
sugar beets, citrus fruit, beef, pork, poul-
try, dairy, largely self-sufficient in food,
fish catch of 1 4 million metric tons
among top 20 nations
Aid: US commitments, including Ex-Im
(FY 70-87), $1 9 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-79), $545 0 million
Currency: peseta (plural—pesetas), 1 pe-
seta (Pta) = 100 céntimos
Exchange rates: pesetas (Ptas) per US$1—
109 69 (January 1990), 118 38 (1989),
116 49 (1988), 123 48 (1987), 140 05
(1986), 170 04 (1985)
Fiscal year: calendar year
Overview: Economic activity 1s limited to
commercial fishing and phosphate mining
Geological surveys carried out several
years ago suggest that substantial reserves
of oil and natural gas may lie beneath the
islands, commercial exploitation has yet to
be developed
Industries: some guano mining
Approved for Release: 2020/08/12 C06554432','d4b2ed24483aa1e5396aa5a494ca9b9b88697d8bd41715930bc60c1daab439b6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eff07dfd419f076929a9586aae209e61473b82956525e2ace660e9cf39a4cd11',1990,'GR','Greece','economy',326,'Overview: Greece has a mixed capitalistic
economy with the basic entrepreneurial
system overlaid in 1981-89 by a socialist-
left-government that enlarged the public
sector and became the nation’s largest em-
ployer Like many other Western econo-
mies, Greece suffered severely from the
global oil price hikes of the 1970s, annual
GDP growth plunging from 8% to 2% in
Approved for Release: 2020/08/12 C06554432
the 1980s, and inflation, unemployment,
and budget deficits rising sharply The fall
of the socialist government in 1989 and
the inability of the conservative opposition
to muster a clear majority have led to
business uncertainty and the continued
prospects for lackluster economic perfor-
mance Once the political situation 1s
sorted out, Greece will have to face the
challenges posed by the steadily increasing
integration of the European Community,
including the progressive lowering of tariff
barriers Tourism continues as a major
industry, providing a vital offset to the
sizable commodity trade deficit
GDP: $56 3 billion, per capita $5,605, real
growth rate 2 3% (1989 est )
Inflation rate (consumer prices): 14 8%
(December 1989)
Unemployment rate: 7 7% (1988)
Budget: revenues $15 5 billion, expendi-
tures $23 9 billion, including capital ex-
penditures of $2 5 billion (1988)
Exports: $5 9 billion (fo b , 1988), com-
modities—manufactured goods, food and
live animals, fuels and lubricants, raw ma-
terials, partners—FRG 24%, Italy 14%,
nonoil developing countries 11 8%, France
9 5%, US 7 1%, UK 6 8%
Imports: $13 5 billion (cif , 1988), com-
modities—machinery and transport equip-
ment, light manufactures, fuels and lubri-
cants, foodstuffs, chemicals, partners—
FRG 22%, nonoil developing countries
14%, oil exporting countries 13%, Italy
12%, France 8%, US 3 2%
External debt: $20 0 billion (December
1988)
Industrial production: growth rate 1 6%
(1989 est )
Electricity: 10,500,000 kW capacity,
36,420 million kWh produced, 3,630 kWh
per capita (1989)
Industries: food and tobacco processing,
textiles, chemicals, metal products, tour-
ism, mining, petroleum
Agriculture: including fishing and forestry,
accounts for 14% of GNP and 27% of the
labor force, principal products—wheat,
corn, barley, sugar beets, olives, tomatoes,
wine, tobacco, potatoes, beef, mutton,
pork, dairy products, self-sufficient in
food, fish catch of 135,000 metric tons in
1987
Aid: US commitments, including Ex-Im
(FY70-81), $525 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 3 billion
Currency: drachma (plural—drachmas), 1
drachma (Dr) = 100 lepta
Exchange rates: drachma (Dr) per
US$1—158 03 (January 1990), 162 42
(1989), 141 86 (1988), 135 43 (1987),
139 98 (1986), 138 12 (1985)
Fiscal year: calendar year
Overview: In 1988, in spite of large min-
eral resources and one of the most devel-
oped and diversified economies in Sub-
Saharan Africa, Zaire had a GDP per
capita of $195, one of the lowest on the
continent Agriculture, a key sector of the
economy, employs 75% of the population
but generates under 30% of GDP The
main impetus for economic development
has been the extractive industries Mining
and mineral processing account for about
one-third of GDP and two-thirds of total
export earnings During the period 1983-
88 the economy experienced slow growth,
ugh inflation, a rising foreign debt, and a
jrop in foreign exchange earnings Recent
ncreases in foreign prices for copper—a
cey export earner—and other minerals
yffer some hope of reversing the economic
lecline Zaire 1s the world’s largest pro-
lucer of diamonds
3DP: $6 5 billion, per capita $195, real
rrowth rate 2 8% (1988)
nflation rate (consumer prices): 82%
1988)
Jnemployment rate: NA%
3udget: revenues $856 million, expendi-
ures $2 3 billion, including capital expen-
litures of $655 million (1988)
ixports: $2 2 billion (fob, 1988), com-
nodities—copper 37%, coffee 24%, dia-
nonds 12%, cobalt, crude oil, partners—
JS, Belgium, France, FRG, Italy, UK,','be45f72c625050eaa9fad1a9c239cdada4c2eeb3b1f35a984a80c0769b1484ca','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2afd591772ddc729d1153e4bf8fc3fab8bf68bc2a0053e3f1caa5501194b1960',1990,'GL','Greenland','economy',331,'Overview: Over the past 25 years, the
economy has changed from one based on
subsistence whaling, hunting, and fishing
to one dependent on foreign trade Fishing
1s still the most important industry, ac-
counting for over two-thirds of exports
and about 25% of the population’s income
Exploitation of mineral resources 1s lim-
ited to lead and zinc Maintenance of a
social welfare system similar to
Denmark’s has given the public sector a
dominant role in the economy Greenland
1s heavily dependent on an annual subsidy
of about $400 million from the Danish','814aaa0b3b32cfd7329178493f5042997ea3d1e322cd24cbf194424639f56c29','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed7d3df5d2539418777dbc6f742e7b779f1f1e18d0b05a72499affbc917d2c9c',1990,'GD','Grenada','economy',336,'Overview: The economy is essentially agri-
cultural and centers on the traditional
production of spices and tropical plants
Agriculture accounts for about 20% of
GDP and 90% of exports and employs
24% of the labor force Tourism 1s the
leading foreign exchange earner, followed
by agricultural exports Manufacturing
remains relatively undeveloped, but with a
more favorable private investment climate
since 1983, it 1s expected to grow Despite
an impressive average annual growth rate
for the economy of 5 5% during the period
1984-88, unemployment remains high at
about 26%
GDP: $129 7 million, per capita $1,535,
real growth rate 5% (1988)
Inflation rate (consumer prices): 5 0%
(1989 est )
Unemployment rate: 26% (1988)
Budget: revenues $74 2 million, expendi-
tures $82 3 million, including capital ex-
penditures of $27 8 million (1989 est )
Exports: $31 8 million (fo b, 1988 est ),
commodities—nutmeg 35%, cocoa beans
15%, bananas 13%, mace 7%, textiles,
partners—US 4%, UK, FRG, Nether-
lands, Trinidad and Tobago
Imports: $92 6 million (cif, 1988 est ),
commodities—machinery 24%, food 22%,
manufactured goods 19%, petroleum 8%,
partners—US 32%, UK, Trinidad and
Tobago, Japan, Canada
External debt: $108 million (1989 est )
Industrial production: growth rate 5 8%
(1989 est.)
Electricity: 11,400 kW capacity; 24 mil-
lion kWh produced, 280 kWh per capita
(1989)
122
Approved for Release: 2020/08/12 C06554432
Industries: food and beverage, textile, light
assembly operations, tourism, construction
Agriculture: accounts for 20% of GDP and
90% of exports, bananas, cocoa, nutmeg,
and mace account for two-thirds of total
crop production; world’s second-largest
producer and fourth-largest exporter of
nutmeg and mace, small-size farms pre-
dominate, growing a variety of citrus
fruits, avocados, root crops, sugarcane,
corn, and vegetables
Aid: US commitments, including Ex-Im
(FY 84-88), $60 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $61 million, Commu-
nist countries (1970-88), $32 million
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: calendar year','3c1a09986e085cb991e89bf54ff8d7414be04c21362b6c0ea1666bf3356cfadf','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40b3bbc28615210f6b20142a4a7e65d4d31a85363b4b33b1fe034f2d1336f840',1990,'GU','Guam','economy',345,'Overview: The economy 1s based on US
military spending and on revenues from
tourism Over the past 20 years the tourist
industry has grown rapidly, creating a
construction boom for new hotels and the
expansion of older ones Visitors
numbered about 800,000 in 1989 The
small manufacturing sector includes tex-
tile and clothing, beverage, food, and
watch production About 58% of the labor
force works for the private sector and the
rest for government Most food and indus-
trial goods are imported, with about 75%
from the US In 1989 the unemployment
rate was about 3%, down from 10% in
1983
GNP: $1 0 billion, per capita $7,675, real
growth rate 20% (1988 est )
Inflation rate (consumer prices): 5 9%
(1988)
Unemployment rate: 3% (1989 est )
Budget: revenues $208 0 million, expendi-
tures $175 mullion, including capital ex-
penditures of $17 million (1987 est )
Exports: $39 million (fob, 1983), com-
modities—mostly transshipments of re-
fined petroleum products, copra, fish, part-
ners—US 25%, others 75%
Imports: $611 milhon (c1f , 1983), com-
modities—mostly crude petroleum and
petroleum products, food, manufactured
goods, partners—US 77%, others 23%
External debt: $NA
Industrial production: growth rate NA%
Electricity: 500,000 kW capacity, 2,300
million kWh produced, 16,660 kWh per
capita (1989)
Industries: US military, tourism, petro-
leum refining, construction, concrete prod-
ucts, printing and publishing, food pro-
cessing, textiles
Agriculture: relatively undeveloped with
most food imported, fruits, vegetables,
eggs, pork, poultry, beef, copra
Aid: NA
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: 1 October-30 September','cb745c59c39340e211eb1c3ffe78cafd5f5355e5fa4282186c194ca1b464f3cd','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('548b12760da181bba5782c9d2247438830db746f92cb2778d70244e5f1bacbe7',1990,'GT','Guatemala','economy',350,'Overview: The economy is based on agri-
culture, which accounts for 25% of GDP,
employs about 60% of the labor force, and
supplies two-thirds of exports Industry
accounts for about 20% of GDP and 15%
of the labor force The economy has reen-
tered a slow-growth phase, but 1s ham-
pered by political uncertainty In 1988 the
economy grew by 3 7%, the third consecu-
tive year of mild growth Government eco-
nomic reforms introduced since 1986 have
stabilized exchange rates and have helped
to stem inflationary pressures The infla-
tion rate has dropped from 36 9% in 1986
to 15% 1n 1989
GDP: $10 8 billion, per capita $1,185, real
growth rate 1 3% (1989 est )
Inflation rate (consumer prices): 15%
(1989)
Unemployment rate: 13%, with 30-40%
underemployment (1988 est )
Budget: revenues $771 million, expendi-
tures $957 million, including capital ex-
penditures of $188 million (1988)
Exports: $1 02 billion (f.0 b , 1988), com-
moditres—coffee 38%, bananas 7%, sugar
7%, cardamom 4%, partners—US 29%, El
Salvador, FRG, Costa Rica, Italy
Imports: $1 5 billion (cif, 1988), com-
modities—fuel and petroleum products,
machinery, grain, fertilizers, motor vehi-
cles, partners—US 38%, Mexico, FRG,
Japan, El Salvador
External debt: $3 0 billion (December
1989 est )
Industrial production: growth rate 3 5%
(1988 est }
Electricity: 807,000 kW capacity, 2,540
million kWh produced, 280 kWh per cap-
ita (1989)
Industries: sugar, textiles and clothing,
furniture, chemicals, petroleum, metals,
rubber, tourism
Agriculture: accounts for 25% of GDP;
most important sector of economy and
contributes two-thirds to export earnings,
principal crops—sugarcane, corn, bananas,
coffee, beans, cardamom; livestock—cat-
tle, sheep, pigs, chickens, food importer
Illicit drugs: illicit producer of opium
poppy and cannabis for the international
drug trade, the government has engaged
in aerial eradication of opium poppy, tran-
sit country for cocaine shipments
Approved for Release: 2020/08/12 C06554432
Aid: US commitments, including Ex-Im
(FY 70-88), $869 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $7 7 billion
Currency: quetzal (plural—quetzales), 1
quetzal (Q) = 100 centavos
Exchange rates: free market quetzales (Q)
per US$1—3 3913 (January 1990), 2 8261
(1989), 2 6196 (1988), 2 500 (1987), 1 875
(1986), 1 000 (1985), note—black-market
rate 2 800 (May 1989)
Fiscal year: calendar year','422196ba5c2b5f747fbb5c540fb3a8bfe9b06d7b2eca42803783c0f201bb1966','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffc434f1703d19ad66dc5c4aaf86a9402b4d7fd1ec43e11743c8b18a9bc5d747',1990,'GG','Guernsey','economy',355,'Overview: Tourism is a major source of
revenue. Other economic activity includes
financial services, breeding the
world-famous Guernsey cattle, and grow-
ing tomatoes and flowers for export
GDP: $NA, per capita $NA, real growth
rate 9% (1987)
Inflation rate (consumer prices): 7% (1988)
Unemployment rate: NA%
Budget: revenues $145 0 million, expendi-
tures $117 2 million, including capital ex-
penditures of NA (1985)
Exports: $NA, commodities—tomatoes,
flowers and ferns, sweet peppers, eggplant,
other vegetables, partners—UK (regarded
as internal trade)
Imports: $NA, commodities—coal, gaso-
line and oil, partners—UK (regarded as
internal trade)
External debt: $NA
Industrial production: growth rate NA%
Electricity: 173,000 kW capacity, 525 mil-
lion kWh produced, 9,340 kWh per capita
(1989)
Industries: tourism, banking
Agriculture: tomatoes, flowers (mostly
grown in greenhouses), sweet peppers, egg-
plant, other vegetables and fruit, Guern-
sey Cattle
Aid: none
Currency: Guernsey pound (plural—
pounds), 1 Guernsey (£G) pound = 100
pence
Exchange rates: Guernsey pounds (£G)
per US$1—O 6055 (January 1990), 0 6099
(1989), 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985), note—the
Guernsey pound 1s at par with the British
pound
Fiscal year: calendar year','c8e162d5e5bc265eace0bead3d40ebf3890d9ab9fbe336a4088fa461648fe19a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b45207f122df6134191a7468acb8dd66cb5e630fad965a9ff1ae116be00c1f1',1990,'GW','Guinea-Bissau','economy',362,'Overview: Guinea-Bissau ranks among the
poorest countries in the world, with a per
capita GDP below $200 Agriculture and
fishing are the main economic activities,
with cashew nuts, peanuts, and palm ker-
nels the primary exports Exploitation of
known mineral deposits 1s unlikely at
present because of a weak infrastructure
and the high cost of development The
government’s four-year plan (1988-91) has
targeted agricultural development as the
top priority
GDP: $152 million, per capita $160
(1988), real growth rate 5 6% (1987)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
130
Approved for Release: 2020/08/12 C06554432
Budget: revenues $20 million, expenditures
$25 million, including capital expenditures
of $NA (1987)
Exports: $15 million (fob, 1987), com-
modities~—cashews, fish, peanuts, palm
kernels, partners—Portugal, Spain, Swit-
zerland, Cape Verde, China
Imports: $49 million (f 0 b , 1987), com-
modities—capital equipment, consumer
goods, semiprocessed goods, foods, petro-
leum, partners—Portugal, USSR, EC
countries, other Europe, Senegal, US
External debt: $465 million (December
1989 est )
Industrial production: growth rate —1 7%
(1986 est )
Electricity: 22,000 kW capacity, 28 mil-
lion kWh produced, 30 kWh per capita
(1989)
Industries: agricultural processing, beer,
soft drinks
Agriculture: accounts for over 50% of
GDP, nearly 100% of exports, and 80% of
employment, rice 1s the staple food, other
crops include corn, beans, cassava, cashew
nuts, peanuts, palm kernels, and cotton,
not self-sufficient in food, fishing and for-
estry potential not fully exploited
Aid: US commitments, including Ex-Im
(FY70-88), $46 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $519 mullion, OPEC
bilateral aid (1979-89), $41 million, Com-
munist countries (1970-88), $68 million
Currency: Guinea-Bissauan peso (plural—
pesos), 1 Guinea-Bissauan peso (PG) =
100 centavos
Exchange rates: Guinea-Bissauan pesos
(PG) per US$1—650 pesos (December
1989), NA (1988), 851 65 (1987), 238 98
(1986), 173 61 (1985)
Fiscal year: calendar year
Overview: After growing on average at less
than 1% a year in 1984-87, GDP dropped
by 3% in 1988, the result of bad weather,
labor trouble in the canefields, and
flooding and equipment problems 1n the
bauxite industry Consumer prices rose
about 35%, and the current account deficit
widened substantially as sugar and baux-
ite exports fell Moreover, electric power
1s In short supply and constitutes a major
barrier to future gains in national output
The government, in association with inter-
131
Approved for Release: 2020/08/12 C06554432
Guyana (continued)
national financial agencies, seeks to reduce
its payment arrears and to raise new
funds The government’s stabilization pro-
gram—aimed at establishing realistic ex-
change rates, reasonable price stability,
and a resumption of growth—requires
considerable public administrative abilities
and continued patience by consumers dur-
ing a long incubation period
GDP: $323 million, per capita $420, real
growth rate —3 0% (1988 est )
Inflation rate (consumer prices): 35% (1988
est )
Unemployment rate: NA%
Budget: revenues $173 million, expendi-
tures $414 million, including capital ex-
penditures of $75 million (1988 est )
Exports: $215 million (fob, 1988 est )
commodities——bauxite, sugar, rice,
shrimp, gold, molasses, timber, rum, part-
ners—UK 37%, US 12%, Canada 10 6%,
CARICOM 4 8% (1986)
Imports: $216 million (cif, 1988 est ),
commodities—manufactures machinery,
food, petroleum, partners—CARICOM
41%, US 18%, UK 9%, Canada 3% (1984)
External debt: $1 8 billion, including ar-
rears (December 1988)
Industrial production: growth rate —5 0%
(1988 est )
Electricity: 221,000 kW capacity, 583 mil-
lion kWh produced, 760 kWh per capita
(1989)
Industries: bauxite mining, sugar, rice
milling, timber, fishing (shrimp), textiles,
gold mining
Agriculture: most important sector, ac-
counting for 25% of GDP and over 50% of
exports, sugar and rice are key crops, de-
velopment potential exists for fishing and
forestry, not self-sufficient in food, espe-
cially wheat, vegetable oils, and animal
products
Aid: US commitments, including Ex-Im
(FY70-88), $109 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $234 million,
Communist countries (1970-88), $242 mil-
lion
Currency: Guyanese dollar (plural—dol-
lars), 1 Guyanese dollar (G$) = 100 cents
Exchange rates: Guyanese dollars (G$) per
US$1—33 0000 (January 1990), 27 159
(1989), 10 000 (1988), 9 756 (1987), 4.272
(1986), 4 252 (1985)
Fiscal year: calendar year','fa6efc91e1f6c4a5f89685c1120881b78b2ef1707b685ed014256b57e5f85e7b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ce042bf15626a82475cf17e49cb3ccf95098e60256e0e3e4a4cb95adca6dff8',1990,'HT','Haiti','economy',367,'Overview: About 85% of the population
live in absolute poverty Agriculture 1s
mainly small-scale subsistence farming
and employs 65% of the work force The
majority of the population does not have
ready access to safe drinking water, ade-
quate medical care, or sufficient food Few
social assistance programs exist, and the
lack of employment opportunities remains
the most critical problem facing the econ-
omy
GDP: $2 4 billion, per capita $380, real
growth rate 0 3% (1988 est )
Inflation rate (consumer prices): 5 8%
(1988)
Unemployment rate: 50% (1988 est )
Budget: revenues $252 million, expendi-
tures $357 million, including capital ex-
penditures of $NA million (1988)
Exports: $200 million (f 0 b , FY88), com-
modities—hght manufactures 65%, coffee
17%, other agriculture 8%, other products
10%, partners—US 77%, France 5%, Italy
4%, FRG 3%, other industrial 9%, less
developed countries 2% (FY86)
Imports: $344 million (cif, FY88), com-
modities—machines and manufactures
36%, food and beverages 21%, petroleum
products 11%, fats and oils 12%, chemi-
cals 12%, partners—US 65%, Netherlands
Antilles 6%, Japan 5%, France 4%, Can-
ada 2%, Asia 2% (FY86)
External debt: $820 million (December
1988)
Industrial production: growth rate —2%
(FY87)
Electricity: 230,000 kW capacity, 482 mil-
lion kWh produced, 75 kWh per capita
(1989)
Industries: sugar refining, textiles, flour
mulling, cement manufacturing, bauxite
mining, tourism, light assembly industries
based on imported parts
Agriculture: accounts for 32% of GDP and
employs 65% of work force, mostly small-
scale subsistence farms; commercial
crops—coffee and sugarcane, staple
crops—rice, corn, sorghum, mangoes,
shortage of wheat flour
Aid: US commitments, including Ex-Im
(FY70-88), $638 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $627 million
Currency: gourde (plural—gourdes), 1
gourde (G) = 100 centimes
Exchange rates: gourdes (G) per US$1—
5 0 (fixed rate)
Fiscal year: 1 October-30 September','47cdcd21163f342ed9a789dda7fee93467f902707c98a8194f86904684410769','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2873a33fea642d6aa23b640cab8fa6335a52929408b6159e027f1ab693ea8db',1990,'HN','Honduras','economy',371,'Overview: Honduras 1s one of the poorest
countries in the Western Hemisphere Ag-
riculture 1s the most important sector of
the economy, accounting for nearly 30%
of GDP, employing 62% of the labor
force, and producing two-thirds of exports.
Productivity remains low, however, leaving
considerable room for improvement Al-
though industry 1s still in its early stages,
it employs nearly 15% of the labor force,
accounts for 23% of GDP, and generates
20% of exports The service sectors, 1n-
cluding public administration, account for
48% of GDP and employ nearly 20% of
the labor force Basic problems facing the
economy include a high population growth
rate, a high unemployment rate, a lack of
basic services, a large and inefficient pub-
lic sector, and an export sector dependent
mostly on coffee and bananas, which are
subject to sharp price fluctuations
GDP: $4 4 billion, per capita $890, real
growth rate 4 0% (1988)
Inflation rate (consumer prices): 11%
(1989)
Unemployment rate: 12% unemployed,
30-40% underemployed (1988)
Budget: revenues $1,053 million, expendi-
tures $949 million, including capital ex-
penditures of $159 million (1989)
Exports: $1 0 billion (fo b, 1988), com-
modities—bananas, coffee, shrimp, lob-
ster, minerals, lumber, partners—US 52%,
FRG 11%, Japan, Italy, Belgium
Imports: $1 4 billion (c.1 f. 1988), com-
modities—machinery and transport equip-
ment, chemical products, manufactured
goods, fuel and oil, foodstuffs; partners—
US 39%, Japan 9%, CACM, Venezuela,','2c0a0ae7405b96333dce6e4b9c6b6c19d95d6072f61811daffd4e1a5f9a68c26','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2a28673bb1895c3eae01684717487681dc7efc76cbbd31ce50d7dcf520bda71',1990,'MX','Mexico','economy',372,'External debt: $3 2 billion (December
1989)
Industrial production: growth rate 5%
(1988)
Electricity: 655,000 kW capacity, 1,980
million kWh produced, 390 kWh per cap-
ita (1989)
Industries: agricultural processing (sugar
and coffee), textiles, clothing, wood prod-
ucts
Agriculture: most important sector, ac-
counting for nearly 30% of GDP, over
60% of the labor force, and two-thirds of
exports, principal products include ba-
136
Approved for Release: 2020/08/12 C06554432
nanas, coffee, timber, beef, citrus fruit,
shrimp, importer of wheat
Illicit drugs: illicit producer of cannabis,
cultivated on small plots and used princi-
pally for local consumption, transshipment
point for cocaine
Aid: US commitments, including Ex-Im
(FY70-88), $1 3 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $776 million
Currency: lempira (plural—lempiras), 1
lempira (L) = 100 centavos
Exchange rates: lempiras (L) per US$1—
2 00 (fixed rate), 3 50 parallel exchange
and black-market rate (October 1989)
Fiscal year: calendar year
Overview: Mexico’s economy is a mixture
of state-owned industrial plants (notably
oil), private manufacturing and services,
and both large-scale and traditional agri-
culture In the 1980s Mexico experienced
severe economic difficulties the nation
accumulated large external debts as world
petroleum prices fell, rapid population
growth outstripped the domestic food sup-
ply, and inflation, unemployment, and
pressures to emigrate became more acute
Growth in national output dropped from
8% in 1980 to 1 1% in 1988 and 2 5% in
1989 The US 1s Mexico’s major trading
partner, accounting for two-thirds of tts
exports and imports After petroleum, bor-
der assembly plants and tourism are the
largest earners of foreign exchange The
government, in consultation with interna-
tional economic agencies, 1s implementing
programs to stabilize the economy and
foster growth
GDP: $187 0 billion, per capita $2,165,
real growth rate 2 5% (1989)
Inflation rate (consumer prices): 20%
(1989)
Unemployment rate: 20% (1989 est )
Budget: revenues $36 1 billion, expendi-
tures $56 1 billion, including capital ex-
penditures of $7 7 bulion (1988)
Exports: $23 | billion (fob, 1989), com-
modities—crude oil, o11 products, coffee,
shrimp, engines, cotton, partners—US
66%, EC 16%, Japan 11%
206
Imports: $23 3 billion (c1 f , 1989), com-
modities—grain, metal manufactures, ag-
ricultural machinery, electrical equipment,
partners—US 62%, EC 18%, Japan 10%
External debt: $95 1 billion (1989)
Industrial production: growth rate 1 3%
(1988)
Electricity: 26,900,000 kW capacity,
103,670 million kWh produced, 1,200
kWh per capita (1989)
Industries: food and beverages, tobacco,
chemicals, iron and steel, petroleum, min-
ing, textiles, clothing, transportation
equipment, tourism
Agriculture: accounts for 9% of GDP and
over 25% of work force, large number of
small farms at subsistence level, major
food crops—corn, wheat, rice, beans, cash
crops—cotton, coffee, fruit, tomatoes, fish
catch of 1 4 million metric tons among top
20 nations (1987)
Illicit drugs: illicit cultivation of opium
poppy and cannabis continues in spite of
government eradication efforts, major link
in chain of countries used to smuggle co-
caine from South American dealers to US
markets
Aid: US commitments, including Ex-Im
(FY70-88), $3 0 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $6 8 billion, Commu-
nist countries (1970-88), $110 million
Currency: Mexican peso (plural—pesos), 1
Mexican peso (Mex$) = 100 centavos
Exchange rates: market rate of Mexican
pesos (Mex$) per US$1—2,660 3 (January
1990), 2,461 3 (1989), 2,273 1 (1988),
1,378 2 (1987), 611 8 (1986), 256 9 (1985)
Fiscal year: calendar year
Overview: The US has the most powerful
and diversified economy in the world, with
a per capita GNP of over $21,000, the
largest among the major industrial na-
tions In 1989 the economy entered its
eighth successive year of growth, the long-
est in peacetime history The expansion
has featured continued moderation in
wage and consumer price increases, an
unemployment rate of 5 2%, (the lowest in
10 years), and an inflation rate of 4 8%
On the negative side, the US enters the
1990s with massive budget and trade defi-
cits, huge and rapidly rising medical costs,
and inadequate investment in industrial
capacity and economic infrastructure
GNP: $5,233 3 billion, per capita $21,082,
real growth rate 2 9% (1989)
Approved for Release: 2020/08/12 C06554432
Inflation rate (consumer prices): 4 8%
(1989)
Unemployment rate: 5 2% (1989)
Budget: revenues $976 billion, expendi-
tures $1,137 billion, including capital ex-
penditures of NA (FY89 est )
Exports: $322 3 billion (fob, 1988), com-
modities—capital goods, automobiles, in-
dustrial supplies and raw materials, con-
sumer goods, agricultural products,
partners—Canada 22 9%, Japan 11 8%
(1988)
Imports: $440 9 billion (cif, 1988), com-
modities—crude and partly refined petro-
leum, machinery, automobiles, consumer
goods, industrial raw materials, food and
beverages, partners—Japan 19 6% , Can-
ada 19 1% (1988)
External debt: $532 billion (December
1988)
Industrial production: growth rate 3 3%
(1989)
Electricity: 776,550,000 kW capacity,
2,958,300 million kWh produced, 11,920
kWh per capita (1989)
Industries: leading industrial power in the
world, highly diversified, petroleum, steel,
motor vehicles, aerospace, telecommunica-
tions, chemicals, electronics, food process-
ing, consumer goods, fishing, lumber, min-
ing
Agriculture: accounts for 2% of GNP and
2 8% of labor force, favorable climate and
soils support a wide variety of crops and
livestock production, world’s
second-largest producer and number-one
exporter of grain, surplus food producer,
fish catch of 5 7 million metric tons (1987)
Illicit drugs: illicit producer of cannabis
for domestic consumption with 1987 pro-
duction estimated at 3,500 metric tons or
about 25% of the available marijuana,
ongoing eradication program aimed at
small plots and greenhouses has not re-
duced production
Aid: donor—commitments, including Ex-
Im (FY80-88), $90 5 billion
Currency: United States dollar (plural—
dollars), 1 United States dollar (US$) =
100 cents
Exchange rates: British pounds (£) per
US$—0 6055 (January 1990), 0 6099
(1989), 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985),
Canadian dollars (Can$) per US$—
1 1885 (February 1990), 1 2307 (1988),
1 3260 (1987), 1 3895 (1986),
French francs (F) per US$—5 695 (Feb-
ruary 1990), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985),
Italian lire (Lit) per US$—1,244 8 (Feb-
ruary 1990), 1,301 6 (1988), 1,296 1
(1987), 1,490 8 (1986), 1,909 4 (1985),
Japanese yen (¥) per US$—145 55 (Feb-
ruary 1990), 128 15 (1988), 144 64 (1987),
168 52 (1986), 238 54 (1985),
FRG deutsche marks (DM) per US$—
1 6775 (February 1990), 1 7562 (1988),
1 7974 (1987), 2 1715 (1986), 2 9440
(1985)
Fiscal year: 1 October-30 September','eaff8bd93ace7bf651f4558d8d8ad98eef686899077d7f8b7b56152c305fb953','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33d26c52b9771334186c0c81dad4feed503c46d30ce622d5cec517bad9feb40b',1990,'HK','Hong Kong','economy',378,'Overview: Hong Kong has a free-market
economy and 1s autonomous in financial
affairs Natural resources are limited and
food and raw materials must be imported
Manufacturing 1s the backbone of the
economy, accounting for more than 20%
of GDP, employing 36% of the labor
force, and exporting about 90% of output.
Real GDP growth averaged a remakable
8% in 1987-88, then slowed to a respect-
able 3% 1n 1989 Unemployment, which
has been declining since the mid-1980s, 1s
now less than 2% A shortage of labor
continues to put upward pressure on prices
and the cost of living Short-term pros-
pects remain solid so long as major trad-
Ing partners continue to be prosperous
The crackdown 1n China in 1989 casts a
long shadow over the longer term
economic outlook
GDP: $57 billion, per capita $10,000; real
growth rate 3% (1989)
Inflation rate (consumer prices): 9 5%
(1989)
Unemployment rate: 1 6% (1988)
Budget: $6 9 billion (FY89)
Exports: $63 2 billion (f ob , 1988), in-
cluding reexports of $22 9 billion, com-
modities—clothing, textile yarn and fab-
ric, footwear, electrical appliances,
watches and clocks, toys, partners—US
31%, China 14%, FRG 8%, UK 6%, Ja-
pan 5%
Imports: $63 9 billion (cif, 1988), com-
modities—foodstuffs, transport equipment,
raw materials, semimanufactures, petro-
leum, partners—China 31%, Japan 20%,
Taiwan 9%, US 8%
External debt: $9 6 billion (December
1988)
Industrial production: growth rate 7 0%
(1988)
Electricity: 7,800,000 kW capacity,
23,000 million kWh produced, 4,030 kWh
per capita (1989)
Industries: textiles, clothing, tourism, elec-
tronics, plastics, toys, watches, clocks
Agriculture: minor role in the economy,
rice, vegetables, dairy products, less than
20% self-sufficient, shortages of rice,
wheat, water
Aid: US commitments, including Ex-Im
(FY70-87), $141 2 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $899 8 million
Currency: Hong Kong dollar (plural—dol-
lars), 1 Hong Kong dollar (HK$) = 100
cents
Exchange rates: Hong Kong dollars (HK$)
per US$—7 800 (March 1989), 7 810
(1988), 7 760 (1987), 7 795 (1986), 7 811
(1985), note—hnked to the US dollar at
the rate of about 7 8 HK$ per 1 US$
since 1985
Fiscal year: 1 April-31 March
Overview: no economic activity
Imports: $18 5 billion (cif, 1989 est ),
commodities—machinery 27%, chemicals
11%, vehicles and aircraft 11%, textiles,
scientific instruments, base metals, part-
ners—US, FRG, Japan, UK, France, It-
aly, Switzerland
External debt: $21 2 billion (1988 est )
Industrial production: growth rate 5 6%
(1988)
Electricity: 34,941,000 kW capacity,
158,000 million kWh produced, 4,100
kWh per capita (1989)
Industries: mining (world’s largest pro-
ducer of diamonds, gold, chrome), auto-
mobile assembly, metalworking, machin-
ery, textile, iron and steel, chemical,
fertilizer, foodstuffs
Agriculture: accounts for 6% of GDP and
30% of labor force, diversified agriculture,
with emphasis on livestock, products—
cattle, poultry, sheep, wool, milk, beef,
corn, wheat, sugarcane, fruits, vegetables;
self-sufficient in food
Aid: NA
Currency: rand (plural—rand), 1 rand (R)
= 100 cents
Exchange rates: rand (R) per US$1—
2 5555 (January 1990), 2 6166 (1989),
2 2611 (1988), 2 0350 (1987), 2 2685
(1986), 2 1911 (1985)
Fiscal year: 1 April-31 March
Overview: Some fishing takes place in ad-
jJacent waters There 1s a potential source
of income from harvesting fin fish and
krill The islands receive income from
postage stamps produced in the UK
Budget: revenues $291,777, expenditures
$451,011, including capital expenditures
of SNA (FY88 est )
Electricity: 900 kW capacity, 2 million
kWh produced, NA kWh per capita
(1989)
Overview: The first five years of
perestroyka (economic restructuring) have
undermined the institutions and processes
287
Approved for Release: 2020/08/12 C06554432
Soviet Union (continued)
of the Soviet command economy without
replacing them with efficiently functioning
markets The initial reforms featured
greater authority for enterprise managers
over prices, wages, product mix, iInvest-
ment, sources of supply, and customers
But 1n the absence of effective market dis-
cipline, the result was the disappearance
of low-price goods, excessive wage
increases, an even larger volume of unfin-
ished construction projects, and, in gen-
eral, continued economic stagnation The
Gorbachev regime has made at least four
serious errors in economic policy in these
five years the unpopular and short-lived
anti-alcohol campaign, the initial cutback
in imports of consumer goods, the failure
to act decisively for the privatization of
agriculture, and the buildup of a massive
overhang of unspent rubles in the hands of
households and enterprises In October
1989, a top economic adviser, Leonid
Abalkin presented an ambitious but rea-
sonable timetable for the conversion to a
partially privatized market system in the
1990s In December 1989, however, Pre-
mier Ryzhkov’s conservative approach
prevailed, namely, the contention that a
period of retrenchment was necessary to
provide a stable financial and legislative
base for launching further reforms Ac-
cordingly, the new strategy was to put the
reform process on hold in 1990-92 by re-
centralizing economic authority and to
placate the rank-and-file through sharp
increases in consumer goods output In
still another policy twist, the leadership in
early 1990 was considering a marked
speedup in the marketization process Be-
cause the economy 1s caught in between
two systems, there was in 1989 an even
greater mismatch between what was pro-
duced and what would serve the best in-
terests of enterprises and households
Meanwhile, the seething nationality prob-
lems have been dislocating regional! pat-
terns of economic specialization and pose
a further major threat to growth prospects
over the next few years
GNP: $2,659 5 billion, per capita $9,211,
real growth rate 1 4% (1989 est based on
Soviet statistics, cutbacks in Soviet report-
ing on products included in sample make
the estimate subject to greater uncertainty
than 1n earlier years)
Inflation rate (consumer prices): 6% (1989
est )
Unemployment rate: officially, no unem-
ployment
Budget: revenues $622 billion, expendi-
tures $781 billion, including capital expen-
ditures of $119 billion (1989 est )
Exports: $110.7 billion (f.0 b , 1988), com-
modities—petroleum and petroleum prod-
ucts, natural gas, metals, wood, agricul-
tural products, and a wide variety of
288
Approved for Release: 2020/08/12 C06554432
manufactured goods (primarily capital
goods and arms), partners—Eastern Eu-
rope 49%, EC 14%, Cuba 5%, US, Af-
ghanistan (1988)
Imports: $107 3 billion (cif, 1988), com-
modities—grain and other agricultural
products, machinery and equipment, steel
products (including large-diameter pipe),
consumer manufactures, partners—East-
ern Europe 54%, EC 11%, Cuba, China,
US (1988)
External debt: $27 3 billion (1988)
Industrial production: growth rate 0 2%
(1989 est )
Electricity: 355,000,000 kW capacity,
1,790,000 million kWh produced, 6,150
kWh per capita (1989)
Industries: diversified, highly developed
capital goods and defense industries, con-
sumer goods industries comparatively less
developed
Agriculture: accounts for roughly 20% of
GNP and labor force, production based on
large collective and state farms, ineffi-
ciently managed, wide range of temperate
crops and livestock produced, world’s
second-largest grain producer after the
US, shortages of grain, oilseeds, and meat,
world’s leading producer of sawnwood and
roundwood, annual fish catch among the
world’s largest—11 2 million metric tons
(1987)
Micit drugs: illegal producer of cannabis
and opium poppy, mostly for domestic
consumption, government has begun erad-
ication program to control cultivation,
used as a transshipment country
Aid: donor—extended to non-Communist
less developed countries (1954-88), $47 4
billion, extended to other Communist
countries (1954-88), $147 6 billion
Currency: ruble (plural—rubles), 1 ruble
(R) = 100 kopeks
Exchange rates: rubles (R) per US$1—
0 600 (February 1990), 0 629 (1989), 0 629
(1988), 0 633 (1987), 0 704 (1986), 0 838
(1985), note—the exchange rate 1s admin-
istratively set and should not be used in-
discriminately to convert domestic rubles
to dollars, on 1 November 1989 the
USSR began using a rate of 6 26 rubles
to the dollar for Western tourists buying
rubles and for Soviets traveling abroad,
but retained the official exchange rate for
most trade transactions
Fiscal year: calendar year','e456be60691cec572c2850e51ae59629bf8b5faccd103b8e97292ce18728a416','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('855a5a95e342dd45bb0fd23c59c9d37632da582781e302456c4b2881ca6ba234',1990,'IS','Iceland','economy',383,'Overview: Iceland’s prosperous
Scandinavian-type economy 1s basically
capitalistic, but with extensive welfare
measures, low unemployment, and com-
paratively even distribution of income
The economy is heavily dependent on the
fishing industry, which provides nearly
75% of export earnings In the absence of
other natural resources, Iceland’s economy
1s vulnerable to changing world fish prices
National output declined for the second
consecutive year in 1989, and two of the
largest fish farms filed for bankruptcy
Other economic activities include livestock
raising and aluminum smelting A fall in
the fish catch 1s expected for 1990, result-
ing in a continuation of the recession
GDP: $4 0 billion, per capita $16,200, real
growth rate —1 8% (1989 est )
Inflation rate (consumer prices): 17 4%
(1989 est )
Unemployment rate: 1 3% (1989 est )
Budget: revenues $1 5 billion, expenditures
$1 7 billion, including capital expenditures
of $NA million (1988)
Exports: $1 4 billion (fo b, 1988), com-
modities—fish and fish products, animal
products, aluminum, diatomite, partners—
EC 58 9% (UK 23 3%, FRG 10 3%), US
13 6%, USSR 3 6%
Imports: $1 6 billion (c1f , 1988), com-
modities—machinery and transportation
equipment, petroleum, foodstuffs, textiles,
partners—EC 58% (FRG 16%, Denmark
10 4%, UK 9 2%), US 8 5%, USSR 3 9%
External debt: $1 8 biilion (1988)
Industrial production: growth rate 47%
(1987 est }
Electricity: 1,063,000 kW capacity, 5,165
million kWh produced, 20,780 kWh per
capita (1989)
Industries: fish processing, aluminum
smelting, ferro-silicon production, hydro-
power
Agriculture: accounts for about 25% of
GDP (including fishing), fishing 1s most
important economic activity, contributing
nearly 75% to export earnings, principal
crops—potatoes and turnips, livestock—
cattle, sheep, self-sufficient in crops, fish
catch of about 1 6 million metric tons in
1987
Aid: US commitments, including Ex-Im
(FY70-81), $19 1 million
Currency: kréna (plural—krénur), | Ice-
landic krona (IKr) = 100 aurar
Exchange rates: Icelandic kroénur (IKr) per
US$1—60 751 (January 1990), 57 042
(1989), 43 014 (1988), 38 677 (1987),
41 104 (1986), 41 508 (1985)
Fiscal year: calendar year','af92bd91d41f5de0545c8828c31e9b8df17c9a7cb3c8dba22fa665e8196e9600','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42a190513d4fd0a89a23d24dfb39e50107f0f22c33d20e8d3e40504bb368520d',1990,'IN','India','economy',386,'Overview: India’s Malthusian economy 1s a
mixture of traditional village farming and
handicrafts, modern agriculture, old and
new branches of industry, and a multitude
of support services It presents both the
entrepreneurial skills and drives of the
capitahst system and widespread govern-
ment intervention of the socialist mold
Growth of 4% to 5% annually in the
1980s has softened the impact of popula-
tion growth on unemployment, social tran-
quility, and the environment Agricultural
output has continued to expand, reflecting
the greater use of modern farming tech-
niques and improved seed that have
helped to make India self-sufficient in food
grains and a net agricultural exporter
However, tens of millions of villagers, par-
ticularly in the south, have not benefited
from the green revolution and live in ab-
ject poverty Industry has benefited from a
liberalization of controls The growth rate
of the service sector has also been strong
GNP: $333 billion, per capita $400, real
growth rate 5 0% (1989 est )
Inflation rate (consumer prices): 9 5%
(1989 est )
Unemployment rate: 20% (1989 est )
Budget: revenues $48 billion, expenditures
$53 billion, including capital expenditures
of $13 6 billion (1989)
Exports: $17 2 billion (fo b , 1989), com-
modities—tea, coffee, iron ore, fish prod-
ucts, manufactures, partners—EC 25%,
USSR and Eastern Europe 17%, US 19%,
Japan 10%
Imports: $24 7 billion (cif, 1989), com-
modities—petroleum, edible oils, textiles,
clothing, capital goods, partners—EC
33%, Middle East 19%, Japan 10%, US
9%, USSR and Eastern Europe 8%
External debt: $48 7 billion (1989)
Industrial production: growth rate 8 8%
(1989)
Electricity: 59,000,000 kW capacity,
215,000 million kWh produced, 260 kWh
per capita (1989)
Industries: textiles, food processing, steel,
machinery, transportation equipment, ce-
ment, jute manufactures, mining, petro-
leum, power, chemicals, pharmaceuticals,
electronics
Agriculture: accounts for about 33% of
GNP and employs 67% of labor force,
self-sufficient in food grains, principal
crops—rice, wheat, oilseeds, cotton, jute,
tea, sugarcane, potatoes, livestock—~<attle,
buffaloes, sheep, goats and poultry, fish
catch of about 3 million metric tons ranks
India in the world’s top 10 fishing nations
Illicit drugs: licit producer of opium poppy
for the pharmaceutical trade, but some
opium 1s diverted to international drug
markets, major transit country for illicit
narcotics produced in neighboring coun-
tries
Aid: US commitments, including Ex-Im
(FY 70-88), $4 2 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1980-87), $18 6 billion, OPEC
bilateral aid (1979-89), $315 million,
USSR (1970-88), $10 0 billion, Eastern
Europe (1970-88), $105 million
Currency: Indian rupee (plural—rupees), 1
Indian rupee (Re) = 100 paise
Exchange rates: Indian rupees (Rs) per
US$1—16 965 (January 1990), 16 226
(1989), 13 917 (1988), 12 962 (1987),
12 611 (1986), 12 369 (1985)
Fiscal year: 1 April-31 March','9e0fd82dc699f0a2bd1243b44a29958a5b972ec511b08857d8cf6e06ceb22256','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efc7a389adceee4ab83c749c72b2a94b51bb84c6cdd55336af478d0694a6bab7',1990,'PK','Pakistan','economy',389,'Overview: The Indian Ocean provides a
major transportation highway for the
movement of petroleum products from the
Middle East to Europe and North and
South American countries Fish from the
ocean are of growing economic importance
to many of the bordering countries as a
source of both food and exports Fishing
fleets from the USSR, Japan, Korea, and
Taiwan also exploit the Indian Ocean for
mostly shrimp and tuna Large reserves of
hydrocarbons are being tapped in the off-
shore areas of Saudi Arabia, Iran, India,
and Western Australia An estimated 40%
of the world’s offshore oil production
comes from the Indian Ocean Beach
sands rich in heavy minerals and offshore
placer deposits are actively exploited by
bordering countries, particularly India,
South Africa, Indonesia, Sri Lanka, and','b885c6d953d4f6323d97c480fa49af8046cf773e31d299b5475845bf53cb11c6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('117b79c01082ddac04a1ea40e651e658b5f49a24c3ae89095d447afcdba257d3',1990,'IQ','Iraq','economy',395,'Overview: The Ba‘thist regime engages in
extensive central planning and manage-
ment of industrial production and foreign
149
Approved for Release: 2020/08/12 C06554432
Iraq (continued)
trade while leaving some small-scale 1n-
dustry and services and most agriculture
to private enterprise The economy 1s
dominated by the oil sector, which pro-
vides about 95% of foreign exchange earn-
ings Since the early 1980s financial prob-
lems, caused by war expenditures and
damage to oil export facilities by Iran,
have led the government to implement
austerity measures and to reschedule for-
eign debt payments Oil exports have
gradually increased with the construction
of new pipelines Agricultural development
remains hampered by labor shortages, sa-
linization, and dislocations caused by pre-
vious land reform and collectivization pro-
grams The industrial sector, although
accorded high priority by the government,
1s under financial constraints New invest-
ment funds are generally allocated only to
projects that result in import substitution
or foreign exchange earnings
GNP: $35 billion, per capita $1,940, real
growth rate 5% (1989 est )
Inflation rate (consumer prices): 30-40%
(1989 est )
Unemployment rate: less than 5% (1989
est )
Budget: revenues $NA billion, expendi-
tures $35 billion, including capital expen-
ditures of NA (1989)
Exports: $12 5 billion (f 0 b , 1988), com-
modities—crude oil and refined products,
machinery, chemicals, dates, partners—
US, Brazil, USSR, Italy, Turkey, France,
Japan, Yugoslavia (1988)
Imports: $10 2 billion (c1f , 1988), com-
modities—manufactures, food, partners—
Turkey, US, FRG, UK, France, Japan,
Romania, Yugoslavia, Brazil (1988)
External debt: $40 billion (1988 est ), ex-
cluding debt to Persian Gulf Arab states
Industrial production: NA%
Electricity: 9,902,000 kW capacity,
20,000 million kWh produced, 1,110 kWh
per capita (1989)
Industries: petroleum, chemicals, textiles,
construction materials, food processing
Agriculture: accounts for less than 10% of
GNP but 33% of labor force; principal
products—wheat, barley, rice, vegetables,
dates, other fruit, cotton, wool, livestock—
cattle, sheep, not self-sufficient in food
output
Aid: US commitments, including Ex-Im
(FY70-80), $3 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $607 million, OPEC
bilateral aid (1980-89), $37 2 billion,
Communist countries (1970-88), $3 9 bil-
lion
Currency: Iraqi dinar (plural—dinars), 1
Traqi dinar (ID) = 1,000 fils
Exchange rates: Iraqi dinars (ID) per
US$1—0 3109 (fixed rate since 1982)
Fiscal year: calendar year
150
Approved for Release: 2020/08/12 C06554432
Overview: no economic activity
Overview: The economy ts small, open, and
trade dependent Agriculture, once the
most important sector, 1s now dwarfed by
industry, which accounts for 35% of GNP
and about 80% of exports and employs
20% of the labor force The government
has successfully reduced the rate of infla-
tion from double-digit figures in the late
1970s to about 4% in 1989 In 1987, after
years of deficits, the balance of payments
was brought into the black Unemploy-
ment, however, 1s a serious problem A
1989 unemployment rate of 17 7% placed
152
Approved for Release: 2020/08/12 C06554432
Ireland along with Spain as the countries
with the worst jobless records in Western
Europe
GDP: $31 4 billion, per capita $8,900, real
growth rate 4 3% (1989 est )
Inflation rate (consumer prices): 4 2%
(1989)
Unemployment rate: 17 7% (1989)
Budget: revenues $10 9 billion, expendi-
tures $11 2 billion, including capital ex-
penditures of $1 5 billion (1989)
Exports: $20 3 billion (fob, 1989), com-
modities—live ammals, animal products,
chemicals, data processing equipment, in-
dustrial machinery, partners—EC 74%
(UK 35%, FRG 11%, France 9%), US 8%
Imports: $17 3 billion (cif, 1989), com-
modities—food, animal feed, chemicals,
petroleum and petroleum products, ma-
chinery, textiles, clothing, partners—EC
66% (UK 42%, FRG 9%, France 4%), US
16%
External debt: $16 1 billion (1988)
Industrial production: growth rate 9 5%
(1989 est )
Electricity: 4,957,000 kW capacity,
14,480 million kWh produced, 4,080 kWh
per capita (1989)
Industries: food products, brewing, tex-
tiles, clothing, chemicals, pharmaceuticals,
machinery, transportation equipment,
glass and crystal
Agriculture: accounts for 11% of GNP
and 14 8% of the labor force, principal
crops—turnips, barley, potatoes, sugar
beets, wheat, livestock—-meat and dairy
products, 85% self-sufficient in food, food
shortages include bread grain, fruits, vege-
tables
Aid: NA
Currency: Irish pound (plural—pounds), 1
Irish pound (Ir) = 100 pence |
Exchange rates: Irish pounds (Ir) per
US$1—0 6399 (January 1990), 0 7047
(1989), 0 6553 (1988), 0 6720 (1987),
0 7454 (1986), 0 9384 (1985)
Fiscal year: calendar year
Overview: Israel has a market economy
with substantial government participation
It depends on imports for crude oil, food,
grains, raw materials, and military equip-
ment Despite limited natural resources,
Israel has developed its agriculture and
industry sectors on an intensive scale over
the past 20 years Industry accounts for
154
Approved for Release: 2020/08/12 C06554432
about 23% of the labor force, agriculture
for 6%, and services for most of the bal-
ance Diamonds, high-technology machin-
ery, and agricultural products (fruits and
vegetables) are the biggest export earners
The balance of payments has traditionally
been negative, but 1s offset by large trans-
fer payments and foreign loans Nearly
two-thirds of Israel’s $16 billion external
debt 1s owed to the US, which 1s its major
source for economic and military aid To
earn needed foreign exchange, Israel must
continue to exploit high-technology niches
in the international market, such as medi-
cal scanning equipment In 1987 the econ-
omy showed a 5 2% growth in real GNP,
the best gain in nearly a decade, in 1988-
89 the gain was only 1% annually, largely
because of the economic impact of the
Palestinian uprising (tntufadah) Inflation
dropped from an annual rate of over 400%
in 1984 to about 16% in 1987-88 without
any major increase in unemployment
GNP: $38 billion, per capita $8,700, real
growth rate 1% (1989)
Inflation rate (consumer prices): 20%
(1989)
Unemployment rate: 9% (December 1989)
Budget: revenues $24 2 billion, expendi-
tures $26 3 billion, including capital ex-
penditures of $7 billion (FY89 est )
Exports: $10 4 billion (f ob, 1989 est ),
commodities—polished diamonds, citrus
and other fruits, textiles and clothing, pro-
cessed foods, fertilizer and chemical prod-
ucts, military hardware, electronics, part-
ners—US, UK, FRG, France, Belgium,
Luxembourg, Italy
Imports: $12 4 billion (cif , 1989 est ),
commodities—mulitary equipment, rough
diamonds, oul, chemicals, machinery, iron
and steel, cereals, textiles, vehicles, ships,
aircraft, partners—US, FRG, UK, Swit-
zerland, Italy, Belgium, Luxembourg
External debt: $16 4 billion (March 1989)
Industrial production: growth rate — 1 5%
(1989)
Electricity: 4,392,000 kW capacity,
17,500 million kWh produced, 4,000 kWh
per capita (1989)
Industries: food processing, diamond cut-
ting and polishing, textiles, clothing,
chemicals, metal products, military equip-
ment, transport equipment, electrical
equipment, miscellaneous machinery, pot-
ash mining, high-technology electronics,
tourism
Agriculture: accounts for 5% of GNP,
largely self-sufficient in food production,
except for bread grains, principal prod-
ucts—citrus and other fruits, vegetables,
cotton, livestock products—beef, dairy,
and poultry
Aid: US commitments, including Ex-Im
(FY70-88), $15 8 billion, Western (non-
Approved for Release: 2020/08/12 C06554432
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 2 billion
Currency: new Israeli shekel (plural—
shekels), 1 new Israeli shekel (NIS) = 100
new agorot
Exchange rates: new Israeli shekels (NIS)
per US$1—1 9450 (January 1990), 1 9164
(1989), 1 5989 (1988), 1 5946 (1987),
1 4878 (1986), 1 1788 (1985)
Fiscal year: 1 April-31 March
GDP: $75 billion, per capita $1,350, real
growth rate 1 8% (1989 est )
Inflation rate (consumer prices): 68 8%
(1989)
Unemployment rate: 15 8% (1988)
Budget: revenues $12 1 billion, expendi-
tures $14 5 billion, including capital ex-
penditures of $2 08 billion (FY88 est )
Exports: $11 7 billion (fob, 1988), com-
modities—industrial products 70%, crops
and livestock products 25%, partners—
FRG 18 4%, Iraq 8 5%, Italy 8 2%, US
6 5%, UK 4 9%, Iran 4 7%
Imports: $14 3 billion (c1f , 1988), com-
modities—crude oil, machinery, transport
equipment, metals, pharmaceuticals, dyes,
plastics, rubber, mineral fuels, fertilizers,
chemicals, partners—FRG 14 3%, US
10 6%, Iraq 10 0%, Italy 7 0%, France
5 8%, UK 52%
External debt: $36 3 billion (November
1989)
Industrial production: growth rate 7 4%
(1988)
Electricity: 14,064,000 kW capacity,
40,000 million kWh produced, 720 kWh
per capita (1989)
Industries: textiles, food processing, min-
ing (coal, chromite, copper, boron miner-
als), steel, petroleum, construction, lum-
ber, paper
Agriculture: accounts for 20% of GDP and
employs majority of population;
products—tobacco, cotton, grain, olives,
sugar beets, pulses, citrus fruit, variety of
animal products; self-sufficient in food
most years
Illicit drugs: one of the world’s major sup-
pliers of licit opiate products, government
maintains strict controls over areas of
opium poppy cultivation and output of
poppy straw concentrate
Aid: US commitments, including Ex-Im
(FY70-88), $2 2 billion; Western (non-US)
countries, ODA and OOF bilateral com-
Approved for Release: 2020/08/12 C06554432
mitments (1970-87), $7 9 bilhon, OPEC
bilateral aid (1979-89), $665 million,
Communist countries (1970-88), $4 5 bil-
lion
Currency: Turkish lira (plural—tiiras), 1
Turkish lira (TL) = 100 kurus
Exchange rates: Turkish liras (TL) per
US$1—2,314 7 (November 1989), 1,422 3
(1988), 857 2 (1987), 674 5 (1986), 5220
(1985)
Fiscal year: calendar year','3e889986b77c06500af5ef903c4e7923d8fa795b2ac128c560f2cdc126faaa22','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aa11faf34f23a083855a3853195ecb6efe8540f53794b676b80339b9966b19f',1990,'IT','Italy','economy',400,'Overview: Since World War II the econ-
omy has changed from one based on agni-
culture into a ranking industrial economy,
with approximately the same total and per
capita output as France and the UK The
country 1s still divided into a developed
industrial north, dominated by large pri-
vate companies and state enterprises and
an undeveloped agricultural south Ser-
vices account for 58% of GDP, industry
37%, and agriculture 5% Most raw mate-
rials needed by industry and over 75% of
energy requirements must be imported
The economic recovery that began in mid-
1983 has continued through 1989, with
the economy growing at an annual aver-
age rate of 3% For the 1990s, Italy faces
the problems of refurbishing a tottering
communications system, curbing the in-
creasing pollution in major industrial cen-
ters, and adjusting to the new competitive
forces accompanying the ongoing
economic integration of the European
Community
GDP: $803 3 billion, per capita $14,000,
real growth rate 3 3% (1989 est )
Inflation rate (consumer prices): 6 6%
(1989 est )
Unemployment rate: 11 9% (1989)
Budget: revenues $355 billion, expendi-
tures $448 billion, including capital expen-
ditures of $NA (1989)
Exports: $141 6 billion (fo b, 1989), com-
modities—textiles, wearing apparel, met-
als, transportation equipment, chemicals,
partners--EC 57%, US 9%, OPEC 4%
Imports: $143 1 billion (fo b , 1989), com-
modities—-petroleum, industrial machin-
ery, chemicals, metals, food, agricultural
products, partners—EC 57%, OPEC 6%,
US 6%
External debt: NA
Industrial production: growth rate 2 9%
(1989)
Electricity: 56,022,000 kW capacity,
201,400 million kWh produced, 3,500
kWh per capita (1989)
Industries: machinery and transportation
equipment, iron and steel, chemicals, food
processing, textiles, motor vehicles
156
Approved for Release: 2020/08/12 C06554432
Agriculture: accounts for about 5% of
GNP and 5% of the work force,
self-sufficient in foods other than meat
and dairy products, principal crops—
fruits, vegetables, grapes, potatoes, sugar
beets, soybeans, grain, olives, fish catch of
554,000 metric tons in 1987
Aid: donor—ODA and OOF commitments
(1970-87), $18 7 billion
Currency: Italian lira (plural—thre), 1 Ital-
1an lira (Lit) = 100 centesimi
Exchange rates: Italian lire (Lit) per
US$1—1,262 5 (January 1990), 1,372 1
(1989), 1,301 6 (1988), 1,296 1 (1987),
1,490 8 (1986), 1,909 4 (1985)
Fiscal year: calendar year','f6d2972a1533429111bd4dcc091bf5eff1bc5dbc674ea74973429a572967c5c7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20f4632da3ee0fdcb6da7f3caea0b84494062ba8f8a97cff24e989e8bf2a3a6f',1990,'JM','Jamaica','economy',405,'Overview: The economy 1s based on sugar,
bauxite, and tourism In 1985 it suffered a
setback with the closure of some facilities
in the bauxite and alumina industry, a
major source of hard currency earnings
Since 1986 an economic recovery has been
under way In 1987 conditions began to
improve for the bauxite and alumina 1n-
dustry because of increases in world metal
prices The recovery has also been sup-
ported by growth in the manufacturing
and tourism sectors In September 1988,
Hurricane Gilbert inflicted severe damage
on crops and the electric power system, a
sharp but temporary setback to the econ-
omy By October 1989 the economic re-
covery from the hurricane was largely
complete and real growth was up about
3% for 1989
GDP: $3 8 billion, per capita $1,529, real
growth rate 3 0% (1989 est }
Inflation rate (consumer prices): 15%
(1989)
Unemployment rate: 18 7% (1988)
Budget: revenues $1 1 billion, expenditures
$1 5 billion, including capital expenditures
of $NA (FY88 est )
Exports: $948 million (fo b , 1989 est ),
commodities—bauxite, alumina, sugar,
bananas; partners—US 40%, UK, Can-
ada, Trinidad and Tobago, Norway
Imports: $1 6 billion (cif, 1989 est ),
commoadities—petroleum, machinery,
food, consumer goods, construction goods,
partners—US 46%, UK, Venezuela, Can-
ada, Japan, Trinidad and Tobago
External debt: $4 4 billion (1989 est )
Industrial production: growth rate 3%
(1989 est )
Electricity: 1,437,000 kW capacity, 2,390
million kWh produced, 960 kWh per cap-
ita (1989)
Industries: tourism, bauxite mining, tex-
tiles, food processing, light manufactures
Agriculture: accounts for about 9% of
GDP, one-third of work force, and 17% of
exports, commercial crops—sugarcane,
bananas, coffee, citrus, potatoes, and vege-
tables, livestock and livestock products
include poultry, goats, milk, not
self-sufficient in grain, meat, and dairy
products
Mllicit drugs: illicit cultivation of cannabis
has decreased, with production shifting
from large to small plots and nurseries to
evade aerial detection and eradication
Aid: US commitments, including Ex-Im
(FY 70-88), $1 1 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 2 billion, OPEC
bilateral aid (1979-89), $27 million, Com-
munist countries (1974-88), $349 million
Currency: Jamaican dollar (plural—dol-
lars), 1 Jamaican dollar (J$) = 100 cents
Exchange rates: Jamaican dollars (J$) per
US$1—6 5013 (January 1990), 5 7446
(1989), 5 4886 (1988), 5 4867 (1987),
5 4778 (1986), 5 5586 (1985)
Fiscal year: 1 April-31 March
Overview: Jan Mayen 1s a volcanic island
with no exploitable natural resources Eco-
nomic activity 1s limited to providing ser-
vices for employees of Norway’s radio and
meteorological stations located on the 1s-
land
Electricity: 15,000 kW capacity, 40 mil-
lon kWh produced, NA kWh per capita
(1989)','c99ef0d1456947846a42eed4dd26ceeaba4278cc50384f2a821fbd6d6b793af9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d8d1d24ac4b6446e017371a5b8f6e7f27615d55e795558e4e2a6ad486ce47ed',1990,'JP','Japan','economy',410,'Overview: Although Japan has few natural
resources, since 1971 it has become the
world’s third-largest tndustrial economy,
ranking behind only the US and the
USSR Government-industry cooperation,
a strong work ethic, and a comparatively
small defense allocation have helped Ja-
pan advance rapidly, notably in
high-technology fields Industry, the most
important sector of the economy, 1s
heavily dependent on imported raw mate-
rials and fuels Self-sufficent in rice, Japan
must import 50% of its requirements for
other grain and fodder crops Japan main-
tains one of the world’s largest fishing
fleets and accounts for nearly 15% of the
total global catch Overall economic
growth has been spectacular a 10% aver-
age in the 1960s, a 5% average in the
1970s and 1980s In 1989 strong tnvest-
ment and consumption spending helped
maintain growth at nearly 5% Inflation
remains low at 2 1% despite high oil
prices and a somewhat weaker yen Japan
continues to run a huge trade surplus, $60
billion in 1989, which supports extensive
investment in foreign properties
GNP: $1,914 1 billion, per capita $15,600,
real growth rate 4 8% (1989 est )
Inflation rate (consumer prices): 2 1%
(1989)
Unemployment rate: 2 3% (1989)
Budget: revenues $392 billion, expendi-
tures $464 billion, including capital expen-
ditures of $NA (FY89)
Exports: $270 billion (fo b , 1989), com-
modities—manufactures 97% (including
machinery 38%, motor vehicles 17%, con-
sumer electronics 10%), partners—US
34%, Southeast Asia 22%, Western Eu-
rope 21%, Communist countries 5%, Mid-
dle East 5%
Imports: $210 billion (cif , 1989), com-
modities—manufactures 42%, fossil! fuels
30%, foodstuffs 15%, nonfuel raw materi-
als 13%, partners—Southeast Asia 23%,
US 23%, Middle East 15%, Western Eu-
rope 16%, Communist countries 7%
External debt: $NA
Industrial production: growth rate 9 0%
(1989)
Electricity: 191,000,000 kW capacity,
700,000 million kWh produced, 5,680
kWh per capita (1989)
Industries: metallurgy, engineering, elec-
trical and electronic, textiles, chemicals,
automobiles, fishing
Agriculture: accounts for 3% of GNP,
highly subsidized and protected sector,
with crop yields among highest in world,
principal crops—rice, sugar beets, vegeta-
bles, fruit, animal products include pork,
poultry, dairy and eggs, about 50% self-
sufficient in food production, shortages of
161
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Japan (continued)
wheat, corn, soybeans, world’s largest fish
catch of 11 8 million metric tons in 1987
Aid: donor—ODA and OOF commitments
(1970-87), $57 5 billion
Currency: yen (plural—yen), 1 yen (¥) =
100 sen
Exchange rates: yen (¥) per US$1—
145 09 (January 1990), 137 96 (1989),
128 15 (1988), 144 64 (1987), 168 52
(1986), 238 54 (1985)
Defense Forces
Branches: Japan Ground Self-Defense
Force (army), Japan Maritime
Self-Defense Force (navy), Japan Aur Self-
Defense Force (air force), Maritime Safety
Agency (coast guard)
Military manpower: males 15-49,
32,181,866, 27,695,890 fit for military
service, 1,004,052 reach military age (18)
Fiscal year: 1 April-31 March annually
— Defense expenditures: 1% of GNP (1989
Communications est )
Railroads: 27,327 km total, 2,012 km
1 435-meter standard gauge and 25,315
km predominantly 1 067-meter narrow
gauge, 5,724 km doubletrack and multi-
track sections, 9,038 km | 067-meter
narrow-gauge electrified, 2,012 km 1 435-
meter standard-gauge electrified (1987)
Highways: 1,098,900 km total, 718,700
km paved, 380,200 km gravel, crushed
stone, or unpaved, 3,900 km national ex-
pressways, 46,544 km national highways,
43,907 km principal local roads, 86,930
km prefectural roads, and 917,619 other
(1987)
Inland waterways: about 1,770 km, seago-
ing craft ply all coastal inland seas
Pipelines: crude oil, 84 km, refined prod-
ucts, 322 km, natural gas, 1,800 km
Ports: Chiba, Muroran, Kitakyushu,
Kobe, Tomakomat, Nagoya, Osaka, To-
kyo, Yokkaichi, Yokohama, Kawasaki,
Nugata, Fushiki-Toyama, Shimizu, Hi-
meji, Wakayama-Shimozu, Shimonosek,
Tokuyama-Shimomatsu
Merchant marine: 1,088 ships (1,000 GRT
or over) totaling 23,597,688 GRT/
36,655,266 DWT, includes 7 passenger,
57 short-sea passenger, 4 passenger cargo,
108 cargo, 44 container, 27 roll-on/roll-off
cargo, 135 refrigerated cargo, 117 vehicle
carrier, 237 petroleum, oils, and lubricants
(POL) tanker, 21 chemical tanker, 42 liq-
uefied gas, 12 combination ore/oil, 3 spe-
cialized tanker, 272 bulk, 1 combination
bulk, 1 multifunction large-load carrier
Civil air: 341 major transport aircraft
Airports: 165 total, 156 usable, 128 with
permanent-surface runways, 2 with run-
ways over 3,659 m, 27 with runways
2,440-3,659 m, 55 with runways 1,220-
2,439 m
Telecommunications: excellent domestic
and international service, 64,000,000 tele-
phones, stations—318 AM, 58 FM,
12,350 TV (196 major—1 kw or greater),
satellite earth stations—4 Pacific Ocean
INTELSAT and 1 Indian Ocean
INTELSAT, submarine cables to US (via
Guam), Philippines, China, and USSR
162
Approved for Release: 2020/08/12 C06554432
Jarvis Island
(territory of the US)
1km
reels
reefs
reels
South Pacific Ocean
See regional map X
Overview: no economic activity
Overview: More than 90% of this com-
mand economy 1s socialized, agricultural
land 1s collectivized, and state-owned 1n-
dustry produces 95% of manufactured
goods State control of economic affairs 1s
unusually tight even for a Communist
country because of the small size and ho-
mogeneity of the society and the strict
one-man rule of Kim Economic growth
during the period 1984-89 has averaged
approximately 3% Abundant natural re-
sources and hydropower form the basis of
industrial development Output of the ex-
tractive industries includes coal, iron ore,
magnesite, graphite, copper, zinc, lead,
and precious metals Manufacturing em-
phasis 1s centered on heavy industry, with
light industry lagging far behind The use
of high-yielding seed varieties, expansion
of irrigation, and the heavy use of fertiliz-
ers have enabled North Korea to become
largely self-sufficient in food production
North Korea, however, 1s far behind
South Korea in economic development
and living standards
GNP: $28 billion, per capita $1,240, real
growth rate 3% (1989)
Inflation rate (consumer prices): NA%
Unemployment rate: officially none
Budget: revenues $15 6 billion; expendi-
tures $15 6 billion, including capital ex-
penditures of $NA (1989)
Exports: $2 4 billion (fo b , 1988), com-
modities—miunerals, metallurgical prod-
ucts, agricultural products, manufactures,
partners—USSR, China, Japan, FRG,
Hong Kong, Singapore
17!
Approved for Release: 2020/08/12 C06554432
Korea, North (continued)
Imports: $3 1 bithon (fob, 1988), com-
modities—petroleum, machinery and
equipment, coking coal, grain, partners—
USSR, Japan, China, FRG, Hong Kong,
Overview: The driving force behind the
economy’s dynamic growth has been the
planned development of an export-oriented
economy in a vigorously entrepreneurial
society GNP increased almost 13% in
both 1986 and 1987 and 12% in 1988 be-
fore slowing to 6 5% in 1989 Such a
rapid rate of growth was achieved with an
inflation rate of only 3% in the period
1986-87, rising to 7% in 1988 and 5% in
1989 Unemployment ts also low, and
some labor bottlenecks have appeared in
several processing industries While the
South Korean economy ts expected to
grow at more than 5% annually during
the 1990s, labor unrest—which led to sub-
stantial wage hikes in 1987-89—threatens
to undermine noninflationary growth
GNP: $200 billion, per capita $4,600, real
growth rate 6 5% (1989)
Inflation rate (consumer prices): 5% (1989)
Unemployment rate: 3% (1989)
Budget: revenues $33 6 billion, expendi-
tures $33 6 billion, including capital ex-
penditures of NA (1990)
Exports: $62 3 billion (fob, 1989), com-
modities—textiles, clothing, electronic and
electrical equipment, footwear, machinery,
steel, automobiles, ships, fish, partners—
US 33%, Japan 21%
Imports: $61 3 billion (c1f, 1989), com-
modities—machuinery, electronics and
electronic equipment, ol, steel, transport
equipment, textiles, organic chemicals,
grains, partners—Japan 28%, US 25%
(1990)
External debt: $30 5 billion (September
1989)
Industrial production: growth rate 3 5%
(1989)
Electricity: 20,500,000 kW capacity,
80,000 million kWh produced, 1,850 kWh
per capita (1989)
Industries: textiles, clothing, footwear,
food processing, chemicals, steel, electron-
1cs, automobile production, ship building
Agriculture: accounts for 11% of GNP
and employs 21% of work force (including
fishing and forestry), principal crops—rice,
root crops, barley, vegetables, fruit, live-
stock and livestock products—cattle, hogs,
chickens, milk, eggs, self-sufficient in food,
except for wheat, fish catch of 2 9 million
metric tons, seventh-largest in world
Aid: US commitments, including Ex-Im
(FY70-85), $3 9 billion
Currency: South Korean won (plural—
won), | South Korean won (W) = 100
chon (theoretical)
Exchange rates: South Korean won (W)
per US$1—683 43 (January 1990), 671 46
(1989), 731 47 (1988), 822 57 (1987),
881 45 (1986), 870 02 (1985)
Fiscal year: calendar year
Imports: $764 million (cif, 1988), includ-
ing ald, commodities—food, clothing,
farm equipment, petroleum, partners—
US, Western Europe, USSR
External debt: $4 4 billion (1988)
Industrial production: growth rate 7%
(1989 est )
Electricity: 2,265,000 kW capacity, 1,740
million kWh produced, 120 kWh per cap-
ita (1989)
Industries: food, beverages, chemicals (fer-
tilizer, soap, paints), petroleum products,
textiles, nonmetallic mineral products (ce-
ment, glass, asbestos), tobacco
Agriculture: accounts for 50% of GDP,
over 80% of labor force, and about 90% of
exports, cash crops—cotton, cashew nuts,
sugarcane, tea, shrimp, other crops—cas-
sava, corn, rice, tropical fruits, not self-
sufficient in food
Aid: US commitments, including Ex-Im
(FY 70-88), $282 million, Western (non-
US) countries, ODA and OOF bilateral
Approved for Release: 2020/08/12 C06554432
commitments (1970-87), $3 1 billion,
OPEC bilateral aid (1979-89), $37 million,
Communist countries (1970-88), $887 mil-
lion
Currency: metical (plural—meticais), 1
metical (Mt) = 100 centavos
Exchange rates: meticais (Mt) per US$1—
800 (September 1989), 528 60 (1988),
289 44 (1987), 40 43 (1986), 43 18 (1985)
Fiscal year: calendar year
mports: $1 9 billion (fob, 1988), com-
nodities—consumer goods, foodstuffs,
nining and other machinery, transport
‘quipment, fuels, partners—US, Belgium,
“rance, FRG, Italy, Japan, UK
<xternal debt: $8 6 billion (December
1989 est )
ndustrial production: growth rate NA%
Llectricity: 2,574,000 kW capacity, 5,550
nillion kWh produced, 160 kWh per cap-
ta (1989)
ndustries: mining, mineral processing,
‘onsumer products (including textiles,
ootwear, and cigarettes), processed foods
ind beverages, cement, diamonds
Agriculture: cash crops—coffee, palm oil,
ubber, quinine, food crops—cassava, ba-
lianas, root crops, corn
llicit drugs: illicit producer of cannabis,
nostly for domestic consumption
Aid: US commitments, including Ex-Im
FY 70-88), $998 million, Western (non-
JS) countries, ODA and OOF bilateral
commitments (1970-87), $6 0 billion,
IPEC bilateral aid (1979-89), $35 million,
Communist countries (1970-88), $263 mil-
1on
Currency: zaire (plural—zaire), 1 zaire (Z)
= 100 makuta
Exchange rates: zaire (Z) per US$1—
465 000 (January 1989), 381 445 (1989),
187 070 (1988), 112 403 (1987), 59 625
1986), 49 873 (1985)
Fiscal year: calendar year','3b76136decfecbf71c8fb9e83d2645d2f9c17534d793c67e96fb2c2a45f52673','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bb79953f166c136c1d2d72354ae2d6a480e425dba33274c59567ac58dba2369',1990,'JE','Jersey','economy',415,'Overview: The economy 1s based largely on
financial services, agriculture, and tour-
ism Potatoes, cauliflower, tomatoes, and
especially flowers are important export
crops, shipped mostly to the UK The Jer-
sey breed of dairy cattle 1s known world-
wide and represents an important export
earner Milk products go to the UK and
other EC countries In 1986 the finance
sector overtook tourism as the main con-
tributor to GDP, accounting for 40% of
the island’s output In recent years the
163
Approved for Release: 2020/08/12 C06554432
Jersey (continued)
electronics industry has developed along-
side the traditional manufacturing of kni-
twear All raw material and energy re-
quirements are imported, as well as a
large share of Jersey’s food needs
GDP: $NA, per capita $NA, real growth
rate 8% (1987 est )
Inflation rate (consumer prices): 8% (1988
est )
Unemployment rate: NA%
Budget: revenues $308 0 million, expendi-
tures $284 4 million, including capital ex-
penditures of NA (1985)
Exports: $NA; commodities—light indus-
trial and electrical goods, foodstuffs, tex-
tiles, partners—UK
Imports: $NA, commodities—machinery
and transport equipment, manufactured
goods, foodstuffs, mineral fuels, chemicals,
partners—UK
External debt: $NA
Industrial production: growth rate NA%
Electricity: 50,000 kW standby capacity
(1989), power supplied by France
Industries: tourism, banking and finance,
dairy
Agriculture: potatoes, cauliflowers, toma-
toes, dairy and cattle farming
Aid: none
Currency: Jersey pound (plural—pounds),
1 Jersey pound (£J) = 100 pence
Exchange rates: Jersey pounds (£J) per
US$1—0 6055 (January 1990), 0 6099
(1989), 0.5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985), the Jersey
pound 1s at par with the British pound
Fiscal year: 1 April-31 March
Overview: Economic activity 1s limited to
providing services to US military person-
nel and contractors located on the island
All food and manufactured goods must be
imported','16b3bf9a4cd9eff0820224eec3aeb0991c955c4dd596bcc3609459c974b93051','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('141c00c6b3960a452646ebb5781e6912777738d38b14c97e6cdef3309c88b2ac',1990,'JO','Jordan','economy',420,'Overview: Jordan was a secondary benefi-
ciary of the oil boom of the late 1970s
and early 1980s, when its GNP growth
averaged 10-12% Recent years, however,
have witnessed a sharp reduction in cash
aid from Arab oil-producing countries and
in worker remittances, with growth aver-
aging 1-2% Imports—mainly oil, capital
goods, consumer durables, and
foodstuffs—have been outstripping exports
by roughly $2 billion annually, the differ-
ence being made up by aid, remittances,
and borrowing In 1989 the government
pursued policies to encourage private 1n-
vestment, curb imports of luxury goods,
165
Approved for Release: 2020/08/12 C06554432
Jordan (continued)
promote exports, reduce the budget deficit,
and, 1n general, reinvigorate economic
growth Success will depend largely on
exogenous forces, such as the absence of
drought and a pickup in outside support
Down the road, the completion of the pro-
posed Unity Dam on the Yarmuk 1s vital
to meet rapidly growing requirements for
water
GNP: $5 2 billion, per capita $1,760; real
growth rate 0% (1989)
Inflation rate (consumer prices): 35% (1989
est )
Unemployment rate: 9-10% (December
1989 est.)
Budget: revenues $0 92 billion, expendi-
tures $1.6 billion, including capital expen-
ditures of $540 million (1989 est )
Exports: $0 910 billion (fo b , 1989 est ),
commoadities—fruits and vegetables, phos-
phates, fertilizers, partners—Iraq, Saudi
Arabia, India, Kuwait, Japan, China, Yu-
goslavia, Indonesia
Imports: $1 7 billion (c1f, 1989 est),
commodities—crude oil, textiles, capital
goods, motor vehicles, foodstuffs, part-
ners—EC, US, Saudi Arabia, Japan, Tur-
key, Romama, China, Taiwan
External debt: $8 3 billion (December
1989)
Industrial production: growth rate —7 8%
(1988 est )
Electricity: 981,000 kW capacity, 3,500
million kWh produced, 1,180 kWh per
capita (1989)
Industries: phosphate mining, petroleum
refining, cement, potash, light manufac-
turing
Agriculture: accounts for only 5% of GDP,
principal products are wheat, barley, cit-
rus fruit, tomatoes, melons, olives, live-
stock—sheep, goats, poultry, large net 1m-
porter of food
Aid: US commitments, including Ex-Im
(FY70-88), $1 7 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 2 billion, OPEC
bilateral aid (1979-89), $9 5 billion, Com-
munist countries (1970-88), $44 million
Currency: Jordanian dinar (plural—
dinars), | Jordanian dinar (JD) = 1,000
fils
Exchange rates: Jordanian dinars (JD) per
US$1—0 6557 (January 1990), 0 5704
(1989), 0 3715 (1988), 0 3387 (1987),
0 3499 (1986), 0 3940 (1985)
Fiscal year: calendar year
Overview: no economic activity','ce0f263f00d3c7fa423807a2391eca86d9914b73ef5b957e17ba1b0c05a440d6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0472693b5290f7908af1d1dd55b4b721a9a1f5bc3f8d14a496c4942c76f70b63',1990,'KE','Kenya','economy',425,'Overview: A serious underlying economic
problem 1s Kenya’s 3 8% annual popula-
tion growth rate—one of the highest in
the world In the meantime, GDP growth
in the near term has kept slightly ahead
of population—annually averaging 5 2% in
the 1986-88 period Undependable
weather conditions and a shortage of ara-
ble land hamper long-term growth 1n agri-
culture, the leading economic sector
GDP: $8 5 billion, per capita $360; real
growth rate 4 9% (1989 est.)
Inflation rate (consumer prices): 8 3%
(1988)
Unemployment rate: NA%, but there is a
high level of unemployment and underem-
ployment
Budget: revenues $2 3 billion, expenditures
$2 6 billion, including capital expenditures
of $0 71 billion (FY87)
Exports: $1 0 billion (fo b , 1988), com-
modities—coffee 20%, tea 18%, manufac-
tures 15%, petroleum products 10%
(1987), partners—Western Europe 45%,
Africa 22%, Far East 10%, US 4%, Mid-
die East 3% (1987)
Imports: $1 8 billion (fob, 1988); com-
modities—machinery and transportation
equipment 36%, raw materials 33%, fuels
168
Approved for Release: 2020/08/12 C06554432
and lubricants 20%, food and consumer
goods 11% (1987), partners—Western Eu-
rope 49%, Far East 20%, Middle East
19%, US 7% (1987)
External debt: $6 2 billion (December
1989 est )
Industrial production: growth rate 4 8%
(1987 est )
Electricity: 587,000 kW capacity, 2,250
million kWh produced, 90 kWh per capita
(1989)
Industries: small-scale consumer goods
(plastic, furniture, batteries, textiles, soap,
cigarettes, flour), agricultural processing,
oil refining, cement, tourism
Agriculture: most important sector, ac-
counting for 30% of GDP, about 80% of
the work force, and over 50% of exports,
cash crops—coffee, tea, sisal, pineapple,
food products—corn, wheat, sugarcane,
fruit, vegetables, dairy products, food out-
put not keeping pace with population
growth
Illicit drugs: illicit producer of cannabis
used mostly for domestic consumption,
widespread cultivation of cannabis and gat
on small plots, transit country for heroin
and methaqualone en route from South-
west Asia to West Africa, Western Eu-
rope, and the US
Aid: US commitments, including Ex-Im
(FY 70-88), $771 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $6 0 billion,
OPEC bilateral! aid (1979-89), $74 million,
Communist countries (1970-88), $83 mil-
hon
Currency: Kenyan shilling (plural—shil-
lings), 1 Kenyan shilling (KSh) = 100
cents
Exchange rates: Kenyan shillings (KSh)
per US$1—21 749 (December 1989),
20 572 (1989), 17 747 (1988), 16 454
(1987), 16 226 (1986), 16 432 (1985)
Fiscal year: | July-30 June
Overview: no economic activity
Approved for Release: 2020/08/12 C06554432','c710d870217a788c9ae982f916b65402eb1ba366bc8a895bc58f2d01fa992bb1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bdcb79e38edeac675b95061379a10f4cd2325571e44ecfa5dae654ad8a0f668',1990,'KI','Kiribati','economy',430,'Overview: The country has few national
resources Phosphate deposits were ex-
hausted at the time of independence in
1979 Copra and fish now represent the
bulk of production and exports The econ-
omy has fluctuated widely in recent years
Real GDP declined about 8% in 1987, as
the fish catch fell sharply to only
one-fourth the level of 1986 and copra
production was hampered by repeated
rains Output rebounded strongly in 1988,
with real GDP growing by 17% The up-
turn in economic growth came from an
increase in copra production and a good
fish catch Following the strong surge in
output in 1988, GDP remained about the
same in 1989
GDP: $34 million, per capita $500, real
growth rate 0% (1989)
Inflation rate (consumer prices): 3 1%
(1988)
Unemployment rate: 2% (1985); consider-
able underemployment
Budget: revenues $22 0 million, expendi-
tures $12 7 million, including capital ex-
penditures of $9 7 million (1988)
Exports: $5 1 million (fob, 1988), com-
modities—fish 55%, copra 42%,
partners—EC 20%, Marshall Islands 12%,
US 8%, American Samoa 4% (1985)
Imports: $21 5 million (c1 f , 1988), com-
moadities—foodstuffs, fuel, transportation
equipment, partners—Australia 39%, Ja-
pan 21%, NZ 6%, UK 6%, US 3% (1985)
External debt: $2 0 million (December
1987 est )
Industrial production: growth rate NA%
Electricity: 5,000 kW capacity, 13 million
kWh produced, 190 kWh per capita
(1989)
Industries: fishing, handicrafts
Agriculture: accounts for 30% of GDP (in-
cluding fishing); copra and fish contribute
95% to exports, subsistence farming pre-
dominates, food crops—taro, breadfruit,
sweet potatoes, vegetables, not
self-sufficient in food
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $245 million
Currency: Australian dollar (plural—dol-
lars), 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A)
per US$1—1 2784 (January 1990), 1 2618
(1989), 1 2752 (1988), 1 4267 (1987),
1 4905 (1986), 1 4269 (1985)
Fiscal year: NA
Approved for Release: 2020/08/12 C06554432','2edf926d1b72a49f549fc4d89f1176a814ac0f4b973d1e01eeb90e3088935bda','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd0a7566116296ea9e35bf405a67e023fd3d920e0ca7bab919a6e36688cc5018',1990,'SG','Singapore','economy',431,'External debt: $2 5 billion hard currency
(1989)
Industrial production: growth rate NA%
Electricity: 6,440,000 kW capacity,
40,250 million kWh produced, 1,740 kWh
per capita (1989)
Industries: machine building, military
products, electric power, chemicals, min-
ing, metallurgy, textiles, food processing
Agriculture: accounts for about 25% of
GNP and 36% of work force, principal
crops—rice, corn, potatoes, soybeans,
pulses, livestock and livestock products—
cattle, hogs, pork, eggs, not self-suffictent
in grain, fish catch estimated at 1 7 mil-
lon metric tons in 1987
Aid: Communist countries (1970-88), $1 3
billion
Currency: North Korean won (plural—
won), | North Korean won (Wn) = 100
chon
Exchange rates: North Korean won (Wn)
per US$1—2 3 (December 1989), 2 13
(December 1988), 0 94 (March 1987), NA
(1986), NA (1985)
Fiscal year: calendar year
Overview: Singapore has an open entrepre-
neurial economy with strong service and
manufacturing sectors and excellent inter-
national trading links derived from its en-
trepéot history During the 1970s and early
1980s, the economy expanded rapidly,
achieving an average annual growth rate
of 9% Per capita GDP 1s among the high-
est in Asia In 1985 the economy regis-
tered its first drop in 20 years and
achieved less than a 2% increase in 1986
Recovery was strong Estimates for 1989
suggest a 9 2% growth rate based on ris-
ing demand for Singapore’s products in
OECD countries, a strong Japanese yen,
and improved competitiveness of domestic
manufactures
GDP: $27 5 billion, per capita $10,300,
real growth rate 9 2% (1989 est )
Inflation rate (consumer prices): 3 5%
(1989 est )
Unemployment rate: 2% (1989 est )
Budget: revenues $6 6 billion, expenditures
$5 9 billion, including capital expenditures
of $2 2 billion (FY88)
Exports: $46 billion (fo b , 1989 est ),
commodities—includes transshipments to
Malaysia—petroleum products, rubber,
electronics, manufactured goods, part-
ners—US 24%, Malaysia 14%, Japan 9%,
Thailand 6%, Hong Kong 5%, Australia
3%, FRG 3%
Imports: $53 billion (cif, 1989 est ), com-
modities—aincludes transshipments from
Malaysia—<apital equipment, petroleum,
chemicals, manufactured goods,
foodstuffs, partners—Japan 22%, US 16%,
Malaysia 15%, EC 12%, Kuwait 1%
External debt: $5 2 billion (December
1988)
Industrial production: growth rate 9%
(1989 est )
Approved for Release: 2020/08/12 C06554432
Electricity: 4,000,000 kW capacity,
12,000 million kWh produced, 4,490 kWI
per capita (1989)
Industries: petroleum refining, electronics,
oul drilling equipment, rubber processing
and rubber products, processed food and
beverages, ship repair, entrepét trade, fi-
nancial services, biotechnology
Agriculture: occupies a position of minor
importance in the economy, self-sufficient
in poultry and eggs, must import much of
other food, major crops—rubber, copra,
fruit, vegetables
Aid: US commitments, including Ex-Im
(FY 70-83), $590 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $882 million
Currency: Singapore dollar (plural—dol-
lars), 1 Singapore dollar (S$) = 100 cents
Exchange rates: Singapore dollars per
US$1—1 8895 (January 1990), 1 9503
(1989), 2 0124 (1988), 2 1060 (1987),
2 1774 (1986), 2 2002 (1985)
Fiscal year: 1 April-31 March
Imports: $598 0 million (fo b, 1988 est ),
commodities—grain, consumer goods,
crude oil, machinery, chemicals,
partners—USSR, Australia, UK
External debt: $2 25 billion (December
1989 est )
Industrial production: growth rate NA%
Electricity: 245,000 kW capacity, 600 mil-
lion kWh produced, 240 kWh per capita
(1989)
Industries: petroleum refinery (operates on
imported crude oil), fish
Agriculture: accounts for 13% of GNP
and 45% of labor force, products—grain,
qat (mildly narcotic shrub), coffee, fish,
livestock, fish and honey major exports,
most food imported
Aid: US commitments, including Ex-Im
(FY70-80), $4 5 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $241 million, OPEC
bilateral aid (1979-89), $279 million,
Communist countries (1970-88), $2 2 bil-
hon
Currency: Yemeni dinar (plural—dinars),
1 Yemeni dinar (YD) = 1,000 fils
Exchange rates: Yemeni dinars (YD) per
US$1—0 3454 (fixed rate)
Fiscal year: calendar year','82afc5c78c26f6f0d970c70397e32e0f52f3ee71411bc070384d17611ce22e25','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac8a285756a68112e6b6b401468b3fac88898ab8a3c5178515e49f2d4f791d4',1990,'KW','Kuwait','economy',437,'Overview: The oil sector dominates the
economy Of the countries in the Middle
East, Kuwait has oil reserves second only
to those of Saudi Arabia Earnings from
hydrocarbons generate over 90% of both
export and government revenues and con-
tribute about 40% to GDP Most of the
nonoil sector is dependent upon oil-derived
government revenues to provide
infrastructure development and to pro-
mote limited industrial diversification The
economy 1s heavily dependent upon for-
eign labor—Kuwaitis account for less
than 20% of the labor force The early
years of the Iran-Iraq war pushed Ku-
wait’s GDP well below its 1980 peak,
however, during the period 1986-88, GDP
increased each year, rising to 5% in 1988
GDP: $20 5 billion, per capita $10,500,
real growth rate 5 0% (1988)
Inflation rate (consumer prices): 1 5%
(1988)
Unemployment rate: 0%
Budget: revenues $7 1 billion, expenditures
$10 5 billion, including capital expendi-
tures of $3 1 billion (FY88)
Exports: $7 1 billion (fob, 1988), com-
modities—oil 90%, partners—Japan, It-
aly, FRG, US
Imports: $5 2 billion (fo b , 1988), com-
modities—food, construction material,
vehicles and parts, clothing, partners—
Japan, US, FRG, UK
External debt: $7 2 billion (December
1989 est )
Industrial production: growth rate 3%
(1988)
Electricity: 8,287,000 kW capacity,
21,500 million kWh produced, 10,710
kWh per capita (1989)
Approved for Release: 2020/08/12 C06554432
Industries: petroleum, petrochemicals, de-
salination, food processing, salt, construc-
tion
Agriculture: virtually none, dependent on
imports for food, about 75% of potable
water must be distilled or imported
Aid: donor—pledged $18 3 billion in bilat-
eral aid to less developed countries (1979-
89)
Currency: Kuwaiti dinar (plural—dinars),
1 Kuwaiti dinar (KD) = 1,000 fils
Exchange rates: Kuwaiti dinars (KD) per
US$1—0 2915 (January 1990), 0 2937
(1989), 0 2790 (1988), 0 2786 (1987),
0 2919 (1986), 0 3007 (1985)
Fiscal year: | July-30 June
Overview: One of the world’s poorest na-
tions, Laos has had a Communist cen-
trally planned economy with government
ownership and control of productive enter-
prises of any size Recently, however, the
government has been decentralizing con-
trol and encouraging private enterprise
Laos 1s a landlocked country with a primi-
tive infrastructure, that 1s, 1t has no rail-
roads, a rudimentary road system, limited
external and internal telecommunications,
and electricity available in only a limited
area Subsistence agriculture 1s the main
occupation, accounting for over 60% of
GDP and providing about 85-90% of total
employment The predominant crop 1s
rice For the foreseeable future the econ-
omy will continue to depend for its sur-
vival on foreign aid—from CEMA, IMF,
and other international sources
GDP: $585 million, per capita $150, real
growth rate 3% (1989 est )
Inflation rate (consumer prices): 35% (1989
est )
Unemployment rate: 15% (1989 est )
Budget: revenues $71 million, expenditures
$198 million, including capital expendi-
tures of $132 million (1988 est )
Exports: $57 5 million (f ob, 1989 est ),
commodities— electricity, wood products,
coffee, tin, partners—Thailand, Malaysia,
Vietnam, USSR, US
Imports: $219 million (cif, 1989 est ),
commodities—food, fuel oil, consumer
goods, manufactures, partners—Thailand,
USSR, Japan, France, Vietnam
External debt: $964 million (1989 est )
Industrial production: growth rate 8%
(1989 est )
Electricity: 176,000 kW capacity, 900 mil-
lion kWh produced, 225 kWh per capita
(1989)
Industries: tin mining, timber, electric
power, agricultural processing
Approved for Release: 2020/08/12 C06554432
Agriculture: accounts for 60% of GDP and
employs most of the work force, subsis-
tence farming predominates, normally
self-sufficient, principal crops—trice (80%
of cultivated land), potatoes, vegetables,
coffee, sugarcane, cotton
Iicit drugs: illicit producer of cannabis
and opium poppy for the international
drug trade, production of cannabis
increased in 1989, marijuana and heroin
are shipped to Western countries, includ-
ing the US
Aid: US commitments, including Ex-I[m
(FY70-79), $276 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $468 million,
Communist countries (1970-88), $895 mil-
hon
Currency: new kip (plural—kips), 1 new
kip (NK) = 100 at
Exchange rates: new kips (NK) per
US3$1—700 (December 1989), 725 (1989),
350 (1988), 200 (1987), 108 (1986), 95
(1985)
Fiscal year: 1 July-30 June','550a938229694456845b81d62cc52892f8f84d5b91781019bf5afd2030544942','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c17cb731e6445234ef7a29abe071e74bb296d6ba385ca3fd5d34631042cb8e57',1990,'LB','Lebanon','economy',442,'Overview: Severe factional infighting in
1989 has been destroying physical prop-
erty, interrupting the established pattern
of economic affairs, and practically ending
chances of restoring Lebanon’s position as
a Middle Eastern entrepét and banking
hub The ordinary Lebanese citizen strug-
gles to keep afioat in an environment of
physical danger, high unemployment, and
growing shortages The central govern-
ment’s ability to collect taxes has suffered
greatly from militia control and taxation
of local areas As the civil strife persists,
the US dollar has become more and more
the medium of exchange Transportation,
communications, and other parts of the
infrastructure continue to deteriorate
Family remittances, foreign political
money going to the factions, international
emergency aid, and a small volume of
manufactured exports help prop up the
battered economy Prospects for 1990 are
grim, with expected further declines in
economic activity and living standards
GDP: $2 3 billion, per capita $700, real
growth rate NA% (1989 est )
Inflation rate (consumer prices): 60% (1989
est )
Unemployment rate: 33% (1987 est )
Budget: revenues $50 million, expenditures
$650 million, including capital expendi-
tures of $NA (1988 est )
Exports: $1 0 billion (fo b , 1987), com-
modities—agricultural products, chemi-
cals, textiles, precious and semiprecious
metals and jewelry, metals and metal
products, partners—Saudi Arabia 16%,
Switzerland 8%, Jordan 6%, Kuwait 6%,
US 5%
Imports: $1 5 billion (cif, 1987), com-
modities—NA, partners—lItaly 14%,
France 12%, US 6%, Turkey 5%, Saudi
Arabia 3%
External debt: $935 million (December
1988)
Industrial production: growth rate NA%
Electricity: 1,381,000 kW capacity, 3,870
million kWh produced, 1,170 kWh per
capita (1989)
Industries: banking, food processing, tex-
tiles, cement, oil refining, chemicals, jew-
elry, some metal fabricating
Agriculture: accounts for about one-third
of GDP, principal products—citrus fruits,
vegetables, potatoes, olives, tobacco, hemp
(hashish), sheep, and goats, not
self-sufficient in grain
Mlicit drugs: illicit producer of opium
poppy and cannabis for the international
drug trade, opium poppy production in Al
Biqd‘ 1s increasing, most hashish produc-
tion 1s shipped to Western Europe
Approved for Release: 2020/08/12 C06554432
Aid: US commitments, including Ex-Im
(FY70-88), $356 million; Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $509 million,
OPEC bilateral aid (1979-89), $962 mil-
lion, Communist countries (1970-86), $9
million
Currency: Lebanese pound (plural—
pounds), 1 Lebanese pound (£L) = 100
plasters
Exchange rates: Lebanese pounds (£L) per
US$1—474 21 (December 1989), 496 69
(1989), 409 23 (1988), 224 60 (1987), 38 37
(1986), 16 42 (1985)
Fiscal year: calendar year','644ec0682781e81a7b5b44c9f5a56d0b090df51a16efacac39aa4080284b2191','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d49f23331e0182a13ba50b758adf5f82c0c3ab7f961501c95a8c3349f1ddcd5',1990,'LS','Lesotho','economy',447,'Overview: Small, landlocked, and moun-
tainous, Lesotho has no important natural
resources other than water Its economy 1s
based on agriculture, light manufacturing,
and remittances from laborers employed
in South Africa Subsistence farming 1s
the principal occupation for about 86% of
the domestic labor force and accounts for
about 20% of GDP Manufacturing de-
pends largely on farm products to support
the milling, canning, leather, and jute in-
dustries, other industries include textile,
clothing, and light engineering Industry’s
share of total GDP rose from 6% in 1982
to 10 5% in 1987 During the period 1985-
87 real GDP growth averaged 2 9% per
year, only slightly above the population
growth rate In FY89 per capita GDP was
only $245 and nearly 25% of the labor
force was unemployed
GDP: $412 million, per capita $245, real
growth rate 8 2% (FY89 est )
Inflation rate (consumer prices): 15 0%
(FY89 est )
Unemployment rate: 23% (1988)
180
Approved for Release: 2020/08/12 C06554432
Budget: revenues $159 million, expendi-
tures $224 million, including capital ex-
penditures of $68 million (FY89 est )
Exports: $55 million (fob, FY89 est ),
commodities—wool, mohair, wheat, cat-
tle, peas, beans, corn, hides, skins, baskets,
partners—South Africa 87%, EC 10%,
(1985)
Imports: $526 million (fob, FY89 est ),
commodities—mainly corn, building ma-
terials, clothing, vehicles, machinery, med-
icines, petroleum, oil, and lubricants, part-
ners—South Africa 95%, EC 2% (1985)
External debt: $235 million (December
1988)
Industrial production: growth rate 10 3%
(1988 est )
Electricity: power supplied by South Af-
rica
Industries: tourism
Agriculture: exceedingly primitive, mostly
subsistence farming and livestock, princi-
pal crops are corn, wheat, pulses,
sorghum, barley
Aid: US commitments, including Ex-Im
(FY70-88), $252 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $714 million,
OPEC bilateral aid (1979-89), $4 million,
Communist countries (1970-88), $14 mil-
lion
Currency: lot: (plural—maloti), 1 loti (L)
= 100 lisente
Exchange rates: maloti (M) per US$1—
2 5555 (January 1990), 2 6166 (1989),
2 2611 (1988), 2 0350 (1987), 2 2685
(1986), 2 1911 (1985), note—the Basotho
loti is at par with the South African rand
Fiscal year: 1 April-31 March','ee958df6727155c0ee2af0417a12ff54ec35fc913473e307e1852bbc1154b587','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b72e0929e0a5a000c9c089a9143bb5bdbc22ca3db6d8d1bc5bf32db4c21c9803',1990,'LR','Liberia','economy',452,'Overview: In 1988 and 1989 the Liberian
economy posted its best two years in a
decade, thanks to a resurgence of the rub-
ber industry and rapid growth in exports
of forest products Richly endowed with
water, mineral resources, forests, and a
climate favorable to agriculture, Liberia 1s
a producer and exporter of basic products
Local manufacturing, mainly foreign
owned, is small in scope Liberia imports
primarily machinery and parts, transpor-
tation equipment, petroleum products, and
foodstuffs Persistent budget deficits, the
flight of capital, and deterioration of
transport and other infrastructure con-
tinue to hold back economic progress
GDP: $988 million, per capita $395, real
growth rate 1 5% (1988)
Inflation rate (consumer prices): 12%
(1989)
Unemployment rate: 43% urban (1988)
Budget: revenues $242 1 million, expendi-
tures $435 4 million, including capital ex-
penditures of $29 5 million (1989)
181
Approved for Release: 2020/08/12 C06554432
Liberia (continued)
Exports: $550 million (fo b, 1989), com-
modities—iron ore 61%, rubber 20%, tim-
ber 11%, coffee, partners—US, EC, Neth-
erlands
Imports: $335 million (c1f , 1989), com-
modities—trice, mineral fuels, chemicals,
machinery, transportation equipment,
other foodstuffs, partners—US, EC, Ja-
pan, China, Netherlands, ECOWAS
External! debt: $1 7 billion (December
1989 est )
Industrial production: growth rate 1 5% in
manufacturing (1987)
Electricity: 400,000 kW capacity, 730 mil-
hon kWh produced, 290 kWh per capita
(1989)
Industries: rubber processing, food pro-
cessing, construction materials, furniture,
palm oil processing, mining (iron ore, dia-
monds)
Agriculture: accounts for about 40% of
GDP (including fishing and forestry), prin-
cipal products—rubber, timber, coffee,
cocoa, rice, cassava, palm oil, sugarcane,
bananas, sheep, and goats, not
self-sufficient in food, imports 25% of rice
consumption
Aid: US commitments, including Ex-Im
(FY 70-88), $634 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $793 million,
OPEC bilateral aid (1979-89), $25 million,
Communist countries (1970-88), $77 muil-
lion
Currency: Liberian dollar (plural—dol-
lars), 1 Liberian dollar (L$) = 100 cents
Exchange rates: Liberian dollars (L$) per
US$1—1 00 (fixed rate since 1940), unof-
ficial parallel exchange rate of L$2 5 =
US$1, January 1989
Fiscal year: calendar year','5b869e1732870f0e825ba9e9625b87103a8a652f2d415ef4c8d815d3fe23fa21','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a84c7fc8c00e11f85a748c7ae1bbb04a34a01977a3838822b9fcc70accb9bbc0',1990,'LY','Libya','economy',457,'Overview: The socialist-oriented economy
depends primarily upon revenues from the
oil sector, which contributes virtually all
export earnings and over 50% to GNP
Since 1980, however, the sharp drop in oil
prices and resulting decline in export reve-
nues has adversely affected economic de-
velopment In 1986 per capita GNP was
the highest in Africa at $5,410, but it had
been $2,000 higher in 1982 Severe cut-
backs in imports over the past five years
have led to shortages of basic goods and
foodstuffs, although the reopening of the
Libyan-Tunisian border in April 1988 and
the Libyan-Egyptian border in December
1989 have somewhat eased shortages
Austerity budgets and a lack of trained
technicians have undermined the govern-
ment’s ability to implement a number of
planned infrastructure development
projects The nonoil industrial and con-
struction sectors, which account for about
15% of GNP, have expanded from pro-
cessing mostly agricultural products to
include petrochemicals, iron, steel, and
aluminum Although agriculture accounts
for less than 5% of GNP, it employs 20%
of the labor force Climatic conditions and
poor soils severely limit farm output, re-
quiring Libya to import about 75% of its
food requirements
GNP: $20 billion, per capita $5,410, real
growth rate 0% (1988 est )
Inflation rate (consumer prices): 20% (1988
est )
Unemployment rate: 2% (1988 est )
Budget: revenues $6 4 billion, expenditures
$11 3 bilhon, including capital expendi-
tures of $3 6 bilhon (1986 est )
Exports: $6 1 billion (fob, 1988 est ),
commodities—petroleum, peanuts, hides,
partners—lItaly, USSR, FRG, Spain,
France, Belgium/Luxembourg, Turkey
Imports: $5 0 billion (fob, 1988 est ),
commoadities—machinery, transport
equipment, food, manufactured goods,
partners—Italy, USSR, FRG, UK, Japan
External debt: $2 1 billion, excluding mili-
tary debt (December 1988)
Industrial production: growth rate NA%
Electricity: 4,580,000 kW capacity,
13,360 million kWh produced, 3,270 kWh
per capita (1989)
Industries: petroleum, food processing, tex-
tiles, handicrafts, cement
Agriculture: 5% of GNP, cash crops—
wheat, barley, olives, dates, citrus fruits,
peanuts, 75% of food 1s imported
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $242 million
Currency: Libyan dinar (plural—dinars), 1
Libyan dinar (LD) = 1,000 dirhams
Exchange rates: Libyan dinars (LD) per
US$1—0 2896 (January 1990), 0 2922
(1989), 0 2853 (1988), 0 2706 (1987),
0 3139 (1986), 0 2961 (1985)
Fiscal year: calendar year
Overview: The economy depends primarily
on petroleum, phosphates, and tourism for
continued growth Two successive
drought-induced crop failures have
strained the government’s budget and in-
creased unemployment The current ac-
count fell from a $23 million surplus in
1988 to a $390 million deficit in 1989
Despite its foreign payments problems,
Tunis appears committed to its
IMF-supported structural adjustment pro-
gram Nonetheless, the government may
have to slow its implementation to head
off labor unrest The increasing foreign
debt—$7 6 billion at yearend 1989—1s
also a key problem Tunis probably will
seek debt relief in 1990
GDP: $8 7 billion, per capita $1,105, real
growth rate 3 1% (1989 est )
Inflation rate (consumer prices): 10%
(1989)
Unemployment rate: 25% (1989)
Budget: revenues $2 9 billion, expenditures
$3 2 billion, including capital expenditures
of $0 8 billion (1989 est )
Exports: $3 1 billion (fob, 1989), com-
modities—hydrocarbons, agricultural
products, phosphates and chemicals, part-
ners—EC 73%, Middle East 9%, US 1%,
Turkey, USSR
Imports: $4 4 billion (fob, 1989), com-
modities—industrial goods and equipment
57%, hydrocarbons 13%, food 12%, con-
Approved for Release: 2020/08/12 C06554432
sumer goods, partners—EC 68%, US 7%,
Canada, Japan, USSR, China, Saudi Ara
bia, Algeria
External debt: $7 6 billion (December
1989)
Industrial production: growth rate 3 5%
(1988)
Electricity: 1,493,000 kW capacity, 4,210
million kWh produced, 530 kWh per cap-
ita (1989)
Industries: petroleum, mining (particularly
phosphate and iron ore), textiles, footwear,
food, beverages
Agriculture: accounts for 16% of GDP anc
one-third of labor force, output subject to
severe fluctuations because of frequent
droughts, export crops—olives, dates, or-
anges, almonds, other products—grain,
sugar beets, wine grapes, poultry, beef,
dairy, not self-sufficient in food, fish catch
of 99,200 metric tons (1986)
Aid: US commitments, including Ex-Im
(FY70-88), $694 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $4 6 billion,
OPEC bilateral aid (1979-89), $684 mil-
hon, Communist countries (1970-88), $410
million
Currency: Tunisian dinar (plural—dinars),
1 Tunisian dinar (TD) = 1,000 millimes
Exchange rates: Tunisian dinars (TD) per
US$1—0 9055 (January 1990), 0 9493
(1989), 0 8578 (1988), 0 8287 (1987),
0 7940 (1986), 0 8345 (1985)
Fiscal year: calendar year
Overview: The economic reforms that Tur-
key launched in 1980 continue to bring an
impressive stream of benefits The econ-
omy has grown steadily since the early
1980s, with real growth in per capita
GDP increasing more than 6% annually
Agriculture remains the most important
316
economic sector, employing about 60% of
the labor force, accounting for almost 20%
of GDP, and contributing about 25% to
exports Impressive growth tn recent years
has not solved all of the economic prob-
lems facing Turkey Inflation and interest
rates remain high, and a large budget def-
1cit will continue to provide difficulties for
a country undergoing a substantial trans-
formation from a centrally controlled to a
free market economy The government has
launched a multimillion-dollar develop-
ment program in the southeastern region,
which includes the building of a dozen
dams on the Tigris and Euphrates rivers
to generate electric power and irrigate
large tracts of farmland The planned tap-
ping of huge quantities of Euphrates wa-
ter has raised serious concern in the
downstream riparian nations of Syria and','4b94a62802693e57644184a3c4c452bbeed40fed0e4c670ba6846d7eeff3df00','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('956f600176d0e49e17c053999e2af91a9248343b70dba8352e23c066409abf72',1990,'LI','Liechtenstein','economy',462,'Overview: The prosperous economy 1s
based primarily on small-scale light indus-
try and some farming Industry accounts
for 54% of total employment, the service
sector 42% (mostly based on tourism), and
agriculture and forestry 4% The sale of
postage stamps to collectors is estimated
at $10 million annually and accounts for
10% of revenues Low business taxes (the
maximum tax rate 1s 20%) and easy incor-
poration rules have induced about 25,000
holding or so-called letter box companies
to establish nominal offices in Liechten-
stein Such companies, incorporated solely
for tax purposes, provide an additional
30% of state revenues The economy 1s
tied closely to that of Switzerland in a
customs union, and incomes and living
standards parallel those of the more pros-
perous Swiss groups
GNP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices): 1 5%
(1987 est.)
Unemployment rate: 0 1% (December
1986)
Budget: revenues $171 million, expendi-
tures $189 million, including capital ex-
penditures of NA (1986)
Exports: $807 million, commodities—
small specialty machinery, dental prod-
ucts, stamps, hardware, pottery,
partners—EC 40%, EFTA 26% (Switzer-
land 19%) (1986)
Imports: $NA; commodities—machinery,
metal goods, textiles, foodstuffs, motor
vehicles, partners—NA
External debt: SNA
Industrial production: growth rate NA%
Electricity: 23,000 kW capacity, 150 mil-
hon kWh produced, 5,340 kWh per capita
(1989)
Industries: electronics, metal manufactur-
ing, textiles, ceramics, pharmaceuticals,
food products, precision instruments, tour-
ism
Agriculture: livestock, vegetables, corn,
wheat, potatoes, grapes
Aid: none
Currency: Swiss franc, franken, or franco
(plural—francs, franken, or franchi), |
Swiss franc, franken, or franco (SwF) =
100 centimes, rappen, or centesimi
Exchange rates: Swiss francs, franken, or
franchi (SwF) per US$1—1 5150 (January
1990), 1 6359 (1989), 1 4633 (1988),
1 4912 (1987), 1 7989 (1986), 2 4571
(1985)
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432','eee529d30b9133a577af8f2d0929673e40acce6fc18aac42d0a6738b11efdee9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8e5be40c33b06bcc8272b406bacdde996281ae4ae55a86eb2eaa6bd2527865',1990,'LU','Luxembourg','economy',466,'Overview: The stable economy features
moderate growth, low inflation, and negli-
gible unemployment Agriculture 1s based
on small but highly productive famtly-
owned farms The industrial sector, until
recently dominated by steel, has become
increasingly more diversified, particularly
toward high-technology firms During the
past decade growth in the financial sector
has more than compensated for the de-
cline in steel Services, especially banking,
account for a growing proportion of the
economy Luxembourg participates in an
economic union with Belgium on trade
and most financial matters and is also
closely connected economically with the','1e7d48bba1e7bc989e5f99ea64b6e389e3133484528e6eae2aa53c4168afed75','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('370cf3dd3922125adb62316500a50ea3d97a373a6b0b10f22ecc1b959b99a15b',1990,'NL','Netherlands','economy',467,'GDP: $6 3 billion, per capita $17,200, real
growth rate 4% (1989 est )
Inflation rate (consumer prices): 3 0%
(1989 est )
Unemployment rate: 1 6% (1989 est )
Budget: revenues $2 5 billion, expenditures
$2 3 billion, including capital expenditures
of NA (1988)
Exports: $4 7 billion (f 0 b , 1988), com-
modities—finished steel products, chemi-
cals, rubber products, glass, aluminum,
other industria! products, partners—EC
75%, US 6%
Imports: $5 9 billion (cif, 1988 est ),
commodities—minerals, metals,
foodstuffs, quality consumer goods, part-
ners—FRG 40%, Belgium 35%, France
15%, US 3%
Approved for Release: 2020/08/12 C06554432
External debt: $131 6 million (1989 est )
Industrial production: growth rate 5%
(1989 est )
Electricity: 1,500,000 kW capacity, 1,163
million kWh produced, 3,170 kWh per
capita (1989)
Industries: banking, iron and steel, food
processing, chemicals, metal products, en-
gineering, tires, glass, aluminum
Agriculture: accounts for less than 3% of
GDP (including forestry), principal prod-
ucts—barley, oats, potatoes, wheat, fruits,
wine grapes, cattle raising widespread
Aid: none
Currency: Luxembourg franc (plural—
francs), 1 Luxembourg franc (LuxF) =
100 centimes
Exchange rates: Luxembourg francs
(LuxF) per US$1—35 468 (January 1990),
39 404 (1989), 36 768 (1988), 37 334
(1987), 44 672 (1986), 59 378 (1985),
note—the Luxembourg franc 1s at par
with the Belgian franc, which circulates
freely in Luxembourg
Fiscal year: calendar year
Overview: The economy 1s based largely on
tourism (including gambling), and textile
and fireworks manufacturing Efforts to
diversify have spawned other small indus-
tries—toys, artificial flowers, and electron-
ics The tourist sector has accounted for
roughly 25% of GDP, and the clothing
industry has provided about two-thirds of
export earnings Macau depends on China
for most of its food, fresh water, and en-
ergy imports Japan and Hong Kong are
the main suppliers of raw materials and
capital goods
GDP: $2 7 billion, per capita $6,300, real
growth rate 5% (1989 est )
Inflation rate (consumer prices): 9 5%
(1989)
Unemployment rate: 2% (1989 est )
Budget: revenues $305 million, expendi-
tures $298 million, including capital ex-
penditures of $NA (1989)
Exports: $1 7 billion (1989 est ), commodi-
tles—textiles, clothing, toys, partners—
US 33%, Hong Kong 15%, FRG 12%,
France 10% (1987)
Imports: $1 6 billion (1989 est ), commodi-
tles—raw materials, foodstuffs, capital
goods, partners—Hong Kong 39%, China
21%, Japan 10% (1987)
External debt: $91 million (1985)
Industrial production: NA
Electricity: 179,000 kW capacity, 485 mil-
hon kWh produced, 1,110 kWh per capita
(1989)
Industries: clothing, textiles, toys, plastic
products, furniture, tourism
Agriculture: rice, vegetables, food short-
ages—trice, vegetables, meat, depends
mostly on imports for food requirements
Aid: none
Currency: pataca (plural—patacas), | pa-
taca (P) = 100 avos
Exchange rates: patacas (P) per US$1—
8 03 (1989), 8 044 (1988), 7 993 (1987),
8 029 (1986), 8 045 (1985), note—linked to
the Hong Kong dollar at the rate of | 03
patacas per Hong Kong dollar
Fiscal year: calendar year
Overview: This highly developed and af-
fluent economy 1s based on private enter-
prise The government makes its presence
felt, however, through many regulations,
permit requirements, and welfare
programs affecting most aspects of eco-
nomic activity The trade and financial
services sector contributes over 50% of
GDP Industrial activity, including con-
struction, provides about 25% of GDP,
and 1s led by the food-processing,
oil-refining, and metal-working industries
The highly mechanized agricultural sector
employs only 6% of the labor force, but
provides large surpluses for export and the
domestic food-processing industry An un-
employment rate of over 8 6% and a siz-
able budget deficit are currently the most
serious economic problems
GDP: $205 9 billion, per capita $13,900,
real growth rate 4 2% (1989 est )
Inflation rate (consumer prices): | 5%
(1989 est )
Unemployment rate: 8 6% (1989 est )
Budget: revenues $71 billion, expenditures
$82 billion, including capital expenditures
of $NA billion (1989)
Exports: $110 3 billion (fo b , 1989), com-
modities—agricultural products, processed
foods and tobacco, natural gas, chemicals,
metal products, textiles, clothing, part-
ners—EC 74 9% (FRG 28 3%, Belgium-
Luxembourg 14 2%, France 10 7%, UK
10 2%), US 4 7% (1988)
Imports: $100 9 billion (c1f, 1989), com-
modities—raw materials and semifinished
products, consumer goods, transportation
equipment, crude oil, food products, part-
ners—EC 63 8% (FRG 26 5%, Belgium-
Luxembourg 23 1%, UK 8 1%), US 79%
(1988)
External debt: none
Industrial production: growth rate 4 8%
(1989 est )
Electricity: 22,216,000 kW capacity,
63,570 million kWh produced, 4,300 kWh
per capita (1989)
Industries: agroindustries, metal and eng!-
neering products, electrical! machinery and
equipment, chemicals, petroleum, fishing,
construction, microelectronics
Agriculture: accounts for 4% of GDP, ani-
mal production predominates, crops—
grains, potatoes, sugar beets, fruits, vege-
tables, shortages of grain, fats, and oils
Aid: donor—ODA and OOF commitments
(1970-87), $15 8 billion
Currency: Netherlands guilder, gulden, or
florin (plural—guilders, gulden, or florins),
1 Netherlands guilder, gulden, or florin (f )
= 100 cents
Exchange rates: Netherlands guilders, gul-
den, or florins (f ) per US$1—2 2906 (Jan-
uary 1990), 2 1207 (1989), 1 9766 (1988),
2 0257 (1987), 2 4500 (1986), 3 3214
(1985)
Fiscal year: calendar year
221
Approved for Release: 2020/08/12 C06554432
Netherlands (continued)
Overview: Tourism, petroleum refining,
and offshore finance are the mainstays of
the economy The islands enjoy a compar-
atively high per capita income and a well-
developed infrastructure compared with
other countries in the region Unlike many
Latin American countries, the Nether-
lands Antilles has avoided large interna-
tional debt Almost all consumer and cap1-
tal goods are imported, with the US being
the major supplier The economy has suf-
fered somewhat in recent years because of
the depressed state of the world oil market
and declining tax revenues In 1983 the
drop in oil prices led to the devaluation of
the Venezuelan bolivar, which ended a
substantial flow of Venezuelan tourists to
the islands As a result of a decline in tax
revenues, the government has been seek-
ing financial support from the Nether-
lands
GDP: $1 0 billion, per capita $5,500, real
growth rate 3% (1988 est )
Inflation rate (consumer prices): 2 0%
(1988)
Unemployment rate: 26 0% (1988)
Budget: revenues $180 million, expendi-
tures $289 million, including capital ex-
penditures of $NA (1987 est )
Exports: $1 3 billion (fob, 1988), com-
modities—petroleum products 98%, part-
ners—US 55%, UK 7%, Jamaica 5%
Imports: $1 5 billion (cif, 1988), com-
modities—crude petroleum 64%, food,
manufactures, partners—Venezuela 52%,
Nigeria 15%, US 12%
External debt: $701 2 million (December
1987)
Industrial production: growth rate NA%
Electricity: 125,000 kW capacity, 365 mil-
lion kWh produced, 1,990 kWh per capita
(1989)
Industries: tourism (Curacao and Sint
Maarten), petroleum refining (Curacao),
petroleum transshipment facilities (Cu-
racao and Bonaire), light manufacturing
(Curacao)
Agriculture: hampered by poor soils and
scarcity of water, chief products—aloes,
sorghum, peanuts, fresh vegetables, tropi-
cal fruit, not self-sufficient in food
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
79), $353 million
Currency: Netherlands Antillean guilder,
gulden, or florin (plural—guilders, gulden,
or florins), | Netherlands Antillean gul-
der, gulden, or florin (NAf ) = 100 cents
Exchange rates: Netherlands Antillean
guilders, guiden, or florins (NAf ) per
US$1—1 80 (fixed rate since 1971)
Fiscal year: calendar year','e346f4633ca718d8db5c6c2044f91f7b086c600520cc07976049563fbb0cad13','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('911156fba623c3a134d1a1973e3327650db156fa2a5f6fc7293e2a2b06f165bc',1990,'MG','Madagascar','economy',474,'Overview: Madagascar 1s one of the poor-
est countries in the world During the pe-
riod 1980-85 it had a population growth
of 3% a year and a —0 4% GDP growth
Approved for Release: 2020/08/12 C06554432
rate Agriculture, including fishing and
forestry, 1s the mainstay of the economy,
accounting for over 40% of GDP, employ-
ing about 85% of the labor force, and con-
tributing more than 70% to export earn-
ings Industry 1s confined to the processing
of agricultural products and textile manu-
facturing, in 1988 it contributed only 16%
to GDP and employed 3% of the labor
force Industrial development has been
hampered by government policies that
have restricted imports of equipment and
spare parts and put strict controls on
foreign-owned enterprises In 1986 the
government introduced a five-year devel-
opment plan that stresses self-sufficiency
in food (mainly rice) by 1990, increased
production for exports, and reduced en-
ergy imports
GDP: $1 7 billion, per capita $155, real
growth rate 2 2% (1988)
Inflation rate (consumer prices): 17 0%
(1988)
Unemployment rate: NA%
Budget: revenues $337 million, expendi-
tures $245 million, including capital ex-
penditures of $163 million (1988)
Exports: $284 million (f ob, 1988), com-
modities—coffee 45%, vanilla 15%, cloves
11%, sugar, petroleum products,
partners—France, Japan, Italy, FRG, US
Imports: $319 million (fo b , 1988), com-
modities—intermediate manufactures
30%, capital goods 28%, petroleum 15%,
consumer goods 14%, food 13%,
partners—France, FRG, UK, other EC,
US
External debt: $3 6 billion (1989)
Industrial production: growth rate —39 %
(1988)
Electricity: 119,000 kW capacity, 430 mil-
lion kWh produced, 40 kWh per capita
(1989)
Industries: agricultural processing (meat
canneries, soap factories, brewery, tanner-
1es, sugar refining), light consumer goods
industries (textiles, glassware), cement,
automobile assembly plant, paper, petro-
leum
Agriculture: accounts for 40% of GDP,
cash crops—coffee, vanilla, sugarcane,
cloves, cocoa, food crops—trice, cassava,
beans, bananas, peanuts, cattle raising
widespread, not self-sufficient in rice and
wheat flour
Illicit drugs: illicit producer of cannabis
(cultivated and wild varteties) used mostly
for domestic consumption
Aid: US commitments, including Ex-Im
(FY 70-88), $118 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 6 billion,
Communist countries (1970-88), $491 mil-
lion
Currency: Malagasy franc (plural—
francs), | Malagasy franc (FMG) = 100
centimes
Exchange rates: Malagasy francs (FMG)
per US$1—1,531 0 (January 1990),
1603 4 (1989), 1,407 1 (1988), 1,069 2
(1987), 676 3 (1986), 662 5 (1985)
Fiscal year: calendar year','50f879781e9c61170c9acfbd5dfbf7a0e32e701508b8610b32719c3100681acb','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a63499d65a916cceff0caa149685bc8d6c9114969f87511ffd5b383caada921',1990,'MW','Malawi','economy',479,'Overview: A landlocked country, Malawi
ranks among the world’s least developed
with a per capita GDP of $180 The econ-
omy 1s predominately agricultural and
operates under a relatively free enterprise
environment, with about 90% of the popu-
lation living in rural areas Agriculture
accounts for 40% of GDP and 90% of ex-
port revenues After two years of weak
performance, economic growth improved
significantly in 1988 as a result of good
weather and a broadly based economic
adjustment effort by the government The
closure of traditional trade routes through
Mozambique continues to be a constraint
on the economy
GDP: $1 4 billion, per capita $180, growth
rate 3 6% (1988)
Inflation rate (consumer prices): 31 5%
(1988)
Unemployment rate: NA%
Budget: revenues $246 million, expendi-
tures $390 million, including capital ex-
penditures of $97 million (FY88 est )
Exports: $292 million (fob, 1988), com-
modities—tobacco, tea, sugar, coffee, pea-
nuts, partners—-US, UK, Zambia, South
Africa, FRG
Imports: $402 million (cif, 1988), com-
modities—food, petroleum, semimanufac-
tures, consumer goods, transportation
equipment, partners—South Africa, Ja-
pan, US, UK, Zimbabwe
External debt: $1 4 billion (December
1989 est )
Industrial production: growth rate 6 4%
(1988)
Electricity: 181,000 kW capacity, 535 mil-
lion kWh produced, 60 kWh per capita
(1989)
Industries: agricultural processing (tea,
tobacco, sugar), sawmilling, cement, con-
sumer goods
Agriculture: accounts for 40% of GDP;
cash crops—tobacco, sugarcane, cotton,
tea, and corn, subsistence crops—potatoes,
cassava, sorghum, pulses, livestock—cattle
and goats
Aid: US commitments, including Ex-Im
(FY70-88), $182 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 8 billion
Currency: Malawian kwacha (plural—
kwacha), | Malawian kwacha (MK) =
100 tambala
Exchange rates: Malawian kwacha (MK)
per US$1—2 6793 (January 1990), 2 7595
(1989), 2 5613 (1988), 2 2087 (1987),
1 8611 (1986), 1 7191 (1985)
Fiscal year: 1 April-31 March','cecda15491a79cf4f25a1987693e1579dee50082b674eca3c8edf7618d0dcad9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be718a8f2260fad0f85f27ba0b9c2089061375878d068ab17420620372f78e18',1990,'MV','Maldives','economy',485,'Overview: The economy 1s based on
fishing, tourism, and shipping Agriculture
1s limited to the production of a few sub-
sistence crops that provide only 10% of
food requirements Fishing 1s the largest
industry, employing 80% of the work force
and accounting for over 60% of exports, it
is also an important source of government
revenue During the 1980s tourism has
become one of the most important and
highest growth sectors of the economy In
1988 industry accounted for about 14% of
GDP Real GDP 1s officially estimated to
have increased by about 10% annually
during the period 1974-86, and GDP esti-
mates for 1988 show a further growth of
9% on the strength of a record fish catch
and an improved tourist season
GDP: $136 million, per capita $670, real
growth rate 9 2% (1988)
Inflation rate (consumer prices): 14% (1988
est )
Unemployment rate: NA%
Budget: revenues $51 million, expenditures
$50 million, including capital expenditures
of $25 million (1988 est )
Exports: $47 0 million (fo b , 1988 est ),
commoadities—fish 57%, clothing 39%,
partners—Thailand, Western Europe, Sri
Lanka
Imports: $90 0 million (cif, 1988 est ),
commodities— intermediate and capital
goods 47%, consumer goods 42%, petro-
leum products 11%, partners—Japan,
Western Europe, Thailand
External debt: $70 million (December
1988)
Industrial production: growth rate 3 9%
(1988 est )
Electricity: 5,000 kW capacity, 10 million
kWh produced, 50 kWh per capita (1989)
Industries: fishing and fish processing,
tourism, shipping, boat building, some co-
conut processing, garments, woven mats,
coir (rope), handicrafts
Agriculture: accounts for almost 30% of
GDP (including fishing), fishing more 1m-
portant than farming, limited production
of coconuts, corn, sweet potatoes, most
staple foods must be imported
Aid: US commitments, including Ex-Im
(FY 70-88), $28 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $84 million, OPEC
bilateral aid (1979-89), $14 million
194
Approved for Release: 2020/08/12 C06554432
Currency: rufiyaa (plural—rufiyaa), | ru-
fiyaa (Rf) = 100 laaris
Exchange rates: rufiyaa (Rf) per US$1—
9 3043 (January 1990), 9 0408 (1989),
8 7846 (1988), 9 2230 (1987), 7 1507
(1986), 7 0981 (1985)
Fiscal year: calendar year','3f10ebf762ad09de2901745c73351b7f9055643297cd311a6ba10b23cb5d80c5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('227648996e18a733219d61fd7dccdb28c83d0d6dd8a0d65f19acfcd808de3c9d',1990,'ML','Mali','economy',490,'Overview: Mali is among the poorest coun-
tries in the world, with about 80% of its
land area desert or semidesert Economic
activity 1s largely confined to the riverine
area irrigated by the Niger About 10% of
the population lives as nomads and some
80% of the labor force is engaged in agri-
culture and fishing Industrial activity is
concentrated on processing farm commod-
ities
GDP: $1 94 billion, per capita $220, real
growth rate —0 9% (1988 est )
Inflation rate (consumer prices): NA%
(1987)
Unemployment rate: NA%
Budget: revenues $338 million, expendi-
tures $559 million, including capital! ex-
penditures of $NA (1987)
Exports: $260 million (fo b , 1987), com-
modities—livestock, peanuts, dried fish,
cotton, skins, partners—mostly franc zone
and Western Europe
Imports: $493 million (fob, 1987), com-
modities—textiles, vehicles, petroleum
products, machinery, sugar, cereals, part-
ners—mostly franc zone and Western Eu-
rope
External debt: $2 | billion (December
1988 est )
Industrial production: growth rate NA%
Electricity: 92,000 kW capacity, 165 mil-
lion kWh produced, 20 kWh per capita
(1989)
Industries: small local consumer goods and
processing, construction, phosphate, gold,
fishing
Agriculture: accounts for 50% of GDP,
most production based on small subsis-
tence farms, cotton and livestock products
account for over 70% of exports, other
crops—millet, rice, corn, vegetables, pea-
nuts, livestock——cattle, sheep, and goats
Aid: US commitments, including Ex-Im
(FY 70-88), $313 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 4 billion,
OPEC bilateral aid (1979-89), $92 million,
Communist countries (1970-88), $190 mil-
lon
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year','d58deb6d909adf50fb17679456f02b00eee2bac9e1021da23f3e292a976e2a88','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1271f0706402cc1c369204d69fd0f8fdeea5e7c1b8a4c2eb00e7270aa5e1f1e4',1990,'MT','Malta','economy',494,'Overview: Significant resources are lime-
stone, a favorable geographic location, and
a productive labor force Malta produces
only about 20% of its food needs, has lim-
ited freshwater supplies, and has no do-
mestic energy sources Consequently, the
economy ts highly dependent on foretgn
trade and services Manufacturing and
tourism are the largest contributors to the
economy Manufacturing accounts for
about 30% of GDP, with the textile and
clothing industry a major contributor In
1988 inflation was held to a low 09% Per
capita GDP at $5,100 places Malta in the
middle-income range of the world’s na-
tions
GDP: $1 9 billion, per capita $5,100, real
growth rate 7 1% (1988)
Inflation rate (consumer prices): 0 9%
(1988)
Unemployment rate: 4 4% (1987)
Budget: revenues $844 million, expendi-
tures $938 million, including capital ex-
penditures of $226 million (1989 est )
Exports: $710 million (fo b , 1988), com-
modities—clothing, textiles, footwear,
ships, partners—FRG 31%, UK 14%, It-
aly 14%
Imports: $1,360 million (cif, 1988), com-
modities—food, petroleum, nonfood raw
materials, partners—FRG 19%, UK 17%,
Italy 17%, US 11%
External debt: $90 million, medium and
long-term (December 1987)
Industrial production: growth rate 6 2%
(1987)
Electricity: 328,000 kW capacity, 1,110
million kWh produced, 2,990 kWh per
capita (1989)
Industries: tourism, ship repair yard,
clothing, construction, food manufactur-
ing, textiles, footwear, clothing, beverages,
tobacco
Agriculture: overall, 20% self-sufficient,
main products—potatoes, cauliflower,
grapes, wheat, barley, tomatoes, citrus,
cut flowers, green peppers, hogs, poultry,
eggs, generally adequate supplies of vege-
tables, poultry, milk, pork products, sea-
sonal or periodic shortages in grain, ani-
mal fodder, fruits, other basic foodstuffs
Aid: US commitments, including Ex-Im
(FY 70-81), $172 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $332 million,
OPEC bilateral aid (1979-89), $76 million,
Communist countries (1970-88), $48 mil-
lion
Currency: Maltese lira (plural—tirn), |
Maltese hra (LM) = 100 cents
Exchange rates: Maltese lir: (LM) per
US$1—0 3332 (January 1990), 0 3483
(1989), 0 3306 (1988), 0 3451 (1987),
0 3924 (1986), 0 4676 (1985)
Fiscal year: 1 April-31 March
Overview: Offshore banking, manufactur-
ing, and tourism are key sectors of the
economy The government''s policy of of-
fering incentives to high-technology com-
panies and financial institutions to locate
on the island has paid off in expanding
197
Approved for Release: 2020/08/12 C06554432
Man, Isle of (continued)
employment opportunities in high-income
industries As a result, agriculture and
fishing, once the mainstays of the econ-
omy, have declined in their shares of
GNP Banking now contributes over 20%
to GNP and manufacturing about 15%
Trade 1s mostly with the UK
GNP: $490 million, per capita $7,573,
real growth rate NA% (1988)
Inflation rate (consumer prices): NA%
Unemployment rate: 1 5% (1988)
Budget: revenues $130 4 million, expendi-
tures $1144 million, including capital ex-
penditures of $18 1 milhon (FY85 est )
Exports: $NA, commodities—tweeds, her-
ring, processed shellfish meat, partners—
UK
Imports: $NA, commodities—timber, fer-
tilizers, fish, partners—UK
External debt: $NA
Industrial production: growth rate NA%
Electricity: 61,000 kW capacity, 190 mil-
lion kWh produced, 2,930 kWh per capita
(1989)
Industries: an important offshore financial
center, financial services, light manufac-
turing, tourism
Agriculture: cereals and vegetables, cattle,
sheep, pigs, poultry
Aid: NA
Currency: Manx pound (plural—pounds),
1 Manx pound (£M) = 100 pence
Exchange rates: Manx pounds (£M) per
US$1—0 6055 (January 1990), 0 6099
(1989), 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985), the Manx
pound 1s at par with the British pound
Fiscal year: | April-31 March','0d8d2f934805fd1084201174a17e06e457497540a45b0013ae03e54a1cd0ec2d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5a7d613b3ad1fca185be86313f3516e1c841abba2302650d3fdac69028f243',1990,'MH','Marshall Islands','economy',499,'Overview: Agriculture and tourism are the
mainstays of the economy Agricultural
production 1s concentrated on small farms,
and the most important commercial! crops
are coconuts, tomatoes, melons, and
breadfruit A few cattle ranches supply
the domestic meat market Small-scale
industry 1s limited to handicrafts, fish pro-
cessing, and copra The tourist industry ts
the primary source of foreign exchange
and employs about 10% of the labor force
The islands have few natural resources,
and imports far exceed exports In 1987
the US Government provided grants of
$40 million out of the Marshallese budget
of $55 million
GDP: $63 million, per capita $1,500, real
growth rate NA% (1989 est )
Inflation rate (consumer prices): 5 6%
(1981)
Unemployment rate: NA%
Budget: revenues $55 million, expenditures
NA, including capital expenditures of NA
(1987 est )
Exports: $2 5 million (fo b, 1985), com-
modities—copra, copra oil, agricultural
products, handicrafts, partners—NA
Imports: $29 2 million (cif , 1985), com-
modities—foodstuffs, beverages, building
materials, partners—NA
External debt: $NA
Industrial production: growth rate NA%
Electricity: 12,000 kW capacity, 10 mil-
lion kWh produced, 240 kWh per capita
(1989)
Industries: copra, fish, tourism, craft items
from shell, wood, and pearl, offshore
banking (embryonic)
Agriculture: coconuts, cacao, taro, bread-
fruit, fruits, copra, pigs, chickens
Aid: under the terms of the Compact of
Free Association, the US 1s to provide ap-
proximately $40 million in aid annually
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: 1 October-30 September
Overview: Economic activity 1s limited to
providing services to US military person-
nel and contractors located on the island
All food and manufactured goods must be
imported','9d15e7a971a1903fe797d3f266d899fdcdf829609e75482fa12deb08233fdd75','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03579d042e4b61b5dea3c0464c3a62dfe5480ee22adbecbfee261642e4a8ca48',1990,'MQ','Martinique','economy',504,'Overview: The economy 1s based on sugar-
cane, bananas, tourism, and light industry
Agriculture accounts for about 7% of
GDP and the small industrial sector for
10% Sugar production has declined, with
most of the sugarcane now used for the
production of rum Banana exports are
increasing, however, going mostly to
France The bulk of meat, vegetable, and
grain requirements must be imported, con-
tributing to a chronic trade deficit that
requires large annual transfers of aid from
France Tourism has become more impor-
tant than agricultural exports as a source
of foreign exchange The majority of the
work force 1s employed in the service sec-
tor and in administration In 1984 the an-
nual per capita income was relatively high
at $3,650 During 1985 the unemployment
rate was between 25% and 30% and was
particularly severe among younger work-
ers
GDP: $1 3 billion, per capita $3,650, real
growth rate NA% (1984)
Inflation rate (consumer prices): 3 4%
(1986)
Unemployment rate: 25-30% (1985)
Budget: revenues $223 million, expendi-
tures $223 million, including capital ex-
penditures of $NA (1987 est }
Exports: $209 million (f 0 b , 1986), com-
modities—tefined petroleum products,
bananas, rum, pineapples, partners—
France 65%, Guadeloupe 26% (1986)
Approved for Release: 2020/08/12 C06554432
Imports: $879 million (c1f, 1986), com-
modities—petroleum products, foodstuffs,
construction materials, vehicles, clothing
and other consumer goods, partners—
France 64% (1986)
External debt: $NA
Industrial production: growth rate NA%
Electricity: 108,000 kW capacity, 330 mil-
lion kWh produced, 990 kWh per capita
(1989)
Industries: construction, rum, cement, oil
refining, sugar, tourism
Agriculture: accounts for about 7% of
GDP, principal crops—pineapples, avoca-
dos, bananas, flowers, vegetables, and sug-
arcane for rum, dependent on imported
food, particularly meat and vegetables
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $9 8 billion
Currency: French franc (plural—francs), !
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Fiscal year: calendar year','2d777fe005a9ecd44263cc79a416b096f11a3c4c6551d07d0e06e28efe4fc9b8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af4090bd99fcdbf2eb7e886c1994981fc24e15b1950b7d31ce9ab578eada30c3',1990,'MR','Mauritania','economy',509,'Overview: A majority of the population
still depends on agriculture and livestock
for a livelihood, even though most of the
nomads and many subsistence farmers
were forced into the cities by recurrent
drought in 1983 Mauritania has extensive
deposits of iron ore that account for al-
most 50% of total exports The decline in
world demand for this ore, however, has
led to cutbacks in production in recent
years The nation’s coastal waters are
among the richest fishing areas in the
world, but overexploitation by foreigners
threatens this key source of revenue The
country’s first deepwater port opened near
Nouakchott in 1986
GDP: $1 0 billion, per capita $520, real
growth rate 3 6% (1988)
Inflation rate (consumer prices)’ 1 4%
(1988 est )
Unemployment rate: 50% (1988 est )
Budget: revenues $358 million, expendi-
tures $334 million, including capita! ex-
penditures of $79 million (1988 est )
Exports: $424 million (f 0 b , 1988), com-
modities—iron ore, processed fish, small
amounts of gum arabic and gypsum, unre-
corded but numerically significant cattle
exports to Senegal, partners—EC 57%,
Japan 39%, Ivory Coast 2%
Imports: $365 million (c1f , 1988), com-
modities—foodstuffs, consumer goods,
petroleum products, capital goods, part-
ners—EC 79%, Africa 5%, US 4%, Japan
2%
External debt: $2 3 billion (December
1989)
Industrial production: growth rate 4 4%
(1988 est )
201
Approved for Release: 2020/08/12 C06554432
Mauritania (continued)
Electricity: 189,000 kW capacity, 136 mil-
lion kWh produced, 70 kWh per capita
(1989)
Industries: fishing, fish processing, mining
of tron ore and gypsum
Agriculture: accounts for 29% of GDP (in-
cluding fishing), largely subsistence farm-
ing and nomadic cattle and sheep herding
except in Senegal river valley, crops—
dates, millet, sorghum, root crops, fish
products number-one export, large food
deficit in years of drought
Aid: US commitments, including Ex-Im
(FY70-88), $160 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 1 billion,
OPEC bilateral aid (1979-89), $490 mil-
lion, Communist countries (1970-88), $277
million
Currency: ouguiya (plural—ougurya), 1
ouguiya (UM) = 5 khoums
Exchange rates: ouguiya (UM) per
US$1—83 838 (January 1990), 83 051
(1989), 75 261 (1988), 73 878 (1987),
74 375 (1986), 77 085 (1985)
Fiscal year: calendar year','9a2edaf48161affbe0182b489a09b2263cbd91a061bdac0fe8bb5e8c506c5e45','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47e141c187e69aece2c6ee18db4720aedbff0fd608a993ed6e1651d908a4f31c',1990,'YT','Mayotte','economy',514,'Overview: Economic activity 1s based pri-
marily on the agricultural sector, includ-
ing fishing and livestock raising Mayotte
Approved for Release: 2020/08/12 C06554432
is not self-sufficient and must import a
large portion of its food requirements,
mainly from France The economy and
future development of the island 1s heavily
dependent on French financial assistance
GDP: NA
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues NA, expenditures $37 3
million, including capital expenditures of
NA (1985)
Exports: $4 0 million (fob, 1984), com-
modities—ylang-ylang, vanilla, partners—
France 79%, Comoros 10%, Reunion 9%
Imports: $21 8 million (fo b , 1984), com-
modities—building materials, transporta-
tion equipment, rice, clothing, flour, part-
ners—France 57%, Kenya 16%, South
Africa 11%, Pakistan 8%
External debt: $NA
Industrial production: growth rate NA%
Electricity: NA kW capacity, NA million
kWh produced, NA kWh per capita
Industries: newly created lobster and
shrimp industry
Agriculture: most important sector, pro-
vides all export earnings, crops—vanulla,
ylang-ylang, coffee, copra, imports major
share of food needs
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $287 8 million
Currency: French franc (plural—francs), |
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Fiscal year: calendar year','5cd72a43d5d4935a2f485c3919a499ca108892d3ad212c4dfc165216635f0bdf','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e6f8bcc51374c0553551b6a046a06935e6326dab990150cf6de776301ba00c5',1990,'FM','Micronesia, Federated States of','economy',522,'Overview: Financial assistance from the
US 1s the primary source of revenue, with
the US pledged to spend $1 billion in the
islands in the 1990s Micronesia also
earns about $4 million a year in fees from
foreign commercial fishing concerns Eco-
nomic activity consists primarily of subsis-
tence farming and fishing The tslands
have few mineral deposits worth exploit-
ing, except for high-grade phosphate The
potential for a tourist industry exists, but
the remoteness of the location and a lack
of adequate facilities hinder development,
note—GNP numbers reflect US spending
GNP: $150 million, per capita $1,500,
real growth rate NA% (1989 est )
Inflation rate (consumer prices): NA%
Unemployment rate: 80%
Budget: revenues $110 8 million, expendi-
tures NA, including capital expenditures
of NA (1987 est )
Exports: $1 6 million (f 0 b , 1983), com-
modities—copra, partners—NA
Imports: $48 9 million (cif, 1983), com-
modities—NA, partners—NA
External debt: SNA
Industrial production: growth rate NA%
Electricity: 15,000 kW capacity, 35 mil-
lion kWh produced, 340 kWh per capita
(1989)
Industries: tourism, craft 1tems from shell,
wood, and pearl
Agriculture: mainly a subsistence econ-
omy, copra, black pepper, tropical fruits
and vegetables, coconuts, cassava, sweet
potatoes, pigs, chickens
Aid: under terms of the Compact of Free
Association, the US will provide $1 3 bil-
lion in grant aid during the period 1986-
2001
Currency: US currency 1s used
Exchange rates: US currency 1s used
207
Approved for Release: 2020/08/12 C06554432
(continued)
Fiscal year: 1 October-30 September
Overview: The economy ts based on pro-
viding support services for US naval oper-
ations located on the islands All food and
manufactured goods must be imported','0e8b519df88d5dcd0dad59426d7b4cd4480999ea05547723bf11690b25a498b5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d3260370a5927de84e3b4f39f79d7b8587236f2875822180dd0058f9eac3318',1990,'MC','Monaco','economy',527,'Overview: No data are published on the
economy Monaco, situated on the French
Mediterranean coast, 1s a popular resort,
attracting tourists to its casino and pleas-
ant climate The Principality has success-
fully sought to diversify into services and
small, high-value-added, non-polluting
industries The state has no income tax
and low business taxes and thrives as a
tax haven both for individuals who have
established residence and for foreign com-
panies that have set up businesses and of-
fices About 50% of Monaco’s annual rev-
enue comes from value-added taxes on
hotels, banks, and the industrial sector,
about 25% of revenue comes from tour-
ism Living standards are high, that 1s,
roughly comparable to those in prosperous
French metropolitan suburbs
GNP: NA
Inflation rate (consumer prices): NA%
Unemployment rate: full employment
(1989)
Budget: revenues $386 million, expendi-
tures $NA, including capital expenditures
of $NA (1988 est )
Exports: $NA, full customs integration
with France, which collects and rebates
Monacan trade duties, also participates in
EC market system through customs union
with France
Imports: $NA, full customs integration
with France, which collects and rebates
Monacan trade duties, also participates in
EC market system through customs unton
with France
External debt: $NA
Industrial production: growth rate NA%
Electricity: 10,000 kW standby capacity
(1988), power supplied by France
Industries: pharmaceuticals, food process-
Ing, precision instruments, glassmaking,
printing, tourism
Agriculture: NA
Aid: NA
Currency: French franc (plural—francs), |
French franc (F) = 100 centimes
Exchange rates French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Fiscal year: calendar year','88e19eeaad3c0be118448ec8d4822089198ed17ac3bbf870dcb05df96132b54e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86e47b29cebea96068bf6889a73a2d1ded56dc162b8e783538baec1f2e7904c7',1990,'MS','Montserrat','economy',532,'Overview: The economy 1s small and open
with economic activity centered on tour-
ism and construction Tourism 1s the most
important sector and accounted for 20%
of GDP in 1986 Agriculture accounted
for about 4% of GDP and industry 9%
212
The economy 1s heavily dependent on tm-
ports, making it vulnerable to fluctuations
in world prices Exports consist mainly of
electronic parts sold to the US
GDP: $45 4 million, per capita $3,780,
real growth rate 12% (1988 est )
Inflation rate (consumer prices): 3 7%
(1987)
Unemployment rate: 3 0% (1987)
Budget: revenues $100 million, expendi-
tures $9 4 million, including capital ex-
penditures of $3 2 million (1987)
Exports: $3 0 million (f ob , 1987), com-
modities—-plastic bags, electronic parts,
apparel, hot peppers, live plants, cattle,
partners—NA
Imports: $25 3 million (c1f , 1987), com-
modities—machinery and transportation
equipment, foodstuffs, manufactured
goods, fuels, lubricants, and related mate-
rials, partners—NA
External debt: $3 7 million (1985)
Industrial production: growth rate 8 1%
(1986)
Electricity: 5,000 kW capacity, 12 million
kWh produced, 930 kWh per capita
(1989)
Industries: tourism, light manufacturing—
rum, textiles, electronic appliances
Agriculture: accounts for 4% of GDP,
small-scale farming, food crops—toma-
toes, onions, peppers, not self-sufficient in
food, especially livestock products
Aid: NA
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: 1 April-31 March','beca72135c7ac7299a9fdc15c839519820df1df56dffb977346edc48fe0b027e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19dcb4d37733bfe0c03a4e7f628a304fce60d9afba3449cf366b653beca36e58',1990,'NA','Namibia','economy',539,'Overview: The economy ts heavily depen-
dent on the mining industry to extract and
process minerals for export Mining ac-
counts for almost 35% of GDP, agricul-
ture and fisheries 10-15%, and manufac-
turing about 5% Namubia 1s the
fourth-largest exporter of nonfuel minerals
in Africa and the world’s fifth-largest pro-
ducer of uranium Alluvial diamond de-
posits are among the richest in the world,
making Namibia a primary source for
gem-quality diamonds Namubia also pro-
duces large quantities of lead, zinc, tin,
silver, and tungsten, and it has substantial
resources of coal
GNP: $1 54 billion, per capita $1,245, real
growth rate 2 9% (1987)
Inflation rate (consumer prices): 15 1%
(1989)
Unemployment rate: over 30% (1988)
Budget: revenues $781 million, expendi-
tures $932 million, including capital ex-
penditures of $NA (FY88)
Exports: $935 million (fo b , 1988), com-
modities—-diamonds, uranium, zinc, cop-
per, meat, processed fish, karakul skins,
partners—South Africa
Imports: $856 million (fo b , 1988), com-
modities—foodstuffs, manufactured con-
sumer goods, machinery and equipment,
partners—South Africa, FRG, UK, US
External debt: about $27 million at inde-
pendence, under a 1971 International
Court of Justice (ICJ) ruling, Namibia
may not be liable for debt incurred during
its colomal period
Industrial production: growth rate NA%
Electricity: 486,000 kW capacity, 1,280
million kWh produced, 930 kWh per cap-
ita (1989)
Industries: meatpacking, fish processing,
dairy products, mining (copper, lead, zinc,
diamond, uranium)
Agriculture: accounts for 10% of GDP (in-
cluding fishing), mostly subsistence farm-
ing, livestock raising major source of cash
Approved for Release: 2020/08/12 C06554432
income, crops—millet, sorghum, peanuts,
fish catch potential of over 1 million met-
ric tons not being fulfilled, 1987 catch
reaching only 520,000 metric tons, not
self-sufficient in food
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $47 2 million
Currency: South African rand (plural—
rand), 1 South African rand (R) = 100
cents
Exchange rates: South African rand (R)
per US$1—2 5555 (January 1990), 2 6166
(1989), 2 2611 (1988), 2 0350 (1987),
2 2685 (1986), 2 1911 (1985)
Fiscal year: | April-31 March
Overview: Revenues come from the export
of phosphates, the reserves of which are
expected to be exhausted by the year
2000 Phosphates have given Nauruans
one of the highest per capita incomes in
the Third World—$10,000 annually Few
other resources exist so most necessities
must be imported, including fresh water
from Austraha The rehabilitation of
mined land and the replacement of income
from phosphates constitute serious long-
term problems Substantial investment in
trust funds, out of phosphate income, will
help cushion the transition
GNP: over $90 million, per capita
$10,000, real growth rate NA% (1989)
Inflation rate (consumer prices): NA%
Unemployment rate: 0%
Budget: revenues $69 7 million, expendi-
tures $51 5 million, including capital ex-
penditures of $NA (FY86 est )
Exports: $93 million (fob, 1984), com-
modities—phosphates, partners—Austra-
ha, NZ
Imports: $73 million (cif , 1984), com-
modities—food, fuel, manufactures, build-
ing materials, machinery, partners—Aus-
tralia, UK, NZ, Japan
External debt: $33 3 million
Industrial production: growth rate NA%
Electricity: 13,250 kW capacity, 48 mil-
lion kWh produced, 5,300 kWh per capita
(1989)
Industries: phosphate mining, financial
services, coconuts
Agriculture: negligible, almost completely
dependent on imports for food and water
Aid: none
Currency: Australian dollar (plural—dol-
lars), | Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A)
per US$1—1 2784 (January 1990), 1 2618
(1989), 1 2752 (1988), | 4267 (1987),
1 4905 (1986), 1 4269 (1985)
Fiscal year: | July-30 June
Overview: no economic activity
218
Approved for Release: 2020/08/12 C06554432','dc1d6374bf1fb4967bd1e880cd2d344bc2e90db0724b5658eca3769cc69c8194','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('326361606f34b77812cf8bd19b8bb1168f0282e2c8879e3dd2004735bd194fff',1990,'NP','Nepal','economy',540,'200 km
Dbangerhi
Nepalganj
‘ “Pokhara
“KATHMANDU
Birghany
See regional map VIII
Overview: Nepal is among the poorest and
least developed countries in the world with
a per capita income of only $158 Real
growth averaged 4% in the 1980s until
FY89, when it plunged to 1 5% because of
the ongoing trade/transit dispute with In-
dia Agriculture is the mainstay of the
economy, providing a livelihood for over
90% of the population and accounting for
60% of GDP and about 75% of exports
Industrial activity 1s limited, and what
there is involves the processing of agricul-
tural produce (jute, sugarcane, tobacco,
and grain) Apart from agricultural land
and forests, the only other exploitable nat-
ural resources are mica, hydropower, and
tourism Despite considerable investment
in the agricultural sector, production in
the 1980s has not kept pace with the pop-
ulation growth of 2 7%, which has led to a
reduction in exportable surpluses and
balance-of-payments difficulties Economic
prospects for the 1990s remain grim
GDP: $2 9 billion, per capita $158, real
growth rate | 5% (FY89)
Inflation rate (consumer prices): 8 1%
(FY89 est )
Unemployment rate: 5%, underemploy-
ment estimated at 25-40% (1987)
219
Approved for Release: 2020/08/12 C06554432
Nepal (continued)
Budget: revenues $296 million, expendi-
tures $635 million, including capital ex-
penditures of $394 million (FY89 est )
Exports: $374 million (fob, FY89 est ),
but does not include unrecorded border
trade with India, commodities—clothing,
carpets, leather goods, grain, partners—
India 38%, US 23%, UK 6%, other Eu-
rope 9% (FY88)
Imports: $724 million (cif, FY89 est ),
commodities—petroleum products 20%,
fertilizer 11%, machinery 10%, partners—
India 36%, Japan 13%, Europe 4%, US
1% (FY88)
External debt: $1 3 billion (December
1989 est )
Industrial production: growth rate —4 5%
(FY89 est )
Electricity: 205,000 kW capacity, 535 mil-
lion kWh produced, 30 kWh per capita
(1989)
Industries: small rice, jute, sugar, and o1l-
seed mills, cigarette, textiles, cement,
brick, tourism
Agriculture: accounts for 60% of GDP and
90% of work force, farm products—trice,
corn, wheat, sugarcane, root crops, milk,
buffalo meat, not self-sufficient in food,
particularly in drought years
Illicit drugs: illicit producer of cannabis
for the domestic and international drug
markets
Aid: US commitments, including Ex-Im
(FY70-88), $285 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1980-87), $1 8 billion,
OPEC bilateral aid (1979-89), $30 million,
Communist countries (1970-88), $273 mil-
hon
Currency: Nepalese rupee (plural—
rupees), | Nepalese rupee (NR) = 100
paisa
Exchange rates: Nepalese rupees (NRs)
per US$1—28 559 (January 1990), 27 189
(1989), 23 289 (1988), 21 819 (1987),
21 230 (1986), 18 246 (1985)
Fiscal year: 16 July-15 July','a0161faec643d6f2dabd5b0c5b64c38afcc61535fcf8f83a0e27944442ecf3b3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92b94586a44833a96131c15edb993f7b9af51be8056a5b9bf9be0def9d561718',1990,'NZ','New Zealand','economy',553,'Overview: Since 1984 the government has
been reorienting an agrarian economy de-
pendent on a guaranteed British market to
Approved for Release: 2020/08/12 C06554432
an open free market economy that can
compete on the global scene The govern-
ment has hoped that dynamic growth
would boost real incomes, reduce infla-
tionary pressures, and permit the expan-
sion of welfare benefits The results have
been mixed inflation 1s down from
double-digit levels but growth has been
sluggish and unemployment, always a
highly sensitive issue, has been at a record
high 7 4% In 1988 GDP fell by 1% and
in 1989 grew by a moderate 2 4%
GDP: $39 | billion, per capita $11,600,
real growth rate 2 4% (1989 est.)
Inflation rate (consumer prices): 5% (1989)
Unemployment rate: 7 4% (1989)
Budget: revenues $18 6 billion, expendi-
tures $19 1 billion, including capital ex-
penditures of $NA (FY90 est )
Exports: $8 9 billion (f.0 b , FY89), com-
modities—wool, lamb, mutton, beef, fruit,
fish, cheese, manufactures, chemicals, fo-
resty products, partners—EC 18 3%, Ja-
pan 17 9%, Australia 17 5%, US 13 5%,
China 3 6%, South Korea 3 1%
Imports: $7 5 billion (c1f , FY89), com-
modities—petroleum, consumer goods,
motor vehicles, industrial equipment, part-
ners—Australia 19 7%, Japan 16 9%, EC
16 9%, US 15 3%, Taiwan 3 0%
External debt: $17 0 billion (1989)
Indystrial production: growth rate — 1 6%
(FY88)
Electricity: 7,800,000 kW capacity,
27,600 million kWh produced, 8,190 kWh
per capita (1989)
Industries: food processing, wood and pa-
per products, textiles, machinery, trans-
portation equipment, banking and insur-
ance, tourism, mining
Agriculture: accounts for about 9% of
GNP and 10% of the work force; livestock
predominates—wool, meat, dairy products
all export earners, crops—wheat, barley,
potatoes, pulses, fruits, and vegetables,
surplus producer of farm products, fish
catch reached a record 431,000 metric
tons in 1987
Aid: donor—ODA and OOF commitments
(1970-87), $448 million
Currency: New Zealand dollar (plural—
dollars), 1 New Zealand dollar (NZ$) =
100 cents
Exchange rates: New Zealand dollars
(NZ$) per US$1—1 6581 (January 1990),
1 6708 (1989), 1 5244 (1988), 1 6886
(1987), 1 9088 (1986), 2 0064 (1985)
Fiscal year: 1 July-30 June
Overview: The economy’s base 1s agricul-
ture, which employs about 70% of the la-
bor force and contributes 50% to GDP
Coconuts, bananas, and vanilla beans are
the main crops and make up two-thirds of
exports The country must import a high
proportion of its food, mainly from New
Zealand The manufacturing sector ac-
counts for only 10% of GDP Tourism 1s
the primary source of hard currency earn-
ings, but the island remains dependent on
sizable external aid and remittances to
sustain its trade deficit
GDP: $86 million, per capita $850, real
growth rate 3 6% (FY89 est )
Inflation rate (consumer prices): 8 2%
(FY87)
Unemployment rate: NA%
Budget: revenues $54 8 million, expendi-
tures $56 2 million, including capital ex-
penditures of $16 9 million (FY88 est )
Exports: $9 1 million (fob, FY88 est ),
commodities—coconut oil, desiccated co-
conut, copra, bananas, taro, vanilla beans,
fruits, vegetables, fish, partners—NZ
54%, Australia 30%, US 8%, Fin 5%
(FY87)
Imports: $60 1 million (cif, FY88 est ),
commodities—food products, beverages
and tobacco, fuels, machinery and trans-
port equipment, chemicals, building mate-
rials, partners—NZ 39%, Australia 25%,
Japan 9%, US 6%, EC 5% (FY87)
External debt: $31 8 million (1987)
Industrial production: growth rate 15%
(FY86)
Electricity: 5,000 kW capacity, 8 million
kWh produced, 80 kWh per capita (1989)
Industries: tourism, fishing
Agriculture: dominated by coconut, copra,
and banana production, vanilla beans, co-
coa, coffee, ginger, black pepper
Aid: US commitments, including Ex-Im
(FY70-87), $15 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $220 million
Currency: pa’anga (plural—pa’anga), 1
pa’anga (T$) = 100 seniti
Exchange rates: pa’anga (T$) per US$1—
1 23 (FY89 est ), 1 37 (FY88), 1 51
(FY87), 1 43 (FY86), 1 30 (FY85)
Fiscal year: 1 July-30 June
Overview: The economy 1s limited to sub-
sistence agriculture The majority of the
labor force earns its livelihood from agri-
335
Wallis and Futuna (continued)
culture, raising livestock, and fishing, with
the rest employed by the government sec-
tor Exports are negligible The Territory
has to import food, fuel, and construction
materials, and is dependent on budgetary
support from France to meet recurring
expenses The economy also benefits from
cash remittances from expatriate workers
GDP: $67 million, per capita $484, real
growth rate NA% (est 1985)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $NA, expenditures $NA,
including capital expenditures of $NA
Exports: $NA, commodities—copra, part-
ners—NA
Imports: $3 4 million (cif, 1977), com-
modities—liargely foodstuffs and some
equipment associated with development
programs, partners—France, Australia,
External debt: SNA
Industrial production: growth rate NA%
Electricity: 1,200 kW capacity, 1 million
kWh produced, 70 kWh per capita (1989)
Industries: copra, handicrafts, fishing,
lumber
Agriculture: dominated by coconut pro-
duction, with subsistence crops of yams,
taro, bananas
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $118 million
Currency: Comptoirs Francais du Paci-
fique franc (plural—francs), 1 CFP franc
(CFPF) = 100 centimes
Exchange rates: Comptoirs Francais du
Pacifique francs (CFPF) per US$1—
104 71 (January 1990), 115 99 (1989),
108 30 (1988), 109 27 (1987), 125 92
(1986), 163 35 (1985), note—linked at the
rate of 18 18 to the French franc
Fiscal year: NA','6edb0bd242d98ed738a5efbbab0913ad356c74f678a1a9c5f8d998743ec0f31b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9da7fc0cc24a103a635938ba1e4cdb1aefc9c41ad2aa7ffeae2d11f987f52579',1990,'NI','Nicaragua','economy',558,'Overview: Government control of the econ-
omy historically has been extensive, al-
though the new government has pledged
to reduce it The financial system 1s di-
rectly controlled by the state, which also
regulates wholesale purchasing, produc-
tion, sales, foreign trade, and distribution
of most goods Over 50% of the agricul-
tural and industrial firms are state owned
Sandinista economic policies and the war
have produced a severe economic crisis
The foundation of the economy continues
to be the export of agricultural commodi-
ties, largely coffee and cotton Farm pro-
duction fell by roughly 7% in 1989, the
fifth successive year of decline The agri-
cultural sector employs 44% of the work
force and accounts for 23% of GDP and
86% of export earnings Industry, which
employs 13% of the work force and con-
tributes 26% to GDP, showed a sharp
drop of —23% in 1988 and remains below
pre-1979 levels External debt 1s one of
the highest in the world on a per capita
basis In 1989 the annual inflation rate
was 1,700%, down from a record 16,000%
in 1988 Shortages of basic consumer
goods are widespread
GDP: $1 7 billion, per capita $470, real
growth rate —5 0% (1989 est )
Inflation rate (consumer prices): 1,700%
(1989)
Unemployment rate: 25% (1989)
Budget: revenues $0 9 billion, expenditures
$1 4 billion, including capital expenditures
of $0 15 billion (1987)
Exports: $250 million (fob, 1989 est ),
commoaities—coffee, cotton, sugar, ba-
Approved for Release: 2020/08/12 C06554432
nanas, seafood, meat, chemicals,
partners—CEMA 15%, OECD 75%, oth-
ers 10%
Imports: $550 million (cif, 1989 est ),
commoadities—petroleum, food, chemicals,
machinery, clothing, partners—CEMA
55%, EC 20%, Latin America 10%, others
10%
External debt: $8 billion (year end 1988)
Industrial production: growth rate —23%
(1988 est )
Electricity: 415,000 kW capacity, 1,340
million kWh produced, 380 kWh per cap-
ita (1989)
Industries: food processing, chemicals,
metal products, textiles, clothing, petro-
leum refining and distribution, beverages,
footwear
Agriculture: accounts for 23% of GDP and
44% of work force, cash crops—coffee,
bananas, sugarcane, cotton, food crops—
rice, corn, cassava, citrus fruit, beans, va-
riety of animal products—beef, veal, pork,
poultry, dairy, while normally
self-sufficient in food, war-induced short-
ages now exist
Aid: US commitments, including Ex-Im
(FY70-82), $290 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $981 million,
Communist countries (1970-88), $3 3 bil-
hon
Currency: cordoba (plural-—cérdobas), |
cérdoba (C$) = 100 centavos
Exchange rates: cérdobas (C$) per
US$1—65,000 (February 1990) 1s the free
market rate, official rate 1s 46,000 (Feb-
ruary 1990), 270 (1988), 0 103 (1987),
0 097 (1986), 0 039 (1985)
Fiscal year: calendar year','f10be81927d239522ee8858da6cb8a0bd9b452c1e4eaa1428f31c3d646e23483','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d49f6e2538a2ae081d6c439855d2b741d1c46d47cde230908f21c6e235d751a3',1990,'NE','Niger','economy',563,'Overview: About 90% of the population 1s
engaged in farming and stock rearing, ac-
tivities which generate almost half of the
national income The economy also de-
pends heavily on exploitation of large ura-
nium deposits Uranium production grew
rapidly in the mid-1970s, but tapered off
in the early 1980s, when world prices de-
clined France is a major customer, while
FRG, Japan, and Spain also make regular
purchases The depressed demand for ura-
nium has contributed to an overall slug-
gishness in the economy, a severe trade
imbalance, and a mounting external debt
GDP: $2 4 billion, per capita $330, real
growth rate 7 1% (1988 est )
Inflation rate (consumer prices): — 1 4%
(1988)
Unemployment rate: NA%
Budget: revenues $254 million, expendi-
tures $510 million, including capital ex-
penditures of $239 million (1988 est )
Exports: $371 million (fob, 1988 est ),
commodities—uranium 76%, livestock,
cowpeas, onions, hides, skins, partners—
NA
Imports: $441 million (cif, 1988 est ),
commodities—petroleum products, pri-
mary materials, machinery, vehicles and
parts, electronic equipment, pharmaceuti-
cals, chemical products, cereals, foodstuffs
External debt: $1 8 billion (December
1989 est )
230
Approved for Release: 2020/08/12 C06554432
Industrial production: growth rate 4 7%
(1989 est )
Electricity: 102,000 kW capacity, 225 mil-
lion kWh produced, 30 kWh per capita
(1989)
Industries: cement, brick, rice mills, small
cotton gins, oilseed presses, slaughter-
houses, and a few other small light indus-
tries, uranium production began in 1971
Agriculture: accounts for roughly 40% of
GDP and 90% of labor force, cash
crops—cowpeas, cotton, peanuts, food
crops—millet, sorghum, cassava, rice, live-
stock—cattle, sheep, goats, self-sufficient
in food except in drought years
Aid: US commitments, including Ex-Im
(FY70-88), $349 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 8 billion,
OPEC bilateral aid (1979-89), $504 mil-
lion, Communist countries (1970-88), $61
million
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: 1 October-30 September','d403ca0b07efbf189d5b6c40e40953691b54ad8a8ea37a60bfa891550f169b74','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7490a9d91b6cafa9f0dcc5d59002fa503b0bffd43180ab60b8edd48444c69892',1990,'NU','Niue','economy',569,'Overview: The economy 1s heavily depen-
dent on aid from New Zealand Govern-
ment expenditures regularly exceed reve-
nues, with the shortfall made up by grants
from New Zealand—the grants are used
to pay wages to the 80% or more of the
work force employed in public service
The agricultural sector consists mainly of
subsistence gardening, although some cash
crops are grown for export Industry con-
sists primarily of small factories to process
passion fruit, lime oil, honey, and coconut
cream The sale of postage stamps to for-
eign collectors 1s an important source of
revenue The island in recent years has
suffered a serious loss of population be-
cause of migration of Niueans to New
Zealand
GNP: $2 1 million, per capita $1,000, real
growth rate NA% (1989 est )
Inflation rate (consumer prices): 9 6%
(1984)
Unemployment rate: NA%
Budget: revenues $5 5 million, expendi-
tures $6 3 million, including capital ex-
penditures of NA (FY85 est )
Exports: $175,274 (fob, 1985), commod-
itles—canned coconut cream, copra,
honey, passion fruit products, pawpaw,
root crops, limes, footballs, stamps, handi-
crafts, partners—NZ 89%, Fiji, Cook Is-
lands, Australia
Imports: $3 8 million (c1f , 1985), com-
modities—food, live animals, manufac-
tured goods, machinery, fuels, lubricants,
chemicals, drugs, partners—NZ 59%, Fiji
20%, Japan 13%, Western Samoa, Austra-
ha, US
External debt: $NA
Industrial production: growth rate NA%
Electricity: 1,500 kW capacity, 3 million
kWh produced, 1,420 kWh per capita
(1989)
Industries: tourist, handicrafts
Agriculture: copra, coconuts, passion fruit,
honey, limes, subsistence crops—taro,
yams, cassava (tapioca), sweet potatoes,
pigs, poultry, beef cattle
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $58 million
Currency: New Zealand doilar (plural—
dollars), 1 New Zealand dollar (NZ$) =
100 cents
Exchange rates: New Zealand dollars
(NZ$) per US$1—1 6581 (January 1990),
1 6708 (1989), 1 5244 (1988), 1 6886
(1987), 1 9088 (1986), 2 0064 (1985)
Fiscal year: 1 April-31 March','304342f8f073982764fe088dd80472a3d702485da6cfd22ac0c0b2832745146b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e53265fa3f152b00cc6ccbbf17daf9ca418cfb59f255be11f4400b0cdafe6197',1990,'NF','Norfolk Island','economy',574,'Overview: The primary economic activity
1s tourism, which has brought a level of
prosperity unusual among inhabitants of
the Pacific Islands The number of visitors
has increased steadily over the years and
reached almost 30,000 in 1986 Revenues
from tourism have given the island a fa-
vorable balance of trade and helped the
234
Approved for Release: 2020/08/12 C06554432
agricultural sector to become self-
sufficient in the production of beef, poul-
try, and eggs
GNP: NA
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $3 4 million, expendi-
tures $3 4 million, including capital ex-
penditures of NA (FY88)
Exports: $1 8 million (fo b , FY85), com-
modities—postage stamps, seeds of the
Norfolk Island pine and Kentia Palm,
small quantities of avocados, partners—
Australia, Pacific Islands, NZ, Asia, Eu-
rope
Imports: $16 3 million (cif, FY85), com-
modities—NA, partners—Australha, Pa-
cific Islands, NZ, Asia, Europe
External debt: NA
Industrial production: growth rate NA%
Electricity: 7,000 kW capacity, 8 million
kWh produced, 3,210 kWh per capita
(1989)
Industries: tourism
Agriculture: Norfolk Island pine seed,
Kentia palm seed, cereals, vegetables,
fruit, cattle, poultry
Aid: none
Currency: Australian dollar (plural—dol-
lars), 1 Australian dollar ($A) = 100 cents
Exchange rates: Australian dollars ($A)
per US$1—1 2784 (January 1990), 1 2618
(1989), 1 2752 (1988), 1 4267 (1987),
1 4905 (1986), 1 4269 (1985)
Fiscal year: | July-30 June','03d14ff0f1a6a016dabb0b6181453cff718c9abc1f0966fcdaf6bdd7cc699424','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf9eda89a0305c779321932c3ff64447af29173e5f9fed93e3013dc8de613cd',1990,'MP','Northern Mariana Islands','economy',579,'Overview: The economy benefits substan-
tially from financial assistance from the
US. An agreement for the years 1986 to
1992 entitles the islands to $228 million
for capital development, government oper-
ations, and special programs Another ma-
jor source of income 1s the tourist indus-
try, which employs about 10% of the work
force The agricultural sector 1s made up
of cattle ranches and small farms produc-
ing coconuts, breadfruit, tomatoes, and
melons Industry 1s small scale in
nature—mostly handicrafts and fish pro-
cessing
GNP: $165 million, per capita $9,170,
real growth rate NA% (1982)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $NA, expenditures $70 6
million, including capital expenditures of
$NA (1987)
Exports: $NA, commodities—vegetables,
beef, pork; partners—NA
Imports: $NA, commodities—NA, part-
ners—NA
External debt: $NA
Industrial production: growth rate NA%
Electricity: 25,000 kW capacity, 35 mil-
lion kWh produced, 1,640 kWh per capita
(1989)
Industries: tourism, construction, light 1n-
dustry, handicrafts
Agriculture: coffee, coconuts, fruits, to-
bacco, cattle
Aid: none
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: 1 October-30 September','4be864042d043d792a4aee11976cf51df5bad09f725249aca868cd3883917ec3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79211b8ad41981cfe9d918c2784ccf17750f3df79c64e355e44eafb393c46be9',1990,'NO','Norway','economy',584,'Overview: Norway 1s a prosperous capital-
ist nation with the resources to finance
extensive welfare measures Since 1975
exploitation of large crude oil and natural
gas reserves has helped achieve an average
annual growth of roughly 4%, the third-
highest among OECD countries Growth
slackened in 1987-88 because of the sharp
drop in world o1] prices and a slowdown in
consumer spending, but picked up again in
1989 Future economic issues involve the
aging of the population, the increased eco-
nomic integration of Europe, and the bal-
ance between private and public influence
in economic decisions
GDP: $75 8 billion, per capita $17,900,
real growth rate 5 7% (1989 est )
Inflation rate (consumer prices): 4 5%
(1989)
Unemployment rate: 3 9% (1989 est , ex-
cluding people in job-training programs)
Budget: revenues $40 6 billion, expendi-
tures $41 3 billion, including capital ex-
penditures of $NA (1989)
Exports: $22 2 billion (fo b , 1989), com-
modities—petroleum and petroleum prod-
ucts 25%, natural gas 11%, fish 7%, alu-
minum 6%, ships 3 5%, pulp and paper,
partners—UK 26%, EFTA 16 3%, less
developed countries 14%, Sweden 12%,
FRG 12%, US 6%, Denmark 5% (1988)
Imports: $18 7 billion (cif, 1989), com-
modities—machinery, fuels and
lubricants, transportation equipment,
chemicals, foodstuffs, clothing, ships, part-
ners—Sweden 18%, less developed coun-
tries 18%, FRG 14%, Denmark 8%, UK
7%, US 7%, Japan 5% (1988)
External debt: $18 3 billion (December
1989)
Industrial production: growth rate 15 8%
(1989)
Electricity: 26,735,000 kW capacity,
121,685 million kWh produced, 28,950
kWh per capita (1989)
Industries: petroleum and gas, food pro-
cessing, shipbuilding, pulp and paper
products, metals, chemicals, timber, min-
ing, textiles, fishing
Agriculture: accounts for 3 1% of GNP
and 6 5% of labor force, among world’s
top 10 fishing nations, livestock output
exceeds value of crops, over half of food
needs imported, fish catch of 1 9 million
metric tons in 1987
Aid: donor—ODA and OOF commitments
(1970-87), $3 7 billion
Currency: Norwegian krone (plural—kro-
ner), | Norwegian krone (NKr) = 100 ore
Exchange rates: Norwegian kroner (NKr)
per US$1—6 5405 (January 1990), 6 9045
(1989), 6 5170 (1988), 6 7375 (1987),
7 3947 (1986), 8 5972 (1985)
Fiscal year: calendar year
Approved for Release: 2020/08/12 C06554432','12f2c32d2577626ad978ebee0efaf0074e0e1ca7bbd7d3e6281d55ea3309cb94','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f66af11c9e92e522362ce043cd5a7b1aaa4f86701196a6cf9b28bf5a13eae29',1990,'OM','Oman','economy',589,'Overview: Economic performance ts closely
tied to the fortunes of the oil industry
Petroleum accounts for nearly all export
earnings, about 70% of government reve-
nues, and more than 50% of GDP Oman
has proved oil reserves of 4 billion barrels,
equivalent to about 20 years’ supply at the
current rate of extraction Although agri-
culture employs a majority of the popula-
tion, urban centers depend on imported
food
GDP: $7 8 billion, per capita $6,006, real
growth rate — 3 0% (1987 est )
Inflation rate (consumer prices): 2 0%
(1988 est )
Unemployment rate: NA%
Budget: revenues $3 | billion, expenditures
$4 2 billion, including capital expenditures
of $1 0 billion (1989 est )
Exports: $3 6 billion (fob, 1988 est ),
commodities—petroleum, reexports, pro-
cessed copper, dates, nuts, fish, partners—
Japan, South Korea, Thailand
Imports: $1 9 billion (Fob, 1988 est ),
commodities —machinery, transportation
equipment, manufactured goods, food,
livestock, lubricants, partners—Japan,
UAE, UK, FRG, US
External debt: $3 1 billion (December
1989 est )
Industrial production: growth rate 5 0%
(1986)
Electricity: 1,130,000 kW capacity, 3,600
million kWh produced, 2,760 kWh per
capita (1989)
Industries: crude oil production and re-
fining, natural gas production, construc-
tion, cement, copper
Agriculture: accounts for 3 4% of GDP
and 60% of the labor force (including
fishing), less than 2% of land cultivated,
largely subsistence farming (dates, limes,
bananas, alfalfa, vegetables, camels, cat-
tle), not self-sufficient in food, annual fish
catch averages 100,000 metric tons
Aid: US commitments, including Ex-Im
(FY 70-88), $122 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $92 million,
OPEC bilateral aid (1979-89), $797 mil-
hon
Approved for Release: 2020/08/12 C06554432
Currency: Omani rtal (plural—niais), |
Omani rial (RO) = 1,000 baiza
Exchange rates: Omani rials (RO) per
US$1—0 3845 (fixed rate since 1986)
Fiscal year: calendar year
Overview: The economy consists primarily
of subsistence agriculture and fishing
Tourism provides some foreign exchange,
although the remote location of Palau and
a shortage of suitable facilities has hin-
dered development The government is the
major employer of the work force, relying
heavily on financial assistance from the
US
GDP: $31 6 million, per capita $2,260,
real growth rate NA% (1986)
Inflation rate (consumer prices): NA%
Unemployment rate: 20% (1986)
Budget: revenues $6 0 million, expendi-
tures NA, including capital expenditures
of NA (1986)
Exports: $0 5 million (fob, 1986), com-
modities—N A, partners—US, Japan
Imports: $27 2 million (cif, 1986), com-
modities—NA, partners—US
External debt: $NA
Industrial production: growth rate NA%
Electricity: 16,000 kW capacity, 22 mil-
hon kWh produced, 1,550 kWh per capita
(1989)
Industries: tourism, craft 1tems (shell,
wood, pearl), some commercial fishing and
agriculture
Agriculture: subsistence-level production
of coconut, copra, cassava, sweet potatoes
Aid: US commitments, including Ex-Im
(FY70-87), $2 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $62 6 million
Currency: US currency is used
Exchange rates: US currency 1s used
Fiscal year: 1 October-30 September
239
Approved for Release: 2020/08/12 C06554432
Pacific Islands, Trust Territory
of the (Palau) (continued)
Overview: The Pacific Ocean 1s a major
contributor to the world economy and par-
ticularly to those nations its waters di-
rectly touch It provides cheap sea trans-
portation between East and West,
extensive fishing grounds, offshore ol and
gas fields, minerals, and sand and gravel
for the construction industry In 1985 over
half (54%) of the world’s total fish catch
came from the Pacific Ocean, which 1s the
only ocean where the fish catch has in-
creased every year since 1978 Exploita-
tion of offshore oil and gas reserves 1s
playing an ever increasing role in the en-
ergy supplies of Australia, New Zealand,
China, US, and Peru The high cost of
recovering offshore oil and gas, combined
with the lower world prices for oil since
1985, has slowed but not stopped new
drillings
Industries: fishing, oil and gas production
Overview: Pakistan 1s a poor Third World
country faced with the usual problems of
rapidly increasing population, sizable gov-
ernment deficits, and heavy dependence on
foreign aid In addition, the economy must
support a large military establishment and
provide for the needs of 4 million Afghan
refugees A real economic growth rate
averaging 5-6% in recent years has en-
abled the country to cope with these prob-
lems Almost all agriculture and small-
scale industry is in private hands, and the
government seeks to privatize a portion of
the large-scale industrial enterprises now
publicly owned In December 1988, Paki-
stan signed a three-year economic reform
agreement with the IMF, which provides
for a reduction in the government deficit
and a liberalization of trade in return for
further IMF financial support The so-
called Islamization of the economy has
affected mainly the financial sector, for
example, a prohibition on certain types of
interest payments Pakistan almost cer-
tainly will make little headway against its
population problem; at the current rate of
growth, population would double in 32
years
GNP: $43 2 billion, per capita $409, real
growth rate 5 1% (FY89)
Inflation rate (consumer prices): 11%
(FY89)
Unemployment rate: 4% (FY89 est )
Budget: revenues $7 5 billion, expenditures
$10 3 billion, including capital expendi-
tures of $2 3 billion (FY89 est )
Exports: $4.5 billion (fo b , FY89), com-
modities—nice, cotton, textiles, clothing,
partners—EC 31%, US 11%, Japan 11%
(FY88)
Imports: $7 2 billion (fob, FY89), com-
modities—petroleum, petroleum products,
machinery, transportation, equipment,
vegetable oils, animal fats, chemicals,
partners—EC 26%, Japan 15%, US 11%
(FY88)
External debt: $17 4 billion (1989)
Industrial production: growth rate 3%
(FY89)
Electricity: 7,575,000 kW capacity,
29,300 million kWh produced, 270 kWh
per capita (1989)
Industries: textiles, food processing, bever-
ages, petroleum products, construction
materials, clothing, paper products, inter-
national finance, shrimp
Agriculture: 24% of GNP, over 50% of
labor force, world’s largest contiguous irri-
gation system, major crops—cotton,
wheat, rice, sugarcane, fruits, and vegeta-
Approved for Release: 2020/08/12 C06554432
bles, livestock products—mulk, beef, mut-
ton, eggs, self-sufficient in food grain
MHiicit drugs: illicit producer of opium
poppy and cannabis for the international
drug trade, government eradication efforts
on poppy cultivation of limited success,
1988 output of opium and hashish each
estimated at about 200 metric tons
Aid: (including Bangladesh before 1972)
US commitments, including Ex-Im
(FY70-88), $4 2 billion authorized (ex-
cluding what 1s now Bangladesh), Western
(non-US) countries, ODA and OOF bilat-
eral commitments (1980-87), $7 5 billion,
OPEC bilateral aid (1979-89), $2 3 billion,
Communist countries (1970-88), $2 9 brl-
lion
Currency: Pakistani rupee (plural—
rupees), 1 Pakistani rupee (PRe) = 100
paisa
Exchange rates: Pakistam rupees (PRs)
per US$1—21 420 (January 1990), 20 541
(1989), 18 003 (1988), 17 399 (1987),
16 648 (1986), 15 928 (1985)
Fiscal year: 1 July-30 June
Overview: no economic activity
243
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432','f5adbc550eee7f755d3a993950c5a663af8735b33ef4a9c04ea399c21b7d41a8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3333b994829083dd2ed2306ff358dff64aae9a5f945dd653b285bec5fbcc0c54',1990,'PA','Panama','economy',590,'150 km
Caribbean Sea
¢Bocas f Panama
5 del Toro s
°
Gulf of Le Palina
North Pacific Ocean
See regional map IE
Overview: The GDP contracted an esti-
mated 7 5% in 1989, following a drop of
20% in 1988 Political instability, lack of
credit, and the erosion of business confi-
dence prompted declines of 20-70% in the
financial, agricultural, commercial, manu-
facturing, and construction sectors be-
tween 1987 and 1989 Transits through
the Panama Canal were off slightly, as
were toll revenues Unemployment
remained about 23% during 1989 Imports
of foodstuffs and crude oil increased dur-
ing 1989, but capital goods imports con-
tinued their slide Exports were widely
promoted by Noriega trade delegations,
but sales abroad remained stagnant
GDP: $3 9 billion, per capita $1,648, real
growth rate —7 5% (1989 est )
Inflation rate (consumer prices): —0 1%
(1989 est )
Unemployment rate: 23% (1989 est )
Budget: revenues $598 million, expendi-
tures $750 million, including capital ex-
penditures of $NA (1989 est )
Exports: $220 million (fo b , 1989 est ),
commodities—bananas 40%, shrimp 27%,
coffee 4%, sugar, petroleum products,
partners—US 90%, Central America and
Caribbean, EC (1989 est )
Imports: $830 million (f o b , 1989 est ),
commodities—foodstuffs 16%, capital
goods 9%, crude oil 16%, consumer goods,
chemicals, partners—US 35%, Central
America and Caribbean, EC, Mexico,
Venezuela (1989 est )
External debt: $5 2 billion (November
1989 est )
Industrial production: growth rate —4 1%
(1989 est )
Electricity: 1,113,000 kW capacity; 3,270
million kWh produced, 1,380 kWh per
capita (1989)
Industries: manufacturing and construc-
tion activities, petroleum refining, brew-
ing, cement and other construction mate-
rial, sugar mills, paper products
Agriculture: accounts for 10% of GDP
(1989 est.), 26% of labor force (1987),
crops—bananas, rice, corn, coffee, sugar-
cane, livestock, fishing, importer of food
grain, vegetables, milk products
Aid: US commitments, including Ex-Im
(FY70-88), $515 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $568 million,
Communist countries (1970-88), $4 million
Approved for Release: 2020/08/12 C06554432
Currency: balboa (plural—balboas), 1 bal-
boa (B) = 100 centésimos
Exchange rates: balboas (B) per US$1—
1 000 (fixed rate)
Fiscal year: calendar year','5f1df7751eafa5b3983839ddda2e460c9c7d675cda23047a3ced1befea280fd5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62356845b7f1021119de18d53f19b1a7b772c273f9e7865d3fbd1b37c858fe41',1990,'PG','Papua New Guinea','economy',599,'Overview: Papua New Guinea 1s richly
endowed with natural resources, but ex-
ploitation has been hampered by the rug-
ged terrain and the high cost of develop-
ing an infrastructure Agriculture provides
a subsistence livelihood for more than half
of the population Mining of numerous
deposits, including copper and gold, ac-
counts for about 60% of export earnings
Budgetary support from Australia and
development aid under World Bank aus-
pices help sustain the economy
GDP: $3 26 billion, per capita $890, real
growth rate 1 2% (1988 est )
Inflation rate (consumer prices): 5% (1988
est )
Unemployment rate: 5% (1988)
Budget: revenues $962 million, expendi-
tures $998 muilhion, including capital ex-
penditures of $169 million (1988)
Exports: $1 4 billion (fob, 1988), com-
modities—gold, copper ore, coffee, copra,
palm oil, timber, lobster, partners—FRG,
Japan, Australia, UK, Spain, US
Imports: $1 2 billion (fo b , 1988), com-
modities—machinery and transport equip-
ment, fuels, food, chemicals, consumer
goods, partners—Australia, Singapore,
Japan, US, New Zealand, UK
External debt: $2 5 billion (December
1988)
Industrial production: growth rate NA%
Approved for Release: 2020/08/12 C06554432
Electricity: 397,000 kW capacity, 1,510
million kWh produced, 400 kWh per cap-
ita (1989)
Industries: copra crushing, oil palm pro-
cessing, plywood processing, wood chip
production, gold, silver, copper, construc-
tion, tourism
Agriculture: one-third of GDP, livelihood
for 85% of population, fertile soils and
favorable climate permits cultivating a
wide variety of crops, cash crops—coffee,
cocoa, coconuts, palm kernels, other prod-
ucts—tea, rubber, sweet potatoes, fruit,
vegetables, poultry, pork, net importer of
food for urban centers
Aid: US commitments, including Ex-Im
(FY 70-87), $38 8 million; Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $5 8 billion,
OPEC bilateral aid (1979-89), $17 million
Currency: kina (plural—kina), | kina (K)
= 100 toea
Exchange rates: kina (K) per US$1—
1 1592 (December 1989), 1 1685 (1989),
1 1538 (1988), 1 1012 (1987), 1 0296
(1986), 1 0000 (1985)
Fiscal year: calendar year
Overview: no economic activity','47511870607afbc6d2d1f67a51da4f89f7381f9c846290c23e6570997d48dea9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8d8a3aaac2e5d0d0005bce6d1c87c748100405ac6b19e3da27575521a020dde',1990,'PY','Paraguay','economy',604,'Overview: The economy 1s predominantly
agricultural Agriculture, including for-
estry, accounts for about 25% of GNP,
employs about 45% of the labor force, and
provides the bulk of exports Paraguay has
248
Approved for Release: 2020/08/12 C06554432
no known significant mineral or petroleum
resources, but does have a large hydro-
power potential Since 1981 economic per-
formance has declined compared with the
boom period of 1976-81, when real GDP
grew at an average annual rate of nearly
11% During 1982-86 real GDP fell three
out of five years, inflation jumped to an
annual rate of 32%, and foreign debt rose
Factors responsible for the erratic behav-
1or of the economy were the completion of
the Itarpu hydroelectric dam, bad weather
for crops, and weak international com-
modity prices for agricultural exports In
1987 the economy experienced a modest
recovery because of improved weather
conditions and stronger international
prices for key agricultural exports The
recovery continued through 1988, with a
bumper soybean crop and record cotton
production The government, however,
must follow through on promises of re-
forms needed to deal with large fiscal def-
icits, growing debt arrearages, and falling
reserves
GDP: $8 9 billion, per capita $1,970, real
growth rate 5 2% (1989 est )
Inflation rate (consumer prices): 30% (1989
est )
Unemployment rate: 12% (1989 est )
Budget: revenues $609 million, expendi-
tures $909 million, including capital ex-
penditures of $401 million (1988)
Exports: $1,020 million (registered fob,
1989 est ), commodities—cotton, soybean,
timber, vegetable oils, coffee, tung oil,
Meat products, partners—EC 37%, Brazil
25%, Argentina 10%, Chile 6%, US 6%
Imports: $1,010 million (registered cif,
1989 est ), commodities—capital goods
35%, consumer goods 20%, fuels and lu-
bricants 19%, raw materials 16%, food-
stuffs, beverages, and tobacco 10%, part-
ners—Brazil 30%, EC 20%, US 18%,
Argentina 8%, Japan 7%
External debt: $2 9 billion (1989 est )
Industrial production: growth rate 2%
(1987)
Electricity: 5,169,000 kW capacity,
15,140 million kWh produced, 3,350 kWh
per capita (1989)
Industries: meat packing, oilseed crushing,
mulling, brewing, textiles, other light con-
sumer goods, cement, construction
Agriculture: accounts for 25% of GDP and
50% of labor force, cash crops—cotton,
sugarcane, other crops—corn, wheat, to-
bacco, soybeans, cassava, fruits, and vege-
tables, animal products—beef, pork, eggs,
milk, surplus producer of timber,
self-sufficient 1n most foods
Illicit drugs: illicit producer of cannabis
for the international drug trade with an
estimated 300 hectares cultivated in 1988,
important transshipment point for Boliv-
1an cocaine headed for the US and Europe
Approved for Release: 2020/08/12 C06554432
Aid: US commitments, including Ex-Im
(FY70-88), $168 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $994 million
Currency: guarani (plural—guaranies), |
guarani (G) = 100 céntimos
Exchange rates: guaranies (G) per US$1—
1,200 20 (November 1989, floated in Feb-
ruary 1989), 550 00 (fixed rate
1986-February 1989), 339 17 (1986),
306 67 (1985)
Fiscal year: calendar year','95492b2a344e432105299cb40e91083526bb7f78c28b9c7d53e2befde0a74847','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43c9ee53083f5dbf5eececa8bea1cab3b00bb62529e0423d32c2d1ae707d1316',1990,'PE','Peru','economy',608,'Overview: The economy ts verging on hy-
perinflation and economic activity 1s con-
tracting rapidly Deficit spending 1s at the
root of domestic economic problems, but
poor relations with international lenders—
the result of curtailing debt payments
since 1985—are preventing an inflow of
funds to generate a recovery Reduced
standards of living have increased labor
tensions, and strikes, particularly in the
key mining sector, have cut production
and exports Foreign exchange shortages
have forced reductions in vital consumer
imports such as food and industrial inputs
Peru 1s the world’s leading producer of
coca, from which the drug cocaine 1s pro-
duced.
GDP: $18 9 billion, per capita $880; real
growth rate — 12.2% (1989 est )
Inflation rate (consumer prices): 2,775%
(1989)
Unemployment rate: 15 0%, underemploy-
ment estimated at 60% (1989)
Budget: revenues $3 2 billion, expenditures
$3 7 billion, including capital expenditures
of $796 million (1986)
Exports: $3 55 billion (fo b , 1989), com-
modities—fishmea], cotton, sugar, coffee,
copper, iron ore, refined silver, lead, zinc,
crude petroleum and byproducts, part-
ners—EC 22%, US 20%, Japan 11%,
Latin America 8%, USSR 4%
Imports: $2 50 billion (f.0.b., 1989), com-
modities—foodstuffs, machinery, transport
equipment, iron and steel semimanufac-
tures, chemicals, pharmaceuticals; part-
ners—US 23%, Latin America 16%, EC
12%, Japan 7%, Switzerland 3%
External debt: $17 7 billion (December
1989)
Industrial production: growth rate
—25 0% (1988 est )
Electricity: 4,867,000 kW capacity,
15,540 million kWh produced, 725 kWh
per capita (1989)
Industries: mining of metals, petroleum,
fishing, textiles, clothing, food processing,
cement, auto assembly, steel, shipbuilding,
metal fabrication
Agriculture: accounts for 12% of GDP,
37% of labor force, commercial crops—
coffee, cotton, sugarcane; other crops—
rice, wheat, potatoes, plantains, coca, ani-
mal products—poultry, red meats, dairy,
wool; not self-sufficient in grain or vegeta-
ble oil, fish catch of 4 6 million metric
tons (1987), world’s fifth-largest
Illicit drugs: world’s largest coca producer
and source of supply for coca paste and
cocaine base, about 85% of cultivation 1s
for illicit production, most of coca base 1s
shipped to Colombian drug dealers for
processing into cocaine for the interna-
tional drug market
250
Approved for Release: 2020/08/12 C06554432
Aid: US commitments, including Ex-Im
(FY70-88), $1 6 billion; Western (non-US)
countries, ODA and OOF bilateral com-
muitments (1970-87), $3 7 billion, Commu-
nist countries (1970-88), $577 million
Currency: inti (plura!—intis), 1 inti (I/) =
1,000 soles
Exchange rates: intis (1/) per US$1—
5,261 40 (December 1989), 128 83 (1988),
16 84 (1987), 13 95 (1986), 10 97 (1985)
Fiscal year: calendar year','73fd7ae18eb95947e00f785aa94538ff1848bda8bac0f949c6424a3249674ed6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca6ed4f765e844e1dc6a910f1aa065fadf2352ae20b8c634314d7dacb85aad78',1990,'PN','Pitcairn','economy',614,'Overview: The inhabitants exist on fishing
and subsistence farming The fertile soil
of the valleys produces a wide variety of
fruits and vegetables, including citrus,
sugarcane, watermelons, bananas, yams,
and beans Bartering 1s an important part
of the economy The major sources of rev-
Approved for Release: 2020/08/12 C06554432
enue are the sale of postage stamps to col-
lectors and the sale of handicrafts to pass-
ing ships
GNP: NA
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $430,440, expenditures
$429,983, including capital expenditures
of $NA (FY87 est )
Exports: $NA, commodities—fruits, vege-
tables, curios, partners—NA
Imports: $NA, commodities—fuel oil, ma-
chinery, building materials, flour, sugar,
other foodstuffs, partners—NA
External debt: $NA
Industrial production: growth rate NA%
Electricity: 110 kW capacity, 0 30 million
kWh produced, 4,410 kWh per capita
(1989)
Industries: postage stamp sales, handi-
crafts
Agriculture: based on subsistence fishing
and farming, wide variety of fruits and
vegetables grown, must import grain prod-
ucts
Aid: none
Currency: New Zealand dollar (plural—
dollars), 1 New Zealand dollar (NZ$) =
100 cents
Exchange rates: New Zealand dollars
(NZ$) per US$1—1 6581 (January 1990),
1.6708 (1989), 1 5244 (1988), 1 6866
(1987), 1 9088 (1986), 2 0064 (1985)
Fiscal year: 1 April-31 March','6928ce3d333eb9adfd632e66995fe2463b5276b91914bf2febda690ddedd1b7e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4de640b68ed9b68decec9988ea543727c90ba0955c65429d6d64434b68b5f85',1990,'PL','Poland','economy',619,'Overview: The economy, except for the
agricultural sector, had followed the So-
viet model of state ownership and control
of the country’s productive assets About
75% of agricultural production had come
from the private sector and the rest from
state farms The economy has presented a
picture of moderate but slowing growth
against a background of underlying weak-
nesses in technology and worker motiva-
tion GNP increased between 3% and 6%
annually during the period 1983-1986, but
grew only 2 5% and 2 1% in 1987 and
1988, respectively Output dropped by
1 5% in 1989 The inflation rate, after
falling sharply from the 1982 peak of
100% to 22% in 1986, rose to a galloping
rate of 640% in 1989 Shortages of con-
sumer goods and some food items wors-
ened in 1988-89 Agricultural products
and coal have remained the biggest hard
currency earners, but manufactures are
increasing 1n importance Poland, with its
hard currency debt of approximately $40
billion, 1s severely limited in its ability to
import much-needed hard currency goods
The sweeping political changes of 1989
disrupted normal economic channels and
exacerbated shortages In January 1990,
the new Solidarity-led government
adopted a cold turkey program for trans-
forming Poland to a market economy The
government moved to eliminate subsidies,
end artificially low prices, make the ztoty
convertible, and, in general, halt the hy-
perinflation These financial measures are
accompanied by plans to privatize the
economy in stages Substantial outside aid
will be needed if Poland 1s to make a suc-
cessful transition in the 1990s
GNP: $172 4 billion, per capita $4,565,
real growth rate — 1 6% (1989 est )
Inflation rate (consumer prices): 640%
(1989 est )
Unemployment rate: NA%, 215,000 (of-
ficial number, mid-March 1990)
Budget: revenues $23 billion, expenditures
$24 billion, including capital expenditures
of $3 5 billion (1988)
Exports: $24 7 billion (fo b , 1987 est ),
commodities—machinery and equipment
63%, fuels, minerals, and metals 14%,
manufactured consumer goods 14%, agri-
cultural and forestry products 5% (1987
est ), partners—USSR 25%, FRG 12%,
Czechoslovakia 6% (1988)
Imports: $22 8 billion (fo b , 1987 est ),
commodities—machinery and equipment
36%, fuels, minerals, and metals 35%,
manufactured consumer goods 9%, agri-
cultural and forestry products 12%, part-
ners—USSR 23%, FRG 13%, Czechoslo-
vakia 6% (1988)
External debt: $40 billion (1989 est )
Industrial production: growth rate —2 0%
(1988)
Electricity: 31,390,000 kW capacity,
125,000 million kWh produced, 3,260
kWh per capita (1989)
Industries: machine building, iron and
steel, extractive industries, chemicals,
shipbuilding, food processing, glass, bever-
ages, textiles
Agriculture: accounts for 15% of GNP
and 28% of labor force, 75% of output
from private farms, 25% from state farms,
productivity remains low by European
standards, leading European producer of
rye, rapeseed, and potatoes, wide variety
of other crops and livestock, major ex-
porter of pork products, normally self-
sufficient in food
Aid: donor—bilateral aid to
non-Communist less developed countries,
$2 1 billion (1954-88)
Currency: zloty (plural—ztotych), 1 zloty
(Zt) = 100 groszy
Exchange rates: zlotych (Zt) per US$1—
9,500 00 (January 1990), 1,439 18 (1989),
430 55 (1988), 265 08 (1987), 175 29
(1986), 147 14 (1985)
Fiscal year: calendar year','c95d3d8b7ae867593afbc3db36a0d613eb3250eda6aac06e887ad1d1b42e5671','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ffa16f14099daf63457c877337a60aaf09970e76a6f19c424577e28b44103e0',1990,'PT','Portugal','economy',624,'Overview: During the past four years, the
economy has made a sustained recovery
from the severe recession of 1983-85 The
economy grew by 47% in 1987, 41% in
1988, and 3 5% in 1989, largely because
Approved for Release: 2020/08/12 C06554432
of strong domestic consumption and in-
vestment spending Unemployment has
declined for the third consecutive year,
but inflation continues to be about three
times the European Community average
The government 1s pushing economic re-
structuring and privatization measures in
anticipation of the 1992 European Com-
munity timetable to form a single large
market in Europe
GDP: $72 1 billion, per capita $6,900, real
growth rate 3 5% (1989 est )
Inflation rate (consumer prices): 11 8%
(1989 est )
Unemployment rate: 5 9% (1989 est )
Budget: revenues $19 0 billion, expendi-
tures $22 2 billion, including capital ex-
penditures of $3 1 billion (1989 est )
Exports: $11 0 billion (fob, 1988), com-
modities—cotton textiles, cork and cork
products, canned fish, wine, timber and
timber products, resin, machinery, appli-
ances, partners—EC 72%, other developed
countries 13%, US 6%
Imports: $17 7 billion (cif, 1988), com-
modities—petroleum, cotton, foodgrains,
industrial machinery, iron and steel,
chemicals, partners—EC 67%, other de-
veloped countries 13%, less developed
countries 15%, US 4%
External debt: $17 2 billion (1988)
Industrial production: growth rate 5 5%
(1988)
Electricity: 6,729,000 kW capacity,
16,000 million kWh produced, 1,530 kWh
per capita (1989)
Industries: textiles and footwear, wood
pulp, paper, and cork, metalworking, oil
refining, chemicals, fish canning, wine,
tourism
Agriculture: accounts for 9% of GDP and
20% of labor force, small inefficient farms,
imports more than half of food needs, ma-
jor crops—grain, potatoes, olives, grapes,
livestock sector—sheep, cattle, goats, poul-
try, meat, dairy products
Aid: US commitments, including Ex-Im
(FY70-88), $1 8 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $998 million
Currency: Portuguese escudo (plural—
escudos), 1 Portuguese escudo (Esc) = 100
centavos
Exchange rates: Portuguese escudos (Esc)
per US$1—149 15 (January 1990), 157 46
(1989), 143 95 (1988), 140 88 (1987),
149 59 (1986), 170 39 (1985)
Fiscal year: calendar year','00230c5bbba727b59cc6338284d9aabd7e0a06ffa6406aba2cc675201fb8366d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2db45a99ab304fcae1e562f12ab9055592b772c79ed68ea23b9ef2fe77a3101b',1990,'PR','Puerto Rico','economy',629,'Overview: Puerto Rico has one of the most
dynamic economies in the Caribbean re-
gion Industry has surpassed agriculture
as the primary sector of economic activity
and income Encouraged by duty-free ac-
cess to the US and by tax incentives, US
firms have invested heavily in Puerto Rico
since the 1970s Important new industries
include pharmaceuticals, electronics, tex-
tiles, petrochemicals, and processed foods
Sugar production has lost out to dairy
production and other livestock products as
the main source of income 1n the agricul-
tural sector Tourism has traditionally
been an important source of income for
the island
GNP: $18 4 billion, per capita $5,574, real
growth rate 4 9% (FY88)
Inflation rate (consumer prices): 33% (De-
cember 1987-88)
Unemployment rate: 12 8% (December
1988)
Budget: revenues $4 9 million, expendi-
tures $49 million, including capital ex-
penditures of $NA (FY88)
Exports: $13 2 billion (fob , FY88), com-
modities—sugar, coffee, petroleum prod-
ucts, chemical, metal products, textiles,
electronic equipment, partners—US 87%
Imports: $11 8 billion (cif, FY88), com-
modities—chemicals, clothing, food, fish
products, crude oil, partners—US 60%
External debt: $NA
258
Approved for Release: 2020/08/12 C06554432
Industrial production: growth rate 5 8%
(FY87)
Electricity: 4,149,000 kW capacity,
14,050 million kWh produced, 4,260 kWh
per capita (1989)
Industries: tourism, manufacturing, phar-
maceuticals, chemicals, food processing,
petroleum refining
Agriculture: accounts for 4% of labor
force, crops—sugarcane, coffee, pineap-
ples, tobacco, bananas, livestock—<attle,
chickens, imports a large share of food
needs
Aid: none
Currency: US currency 1s used
Exchange rates: US currency is used
Fiscal year: 1 July-30 June
Overview: Oil is the backbone of the econ-
omy and accounts for 90% of export earn-
ings and more than 80% of government
revenues Proved oil reserves of 3 3 billion
barrels should ensure continued output at
current levels for about 25 years Oil has
given Qatar a per capita GDP of about
$17,000, among the highest in the world
GDP: $5 4 billion, per capita $17,070, real
growth rate 9 0% (1987)
Inflation rate (consumer prices): 1 6%
(1987)
Unemployment rate: NA%
Budget: revenues $1 7 billion, expenditures
$3 4 billion, including capital expenditures
of $NA (FY88 est }
Exports: $2 2 billion (fob, 1988 est ),
commodities—petroleum products 90%,
steel, fertilizers, partners—France, FRG,
Italy, Japan, Spain
Imports: $1 0 billion (fob, 1988 est ), ex-
cluding military equipment, commodi-
ties—foodstuffs, beverages, animal and
vegetable oils, chemicals, machinery and
equipment, partners—EC, Japan, Arab
countries, US, Australia
External debt: $1 1 billion (December
1989 est )
Industrial production: growth rate 0 6%
(1987)
Electricity: 1,514,000 kW capacity, 4,000
million kWh produced, 8,540 kWh per
capita (1989)
Industries: crude oil production and re-
fining, fertilizers, petrochemicals, steel,
cement
Agriculture: farming and grazing on small
scale, less than 2% of GDP, commercial
fishing increasing 1n importance, most
food imported
Aid: donor—pledged $2 7 billion in ODA
to less developed countries (1979- 88)
Currency: Qatari riyal (plural—triyals), 1
Qatari riyal (QR) = 100 dirhams
Exchange rates: Qatari riyals (QR) per
US$1—3 6400 riyals (fixed rate)
Fiscal year: 1 April-3]1 March
Overview: The economy has traditionally
been based on agriculture Sugarcane has
been the primary crop for more than a
century, and in some years it accounts for
85% of exports The government 1s push-
ing the development of a tourist industry
to relieve a high unemployment rate that
was over 30% in 1986 The economic well
being of Reunion depends heavily on con-
tinued financial assistance from France
GDP: $2 4 billion, per capita $4,290
(1985), real growth rate 9% (1987 est )
Inflation rate (consumer prices): 2 8%
(1987)
Unemployment rate: 32 0%, high seasonal
unemployment (1986)
Budget: revenues $358 million, expendi-
tures $914 million, including capital ex-
penditures of $NA (1986)
Exports: $136 million (fob, 1986), com-
modities—sugar 75%, rum and molasses
4%, perfume essences 4%, vanilla and tea
1%, partners—France, Mauritius, Bah-
rain, S Africa, Italy
Imports: $1 1 million (cif, 1986), com-
modities—manufactured goods, food, bev-
erages, tobacco, machinery and transpor-
tation equipment, raw materials, and
petroleum products, partners—France,
Mauritius, Bahrain, South Africa, Italy
External debt: NA
Industrial production: growth rate NA%
Electricity: 245,000 kW capacity, 546 mil-
lion kWh produced, 965 kWh per capita
(1989)
Industries: sugar, rum, cigarettes, several
small shops producing handicraft 1tems
Agriculture: accounts for 30% of labor
force, dominant sector of economy, cash
crops—sugarcane, vanilla, tobacco, food
crops—tropical fruits, vegetables, corn,
imports large share of food needs
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $13 5 billion
Currency: French franc (plural—francs), 1
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Fiscal year: calendar year
External debt: $NA
Industrial production: growth rate 12%
Electricity: 341,000 kW capacity, 507 mil-
lion kWh produced, 4,650 kWh per capita
(1989)
Industries: tourism, government service,
petroleum refining, watch assembly, rum
distilling, construction, pharmaceuticals,
textiles, electronics
Agriculture: truck gardens, food crops
(small scale), fruit, sorghum, Senepol cat-
tle
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $33 5 million
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: | October-30 September
334','fab659ea61c075736e88b8731acc69514ca936c1366393ffe3a694f743e973d2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b7cbdf46ceaa3be6953d3a446d1b00e78869386646ccc27de2c6b76fe62a19',1990,'RW','Rwanda','economy',634,'Overview: About 40% of GDP comes from
the agricultural sector, coffee and tea
make up 80-90% of total exports The
amount of fertile land 1s limited, however,
and deforestation and soil erosion have
created problems The industrial sector in
Rwanda 1s small, contributing less than
20% to GDP Manufacturing focuses
mainly on the processing of agricultural
products The Rwandan economy remains
dependent on coffee exports and foreign
aid, with no relief in sight Weak interna-
tional prices since 1986 have caused the
economy to contract and per capita GDP
to decline
GDP: $2 3 billion, per capita $325, real
growth rate —2 5% (1988 est )
Inflation rate (consumer prices): 3% (1988)
Unemployment rate: NA%
Budget: revenues $413 million, expendi-
tures $522 million, including capital ex-
penditures of $230 million (1988 est )
Exports: $118 million (fob, 1988), com-
modities—coffee 85%, tea, tin, cassiterite,
wolframite, pyrethrum, partners—FRG,
Belgium, Italy, Uganda, UK, France, US
Imports: $278 million (fob, 1988), com-
modities—textiles, foodstuffs, machines
and equipment, capital goods, steel, petro-
leum products, cement and construction
material, partners—-US, Belgium, FRG,
Kenya, Japan
External debt: $645 million (December
1989 est )
Industrial production: growth rate 1 2%
(1988)
Electricity: 26,000 kW capacity, 112 mil-
lion kWh produced, 15 kWh per capita
(1989)
Industries: mining of cassiterite (tin ore)
and wolframite (tungsten ore), tin, cement,
agricultural processing, small-scale bever-
age production, soap, furniture, shoes,
plastic goods, textiles, cigarettes
Agriculture: cash crops—coffee, tea, pyre-
thrum (insecticide made from
263
Approved for Release: 2020/08/12 C06554432
Rwanda (continued)
chrysanthemums), main food crops—ba-
nanas, beans, sorghum, potatoes, stock
raising, self-sufficiency declining, country
imports foodstuffs as farm production fails
to keep up with a 3 8% annual growth in
population
Aid: US commitments, including Ex-Im
(FY70-88), $118 million; Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1.7 billion,
OPEC bilateral! aid (1979-89), $45 million,
Communist countries (1970-88), $58 mil-
hon
Currency: Rwandan franc (plural—francs),
1 Rwandan franc (RF) = 100 centimes
Exchange rates: Rwandan francs (RF) per
US$1—78 99 (December 1989), 79 98
(1989), 76 45 (1988), 79 67 (1987), 87 64
(1986), 101 26 (1985)
Fiscal year: calendar year
Overview: The economy depends primarily
on financial assistance from the UK The
local population earns some income from
fishing, the rearing of livestock, and sales
of handicrafts Because there are few jobs,
a large proportion of the work force have
left to seek employment overseas
GDP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices): —1 1%
1986)
Unemployment rate: NA%
Budget: revenues $3 2 million, expendi-
tures $2 9 million, including capital ex-
penditures of NA (1984)
Exports: $23 9 thousand (f 0 b, 1984),
commodities—fish (frozen skipjack, tuna,
salt-dried skipyack), handicrafts,
partners—South Africa, UK
Imports: $2 4 million (cif, 1984), com-
modities—food, beverages, tobacco, fuel
oils, animal feed, building materials, mo-
tor vehicles and parts, machinery and
parts, partners—UK, South Africa
External debt: $NA
Industrial production: growth rate NA%
Electricity: 9,800 kW capacity, 10 million
kWh produced, 1,390 kWh per capita
(1989)
Industries: crafts (furniture, lacework,
fancy woodwork), fish
Agriculture: maize, potatoes, vegetables,
timber production being developed, craw-
fishing on Tristan da Cunha
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $168 million
Currency: St Helenian pound (plural—
pounds), 1 St Helenian pound (£S) = 100
pence
Exchange rates: St Helenian pounds (£S)
per US$1—-0 6055 (January 1990), 0 6099
(1989), 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985), note—the
St Helenian pound 1s at par with the
British pound
Fiscal year: 1 April-31 March
Overview: The economy has historically
depended on the growing and processing
of sugarcane and on remittances from
overseas workers In recent years, tourism
and export-oriented manufacturing have
assumed larger roles
GDP: $119 million, per capita $3,240, real
growth rate 6% (1988 est )
Inflation rate (consumer prices): 0 9%
(1987)
Unemployment rate: 20-25% (1987)
Budget: revenues $38 5 million, expendi-
tures $45 0 million, including capital ex-
penditures of $15 8 million (1988)
Exports: $30 3 million (fob, 1988), com-
modities—sugar, manufactures, postage
stamps, partners—US 44%, UK 30%, Tri-
nidad and Tobago 12% (1987)
Imports: $94 7 million (c1f , 1988), com-
modities—foodstuffs, intermediate manu-
factures, machinery, fuels, partners—US
35%, UK 18%, Trinidad and Tobago 10%,
Canada 6%, Japan 4% (1987)
External debt: $27 6 million (1988)
Industrial production: growth rate 5 8%
(1986)
Electricity: 15,800 kW capacity, 45 mil-
lion kWh produced, 1,120 kWh per capita
(1989)
Industries: sugar processing, tourism, cot-
ton, salt, copra, clothing, footwear, bever-
ages
Agriculture: accounts for 10% of GDP,
cash crop—sugarcane, subsistence crops-—
rice, yams, bananas, fishing potential not
fully exploited, most food imported
Aid: US commitments, including Ex-Im
(FY 70-87), $13 6 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $46 million
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal year: calendar year
Overview: Since 1983 the economy has
shown an impressive average annual
growth rate of almost 5% because of
strong agricultural and tourist industry
sectors There 1s also an expanding tndus-
trial base supported by foreign investment
in manufacturing and other activities,
such as in data processing The economy,
however, remains vulnerable because the
important agricultural sector 1s dominated
by banana production St Lucia is subject
to periodic droughts and/or tropical
storms, and its protected market agree-
ment with the UK for bananas may end
in 1992
GDP: $172 million, per capita $1,258, real
growth rate 6 8% (1988 est )
Inflation rate (consumer prices): 7 0%
(1987)
Unemployment rate: 18 6% (1986)
Budget: revenues $71 7 million, expendi-
tures $79 3 million, including capital ex-
penditures of $19 6 million (1987)
Exports: $76 8 million (fo b, 1987), com-
modities—bananas 67%, cocoa, vegeta-
bles, fruits, coconut oil, clothing, part-
ners—UK 55%, CARICOM 21%, US
18%, other 6%
Imports: $178 1 million (cif, 1987), com-
modities—manufactured goods 22%, ma-
chinery and transportation equipment
21%, food and live animals 20%, mineral
fuels, foodstuffs, machinery and equip-
ment, fertilizers, petroleum products, part-
ners—US 33%, UK 16%, CARICOM
14 8%, Japan 6 5%, other 29 7%
External debt: $39 5 million (December
1987)
Industrial production: growth rate 2 4%
(1987)
Electricity: 20,000 kW capacity, 80 mil-
lion kWh produced, 530 kWh per capita
(1989)
Industries: clothing, assembly of electronic
components, beverages, corrugated boxes,
tourism, lime processing, coconut process-
ing
Agriculture: accounts for 15% of GDP and
43% of labor force, crops—bananas, coco-
nuts, vegetables, citrus fruit, root crops,
cocoa, imports food for the tourist indus-
try
Aid: US commitments, including Ex-Im
(FY70-87), $4 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $93 million
Currency: East Caribbean dollar (plural—
dollars), 1 EC dollar (EC$) = 100 cents
267
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
St. Lucia (continued)
Exchange rates: East Caribbean dollars
(EC$) per US$1—2 70 (fixed rate since
1976)
Fiscal Year: | April-31 March
Overview: The inhabitants have tradition-
ally earned their livelihood by fishing and
by servicing fishing fleets operating off the
coast of Newfoundland The economy has
been declining, however, because the num-
ber of ships stopping at St Pierre has
steadily dropped over the years In March
1989, an agreement between France and
Canada set fish quotas for St Pierre’s
trawlers fishing in Canadian and
Canadian-claimed waters for three years
The agreement settles a longstanding dis-
pute that had virtually brought fish ex-
ports to a halt The islands are heavily
subsidized by France Imports come pri-
marily from Canada
GDP: $NA, per capita $2,495 (1984), real
growth rate NA%
Inflation rate (consumer prices): NA%
Unemployment rate: 13 3% (1987)
Budget: revenues $NA million, expendi-
tures $139 million, including capita! ex-
penditures of $NA (1988)
Exports: $23 3 million (fob , 1986), com-
modities—fish and fish products, fox and
mink pelts, partners—US 58%, France
17%, UK 11%, Canada, Portugal
Imports: $50 3 million (cif, 1986), com-
modities—meat, clothing, fuel, electrical
equipment, machinery, building materials,
partners—Canada, France, US, Nether-
lands, UK
External debt: $NA
Industrial production: growth rate NA%
Electricity: 10,000 kW capacity, 25 mil-
lion kWh produced, 3,970 kWh per capita
(1989)
Industries: fishing and supply base for
fishing fleets, tourism
Agriculture: vegetables, cattle, sheep and
pigs for local consumption, fish catch,
14,750 metric tons (1986)
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $477 million
Currency: French franc (plural—francs), 1
French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1—5 7598 (January 1990), 6 3801
(1989), 5 9569 (1988), 6 0107 (1987),
6 9261 (1986), 8 9852 (1985)
Fiscal year: calendar year','68f23507fd4802111daf828820b6f4fbd051250e11d2ed899ca45e388ad1c69b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a434dc5a12a245f17d796cd6dd4e9b50195a746436da972c3997bc487a9380a7',1990,'SM','San Marino','economy',639,'Overview: The economy relies heavily on
the tourist industry as a source of revenue
More than 2 million tourists visit each
year, contributing about 60% to GDP
The sale of postage stamps to foreign col-
lectors 1s another important income pro-
ducer The manufacturing sector employs
nearly 40% of the labor force and agricul-
ture less than 4% The per capita level of
output and standard of living are compa-
rable to northern Italy
GDP: $NA, per capita $NA, real growth
rate NA%
Inflation rate (consumer prices): 6 4%
(1986)
Unemployment rate: 6 5% (1985)
Budget: revenues $99 2 million, expendi-
tures $NA, including capital expenditures
of $NA (1983)
Exports: trade data are included with the
statistics for Italy, commodity trade con-
sists primarily of exchanging building
stone, lime, wood, chestnuts, wheat, wine,
baked goods, hides, and ceramics for a
wide variety of consumer manufactures
Imports: see Exports
External debt: $NA
Industrial production: growth rate NA%
Electricity: supplied by Italy
Industries: wine, olive oil, cement, leather,
textile, tourist
Agriculture: employs less than 4% of labor
force, products—wheat, grapes, corn, ol-
ives, meat, cheese, hides, small numbers of
cattle, pigs, horses, depends on Italy for
food imports
Aid: NA
Currency: Italian jira (plural—hre), 1 Ital-
1an lira (Lit) = 100 centesimi, also mints
its Own coins
Exchange rates: Italian lire (Lit) per
US$1—1,262 5 (January 1990), 1,372 1
(1989), 1,301 6 (1988), 1,296 1 (1987),
1,490 8 (1986), 1,909 4 (1985)
Fiscal year: calendar year
271
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
San Marino (continued)','f826eb4ff4cf89c0feb616ada4fc08a8014cf7aa310af654f4f93c6653425407','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb3416be433cba2ce78e71d222228a853e808df64c5133e49c66ac0f72c6a119',1990,'SA','Saudi Arabia','economy',646,'Overview: By far the most important eco-
nomic activity 1s the production of petro-
leum and petroleum products The petro-
leum sector accounts for about 85% of
budget revenues, 80% of GDP, and almost
all export earnings Saudi Arabia has the
largest reserves of petroleum in the world,
1s the largest exporter of petroleum, and
plays a leading role in OPEC Oil wealth
has provided a per capita GDP that 1s
comparable to most industrialized coun-
tries Saudi Arabia 1s one of the few coun-
tries where consumer prices have been
dropping or showing little change in re-
cent years
GDP: $73 billion, per capita $4,720, real
growth rate 3 2% (1988)
Inflation rate (consumer prices): | 5%
(1989 est )
Unemployment rate: 0% (1989 est )
Budget: revenues $31 5 billion, expendi-
tures $38 1 billion, including capital ex-
penditures of $NA (1990)
Exports: $24 5 billion (fob, 1989 est ),
commodities—petroleum and petroleum
products 89%, partners—Japan 26%, US
26%, France 6%, Bahrain 6%
Approved for Release: 2020/08/12 C06554432
Imports: $21 8 billion (fob, 1989 est),
commoaities—manufactured goods, trans-
portation equipment, construction materi-
als, processed food products, partners—
US 20%, Japan 18%, UK 16%, Italy 11%
External debt: $18 9 billion (December
1989 est )
Industrial production: growth rate 6 1%
(1980-86)
Electricity: 25,066,000 kW capacity,
50,000 million kWh produced, 3,100 kWh
per capita (1989)
Industries: crude oil production, petroleum
refining, basic petrochemicals, cement,
small steel-rolling mill, construction, fer-
tilizer, plastic
Agriculture: accounts for about 10% of
GDP, 16% of labor force, fastest growing
economic sector, subsidized by govern-
ment, products—wheat, barley, tomatoes,
melons, dates, citrus fruit, mutton, chick-
ens, eggs, milk, approaching self-sufh-
ciency 1n food
Aid: donor—pledged $64 7 billion in bilat-
eral aid (1979-89)
Currency: Saudi riya! (plural—riyals), 1
Saudi riyal (SR) = 100 halalas
Exchange rates: Saudi riyals (SR) per
US$1—3 7450 (fixed rate since late 1986),
3 7033 (1986), 3 6221 (1985)
Fiscal year: calendar year','741dccac2d57ce502e0a87825065185788c462d7ec6375d61cb94a53087b9ef1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d568d3deebb4028ede74f965a25ff222fa6ce93d460fc9c91f861d314cb61b2',1990,'SN','Senegal','economy',651,'Overview: The agricultural sector accounts
for about 20% of GDP and provides em-
ployment for about 75% of the labor
force About 40% of the total cultivated
land 1s used to grow peanuts, an impor-
tant export crop The principal economic
resource 1s fishing, which brought in about
$200 million or about 25% of total foreign
exchange earnings in 1987 Mining 1s
dominated by the extraction of phosphate,
but production has faltered because of
reduced worldwide demand for fertilizers
in recent years Over the past 10 years
tourism has become increasingly more 1m-
portant to the economy
GDP: $5 0 billion, per capita $680, real
growth rate 5 1% (1988 est )
276
Approved for Release: 2020/08/12 C06554432
Inflation rate (consumer prices): — 1 8%
(1988 est )
Unemployment rate: 3 5% (1987)
Budget: revenues $921 million, expendi-
tures $1,024 million, including capital ex-
penditures of $14 million (FY89 est )
Exports: $761 million (fob, 1988), com-
modities—manufactures 30%, fish prod-
ucts 27%, peanuts 11%, petroleum prod-
ucts 11%, phosphates 10%, partners-—US,
France, other EC, Ivory Coast, India
Imports: $1 1 billion (cif, 1988), com-
modities—semimanufactures 30%, food
27%, durable consumer goods 17%, petro-
leum 12%, capital goods 14%, partners—
US, France, other EC, Nigeria, Algeria,
China, Japan
External debt: $3 8 billion (1988)
Industrial production: growth rate 4 9%
(1986)
Electricity: 210,000 kW capacity, 760 mil-
lion kWh produced, 100 kWh per capita
(1989)
Industries: fishing, agricultural processing,
phosphate mining, petroleum refining,
building materials
Agriculture: including fishing, accounts for
20% of GDP and 75% of labor force, ma-
jor products—peanuts (cash crop), millet,
corn, sorghum, rice, cotton, tomatoes,
green vegetables, estimated two-thirds
self-sufficient in food, fish catch of
299,000 metric tons in 1987
Aid: US commitments, including Ex-Im
(FY70-88), $492 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $4 4 billion,
OPEC bilateral aid (1979-89), $589 mil-
lion, Communist countries (1970-88), $295
million
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300 54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: 1 July-30 June','d6f95972dccc13b87468fab43b35515ccf2f7b36a4aa29c1269eebc0562ec3ae','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea43c6df21597306ec11c61d38ec603e27bb8b080a477e1dfcd7fa1b21fed28',1990,'SC','Seychelles','economy',656,'Overview: In this small, open tropical 1s-
land economy, the tourist industry em-
ploys about 30% of the labor force and
provides the main source of hard currency
earnings In recent years the government
has encouraged foreign investment 1n or-
der to upgrade hotels and other services
At the same time, the government has
moved to reduce the high dependence on
tourism by promoting the development of
farming, fishing, and small-scale manufac-
turing
GDP: $255 million, per capita $3,720, real
growth rate 6 2%, (1988 est )
Inflation rate (consumer prices): 2 3%
(1988)
Unemployment rate: 15% (1986)
Budget: revenues $106 million, expend:-
tures $130 million, including capital ex-
penditures of $21 million (1987)
Exports: $17 million (fo b , 1988 est ),
commodities—fish, copra, cinnamon bark,
petroleum products (reexports), partners—
France 63%, Pakistan 12%, Reunion 10%,
UK 7% (1987)
Imports: $116 million (fo b , 1988 est ),
commodities—manufactured goods, food,
tobacco, beverages, machinery and trans-
portation equipment, petroleum products,
partners—UK 20%, France 14%, South
Africa 13%, PDRY 13%, Singapore 8%,
Japan 6% (1987)
External debt: $178 million (December
1988)
Industrial production: growth rate 7%
(1987)
Electricity: 25,000 kW capacity, 67 mil-
lion kWh produced, 960 kWh per capita
(1989)
Industries: tourism, processing of coconut
and vanilla, fishing, coir rope factory, boat
building, printing, furniture, beverage
Agriculture: accounts for 7% of GDP,
mostly subsistence farming, cash crops—
coconuts, cinnamon, vanilla, other prod-
277
Approved for Release: 2020/08/12 C06554432
Seychelles (continued)
ucts—sweet potatoes, cassava, bananas,
broiler chickens, large share of food needs
imported, expansion of tuna fishing under
way
Aid: US commitments, including Ex-Im
(FY 78-88), $23 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1978-87), $297 million, OPEC
bilateral aid (1979-89), $5 million, Com-
munist countries (1970-88), $56 million
Currency: Seychelles rupee (plural—
rupees), | Seychelles rupee (SRe) = 100
cents
Exchange rates: Seychelles rupees (SR)
per US$1—5 4884 (January 1990), 5 6457
(1989), 5 3836 (1988), 5 6000 (1987),
6 1768 (1986), 7 1343 (1985)
Fiscal year: calendar year','894f6cfd2f204f1c68dd5e9dc3537b1cad7f4104226cc60dc065749d7f888b0a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec779d9bb23b2ad32250c5262a4a2e61094822407bda07140444262079409cf3',1990,'SB','Solomon Islands','economy',668,'Overview: About 90% of the population
depend on subsistence agriculture, fishing,
and forestry for at least part of their live-
lihood Agriculture, fishing, and forestry
contribute about 75% to GDP, with the
fishing and forestry sectors being impor-
tant export earners The service sector
contributes about 25% to GDP Manufac-
turing activity is neghgible Most manu-
factured goods and petroleum products
must be imported The islands are rich in
undeveloped mineral resources such as
lead, zinc, nickel, and gold The economy
suffered from a severe cyclone in mid-
1986 which caused widespread damage to
the infrastructure
GDP: $156 million, per capita $500, real
growth rate 4 3% (1988)
Inflation rate (consumer prices): 11 2%
(1988)
Unemployment rate: NA%
Budget: revenues $139 0 million, expendi-
tures $154 4 milhon, including capital ex-
penditures of $113 4 million (1987)
Exports: $80 1 million (fo b , 1988), com-
modities—fish 46%, timber 31%, copra
5%, palm oil 5%, partners—Japan 51%,
UK 12%, Thailand 9%, Netherlands 8%,
Australia 2%, US 2% (1985)
Imports: $101 7 million (fob, 1988),
commodities—plant and machinery 30%,
fuel 19%, food 16%; partners—Japan
36%, US 23%, Singapore 9%, UK 9%,
NZ 9%, Australia 4%, Hong Kong 4%,
China 3% (1985)
External debt: $128 million (1988 est )
Industrial production: growth rate 0%
(1987)
Electricity: 15,000 kW capacity, 30 mil-
lion kWh produced, 90 kWh per capita
(1989)
Industries: copra, fish (tuna)
Agriculture: including fishing and forestry,
accounts for about 75% of GDP, mostly
subsistence farming, cash crops—cocoa,
beans, coconuts, palm kernels, timber,
other products—rice, potatoes, vegetables,
fruit, cattle, pigs, not self-sufficient in food
grains, 90% of the total fish catch of
44,500 metric tons was exported (1988)
281
Approved for Release: 2020/08/12 C06554432
Solomon Islands (continued)
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1985),
$16 1 million
Currency: Solomon Islands dollar
(plural—dollars), 1 Solomon Islands dollar
(SI$) = 100 cents
Exchange rates: Solomon Islands dollars
(SI$) per US$1—2 4067 (January 1990),
2 3090 (1989), 2 0825 (1988), 2 0033
(1987), 1 7415 (1986), 1 4808 (1985)
Fiscal year: calendar year','1cfb83f72da6d92ed1636368151dcb2961ddb6ced54371084fb31a8fc8782261','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed598e6b808c47e32c06a8f0497488589e95129d7f1582615ddd94dce86c4e00',1990,'SO','Somalia','economy',673,'Overview: One of the world’s least devel-
oped countries, Somalia has few resources
In 1988 per capita GDP was $210 Agri-
culture is the most important sector of the
economy, with the livestock sector
accounting for about 40% of GDP and
about 65% of export earnings Nomads
and seminomads who are dependent upon
livestock for their livelihoods make up
about 50% of the population Crop pro-
duction generates only 10% of GDP and
employs about 20% of the work force The
main export crop 1s bananas, sugar, sor-
ghum, and corn are grown for the domes-
tic market The small industrial sector 1s
based on the processing of agricultural
products and accounts for less than 10%
of GDP At the end of 1988 serious eco-
nomic problems facing the nation were the
external debt of $2 8 billion and double-
digit inflation
GDP: $1 7 billion, per capita $210, real
growth rate —1 4% (1988)
Inflation rate (consumer prices): 81 7%
(1988 est )
Unemployment rate: NA%
Approved for Release: 2020/08/12 C06554432
Budget: revenues $273 million, expendi-
tures $405 million, including capital ex-
penditures of $219 million (1987)
Exports: $58 0 million (fo b, 1988), com-
modities—livestock, hides, skins, bananas,
fish, partners—US 0 5%, Saudi Arabia,
Italy, FRG (1986)
Imports: $354 0 million (c1 f , 1988), com-
modities—textiles, petroleum products,
foodstuffs, construction materials, part-
ners—US 13%, Italy, FRG, Kenya, UK,
Saudi Arabia (1986)
External debt: $2 8 billion (1989 est )
Industrial production: growth rate NA%
Electricity: 71,000 kW capacity, 65 mul-
lion kWh produced, 8 kWh per capita
(1989)
Industries: a few small industries, includ-
Ing sugar refining, textiles, petroleum re-
fining
Agriculture: dominant sector, led by live-
stock raising (cattle, sheep, goats), crops—
bananas, sorghum, corn, mangoes, sugar-
cane, not self-sufficient in food, fishing
potential largely unexploited
Aid: US commitments, including Ex-[m
(FY 70-88), $618 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 8 billion,
OPEC bilateral aid (1979-89), $1 1 billion,
Communist countries (1970-88), $336 mil-
lion
Currency: Somali shilling (plural—shil-
lings), 1 Somali shilling (So Sh) = 100
centesim1
Exchange rates: Somali shillings (So Sh)
per US$1—643 92 (December 1989),
170 45 (1988), 105 18 (1987), 72 00 (1986),
39 49 (1985)
Fiscal year: calendar year','f82a8baca2f7d1208a1370b3690886d2d2a8af683a8e7005f6274955b8380bac','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1c8d98e339e596976ae29809004afbd28b646316d88fecf17fb9f95a9c86fb3',1990,'LK','Sri Lanka','economy',680,'Overview: Agriculture, forestry, and
fishing dominate the economy, employing
about half of the labor force and account-
Approved for Release: 2020/08/12 C06554432
ing for about 25% of GDP The plantatioi
crops of tea, rubber, and coconuts provide
about 50% of export earnings and almost
20% of budgetary revenues The economy
has been plagued by high rates of unem-
ployment since the late 1970s
GDP: $6 1 billion, per capita $370, real
growth rate 2 7% (1988)
Inflation rate (consumer prices): 15%
(1988)
Unemployment rate: 20% (1988 est )
Budget: revenues $1 5 billion, expenditure
$2 3 billion, including capital expenditure
of $0 7 billion (1989)
Exports: $1 5 billion (fo b , 1988), com-
modities—tea, textiles and garments, pe-
troleum products, coconut, rubber, agri-
cultural products, gems and jewelry,
marine products, partners—US 26%,
Egypt, Iraq, UK, FRG, Singapore, Japan
Imports: $2 3 billion (cif, 1988), com-
modities—petroleum, machinery and
equipment, textiles and textile materials,
wheat, transportation equipment, electrica
machinery, sugar, rice, partners—Japan,
Saudi Arabia, US 5 6%, India, Singapore
FRG, UK, Iran
External debt: $5 6 billion (1989)
Industrial production: growth rate 5%
(1988)
Electricity: 1,300,000 kW capacity, 4,200
million kWh produced, 250 kWh per cap-
ita (1989)
Industries: processing of rubber, tea, coco-
nuts, and other agricultural commodities,
cement, petroleum refining, textiles, to-
bacco, clothing
Agriculture: accounts for 25% of GDP anc
nearly half of labor force, most important
staple crop 1s paddy rice, other field
crops—-sugarcane, grains, pulses, oilseeds,
roots, spices, cash crops—tea, rubber, co-
conuts, animal products—mulk, eggs,
hides, meat, not self-sufficient in rice pro-
duction
Aid: US commitments, including Ex-Im
(FY 70-88), $932 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1980-87), $4 3 billion,
OPEC bilateral aid (1979-89), $169 mil-
hon, Communist countries (1970-88), $369
million
Currency: Sri Lankan rupee (plural—
rupees), | Sri Lankan rupee (SLRe) = 100
cents
Exchange rates: Sri Lankan rupees (SLRs)
per US$1—40 000 (January 1990), 36 047
(1989), 31 807 (1988), 29 445 (1987),
28 017 (1986), 27 163 (1985)
Fiscal year: calendar year','013f7268fdd2e9991ab6b89dc1ac9a9623b723a75b63b4124f184063f2ed53ae','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8769232d4c58c4e7f4263614e6834e8ce28e962d65b78318013e0382c222cf6d',1990,'SD','Sudan','economy',685,'Overview: Sudan, one of the world’s poor-
est countries, 1s buffeted by civil war,
chronic political instability, adverse
weather, and counterproductive economic
policies The economy 1s dominated by
governmental entities that account for
more than 70% of new investment The
private sector’s main areas of activity are
agriculture and trading, with most private
industrial investment predating 1980 The
economy’s base 1s agriculture, which em-
ploys 80% of the work force Industry
mainly processes agricultural items A
high foreign debt and arrearages of about
$13 billion continue to cause difficulties
Since 1979 the International Monetary
Fund has provided assistance and has
forced Sudan to make economic reforms
aimed at improving the performance of
the economy
GDP: $8 5 billion, per capita $340
(FY87), real growth rate 7 0% (FY89 est )
Inflation rate (consumer prices): 70%
(FY89)
Unemployment rate: NA
Budget: revenues $514 million, expendi-
tures $1 3 billion, including capital expen-
ditures of $183 million (FY89 est )
294
Approved for Release: 2020/08/12 C06554432
Exports: $550 million (fob, FY89 est ),
commoadities—cotton 43%, sesame, gum
arabic, peanuts, partners—Western Eu-
rope 46%, Saudi Arabia 14%, Eastern Eu-
rope 9%, Japan 9%, US 3% (FY88)
Imports: $1 2 billion (cif, FY89 est ),
commoadities—petroleum products, manu-
factured goods, machinery and equipment,
medicines and chemicals, partners—West-
ern Europe 32%, Africa and Asia 15%,
US 13%, Eastern Europe 3% (FY88)
External debt: $11 6 billion (December
1989 est )
Industrial production: growth rate — 1 7%
(FY89 est )
Electricity: 606,000 kW capacity, 900 mil-
lion kWh produced, 37 kWh per capita
(1989)
Industries: cotton ginning, textiles,
cement, edible oils, sugar, soap distilling,
shoes, petroleum refining
Agriculture: accounts for 35% of GNP
and 80% of labor force, untapped poten-
tial for higher farm production, two-thirds
of land area suitable for raising crops and
livestock, major products—cotton,
oilseeds, sorghum, millet, wheat, gum ara-
bic, sheep, marginally self-sufficient in
most foods
Aid: US commitments, including Ex-Im
(FY 70-88), $1 4 billion, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $4 4 billion, OPEC
bilateral aid (1979-89), $3 1 billion, Com-
munist countries (1970-88), $588 million
Currency: Sudanese pound (plural—
pounds), | Sudanese pound (£Sd) = 100
plasters
Exchange rates: official rate—Sudanese
pounds (£Sd) per US$1—4 5004 (fixed
rate since 1987), 2 8121 (1987), 2 5000
(1986), 2 2883 (1985), note—commercial
exchange rate 1s set daily, 12 2 (March
1990)
Fiscal year: 1 July-30 June','34be6f9da829b379b647d3cc18984f86235bf287baa3db4e3def1dbd215c0abe','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d99614b6b1906bfdce2c84f5c7734654aa573a20b8e6aba3f26e627823f60ef2',1990,'GE','Georgia','economy',691,'Overview: The economy 1s dominated by
the bauxite industry, which accounts for
about 80% of export earnings and 40% of
tax revenues The economy has been in
trouble since the Dutch ended develop-
ment aid in 1982 A drop in world bauxite
prices that started in the late 1970s and
continued until late 1986, was followed by
the outbreak of a guerrilla insurgency in
the interior The guerrillas targeted the
economic infrastructure, crippling the 1m-
portant bauxite sector and shutting down
other export industries These problems
have created both high inflation and high
unemployment A small gain in economic
growth of 3 6% was registered in 1988
due to reduced guerrilla activity and im-
proved international markets for bauxite
GDP: $1 27 billion, per capita $3,215, real
growth rate 3 6% (1988 est )
Inflation rate (consumer prices): 50% (1988
est )
Unemployment rate: 27% (1988)
Budget: revenues $466 million, expendi-
tures $716 million, including capital ex-
penditures of $123 million (1989 est )
295
Approved for Release: 2020/08/12 C06554432
Suriname (continued)
Exports: $425 million (fob, 1988 est ),
commodities—alumina, bauxite, alumi-
num, rice, wood and wood products,
shrimp and fish, bananas, partners—Neth-
erlands 28%, US 22%, Norway 18%, Ja-
pan 11%, Brazil 10%, UK 4%
Imports: $365 million (fob, 1988 est ),
commoadities—capital equipment, petro-
leum, foodstuffs, cotton, consumer goods,
partners—US 34%, Netherlands 20%,
Trinidad and Tobago 8%, Brazil 5%, UK
3%
External debt: $65 million (1989 est )
Industrial production: growth rate —3 1%
(1986)
Electricity: 458,000 kW capacity, 2,018
million kWh produced, 5,030 kWh per
capita (1989)
Industries: bauxite mining, alumina and
aluminum production, lumbering, food
processing, fishing
Agriculture: accounts for 11% of both
GDP and labor force, paddy rice planted
on 85% of arable land and represents 60%
of total farm output, other products—ba-
nanas, palm kernels, coconuts, plantains,
peanuts, beef, chicken, shrimp and for-
estry products of increasing importance,
self-sufficient in most foods
Aid: US commitments, including Ex-Im
(FY70-83), $2 5 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 4 billion
Currency: Surinamese guilder, gulden, or
florin (plural—guilders, gulden, or florins),
1 Surinamese guilder, gulden, or florin
(Sf) = 100 cents
Exchange rates: Surinamese guilders, gul-
den, or florins (Sf ) per US$1—-1 7850
(fixed rate)
Fiscal year: calendar year
Overview: Coal mining 1s the major eco-
nomic activity on Svalbard By treaty (9
February 1920), the nationals of the
treaty powers have equal rights to exploit
mineral deposits, subject to Norwegian
regulation Although US, UK, Dutch, and
Swedish coal companies have mined 1n the
past, the only companies still mining are
Norwegian and Soviet Each company
mines about half a million tons of coal
annually The settlements on Svalbard are
essentially company towns The Norwe-
gian state-owned coal company employs
nearly 60% of the Norwegian population
on the island, runs many of the local ser-
vices, and provides most of the local infra-
Structure There 1s also some trapping of
seal, polar bear, fox, and walrus
Electricity: 21,000 kW capacity, 45 mil-
lion kWh produced, 11,420 kWh per cap-
ita (1989)
Currency: Norwegian krone (plural—kro-
ner), | Norwegian krone (NKr) = 100 gre
Approved for Release: 2020/08/12 C06554432
Exchange rates: Norwegian kroner (NKr)
per US$1—6 5405 (January 1990), 6 9045
(1989), 6 5170 (1988), 6 7375 (1987),
7 3947 (1986), 8 5972 (1985)
Overview: The economy 1s based on subsis-
tence agriculture, which occupies much of
the labor force and contributes about 25%
to GDP Manufacturing, which includes a
number of agroprocessing factories, ac-
counts for another 25% of GDP Mining
has declined in importance in recent
years, high-grade iron ore deposits were
depleted in 1978, and health concerns cut
world demand for asbestos Exports of
sugar and forestry products are the main
earners of hard currency Surrounded by
South Africa, except for a short border
with Mozambique, Swaziland 1s heavily
dependent on South Africa, from which it
receives 90% of its imports and to which it
sends about one-third of its exports
GNP: $539 million, per capita $750, real
growth rate 5 7% (1989 est )
Inflation rate (consumer prices): 17% (1989
est )
Unemployment rate: NA%
Budget: revenues $255 million, expendi-
tures $253 million, including capital ex-
penditures of $NA million (FY91 est )
Exports: $394 million (fo b , 1988), com-
modities—sugar, asbestos, wood pulp, cit-
rus, canned fruit, soft drink concentrates,
partners—South Africa, UK, US
Imports: $386 million (fo b , 1988), com-
modities—motor vehicles, machinery,
transport equipment, chemicals, petroleum
products, foodstuffs, partners—South Af-
rica, US, UK
External debt: $275 million (December
1987)
Industrial production: growth rate 24%
(1986)
Electricity: 50,000 kW capacity, 130 mil-
lion kWh produced, 170 kWh per capita
(1989)
Industries: mining (coal and asbestos),
wood pulp, sugar
Agriculture: accounts for 25% of GDP and
over 60% of labor force, mostly subsis-
tence agriculture, cash crops—sugarcane,
citrus fruit, cotton, pineapples, other crops
Approved for Release: 2020/08/12 C06554432
and livestock—corn, sorghum, peanuts,
cattle, goats, sheep, not self-sufficient in
grain
Aid: US commitments, including Ex-Im
(FY70-88), $132 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $468 million
Currency: lilangeni (ptural—emalangen1),
1 lilangeni (E) = 100 cents
Exchange rates: emalangeni (E) per
US$1—2 5555 (January 1990), 2 6166
(1989), 2 2611 (1988), 2 0350 (1987),
2 2685 (1986), 2 1911 (1985), note—the
Swazi emalangeni ts at par with the South
African rand
Fiscal year: 1 April-31 March','99359da1603cdf431490607d082f5ff272fefd21e69f55ef689edd9f03978a1a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3ef554954b44816a6365048014c758ee142e4badeb0c2fbaff81b036ef483b2',1990,'SE','Sweden','economy',697,'Overview: Aided by a long period of peace
and neutrality during World War I
through World War II, Sweden has
achieved an enviable standard of living
under a mixed system of high-tech cap1-
talism and extensive welfare benefits It
has essentially full employment, a modern
distribution system, excellent internal and
external communications, and a skilled
and intelligent labor force Timber, hydro-
power, and iron ore constitute the resource
base of an economy that 1s heavily ori-
ented toward foreign trade Privately
owned firms account for about 90% of in-
dustrial output, of which the engineering
sector accounts for 50% of output and ex-
ports As the 1990s open, however, Swe-
den faces serious economic problems long
waits for adequate housing, the decay of
299
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Sweden (continued)
the work ethic, and a loss of competitive
edge in international markets
GDP: $132 7 billion, per capita $15,700,
real growth rate 2 1% (1989 est )
Inflation rate (consumer prices): 5 7% (Sep-
tember 1989)
Unemployment rate: 1 5% (1989)
Budget: revenues $58 0 billion, expendi-
tures $57 9 billion, including capital ex-
penditures of $NA (FY89)
Exports: $52 2 billion (fob, 1989 est ),
commoaities—machinery, motor vehicles,
paper products, pulp and wood, iron and
steel products, chemicals, petroleum and
petroleum products, partners—EC 52 1%,
(FRG 12 1%, UK 11 2%, Denmark 6 8%),
US 9 8%, Norway 9 3%
Imports: $48 5 billion (cif, 1989 est ),
commodities—machinery, petroleum and
petroleum products, chemicals, motor ve-
hicles, foodstuffs, iron and steel, clothing,
partners—EC 55 8% (FRG 21 2%, UK
8 6%, Denmark 6 6%), US 7 5%, Norway
6 0%
External debt: $17 9 billion (1988)
Industrial production: growth rate 3 3%
(1989)
Electricity: 39,716,000 kW capacity,
200,315 million kWh produced, 23,840
kWh per capita (1989)
Industries: iron and steel, precision equip-
ment (bearings, radio and telephone parts,
armaments), wood pulp and paper prod-
ucts, processed foods, motor vehicles
Agriculture: animal husbandry predomi-
nates, with milk and dairy products ac-
counting for 37% of farm income, main
crops—grains, sugar beets, potatoes, 100%
self-sufficient in grains and potatoes, 85%
self-sufficient in sugar beets
Aid: donor—ODA and OOF commitments
(1970-87), $7 9 billion
Currency: Swedish krona (plural—kronor),
1 Swedish krona (SKr) = 100 ore
Exchange rates: Swedish kronor (SKr) per
US$1—6 1798 (January 1990), 6 4469
(1989), 6 1272 (1988), 6 3404 (1987),
7 1236 (1986), 8 6039 (1985)
Fiscal year: 1 July-30 June','a491fd60d446261291abe694d901a621d2d8613805af22f1de5be457ed85f432','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8388bd12256c338c67bb04b8f7b116c87b0515106825955fefd0ac96d20100d',1990,'CH','Switzerland','economy',701,'Overview: Switzerland’s economic success
1s matched in few, if any, other nations
Per capita output, general living
standards, education and science, health
care, and diet are unsurpassed in Europe
Inflation remains low because of sound
government policy and harmonious labor-
management relations Unemployment 1s
negligible, a marked contrast to the larger
economies of Western Europe This eco-
nomic stability helps promote the impor-
tant banking and tourist sectors Since
World War II, Switzerland’s economy has
adjusted smoothly to the great changes in
output and trade patterns in Europe and
presumably can adjust to the challenges of
the 1990s, in particular, the further eco-
nomic integration of Western Europe and
the amazingly rapid changes in East Eu-
ropean political /economic prospects
GDP: $119 5 billion, per capita $17,800,
real growth rate 3 0% (1989 est )
Inflation rate (consumer prices): 2 8%
(1989 est )
Unemployment rate: 0 5% (1989 est )
Budget: revenues $17 0 billion, expendi-
tures $16 8 billion, including capital ex-
penditures of $NA (1988)
Exports: $51 2 billion (fo b , 1988), com-
modities—machinery and equipment, pre-
cision instruments, metal products, food-
stuffs, textiles and clothing, partners—
Europe 64% (EC 56%, other 8%), US 9%,
Japan 4%
Imports: $57 2 billion (cif, 1988), com-
modities—agricultural products, machin-
ery and transportation equipment, chemi-
cals, textiles, construction materials,
partners—Europe 79% (EC 72%, other
7%), US 5%
External debt: $NA
Industrial production: growth rate 7 0%
(1988)
Electricity: 17,710,000 kW capacity,
$9,070 million kWh produced, 8,930 kWh
per capita (1989)
Industries: machinery, chemicals, watches,
textiles, precision instruments
Agriculture: dairy farming predominates,
less than 50% self-sufficient, food short-
ages—fish, refined sugar, fats and oils
(other than butter), grains, eggs, fruits,
vegetables, meat
Aid: donor—ODA and OOF commitments
(1970-87), $2 5 billion
Currency: Swiss franc, franken, or franco
(plural—francs, franken, or franchi), |
Swiss franc, franken, or franco (SwF) =
100 centimes, rappen, or centesim1
Exchange rates: Swiss francs, franken, or
franc (SwF) per US$1—1 5150 (January
1990), 1 6359 (1989), 1 4633 (1988),
1 4912 (1987), 1 7989 (1986), 2 4571
(1985)
Fiscal year: calendar year
Overview: Syria’s rigidly structured
Ba‘thist economy 1s turning out roughly
the same amount of goods in 1989 as in
1983, when the population was 20%
smaller Economic difficulties are attribut-
able, in part, to severe drought 1n several
recent years, costly but unsuccessful at-
tempts to match Israel’s military strength,
a falloff in Arab aid, and insufficient for-
eign exchange earnings to buy needed 1n-
puts for industry and agriculture Socialist
policy, embodied in a thicket of bureau-
cratic regulations, in many instances has
driven away or pushed underground the
mercantile and entrepreneurial spirit for
which Syrian businessmen have long been
famous Two bright spots a sizable num-
ber of villagers have benefited from land
redistribution, electrification, and other
rural development programs, and a recent
find of light crude oil has enabled Syria to
cut back its substantial imports of light
crude A long-term concern 1s the addi-
tional drain of upstream Euphrates water
by Turkey when its vast dam and irriga-
tion projects are completed toward the
end of the 1990s
GDP: $18 5 billion, per capita $1,540, real
growth rate —2% (1989 est )
Inflation rate (consumer prices): 70% (1989
est )
Unemployment rate: NA%
Budget: revenues $NA, expenditures $3 2
billion, including capital expenditures of
$1 92 billion (1989)
Exports: $1 3 billion (fob, 1988 est ),
commodities—petroleum, textiles, fruits
and vegetables, phosphates, partners—
Italy, Romama, USSR, US, Iran, France
Imports: $1 9 billion (fo b, 1988 est ),
commoaities—petroleum, machinery, base
metals, foodstuffs and beverages, part-
ners—lIran, FRG, USSR, France, GDR,
Libya, US
External debt: $5 3 billion in hard cur-
rency (1989 est )
Industrial production: growth rate NA%
Electricity: 2,867,000 kW capacity, 6,000
million kWh produced, 500 kWh per cap-
ita (1989)
Industries: textiles, food processing, bever-
ages, tobacco, phosphate rock mining, pe-
troleum
Agriculture: accounts for 27% of GDP and
one-third of labor force, all major crops
(wheat, barley, cotton, lentils, chickpeas)
grown on rainfed land causing wide
swings in yields, animal products—beef,
Approved for Release: 2020/08/12 C06554432
lamb, eggs, poultry, milk, not
self-sufficient in grain or livestock prod-
ucts
Aid: US commitments, including Ex-Im
(FY70-81), $538 million, Western (non-
US) ODA and OOF bilateral commit-
ments (1970-87), $1 0 billion, OPEC bilat-
eral aid (1979-89), $12 3 billion,
Communist countries (1970-88), $3 3 bil-
lion
Currency: Syrian pound (plural—pounds),
1 Syrian pound (£S) = 100 piasters
Exchange rates: Syrian pounds (£S) per
US$1—11 2250 (fixed rate since 1987),
3 9250 (fixed rate 1976-87)
Fiscal year: calendar year
Overview: Tanzania 1s one of the poorest
countries in the world The economy 1s
heavily dependent on agriculture, which
accounts for about 40% of GDP, provides
85% of exports, and employs 90% of the
work force Industry accounts for about
10% of GDP and 1s mainly limited to pro-
cessing agricultural products and light
consumer goods The economic recovery
program announced in mid-1986 has gen-
erated notable increases 1n agricultural
production and financial support for the
program by bilateral donors The World
Bank and the International Monetary
Fund have increased the availability of
imports and provided funds to rehabilitate
Tanzania’s deteriorated economic infra-
structure
GDP: $5 92 billion, per capita $235, real
growth rate 4 5% (1989 est )
Inflation rate (consumer prices): 29%
(1989)
Unemployment rate: NA%
Budget: revenues $568 million, expendi-
tures $835 million, including capital ex-
penditures of $230 million (FY89)
Exports: $394 million (fob, FY89), com-
modities—coffee, cotton, sisal, cashew
nuts, meat, tobacco, tea, diamonds, coco-
nut products, pyrethrum, cloves
(Zanzibar), partners—FRG, UK, US,
Netherlands, Japan
Imports: $1 3 billion (c1f, FY89), com-
modities—manufactured goods, machin-
ery and transportation equipment, cotton
piece goods, crude oil, foodstuffs, part-
ners—FRG, UK, US, Iran, Japan, Italy
External debt: $4 5 billion (December
1989 est )
Industrial production: growth rate 6%
(1988 est )
Electricity: 401,000 kW capacity, 895 mil-
lion kWh produced, 35 kWh per capita
(1989)
Industries: primarily agricultural process-
ing (sugar, beer, cigarettes, sisal twine),
diamond mine, oil refinery, shoes, cement,
textiles, wood products, fertilizer
Agriculture: accounts for over 40% of
GDP, topography and climatic conditions
limit cultivated crops to only 5% of land
area, cash crops—coffee, sisal, tea, cotton,
pyrethrum (insecticide made from chry-
santhemums), cashews, tobacco, cloves
(Zanzibar), food crops—corn, wheat, cas-
sava, bananas, fruits, and vegetables,
small numbers of cattle, sheep, and goats,
not self-sufficient in food grain production
Aid: US commitments, including Ex-Im
(FY 70-88), $387 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $8 5 billion,
OPEC bilateral aid (1979-89), $44 million,
Communist countries (1970-88), $607 mil-
lion
Currency: Tanzanian shilling (plural—
shillings), | Tanzanian shilling (TSh) =
100 cents
Exchange rates: Tanzanian shillings (TSh)
per US$1—192 901 (January 1990),
143 377 (1989), 99 292 (1988), 64 260
(1987), 32 698 (1986), 17 472 (1985)
Fiscal year: | July-30 June','af28f57a1367b75b7e88fa56df62a0663bebf3c61af14066805bbf520002b82b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de414cfd5c1013d814edd438b17a245c391cee512a447094dc0790d17d341c98',1990,'TG','Togo','economy',707,'Overview: Togo 1s one of the least devel-
oped countries in the world with a per
capita GDP of about $400 The economy
1s heavily dependent on subsistence agri-
culture, which accounts for about 35% of
GDP and provides employment for 80% of
the labor force Primary agricultural ex-
ports are cocoa, coffee, and cotton, which
together account for about 30% of total
export earnings Togo 1s self-sufficient in
basic foodstuffs when harvests are normal
In the industrial sector phosphate mining
is by far the most important activity, with
phosphate exports accounting for about
40% of total foreign exchange earnings
GDP: $1 35 billion, per capita $405, real
growth rate 4 1% (1988 est )
Inflation rate (consumer prices): 2.5%
(1987 est.)
Unemployment rate: 2 0% (1987)
Budget: revenues $354 million, expendi-
tures $399 million, including capita! ex-
penditures of $102 million (1988 est )
Exports: $344 million (fo b , 1988), com-
modities—phosphates, cocoa, coffee, cot-
ton, manufactures, palm kernels, part-
ners—EC 70%, Africa 9%, US 2%, other
19% (1985)
Imports: $369 million (f ob , 1988), com-
modities—food, fuels, durable consumer
goods, other intermediate goods, capital
goods, partners—EC 69%, Africa 10%,
Japan 7%, US 4%, other 10% (1985)
External debt: $1 3 billion (December
1988)
Approved for Release: 2020/08/12 C06554432
Industrial production: growth rate 4 9%
(1987 est )
Electricity: 117,000 kW capacity, 155 mil-
lion kWh produced, 45 kWh per capita
(1989)
Industries: phosphate mining, agricultural
processing, cement, handicrafts, textiles,
beverages
Agriculture: cash crops—coffee, cocoa,
cotton, food crops—yams, cassava, corn,
beans, rice, millet, sorghum, fish
Aid: US commitments, including Ex-Im
(FY70-88), $121 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $1 6 billion,
OPEC bilateral aid (1979-89), $35 million,
Communist countries (1970-88), $46 mil-
lion
Currency: Communauté Financiére Afri-
caine franc (plural—francs), 1 CFA franc
(CFAF) = 100 centimes
Exchange rates: Communauté Financiére
Africaine francs (CFAF) per US$1—
287 99 (January 1990), 319 01 (1989),
297 85 (1988), 300.54 (1987), 346 30
(1986), 449 26 (1985)
Fiscal year: calendar year','3f2d203dedb1123eae5fc27f83e02a8138b99cb8b97ddb61a6f7a0eb338be3af','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d38303060622816c2df54471c03e370a96f462bc487681b78836347c967855',1990,'TK','Tokelau','economy',712,'Overview: Tokelau’s small size, isolation,
and lack of resources greatly restrain eco-
nomic development and confine agricul-
ture to the subsistence level The people
must rely on aid from New Zealand to
maintain public services, annual aid being
substantially greater than GDP The prin-
cipal sources of revenue come from sales
of copra, postage stamps, souvenir coins,
and handicrafts Money 1s also remitted to
families from relatives in New Zealand.
GDP: $1 4 million, per capita $800; real
growth rate NA% (1988 est )
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget: revenues $430,830, expenditures
$2 8 million, including capital expendi-
tures of $37,300 (FY87)
Approved for Release: 2020/08/12 C06554432
Exports: $98,000 (fob, 1983), commod:-
tles—stamps, copra, handicrafts, part-
ners—NZ
Imports: $323,400 (cif, 1983), commodi-
tres—foodstuffs, building materials, fuel,
partners—NZ
External debt: none
Industrial production: growth rate NA%
Electricity: 200 kW capacity, 0 30 million
kWh produced, 175 kWh per capita
(1989)
Industries: small-scale enterprises for co-
pra production, wood work, plaited craft
goods, stamps, coins, fishing
Agriculture: coconuts, copra, basic subsis-
tence crops—breadfruit, papaya, bananas,
pigs, poultry, goats
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $21 million
Currency: New Zealand dollar (plural—
dollars), 1 New Zealand dollar (NZ$) =
100 cents
Exchange rates: New Zealand dollars
(NZ$) per US$1—1 6581 (January 1990),
1 6708 (1989), 1 5244 (1988), 1 6886
(1987), 1 9088 (1986), 2 0064 (1985)
Fiscal year: 1 April-31 March','ef09a6fe9ab7ed5510fbfc651be0b38aef2f6ebed4c50f82e4745cd700fba839','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd0bfacada82bbb5dd1083282081d22cb4940e5044f88f938954f0ee57a9625b',1990,'TT','Trinidad and Tobago','economy',719,'Overview: Trinidad and Tobago’s
petroleum-based economy has been in de-
cline since 1982 During the first half of
the 1980s, the petroleum sector accounted
for nearly 80% of export earnings, 40% of
government revenues, and almost 25% of
GDP In recent years, however, the econ-
omy has suffered because of the sharp fall
in the price of oil The government, in re-
sponse to the revenue loss, pursued a se-
ries of austerity measures that pushed the
unemployment rate to 22% 1n 1988 Agri-
culture employs only about 11% of the
labor force and produces less than 3% of
GDP Since this sector is small, it has
been unable to absorb the large numbers
of the unemployed The government cur-
rently seeks to diversify its export base
GDP: $3 75 billion, per capita $3,070, real
growth rate —2.0% (1988 est )
Inflation rate (consumer prices): 15 0%
(1989 est )
Unemployment rate: 22% (1988)
Budget: revenues $1.4 billion; expenditures
$2 1 billion, including capital expenditures
of $430 million (1988 est.)
312
Approved for Release: 2020/08/12 C06554432
Exports: $1 4 billion (f ob , 1987), com-
modities—includes reexports—petroleum
and petroleum products 70%, fertilizer,
chemicals 15%, steel products, sugar, co-
coa, coffee, citrus (1987), partners—US
61%, EC 15%, CARICOM 9%, Latin
America 7%, Canada 3% (1986)
Imports: $1 2 billion (cif, 1987), com-
modities—raw materials 41%, capital
goods 30%, consumer goods 29% (1986),
partners—US 42%, EC 21%, Japan 10%,
Canada 6%, Latin America 6%, CARI-
COM 4% (1986)
External debt: $2 02 billion (December
1987)
Industrial production: growth rate 5 2%,
excluding oi! refining (1986)
Electricity: 1,176,000 kW capacity, 3,350
million kWh produced, 2,700 kWh per
capita (1989)
Industries: petroleum, chemicals, tourism,
food processing, cement, beverage, cotton
textiles
Agriculture: accounts for about 3% of
GDP and 4% of labor force, highly subsi-
dized sector, major crops—cocoa and sug-
arcane, sugarcane acreage 1s being shifted
into rice, citrus, coffee, vegetables, must
import large share of food needs
Aid: US commitments, including Ex-Im
(FY70-85), $370 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $437 million
Currency: Trinidad and Tobago dollar
(plural—dollars), 1 Trinidad and Tobago
dollar (TT$) = 100 cents
Exchange rates: Trinidad and Tobago dol-
lars (TT$) per US$1—4 2500 (January
1990), 4 2500 (1989), 3 8438 (1988),
3 6000 (1987), 3 6000 (1986), 2 4500
(1985)
Fiscal year: calendar year
Overview: no economic activity
Approved for Release: 2020/08/12 C06554432','7cbb13b48a56c816ecb815fdc31bf144c357d382e58077f831fe3c799768d373','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cd6d0cf9ac23d71e7754b52f4e5e828e7c02e7efa5f079602b7c14522a5aa6f',1990,'TC','Turks and Caicos Islands','economy',725,'Overview: The economy ts based on
fishing, tourism, and offshore banking
Subsistence farming—corn and beans—
exists only on the Caicos Islands, so that
most foods, as well as nonfood products,
must be imported
GDP: $44 9 million, per capita $5,000,
real growth rate NA% (1986)
Inflation rate (consumer prices): NA%
Unemployment rate: 12% (1989)
Budget: revenues $12 4 million, expendi-
tures $15 8 million, including capital ex-
penditures of $2 6 million (FY87)
Exports: $2 9 million (fo b , FY84), com-
modities—lobster, dried and fresh conch,
conch shells, partners—US, UK
Imports: $26 3 million (cif, FY84), com-
modities—foodstuffs, drink, tobacco,
clothing, partners—US, UK
External debt: SNA
Industrial production: growth rate NA%
Electricity: 9,050 kW capacity, 11 million
kWh produced, 1,160 kWh per capita
(1989)
Industries: fishing, tourism, offshore finan-
cial services
Agriculture: subsistence farming prevails,
based on corn and beans, fishing more 1m-
portant than farming, not self-sufficient in
food
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $92 8 million
Currency: US currency 1s used
Exchange rates: US currency 1s used
Fiscal year: calendar year','b06dc513b4486e12c73a24213b0b5d5a62a505ce41ab2a161a6b56438a06f10b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bc7ccc402696d5ec6761c32608d88dfc0ddc621c2fa4d70427c70ac503f901f',1990,'TV','Tuvalu','economy',730,'Overview: Tuvalu consists of a scattered
group of nine coral atolls with
poor-quality soil The country has a small
economy, no known mineral resources,
and few exports Subsistence farming and
fishing are the primary economic activi-
ties The islands are too small and too re-
mote for development of a tourist indus-
try Government revenues largely come
from the sale of stamps and coins and
worker remittances Substantial income 1s
received annually from an international
trust fund established in 1987 by Austra-
lia, New Zealand, and the UK and sup-
ported also by Japan and South Korea
GNP: $4 6 million, per capita $530, real
growth rate NA% (1989 est )
Inflation rate (consumer prices): 3 9%
(1984)
Approved for Release: 2020/08/12 C06554432
Unemployment rate: NA%
Budget: revenues $2 59 million, expendi-
tures $3 6 million, including capital ex-
penditures of NA (1983 est )
Exports: $1 0 million (fob, 1983 est ),
commodities—copra, partners—Fij1, Aus-
tralia, NZ
Imports: $2 8 million (c1 f, 1983 est ),
commodities—food, animals, mineral fu-
els, machinery, manufactured goods, part-
ners—Fiyi, Australia, NZ
External debt: $NA
Industrial production: growth rate NA
Electricity: 2,600 kW capacity, 3 million
kWh produced, 350 kWh per capita
(1989)
Industries: fishing, tourism, copra
Agriculture: coconuts, copra
Aid: US commitments, including Ex-Im
(FY70-87), $1 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $84 million
Currency: Tuvaluan dollar and Australian
dollar (plural—dollars), 1 Tuvaluan dollar
($T) or 1 Australian dollar ($A) = 100
cents
Exchange rates: Tuvaluan dollars (§T) or
Australian dollars ($A) per US$1—1 2784
(January 1990), 1 2618 (1989), 1 2752
(1988), 1 4267 (1987), 1 4905 (1986),
1 4269 (1985)
Fiscal year: NA
Overview: Uganda has substantial natural
resources, including fertile soils, regular
rainfall, and sizable mineral deposits of
copper and cobalt For most of the past 15
years the economy has been devastated by
political instability, mismanagement, and
civil war, keeping Uganda poor with a per
capita income of about $300 (GDP re-
mains below the levels of the early 1970s,
as does industrial production ) Agriculture
is the most important sector of the econ-
omy, employing over 80% of the work
force Coffee is the major export crop and
accounted for 97% of export revenues in
1988 Since 1986 the government has
acted to rehabilitate and stabilize the
economy by undertaking currency reform,
raising producer prices on export crops,
increasing petroleum prices, and improv-
ing civil service wages The policy changes
are especially aimed at dampening infla-
tion, which was running at over 300% in
1987, and boosting production and export
earnings
GDP: $4 9 billion, per capita $300 (1988),
real growth rate 6 1% (1989 est )
Inflation rate (consumer prices): 72%
(FY89)
Unemployment rate: NA%
Budget: revenues $365 million, expendi-
tures $545 million, including capital ex-
penditures of $165 million (FY89 est )
Exports: $272 million (fob, 1988), com-
modities—coffee 97%, cotton, tea, part-
ners—US 25%, UK 18%, France 11%,
Spain 10%
Imports: $626 million (c1f , 1988), com-
modities—petroleum products, machinery,
cotton piece goods, metals, transportation
equipment, food, partners—Kenya 25%,
UK 14%, Italy 13%
External debt: $1 4 billion (1989 est )
319
Approved for Release: 2020/08/12 C06554432
Uganda (continued)
Industrial production: growth rate 25 1%
(1988)
Electricity: 173,000 kW capacity, 312 mil-
lion kWh produced, 18 kWh per capita
(1989)
Industries: sugar, brewing, tobacco, cotton
textiles, cement
Agriculture: accounts for 57% of GDP and
83% of labor force, cash crops—coffee,
tea, cotton, tobacco, food crops—cassava,
potatoes, corn, millet, pulses, livestock
products—beef, goat meat, milk, poultry,
self-sufficient in food
Aid: US commitments, including Ex-Im
(1970-88), $123 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 0 billion, OPEC
bilateral aid (1979-89), $60 million, Com-
munist countries (1970-88), $140 million
Currency: Ugandan shilling (plural—shil-
lings), 1 Ugandan shilling (USh) = 100
cents
Exchange rates: Ugandan shillings (USh)
per US$1—370 (December 1989), 223 09
(1989), 106 14 (1988), 42 84 (1987), 14.00
(1986), 6 72 (1985)
Fiscal year: 1 July-30 June','e0f692b6ad13cc96801bf832cce7986341225127747298048328366e220dcdd1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79f4d0b0ee9d9b80b30fb77be92f9c8b29015cd01a32961e6725d56d59d2a718',1990,'AE','United Arab Emirates','economy',735,'Overview: The UAE has an open economy
with one of the world’s higher levels of
income per capita This wealth 1s based on
oil and gas, and the fortunes of the econ-
omy fluctuate with the prices of those
commodities Since 1973, when petroleum
prices shot up, the UAE has undergone a
profound transformation from an impover-
ished region of small desert principalities
to a modern state with a high standard of
living At present levels of production,
crude oil reserves should last for over 100
years
GNP: $23 3 billion, per capita $11,680;
real growth rate —2 1% (1988)
Inflation rate (consumer prices): 5-6%
(1988 est )
Unemployment rate: NEGL (1988)
Budget: revenues $3 5 billion, expenditures
$4 0 billion, including capital expenditures
of $NA (1989 est )
Exports: $10 6 billion (fo b, 1988 est ),
commodities—crude oil 75%, natural gas,
reexports, dried fish, dates, partners—US,
EC, Japan
Imports: $8 5 billion (cif , 1988 est ),
commodities—food, consumer and capital
goods, partners—EC, Japan, US
Approved for Release: 2020/08/12 C06554432
External debt: $11 0 billion (December
1989 est )
Industrial production: growth rate —9 3%
(1986)
Electricity: 5,590,000 kW capacity,
15,000 million kWh produced, 7,090 kWh
per capita (1989)
Industries: petroleum, fishing, petrochem-
cals, construction materials, some boat
building, handicrafts, pearling
Agriculture: accounts for 1% of GNP and
5% of labor force, cash crop—dates, food
products—vegetables, watermelons, poul-
try, eggs, dairy, fish, only 25% self-
sufficient in food
Aid: donor—pledged $9 1 billion in bilat-
eral aid to less developed countries (1979-
89)
Currency: Eminian dirham (plural—dir-
hams), 1 Emirian dirham (Dh) = 100 fils
Exchange rates: Emirian dirhams (Dh) per
US$1—3 6710 (fixed rate)
Fiscal year: calendar year','752edd490c2f28c32ad1727269742478d2e388f432f03eecd546e878050af6ab','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a265b2cd9fa2b47fa06cb2d62b8806be5af7c711bc8b2f057d530a5a3203a501',1990,'GB','United Kingdom','economy',740,'Overview: The UK 1s one of the world’s
great trading powers and financial centers,
and its economy ranks among the four
largest in Europe The economy 1s essen-
tially capitalistic with a generous admix-
ture of social welfare programs and gov-
ernment ownership Over the last decade
the Thatcher government has halted the
expansion of welfare measures and has
promoted extensive reprivatization of the
government economic sector Agriculture
1s intensive, highly mechanized, and effi-
cient by European standards, producing
about 60% of food needs with only 1% of
the labor force Industry 1s a mixture of
public and private enterprises, employing
about 24% of the work force and generat-
ing 22% of GDP The UK 1s an energy-
rich nation with large coal, natural gas,
and oil reserves, primary energy produc-
tion accounts for 12% of GDP, one of the
highest shares of any industrial nation
Following the recession of 1979-81, the
economy has enjoyed the longest period of
continuous economic growth it has had
during the last 30 years During the pe-
riod 1982-89 real GDP grew by about
25%, while the inflation rate of 14% was
nearly halved Between 1986 and 1989
unemployment fell from 11% to about 6%
As a major trading nation, the UK will
continue to be greatly affected by world
boom or recession, swings in the interna-
tional oil market, productivity trends in
domestic industry, and the terms on which
the economic integration of Europe pro-
ceeds
GDP: $818 0 billion, per capita $14,300,
real growth rate 2 3% (1989 est )
Inflation rate (consumer prices): 7 8%
(1989)
Unemployment rate: 6 4% (1989)
Budget: revenues $348 7 billion, expendi-
tures $327 8 billion, including capital ex-
penditures of $42 0 billion (FY89)
Exports: $151 0 billion (fo b, 1989), com-
modities—manufactured goods, machin-
ery, fuels, chemicals, semifinished goods,
transport equipment, partners—EC 50 4%
(FRG 11 7%, France 10 2%, Netherlands
6 8%), US 13 0%, Communist countries
23%
Imports: $189 2 billion (cif, 1989), com-
modities—manufactured goods, machin-
ery, semifinished goods, foodstuffs, con-
sumer goods, partners—EC 52 5% (FRG
16 6%, France 8 8%, Netherlands 7 8%),
US 10 2%, Communist countries 2 1%
External debt: $15 7 billion (1988)
Industrial production: growth rate 0 9%
(1989)
Electricity: 98,000,000 kW capacity,
361,990 million kWh produced, 6,350
kWh per capita (1989)
Industries: machinery and transportation
equipment, metals, food processing, paper
and paper products, textiles, chemicals,
clothing, other consumer goods, motor ve-
hicles, aircraft, shipbuilding, petroleum,
coal
Approved for Release: 2020/08/12 C06554432
Agriculture: accounts for only 1 5% of
GNP and 1% of labor force, highly mech-
anized and efficient farms, wide variety of
crops and livestock products produced,
about 60% self-sufficient in food and feed
needs, fish catch of 665,000 metric tons
(1987)
Aid: donor—ODA and OOF commitments
(1970-87), $18 9 billion
Currency: British pound or pound sterling
(plural—pounds), 1 British pound (£) =
100 pence
Exchange rates: British pounds (£) per
US$1—0 6055 (January 1990), 0 6099
(1989) 0 5614 (1988), 0 6102 (1987),
0 6817 (1986), 0 7714 (1985)
Fiscal year: | April-31 March','5b78dbdfd6993d7ecc71f6755e95659eefb9e01611c976f9d4f9e004c6d9f23f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('615e6f3c0f1d02f2b2c54850578d32fb7cc73aa7b2c61f2d6bd321dddfb0826d',1990,'UY','Uruguay','economy',746,'Overview: The economy 1s slowly recover-
ing from the deep recession of 1981-84 In
1986 real GDP grew by 6 6% and in 1987
by 49% The recovery was led by growth
in the agriculture and fishing sectors, agri-
culture alone contributing 20% to GDP,
employing about 11% of the labor force,
and generating a large proportion of ex-
port earnings Rausing livestock, particu-
larly cattle and sheep, 1s the major agri-
cultural activity In 1988, despite healthy
exports and an improved current account,
domestic growth slowed because of gov-
ernment concentration on the external sec-
tor, adverse weather conditions, and pro-
longed strikes High inflation rates of
about 80%, a large domestic debt, and
frequent strikes remain major economic
problems for the government
GDP: $8 8 billion, per capita $2,950, real
growth rate 1% (1989 est )
Inflation rate (consumer prices): 80% (1989
est )
Unemployment rate: 9 0% (1989 est )
Budget: revenues $1 2 billion, expenditures
$1 4 billion, including capital expenditures
of $165 million (1988)
Exports: $1 5 billion (fob, 1989 est ),
commodities—hides and leather goods
17%, beef 10%, wool 9%, fish 7%, rice 4%,
partners—Brazil 17%, US 15%, FRG
10%, Argentina 10% (1987)
Imports: $1 1 billion (fob, 1989 est ),
commodities—fuels and lubricants 15%,
metals, machinery, transportation equip-
ment, industrial chemicals, partners—
Brazil 24%, Argentina 14%, US 8%, FRG
8% (1987)
External debt: $6 billion (1988)
Industrial production: growth rate —2 9%
(1988 est )
Electricity: 1,950,000 kW capacity, 4,330
million kWh produced, 1,450 kWh per
capita (1989)
Industries: meat processing, wool and
hides, sugar, textiles, footwear, leather
apparel, tires, cement, fishing, petroleum
refining, wine
Agriculture: large areas devoted to exten-
sive livestock grazing, wheat, rice, corn,
sorghum, self-sufficient in most basic food-
stuffs
Aid: US commitments, including Ex-Im
(FY 70-88), $105 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $263 million,
Communist countries (1970-88), $69 mil-
hon
Currency: new Uruguayan peso (plural—
pesos), | new Uruguayan peso (N$Ur) =
100 centésimos
Exchange rates: new Uruguayan pesos
(N$Ur) per US$1—832 62 (January
1990), 605 62 (1989), 359 44 (1988),
226 67 (1987), 151 99 (1986), 101 43
(1985)
Fiscal year: calendar year','8671f8168cc88640b71c80e9851eba970a199a9af5686e4cb64cd83edf0a076a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72b9a70a0216713737c7b09ec5ee8d3aa23840f3b8d457030bd14cfad503ae10',1990,'VU','Vanuatu','economy',751,'Overview: The economy ts based primarily
on subsistence farming that provides a
living for about 80% of the population
Fishing and tourism are the other main-
stays of the economy Mineral deposits are
negligible, the country has no known pe-
troleum deposits A small light-industry
sector caters to the local market Tax rev-
enues come mainly from import duties
GDP: $120 million, per capita $820, real
growth rate 0 7% (1987 est )
Inflation rate (consumer prices): 8 0%
(1988 est )
Unemployment rate: NA%
Budget: revenues $80 1 million, expendi-
tures $86 6 million, including capital ex-
penditures of $27 1 million (1988 est )
Exports: $16 million (fo b , 1988 est ),
commodities—copra 37%, cocoa 11%,
meat 9%, fish 8%, timber 4%, partners—
Netherlands 34%, France 27%, Japan
17%, Belgium 4%, New Caledonia 3%,
Singapore 2% (1987)
Imports: $58 million (fob, 1988 est ),
commodities—machines and vehicles
25%, food and beverages 23%, basic man-
ufactures 18%, raw materials and fuels
11%, chemicals 6%, partners—Australia
36%, Japan 13%, NZ 10%, France 8%,
Fiy: 5% (1987)
External debt: $57 million (1988)
Industrial production: growth rate NA%
Electricity: 10,000 kW capacity, 20 mil-
lion kWh produced, 125 kWh per capita
(1989)
Industries: food and fish freezing, forestry
processing, meat canning
Agriculture: export crops—copra, cocoa,
coffee, and fish, subsistence crops—copra,
taro, yams, coconuts, fruits, and vegeta-
bles
Aid: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $541 million
Currency: vatu (plural—vatu), 1 vatu (VT)
= 100 centimes
Exchange rates: vatu (VT) per US$1—
107 17 (January 1990), 116 04 (1989),
104 43 (1988), 109 85 (1987), 106 08
(1986), 106 03 (1985)
Approved for Release: 2020/08/12 C06554432
Fiscal year: calendar year
Overview: The economy is supported fi-
nancially by contributions (known as Pe-
ter’s pence) from Roman Catholics
throughout the world, the sale of postage
stamps, tourist mementos, fees for admis-
sion to museums, and the sale of publica-
tions
Budget: revenues $57 million, expenditures
$113 7 million, including capital expendi-
tures of $NA (1986)
Electricity: 5,000 kW standby capacity
(1989), power supplied by Italy
Approved for Release: 2020/08/12 C06554432
Industries: printing and production of a
small amount of mosaics and staff um-
forms, worldwide banking and financial
activities
Currency: Vatican lira (plural—tire), 1
Vatican hra (VLit) = 100 centesimi
Exchange rates: Vatican lire (VLit) per
US$1—1,262 5S (January 1990), 1,372 1
(1989), 1,301 6 (1988), 1,296 1 (1987),
1,490 8 (1986), 1,909 4 (1985), note—the
Vatican lira 1s at par with the Italian lira
which circulates freely
Fiscal year: calendar year
Overview: Petroleum is the cornerstone of
the economy and accounted for 17% of
GDP, 52% of central government reve-
nues, and 81% of export earnings in 1988
President Pérez introduced an economic
readjustment program when he assumed
office in February 1989 Lower tariffs and
price supports, a free market exchange
rate, and market-linked interest rates have
thrown the economy into confusion, caus-
ing about an 8% decline in GDP
GDP: $52 0 billion, per capita $2,700, real
growth rate —8 1% (1989 est )
Inflation rate (consumer prices): 80 7%
(1989)
Unemployment rate: 7 0% (1988)
Budget: revenues $8 4 billion, expenditures
$8 6 billion, including capital expenditures
of $5 9 billion (1989)
Exports: $10 4 billion (fo b , 1988), com-
modities—petroleum 81%, bauxite and
aluminum, iron ore, agricultural products,
basic manufactures, partners—US 50 3%,
FRG 5 3%, Japan 4 1% (1988)
Imports: $10 9 billion (fo b, 1988), com-
modities—foodstuffs, chemicals, manufac-
tures, machinery and transport equipment,
partners—US 44%, FRG 8 5%, Japan 6%,
Italy 5%, Brazil 4 4% (1987)
External debt: $33 6 billion (1988)
Industrial production: growth rate 3 7%,
excluding oil (1988)
Electricity: 19,110,000 kW capacity,
$4,516 million kWh produced, 2,830 kWh
per capita (1989)
Industries: petroleum, iron-ore mining,
construction materials, food processing,
textiles, steel, aluminum, motor vehicle
assembly
Agriculture: accounts for 6% of GDP and
15% of labor force, products—corn, sor-
ghum, sugarcane, rice, bananas, vegeta-
bles, coffee, beef, pork, milk, eggs, fish,
not self-sufficient in food other than meat
Ilicit drugs: illicit producer of cannabis
and coca for the international drug trade
on a small scale, however, large quantities
of cocaine and mariuana do transit the
country
Aid: US commitments, including Ex-Im
(FY70-86), $488 million, Communist
countries (1970-88), $10 million
Currency: bolivar (plural—bolivares), |
bolivar (Bs) = 100 céntimos
Exchange rates: bolivares (Bs) per US$1—
43 42 (January 1990), 34 6815 (1989),
14 5000 (fixed rate 1987-88), 8 0833
(1986), 7 5000 (1985)
Fiscal year: calendar year','faca07a1ce01e3ede17211db2ed39dcca34b1c37ce9a9b519b6ae2179a4f25a4','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0437bda528eea013e8e1911d384fbf9ddb038067850551ce6c5ff0fb386b18ba',1990,'US','United States','economy',753,'Overview: Tourism 1s the primary
economic activity, accounting for more
than 70% of GDP and 70% of employ-
ment The manufacturing sector consists
of textile, electronics, pharmaceutical, and
watch assembly plants The agricultural
sector is small with most food imported
International business and financial ser-
vices are a small but growing component
of the economy The world’s largest petro-
leum refinery 1s at St Croix
GDP: $1 03 billion, per capita $9,030, real
growth rate NA% (1985)
Inflation rate (consumer prices): NA%
Unemployment rate: 3 5% (1987)
Budget: revenues $315 million, expendi-
tures $322 million, including capital ex-
penditures of NA (FY88)
Exports: $3 4 billion (fo b , 1985), com-
modities—refined petroleum products,
partners—US, Puerto Rico
Imports: $3 7 billion (cif, 1985), com-
modities—crude oil, foodstuffs, consumer
goods, building materials, partners—US,','70618c7fab79925a77e425cc3ffd0a0a1101e4280975c1db699b08da5aa1af56','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f08fb3a2af3af868d9cd125ad18724fc635cef5acc1ac64f8be8a236eb26f584',1990,'IL','Israel','economy',755,'Imports: $410 million (cif, 1988 est ),
commodities—NA, partners—Jordan,
External debt: $NA
Industrial production: growth rate NA%
Electricity: power supplied by Israel
Industries: generally small family busi-
nesses that produce cement, textiles, soap,
olive-wood carvings, and mother-of-pearl
souvenirs, the Israelis have established
some small-scale modern industries in the
settlements and industrial centers
Agriculture: olives, citrus and other fruits,
vegetables, beef, and dairy products
Aid: none
Currency: new Israeli shekel (plural—
shekels) and Jordaman dinar (plural—
dinars), | new Israeli shekel (NIS) = 100
new agorot and | Jordanian dinar (JD) =
1,000 fils
Exchange rates: new Israeli shekels (NIS)
per US$1—1 9450 (January 1990), 1 9164
(1989), 1 5992 (1988), 1 5946 (1987),
1 4878 (1986), 1 1788 (1985), Jordanian
dinars (JD) per US$1—0 6557 (January
1990), 0 5704 (1989), 0 3715 (1988),
0 3387 (1987), 0 3499 (1986), 0 3940
(1985)
Fiscal year: 1 April-31 March
Approved for Release: 2020/08/12 C06554432','3a676d40dbb5183f78f40a4d3617dcc2d5351c93c587f21366558ba246ed75ef','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aa963919059063973fe1355831cc825e20a93d18ff763d57011627de058101f',1990,'EH','Western Sahara','economy',761,'Overview: Western Sahara, a territory
poor in natural resources and having little
rainfall, has a per capita GDP of just a
few hundred dollars Fishing and phos-
phate mining are the principal industries
and sources of income Most of the food
for the urban population must be
imported All trade and other economic
activities are controlled by the Moroccan
Overview: Agriculture employs two-thirds
of the labor force, contributes 50% to
GDP, and 1s the source of 90% of exports
The bulk of export earnings comes from
the sale of coconut oil and copra The
economy depends on emigrant remittances
and foreign aid to support a level of 1m-
ports about five times export earnings
Tourism has become the most important
growth industry, and construction of the
first international hotel 1s under way
GDP: $112 million, per capita $615, real
growth rate 0 2% (1989 est )
Inflation rate (consumer prices): 8 5%
(1988)
Unemployment rate: NA%, shortage of
skilled labor
Budget: revenues $54 million, expenditures
$54 million, including capital expenditures
of $28 million (1988)
Exports: $9 9 million (fob, 1988), com-
modities—coconut otl and cream 42%,
taro 19%, cocoa 14%, copra, timber, part-
ners—NZ 30%, EC 24%, Australia 21%,
American Samoa 7%, US 9% (1987)
Imports: $51 8 million (cif , 1988), com-
modities—intermediate goods 58%, food
17%, capital goods 12%, partners—New
Zealand 31%, Australia 20%, Japan 15%,
Fiji 15%, US 5%, EC 4% (1987)
External debt: $75 million (December
1988 est )
Industrial production: growth rate —4 0%
(1987)
Electricity: 23,000 kW capacity, 35 mil-
lion kWh produced, 190 kWh per capita
(1989)
Industries: timber, tourism, food process-
ing, fishing
Agriculture: coconuts, fruit (including ba-
nanas, taro, yams)
Aid: US commitments, including Ex-Im
(FY70-88), $16 million, Western (non-US)
countries, ODA and OOF bilateral com-
Approved for Release: 2020/08/12 C06554432
mitments (1970-87), $261 million, OPEC
bilateral aid (1979-89), $4 million
Currency: tala (plural—tala), 1 tala (WS$)
= 100 sene
Exchange rates: tala (WS$) per US$1—
2 2857 (January 1990), 2 2686 (1989),
2 0790 (1988), 2 1204 (1987), 2 2351
(1986), 2 2437 (1985)
Fiscal year: calendar year
Overview: In 1989 the World economy
grew at an estimated 3 0%, somewhat
lower than the estimated 3 4% for 1988
The technologically advanced areas—
North America, Japan, and Western Eu-
rope—together account for 65% of the
gross world product (GWP) of $20 3 tril-
lion, these developed areas grew in the
aggregate at 35% In contrast, the Com-
munist (Second World) countries typically
grew at between 0% and 2%, accounting
for 23% of GWP Experience in the devel-
oping countries continued mixed, with the
newly industrializing countries generally
maintaining their rapid growth, and many
others struggling with debt, inflation, and
inadequate investment The year 1989
ended with remarkable political upheavals
in the Communist countries, which pre-
sumably will dislocate economic produc-
tion still further The addition of nearly
100 million people a year to an already
overcrowded globe will exacerbate the
problems of pollution, desertification, un-
deremployment, and poverty throughout
the 1990s
Approved for Release: 2020/08/12 C06554432
GWP (gross world product): $20 3 trillion,
per capita $3,870, real growth rate 3 0%
(1989 est )
Inflation rate (consumer prices): 5%, devel-
oped countries, 100%, developing countries
with wide variations (1989 est )
Unemployment rate: NA%
Exports: $2,694 billion (fo b , 1988), com-
modities—NA, partners—ain value, about
70% of exports from industrial countries
Imports: $2,750 billion (c1f , 1988), com-
modities—NA, partners—in value, about
75% of imports by the industrial countries
External debt: $1,008 billion for less de-
veloped countries (1988 est )
Industrial production: growth rate 5%
(1989 est )
Electricity: 2,838,680,000 kW capacity,
11,222,029 million kWh produced, 2,140
kWh per capita (1989)
Industries: chemicals, energy, machinery,
electronics, metals, mining, textiles, food
processing
Agriculture: cereals (wheat, maize, rice),
sugar, lrvestock products, tropical crops,
fruit, vegetables, fish
Aid: NA
Overview: The low level of domestic indus-
try and agriculture make North Yemen
dependent on imports for virtually all of
its essential needs Large trade deficits are
made up for by remittances from Yemenis
working abroad and foreign aid Once
self-sufficient in food production, the YAR
1s now a major importer Land once used
for export crops—cotton, fruit, and vege-
tables—has been turned over to growing
qat, a mildly narcotic shrub chewed by
Yemenis that has no significant export
market Oil export revenues started
flowing in late 1987 and boosted 1988
earnings by about $800 million
GDP: $5 5 billion, per capita $820, real
growth rate 19 7% (1988 est )
Inflation rate (consumer prices): 16 9%
(1988)
Unemployment rate: 13% (1986)
Budget: revenues $1 32 billion, expendi-
tures $2 18 billion, including capital ex-
penditures of $588 million (1988 est )
Exports: $853 million (fob, 1988), com-
modities—crude oil, cotton, coffee, hides,
vegetables, partners—US 41%, PDRY
14%, Japan 12%
Imports: $1 3 billion (fob, 1988), com-
modities—textiles and other manufac-
tured consumer goods, petroleum prod-
ucts, sugar, grain, flour, other foodstuffs,
341
Approved for Release: 2020/08/12 C06554432
Yemen Arab Republic (continued)
and cement, partners—lItaly 10%, Saudi
Arabia 9%, US 9 3%, Japan 9%, UK 8%
Defense Forces
(1985) Branches: Army, Navy, Air Force, Police
External debt: $3 5 billion (December Military manpower: males 15-49,
1989 est ) 1,289,217, 734,403 fit for military service,
Industrial production: growth rate 2% in
manufacturing (1988)
Electricity: 415,000 kW capacity, 500 mil-
lion kWh produced, 70 kWh per capita
(1989)
Industries: crude o1] production, small-
scale production of cotton textiles and
leather goods, food processing, handi-
crafts, fishing, small aluminum products
factory, cement
Agriculture: accounts for 50% of GDP and
70% of labor force, farm products—grain,
fruits, vegetables, qat (mildly narcotic
shrub), coffee, cotton, dairy, poultry, meat,
goat meat, not self-sufficient in grain
Aid: US commitments, including Ex-Im
(1970-88), $354 million, Western (non-US)
countries, ODA and OOF bilateral com-
mitments (1970-87), $1 4 billion, OPEC
bilateral aid (1979-89), $2 9 billion, Com-
munist countries (1970-88), $248 million
Currency: Yemeni riyal (plural—riyals), 1
Yemeni riyal (YR) = 100 fils
Exchange rates: Yemeni riyals (YR) per
US$1—9 7600 (January 1990), 9 7600
(1989), 9 7717 (1988), 10 3417 (1987),
9 6392 (1986), 7 3633 (1985)
Fiscal year: calendar year
79,609 reach military age (18) annually
Defense expenditures: $358 million (1987)
Overview: The PDRY 1s one of the poorest
Arab countries, with a per capita GNP of
about $500 A shortage of natural
resources, a widely dispersed population,
and an arid climate make economic devel-
opment difficult The economy has grown
at an average annual rate of only 2-3%
since the mid-1970s The economy 1s or-
ganized along socialist lines, dominated by
the public sector Economic growth has
been constrained by a lack of incentives,
partly stemming from centralized control
over production decisions, investment allo-
cation, and import choices
GNP: $1 2 billion, per capita $495, real
growth rate 5 2% (1988 est )
Inflation rate (consumer prices): 2 8%
(1987)
Unemployment rate: NA%
Budget: revenues $429 million, expendi-
tures $976 million, including capital ex-
penditures of $402 million (1988 est )
Exports: $82 2 million (fob, 1988 est ),
commodities—cotton, hides, skins, dried
and salted fish, partners—Japan, YAR,','4e1d2491f3756dfee176c0c6f4df85de064bec9ac636ce61e7bdda84005df034','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('016d83a200f3a4ffd7a31445c0d5cc6cb86768ba14c686493ee079766793e651',1990,'ZM','Zambia','economy',766,'Overview: Despite temporary growth in
1988, the economy has been in decline for
more than a decade with falling imports
and growing foreign debt Economic diffi-
culties stem from a sustained drop in cop-
per production and ineffective economic
polictes In 1988 real GDP stood only
shghtly higher than that of 10 years be-
fore, while an annual population growth of
more than 3% has brought a decline in
per capita GDP of 25% during the same
period A high inflation rate has also
added to Zambia’s economic woes in re-
cent years
GDP: $4 0 billion, per capita $530, real
growth rate 6 7% (1988)
Inflation rate (consumer prices): 55 7%
(1988)
Unemployment rate: NA%
Budget: revenues $570 million, expendi-
tures $939 million, including capital ex-
penditures of $36 million (1988 est )
Exports: $1,184 million (fob, 1988),
commodities—copper, zinc, cobalt, lead,
tobacco, partners—EC, Japan, South Af-
rica, US
Imports: $687 million (cif, 1988), com-
modities—machinery, transportation
equipment, foodstuffs, fuels,
manufactures, partners—EC, Japan,
South Africa, US
External debt: $6 9 billion (December
1989)
Industrial production: growth rate NA%
(1986)
Electricity: 1,900,000 kW capacity, 8,245
milion kWh produced, 1,050 kWh per
capita (1989)
Industries: copper mining and processing,
transport, construction, foodstuffs, bever-
ages, chemicals, textiles, and fertilizer
Agriculture: accounts for 15% of GDP and
85% of labor force, crops—corn (food sta-
ple), sorghum, rice, peanuts, sunflower,
Approved for Release: 2020/08/12 C06554432
tobacco, cotton, sugarcane, cassava, cattle
goats, beef, eggs produced, marginally
self-sufficient in corn
Aid: US commitments, including Ex-Im
(1970-88), $466 million, Western (non-US
countries, ODA and OOF bilateral com-
mitments (1970-87), $4 2 billion, OPEC
bilateral aid (1979-89), $60 million, Com
munist countries (1970-88), $533 million
Currency: Zambian kwacha (plural—kwa
cha), 1 Zambian kwacha (ZK) = 100 ng-
wee
Exchange rates: Zambian kwacha (ZK)
per US$1—21 7865 (January 1990),
12 9032 (1989), 8 2237 (1988), 8 8889
(1987), 7 3046 (1986), 2 7137 (1985)
Fiscal year: calendar year','c50438d6c4a43ac0a76a5cd8ab0a71e05aa1685418cabfa633c9dc00e29aae06','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd79f710952526cc9d853f4e5a5faa5e4f36b43e6780f4a9d4598055cc36da06',1990,'ZW','Zimbabwe','economy',772,'Overview: Agriculture employs a majority
of the labor force and supplies almost 40%
of exports The agro-based manufacturing
sector produces a variety of goods and
contributes about 25% to GDP Mining
accounts for only 5% of both GDP and
employment, but supplies of minerals and
metals account for about 40% of exports
Wide year-to-year fluctuations in agricul-
tural production over the past six years
resulted in not only an uneven growth
rate, but one that did not equal the 3%
annual increase 1n population
GDP: $4 6 billion, per capita $470, real
growth rate 5 3% (1988 est )
Inflation rate (consumer prices): 7 4%
(1988)
Unemployment rate: at least 20% (1988
est )
Budget: revenues $2 4 billion, expenditures
$3 0 billion, including capital expenditures
of $290 million (FY90)
Exports: $1 6 billion (fo b , 1988), com-
modities—agricultural 34% (tobacco 21%,
other 13%), manufactures 19%, gold 11%,
ferrochrome 11%, cotton 6%, partners—
Europe 55% (EC 41%, Netherlands 6%,
other 8%), Africa 22% (South Africa 12%,
other 10%), US 6%
Imports: $1 1 billion (cif , 1988), com-
modities—machinery and transportation
equipment 37%, other manufactures 22%,
chemicals 16%, fuels 15%, partners—EC
31%, Africa 29% (South Africa 21%,
other 8%), US 8%, Japan 4%
External] debt: $2 96 billion (December
1989 est )
Industrial production: growth rate 4 7%
(1988 est )
Electricity: 2,036,000 kW capacity, 5,460
million kWh produced, 540 kWh per cap-
ita (1989)
349
Approved for Release: 2020/08/12 C06554432
Zimbabwe (continued)
Industries: mining, steel, clothing and
footwear, chemicals, foodstuffs, fertilizer,
beverage, transportation equipment, wood
products
Agriculture: accounts for about 15% of
GDP and employs over 70% of population,
40% of land area divided into 6,000 large
commercial farms and 42% in communal
lands, crops—corn (food staple), cotton,
tobacco, wheat, coffee, sugarcane, pea-
nuts, livestock—cattle, sheep, goats, pigs,
self-sufficient in food
Aid: US commitments, including Ex-Im
(FY80-88), $359 million, Western (non-
US) countries, ODA and OOF bilateral
commitments (1970-87), $2 0 billion,
OPEC bilateral aid (1979-89), $36 million,
Communist countries (1970-88), $134 mil-
hon
Currency: Zimbabwean dollar (plural—
dollars), 1 Zimbabwean dollar (Z$) = 100
cents
Exchange rates: Zimbabwean dollars (Z$)
per US$1—2 2873 (January 1990), 2 1133
(1989), 1 8018 (1988), 1 6611 (1987),
1 6650 (1986), 1 6119 (1985)
Fiscal year: 1 July-30 June
Overview: Taiwan has a dynamic capitalist
economy with considerable government
guidance of investment and foreign trade
and partial government ownership of some
large banks and industrial firms Real
growth in GNP has averaged about 9% a
year during the past three decades Export
growth has been even faster and has pro-
vided the impetus for industrialization
Agriculture contributes about 6% to GNP,
down from 35% 1n 1952 Taiwan currently
Approved for Release: 2020/08/12 C06554432
ranks as number 13 among major trading
countries Traditional labor-intensive in-
dustries are steadily being replaced with
more capital- and technology-intensive
industries
GNP: $121 4 billion, per capita $6,000,
real growth rate 7 2% (1989)
Inflation rate (consumer prices): 5 0%
(1989)
Unemployment rate: 1 7% (1989)
Budget: revenues $25 9 billion, expendi-
tures $33 2 billion, including capital ex-
penditures of $NA (FY89)
Exports: $66 2 billion (fob, 1989), com-
modities—textiles 9 7%, electrical ma-
chinery 19 0%, general machinery and
equipment 14%, telecommunications
equipment 9%, basic metals and metal
products 7 4%, foodstuffs 0 9%, plywood
and wood products | 3%, partners—US
36 2%, Japan 13 7%
Imports: $52 2 billion (cif , 1989), com-
modities—machinery and equipment
15 9%, crude oil 5%, chemical and chemi-
cal products 11 1%, basic metals 7 4%,
foodstuffs 2 0%, partners—Japan 31%, US
23%, Saudi Arabia 8 6%
External debt: $1 0 billion (December
1989 est )
Industrial production: growth rate 4 1%
(1988)
Electricity: 17,000,000 kW capacity,
68,000 million kWh produced, 3,360 kWh
per capita (1989)
Industries: textiles, clothing, chemicals,
electronics, food processing, plywood,
sugar milling, cement, shipbuilding, petro-
leum
Agriculture: accounts for 6% of GNP and
20% of labor force (includes part-time
farmers), heavily subsidized sector, major
crops—trice, sugarcane, sweet potatoes,
fruits, vegetables, livestock—hogs, poultry,
beef, milk, cattle, not self-sufficient in
wheat, soybeans, corn, fish catch expand-
ing, 1 1 million metric tons 1n (1987)
Aid: US, including Ex-Im (FY 46-82), $4 6
billion, Western (non-US) countries, ODA
and OOF bilateral commitments (1970-
87), $439 million
Currency: new Taiwan dollar (plural—
dollars), | new Taiwan dollar (NT$) =
100 cents
Exchange rates: new Taiwan dollars per
US$1—26 3 (March 1990), 26 156 (De-
cember 1989), 28 589 (1988), 31 845
(1987), 37 838 (1986), 39 849 (1985)
Fiscal year: 1 July-30 June','024988fdc1c52ed91fbd7e75d44b4868f3931d84ff4b6832fe40b22e1e85139c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

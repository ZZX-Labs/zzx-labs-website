SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('565252e9a8cb7ab526c48588555b5cad0d99738248c715f663c87308db0c50ed',1990,'AO','Angola','introduction',11,'Current issues: Civil war has been the norm since independence from
Portugal on 11 November 1975. A cease-fire between the government and
(UNITA) lasted from 31 May 1991 until October 1992 when UNITA refused
to accept its defeat in internationally monitored elections and
fighting resumed throughout much of the country. The two sides signed
another peace accord on 20 November 1994 and the cease-fire is
generally holding, but military tensions and banditry persist. The
peace accord provided for the integration of former UNITA insurgents
into the Angolan armed forces and the government. A Government of
National Unity and Reconciliation was installed in April 1997 and
military integration was declared complete in June 1997, although
UNITA filled fewer than half of the military positions allocated to
the rebels. Efforts which began in May 1997 to extend government into
UNITA-occupied areas are proceeding slowly. The original 7,200-man UN
peacekeeping force began a phased drawdown in late 1996 and all UN
military components are scheduled to depart by 30 June 1998 except for
through 1998.
@Angola:Geography
Location: Southern Africa, bordering the South Atlantic Ocean, between
Namibia and Democratic Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area-comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo 2,511 km of which
220 km is the boundary of discontiguous Cabinda Province, Republic of
the Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 20 nm
Climate: semiarid in south and along coast to Luanda; north has cool,
dry season (May to October) and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore, phosphates, copper,
feldspar, gold, bauxite, uranium
Land use:
arable land: 2%
permanent crops: 0%
permanent pastures: 23%
forests and woodland: 43%
other: 32% (1993 est.)
Irrigated land: 750 sq km (1993 est.)
Natural hazards: locally heavy rainfall causes periodic flooding on
the plateau
Environment-current issues: the overuse of pastures and subsequent
soil erosion attributable to population pressures; desertification;
deforestation of tropical rain forest, in response to both
international demand for tropical timber and to domestic use as fuel,
resulting in loss of biodiversity; soil erosion contributing to water
pollution and siltation of rivers and dams; inadequate supplies of
potable water
Environment-international agreements:
party to: Biodiversity, Desertification, Law of the Sea
signed, but not ratified: Climate Change
Geography-note: Cabinda is separated from rest of country by the
Democratic Republic of the Congo
@Angola:People
Population: 10,864,512 (July 1998 est.)
Age structure:
0-14 years: 45% (male 2,471,108; female 2,401,631)
15-64 years: 52% (male 2,864,152; female 2,831,209)
65 years and over: 3% (male 137,432; female 158,980) (July 1998 est.)
Population growth rate: 2.84% (1998 est.)
Birth rate: 43.58 births/1,000 population (1998 est.)
Death rate: 16.79 deaths/1,000 population (1998 est.)
Net migration rate: 1.65 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.86 male(s)/female (1998 est.)
Infant mortality rate: 132.44 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 47.86 years
male: 45.6 years
female: 50.23 years (1998 est.)
Total fertility rate: 6.2 children born/woman (1998 est.)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%, mestico
(mixed European and Native African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic 38%, Protestant 15%
(1998 est.)
Languages: Portuguese (official), Bantu and other African languages
Literacy:
definition: age 15 and over can read and write
total population: 42%
male: 56%
female: 28% (1998 est.)
@Angola:Government
Country name:
conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former: People''s Republic of Angola
Data code: AO
Government type: transitional government, nominally a multiparty
democracy with a strong presidential system
National capital: Luanda
Administrative divisions: 18 provinces (provincias,
singular-provincia); Bengo, Benguela, Bie, Cabinda, Cuando Cubango,
Cuanza Norte, Cuanza Sul, Cunene, Huambo, Huila, Luanda, Lunda Norte,
Lunda Sul, Malanje, Moxico, Namibe, Uige, Zaire
Independence: 11 November 1975 (from Portugal)
National holiday: Independence Day, 11 November (1975)
Constitution: 11 November 1975; revised 7 January 1978, 11 August
1980, 6 March 1991, and 26 August 1992
Legal system: based on Portuguese civil law system and customary law;
recently modified to accommodate political pluralism and increased use
of free markets
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Jose Eduardo DOS SANTOS (since 21 September
1979)
head of government: Prime Minister Fernando Franca VAN DUNEM (since 8
June 1996)
cabinet: Council of Ministers appointed by the president
elections: President DOS SANTOS originally elected without opposition
under a one-party system and stood for reelection in Angola''s first
multiparty elections in 28-29 September 1992, the last elections to be
held, (next to be held NA); prime minister appointed by the president
and answerable to the Assembly
election results: DOS SANTOS received 49.6% of the total vote, making
a run-off election necessary between him and second-place finisher
Jonas SAVIMBI; the run-off was not held and SAVIMBI''s National Union
for the Total Independence of Angola (UNITA) repudiated the results of
the first election; the civil war was resumed
Legislative branch: unicameral National Assembly or Assembleia
Nacional (220 seats; members elected by proportional vote to serve
four-year terms)
elections: last held 29-30 September 1992 (next to be held NA)
election results: percent of vote by party-MPLA 54%, UNITA 34%, others
12%; seats by party-NA
Judicial branch: Supreme Court or Tribunal da Relacao, judges of the
Supreme Court are appointed by the president
Political parties and leaders: Popular Movement for the Liberation of
Angola or MPLA [Jose Eduardo DOS SANTOS], is the ruling party and has
been in power since 1975; National Union for the Total Independence of
Angola or UNITA [Jonas SAVIMBI], is the largest opposition party and
engaged in years of armed resistance before joining the current unity
government in April 1997
note: about a dozen minor parties participated in the 1992 elections
but won few seats and have little influence in the National Assembly
Political pressure groups and leaders: Front for the Liberation of the
Enclave of Cabinda or FLEC
note: FLEC is waging a small-scale, highly factionalized, armed
struggle for the independence of Cabinda Province
International organization participation: ACP, AfDB, CCC, CEEAC
(observer), ECA, FAO, G-77, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS,
ILO, IMF, IMO, Intelsat, Interpol, IOC, IOM, ITU, NAM, OAS (observer),
OAU, SADC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WFTU, WHO, WIPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Antonio dos Santos FRANCA "N''dalu"
chancery: 1050 Connecticut Avenue, NW, Suite 760, Washington, DC 20036
telephone: [1] (202) 785-1156
FAX: [1] (202) 785-1258
Diplomatic representation from the US:
chief of mission: Ambassador Donald K. STEINBERG
embassy: No. 32 Rua Houari Boumedienne, Miramar, Luanda
mailing address: International mail: Caixa Postal 6484, Luanda; Pouch:
American Embassy Luanda, Department of State, Washington, DC
20521-2550
telephone: [244] (2) 345-481, 346-418
FAX: [244] (2) 346-924
Flag description: two equal horizontal bands of red (top) and black
with a centered yellow emblem consisting of a five-pointed star within
half a cogwheel crossed by a machete (in the style of a hammer and
sickle)
@Angola:Economy
Economy-overview: Angola is an economy in disarray because of more
than 20 years of nearly continuous warfare. Despite its abundant
natural resources, output per capita is among the world''s lowest.
Subsistence agriculture provides the main livelihood for 85% of the
population. Oil production and the supporting activities are vital to
the economy, contributing about 50% to GDP. Notwithstanding the
signing of a peace accord in November 1994, sporadic violence
continues, millions of land mines remain, and many farmers are
reluctant to return to their fields. As a result, much of the
country''s food must still be imported. To take advantage of its rich
resources-gold, diamonds, extensive forests, Atlantic fisheries,
arable land, and large oil deposits-Angola will need to implement the
peace agreement and reform government policies. Despite the high
inflation and political difficulties, total output grew an estimated
9% in 1996, largely due to increased oil production and higher oil
prices.
GDP: purchasing power parity-$8.2 billion (1996 est.)
GDP-real growth rate: 9% (1996 est.)
GDP-per capita: purchasing power parity-$800 (1996 est.)
GDP-composition by sector:
agriculture: 12%
industry: 56%
services: 32% (1994 est.)
Inflation rate-consumer price index: 92% (mid-1997 est.)
Labor force:
total: 2.783 million economically active
by occupation: agriculture 85%, industry and services 15% (1997 est.)
Unemployment rate: extensive unemployment and underemployment
affecting more than half the population (1997 est.)
Budget:
revenues: $928 million
expenditures: $2.5 billion, including capital expenditures of $963
million (1992 est.)
Industries: petroleum; diamonds, iron ore, phosphates, feldspar,
bauxite, uranium, and gold; cement; basic metal products; fish
processing; food processing; brewing; tobacco products; sugar;
textiles
Industrial production growth rate: NA%
Electricity-capacity: 617,000 kW (1995)
Electricity-production: 18.62 billion kWh (1995)
Electricity-consumption per capita: 185 kWh (1995)
Agriculture-products: bananas, sugarcane, coffee, sisal, corn, cotton,
manioc (tapioca), tobacco, vegetables, plantains; livestock; forest
products; fish
Exports:
total value: $4 billion (f.o.b., 1996 est.)
commodities: crude oil 90%, diamonds, refined petroleum products, gas,
coffee, sisal, fish and fish products, timber, cotton
partners: US 70%, EU
Imports:
total value: $1.7 billion (f.o.b., 1995 est.)
commodities: capital equipment (machinery and electrical equipment),
vehicles and spare parts; medicines, food, textiles and clothing;
substantial military supplies
partners: Portugal, Brazil, US, France, Spain
Debt-external: $12.5 billion (1996 est.)
Economic aid:
recipient: ODA, $451 million (1994)
Currency: 1 kwanza (NKz) = 100 lwei
Exchange rates: kwanza (NKz) per US$1-265,000 (August 1997), 201,994
(November 1996)
note: the exchange rate is set by the National Bank of Angola (BNA);
adjusted by BNA on 19 July 1997 at 265,000 kwanzas per US$1; black
market rate was then 360,000 kwanzas per US$1
Fiscal year: calendar year','9ca34178e12494f78e581119ca3a201ed17b002c272db456047c6dd473f98a10','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86a98a5fec55b0811077906c40613eb24c8ffa928705104286b6fd66ea85e6c9',1990,'AM','Armenia','introduction',17,'Current issues: Armenia''s leaders remain preoccupied by Armenia''s
10-year conflict with Azerbaijan over the Nagorno-Karabakh enclave.
Although a cease-fire has been in effect since May 1994, the sides
have not made substantial progress toward a peaceful resolution. In
January 1998, differences between President TER-PETROSSIAN and members
of his cabinet over the Nagorno-Karabakh peace process came to a head.
With the prime minister and defense and security ministers arrayed
against him, an isolated TER-PETROSSIAN resigned the presidency on 3
February 1998. Robert KOCHARIAN, TER-PETROSSIAN''s prime minister, was
elected president in March 1998. Concerns about Armenia''s economic
performance rose in 1997 with a slowdown in growth and an increase in
inflation.
@Armenia:Geography
Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Commonwealth of Independent States
Area:
total: 29,800 sq km
land: 28,400 sq km
water: 1,400 sq km
Area-comparative: slightly smaller than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566 km, Azerbaijan-Naxcivan
exclave 221 km, Georgia 164 km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold winters
Terrain: high Armenian Plateau with mountains; little forest land;
fast flowing rivers; good soil in Aras River valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerr 4,095 m
Natural resources: small deposits of gold, copper, molybdenum, zinc,
alumina
Land use:
arable land: 17%
permanent crops: 3%
permanent pastures: 24%
forests and woodland: 15%
other: 41% (1993 est.)
Irrigated land: 2,870 sq km (1993 est.)
Natural hazards: occasionally severe earthquakes; droughts
Environment-current issues: soil pollution from toxic chemicals such
as DDT; energy blockade, the result of conflict with Azerbaijan, has
led to deforestation when citizens scavenged for firewood; pollution
of Hrazdan (Razdan) and Aras Rivers; the draining of Sevana Lich (Lake
Sevan), a result of its use as a source for hydropower, threatens
drinking water supplies; restart of Metsamor nuclear power plant
without adequate (IAEA-recommended) safety and backup systems
Environment-international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Nuclear Test Ban, Wetlands
signed, but not ratified: none of the selected agreements
Geography-note: landlocked
@Armenia:People
Population: 3,421,775 (July 1998 est.)
Age structure:
0-14 years: 26% (male 460,191; female 441,906)
15-64 years: 65% (male 1,092,652; female 1,139,916)
65 years and over: 9% (male 119,464; female 167,646) (July 1998 est.)
Population growth rate: -0.36% (1998 est.)
Birth rate: 13.52 births/1,000 population (1998 est.)
Death rate: 8.82 deaths/1,000 population (1998 est.)
Net migration rate: -8.29 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.71 male(s)/female (1998 est.)
Infant mortality rate: 40.77 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 66.73 years
male: 62.45 years
female: 71.23 years (1998 est.)
Total fertility rate: 1.69 children born/woman (1998 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 93%, Azeri 3%, Russian 2%, other (mostly
Yezidi Kurds) 2% (1989)
note: as of the end of 1993, virtually all Azeris had emigrated from
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Russian 2%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 98% (1989 est.)
@Armenia:Government
Country name:
conventional long form: Republic of Armenia
conventional short form: Armenia
local long form: Hayastani Hanrapetut''yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic; Armenian Republic
Data code: AM
Government type: republic
National capital: Yerevan
Administrative divisions: 10 provinces (marzer, singular-marz) and 1
city* (k''aghak''ner, singular - k''aghak''); Aragatsotn, Ararat, Armavir,
Geghark''unik'', Kotayk'', Lorri, Shirak, Syunik'', Tavush, Vayots'' Dzor,
Yerevan*
Independence: 28 May 1918 (First Armenian Republic); 23 September 1991
(from Soviet Union)
National holiday: Referendum Day, 21 September
Constitution: adopted by nationwide referendum 5 July 1995
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Robert KOCHARIAN (since 30 March 1998)
head of government: Prime Minister Armen DARBINYAN (since 10 April
1998)
cabinet: Council of Ministers appointed by the prime minister
elections: president elected by popular vote for a five-year term;
special election last held 30 March 1998 (next election to be held
March 2003); prime minister appointed by the president
election results: Robert KOCHARIAN elected president; percent of
vote-Robert KOCHARIAN 59%, Karen DEMIRCHYAN 41%
Legislative branch: unicameral National Assembly (Parliament) or
Azgayin Zhoghov (190 seats; members serve four-year terms)
elections: last held 5 July 1995 (next to be held NA July 1999)
election results: percent of vote by party-NA; seats by
party-Republican Bloc 159 (ANM 63, DLP-Hanrapetutyun Bloc 6, Republic
Party 4, CDU 3, Intellectual Armenia 3, Social Democratic Party 2,
independents 78), SWM 8, ACP 7, NDU 5, NSDU 3, DLP 1, ARF 1, other 4,
vacant 2
Judicial branch: Supreme Court; Constitutional Court
Political parties and leaders: Armenian National Movement or ANM [Vano
SIRADEGIAN, chairman]; National Democratic Union or NDU [Vazgen
MANUKIAN]; Intellectual Armenia [H. TOKMAJIAN]; Social Democratic
(Hnchakian) Party [Yeghia NACHARIAN]; Shamiram Women''s Movement or SWM
[Maria NERSISSIAN]; Armenian Communist Party or ACP [Sergey BADALYAN];
Union of National Self-Determination or NSDU [Paruir HAIRIKIAN,
chairman]; Armenian Revolutionary Federation ("Dashnak" Party) or ARF;
Christian Democratic Union or CDU [Azat ARSHAKYN, chairman];
Democratic Liberal Party [Orthosis GYONJIAN, chairman]; Republican
Party [Andranik MARKARYAN]
International organization participation: BSEC, CCC, CE (guest), CIS,
EAPC, EBRD, ECE, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFAD, IFC, IFRCS,
ILO, IMF, Intelsat, Interpol, IOC, IOM, ITU, NAM (observer), OSCE,
PFP, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO, WTrO
(applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Rouben SHUGARIAN
chancery: 2225 R Street NW, Washington, DC 20008
telephone: [1] (202) 319-1976
FAX: [1] (202) 319-2982
consulate(s) general: Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Peter TOMSEN
embassy: 18 General Baghramian Avenue, Yerevan
mailing address: use embassy street address
telephone: [374] (2) 524-661, 521-611
FAX: [374] (2) 151-550, 151-511
Flag description: three equal horizontal bands of red (top), blue, and
gold
@Armenia:Economy
Economy-overview: Under the old Soviet central planning system,
Armenia had developed a modern industrial sector, supplying machine
tools, textiles, and other manufactured goods to sister republics in
exchange for raw materials and energy. Since the implosion of the USSR
in December 1991, Armenia has switched to small-scale agriculture away
from the large agroindustrial complexes of the Soviet area. The
agricultural sector has long-term needs for more investment and
updated technology. The privatization of industry has been at a slower
pace, but ahead of most of the rest of the CIS. Armenia is a food
importer and its mineral deposits (gold, bauxite) are small. The
ongoing conflict with Azerbaijan over the ethnic Armenian-dominated
region of Nagorno-Karabakh and the embargoes imposed by Azerbaijan and
Turkey contributed to a severe economic decline in the early 1990s. By
1994, however, the Armenian Government had launched an ambitious
IMF-sponsored economic program that has resulted in positive growth
rates in 1995-97. Armenia also managed to slash inflation and to
privatize most small and medium-sized enterprises. The chronic energy
shortages Armenia suffered in recent years has been partially offset
by the energy supplied by one of its nuclear power plants at Metsamor,
which in 1996 supplied about 40% of the country''s energy needs,
according to the Armenian Government. Moreover, Armenia is expanding
its energy imports from Iran.
GDP: purchasing power parity-$9.5 billion (1997 est.)
GDP-real growth rate: 2.7% (1997 est.)
GDP-per capita: purchasing power parity-$2,750 (1997 est.)
GDP-composition by sector:
agriculture: 38%
industry: 32%
services: 30% (1996 est.)
Inflation rate-consumer price index: 13.2% (1997 est.)
Labor force:
total: 1.6 million (1997)
by occupation: manufacturing, mining, and construction 25%,
agriculture 38%, services 37%
Unemployment rate: 10.6% officially registered unemployed, but large
numbers of underemployed (June 1997)
Budget:
revenues: $322 million
expenditures: $424 million, including capital expenditures of $80
million (1998 est.)
Industries: much of industry is shut down; metal-cutting machine
tools, forging-pressing machines, electric motors, tires, knitted
wear, hosiery, shoes, silk fabric, washing machines, chemicals,
trucks, watches, instruments, microelectronics
Industrial production growth rate: 0.7% (1997 est.)
Electricity-capacity: 2.768 million kW (1995)
Electricity-production: 6.3 billion kWh (1996)
Electricity-consumption per capita: 1,570 kWh (1995)
Agriculture-products: fruit (especially grapes), vegetables; vineyards
near Yerevan are famous for brandy and other liqueurs; minor livestock
sector
Exports:
total value: $290 million (f.o.b., 1996)
commodities: gold and jewelry, aluminum, transport equipment,
electrical equipment, scrap metal
partners: Iran, Russia, Turkmenistan, Georgia
Imports:
total value: $727 million (c.i.f., 1996)
commodities: grain, other foods, fuel, other energy
partners: Iran, Russia, Turkmenistan, Georgia, US, EU
Debt-external: $820 million (of which $75 million to Russia) (1997
est.)
Economic aid:
recipient: ODA, $NA
note: commitments (excluding Russia), $1,385 million ($675 million in
disbursements) (1992-95)
Currency: 1 dram = 100 luma (introduced new currency in November 1993)
Exchange rates: dram per US$1-499.89 (November 1997), 414.04 (1996),
405.91 (1995), 288.65 (1994), 9.11 (1993)
Fiscal year: calendar year','1f1d62787fd545525371536ff68005970b8a25a8dbf68ce411fe001bb384d9cf','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8db7ee1220ac51f75763442075b2156749d9559c8fa16ad9e4a70ee279f48c10',1990,'AZ','Azerbaijan','introduction',25,'Current issues: Azerbaijan continues to be plagued by an unresolved
10-year-old conflict with Armenian separatists over its
Nagorno-Karabakh region. The Karabakh Armenians have declared
independence and seized almost 20% of the country''s territory,
creating almost 1 million Azerbaijani refugees in the process. Both
sides have generally observed a Russian-mediated cease-fire in place
since May 1994.
@Azerbaijan:Geography
Location: Southwestern Asia, bordering the Caspian Sea, between Iran
and Russia
Geographic coordinates: 40 30 N, 47 30 E
Map references: Commonwealth of Independent States
Area:
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous Republic and the
Nagorno-Karabakh region; the region''s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November 1991
Area-comparative: slightly smaller than Maine
Land boundaries:
total: 2,013 km
border countries: Armenia (with Azerbaijan-proper) 566 km, Armenia
(with Azerbaijan-Naxcivan exclave) 221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with Azerbaijan-Naxcivan exclave) 179
km, Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked)
note: Azerbaijan borders the Caspian Sea (800 km, est.)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Lowland (much of it below sea level)
with Great Caucasus Mountains to the north, Qarabag (Karabakh) Upland
in west; Baku lies on Abseron (Apsheron) Peninsula that juts into
Caspian Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore, nonferrous
metals, alumina
Land use:
arable land: 18%
permanent crops: 5%
permanent pastures: 25%
forests and woodland: 11%
other: 41% (1993 est.)
Irrigated land: 10,000 sq km (1993 est.)
Natural hazards: droughts; some lowland areas threatened by rising
levels of the Caspian Sea
Environment-current issues: local scientists consider the Abseron
(Apsheron) Peninsula (including Baku and Sumqayit) and the Caspian Sea
to be the ecologically most devastated area in the world because of
severe air, water, and soil pollution; soil pollution results from the
use of DDT as a pesticide and also from toxic defoliants used in the
production of cotton
Environment-international agreements:
party to: Climate Change, Ozone Layer Protection
signed, but not ratified: Biodiversity
Geography-note: landlocked
@Azerbaijan:People
Population: 7,855,576 (July 1998 est.)
Age structure:
0-14 years: 32% (male 1,300,236; female 1,247,027)
15-64 years: 61% (male 2,336,568; female 2,468,679)
65 years and over: 7% (male 195,322; female 307,744) (July 1998 est.)
Population growth rate: 0.7% (1998 est.)
Birth rate: 22.2 births/1,000 population (1998 est.)
Death rate: 9.41 deaths/1,000 population (1998 est.)
Net migration rate: -5.75 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.63 male(s)/female (1998 est.)
Infant mortality rate: 81.64 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 63.3 years
male: 59.01 years
female: 67.81 years (1998 est.)
Total fertility rate: 2.72 children born/woman (1998 est.)
Nationality:
noun: Azerbaijani(s)
adjective: Azerbaijani
Ethnic groups: Azeri 90%, Dagestani Peoples 3.2%, Russian 2.5%,
Armenian 2.3%, other 2% (1995 est.)
note: almost all Armenians live in the separatist Nagorno-Karabakh
region
Religions: Muslim 93.4%, Russian Orthodox 2.5%, Armenian Orthodox
2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan; actual
practicing adherents are much lower
Languages: Azeri 89%, Russian 3%, Armenian 2%, other 6% (1995 est.)
Literacy:
definition: age 15 and over can read and write
total population: 97%
male: 99%
female: 96% (1989 est.)
@Azerbaijan:Government
Country name:
conventional long form: Azerbaijani Republic
conventional short form: Azerbaijan
local long form: Azarbaycan Respublikasi
local short form: none
former: Azerbaijan Soviet Socialist Republic
Data code: AJ
Government type: republic
National capital: Baku (Baki)
Administrative divisions: 59 rayons (rayonlar; rayon-singular), 11
cities* (saharlar; sahar - singular), 1 autonomous republic** (muxtar
respublika); Abseron Rayonu, Agcabadi Rayonu, Agdam Rayonu, Agdas
Rayonu, Agstafa Rayonu, Agsu Rayonu, Ali Bayramli Sahari*, Astara
Rayonu, Baki Sahari*, Balakan Rayonu, Barda Rayonu, Beylaqan Rayonu,
Bilasuvar Rayonu, Cabrayil Rayonu, Calilabad Rayonu, Daskasan Rayonu,
Davaci Rayonu, Fuzuli Rayonu, Gadabay Rayonu, Ganca Sahari*, Goranboy
Rayonu, Goycay Rayonu, Haciqabul Rayonu, Imisli Rayonu, Ismayilli
Rayonu, Kalbacar Rayonu, Kurdamir Rayonu, Lacin Rayonu, Lankaran
Rayonu, Lankaran Sahari*, Lerik Rayonu, Masalli Rayonu, Mingacevir
Sahari*, Naftalan Sahari*, Naxcivan Muxtar Respublikasi**, Neftcala
Rayonu, Oguz Rayonu, Qabala Rayonu, Qax Rayonu, Qazax Rayonu, Qobustan
Rayonu, Quba Rayonu, Qubadli Rayonu, Qusar Rayonu, Saatli Rayonu,
Sabirabad Rayonu, Saki Rayonu, Saki Sahari*, Salyan Rayonu, Samaxi
Rayonu, Samkir Rayonu, Samux Rayonu, Siyazan Rayonu, Sumqayit Sahari*,
Susa Rayonu, Susa Sahari*, Tartar Rayonu, Tovuz Rayonu, Ucar Rayonu,
Xacmaz Rayonu, Xankandi Sahari*, Xanlar Rayonu, Xizi Rayonu, Xocali
Rayonu, Xocavand Rayonu, Yardimli Rayonu, Yevlax Rayonu, Yevlax
Sahari*, Zangilan Rayonu, Zaqatala Rayonu, Zardab Rayonu
Independence: 30 August 1991 (from Soviet Union)
National holiday: Independence Day, 28 May
Constitution: adopted 12 November 1995
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Heydar ALIYEV (since 18 June 1993)
head of government: Prime Minister Artur RASIZADE (since 26 November
1996)
cabinet: Council of Ministers appointed by the president and confirmed
by the National Assembly
elections: president elected by popular vote to a five-year term;
election last held 3 October 1993 (next to be held October 1998);
prime minister and first deputy prime ministers appointed by the
president and confirmed by the National Assembly
election results: Heydar ALIYEV elected president; percent of
vote-Heydar ALIYEV 97%
Legislative branch: unicameral National Assembly or Milli Mejlis (125
seats; members serve five-year terms)
elections: last held 12 and 26 November 1995 (next to be held NA 2000)
election results: percent of vote by party-NA; seats by party-YAP and
allies 115, AXC 4, AMIP 3, YMP 1, vacant 2
Judicial branch: Supreme Court
Political parties and leaders: New Azerbaijan Party or YAP [Heydar
ALIYEV, chairman]; Azerbaijan Popular Front or AXC [Abulfaz ELCHIBEY,
chairman]; Party for National Independence of Azerbaijan or AMIP
[Etibar MAMMADOV, chairman]; Musavat Party or YMP [Isa GAMBAR,
chairman]; People''s Democratic Party of Azerbaijan [Rafig TURABXANLY];
People''s Freedom Party [Yunus OGUZ, chairman]; Democratic Party of
Independence of Azerbaijan [Vagit KERIMOV]; Communist Party of
Azerbaijan (CPA-2) [Firudin HASANOV]; Social Democratic Party of
Azerbaijan or SDP [Zardusht ALIZADE, chairman]; Liberal Party of
Azerbaijan [Lala HAJIYEVA]; Vahdat Party [Leyla YUNUSOV, Gadzhi
ALIZADE]; Azerbaijan Muslim Democratic Party (former Islamic Party)
[Haji Mekhti SHAMILLI]; Azerbaijan Democratic Party or ADP [Ilyas
ISMAYLOV]; Civic Solidarity [Sabir RUSTAMXANLI]; Ana Vatan Party
[Fazail AGAMALI]
Political pressure groups and leaders: self-proclaimed Armenian
Nagorno-Karabakh Republic; Talysh independence movement; Sadval,
Lezgin movement
International organization participation: BSEC, CCC, CE (guest), CIS,
EAPC, EBRD, ECE, ECO, ESCAP, FAO, IBRD, ICAO, IDA, IDB, IFAD, IFC,
IFRCS, ILO, IMF, IMO, Intelsat, Interpol, IOC, ITU, NAM (observer),
OIC, OSCE, PFP, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO, WMO,
WTrO (observer)
Diplomatic representation in the US:
chief of mission: Ambassador Hafiz Mir Jalal PASHAYEV
chancery: (temporary) Suite 700, 927 15th Street NW, Washington, DC
20005 or P. O. Box 28790, Washington, DC 20038-8790
telephone: [1] (202) 842-0001
FAX: [1] (202) 842-0004
Diplomatic representation from the US:
chief of mission: Ambassador Stanley ESCUDERO
embassy: Azadliq Prospekti 83, Baku
mailing address: use embassy street address
telephone: [9] (9412) 98-03-35
FAX: [9] (9412) 96-04-69
Flag description: three equal horizontal bands of blue (top), red, and
green; a crescent and eight-pointed star in white are centered in red
band
@Azerbaijan:Economy
Economy-overview: Azerbaijan is less developed industrially than
either Armenia or Georgia, the other Transcaucasian states. It
resembles the Central Asian states in its majority nominally Muslim
population, high structural unemployment, and low standard of living.
The economy''s most prominent products are oil, cotton, and gas.
Production from the Caspian oil and gas field has been in decline for
several years, but the negotiation of more than a dozen
production-sharing arrangements (PSAs) with foreign firms, which have
thus far committed $30 billion to oil field development, should
generate the funds needed to spur future industrial development. Oil
production under the first of these PSAs, with the Azerbaijan
International Operating Company, began in November 1997. Azerbaijan
shares all the formidable problems of the ex-Soviet republics in
making the transition from a command to a market economy, but its
considerable energy resources brighten its long-term prospects. Baku
has only recently begun making progress on economic reform, and old
economic ties and structures are slowly being replaced. A major
short-term obstacle to economic progress, including stepped up foreign
investment, is the continuing conflict with Armenia over the ethnic
Armenian-dominated region of Nagorno-Karabakh. Trade with Russia and
the other former Soviet republics is declining in importance while
trade is building up with the nations of Europe, Turkey, Iran, and the
UAE. A serious long-term challenge is the maintenance of the
competitiveness of non-oil exports in world markets.
GDP: purchasing power parity-$11.9 billion (1997 est.)
GDP-real growth rate: 5.8% (1997 est.)
GDP-per capita: purchasing power parity-$1,460 (1997 est.)
GDP-composition by sector:
agriculture: 30%
industry: 23%
services: 47% (1996 est.)
Inflation rate-consumer price index: 3.7% (1997 est.)
Labor force:
total: 2.789 million
by occupation: agriculture and forestry 32%, industry and construction
26%, other 42% (1990)
Unemployment rate: 20% (1996 est.)
Budget:
revenues: $565 million
expenditures: $682 million, including capital expenditures of $NA
(1996 est.)
Industries: petroleum and natural gas, petroleum products, oilfield
equipment; steel, iron ore, cement; chemicals and petrochemicals;
textiles
Industrial production growth rate: 0.3% (1997 est.)
Electricity-capacity: 5.239 million kW (1995)
Electricity-production: 16.051 billion kWh (1995)
Electricity-consumption per capita: 2,200 kWh (1996 est.)
Agriculture-products: cotton, grain, rice, grapes, fruit, vegetables,
tea, tobacco; cattle, pigs, sheep, goats
Exports:
total value: $789 million (f.o.b., 1996 est.)
commodities: oil and gas, chemicals, oilfield equipment, textiles,
cotton
partners: CIS, European countries, Turkey
Imports:
total value: $1.3 billion (c.i.f., 1996 est.)
commodities: machinery and parts, consumer durables, foodstuffs,
textiles
partners: CIS, European countries, Turkey
Debt-external: $100 million (of which $75 million to Russia)
Economic aid:
recipient: ODA, $14 million (1993)
note: commitments, 1992-95, $1,000 million ($185 million in
disbursements); wheat from Turkey
Currency: 1 manat = 100 gopik
Exchange rates: manats per US$1-3,936.00 (September 1997), 4,301.26
(1996), 4,413.54 (1995), 1,570.23 (1994), 99.98 (1993)
Fiscal year: calendar year','c15db388bb9872566a8f68bbfd0abf0517c394e8a5c4486d1627a22b74eff187','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d34c395196b7508fa7c6137dd4bd2836e801591291899d5fed558c326430863',1990,'BA','Bosnia and Herzegovina','introduction',39,'Current issues: On 21 November 1995, in Dayton, Ohio, the former
Yugoslavia''s three warring parties signed a peace agreement that
brought to a halt over three years of interethnic civil strife in
Bosnia and Herzegovina (the final agreement was signed in Paris on 14
December 1995). The Dayton Agreement, signed then by Bosnian President
IZETBEGOVIC, Croatian President TUDJMAN, and Serbian President
MILOSEVIC, divides Bosnia and Herzegovina roughly equally between the
Muslim/Croat Federation and the Bosnian Serbs while maintaining
Bosnia''s currently recognized borders. In 1995-96, a NATO-led
international peacekeeping force (IFOR) of 60,000 troops served in
Bosnia to implement and monitor the military aspects of the agreement.
IFOR was succeeded by a smaller, NATO-led Stabilization Force (SFOR)
whose mission is to deter renewed hostilities. SFOR will remain in
place until June 1998. A High Representative appointed by the UN
Security Council is responsible for civilian implementation of the
accord, including monitoring implementation, facilitating any
difficulties arising in connection with civilian implementation, and
coordinating activities of the civilian organizations and agencies in
Bosnia and Herzegovina. The Bosnian conflict began in the spring of
1992 when the government of Bosnia and Herzegovina held a referendum
on independence and the Bosnian Serbs - supported by neighboring
Serbia-responded with armed resistance aimed at partitioning the
republic along ethnic lines and joining Serb-held areas to form a
"greater Serbia." In March 1994, Bosnia''s Muslims and Croats reduced
the number of warring factions from three to two by signing an
agreement in Washington creating their joint Muslim/Croat Federation
of Bosnia and Herzegovina. The Federation, formed by the Muslims and
Croats in March 1994, is one of two entities (the other being the
Bosnian Serb-led Republika Srpska) that comprise Bosnia and
Herzegovina.
@Bosnia and Herzegovina:Geography
Location: Southeastern Europe, bordering the Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Bosnia and Herzegovina, Europe
Area:
total: 51,233 sq km
land: 51,233 sq km
water: 0 sq km
Area-comparative: slightly smaller than West Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km, Serbia and Montenegro 527 km (312 km
with Serbia, 215 km with Montenegro)
Coastline: 20 km
Maritime claims: NA
Climate: hot summers and cold winters; areas of high elevation have
short, cool summers and long, severe winters; mild, rainy winters
along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron, bauxite, manganese, forests, copper,
chromium, lead, zinc
Land use:
arable land: 14%
permanent crops: 5%
permanent pastures: 20%
forests and woodland: 39%
other: 22% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: frequent and destructive earthquakes
Environment-current issues: air pollution from metallurgical plants;
sites for disposing of urban waste are limited; widespread casualties,
water shortages, and destruction of infrastructure because of the
1992-95 civil strife
Environment-international agreements:
party to: Air Pollution, Law of the Sea, Marine Dumping, Marine Life
Conservation, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography-note: within Bosnia and Herzegovina''s recognized borders,
the country is divided into a joint Muslim/Croat Federation (about 51%
of the territory) and a Serb Republic, The Republika Srpska [RS]
(about 49% of the territory); the region called Herzegovina is
contiguous to Croatia and traditionally has been settled by an ethnic
Croat majority
@Bosnia and Herzegovina:People
Population: 3,365,727 (July 1998 est.)
note: all data dealing with population is subject to considerable
error because of the dislocations caused by military action and ethnic
cleansing
Age structure:
0-14 years: 18% (male 307,857; female 291,424)
15-64 years: 71% (male 1,177,516; female 1,195,419)
65 years and over: 11% (male 156,041; female 237,470) (July 1998 est.)
Population growth rate: 3.63% (1998 est.)
Birth rate: 8.72 births/1,000 population (1998 est.)
Death rate: 12.32 deaths/1,000 population (1998 est.)
Net migration rate: 39.91 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.65 male(s)/female (1998 est.)
Infant mortality rate: 30.8 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 63.03 years
male: 58.35 years
female: 68.02 years (1998 est.)
Total fertility rate: 1.14 children born/woman (1998 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Serb 40%, Muslim 38%, Croat 22% (est.)
Religions: Muslim 40%, Orthodox 31%, Catholic 15%, Protestant 4%,
other 10%
Languages: Serbo-Croatian (often called Bosnian) 99%
Literacy: NA
@Bosnia and Herzegovina:Government
Country name:
conventional long form: none
conventional short form: Bosnia and Herzegovina
local long form: none
local short form: Bosna i Hercegovina
Data code: BK
Government type: emerging democracy
National capital: Sarajevo
Administrative divisions: there are two first-order administrative
divisions approved by the US Government-the Muslim/Croat Federation of
Bosnia and Herzegovina (Federacija Bosna i Hercegovina) and Republika
Srpska; it has been reported that the Muslim/Croat Federation is
comprised of 10 cantons identified by either number or name - Goradzde
(5), Livno (10), Middle Bosnia (6), Neretva (7), Posavina (2),
Sarajevo (9), Tuzla Podrinje (3), Una Sana (1), West Herzegovina (8),
Zenica Doboj (4)
Independence: NA April 1992 (from Yugoslavia)
National holiday: Republika Srpska-"Republic Day," 9 January;
Independence Day, 1 March; Bosnia-"Republic Day," 25 November
Constitution: the Dayton Agreement, signed 14 December 1995, included
a new constitution now in force
Legal system: based on civil law system
Suffrage: 16 years of age, if employed; 18 years of age, universal
Executive branch:
chief of state: Chairman of the Presidency Alija IZETBEGOVIC (since 14
September 1996); other members of the three-member rotating
presidency: Kresimir ZUBAK (since 14 September 1996-Croat) and Momcilo
KRAJISNIK (since 14 September 1996 - Serb)
head of government: Cochairman of the Council of Ministers Haris
SILAJDZIC (since NA January 1997); Cochairman of the Council of
Ministers Boro BOSIC (since NA January 1997) NA
cabinet: Council of Ministers nominated by the council chairmen
note: president of the Muslim/Croat Federation of Bosnia and
Herzegovina: Ejup GANIC (since 1 January 1998); president of the
Republika Srpska: Biljana PLAVSIC (since September 1996)
elections: the three presidency members (one each Muslim, Croat, Serb)
are elected by direct election (first election for a two-year term,
thereafter for a four-year term); the president with the most votes
becomes the chairman; election last held 14 September 1996 (next to be
held September 1998); the cochairmen are nominated by the presidency
election results: Alija IZETBEGOVIC elected chairman of the collective
presidency with the highest number of votes; percent of vote-Alija
IZETBEGOVIC received 80% of the Muslim vote to Haris SILAJDZIC''s 14%;
Kresimir ZUBAK received 88% of the Croat vote to Ivo KOMSIC''s 11%;
Momcilo KRAJISNIK received 68% of the Serb vote to Mladen IVANIC''s 30%
Legislative branch: bicameral Parliamentary Assembly or Skupstina
consists of the National House of Representatives or Vijece Opcina (42
seats-14 Serb, 14 Croat, and 14 Muslim; members serve two-year terms)
and the House of Peoples or Vijece Gradanstvo (15 seats-5 Muslim, 5
Croat, 5 Serb; members serve two-year terms)
elections: National House of Representatives-elections last held 14
September 1996 (next to be held NA); note-the House of Peoples is
elected by the Muslim/Croat Federation''s 140-seat House of
Representatives (two-thirds) and the Republika Srpska''s 83-seat
National Assembly (one-third)
election results: National House of Representatives: two-thirds chosen
from the Muslim/Croat Federation: percent of vote by party-NA; seats
by party-SDA 16, HDZ-BiH 7, Joint List of Social Democrats 3, Party
for Bosnia and Herzegovina 2; one-third chosen from the Bosnian Serb
Republic: percent of vote by party-NA; seats by party-SDS 9, SDA 3,
Democratic Patriotic Front/Union for Peace and Progress 2
note: the Muslim/Croat Federation has a House of Representatives with
140 seats: seats by party-SDA 80, HDZ-BiH 33, Party for Bosnia and
Herzegovina 11, Joint List of Social Democrats 10, other 6; the
Republika Srpska has a National Assembly with 83 seats: seats by
party-SDS 24, Serb Radical Party 15, Serb National Alliance 15,
Socialist Party 9, Independent Social Democrats 2, Coalition for
United Bosnia and Herzegovina and others 18
Judicial branch: Supreme Court, supervised by the Ministry of Justice;
Constitutional Court, supervised by the Ministry of Justice
Political parties and leaders: Party of Democratic Action or SDA
[Alija IZETBEGOVIC]; Croatian Democratic Union of BiH or HDZ-BiH [Bozo
RAJIC]; Serb Democratic Party or SDS [Aleksa BUHA]; Party for Bosnia
and Herzegovina or SBiH [Haris SILAJDZIC]; Joint List (consists of the
following parties: UBSD, RP, MBO, HSG, and SPP); Civic Democratic
Party or GDS [Ibrahim SPAHIC]; Croatian Peasants'' Party of BiH or HSS
[Ivo KOMSIC]; Independent Social Democratic Party or SNSD [Milorad
DODIK]; Liberal Bosniak Organization or LBO [Muhamed FILIPOVIC];
Liberal Party or LS [Rasim KADIC, president]; Muslim-Bosniac
Organization or MBO [Adil ZULFIKARPASIC]; Republican Party of Bosnia
and Herzegovina or RS [Stjepan KLJUIC]; Serb Civic Council or SGV
[Mirko PEJANOVIC]; Social Democratic Party or SDP (formerly the
Democratic Party of Socialists or DSS) [Zlatko LAGUMDZIJA]; Socialist
Party of Republika Srpska or SPRS [Zivko RADISIC]; Social Democrats of
Bosnia Herzegovina [Selim BESLAGIC]; Serb Radical Party of RS [Nikola
POPLASEN]; Serb Party of Krojina and Posavina or SSKIP [Predrag
LAZAREVIC]; National Democratic Union (also known as Democratic
People''s Union or DNZ) [Fikret ABDIC]; Serb National Alliance or SNS
[Biljana PLAVSIC]; Coalition for a United and Democratic BiH
(coalition of SDA, SBiH, LS, and GDS)
note: 82 parties participated in the September 1997 municipal
elections
Political pressure groups and leaders: NA
International organization participation: CE (guest), CEI, EBRD, ECE,
FAO, IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO, Intelsat,
Interpol, IOC, IOM (observer), ISO, ITU, NAM (guest), OIC (observer),
OSCE, UN, UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador Sven ALKALAJ
chancery: Suite 760, 1707 L Street NW, Washington, DC 20036
telephone: [1] (202) 833-3612, 3613, 3615
FAX: [1] (202) 833-2061
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador Richard KAUZLARICH
embassy: 43 Ul. Dure Dakovica, Sarajevo
mailing address: use street address
telephone: [387] (71) 445-700, 667-391, 667-389, 667-743, 667-390,
659-969, 659-992
FAX: [387] (71) 659-722
Flag description: a wide medium blue vertical band on the fly side
with a yellow isosceles triangle abutting the band and the top of the
flag; the remainder of the flag is medium blue with seven full
five-pointed white stars and two half stars top and bottom along the
hypotenuse of the triangle
Government-note: Until declaring independence in spring 1992, Bosnia
and Herzegovina existed as a republic in the former Yugoslavia. Bosnia
was partitioned by fighting during 1992-95 and governed by competing
ethnic factions. Bosnia''s current governing structures were created by
the Dayton Accords, the 1995 peace agreement which was officially
signed in Paris on 14 December 1995 by Bosnian President IZETBEGOVIC,
Croatian President TUDJMAN, and Serbian President MILOSEVIC. This
agreement retained Bosnia''s exterior border and created a joint
multi-ethnic and democratic government. This national government-based
on proportional representation similar to that which existed in the
former socialist regime-is charged with conducting foreign, economic,
and fiscal policy. The Dayton Accords also recognized a second tier of
government, comprised of two entities-a joint Muslim/Croat Federation
and the Bosnian Serb Republika Srpska (RS)-each presiding over roughly
one-half the territory. The Federation and RS governments are charged
with overseeing internal functions. As mandated by the Dayton Accords,
the Bosnians on 14 September 1996 participated in the first post-war
elections of national, entity, and cantonal leaders. The Bosnians have
been slow to form and install new joint institutions. A new Federation
cabinet was sworn in 18 December 1996 and the new Bosnian central
government cabinet was confirmed on 3 January 1997. The Bosnians on
13-14 September 1997 participated in municipal elections, postponed in
1996 because of voter registration irregularities.
@Bosnia and Herzegovina:Economy
Economy-overview: Bosnia and Herzegovina ranked next to The Former
Yugoslav Republic of Macedonia as the poorest republic in the old
Yugoslav federation. Although agriculture has been almost all in
private hands, farms have been small and inefficient, and the republic
traditionally has been a net importer of food. Industry has been
greatly overstaffed, one reflection of the rigidities of communist
central planning and management. TITO had pushed the development of
military industries in the republic with the result that Bosnia hosted
a large share of Yugoslavia''s defense plants. The bitter interethnic
warfare in Bosnia caused production to plummet by 80% from 1990 to
1995, unemployment to soar, and human misery to multiply. With an
uneasy peace in place, output has recovered in 1996-97 at high
percentage rates on a low base, but remains less than half the 1990
level. The country, especially in the Muslim-Croat area, receives
substantial amounts of humanitarian aid from the international
community. Wide regional differences in war damage and access to the
outside world have resulted in substantial variations in living
conditions among local areas and individual families.
GDP: purchasing power parity-$4.41 billion (1997 est.)
GDP-real growth rate: 35% (1997 est.)
GDP-per capita: purchasing power parity-$1,690 (1997 est.)
GDP-composition by sector:
agriculture: 19%
industry: 23%
services: 58% (1996 est.)
Inflation rate-consumer price index: NA%
Labor force:
total: 1,026,254
by occupation: NA%
Unemployment rate: 40%-50% (1996 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: steel, coal, iron ore, lead, zinc, manganese, bauxite,
vehicle assembly, textiles, tobacco products, wooden furniture, tank
and aircraft assembly, domestic appliances, oil refining; much of
capacity damaged or shut down (1995)
Industrial production growth rate: NA%
Electricity-capacity: 2.339 million kW (1995)
Electricity-production: 1.4 billion kWh (1995)
Electricity-consumption per capita: 506 kWh (1995)
Agriculture-products: wheat, corn, fruits, vegetables; livestock
Exports:
total value: $152 million (1995 est.)
commodities: NA
partners: NA
Imports:
total value: $1.1 billion (1995 est.)
commodities: NA
partners: NA
Debt-external: $3.5 billion (yearend 1995 est.)
Economic aid:
recipient: $1.2 billion (1997 pledged)
Currency: 1 convertible marka = 100 convertible pfenniga; former
currencies still used
Exchange rates: NA
Fiscal year: calendar year','5c6f8d9aed5bc4baaa4a7eebfa8567494d5e8100b50574605abd97d48727bc9f','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b208411c2d34968e69e3cdb2f766afd2546ff061f4f3c172c20726ed80f514',1990,'BI','Burundi','introduction',50,'Current issues: in a number of waves since October 1993, hundreds of
thousands of refugees have fled the ethnic violence between the Hutu
and Tutsi factions in Burundi and crossed into Rwanda, Tanzania, and
Zaire (now called Democratic Republic of the Congo); since October
1996, an estimated 92,000 Hutu refuguees have been forced to return to
Burundi by Tutsi rebel forces in the Democratic Republic of the Congo,
leaving an estimated 35,000 still dispersed there; in Burundi, the
ethnic violence between the Hutus and the Tutsis continued in 1996,
causing an additional 150,000 Hutus to flee to Tanzania, thus raising
their numbers in that country to about 250,000
@Burundi:Geography
Location: Central Africa, east of Democratic Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area-comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countries: Democratic Republic of the Congo 233 km, Rwanda 290
km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable altitude variation
(772 m to 2,760 m); average annual temperature varies with altitude
from 23 to 17 degrees centigrade but is generally moderate as the
average altitude is about 1,700 m; average annual rainfall is about
150 cm; wet seasons from February to May and September to November,
and dry seasons from June to August and December to January
Terrain: hilly and mountainous, dropping to a plateau in east, some
plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Mount Heha 2,760 m
Natural resources: nickel, uranium, rare earth oxides, peat, cobalt,
copper, platinum (not yet exploited), vanadium
Land use:
arable land: 44%
permanent crops: 9%
permanent pastures: 36%
forests and woodland: 3%
other: 8% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: flooding, landslides
Environment-current issues: soil erosion as a result of overgrazing
and the expansion of agriculture into marginal lands; deforestation
(little forested land remains because of uncontrolled cutting of trees
for fuel); habitat loss threatens wildlife populations
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea, Nuclear Test Ban
Geography-note: landlocked; straddles crest of the Nile-Congo
watershed
@Burundi:People
Population: 5,537,387 (July 1998 est.)
Age structure:
0-14 years: 47% (male 1,313,112; female 1,309,600)
15-64 years: 50% (male 1,331,336; female 1,417,228)
65 years and over: 3% (male 69,718; female 96,393) (July 1998 est.)
Population growth rate: 3.51% (1998 est.)
Birth rate: 41.61 births/1,000 population (1998 est.)
Death rate: 17.38 deaths/1,000 population (1998 est.)
Net migration rate: 10.84 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.72 male(s)/female (1998 est.)
Infant mortality rate: 101.19 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 45.56 years
male: 43.79 years
female: 47.38 years (1998 est.)
Total fertility rate: 6.4 children born/woman (1998 est.)
Nationality:
noun: Burundian(s)
adjective: Burundi
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic) 14%, Twa (Pygmy) 1%,
Europeans 3,000, South Asians 2,000
Religions: Christian 67% (Roman Catholic 62%, Protestant 5%),
indigenous beliefs 32%, Muslim 1%
Languages: Kirundi (official), French (official), Swahili (along Lake
Tanganyika and in the Bujumbura area)
Literacy:
definition: age 15 and over can read and write
total population: 35.3%
male: 49.3%
female: 22.5% (1995 est.)
@Burundi:Government
Country name:
conventional long form: Republic of Burundi
conventional short form: Burundi
local long form: Republika y''u Burundi
local short form: Burundi
Data code: BY
Government type: republic
National capital: Bujumbura
Administrative divisions: 15 provinces; Bubanza, Bujumbura, Bururi,
Cankuzo, Cibitoke, Gitega, Karuzi, Kayanza, Kirundo, Makamba,
Muramvya, Muyinga, Ngozi, Rutana, Ruyigi
Independence: 1 July 1962 (from UN trusteeship under Belgian
administration)
National holiday: Independence Day, 1 July (1962)
Constitution: 13 March 1992; provides for establishment of a plural
political system
Legal system: based on German and Belgian civil codes and customary
law; does not accept compulsory ICJ jurisdiction
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: President Pierre BUYOYA (interim president since 27
September 1996); note-former President NTIBANTUNGANYA was overthrown
in a coup on 25 July 1996 and took refuge for 11 months in the US
ambassador''s residence in Bujumbura; former Major (retired) Pierre
BUYOYA has not been recognized as president of Burundi by the US or
most other governments
head of government: Prime Minister Pascal-Firmin NDIMIRA (since 31
July 1996)
cabinet: Council of Ministers appointed by prime minister
elections: NA
Legislative branch: unicameral National Assembly or Assemblee
Nationale (81 seats; members are popularly elected on a proportional
basis to serve five-year terms)
elections: last held 29 June 1993 (scheduled to be held in 1998,
although no date has been set)
election results: percent of vote by party-FRODEBU 71%, UPRONA 21.4%;
seats by party - FRODEBU 65, UPRONA 16; other parties won too small
shares of the vote to win seats in the assembly
Judicial branch: Supreme Court or Cour Supreme
Political parties and leaders: Unity for National Progress or UPRONA
[Charles MUKASI, president]; Burundi Democratic Front or FRODEBU [Jean
MINANI, president]; Socialist Party of Burundi or PSB; People''s
Reconciliation Party or PRP [Mathias HITIMANA, leader]; opposition
parties, legalized in March 1992, include Burundi African Alliance for
the Salvation or ABASA; Rally for Democracy and Economic and Social
Development or RADDES [Cyrille SIGEJEJE, chairman]; and Party for
National Redress or PARENA [Jean-Baptiste BAGAZA, leader]
International organization participation: ACCT, ACP, AfDB, CCC, CEEAC,
CEPGL, ECA, FAO, G-77, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, ILO,
IMF, Intelsat (nonsignatory user), Interpol, IOC, ITU, NAM, OAU, UN,
UNCTAD, UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador (vacant); Charge d''Affaires Henri
SIMBAKWTRA
chancery: Suite 212, 2233 Wisconsin Avenue NW, Washington, DC 20007
telephone: [1] (202) 342-2574
Diplomatic representation from the US:
chief of mission: Ambassador Morris N. HUGHES, Jr. (27 June l996)
embassy: Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone: [257] (2) 223454
FAX: [257] (2) 222926
Flag description: divided by a white diagonal cross into red panels
(top and bottom) and green panels (hoist side and outer side) with a
white disk superimposed at the center bearing three red six-pointed
stars outlined in green arranged in a triangular design (one star
above, two stars below)
@Burundi:Economy
Economy-overview: Burundi is a landlocked, resource-poor country in an
early stage of economic development. The economy is predominately
agricultural with roughly 90% of the population dependent on
subsistence agriculture. Its economic health depends on the coffee
crop, which accounts for 80% of foreign exchange earnings. The ability
to pay for imports therefore rests largely on the vagaries of the
climate and the international coffee market. As part of its economic
reform agenda, launched in February 1991 with IMF and World Bank
support, Burundi is trying to diversify its agricultural exports,
attract foreign investment in industry, and modernize government
budgetary practices. Since October 1993 the nation has suffered from
massive ethnic-based violence which has resulted in the death of
perhaps 100,000 persons and the displacement of a million others.
Foods, medicines, and electricity remain in short supply. An
impoverished and disorganized government can hardly implement the
needed reform programs.
GDP: purchasing power parity-$4 billion (1997 est.)
GDP-real growth rate: 4.4% (1997 est.)
GDP-per capita: purchasing power parity-$660 (1997 est.)
GDP-composition by sector:
agriculture: 56%
industry: 18%
services: 26% (1995 est.)
Inflation rate-consumer price index: 26% (1996 est.)
Labor force:
total: 1.9 million
by occupation: agriculture 93.0%, government 4.0%, industry and
commerce 1.5%, services 1.5% (1983 est.)
Unemployment rate: NA%
Budget:
revenues: $222 million
expenditures: $258 million, including capital expenditures of $92
million (1995 est.)
Industries: light consumer goods such as blankets, shoes, soap;
assembly of imported components; public works construction; food
processing
Industrial production growth rate: NA%
Electricity-capacity: 43,000 kW (1995)
Electricity-production: 158 million kWh (1995)
note: imports some electricity from Democratic Republic of the Congo
Electricity-consumption per capita: 32 kWh (1995)
Agriculture-products: coffee, cotton, tea, corn, sorghum, sweet
potatoes, bananas, manioc (tapioca); meat, milk, hides
Exports:
total value: $40 million (f.o.b., 1996)
commodities: coffee 81%, tea, cotton, hides
partners: EU 60%, US 7%, Asia 1%
Imports:
total value: $127 million (c.i.f., 1996)
commodities: capital goods 26%, petroleum products, foodstuffs,
consumer goods
partners: EU 47%, Asia 25%, US 6%
Debt-external: $1.1 billion (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Burundi franc (FBu) = 100 centimes
Exchange rates: Burundi francs (FBu) per US$1-412.59 (January 1998),
352.35 (1997), 302.75 (1996), 249.76 (1995), 252.66 (1994), 242.78
(1993)
Fiscal year: calendar year','d4ebfafed5adfa009f34744b4a6a8ac808f9c320a2bf786be2caa1b19cd575c7','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('775138ae6f81cf0a7d2fa82ce8212d93acd4a12e782e7f7956ac004ac1df39cc',1990,'CF','Central African Republic','introduction',57,'Current issues: In 1996, the Central African Republic experienced
three mutinies by dissident elements of the armed forces, which
demanded back pay as well as political and military reforms.
Continuing violence in 1997 between the government and rebel military
groups over pay issues, living conditions, and lack of opposition
party representation in the government has destroyed many businesses
in the capital, reducing tax revenues and exacerbating the
government''s problems in meeting expenses.
@Central African Republic:Geography
Location: Central Africa, north of Democratic Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,980 sq km
land: 622,980 sq km
water: 0 sq km
Area-comparative: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1,197 km, Democratic Republic
of the Congo 1,577 km, Republic of the Congo 467 km, Sudan 1,165 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet summers
Terrain: vast, flat to rolling, monotonous plateau; scattered hills in
northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mount Gaou 1,420 m
Natural resources: diamonds, uranium, timber, gold, oil
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 5%
forests and woodland: 75%
other: 17% (1993 est.)
Irrigated land: NA sq km
Natural hazards: hot, dry, dusty harmattan winds affect northern
areas; floods are common
Environment-current issues: tap water is not potable; poaching has
diminished its reputation as one of the last great wildlife refuges;
desertification; deforestation
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography-note: landlocked; almost the precise center of Africa
@Central African Republic:People
Population: 3,375,771 (July 1998 est.)
Age structure:
0-14 years: 44% (male 745,128; female 737,879)
15-64 years: 52% (male 864,263; female 906,656)
65 years and over: 4% (male 55,051; female 66,794) (July 1998 est.)
Population growth rate: 2.02% (1998 est.)
Birth rate: 38.72 births/1,000 population (1998 est.)
Death rate: 16.75 deaths/1,000 population (1998 est.)
Net migration rate: -1.78 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.82 male(s)/female (1998 est.)
Infant mortality rate: 105.73 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 46.82 years
male: 45.02 years
female: 48.68 years (1998 est.)
Total fertility rate: 5.12 children born/woman (1998 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 34%, Banda 27%, Sara 10%, Mandjia 21%, Mboum 4%,
M''Baka 4%, Europeans 6,500 (including 3,600 French)
Religions: indigenous beliefs 24%, Protestant 25%, Roman Catholic 25%,
Muslim 15%, other 11%
note: animistic beliefs and practices strongly influence the Christian
majority
Languages: French (official), Sangho (lingua franca and national
language), Arabic, Hunsa, Swahili
Literacy:
definition: age 15 and over can read and write
total population: 60%
male: 68.5%
female: 52.4% (1995 est.)
@Central African Republic:Government
Country name:
conventional long form: Central African Republic
conventional short form: none
local long form: Republique Centrafricaine
local short form: none
former: Central African Empire
abbreviation: CAR
Data code: CT
Government type: republic
National capital: Bangui
Administrative divisions: 14 prefectures (prefectures,
singular-prefecture), 2 economic prefectures* (prefectures
economiques, singular-prefecture economique), and 1 commune**;
Bamingui-Bangoran, Bangui**, Basse-Kotto, Gribingui*, Haute-Kotto,
Haute-Sangha, Haut-Mbomou, Kemo-Gribingui, Lobaye, Mbomou,
Nana-Mambere, Ombella-Mpoko, Ouaka, Ouham, Ouham-Pende, Sangha*,
Vakaga
Independence: 13 August 1960 (from France)
National holiday: National Day, 1 December (1958) (proclamation of the
republic)
Constitution: passed by referendum 29 December 1994; adopted 7 January
1995
Legal system: based on French law
Suffrage: 21 years of age; universal
Executive branch:
chief of state: President Ange PATASSE (since 22 October 1993)
head of government: Prime Minister Michel GBEZERA-BRIA (since January
1997)
cabinet: Council of Ministers
elections: president elected by popular vote for a 6-year term;
election last held 19 September 1993 (next to be held NA 1999); prime
minister appointed by the president
election results: Ange PATASSE elected president; percent of
vote-PATASSE 52.45%, Abel GOUMBA 45.62%
Legislative branch: unicameral National Assembly or Assemblee
Nationale (85 seats; members are elected by popular vote to serve
five-year terms)
elections: last held 19 September 1993 (next to be held NA 1998)
election results: percent of vote by party-NA; seats by party-MLPC 34,
RDC 13, PLD 7, FPP 7, ADP 6, PSD 3, CN 3, MDREC 1, PRC 1, FC 1, MESAN
1, independents supporting David DACKO 6, other independents 2
note: the National Assembly is advised by the Economic and Regional
Council or Conseil Economique et Regional; when they sit together they
are called the Congress or Congres
Judicial branch: Supreme Court or Cour Supreme, judges appointed by
the president; Constitutional Court, judges appointed by the president
Political parties and leaders: Alliance for Democracy and Progress or
ADP [Tchapka BREDE]; Central African Democratic Assembly or RDC [Andre
KOLINGBA]; Central African Republican Party or PRC; Civic Forum or FC
[Gen. Timothee MALENDOMA]; Democratic Movement for the Renaissance and
Evolution of Central Africa or MDREC [Joseph BENDOUNGA]; Liberal
Democratic Party or PLD [Nestor KOMBO-NAGUEMON]; Movement for the
Liberation of the Central African People or MLPC [the party of the
president, Ange Felix PATASSE]; Movement for Democracy and Development
or MDD [David DACKO]; National Convention or CN [David GALIAMBO];
Patriotic Front for Progress or FPP [Abel GOUMBA]; Social Democratic
Party or PSD [Enoch Derant LAKOUE]; Social Evolution Movement of Black
Africa or MESAN [Prosper LAVODRAMA and Joseph NGBANGADIBO]
International organization participation: ACCT, ACP, AfDB, BDEAC, CCC,
CEEAC, ECA, FAO, FZ, G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, ILO, IMF, Intelsat, Interpol, IOC, ITU, NAM, OAU, OIC
(observer), UDEAC, UN, UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO,
WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Henri KOBA
chancery: 1618 22nd Street NW, Washington, DC 20008
telephone: [1] (202) 462 2517
FAX: [1] (202) 462 2517
Diplomatic representation from the US:
chief of mission: Ambassador Mosina H. JORDAN
embassy: Avenue David Dacko, Bangui
mailing address: B. P. 924, Bangui
telephone: [236] 61 26 21
FAX: [236] 61 44 94
Flag description: four equal horizontal bands of blue (top), white,
green, and yellow with a vertical red band in center; there is a
yellow five-pointed star on the hoist side of the blue band
@Central African Republic:Economy
Economy-overview: Subsistence agriculture, together with forestry,
remains the backbone of the economy of the Central African Republic
(CAR), with more than 70% of the population living in outlying areas.
The agricultural sector generates half of GDP. Timber has accounted
for about 16% of export earnings and the diamond industry for nearly
54%. Important constraints to economic development include the CAR''s
landlocked position, a poor transportation system, a largely unskilled
work force, and a legacy of misdirected macroeconomic policies. The
50% devaluation of the currencies of 14 Francophone African nations on
12 January 1994 had mixed effects on the CAR''s economy. Diamond,
timber, coffee, and cotton exports increased, leading an estimated
rise of GDP of 7% in 1994 and nearly 5% in 1995. Military rebellions
and social unrest in 1996 were accompanied by widespread destruction
of property and a drop in GDP of 1%. Ongoing violence between the
government and rebel military groups over pay issues, living
conditions, and political representation has destroyed many businesses
in the capital, reduced tax revenues for the government, and delayed
negotiations for an IMF financial aid agreement.
GDP: purchasing power parity-$3.3 billion (1997 est.)
GDP-real growth rate: NA%
GDP-per capita: purchasing power parity-$1,000 (1997 est.)
GDP-composition by sector:
agriculture: 50%
industry: 14%
services: 36% (1994 est.)
Inflation rate-consumer price index: 4% (1996 est.)
Labor force: NA
Unemployment rate: 6% (1993)
Budget:
revenues: $638 million
expenditures: $1.9 billion, including capital expenditures of $888
million (1994 est.)
Industries: diamond mining, sawmills, breweries, textiles, footwear,
assembly of bicycles and motorcycles
Industrial production growth rate: NA%
Electricity-capacity: 43,000 kW (1995)
Electricity-production: 100 million kWh (1995)
Electricity-consumption per capita: 31 kWh (1995)
Agriculture-products: cotton, coffee, tobacco, manioc (tapioca), yams,
millet, corn, bananas; timber
Exports:
total value: $171 million (f.o.b., 1995)
commodities: diamonds, timber, cotton, coffee, tobacco
partners: France 16%, Belgium-Luxembourg 40.1%, Italy, Japan, US,
Spain, Iran, Democratic Republic of the Congo, Republic of the Congo
Imports:
total value: $174 million (f.o.b., 1995)
commodities: food, textiles, petroleum products, machinery, electrical
equipment, motor vehicles, chemicals, pharmaceuticals, consumer goods,
industrial products
partners: France 37%, other EU countries, Japan 24%, Algeria,
Cameroon, Namibia
Debt-external: $890 million (1994 est.)
Economic aid:
recipient: ODA, $NA; traditional budget subsidies from France
Currency: 1 Communaute Financiere Africaine franc (CFAF) = 100
centimes
Exchange rates: CFA francs (CFAF) per US$1-608.36 (January 1998),
583.67 (1997), 511.55 (1996), 499.15 (1995), 555.20 (1994), 283.16
(1993)
note: beginning 12 January 1994, the CFA franc was devalued to CFAF
100 per French franc from CFAF 50 at which it had been fixed since
1948
Fiscal year: calendar year','f6fd19d3c65b78bebca4e43c34c76d1ac12ed33dc86beb2f2155e940bb853e86','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a0fdccc5b95173ce01eb282d9c16259b0ffd0d3d1d1f7785d1016c14b5710b3',1990,'TD','Chad','introduction',59,'Historical perspective: In December 1990, after Chad had endured
decades of civil warfare among ethnic groups as well as invasions by
Libya, former northern guerrilla leader Idriss DEBY seized control of
the government. His transitional government eventually suppressed or
came to terms with most political-military groups, settled the
territorial dispute with Libya on terms favorable to Chad, drafted a
democratic constitution which was ratified by popular referendum in
March 1996, held multiparty national presidential elections in June
and July 1996 (DEBY won with 67% of the vote), and held multiparty
elections for the National Assembly in January and February 1997, in
which Idriss DEBY''s party, Patriotic Salvation Movement or MPS, won a
majority of the seats.
@Chad:Geography
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area:
total: 1.284 million sq km
land: 1,259,200 sq km
water: 24,800 sq km
Area-comparative: slightly more than three times the size of
California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1,094 km, Central African Republic 1,197
km, Libya 1,055 km, Niger 1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 175 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum (unexploited but exploration under way),
uranium, natron, kaolin, fish (Lake Chad)
Land use:
arable land: 3%
permanent crops: 0%
permanent pastures: 36%
forests and woodland: 26%
other: 35% (1993 est.)
Irrigated land: 140 sq km (1993 est.)
Natural hazards: hot, dry, dusty harmattan winds occur in north;
periodic droughts; locust plagues
Environment-current issues: inadequate supplies of potable water;
improper waste disposal in rural areas contributes to soil and water
pollution; desertification
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine Dumping
Geography-note: landlocked; Lake Chad is the most significant water
body in the Sahel
@Chad:People
Population: 7,359,512 (July 1998 est.)
Age structure:
0-14 years: 44% (male 1,631,010; female 1,623,272)
15-64 years: 53% (male 1,903,012; female 1,982,257)
65 years and over: 3% (male 97,118; female 122,843) (July 1998 est.)
Population growth rate: 2.66% (1998 est.)
Birth rate: 43.45 births/1,000 population (1998 est.)
Death rate: 16.86 deaths/1,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female (1998 est.)
Infant mortality rate: 116.97 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 48.22 years
male: 45.81 years
female: 50.73 years (1998 est.)
Total fertility rate: 5.74 children born/woman (1998 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: Muslims (Arabs, Toubou, Hadjerai, Fulbe, Kotoko,
Kanembou, Baguirmi, Boulala, Zaghawa, and Maba), non-Muslims (Sara,
Ngambaye, Mbaye, Goulaye, Moundang, Moussei, Massa), nonindigenous
150,000 (of whom 1,000 are French)
Religions: Muslim 50%, Christian 25%, indigenous beliefs (mostly
animism) 25%
Languages: French (official), Arabic (official), Sara and Sango (in
south), more than 100 different languages and dialects
Literacy:
definition: age 15 and over can read and write in French or Arabic
total population: 48.1%
male: 62.1%
female: 34.7% (1995 est.)
@Chad:Government
Country name:
conventional long form: Republic of Chad
conventional short form: Chad
local long form: Republique du Tchad
local short form: Tchad
Data code: CD
Government type: republic
National capital: N''Djamena
Administrative divisions: 14 prefectures (prefectures,
singular-prefecture); Batha, Biltine, Borkou-Ennedi-Tibesti,
Chari-Baguirmi, Guera, Kanem, Lac, Logone Occidental, Logone Oriental,
Mayo-Kebbi, Moyen-Chari, Ouaddai, Salamat, Tandjile
Independence: 11 August 1960 (from France)
National holiday: Independence Day, 11 August (1960)
Constitution: 31 March 1995, passed by referendum
Legal system: based on French civil law system and Chadian customary
law; does not accept compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Lt. Gen. Idriss DEBY (since 4 December 1990)
head of government: Prime Minister Nassour Guelengdouksia OUAIDOU
(since 16 May 1997); appointed by the president; note-he was
reappointed on 1 January 1998 when President DEBY named his new','9bb9342deb413890f4547d8363e816fe169833271960aeaaead2e3894c7bf18c','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c782d6587682f73fac64759f3fb47c26f4b17f001dc3364ce683dd6a2d252da',1990,'KM','Comoros','introduction',71,'Historical perspective: Comoros has had difficulty in achieving
political stability, having endured 18 coups or attempted coups since
receiving independence from France in 1975. Most recently, in August
1997, the islands of Anjouan and Moheli declared their independence
from Comoros. An attempt in September 1997 by the government to
reestablish control over the rebellious islands by force failed, and
presently the Organization of African Unity is brokering negotiations
to effect a reconciliation.
@Comoros:Geography
Location: Southern Africa, group of islands in the Mozambique Channel,
about two-thirds of the way between northern Madagascar and northern','7bb411d50fe5f796d01a2b9d0d90c43472ef6af51e7f2c2be7293c1833763aa7','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e219ace0b274c39baa3be0c37d976d23ea8d675a7704775d97e53d5c1f89e63',1990,'MZ','Mozambique','introduction',72,'Geographic coordinates: 12 10 S, 44 15 E
Map references: Africa
Area:
total: 2,170 sq km
land: 2,170 sq km
water: 0 sq km
Area-comparative: slightly more than 12 times the size of Washington,
DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
Climate: tropical marine; rainy season (November to May)
Terrain: volcanic islands, interiors vary from steep mountains to low
hills
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kartala 2,360 m
Natural resources: NEGL
Land use:
arable land: 35%
permanent crops: 10%
permanent pastures: 7%
forests and woodland: 18%
other: 30% (1993 est.)
Irrigated land: NA sq km
Natural hazards: cyclones possible during rainy season (December to
April); Mount Kartala on Grand Comore is an active volcano
Environment-current issues: soil degradation and erosion results from
crop cultivation on slopes without proper terracing; deforestation
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected agreements
Geography-note: important location at northern end of Mozambique
Channel
@Comoros:People
Population: 545,528 (July 1998 est.)
Age structure:
0-14 years: 43% (male 116,345; female 115,886)
15-64 years: 54% (male 146,655; female 150,612)
65 years and over: 3% (male 7,644; female 8,386) (July 1998 est.)
Population growth rate: 3.1% (1998 est.)
Birth rate: 40.52 births/1,000 population (1998 est.)
Death rate: 9.52 deaths/1,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.91 male(s)/female (1998 est.)
Infant mortality rate: 84.54 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 60.36 years
male: 57.95 years
female: 62.84 years (1998 est.)
Total fertility rate: 5.48 children born/woman (1998 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha, Sakalava
Religions: Sunni Muslim 86%, Roman Catholic 14%
Languages: Arabic (official), French (official), Comoran (a blend of
Swahili and Arabic)
Literacy:
definition: age 15 and over can read and write
total population: 57.3%
male: 64.2%
female: 50.4% (1995 est.)
@Comoros:Government
Country name:
conventional long form: Federal Islamic Republic of the Comoros
conventional short form: Comoros
local long form: Republique Federale Islamique des Comores
local short form: Comores
Data code: CN
Government type: independent republic
National capital: Moroni
Administrative divisions: three islands; Grande Comore (Njazidja),
Anjouan (Nzwani), and Moheli (Mwali)
note: there are also four municipalities named Domoni, Fomboni,
Moroni, and Mutsamudu
Independence: 6 July 1975 (from France)
National holiday: Independence Day, 6 July (1975)
Constitution: 20 October 1996
Legal system: French and Muslim law in a new consolidated code
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Mohamed TAKI Abdulkarim (since 16 March
1996)
head of government: Prime Minister Nourdine BOURHANE (since 6 December
1997)
cabinet: Council of Ministers appointed by the president
elections: president elected by popular vote to a five-year term;
election last held 16 March 1996 (next to be held NA March 2001);
prime minister appointed by the president
election results: Mohamed TAKI Abdulkarim elected president; share of
vote-64%
Legislative branch: bicameral legislature consists of the Senate (15
seats; members selected by regional councils for six-year terms) and a
Federal Assembly or Assemblee Federale (43 seats; members elected by
popular vote to serve four-year terms)
elections: last held 1 and 8 December 1996 (next to be held NA
December 2000)
election results: percent of vote by party-NA; seats by party-RND 39,
RND candidate running as independent 1, FNJ 3
Judicial branch: Supreme Court or Cour Supremes, two members are
appointed by the president, two members are elected by the Federal
Assembly, one by the Council of each island, and former presidents of
the republic
Political parties and leaders: Rassemblement National pour le
Development or RND [Mohamed TAKI Abdulkarim], party of the government;
Front National pour la Justice or FNJ, Islamic party in opposition
note: under a new constitution ratified in October 1996, a two party
system was established; President Mohamed TAKI Abdulkarim called for
all parties to dissolve and join him in creating the RND; the
constitution stipulates that only parties that win six seats in the
Federal Assembly (two from each island) are permitted to be in
opposition, but if no party accomplishes that the second most
successful party will be in opposition; in the elections of December
1996 the FNJ appeared to qualify as opposition
International organization participation: ACCT, ACP, AfDB, AFESD, AL,
CCC, ECA, FAO, FZ, G-77, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF,
InOC, Intelsat (nonsignatory user), IOC, ITU, NAM, OAU, OIC, UN,
UNCTAD, UNESCO, UNIDO, UPU, WHO, WMO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Ahmed DJABIR (ambassador to the US and
Canada and permanent representative to the UN)
chancery: (temporary) care of the Permanent Mission of the Federal and
Islamic Republic of the Comoros to the United Nations, 336 East 45th
Street, 2nd Floor, New York, NY 10017
telephone: [1] (212) 972-8010
Diplomatic representation from the US: the US does not have an embassy
in Comoros; the ambassador to Mauritius is accredited to Comoros
Flag description: green with a white crescent in the center of the
field, its points facing downward; there are four white five-pointed
stars placed in a line between the points of the crescent; the
crescent, stars, and color green are traditional symbols of Islam; the
four stars represent the four main islands of the archipelago - Mwali,
Njazidja, Nzwani, and Mayotte (a territorial collectivity of France,
but claimed by Comoros); the design, the most recent of several, is
described in the constitution approved by referendum on 7 June 1992
@Comoros:Economy
Economy-overview: One of the world''s poorest countries, Comoros is
made up of three islands that have inadequate transportation links, a
young and rapidly increasing population, and few natural resources.
The low educational level of the labor force contributes to a
subsistence level of economic activity, high unemployment, and a heavy
dependence on foreign grants and technical assistance. Agriculture,
including fishing, hunting, and forestry, is the leading sector of the
economy. It contributes 40% to GDP, employs 80% of the labor force,
and provides most of the exports. The country is not self-sufficient
in food production; rice, the main staple, accounts for the bulk of
imports. The government is struggling to upgrade education and
technical training, to privatize commercial and industrial
enterprises, to improve health services, to diversify exports, to
promote tourism, and to reduce the high population growth rate.
Continued foreign support is essential if the goal of 4% annual GDP
growth is to be maintained in the late 1990s.
GDP: purchasing power parity-$400 million (1997 est.)
GDP-real growth rate: 3.5% (1997 est.)
GDP-per capita: purchasing power parity-$685 (1997 est.)
GDP-composition by sector:
agriculture: 40%
industry: 14%
services: 46% (1996 est.)
Inflation rate-consumer price index: 3.5% (1996 est.)
Labor force:
total: 144,500 (1996 est.)
by occupation: agriculture 80%, government 3%
Unemployment rate: 20% (1996 est.)
Budget:
revenues: $55 million
expenditures: $71 million, including capital expenditures of $15
million (1995 est.)
Industries: tourism, perfume distillation, textiles, furniture,
jewelry, construction materials, soft drinks
Industrial production growth rate: -6.5% (1989 est.)
Electricity-capacity: 9,750 kW (1996)
Electricity-production: 31 million kWh (1996)
Electricity-consumption per capita: 38 kWh (1996)
Agriculture-products: vanilla, cloves, perfume essences, copra,
coconuts, bananas, cassava (tapioca)
Exports:
total value: $11.4 million (f.o.b., 1996 est.)
commodities: vanilla, ylang-ylang, cloves, perfume oil, copra
partners: France 54%, Germany 18%, US 18%
Imports:
total value: $70 million (f.o.b., 1996 est.)
commodities: rice and other foodstuffs, consumer goods; petroleum
products, cement, transport equipment
partners: France 60%, South Africa 10%, Kenya 5%, Singapore 4%
Debt-external: $219 million (1996 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Comoran franc (CF) = 100 centimes
Exchange rates: Comoran francs (CF) per US$1-456.27 (January 1998),
437.75 (1997), 383.66 (1996), 374.36 (1995), 416.40 (1994), 283.16
(1993)
note: beginning 12 January 1994, the Comoran franc was devalued to 75
per French franc from 50 per French franc at which it had been fixed
since 1948
Fiscal year: calendar year','43793abd9f3b34966a59e6e8951aeaf573a1f8be21ab69c3e5534f1691a5f754','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8841392477b7bf4157a5cafb1c0e14d40acaed86bb8af9499d827e255c0fd5c',1990,'ER','Eritrea','introduction',96,'Historical perspective: On 29 May 1991, ISAIAS Afworki, secretary
general of the People''s Front for Democracy and Justice (PFDJ), which
then served as the country''s legislative body, announced the formation
of the Provisional Government in Eritrea (PGE) in preparation for the
23-25 April 1993 referendum on independence for the Autonomous Region
of Eritrea; the referendum resulted in a landslide vote for
independence, which was proclaimed on 27 April 1993.
@Eritrea:Geography
Location: Eastern Africa, bordering the Red Sea, between Djibouti and','09b38af8f8cc9e5408f861c8d1504d182fb70bab8c1071a0b3fe72c89d32de55','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8750fa3494792a82de153dfd0ad2f61d526b65562044cec4f841f00108e4a424',1990,'SD','Sudan','introduction',97,'Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
Area-comparative: slightly larger than Pennsylvania
Land boundaries:
total: 1,630 km
border countries: Djibouti 113 km, Ethiopia 912 km, Sudan 605 km
Coastline: 2,234 km total; mainland on Red Sea 1,151 km, islands in
Red Sea 1,083 km
Maritime claims: NA
Climate: hot, dry desert strip along Red Sea coast; cooler and wetter
in the central highlands (up to 61 cm of rainfall annually); semiarid
in western hills and lowlands; rainfall heaviest during June-September
except on coastal desert
Terrain: dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
Elevation extremes:
lowest point: Kobar Sink -75 m
highest point: Soira 3,013 m
Natural resources: gold, potash, zinc, copper, salt, probably oil and
natural gas (petroleum geologists are prospecting for it), fish
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 48%
forests and woodland: 20%
other: 19% (1993 est.)
Irrigated land: 280 sq km (1993 est.)
Natural hazards: frequent droughts
Environment-current issues: deforestation; desertification; soil
erosion; overgrazing; loss of infrastructure from civil warfare
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species
signed, but not ratified: none of the selected agreements
Geography-note: strategic geopolitical position along world''s busiest
shipping lanes; Eritrea retained the entire coastline of Ethiopia
along the Red Sea upon de jure independence from Ethiopia on 27 April
1993
@Eritrea:People
Population: 3,842,436 (July 1998 est.)
Age structure:
0-14 years: 43% (male 826,686; female 818,323)
15-64 years: 54% (male 1,026,922; female 1,042,156)
65 years and over: 3% (male 66,222; female 62,127) (July 1998 est.)
Population growth rate: 3.39% (1998 est.)
Birth rate: 42.52 births/1,000 population (1998 est.)
Death rate: 12.57 deaths/1,000 population (1998 est.)
Net migration rate: 3.9 migrant(s)/1,000 population (1998 est.)
note: it is estimated that between 200,000 and 350,000 Eritrean
refugees were still living in Sudan in mid-1997
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 1.06 male(s)/female (1998 est.)
Infant mortality rate: 78.51 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 55.31 years
male: 53.19 years
female: 57.51 years (1998 est.)
Total fertility rate: 5.99 children born/woman (1998 est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and Kunama 40%, Afar 4%,
Saho (Red Sea coast dwellers) 3%
Religions: Muslim, Coptic Christian, Roman Catholic, Protestant
Languages: Afar, Amharic, Arabic, Tigre and Kunama, Tigrinya, minor
ethnic group languages
Literacy: NA
@Eritrea:Government
Country name:
conventional long form: State of Eritrea
conventional short form: Eritrea
local long form: Hagere Ertra
local short form: Ertra
former: Eritrea Autonomous Region in Ethiopia
Data code: ER
Government type: transitional government
note: following a successful referendum on independence for the
Autonomous Region of Eritrea on 23-25 April 1993, a National Assembly,
composed entirely of the Peoples'' Front for Democracy and Justice or
PFDJ, was established as a transitional legislature; a Constitutional
Commission was also established to draft a constitution; ISAIAS
Afworki was elected president by the transitional legislature
National capital: Asmara (formerly Asmera)
Administrative divisions: 8 provinces (singular-awraja); Akele Guzay,
Barka, Denkel, Hamasen, Sahil, Semhar, Senhit, Seraye
note: in May 1995 the National Assembly adopted a resolution stating
that the administrative structure of Eritrea, which had been
established by former colonial powers, would consist of only six
provinces when the new constitution, then being drafted, would go into
effect some time in 1998; the new provinces, the names of which had
not been recommended by the US Board on Geographic Names for
recognition by the US government, pending acceptable definition of the
boundaries, were: Anseba, Debub, Debubawi Keyih Bahri, Gash-Barka,
Maakel, and Semanawi Keyih Bahri; more recently, it has been reported
that these provinces have been redesignated regions and renamed
Southern Red Sea, Northern Red Sea, Anseba, Gash-Barka, Southern, and
Central
Independence: 27 May 1993 (from Ethiopia; formerly the Eritrea
Autonomous Region)
National holiday: National Day (independence from Ethiopia), 24 May
(1993)
Constitution: the transitional constitution, decreed on 19 May 1993,
was replaced by a new constitution that was promulgated in May 1997
Legal system: NA
Suffrage: NA; note-the transitional constitution of 19 May 1993 did
not provide rules for suffrage, but it seems likely that the final
version of the constitution, which may be promulgated some time in
1998, will follow the example set in the referendum of 1993 and extend
suffrage to all persons 18 years of age or older
Executive branch:
chief of state: President ISAIAS Afworki (since 8 June 1993); note-the
president is both the chief of state and head of government
head of government: President ISAIAS Afworki (since 8 June 1993);
note-the president is both the chief of state and head of government
cabinet: State Council is the collective executive authority
note: the president is head of the State Council and National Assembly
elections: president elected by the National Assembly; election last
held 8 June 1993 (next to be held NA)
election results: ISAIAS Afworki elected president; percent of
National Assembly vote - ISAIAS Afworki 95%
Legislative branch: unicameral National Assembly (150 seats; term
limits not established)
elections: in May 1997, following the adoption of the new
constitution, 75 members of the PFDJ Central Committee (the old
Central Committee of the EPLF), 60 members of the 527-member
Constituent Assembly which had been established in 1997 to discuss and
ratify the new constitution, and 15 representatives of Eritreans
living abroad were formed into a Transitional National Assembly to
serve as the country''s legislative body until country-wide elections
to a National Assembly are held in 1998; only 75 members will be
elected to the National Assembly-the other 75 will be members of the
Central Committee of the PFDJ
Judicial branch: Judiciary the Supreme Court; 10 provincial courts; 29
district courts
Political parties and leaders: People''s Front for Democracy and
Justice or PFDJ, the only party recognized by the government [ISAIAS
Afworki, PETROS Solomon]
Political pressure groups and leaders: Eritrean Islamic Jihad or EIJ;
Eritrean Liberation Front or ELF [ABDULLAH Muhammed]; Eritrean
Liberation Front-United Organization or ELF-UO [Mohammed Said NAWUD];
Eritrean Liberation Front-Revolutionary Council or ELF-RC [Ahmed
NASSER]
International organization participation: ACP, AfDB, CCC, ECA, FAO,
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, IGAD, ILO, IMF, IMO, Intelsat
(nonsignatory user), ITU, NAM, OAU, UN, UNCTAD, UNESCO, UNIDO, UPU,
WFTU, WHO, WIPO, WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador Semere RUSSOM
chancery: 1708 New Hampshire Avenue NW, Washington, DC 20009
telephone: [1] (202) 319-1991
FAX: [1] (202) 319-1304
Diplomatic representation from the US:
chief of mission: Ambassador-designate William CLARK
embassy: Franklin D. Roosevelt Street, Asmara
mailing address: P.O. Box 211, Asmara
telephone: [291] (1) 120004
FAX: [291] (1) 127584
Flag description: red isosceles triangle (based on the hoist side)
dividing the flag into two right triangles; the upper triangle is
green, the lower one is blue; a gold wreath encircling a gold olive
branch is centered on the hoist side of the red triangle
@Eritrea:Economy
Economy-overview: With independence from Ethiopia on 27 April 1993,
Eritrea faced the bitter economic problems of a small, desperately
poor African country. The economy is largely based on subsistence
agriculture, with over 70% of the population involved in farming and
herding. The small industrial sector consists mainly of light
industries with outmoded technologies. Domestic output (GDP) is
substantially augmented by worker remittances from abroad. Government
revenues come from custom duties and taxes on income and sales. Road
construction is a top domestic priority. Eritrea has inherited the
entire coastline of Ethiopia and has long-term prospects for revenues
from the development of offshore oil fields, offshore fishing, and
tourism. Eritrea''s economic future depends on its ability to master
fundamental social and economic problems, e.g., overcoming illiteracy,
promoting job creation, expanding technical training, attracting
foreign investment, and streamlining the bureaucracy.
GDP: purchasing power parity-$2.2 billion (1996 est.)
GDP-real growth rate: 6.8% (1996 est.)
GDP-per capita: purchasing power parity-$600 (1996 est.)
GDP-composition by sector:
agriculture: 18%
industry: 20%
services: 62% (1995 est.)
Inflation rate-consumer price index: 4% (1997 est.)
Labor force: NA
Unemployment rate: NA%
Budget:
revenues: $226 million
expenditures: $453 million, including capital expenditures of $88
million (1996 est.)
Industries: food processing, beverages, clothing and textiles
Industrial production growth rate: NA%
Electricity-capacity: 73,000 kW (1995)
Electricity-production: NA kWh
Electricity-consumption per capita: NA kWh
Agriculture-products: sorghum, lentils, vegetables, maize, cotton,
tobacco, coffee, sisal (for making rope); livestock (including goats);
fish
Exports:
total value: $71 million (1996 est.)
commodities: livestock, sorghum, textiles, food, small manufactures
partners: Ethiopia 67%, Sudan 10%, Saudi Arabia 4%, US 3%, Italy,
Yemen (1996)
Imports:
total value: $499 million (1996 est.)
commodities: processed goods, machinery, petroleum products
partners: Ethiopia, Saudi Arabia, Italy, United Arab Emirates
Debt-external: $162 million (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 nafka = 100 cents
Exchange rates: nakfa per US$1 = 7.2 (March 1998 est.)
note: following independence from Ethiopia, Eritrea continued to use
Ethiopian currency until late in 1997 when Eritrea issued its own
currency, the nakfa, at approximately the same rate as the birr, i.e.,
7.2 nakfa per US$1
Fiscal year: calendar year','14259dce2ef65cb1117a92ccb1bd535a6aebac8a2bf8bedc05c0f8d69e25cbd5','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5113b97f80e15c215414f835c506cc5227e95491a65f0eee41cd4c12cb64fe4b',1990,'ET','Ethiopia','introduction',100,'Historical perspective: On 28 May 1991 the Ethiopian People''s
Revolutionary Democratic Front (EPRDF) toppled the authoritarian
government of MENGISTU Haile-Mariam and took control in Addis Ababa; a
new constitution was promulgated in December 1994 and national and
regional popular elections were held in May and June 1995.
@Ethiopia:Geography
Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Area-comparative: slightly less than twice the size of Texas
Land boundaries:
total: 5,311 km
border countries: Djibouti 337 km, Eritrea 912 km, Kenya 830 km,
Somalia 1,626 km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide topographic-induced variation
Terrain: high plateau with central mountain range divided by Great
Rift Valley
Elevation extremes:
lowest point: Denakil -125 m
highest point: Ras Dashen Terara 4,620 m
Natural resources: small reserves of gold, platinum, copper, potash,
natural gas
Land use:
arable land: 12%
permanent crops: 1%
permanent pastures: 40%
forests and woodland: 25%
other: 22% (1993 est.)
Irrigated land: 1,900 sq km (1993 est.)
Natural hazards: geologically active Great Rift Valley susceptible to
earthquakes, volcanic eruptions; frequent droughts
Environment-current issues: deforestation; overgrazing; soil erosion;
desertification
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Ozone Layer Protection
signed, but not ratified: Environmental Modification, Law of the Sea,
Nuclear Test Ban
Geography-note: landlocked-entire coastline along the Red Sea was lost
with the de jure independence of Eritrea on 27 April 1993
@Ethiopia:People
Population: 58,390,351 (July 1998 est.)
Age structure:
0-14 years: 46% (male 13,468,783; female 13,398,500)
15-64 years: 51% (male 15,095,357; female 14,812,537)
65 years and over: 3% (male 734,471; female 880,703) (July 1998 est.)
Population growth rate: 2.21% (1998 est.)
Birth rate: 44.69 births/1,000 population (1998 est.)
Death rate: 21.25 deaths/1,000 population (1998 est.)
Net migration rate: -1.33 migrant(s)/1,000 population (1998 est.)
note: repatriation of Ethiopians who fled to Sudan, Kenya, and Somalia
for refuge from war and famine in earlier years, is expected to
continue slowly in 1998; small numbers of Sudanese and Somali
refugees, who fled to Ethiopia from the fighting in their own
countries, began returning to their homes in 1998
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.83 male(s)/female (1998 est.)
Infant mortality rate: 125.65 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 40.85 years
male: 39.76 years
female: 41.97 years (1998 est.)
Total fertility rate: 6.88 children born/woman (1998 est.)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigrean 32%, Sidamo 9%, Shankella
6%, Somali 6%, Afar 4%, Gurage 2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox 35%-40%, animist 12%,
other 3%-8%
Languages: Amharic (official), Tigrinya, Orominga, Guaraginga, Somali,
Arabic, English (major foreign language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 35.5%
male: 45.5%
female: 25.3% (1995 est.)
@Ethiopia:Government
Country name:
conventional long form: Federal Democratic Republic of Ethiopia
conventional short form: Ethiopia
local long form: YeItyop''iya Federalawi Demokrasiyawi Ripeblik
local short form: YeItyop''iya
abbreviation: FDRE
Data code: ET
Government type: federal republic
National capital: Addis Ababa
Administrative divisions: 9 ethnically-based administrative regions
(astedader akababiwach, singular - astedader akababi) and 1 federal
capital*: Addis Ababa*; Afar; Amhara; Benishangul/Gumaz; Gambela;
Harar; Oromia; Somali; Southern Nations, Nationalities and Peoples;
Tigray
Independence: oldest independent country in Africa and one of the
oldest in the world - at least 2,000 years
National holiday: National Day, 28 May (1991) (defeat of Mengistu
regime)
Constitution: promulgated December 1994
Legal system: NA
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President NEGASSO Gidada (since 22 August 1995)
head of government: Prime Minister MELES Zenawi (since August 1995)
cabinet: Council of Ministers as provided in the December 1994
constitution; ministers are selected by the prime minister and
approved by the Council of People''s Representatives
elections: president elected by the Council of People''s
Representatives for a six-year term; election last held June 1995
(next to be held NA 2001); prime minister designated by the party in
power following legislative elections
election results: NEGASSO Gidada elected president; percent of vote by
the Council of People''s Representatives-NA
Legislative branch: bicameral Parliament consists of the Council of
the Federation or upper chamber (117 seats; members are chosen by
state assemblies to serve five-year terms) and the Council of People''s
Representatives or lower chamber (548 seats; members are directly
elected by popular vote from single-member districts to serve
five-year terms); note-the upper chamber represents the ethnic
interests of the regional governments
elections: regional and national popular elections were held in May
and June 1995 (next to be held NA 2000) and the Federal Parliamentary
Assembly assumed legislative power on 21 August 1995
election results: percent of vote-NA; seats-NA; note-EPRDF won nearly
all seats
Judicial branch: Supreme Court, judges are elected by the national
legislature
Political parties and leaders: Ethiopian People''s Revolutionary
Democratic Front or EPRDF [MELES Zenawi]
Political pressure groups and leaders: Oromo Liberation Front or OLF;
All Amhara People''s Organization; Southern Ethiopia People''s
Democratic Coalition; numerous small, ethnic-based groups have formed
since MENGISTU''S defeat, including several Islamic militant groups
International organization participation: ACP, AfDB, CCC, ECA, FAO,
G-24, G-77, IAEA, IBRD, ICAO, ICRM, IDA, IFAD, IFC, IFRCS, IGAD, ILO,
IMF, IMO, Intelsat, Interpol, IOC, ISO, ITU, NAM, OAU, UN, UNCTAD,
UNESCO, UNHCR, UNIDO, UNU, UPU, WFTU, WHO, WMO, WToO, WTrO (observer)
Diplomatic representation in the US:
chief of mission: Ambassador BERHANE Gebre-Christos
chancery: 2134 Kalorama Road NW, Washington, DC 20008
telephone: [1] (202) 234-2281, 2282
FAX: [1] (202) 328-7950
Diplomatic representation from the US:
chief of mission: Ambassador David H. SHINN
embassy: Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 550666
FAX: [251] (1) 552191
Flag description: three equal horizontal bands of green (top), yellow,
and red with a yellow pentagram and single yellow rays emanating from
the angles between the points on a light blue disk centered on the
three bands; Ethiopia is the oldest independent country in Africa, and
the colors of her flag were so often adopted by other African
countries upon independence that they became known as the pan-African
colors
@Ethiopia:Economy
Economy-overview: Ethiopia remains one of the poorest and least
developed countries in the world. Its economy is based on agriculture,
which accounts for more than half of GDP, 90% of exports, and 80% of
total employment; coffee generates 60% of export earnings. The
agricultural sector suffers from frequent periods of drought, poor
cultivation practices, and deterioration of internal security
conditions. The manufacturing sector is heavily dependent on inputs
from the agricultural sector. Over 90% of large-scale industry, but
less than 10% of agriculture, is state-run. The government is
considering selling off a portion of state-owned plants and is
implementing reform measures that are gradually liberalizing the
economy. A major medium-term problem is the improvement of roads,
water supply, and other parts of an infrastructure badly neglected
during years of civil strife.
GDP: purchasing power parity-$29 billion (1997 est.)
GDP-real growth rate: 5% (1997 est.)
GDP-per capita: purchasing power parity-$530 (1997 est.)
GDP-composition by sector:
agriculture: 55%
industry: 12%
services: 33% (1995 est.)
Inflation rate-consumer price index: 0% (1996 est.)
Labor force:
total: NA
by occupation: agriculture and animal husbandry 80%, government and
services 12%, industry and construction 8% (1985)
Unemployment rate: NA%
Budget:
revenues: $1 billion
expenditures: $1.48 billion, including capital expenditures of $415
million (FY96/97)
Industries: food processing, beverages, textiles, chemicals, metals
processing, cement
Industrial production growth rate: NA%
Electricity-capacity: 464,000 kW (1995)
Electricity-production: 1.143 billion kWh (1995)
Electricity-consumption per capita: 20 kWh (1995)
Agriculture-products: cereals, pulses, coffee, oilseed, sugarcane,
potatoes, other vegetables; hides, cattle, sheep, goats
Exports:
total value: $418 million (f.o.b., 1996)
commodities: coffee, leather products, gold (1995)
partners: Germany 32%, Japan 14%, Djibouti 7%, Saudi Arabia 8%, Italy
8% (1994)
Imports:
total value: $1.23 billion (f.o.b., 1996 est.)
commodities: food and live animals, petroleum and petroleum products,
chemicals, machinery, motor vehicles and aircraft (1994)
partners: Saudi Arabia 15%, Italy 11%, US 12.3%, Germany 8% (1994)
Debt-external: $5.2 billion (1995)
Economic aid:
recipient: ODA, $367 million (FY95/96)
Currency: 1 birr (Br) = 100 cents
Exchange rates: birr (Br) per US$1 (end of period)-6.9530 (February
1998), 6.8080 (September 1997), 6.4260 (1996), 6.3200 (1995), 5.9500
(1994), 5.0000 (fixed rate 1992-93)
note: since May 1993, the birr market rate has been determined in an
interbank market supported by weekly wholesale auction; prior to that
date, the official rate was pegged to US$1 = 5.000 birr
Fiscal year: 8 July-7 July','6db50e9cb044b902a07f09a814518a6a411932818586edd15457f2922a012fd5','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bd6c2a516d9654fcfc262d565284f6a634e87be80b4ce33e68657c9ac838c3c',1990,'ID','Indonesia','introduction',111,'Current issues: The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements ("the DOP"), signed in Washington on 13
September 1993, provides for a transitional period not exceeding five
years of Palestinian interim self-government in the Gaza Strip and the
West Bank. Permanent status negotiations began on 5 May 1996, but have
not resumed since the initial meeting. Under the DOP, Israel agreed to
transfer certain powers and responsibilities to the Palestinian
Authority, which includes a Palestinian Legislative Council elected in
January 1996, as part of interim self-governing arrangements in the
West Bank and Gaza Strip. A transfer of powers and responsibilities
for the Gaza Strip and Jericho took place pursuant to the Israel-PLO 4
May 1994 Cairo Agreement on the Gaza Strip and the Jericho Area and in
additional areas of the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement and the Israel-PLO 15 January 1997
Protocol Concerning Redeployment in Hebron. The DOP provides that
Israel will retain responsibility during the transitional period for
external security and for internal security and public order of
settlements and Israelis. Permanent status is to be determined through
direct negotiations.
@Gaza Strip:Geography
Location: Middle East, bordering the Mediterranean Sea, between Egypt
and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area:
total: 360 sq km
land: 360 sq km
water: 0 sq km
Area-comparative: slightly more than twice the size of Washington, DC
Land boundaries:
total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement-permanent status to be
determined through further negotiation
Climate: temperate, mild winters, dry and warm to hot summers
Terrain: flat to rolling, sand- and dune-covered coastal plain
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Abu ''Awdah (Joz Abu ''Auda) 105 m
Natural resources: NEGL
Land use:
arable land: 24%
permanent crops: 39%
permanent pastures: 0%
forests and woodland: 11%
other: 26% (1993 est.)
Irrigated land: 120 sq km (1993 est.)
Natural hazards: NA
Environment-current issues: desertification; salination of fresh
water; sewage treatment
Environment-international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography-note: there are 24 Israeli settlements and civilian land use
sites in the Gaza Strip (August 1997 est.)
@Gaza Strip:People
Population: 1,054,173 (July 1998 est.)
note: in addition, there are 6,000 Israeli settlers in the Gaza Strip
(August 1997 est.)
Age structure:
0-14 years: 52% (male 278,551; female 265,009)
15-64 years: 46% (male 241,420; female 238,857)
65 years and over: 2% (male 12,966; female 17,370) (July 1998 est.)
Population growth rate: 6.4% (1998 est.)
Birth rate: 49.07 births/1,000 population (1998 est.)
Death rate: 4 deaths/1,000 population (1998 est.)
Net migration rate: 18.97 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.75 male(s)/female (1998 est.)
Infant mortality rate: 24.45 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 72.95 years
male: 71.56 years
female: 74.4 years (1998 est.)
Total fertility rate: 7.57 children born/woman (1998 est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%, Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%, Christian 0.7%, Jewish
0.6%
Languages: Arabic, Hebrew (spoken by Israeli settlers and many
Palestinians), English (widely understood)
Literacy: NA
@Gaza Strip:Government
Country name:
conventional long form: none
conventional short form: Gaza Strip
local long form: none
local short form: Qita Ghazzah
Data code: GZ
@Gaza Strip:Economy
Economy-overview: Economic progress in the Gaza Strip has been
hampered by tight Israeli security restrictions. In 1991 roughly 40%
of Gaza Strip workers were employed across the border by Israeli
industrial, construction, and agricultural enterprises, with worker
remittances supplementing GDP by roughly 50%. Gaza has depended upon
Israel for nearly 90% of its external trade. The Persian Gulf crisis
and its aftershocks have dealt blows to Gaza since August 1990. Worker
remittances from the Gulf states have dropped, unemployment and
popular unrest have increased, and living standards have fallen. The
redeployment of Israeli forces in the Gaza Strip in May 1994 has added
to the set of adjustment problems. This series of disruptions has
meant a sharp decline in employment in Israel since 1991 and a drop in
GDP as a whole. An estimated 378,000 persons were in refugee camps in
1996.
GDP: purchasing power parity-$1 billion (1996 est.)
GDP-real growth rate: -6.9% (1996 est.)
GDP-per capita: purchasing power parity-$1,100 (1996 est.)
GDP-composition by sector:
agriculture: 33%
industry: 25%
services: 42% (1995 est., includes West Bank)
Inflation rate-consumer price index: 8.4% (1996 est.)
Labor force: NA
by occupation: services 66%, industry 21%, agriculture 13% (1996)
note: excluding Israeli settlers
Unemployment rate: 28% (1997 est.)
Budget:
revenues: $684 million
expenditures: $779 million, including capital expenditures of $NA
(1996)
note: includes West Bank
Industries: generally small family businesses that produce textiles,
soap, olive-wood carvings, and mother-of-pearl souvenirs; the Israelis
have established some small-scale modern industries in an industrial
center
Industrial production growth rate: NA%
Electricity-capacity: NA kW
note: electricity supplied by Israel
Electricity-production: NA kWh
note: electricity supplied by Israel
Electricity-consumption per capita: NA kWh
Agriculture-products: olives, citrus, other fruits, vegetables; beef,
dairy products
Exports:
total value: $630 million (f.o.b., 1997 est.) (includes West Bank)
commodities: citrus
partners: Israel, Egypt, West Bank
Imports:
total value: $1.7 billion (c.i.f., 1997 est.) (includes West Bank)
commodities: food, consumer goods, construction materials
partners: Israel, Egypt, West Bank
Debt-external: $NA
Economic aid:
recipient: ODA, $NA
Currency: 1 new Israeli shekel (NIS) = 100 new agorot
Exchange rates: new Israeli shekels (NIS) per US$1-3.5340 (December
1997), 3.4494 3.1917 (1996), 3.0113 (1995), 3.0111 (1994), 2.8301
(1993)
Fiscal year: calendar year (since 1 January 1992)','f737416f7ec8864e63bf51a24a785cde60e334181e620b3bbb4d24e3ed9c7f0a','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf8e7e4a74c19816dc8cbfca2b1832ae6753e9ff0184f16f240a3cdc62005e11',1990,'GE','Georgia','introduction',112,'Current issues: Beset by ethnic and civil strife since independence in
1991, Georgia began to stabilize in 1994. Separatist conflicts in
Abkhazia and South Ossetia have been dormant since spring 1994,
although political settlements remain elusive. Russian peacekeepers
are deployed in both regions and a UN Observer Mission is operating in
Abkhazia. As a result of these conflicts, Georgia still has about
250,000 internally displaced people. In 1995, Georgia adopted a new
constitution and conducted generally free and fair nationwide
presidential and parliamentary elections. In 1996, the government
focused its attention to implementing an ambitious economic reform
program and professionalizing its parliament. Violence and organized
crime were sharply curtailed in 1995 and 1996, but corruption remains
rife. In 1997, SHEVARDNADZE succeeded in bringing international
attention to the Abkhazia conflict. The UN sponsored two meetings on
the subject, but a resolution is still far off. Georgia also took some
steps in 1997 to reduce its dependence on Russia, acquiring coastal
patrol boats it hopes to use to replace the current Russian border
units on the Black Sea coast. The year 1997 also saw a sharpening of
rhetoric-especially from parliament-against Russia''s continued
military presence on Georgian territory.
@Georgia:Geography
Location: Southwestern Asia, bordering the Black Sea, between Turkey
and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Commonwealth of Independent States
Area:
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
Area-comparative: slightly smaller than South Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km, Azerbaijan 322 km, Russia 723 km,
Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on Black Sea coast
Terrain: largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhida Lowland
opens to the Black Sea in the west; Mtkvari River Basin in the east;
good soils in river valley flood plains, foothills of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Mqinvartsveri (Gora Kazbek) 5,048 m
Natural resources: forests, hydropower, manganese deposits, iron ore,
copper, minor coal and oil deposits; coastal climate and soils allow
for important tea and citrus growth
Land use:
arable land: 9%
permanent crops: 4%
permanent pastures: 25%
forests and woodland: 34%
other: 28% (1993 est.)
Irrigated land: 4,000 sq km (1993 est.)
Natural hazards: NA
Environment-current issues: air pollution, particularly in Rust''avi;
heavy pollution of Mtkvari River and the Black Sea; inadequate
supplies of potable water; soil pollution from toxic chemicals
Environment-international agreements:
party to: Biodiversity, Climate Change, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: Desertification
@Georgia:People
Population: 5,108,527 (July 1998 est.)
Age structure:
0-14 years: 22% (male 562,623; female 540,378)
15-64 years: 66% (male 1,631,296; female 1,756,087)
65 years and over: 12% (male 235,042; female 383,101) (July 1998 est.)
Population growth rate: -0.92% (1998 est.)
Birth rate: 11.72 births/1,000 population (1998 est.)
Death rate: 14.1 deaths/1,000 population (1998 est.)
Net migration rate: -6.79 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.61 male(s)/female (1998 est.)
Infant mortality rate: 51.07 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 64.79 years
male: 61.36 years
female: 68.4 years (1998 est.)
Total fertility rate: 1.54 children born/woman (1998 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 70.1%, Armenian 8.1%, Russian 6.3%, Azeri
5.7%, Ossetian 3%, Abkhaz 1.8%, other 5%
Religions: Christian Orthodox 75% (Georgian Orthodox 65%, Russian
Orthodox 10%), Muslim 11%, Armenian Apostolic 8%, unknown 6%
Languages: Armenian 7%, Azeri 6%, Georgian 71% (official), Russian 9%,
other 7%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 100%
female: 98% (1989 est.)
@Georgia:Government
Country name:
conventional long form: none
conventional short form: Georgia
local long form: none
local short form: Sak''art''velo
former: Georgian Soviet Socialist Republic
Data code: GG
Government type: republic
National capital: T''bilisi
Administrative divisions: 53 rayons (raionebi, singular-raioni), 9
cities* (k''alak''ebi, singular - k''alak''i), and 2 autonomous
republics** (avtomnoy respubliki, singular - avtom respublika);
Abashis, Abkhazia or Ap''khazet''is Avtonomiuri Respublika** (Sokhumi),
Adigenis, Ajaria or Acharis Avtonomiuri Respublika** (Bat''umi),
Akhalgoris, Akhalk''alak''is, Akhalts''ikhis, Akhmetis, Ambrolauris,
Aspindzis, Baghdat''is, Bolnisis, Borjomis, Chiat''ura*, Ch''khorotsqus,
Ch''okhatauris, Dedop''listsqaros, Dmanisis, Dushet''is, Gardabanis,
Gori*, Goris, Gurjaanis, Javis, K''arelis, Kaspis, Kharagaulis,
Khashuris, Khobis, Khonis, K''ut''aisi*, Lagodekhis, Lanch''khut''is,
Lentekhis, Marneulis, Martvilis, Mestiis, Mts''khet''is, Ninotsmindis,
Onis, Ozurget''is, P''ot''i*, Qazbegis, Qvarlis, Rust''avi*, Sach''kheris,
Sagarejos, Samtrediis, Senakis, Sighnaghis, T''bilisi*, T''elavis,
T''erjolis, T''et''ritsqaros, T''ianet''is, Tqibuli*, Ts''ageris,
Tsalenjikhis, Tsalkis, Tsqaltubo*, Vanis, Zestap''onis, Zugdidi*,
Zugdidis
note: administrative divisions have the same names as their
administrative centers (exceptions have the administrative center name
following in parentheses)
Independence: 9 April 1991 (from Soviet Union)
National holiday: Independence Day, 26 May (1991)
Constitution: adopted 17 October 1995
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Eduard Amvrosiyevich SHEVARDNADZE
(previously elected chairman of the Government Council 10 March 1992,
Council has since been disbanded; previously elected chairman of
Parliament 11 October 1992; elected president 5 November 1995;
inaugurated 26 November 1995); note-the president is both the chief of
state and head of government
head of government: President Eduard Amvrosiyevich SHEVARDNADZE
(previously elected chairman of the Government Council 10 March 1992,
Council has since been disbanded; previously elected chairman of
Parliament 11 October 1992; elected president 5 November 1995);
note-the president is both the chief of state and head of government
cabinet: Cabinet of Ministers
elections: president elected by popular vote for a five-year term;
election last held 5 November 1995 (next to be held NA April 2000)
election results: Eduard SHEVARDNADZE elected president; percent of
vote-Eduard SHEVARDNADZE 74%
Legislative branch: unicameral Supreme Council or Umaghiesi Sabcho
(235 seats; members are elected to serve four-year terms)
elections: last held 5 November 1995 (next to be held NA November
1999)
election results: percent of vote by party-CUG 24%, NDP 8%, AGUR 7%,
all other parties received less than 5% each; seats by party-CUG 107,
NDP 34, AGUR 32, Progress Bloc (DUG, Political Association "Georgian
Proprietors," Political Union of Young Democrats, Solidarity) 4, SPG
4, others 9, Abkazian deputies 12, independents 29, not filled 4
Judicial branch: Supreme Court, judges elected by the Supreme Council
on the president''s recommendation; Constitutional Court
Political parties and leaders: Citizen''s Union of Georgia or CUG
[Eduard SHEVARDNADZE]; National Democratic People''s Party [Mamuka
GIORGADZE]; National Democratic Party or NDP [Irina
SARISHVILI-CHANTARIA]; Union for "Revival" Party or AGUR [Alsan
ABASHIDZE]; Union of Traditionalists or UGT [Akaki ASTANTIANI];
Socialist Party or SPG [Vakhtang RCHEULISHVILI]; Georgian United
Communist Party or UCPG [Panteleimon GIORGADZE, chairman]; Greens
Party [Giorgi GACHECHILADZE]; United Republican Party or URP [Nodar
NATADZE, chairman]; National Independent Party or NIP [Irakli
TSERETELI, chairman]; Social Democratic Party or GSDP [Guram
MUCHAIDZE, secretary general]; Conservative-Monarchist Party or GCMP
[Temur ZHORZHOLIANI]
Political pressure groups and leaders: supporters of ousted President
Zviad GAMSAKHURDIA (deceased 1 January 1994) remain a source of
opposition; separatist elements in the breakaway region of Abkhazia
International organization participation: BSEC, CCC, CE (guest), CIS,
EAPC, EBRD, ECE, FAO, IAEA, IBRD, ICAO, IDA, IFAD, IFC, ILO, IMF, IMO,
Inmarsat, Interpol, IOC, IOM (observer), ITU, OSCE, PFP, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO, WMO, WToO, WTrO (applicant)
Diplomatic representation in the US:
chief of mission: Ambassador Tedo JAPARIDZE
chancery: (temporary) Suite 424, 1511 K Street NW, Washington, DC
20005
telephone: [1] (202) 393-5959
FAX: [1] (202) 393-4537
Diplomatic representation from the US:
chief of mission: Ambassador (vacant)
embassy: #25 Antonelli Street, T''bilisi 380026
mailing address: use embassy street address
telephone: 995-32-989-967 or 995-32-933-803 (operator assisted)
FAX: tie-line FAX 997-0200; 933-759 or 938-951
Flag description: maroon field with small rectangle in upper hoist
side corner; rectangle divided horizontally with black on top, white
below
@Georgia:Economy
Economy-overview: Georgia''s economy has traditionally revolved around
Black Sea tourism; cultivation of citrus fruits, tea, and grapes;
mining of manganese and copper; and output of a small industrial
sector producing wine, metals, machinery, chemicals, and textiles. The
country imports the bulk of its energy needs, including natural gas
and oil products. Its only sizable internal energy resource is
hydropower. Despite the severe damage the economy has suffered due to
civil strife, Georgia, with the help of the IMF and World Bank, has
made substantial economic gains in 1995-97, increasing GDP growth and
slashing inflation. Georgia still suffers from energy shortages,
although energy deliveries are steadily improving. Georgia is pinning
its hopes for long-term recovery on the development of an
international transportation corridor through the key Black Sea ports
of P''ot''i and Bat''umi. The construction of a Caspian oil pipeline
through Georgia-scheduled to open in early 1999-should spur greater
western investment in the economy. A growing trade deficit, continuing
problems with corruption, and political uncertainties cloud the
short-term economic picture.
GDP: purchasing power parity-$8.1 billion (1997 est.)
GDP-real growth rate: 11.8% (1997 est.)
GDP-per capita: purchasing power parity-$1,570 (1997 est.)
GDP-composition by sector:
agriculture: 29%
industry: 16%
services: 55% (1997 est.)
Inflation rate-consumer price index: 7.1% (1997 est.)
Labor force:
total: 2.2 million (1996)
by occupation: industry and construction 31%, agriculture and forestry
25%, other 44% (1990)
Unemployment rate: 16% (1996 est.)
Budget:
revenues: $441 million
expenditures: $606 million, including capital expenditures of $54
million (1996 est.)
Industries: steel, aircraft, machine tools, foundry equipment,
electric locomotives, tower cranes, electric welding equipment,
machinery for food preparation and meat packing, electric motors,
process control equipment, trucks, tractors, textiles, shoes,
chemicals, wood products, wine
Industrial production growth rate: 8.1% (1997 est.)
Electricity-capacity: 4.558 million kW (1995)
Electricity-production: 7.1 billion kWh (1996)
Electricity-consumption per capita: 1,175 kWh (1995)
Agriculture-products: citrus, grapes, tea, vegetables, potatoes; small
livestock sector
Exports:
total value: $400 million (f.o.b., 1996 est.)
commodities: citrus fruits, tea, wine, other agricultural products;
diverse types of machinery; ferrous and nonferrous metals; textiles;
chemicals; fuel re-exports
partners: Russia, Turkey, Armenia, Azerbaijan, Bulgaria (1996)
Imports:
total value: $733 million (c.i.f., 1996 est.)
commodities: fuel, grain and other foods, machinery and parts,
transport equipment
partners: Russia, Turkey, Azerbaijan (1996); note-EU and US send
humanitarian food shipments
Debt-external: $1.3 billion (1996 est.)
Economic aid:
recipient: ODA, $28 million (1993)
note: commitments, 1992-95, $1,200 million ($675 million
disbursements)
Currency: lari introduced September 1995 replacing the coupon
Exchange rates: lari per US$1 (end of period)-1.32 (December 1997),
1.28 (December 1996), 1.24 (December 1995)
Fiscal year: calendar year','6b9b224f6eaa33bdaa1658eabbf5605e7729d7a110fc0faa31a2b44d844f6c5e','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ac14384b5860ce18cc0eb759dc79f8a039083d8d4b1e51e6c1be4473e3167af',1990,'HK','Hong Kong','introduction',133,'Current issues: Pursuant to the agreement signed by China and the UK
on 19 December 1984, Hong Kong became a special administrative region
of China on 1 July 1997. Under the terms of this agreement, China has
promised that Hong Kong shall enjoy a high degree of autonomy in all
matters except foreign and defense affairs.
@Hong Kong:Geography
Location: Eastern Asia, bordering the South China Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total: 1,092 sq km
land: 1,042 sq km
water: 50 sq km
Area-comparative: six times the size of Washington, DC
Land boundaries:
total: 30 km
border countries: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3 nm
Climate: tropical monsoon; cool and humid in winter, hot and rainy
from spring through summer, warm and sunny in fall
Terrain: hilly to mountainous with steep slopes; lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater harbor, feldspar
Land use:
arable land: 6%
permanent crops: 1%
permanent pastures: 1%
forests and woodland: 22%
other: 70% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: occasional typhoons
Environment-current issues: air and water pollution from rapid
urbanization
Environment-international agreements:
party to: NA
signed, but not ratified: NA
Geography-note: more than 200 islands
@Hong Kong:People
Population: 6,706,965 (July 1998 est.)
Age structure:
0-14 years: 18% (male 637,808; female 591,900)
15-64 years: 71% (male 2,360,878; female 2,425,291)
65 years and over: 11% (male 312,033; female 379,055) (July 1998 est.)
Population growth rate: 2.24% (1998 est.)
Birth rate: 12.85 births/1,000 population (1998 est.)
Death rate: 5.87 deaths/1,000 population (1998 est.)
Net migration rate: 15.41 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.08 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.82 male(s)/female (1998 est.)
Infant mortality rate: 5.24 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 78.81 years
male: 76.07 years
female: 81.74 years (1998 est.)
Total fertility rate: 1.36 children born/woman (1998 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%, Christian 10%
Languages: Chinese (Cantonese), English
Literacy:
definition: age 15 and over has ever attended school
total population: 92.2%
male: 96%
female: 88.2% (1996 est.)
@Hong Kong:Government
Country name:
conventional long form: Hong Kong Special Administrative Region
conventional short form: Hong Kong
local long form: Xianggang Tebie Xingzhengqu
local short form: Xianggang
abbreviation: HK
Data code: HK
Dependency status: special administrative region of China
Government type: NA
National capital: Victoria
Administrative divisions: none (special administrative region of
China)
Independence: none (special administrative region of China)
National holiday: National Day, 1-2 October
note: 1 July 1997 is celebrated as Hong Kong Special Administrative
Region Establishment Day
Constitution: Basic Law approved in March 1990 by China''s National
People''s Congress is Hong Kong''s "mini-constitution"
Legal system: based on English common law
Suffrage: direct election 18 years of age; universal for permanent
residents living in the territory of Hong Kong for the past seven
years; indirect election limited to about 100,000 members of
functional constituencies and an 800-member Election Commission drawn
from broad regional groupings and other central government bodies
Executive branch:
chief of state: President of China JIANG Zemin (since 27 March 1993)
head of government: Chief Executive TUNG Chee-hwa (since 1 July 1997)
cabinet: Executive Council consists of three ex-officio members and 10
appointed members; ex-officio members are: Chief Secretary Anson CHAN
(since 29 November 1993), Financial Secretary Donald TSANG (since NA
1995), and Secretary of Justice Elsie LEUNG (since NA 1997)
elections: NA
Legislative branch: a provisional legislature replaced the unicameral
Legislative Council or LEGCO (60 seats; 30 indirectly elected by
functional constituencies, 20 elected by popular vote, and 10 elected
by election committee; members served four-year terms) on 1 July 1997
elections: indirect and direct elections for the Legislative Council
were last held on 17 September 1995; elections for the first Special
Administrative Region Legislative Council are scheduled to be held in
May 1998
election results: the following are results of the 1995 election of
the Legislative Council - percent of vote by party-NA; seats by
party-Democratic Party 21, Liberal Party 10, Democratic Alliance for
the Betterment of Hong Kong 6, other parties and independents 23
Judicial branch: Supreme Court
Political parties and leaders: Democratic Party, Martin LEE, chairman;
Liberal Party, Allen LEE, chairman; Democratic Alliance for the
Betterment of Hong Kong, TSANG Yuk-shing, chairman; Hong Kong
Democratic Foundation, Dr. Patrick SHIU Kin-ying, chairman; The
Frontier, Emily LAN Wai-hang, chairwoman
Political pressure groups and leaders: Association for Democracy and
People''s Livelihood (ADPL), Frederick FUNG Kin Kee, chairman; Liberal
Democratic Federation, HU Fa-kuang, chairman; Federation of Trade
Unions (pro-China), LEE Chark-tim, president; Hong Kong and Kowloon
Trade Union Council (pro-Taiwan); Confederation of Trade Unions
(pro-democracy), LEE Cheuk-yan, chairman; Hong Kong General Chamber of
Commerce; Chinese General Chamber of Commerce (pro-China); Federation
of Hong Kong Industries; Chinese Manufacturers'' Association of Hong
Kong; Hong Kong Professional Teachers'' Union, CHEUNG Man-kwong,
president; Hong Kong Alliance in Support of the Patriotic Democratic
Movement in China, Szeto WAH, chairman
International organization participation: APEC, AsDB, BIS (pending
member), CCC, ESCAP (associate), ICFTU, IMO (associate), Interpol
(subbureau), IOC, ISO (correspondent), WCL, WMO, WTrO
Diplomatic representation in the US: none (special administrative
region of China)
Diplomatic representation from the US:
chief of mission: Consul General Richard A. BOUCHER
consulate(s) general: 26 Garden Road, Hong Kong
mailing address: PSC 464, Box 30, FPO AP 96522-0002
telephone: [852] 2523-9011
FAX: [852] 2845-1598
Flag description: red with a stylized, white, five-petal bauhinia
flower in the center
@Hong Kong:Economy
Economy-overview: Hong Kong has a bustling free market economy highly
dependent on international trade. Natural resources are limited, and
food and raw materials must be imported. Indeed, imports and exports,
including reexports, each exceed GDP in dollar value. Real GDP growth
averaged a remarkable 8% in 1987-88, slowed to 3.0% in 1989-90, and
picked up to 4.2% in 1991, 5.0% in 1992, 5.2% in 1993, 5.5% in 1994,
4.8% in 1995, 4.7% in 1996, and an estimated 5.5% in 1997. A shortage
of labor continues to put upward pressure on prices and the cost of
living. Even before Hong Kong reverted to Chinese administration on 1
July 1997 it had extensive trade and investment ties with China.
GDP: purchasing power parity-$175.2 billion (1997 est.)
GDP-real growth rate: 5.5% (1997 est.)
GDP-per capita: purchasing power parity-$26,800 (1997 est.)
GDP-composition by sector:
agriculture: 0.1%
industry: 16.1%
services: 83.8% (1996 est.)
Inflation rate-consumer price index: 5.1% (1997 est.)
Labor force:
total: 3.183 million (1997)
by occupation: wholesale and retail trade, restaurants, and hotels
32.4%, social services 9.9%, manufacturing 9.9%, financing, insurance,
and real estate 13.0%, transport and communications 5.7%, construction
2.6%, other 26.5% (June 1997)
Unemployment rate: 3.1% (1996 est.)
Budget:
revenues: $19 billion
expenditures: $14.1 billion, including capital expenditures of $289
million (FY95/96 est.)
Industries: textiles, clothing, tourism, electronics, plastics, toys,
watches, clocks
Industrial production growth rate: -3.2% (1997 est.)
Electricity-capacity: 11.3 million kW (1996)
Electricity-production: 28 billion kWh (1996)
Electricity-consumption per capita: 3,968 kWh (1995)
Agriculture-products: fresh vegetables; poultry
Exports:
total value: $180.7 billion (including reexports; f.o.b., 1996)
commodities: clothing, textiles, yarn and fabric, footwear, electrical
appliances, watches and clocks, toys
partners: China 34%, US 21%, Japan 7%, Germany 4%, UK 3% (1996)
Imports:
total value: $198.6 billion (c.i.f., 1996)
commodities: foodstuffs, transport equipment, raw materials,
semimanufactures, petroleum; a large share is reexported
partners: China 37%, Japan 14%, Taiwan 8%, US 8%, Singapore 5% (1996)
Debt-external: none (1996)
Economic aid: $NA
Currency: 1 Hong Kong dollar (HK$) = 100 cents
Exchange rates: Hong Kong dollars (HK$) per US$-7.74 (1997), 7.730
(1996), 7.800 (1995), 7.800 (1994), 7.800 (1993), 7.741 (1992);
note-linked to the US dollar at the rate of about 7.8 HK$ per 1 US$
Fiscal year: 1 April-31 March','954de31ff2a0d09aad66b925ea9bd485400300c58626047e73cc57a4e4b21c9b','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0c97e346639de8f74fb7079fb13e01a8d3a66ea3adcb63d3a516876cb37e5d1',1990,'IL','Israel','introduction',143,'Current issues: The territories occupied by Israel since the 1967 war
are not included in the data below, unless otherwise noted. In keeping
with the framework established at the Madrid Conference in October
1991, bilateral negotiations are being conducted between Israel and
Palestinian representatives, and Israel and Syria, to achieve a
permanent settlement between them. On 25 April 1982, Israel withdrew
from the Sinai pursuant to the 1979 Israel-Egypt Peace treaty.
Outstanding territorial and other disputes with Jordan were resolved
in the 26 October 1994 Israel-Jordan Treaty of Peace.
@Israel:Geography
Location: Middle East, bordering the Mediterranean Sea, between Egypt
and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area-comparative: slightly smaller than New Jersey
Land boundaries:
total: 1,006 km
border countries: Egypt 255 km, Gaza Strip 51 km, Jordan 238 km,
Lebanon 79 km, Syria 76 km, West Bank 307 km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
Climate: temperate; hot and dry in southern and eastern desert areas
Terrain: Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: copper, phosphates, bromide, potash, clay, sand,
sulfur, asphalt, manganese, small amounts of natural gas and crude oil
Land use:
arable land: 17%
permanent crops: 4%
permanent pastures: 7%
forests and woodland: 6%
other: 66% (1993 est.)
Irrigated land: 1,800 sq km (1993 est.)
Natural hazards: sandstorms may occur during spring and summer
Environment-current issues: limited arable land and natural fresh
water resources pose serious constraints; desertification; air
pollution from industrial and vehicle emissions; groundwater pollution
from industrial and domestic waste, chemical fertilizers, and
pesticides
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography-note: there are 207 Israeli settlements and civilian land
use sites in the West Bank, 42 in the Israeli-occupied Golan Heights,
24 in the Gaza Strip, and 29 in East Jerusalem (August 1997 est.)
@Israel:People
Population: 5,643,966 (July 1998 est.)
note: includes 155,000 Israeli settlers in the West Bank, 17,000 in
the Israeli-occupied Golan Heights, 6,000 in the Gaza Strip, and
164,000 in East Jerusalem (August 1997 est.)
Age structure:
0-14 years: 28% (male 814,558; female 776,630)
15-64 years: 62% (male 1,751,111; female 1,745,499)
65 years and over: 10% (male 239,658; female 316,510) (July 1998 est.)
Population growth rate: 1.91% (1998 est.)
Birth rate: 19.99 births/1,000 population (1998 est.)
Death rate: 6.19 deaths/1,000 population (1998 est.)
Net migration rate: 5.25 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female (1998 est.)
Infant mortality rate: 8.02 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 78.41 years
male: 76.52 years
female: 80.39 years (1998 est.)
Total fertility rate: 2.71 children born/woman (1998 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic groups: Jewish 82% (Israel-born 50%,
Europe/Americas/Oceania-born 20%, Africa-born 7%, Asia-born 5%),
non-Jewish 18% (mostly Arab) (1993 est.)
Religions: Judaism 82%, Islam 14% (mostly Sunni Muslim), Christian 2%,
Druze and other 2%
Languages: Hebrew (official), Arabic used officially for Arab
minority, English most commonly used foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95%
male: 97%
female: 93% (1992 est.)
@Israel:Government
Country name:
conventional long form: State of Israel
conventional short form: Israel
local long form: Medinat Yisra''el
local short form: Yisra''el
Data code: IS
Government type: republic
National capital: Jerusalem
note: Israel proclaimed Jerusalem as its capital in 1950, but the US,
like nearly all other countries, maintains its Embassy in Tel Aviv
Administrative divisions: 6 districts (mehozot, singular-mehoz);
Central, Haifa, Jerusalem, Northern, Southern, Tel Aviv
Independence: 14 May 1948 (from League of Nations mandate under
British administration)
National holiday: Independence Day, 14 May 1948 (Israel declared
independence on 14 May 1948, but the Jewish calendar is lunar and the
holiday may occur in April or May)
Constitution: no formal constitution; some of the functions of a
constitution are filled by the Declaration of Establishment (1948),
the basic laws of the parliament (Knesset), and the Israeli
citizenship law
Legal system: mixture of English common law, British Mandate
regulations, and, in personal matters, Jewish, Christian, and Muslim
legal systems; in December 1985, Israel informed the UN Secretariat
that it would no longer accept compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Ezer WEIZMAN (since 13 May 1993)
head of government: Prime Minister Binyamin NETANYAHU (since 18 June
1996)
cabinet: Cabinet selected from and approved by the Knesset
elections: president elected by the Knesset for a five-year term;
election last held 4 March 1998 (next to be held NA March 2003); prime
minister elected by popular vote for a four-year term; election last
held 29 May 1996 (next to be held NA 2000); note-in March 1992, the
Knesset approved legislation, effective in 1996, which allowed for the
direct election of the prime minister; under the new law, each voter
casts two ballots-one for the direct election of the prime minister
and one for the party in the Knesset; the candidate that receives the
largest percentage of the popular vote then works to form a coalition
with other parties to achieve a parliamentary majority of 61 seats;
finally, the candidate must submit his or her cabinet to the Knesset
for approval and this must be done within 45 days of the election; in
contrast to the old system, under the new law, the prime minister''s
party need not be the single-largest party in the Knesset
election results: Ezer WEIZMAN elected president by the Knesset with a
total of 63 votes, other candidate, Shaul AMOR, received 49 votes
(there were seven abstentions and one absence); Binyamin NETANYAHU
elected prime minister; percent of vote - Binyamin NETANYAHU 50.4%,
Shimon PERES 49.5%
Legislative branch: unicameral Knesset or parliament (120 seats;
members elected by popular vote to serve four-year terms)
elections: last held 29 May 1996 (next to be held NA 2000)
election results: percent of vote by party-NA; seats by party-Labor
Party 34, Likud Party 32, SHAS 10, MERETZ 9, National Religious Party
9, Yisra''el Ba''Aliya 7, Hadash-Balad 5, Third Way 4, United Arab List
4, United Jewish Torah 4, Moledet 2; note-Likud, Tzomet, and Gesher
candidates ran on a joint list
Judicial branch: Supreme Court, appointed for life by the president
Political parties and leaders:
government coalition: Likud Party, Prime Minister Binyamin NETANYAHU;
Tzomet, Rafael EITAN; SHAS, Arieh DERI; National Religious Party,
Yitzhak LEVI; Yisra''el Ba''Aliya, Natan SHARANSKY; United Jewish Torah,
Meir PORUSH; Third Way, Avigdor KAHALANI
opposition: Labor Party, Ehud BARAK; MERETZ, Yossi SARID; United Arab
List, Abd al-Malik DAHAMSHAH; Hadash-Balad, Hashim MAHAMID
other: Moledet, Rehavam ZEEVI; Gesher, David LEVI
Political pressure groups and leaders: Gush Emunim, Israeli
nationalists advocating Jewish settlement on the West Bank and Gaza
Strip; Peace Now supports territorial concessions in the West Bank and
is critical of government''s Lebanon policy
International organization participation: AG (observer), BSEC
(observer), CCC, CE (observer), CERN (observer), EBRD, ECE, FAO, IADB,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA, IFAD, IFC, ILO, IMF, IMO, Inmarsat,
Intelsat, Interpol, IOC, IOM, ISO, ITU, OAS (observer), OSCE
(partner), PCA, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UPU, WHO, WIPO, WMO,
WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador-designate Zalman SHOVAL
chancery: 3514 International Drive NW, Washington, DC 20008
telephone: [1] (202) 364-5500
FAX: [1] (202) 364-5607
consulate(s) general: Atlanta, Boston, Chicago, Houston, Los Angeles,
Miami, New York, Philadelphia, and San Francisco
Diplomatic representation from the US:
chief of mission: Ambassador Edward WALKER
embassy: 71 Hayarkon Street, Tel Aviv
mailing address: PSC 98, Box 100, APO AE 09830
telephone: [972] (3) 519-7575
FAX: [972] (3) 517-3227
consulate(s) general: Jerusalem; note-an independent US mission,
established in 1928, whose members are not accredited to a foreign','63901e2b53474d1dd43536f92d825085bf2c1147ca6d23ea13a1800f08bfab7d','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b496c7ad6fa95d4244637e220975df7ef87e6d702fe5d70427354c397292d2',1990,'LB','Lebanon','introduction',160,'Current issues: Lebanon has made progress toward rebuilding its
political institutions and regaining its national sovereignty since
the end of the devastating 16-year civil war, which began in 1975.
Under the Ta''if Accord-the blueprint for national reconciliation-the
Lebanese have established a more equitable political system,
particularly by giving Muslims a greater say in the political process
while institutionalizing sectarian divisions in the government. Since
the end of the civil war, the Lebanese have formed five cabinets and
conducted two legislative elections. Most of the militias have been
weakened or disbanded. The Lebanese Armed Forces (LAF) has seized vast
quantities of weapons used by the militias during the war and extended
central government authority over about one-half of the country.
Hizballah, the radical Shi''a party, retains most of its weapons.
Foreign forces still occupy areas of Lebanon. Israel maintains troops
in southern Lebanon and continues to support a proxy militia, the Army
of South Lebanon (ASL), along a narrow stretch of territory contiguous
to its border. The ASL''s enclave encompasses this self-declared
security zone and about 20 kilometers north to the strategic town of
Jazzin. Syria maintains about 25,000 troops in Lebanon. These troops
are based mainly in Beirut, North Lebanon, and the Bekaa Valley.
Syria''s deployment was legitimized by the Arab League during Lebanon''s
civil war and in the Ta''if accord. Citing the continued weakness of
the LAF, Beirut''s requests, and failure of the Lebanese Government to
implement all of the constitutional reforms in the Ta''if accord,
Damascus has so far refused to withdraw its troops from Lebanon.
@Lebanon:Geography
Location: Middle East, bordering the Mediterranean Sea, between Israel
and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area-comparative: about 0.7 times the size of Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet winters with hot, dry
summers; Lebanon mountains experience heavy winter snows
Terrain: narrow coastal plain; Al Biqa'' (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Jabal al Makmal 3,087 m
Natural resources: limestone, iron ore, salt, water-surplus state in a
water-deficit region
Land use:
arable land: 21%
permanent crops: 9%
permanent pastures: 1%
forests and woodland: 8%
other: 61% (1993 est.)
Irrigated land: 860 sq km (1993 est.)
Natural hazards: dust storms, sandstorms
Environment-current issues: deforestation; soil erosion;
desertification; air pollution in Beirut from vehicular traffic and
the burning of industrial wastes; pollution of coastal waters from raw
sewage and oil spills
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Hazardous
Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Environmental Modification, Marine Dumping,
Marine Life Conservation
Geography-note: Nahr al Litani only major river in Near East not
crossing an international boundary; rugged terrain historically helped
isolate, protect, and develop numerous factional groups based on
religion, clan, and ethnicity
@Lebanon:People
Population: 3,505,794 (July 1998 est.)
Age structure:
0-14 years: 30% (male 532,688; female 512,979)
15-64 years: 64% (male 1,060,903; female 1,174,236)
65 years and over: 6% (male 102,946; female 122,042) (July 1998 est.)
Population growth rate: 1.62% (1998 est.)
Birth rate: 22.66 births/1,000 population (1998 est.)
Death rate: 6.51 deaths/1,000 population (1998 est.)
Net migration rate: 0 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.84 male(s)/female (1998 est.)
Infant mortality rate: 31.64 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 70.64 years
male: 68.08 years
female: 73.33 years (1998 est.)
Total fertility rate: 2.28 children born/woman (1998 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Islam 70% (5 legally recognized Islamic groups-Alawite or
Nusayri, Druze, Isma''ilite, Shi''a, Sunni), Christian 30% (11 legally
recognized Christian groups-4 Orthodox Christian, 6 Catholic, 1
Protestant), Judaism NEGL%
Languages: Arabic (official), French, English, Armenian widely
understood
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 90.8%
female: 82.2% (1997 est.)
@Lebanon:Government
Country name:
conventional long form: Lebanese Republic
conventional short form: Lebanon
local long form: Al Jumhuriyah al Lubnaniyah
local short form: Lubnan
Data code: LE
Government type: republic
National capital: Beirut
Administrative divisions: 5 governorates (muhafazat,
singular-muhafazah); Al Biqa'', Al Janub, Ash Shamal, Bayrut, Jabal
Lubnan
Independence: 22 November 1943 (from League of Nations mandate under
French administration)
National holiday: Independence Day, 22 November (1943)
Constitution: 23 May 1926, amended a number of times
Legal system: mixture of Ottoman law, canon law, Napoleonic code, and
civil law; no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Suffrage: 21 years of age; compulsory for all males; authorized for
women at age 21 with elementary education
Executive branch:
chief of state: President Ilyas HARAWI (since 24 November 1989)
head of government: Prime Minister Rafiq al-HARIRI (since 22 October
1992)
cabinet: Cabinet chosen by the prime minister in consultation with the
members of the National Assembly; the current Cabinet was formed in
1996
elections: president elected by the National Assembly for a six-year
term; election last held 24 November 1989 (next to be held NA 1998);
note-in 1995, the National Assembly amended the constitution to extend
the president''s term by three years; prime minister and deputy prime
minister appointed by the president in consultation with the National
Assembly; by custom, the president is a Maronite Christian, the prime
minister is a Sunni Muslim, and the speaker of the legislature is a
Shi''a Muslim
election results: Ilyas HARAWI elected president; percent of National
Assembly vote - NA
Legislative branch: unicameral National Assembly or Majlis Alnuwab
(Arabic) or Assemblee Nationale (French) (128 seats; members elected
by popular vote on the basis of sectarian proportional representation
to serve four-year terms)
elections: last held in the summer of 1996 (next to be held NA 2000)
election results: percent of vote by party-NA; seats by party-NA
(one-half Christian and one-half Muslim)
Judicial branch: four Courts of Cassation (three courts for civil and
commercial cases and one court for criminal cases); Constitutional
Council (called for in Ta''if Accord-rules on constitutionality of
laws); Supreme Council (hears charges against the president and prime
minister as needed)
Political parties and leaders: political party activity is organized
along largely sectarian lines; numerous political groupings exist,
consisting of individual political figures and followers motivated by
religious, clan, and economic considerations
International organization participation: ABEDA, ACCT, AFESD, AL, AMF,
CCC, ESCWA, FAO, G-24, G-77, IAEA, IBRD, ICAO, ICC, ICFTU, ICRM, IDA,
IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Inmarsat, Intelsat, Interpol,
IOC, ISO (correspondent), ITU, NAM, OIC, PCA, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNRWA, UPU, WFTU, WHO, WIPO, WMO, WToO
Diplomatic representation in the US:
chief of mission: Ambassador Mohamad Baha CHATAH
chancery: 2560 28th Street NW, Washington, DC 20008
telephone: [1] (202) 939-6300
FAX: [1] (202) 939-6324
consulate(s) general: Detroit, New York, and Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador-designate David SATTERFIELD
embassy: Antelias, Beirut
mailing address: P. O. Box 70-840, Beirut; PSC 815, Box 2, FPO AE
09836-0002
telephone: [961] (1) 402200, 403300, 426183, 417774, 889926
FAX: [961] (1) 407112
Flag description: three horizontal bands of red (top), white (double
width), and red with a green and brown cedar tree centered in the
white band
@Lebanon:Economy
Economy-overview: The 1975-91 civil war seriously damaged Lebanon''s
economic infrastructure, cut national output by half, and all but
ended Lebanon''s position as a Middle Eastern entrepot and banking hub.
Peace has enabled the central government to restore control in Beirut,
begin collecting taxes, and regain access to key port and government
facilities. Economic recovery has been helped by a financially sound
banking system and resilient small- and medium-scale manufacturers,
with family remittances, banking services, manufactured and farm
exports, and international aid as the main sources of foreign
exchange. Lebanon''s economy has made impressive gains since Prime
Minister HARIRI launched his $18 billion "Horizon 2000" reconstruction
program in 1993. Real GDP grew 8% in 1994 and 7% in 1995 before
Israel''s Operation Grapes of Wrath in April 1996 stunted economic
activity. During 1992-97, annual inflation fell from more than 170% to
9%, and foreign exchange reserves jumped to more than $4 billion from
$1.4 billion. Burgeoning capital inflows have generated foreign
payments surpluses, and the Lebanese pound has remained relatively
stable. Progress also has been made in rebuilding Lebanon''s war-torn
physical and financial infrastructure. Solidere, a $2-billion firm, is
managing the reconstruction of Beirut''s central business district; the
stock market reopened in January 1996; and international banks and
insurance companies are returning. The government nonetheless faces
serious challenges in the economic arena. It has had to fund
reconstruction by tapping foreign exchange reserves and boosting
borrowing. The stalled peace process and ongoing violence in southern
Lebanon could lead to wider hostilities that would disrupt vital
capital inflows. Furthermore, the gap between rich and poor has
widened since HARIRI took office, resulting in grassroots
dissatisfaction over the skewed distribution of the reconstruction''s
benefits and leading the government to shift its focus from rebuilding
infrastructure to improving living conditions.
GDP: purchasing power parity-$15.2 billion (1997 est.)
GDP-real growth rate: 4% (1997 est.)
GDP-per capita: purchasing power parity-$4,400 (1997 est.)
GDP-composition by sector:
agriculture: 4%
industry: 23%
services: 73% (1997 est.)
Inflation rate-consumer price index: 9% (1997 est.)
Labor force:
total: 1 million plus as many as 1 million foreign workers (1996 est.)
by occupation: services 62%, industry 31%, agriculture 7% (1997 est.)
Unemployment rate: 18% (1997 est.)
Budget:
revenues: $2.4 billion
expenditures: $5.9 billion, including capital expenditures of $NA
(1997 est.)
Industries: banking; food processing; jewelry; cement; textiles;
mineral and chemical products; wood and furniture products; oil
refining; metal fabricating
Industrial production growth rate: 25% (1993 est.)
Electricity-capacity: 1.35 million kW (1997)
Electricity-production: 5 billion kWh (1995)
Electricity-consumption per capita: 1,380 kWh (1995)
Agriculture-products: citrus, vegetables, potatoes, olives, tobacco,
hemp (hashish); sheep, goats
Exports:
total value: $1.018 billion (f.o.b., 1996)
commodities: paper and paper products 26%, food stuffs 16%, textiles
and textile products 10%, jewelry 8%, metals and metal products 8%,
electrical equipment and products 8%, chemical products 6%, transport
vehicles 4% (1995)
partners: UAE 23%, Saudi Arabia 14%, Kuwait 8%, Syria 7%, Jordan 5%,
France 5%, Italy 4%, US 3% (1996)
Imports:
total value: $7.559 billion (c.i.f., 1996)
commodities: machinery and transport equipment 28%, foodstuffs 20%,
consumer goods 19%, chemicals 9%, textiles 5%, metals 5%, fuels 3%
(1995)
partners: Italy 12%, US 11%, Germany 9%, France 8%, Syria 4%, UK 4%,
Japan 4% (1996)
Debt-external: $2.3 billion (1997 est.)
Economic aid:
recipient: aid pledges of $3.5 billion for 1997-2001
Currency: 1 Lebanese pound (£L) = 100 piasters
Exchange rates: Lebanese pounds (£L) per US$1-1,526.1 (January 1998),
1,539.5 (1997), 1,571.4 (1996), 1,621.4 (1995), 1,680.1 (1994),
1,741.4 (1993)
Fiscal year: calendar year','73692fb36c871c739ff678986253ffd94b38621af2bfda9accc94ef17ef8baeb','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae6a7e93710b6916e8fbf6a502b497737070e35162cf87c23845e3042bbed8f3',1990,'LR','Liberia','introduction',163,'Current issues: The Abuja Peace Accords ended seven years of civil
warfare in Liberia. More than 20,000 of the estimated 33,000 factional
fighters gave up their arms to the Cease-Fire Monitoring Group of the
Economic Community of West African States (ECOMOG). Free and open
presidential and legislative elections were held 19 July 1997; former
faction leader, Charles TAYLOR, and his National Patriotic Party won
overwhelming victories. The years of civil strife coupled with the
flight of most business people disrupted formal economic activity, but
with peace restored and a popularly-elected government installed, the
difficult task of rebuilding the social and economic structure of this
war-torn country can proceed.
@Liberia:Geography
Location: Western Africa, bordering the North Atlantic Ocean, between
Cote d''Ivoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
Area-comparative: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire 716 km, Sierra Leone
306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot days and cool to
cold nights; wet, cloudy summers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber, diamonds, gold
Land use:
arable land: 1%
permanent crops: 3%
permanent pastures: 59%
forests and woodland: 18%
other: 19% (1993 est.)
Irrigated land: 20 sq km (1993 est.)
Natural hazards: dust-laden harmattan winds blow from the Sahara
(December to March)
Environment-current issues: tropical rain forest subject to
deforestation; soil erosion; loss of biodiversity; pollution of rivers
from the dumping of iron ore tailings and of coastal waters from oil
residue and raw sewage
Environment-international agreements:
party to: Desertification, Endangered Species, Nuclear Test Ban, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83, Tropical Timber
94
signed, but not ratified: Biodiversity, Climate Change, Environmental
Modification, Law of the Sea, Marine Dumping, Marine Life Conservation
@Liberia:People
Population: 2,771,901 (July 1998 est.)
Age structure:
0-14 years: 45% (male 622,797; female 616,902)
15-64 years: 52% (male 734,425; female 700,124)
65 years and over: 3% (male 47,099; female 50,554) (July 1998 est.)
Population growth rate: 5.76% (1998 est.)
Birth rate: 41.88 births/1,000 population (1998 est.)
Death rate: 11.28 deaths/1,000 population (1998 est.)
Net migration rate: 27.02 migrant(s)/1,000 population (1998 est.)
note: until domestic peace is restored, many Liberian refugees will
not return from exile
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.04 male(s)/female
65 years and over: 0.93 male(s)/female (1998 est.)
Infant mortality rate: 103.13 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 59.45 years
male: 56.81 years
female: 62.16 years (1998 est.)
Total fertility rate: 6.09 children born/woman (1998 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95% (including Kpelle, Bassa,
Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai, and
Bella), Americo-Liberians 2.5% (descendants of immigrants from the US
who had been slaves)
Religions: traditional 70%, Muslim 20%, Christian 10%
Languages: English 20% (official), about 20 tribal languages, of which
a few can be written and are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 38.3%
male: 53.9%
female: 22.4% (1995 est.)
@Liberia:Government
Country name:
conventional long form: Republic of Liberia
conventional short form: Liberia
Data code: LI
Government type: republic
National capital: Monrovia
Administrative divisions: 13 counties; Bomi, Bong, Grand Bassa, Grand
Cape Mount, Grand Gedeh, Grand Kru, Lofa, Margibi, Maryland,
Montserrado, Nimba, River Cess, Sinoe
Independence: 26 July 1847
National holiday: Independence Day, 26 July (1847)
Constitution: 6 January 1986
Legal system: dual system of statutory law based on Anglo-American
common law for the modern sector and customary law based on unwritten
tribal practices for indigenous sector
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Charles Ghankay TAYLOR (since 2 August
1997); note-the president is both the chief of state and head of','3bb52f1da828eea04b48f4af473af86abf1c67017d2b868d4887e1a064ff374c','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d4cd2e387db56f06a4f68e5ab04a44de4b9313445dc270bd93c6d8e2a3814d2',1990,'RW','Rwanda','introduction',213,'in April 1994 between Tutsi and Hutu factions, more than 2 million
refugees fled to neighboring Burundi, Tanzania, Uganda, and Zaire, now
called Democratic Republic of the Congo. According to the UN High
Commission on Refugees, in 1996 and early 1997 nearly 1,300,000 Hutus
returned to Rwanda; of these, 720,000 returned from Democratic
Republic of the Congo, 480,000 from Tanzania, 88,000 from Burundi, and
10,000 from Uganda.
@Rwanda:Geography
Location: Central Africa, east of Democratic Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,340 sq km
land: 24,950 sq km
water: 1,390 sq km
Area-comparative: slightly smaller than Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Democratic Republic of the Congo 217
km, Tanzania 217 km, Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February to April, November to
January); mild in mountains with frost and snow possible
Terrain: mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore), wolframite (tungsten
ore), natural gas, hydropower
Land use:
arable land: 35%
permanent crops: 13%
permanent pastures: 18%
forests and woodland: 22%
other: 12% (1993 est.)
Irrigated land: 40 sq km (1993 est.)
Natural hazards: periodic droughts; the volcanic Virunga mountains are
in the northwest along the border with Democratic Republic of the','544e4ef581493d13d01a25536cbc2040cd7a2ac1a88ee1278876751dc52597b1','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a472bf65bc90d6fc058bf968ff003a232d79611bcab0e4c2167d43cae07f2e11',1990,'CG','Congo','introduction',214,'Environment-current issues: deforestation results from uncontrolled
cutting of trees for fuel; overgrazing; soil exhaustion; soil erosion
Environment-international agreements:
party to: Biodiversity, Endangered Species, Nuclear Test Ban
signed, but not ratified: Climate Change, Desertification, Law of the
Sea
Geography-note: landlocked; predominantly rural population
@Rwanda:People
Population: 7,956,172 (July 1998 est.)
Age structure:
0-14 years: 45% (male 1,785,650; female 1,772,609)
15-64 years: 53% (male 2,070,401; female 2,106,809)
65 years and over: 2% (male 90,941; female 129,762) (July 1998 est.)
Population growth rate: 2.5% (1998 est.)
Birth rate: 38.99 births/1,000 population (1998 est.)
Death rate: 19 deaths/1,000 population (1998 est.)
Net migration rate: 5.03 migrant(s)/1,000 population (1998 est.)
note: following the outbreak of genocidal strife in Rwanda in April
1994 between Tutsi and Hutu factions, more than 2 million refugees
fled to neighboring Burundi, Tanzania, Uganda, and Democratic Republic
of the Congo, formerly Zaire; according to the UN High Commission on
Refugees, in 1996 and early 1997 nearly 1,300,000 Hutus returned to
Rwanda; of these 720,000 returned from Democratic Republic of the
Congo, 480,000 from Tanzania, 88,000 from Burundi, and 10,000 from
Uganda; probably fewer than 100,000 Rwandans remained outside of
Rwanda at the end of 1997
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female (1998 est.)
Infant mortality rate: 113.31 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 41.93 years
male: 41.49 years
female: 42.4 years (1998 est.)
Total fertility rate: 5.86 children born/woman (1998 est.)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 80%, Tutsi 19%, Twa (Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant 9%, Muslim 1%, indigenous
beliefs and other 25%
Languages: Kinyarwanda (official) universal Bantu vernacular, French
(official), English (official), Kiswahili (Swahili) used in commercial
centers
Literacy:
definition: age 15 and over can read and write
total population: 60.5%
male: 69.8%
female: 51.6% (1995 est.)
@Rwanda:Government
Country name:
conventional long form: Rwandese Republic
conventional short form: Rwanda
local long form: Republika y''u Rwanda
local short form: Rwanda
Data code: RW
Government type: republic; presidential, multiparty system
National capital: Kigali
Administrative divisions: 12 prefectures (prefectures,
singular-prefecture in French; plural - NA, singular-prefegitura in
Kinyarwanda); Butare, Byumba, Cyangugu, Gikongoro, Gisenyi, Gitarama,
Kibungo, Kibuye, Kigali, Kigaliville, Umutara, Ruhengeri
Independence: 1 July 1962 (from Belgium-administered UN trusteeship)
National holiday: Independence Day, 1 July (1962)
Constitution: on 5 May 1995, the Transitional National Assembly
adopted a new constitution which included elements of the constitution
of 18 June 1991 as well as provisions of the 1993 Arusha peace accord
and the November 1994 multi-party protocol of understanding
Legal system: based on German and Belgian civil law systems and
customary law; judicial review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ jurisdiction
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: President Pasteur BIZIMUNGU (since 19 July 1994); Vice
President Maj. Gen. Paul KAGAME (since 19 July 1994)
head of government: Prime Minister Celestin RWIGEMA (since 1 September
1995)
cabinet: Council of Ministers appointed by the president
elections: normally the president is elected by popular vote for a
five-year term; election last held in December 1988 (next to be held
NA); prime minister is appointed by the president
election results: Juvenal HABYARIMANA elected president; percent of
vote-99.98% (HABYARIMANA was the sole candidate)
note: President HABYARIMANA was assassinated on 6 April 1994 and
replaced by President BIZIMUNGU who was installed by the military
forces of the ruling Rwandan Patriotic Front on 19 July 1994
Legislative branch: unicameral Transitional National Assembly or
Assemblee Nationale de Transition (70 seats; members were
predetermined by the Arusha peace accord to serve NA-year terms)
elections: last held 26 December 1988 (next to be held NA); note-the
Transitional National Assembly is a power-sharing body established on
12 December 1994 following a multi-party protocol of understanding
election results: percent of vote by party-NA; seats by party-RPF 19,
MDR 13, PSD 13, PL 13, PDC 6, PSR 2, PDI 2, other 2; note-the
distribution of seats was predetermined
Judicial branch: Constitutional Court, consists of the Court of
Cassation and the Council of State in joint session
Political parties and leaders: significant parties include: Rwandan
Patriotic Front or RPF [Alexis KANYARENGWE, chairman]; Democratic
Republican Movement or MDR; Liberal Party or PL; Democratic and
Socialist Party or PSD; Christian Democratic Party or PDC; Islamic
Democratic Party or PDI; Rwandan Socialist Party or PSR; National
Movement for Democracy and Development or MRND (former ruling party)
Political pressure groups and leaders: Rwanda Patriotic Army or RPA,
the RPF military wing [Maj. Gen. Paul KAGAME, commander]; Rally for
the Democracy and Return (RDR)
International organization participation: ACCT, ACP, AfDB, CCC, CEEAC,
CEPGL, ECA, FAO, G-77, IBRD, ICAO, ICFTU, ICRM, IDA, IFAD, IFC, IFRCS,
ILO, IMF, Intelsat, Interpol, IOC, IOM (observer), ITU, NAM, OAU, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US:
chief of mission: Ambassador Theogene N. RUDASINGWA
chancery: (temporary) 1814 New Hampshire Ave. NW, Washington, DC 20007
telephone: [1] (202) 232-2882
FAX: [1] (202) 232-4544
Diplomatic representation from the US:
chief of mission: Ambassador Robert GRIBBIN III
embassy: Boulevard de la Revolution, Kigali
mailing address: B. P. 28, Kigali
telephone: [250] 756 01 through 03, 721 26, 771 47
FAX: [250] 721 28
Flag description: three equal vertical bands of red (hoist side),
yellow, and green with a large black letter R centered in the yellow
band; uses the popular pan-African colors of Ethiopia; similar to the
flag of Guinea, which has a plain yellow band
@Rwanda:Economy
Economy-overview: Rwanda is a poor African nation that has suffered
bitterly from ethnic-based civil war. The agricultural sector
dominates the economy; coffee and tea normally make up 80%-90% of
exports. The amount of fertile land is limited, however, and
deforestation and soil erosion continue to reduce the production
potential. Manufacturing focuses mainly on the processing of
agricultural products. A structural adjustment program with the World
Bank began in October 1990. Civil war in 1990 devastated wide areas,
especially in the north, and displaced hundreds of thousands of
people. A peace accord in mid-1993 temporarily ended most of the
fighting, but resumption of large-scale violence and genocide in April
1994 in the capital city Kigali and elsewhere took 500,000 lives in
that year alone and severely damaged already poor economic prospects.
In 1994-96, peace was restored throughout much of the country. In
1996-97 most of the refugees who fled the war returned to Rwanda.
Sketchy data suggest that GDP dropped 50% in 1994 and came back
partially, by 25%, in 1995. Plentiful rains helped agriculture in
1996, and outside aid continued to support this desperately poor
economy. The economy continues to face significant challenges in
rehabilitating infrastructure, agriculture, health care facilities,
and capital plant. Recovery of domestic production will proceed
slowly.
GDP: purchasing power parity-$3 billion (1996 est.)
GDP-real growth rate: 13.3% (1996)
GDP-per capita: purchasing power parity-$440 (1996 est.)
GDP-composition by sector:
agriculture: 37%
industry: 17%
services: 46% (1995 est.)
Inflation rate-consumer price index: 7.4% (1996)
Labor force:
total: 3.6 million
by occupation: agriculture 93%, government and services 5%, industry
and commerce 2%
Unemployment rate: NA%
Budget:
revenues: $231 million
expenditures: $319 million, including capital expenditures of $13
million (1996 est.)
Industries: mining of cassiterite (tin ore) and wolframite (tungsten
ore), tin, cement, processing of agricultural products, small-scale
beverage production, soap, furniture, shoes, plastic goods, textiles,
cigarettes
Industrial production growth rate: 4.9% (1995 est.)
Electricity-capacity: 34,000 kW (1995)
Electricity-production: 169 million kWh (1995)
Electricity-consumption per capita: 21 kWh (1995)
Agriculture-products: coffee, tea, pyrethrum (insecticide made from
chrysanthemums), bananas, beans, sorghum, potatoes; livestock
Exports:
total value: $62.3 million (f.o.b., 1996 est.)
commodities: coffee 74%, tea, cassiterite, wolframite, pyrethrum
(1995)
partners: Brazil, EU
Imports:
total value: $202.4 million (f.o.b., 1996 est.)
commodities: foodstuffs 35%, machines and equipment, capital goods,
steel, petroleum products, cement and construction material (1995)
partners: US, EU, Kenya, Tanzania
Debt-external: $1 billion (December 1995)
Economic aid:
recipient: ODA, $NA
note: in October 1990 Rwanda launched a Structural Adjustment Program
with the IMF; since September 1991, the EU has given $46 million and
the US $25 million in support of this program (1993)
Currency: 1 Rwandan franc (RF) = 100 centimes
Exchange rates: Rwandan francs (RF) per US$1-302.28 (January 1998),
301.53 (1997), 306.82 (1996), 262.20 (1995), 144.31 (1993)
Fiscal year: calendar year','59fc04d4d9dbbe96bad510d4b6f443b1e79b210f13641238397c01bf25523e33','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccdd40838bad157c502f5127c9f44ee6e87377f3100abd41e7ad0971bbb1575a',1990,'SN','Senegal','introduction',224,'Current issues: Serbia and Montenegro have asserted the formation of a
joint independent state, but this entity has not been formally
recognized as a state by the US; the US view is that the Socialist
Federal Republic of Yugoslavia (SFRY), has dissolved and that none of
the successor republics represents its continuation.
@Serbia and Montenegro:Geography
Location: Southeastern Europe, bordering the Adriatic Sea, between
Albania and Bosnia and Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total: 102,350 sq km (Serbia 88,412 sq km; Montenegro 13,938 sq km)
land: 102,136 sq km (Serbia 88,412 sq km; Montenegro 13,724 sq km)
water: 214 sq km (Serbia 0 sq km; Montenegro 214 sq km)
Area-comparative: slightly smaller than Kentucky (Serbia is slightly
larger than Maine; Montenegro is slightly smaller than Connecticut)
Land boundaries:
total: 2,246 km
border countries: Albania 287 km (114 km with Serbia, 173 km with
Montenegro), Bosnia and Herzegovina 527 km (312 km with Serbia, 215 km
with Montenegro), Bulgaria 318 km (with Serbia), Croatia (north) 241
km (with Serbia), Croatia (south) 25 km (with Montenegro), Hungary 151
km (with Serbia), The Former Yugoslav Republic of Macedonia 221 km
(with Serbia), Romania 476 km (with Serbia)
note: the internal boundary between Montenegro and Serbia is 211 km
Coastline: 199 km (Montenegro 199 km, Serbia 0 km)
Maritime claims: NA
Climate: in the north, continental climate (cold winter and hot, humid
summers with well distributed rainfall); central portion, continental
and Mediterranean climate; to the south, Adriatic climate along the
coast, hot, dry summers and autumns and relatively cold winters with
heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile plains; to the
east, limestone ranges and basins; to the southeast, ancient mountains
and hills; to the southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, antimony, copper, lead, zinc,
nickel, gold, pyrite, chrome
Land use:
arable land: NA%
permanent crops: NA%
permanent pastures: NA%
forests and woodland: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: destructive earthquakes
Environment-current issues: pollution of coastal waters from sewage
outlets, especially in tourist-related areas such as Kotor; air
pollution around Belgrade and other industrial cities; water pollution
from industrial wastes dumped into the Sava which flows into the
Danube
Environment-international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography-note: controls one of the major land routes from Western
Europe to Turkey and the Near East; strategic location along the
Adriatic coast
@Serbia and Montenegro:People
Population: 11,206,039 (July 1998 est.) (Montenegro-679,904;
Serbia-10,526,135)
Age structure:
0-14 years: Montenegro-22% (male 76,764; female 71,647); Serbia- 20%
(male 1,121,483; female 1,043,535)
15-64 years: Montenegro-67% (male 231,849; female 227,268); Serbia-
67% (male 3,539,198; female 3,487,318)
65 years and over: Montenegro-11% (male 29,837; female 42,539);
Serbia- 13% (male 575,697; female 758,904) (July 1998 est.)
Population growth rate: Montenegro-0.07%; Serbia--0.02% (1998 est.)
Birth rate: Montenegro-13.55 births/1,000 population; Serbia-12.62
births/1,000 population (1998 est.)
Death rate: Montenegro-7.40 deaths/1,000 population; Serbia-9.67
deaths/1,000 population (1998 est.)
Net migration rate: Montenegro: -5.43 migrant(s)/1,000 population;
Serbia: -3.1 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: Montenegro-1.09 male(s)/female; Serbia-1.08 male(s)/female
under 15 years: Montenegro-1.07 male(s)/female; Serbia-1.07
male(s)/female
15-64 years: Montenegro-1.02 male(s)/female; Serbia-1.01
male(s)/female
65 years and over: Montenegro-0.70 male(s)/female; Serbia-0.75
male(s)/female (1998 est.)
Infant mortality rate: Montenegro-11.24 deaths/1,000 live births;
Serbia-17.11 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: Montenegro-76.14 years; Serbia-73.17 years
male: Montenegro-72.67 years; Serbia-70.77 years
female: Montenegro-79.92 years; Serbia-75.76 years (1998 est.)
Total fertility rate: Montenegro-1.76 children born/woman; Serbia-1.75
children born/woman (1998 est.)
Nationality:
noun: Serb(s) and Montenegrin(s)
adjective: Serbian and Montenegrin
Ethnic groups: Serbs 63%, Albanians 14%, Montenegrins 6%, Hungarians
4%, other 13%
Religions: Orthodox 65%, Muslim 19%, Roman Catholic 4%, Protestant 1%,
other 11%
Languages: Serbo-Croatian 95%, Albanian 5%
Literacy: NA
@Serbia and Montenegro:Government
Country name:
conventional long form: none
conventional short form: Serbia and Montenegro
local long form: none
local short form: Srbija-Crna Gora
note: Serbia and Montenegro has self-proclaimed itself the "Federal
Republic of Yugoslavia," but the US view is that the Socialist Federal
Republic of Yugoslavia (SFRY) has dissolved and that none of the
successor republics represents its continuation
Data code: Serbia-SR; Montenegro-MW
Government type: republic
National capital: Belgrade (Serbia), Podgorica (Montenegro)
Administrative divisions: 2 republics (republike, singular-republika);
and 2 nominally autonomous provinces* (autonomn pokrajine,
singular-autonomna pokrajina); Kosovo*, Montenegro, Serbia, Vojvodina*
Independence: 11 April 1992 (Federal Republic of Yugoslavia formed as
self-proclaimed successor to the Socialist Federal Republic of
Yugoslavia-SFRY)
National holiday: St. Vitus Day, 28 June
Constitution: 27 April 1992
Legal system: based on civil law system
Suffrage: 16 years of age, if employed; 18 years of age, universal
Executive branch:
chief of state: President Slobodan MILOSEVIC (since 23 July 1997);
note-Milan MILUTINOVIC is president of Serbia (since 21 December
1997); Milo DJUKANOVIC is president of Montenegro (since 21 December
1997)
head of government: Prime Minister Radoje KONTIC (since 29 December
1992); Deputy Prime Ministers Nikola SAINOVIC (since 15 September
1995), Vojin DJUKANOVIC (since 20 March 1997), Jovan ZEBIC (since 9
April 1998), and Vladan KUTLESIC (since 20 March 1997)
cabinet: Federal Executive Council
elections: president elected by the Federal Assembly for a four-year
term; election last held 23 July 1997 (next to be held NA 2001); prime
minister nominated by the president
election results: Slobodan MILOSEVIC elected president; percent of
legislative vote - Slobodan MILOSEVIC 90%
Legislative branch: bicameral Federal Assembly or Savezna Skupstina
consists of the Chamber of Republics or Vece Republika (40 seats, 20
Serbian, 20 Montenegrin; members distributed on the basis of party
representation in the republican assemblies to serve four-year terms)
and the Chamber of Citizens or Vece Gradjana (138 seats, 108 Serbian
with half elected by constituency majorities and half by proportional
representation, 30 Montenegrin with six elected by constituency and 24
proportionally; members serve four-year terms)
elections: Chamber of Republics-last held 24 December 1996 (next to be
held NA 2000); Chamber of Citizens-last held 3 November 1996 (next to
be held NA 2000)
election results: Chamber of Republics-percent of vote by party-NA;
seats by party - NA; note-seats are filled on a proportional basis to
reflect the composition of the legislatures of the republics of
Montenegro and Serbia; Chamber of Citizens-percent of vote by
party-NA; seats by party-SPS/JUL/ND 64, Zajedno 22, DPSCG 20, SRS 16,
NS 8, SVM 3, other 5; note-Zajedno coalition includes SPO, DS, GSS
Judicial branch: Federal Court or Savezni Sud, judges are elected by
the Federal Assembly for a nine-year term; Constitutional Court,
judges are elected by the Federal Assembly for a nine-year term
Political parties and leaders: Serbian Socialist Party or SPS (former
Communist Party) [Slobodan MILOSEVIC]; Serbian Radical Party or SRS
[Vojislav SESELJ]; Serbian Renewal Movement or SPO [Vuk DRASKOVIC,
president]; Democratic Party or DS [Zoran DJINDJIC]; Democratic Party
of Serbia or DSS [Vojislav KOSTUNICA]; Democratic Party of Socialists
of Montenegro or DPSCG [Milica PEJANOVIC-DJURISIC, president];
People''s Party of Montenegro or NS [Novak KILIBARDA]; Socialist
People''s Party of Montenegro or SNP [Momir BULATOVIC]; Social
Democratic Party of Montenegro or SDP [Zarko RAKCEVIE]; Liberal
Alliance of Montenegro [Slavko PEROVIC]; Democratic Community of
Vojvodina Hungarians or DZVM [Sandor PALL]; League of Social Democrats
of Vojvodina or LSV [Nenad CANAK]; Reformist Democratic Party of
Vojvodina or RDSV [Aleksandar POPOV]; Democratic Alliance of Vojvodina
Croats or DSHV [Bela TONKOVIC]; League of Communists-Movement for
Yugoslavia or SK-PJ [Dragomir DRASKOVIC]; Democratic Alliance of
Kosovo or LDK [Dr. Ibrahim RUGOVA, president]; New Democratic League
of Kosovo or LDRK [Hydayet HYSENI]; Parliamentary Party of Kosovo or
PPK [Adern DERNACI]; Party of Democratic Action or SDA [Dr. Sulejman
UGLJANIN]; Civic Alliance of Serbia or GSS [Vesna PESIC, chairman];
Yugoslav United Left or JUL [Mirjana MARKOVIC (MILOSEVIC''s wife)]; New
Democracy or ND [Dusan MIHAJLOVIC]; Alliance of Vojvodina Hungarians
or SVM [Jozsef KASZA]
Political pressure groups and leaders: NA
Diplomatic representation in the US: the US and Serbia and Montenegro
do not maintain full diplomatic relations; the Embassy of the former
Socialist Federal Republic of Yugoslavia continues to function in the
US
chief of mission: Ambassador (vacant); Counselor, Charge d''Affaires ad
interim Nebojsa VUJOVIC
chancery: 2410 California St. NW, Washington, DC 20008
telephone: [1] (202) 462-6566
Diplomatic representation from the US: the US and Serbia and
Montenegro do not maintain full diplomatic relations
chief of mission: Ambassador (vacant); Chief of Mission Richard M.
MILES
embassy: Kneza Milosa 50, 11000 Belgrade
mailing address: American Embassy, Belgrade, United States Department
of State, Washington, DC 20521-5070 (pouch); Unit 1310, APO AE
09213-1310
telephone: [381] (11) 645655
FAX: [381] (11) 645332
@Serbia and Montenegro:Economy
Economy-overview: The swift collapse of the Yugoslav federation in
1991 has been followed by highly destructive warfare, the
destabilization of republic boundaries, and the breakup of important
interrepublic trade flows. Output in Serbia and Montenegro dropped by
half in 1992-93. Like the other former Yugoslav republics, it had
depended on its sister republics for large amounts of energy and
manufactures. Wide differences in climate, mineral resources, and
levels of technology among the republics accentuated this
interdependence, as did the communist practice of concentrating much
industrial output in a small number of giant plants. The breakup of
many of the trade links, the sharp drop in output as industrial plants
lost suppliers and markets, and the destruction of physical assets in
the fighting all have contributed to the economic difficulties of the
republics. One singular factor in the economic situation of Serbia is
the continuation in office of a communist government that is primarily
interested in political and military mastery, not economic reform.
Hyperinflation ended with the establishment of a new currency unit in
June 1993; prices have been relatively stable since 1995. Reliable
statistics continue to be hard to come by, and the GDP estimate is
extremely rough. The economic boom anticipated by the government after
the suspension of UN sanctions in December 1995 has failed to
materialize. Until the government cooperates on such matters as human
rights and war criminals, it will lack full support from international
financial institutions.
GDP: purchasing power parity-$24.3 billion (1997 est.)
GDP-real growth rate: 7% (1997 est.)
GDP-per capita: purchasing power parity-$2,280 (1997 est.)
GDP-composition by sector:
agriculture: 25%
industry: 50%
services: 25% (1994 est.)
Inflation rate-consumer price index: 7% (1997)
Labor force:
total: 2.178 million
by occupation: industry 41%, services 35%, trade and tourism 12%,
transportation and communication 7%, agriculture 5% (1994)
Unemployment rate: more than 35% (1995 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: machine building (aircraft, trucks, and automobiles; tanks
and weapons; electrical equipment; agricultural machinery); metallurgy
(steel, aluminum, copper, lead, zinc, chromium, antimony, bismuth,
cadmium); mining (coal, bauxite, nonferrous ore, iron ore, limestone);
consumer goods (textiles, footwear, foodstuffs, appliances);
electronics, petroleum products, chemicals, and pharmaceuticals
Industrial production growth rate: 8% (1997 est.)
Electricity-capacity: 11.779 million kW (1995)
Electricity-production: 33.4 billion kWh (1995)
Electricity-consumption per capita: 3,009 kWh (1995)
Agriculture-products: cereals, fruits, vegetables, tobacco, olives;
cattle, sheep, goats
Exports:
total value: $2.8 billion (1996 est.)
commodities: manufactured goods, food and live animals, raw materials
partners: Russia, Italy, Germany
Imports:
total value: $6.2 billion (1996 est.)
commodities: machinery and transport equipment, fuels and lubricants,
manufactured goods, chemicals, food and live animals, raw materials
partners: Germany, Italy, Russia
Debt-external: $11.2 billion (1995 est.)
Economic aid:
recipient: ODA, $NA
Currency: 1 Yugoslav New Dinar (YD) = 100 paras
Exchange rates: Yugoslav New Dinars (YD) per US $1-official rate: 5.85
(December 1997), 5.02 (September 1996), 1.5 (early 1995); black market
rate: 8.9 (December 1997), 2 to 3 (early 1995)
Fiscal year: calendar year','3305e7a01a562e781242a4d0cee156e3c8ed6509232f498cdfcec19ef9d9bf99','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beaa501989267ac347ce9be2f2955366d2d7750a7d72a442151e20af86a4470c',1990,'SL','Sierra Leone','introduction',226,'Current issues: On 25 May 1997, the democratically-elected government
of President Ahmad Tejan KABBAH was overthrown by disgruntled army
personnel under the command of Major Johnny Paul KOROMA; President
KABBAH fled to exile in Guinea. The Economic Community of West African
States Cease-Fire Monitoring Group (ECOMOG) forces, led by a strong
Nigerian contingent, undertook the suppression of the rebellion. They
were initially unsuccessful, but, by October 1997, they forced the
rebels to agree to a cease-fire and to a plan to return the government
to democratic control by 22 April 1998. However, the agreed
demobilization of the combatants was not carried out by the rebel
junta. On 5 February 1998, hostilities broke out in the outskirts of
Freetown and ECOMOG mounted a major offensive, completely routing the
rebels. President KABBAH returned to office on 10 March to face the
task of restoring order to a demoralized population and a disorganized
and severely damaged economy.
@Sierra Leone:Geography
Location: Western Africa, bordering the North Atlantic Ocean, between
Guinea and Liberia
Geographic coordinates: 8 30 N, 11 30 W
Map references: Africa
Area:
total: 71,740 sq km
land: 71,620 sq km
water: 120 sq km
Area-comparative: slightly smaller than South Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200-m depth or to the depth of exploitation
Climate: tropical; hot, humid; summer rainy season (May to December);
winter dry season (December to April)
Terrain: coastal belt of mangrove swamps, wooded hill country, upland
plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite, iron ore, gold,
chromite
Land use:
arable land: 7%
permanent crops: 1%
permanent pastures: 31%
forests and woodland: 28%
other: 33% (1993 est.)
Irrigated land: 290 sq km (1993 est.)
Natural hazards: dry, sand-laden harmattan winds blow from the Sahara
(November to May); sandstorms, dust storms
Environment-current issues: rapid population growth pressuring the
environment; overharvesting of timber, expansion of cattle grazing,
and slash-and-burn agriculture have resulted in deforestation and soil
exhaustion; civil war depleting natural resources; overfishing
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Endangered
Species, Law of the Sea, Marine Life Conservation, Nuclear Test Ban,
Whaling
signed, but not ratified: Environmental Modification
@Sierra Leone:People
Population: 5,080,004 (July 1998 est.)
Age structure:
0-14 years: 45% (male 1,130,728; female 1,167,084)
15-64 years: 52% (male 1,257,901; female 1,367,902)
65 years and over: 3% (male 79,113; female 77,276) (July 1998 est.)
Population growth rate: 4.01% (1998 est.)
Birth rate: 46.16 births/1,000 population (1998 est.)
Death rate: 17.25 deaths/1,000 population (1998 est.)
Net migration rate: 11.18 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 0.96 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 1.02 male(s)/female (1998 est.)
Infant mortality rate: 129.38 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 48.57 years
male: 45.56 years
female: 51.66 years (1998 est.)
Total fertility rate: 6.23 children born/woman (1998 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne 30%, Mende 30%,
other 30%), Creole 10% (descendents of freed Jamaican slaves who were
settled in the Freetown area in the late-eighteenth century), refugees
from Liberia''s recent civil war, small numbers of Europeans, Lebanese,
Pakistanis and Indians
Religions: Muslim 60%, indigenous beliefs 30%, Christian 10%
Languages: English (official, regular use limited to literate
minority), Mende (principal vernacular in the south), Temne (principal
vernacular in the north), Krio (English-based Creole, spoken by the
descendents of freed Jamaican slaves who were settled in the Freetown
area, a lingua franca and a first language for 10% of the population
but understood by 95%)
Literacy:
definition: age 15 and over can read and write in English, Mende,
Temne, or Arabic
total population: 31.4%
male: 45.4%
female: 18.2% (1995 est.)
@Sierra Leone:Government
Country name:
conventional long form: Republic of Sierra Leone
conventional short form: Sierra Leone
Data code: SL
Government type: constitutional democracy
National capital: Freetown
Administrative divisions: 3 provinces and 1 area*; Eastern, Northern,
Southern, Western*
Independence: 27 April 1961 (from UK)
National holiday: Republic Day, 27 April (1961)
Constitution: 1 October 1991; subsequently amended several times
Legal system: based on English law and customary laws indigenous to
local tribes; has not accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Ahmad Tejan KABBAH (inaugurated 29 March
1996); note-the president is both the chief of state and head of','119e95a61e2f7260f51a75c3fe599971e9c072f46f19639e3e3df0940be08f51','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0673b24e92587acb31e5617dc2651cf35895c3d91207932b6a93e1ed8a075afd',1990,'TJ','Tajikistan','introduction',244,'Current issues: Tajikistan has experienced three changes of government
and a civil war since it gained independence in September 1991. The
current president, Emomali RAHMONOV, was elected in November 1994, yet
has been in power since 1992. A peace agreement was signed in June
1997, but implementation is progressing slowly. Russian-led
peacekeeping troops are deployed throughout the country, and
Russian-commanded border guards are stationed along the
Tajikistani-Afghan border.
@Tajikistan:Geography
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Commonwealth of Independent States
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area-comparative: slightly smaller than Wisconsin
Land boundaries:
total: 3,651 km
border countries: Afghanistan 1,206 km, China 414 km, Kyrgyzstan 870
km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild winters; semiarid
to polar in Pamir Mountains
Terrain: Pamirs and Alay Mountains dominate landscape; western Fergana
Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes:
lowest point: Syrdariya 300 m
highest point: Qullai Kommunizm 7,495 m
Natural resources: significant hydropower potential, some petroleum,
uranium, mercury, brown coal, lead, zinc, antimony, tungsten
Land use:
arable land: 6%
permanent crops: 0%
permanent pastures: 25%
forests and woodland: 4%
other: 65% (1993 est.)
Irrigated land: 6,390 sq km (1993 est.)
Natural hazards: NA
Environment-current issues: inadequate sanitation facilities;
increasing levels of soil salinity; industrial pollution; excessive
pesticides; part of the basin of the shrinking Aral Sea suffers from
severe overutilization of available water for irrigation and
associated pollution
Environment-international agreements:
party to: Biodiversity, Climate Change, Desertification, Ozone Layer
Protection
signed, but not ratified: none of the selected agreements
Geography-note: landlocked
@Tajikistan:People
Population: 6,020,095 (July 1998 est.)
Age structure:
0-14 years: 41% (male 1,258,424; female 1,230,891)
15-64 years: 54% (male 1,616,257; female 1,636,732)
65 years and over: 5% (male 118,485; female 159,306) (July 1998 est.)
Population growth rate: 1.3% (1998 est.)
Birth rate: 27.67 births/1,000 population (1998 est.)
Death rate: 7.77 deaths/1,000 population (1998 est.)
Net migration rate: -6.87 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.74 male(s)/female (1998 est.)
Infant mortality rate: 112.14 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 64.48 years
male: 61.35 years
female: 67.77 years (1998 est.)
Total fertility rate: 3.53 children born/woman (1998 est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 64.9%, Uzbek 25%, Russian 3.5% (declining because
of emigration), other 6.6%
Religions: Sunni Muslim 80%, Shi''a Muslim 5%
Languages: Tajik (official), Russian widely used in government and
business
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 99%
female: 97% (1989 est.)
@Tajikistan:Government
Country name:
conventional long form: Republic of Tajikistan
conventional short form: Tajikistan
local long form: Jumhurii Tojikistan
local short form: none
former: Tajik Soviet Socialist Republic
Data code: TI
Government type: republic
National capital: Dushanbe
Administrative divisions: 2 oblasts (viloyatho, singular-viloyat) and
one autonomous oblast* (viloyati avtonomii); Viloyati Avtonomii
Badakhshoni Kuni* (Khorugh-formerly Khorog), Viloyati Khatlon
(Qurghonteppa-formerly Kurgan-Tyube), Viloyati Leninobod
(Khujand-formerly Leninabad)
note: the administrative center name follows in parentheses
Independence: 9 September 1991 (from Soviet Union)
National holiday: National Day, 9 September (1991)
Constitution: 6 November 1994
Legal system: based on civil law system; no judicial review of
legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Emomali RAHMONOV (since 6 November 1994;
head of state and Assembly chairman since 19 November 1992)
head of government: Prime Minister Yahyo AZIMOV (since 8 February
1996)
cabinet: Council of Ministers appointed by the president who proposes
them to the Supreme Assembly for approval
elections: president elected by popular vote for a five-year term;
election last held 6 November 1994 (next to be held NA 1999); prime
minister appointed by the president
election results: Emomali RAHMONOV elected president; percent of
vote-Emomali RAHMONOV 58%, Abdumalik ABDULLOJANOV 40%
Legislative branch: unicameral Supreme Assembly or Majlisi Oli (181
seats; members are popularly elected to serve five-year terms)
elections: last held 26 February and 12 March 1995 (next to be held NA
2000)
election results: percent of vote by party-NA; estimated seats by
party-Communist Party and affiliates 100, People''s Party 10, Party of
People''s Unity 6, Party of Economic and Political Renewal 1, other 64
Judicial branch: Supreme Court, judges are appointed by the president
Political parties and leaders: People''s Democratic Party of Tajikistan
or PPT [Emomali RAHMONOV]; National Revival Bloc (Party of Popular
Unity and Accord or PPUA) [Abdumalik ABDULLOJONOV]; Tajik Communist
Party or CPT [Shodi SHABDOLOV]; Democratic Party or TDP [Jumaboy
NIYAZOV, chairman]; Islamic Renaissance Party or IRP [Mohammed Sharif
HIMATZODA, chairman]; Rebirth (Rastokhez) [Takhir ABDUZHABOROV]; Lali
Badakhshan Society [Atobek AMIRBEKOV]; Tajikistan Party of Economic
and Political Renewal or TPEPR; Citizenship, Patriotism, Unity Party
[Bobokhon MAHMADOV]; Adolatho "Justice" Party [Abdurahmon KARIMOV,
chairman]; Congress of Popular Unity [Saifuddin TURAYEV]; Party of
Justice and Development [Rahmutullo ZAINAV]
International organization participation: CIS, EAPC, EBRD, ECE, ECO,
ESCAP, FAO, IBRD, ICAO, IDA, IDB, IFAD, IFC, ILO, IMF, Intelsat, IOC,
IOM, ITU, OIC, OSCE, UN, UNCTAD, UNESCO, UNIDO, UPU, WFTU, WHO, WIPO,
WMO, WTrO (observer)
Diplomatic representation in the US: Tajikistan does not have an
embassy in the US, but has a mission at the UN: address-136 East 67th
Street, New York, NY 10021, telephone-[1] (212) 472-7645, FAX-[1]
(212) 628-0252; permanent representative to the UN is Rashid ALIMOV
Diplomatic representation from the US:
chief of mission: Ambassador R. Grant SMITH
embassy: interim chancery, Oktyabrskaya Hotel, 105A Prospect Rudaki,
Dushanbe 734001
mailing address: use embassy street address
telephone: [7] (3772) 21-03-56
FAX: Telex [7] (3772) 20-03-62
Flag description: three horizontal stripes of red (top), a wider
stripe of white, and green; a gold crown surmounted by seven
five-pointed gold stars is located in the center of the white stripe
@Tajikistan:Economy
Economy-overview: Tajikistan has the lowest per capita GDP among the
former Soviet republics. Agriculture dominates the economy, with
cotton the most important crop. Mineral resources, varied but limited
in amount, include silver, gold, uranium, and tungsten. Industry is
limited to a large aluminum plant, hydropower facilities, and small
obsolete factories mostly in light industry and food processing. The
Tajik economy has been gravely weakened by four years of civil
conflict and by the loss of subsidies from Moscow and of markets for
its products. Tajikistan thus depends on aid from Russia and
Uzbekistan and on international humanitarian assistance for much of
its basic subsistence needs. Even if the peace agreement of June 1997
is honored, the country faces major problems in integrating refugees
and former combatants into the economy. Moreover, constant political
turmoil and the continued dominance by former communist officials have
impeded the introduction of meaningful economic reforms.
GDP: purchasing power parity-$4.1 billion (1997 est.)
GDP-real growth rate: -10% (1997 est.)
GDP-per capita: purchasing power parity-$700 (1997 est.)
GDP-composition by sector:
agriculture: 25%
industry: 35%
services: 40% (1997)
Inflation rate-consumer price index: 40% (1996 est.)
Labor force:
total: 1.9 million (1996)
by occupation: agriculture and forestry 52%, manufacturing, mining,
and construction 17%, services 31% (1995)
Unemployment rate: 2.4% includes only officially registered
unemployed; also large numbers of underemployed workers and
unregistered unemployed people (December 1996)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: aluminum, zinc, lead, chemicals and fertilizers, cement,
vegetable oil, metal-cutting machine tools, refrigerators and freezers
Industrial production growth rate: -20% (1996 est.)
Electricity-capacity: 4.443 million kW (1995)
Electricity-production: 14.66 billion kWh (1995)
Electricity-consumption per capita: 2,302 kWh (1995)
Agriculture-products: cotton, grain, fruits, grapes, vegetables;
cattle, sheep, goats
Exports:
total value: $768 million (1996 est.)
commodities: cotton, aluminum, fruits, vegetable oil, textiles
partners: FSU 78%, Netherlands (1994)
Imports:
total value: $657 million (1996 est.)
commodities: fuel, chemicals, machinery and transport equipment,
textiles, foodstuffs
partners: FSU 55%, Switzerland, UK (1994)
Debt-external: $635 million (of which $250 million to Russia) (1995
est.)
Economic aid:
recipient: ODA, $22 million (1993)
note: commitments, $885 million (disbursements $115 million) (1992-95)
Currency: the Tajikistani ruble (TJR) = 100 tanga; Tajikistan
introduced its own currency in May 1995
Exchange rates: Tajikistani rubles (TJR) per US$1-350 (January 1997),
284 (January 1996)
Fiscal year: calendar year','13bb1d4f4963df1319b9785e900c0c793852a50e654527aa57aa149ef93c0e62','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffee9294ab8998908c2b265a7a4e9b941544d20d7885bdb3998ebd086f99be06',1990,'WF','Wallis and Futuna','introduction',268,'Current issues: The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements ("the DOP"), signed in Washington on 13
September 1993, provides for a transitional period not exceeding five
years of Palestinian interim self-government in the Gaza Strip and the
West Bank. Permanent status negotiations began on 5 May 1996, but have
not resumed since the initial meeting. Under the DOP, Israel agreed to
transfer certain powers and responsibilities to the Palestinian
Authority, which includes a Palestinian Legislative Council elected in
January 1996, as part of interim self-governing arrangements in the
West Bank and Gaza Strip. A transfer of powers and responsibilities
for the Gaza Strip and Jericho took place pursuant to the Israel-PLO 4
May 1994 Cairo Agreement on the Gaza Strip and the Jericho Area and in
additional areas of the West Bank pursuant to the Israel-PLO 28
September 1995 Interim Agreement and the Israel-PLO 15 January 1997
Protocol Concerning Redeployment in Hebron. The DOP provides that
Israel will retain responsibility during the transitional period for
external security and for internal security and public order of
settlements and Israelis. Permanent status is to be determined through
direct negotiations.
@West Bank:Geography
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the northwest quarter of
the Dead Sea, but excludes Mt. Scopus; East Jerusalem and Jerusalem No
Man''s Land are also included only as a means of depicting the entire
area occupied by Israel in 1967
Area-comparative: slightly smaller than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, temperature and precipitation vary with altitude,
warm to hot summers, cool to mild winters
Terrain: mostly rugged dissected upland, some vegetation in west, but
barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1,022 m
Natural resources: NEGL
Land use:
arable land: 27%
permanent crops: 0%
permanent pastures: 32%
forests and woodland: 1%
other: 40%
Irrigated land: NA sq km
Natural hazards: NA
Environment-current issues: adequacy of fresh water supply; sewage
treatment
Environment-international agreements:
party to: none of the selected agreements
signed, but not ratified: none of the selected agreements
Geography-note: landlocked; highlands are main recharge area for
Israel''s coastal aquifers; there are 207 Israeli settlements and
civilian land use sites in the West Bank and 29 in East Jerusalem
(August 1997 est.)
@West Bank:People
Population: 1,556,919 (July 1998 est.)
note: in addition, there are 155,000 Israeli settlers in the West Bank
and 164,000 in East Jerusalem (August 1997 est.)
Age structure:
0-14 years: 45% (male 359,848; female 342,173)
15-64 years: 52% (male 405,929; female 396,928)
65 years and over: 3% (male 21,853; female 30,188) (July 1998 est.)
Population growth rate: 3.71% (1998 est.)
Birth rate: 36.65 births/1,000 population (1998 est.)
Death rate: 4.35 deaths/1,000 population (1998 est.)
Net migration rate: 4.82 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.72 male(s)/female (1998 est.)
Infant mortality rate: 26.35 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 72.47 years
male: 70.7 years
female: 74.33 years (1998 est.)
Total fertility rate: 4.92 children born/woman (1998 est.)
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%, Jewish 17%
Religions: Muslim 75% (predominantly Sunni), Jewish 17%, Christian and
other 8%
Languages: Arabic, Hebrew (spoken by Israeli settlers and many
Palestinians), English (widely understood)
Literacy: NA
@West Bank:Government
Country name:
conventional long form: none
conventional short form: West Bank
Data code: WE
@West Bank:Economy
Economy-overview: Economic progress in the West Bank has been hampered
by tight Israeli security restrictions. Industries using advanced
technology or requiring sizable investment have been discouraged by a
lack of local capital and Israeli policies that block the movement of
goods and people. Capital investment consists largely of residential
housing, not productive assets that would enable local Palestinian
firms to compete with Israeli industry. GDP has been substantially
supplemented by workers who commute to jobs in Israel. Worker
remittances from the Persian Gulf states dropped after Iraq invaded
Kuwait in August 1990. In the wake of the Persian Gulf crisis, many
Palestinians have returned to the West Bank, increasing unemployment,
and export revenues have dropped because of the decline of markets in
Jordan and the Gulf states. An estimated 147,000 people were in
refugee camps in 1996.
GDP: purchasing power parity-$2.8 billion (1996 est.)
GDP-real growth rate: -6.9% (1996 est.)
GDP-per capita: purchasing power parity-$1,600 (1996 est.)
GDP-composition by sector:
agriculture: 33%
industry: 25%
services: 42% (1995 est., includes Gaza Strip)
Inflation rate-consumer price index: 8.4% (1996 est.)
Labor force: NA
by occupation: agriculture 13%, industry 13%, commerce, restaurants,
and hotels 12%, construction 8%, other services 54% (1996)
note: excluding Israeli settlers
Unemployment rate: 28% (1997 est.)
Budget:
revenues: $684 million
expenditures: $779 million, including capital expenditures of $NA
(1996)
note: includes Gaza Strip
Industries: generally small family businesses that produce cement,
textiles, soap, olive-wood carvings, and mother-of-pearl souvenirs;
the Israelis have established some small-scale, modern industries in
the settlements and industrial centers
Industrial production growth rate: NA%
Electricity-capacity: NA kW
note: most electricity imported from Israel; East Jerusalem Electric
Company buys and distributes electricity to Palestinians in East
Jerusalem and its concession in the West Bank; the Israel Electric
Company directly supplies electricity to most Jewish residents and
military facilities; at the same time, some Palestinian
municipalities, such as Nabulus and Janin, generate their own
electricity from small power plants
Electricity-production: NA kWh
note: most electricity imported from Israel; East Jerusalem Electric
Company buys and distributes electricity to Palestinians in East
Jerusalem and its concession in the West Bank; the Israel Electric
Company directly supplies electricity to most Jewish residents and
military facilities; at the same time, some Palestinian
municipalities, such as Nabulus and Janin, generate their own
electricity from small power plants
Electricity-consumption per capita: NA kWh
Agriculture-products: olives, citrus and other fruits, vegetables;
beef, dairy products
Exports:
total value: $630 million (f.o.b., 1997 est.) (includes Gaza Strip)
commodities: olives, fruit, vegetables, limestone
partners: Jordan, Israel
Imports:
total value: $1.7 billion (c.i.f., 1997 est.) (includes Gaza Strip)
commodities: food, consumer goods, construction materials
partners: Jordan, Israel
Debt-external: $51 million (1995)
Economic aid:
recipient: ODA, $NA
Currency: 1 new Israeli shekel (NIS) = 100 new agorot; 1 Jordanian
dinar (JD) = 1,000 fils
Exchange rates: new Israeli shekels (NIS) per US$1-3.5340 (December
1997), 3.4494 (1997), 3.1917 (1996), 3.0113 (1995), 3.0111 (1994),
2.8301 (1993); Jordanian dinars (JD) per US$1-0.7090 (January 1998),
0.7090 (1997), 0.7090 (1996), 0.7005 (1995), 0.6987 (1994), 0.6928
(1993)
Fiscal year: calendar year (since 1 January 1992)','81043a2405f1448354fce83d0da2876a63e8fad0dd1812c0c0d614d85ca24f30','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

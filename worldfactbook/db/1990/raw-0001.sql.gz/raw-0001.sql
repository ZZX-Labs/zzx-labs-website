SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('267959dd7acffc8579de51e7b65066b6a09d91732801664fa175c5bbc238dbd6',1990,'','','raw',1,'Approved for Release: 2020/08/12 C06554432 .
Central
Intelligence
Agency
World
Factbook
1990
Approved for Release: 2026/08/12 6065544325
Approved for Release: 2020/08/12 C06554432
é
US Government officials should obtain copies of
The World Factbook directly from their own
organization or through liaison channels from
the Central Intelligence Agency This publica-
tion 1s also available in microfiche, magnetic
tape, or diskettes for microcomputers
This publication may be purchased by telephone
(VISA or MasterCard) or mail from
Superintendent of Documents
US Government Printing Office
Washington, DC 20402-9325
Tel: (202) 783-3238
A subscription to this publication may be pur-
chased from
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4630
or Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, DC 20540
Tel: (202) 707-9527
This publication may be purchased in photocopy,
microfiche, magnetic tape, or diskettes for mi-
crocomputers from
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4650
This publication may be purchased 1n photocopy
or microform from i
Photoduplication Service
Library of Congress
Washington, DC 20540
Tel: (202) 707-5640
Approved for Release: 2020/08/12 C06554432
I
Approved for Release: 2020/08/12 C06554432
Central
\\ Intelligence
Agency
The |
World |
Factbook
1990
The World Factbook is produced annually
by the Central Intelligence Agency for the
use of United States Government officials,
and the style, format, coverage, and
content are designed to meet their specific
requirements.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, DC 20505
(703) 351-2053
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Page
Notes, Definitions, and
Abbreviations vil
Afghanistan 1
Albama 2
Algeria 4
American Samoa 6
Andorra 7
Angola 8
Anguilla 10
Antarctica 1]
Antigua and Barbuda 12
Arctic Ocean 13
Argentina 14
Aruba 16
Ashmore and Cartier Islands 17
Atlantic Ocean 17
Austraha 18
Austria 20
Bahamas, The 21
Bahrain 23
Baker Island 24
Bangladesh 25
Barbados 26
Bassas da India 28
Belgium 28
Belize 30
Benin 31
Bermuda 32
Bhutan 34
Bolivia 35
Botswana 37
Bouvet Island 38
Brazil 38
British Indian Ocean Territory 40
British Virgin Islands 41
Brunei 42
Bulgaria 43
Burkina 45
Burma 47
Burundi 48
Cambodia 50
Cameroon 51
Canada 53
Cape Verde 55
Cayman Islands 56
Central African Republic 57
Chad 59
Chile 61
Approved for Release: 2020/08/12 C06554432
Il
Contents
Page Page
China (also see separate 62 Guatemala 125
Tawwan entry) Guernsey 127
Christmas Island 64 Guinea 128
Clipperton Island 65 Guinea-Bissau 129
Cocos (Keeling) Islands 66 Guyana 131
Colombia 67 H Haiti 132
Comoros 69 Heard Island and McDonald 134
Congo 70 Islands
Cook Islands 72 Honduras 135
Coral Sea Islands 73 Hong Kong 136
Costa Rica 74 Howland Island 138
Cuba 75 Hungary 139
Cyprus 77 I Iceland 140
Czechoslovakia 79 India 142
Denmark 81 Indian Ocean 144
Dyibout: 82 Indonesia 145
Dominica 84 Iran 147
Dominican Republic 85 Iraq 149
Ecuador 87 Iraq-Saudi Arabia Neutral 150
Egypt 88 Zone
El Salvador 90 Ireland 151
Equatorial Guinea 92 Israel (also see separate Gaza 153
Fihiopis 94 Strip and West Bank entries)
Europa Island 95 italy 18
Falkland Islands 96 Ivory Coast i
(Islas Malvinas) J Jamaica 158
Faroe Islands 97 Jan Mayen 160
Fit 99 Japan 160
Finland 100 Jarvis Island 162
France 102 Jersey 163
French Guiana 104 Johnston Atoll 164
French Polynesia 105 Jordan (also see separate 165
French Southern and 107 West Baniseney)
Antarctic Lands Juan de Nova Island 166
Gabon 107 K Kenya 167
Gambia, The 109 Kingman Reef 169
Gaza Strip 110 Kiribati 169
German Democratic Republic 111 Korea, North 171
(East Germany) Korea, South 172
Germany, Federal Republic of 113 Kuwait 174
(West Germany) L Laos 175
Ghana 115 Lebanon 177
Gibraltar 116 Lesotho 179
Glorioso Islands 117 Liberia 181
Greece 118 Libya 182
Greenland 120 Liechtenstein 184
Grenada 121 Luxembourg 185
Guadeloupe 122 M Macau 187
Guam 124 Madagascar 188
Approved for Release: 2020/08/12 C06554432
Page Page Page
Malawi 190 Panama 244 Switzerland 300
Malaysia 191 Papua New Guinea 245 Syria 302
Maldives 193 Paracel Islands 247 T Taiwan entry follows Zimbabwe
Mal 194 ‘ Paraguay 247 Tanzania 304
Malta 196 Peru 249 Thailand 305
Man, Isle of 197 Philippines 250 Togo 307
Marshall Islands 198 Pitcairn Islands 252 Tokelau 309
Martinique 199 Poland 253 Tonga 310
Mauritama 201 Portugal 255 Trinidad and Tobago 311
Mauritius 202 Puerto Rico 257 Tromelin Island 313
Mayotte 204 Q Qatar 258 Tunisia 313
Mexico 205 R Reunion 260 Turkey 315
Micronesia, Federated States of 207 Romania 261 Turks and Caicos Islands 317
Midway Islands 208 Rwanda 263 Tuvalu 318
Monaco 209 S St Helena 264 U Uganda 319
Mongolia 210 St Kitts and Nevis 265 United Arab Emirates 320
Montserrat 211 St Lucia 267 United Kingdom 321
Morocco 212 St Pierre and Miquelon 268 United States 324
Mozambique 214 St Vincent and the Grenadines 269 Uruguay 326
Namibia 215 San Marino 271 Vv Vanuatu 327
Nauru 217 Sao Tome and Principe 272 Vatican City 329
Navassa Island 218 Saud: Arabia 273 Venezuela 330
Nepal 219 Senegal 275 Vietnam 331
Netherlands 220 Seychelles 277 Virgin Islands 333
Netherlands Antilles 222 Sierra Leone 278 W Wake Island 334
New Caledonia 224 Singapore 279 Wallis and Futuna 335
New Zealand 225 Solomon Islands 281 West Bank 336
Nicaragua 227 Somalia 282 Western Sahara 337
Niger 229 South Africa 284 Western Samoa 338
Nigeria 230 South Georgia and the South 286 World 340
Nive 232 Sandwich Islands Y Yemen Arab Republic [Yemen 341
Norfolk Island 233 Soviet Union 286 (Sanaa) or North Yemen]
Northern Mariana Islands 234 Spain 289 Yemen, People’s Democratic 342
Norway 236 Spratly Islands 291 ee ona (Aden)
Oman 237 Sr Lanka 291
Yugoslavia 344
Pacific Islands, Trust Territory 239 Sudan 293 Z Zaire 346
of the (Palau) Suriname 295
Pacific Ocean 240 Svalbard 296 AMS So
Pakistan 241 Swaziland 297 SE Ss
Palmyra Atoll 243 Sweden 299 FAO Soe
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Page
Appendixes A The United Nations System 352
B International Organizations 353
Cc Country Membership in International Organizations 356
D Weights and Measures 364
E Cross-Reference List of Geographic Names 367
Maps I The World (Guide to Regional Maps)
II North America
III Central America and the Caribbean
IV South America
Vv Europe
VI Middle East
VII Africa
VIII Soviet Union, East and South Asia
IX Southeast Asia
XxX Oceania
XI Arctic Region
XII Antarctic Region
XIHI Standard Time Zones of the World
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Notes, Definitions,
and Abbreviations
There have been some significant changes in this edition In the
Goverment section the former Branches entry has been replaced by
three entries—Executive branch, Legislative branch, and Judicial
branch The Leaders entry now has subentries for Chief of State,
Head of Government, and their deputies The Elections entry has
been completely redone with information for each branch of the
national government, including the date for the last election, the date
for the next election, results (percent of vote by candidate or party),
and current distribution of seats by party In the Economy section
there 1s a new entry on Illicit drugs
Abbreviations: (see Appendix B for international organizations)
avdp avoirdupois
cif cost, insurance, and freight
CY calendar year
DWT _ deadweight ton
est estimate
Ex-Im Export-Import Bank of the United States
fob free on board
FRG Federal Republic of Germany (West Germany)
FY fiscal year
GDP gross domestic product
GDR German Democratic Republic (East Germany)
GNP gross national product
GRT gross register ton
km kilometer
km? square kilometer
kW kilowatt
kWh kilowatt-hour
m meter
NA not available
NEGL negligible
nm nautical mile
NZ New Zealand
ODA _ official development assistance
OOF other official flows
PDRY People’s Democratic Republic of Yemen [Yemen
(Aden) or South Yemen]
UAE — United Arab Emirates
UK United Kingdom
US United States
USSR Union of Soviet Socialist Republics (Soviet Union)
YAR Yemen Arab Republic [Yemen (Sanaa) or North
Yemen]
Administrative divisions: The numbers, designatory terms, and first-
order administrative divisions are generally those approved by the
United States Board on Geographic Names (BGN) as of 5 April
1990 Changes that have been reported but not yet acted upon by
BGN are noted
Area: Total area 1s the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggre-
gate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers)
Comparative areas are based on total area equivalents Most entities
are compared with the entire US or one of the 50 states. The smaller
entities are compared with Washington, DC (178 km’, 69 miles’) or
The Mall in Washington, DC (0 59 km’, 0 23 miles’, 146 acres).
Birth rate: The average annual number of births during a year per
1,000 population at midyear Also known as crude birth rate.
Vii
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Notes, Definitions,
and Abbreviations (continued)
Contributors: Information was provided by the Bureau of the Census
(Department of Commerce), Central Intelligence Agency, Defense
Intelligence Agency, Defense Nuclear Agency, Department of State,
Foreign Broadcast Information Service, Navy Operational Intelli-
gence Center and Maritime Administration (merchant marine data),
Office of Territorial and International! Affairs (Department of the
Interior), United States Board on Geographic Names, United States
Coast Guard, and others.
Dates of information: In general, information available as of 1
January 1990 was used 1n the preparation of this edition Population
figures are estimates for 1 July 1990, with population growth rates
estimated for mid-1990 through mid-1991 Mayor political events
have been updated through 30 March 1990 Military age figures are
average annual estimates for 1990-94
Death rate: The average annual number of deaths during a year per
1,000 population at midyear Also known as crude death rate
Diplomatic representation: The US Government has diplomatic rela-
tions with 162 nations There are only 144 US embassies, since some
nations have US ambassadors accredited to them, but no physical US
mission exists The US has diplomatic relations with 149 of the 159
UN members—the exceptions are Albania, Angola, Byelorussia
(constituent republic of the Soviet Union), Cambodia, Cuba, Iran,
Vietnam, People’s Democratic Republic of Yemen [Yemen (Aden) or
South Yemen], Ukraine (constituent republic of the Soviet Union),
and, obviously, the US itself In addition, the US has diplomatic
relations with 13 nations that are not in the UN—Andorra, Federat-
ed States of Micronesia, Kiribati, Liechtenstein, Marshall Islands,
Monaco, Nauru, San Marino, South Korea, Switzerland, Tonga,
Tuvalu, and the Vatican City North Korea 1s not in the UN and the
US does not have diplomatic relations with that nation The US has
not recognized the incorporation of Estonia, Latvia, and Lithuama
into the Soviet Union and continues to accredit the diplomatic
representatives of their last free governments
Disputes: This category includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral
claims of one sort or another Every international land boundary
dispute in the “Guide to International Boundaries,” a map published
by the Department of State, 1s included References to other situa-
tions may also be included that are border- or frontier-relevant, such
as maritime disputes, geopolitical questions, or irredentist issues.
However, inclusion does not necessarily constitute official acceptance
or recognition by the US Government
Entities: Some of the nations, dependent areas, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government Nation refers to a people politically organized into a
sovereign state with a definite territory Dependent area refers to a
broad category of political entities that are associated in some way
with a nation. Names used for page headings are usually the short-
form names as approved by the US Board on Geographic Names The
long-form name 1s included in the Government section and an entry
of “none” indicates a long-form name does not exist. In some
instances, no short-form name exists—then the long-form name must
serve for all usages
There are 249 entities in the Factbook that may be categorized as
follows
Vill
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Notes, Definitions,
and Abbreviations (continued)
NATIONS
157 UN members (There are 159 members 1n the UN, but only 157
are included in The World Factbook because Byelorussia and
Ukraine are constituent republics of the Soviet Union )
15 nations that are not members of the UN—Andorra, Federated
States of Micronesia, Kiribati, Liechtenstein, Marshall Islands,
Monaco, Namibia, Nauru, North Korea, San Marino, South
Korea, Switzerland, Tonga, Tuvalu, Vatican City
OTHER
1 Taiwan
DEPENDENT AREAS
6 Australia—Ashmore and Cartter Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 Denmark—Faroe Islands, Greenland
16 France—Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic
Lands, Glorioso Islands, Guadeloupe, Juan de Nova Island,
Martinique, Mayotte, New Caledonia, Reunion, St Pierre and
Miquelon, Tromelin Island, Wallis and Futuna
2 Netherlands—Aruba, Netherlands Antilles
3 New Zealand—Cook Islands, Niue, Tokelau
3 Norway—Bouvet Island, Jan Mayen, Svalbard
1 Portugal—Macau
16 United Kingdom—Anguilla, Bermuda, British Indian Ocean
Territory, British Virgin Islands, Cayman Islands, Falkland Is-
lands, Gibraltar, Guernsey, Hong Kong, Isle of Man, Jersey,
Montserrat, Pitcairn Islands, St Helena, South Georgia and the
South Sandwich Islands, Turks and Caicos Islands
15 United States—American Samoa, Baker Island, Guam, Howland
Island, Jarvis Island, Johnston Atoll, Kingman Reef, Midway
Islands, Navassa Island, Northern Mariana Islands, Palmyra
Atoll, Puerto Rico, Trust Territory of the Pacific Islands (Palau),
Virgin Islands, Wake Island
MISCELLANEOUS
7 Antarctica, Gaza Strip, Iraq-Saudi Arabia Neutral Zone, Paracel
Islands, Spratly Islands, West Bank, Western Sahara
OTHER ENTITIES
4 oceans—Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific
Ocean
1 World
249 total
Notes The US Government has not recognized the incorporation of
Estonia, Latvia, and Lithuania into the Soviet Union as constituent
republics during World War II Those Baltic states are not members
of the UN and are not included in the list of nations The US
Government does not recognize the four so-called “independent”
homelands of Bophuthatswana, Ciske1, Transkei, and Venda in South
Africa
Gross domestic product (GDP): The value of all goods and services
produced domestically.
Gross national product (GNP): The value of all goods and services
produced domestically, plus income earned abroad, minus income
earned by foreigners from domestic production
1X
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Notes, Definitions,
and Abbreviations (continued)
GNP/GDP methodology: GNP/GDP dollar estimates for the OECD
countries, the USSR, Eastern Europe, and a portion of the developing
countries, are derived from purchasing power parity (PPP) calculations
rather than from conversions at official currency exchange rates The
PPP methods involve the use of average price weights, which lie
between the weights of the domestic and foreign price systems; using
these weights US $100 converted into German marks by a PPP
method will buy an equal amount of goods and services in both the
US and Germany. One caution the proportion of, say, military
expenditures as a percent of GNP/GDP 1n local currency accounts
may differ substantially from the proportion when GNP/GDP 1s
expressed in PPP dollar terms, as, for example, when an observer
estimates the dollar level of Soviet or Japanese military expenditures
Similarly, dollar figures for exports and imports reflect the price
patterns of international markets rather than PPP price patterns
Growth rate (population): The annual percent change in the popula-
tion, resulting from a surplus (or deficit) of births over deaths and the
balance of migrants entering and leaving a country The rate may be
positive or negative.
Illicit drugs: There are five categories of illicit drugs—narcotics,
stimulants, depressants (sedatives), hallucinogens, and cannabis
These categories include many drugs legally produced and prescribed
by doctors as well as those illegally produced and sold outside medical
channels
Cannabis (Cannabis sativa) is the common hemp plant, provides
hallucinogens with some sedative properties, and includes marijuana
(pot, Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Mar-
nol), hashish (hash), and hashish oil (hash oil)
Coca (Erythroxylon coca) is a bush and the leaves contain the
stimulant cocaine Coca 1s not to be confused with cocoa which comes
from cacao seeds and 1s used 1n making chocolate, cocoa, and cocoa
butter
Cocaine 1s a stimulant derived from the leaves of the coca bush
Depressants (sedatives) are drugs that reduce tension and anxiety
and include chloral hydrate, barbiturates (Amytal, Nembutal, Se-
conal, phenobarbital), benzodiazepines (Librium, Valium), methaqua-
lone (Quaalude), glutethimide (Doriden), and others (Equanil, Placi-
dyl, Valmid)
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change 1n an individual
Drug abuse 1s the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual
Hallucinogens are drugs that affect sensation, thinking, self-
awareness, and emotion Hallucinogens include LSD (acid, microdot),
mescaline and peyote (mexc, buttons, cactus), amphetamine variants
(PMA, STP, DOB), phencyclidine (PCP, angel dust, hog), phencycli-
dine analogues (PCE, PCPy, TCP), and others (psilocybin, psilocyn)
Hashish 1s the resinous exudate of the cannabis or hemp plant
(Cannabis sativa)
Heroin is a semisynthetic derivative of morphine
Marjuana ts the dried leaves of the cannabis or hemp plant
(Cannabis sativa)
Narcotics are drugs that relieve pain, often induce sleep, and refer
to opium, opium derivatives, and synthetic substitutes Natural
narcotics include opium (paregoric, parepectolin), morphine (MS-
Contin, Roxanol), codeine (Tylenol w/codeine, Empirin w/codeine,
Robitussan A-C), and thebaine Semisynthetic narcotics include
heroin (horse, smack) and hydromorphone (Dilaudid) Synthetic nar-
cotics include meperidine or Pethidine (Demerol, Mepergan), metha-
done (Dolophine, Methadose), and others (Darvon, Lomotil)
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Notes, Definitions,
and Abbreviations (continued)
Opium 1s the milky exudate of the incised, unripe seedpod of the
opium poppy
Opium poppy (Papaver somniferum) 1s the source for many natural
and semisynthetic narcotics
Poppy straw concentrate is the alkaloid derived from the mature
dried opium poppy
Qat (kat, khat) 1s a stimulant from the buds or leaves of Catha
edulis and 1s chewed or drunk as tea
Stimulants are drugs that relieve mild depression, increase energy
and activity, and include cocaine (coke, snow, crack), amphetamines
(Desoxyn, Dexedrine), phenmetrazine (Preludin), methylphenidate
(Ritalin), and others (Cylert, Sanorex, Tenuate)
Infant mortality rate: The number of deaths to infants under one year
of age in a given year per 1,000 live births occurring in the same year
Land use: Human use of the land surface 1s categorized as arable
land—iand cultivated for crops that are replanted after each harvest
(wheat, maize, rice), permanent crops—tand cultivated for crops that
are not replanted after each harvest (citrus, coffee, rubber), meadows
and pastures—land permanently used for herbaceous forage crops,
forest and woodland—iand under dense or open stands of trees; and
other—any land type not specifically mentioned above (urban areas,
roads, desert) The percentage figure for irrigated refers to the portion
of the entire amount of land area that 1s artificially supplied with
water
Leaders: The chief of state 1s the titular leader of the country who
represents the state at official and ceremonial functions but 1s not
involved with the day-to-day activities of the government The head
of government 1s the administrative leader who manages the day-to-
day activities of the government In the UK, the monarch is the chief
of state and the prime minister 1s the head of government. In the US,
the President 1s both the chief of state and the head of government.
Life expectancy at birth: The average number of years to be lived by
a group of people all born in the same year, if mortality at each age
remains constant in the future.
Maritime claims: The proximity of neighboring states may prevent
some national claims from being fully extended
Merchant marine: All ships engaged in the carriage of goods All
commercial vessels (as opposed to all nonmilitary ships), which
excludes tugs, fishing vessels, offshore oil rigs, etc Also, a grouping of
merchant ships by nationality or register.
Captive register—A register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships
owned in the parent country Also referred to as an offshore register,
the offshore equivalent of an internal register. Ships on a captive
register will fly the same flag as the parent country, or a local variant
of it, but will be subyect to the maritime laws and taxation rules of the
offshore territory Although the nature of a captive register makes it
especially desirable for ships owned in the parent country, just as in
the internal register, the ships may also be owned abroad. The captive
register then acts as a flag of convemience register, except that it 1s
not the register of an independent state
Flag of convenience register—A national register offering registra-
tion to a merchant ship not owned in the flag state The major flags of
convenience (FOC) attract ships to their register by virtue of low fees,
Xi
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
xii
Notes, Definitions,
and Abbreviations (continued)
low or nonexistent taxation of profits, and liberal manning require-
ments True FOC registers are characterized by having relatively few
of the ships registered actually owned in the flag state Thus, while
virtually any flag can be used for ships under a given set of
circumstances, an FOC register 1s one where the majority of the
merchant fleet 1s owned abroad It 1s also referred to as an open
register
Flag state—The nation 1n which a ship 1s registered and which
holds legal jurisdiction over operation of the ship, whether at home or
abroad Differences 1n flag state maritime legislation determine how
a ship 1s manned and taxed and whether a foreign-owned ship may be
placed on the register
Internal register—A register of ships maintained as a subset of a
National register Ships on the internal register fly the national flag
and have that nationality but are subject to a separate set of maritime
rules from those on the main national register These differences
usually include lower taxation of profits, manning by foreign nation-
als, and, usually, ownership outside the flag state (when it function','6a9cefbb71f664b9cf6bb0006f01f72da1704734b59df536beac4b0e2f655d4c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9641cd853df7acd5cf51b64bcad8ee8f7f8a30eada66d2fb42ab7fcd9e29c8',1990,'','','raw',2,'s
as an FOC register) The Norwegian International Ship Register and
Danish International Ship Register are the most notable examples of
an internal register Both have been instrumental in stemming flight
from the national flag to flags of convemence and in attracting
foreign-owned ships to the Norwegian and Danish flags
Merchant ship—A vessel that carries goods against payment of
freight Commonly used to denote any nonmilitary ship but accurate-
ly restricted to commercial vessels only
Register—The record of a ship’s ownership and nationality as
listed with the maritime authorities of a country Also, the compendi-
um of such individual ships’ registrations Registration of a ship
provides it with a nationality and makes it subject to the laws of the
country 1n which registered (the flag state) regardless of the national-
ity of the ship’s ultimate owner
Money figures: All are expressed in contemporaneous US dollars
unless otherwise indicated
Net migration rate: The balance between the number of persons
entering and leaving a country during the year per 1,000 persons
(based on midyear population) An excess of persons entering the
country 1s referred to as net immigration (3.56 migrants/ 1,000
population), an excess of persons leaving the country as net emigra-
tion (—9 26 migrants/1,000 population)
Population: Figures are estimates from the Bureau of the Census
based on statistics from population censuses, vital registration sys-
tems, or sample surveys pertaining to the recent past, and on
assumptions about future trends
Total fertility rate: The average number of children that would be
born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each age
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY)
Approved for Release: 2020/08/12 C06554432','71d0224ef48ebede74d461a2ec190e9b8d1b490db76f884ab20e7be049ec7e4c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dc81c32a838d49f75f5cf68c27b43e5509675c4b47750de87961f9cd340464a',1990,'','','raw',1,'*The Project Gutenberg Etext of The CIA World Factbook for 1998*
by the United States Central Intelligence Agency (CIA)
Copyright laws are changing all over the world, be sure to check
the copyright laws for your country before posting these files!!
Please take a look at the important information in this header.
We encourage you to keep this file on your own disk, keeping an
electronic path open for the next readers. Do not remove this.
**Welcome To The World of Free Plain Vanilla Electronic Texts**
**Etexts Readable By Both Humans and By Computers, Since 1971**
*These Etexts Prepared By Hundreds of Volunteers and Donations*
Information on contacting Project Gutenberg to get Etexts, and
further information is included below. We need your donations.
The World Factbook 1998
by The United States Central Intelligence Agency (CIA)
December, 1999 [Etext #2016]
*The Project Gutenberg Etext of The CIA World Factbook for 1998*
******This file should be named world98.txt or world98.zip******
Corrected EDITIONS of our etexts get a new NUMBER, world981.txt
VERSIONS based on separate sources get new LETTER, world98a.txt
This etext was prepared by Dr. Gregory B. Newby, as taken from
the CIA''s online version of the book published at the address:
http://www.odci.gov/cia/publications/factbook/guide.html Note
the original book includes maps and other graphics. These are
not included in the Project Gutenberg edition. The tables may
not correctly align due to limitations of HTML conversion, but
are otherwise intact. It is past experience that the CIA does
not maintain past versions of The Factbook online. Hopefully,
the Project Gutenberg edition will be useful to you for a long
time in the future.
Project Gutenberg Etexts are usually created from multiple editions,
all of which are in the Public Domain in the United States, unless a
copyright notice is included. Therefore, we do usually do NOT! keep
these books in compliance with any particular paper edition.
We are now trying to release all our books one month in advance
of the official release dates, leaving time for better editing.
Please note: neither this list nor its contents are final till
midnight of the last day of the month of any such announcement.
The official release date of all Project Gutenberg Etexts is at
Midnight, Central Time, of the last day of the stated month. A
preliminary version may often be posted for suggestion, comment
and editing by those who wish to do so. To be sure you have an
up to date first edition [xxxxx10x.xxx] please check file sizes
in the first week of the next month. Since our ftp program has
a bug in it that scrambles the date [tried to fix and failed] a
look at the file size will have to do, but we will try to see a
new copy has at least one byte more or less.
Information about Project Gutenberg (one page)
We produce about two million dollars for each hour we work. The
time it takes us, a rather conservative estimate, is fifty hours
to get any etext selected, entered, proofread, edited, copyright
searched and analyzed, the copyright letters written, etc. This
projected audience is one hundred million readers. If our value
per text is nominally estimated at one dollar then we produce $2
million dollars per hour this year as we release thirty-six text
files per month, or 432 more Etexts in 1999 for a total of 2000+
If these reach just 10% of the computerized population, then the
total should reach over 200 billion Etexts given away this year.
The Goal of Project Gutenberg is to Give Away One Trillion Etext
Files by December 31, 2001. [10,000 x 100,000,000 = 1 Trillion]
This is ten thousand titles each to one hundred million readers,
which is only ~5% of the present number of computer users.
At our revised rates of production, we will reach only one-third
of that goal by the end of 2001, or about 3,333 Etexts unless we
manage to get some real funding; currently our funding is mostly
from Michael Hart''s salary at Carnegie-Mellon University, and an
assortment of sporadic gifts; this salary is only good for a few
more years, so we are looking for something to replace it, as we
don''t want Project Gutenberg to be so dependent on one person.
We need your donations more than ever!
All donations should be made to "Project Gutenberg/CMU": and are
tax deductible to the extent allowable by law. (CMU = Carnegie-
Mellon University).
For these and other matters, please mail to:
Project Gutenberg
P. O. Box 2782
Champaign, IL 61825
When all other email fails. . .try our Executive Director:
Michael S. Hart <hart@pobox.com>
hart@pobox.com forwards to hart@prairienet.org and archive.org
if your mail bounces from archive.org, I will still see it, if
it bounces from prairienet.org, better resend later on. . . .
We would prefer to send you this information by email.
******
To access Project Gutenberg etexts, use any Web browser
to view http://promo.net/pg. This site lists Etexts by
author and by title, and includes information about how
to get involved with Project Gutenberg. You could also
download our past Newsletters, or subscribe here. This
is one of our major sites, please email hart@pobox.com,
for a more complete list of our various sites.
To go directly to the etext collections, use FTP or any
Web browser to visit a Project Gutenberg mirror (mirror
sites are available on 7 continents; mirrors are listed
at http://promo.net/pg).
Mac users, do NOT point and click, typing works better.
Example FTP session:
ftp metalab.unc.edu
login: anonymous
password: your@login
cd pub/docs/books/gutenberg
cd etext90 through etext99
dir [to see files]
get or mget [to get files. . .set bin for zip files]
GET GUTINDEX.?? [to get a year''s listing of books, e.g., GUTINDEX.99]
GET GUTINDEX.ALL [to get a listing of ALL books]
***
**Information prepared by the Project Gutenberg legal advisor**
(Three Pages)
***START**THE SMALL PRINT!**FOR PUBLIC DOMAIN ETEXTS**START***
Why is this "Small Print!" statement here? You know: lawyers.
They tell us you might sue us if there is something wrong with
your copy of this etext, even if you got it for free from
someone other than us, and even if what''s wrong is not our
fault. So, among other things, this "Small Print!" statement
disclaims most of our liability to you. It also tells you how
you can distribute copies of this etext if you want to.
*BEFORE!* YOU USE OR READ THIS ETEXT
By using or reading any part of this PROJECT GUTENBERG-tm
etext, you indicate that you understand, agree to and accept
this "Small Print!" statement. If you do not, you can receive
a refund of the money (if any) you paid for this etext by
sending a request within 30 days of receiving it to the person
you got it from. If you received this etext on a physical
medium (such as a disk), you must return it with your request.
ABOUT PROJECT GUTENBERG-TM ETEXTS
This PROJECT GUTENBERG-tm etext, like most PROJECT GUTENBERG-
tm etexts, is a "public domain" work distributed by Professor
Michael S. Hart through the Project Gutenberg Association at
Carnegie-Mellon University (the "Project"). Among other
things, this means that no one owns a United States copyright
on or for this work, so the Project (and you!) can copy and
distribute it in the United States without permission and
without paying copyright royalties. Special rules, set forth
below, apply if you wish to copy and distribute this etext
under the Project''s "PROJECT GUTENBERG" trademark.
To create these etexts, the Project expends considerable
efforts to identify, transcribe and proofread public domain
works. Despite these efforts, the Project''s etexts and any
medium they may be on may contain "Defects". Among other
things, Defects may take the form of incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other
intellectual property infringement, a defective or damaged
disk or other etext medium, a computer virus, or computer
codes that damage or cannot be read by your equipment.
LIMITED WARRANTY; DISCLAIMER OF DAMAGES
But for the "Right of Replacement or Refund" described below,
[1] the Project (and any other party you may receive this
etext from as a PROJECT GUTENBERG-tm etext) disclaims all
liability to you for damages, costs and expenses, including
legal fees, and [2] YOU HAVE NO REMEDIES FOR NEGLIGENCE OR
UNDER STRICT LIABILITY, OR FOR BREACH OF WARRANTY OR CONTRACT,
INCLUDING BUT NOT LIMITED TO INDIRECT, CONSEQUENTIAL, PUNITIVE
OR INCIDENTAL DAMAGES, EVEN IF YOU GIVE NOTICE OF THE
POSSIBILITY OF SUCH DAMAGES.
If you discover a Defect in this etext within 90 days of
receiving it, you can receive a refund of the money (if any)
you paid for it by sending an explanatory note within that
time to the person you received it from. If you received it
on a physical medium, you must return it with your note, and
such person may choose to alternatively give you a replacement
copy. If you received it electronically, such person may
choose to alternatively give you a second opportunity to
receive it electronically.
THIS ETEXT IS OTHERWISE PROVIDED TO YOU "AS-IS". NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, ARE MADE TO YOU AS
TO THE ETEXT OR ANY MEDIUM IT MAY BE ON, INCLUDING BUT NOT
LIMITED TO WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE.
Some states do not allow disclaimers of implied warranties or
the exclusion or limitation of consequential damages, so the
above disclaimers and exclusions may not apply to you, and you
may have other legal rights.
INDEMNITY
You will indemnify and hold the Project, its directors,
officers, members and agents harmless from all liability, cost
and expense, including legal fees, that arise directly or
indirectly from any of the following that you do or cause:
[1] distribution of this etext, [2] alteration, modification,
or addition to the etext, or [3] any Defect.
DISTRIBUTION UNDER "PROJECT GUTENBERG-tm"
You may distribute copies of this etext electronically, or by
disk, book or any other medium if you either delete this
"Small Print!" and all other references to Project Gutenberg,
or:
[1] Only give exact copies of it. Among other things, this
requires that you do not remove, alter or modify the
etext or this "small print!" statement. You may however,
if you wish, distribute this etext in machine readable
binary, compressed, mark-up, or proprietary form,
including any form resulting from conversion by word pro-
cessing or hypertext software, but only so long as
*EITHER*:
[*] The etext, when displayed, is clearly readable, and
does *not* contain characters other than those
intended by the author of the work, although tilde
(~), asterisk (*) and underline (_) characters may
be used to convey punctuation intended by the
author, and additional characters may be used to
indicate hypertext links; OR
[*] The etext may be readily converted by the reader at
no expense into plain ASCII, EBCDIC or equivalent
form by the program that displays the etext (as is
the case, for instance, with most word processors);
OR
[*] You provide, or agree to also provide on request at
no additional cost, fee or expense, a copy of the
etext in its original plain ASCII form (or in EBCDIC
or other equivalent proprietary form).
[2] Honor the etext refund and replacement provisions of this
"Small Print!" statement.
[3] Pay a trademark license fee to the Project of 20% of the
net profits you derive calculated using the method you
already use to calculate your applicable taxes. If you
don''t derive profits, no royalty is due. Royalties are
payable to "Project Gutenberg Association/Carnegie-Mellon
University" within the 60 days following each
date you prepare (or were legally required to prepare)
your annual (or equivalent periodic) tax return.
WHAT IF YOU *WANT* TO SEND MONEY EVEN IF YOU DON''T HAVE TO?
The Project gratefully accepts contributions in money, time,
scanning machines, OCR software, public domain etexts, royalty
free copyright licenses, and every other sort of contribution
you can think of. Money should be paid to "Project Gutenberg
Association / Carnegie-Mellon University".
*END*THE SMALL PRINT! FOR PUBLIC DOMAIN ETEXTS*Ver.04.29.93*END*
This etext was prepared by Dr. Gregory B. Newby, as taken from
the CIA''s online version of the book published at the address:
http://www.odci.gov/cia/publications/factbook/guide.html Note
the original book includes maps and other graphics. These are
not included in the Project Gutenberg edition. The tables may
not correctly align due to limitations of HTML conversion, but
are otherwise intact. It is past experience that the CIA does
not maintain past versions of The Factbook online. Hopefully,
the Project Gutenberg edition will be useful to you for a long
time in the future.
The World Factbook 1998
TABLE OF CONTENTS
Countries are listed in alphabetical order. Notes and
appendixes follow the country listings.','59068e2a88f1f441fc0d819e93f5e8ba82cbf80622e240e5a943d69a026d6da5','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b116ea47037dcc6c1f820139d9cb7aa8dfc1daf29bffd09ea9ddd97d6ba1b67e',1990,'ZW','Zimbabwe','raw',2,'Notes and Definitions
Appendixes
Appendix A: Abbreviations
Appendix B: United Nations System
Appendix C: International Organizations and Groups
Appendix D: Selected International Environmental Agreements
Appendix E: Weights and Measures
Appendix F: Cross-Reference List of Country Data Codes
Appendix G: Cross-Reference List of Hydrographic Codes
Appendix H: Cross-Reference List of Geographic Names
History
Contributors and Copyright Information
Purchase Information
______________________________________________________________________','5296dbc67f9a9e3333f62b6d9117af24a6766695357b35a3841d6802970552b0','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ba74e8b302d7680c55d74ef20df16a0346e717032f958fc545794a19810a5d4',1990,'AF','Afghanistan','raw',3,'@Afghanistan:Geography
Location: Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area-comparative: slightly smaller than Texas
Land boundaries:
total: 5,529 km
border countries: China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot summers
Terrain: mostly rugged mountains; plains in north and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal, copper, talc,
barites, sulfur, lead, zinc, iron ore, salt, precious and semiprecious
stones
Land use:
arable land: 12%
permanent crops: 0%
permanent pastures: 46%
forests and woodland: 3%
other: 39% (1993 est.)
Irrigated land: 30,000 sq km (1993 est.)
Natural hazards: damaging earthquakes occur in Hindu Kush mountains;
flooding
Environment-current issues: soil degradation; overgrazing;
deforestation (much of the remaining forests are being cut down for
fuel and building materials); desertification
Environment-international agreements:
party to: Desertification, Endangered Species, Environmental
Modification, Marine Dumping, Nuclear Test Ban
signed, but not ratified: Biodiversity, Climate Change, Hazardous
Wastes, Law of the Sea, Marine Life Conservation
Geography-note: landlocked
@Afghanistan:People
Population: 24,792,375 (July 1998 est.)
Age structure:
0-14 years: 43% (male 5,425,510; female 5,216,954)
15-64 years: 54% (male 6,978,549; female 6,494,253)
65 years and over: 3% (male 357,780; female 319,329) (July 1998 est.)
Population growth rate: 4.21% (1998 est.)
note: this rate reflects the continued return of refugees
Birth rate: 42.37 births/1,000 population (1998 est.)
Death rate: 17.4 deaths/1,000 population (1998 est.)
Net migration rate: 17.14 migrant(s)/1,000 population (1998 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1.07 male(s)/female
65 years and over: 1.12 male(s)/female (1998 est.)
Infant mortality rate: 143.63 deaths/1,000 live births (1998 est.)
Life expectancy at birth:
total population: 46.83 years
male: 47.35 years
female: 46.29 years (1998 est.)
Total fertility rate: 6.01 children born/woman (1998 est.)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 38%, Tajik 25%, Uzbek 6%, Hazara 19%, minor
ethnic groups (Aimaks, Turkmen, Baloch, and others)
Religions: Sunni Muslim 84%, Shi''a Muslim 15%, other 1%
Languages: Pashtu 35%, Afghan Persian (Dari) 50%, Turkic languages
(primarily Uzbek and Turkmen) 11%, 30 minor languages (primarily
Balochi and Pashai) 4%, much bilingualism
Literacy:
definition: age 15 and over can read and write
total population: 31.5%
male: 47.2%
female: 15% (1995 est.)
@Afghanistan:Government
Country name:
conventional long form: Islamic State of Afghanistan; note-the
self-proclaimed Taliban government refers to the country as Islamic
Emirate of Afghanistan
conventional short form: Afghanistan
local long form: Dowlat-e Eslami-ye Afghanestan
local short form: Afghanestan
former: Republic of Afghanistan
Data code: AF
Government type: transitional government
National capital: Kabul
Administrative divisions: 30 provinces (velayat, singular-velayat);
Badakhshan, Badghis, Baghlan, Balkh, Bamian, Farah, Faryab, Ghazni,
Ghowr, Helmand, Herat, Jowzjan, Kabol, Kandahar, Kapisa, Konar,
Kondoz, Laghman, Lowgar, Nangarhar, Nimruz, Oruzgan, Paktia, Paktika,
Parvan, Samangan, Sar-e Pol, Takhar, Vardak, Zabol
note: there may be two new provinces of Nurestan (Nuristan) and Khowst
Independence: 19 August 1919 (from UK control over Afghan foreign
affairs)
National holiday: Victory of the Muslim Nation, 28 April; Remembrance
Day for Martyrs and Disabled, 4 May; Independence Day, 19 August
Constitution: none
Legal system: a new legal system has not been adopted but all factions
tacitly agree they will follow Shari''a (Islamic law)
Suffrage: undetermined; previously males 15-50 years of age
Executive branch: on 27 September 1996, the ruling members of the
Afghan Government were displaced by members of the Islamic Taliban
movement; the Islamic State of Afghanistan has no functioning
government at this time, and the country remains divided among
fighting factions
note: the Taliban have declared themselves the legitimate government
of Afghanistan; the UN has deferred a decision on credentials and the
Organization of the Islamic Conference has left the Afghan seat vacant
until the question of legitimacy can be resolved through negotiations
among the warring factions; the country is essentially divided along
ethnic lines; the Taliban controls the capital of Kabul and
approximately two-thirds of the country including the predominately
ethnic Pashtun areas in southern Afghanistan; opposing factions have
their stronghold in the ethnically diverse north-General DOSTAM''s
National Islamic Movement controls several northcentral provinces and
Commander MASOOD controls the ethnic Tajik majority areas of the
northeast
Legislative branch: non-functioning as of June 1993
Judicial branch: non-functioning as of March 1995, although there are
local Shari''a (Islamic law) courts throughout the country
Political parties and leaders: Taliban (Religious Students Movement),
Mohammad OMAR; United Islamic Front for the Salvation of Afghanistan
[comprised of Jumbesh-i-Melli Islami (National Islamic Movement),
Abdul Rashid DOSTAM; Jamiat-i-Islami (Islamic Society), Burhanuddin
RABBANI and Ahmad Shah MASOOD; and Hizbi Wahdat-Khalili faction
(Islamic Unity Party), Abdul Karim KHALILI]; other smaller parties are
Hizbi Islami-Gulbuddin (Islamic Party), Gulbuddin HIKMATYAR faction;
Hizbi Islami-Khalis (Islamic Party), Yunis KHALIS faction;
Ittihad-i-Islami Barai Azadi Afghanistan (Islamic Union for the
Liberation of Afghanistan), Abdul Rasul SAYYAF;
Harakat-Inqilab-i-Islami (Islamic Revolutionary Movement), Mohammad
Nabi MOHAMMADI; Jabha-i-Najat-i-Milli Afghanistan (Afghanistan
National Liberation Front), Sibghatullah MOJADDEDI;
Mahaz-i-Milli-Islami (National Islamic Front), Sayed Ahamad GAILANI;
Hizbi Wahdat-Akbari faction (Islamic Unity Party), Mohammad Akbar
AKBARI; Harakat-i-Islami (Islamic Movement), Mohammed Asif MOHSENI
Political pressure groups and leaders: tribal elders represent
traditional Pashtun leadership; Afghan refugees in Pakistan,
Australia, US, and elsewhere have organized politically; Peshawar,
Pakistan-based groups such as the Coordination Council for National
Unity and Understanding in Afghanistan (CUNUA), Ishaq GAILANI; Writers
Union of Free Afghanistan (WUFA), A. Rasul AMIN; Mellat (Social
Democratic Party), leader NA
International organization participation: AsDB, CP, ECO, ESCAP, FAO,
G-77, IAEA, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
Intelsat, IOC, IOM (observer), ITU, NAM, OIC, UN, UNCTAD, UNESCO,
UNIDO, UPU, WFTU, WHO, WMO, WToO
Diplomatic representation in the US:
note: embassy operations suspended 21 August 1997
chief of mission: Ambassador (vacant)
chancery: 2341 Wyoming Avenue NW, Washington, DC 20008
telephone: [1] (202) 234-3770
FAX: [1] (202) 328-3516
consulate(s) general: New York
Diplomatic representation from the US: the US embassy in Kabul has
been closed since January 1989 due to security concerns
Flag description: three equal horizontal bands of green (top), white,
and black with a gold emblem centered on the three bands; the emblem
features a temple-like structure with Islamic inscriptions above and
below, encircled by a wreath on the left and right and by a bolder
Islamic inscription above, all of which are encircled by two crossed
scimitars
note: the Taliban uses a plain white flag
@Afghanistan:Economy
Economy-overview: Afghanistan is an extremely poor, landlocked
country, highly dependent on farming and livestock raising (sheep and
goats). Economic considerations have played second fiddle to political
and military upheavals during more than 18 years of war, including the
nearly 10-year Soviet military occupation (which ended 15 February
1989). During the war one-third of the population fled the country,
with Pakistan and Iran sheltering a combined peak of more than 6
million refugees. Now, only 750,000 registered Afghan refugees remain
in Pakistan and about 1.2 million in Iran. Another 1 million have
probably moved into and around urban areas within Afghanistan. Gross
domestic product has fallen substantially over the past 18 years
because of the loss of labor and capital and the disruption of trade
and transport. Much of the population continues to suffer from
insufficient food, clothing, housing, and medical care. Inflation
remains a serious problem throughout the country, with one estimate
putting the rate at 240% in Kabul in 1996. Numerical data are likely
to be either unavailable or unreliable.
GDP: purchasing power parity-$19.3 billion (1997 est.)
GDP-real growth rate: NA%
GDP-per capita: purchasing power parity-$800 (1997 est.)
GDP-composition by sector:
agriculture: 53%
industry: 28.5%
services: 18.5% (1990)
Inflation rate-consumer price index: 240% (1996 est.)
Labor force:
total: 7.1 million
by occupation: agriculture and animal husbandry 67.8%, industry 10.2%,
construction 6.3%, commerce 5.0%, services and other 10.7% (1980 est.)
Unemployment rate: 8% (1995 est.)
Budget:
revenues: $NA
expenditures: $NA, including capital expenditures of $NA
Industries: small-scale production of textiles, soap, furniture,
shoes, fertilizer, and cement; handwoven carpets; natural gas, oil,
coal, copper
Electricity-capacity: 494,000 kW (1995)
Electricity-production: 655 million kWh (1995)
Electricity-consumption per capita: 37 kWh (1995)
Agriculture-products: wheat, fruits, nuts, karakul pelts; wool, mutton
Exports:
total value: $80 million (1996 est.)
commodities: fruits and nuts, handwoven carpets, wool, cotton, hides
and pelts, precious and semi-precious gems
partners: FSU, Pakistan, Iran, Germany, India, UK, Belgium,
Luxembourg, Czechoslovakia
Imports:
total value: $150 million (1996 est.)
commodities: food and petroleum products; most consumer goods
partners: FSU, Pakistan, Iran, Japan, Singapore, India, South Korea,','2e3bb889511abf75e37a431ef0c2fd6c556e3cb57715d549eaf3ba15c1a01e3a','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf5ccfff050bb053e8f78e4e2edb0ba039250f0bacbd69d25efbe30d37f5b32d',1990,'DE','Germany','raw',4,'Debt-external: $2.3 billion (March 1991 est.)
Economic aid:
recipient: ODA; about $45 million in UN aid plus additional bilateral
aid and aid in kind (1997)
note: US provided $450 million in bilateral assistance (1985-93); US
continues to contribute to multilateral assistance through the UN
programs of food aid, immunization, land mine removal, and a wide
range of aid to refugees and displaced persons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (Af) per US$1-17,000 (December 1996), 7,000
(January 1995), 1,900 (January 1994), 1,019 (March 1993), 850 (1991);
note-these rates reflect the free market exchange rates rather than
the official exchange rate, which was fixed at 50.600 afghanis to the
dollar until 1996, when it rose to 2,262.65 per dollar, and finally
became fixed again at 3,000.00 per dollar on April 1996
Fiscal year: 21 March-20 March','c8740f8144a6193ba71d5f7aefa556a084bd2d9cac9fdeffcbe25455b6105c1d','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e786cfa662f5c5074285bb23837161192fa0dec32d493cdb55e20c30fb753c30',1990,'AF','Afghanistan','geography',3,'Total area: 647,500 km’, land area
647,500 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 5,826 km total, China
76 km, Iran 936 km, Pakistan 2,430 km,
USSR 2,384 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: Pashtun question with Pakistan,
Baloch question with Iran and Pakistan,
periodic disputes with Iran over Helmand
water rights, insurgency with Iranian and
Pakistani involvement, traditional tribal
rivalries
Climate: arid to semiarid, cold winters and
hot summers
Terrain: mostly rugged mountains, plains
im north and southwest
Natural resources: natural gas, crude oil,
coal, copper, talc, barites, sulphur, lead,
zinc, iron ore, salt, precious and semipre-
cious stones
Land use: 12% arable land, NEGL% per-
manent crops, 46% meadows and pastures,
3% forest and woodland, 39% other, in-
cludes NEGL% irrigated
Environment: damaging earthquakes occur
in Hindu Kush mountains, soil degrada-
tion, desertification, overgrazing, defores-
tation, pollution
Note: landlocked','e5fe117e227513bb0d82c2aed13271b4b99d796d80adfa1292939130221dc453','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a18de539800f5a897d1e49f3cef4e02c3db7872507beb3faa58654334e9692b',1990,'AL','Albania','geography',9,'Total area: 28,750 km?, land area 27,400
km?
Comparative area: slightly larger than
Maryland
Land boundaries: 768 km total, Greece
282 km, Yugoslavia 486 km
Coastline: 362 km
Maritime claims:
Continental shelf not specified
Territorial sea 15 nm
Disputes: Kosovo question with Yugosla-
via, Northern Epirus question with Greece
Climate: mild temperate, cool, cloudy, wet
winters, hot, clear, dry summers; interior
1s cooler and wetter
Terrain: mostly mountains and hills, small
plains along coast
Natural resources: crude oil, natural gas,
coal, chromium, copper, timber, nickel
Land use: 21% arable land, 4% permanent
crops, 15% meadows and pastures, 38%
forest and woodland, 22% other, includes
1% irrigated
Environment: subject to destructive earth-
quakes, tsunami occur along southwestern
coast, deforestation seems to be slowing
Note: strategic location along Strait of
Otranto (links Adriatic Sea to Ioman Sea
and Mediterranean Sea)','9ceae62f5f2fb14f811d419480362b6ffcbacda4dbc5e8046b196865f2834d09','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('804ccd6fa27ca44f8aa2c8e8d3834fabe9d546448ded9c2ecb916f2c7932718d',1990,'DZ','Algeria','geography',14,'Total area: 2,381,740 km?, land area
2,381,740 km?
Comparative area: slightly less than 3 5
times the size of Texas
Land boundaries: 6,343 km total, Libya
982 km, Mali 1,376 km, Mauritania 463
km, Morocco 1,559 km, Niger 956 km,
Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
Territorial sea 12 nm
Disputes: Libya claims about 19,400 km?
in southeastern Algeria
Climate: arid to semiarid, mild, wet win-
ters with hot, dry summers along coast,
drier with cold winters and hot summers
on high plateau, sirocco 1s a hot, dust/
sand-laden wind especially common in
summer
Terrain: mostly high plateau and desert,
some mountains, narrow, discontinuous
coastal plain
Natural resources: crude oil, natural gas,
iron ore, phosphates, uranium, lead, zinc
Land use: 3% arable land, NEGL% per-
manent crops, 13% meadows and pastures,
2% forest and woodland, 82% other, in-
cludes NEGL% irrigated
Environment: mountainous areas subject to
severe earthquakes, desertification
Note: second largest country in Africa
(after Sudan)','4d1bafc2c97a75db20c69b5330e5b6b6b94f38beb237d2a2f4cc66a98bf9b1bf','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2432c8a2b81d759c39617a7e307b4521359a4e0a801256dd716f0ac9d0fe8327',1990,'AS','American Samoa','geography',19,'Total area: 199 km?, land area 199 km?
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 116 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical marine, moderated by
southeast trade winds, annual rainfall av-
erages 124 inches, rainy season from No-
vember to April, dry season from May to
October, little seasonal temperature varia-
tion
Terrain: five volcanic islands with rugged
peaks and limited coastal plains, two coral
atolls
Natural resources: pumice and pumicite
Land use: 10% arable land; 5% permanent
crops, 0% meadows and pastures, 75%
forest and woodland, 10% other
Environment: typhoons common from De-
cember to March
Note: Pago Pago has one of the best natu-
ral deepwater harbors in the South Pacific
Ocean, sheltered by shape from rough
seas and protected by periphera! moun-
tains from high winds, strategic location
about 3,700 km south-southwest of Hono-
julu in the South Pacific Ocean about
halfway between Hawan and New Zea-
land','523ffef98bbdd6c2771d28629c534c3c4fe5a6cdb873df5a5f579531879812a4','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64fa2928dde0a49f96ffa24fdc578bbbad96676c5ff1e02ddcd8b06f0e61bf09',1990,'AD','Andorra','geography',24,'Total area: 450 km?, land area 450 km?
Comparative area: slightly more than 2 5
times the size of Washington, DC
Land boundaries: 125 km total, France 60
km, Spain 65 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: temperate, snowy, cold winters
and cool, dry summers
Terrain: rugged mountains dissected by
narrow valleys
Natural resources: hydropower, mineral
water, timber, iron ore, lead
Land use: 2% arable land, 0% permanent
crops, 56% meadows and pastures, 22%
forest and woodland, 20% other
Environment: deforestation, overgrazing
Note: landlocked','5ec9baef27c6e70f8fbb355665e515ba523ebc8c70b1f3e199ae00dacbfb8441','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d7f1cf31747a951d2d91053bca80c56b9f18d25535346ceed5f9b623a27b1a0',1990,'AO','Angola','geography',30,'Total area: 1,246,700 km7?, land area
1,246,700 km?
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 5,198 km total, Congo
201 km, Namibia 1,376 km, Zaire 2,511
km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 20 nm
Disputes: civil war since independence on
11 November 1975
Climate: semiarid in south and along coast
to Luanda, north has cool, dry season
(May to October) and hot, rainy season
(November to April)
Terrain: narrow coastal plain rises
abruptly to vast interior plateau
Natural resources: petroleum, diamonds,
iron ore, phosphates, copper, feldspar,
gold, bauxite, uranium
Land use: 2% arable land, NEGL% per-
manent crops, 23% meadows and pastures,
43% forest and woodland, 32% other
Environment: locally heavy rainfall causes
periodic flooding on plateau, desertifica-
tion
Note: Cabinda 1s separated from rest of
country by Zaire
Defense Forces
Note: defense 1s the responsibility of
France and Spain','1463309ee14740db24966062187634a5c1c444c66df7b443c13440ac1ecd6a33','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3cdf135423305014dfbf569cd495a86fe826c3db3aa47aec97c0263a981ff8c',1990,'AI','Anguilla','geography',36,'Total area: 91 km?; land area 91 km?
Comparative area: about half the size of
Washington, DC
Land boundaries: none
Coastline: 61 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical, moderated by northeast
trade winds
Terrain: flat and low-lying island of coral
and limestone
Natural resources: negligible, salt, fish,
lobsters
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland; NA% other,
mostly rock with sparse scrub oak, few
trees, some commercial salt ponds
Environment: frequent hurricanes, other
tropical storms (July to October)
Note: located 270 km east of Puerto Rico','4d2ef30404775afb225ce9a118f3ad4a7aca43eb88f79e86b763ebbae4981502','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cfe908e0cc4395230905a85eb8ea2ba42897cfe9f096204177b7625a580c3c3',1990,'AQ','Antarctica','geography',41,'Total area: about 14,000,000 km?, land
area about 14,000,000 km?
Comparative area: slightly less than 1 5
times the size of the US, second-smallest
continent (after Australia)
Land boundaries: see entry on Disputes
Coastline: 17,968 km
Maritime claims: see entry on Disputes
Disputes: Antarctic Treaty suspends all
claims, sections (some overlapping)
claimed by Argentina, Australia, Chile,
France (Adéhe Land), New Zealand (Ross
Dependency), Norway (Queen Maud
Land), and UK, Brazil claims a Zone of
Interest, the US and USSR do not recog-
nize the territorial claims of other nations
and have made no claims themselves (but
reserve the right to do so), no formal
claims have been made in the sector be-
tween 90° west and 150° west
Climate: severe low temperatures vary
with latitude, elevation, and distance from
the ocean, East Antarctica colder than
Antarctic Peninsula in the west, warmest
temperatures occur in January along the
coast and average slightly below freezing
Terrain: about 98% thick continental tce
sheet, with average elevations between
2,000 and 4,000 meters, mountain ranges
up to 5,000 meters high, ice-free coastal
areas include parts of southern Victoria
Land, Wilkes Land, and the scientific re-
search areas of Graham Land and Ross
Island on McMurdo Sound, glaciers form
1ce shelves along about half of coastline
Natural resources: coal and iron ore, chro-
mium, copper, gold, nickel, platinum, and
hydrocarbons have been found 1n small
quantities along the coast, offshore depos-
its of oil and gas
Land use: 0% arable land, 0% permanent
crops; 0% meadows and pastures; 0% for-
est and woodland, 100% other (98% ice,
2% barren rock)
Approved for Release: 2020/08/12 C06554432
Environment: mostly uninhabitable, kata-
batic (gravity) winds blow coastward from
the high interior, frequent blizzards form
near the foot of the plateau, cyclonic
storms form over the ocean and move
clockwise around the coast, during sum-
mer more solar radtation reaches the sur-
face at the South Pole than 1s received at
the Equator in an equivalent period, in
October 1987 it was reported that the
ozone shield, which protects the Earth’s
surface from harmful ultraviolet radtation,
has dwindled to its lowest level ever over
Antarctica, subject to active volcanism
(Deception Island)
Note: the coldest continent','ce1d2a0b0a46aa9fea5b4715ee051a1b805a87a2ea3155ccf856bbe018929c07','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e024c37adc6f23ff59111d4973acfaf5087b1a093237b97a4a1a3a6366365299',1990,'AG','Antigua and Barbuda','geography',46,'Total area: 440 km”, land area 440 km?,
includes Redonda
Comparative area: slightly less than 2 5
times the size of Washington, DC
Land boundaries: none
Coastline: 153 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical marine, little seasonal
temperature variation
Terrain: mostly low-lying limestone and
coral islands with some higher volcanic
areas
Natural resources: negligible, pleasant chi-
mate fosters tourism
Land use: 18% arable land, 0% permanent
crops, 7% meadows and pastures, 16%
forest and woodland, 59% other
Environment: subject to hurricanes and
tropical storms (July to October), insuffi-
cient freshwater resources, deeply
indented coastline provides many natural
harbors
Note: 420 km east-southeast of Puerto
Rico
Total area: 14,056,000 km?, includes
Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea, East Siberian Sea, Green-
land Sea, Hudson Bay, Hudson Strait,
Kara Sea, Laptev Sea, and other tributary
water bodies
Comparative area: slightly more than 1 5
times the size of the US, smallest of the
world’s four oceans (after Pacific Ocean,
Atlantic Ocean, and Indian Ocean)
Coastline: 45,389 km
Climate: persistent cold and relatively nar-
row annual temperature ranges, winters
characterized by continuous darkness, cold
and stable weather conditions, and clear
skies, summers characterized by continu-
ous daylight, damp and foggy weather,
and weak cyclones with rain or snow
Terrain: central surface covered by a pe-
rennial drifting polar icepack which aver-
ages about 3 meters in thickness, although
pressure ridges may be three times that
size, clockwise drift pattern in the Beau-
fort Gyral Stream, but nearly straight line
movement from the New Siberian Islands
(USSR) to Denmark Strait (between
Greenland and Iceland), the ice pack 1s
surrounded by open seas during the sum-
mer, but more than doubles in size during
the winter and extends to the encircling
land masses, the ocean floor 1s about 50%
continental shelf (highest percentage of
any ocean) with the remainder a central
basin interrupted by three submarine
ridges (Alpha Cordillera, Nansen Cordil-
lera, and Lomonsov Ridge), maximum
depth 1s 4,665 meters in the Fram Basin
Natural resources: sand and gravel aggre-
gates, placer deposits, polymetallic nod-
ules, oil and gas fields, fish, marine mam-
mals (seals, whales)
Environment: endangered marine species
include walruses and whales, 1ce islands
occasionally break away from northern
Ellesmere Island, icebergs calved from
13
Approved for Release: 2020/08/12 C06554432
Arctic Ocean (continued)
western Greenland and extreme northeast-
ern Canada, maximum snow cover in
March or April about 20 to 50 centime-
ters over the frozen ocean and lasts about
10 months, permafrost in islands, virtually
1celocked from October to June, fragile
ecosystem slow to change and slow to re-
cover from disruptions or damage
Note: major chokepoint ts the southern
Chukchi Sea (northern access to the Pa-
cific Ocean via the Bering Strait), ships
subject to superstructure icing from Octo-
ber to May, strategic location between
North America and the USSR, shortest
marine link between the extremes of east-
ern and western USSR, floating research
stations operated by the US and USSR','1096ece453712bd690bb101a05b0d56cd1793e6c08ea350c127dd5f6c6ea551e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('561437db77008a4fdad829e7fea67ff6358da89b1efedf4a5eccf07ba4a39f44',1990,'AR','Argentina','geography',51,'Total area: 2,766,890 km?, land area
2,736,690 km?
Comparative area: slightly more than four
times the size of Texas
Land boundaries: 9,665 km total, Bolivia
832 km, Brazil 1,224 km, Chile 5,150 km,
Paraguay 1,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 200 nm (overflight and
navigation permitted beyond 12 nm)
Disputes: short section of the boundary
with Uruguay 1s in dispute; short section
of the boundary with Chile is indefinite,
claims British-administered Falkland Is-
lands (Islas Malvinas); claims
British-administered South Georgia and
the South Sandwich Islands, territorial
claim in Antarctica
Climate: mostly temperate, arid in south-
east, subantarctic in southwest
Terrain: rich plains of the Pampas 1n
northern half, flat to rolling plateau of
Patagonia 1n south, rugged Andes along
western border
Natural resources: fertile plains of the
pampas, lead, zinc, tin, copper, iron ore,
manganese, crude oil, uranium
Land use: 9% arable land; 4% permanent
crops, 52% meadows and pastures, 22%
forest and woodland, 13% other, includes
1% irrigated
Environment: Tucuman and Mendoza ar-
eas in Andes subject to earthquakes, pam-
peros are violent windstorms that can
strike Pampas and northeast, irrigated soil
degradation, desertification; air and water
pollution in Buenos Aires
Note: second-largest country in South
America (after Brazil); strategic location
relative to sea lanes between South Atlan-
Approved for Release: 2020/08/12 C06554432
tic and South Pacific Oceans (Strait of
Magellan, Beagle Channel, Drake Pas-
sage)','0f8cca8e46b6b70a9aaa01991896a25f88010e035736b11241ee8216845c1d71','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f432dcbf55cca03a40a0445b1ddb73d1f68fd5383cbaaa11f13d53b1e560487',1990,'AW','Aruba','geography',56,'Total area: 193 km?, land area 193 km?
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 68 5 km
Maritime claims:
Exclusive fishing zone 12 nm
Territorial sea 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: flat with a few hills, scant vegeta-
tion
Natural resources: negligible, white sandy
beaches
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: lies outside the Caribbean
hurricane belt
Note: 28 km north of Venezuela
Total area: 5 km?, land area 5 km’, in-
cludes Ashmore Reef (West, Middle, and
East Islets) and Cartier Island
Comparative area: about 8 5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 74 | km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploration
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical
Terrain: low with sand and coral
Natural resources: fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other—grass and
sand
Environment: surrounded by shoals and
reefs, Ashmore Reef Nattonal Nature Re-
serve established in August 1983
Note: located in extreme eastern Indian
Ocean between Australia and Indonesia
320 km off the northwest coast of Austra-
ha
Total area: 82,217,000 km?, includes Bal-
tic Sea, Black Sea, Caribbean Sea, Davis
Strait, Denmark Strait, Drake Passage,
Gulf of Mexico, Mediterranean Sea,
North Sea, Norwegian Sea, Weddell Sea,
and other tributary water bodies
Comparative area: slightly less than nine
times the size of the US, second-largest of
the world’s four oceans (after the Pacific
Ocean, but larger than Indian Ocean or
Arctic Ocean)
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) de-
velop off the coast of Africa near Cape
Verde and move westward into the Carib-
bean Sea, hurricanes can occur from May
to December, but are most frequent from
August to November
Terrain: surface usually covered with sea
ice in Labrador Sea, Denmark Strait, and
Baltic Sea from October to June, clock-
wise warm water gyre (broad, circular sys-
tem of currents) in the north Atlantic,
counterclockwise warm water gyre in the
south Atlantic, the ocean floor is domi-
nated by the Mid-Atlantic Ridge, a rug-
ged north-south centerline for the entire
Atlantic basin, maximum depth 1s 8,605
meters in the Puerto Rico Trench
Natural resources: oil and gas fields, fish,
marine mammals (seals and whales), sand
and gravel aggregates, placer deposits,
polymetallic nodules, precious stones
Environment: endangered marine species
include the manatee, seals, sea lions, tur-
tles, and whales, municipa! sludge pollu-
tion off eastern US, southern Brazil, and
eastern Argentina, oil pollution in Carib-
bean Sea, Gulf of Mexico, Lake Mara-
caibo, Mediterranean Sea, and North Sea,
mdustrial waste and municipal sewage
pollution in Baltic Sea, North Sea, and
Mediterranean Sea, icebergs common in
Davis Strait, Denmark Strait, and the
northwestern Atlantic from February to
17
Approved for Release: 2020/08/12 C06554432
Atlantic Ocean (continued)
August and have been spotted as far south
as Bermuda and the Madeira Islands, 1ce-
bergs from Antarctica occur 1n the ex-
treme southern Atlantic
Note: ships subject to superstructure icing
in extreme north Atlantic from October to
May and extreme south Atlantic from
May to October, persistent fog can be a
hazard to shipping from May to Septem-
ber, major choke points include the Dar-
danelles, Strait of Gibraltar, access to the
Panama and Suez Canals, strategic straits
include the Dover Strait, Straits of Flor-
ida, Mona Passage, The Sound (@resund),
and Windward Passage, north Atlantic
shipping lanes subject to icebergs from
February to August, the Equator divides
the Atlantic Ocean into the North Atlan-
tic Ocean and South Atlantic Ocean','3cb054bd66ea9f4ba36bf11d9c2e5a384b712b171b394591e37ffa60cc747fe4','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9002362453c4cbe7bde52a9a850e161892d848ea1e0af31619622c5ef3d6357d',1990,'AU','Australia','geography',61,'Total area: 7,686,850 km?, land area
7,617,930 km?, includes Macquarie Island
Comparative area: slightly smaller than
the US
Land boundaries: none
Coastline: 25,760 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Disputes: territorial claim in Antarctica
(Australian Antarctic Territory)
Climate: generally arid to semiarid; tem-
perate in south and east, tropical in north
Terrain: mostly low plateau with deserts,
fertile plain in southeast
Natural resources: bauxite, coal, iron ore,
copper, tin, silver, uranium, nickel, tung-
sten, mineral sands, lead, zinc, diamonds,
natural gas, crude oil
Land use: 6% arable land, NEGL% per-
manent crops, 58% meadows and pastures,
14% forest and woodland, 22% other, in-
cludes NEGL% irrigated
Environment: subject to severe droughts
and floods, cyclones along coast, limited
freshwater availability, irrigated soil deg-
radation, regular, tropical, invigorating,
sea breeze known as the doctor occurs
along west coast in summer, desertifica-
tion
Note: world’s smallest continent but sixth-
largest country','38036814e75ca101871c80e3d678b2514c973d52bc5bd35d75944f288877694d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da3c12184d99e456ac26e06ed939af2f27db29f02e1318df33561e9f810e4997',1990,'AT','Austria','geography',66,'Total area: 83,850 km?, land area 82,730
km?
Comparative area: slightly smaller than
Maine
Land boundaries: 2,640 km total, Czecho-
slovakia 548 km, Hungary 366 km, Italy
430 km, Liechtenstein 37 km, Switzerland
164 km, FRG 784 km, Yugoslavia 311
km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: South Tyrol question with Italy
Climate: temperate, continental, cloudy,
cold winters with frequent rain in low-
lands and snow in mountains, cool sum-
mers with occasional showers
Terrain: mostly mountains with Alps in
west and south, mostly flat, with gentle
slopes along eastern and northern margins
Natural resources: iron ore, crude oil, tim-
ber, magnesite, aluminum, lead, coal, lig-
nite, copper, hydropower
Land use: 17% arable land, 1% permanent
crops, 24% meadows and pastures; 39%
forest and woodland, 19% other, includes
NEGL% irrigated
Environment: because of steep slopes, poor
soils, and cold temperatures, population 1s
concentrated on eastern lowlands
Note: landlocked, strategic location at the
crossroads of central Europe with many
easily traversable Alpine passes and val-
leys, major river 1s the Danube
Total area: 13,940 km?, land area 10,070
km?
Comparative area: slightly larger than
Connecticut
Land boundaries: none
Coastline: 3,542 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical marine, moderated by
warm waters of Gulf Stream
Terrain: long, flat coral formations with
some low rounded hills
Natural resources: salt, aragonite, timber
Land use: 1% arable land, NEGL% per-
manent crops, NEGL% meadows and pas-
tures, 32% forest and woodland, 67%
other
Environment: subject to hurricanes and
other tropical storms that cause extensive
flood damage
Note: strategic location adjacent to US
and Cuba, extensive island chain','4a9dd51866c72dec09ccb5a9d1b95368a9f67b23dc708172830f090385feabe1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42b8b798008bc3f7236c778b7768523e0e296db1f723a6af0c3442186d381ce2',1990,'BH','Bahrain','geography',71,'Total area: 620 km”, land area 620 km?
Comparative area: slightly less than 3 5
times the size of Washington, DC
Land boundaries: none
Coastline: 161 km
Maritime claims:
Continental shelf not specific
Territorial sea 3 nm
Disputes: territorial dispute with Qatar
over the Hawar Islands
Climate: arid, mild, pleasant winters, very
hot, humid summers
Terrain: mostly low desert plain rising
gently to low central escarpment
Natural resources: oil, associated and no-
nassociated natural gas, fish
Land use: 2% arable land, 2% permanent
crops, 6% meadows and pastures, 0% for-
est and woodland, 90% other, includes
NEGL% irrigated
Environment: subsurface water sources
being rapidly depleted (requires develop-
ment of desalination facilities), dust
storms, desertification
Note: proximity to primary Middle East-
ern crude oil sources and strategic loca-
tion in Persian Gulf through which much
of Western world’s crude oil must transit
to reach open ocean
Total area: | 4 km’, land area 1 4 km?
Comparative area: about 2 3 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 4 8 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: equatorial, scant rainfall, con-
stant wind, burning sun
Terrain: low, nearly level coral island sur-
rounded by a narrow fringing reef
Natural resources: guano (deposits worked
until 1891)
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: treeless, sparse and scattered
vegetation consisting of grasses, prostrate
vines, and low growing shrubs, lacks fresh
water, primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds,
and marine wildlife
Note: remote location 2,575 km southwest
of Honolulu in the North Pacific Ocean,
Just north of the Equator, about halfway
between Hawau and Australia','0d2fddbc4167c35e39c47befed6ffa5997613fc412fe5d6a5eb650802bfd7e0e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c451ca5d65143e61089c3996ba1b903533f2dcac1e713c4877826d6e2be52098',1990,'BD','Bangladesh','geography',76,'Total area: 144,000 km?, land area
133,910 km?
Comparative area: slightly smaller than
Wisconsin
Land boundaries: 4,246 km total; Burma
193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
Contiguous zone 18 nm
Continental shelf up to outer limits of
continental margin
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: a portion of the boundary with
India is in dispute, water sharing problems
with upstream riparian India over the
Ganges
Climate: tropical; cool, dry winter (Oc-
tober to March), hot, humid summer
(March to June), cool, rainy monsoon
(June to October)
Terrain: mostly flat alluvial plain, hilly in
southeast
Natural resources: natural gas, uranium,
arable land, timber
Land use: 67% arable land; 2% permanent
crops, 4% meadows and pastures, 16%
forest and woodland, 11% other, includes
14% irrigated
Environment: vulnerable to droughts,
much of country routinely flooded during
summer monsoon season, overpopulation,
deforestation
Note: almost completely surrounded by','d38ce2e2c95a8e4428fc15071406e67c6c8336efe2f91cf279a465abe7f411cd','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f247fa1084f8a1773156147a34a4149a99fa4d5f05db076f4df061708913fca',1990,'BB','Barbados','geography',82,'Total area: 430 km’, land area 430 km?
Comparative area: slightly less than 2 5
times the size of Washington, DC
Land boundaries: none
Coastline: 97 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, rainy season (June to
October)
Terrain: relatively flat, rises gently to cen-
tral highland region
Natural resources: crude oil, fishing, natu-
ral gas
Land use: 77% arable land, 0% permanent
crops, 9% meadows and pastures, 0% for-
est and woodland, 14% other
Environment: subject to hurricanes (espe-
cially June to October)
Note: easternmost Caribbean island','58f24d75a54f0b912bf1da68c2fb9313f9acfe6d64c228fe5724cf5cf95d32aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d620eb44fca2391cf8891657aa01a10f03ddb3d938016c25870f3ff5f0c4675',1990,'MZ','Mozambique','geography',87,'Total area: undetermined
Comparative area: undetermined
Land boundaries: none
Coastline: 35 2 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: a volcanic rock 2 4 m high
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland; 100% other (rock)
Environment: surrounded by reefs; subject
to periodic cyclones
Note: navigational hazard since it is usu-
ally under water during high tide, located
in southern Mozambique Channel about
halfway between Africa and Madagascar
Total area: 2,170 km’, land area 2,170
km?
Comparative area: slightly more than 12
times the size of Washington, DC
Land boundaries: none
Coastline: 340 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims French-administered Ma-
yotte
Climate: tropical marine, rainy season
(November to May)
Terrain: volcanic islands, interiors vary
from steep mountains to low hills
Natural resources: negligible
Land use: 35% arable land, 8% permanent
crops, 7% meadows and pastures, 16%
forest and woodland, 34% other
Environment: soil degradation and erosion,
deforestation, cyclones possible during
rainy season
Note: important location at northern end
of Mozambique Channel
Total area: 28 km?, land area 28 km?
Comparative area: about 0 2 times the size
of Washington, DC
Land boundaries: none
Coastline: 22 2 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: NA
Natural resources: negligible
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other,
heavily wooded
Environment: wildlife sanctuary
Note: located in the Mozambique Channel
340 km west of Madagascar
Total area: 587,040 km7, land area
581,540 km?
Comparative area: slightly less than twice
the size of Arizona
Land boundaries: none
Coastline: 4,828 km
Maritime claims:
Exclusive fishing zone 150 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova
Island, and Tromelin Island (all admuinis-
tered by France)
Climate: tropical along coast, temperate
inland, arid in south
Terrain: narrow coastal plain, high pla-
teau and mountains in center
Natural resources: graphite, chromite,
coal, bauxite, salt, quartz, tar sands, semi-
precious stones, mica, fish
Land use: 4% arable land, 1% permanent
crops, 58% meadows and pastures, 26%
forest and woodland, 11% other, includes
2% irrigated
Environment: subject to periodic cyclones,
deforestation, overgrazing, soil erosion,
desertification
Note: world’s fourth-largest island, strate-
gic location along Mozambique Channel
Total area: 801,590 km7?, land area
784,090 km?
Comparative area: slightly less than twice
the size of California
Land boundaries: 4,571 km total, Malawi
1,569 km, South Africa 491 km, Swazi-
land 105 km, Tanzania 756 km, Zambia
419 km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands
in center, high plateaus 1n northwest,
mountains 1n west
Natural resources: coal, titanium
Land use: 4% arable land, NEGL% per-
manent crops, 56% meadows and pastures,
20% forest and woodland, 20% other, in-
cludes NEGL% irrigated
Environment: severe drought and floods
occur in south, desertification','16d1ad7ff207c9bf979f929fc88f12365258e4fcb18621435213d0a35a32d26f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9aac1f8cc4d64f7f19abdf5671bd23a324fcffdfef1be665a5595e92926adcd',1990,'BE','Belgium','geography',93,'Total area: 30,510 km; land area 30,230
km?
Comparative area: slightly larger than
Maryland
Land boundaries: 1,385 km total, France
620 km, Luxembourg 148 km, Nether-
lands 450 km, FRG 167 km
Coastline: 64 km
Maritime claims:
Continental shelf not specific
Exclusive fishing zone equidistant line
with neighbors (extends about 68 km
from coast)
Territorial sea 12 nm
Climate: temperate, mild winters, cool
summers, rainy, humid, cloudy
Terrain: flat coastal plains in northwest,
central rolling hills, rugged mountains of
Ardennes Forest in southeast
Natural resources: coal, natural gas
Land use: 24% arable land, 1% permanent
crops, 20% meadows and pastures, 21%
forest and woodland, 34% other, includes
NEGL% irrigated
Environment: air and water pollution
Note: majority of West European capitals
within 1,000 km of Brussels, crossroads of
Western Europe, Brussels is the seat of
the EC','9450b174a693beb9f1a0d32d5bdc30a6e9f351f4527dc032734f0c80e7a7ed39','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9fdb82acda0da0f228ac873635350c797185aef8700d6340fbbfe370b868a45',1990,'BZ','Belize','geography',98,'Total area: 22,960 km?, land area 22,800
km?
Comparative area: slightly larger than
Massachusetts
Land boundaries: 516 km total, Guate-
mala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
Territorial sea 3 nm
Disputes: claimed by Guatemala, but
boundary negotiations are under way
Climate: tropical, very hot and humid,
rainy season (May to February)
Terrain: flat, swampy coastal plain, low
mountains 1n south
Natural resources: arable land potential,
timber, fish
Land use: 2% arable land, NEGL% per-
manent crops, 2% meadows and pastures,
44% forest and woodland, 52% other, 1n-
cludes NEGL% irrigated
Environment: frequent devastating hurri-
canes (September to December) and
coastal flooding (especially in south), de-
forestation
Note: national capital moved 80 km 1n-
land from Belize City to Belmopan be-
cause of hurricanes, only country in Cen-
tral America without a coastline on the
North Pacific Ocean','a148aea3b1ea7da28a3ca2025fb98e9bb6fc4453ac358878494c6ef31a176819','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3ae4e163c20641eb98a045441b6f9c5e3fbf7f9a8940739a193a5360d0724c2',1990,'BJ','Benin','geography',103,'Total area: 112,620 km, land area
110,620 km?
Comparative area: slightly smalier than
Pennsylvania
Land boundaries: 1,989 km total, Burkina
306 km, Niger 266 km, Nigeria 773 km,
Togo 644 km
Coastline: 121 km
Maritime claims:
Territorial sea 200 nm
Climate: tropical, hot, humid in south, se-
muarid in north
Terrain: mostly flat to undulating plain,
some hills and low mountains
Natural resources: small offshore oil de-
posits, limestone, marble, timber
Land use: 12% arable land, 4% permanent
crops, 4% meadows and pastures, 35%
forest and woodland, 45% other, includes
NEGL% irrigated
Environment: hot, dry, dusty harmattan
wind may affect north in winter, defores-
tation, desertification
Note: recent droughts have severely af-
fected marginal agriculture in north, no
natural harbors
Total area: 923,770 km?, land area
910,770 km?
Comparative area: slightly more than
twice the size of California
Land boundaries: 4,047 km total, Benin
773 km, Cameroon 1,690 km, Chad 87
km, Niger 1,497 km
Coastline: 853 km
Maritime claims:
Continental shelf 200 meters or to
depth of, exploitation
Extended economic zone 200 nm
Territorial sea 30 nm
Disputes: exact locations of the
Chad-Niger-Nigeria and Cameroon-Chad-
Nigeria tripoints in Lake Chad have not
been determined, so the boundary has not
been demarcated and border incidents
have resulted, Nigerian proposals to re-
open maritime boundary negotiations and
redemarcate the entire land boundary
have been rejected by Cameroon
Climate: varies—equatorial in south, tropi-
cal in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus, mountains in
southeast, plains in north
Natural resources: crude oil, tin, colum-
bite, iron ore, coal, limestone, lead, zinc,
natural gas
Land use: 31% arable land, 3% permanent
crops, 23% meadows and pastures, 15%
forest and woodland, 28% other, includes
NEGL®% irrigated
Environment: recent droughts in north se-
verely affecting marginal agricultural ac-
tivities, desertification, soil degradation,
rapid deforestation','e68d1e8363edcdfcc406b19eac78f8677cbd2c224f3a20532d98be8ae379e7a9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc515c89afbf4baf3c311074812acfd7dc17d0bdb673d6929790f0b06da6e006',1990,'BM','Bermuda','geography',108,'Total area: 50 km?, land area 50 km?
Comparative area: about 0 3 times the size
of Washington, DC
Land boundaries: none
Coastline: 103 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: subtropical, mild, humid, gales,
strong winds common in winter
Terrain: low hills separated by fertile de-
pressions
Natural resources: limestone, pleasant ch-
mate fostering tourism
Land use: 0% arable land, 0% permanent
crops; 0% meadows and pastures, 20%
forest and woodland; 80% other
Environment: ample rainfall, but no rivers
or freshwater lakes, consists of about 360
small coral islands
Note: 1,050 km east of North Carolina,
some reclaimed land leased by US Gov-
ernment','b524fa7aab578ac5484de78a9aa5d0e0eac3d3fbccbd5c13660a62b936f98155','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f79483e51cdf392208d701e68eeac3bef68bfd966c6cc7d16532098d059e5ec',1990,'BT','Bhutan','geography',113,'Total area: 47,000 km?, land area 47,000
km?
Comparative area: slightly more than half
the size of Indiana
Land boundaries: 1,075 km total, China
470 km, India 605 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: varies; tropical in southern
plains, cool winters and hot summers 1n
central valleys, severe winters and cool
summers in Himalayas
Terrain: mostly mountainous with some
fertile valleys and savanna
Natural resources: timber, hydropower,
gypsum, calcium carbide
Land use: 2% arable land, NEGL% per-
manent crops, 5% meadows and pastures,
70% forest and woodland, 23% other
Environment: violent storms coming down
from the Himalayas were the source of
the country name which translates as
Land of the Thunder Dragon
Note: landlocked, strategic location be-
tween China and India, controls several
key Himalayan mountain passes
Total area: 1,098,580 km7, land area
1,084,390 km?
Comparative area: slightly less than three
times the size of Montana
Land boundaries: 6,743 km total, Argen-
tina 832 km, Brazil 3,400 km, Chile 861
km, Paraguay 750 km, Peru 900 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: has wanted a sovereign corridor
to the South Pacific Ocean since the Ata-
cama area was lost to Chile in 1884, dis-
pute with Chile over Rio Lauca water
rights
Climate: varies with altitude, humid and
tropical to cold and semiarid
Terrain: high plateau, hills, lowland plains
Natural resources: tin, natural gas, crude
oil, zinc, tungsten, antimony, silver, iron
ore, lead, gold, timber
Land use: 3% arable land, NEGL% per-
manent crops, 25% meadows and pastures,
52% forest and woodland, 20% other, in-
cludes NEGL% irrigated
Environment: cold, thin air of high plateau
1s obstacle to efficient fuel combustion,
overgrazing, soil erosion, desertification
Note: landlocked, shares control of Lago
Titicaca, world’s highest navigable lake,
with Peru','d583d4d3b4c7dd0122e351ff7a446087bfdb3581e9486118b069eea45031c60f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dcddcd5b29bed82095112503adf8c708043a7e0025246ffdb7be0285e10a9fa',1990,'BW','Botswana','geography',119,'Total area: 600,370 km7, land area
585,370 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 4,013 km total, Namibia
1,360 km, South Africa 1,840 km, Zimba-
bwe 813 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: short section of the boundary
with Namubia 1s indefinite, quadripoint
with Namibia, Zambia, and Zimbabwe 1s
in disagreement
Climate: semiarid, warm winters and hot
summers
Terrain: predominately flat to gently roll-
ing tableland, Kalahari Desert in south-
west
Natural resources: diamonds, copper,
nickel, salt, soda ash, potash, coal, iron
ore, silver, natural gas
Land use: 2% arable land, 0% permanent
crops, 75% meadows and pastures, 2%
forest and woodland, 21% other; includes
NEGL% irrigated
Environment: rains in early 1988 broke six
years of drought that had severely
affected the important cattle industry;
overgrazing, desertification
Note: landlocked, very long boundary with','e631028b3bfd4eae706e810f4a88f581cab4296a7723985f6817e050b506eca0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b92d545116c95340e3001d7177b284f7127691a127553ad3c312f9207cb731c3',1990,'BV','Bouvet Island','geography',125,'Total area: 58 km, land area 58 km?
Comparative area: about 0 3 times the size
of Washington, DC
Land boundaries: none
Coastline: 29 6 km
Maritime claims:
Contiguous zone 10 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 4 nm
Climate: antarctic
Terrain: volcanic, maximum elevation about
800 meters, coast 1s mostly inacessible
Natural resources: none
Land use: 0% arable land; 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: covered by glacial ice
Note: located in the South Atlantic Ocean
2,575 km south-southwest of the Cape of
Good Hope, South Africa','87e581e074c5afc52b564b11f07ba09f05b3eb6b6fc1ceaad95a8b20749ace51','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('506f95694449d26c093b9a2c90d4bb0f37bdadd699afb5b1b5c1fe2061310fe1',1990,'BR','Brazil','geography',126,'Total area: 8,511,965 km7, land area
8,456,510 km?, includes Arquipélago de
Fernando de Noronha, Atol das Rocas,
Ilha da Trindade, I!has Martin Vaz, and
Penedos de Sio Pedro e Sado Paulo
Comparative area: slightly smaller than
the US
Land boundaries: 14,691 km total, Argen-
tina 1,224 km, Bolivia 3,400 km, Colom-
bia 1,643 km, French Guiana 673 km,
Guyana 1,119 km, Paraguay 1,290 km,
Peru 1,560 km, Suriname 597 km, Uru-
guay 985 km, Venezuela 2,200 km
Coastline: 7,491 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 200 nm
Disputes: short section of the boundary with
Paraguay (just west of Guaira Falls on the
Rio Paranda) 1s in dispute, two short sections
of boundary with Uruguay are in dispute
(Arroyo de la Invernada area of the Rio
Quarai and the islands at the confluence of
the Rio Quarai and the Uruguay), claims a
Zone of Interest in Antarctica
Climate: mostly tropical, but temperate in
south
Terrain: mostly flat to rolling lowlands in
north, some plains, hills, mountains, and
narrow coastal belt
Natural resources: iron ore, manganese,
bauxite, nickel, uranium, phosphates, tin,
hydropower, gold, platinum, crude oil,
timber
Land use: 7% arable land, 1% permanent
crops, 19% meadows and pastures, 67%
forest and woodland, 6% other, includes
NEGL% irrigated
Environment: recurrent droughts in north-
east, floods and frost in south, deforesta-
tion in Amazon basin, air and water pollu-
tion in Rio de Janeiro and Sao Paulo
Note: largest country in South America,
shares common boundaries with every
South American country except Chile and','3f08404e850002b8211f81ba14a194302d348b47ba563e1e32571edb3311ae52','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4305c7512c75e5d90e60a1864bba438fe76e15247c9d9f02d243a80bb9ae9753',1990,'IO','British Indian Ocean Territory','geography',131,'Total area: 60 km?, land area 60 km?
Comparative area: about 0 3 times the size
of Washington, DC
Land boundaries: none
Coastline: 698 km
Maritime claims:
Territorial sea 3 nm
Disputes: Diego Garcia 1s claimed by','757d6ae5c07e112fb7e6476f8fddc754b9c20045ff9c397acfe98300ee90581c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbe53066fb3e92b1af8e155cdf8962c067e5ad003b26213f7386972debccae38',1990,'MU','Mauritius','geography',132,'Climate: tropical marine, hot, humid,
moderated by trade winds
Terrain: flat and low (up to 4 meters in
elevation)
Natural resources: coconuts, fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland; 100% other
Environment: archipelago of 2,300 islands
Note: Diego Garcia, largest and southern-
most island, occupies strategic location in
central Indian Ocean
Total area: 150 km?; land area 150 km?
Comparative area: about 0 8 times the size
of Washington, DC
Coastline: 80 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: subtropical, humid, temperatures
moderated by trade winds
Terrain: coral islands relatively flat, volca-
nic islands steep, hilly
Natural resources: negligible
Land use: 20% arable land, 7% permanent
crops, 33% meadows and pastures, 7%
forest and woodland; 33% other
Environment: subject to hurricanes and
tropical storms from July to October
Note: strong ties to nearby US Virgin Is-
lands and Puerto Rico
Total area: 5,770 km7, land area 5,270
km?
Comparative area: slightly larger than
Delaware
Land boundary: 381 km with Malaysia
Coastline: 161 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: may wish to purchase the Ma-
laysian salient that divides the country
Climate: tropical, hot, humid, rainy
Terrain: flat coastal plain rises to moun-
tains in east, hilly lowland in west
Natural resources: crude oil, natural gas,
timber
Land use: 1% arable land, 1% permanent
crops, 1% meadows and pastures, 79%
forest and woodland, 18% other, includes
NEGL% trrigated
Environment: typhoons, earthquakes, and
severe flooding are rare
Note: close to vital sea lanes through
South China Sea linking Indian and Pa-
cific Oceans, two parts physically sepa-
rated by Malaysia, almost an enclave of
Total area: 1,860 km?, land area 1,850
km?, includes Agalega Islands, Cargados
Carajos Shoals (St Brandon) and Rodri-
gues
Comparative area: slightly less than 10 5
times the size of Washington, DC
Land boundaries: none
Coastline: 177 km
Maritime claims:
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims Chagos Archipelago,
which includes the island of Diego Garcia
in UK-administered British Indian Ocean
Territory, claims French-administered
Tromelin [sland
Climate: tropical modified by southeast
trade winds, warm, dry winter (May to
November), hot, wet, humid summer (No-
vember to May)
Terrain: small coastal plain rising to dis-
continuous mountains encircling central
plateau
Natural resources: arable land, fish
Land use: 54% arable land, 4% permanent
crops, 4% meadows and pastures, 31%
forest and woodland, 7% other, includes
9% irrigated
Environment: subject to cyclones
(November to April), almost completely
surrounded by reefs
Note: located 900 km east of Madagascar
in the Indian Ocean','6e36e7ab96247a5982e4be714d03ae60c1717d39708d2954174d04864ad49114','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a4ce57e3eee0ac206bf0c69afdfaa7687f3eee0ae9c3241de7524a9551b4b12',1990,'BG','Bulgaria','geography',142,'Total area: 110,910 km?, land area
110,550 km?
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,881 km total, Greece
494 km, Romania 608 km, Turkey 240
km, Yugoslavia 539 km
Coastline: 354 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: Macedonia question with Greece
and Yugoslavia
Climate: temperate, cold, damp winters,
hot, dry summers
Terrain: mostly mountains with lowlands
in north and south
Natural resources: bauxite, copper, lead,
zinc, coal, timber, arable land
Land use: 34% arable land, 3% permanent
crops, 18% meadows and pastures, 35%
forest and woodland, 10% other, includes
11% irrigated
Environment: subject to earthquakes, land-
slides, deforestation, air pollution
Note: strategic location near Turkish
Straits, controls key land routes from Eu-
rope to Middle East and Asia
Total area: 274,200 km”, land area
273,800 km?
Comparative area: slightly larger than
Colorado
Land boundaries: 3,192 km total, Benin
306 km, Ghana 548 km, Ivory Coast 584
km, Mal: 1,000 km, Niger 628 km, Togo
126 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: the disputed international
boundary between Burkina and Mali was
submitted to the International Court of
Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1986,
which both sides agreed to accept, Burk-
ina and Mali are proceeding with bound-
ary demarcation, including the tripoint
with Niger
Climate: tropical, warm, dry winters, hot,
wet summers
Terrain: mostly flat to dissected, undulat-
ing plains, hills in west and southeast
Natural resources: manganese, limestone,
marble, small deposits of gold, antimony,
copper, nickel, bauxite, lead, phosphates,
zinc, silver
Land use: 10% arable land, NEGL% per-
manent crops, 37% meadows and pastures,
26% forest and woodland, 27% other, in-
cludes NEGL% irrigated
Environment: recent droughts and deserti-
fication severely affecting marginal agri-
cultural activities, population distribution,
economy, overgrazing, deforestation
Note: landlocked
Total area: 678,500 km?, land area
657,740 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 5,876 km total, Bangla-
desh 193 km, China 2,185 km, India
1,463 km, Laos 235 km, Thailand 1,800
km
Coastline: 1,930 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical monsoon, cloudy, rainy,
hot, humid summers (southwest monsoon,
June to September), less cloudy, scant
rainfall, mild temperatures, lower humid-
ity during winter (northeast monsoon, De-
cember to Apri!)
Terrain: central lowlands ringed by steep,
rugged highlands
Natural resources: crude oil, timber, tin,
antimony, zinc, copper, tungsten, lead,
coal, some marble, limestone, precious
stones, natural gas
Land use: 15% arable land; 1% permanent
crops, 1% meadows and pastures, 49%
forest and woodland, 34% other, includes
2% irrigated
Environment: subject to destructive earth-
quakes and cyclones, flooding and land-
slides common during rainy season (June
to September), deforestation
Note: strategic location near major Indian
Ocean shipping lanes','262ac5c33db0c7592b199527d79f886c0db62611dcb1c4c849277955fd77d27b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7634d4211fbf3f286bf451ae6858540f629a232a782cd298b6a4938a9f82be2',1990,'BI','Burundi','geography',147,'Total area: 27,830 km?2, land area 25,650
km2
Comparative area: slightly larger than
Maryland
Land boundaries: 974 km total, Rwanda
290 km, Tanzania 451 km, Zaire 233 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: temperate, warm, occasional frost
in uplands
Terrain: mostly rolling to hilly highland,
some plains
Natural resources: nickel, uranium, rare
earth oxide, peat, cobalt, copper, platinum
(not yet exploited), vanadium
Land use: 43% arable land, 8% permanent
crops, 35% meadows and pastures, 2%
forest and woodland, 12% other, includes
NEGL% irrigated
Environment: soil exhaustion, soil erosion,
deforestation
Note: landlocked, straddles crest of the
Nile-Congo watershed','961add736626168140728493d04406606e3786efd0b7503ed2b31d5dbcbbb77e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd96813c1a1171cebcfccc208cc1f1ca7ebf9f5a7c842c0c11aac5d336f1a1b1',1990,'TH','Thailand','geography',153,'Total area: 181,040 km?, land area
176,520 km?
Comparative area: slightly smaller than
Oklahoma
Land boundaries: 2,572 km total, Laos
541 km, Thailand 803 km, Vietnam 1,228
km
Coastline: 443 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: offshore islands and three sec-
tions of the boundary with Vietnam are in
dispute, maritime boundary with Vietnam
not defined, occupied by Vietnam on 25
December 1978
Climate: tropical, rainy, monsoon season
(May to October), dry season (December
to March), little seasonal temperature
variation
Terrain: mostly low, flat plains, mountains
in southwest and north
Natural resources: timber, gemstones,
some iron ore, manganese, phosphates,
hydropower potential
Land use: 16% arable land; 1% permanent
crops, 3% meadows and pastures, 76%
forest and woodland, 4% other, includes
1% irrigated
Environment: a land of paddies and forests
dominated by Mekong Rover and Tonle
Sap
Note: buffer between Thailand and Viet-
nam
Total area: 514,000 km7, land area
511,770 km?
Comparative area: slightly more than
twice the size of Wyoming
Land boundaries: 4,863 km total, Burma
1,800 km, Cambodia 803 km, Laos 1,754
km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
Continental shelf not specific
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: boundary dispute with Laos
Chmate: tropical, rainy, warm, cloudy
southwest monsoon (mid-May to Septem-
ber), dry, cool northeast monsoon (No-
vember to mid-March), southern isthmus
always hot and humid
Terrain: central plain, eastern plateau
(Khorat), mountains elsewhere
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gyp-
sum, lignite, fluorite
Land use: 34% arable land, 4% permanent
crops, 1% meadows and pastures, 30%
forest and woodland, 31% other, includes
7% \\trigated
Environment: air and water pollution, land
subsidence in Bangkok area
Note: controls only land route from Asia
to Malaysia and Singapore','42d470bf525dd7d329b19fa3e0567d4362e9b104e248a241366997f79b6fa337','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c19a9d8abaaf3e4cff62d8d4602a74b750b43d08ad8b59d84907a221cb137c2',1990,'CM','Cameroon','geography',158,'Total area: 475,440 km/?, land area
469,440 km?
Comparative area: slightly larger than
California
Land boundaries: 4,591 km total, Central
African Republic 797 km, Chad 1,094
km, Congo 523 km, Equatorial Guinea
189 km, Gabon 298 km, Nigeria 1,690
km
Coastline: 402 km
Maritime claims:
Continental shelf not specific
Territorial sea 50 nm
Disputes: exact locations of the
Chad-Niger-Nigeria and Cameroon-Chad-
Nigeria tripoints in Lake Chad have not
been determined, so the boundary has not
been demarcated and border incidents
have resulted, Nigerian proposals to re-
open maritime boundary negotiations and
redemarcate the entire land boundary
have been reyected by Cameroon
Climate: varies with terrain from tropical
along coast to semiarid and hot in north
Terrain: diverse with coastal plain in
southwest, dissected plateau 1n center,
mountains 1n west, plains in north
Natural resources: crude oil, bauxite, iron
ore, timber, hydropower potential
Land use: 13% arable land, 2% permanent
crops, 18% meadows and pastures, 54%
forest and woodland, 13% other, includes
NEGL% irrigated
Environment: recent volcanic activity with
release of poisonous gases, deforestation,
overgrazing, desertification
Note: sometimes referred to as the hinge
of Africa','45de545d8a6623d8ef78829fd25576d22e8cfb2fa20159cbdce67e2a10401196','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c6ac512fcfb4c5703a9b2af1b305d4adbe10a17c384188c13324f4d20ff70a6',1990,'CA','Canada','geography',164,'Total area: 9,976,140 km?; land area
9,220,970 km?
Comparative area: slightly larger than US
Land boundaries: 8,893 km with US (in-
cludes 2,477 km with Alaska)
Coastline: 243,791 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary disputes
with France (St Pierre and Miquelon) and
US
Climate: varies from temperate in south to
subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Natural resources: nickel, zinc, copper,
gold, lead, molybdenum, potash, silver,
fish, trmber, wildlife, coal, crude oi!, natu-
ral gas
Land use: 5% arable land, NEGL% per-
manent crops, 3% meadows and pastures,
35% forest and woodland, 57% other, in-
cludes NEGL% irrigated
Environment: 80% of population concen-
trated within 160 km of US border, con-
tinuous permafrost in north a serious ob-
stacle to development
Note: second-largest country in world
(after USSR), strategic location between
USSR and US via north polar route
Total area: 4,030 km’, land area 4,030
km?
Comparative area: slightly larger than
Rhode Island
Land boundaries: none
Coastline: 965 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: temperate, warm, dry, summer
precipitation very erratic
Terrain: steep, rugged, rocky, volcanic
Natural resources: salt, basalt rock, pozzo-
lana, limestone, kaolin, fish
Land use: 9% arable land, NEGL% per-
manent crops, 6% meadows and pastures,
NEGL% forest and woodland, 85% other;
includes 1% irrigated
Environment: subject to prolonged
droughts, harmattan wind can obscure
visibility, volcanically and seismically ac-
tive, deforestation, overgrazing
Note: strategic location 500 km from Af-
rican coast near major north-south sea
routes, important communications station,
important sea and air refueling site','45bb79bb49907122b8715904f6796e737ad033208c74d23fa15348f2dca7b40c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a7fa1c11cf9fc11feb0341b3edf142e08203d7a5ad2a0fbbcf6810e4e88ca68',1990,'KY','Cayman Islands','geography',169,'Total area: 260 km?, land area 260 km?
Comparative area: slightly less than 1 5
times the size of Washington, DC
Land boundaries: none
Coastline: 160 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical marine, warm, rainy
summers (May to October) and cool, rela-
tively dry winters (November to April)
Terrain: low-lying limestone base
surrounded by coral reefs
Natural resources: fish, climate and
beaches that foster tourism
Land use: 0% arable land, 0% permanent
crops, 8% meadows and pastures, 23%
forest and woodland, 69% other
Environment: within the Caribbean hurri-
cane belt
Note: important location between Cuba
and Central America','2c13b0fb3b0af64e0a221c4aff37034f3b334031594a897ef7c014a1c9045393','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad94d4c5bef18102c23de8bc91db7ce1b3aea80416682e615bf51c4054a3a2cb',1990,'CF','Central African Republic','geography',174,'Total area: 622,980 km”, land area
622,980 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 5,203 km total, Came-
roon 797 km, Chad 1,197 km, Congo 467
km, Sudan 1,165 km, Zaire 1,577 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: tropical, hot, dry winters, mild to
hot, wet summers
Terrain: vast, flat to rolling, monotonous
plateau, scattered hills in northeast and
southwest
Natural resources: diamonds, uranium,
timber, gold, oil
Land use: 3% arable land, NEGL% per-
manent crops, 5% meadows and pastures,
64% forest and woodland, 28% other
Environment: hot, dry, dusty harmattan
winds affect northern areas, poaching has
diminished reputation as one of last great
wildlife refuges, desertification
Note: landlocked, almost the precise cen-
ter of Africa','3cecf4a809d7ab37a50c56da3d94dc1a6d6d2a2d0922c448ad934b9c65fcf900','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3254f72f9173e3eedb061b4f01e19f9dd98b4dd00e96e6cc9fbb95da9e404619',1990,'TD','Chad','geography',179,'Total area: 1,284,000 km?, land area
1,259,200 km?
Comparative area: slightly more than
three times the size of California
Land boundaries: 5,968 km total, Came-
roon 1,094 km, Central African Republic
1,197 km, Libya 1,055 km, Niger 1,175
km, Nigeria 87 km, Sudan 1,360 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: Libya claims and occupies a
small portion of the Aozou Strip in far
north, exact locations of the Chad-Niger-
Nigeria and Cameroon-Chad-Nigeria tri-
points in Lake Chad have not been deter-
mined—since the boundary has not been
demarcated, border incidents have
resulted
Climate: tropical in south, desert in north
Terrain: broad, arid plains 1n center,
desert in north, mountains in northwest,
lowlands 1n south
Natural resources: small quantities of
crude oi! (unexploited but exploration be-
ginning), uranium, natron, kaolin, fish
(Lake Chad)
Land use: 2% arable land, NEGL% per-
manent crops, 36% meadows and pastures,
11% forest and woodland, 51% other, in-
cludes NEGL% irrigated
Environment: hot, dry, dusty harmattan
winds occur in north, drought and deserti-
fication adversely affecting south, subject
to plagues of locusts
Note: landlocked, Lake Chad 1s the most
significant water body in the Sahel','c4583c3d6e7183701beb0447edd719eb92c5fe63901737cff3a50a625b6bfd31','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ee1860141eb311e44cc799e7f29f488ea9084d467d196e0d8a4434c025d885c',1990,'CL','Chile','geography',184,'Total area: 756,950 km?, land area
748,800 km?, includes Isla de Pascua
(Easter Island) and Isla Sala y Gdmez
Comparative area: slightly smaller than
twice the size of Montana
Land boundaries: 6,171 km total, Argen-
tina 5,150 km, Bolivia 861 km, Peru 160
km
Coastline: 6,435 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 nm
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: short section of the southern
boundary with Argentina 1s indefinite, Bo-
livia has wanted a sovereign corridor to
the South Pacific Ocean since the Ata-
cama area was lost to Chile in 1884, dis-
pute with Bolivia over Rio Lauca water
rights, territorial claim in Antarctica
(Chilean Antarctic Territory) partially
overlaps Argentine claim
Climate: temperate, desert 1n north, cool
and damp in south
Terrain: low coastal mountains, fertile
central valley, rugged Andes in east
Natural resources: copper, timber, iron
ore, nitrates, precious metals, molybde-
num
Land use: 7% arable land, NEGL% per-
manent crops, 16% meadows and pastures,
21% forest and woodland, 56% other, in-
cludes 2% irrigated
Environment: subject to severe
earthquakes, active volcanism, tsunami,
Atacama Desert one of world’s driest re-
gions, desertification
Note: strategic location relative to sea
lanes between Atlantic and Pacific Oceans
(Strait of Magellan, Beagle Channel,
Drake Passage)
Approved for Release: 2020/08/12 C06554432','bdbbb6e52111df687c43670d0510390d000fd5f27652905ec98dbe16d9c4eff7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40c3303e9cc90cda0615fa8ba9186bf36089a5a981d13451865892351e0c5ca4',1990,'CN','China','geography',189,'Total area: 9,596,960 km2, land area
9,326,410 km?
Comparative area: slightly larger than the
US
Land boundaries: 23,213 34 km total, Af-
ghanistan 76 km, Bhutan 470 km, Burma
2,185 km, Hong Kong 30 km, India 3,380
km, North Korea 1,416 km, Laos 423 km,
Macau 0 34 km, Mongolia 4,673 km,
Nepal 1,236 km, Pakistan 523 km, USSR
7,520 km, Vietnam 1,281 km
Coastline: 14,500 km
Maritime claims:
Territorial sea 12 nm
Disputes: boundary with India; bilateral
negotiations are under way to resolve four
disputed sections of the boundary with the
USSR (Pamir, Argun, Amur, and Khaba-
rovsk areas), a short section of the bound-
ary with North Korea is indefinite, Hong
Kong 1s scheduled to become a Special
Administrative Region in 1997, Portu-
guese territory of Macau is scheduled to
become a Special Administrative Region
in 1999, sporadic border clashes with
Vietnam; involved in a complex dispute
over the Spratly Islands with Malaysia,
Philippines, Taiwan, and Vietnam, mari-
time boundary dispute with Vietnam in
the Gulf of Tonkin, Paracel Islands occu-
pied by China, but claimed by Vietnam
and Taiwan, claims Japanese-administered
Senkaku-shotd (Senkaku Islands)
Climate: extremely diverse, tropical in
south to subarctic in north
Terrain: mostly mountains, high plateaus,
deserts in west, plains, deltas, and hills in
east
Natural resources: coal, iron ore, crude oil,
mercury, tin, tungsten, antimony, manga-
nese, molybdenum, vanadium, magnetite,
aluminum, lead, ztnc, uranium, world’s
largest hydropower potential
Land use: 10% arable land, NEGL% per-
manent crops, 31% meadows and pastures,
14% forest and woodland, 45% other, 1n-
cludes 5% irrigated
Environment: frequent typhoons (about five
times per year along southern and eastern
coasts), damaging floods, tsunamis, earth-
quakes, deforestation, soil erosion, indus-
trial pollution, water pollution, desertifica-
tion
Note: world’s third-largest country (after
USSR and Canada)
Total area: 300,000 km; land area
298,170 km?
Comparative area: slightly larger than Ar-
izona
Land boundaries: none
Coastline: 36,289 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf to depth of exploita-
tion
Extended economic zone 200 nm
Territorial sea irregular polygon ex-
tending up to 100 nm from coastline as
defined by 1898 treaty, since late 1970s
has also claimed polygonal-shaped area
in South China Sea up to 285 nm in
breadth
Disputes: involved in a complex dispute
over the Spratly Islands with China, Ma-
laysia, Taiwan, and Vietnam; claims Ma-
laysian state of Sabah
Climate: tropical marine, northeast mon-
soon (November to April); southwest mon-
soon (May to October)
Terrain: mostly mountains with narrow to
extensive coastal lowlands
Natural resources: timber, crude oil,
nickel, cobalt, silver, gold, salt, copper
Land use: 26% arable land, 11% perma-
nent crops, 4% meadows and pastures,
40% forest and woodland, 19% other, in-
cludes 5% irrigated
Environment: astride typhoon belt, usually
affected by 15 and struck by five to six
cyclonic storms per year, subject to land-
slides, active volcanoes, destructive earth-
quakes, tsunami, deforestation, soil ero-
sion, water pollution
Total area: 329,560 km’, land area
325,360
Comparative area: slightly larger than
New Mexico
Land boundaries: 3,818 km total, Cambo-
dia 982 km, China 1,281 km, Laos 1,555
km
Coastline: 3,444 km (excluding islands)
Maritime claims:
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: offshore islands and three sec-
tions of the boundary with Cambodia are
in dispute, occupied Cambodia on 25 De-
cember 1978, sporadic border clashes with
China, involved in a complex dispute over
the Spratly Islands with China, Malaysia,
Philippines, and Taiwan, maritime bound-
ary dispute with China in the Gulf of
Tonkin, Paracel Islands occupied by
China but claimed by Vietnam and Tai-
wan
Climate: tropical in south, monsoonal in
north with hot, rainy season (mid-May to
mid-September) and warm, dry season
(mid-October to mid-March)
Terrain: low, flat delta in south and north,
central highlands; hilly, mountainous in
far north and northwest
Natural resources: phosphates, coal, man-
ganese, bauxite, chromate, offshore oi!
deposits, forests
Land use: 22% arable land; 2% permanent
crops, 1% meadows and pastures, 40%
forest and woodland, 35% other, includes
5% irrigated
Environment: occasional typhoons (May to
January) with extensive flooding
331
Vietnam (continued)
Total area: 352 km?, land area 349 km?
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 188 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: subtropical, tempered by easterly
tradewinds, relatively low humidity, little
seasonal temperature variation, rainy sea-
son May to November
Terrain: mostly hilly to rugged and moun-
tainous with little level land
Natural resources: sun, sand, sea, surf
Land use: 15% arable land, 6% permanent
crops, 26% meadows and pastures, 6%
forest and woodland, 47% other
Environment: rarely affected by
hurricanes, subject to frequent severe
droughts, floods, earthquakes, lack of nat-
ural freshwater resources
Note: important location 1,770 km south-
east of Miami and 65 km east of Puerto
Rico, along the Anegada Passage—a key
shipping lane for the Panama Canal, St
Thomas has one of the best natural, deep-
water harbors in the Caribbean','f760b2d969e3d2d94ccc57b1310c4b7f59e644633a642d1b464eab0ba346da35','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38361eea8ddceab4c64876a0e51003dc4a3a619002ba08332b6f84f82e39bc2d',1990,'CX','Christmas Island','geography',195,'Total area: 135 km?, land area 135 km?
Comparative area: about 0 8 times the size
of Washington, DC
Land boundaries: none
Coastline: 138 9 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical, heat and humidity mod-
erated by trade winds
Terrain: steep cliffs along coast rise
abruptly to central plateau
Natural resources: phosphate
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: almost completely
surrounded by a reef
Note: located along major sea lanes of
Indian Ocean
Total area: undetermined
Comparative area: undetermined
Land boundaries: none
Coastline: 11 1 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical
Terrain: coral atoll
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other (coral)
Environment: reef about 8 km in circum-
ference
Note: located 1,120 km southwest of Mex-
ico in the North Pacific Ocean','09941df244b26f4b2c90facf72739567ab82df804e320b128ccda5940601da6e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac82b3061e7bf9dcd4871b0cf765958fd6e161ed03bf78f94f6148e79c65a3a',1990,'CC','Cocos (Keeling) Islands','geography',200,'Total area: 14 km?, land area 14 km?,
main islands are West Island and Home
Island
Comparative area: about 24 times the size
of The Mail in Washington, DC
Land boundaries: none
Coastline: 42 6 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: pleasant, modified by the south-
east trade winds for about nine months of
the year; moderate rainfall
Terrain: flat, low-lying coral atolls
Natural resources: fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: two coral atolls thickly cov-
ered with coconut palms and other vegeta-
tion
Note: located 1,070 km southwest of Su-
matra (Indonesia) in the Indian Ocean
about halfway between Australia and Sri
Lanka','0cd55df6d032b128887976d7e4aab31446da0ab0b70206e4e1ba3e1cda3214fd','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53095a4986f9b2cd1e51bebfe2abce5f159d2bb8c7d2bc27c0ff1368781163e1',1990,'CO','Colombia','geography',205,'Total area: 1,138,910 km?, land area
1,038,700 km7?, includes Isla de Malpelo,
Roncador Cay, Serrana Bank, and Serra-
nilla Bank
Comparative area: slightly less than three
times the size of Montana
Land boundaries: 7,408 km total, Brazil
1,643 km, Ecuador 590 km, Panama 225
km, Peru 2,900, Venezuela 2,050 km
Coastline: 3,208 km total (1,448 km North
Pacific Ocean, 1,760 Caribbean Sea)
Maritime claims:
Continental shelf not specified
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary dispute with
Venezuela in the Gulf of Venezuela, terri-
torial dispute with Nicaragua over Archi-
pelago de San Andres y Providencia and
Quita Sueno Bank
Climate: tropical along coast and eastern
plains, cooler in highlands
Terrain: mixture of flat coastal lowlands,
plains in east, central highlands, some
high mountains
Natural resources: crude oil, natural gas,
coal, iron ore, nickel, gold, copper, emer-
alds
Land use: 4% arable land, 2% permanent
crops, 29% meadows and pastures, 49%
forest and woodland, 16% other, includes
NEGL irrigated
Environment: highlands subject to volcanic
eruptions; deforestation, soil damage from
overuse of pesticides, periodic droughts
Note: only South American country with
coastlines on both North Pacific Ocean
and Caribbean Sea','78d62692be6f2e86439966f00f243f05bac74a446247262026ac20582dab56ca','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cad1c69146c4c6d83e5e6370641c82675355a38f76cfcce9d61a9d2b7de3ac78',1990,'CG','Congo','geography',211,'Total area: 342,000 km?, land area
341,500 km?
Comparative area: slightly smaller than
Montana
Land boundaries: 5,504 km total, Angola
201 km, Cameroon 523 km, Central Afri-
can Republic 467 km, Gabon 1,903 km,
Zaire 2,410 km
Coastline: 169 km
Maritime claims:
Territorial sea 200 nm
Disputes: long section with Zaire along
the Congo River 1s indefinite (no division
of the river or its tslands has been made)
Climate: tropical, rainy season (March to
June), dry season (June to October), con-
stantly high temperatures and humidity,
particularly enervating climate astride the
Equator
Terrain: coasta! plain, southern basin, cen-
tral plateau, northern basin
Natural resources: petroleum, timber, pot-
ash, lead, zinc, uranium, copper, phos-
phates, natural gas
Land use: 2% arable land, NEGL% per-
manent crops, 29% meadows and pastures,
62% forest and woodland, 7% other
Environment: deforestation, about 70% of
the population lives in Brazzaville, Pointe
Noire, or along the railroad between them','9548320b8916052a01c57cea63872177c63ff27aab306f9a8b9526a7c69ec431','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88ca1d8cba4a09cc72b0c11aa4ab6c001a1e859e65fe87349a7761a4c86c3823',1990,'CK','Cook Islands','geography',216,'Total area: 240 km?, land area 240 km?
Comparative area: slightly less than 1 5
times the size of Washington, DC
Land boundaries: none
Coastline: 120 km
Maritime claims:
Continental shelf 200 meters or edge
of continental margin
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by trade
winds
Terrain: low coral atolls in north, volcanic,
hilly islands in south
Natural resources: negligible
Land use: 4% arable land, 22% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 74% other
Environment: subject to typhoons from
November to March
Note: located 4,500 km south of Hawau
in the South Pacific Ocean
Total area: undetermined, includes numer-
ous small islands and reefs scattered over
a sea area of about 1 million km?, with
Willis Islets the most important
Comparative area: undetermined
Land boundaries: none
Coastline: 3,095 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical
Terrain: sand and coral reefs and islands
(or cays)
Natural resources: negligible
Land use: 0% arable land, 0% permanent
crops; 0% meadows and pastures, 0% for-
est and woodland, 100% other, mostly
grass or scrub cover, Lihou Reef Reserve
and Coringa-Herald Reserve were
declared National Nature Reserves on 3
August 1982
Environment: subject to occasional tropical
cyclones; no permanent fresh water, 1m-
portant nesting area for birds and turtles
Note: the islands are located just off the
northeast coast of Australia in the Coral
Sea','c754a5d83bd772952f816b50c14a2c678e040eda05771bda7932f8b2d2edce77','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d43a895111b0cd9350ae5d74afacdcce36556259ab243c7caec7cbe80196db',1990,'CR','Costa Rica','geography',221,'Total area: 51,100 km?, land area 50,660
km7?, includes Isla del Coco
Comparative area: slightly smaller than
West Virginia
Land boundaries: 639 km total, Nicaragua
309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
Continental shelf 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, dry season (December to
April), rainy season (May to November)
Terrain: coastal plains separated by rug-
ged mountains
Natural resources: hydropower potential
Land use: 6% arable land, 7% permanent
crops, 45% meadows and pastures, 34%
forest and woodland, 8% other, includes
1% irrigated
Environment: subject to occasional earth-
quakes, hurricanes along Atlantic coast,
frequent flooding of lowlands at onset of
rainy season, active volcanoes, deforesta-
tion, soil erosion','f6aba6242db4d86904a8b0971822d62e654ac7e8a4e2774e6dd8104da3ae655c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20fcfbd9e8ad1d54bd2b8586bcabac57d6ba98036311f50bf02b92002d83bf21',1990,'CU','Cuba','geography',226,'Total area: 110,860 km7, land area
110,860 km?
Comparative area: slightly smaller than
Pennsylvania
Land boundary: 29 | km with US Naval
Base at Guantanamo, note—Guantanamo
is leased and as such remains part of
Coastline: 3,735 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: US Naval Base at Guantanamo
1s leased to US and only mutual agree-
ment or US abandonment of the area can
terminate the lease
Climate: tropical, moderated by trade
winds, dry season (November to April),
rainy season (May to October)
Terrain: mostly fiat to rolling plains with
rugged hills and mountains in the south-
east
Natural resources: cobalt, nickel, iron ore,
copper, manganese, salt, timber, silica
Land use: 23% arable land, 6% permanent
crops, 23% meadows and pastures, 17%
forest and woodland, 31% other, includes
10% irrigated
Environment: averages one hurricane every
other year
Note: largest country in Caribbean, 145
km south of Florida','2f71f4d6dfbe0f0cf929e62f20988e0832c5e8665b47199cf6faacc193c857aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15b8c325e3f3fb0b1ae0141ee3b89950a3926bdf4938b44aff8331b00b622b4c',1990,'CY','Cyprus','geography',231,'Total area: 9,250 km?, land area 9,240
km?
Comparative area: about 0 7 times the size
of Connecticut
Land boundaries: none
Coastline: 648 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 12 nm
Disputes: 1974 hostilities divided the 1s-
land into two de facto autonomous ar-
eas—a Greek area controlled by the Cyp-
riot Government (60% of the island’s land
area) and a Turkish-Cypriot area (35% of
the island) that are separated by a narrow
UN buffer zone, in addition, there are two
UK sovereign base areas (about 5% of the
island’s land area)
Climate: temperate, Mediterranean with
hot, dry summers and cool, wet winters
Terrain: central plain with mountains to
north and south
Natural resources: copper, pyrites, asbes-
tos, gypsum, timber, salt, marble, clay
earth pigment
Land use: 40% arable land, 7% permanent
crops, 10% meadows and pastures, 18%
forest and woodland, 25% other, includes
10% irrigated (most irrigated lands are in
the Turkish-Cypriot area of the island)
Environment: moderate earthquake activ-
ity, water resource problems (no natural
reservoir catchments, seasonal disparity in
rainfall, and most potable resources con-
centrated in the Turkish-Cypriot area)
Total area: 127,870 km, land area
125,460 km?
Comparative area: slightly larger than
New York State
Land boundaries: 3,446 km total, Austria
548 km, GDR 459 km, Hungary 676 km,
Poland 1,309 km, USSR 98 km, FRG 356
km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: Nagymaros Dam dispute with','3c38140f72d7a8e11d2609e03addcc97d799a3e7b96306baca194692d84a7548','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed972161e2dccf12f605c1d560d6c1e2e3605e547f1f71a3c20abd2565a1d607',1990,'HU','Hungary','geography',235,'Climate: temperate, cool summers, cold,
cloudy, humid winters
Terrain: mixture of hills and mountains
separated by plains and basins
Natural resources: coal, timber, lignite,
uranium, magnesite, iron ore, copper, zinc
Land use: 40% arable land, 1% permanent
crops; 13% meadows and pastures, 37%
forest and woodland, 9% other, includes
1% irrigated
Environment: infrequent earthquakes, acid
rain, water pollution, air pollution
Note: landlocked, strategically located
astride some of oldest and most significant
land routes in Europe, Moravian Gate 1s a
traditional military corridor between the
North European Plain and the Danube in
central Europe
Total area: 93,030 km?, land area 92,340
km?
Comparative area: slightly smaller than
Indiana
Land boundaries: 2,251 km total, Austria
366 km, Czechoslovakia 676 km, Roma-
nia 443 km, USSR 135 km, Yugoslavia
631 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: Transylvania question with Ro-
mania, Nagymaros Dam dispute with
Czechoslovakia
Climate: temperate, cold, cloudy, humid
winters, warm summers
Terrain: mostly flat to rolling plains
Natural resources: bauxite, coal, natural
gas, fertile soils
Land use: 54% arable land; 3% permanent
crops, 14% meadows and pastures, 18%
forest and woodland, 11% other, includes
2% irrigated
Environment: levees are common along
many streams, but flooding occurs almost
every year
Note: landlocked, strategic location astride
main land routes between Western Europe
and Balkan Peninsula as well as between
USSR and Mediterranean basin','2edf1856a960971f3e4922079c675e6ec8694bb49989780a17cc9c7913a8dd33','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7f18220fff89571906272f5daab147da6a582ee86573e592caa8648602f430',1990,'DK','Denmark','geography',241,'Total area: 43,070 km?, land area 42,370
km7?, includes the island of Bornholm in
the Baltic Sea and the rest of metropoli-
tan Denmark, but excludes the Faroe Is-
lands and Greenland
Comparative area: slightly more than
twice the size of Massachusetts
Land boundaries: 68 km with FRG
Coastline: 3,379 km
Maritime claims:
Contiguous zone 4 nm
Continental shelf 200 meters or to
depth of exploitation
Excluswe fishing zone 200 nm
Territorial sea 3 nm
Disputes: Rockall continental shelf dispute
involving Iceland, Ireland, and the UK
(Ireland and the UK have signed a bound-
ary agreement in the Rockall area), Den-
mark has challenged Norway’s maritime
claims between Greenland and Jan Mayen
Climate: temperate, humid and overcast,
mild, windy winters and cool summers
Terrain: low and flat to gently rolling
plains
Natural resources: crude oil, natural gas,
fish, salt, limestone
Land use: 61% arable land, NEGL% per-
manent crops, 6% meadows and pastures,
12% forest and woodland, 21% other, in-
cludes 9% irrigated
Environment: air and water pollution
Note: controls Damish Straits linking Bal-
tic and North Seas','f88a721375d25ff3bca5455329782f981ad0ec1ce594f5493155c2a151e9ea59','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9da8e79b3cbf2b8c5abe65a55e77ca59e21c339251acf1f04cad3105fb10c475',1990,'DJ','Djibouti','geography',246,'Total area: 22,000 km?, land area 21,980
km?
Comparative area: slightly larger than
Massachusetts
Land boundaries: 517 km total, Ethiopia
459 km, Somalia 58 km
Coastline: 314 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: possible claim by Somalia based
on unification of ethnic Somalis
Climate: desert, torrid, dry
Terrain: coastal plain and plateau sepa-
rated by central mountains
Natural resources: geothermal areas
Land use: 0% arable land, 0% permanent
crops, 9% meadows and pastures,
NEGL% forest and woodland, 91% other
Environment: vast wasteland
Note: strategic location near world’s busi-
est shipping lanes and close to Arabian
oilfields, terminus of rail traffic into Ethio-
pia','fb60b3e95fc1ae0258d133d07ec10f8a2c55b93183e9d2a303669092a884fca5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e441b47a5260a72f185c92b06c1c78d4a2a2c358115c230402bf03c9d386dc4b',1990,'DM','Dominica','geography',251,'Total area: 750 km?, land area 750 km?
Comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: none
Coastline: 148 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by northeast
trade winds, heavy rainfall
Terrain: rugged mountains of volcanic ort-
gin
Natural resources: timber
Land use: 9% arable land, 13% permanent
crops, 3% meadows and pastures, 41%
forest and woodland, 34% other
Environment: flash floods a constant haz-
ard, occasional hurricanes
Note: located 550 km southeast of Puerto
Rico 1n the Caribbean Sea','1006ea430b4388b6c7bedbd487312a38d1a9c99e5ed136c0819eef1bd1be39b8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5f27f4306880969b99d4e4d7ee9d49a72284461b38db7f1837da85d35daffea',1990,'DO','Dominican Republic','geography',256,'Total area: 48,730 km?, land area 48,380
km?
Comparative area: slightly more than
twice the size of New Hampshire
Land boundary 275 km with Haiti
Coastline: 1,288 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf outer edge of conti-
nental margin or 200 nm
Extended economic zone 200 nm
Territorial sea 6 nm
Climate: tropical maritime, little seasonal
temperature variation
Terrain: rugged highlands and mountains
with fertile valleys interspersed
Natural resources: nickel, bauxite, gold,
silver
Land use: 23% arable land, 7% permanent
crops; 43% meadows and pastures, 13%
forest and woodland, 14% other, includes
4% irrigated
Environment: subject to occasional hurri-
canes (July to October), deforestation
Note: shares island of Hispaniola with
Haiti (western one-third is Haiti, eastern
two-thirds 1s the Dominican Republic)','58d947627514c7ecc6cb6cb4dc78fe452981343e57b8ca2d7a23bca279767e00','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72a5fb067ca5bc8d73e3abf23e64508530f5bef4b193ad356cebd38dbecfa5e0',1990,'EC','Ecuador','geography',261,'Total area: 283,560 km”, land area
276,840 km?, includes Galapagos Islands
Comparative area: slightly smaller than
Nevada
Land boundaries: 2,010 km total, Colom-
bia 590 km, Peru 1,420 km
Coastline: 2,237 km
Maritime claims:
Continental shelf 200 m
Territorial sea 200 nm
Disputes: two sections of the boundary
with Peru are in dispute
Climate: tropical along coast becoming
cooler inland
Terrain: coastal plain (Costa),
inter-Andean central highlands (Sierra),
and flat to rolling eastern jungle (Oriente)
Natural resources: petroleum, fish, timber
Land use: 6% arable land, 3% permanent
crops, 17% meadows and pastures, 51%
forest and woodland, 23% other, includes
2% irrigated
Environment: subject to frequent earth-
quakes, landslides, volcanic activity, defor-
estation, desertification, soil erosion, peri-
odic droughts
Note: Cotopaxi in Andes 1s highest active
volcano in world','d8888445e97e393373dcc51327c6fd8cebcc29fbbdf62bc61726d658e939fea5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4fccc978bc21d9fc50e01860f0192c907aa4f5a9fd9df9e7d894f2e0f33781a',1990,'EG','Egypt','geography',264,'Total area: 1,001,450 km?, land area
995,450 km?
Comparative area: slightly more than
three times the size of New Mexico
Land boundaries: 2,689 km total, Gaza
Strip 11, Israel 255 km, Libya 1,150 km,
Sudan 1,273 km
Coastline: 2,450 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone undefined
Territorial sea 12 nm
Disputes: Administrative Boundary and
international boundary with Sudan
Climate: desert, hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
Natural resources: crude oil, natural gas,
iron ore, phosphates, manganese, lime-
stone, gypsum, talc, asbestos, lead, zinc
Land use: 3% arable land, 2% permanent
crops, 0% meadows and pastures;
NEGL®% forest and woodland, 95% other,
includes 5% irrigated
Environment: Nile is only perenmal water
source, increasing soil salinization below
Aswan High Dam, hot, driving windstorm
called khamsin occurs 1n spring, water
pollution, desertification
Note: controls Sinai Peninsula, only land
bridge between Africa and remainder of
Eastern Hemisphere; controls Suez Canal,
shortest sea link between Indian Ocean
and Mediterranean, size and juxtaposition
to Israel establish 1ts major role in Middle
Eastern geopolitics
Total area: 21,040 km?2, land area 20,720
km?
Comparative area: slightly smaller than
Massachusetts
Land boundaries: 545 km total, Guate-
mala 203 km, Honduras 342 km
Coastline: 307 km
Maritime claims:
Territorial sea 200 nm (overflight and
navigation permitted beyond 12 nm)
Disputes: several sections of the boundary
with Honduras are in dispute
Climate: tropical, rainy season (May to
October), dry season (November to April)
Terrain: mostly mountains with narrow
coastal belt and central plateau
Natural resources: hydropower and geo-
thermal power, crude oil
Land use: 27% arable land, 8% permanent
crops, 29% meadows and pastures, 6%
forest and woodland, 30% other, includes
5% irrigated
Environment: The Land of Volcanoes; sub-
Ject to frequent and sometimes very de-
structive earthquakes, deforestation, soil
erosion, water pollution
Note: smallest Central American country
and only one without a coastline on Carib-
bean Sea','175857b97bc574a0406138dbc6042dd68bfe11a1db6124545f4411ad8dace05e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a618d1326a84214c31d43692c1ba9ae0020fdead30420128b95bfba8d1b6f34f',1990,'GQ','Equatorial Guinea','geography',269,'Total area: 28,050 km, land area 28,050
km?
Comparative area: slightly larger than
Maryland
Land boundaries: 539 km total, Cameroon
189 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
Exclusive economic zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary dispute with','fc166239e987bd2159645455a9bd6535c3cae6cb633bbcaa54fa74e19e8c1487','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e2419f20feca50b3bc02d5526b92f07b085479294c922b5d9457e96d5c15ce3',1990,'GA','Gabon','geography',270,'Climate: tropical, always hot, humid
Terrain: coastal plains rise to interior hills,
islands are volcanic
Natural resources: timber, crude oil, small
unexploited deposits of gold, manganese,
uranium
Land use: 8% arable land, 4% permanent
crops, 4% meadows and pastures, 51%
forest and woodland, 33% other
Environment: subject to violent windstorms
Note: insular and continental regions
rather widely separated
Total area: 267,670 km7, land area
257,670 km?
Comparative area: slightly smaller than
Colorado
Land boundaries: 2,551 km total, Came-
roon 298 km, Congo 1,903 km, Equatorial
Guinea 350 km
Coastline: 885 km
Maritime claims:
Contiguous zone 24 nm
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary with Equato-
rial Guinea
Climate: tropical, always hot, humid
Terrain: narrow coastal plain, hilly inte-
rior, savanna 1n east and south
Natural resources: crude oil, manganese,
uranium, gold, timber, iron ore
Land use: 1% arable land, 1% permanent
crops, 18% meadows and pastures, 78%
forest and woodland, 2% other
Environment: deforestation
Total area: 11,300 km”, land area 10,000
m
Comparative area: slightly more than
twice the size of Delaware
Land boundary: 740 km with Senegal
Coastline: 80 km
Maritime claims:
Contiguous zone 18 nm
Continental shelf not specific
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: short section of boundary with
Senegal 1s indefinite
Climate: tropical, hot, rainy season (June
to November), cooler, dry season
(November to May)
Terrain: flood plain of the Gambia River
flanked by some low hills
Natural resources: fish
Land use: 16% arable land, 0% permanent
crops, 9% meadows and pastures, 20%
forest and woodland, 55% other, includes
3% irrigated
Environment: deforestation
Note: almost an enclave of Senegal, small-
est country on the continent of Africa
Total area: 380km7, land area 380 km?
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: 62 km total, Egypt 11
km, Israel 51 km
Coastline: 40 km
Maritime claims: Israeli occupied with
status to be determined
Disputes: Israel occupied with status to
be determined
Climate: temperate, mild winters, dry and
warm to hot summers
Approved for Release: 2020/08/12 C06554432
Terrain: flat to rolling, sand and dune cov-
ered coastal plain
Natural resources: negligible
Land use: 13% arable land, 32% perma-
nent crops, 0% meadows and pastures, 0%
forest and woodland, 55% other
Environment: desertification
Note: there are 18 Jewish settlements in
the Gaza Strip
Total area: 108,330 km, land area
105,980 km?
Comparative area: slightly smaller than
Tennessee
Land boundaries: 2,296 km total, Czecho-
slovakia 459 km, Poland 456 km, FRG
1,381 km
Coastline: 901 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: it 1s US policy that the final
borders of Germany have not been estab-
lished, the US 1s seeking to settle the
property claims of US nationals against
the GDR
Climate: temperate, cloudy, cold winters
with frequent rain and snow, cool, wet
summers
Terrain: mostly flat plain with hills and
mountains 1n south
Natural resources: lignite, potash, ura-
nium, copper, natural gas, salt, nickel
Land use: 45% arable land, 3% permanent
crops, 12% meadows and pastures, 28%
forest and woodland, 12% other, includes
2% irrigated
Environment: significant deforestation in
mountains caused by air pollution and
acid rain
Note: strategic location on North Euro-
pean Plain and near the entrance to the
Baltic Sea, West Berlin ts an enclave
(about 116 km by air or 176 km by road
from FRG)','12f220e522dd5eaa349360542ab43b1681f82a0bcd39daade7bf52abcb51e50c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16f5e0d43af73879d84311ddd4eeed4e2143711f9286d857ea208f51938f9fc3',1990,'ET','Ethiopia','geography',276,'Total area: 1,221,900 km?, land area
1,101,000 km?
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 5,141 km total, Djibouti
459 km, Kenya 861 km, Somalia 1,600
km, Sudan 2,221 km
Coastline: 1,094 km
Maritime claims:
Territorial sea 12 nm
Disputes: southern half of the boundary
with Somalia 1s a Provisional Administra-
tive Line, possible clarm by Somalia based
on unification of ethnic Somalis, territorial
dispute with Somalia over the Ogaden,
separatist movement in Eritrea, antigo-
vernment insurgencies in Tigray and other
areas
Climate: tropical monsoon with wide
topographic-induced variation, prone to
extended droughts
Terrain: high plateau with central moun-
tain range divided by Great Rift Valley
Natural resources: small reserves of gold,
platinum, copper, potash
Land use: 12% arable land, 1% permanent
crops, 41% meadows and pastures, 24%
forest and woodland, 22% other, includes
NEGL% irrigated
Environment: geologically active Great
Rift Valley susceptible to earthquakes,
volcanic eruptions, deforestation, overgraz-
ing, soul erosion; desertification, frequent
droughts, famine
Note: strategic geopolitical position along
world’s busiest shipping lanes and close to
Arabian oilfields, major resettlement
project ongoing in rural areas will signifi-
cantly alter population distribution and
settlement patterns over the next several
decades
94
Approved for Release: 2020/08/12 C06554432','e65ec68076bb522ba979b9de2373569c3add00d5b3d8740d6611edae276d99d2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7567c7fa5948e043dc4a24d40cb92ee50d760c42e23d258d6a2b53af63bb6a15',1990,'FR','France','geography',279,'Total area: 12,170 km?, land area 12,170
km7?, includes the two main islands of East
and West Falkland and about 200 small
islands
Comparative area: slightly smaller than
Connecticut
Land boundaries: none
Coastline: 1,288 km
Maritime claims:
Continental shelf 100 meter depth
Exclusive fishing zone 150 nm
Territorial sea 12 nm
Disputes: administered by the UK,
claimed by Argentina
Climate: cold marine, strong westerly
winds, cloudy, humid, rain occurs on more
than half of days in year, occasional snow
all year, except in January and February,
but does not accumulate
Terrain: rocky, hilly, mountainous with
some boggy, undulating plains
Natural resources: fish and wildlife
Land use: 0% arable land, 0% permanent
crops, 99% meadows and pastures, 0%
forest and woodland, 1% other
Environment: poor soil fertility and a short
growing season
Note: deeply indented coast provides good
natural harbors
Total area: 547,030 km, land area
545,630 km/?, includes Corsica and the
rest of metropolitan France, but excludes
the overseas administrative divisions
Comparative area: slightly more than
twice the size of Colorado
Land boundaries: 2,892 4 km total, An-
dorra 60 km, Belgium 620 km, FRG 451
km, Italy 488 km, Luxembourg 73 km,
Monaco 4 4 km, Spain 623 km, Switzer-
land 573 km
Coastline: 3,427 km (includes Corsica, 644
km)
Maritime claims:
Contiguous zone 12-24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary dispute with
Canada (St Pierre and Miquelon), Mada-
gascar claims Bassas da India, Europa
Island, Glorioso Islands, Juan de Nova
Island, and Tromelin Island, Comoros
claims Mayotte, Mauritius claims Trome-
hn Island, Seychelles claims Tromelin Is-
land, Suriname claims part of French Gu-
lana, territorial claim in Antarctica
(Adéhe Land)
Climate: generally cool winters and mild
summers, but mild winters and hot sum-
mers along the Mediterranean
Terrain: mostly flat plains or gently rolling
hills in north and west, remainder 1s
mountainous, especially Pyrenees in south,
Alps in east
Natural resources: coal, iron ore, bauxite,
fish, timber, zinc, potash
Land use: 32% arable land, 2% permanent
crops, 23% meadows and pastures, 27%
forest and woodland, 16% other; includes
2% irrigated
Environment: most of large urban areas
and industrial centers in Rhéne, Garonne,
Seine, or Loire River basins, occasional
warm tropical wind known as mistral
Note: largest West European nation
Approved for Release: 2020/08/12 C06554432
Total area: 7,781 km7, land area 7,781
km/?, includes Ile Amsterdam, Ile Saint-
Paul, Iles Kerguelen, and Iles Crozet, ex-
cludes claim not recogmzed by the US of
about 500,000 km? in Antarctica known
as Terre Adélie
Comparative area: slightly less than 1 5
times the size of Delaware
Land boundaries: none
Coastline: 1,232 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploration
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claim in Antarctica (Terre
Adélie) not recognized by the US
Climate: antarctic
Terrain: volcanic
Natural resources: fish, crayfish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: [le Amsterdam and Ile
Saint-Paul are extinct volcanoes
Note: located in the southern Indian
Ocean about equidistant between Africa,
Antarctica, and Australia
Total area: 1,565,000 km?, land area
1,565,000 km?
Comparative area: slightly larger than
Alaska
Land boundaries: 8,114 km total, China
4,673 km, USSR 3,441 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: desert, continental (large daily
and seasonal temperature ranges)
Terrain: vast semidesert and desert plains,
mountains in west and southwest, Gob
Desert in southeast
Natural resources: coal, copper, molybde-
num, tungsten, phosphates, tin, nickel,
zinc, wolfram, fluorspar, gold
Land use: 1% arable land, 0% permanent
crops, 79% meadows and pastures, 10%
forest and woodland, 10% other, includes
NEGLG irrigated
Environment: harsh and rugged
Note: landlocked, strategic location be-
tween China and Soviet Union
Total area: 340 km?, land area 340 km?
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 84 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, little seasonal tempera-
ture variation, rainy season (May to No-
vember)
Terrain: volcanic, mountainous, Soufriére
volcano on the island of St Vincent
Natural resources: negligible
Land use: 38% arable land, 12% perma-
nent crops, 6% meadows and pastures,
41% forest and woodland, 3% other, 1n-
cludes 3% irrigated
Environment: subject to hurricanes, Souf-
riére volcano is a constant threat
Note: some islands of the Grenadines
group are administered by Grenada
Total area: 163,610 km, land area
155,360 km?
Comparative area: slightly larger than
Total area: 5,860 km7?, land area 5,640
km7?, includes West Bank, East Jerusalem,
Latrun Salient, Jerusalem No Man’s
Land, and the northwest quarter of the
Dead Sea, but excludes Mt Scopus
Comparative area: slightly larger than
Delaware
Land boundaries: 404 km total, Israel 307
km, Jordan 97 km,
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: Israeli occupied with status to
be determined
Approved for Release: 2020/08/12 C06554432
Climate: temperate, temperature and pre-
cipitation vary with altitude, warm to hot
summers, cool to mild winters
Terrain: mostly rugged dissected upland,
some vegetation in west, but barren in
east
Natural resources: negligible
Land use: 27% arable land, 0% permanent
crops, 32% meadows and pastures, 1%
forest and woodland, 40% other
Environment: highlands are main recharge
area for Israel’s coastal aquifers
Note: landlocked, there are 173 Jewish
settlements in the West Bank and 14
Israeli-bu:lt Jewish neighborhoods in East
Jerusalem','3fefd9593bc3551c07ca4d17ccd6a2f718c483abbc124c2663738b7e32ed88f7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf094510d855217c3331005bfed4002289be31d9a78a5513fd79aa58c1bef4d1',1990,'FO','Faroe Islands','geography',284,'Total area: 1,400 km’, land area 1,400
km?
Comparative area: slightly less than eight
times the size of Washington, DC
Land boundaries: none
Coastline: 764 km
Maritime claims:
Contiguous zone 4 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: mild winters, cool summers, usu-
ally overcast, foggy, windy
Terrain: rugged, rocky, some low peaks,
cliffs along most of coast
Natural resources: fish
Land use: 2% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 98% other
Environment: precipitous terrain |imits
habitation to small coastal lowlands, ar-
chipelago of 18 inhabited islands and a
few unmhabited islets
Note: strategically located along impor-
tant sea lanes tn northeastern Atlantic
about midway between Iceland and Shet-
land Islands
Total area: 18,270 km7, land area 18,270
km?
Comparative area: slightly smaller than
New Jersey
Land boundaries: none
Coastline: 1,129 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical marine, only slight sea-
sonal temperature variation
Terrain: mostly mountains of volcanic or1-
gin
Natural resources: timber, fish, gold, cop-
per, offshore oil potential
Land use: 8% arable land, 5% permanent
crops, 3% meadows and pastures; 65%
forest and woodland, 19% other, includes
NEGL% irrigated
Environment: subject to hurricanes from
November to January; includes 332 1s-
lands of which approximately 110 are 1n-
habited
Note: located 2,500 km north of New
Zealand in the South Pacific Ocean','72152c68079e7cf09821e65a41631ecd2a0d1bc772c86b62481f7bd85340da7e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25251d377265f13af2851416eee54ef8a2a9fd2c25f6732ac036b2cbf48771d3',1990,'FI','Finland','geography',289,'Total area: 337,030 km?, land area
305,470 km?
Comparative area: slightly smaller than
Montana
Land boundaries: 2,578 km total, Norway
729 km, Sweden 536 km, USSR 1,313 km
Coastline: 1,126 km excluding islands and
coastal indentations
Maritime claims:
Contiguous zone 6 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 12 nm
Territorial sea 4 nm
Climate: cold temperate, potentially sub-
arctic, but comparatively mild because of
moderating influence of the North Atlan-
tic Current, Baltic Sea, and more than
60,000 lakes
Terrain: mostly low, flat to rolling plains
interspersed with lakes and low hills
Natural resources: timber, copper, zinc,
Iron ore, silver
Land use: 8% arable land, 0% permanent
crops, NEGL% meadows and pastures,
76% forest and woodland; 16% other, in-
cludes NEGL% irrigated
Environment: permanently wet ground
covers about 30% of land, population con-
centrated on small southwestern coastal
plain
Note: long boundary with USSR, Helsinki
1s northernmost national capital on Euro-
pean continent','929ede867119dcf71e626ebc1dad1aea05b13599893eafdab5188b81256ba1c1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac89b54fb994a5810adf6f927760b696c9ba429fef0ae93f14d03286bc032c54',1990,'GF','French Guiana','geography',297,'Total area: 91,000 km7?, land area 89,150
km?
Comparative area: slightly smaller than
Indiana
Land boundaries: 1,183 km total, Brazil
673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: Suriname claims area between
Riviére Litani and Riviére Marouini (both
headwaters of the Lawa)
Climate: tropical, hot, humid, little sea-
sonal temperature variation
Terrain: low-lying coastal plains rising to
hills and small mountains
Natural resources: bauxite, timber, gold
(widely scattered), cinnabar, kaolin, fish
Land use: NEGL% arable land, NEGL%
permanent crops, NEGL% meadows and
pastures, 82% forest and woodland, 18%
other
Environment: mostly an unsettled wilder-
ness','2b938bdcff3d03427ea6cc2a1e32da8e1f56a341cb7f74a930a0b4920799f871','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd758d9ff54bbc1bca5aa5c6bc40438a8fd1ca363cef63bb96ea651db1c304d9',1990,'PF','French Polynesia','geography',302,'Total area: 3,941 km?, land area 3,660
km?
Comparative area: slightly less than one-
third the size of Connecticut
Land boundaries: none
Coastline: 2,525 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands
and low islands with reefs
Natural resources: timber, fish, cobalt
Land use: 1% arable land, 19% permanent
crops, 5% meadows and pastures, 31%
forest and woodland, 44% other
Environment: occasional cyclonic storm 1n
January, includes five archipelagoes
Note: Makatea 1s one of three great phos-
phate rock islands in the Pacific (others
are Banaba or Ocean Island 1n Kiribati
and Nauru)','41b3db23b26aaa9b279dda93aff474db19093922e9005182bb0427f28ab20463','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2549686abaf2dfd9fc11fb68599a273c987228b02e98f22f0fe2b04614e156c',1990,'RO','Romania','geography',309,'Total area: 248,580 km, land area
244,280 km?, includes West Berlin
Comparative area: slightly smaller than
Oregon
Land boundaries: 4,256 km total, Austria
784 km, Belgium 167 km, Czechoslovakia
356 km, Denmark 68 km, France 451 km,
GDR 1,381 km, Luxembourg 138 km,
Netherlands 577 km, Switzerland 334 km
Coastline: 1,488 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm (extends, at one
point, to 16 nm 1n the Helgoldnder
Bucht)
Disputes: it is US policy that the final
borders of Germany have not been estab-
lished
Climate: temperate and marine, cool,
cloudy, wet winters and summers, occa-
sional warm, tropical foehn wind; high
relative humidity
Terrain: lowlands in north, uplands in cen-
ter, Bavarian Alps in south
Natural resources: iron ore, coal, potash,
timber
Land use: 30% arable land, 1% permanent
crops, 19% meadows and pastures, 30%
forest and woodland, 20% other, includes
1% irrigated
Environment: air and water pollution
Note: West Berlin 1s an exclave (about
116 km by air or 176 km by road from
FRG)
Total area: 237,500 km, land area
230,340 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,904 km total, Bulgaria
608 km, Hungary 443 km, USSR 1,307
km, Yugoslavia 546 km
Coastline: 225 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: Transylvania question with Hun-
gary, Bessarabia question with USSR
Climate: temperate, cold, cloudy winters
with frequent snow and fog, sunny sum-
mers with frequent showers and thunder-
storms
Terrain: central Transylvanian Basin 1s
separated from the plain of Moldavia on
the east by the Carpathian Mountains and
separated from the Walachian Plain on
the south by the Transylvanian Alps
Natural resources: crude oil (reserves be-
ing exhausted), timber, natural gas, coal,
Iron ore, salt
Land use: 43% arable land, 3% permanent
crops, 19% meadows and pastures, 28%
forest and woodland, 7% other, includes
11% irrigated
Environment: frequent earthquakes most
severe in south and southwest, geologic
structure and climate promote landslides,
air pollution in south
Note: controls most easily traversable land
route between the Balkans and western
USSR','1ca206e65284f34ec3e179415458e8c4f9e739c82c8147fcf7d7e804962017e7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b1f518a80e4fac7cc3b8b35118b91d5c72db97d5bd0b631a7822bd55e88391',1990,'GH','Ghana','geography',313,'Total area: 238,540 km?, land area
230,020 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,093 km total, Burkina
aly km, Ivory Coast 668 km, Togo 877
m
Coastline: 539 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 nm
Exclusive economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, warm and comparatively
dry along southeast coast, hot and humid
in southwest, hot and dry in north
Terrain: mostly low plains with dissected
plateau in south-central area
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rub-
ber
Land use: 5% arable land, 7% permanent
crops, 15% meadows and pastures, 37%
forest and woodland, 36% other, includes
NEGL% irrigated
Environment: recent drought in north se-
verely affecting marginal agricultural ac-
tivities, deforestation, overgrazing, soil
erosion, dry, northeasterly harmattan wind
(January to March)
Note: Lake Volta 1s world’s largest artifi-
cial lake','fe90c5fa13cbcbd98d06ab31bf441e4b0d62f6e5883d7c1b7d3ce1336f16c728','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba9882b4cd340c80f4ab066d644e4b2a77e51f66db0b9cf88f1d94a82587183',1990,'GI','Gibraltar','geography',318,'Total area: 6 5 km?, land area 6 5 km?
Comparative area: about 11 times the size
of The Mall in Washington, DC
Land boundaries: | 2 km with Spain
Coastline: 12 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 3 nm
Territorial sea 3 nm
Disputes: source of occasional friction be-
tween Spain and the UK
Climate: Mediterranean with mild winters
and warm summers
Terrain: a narrow coastal lowland borders
The Rock
Natural resources: negligible
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: natural freshwater sources
are meager so large water catchments
(concrete or natural rock) collect rain wa-
ter
Note: strategic location on Strait of Gi-
braltar that links the North Atlantic
Ocean and Mediterranean Sea
Total area: 5 km7, land area 5 km/?, in-
cludes Ile Glorieuse, Ile du Lys, Verte
Rocks, Wreck Rock, and South Rock
Comparative area: about 8 5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 35 2 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by Madagascar
Climate: tropical
Terrain: undetermined
Natural resources: guano, coconuts
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other—lush vege-
tation and coconut palms
Environment: subject to periodic cyclones
Note: located in the Indian Ocean just
north of the Mozambique Channel be-
tween Africa and Madagascar
Total area: less than 5 km?, land area
less than 5 km?, includes 100 or so islets,
coral reefs, and sea mounts scattered over
the South China Sea
Comparative area: undetermined
Land boundaries: none
Coastline: 926 km
Maritime claims: undetermined
Disputes: China, Malaysia, the Philip-
pines, Taiwan, and Vietnam claim all or
part of the Spratly Islands
Climate: tropical
Terrain: flat
Natural resources: fish, guano, oil and nat-
ural gas potential
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: subject to typhoons, includes
numerous small islands, atolls, shoals, and
coral reefs
Note: strategically located near several
primary shipping lanes 1n the central
South China Sea, serious navigational
hazard','b0def63edf84012be757a1789e61ff81fda2a377e3bcf050176ff149bc52b373','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b45b08a6da1039b39ab4a7307cbee5209b0819329328b4d91b4347def7a49df',1990,'GR','Greece','geography',323,'Total area: 131,940 km”, land area
130,800 km?
Comparative area: slightly smaller than
Alabama
Land boundaries: 1,228 km total, Albania
282 km, Bulgaria 494 km, Turkey 206
km, Yugoslavia 246 km
Coastline: 13,676 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 6 nm
Disputes: complex maritime and air (but
not territorial) disputes with Turkey in
Aegean Sea; Cyprus question, Macedonia
question with Bulgaria and Yugoslavia,
Northern Epirus question with Albania
Climate: temperate, mild, wet winters, hot,
dry summers
Terrain: mostly mountains with ranges
extending into sea as peninsulas or chains
of islands
Natural resources: bauxite, lignite, magne-
site, crude oil, marble
Land use: 23% arable land, 8% permanent
crops, 40% meadows and pastures, 20%
forest and woodland, 9% other, includes
7% irrigated
Environment: subject to severe
earthquakes, air pollution, archipelago of
2,000 islands
Note: strategic location dominating the
Aegean Sea and southern approach to
Turkish Straits
Climate: temperate, hot, relatively dry
summers with mild, rainy winters along
coast, warm summer with cold winters
inland
Terrain: mostly mountains with large ar-
eas of karst topography, plain in north
Natural resources: coal, copper, bauxite,
timber, iron ore, antimony, chromium,
lead, zinc, asbestos, mercury, crude oil,
natural gas, nickel, uranium
Land use: 28% arable land, 3% permanent
crops, 25% meadows and pastures, 36%
forest and woodland, 8% other, includes
1% irrigated
Environment: subject to frequent and de-
structive earthquakes
Note: controls the most important land
routes from central and western Europe to
Aegean Sea and Turkish straits
Total area: 2,345,410 km/?, land area
2,267,600 km?
Comparative area: slightly more than one-
quarter the size of US
Land boundaries: 10,271 km total, Angola
2,511 km, Burund: 233 km, Central Afri-
can Republic 1,577 km, Congo 2,410 km,
Rwanda 217 km, Sudan 628 km, Uganda
765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
Territorial sea 12 nm
Disputes: Tanzania-Zaire-Zambuia tripoint
in Lake Tanganyika may no longer be
indefinite since it 1s reported that the in-
definite section of the Zaire-Zambia
boundary has been settled, long section
with Congo along the Congo River 1s 1n-
definite (no division of the river or its 1s-
lands has been made)
Climate: tropical, hot and humid in equa-
torial river basin, cooler and drier in
southern highlands, cooler and wetter in
eastern highlands, north of Equator—wet
season April to October, dry season De-
cember to February, south of Equator—
wet season November to March, dry sea-
son April to October
Terrain: vast central basin 1s a low-lying
plateau, mountains in east
Natural resources: cobalt, copper, cad-
mium, crude oil, industrial and gem dia-
monds, gold, silver, zinc, manganese, tin,
germanium, uranium, radium, bauxite,
iron ore, coal, hydropower potential
Land use: 3% arable land, NEGL% per-
manent crops, 4% meadows and pastures,
78% forest and woodland, 15% other, in-
cludes NEGL% irrigated
Environment: dense tropical rainforest in
central river basin and eastern highlands,
periodic droughts in south
Note: straddles Equator, very narrow strip
of land 1s only outlet to South Atlantic
Ocean
346','4409513c9975c8333baf57584391e6e77c88c4d34154864a1f75053192db6847','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('828911274d78fae9a84ddfafd8ff52f9cbf0d6f078610069a45defddee51cd59',1990,'GL','Greenland','geography',328,'Total area: 2,175,600 km2, land area
341,700 km? (ice free)
Comparative area: slightly more than
three times the size of Texas
Land boundaries: none
Coastline: 44,087 km
Maritime claims:
Contiguous zone 4 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Disputes: Denmark has challenged Nor-
way’s maritime claims between Greenland
and Jan Mayen
Climate: arctic to subarctic, cool summers,
cold winters
Terrain: flat to gradually sloping 1cecap
covers all but a narrow, mountainous, bar-
ren, rocky coast
Natural resources: zinc, lead, iron ore,
coal, molybdenum, cryolite, uranium, fish
Land use: 0% arable land, 0% permanent
crops, 1% meadows and pastures,
NEGL% forest and woodland, 99% other
Environment: sparse population confined to
small settlements along coast, continuous
permafrost over northern two-thirds of the
island
Note: dominates North Atlantic Ocean
between North America and Europe','31e37ed2df01d32613e6809497804307b0f81f7cf31cafe1d83b5c4258390b17','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5c9352ebd3820ca69c016ab9ad801c263616d1fc4167896a58159c82145fa7c',1990,'GD','Grenada','geography',333,'Total area: 340 km?, land area 340 km?
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 121 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, tempered by northeast
trade winds
Terrain: volcanic in origin with central
mountains
Natural resources: timber, tropical fruit,
deepwater harbors
Land use: 15% arable land, 26% perma-
nent crops, 3% meadows and pastures, 9%
forest and woodland, 47% other
Environment: lies on edge of hurricane
belt, hurricane season lasts from June to
November
Note: islands of the Grenadines group are
divided politically with St Vincent and
the Grenadines','f8060c34597e7ad428442c044559649562209ad52b63942c90ce91dc4112fc1c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1788875fedf06945bdadafd5dc89e9aafc6db62b7539ad4eee4a187fb42e8648',1990,'GP','Guadeloupe','geography',338,'Total area: 1,780 km7, land area 1,760
km?
Comparative area: 10 times the size of
Washington, DC
Land boundaries: 14 km with Netherlands
Antilles
Coastline: 306 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: subtropical tempered by trade
winds, relatively high humidity
Terrain: Basse-Terre 1s volcanic in origin
with interior mountains, Grand-Terre 1s
low limestone formation
Natural resources: cultivable land,
beaches, and climate that foster tourism
Land use: 18% arable land, 5% permanent
crops, 13% meadows and pastures, 40%
forest and woodland, 24% other, includes
1% irrigated
Environment: subject to hurricanes (June
to October), La Soufriére 1s an active vol-
cano
Note: located 500 km southeast of Puerto
Rico in the Caribbean Sea','0e34962d0b0ff1e4272a11ebf86cd5160cbc9ad72f741b83a052eae4030440e0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f06251925e5f8808152939b834c05dc3a6c092a7841f85c48e23cd383c117a6',1990,'GU','Guam','geography',342,'Total area: 541 km?, land area 541 km?
Comparative area: slightly more than
three times the size of Washington, DC
Land boundaries: none
Coastline: 125 5 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical marine, generally warm
and humid, moderated by northeast trade
winds, dry season from January to June,
rainy season from July to December, little
seasonal temperature variation
Terrain: volcanic origin, surrounded by
coral reefs, relatively flat coraline lime-
stone plateau (source of most fresh water)
with steep coastal cliffs and narrow
coastal plains in north, low-rising hills in
center, mountains 1n south
Natural resources: fishing (largely undevel-
oped), tourism (especially from Japan)
Land use: 11% arable land, 11% perma-
nent crops, 15% meadows and pastures,
18% forest and woodland, 45% other
Environment: frequent squalls during rainy
season, subject to relatively rare, but po-
tentially very destructive typhoons (espe-
cially in August)
Note: largest and southernmost island in
the Mariana Islands archipelago, strategic
location in western North Pacific Ocean
5,955 km west-southwest of Honolulu
about three-quarters of the way between
Hawaun and the Philippines','49cec81e69c08c3894720e2d6667b3055420c260028aa7837c5d813f38315b8d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e40f3644b9aeda9606974954b44fe7829091e7a0f7925f761e961fdb9e40d40',1990,'GT','Guatemala','geography',347,'Total area: 108,890 km7?, land area
108,430 km?
Comparative area: slightly smaller than
Tennessee
Land boundaries: 1,687 km total, Belize
266 km, El Salvador 203 km, Honduras
256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
Continental shelf not specific
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims Belize, but boundary ne-
gotiations are under way
Climate: tropical, hot, humid in lowlands,
cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone pla-
teau (Petén)
Natural resources: crude oil, nickel, rare
woods, fish, chicle
Land use: 12% arable land, 4% permanent
crops, 12% meadows and pastures, 40%
forest and woodland, 32% other, includes
1% irrigated
Environment: numerous volcanoes in
mountains, with frequent violent earth-
quakes, Caribbean coast subject to hurri-
canes and other tropical storms, deforesta-
tion, soil erosion, water pollution
Note: no natural harbors on west coast','b3eff079549d91743c6f0403ad62e47dd3f00f929c2618e2d8771d730d38648a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88713100cb4138ef3e553753c28cd7dc71733c15ad1b1be9be617a362a2435e4',1990,'GG','Guernsey','geography',352,'Total area: 194 km?, land area 194 km?;
includes Alderney, Guernsey, Herm, Sark,
and some other smaller islands
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 50 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: temperate with mild winters and
cool summers, about 50% of days are
overcast
Terrain: mostly level with low hills in
southwest
Natural resources: cropland
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other,
about 50% cultivated
Environment: large, deepwater harbor at
St Peter Port
Note: 52 km west of France','d4b65c452cd80481c7873cdf6ecea4532f8801bc7c48d17a5264d40188d695b0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bfdbff356cf3a59eb0a0eeb70f44daefc928f5743c6027d79af386b6b7618a5',1990,'GN','Guinea','geography',356,'Total area: 245,860 km7; land area
245,860 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 3,399 km total, Guinea-
Bissau 386 km, Ivory Coast 610 km, Libe-
ria 563 km, Mali 858 km, Senegal 330
km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: generally hot and humid,
monsoonal-type rainy season (June to No-
vember) with southwesterly winds, dry
season (December to May) with northeast-
erly harmattan winds
Terrain: generally flat coastal! plain, hilly
to mountainous interior
Natural resources: bauxite, iron ore, dia-
monds, gold, uranium, hydropower, fish
Land use: 6% arable land; NEGL% per-
manent crops, 12% meadows and pastures,
42% forest and woodland, 40% other, in-
cludes NEGL% irrigated
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry sea-
son, deforestation
Total area: 1,919,440 km?, land area
1,826,440 km?
Comparative area: slightly less than three
times the size of Texas
Land boundaries: 2,602 km total, Malay-
sia 1,782 km, Papua New Guinea 820 km
Coastline: 54,716 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf to depth of exploita-
tion
Extended economic zone 200 nm Ter-
ritorial sea 12 nm
Disputes East Timor question with Portu-
gal
Climate: tropical, hot, humid, more mod-
erate in highlands
Terrain: mostly coastal lowlands, larger
islands have interior mountains
Natural resources: crude oil, tin, natural
gas, nickel, timber, bauxite, copper, fertile
soils, coal, gold, silver
Land use: 8% arable land, 3% permanent
crops, 7% meadows and pastures, 67%
forest and woodland, 15% other, includes
3% irrigated
Environment: archipelago of 13,500 islands
(6,000 inhabited), occasional floods, severe
droughts, and tsunamis, deforestation
Note: straddles Equator, strategic location
astride or along major sea lanes from In-
dian Ocean to Pacific Ocean
Total area: 1,648,000 km, land area
1,636,000 km?
Comparative area: slightly larger than
Alaska
Land boundaries: 5,492 km total, Afghani-
stan 936 km, Iraq 1,458 km, Pakistan 909
km, Turkey 499 km, USSR 1,690 km
Coastline: 3,180 km
Maritime claims:
Continental shelf not specific
Exclusive fishing zone 50 nm in the
Sea of Oman, median-line boundaries
in the Persian Gulf
Territorial sea 12 nm
Disputes: Iran began formal UN peace
negotiations with Iraq in August 1988 to
end the war that began on 22 September
1980—troop withdrawal, freedom of navi-
gation, sovereignty over the Shatt al Arab
waterway and prisoner-of-war exchange
are the major issues for negotiation; Kurd-
ish question among Iran, Iraq, Syria, Tur-
key, and the USSR, occupies three islands
in the Persian Gulf claimed by UAE
(Jazireh-ye Abi Misa or Abii Misa,
Jazireh-ye Tonb-e Bozorg or Greater
Tunb, and Jazireh-ye Tonb-e Kiichek or
Lesser Tunb), periodic disputes with Af-
ghanistan over Helmand water rights, Bo-
luch question with Afghanistan and Paki-
stan
Climate: mostly arid or semiarid, subtro-
pical along Caspian coast
Terrain: rugged, mountainous rim, high,
central basin with deserts, mountains,
small, discontinuous plains along both
coasts
Natural resources: petroleum, natural gas,
coal, chromium, copper, iron ore, lead,
manganese, zinc, sulfur
Land use: 8% arable land, NEGL% per-
manent crops, 27% meadows and pastures,
11% forest and woodland, 54% other, in-
cludes 2% irrigated
Approved for Release: 2020/08/12 C06554432
Environment: deforestation, overgrazing,
desertification
Total area: 960 km?, land area 960 km?
Comparative area: slightly less than 5 5
times the size of Washington, DC
Land boundaries: none
Coastline: 209 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, hot, humid, one rainy
season (October to May)
Terrain: volcanic, mountainous
Natural resources: fish
Land use: 1% arable land, 20% permanent
crops, 1% meadows and pastures, 75%
forest and woodland, 3% other
Environment: deforestation, soil erosion
Note: located south of Nigeria and west of
Gabon near the Equator in the North At-
lantic Ocean','779b1e8d8eb2111a86b4535cdc9e99c94d01f7b05eaf1afb9cb64908c94c8393','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e47aa3932868e83cbbc120855d2a6b227d029c5c220ae491658d5cb5b4dd6aa4',1990,'GW','Guinea-Bissau','geography',359,'Total area: 36,120 km?, land area 28,000
km?
Comparative area: slightly less than three
times the size of Connecticut
Land boundaries: 724 km total, Guinea
386, Senegal 338 km
Coastline: 350 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: the International Court of Jus-
tice (ICJ) has rendered its decision on the
Guinea-Bissau/Senegal maritime bound-
ary (in favor of Senegal)—that decision
has been rejected by Guinea-Bissau
Climate: tropical, generally hot and hu-
mid, monsoon-type rainy season (June to
November) with southwesterly winds, dry
season (December to May) with northeast-
erly harmattan winds
Terrain: mostly low coastal plain rising to
savanna in east
Natural resources: unexploited deposits of
petroleum, bauxite, phosphates, fish, tim-
ber
Land use: 11% arable land, 1% permanent
crops, 43% meadows and pastures, 38%
forest and woodland, 7% other
Environment: hot, dry, dusty harmattan
haze may reduce visibility during dry sea-
son
Total area: 214,970 km; land area
196,850 km?
Comparative area: slightly smaller than
Idaho
Land boundaries: 2,462 km total, Brazil
1,119 km, Suriname 600 km, Venezuela
743 km
Coastline: 459 km
Maritime claims:
Continental shelf outer edge of conti-
nental margin or 200 nm
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: Essequibo area claimed by Ven-
ezuela; Suriname claims area between
New (Upper Courantyne) and Courantyne/
Kutari Rivers (all headwaters of the Cou-
rantyne)
Climate: tropical, hot, humid, moderated
by northeast trade winds, two rainy sea-
sons (May to mid-August, mid-November
to mid-January)
Terrain: mostly rolling highlands, low
coastal plain, savanna in south
Natural resources: bauxite, gold,
diamonds, hardwood timber, shrimp, fish
Land use: 3% arable land, NEGL% per-
manent crops, 6% meadows and pastures,
83% forest and woodland, 8% other; in-
cludes 1% irrigated
Environment: flash floods a constant threat
during rainy seasons, water pollution','19d2b8431de19af8e62a3c5ed9fdd6061fc92c43c67c53fbbdd72445e72f36df','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('235fd9273e5385181769b64c96ac5d6c0a5211a7e5c20f21ceb9217d3b968fcb',1990,'HT','Haiti','geography',364,'Total area: 27,750 km?; land area 27,560
km?
Comparative area: slightly larger than
Maryland
Land boundary: 275 km with the Domini-
can Republic
Coastline: 1,771 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf to depth of exploita-
tion
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims US-admuinistered Na-
vassa Island
Climate: tropical, semiarid where moun-
tains in east cut off trade winds
Terrain: mostly rough and mountainous
Natural resources: bauxite
Land use: 20% arable land, 13% perma-
nent crops, 18% meadows and pastures,
4% forest and woodland, 45% other, 1n-
cludes 3% irrigated
Environment: lies in the middle of the hur-
ricane belt and subject to severe storms
from June to October, occasional flooding
and earthquakes, deforestation
Note: shares island of Hispaniola with Do-
minican Republic','cc663351baaeee6511f1710394a9c39c7dd4cce95e391c04b6dba7442f837922','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('871536e0aaa18828b3cf41c68aa71db8a185a24b7eceeb5f02894e76850f224d',1990,'HN','Honduras','geography',369,'Total area: 112,090 km?, land area
111,890 km?
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,520 km total, Guate-
mala 256 km, El Salvador 342 km, Nica-
ragua 922 km
Coastline: 820 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: several sections of the boundary
with El Salvador are in dispute
Climate: subtropical in lowlands, temper-
ate in mountains
Terrain: mostly mountains tn interior, nar-
row coastal plains
Natural resources: timber, gold, silver,
copper, lead, zinc, tron ore, antimony,
coal, fish
Land use: 14% arable land, 2% permanent
crops, 30% meadows and pastures, 34%
forest and woodland, 20% other, includes
1% irrigated
Environment: subject to frequent, but gen-
erally mild, earthquakes, damaging hurri-
canes along Caribbean coast, deforesta-
tion, soil erosion','57538db2238c3df1280c5af859f79343b3869a2a32476f37d71a25f000b3c9a5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f580ca498e4c61ac297c1e850f959226cfaecdd7fad97326ba82ce30e5f503',1990,'HK','Hong Kong','geography',375,'Total area: 1,040 km?, land area 990 km?
Comparative area: slightly less than six
times the size of Washington, DC
Land boundary: 30 km with China
Coastline: 733 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 3 nm
Territorial sea 3 nm
Disputes: scheduled to become a Special
Administrative Region of China in 1997
Climate: tropical monsoon, coo! and hu-
mid in winter, hot and rainy from spring
through summer, warm and sunny 1n fall
Terrain: hilly to mountainous with steep
slopes, lowlands 1n north
Natural resources: outstanding deepwater
harbor, feldspar
Land use: 7% arable land, 1% permanent
crops, 1% meadows and pastures, 12%
forest and woodland, 79% other, includes
3% irrigated
Environment: more than 200 tslands, occa-
sional typhoons
Total area: 1 6 km”, land area 1 6 km?
Comparative area: about 2 7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 6 4 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: equatorial, scant rainfall, con-
stant wind, burning sun
Terrain: low-lying, nearly level, sandy,
coral island surrounded by a narrow fring-
ing reef, depressed central area
Natural resources: guano (deposits worked
until late 1800s)
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 5% for-
est and woodland; 95% other
Environment: almost totally covered with
grasses, prostrate vines, and low-growing
shrubs, small area of trees in the center,
lacks fresh water, primartly a nesting,
roosting, and foraging habitat for
seabirds, shorebirds, and marine wildlife,
feral cats
Note: remote location 2,575 km southwest
of Honolulu in the North Pacific Ocean,
just north of the Equator, about halfway
between Hawai and Australia
Total area: 4,066 km7, land area 4,066
km/?, includes Shag and Clerke Rocks
Comparative area: slightly larger than
Rhode Island
Land boundaries: none
Coastline: undetermined
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: administered by the UK,
claimed by Argentina
Climate: variable, with mostly westerly
winds throughout the year, interspersed
with periods of calm, nearly all precipita-
tion falls as snow
Terrain: most of the islands, rising steeply
from the sea, are rugged and mountain-
ous, South Georgia 1s largely barren and
has steep, glacier-covered mountains, the
South Sandwich Islands are of volcanic
origin with some active volcanoes
Natural resources: fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other, largely
covered by permanent ice and snow with
some sparse vegetation consisting of grass,
moss, and lichen
Environment: reindeer, introduced early in
this century, live on South Georgia,
weather conditions generally make 1t diffi-
cult to approach the South Sandwich Is-
lands, the South Sandwich Islands are
subject to active volcanism
Note: the north coast of South Georgia
has several large bays, which provide good
anchorage
Total area: 22,402,200 km?, land area
22,272,000 km?
Comparative area: slightly less than 2 5
times the size of US
Land boundaries: 19,933 km total, Af-
ghanistan 2,384 km, Czechoslovakia 98
km, China 7,520 km, Finland 1,313 km,
Hungary 135 km, Iran 1,690 km, North
Korea 17 km, Mongolia 3,441 km, Nor-
way 196 km, Poland 1,215 km, Romania
1,307 km, Turkey 617 km
Coastline: 42,777 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: bilateral negotiations are under
way to resolve four disputed sections of
the boundary with China (Pamir, Argun,
Amur, and Khabarovsk areas), US Gov-
ernment has not recognized the incorpora-
tion of Estonia, Latvia, and Lithuania intc
the Soviet Union, Habomai Islands, Eto-
rofu, Kunashiri, and Shikotan islands oc-
cupied by Soviet Union since 1945,
claimed by Japan, Kuril Islands adminis-
tered by Soviet Union, maritime dispute
with Norway over portion of Barents Sea,
has made no territorial claim in Antarc-
tica (but has reserved the mght to do so)
and does not recognize the claims of any
other nation, Bessarabia question with
Romania, Kurdish question among Iran,
Iraq, Syria, Turkey, and the USSR
Climate: mostly temperate to arctic conti-
nental, winters vary from cool along Black
Sea to frigid in Siberia, summers vary
from hot in southern deserts to cool along
Arctic coast
Terrain: broad plain with low hills west of
Urals, vast coniferous forest and tundra in
Siberia, deserts in Central Asia, moun-
tains in south
Natural resources: self-sufficient 1n oil,
natural gas, coal, and strategic minerals
(except bauxite, alumina, tantalum, tin,
tungsten, fluorspar, and molybdenum),
timber, gold, manganese, lead, zinc,
nickel, mercury, potash, phosphates
Land use: 10% arable land, NEGL% per-
manent crops, 17% meadows and pastures,
41% forest and woodland, 32% other, in-
cludes 1% irrigated
Environment: despite size and diversity,
small percentage of land 1s arable and
much 1s too far north, some of most fertile
land is water deficient or has insufficient
growing season, many better climates have
poor soils, hot, dry, desiccating sukhovey
wind affects south, desertification, contin-
uous permafrost over much of Siberia 1s a
major impediment to development
Note: largest country in world, but unfa-
vorably located in relation to major sea
lanes of world','01855d8f8daa313a4e41599e12c78e1108cd0e705121a0f9e07d7e67b4d0e670','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6179ea0655ce1d3ff58506e273ac318b4c248473220d89d3584540c75b4e801f',1990,'IS','Iceland','geography',380,'Total area: 103,000 km?, land area
100,250 km?
Comparative area: slightly smaller than
Kentucky
Land boundaries: none
Coastline: 4,988 km
Maritime claims:
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: Rockall continental shelf dispute
involving Denmark, Ireland, and the UK
(Ireland and the UK have signed a bound-
ary agreement in the Rockall area)
Climate: temperate, moderated by North
Atlantic Current, mild, windy winters,
damp, cool summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields, coast deeply
indented by bays and fiords
Natural resources: fish, hydroelectric and
geothermal power, diatomite
Land use: NEGL% arable land, 0% per-
manent crops, 23% meadows and pastures,
1% forest and woodland; 76% other
Environment: subject to earthquakes and
volcanic activity
Note: strategic location between Green-
land and Europe, westernmost European
country','3b6a1b061c54db03b3a13acf37d45943f8d487dcb9b50807ed3c0ff5720c1584','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef59d4157922c46ed1d6bd241d2df020a1b3d3882b119e75d8369d05b3d3f71',1990,'IN','India','geography',385,'Total area: 3,287,590 km?, land area
2,973,190 km?
Comparative area: slightly more than one-
third the size of the US
Land boundaries: 14,103 km total, Bangla-
desh 4,053 km, Bhutan 605 km, Burma
1,463 km, China 3,380, Nepal 1,690 km,
Pakistan 2,912 km
Coastline: 7,000 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: boundaries with Bangladesh,
China, and Pakistan, water sharing prob-
lems with downstream riparians, Bangla-
desh over the Ganges and Pakistan over
the Indus
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the
Ganges, deserts in west, Himalayas in
north
Natural resources: coal (fourth-largest re-
serves in the world), iron ore, manganese,
mica, bauxite, titanium ore, chromite, nat-
ural gas, diamonds, crude oil, limestone
Land use: 55% arable land, 1% permanent
crops, 4% meadows and pastures, 23%
forest and woodland, 17% other, includes
13% irrigated
Environment: droughts, flash floods, severe
thunderstorms common, deforestation, soil
erosion, overgrazing, air and water pollu-
tion, desertification
Note: dominates South Asian subconti-
nent, near important Indian Ocean trade
routes
Approved for Release: 2020/08/12 C06554432','1e8e794bcd202ffb07b13dcbe90957f2371e20b608fd21c5bbe54b6e600532d4','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f59ae07d7b30bcfdb61b516869b5e71462e6c0999bfe41b623647e6d3ab2376',1990,'PK','Pakistan','geography',388,'Total area: 73,600,000 km”, Arabian Sea,
Bass Strait, Bay of Bengal, Java Sea, Per-
sian Gulf, Red Sea, Strait of Malacca,
Timor Sea, and other tributary water bod-
1es
Comparative area: slightly less than eight
times the size of the US, third-largest
ocean (after the Pacific Ocean and Atlan-
tic Ocean, but larger than the Arctic
Ocean)
Coastline: 66,526 km
Climate: northeast monsoon (December to
April), southwest monsoon (June to Octo-
ber), tropical cyclones occur during May/
June and October/November in the north
Indian Ocean and January/February in
the south Indian Ocean
Terrain: surface dominated by counter-
clockwise gyre (broad, circular system of
currents) in the south Indian Ocean,
unique reversal of surface currents in the
north Indian Ocean—low pressure over
southwest Asia from hot, rising, summer
air results in the southwest monsoon and
southwest-to-northeast winds and currents,
while high pressure over northern Asia
from cold, falling, winter air results in the
northeast monsoon and
northeast-to-southwest winds and currents,
ocean floor 1s dominated by the
Mid-Indian Ocean Ridge and subdivided
by the Southeast Indian Ocean Ridge,
Southwest Indian Ocean Ridge, and
Ninety East Ridge, maximum depth 1s
7,258 meters in the Java Trench
Natural resources: 01] and gas fields, fish,
shrimp, sand and gravel aggregates, placer
deposits, polymetallic nodules
Environment: endangered marine species
include the dugong, seals, turtles, and
whales, oil pollution in the Arabian Sea,
Persian Gulf, and Red Sea
Note: major choke points include Bab el
Mandeb, Strait of Hormuz, Strait of Ma-
lacca, southern access to the Suez Canal,
Approved for Release: 2020/08/12 C06554432
and the Lombok Strait, ships subject to
superstructure icing in extreme south near
Antarctica from May to October','7d55f09aa60a57d8c5d955d60f1fede074c2d895e9ae22dac8eacc7cfc4ca173','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fcf45cb67e1c48ba32af36c11178cdc97df5683615f6c3285619d9bcf4fc1c7',1990,'IQ','Iraq','geography',392,'Total area: 434,920 km?, land area
433,970 km?
Comparative area: slightly more than
twice the size of Idaho
Land boundaries: 3,454 km total, Iran
1,458 km, Iraq —Saudi Arabia Neutral
Zone 191 km, Jordan 134 km, Kuwait
240 km, Saudi Arabia 495 km, Syria 605
km, Turkey 331 km
Coastline: 58 km
Maritime claims:
Continental shelf not specific
Territorial sea 12 nm
Disputes: Iraq began formal UN peace
negotiations with Iran in August 1988 to
end the war that began on 22 September
1980—sovereignty over the Shatt al Arab
waterway, troop withdrawal, freedom of
navigation, and prisoner of war exchange
are the major issues for negotiation, Kurd-
ish question among Iran, Iraq, Syria, Tur-
key, and the USSR, shares Neutral Zone
with Saudi Arabia—in July 1975, Iraq
and Saudi Arabia signed an agreement to
divide the zone between them, but the
agreement must be ratified before it be-
comes effective, disputes Kuwaiti owner-
ship of Warbah and Babuyan islands, peri-
odic disputes with upstream riparian Syria
over Euphrates water rights, potential dis-
pute over water development plans by
Turkey for the Tigris and Euphrates Riv-
ers
Climate: desert, mild to cool winters with
dry, hot, cloudless summers
Terrain: mostly broad plains, reedy
marshes in southeast, mountains along
borders with Iran and Turkey
Natural resources: crude oil, natural gas,
phosphates, sulfur
Land use: 12% arable land, 1% permanent
crops, 9% meadows and pastures, 3% for-
est and woodland, 75% other, includes 4%
irrigated
Approved for Release: 2020/08/12 C06554432
Environment: development of
Tigris-Euphrates river systems contingent
upon agreements with upstream riparians
(Syria, Turkey), air and water pollution,
soil degradation (salinization) and erosion,
desertification
Total area: 3,520 km?, land area 3,520
km?
Comparative area: slightly larger than
Rhode Island
Land boundaries: 389 km total, 191 km
Iraq, 198 km Saud: Arabia
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: harsh, dry desert
Terrain: sandy desert
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other (sandy
desert)
Environment: harsh, inhospitable
Note: landlocked, located west of quadn-
point with Iraq, Kuwait, and Saudi Ara-
bia
Total area: 70,280 km?, land area 68,890
km?
Comparative area: slightly larger than
West Virginia
Land boundary: 360 km with UK
Coastline: 1,448 km
Maritime claims:
Continental shelf no precise definition
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary with the
UK, Northern Ireland question with the
UK, Rockall continental shelf dispute in-
volving Denmark, Iceland, and the UK
(Ireland and the UK have signed a bound-
ary agreement in the Rockall area)
Climate: temperate maritime, modified by
North Atlantic Current, mild winters, cool
summers, consistently humid, overcast
about half the time
Terrain: mostly level to rolling interior
plain surrounded by rugged hills and low
mountains, sea cliffs on west coast
Natural resources: zinc, lead, natural gas,
crude oil, barite, copper, gypsum, lime-
stone, dolomite, peat, silver
Land use: 14% arable land, NEGL% per-
manent crops, 71% meadows and pastures,
5% forest and woodland, 10% other
Environment: deforestation
Total area: 20,770 km?, land area 20,330
km?
Comparative area: slightly larger than
New Jersey
Land boundaries: 1,006 km total, Egypt
255 km, Jordan 238 km, Lebanon 79 km,
Syria 76 km, West Bank 307, Gaza Stnp
51 km
Coastline: 273 km
Maritime claims:
Continental shelf to depth of exploita-
tion
Territorial sea 6 nm
Disputes: separated from Lebanon, Syria,
and the West Bank by the 1949 Armistice
Line, differences with Jordan over the lo-
cation of the 1949 Armistice Line which
separates the two countries, West Bank
and Gaza Strip are Israeli occupied with
status to be determined, Golan Heights 1s
Israeli occupied, Israeli troops in southern
Lebanon since June 1982, water-sharing
issues with Jordan
Approved for Release: 2020/08/12 C06554432
Climate: temperate, hot and dry in desert
areas
Terrain: Negev desert in the south, low
coastal plain, central mountains, Jordan
Rift Valley
Natural resources: copper, phosphates,
bromide, potash, clay, sand, sulfur, as-
phalt, manganese, small amounts of natu-
ral gas and crude oil
Land use: 17% arable land, 5% permanent
crops, 40% meadows and pastures, 6%
forest and woodland, 32% other, includes
11% irrigated
Environment: sandstorms may occur dur-
ing spring and summer, limited arable
land and natural water resources pose se-
rious constraints, deforestation,
Note: there are 173 Jewish settlements in
the West Bank, 35 in the Israeli-occupied
Golan Heights, 18 in the Gaza Strip, and
14 Israeli-built Jewish neighborhoods in
East Jerusalem','cd8873ef13bd933161825ed9919e513d7696a772f7f4928f0ff472aa31ae6d86','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21f0cf9efc05eaed2c4399cb9fae46d947adc8cfc1c06a50cefcc3efc9193aaa',1990,'IT','Italy','geography',397,'Total area: 301,230 km?, land area
294,020 km?, includes Sardinia and Sicily
Comparative area: slightly larger than Ar-
1zona
Land boundaries: 1,902 2 km total, Aus-
tria 430 km, France 488 km, San Marino
39 km, Switzerland 740 km, Vatican City
32 km, Yugoslavia 202 km
Coastline: 4,996 km
Maritime claims:
Continental shelf 200 m or to depth of
exploitation
Territorial sea 12 nm
Disputes: South Tyrol question with Aus-
tria
Climate: predominantly Mediterranean;
Alpine in far north, hot, dry in south
Terrain: mostly rugged and mountainous,
some plains, coastal lowlands
Natural resources: mercury, potash, mar-
ble, sulfur, dwindling natural gas and
crude oil reserves, fish, coal
Land use: 32% arable land; 10% perma-
nent crops, 17% meadows and pastures,
22% forest and woodland, 19% other, in-
cludes 10% irrigated
Environment: regional risks include land-
slides, mudflows, snowslides, earthquakes,
volcanic eruptions, flooding, pollution,
land sinkage in Venice
Note: strategic location dominating cen-
tral Mediterranean as well as southern sea
and air approaches to Western Europe
Total area: 322,460 km, land area
318,000 km?
Comparative area: slightly larger than
New Mexico
Land boundaries: 3,110 km total, Burkina
584 km, Ghana 668 km, Guinea 610 km,
Libera 716 km, Mah 532 km
Coastline: 515 km
Maritime claims:
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical along coast, semiarid in
far north, three seasons—warm and dry
(November to March), hot and dry
(March to May), hot and wet (June to Oc-
tober)
Terrain: mostly flat to undulating plains,
mountains in northwest
Natural resources: crude oil, diamonds,
manganese, iron ore, cobalt, bauxite, cop-
per
Land use: 9% arable land, 4% permanent
crops, 9% meadows and pastures, 26%
forest and woodland, 52% other, includes
NEGL% trrigated
Environment: coast has heavy surf and no
natural harbors, severe deforestation','0d8cc28be5d463305489df6a48817008679b7adb9458fb1743fa5daeb9164f55','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7316d85228d364dc0611e7a713ccd765530988750f3d6890b031d894bd579ed1',1990,'JM','Jamaica','geography',402,'Total area: 10,990 km?, land area 10,830
km?
Comparative area: slightly smaller than
Connecticut
Land boundaries: none
Coastline: 1,022 km
Maritime claim:
Territorial sea 12 nm
Climate: tropical, hot, humid, temperate
interior
Terrain: mostly mountains with narrow,
discontinuous coastal plain
Natural resources: bauxite, gypsum, lime-
stone
Land use: 19% arable land, 6% permanent
crops, 18% meadows and pastures, 28%
forest and woodland, 29% other, includes
3% irrigated
Environment: subject to hurricanes (espe-
cially July to November), deforestation,
water pollution
Note: strategic location between Cayman
Trench and Jamaica Channel, the main
sea lanes for Panama Canal
Total area: 373 km?, land area 373 km?
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: none
Coastline: 124 1 km
Maritime claims:
Contiguous zone 10 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm Territo-
rial sea 4nm
Disputes: Denmark has challenged Nor-
way’s maritime claims beween Greenland
and Jan Mayen
Climate: arctic maritime with frequent
storms and persistent fog
Terrain: volcanic island, partly covered by
glaciers, Beerenberg 1s the highest peak,
with an elevation of 2,277 meters
Natural resources: none
Land use: 0% arable land; 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: barren volcanic island with
some moss and grass, volcanic activity
resumed in 1970
Note: located 590 km north-northwest of
Iceland between the Greenland Sea and
the Norwegian Sea north of the Arctic
Circle','720c6393c541a39995b6679ff6c837dc1e610cf56195e7d249b8078f56e3d6aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c9a3f6bc0eb8c4cb133905249dc536fbe52c5ed56d1bfb01bf52dafb530930a',1990,'JP','Japan','geography',407,'Total area: 377,835 km7, land area
374,744 km7?, includes Bonin Islands
(Ogasawara-gunt6), Daité-shot6, Minami-
jima, Okinotori-shima, Ryukyu Islands
(Nansei-shotd), and Volcano Islands
(Kazan-rettd)
Comparative area: slightly smaller than
Califorma
Land boundaries: none
Coastline: 29,751 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm (3 nm in inter-
national straits—La Perouse or Soya,
Tsugaru, Osumi, and Eastern and
Western channels of the Korea or
Tsushima Strait)
Disputes: Habomai Islands, Etorofu, Ku-
nashiri, and Shikotan Islands occupied by
Soviet Union since 1945, claimed by Ja-
pan, Kuril Islands administered by Soviet
Union, Liancourt Rocks disputed with
South Korea, Senkaku-shoté (Senkaku
Islands) claimed by China and Taiwan
Climate: varies from tropical in south to
cool temperate in north
Terrain: mostly rugged and mountainous
Natural resources: negligible mineral re-
sources, fish
Land use: 13% arable land, 1% permanent
crops, 1% meadows and pastures, 67%
forest and woodland, 18% other, includes
9% irrigated
Environment: many dormant and some
active volcanoes, about 1,500 seismic oc-
currences (mostly tremors) every year,
subject to tsunamis
Note: strategic location in northeast Asia
Total area: 4 5 km?; land area 45 km?
Comparative area: about 7 5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 8 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, scant rainfall, constant
wind, burning sun
Terrain: sandy, coral island surrounded by
a narrow fringing reef
Natural resources: guano (deposits worked
until late 1800s)
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: sparse bunch grass, prostrate
vines, and low-growing shrubs, lacks fresh
water, primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds,
and marine wildlife, feral cats
Note: 2,090 km south of Honolulu in the
South Pacific Ocean, just south of the
Equator, about halfway between Hawaii
and the Cook Islands
Total area: 120,540 km/?, land area
120,410 km?
Comparative area: slightly smaller than
Mississippi
Land boundaries: 1,671 km total, China
1,416 km, South Korea 238 km, USSR 17
km
Coastline: 2,495 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Military boundary line 50 nm (all for-
eign vessels and aircraft without per-
mission are banned)
Disputes: short section of boundary with
China 1s indefinite, Demarcation Line
with South Korea
Climate: temperate with rainfall concen-
trated in summer
Terrain: mostly hills and mountains sepa-
rated by deep, narrow valleys, coastal
plains wide in west, discontinuous 1n east
Natural resources: coal, lead, tungsten,
zinc, graphite, magnesite, iron ore, copper,
gold, pyrites, salt, fluorspar, hydropower
Land use: 18% arable land, 1% permanent
crops, NEGL% meadows and pastures,
74% forest and woodland, 7% other, 1n-
cludes 9% irrigated
Environment: mountainous interior 1s 1s0-
lated, nearly inaccessible, and sparsely
populated, late spring droughts often fol-
lowed by severe flooding
Note: strategic location bordering China,
South Korea, and USSR
Total area: 98,480 km, land area 98,190
km?
Comparative area: slightly larger than In-
diana
Land boundary: 238 km with North Korea
Coastline: 2,413 km
Maritime claims:
Territorial sea 12 nm (3 nm in the Ko-
rea Strait)
Disputes: Demarcation Line with North
Korea, Liancourt Rocks claimed by Japan
Climate: temperate, with rainfall heavier
in summer than winter
Terrain: mostly hills and mountains, wide
coastal plains in west and south
Natural resources: coal, tungsten, graph-
ite, molybdenum, lead, hydropower
Land use: 21% arable land; 1% permanent
crops, 1% meadows and pastures, 67%
forest and woodland, 10% other, includes
12% irrigated
Environment: occasional typhoons bring
high winds and floods, earthquakes in
southwest, air pollution in large cities
Notes: strategic location along the Korea
Strait, Sea of Japan, and Yellow Sea','146806287eb153bb75eca3a593cf45755a1e36c07cc396b961c2efff3f92082f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('069be8cc95649da922fc14b717382b02c1c5b113cf52382be6909c15dd435b30',1990,'JE','Jersey','geography',412,'Total area: 117 km?, land area 117 km?
Comparative area: about 0 7 times the size
of Washington, DC
Land boundaries: none
Coastline: 70 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Excluswve fishing zone 200 nm
Territorial sea 3 nm
Climate: temperate, mild winters and cool
summers
Terrain: gently rolling plain with low, rug-
ged hills along north coast
Natural resources: agricultural land
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other,
about 58% of land under cultivation
Environment: about 30% of population
concentrated in Saint Helier
Note: largest and southernmost of Chan-
nel Islands, 27 km from France
Total area: 2 8 km’, land area 28 km?
Comparative area: about 4 7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 10 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, but generally dry, con-
sistent northeast trade winds with little
seasonal temperature variation
Terrain: mostly flat with a maximum ele-
vation of 4 meters
Natural resources: guano (deposits worked
until about 1890)
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland; 100% other
Environment: some low-growing vegetation
Note: strategic location 1,328 km west-
southwest of Honolulu in the North Pa-
cific Ocean, about one-third of the way
between Hawai and the Marshall Islands,
Johnston Island and Sand Island are natu-
ral islands, North Island (Akau) and East
Island (Hikina) are manmade islands
formed from coral dredging, closed to the
public; former nuclear weapons test site','5a25c7880ac4073c1f97ef876fc77ce237f0659b3a9bccaf453c88b3abb1c681','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e386c3ac9eb091d7e1d53bc9919b9fc5845990ece74f7f73f79ab2703564536',1990,'JO','Jordan','geography',417,'Total area: 91,880 km, land area 91,540
km?
Comparative area: slightly smaller than
Indiana
Land boundaries: 1,586 km total, Iraq 134
km, Israel 238 km, Saudi Arabia 742 km,
Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claim:
Territorial sea 3 nm
Disputes: differences with Israel over the
location of the 1949 Armistice Line which
separates the two countries
Climate: mostly arid desert, rainy season
in west (November to April)
Terrain: mostly desert plateau in east,
highland area in west, Great Rift Valley
separates East and West Banks of the Jor-
dan River
Natural resources: phosphates, potash,
shale oil
Land use: 4% arable land, 0 5% perma-
nent crops, 1% meadows and pastures,
0 5% forest and woodland, 94% other, in-
cludes 0 5% irrigated
Approved for Release: 2020/08/12 C06554432
Environment: lack of natural water re-
sources; deforestation, overgrazing, soil
erosion, desertification
Total area: 4 4 km?; land area 44 km?
Comparative area: about 7 5 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 24 1 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: clamed by Madagascar
Climate: tropical
Terrain: undetermined
Natural resources: guano deposits and
other fertilizers
Land use: 0% arable land, 0% permanent
crops; 0% meadows and pastures, 90%
forest and woodland, 10% other
Environment: subject to periodic cyclones,
wildlife sanctuary
Note: located in the central Mozambique
Channel about halfway between Africa
and Madagascar','7fbe17a621a0dce4cd5ffbdb5618fe41cc4bb834133dd4e4e00b1c23b5f449d8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94c6d6b9e875bc30b3084e13033eff2d10e97b75a17478a1fb70f405684a9e8a',1990,'KE','Kenya','geography',422,'Total area: 582,650 km?, land area
569,250 km?
Comparative area: slightly more than
twice the size of Nevada
Land boundaries: 3,477 km total, Ethiopia
861 km, Somaha 682 km, Sudan 232 km,
Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: international boundary and Ad-
ministrative Boundary with Sudan, possi-
ble claim by Somalia based on unification
of ethnic Somalis
Climate: varies from tropical along coast
to arid in interior
Terrain: low plains rise to central high-
lands bisected by Great Rift Valley, fer-
tile plateau in west
Natural resources: gold, limestone, dioto-
mite, salt barytes, magnesite, feldspar,
sapphires, fluorspar, garnets, wildlife
Land use: 3% arable land, 1% permanent
crops, 7% meadows and pastures, 4% for-
est and woodland, 85% other, includes
NEGL®% irrigated
Environment: unique physiography sup-
ports abundant and varied wildlife of sci-
entific and economic value, deforestation,
soil erosion, desertification, glaciers on
Mt Kenya
Note: Kenyan Highlands one of the most
successful agricultural production regions
in Africa
Total area: 1 km?, land area 1 km?
Comparative area: about 1 7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 3 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, but moderated by pre-
vailing winds
Terrain: low and nearly level with a maxi-
mum elevation of about 1 meter
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: barren coral atoll with deep
interior lagoon, wet or awash most of the
time
Note: located 1,600 km south-southwest of
Honolulu in the North Pacific Ocean,
about halfway between Hawau and Amer-
ican Samoa, maximum elevation of about
1 meter makes this a navigational hazard,
closed to the public','312609f8af6cb9ccfd160469d82cae87dc11471f138cef13b47db60b97480819','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e0bbecc02a3f23d1a3910d6f5241e12557f89569514b03a447a2c1de6dbb447',1990,'KI','Kiribati','geography',427,'Total area: 717 km?, land area 717 km/?,
includes three island groups—Gulbert Is-
lands, Line Islands, Phoenix Islands
Comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: none
Coastline: 1,143 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: tropical, marine, hot and humid,
moderated by trade winds
Terrain: mostly low-lying coral atolls sur-
rounded by extensive reefs
Natural resources: phosphate (production
discontinued in 1979)
Land use: NEGL% arable land, 51% per-
manent crops, 0% meadows and pastures,
3% forest and woodland, 46% other
Environment: typhoons can occur any
time, but usually November to March, 20
of the 33 islands are inhabited
Note: Banaba or Ocean Island 1s one of
the three great phosphate rock islands in
the Pacific (the others are Makatea in
French Polynesia and Nauru)','b2f893847edec753078126b1f60c247a7a6d4312a01a01c819071d5c63261d30','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8644c446e47206f353f8a7e01327984f46f27975d97864dfe6c479c6e47ebfdc',1990,'KW','Kuwait','geography',434,'Total area: 17,820 km?, land area 17,820
km?
Comparative area: slightly smaller than
New Jersey
Land boundaries: 462 km total, Iraq 240
km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
Continental shelf not specific
Territorial sea 12 nm
Disputes: ownership of Warbah and
Bibiy4an islands disputed by Iraq, owner-
ship of Qaruh and Umm al Maradim Is-
lands disputed by Saud: Arabia
Climate: dry desert, intensely hot sum-
mers, short, cool winters
Terrain: flat to slightly undulating desert
plain
Natural resources: petroleum, fish, shrimp,
natural gas
Land use: NEGL% arable land, 0% per-
manent crops, 8% meadows and pastures,
NEGL% forest and woodland, 92% other,
includes NEGL% irrigated
Environment: some of world’s largest and
most sophisticated desalination facilities
provide most of water, air and water pol-
lution, desertification
Note: strategic location at head of Persian
Gulf
Total area: 236,800 km?, land area
230,800 km?
Comparative area: slightly larger than
Utah
Land boundaries: 5,083 km total, Burma
235 km, Cambodia 541 km, China 423
km, Thailand 1,754 km, Vietnam 2,130
km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: boundary dispute with Thailand
Climate: tropical monsoon, rainy season
(May to November); dry season
(December to April)
Terrain: mostly rugged mountains, some
plains and plateaus
Natural resources: timber, hydropower,
gypsum, tin, gold, gemstones
Land use: 4% arable land, NEGL% per-
manent crops, 3% meadows and pastures,
58% forest and woodland, 35% other, 1n-
cludes 1% irrigated
Environment: deforestation, soil erosion,
subject to floods
Note: landlocked','9aacf0051dea413ff6a7d0bf11fbafd8ca1da7ec103a16a07c03da7ed0d1d852','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce6bb843d5db58e21e11a653626145f792c84f178972780d68ad13801c16b3fd',1990,'LB','Lebanon','geography',439,'Total area: 10,400 km?, land area 10,230
km?
Comparative area: about 0 8 times the size
of Connecticut
Land boundaries: 454 km total, Israel 79
km, Syria 375 km
Coastline: 225 km
Maritime claim:
Territorial sea 12 nm
Disputes: separated from Israel by the
1949 Armistice Line, Israeli troops in
southern Lebanon since June 1982, Syrian
troops in northern Lebanon since October
1976
Climate: Mediterranean, mild to cool, wet
winters with hot, dry summers
Terrain: narrow coastal plain, Al Biqd‘
separates Lebanon and Anti-Lebanon
Mountains
Natural resources: limestone, iron ore,
salt, water-surplus state in a water-deficit
region
Land use: 21% arable land; 9% permanent
crops, 1% meadows and pastures, 8% for-
est and woodland, 61% other, includes 7%
irrigated
Environment: rugged terrain historically
helped isolate, protect, and develop nu-
merous factional groups based on religion,
clan, ethnicity, deforestation, soil erosion,
air and water pollution, desertification
Note: Nahr al Litani only major river in
Near East not crossing an international
boundary','64b784fc5fa41ef2c3a7dd9f097878d6abc261a6899d786300988b6605f822ff','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21de90ac53411c5d48c79739c0c83405e32fb27918d83d6e170ce4062223faa6',1990,'LS','Lesotho','geography',444,'Total area: 30,350 km?, land area 30,350
km? Comparative area: slightly larger than
Maryland
Land boundary: 909 km with South Africa
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: temperate, cool to cold, dry win-
ters, hot, wet summers
Terrain: mostly highland with some pla-
teaus, hills, and mountains
Natural resources: some diamonds and
other minerals, water, agricultural and
grazing land
Land use: 10% arable land, 0% permanent
crops, 66% meadows and pastures, 0%
forest and woodland, 24% other
Environment: population pressure forcing
settlement in marginal areas results in
overgrazing, severe soil erosion, soil ex-
haustion, desertification
Note: surrounded by South Africa, High-
lands Water Project will control, store,
and redirect water to South Africa','a486ff3fd80b790eb4a6a7e33ddcd42dd16a485f93e8564cb3ec9eedd15fa4e1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b60a70b1596cc9db49ba3d0069632589ff1eaf5f06a69c8fa28421d691322161',1990,'LR','Liberia','geography',449,'Total area: 111,370 km?, land area
96,320 km?
Comparative area: slightly larger than
Tennessee
Land boundaries: 1,585 km total, Guinea
563 km, Ivory Coast 716 km, Sierra
Leone 306 km
Coastline: 579 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 200 nm
Climate: tropical, hot, humid, dry winters
with hot days and cool to cold nights, wet,
cloudy summers with frequent heavy
showers
Terrain: mostly flat to rolling coastal
plains rising to rolling plateau and low
mountains 1n northeast
Natural resources: iron ore, timber, dia-
monds, gold
Land use: 1% arable land, 3% permanent
crops, 2% meadows and pastures, 39%
forest and woodland, 55% other, includes
NEGL% irrigated
Environment: West Africa’s largest tropi-
cal rain forest, subject to deforestation','b0d1e14ff38c9c449160bdcda80fa9b41789ee4b81165114274cf973fb93df97','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aceebd1fecc18969bddeaeda3a50864d8b504ccf6e1923743ad996dc0b472f0',1990,'LY','Libya','geography',454,'Total area: 1,759,540 km?, land area
1,759,540 km?
Comparative area: slightly larger than
Alaska
Land boundaries: 4,383 km total, Algeria
982 km, Chad 1,055 km, Egypt 1,150 km,
Niger 354 km, Sudan 383 km, Tunisia
459 km
Coastline: 1,770 km
Maritime claims:
Territorial sea 12 nm
Gulf of Sidra closing line 32° 30''N
Disputes: claims and occupies a small por-
tion of the Aozou Strip in northern Chad,
maritime boundary dispute with Tunisia,
Libya claims about 19,400 km? in north-
ern Niger, Libya claims about 19,400 km?
in southeastern Algeria
Climate: Mediterranean along coast, dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Natural resources: crude oil, natural gas,
gypsum
Land use: 1% arable land, 0% permanent
crops, 8% meadows and pastures, 0% for-
est and woodland, 91% other, includes
NEGL% irrigated
Environment: hot, dry, dust-laden ghibhi is
a southern wind lasting one to four days
in spring and fall, desertification, sparse
natural surface-water resources
Note: the Great Manmade River Project,
the largest water development scheme in
the world, 1s being built to bring water
from large aquifers under the Sahara to
coastal cities
Climate: temperate in north with mild,
rainy winters and hot, dry summers,
desert in south
Terrain: mountains in north, hot, dry cen-
tral plain, semiarid south merges into the
Sahara
Natural resources: crude oil, phosphates,
iron ore, lead, zinc, salt
Land use: 20% arable land, 10% perma-
nent crops, 19% meadows and pastures,
4% forest and woodland, 47% other, in-
cludes 1% irrigated
Environment: deforestation, overgrazing,
soil erosion, desertification
Note: strategic location in central Medi-
terranean, only 144 km from Italy across
the Strait of Sicily, borders Libya on east
Total area: 780,580 km?, land area
770,760 km?
Comparative area: slightly larger than
Texas
Land boundaries: 2,715 km total, Bulgaria
240 km, Greece 206 km, Iran 499 km,
Iraq 331 km, Syria 822 km, USSR 617
km
Coastline: 7,200 km
Maritime claims:
Extended economic zone in Black Sea
only—to the maritime boundary agreed
upon with the USSR
Territorial sea 6 nm (12 nm in Black
Sea and Mediterranean Sea)
Disputes: complex maritime and air (but
not territorial) disputes with Greece in
Aegean Sea, Cyprus question, Hatay
question with Syria, ongoing dispute with
downstream riparians (Syria and Iraq)
over water development plans for the T1-
gris and Euphrates rivers, Kurdish ques-
tion among Iran, Iraq, Syria, Turkey, and
the USSR
Climate: temperate, hot, dry summers
with mild, wet winters, harsher in interior
Terrain: mostly mountains, narrow coastal
plain, high central plateau (Anatolia)
Natural resources: antimony, coal, chro-
mium, mercury, copper, borate, sulphur,
iron ore
Land use: 30% arable land, 4% permanent
crops, 12% meadows and pastures, 26%
forest and woodland, 28% other, includes
3% irrigated
Environment: subject to severe earth-
quakes, especially along major river val-
leys in west, air pollution, desertification’
Note: strategic location controlling the
Turkish straits (Bosporus, Sea of Mar-
mara, Dardanelles) that link Black and
Aegean Seas, Turkey and Norway only
NATO members having a land boundary
with the USSR
Approved for Release: 2020/08/12 C06554432
“','ceb34cb32df77fafa0ab18eabe932adeb03c20df9fcb45c4763d1c253e3d8756','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ff2e02762a83876a3ef4b32b15ba18ebada85c5be1e9ca86157572e6f08d667',1990,'LI','Liechtenstein','geography',459,'Total area: 160 km?, land area 160 km?
Comparative area: about 0 9 times the size
of Washington, DC
Land boundaries: 78 km total, Austria 37
km, Switzerland 41 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: continental, cold, cloudy winters
with frequent snow or rain; cool to moder-
ately warm, cloudy, humid summers
Terrain: mostly mountainous (Alps) with
Rhine Valley in western third
Natural resources: hydroelectric potential
Land use: 25% arable land, 0% permanent
crops, 38% meadows and pastures, 19%
forest and woodland; 18% other
Environment: variety of microclimatic
variations based on elevation
Note: landlocked','1bfffcec7041bcf08960f7c60945196f9fe4b36c92950d58131b2c4d62414def','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bb990d57570c9e0f4582729ba03f1b434a4d25ff3689cfeace2d0c9eadca5c8',1990,'LU','Luxembourg','geography',463,'Total area: 2,586 km?, land area 2,586
km?
Comparative area: slightly smaller than
Rhode Island
Land boundaries: 359 km total, Belgium
148 km, France 73 km, FRG 138 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: modified continenta! with mild
winters, cool summers
Terrain: mostly gently rolling uplands
with broad, shallow valleys, uplands to
slightly mountainous in the north, steep
slope down to Moselle floodplain in the
southeast
Natural resources: iron ore (no longer ex-
ploited)
Land use: 24% arable land, 1% permanent
crops, 20% meadows and pastures, 21%
forest and woodland, 34% other
Environment: deforestation
Note: landlocked','4e0a0c24c5b70169ee3f6927573be42a98c21180526e088159e00fdf78224c53','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('320db48bbd517ec218d5521fe9209f594ac4fe9f6fccf7d2310d6dab08195d58',1990,'NL','Netherlands','geography',469,'Total area: 16 km’, land area 16 km?
Comparative area: about 0 | times the size
of Washington, DC
Land boundary: 0 34 km with China
Coastline: 40 km
Maritime claims:
Exclusive fishing zone 12 nm
Territorial sea 6 nm
Disputes: scheduled to become a Special
Administrative Region of China in 1999
Climate: subtropical, marine with cool
winters, warm summers
Terrain: generally flat
Natural resources: negligible
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: essentially urban, one cause-
way and one bridge connect the two 1s-
lands to the peninsula on mainland
Note: 27 km west southwest of Hong
Kong on the southeast coast of China
Total area: 37,290 km’, land area 33,940
km?
Comparative area: slightly less than twice
the size of New Jersey
Land boundaries: |,027 km total, Belgium
450 km, FRG 577 km
Coastline: 451 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: temperate, marine, cool summers
and mild winters
Terrain: mostly coastal lowland and re-
claimed land (polders), some hills in south-
east
Natural resources: natural gas, crude oll,
fertile soul
Land use: 25% arable land, 1% permanent
crops, 34% meadows and pastures, 9%
forest and woodland, 31% other, includes
15% irrigated
Environment: 27% of the land area 1s be-
low sea level and protected from the
North Sea by dikes
Note: located at mouths of three major
European rivers (Rhine, Maas or Meuse,
Schelde)
Total area: 960 km?, land area 960 km?,
includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part
of the island of Saint Martin)
Comparative area: slightly less than 5 5
times the size of Washington, DC
Land boundaries: 14 km with Guadeloupe
Coastline: 364 km
Maritime claims:
Excluswe fishing zone 12 nm
Territorial sea 12 nm
Climate: tropical, modified by northeast
trade winds
Terrain: generally hilly, volcanic interiors
Natural resources: phosphates (Curacao
only), salt (Bonaire only)
Land use: 8% arable land; 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 92% other
Environment: Curacao and Bonaire are
south of Cartbbean hurricane belt, so
rarely threatened, Sint Maarten, Saba,
and Sint Eustatius are subject to hurri-
canes from July to October
Note: consists of two island groups-—Cu-
racao and Bonaire are located off the
coast of Venezuela, and Sint Maarten,
Saba, and Sint Eustatius lie 800 km to
the north','4476d5e3e8df9cd2b2700e714d151a6c764e8acd8522ea265f2f54d0d0d60c79','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67e2cdd1d1c6d70c6e17003f1156f0aa96103be06736d24652feb0836a81dd99',1990,'MW','Malawi','geography',476,'Total area: 118,480 km7, land area
94,080 km?
Comparative area: slightly larger than
Pennsylvania
Land boundaries: 2,881 km total, Mozam-
bique 1,569 km, Tanzania 475 km, Zam-
bia 837 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: dispute with Tanzania over the
boundary in Lake Nyasa (Lake Malawi)
Climate: tropical, rainy season (November
to May), dry season (May to November)
Terrain: narrow elongated plateau with
rolling plains, rounded hills, some moun-
tains
Natural resources: limestone, unexploited
deposits of uranium, coal, and bauxite
Land use: 25% arable land, NEGL% per-
manent crops, 20% meadows and pastures,
50% forest and woodland, 5% other, in-
cludes NEGL% irrigated
Environment: deforestation
Note: landlocked','f28c38f911c527cbf40169f1c10b441d4a3447386805e6d2c73d9c6e85314c9b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('868d9520c2219d0a5279010e170fd8bbd6e06aa71910bc4c50f49dac0ed1756e',1990,'MY','Malaysia','geography',480,'Total area: 329,750 km’, land area
328,550 km?
Comparative area: slightly larger than
New Mexico
Land boundaries: 2,669 km total; Bruner
381 km, Indonesia 1,782, Thailand 506
km
Coastline: 4,675 km total (2,068 km Pen-
insular Malaysia, 2,607 km East Malay-
sia)
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation, specified bound-
ary in the South China Sea
Exclusive fishing zone 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: involved in a complex dispute
over the Spratly Islands with China, Phil-
ippines, Taiwan, and Vietnam; state of
Sabah claimed by the Philippines, Brunei
may wish to purchase the Malaysian sa-
lent that divides Brunei into two parts
Climate: tropical, annual southwest (April
to October) and northeast (October to
February) monsoons
Terrain: coastal plains rising to hills and
mountains
Natural resources: tin, crude oil, timber,
copper, iron ore, natural gas, bauxite
Land use: 3% arable land, 10% permanent
crops, NEGL% meadows and pastures,
63% forest and woodland, 24% other, in-
cludes 1% irrigated
Environment: subject to flooding, air and
water pollution
Note: strategic location along Strait of
Malacca and southern South China Sea','2aa48f1a8145ec9321c07d4530243d3af0d1bcc8fd2bb19ccc6e5a2f01a0ac47','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('333dc2ece1d548b961ce3fa9a324fbb7fb8c87b4ab92d5072cd411433c51ba74',1990,'MV','Maldives','geography',482,'Total area: 300 km’, land area 300 km?
Comparative area: slightly more than 1 5
times the size of Washington, DC
Land boundaries: none
Coastline: 644 km
Maritime claims:
Exclusive fishing zone about 100 nm
(defined by geographic coordinates)
Extended economic zone 37-310 nm
(segment of zone coincides with mari-
time boundary with India)
Territorial sea 12 nm
Climate: tropical, hot, humid, dry, north-
east monsoon (November to March),
rainy, southwest monsoon (June to Au-
gust)
Terrain: flat with elevations only as high
as 2 5 meters
Natural resources: fish
Land use: 10% arable land, 0% permanent
crops, 3% meadows and pastures, 3% for-
est and woodland, 84% other
Environment: |,200 coral islands grouped
into 19 atolls
Note: archipelago of strategic location
astride and along major sea lanes in In-
dian Ocean','e0ff716c3f96a42b5466f0ae8b36ec1b1156324c1dbba67dae504a6f084d0884','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e9b9589c7425abd2c461aab040b444b09586d232d3bdbec2a611a383f12357',1990,'ML','Mali','geography',487,'Total area: !,240,000 km?, land area
1,220,000 km?
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 7,243 km total, Algeria
1,376 km, Burkina 1,000 km, Guinea 858
km, Ivory Coast 532 km, Mauritania
2,237 km, Niger 821 km, Senegal 419 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: the disputed international
boundary between Burkina and Mali was
submitted to the International Court of
Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1986,
which both sides agreed to accept, Burk-
ina and Mali are proceeding with bound-
ary demarcation, including the tripoint
with Niger
Climate: subtropical to arid, hot and dry
February to June, rainy, humid, and mild
June to November, cool and dry Novem-
ber to February
Terrain: mostly flat to rolling northern
plains covered by sand, savanna in south,
rugged hills in northeast
Natural resources: gold, phosphates, ka-
olin, salt, hmestone, uranium, bauxite,
iron ore, manganese, tin, and copper de-
posits are known but not exploited
Land use: 2% arable land, NEGL% per-
manent crops, 25% meadows and pastures,
7% forest and woodland, 66% other, in-
cludes NEGL% irrigated
Environment: hot, dust-laden harmattan
haze common during dry seasons, deserti-
fication
Note: landlocked','a668dffc92753d221d5b7676ec04936387b920cec5a0c386af61fa29b10d8524','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3b1fdf826204e956a15fb2ccfb6867d255921efe479dc3cc6406a9aae55baf',1990,'MT','Malta','geography',491,'Total area: 320 km’, land area 320 km?
Comparative area: slightly less than twice
the size of Washington, DC
Land boundaries: none
Coastline: 140 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 25 nm
Territorial sea 12 nm
Climate: Mediterranean with mild, rainy
winters and hot, dry summers
Terrain: mostly low, rocky, flat to
dissected plains, many coastal cliffs
Natural resources: limestone, salt
Land use: 38% arable land, 3% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 59% other, includes 3%
irrigated
Environment: numerous bays provide good
harbors, fresh water very scarce—increas-
ing reliance on desalination
Note: strategic location in central Medi-
terranean, 93 km south of Sicily, 290 km
north of Libya
Total area: 588 km, land area 588 km?
Comparative area: slightly less than 3 5
times the size of Washington, DC
Land boundaries: none
Coastline: 113 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: cool summers and mild winters,
humid, overcast about half the time
Terrain: hills in north and south bisected
by central valley
Natural resources: lead, iron ore
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other,
extensive arable Jand and forests
Environment: strong westerly winds prevail
Note: located in Irish Sea equidistant
from England, Scotland, and Ireland','eb017d1f7a4601a3e37cf3ec3661202ff720a24f2f9fd69fc88be0e681a0429f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7858884f90014610328f832317839d973ad4d7e875eba13e442ef54e4e5ab758',1990,'MH','Marshall Islands','geography',496,'Total area: 181 3 km?, land area 1813
km7?, includes the atolls of Bikini, Eniwe-
tak, and Kwajalein
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 370 4 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims US-administered Wake
Island
Climate: wet season May to November,
hot and humid, islands border typhoon
belt
Terrain: low coral limestone and sand 1s-
lands
Natural resources: phosphate deposits, ma-
rine products, deep seabed minerals
Land use: 0% arable land, 60% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 40% other
Environment: occasionally subject to ty-
phoons, two archipelagic island chains of
30 atolls and 1,152 islands
Note: located 3,825 km southwest of Ho-
nolulu in the North Pacific Ocean, about
two-thirds of the way between Hawa and
Papua New Guinea, Bikini and Eniwetak
are former US nuclear test sites, Kwaja-
lein, the famous World War II battle-
ground, 1s now used as a US missile test
range
Climate: tropical
Terrain: atoll of three coral! islands built
up on an underwater volcano, central la-
goon 1s former crater, islands are part of
the rim, average elevation less than four
meters
Natur4l resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: subject to occasional
typhoons
Note: strategic location 3,700 km west of
Honolulu in the North Pacific Ocean,
about two-thirds of the way between Ha-
wai and the Northern Mariana Islands,
emergency landing location for transpa-
cific flights','6c68b2a136e8efcedcfa510c9ec2cd2f45251d70c394c3afd4f091e08c5b4ff0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3ae9a5311d3e27aa6b8b301ef7b8ff13c6032ccdcb7b650daf29b474b20ffc7',1990,'MQ','Martinique','geography',501,'Total area: 1,100 km?, land area 1,060
km?
Comparative area: slightly more than six
times the size of Washington, DC
Land boundaries: none
Coastline: 290 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by trade
winds, rainy season (June to October)
Terrain: mountainous with indented coast-
line, dormant volcano
Natural resources: coastal scenery and
beaches, cultivable land
Land use: 10% arable land, 8% permanent
crops, 30% meadows and pastures, 26%
forest and woodland, 26% other, includes
5% irrigated
Environment: subject to hurricanes,
flooding, and volcanic activity that result
in an average of one major natural disas-
ter every five years
Note: located 625 km southeast of Puerto
Rico in the Caribbean Sea','f502999b8939cd6c2935fd67325b3ed3b210b7e6cc2ff4a791371e082dd94cd7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a06eddf331e76e190b84987c490ca3a05a404cac77755db37ea3ae4f81d3a73',1990,'MR','Mauritania','geography',506,'Total area: 1,030,700 km”, land area
1,030,400 km?
Comparative area: slightly larger than
three times the size of New Mexico
Land boundaries: 5,074 km total, Algeria
463 km, Mali 2,237 km, Senegal 813 km,
Western Sahara 1,561 km
Coastline: 754 km
Maritime claims:
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: armed conflict 1n Western Sa-
hara, boundary with Senegal
Climate: desert, constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the
Sahara, some central hills
Natural resources: iron ore, gypsum, fish,
copper, phosphate
Land use: 1% arable land, NEGL% per-
manent crops, 38% meadows and pastures,
5% forest and woodland, 56% other, in-
cludes NEGL% irrigated
Environment: hot, dry, dust /sand-laden
sirocco wind blows primarily in March
and April, desertification, only perennial
river 1s the Senegal','1f2584746a9e093fb5ea1d79b0acfdd4bc2af4f1e559eb32463436aa98ce0ca8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc9ab81005ff5c9b45525f2519137808c5830643b53777670b2e7344f7c3e46d',1990,'YT','Mayotte','geography',511,'Total area: 375 km7, land area 375 km?
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: none
Coastline: 185 2 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by Comoros
Climate: tropical, marine, hot, humid,
rainy season during northeastern monsoon
(November to May), dry season 1s cooler
(May to November)
Terrain: generally undulating with ancient
volcanic peaks, deep ravines
Natural resources: negligible
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other
Environment: subject to cyclones during
rainy season
Note: part of Comoro Archipelago, lo-
cated in the Mozambique Channel about
halfway between Africa and Madagascar','95538ed8c15cb92546e80dc7fbadf21a2092bbdf6b89ce58a9b797755c6c81a7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f352e79c4718cef12498de0c134fee9973b9eea65d2294deef5bcd265974aa7d',1990,'MX','Mexico','geography',515,'Total area: 1,972,550 km?, land area
1,923,040 km?
Comparative area: slightly less than three
times the size of Texas
Land boundaries: 4,538 km total, Belize
250 km, Guatemala 962 km, US 3,326
km
Coastline: 9,330 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf natural prolongation
of continental margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: varies from tropical to desert
Terrain: high, rugged mountains, low
coastal plains, high plateaus, and desert
Natural resources: crude oil, silver, copper,
gold, lead, zinc, natural gas, timber
Land use: 12% arable land, 1% permanent
crops, 39% meadows and pastures, 24%
forest and woodland, 24% other; includes
3% irrigated
Environment: subject to tsunamis along
the Pacific coast and destructive earth-
quakes 1n the center and south, natural
water resources scarce and polluted in
north, inaccessible and poor quality in
center and extreme southeast, deforesta-
tion, erosion widespread, desertification,
serious air pollution in Mexico City and
urban centers along US-Mexico border
Note: strategic location on southern bor-
der of US
Total area: 9,372,610 km/7, land area
9,166,600 km7?, includes only the 50 states
and District of Colombia
Comparative area: about four-tenths the
size of USSR, about one-third the size of
Africa, about one-half the size of South
America (or slightly larger than Brazil),
shghtly smaller than China, about two
and one-half times the size of Western
Europe
Land boundaries: 12,248 1 km total, Can-
ada 8,893 km (including 2,477 km with
Alaska), Mexico 3,326 km, Cuba (US na-
val base at Guantanamo) 29 | km
Coastline: 19,924 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf not specified
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary disputes
with Canada, US Naval Base at Guan-
tanamo 1s leased from Cuba and only mu-
tual agreement or US abandonment of the
area can terminate the lease; Haiti claims
Navassa Island, has made no territorial
claim in Antarctica (but has reserved the
right to do so) and does not recognize the
claims of any other nation
Climate: mostly temperate, but varies
from tropical (Hawaii) to arctic (Alaska),
arid to semiarid in west with occasional
warm, dry chinook wind
Terrain: vast central plain, mountains in
west, hills and low mountains 1n east, rug-
ged mountains and broad river valleys in
Alaska, rugged, volcanic topography in
Hawai
Natural resources: coal, copper, lead, mo-
lybdenum, phosphates, uranium, bauxite,
gold, iron, mercury, nickel, potash, silver,
tungsten, zinc, crude oil, natural gas, tim-
ber
324
Approved for Release: 2020/08/12 C06554432
Land use: 20% arable land, NEGL% per-
manent crops, 26% meadows and pastures,
29% forest and woodland, 25% other, in-
cludes 2% irrigated
Environment: pollution control measures
improving air and water quality, acid rain,
agricultural fertilizer and pesticide pollu-
tion, management of sparse natural water
resources 1n west, desertification, tsuna-
mus, volcanoes, and earthquake activity
around Pacific Basin, continuous perma-
frost in northern Alaska 1s a major imped-
iment to development
Note: world’s fourth-largest country (after
USSR, Canada, and China)','ab18a18adc3a996e667ab18acafe18ac9687fd3979720633358e1dc9edb9abf1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35bea11369ca763f4d19ca8991ee96c302551176d1c2e79a8a34bbc29754ea05',1990,'FM','Micronesia, Federated States of','geography',519,'Total area: 702 km7, land area 702 km?;
includes Pohnpei, Truk, Yap, and Kosrae
Comparative area: slightly less than four
times the size of Washington, DC
Land boundaries: none
Coastline: 6,112 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, heavy year-round rain-
fall, especially in the eastern islands, lo-
cated on southern edge of the typhoon belt
with occasional severe damage
Terrain: islands vary geologically from
high mountainous islands to low, coral
atolls, volcanic outcroppings on Pohnpei,
Kosrae, and Truk
Natural resources: forests, marine prod-
ucts, deep-seabed minerals
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other
Environment: subject to typhoons from
June to December, four mayor island
groups totaling 607 islands
Note: located 5,150 km west-southwest of
Honolulu in the North Pacific Ocean,
about three-quarters of the way between
Hawan and Indonesia
Total area: 5 2 km”, land area 5 2 km’,
includes Eastern Island and Sand Island
Comparative area: about nine times the
size of The Mall in Washington, DC
Land boundaries: none
Coastline: 15 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, but moderated by pre-
vailing easterly winds
Terrain: low, nearly level
Natural resources: fish and wildlife
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: coral atoll
Note: located 2,350 km west-northwest of
Honolulu at the western end of Hawanan
Islands group, about one-third of the way
between Honolulu and Tokyo, closed to
the public','5e1223f15687686e5e22139aa001cc25aeff97fc25d9b674b327e96b6430d60f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('089b44bb090f89f4fed4a8162d06ce1b7d9a2c5c7c6c67f7cae0912f687e4a87',1990,'MC','Monaco','geography',524,'Total area’ 1 9 km°, land area 1 9 km?
Comparative area: about three times the
size of The Mall in Washington, DC
Land boundary: 4 4 km with France
Coastline: 41 km
Maritime claim:
Territorial sea 12 nm
Chmate: Mediterranean with mild, wet
winters and hot, dry summers
Terrain: hilly, rugged, rocky
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: almost entirely urban
Note: second-smallest independent state in
world (after Vatican City)','b7f8cbf29c4074a6daa2200b88a6a5bee5831f96116da538246729c8d7f2bd53','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29d80954690e88ed4b878819addeec8af0fa24b3846858426fbb5a3052998f5f',1990,'MS','Montserrat','geography',529,'Total area: 100 km’, land area 100 km?
Comparative area: about 0 6 times the size
of Washington, DC
Land boundaries: none
Coastline: 40 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical, little daily or seasonal
temperature variation
Terrain: volcanic islands, mostly moun-
tainous, with small coastal lowland
Natural resources: negligible
Land use: 20% arable land, 0% permanent
crops, 10% meadows and pastures, 40%
forest and woodland, 30% other
Environment: subject to severe hurricanes
from June to November
Note: located 400 km southeast of Puerto
Rico in the Caribbean Sea','1728da20e5f87bcf9e8dcf197710f67c50fc5f5b896c8bd1f3982145a7fc40fa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9297bfc3a73f780160ac8f4e8b77e8441283a37858f76aee0eb677951d1277e6',1990,'MA','Morocco','geography',534,'Total area: 446,550 km?, land area
446,300 km?
Comparative area: slightly larger than
California
Land boundaries: 2,002 km total, Algeria
1,559 km, Western Sahara 443 km
Coastline: 1,835 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims and administers Western
Sahara, but sovereignty 1s unresolved,
armed conflict in Western Sahara, Spain
controls two coastal presidios or places of
sovereignty (Ceuta, Melilla)
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: mostly mountains with rich
coastal plains
Natural resources: phosphates, tron ore,
manganese, lead, zinc, fish, salt
Land use: 18% arable land, 1% permanent
crops, 28% meadows and pastures, 12%
forest and woodland, 41% other, includes
1% irrigated
Environment: northern mountains geologt-
cally unstable and subject to earthquakes,
desertification
Note: strategic location along Strait of','8c70f5cb92e7a814937a41871673a108b361de194f009ebd3d46292dcf4fc706','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46a7919f58b0c77c12a99b0fa861127db073aacb4563a467e9dbeb396a3b854d',1990,'NA','Namibia','geography',536,'Total area: 824,290 km/?, land area
823,290 km?
Comparative area: slightly more than half
the size of Alaska
Land boundaries: 3,935 km total, Angola
1,376 km, Botswana 1,360 km, South Af-
rica 966 km, Zambia 233 km
Coastline: 1,489 km
Maritime claims:
Exclusive fishing zone 12 nm
Territorial sea 6 nm
Disputes: short section of boundary with
Botswana 1s indefinite, quadripoint with
Botswana, Zambra, and Zimbabwe 1s in
disagreement, possible future claim to
South Africa’s Walvis Bay
Climate: desert, hot, dry, rainfall sparse
and erratic
Terrain: mostly high plateau, Namib
Desert along coast, Kalahari Desert in
east
Natural resources: diamonds, copper, ura-
nium, gold, lead, tin, zinc, salt, vanadium,
natural gas, fish, suspected deposits of
coal and tron ore
Land use: 1% arable land, NEGL% per-
manent crops, 64% meadows and pastures,
22% forest and woodland, 13% other, in-
cludes NEGL% irrigated
Environment: inhospitable with very lim-
ited natural water resources, desertifica-
tion
Note: Walvis Bay area 1s an exclave of
South Africa in Namibia
Total area: 21 km?, land area 21 km?
Comparative area: about 0 | times the size
of Washington, DC
Land boundaries: none
Coastline: 30 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: tropical, monsoonal, rainy season
(November to February)
Terrain: sandy beach rises to fertile ring
around raised coral reefs with phosphate
plateau in center
Natural resources: phosphates
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: only 53 km south of Equator
Note: one of three great phosphate rock
islands in the Pacific (others are Banaba
or Ocean Island in Kiribati and Makatea
in French Polynesia)
Total area: 5 2 km?, land area 5 2 km?
Comparative area: about nine times the
size of The Mall in Washington, DC
Land boundaries: none
Coastline: 8 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by Haiti
Climate: marine, tropical
Terrain: raised coral and limestone pla-
teau, flat to undulating, ringed by vertical
white cliffs (9 to 15 meters high)
Natural resources: guano
Land use: 0% arable land, 0% permanent
crops, 10% meadows and pastures, 0%
forest and woodland, 90% other
Environment: mostly exposed rock, but
enough grassland to support goat herds,
dense stands of fig-like trees, scattered
cactus
Note: strategic location between Cuba,
Haiti, and Jamaica in the Caribbean Sea,
160 km south of the US Naval Base at
Guantanamo, Cuba','ce3c387196964da002bc84bcdbbd1615d609e94917522f23f30d98a3a57e30cf','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86a49b5b147d42b5220a2e44f42515655ca9e558c7da870d14aade85fac6fdda',1990,'NP','Nepal','geography',541,'Total area: 140,800 km”, land area
136,800 km?
Comparative area: slightly larger than Ar-
kansas
Land boundaries: 2,926 km total, China
1,236 km, India 1,690 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: varies from cool summers and
severe winters in north to subtropical sum-
mers and mild winter in south
Terrain: Tarai or flat river plain of the
Ganges in south, central hill region, rug-
ged Himalayas in north
Natural resources: quartz, water, timber,
hydroelectric potential, scenic beauty,
small deposits of lignite, copper, cobalt,
iron ore
Land use: 17% arable land, NEGL% per-
manent crops, 13% meadows and pastures,
33% forest and woodland, 37% other, 1n-
cludes 2% irrigated
Environment: contains eight of world’s 10
highest peaks, deforestation, soil erosion,
water pollution
Note: landlocked, strategic location be-
tween China and India','98f8d6967c29517700943c9fbc9f85601a9cb621771d5c87e4b0c20535b58d18','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e9f099b1d996bc6a4676f5d7db8c38d889824a77920a2210888b3276ecda3b9',1990,'NC','New Caledonia','geography',546,'Total area: 19,060 km?, land area 18,760
km?
Comparative area: slightly smaller than
New Jersey
Land boundaries: none
Coastline: 2,254 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, modified by southeast
trade winds, hot, humid
Terrain: coastal plains with interior moun-
tains
Natural resources: nickel, chrome, tron,
cobalt, manganese, silver, gold, lead, cop-
per
Land use: NEGL% arable land, NEGL%
permanent crops, 14% meadows and pas-
tures, 51% forest and woodland, 35%
other
Environment: typhoons most frequent from
November to March
Note: located 1,750 km east of Australia
in the South Pacific Ocean','633fe62c41fc77d0c9c0160647a3445a245adebb0976af27dc446d26a31c998a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f7143f55bd3def488cba04027a2be9ae3a86d6015e5f6a69cdc766fbdc87816',1990,'NZ','New Zealand','geography',550,'Total area: 268,680 km’, land area
268,670 km?, includes Antipodes Islands,
Auckland Islands, Bounty Islands, Camp-
bell Island, Chatham Islands, and Kerma-
dec Islands
Comparative area: about the size of Colo-
rado
Land boundaries: none
Coastline: 15,134 km
Maritime claims:
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: territorial claim in Antarctica
(Ross Dependency)
Climate: temperate with sharp regional
contrasts
Terrain: predominately mountainous with
some large coastal plains
Natural resources: natural gas, tron ore,
sand, coal, timber, hydropower, gold,
limestone
Land use: 2% arable land, 0% permanent
crops, 53% meadows and pastures, 38%
forest and woodland, 7% other, includes
1% irrigated
Environment: earthquakes are common,
though usually not severe','ff043c033e07b0755940dec517d4ea6b133a9b6b6f9bd35feb7fb3c6c1bcf0fd','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01e23e8a9bda5d2ee056e8fe16d7bce59b7444561b59fbf7d5e89388f86ae233',1990,'NI','Nicaragua','geography',555,'Total area: 129,494 km?, land area
120,254 km?
Comparative area: slightly larger than
New York State
Land boundaries: 1,231 km total, Costa
Rica 309 km, Honduras 922 km
Coastline: 910 km
Maritime claims:
Contiguous zone 25 nm security zone
(status of claim uncertain)
Continental shelf not specified
Territorial sea 200 nm
Disputes: territorial disputes with Colom-
bia over the Archipelago de San Andres y
Providencia and Quita Sueno Bank
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive Atlantic coastal plains
rising to central interior mountains, nar-
row Pacific coastal plain interrupted by
volcanoes
Natural resources: gold, silver, copper,
tungsten, lead, zinc, timber, fish
Land use: 9% arable land, 1% permanent
crops, 43% meadows and pastures, 35%
forest and woodland, 12% other, including
1% irrigated
Environment: subject to destructive earth-
quakes, volcanoes, landslides, and occa-
sional severe hurricanes, deforestation, soil
erosion, water pollution','ebce1e3feeb0e5fdb52026dedd24a8543ad63980ae95ab372f11865553e1bbd2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ed516334b276ba31b58cbf7faee3f731dd019ee6da0e63be792a36d80c6e510',1990,'NE','Niger','geography',560,'Total area: 1,267,000 km?, land area
1,266,700 km?
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 5,697 km total, Algeria
956 km, Benin 266 km, Burkina 628 km,
Chad 1,175 km, Libya 354 km, Mali 821
km, Nigerta 1,497 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: Libya claims about 19,400 km?
in northern Niger, exact locations of the
Chad-Niger-Nigeria and Cameroon-Chad-
Nigeria tripoints in Lake Chad have not
been determined, so the boundary has not
been demarcated and border incidents
have resulted, Burkina and Mali are pro-
ceeding with boundary demarcation, 1n-
cluding the tripoint with Niger
Climate: desert, mostly hot, dry, dusty,
tropical in extreme south
Terrain: predominately desert plains and
sand dunes, flat to rolling plains in south,
hills in north
Natural resources: uranium, coal, iron ore,
tin, phosphates
Land use: 3% arable land, 0% permanent
crops, 7% meadows and pastures, 2% for-
est and woodland, 88% other, includes
NEGL% irrigated
Environment: recurrent drought and deser-
tification severely affecting marginal agri-
cultural activities, overgrazing, soil erosion
Note: landlocked','b7fa22378be9d3eba8ba1e2627b4527806eb9fae3b743d3cab73afdb709265d3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f8cb4fe5c72f2a66127ec6fa1f711680eab189df85cbd807d0a954fd3e38124',1990,'NU','Niue','geography',566,'Total area: 260 km?, land area 260 km?
Comparative area: slightly less than | 5
times the size of Washington, DC
Land boundaries: none
Coastline: 64 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, modified by southeast
trade winds
Terrain: steep limestone cliffs along coast,
central plateau
Natural resources: fish, arable land
Land use: 61% arable land, 4% permanent
crops, 4% meadows and pastures, 19%
forest and woodland, 12% other
Environment: subject to typhoons
Note: one of world’s largest coral islands,
located about 460 km east of Tonga','47911bcd96fea4aaab90397ce935dffd4beb547120a3c779c24d9404d2e97905','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad2a2ccbcb2e86c6c1384efb0456d81b2113c83784da97470c0dbf12ea923af3',1990,'NF','Norfolk Island','geography',571,'Total area: 34 6 km?, land area 34 6 km?
Comparative area: about 0 2 times the size
of Washington, DC
Land boundaries: none
Coastline: 32 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly
rolling plains
Natural resources: fish
Land use: 0% arable land, 0% permanent
crops, 25% meadows and pastures, 0%
forest and woodland, 75% other
Environment: subject to typhoons (espe-
cially May to July)
Note: located 1,575 km east of Austraha
in the South Pacific Ocean','e72dfd44a1df6ed971af56b1ae4b8f3d3f497297ea7e31483eb31155354b4892','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f79ae54a0831d61a297f46dac87d9217f29734456c165a7b27aefbc9211c6538',1990,'MP','Northern Mariana Islands','geography',576,'Total area: 477 km?, land area 477 km?,
includes Saipan, Rota, and Tinian
Comparative area: slightly more than 2 5
times the size of Washington, DC
Land boundaries: none
Coastline: 1,482 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 3 nm
Climate: tropical marine, moderated by
northeast trade winds, little seasonal tem-
perature variation, dry season December
to July, rainy season July to October
Terrain: southern islands are limestone
with level terraces and fringing coral
reefs, northern islands are volcanic, high-
est elevation 1s 471 meters (Mt Tagpochu
on Saipan)
Natural resources: arable land, fish
Land use: 1% arable land, NA% perma-
nent crops, 19% meadows and pastures,
NA% forest and woodland, NA% other
Environment: Mt Pagan 1s an active vol-
cano (last erupted in October 1988), sub-
ject to typhoons during the rainy season
Note: strategic location 5,635 km west-
southwest of Honolulu in the North Pa-
cific Ocean, about three-quarters of the
way between Hawaun and the Philippines','1a27098fcbaa9a396c8c6582025fc4a61b472ed46f7d4fcc6b9a5f1f7c8dfb74','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53469356aa42097d094fb71d074e457c37c466dff90f369c9d2b6a6b0cdcb370',1990,'NO','Norway','geography',581,'Total area: 324,220 km’, land area
307,860 km?
Comparative area: slightly larger than
New Mexico
Land boundaries: 2,582 km total, Finland
729 km, Sweden 1,657, USSR 196 km
Coastline: 21,925 km (3,419 km mainland,
2,413 km large islands, 16,093 km long
fyords, numerous small islands, and minor
indentations)
Maritime claims:
Contiguous zone 10 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 4 nm
Disputes: maritime boundary dispute with
USSR, territorial claim in Antarctica
(Queen Maud Land), Denmark has chal-
lenged Norway’s maritime claims beween
Greenland and Jan Mayen
Climate: temperate along coast, modified
by North Atlantic Current, colder inte-
rlor, rainy year-round on west coast
Terrain: glaciated, mostly high plateaus
and rugged mountains broken by fertile
valleys, small, scattered plains, coastline
deeply indented by fjords, arctic tundra in
north
Natural resources: crude oil, copper, natu-
ral gas, pyrites, nickel, iron ore, zinc, lead,
fish, ttmber, hydropower
Land use: 3% arable land, 0% permanent
crops, NEGL% meadows and pastures,
27% forest and woodland, 70% other, in-
cludes NEGL% irrigated
Environment: air and water pollution, acid
rain
Note: strategic location adjacent to sea
lanes and air routes in North Atlantic,
one of most rugged and longest coastlines
in world, Norway and Turkey only NATO
members having a land boundary with the
USSR
236
Approved for Release: 2020/08/12 C06554432','2fd7f038c94233efec6f4d6f4d0384fe92bd75a3a02dd96a9bf5d194abcf87af','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6fe83ee66f60eb635a2484b89b8170aef83133e67be7080b13dcd6d9b6d7a83',1990,'OM','Oman','geography',586,'Total area: 212,460 km’, land area
212,460 km?
Comparative area: slightly smaller than
Kansas
Land boundaries: 1,374 km total, Saudi
Arabia 676 km, UAE 410 km, PDRY 288
km
Coastline: 2,092 km
Maritime claims:
Continental shelf to be defined
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: Administrative Line with
PDRY, no defined boundary with most of
UAE, Administrative Line in far north
Climate: dry desert, hot, humid along
coast, hot, dry intertor, strong southwest
summer monsoon (May to September) in
far south
Terrain: vast central desert plain, rugged
mountains in north and south
Natural resources: crude oil, copper, as-
bestos, some marble, limestone,
chromium, gypsum, natural! gas
Land use: NEGL% arable land, NEGL%
permanent crops, 5% meadows and pas-
tures, 0% forest and woodland, 95% other,
includes NEGL% irrigated
Environment: summer winds often raise
large sandstorms and duststorms in inte-
rior, sparse natural freshwater resources
Note: strategic location with small foot-
hold on Musandam Peninsula controlling
Strait of Hormuz (17% of world’s oil pro-
duction transits this point going from Per-
sian Gulf to Arabian Sea)
Total area: 458 km: land area 458 km?
Comparative area: slightly more than 2 5
times the size of Washington, DC
Land boundaries: none
Coastline: 1,519 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 3 nm
Climate: wet season May to November,
hot and humid
Terrain: islands vary geologically from the
high mountainous main island of Babel-
thuap to low, coral islands usually fringed
by large barrier reefs
Natural resources: forests, minerals (espe-
cially gold), marine products, deep-seabed
minerals
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other
Environment: subject to typhoons from
June to December, archipelago of six 1s-
land groups totaling over 200 islands in
the Caroline chain
Note: important location 850 km south-
east of the Philippines, includes World
War II battleground of Peleliu and world-
famous rock tslands
Total area: 165,384,000 km?, includes
Arafura Sea, Banda Sea, Bellingshausen
Sea, Bering Sea, Bering Strait, Coral Sea,
East China Sea, Gulf of Alaska, Makas-
sar Strait, Philippine Sea, Ross Sea, Sea
of Japan, Sea of Okhotsk, South China
Sea, Tasman Sea, and other tributary wa-
ter bodies
Comparative area: slightly less than 18
times the size of the US, the largest ocean
(followed by the Atlantic Ocean, Indian
Ocean, and Arctic Ocean), covers about
one-third of the global surface, larger
than the total land area of the world
Coastline: 135,663 km
Climate: the western Pacific 1s
monsoonal—a rainy season occurs during
the summer months, when moisture-laden
winds blow from the ocean over the land,
and a dry season during the winter
months, when dry winds blow from the
Asian land mass back to the ocean
Terrain: surface in the northern Pacific
dominated by a clockwise, warm water
gyre (broad, circular system of currents)
and in the southern Pacific by a counter-
clockwise, cool water gyre, sea ice occurs
in the Bering Sea and Sea of Okhotsk
during winter and reaches maximum
northern extent from Antarctica in Octo-
ber, the ocean floor in the eastern Pacific
1s dominated by the East Pacific Rise,
while the western Pacific 1s dissected by
deep trenches, the world’s greatest depth
1s 10,924 meters in the Marianas Trench
Natural resources: oil and gas fields, poly-
metallic nodules, sand and gravel aggre-
gates, placer deposits, fish
Approved for Release: 2020/08/12 C06554432
Environment: endangered marine species
include the dugong, sea lion, sea otter,
seals, turtles, and whales, oil pollution in
Philippine Sea and South China Sea, dot-
ted with low coral islands and rugged vol-
canic islands in the southwestern Pacific
Ocean, subject to tropical cyclones (ty-
phoons) in southeast and east Asia from
May to December (most frequent from
July to October), tropical cyclones (hurri-
canes) may form south of Mexico and
strike Central America and Mexico from
June to October (most common tn August
and September), southern shipping lanes
subject to icebergs from Antarctica, occa-
sional El Nifio phenomenon occurs off the
coast of Peru when the trade winds
slacken and the warm Equatorial Coun-
tercurrent moves south, which kills the
plankton that is the primary food source
for anchovies, consequently, the anchovies
move to better feeding grounds, causing
resident marine birds to starve by the
thousands because of their lost food
source
Note: the major choke points are the Ber-
ing Strait, Panama Canal, Luzon Strait,
and the Singapore Strait, the Equator di-
vides the Pacific Ocean into the North
Pacific Ocean and the South Pacific
Ocean, ships subject to superstructure ic-
ing in extreme north from October to
May and 1n extreme south from May to
October, persistent fog in the northern
Pacific from June to December 1s a haz-
ard to shipping, surrounded by a zone of
violent volcanic and earthquake activity
sometimes referred to as the Pacific Ring
of Fire
Total area: 803,940 km?, land area
778,720 km?
Comparative area: slightly less than twice
the size of California
Land boundaries: 6,774 km total, Afghani-
stan 2,430 km, China 523 km, India 2,912
km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: boundary with India, Pashtun
question with Afghanistan, Baloch ques-
tion with Afghanistan and Iran, water
sharing problems with upstream riparian
India over the Indus
Climate: mostly hot, dry desert, temperate
in northwest, arctic in north
Terrain: flat Indus plain in east, moun-
taims in north and northwest, Balochistan
plateau in west
Natural resources: land, extensive natural
gas reserves, limited crude oil, poor qual-
ity coal, iron ore, copper, salt, limestone
Land use: 26% arable land, NEGL% per-
manent crops, 6% meadows and pastures,
4% forest and woodland, 64% other, in-
cludes 19% irrigated
Environment: frequent earthquakes, occa-
sionally severe especially in north and
west, flooding along the Indus after heavy
rains (July and August), deforestation, soil
erosion, desertification, water logging
Note: controls Khyber Pass and Malakand
Pass, traditional! invasion routes between
Central Asia and the Indian Subcontinent
Total area: 11 9 km?, land area. 11 9 km?
Comparative area: about 20 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 14.5 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: equatorial, hot, and very rainy
Terrain: low, with maximum elevations of
about 2 meters
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 100%
forest and woodland, 0% other
Environment: about 50 islets covered with
dense vegetation, coconut trees, and balsa-
like trees up to 30 meters tall
Note: located 1,600 km south-southwest of
Honolulu in the North Pacific Ocean, al-
most halfway between Hawau and Amert-
can Samoa','fa1173f85f67b30c769d21cdff5184f23eeb3d47b4553d649dc42bcf3a7ef097','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9ea4d33d6f767c4619df8029f81791a08ae5344e50dff9871a32cd9a1b35ca5',1990,'PA','Panama','geography',591,'Total area: 78,200 km?, land area 75,990
km?
Comparative area: slightly smaller than
South Carolina
Land boundaries: 555 km total, Colombia
225 km, Costa Rica 330 km
Coastline: 2,490 km
Maritime claims:
Territorial sea 200 nm
Climate: tropical, hot, humid, cloudy, pro-
longed rainy season (May to January),
short dry season (January to May)
Terrain: interior mostly steep, rugged
mountains and dissected, upland plains,
coastal areas largely plains and rolling
hills
Natural resources: copper, mahogany for-
ests, shrimp
Land use: 6% arable land, 2% permanent
crops, 15% meadows and pastures, 54%
forest and woodland, 23% other, includes
NEGL% irrigated
Environment: dense tropical forest in east
and northwest
Note: strategic location on eastern end of
isthmus forming land bridge connecting
North and South America, controls Pan-
ama Canal that links North Atlantic
Ocean via Caribbean Sea with North Pa-
cific Ocean','4dac4425f44ccc0cf7ac1ef874cafcd5bd7c69db8d109c13b10a282cbc83a902','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81f66cdaceff5b03e6c39e25e7b61ea42fd7c7cad3bacee7f1c48b8034878b72',1990,'PG','Papua New Guinea','geography',596,'Total area: 461,690 km/?, land area
451,710 km?
Comparative area: slightly larger than
Cahfornia
Land boundary: 820 km with Indonesia
Coastline: 5,152 km
Maritime claims: (measured from claimed
archipelagic baselines)
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 3 nm
Climate: tropical, northwest monsoon (De-
cember to March), southeast monsoon
(May to October), slight seasonal tempera-
ture variation
Terrain: mostly mountains with coastal
lowlands and rolling foothills
Natural resources: gold, copper, stlver,
natural gas, timber, oil potential
Land use: NEGL% arable land, 1% per-
manent crops, NEGL% meadows and pas-
tures; 71% forest and woodland, 28%
other
Environment: one of world’s largest
swamps along southwest coast, some ac-
tive volcanos, frequent earthquakes
Note: shares island of New Guinea with
Total area: undetermined
Comparative area: undetermined
Land boundaries: none
Coastline: 518 km
Maritime claims: undetermined
Disputes: occupied by China, but claimed
by Taiwan and Vietnam
Climate: tropical
Terrain: undetermined
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: subject to typhoons
Note: located 400 km east of Vietnam in
the South China Sea about one-third of
the way between Vietnam and the Philip-
pines','29b6e0f1336a974f06a4febbf2264712aa24414b38df7c3fa740a4c4407777b9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db0105cca26b0cf8173fe29cd07636d03177316ae349001a0c076777839c6da4',1990,'PY','Paraguay','geography',601,'Total area: 406,750 km?, land area
397,300 km?
Comparative area: slightly smaller than
California
Land boundaries: 3,920 km total, Argen-
tina 1,880 km, Bolivia 750 km, Brazil
1,290 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: short section of the boundary
with Brazil (just west of Guaira Falls on
the Rio Paranda) 1s in dispute
Climate: varies from temperate in east to
semiarid in far west
Terrain: grassy plains and wooded hills
east of Rio Paraguay, Gran Chaco region
west of Rio Paraguay mostly low, marshy
plain near the river, and dry forest and
thorny scrub elsewhere
Natural resources: iron ore, manganese,
limestone, hydropower, timber
Land use: 20% arable land, 1% permanent
crops, 39% meadows and pastures, 35%
forest and woodland, 5% other, includes
NEGL% irrigated
Environment: local flooding in southeast
(early September to June), poorly drained
plains may become boggy (early October
to June)
Note: landlocked, buffer between Argen-
tina and Brazil','695d160643205fca98fcc65b8328a55f184a4aa1069fb0960a15ca9b9f588d10','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2be9ecd397d5e155dd9ad257a95d14940894849867d578e3c579091202267eca',1990,'PE','Peru','geography',605,'Total area: 1,285,220 km7, land area
1,280,000 km?
Comparative area: slightly smaller than
Alaska
Land boundaries: 6,940 km total, Bolivia
900 km, Brazil 1,560 km, Chile 160 km,
Colombia 2,900 km, Ecuador 1,420 km
Coastline: 2,414 km
Maritime claims:
Territorial sea 200 nm
Disputes: two sections of the boundary
with Ecuador are in dispute
Climate: varies from tropical in east to dry
desert in west
Terrain: western coastal plain (costa), high
and rugged Andes in center (sierra), east-
ern lowland jungle of Amazon Basin
(selva)
Natural resources: copper, silver, gold, pe-
troleum, timber, fish, 1ron ore, coal, phos-
phate, potash
Land use: 3% arable land, NEGL% per-
manent crops, 21% meadows and pastures,
$5% forest and woodland, 21% other, 1n-
cludes 1% irrigated
Environment: subject to earthquakes, tsu-
namis, landslides, mild volcanic activity,
deforestation, overgrazing, soil erosion,
desertification, air pollution in Lima
Note: shares control of Lago Titicaca,
world’s highest navigable lake, with Bo-
livia','53656de465f001ad8e6c6e9d876afc1082c3fbbbf38bf7aee9bfbe9988dafb73','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21cd638e98ec3ba35f844ffa93f6129046ed3e875b521251dab48bf9f2057d73',1990,'PN','Pitcairn','geography',611,'Total area: 47 km?, land area 47 km?
Comparative area: about 0 3 times the size
of Washington, DC
Land boundaries: none
Coastline: 51 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 3 nm
Climate: tropical, hot, humid, modified by
southeast trade winds, rainy season (No-
vember to March)
Terrain: rugged volcanic formation, rocky
coastline with chiffs
Natural resources: miro trees (used for
handicrafts), fish
Land use: NA% arable land, NA% perma-
nent crops, NA% meadows and pastures,
NA% forest and woodland, NA% other
Environment: subject to typhoons (espe-
cially November to March)
Note: located in the South Pacific Ocean
about halfway between Peru and New
Zealand','74540c61d3cdb829bf8069c4a63927f54cebeca64aa3a535220c44a855c88a87','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b684ea475b94b309b217a61f7d61ae08388ee675507e1d69cfd97a2c209607b',1990,'PL','Poland','geography',616,'Total area: 312,680 km”, land area
304,510 km?
Comparative area: slightly smaller than
New Mexico
Land boundaries: 2,980 km total, Czecho-
slovakia 1,309 km, GDR 456 km, USSR
1,215 km
Coastline: 491 km
Maritime claims:
Territorial sea 12 nm
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation, mild summers with frequent
showers and thundershowers
Terrain: mostly flat plain, mountains along
southern border
Natural resources: coal, sulfur, copper,
natural gas, silver, lead, salt
Land use: 46% arable land, 1% permanent
crops, 13% meadows and pastures, 28%
forest and woodland, 12% other, includes
NEGL% irrigated
Environment: plain crossed by a few north-
flowing, meandering streams, severe air
and water pollution in south
Note: historically, an area of conflict be-
cause of flat terrain and the lack of natu-
ral barriers on the North European Plain','8bf7f22032112cb1057ff0b4cd93f0ef946cd640f442eae4b35ef56165f30e3a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eba2a8c3a353928bd107eb620677ca6323327d7044a7ef608f47c0040c3ffcb',1990,'PT','Portugal','geography',621,'Total area: 92,080 km?, land area 91,640
km?, includes Azores and Madeira Islands
Comparative area: slightly smaller than
Indiana
Land boundary: 1,214 km with Spain
Coastline: 1,793 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: Macau 1s scheduled to become a
Special Administrative Region of China in
1999, East Timor question with Indonesia
Climate: maritime temperate, cool and
rainy in north, warmer and drier in south
Terrain: mountainous north of the Tagus,
rolling plains in south
Natural resources: fish, forests (cork),
tungsten, iron ore, uranium ore, marble
Land use: 32% arable land, 6% permanent
crops, 6% meadows and pastures, 40%
forest and woodland, 16% other, includes
7% irrigated
Environment: Azores subject to severe
earthquakes
Note: Azores and Madeira Islands occupy
strategic locations along western sea ap-
proaches to Strait of Gibraltar','926cfabb60ab252e1c79a91e2fb340281f0e92a662c52d8f848b740726eb3d31','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6beefb805e71a01d5e3a575d84c27dd081d5ed6a08422d777fce46d7e5c32992',1990,'PR','Puerto Rico','geography',626,'Total area: 9,104 km?, land area 8,959
km?
Comparative area: slightly less than three
times the size of Rhode Island
Land boundaries: none
Coastline: 501 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical marine, mild, little sea-
sonal temperature variation
Terrain: mostly mountains with coastal
plain belt in north, mountains precipitous
to sea on west coast
Natural resources: some copper and
nickel, potential for onshore and offshore
crude oil
Land use: 8% arable land, 9% permanent
crops, 51% meadows and pastures, 25%
forest and woodland, 7% other
Environment: many small rivers and high
central mountains ensure land 1s well wa-
tered, south coast relatively dry, fertile
coastal plain belt in north
Note: important location between the Do-
minican Republic and the Virgin Islands
group along the Mona Passage—a key
shipping lane to the Panama Canal, San
Juan 1s one of the biggest and best natural
harbors 1n the Caribbean
Total area: 11,000 km?, land area 11,000
km?
Comparative area: slightly smaller than
Connecticut
Land boundaries: 60 km total, Saudi Ara-
bia 40 km, UAE 20 km
Coastline: 563 km
Maritime claims:
Continental shelf not specific
Exclusive fishing zone as delimited
with neighboring states, or to limit of
shelf, or to median line
Extended economic zone to median
line
Territorial sea 3 nm
Disputes: boundary with UAE 1s 1n dis-
pute, territorial dispute with Bahrain over
the Hawar Islands
Climate: desert, hot, dry, humid and sultry
in summer
Terrain: mostly flat and barren desert cov-
ered with loose sand and gravel
Natural resources: crude oil, natural gas,
fish
Land use: NEGL% arable land, 0% per-
manent crops, 5% meadows and pastures,
0% forest and woodland, 95% other
Environment: haze, duststorms, sandstorms
common, limited freshwater resources
mean increasing dependence on
large-scale desalination facilities
Note: strategic location 1n central Persian
Gulf near major crude orl sources
Total area: 2,510 km’, land area 2,500
km?
Comparative area: slightly smaller than
Rhode Island
Land boundaries: none
Coastline: 201 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, but moderates with ele-
vation, cool and dry from May to Novem-
ber, hot and rainy from November to
April
Terrain: mostly rugged and mountainous,
fertile lowlands along coast
Natural resources: fish, arable land
Land use: 20% arable land, 2% permanent
crops, 4% meadows and pastures, 35%
forest and woodland, 39% other, includes
2% irrigated
Environment: periodic devastating cyclones
Note: located 750 km east of Madagascar
mm the Indian Ocean
Total area: 6 5 km?, land area 6 5 km?
Comparative area: about 11 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 19 3 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 m
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by the Republic of the','77d257e28939611dc73ef6845e719a88534bbb96dfd7144dcef7673af59c7df9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e19892c97a68f10c9524cefc557efffdbb8255945e2b8f250e5a0e7fdf4168',1990,'RW','Rwanda','geography',631,'Total area: 26,340 km?, land area 24,950
km?
Comparative area: slightly smaller than
Maryland
Land boundaries: 893 km total, Burundi
290 km, Tanzania 217 km, Uganda 169
km, Zaire 217 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: temperate, two rainy seasons
(February to April, November to Janu-
ary), mild in mountains with frost and
snow possible
Terrain: mostly grassy uplands and hills,
mountains in west
Natural resources: gold, cassiterite (tin
ore), wolframite (tungsten ore), natural
gas, hydropower
Land use: 29% arable land, 11% perma-
nent crops, 18% meadows and pastures,
10% forest and woodland, 32% other, in-
cludes NEGL% irrigated
Environment: deforestation, overgrazing,
soil exhaustion, soil erosion, periodic
droughts
Note: landlocked
Total area: 410 km?, land area 410 km?,
includes Ascension, Gough Island, Inac-
cessible Island, Nightingale Island, and
Tristan da Cunha
Comparative area: slightly more than 2 3
times the size of Washington, DC
Land boundaries: none
Coastline: 60 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: tropical, marine, mild, tempered
by trade winds
Terrain: rugged, volcanic, small scattered
plateaus and plains
Natural resources: fish, Ascension is a
breeding ground for sea turtles and sooty
terns, no minerals
Land use: 7% arable land, 0% permanent
crops, 7% meadows and pastures, 3% for-
est and woodland, 83% other
Environment: very few perennial streams
Note: Napoleon Bonaparte’s place of exile
and burial, the remains were taken to
Paris in 1840
Total area: 360 km’, land area 360 km?
Comparative area: slightly more than
twice the size of Washington, DC
Land boundaries: none
Coastline: 135 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: subtropical tempered by constant
sea breezes, little seasonal temperature
variation, rainy season (May to Novem-
ber)
Terrain: volcanic with mountainous inter1-
ors
Natural resources: negligible
Land use: 22% arable land, 17% perma-
nent crops, 3% meadows and pastures,
17% forest and woodland, 41% other
Environment: subject to hurricanes (July to
October)
Note: located 320 km southeast of Puerto
Rico
Total area: 620 km7, land area 610 km?
Comparative area: slightly less than 3 5
times the size of Washington, DC
Land boundaries: none
Coastline: 158 km
Maritime claims:
Contiguous zone 24 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by northeast
trade winds, dry season from January to
April, rainy season from May to August
Terrain: volcanic and mountainous with
some broad, fertile valleys
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs, geo-
therma! potential
Land use: 8% arable land, 20% permanent
crops, 5% meadows and pastures, 13%
forest and woodland, 54% other, includes
2% irrigated
Environment: subject to hurricanes and
volcanic activity, deforestation, soil erosion
Note: located 700 km southeast of Puerto
Rico
Total area: 242 km?, land area 242 km?,
includes eight small islands in the St
Pierre and the Miquelon groups
Comparative area: slightly less than 1 5
times the size of Washington, DC
Land boundaries: none
Coastline: 120 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: focus of maritime boundary dis-
pute between Canada and France
Climate: cold and wet, with much mist
and fog, spring and autumn are windy
Terrain: mostly barren rock
Natural resources: fish, deep-water ports
Land use: 13% arable land, 0% permanent
crops, 0% meadows and pastures, 4% for-
est and woodland, 83% other
Environment: vegetation scanty
Note: located 25 km south of Newfound-
land, Canada, in the North Atlantic
Ocean','5c10a5ee5d735f5f05b96226fb2387bcff1e91c7a412319430df7f491f7402bd','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c080df45c0e39835b3ca52111bd37fdc02312ef1c27941260fcbfc87ae75f81',1990,'SM','San Marino','geography',636,'Total area: 60 km, land area 60 km?
Comparative area: about 0 3 times the size
of Washington, DC
Land boundary: 39 km with Italy
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: Mediterranean, mild to cool win-
ters, warm, sunny summers
Terrain: rugged mountains
Natural resources: building stones
Land use: 17% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 83% other
Environment: dominated by the Appenines
Note: landlocked, world’s smallest repub-
lic, enclave of Italy','acf1a79b9cb0d45344c9d758139839cde95b9ffc5762bda2e8d015c01a28b87b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82adb2860d90f2042871984632e42a9d2d8d64ef21bc26fa2c0d406e577b3699',1990,'SA','Saudi Arabia','geography',643,'Total area: 2,149,690 km?, land area
2,149,690 km?
Comparative area: slightly less than one-
fourth the size of US
Land boundaries: 4,410 km total, Iraq 488
km, Iraq-Saudi Arabia Neutral Zone 198
km, Jordan 742 km, Kuwait 222 km,
Oman 676 km, Qatar 40 km, UAE 586
km, PDRY 830 km, YAR 628 km
Coastline: 2,510 km
Maritime claims:
Contiguous zone 18 nm
Continental shelf not specific
Exclusive fishing zone not specific
Territorial sea 12 nm
Disputes: no defined boundaries with
PDRY, UAE, and YAR, shares Neutral
Zone with [raq—in July 1975, Iraq and
Saudi Arabia signed an agreement to di-
vide the zone between them, but the
agreement must be ratified, however, be-
fore 1t becomes effective, Kuwaiti owner-
ship of Qaruh and Umm al Maradim Is-
lands is disputed by Saudi Arabia
Climate: harsh, dry desert with great ex-
tremes of temperature
Terrain: mostly uninhabited, sandy desert
Natural resources: crude oil, natural gas,
iron ore, gold, copper
Land use: 1% arable land, NEGL% per-
manent crops, 39% meadows and pastures,
1% forest and woodland, 59% other, in-
cludes NEGL% irrigated
Environment: no perennial rivers or per-
manent water bodies, developing extensive
coastal seawater desalination facilities,
desertification
Note: extensive coastlines on Persian Gulf
and Red Sea provide great leverage on
shipping (especially crude oil) through Per-
sian Gulf and Suez Canal
273
Approved for Release: 2020/08/12 C06554432
Saudi Arabia (continued)','8882409eb06d3bbea2d5e617296c9f3a850a431e2ec1d4f415dadd052249fdba','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('002d135916a7aa2f880c5b2f8cbfd83c337e9f4debf08cbd56f5fa7bc0f5f591',1990,'SN','Senegal','geography',648,'Total area: 196,190 km7, land area
192,000 km?
Comparative area: slightly smaller than
South Dakota
Land boundaries: 2,640 km total, The
Gambia 740 km, Guinea 330 km, Guinea-
Bissau 338 km, Mali 419 km, Mauritania
813 km
Coastline: 531 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: short section of the boundary
with The Gambia is indefinite, the Inter-
national Court of Justice (ICJ) rendered
its decision on the Guinea-Bissau /Senegal
maritime boundary in favor of Senegal—
that decision has been rejected by Guinea-
Bissau, boundary with Mauritania
Climate: tropical, hot, humid, rainy season
(December to April) has strong southeast
winds, dry season (May to November)
dominated by hot, dry harmattan wind
Terrain: generally low, rolling, plains ris-
ing to foothills in southeast
Natural resources: fish, phosphates, iron
ore
Land use: 27% arable land, 0% permanent
crops, 30% meadows and pastures, 31%
forest and woodland, 12% other, includes
1% irrigated
Environment: lowlands seasonally flooded,
deforestation, overgrazing, soil erosion,
desertification
Note: The Gambia is almost an enclave','a358a851cb1628f10d518dbfea52277b2e21422b34532cd8d4a2b8776c9335c7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3065ecc778dc123a8bb1d04ee4dbd08d008e2c8e44f7a7b73c4467a2d70d0c65',1990,'SC','Seychelles','geography',653,'Total area: 455 km?, land area 455 km?
Comparative area: slightly more than 2 5
tumes the size of Washington, DC
Land boundaries: none
Coastline: 491 km
Maritime claims:
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims Tromelin Island
Climate: tropical marine, humid, cooler
season during southeast monsoon (late
May to September), warmer season during
northwest monsoon (March to May)
Terrain: Mahé Group 1s granitic, narrow
coastal strip, rocky, hilly, others are coral,
flat, elevated reefs
Natural resources: fish, copra, cinnamon
trees
Land use: 4% arable land, 18% permanent
crops, 0% meadows and pastures, 18%
forest and woodland, 60% other
Environment: lies outside the cyclone belt,
50 severe storms are rare, short droughts
possible, no fresh water, catchements col-
lect rain, 40 granitic and about 50 coral-
line islands
Note: located north-northeast of Madaga-
scar in the Indtan Ocean','d4adc90bb7e04306740ae6b21361fe8401b8b4ff9abbf49d05bd67ad9a4ac56b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2aa32feb69f5d8b02ebbb5ea9099d39bf8ee6afa09228f15ae0cdd23f662dc0',1990,'SL','Sierra Leone','geography',658,'Total area: 71,740 km?, land area 71,620
km?
Comparative area: slightly smaller than
South Carolina
Land boundaries: 958 km total, Guinea
652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
Territorial sea 200 nm
Climate: tropical, hot, humid, summer
rainy season (May to December), winter
dry season (December to April)
Terrain: coastal belt of mangrove swamps,
wooded hill country, upland plateau,
mountains in east
Natural resources: diamonds, titanium ore,
bauxite, iron ore, gold, chromite
Land use: 25% arable land, 2% permanent
crops, 31% meadows and pastures, 29%
forest and woodland, 13% other, includes
NEGL% irrigated
Environment: extensive mangrove swamps
hinder access to sea, deforestation, soil
degradation','1b36e842968a2ab3b08e4c1aa58d9824c45c9324cfadf3ccf0f9790019406a99','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62a5493c660db1af0cac42bf151111669197022b4db22a3a05ae2fb105c30409',1990,'SG','Singapore','geography',661,'Total area: 632 6 km?, land area 622 6
km?
Comparative area: slightly less than 3 5
times the size of Washington, DC
Land boundaries: none
Coastline: 193 km
Maritime claims:
Exclusive fishing zone not specific
Territorial sea 3 nm
Climate: tropical, hot, humid, rainy, no
pronounced rainy or dry seasons, thunder-
storms occur on 40% of all days (67% of
days in April)
Terrain: lowland, gently undulating cen-
tral plateau contains water catchment
area and nature preserve
Natural resources: fish, deepwater ports
Land use: 4% arable land, 7% permanent
crops, 0% meadows and pastures, 5% for-
est and woodland, 84% other
Environment: mostly urban and industrial-
ized
Note: focal point for Southeast Asian sea
routes
Total area: 255,800 km, land area
255,400 km?
Comparative area: slightly larger than
Wyoming
Land boundaries: 2,961 km total, Albania
486 km, Austria 311 km, Bulgaria 539
km, Greece 246 km, Hungary 631 km,
Italy 202 km, Romania 546 km
Coastline: 3,935 km (including 2,414 km
offshore islands)
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 12 nm
Disputes: Kosovo question with Albania,
Macedonia question with Bulgaria and','62a753dc1cb186cb0624b4d091a1f995b87ee3b8c0eb63af47dc229dd5cc02aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb07c303ef9f5a27346c26b0f5414b0bbbacd46b80b63c5e6cf8716141487df3',1990,'SB','Solomon Islands','geography',665,'Total area: 28,450 km?, land area 27,540
km?
Comparative area: slightly larger than
Maryland
Land boundaries: none
Coastline: 5,313 km
Maritime claims: (measured from claimed
archipelagic baselines)
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical monsoon, few extremes
of temperature and weather
Terrain: mostly rugged mountains with
some low coral atolls
Natural resources: fish, forests, gold, baux-
ite, phosphates
Land use: 1% arable land, 1% permanent
crops, 1% meadows and pastures, 93%
forest and woodland, 4% other
Environment: subject to typhoons, which
are rarely destructive, geologically active
region with frequent earth tremors
Note: located just east of Papua New
Guinea in the South Pacific Ocean','1d18dda4737a6a984e3c52cc64225ee99a33b68d1741a1df8fce1877059ddc17','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7069738cb549d7d00f5cb919dedbf367454304d0240ea2b388082e691715bd93',1990,'SO','Somalia','geography',670,'Total area: 637,660 km7, land area
627,340 km?
Comparative area: slightly smaller than
Texas
Land boundaries: 2,340 km total, Dyibout:
58 km, Ethiopia 1,600 km, Kenya 682 km
Coastline: 3,025 km
Maritime claims:
Territorial sea 200 nm
Disputes: southern half of boundary with
Ethiopia 1s a Provisional Administrative
Line, territorial dispute with Ethiopia over
the Ogaden, possible claims to Dybouti,
Ethiopia, and Kenya based on unification
of ethnic Somalis
Climate: desert, northeast monsoon (De-
cember to February), cooler southwest
monsoon (May to October), irregular rain-
fall, hot, humid periods (tangambili) be-
tween monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Natural resources: uranium, and largely
unexploited reserves of iron ore, tin, gyp-
sum, bauxite, copper, salt
Land use: 2% arable land, NEGL% per-
manent crops, 46% meadows and pastures,
14% forest and woodland, 38% other, in-
cludes 3% irrigated
Environment: recurring droughts, frequent
dust storms over eastern plains in summer,
deforestation, overgrazing, soil erosion,
desertification
Note: strategic location on Horn of Africa
along southern approaches to Bab el Man-
deb and route through Red Sea and Suez
Canal','d22e3110173b3873bbca50dcda3ca97a2f142dfc6febacdba35e4562dd46b16d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b594d4a0281589ca44ae275b2bca0aca8b2bd85cfa00c85c7f83aad55aca16a1',1990,'ZA','South Africa','geography',674,'Total area: 1,221,040 km?, land area
1,221,040 km?, includes Walvis Bay, Ma-
rion Island, and Prince Edward Island
Comparative area: slightly less than twice
the size of Texas
Land boundaries: 4,973 km total, Bots-
wana 1,840 km, Lesotho 909 km, Mozam-
bique 491 km, Namibia 1,078 km, Swazi-
land 430 km, Zimbabwe 225 km
Coastline: 2,881 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: South Africa administered Na-
mibia until independence was achieved on
21 March 1990, possible future claim to
Walvis Bay by Namibia
Climate: mostly semiarid, subtropical
along coast, sunny days, cool mghts
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
Natural resources: gold, chromium, anti-
mony, coal, iron ore, manganese, nickel,
phosphates, tin, uranium, gem diamonds,
platinum, copper, vanadium, salt, natural
gas
Land use: 10% arable land, 1% permanent
crops, 65% meadows and pastures, 3%
forest and woodland, 21% other, includes
1% irrigated
Environment: lack of important arterial
rivers or lakes requires extensive water
conservation and control measures
Note: Walvis Bay 1s an exclave of South
Africa in Namibia, completely surrounds
Lesotho; almost completely surrounds
Swaziland
284
Approved for Release: 2020/08/12 C06554432','b18fb49adb7b3ba69b03d3ab4b717f104414ab475761cef8a8ae84573ac2fe9c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4a8df5702e4fb506627c8b1962c63c946647c6c992bf777fe1ca9a7dfe15b17',1990,'LK','Sri Lanka','geography',677,'Total area: 65,610 km?, land area 64,740
km?
Comparative area: slightly larger than
West Virginia
Land boundaries: none
Coastline: 1,340 km
Maritime claims:
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, monsoonal, northeast
monsoon (December to March), southwest
monsoon (June to October)
Terrain: mostly low, flat to rolling plain,
mountains in south-central interior
Natural resources: limestone, graphite,
mineral sands, gems, phosphates, clay
Land use: 16% arable land, 17% perma-
nent crops, 7% meadows and pastures,
37% forest and woodland, 23% other, in-
cludes 8% irrigated
Environment: occasional cyclones, torna-
dos, deforestation, soil erosion
Note: only 29 km from India across the
Palk Strait, near major Indian Ocean sea
lanes','98e471fcbff42e9d8592907ff0892addaadee0e982e6a891b8f6a97dcce5eaa9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('468ac37dbc1b3be00442e45a613dd57daf5b18544acb9c53301288b9d428070e',1990,'SD','Sudan','geography',682,'Total area: 2,505,810 km/?, land area
2,376,000 km?
Comparative area: slightly more than one
quarter the size of US
Land boundaries: 7,697 km total, Central
African Republic 1,165 km, Chad 1,360
km, Egypt 1,273 km, Ethiopia 2,221 km,
Kenya 232 km, Libya 383 km, Uganda
435 km, Zaire 628 km
Coastline: 853 km
Maritime claims:
Contiguous zone 18 nm
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 12 nm
Disputes: international boundary and Ad-
ministrative Boundary with Kenya, inter-
national boundary and Administrative
Boundary with Egypt
Climate: tropical in south, arid desert in
north, rainy season (April to October)
Terrain: generally flat, featureless plain,
mountains in east and west
Natural resources: modest reserves of
crude oil, iron ore, copper, chromium ore,
zinc, tungsten, mica, silver, crude oil
Land use: 5% arable land, NEGL% per-
manent crops, 24% meadows and pastures,
20% forest and woodland, 51% other, in-
cludes 1% irrigated
Environment: dominated by the Nile and
its tributaries, dust storms, desertification
Note: largest country in Africa','0c1ac1553892c5af32a95e11b3d4f5e51e8ffb85301deeb7ce381c63657e1ef7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1128f12d5108573ffba4b36855cf43180ca58eab1a96c8fb1f1262b874264bd',1990,'SR','Suriname','geography',687,'Total area: 163,270 km’, land area
161,470 km?
Comparative area: slightly larger than','7cf191d983ec8bdc32cebe5df6815499175d9d3b29f4f0b688c182c47c7c39ae','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b816ecfbe851865c90a294ba6f15332cc783688af5dbb1bf146e5ad1f65b52b',1990,'GE','Georgia','geography',688,'Land boundaries: 1,707 km total, Brazil
597 km, French Guiana 510 km, Guyana
600 km
Coastline: 386 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims area in French Guiana
between Litani Rivier and Riviére Ma-
rouint (both headwaters of the Lawa),
claims area in Guyana between New
(Upper Courantyne) and Courantyne/
Kutari Rivers (all headwaters of the Cou-
rantyne)
Climate: tropical, moderated by trade
winds
Terrain: mostly rolling hills, narrow
coastal plain with swamps
Natural resources: timber, hydropower
potential, fish, shrimp, bauxite, iron ore,
and modest amounts of nickel, copper,
platinum, gold
Land use: NEGL% arable land, NEGL%
permanent crops, NEGL% meadows and
pastures, 97% forest and woodland, 3%
other, includes NEGL% irrigated
Environment: mostly tropical rain forest
Total area: 62,049 km?, land area 62,049
km’, includes Spitsbergen and Bygrneya
(Bear Island)
Comparative area: slightly smaller than
West Virginia
Land boundaries: none
Coastline: 3,587 km
Maritime claims:
Contiguous zone 10 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm un-
laterally claimed by Norway, not recog-
nized by USSR
Territorial sea 4nm
Disputes: focus of maritime boundary dis-
pute between Norway and USSR
Climate: arctic, tempered by warm North
Atlantic Current, cool summers, cold win-
ters, North Atlantic Current flows along
west and north coasts of Spitsbergen,
keeping water open and navigable most of
the year
Terrain: wild, rugged mountains, much of
high land ice covered, west coast clear of
ice about half the year, fjords along west
and north coasts
Natural resources: coal, copper, iron ore,
phosphate, zinc, wildlife, fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other, there are
no trees and the only bushes are crow-
berry and cloudberry
Environment: great calving glaciers de-
scend to the sea
Note: located 445 km north of Norway
where the Arctic Ocean, Barents Sea,
Greenland Sea, and Norwegian Sea meet
Total area: 17,360 km’, land area 17,200
km?
Comparative area: slightly smaller than
New Jersey
Land boundaries: 535 km total, Mozambi-
que 105 km, South Africa 430 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: varies from tropical to near tem-
perate
Terrain: mostly mountains and hills, some
moderately sloping plains
Natural resources: asbestos, coal, clay, tin,
hydroelelectric power, forests, and small
gold and diamond deposits
Land use: 8% arable land, NEGL% per-
manent crops, 67% meadows and pastures,
6% forest and woodland, 19% other, in-
cludes 2% irrigated
Environment: overgrazing, soil degrada-
tion, soil erosion
Note: landlocked, almost completely sur-
rounded by South Africa
Land boundaries: 1,424 km total, Algeria
965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
Territorial sea 12 nm
Disputes: maritime boundary dispute with','82c61a2fc46ea9dcc42020b2c90b8377eee2bfd9304ba067e055465094065478','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b383d22663848bbda1ccc3bd00ed443f80ee0d2946279574ca17724451a6b869',1990,'SE','Sweden','geography',694,'Total area: 449,960 km7, land area
411,620 km?
Comparative area: slightly larger than
California
Land boundaries: 2,193 km total, Finland
536 km, Norway 1,657 km
Coastline: 3,218 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: temperate in south with cold,
cloudy winters and cool, partly cloudy
summers, subarctic in north
Terrain: mostly flat or gently rolling low-
ands, mountains in west
Natural resources: zinc, iron ore, lead,
>opper, silver, timber, uranium, hydro-
power potential
Land use: 7% arable land, 0% permanent
crops, 2% meadows and pastures, 64%
forest and woodland, 27% other, includes
NEGL% irrigated
Environment: water pollution, acid rain
Note: strategic location along Danish
Straits linking Baltic and North Seas','a6e6ca29e9754cb26c33ac118ac353c6df7dbb8bfb8b3fd8f865de1be86bc91e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdece27fc1ea424796b91b4fdcb4af419ca18f542768236b86b6aaf06b592d2f',1990,'CH','Switzerland','geography',699,'Total area: 41,290 km?, land area 39,770
km?
Comparative area: slightly more than
twice the size of New Jersey
Land boundaries: 1,852 km total, Austria
164 km, France 573 km, Italy 740 km,
Liechtenstein 41 km, FRG 334 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: temperate, but varies with alti-
tude, cold, cloudy, rainy/snowy winters,
cool to warm, cloudy, humid summers
with occasional showers
Terrain: mostly mountains (Alps in south,
Jura in northwest) with a central plateau
of rolling hills, plains, and large lakes
Natural resources: hydropower potential,
timber, salt
Land use: 10% arable land, 1% permanent
crops, 40% meadows and pastures, 26%
forest and woodland, 23% other, includes
1% irrigated
Environment: dominated by Alps
Note: landlocked, crossroads of northern
and southern Europe
Total area: 185,180 km/?, land area
184,050 km? (including 1,295 km? of
Israeli-occupied territory)
Comparative area: slightly larger than
North Dakota
Land boundaries: 2,253 km total, Iraq 605
km, Israel 76 km, Jordan 375 km, Leba-
non 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims:
Contiguous zone 6 nm beyond territo-
rial sea limit
Territorial sea 35 nm
Disputes: separated from Israel by the
1949 Armistice Line, Golan Heights 1s
Israeli occupied, Hatay question with Tur-
key, periodic disputes with Iraq over
Euphrates water rights, ongoing dispute
over water development plans by Turkey
for the Tigris and Euphrates Rivers,
Kurdish question among Iran, Iraq, Syria,
Turkey, and the USSR
Climate: mostly desert, hot, dry, sunny
summers (June to August) and mild, rainy
winters (December to February) along
coast
Terrain: primarily semiarid and desert
plateau, narrow coastal plain, mountains
in west
Natural resources: crude oil, phosphates,
chrome and manganese ores, asphalt, iron
ore, rock salt, marble, gypsum
Land use: 28% arable land, 3% permanent
crops, 46% meadows and pastures, 3%
forest and woodland, 20% other, includes
3% irrigated
Environment: deforestation, overgrazing,
soil erosion, desertification
Note: there are 35 Jewish settlements in
the Israeli-occupied Golan Heights
Total area: 945,090 km, land area
886,040 km?
Comparative area: slightly larger than
twice the size of California
Land boundaries: 3,402 km total, Burundi
451 km, Kenya 769 km, Malawi 475 km,
Mozambique 756 km, Rwanda 217 km,
Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claim:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: boundary dispute with Malawi
in Lake Nyasa, Tanzania-Zaire-Zambia
tripoint in Lake Tanganyika may no
longer be indefinite since it 1s reported
that the indefinite section of the Zaire-
Zambia boundary has been settled
Climate: varies from tropical along coast
to temperate in highlands
Terrain: plains along coast, central pla-
teau, highlands in north, south
Natural resources: hydropower potential,
tin, phosphates, iron ore, coal, diamonds,
gemstones, gold, natural gas, nickel
Land use: 5% arable land, 1% permanent
crops, 40% meadows and pastures, 47%
forest and woodland, 7% other, includes
NEGL% irrigated
Environment: jack of water and tsetse fly
limit agriculture, recent droughts affected
marginal agriculture, Kilimanjaro 1s high-
est point in Africa','1bcaafffe998bcec345dc39e51b54fb8b9c48bf2384a0685c296890360536f25','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37ce10c4725a78ba7eae4e88dfc48dec8119b8aceb0d594445e3e2aaf90661b3',1990,'TG','Togo','geography',704,'Total area: 56,790 km?, land area 54,390
km?
Comparative area: slightly smaller than
West Virginia
Land boundaries: 1,647 km total, Benin
644 km, Burkina 126 km, Ghana 877 km
Coastline: 56 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 30 nm
Climate: tropical, hot, humid in south, se-
muiarid in north
Terrain: gently rolling savanna in north,
central hills, southern plateau, low coastal
plain with extensive lagoons and marshes
Natural resources: phosphates, limestone,
marble
Land use: 25% arable land, 1% permanent
crops, 4% meadows and pastures, 28%
forest and woodland, 42% other, includes
NEGL% irrigated
Environment: hot, dry harmattan wind can
reduce visibility in north during winter,
recent droughts affecting agriculture, de-
forestation','d8fc6c72c5c5162231265030752f87faad669ad2efbc9e67d08c24afbb2d835d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('277e76225dc14cb103bdb0d21f1d3bf2ee8a6103fc8eb7ba5e70f6544929afeb',1990,'TK','Tokelau','geography',709,'Total area: 10 km’, land area 10 km?
Comparative area: about 17 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 101 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by trade
winds (April to November)
Terrain: coral atolls enclosing large la-
goons
Natural resources: negligible
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: hes in Pacific typhoon belt
Note: located 3,750 km southwest of Ho-
nolulu in the South Pacific Ocean, about
halfway between Hawan and New Zea-
land','6bfe2b42d1532ab6efa6a5ce83dc1eea4498cd889567dd99fefb492ffd79dc84','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8ce7a7745ae8bdf8ae3fe3a35607690370bb6c621f9ae08d74f8e72405b6288',1990,'TO','Tonga','geography',714,'Total area: 748 km?, land area 718 km?
Comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: none
Coastline: 419 km
Maritime claims:
Continental shelf no specific limits
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, modified by trade winds;
warm season (December to May), cool
season (May to December)
Terrain: most islands have limestone base
formed from uplifted coral formation, oth-
ers have limestone overlying volcanic base
Natural resources: fish, fertile soil
Land use: 25% arable land, 55% perma-
nent crops, 6% meadows and pastures,
12% forest and woodiand, 2% other
Environment: archipelago of 170 islands
(36 inhabited), subject to cyclones (Oc-
tober to April), deforestation
Note: located about 2,250 km north-
northwest of New Zealand, about two-
thirds of the way between Hawani and','5f743feb963a484539a43ec1fb9094bf807799edf0b8b5be9cd369d8ce880ab6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c6364edd3931b92e10b446ada9c6f3a213c74ef81a48947803c1109f7b5771a',1990,'TT','Trinidad and Tobago','geography',716,'Total area: 5,130 km?, land area 5,130
km?
Comparative area: slightly smaller than
Delaware
Land boundaries: none
Coastline: 362 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Exclusive fishing zone 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary with Vene-
zuela in the Gulf of Pana
Climate: tropical, rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
Natural resources: crude oil, natural gas,
asphalt
Land use: 14% arable land, 17% perma-
nent crops, 2% meadows and pastures,
44% forest and woodland, 23% other, 1n-
cludes 4% irrigated
Environment: outside usual path of hurri-
canes and other tropical storms
Note: located 11 km from Venezuela
Total area: | km?, land area 1 km?
Comparative area: about 1 7 times the size
of The Mall in Washington, DC
Land boundaries: none
Coastline: 3 7 km
Maritime claims:
Contiguous zone 12 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claimed by Madagascar, Mauri-
tus, and Seychelles
Climate: tropical
Terrain: sandy
Natural resources: fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other—scattered
bushes
Environment: wildlife sanctuary
Note: located 350 km east of Madagascar
and 600 km north of Reunion in the In-
dian Ocean, climatologically important
location for forecasting cyclones','ba06215f220ad114e7c6150751e857b466e09810c92a121b5385687447d1ed1e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2c3f0723cced9ece69a146fa3907a003ce8a5a32739b3f9fbe6174a404d19cc',1990,'TC','Turks and Caicos Islands','geography',722,'Total area: 430 km’, land area 430 km?
Comparative area: slightly less than 2 5
times the size of Washington, DC
Land boundaries: none
Coastline: 389 km
Maritime claims:
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Climate: tropical, marine, moderated by
trade winds, sunny and relatively dry
Terrain: low, flat limestone, extensive
marshes and mangrove swamps
Natural resources: spiny lobster, conch
Land use: 2% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 98% other
Environment: 30 islands (eight inhabited),
subject to frequent hurricanes
Note: located 190 km north of the Domin-
ican Republic in the North Atlantic
Ocean','2cab8d93980855e6dc2cf07541163c3b1958236ba92adcb7da528a937a2ab0ee','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1685c4eb1c06f3c51f69cbcc3c5576ceb7ca6b8395ca872e7e53f57465d3e720',1990,'TV','Tuvalu','geography',727,'Total area: 26 km?, land area 26 km?
Comparative area: about 0 1 times the size
of Washington, DC
Land boundaries: none
Coastline: 24 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by easterly
trade winds (March to November), west-
erly gales and heavy rain (November to
March)
Terrain: very low-lying and narrow coral
atolls
Natural resources: fish
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: severe tropical storms are
rare
Note: located 3,000 km east of Papua
New Guinea in the South Pacific Ocean
Total area: 236,040 km?, land area
199,710 km?
Comparative area: slightly smaller than
Oregon
Land boundaries: 2,698 km total, Kenya
933 km, Rwanda 169 km, Sudan 435 km,
Tanzania 396 km, Zaire 765 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: tropical, generally rainy with two
dry seasons (December to February, June
to August), semiarid in northeast
Terrain: mostly plateau with rim of moun-
tains
Natural resources: copper, cobalt, lime-
stone, salt
Land use: 23% arable land, 9% permanent
crops, 25% meadows and pastures, 30%
forest and woodland, 13% other, includes
NEGL% irrigated
Environment: straddles Equator, deforesta-
tion, overgrazing, soil erosion
Note: landlocked','c20c55e93207ed97b1506b935c3c3d56ad7d3ec5fbbc2bb71c02d4c1dca203ab','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7232d34bb692d222d2f31259652e456b035f938ee096fab915b9eff231dbec77',1990,'AE','United Arab Emirates','geography',732,'Total area: 83,600 km?, land area 83,600
km?
Comparative area: slightly smaller than
Maine
Land boundaries: |,016 km total, Oman
410 km, Saudi Arabia 586 km, Qatar 20
km
Coastline: 1,448 km
Maritime claims:
Continental shelf defined by bilateral
boundaries or equidistant line
Extended economic zone 200 nm
Territorial sea 3 nm
Disputes: boundary with Qatar 1s in dis-
pute, no defined boundary with Saudi
Arabia, no defined boundary with most of
Oman, but Administrative Line in far
north, claims three islands in the Persian
Gulf occupied by Iran (Jazireh-ye Abi
Misa or Abi Misa, Jazireh-ye Tonb-e
Bozorg or Greater Tunb, and Jazireh-ye
Tonb-e Kichek or Lesser Tunb)
Climate: desert, cooler in eastern moun-
tains
Terrain: flat, barren coastal plain merging
into rolling sand dunes of vast desert
wasteland, mountains in east
Natural resources: crude oil and natural
gas
Land use: NEGL% arable land, NEGL%
permanent crops, 2% meadows and pas-
tures, NEGL% forest and woodland, 98%
other, includes NEGL% irrigated
Environment: frequent dust and sand
storms, lack of natural freshwater
resources being overcome by desalination
plants, desertification
Note: strategic location along southern
approaches to Strait of Hormuz, a vital
transit point for world crude oil','084b09f8dd7330779c98eeacd6ddf53085d6797f1924a098bebc10de6cddc7db','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e84761caa8d565905ca32431418e2ba22ff2184a7668b6ab32ad7735a947e4',1990,'GB','United Kingdom','geography',737,'Total area: 244,820 km’, land area
241,590 km7?, includes Rockall and Shet-
land Islands
Comparative area: shghtly smaller than
Oregon
Land boundary: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation or in accordance
with agreed upon boundaries
Exclusive fishing zone 200 nm
Territorial sea 12 nm
Disputes: maritime boundary with Ireland,
Northern Ireland question with Ireland,
Gibraltar question with Spain; Argentina
claims Falkland Islands (Islas Malvinas),
Argentina claims South Georgia and the
South Sandwich Islands, Mauritius claims
island of Diego Garcia 1n British Indian
Ocean Territory, Hong Kong 1s scheduled
to become a Special Administrative Re-
gion of China in 1997, Rockall continental
shelf dispute involving Denmark, Iceland,
and Ireland (Ireland and the UK have
signed a boundary agreement 1n the Rock-
all area), territorial claim in Antarctica
(British Antarctic Territory)
Climate: temperate; moderated by prevail-
ing southwest winds over the North At-
lantic Current, more than half of the days
are overcast
Terrain: mostly rugged hills and low
mountains, level to rolling plains in east
and southeast
Natural resources: coal, crude oil, natural
gas, tin, limestone, iron ore, salt, clay,
chalk, gypsum, lead, stlica
Land use: 29% arable land, NEGL% per-
manent crops, 48% meadows and pastures,
9% forest and woodland, 14% other, in-
cludes 1% irrigated
Environment: pollution control measures
improving air, water quality, because of
321
United Kingdom (continued)
heavily indented coastline, no location 1s
more than 125 km from tidal waters
Note: lies near vital North Atlantic sea
lanes, only 35 km from France','2b10de369b05c6f77543a062b21871d81c7b9b5f7e17156747553a4eec20a347','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57c872eadf281fc9371b9e95d367254be7316a11120f1128199b1ece3a9d2490',1990,'UY','Uruguay','geography',743,'Total area: 176,220 km7, land area
173,620 km?
Comparative area: slightly smaller than
Washington State
Land boundaries: 1,564 km total, Argen-
tina 579 km, Brazil 985 km
Coastline: 660 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Territorial sea 200 nm (overflight and
navigation permitted beyond 12 nm)
Disputes: short section of boundary with
Argentina 1s in dispute, two short sections
of the boundary with Brazil are in dispute
(Arroyo de la Invernada area of the Rio
Quarai and the islands at the confluence
of the Rio Quarai and the Uruguay)
Climate: warm temperate, freezing tem-
peratures almost unknown
Terrain: mostly rolling plains and low
hills, fertile coastal lowland
Natural resources: soil, hydropower poten-
tial, minor minerals
Land use: 8% arable land, NEGL% per-
manent crops, 78% meadows and pastures,
4% forest and woodland, 10% other, in-
cludes 1% irrigated
Environment: subject to seasonally high
winds, droughts, floods','03edb1dddfde200a7e0bf77dfcffe2ec3b43afeeeb93b011b31db9da0039ce20','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f52e92b7da2a3b584c548ab2a82e926cdaf46d3e6714b0e617e0bdb2a9cbd2d',1990,'VU','Vanuatu','geography',748,'Total area: 14,760 km’, land area 14,760
km?, includes more than 80 islands
Comparative area: slightly larger than
Connecticut
Land boundary: none
Coastline: 2,528 km
Maritime claims: (measured from claimed
archipelagic baselines)
Contiguous zone 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, moderated by southeast
trade winds
Terrain: mostly mountains of volcanic ori-
gin, narrow coastal plains
Natural resources: manganese, hardwood
forests, fish
Land use: !% arable land, 5% permanent
crops, 2% meadows and pastures, 1% for-
est and woodland, 91% other
Environment: subject to tropical cyclones
or typhoons (January to April), volcanism
causes minor earthquakes
Note: located 5,750 km southwest of Ho-
nolulu in the South Pacific Ocean about
three-quarters of the way between Hawau
and Australia
Total area: 0 438 km?, land area 0 438
km?
Comparative area: about 0 7 times the size
of The Mall in Washington, DC
Land boundary: 3 2 km with Italy
Coastline: none—landlocked
Maritime claims: none—landlocked
Climate: temperate, mild, rainy winters
(September to mid-May) with hot, dry
summers (May to September)
Terrain: low hill
Natural resources: none
Land use: 0% arable land, 0% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 100% other
Environment: urban
Note: landlocked, enclave of Rome, Italy,
world’s smallest state, outside the Vatican
City, 13 buildings in Rome and Castel
Gandolfo (the pope’s summer residence)
enjoy extraterritorial rights
Total area: 912,050 km’, land area
882,050 km?
Comparative area: slightly more than
twice the size of California
Land boundaries: 4,993 km total, Brazil
2,200 km, Colombia 2,050 km, Guyana
743 km
Coastline: 2,800 km
Maritime claims:
Contiguous zone 15 nm
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: claims Essequibo area of Gu-
yana, maritime boundary disputes with
Colombia in the Gulf of Venezuela and
with Trinidad and Tobago in the Gulf of
Paria
Climate: tropical, hot, humid, more mod-
erate in highlands
Terrain: Andes mountains and Maracaibo
lowlands in northwest, central plains
(llanos), Guyana highlands in southeast
Natural resources: crude oil, natural gas,
iron ore, gold, bauxite, other minerals,
hydropower, diamonds
Land use: 3% arable land, 1% permanent
crops, 20% meadows and pastures, 39%
forest and woodland, 37% other, includes
NEGL% irrigated
Environment: subject to floods, rockslides,
mudslides, periodic droughts, increasing
industrial pollution in Caracas and Mara-
caibo
Note: on major sea and air routes linking
North and South America','0b4a3322722aaa75fe02e7b998d26fb320b0570c22a94a072b9443d316ed5db1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e3fa8168b9f53129b872706259ee9d21a4a22c82e00ddbd7bce0eec23260ed8',1990,'WF','Wallis and Futuna','geography',754,'Total area: 274 km?, land area 274 km?
Comparative area: slightly larger than
Washington, DC
Land boundaries: none
Coastline: 129 km
Maritime claims:
Continental shelf 200 meters or to
depth of exploitation
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, hot, rainy season (No-
vember to April), cool, dry season (May to
October)
Terrain: volcanic origin, low hills
Natural resources: negligible
Land use: 5% arable land, 20% permanent
crops, 0% meadows and pastures, 0% for-
est and woodland, 75% other
Environment: both island groups have
fringing reefs
Note: located 4,600 km southwest of Ho-
nolulu in the South Pacific Ocean about
two-thirds of the way from Hawaii to','97eafe84709c361f1de0813a36477d06b41b41d44f2e79a96111aac3cee55d74','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca0700cb711d62ae02747ea3761b386922fe1f2cb7c5984bfa4307cd2658b3e9',1990,'EH','Western Sahara','geography',758,'Total area: 266,000 km”, land area
266,000 km?
Comparative area: slightly smaller than
Colorado
Land boundaries: 2,046 km total, Algeria
42 km, Mauritania 1,561 km, Morocco
443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolu-
tion of sovereignty issue
Disputes: claimed and administered by
Morocco, but sovereignty 1s unresolved
and guerrilla fighting continues 1n the
area
Climate: hot, dry desert, rain is rare, cold
offshore currents produce fog and heavy
dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
Natural resources: phosphates, iron ore
Land use: NEGL% arable land, 0% per-
manent crops, 19% meadows and pastures,
0% forest and woodland, 81% other
Environment: hot, dry, dust/sand-laden
sirocco wind can occur during winter and
spring, widespread harmattan haze exists
60% of time, often severely restricting vis-
ibility, sparse water and arable land
Total area: 2,860 km7, land area 2,850
km?
Comparative area: slightly smaller than
Rhode Island
Land boundaries: none
Coastline: 403 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Climate: tropical, rainy season (October to
March), dry season (May to October)
Terrain: narrow coastal plain with volca-
nic, rocky, rugged mountains tn interior
Natural resources: hardwood forests, fish
Land use: 19% arable land, 24% perma-
nent crops, NEGL% meadows and pas-
tures, 47% forest and woodland, 10%
other
Environment: subject to occasional
typhoons, active volcanism
Note: located 4,300 km southwest of Ho-
nolulu in the South Pacific Ocean about
halfway between Hawau and New Zea-
land
Total area: 510,072,000 km?, 361,132,000
km? (70 8%) 1s water and 148,940,000
km? (29 2%) 1s land
Comparative area: land area about 16
times the size of the US
Land boundaries: 442,000 km
Coastline: 359,000 km
Maritime claims:
Contiguous zone generally 24 nm, but
varies from 4 nm to 24 nm
Continental shelf generally 200 nm,
but some are 200 meters in depth
Exclusive fishing zone most are 200
nm, but varies from 12 nm to 200 nm
Extended economic zone 200 nm, only
Madagascar claims 150 nm
Territorial sea generally 12 nm, but
varies from 3 nm to 200 nm
Disputes: 13 international land boundary
disputes—Argentina-Uruguay,
Bangladesh-India, Brazil-Paraguay,
Brazil-Uruguay, Cambodia- Vietnam,
China-India, China-USSR, Ecuador-Peru,
E! Salvador-Honduras, French Guiana-
Suriname, Guyana-Suriname, Guyana-
Venezuela, Qatar-UAE
Climate: two large areas of polar climates
separated by two rather narrow temperate
zones from a wide equatorial band of
tropical to subtropical climates
Terrain: highest elevation 1s Mt Everest
at 8,848 meters and lowest elevation 1s the
Dead Sea at 392 meters below sea level,
greatest ocean depth 1s the Marianas
Trench at 10,924 meters
Natural resources: the oceans represent
the last major frontier for the discovery
and development of natural resources
Land use: 10% arable land, 1% permanent
crops, 24% meadows and pastures, 31%
forest and woodland, 34% other, includes
1 6% irrigated
Environment: large areas subject to severe
weather (tropical cyclones), natural disas-
ters (earthquakes, landslides, tsunamis,
340
Approved for Release: 2020/08/12 C06554432
volcanic eruptions), industrial disasters,
pollution (air, water, acid rain, toxic sub-
stances), loss of vegetation (overgrazing,
deforestation, desertification), loss of wild-
life resources, soil degradation, soil deple-
tion, erosion
Total area: 195,000 km?, land area
195,000 km?
Comparative area: slightly smaller than
South Dakota
Land boundaries: 1,209 km total, Saudi
Arabia 628 km, PDRY 581 km
Coastline: 523 km
Maritime claims:
Contiguous zone 18 nm
Continental shelf 200 meters
Territorial sea 12 nm
Disputes: sections of the boundary with
PDRY are indefinite or undefined, unde-
fined section of boundary with Saudi Ara-
bia
Climate: desert, hot and humid along
coast, temperate in central mountains,
harsh desert in east
Terrain: narrow coastal plain (Tihama),
western mountains, flat dissected plain in
center sloping into desert interior of Ara-
bian Peninsula
Natural resources: crude oil, rock salt,
marble, small deposits of coal, nickel, and
copper, fertile soil
Land use: 14% arable land, NEGL% per-
manent crops, 36% meadows and pastures,
8% forest and woodland, 42% other, in-
cludes 1% irrigated
Environment: subject to sand and dust
storms in summer, overgrazing, soil ero-
sion, desertification
Note: controls northern approaches to Bab
el Mandeb linking Red Sea and Gulf of
Aden, one of world’s most active shipping
lanes
Total area: 332,970 km’, land area
332,970 km?, includes Perim, Socotra
Comparative area: slightly larger than
New Mexico
Land boundaries: 1,699 km total, Oman
288 km, Saudi Arabia 830 km, YAR 581
km
Coastline: 1,383 km
Maritime claims:
Contiguous zoné 24 nm
Continental shelf edge of continental
margin or 200 nm
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: sections of boundary with YAR
indefinite or undefined, Administrative
Line with Oman, no defined boundary
with Saudi Arabia
Climate: desert, extraordinarily hot and
dry
Terrain: mostly upland desert plains, nar-
row, flat, sandy coastal plain backed by
flat-topped hills and rugged mountains
Natural resources: fish, oil, minerals (gold,
copper, lead)
Land use: 1% arable land, NEGL% per-
manent crops, 27% meadows and pastures,
7% forest and woodland, 65% other, 1n-
cludes NEGL% irrigated
Environment: scarcity of natural freshwa-
ter resources, overgrazing, soil erosion,
desertification
Note: controls southern approaches to Bab
el Mandeb linking Red Sea to Gulf of
Aden, one of world’s most active shipping
lanes','cf7142bada707eccd0b9350ba8ee32563f0b752ef5dc992f1ee101632763c12c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72621bd90b636057d2a45c85829cfb4db310b1a5bb1fcf27c5ac60b574243045',1990,'ZM','Zambia','geography',763,'Total area: 752,610 km’, land area
740,720 km?
Comparative area: slightly larger than
Texas
Land boundaries: 5,664 km total, Angola
1,110 km, Malawi 837 km, Mozambique
419 km, Namibia 233 km, Tanzania 338
km, Zaire 1,930 km, Zimbabwe 797 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: quadripoint with Botswana, Na-
mibia, and Zimbabwe 1s in disagreement,
Tanzania-Zaire-Zambuia tripoint in Lake
Tanganyika may no longer be indefinite
since it 1s reported that the indefinite sec-
tion of the Zaire-Zambia boundary has
been settled
Climate: tropical, modified by altitude,
rainy season (October to April)
Terrain: mostly high plateau with some
hills and mountains
Natural resources: copper, cobalt, zinc,
lead, coal, emeralds, gold, silver, uramum,
hydropower potential
Land use: 7% arable land, NEGL% per-
manent crops, 47% meadows and pastures,
27% forest and woodland, 19% other, in-
cludes NEGL% irrigated
Environment: deforestation, soil erosion,
desertification
Note: landlocked','7e726b5e52e301bbdaaba1f8b732f0b9fa16caadadc2117b3b3fb4ba68da813c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4ffa6c9145da67a5c157d6b50953592b0e92d8817c1db8ff62f95b87417a321',1990,'ZW','Zimbabwe','geography',769,'Total area: 390,580 km’, land area
386,670 km?
Comparative area: slightly larger than
Montana
Land boundaries: 3,066 km total, Bots-
wana 813 km, Mozambique 1,231 km,
South Africa 225 km, Zambia 797 km
Coastline: none—landlocked
Maritime claims: none—landlocked
Disputes: quadripoint with Botswana, Na-
mibia, and Zambia 1s in disagreement
Climate: tropical, moderated by altitude,
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld), mountains in
east
Natural resources: coal, chromium ore,
asbestos, gold, nickel, copper, iron ore,
vanadium, lithium, tin
Land use: 7% arable land, NEGL% per-
manent crops, 12% meadows and pastures,
62% forest and woodland, 19% other, in-
cludes NEGL% irrigated
Environment: recurring droughts, floods
and severe storms are rare, deforestation,
soil erosion, air and water pollution, deser-
tification
Note: landlocked
Total area: 35,980 km, land area 32,260
km7?, includes the Pescadores, Matsu, and
Quemoy
Comparative area: slightly less than three
times the size of Connecticut
Land boundaries: none
Coastline: 1,448 km
Maritime claims:
Extended economic zone 200 nm
Territorial sea 12 nm
Disputes: involved in complex dispute over
the Spratly Islands with China, Malaysia,
Philippines, and Vietnam, Paracel Islands
occupied by China, but claimed by Viet-
nam and Taiwan, Japanese-administered
Senkaku-shoté (Senkaku Islands) claimed
by China and Taiwan
Climate: tropical, marine, rainy season
during southwest monsoon (June to
August), cloudiness 1s persistent and ex-
tensive all year
Terrain: eastern two-thirds mostly rugged
mountains, flat to gently rolling plains in
west
Natural resources: small deposits of coal,
natural gas, limestone, marble, and asbes-
tos
Land use: 24% arable land, 1% permanent
crops, 5% meadows and pastures, 55%
forest and woodland, 15% other, 14% irni-
gated
Environment: subject to earthquakes and
typhoons','d85f817edf8d50ff1d67a4ce027a4197a631a57447d4170f9fa698496cc20f64','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

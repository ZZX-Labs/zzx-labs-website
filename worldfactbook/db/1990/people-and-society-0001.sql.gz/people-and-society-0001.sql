SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1ed1af22287cba03a1efba882ce7bb3a967ad90b1ebadf3cc7826a105721e6',1990,'AF','Afghanistan','people-and-society',4,'Population: 15,862,293 (July 1990),
growth rate 7 7% (1990)
Birth rate: 44 births/1,000 population
(1990)
Death rate: 18 deaths/1,000 population
(1990)
Net migration rate: 51 migrants/1,000
population (1990), note—there are flows
across the border in both directions, but
data are fragmentary and unreliable
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 154 deaths/1,000
live births (1990)
Life expectancy at birth: 47 years male,
46 years female (1990)
Total fertility rate: 6 4 children born/
woman (1990)
Nationality: noun—Afghan(s), adjective—
Afghan
Ethnic divisions: 50% Pashtun, 25% Tayik,
9% Uzbek, 12-15% Hazara, minor ethnic
groups include Chahar Aimaks, Turkmen,
Baloch, and others
Religion: 74% Sunni Muslim, 15% Shi‘a
Muslim, 11% other
Language: 50% Pashtu, 35% Afghan Per-
sian (Dari), 11% Turkic languages (prima-
nly Uzbek and Turkmen), 4% thirty mi-
nor languages (primarily Balochi and
Pasha1), much bilingualism
Literacy: 12%
Labor force: 4,980,000, 67 8% agriculture
and animal husbandry, 10 2% industry,
6 3% construction, 5 0% commerce, 10 7%
services and other (1980 est )
Organized labor: some small government-
controlled unions','37af3a2e180d47f6b0901e1f5fcd7ae6488f885b9433b947c4cd6e0df9e70a8b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d31a8e60490c46b5e47c5b9903529c90874f8c1dd7200cd3bca873055ad9e3d5',1990,'AL','Albania','people-and-society',10,'Population: 3,273,131 (July 1990), growth
rate 1 9% (1990)
Birth rate: 25 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 52 deaths/1,000 hve
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 3 0 children born/
woman (1990)
Nationality: noun—Albanian(s), adjec-
tive—Albanian
Ethnic divisions: Albanian 90%, Greeks
8%, other 2% (Vlachs, Gypsies, Serbs, and
Bulgarians) (1989 est )
Religion: Albania claims to be the world’s
first atheist state, all churches and
mosques were closed in 1967 and religious
observances prohibited, pre-1967 estimates
of religious affiliation—70% Muslim, 20%
Albaman Orthodox, 10% Roman Catholic
Language: Albanian (Tosk 1s official dia-
lect), Greek
Literacy: 75%
Labor force: 1,500,000 (1987), about 60%
agriculture, 40% industry and commerce
(1986)
Organized labor: Central Council of Alba-
nian Trade Unions, 610,000 members','b9a755a140cd76097e8b17d3c09f9344562d9e8c3a7613c782ccce4f541adb92','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a29c8956e54508e5ef1cab441bec88506c1ea0d97033b3b634a3238ac29574e',1990,'DZ','Algeria','people-and-society',15,'Population: 25,566,507 (July 1990),
growth rate 2 8% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 87 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 61 years male,
64 years female (1990)
Total fertility rate: 5 4 children born/
woman (1990)
Nationality: noun—Algerian(s),
adyective—Algerian
Ethnic divisions: 99% Arab-Berber, less
than 1% European
Religion: 99% Sunni Muslim (state reli-
gion), 1% Christian and Jewish
Language: Arabic (official), French, Berber
dialects
Literacy: 52%
Labor force: 3,700,000, 40% industry and
commerce, 24% agriculture, 17% govern-
ment, 10% services (1984)
Organized labor: 16-19% of labor force
clarmed, General Union of Algerian
Workers (UGTA) 1s the only labor organi-
zation and 1s subordinate to the National
Liberation Front','80bcbbb645a761916b7c66d8d4c584d8087073ca6c6ffc270ff26da8aed5f79e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('486465889b4765bade3043a59043bf9ba2ccbd2d43b467e7f26805d632ba7b58',1990,'AS','American Samoa','people-and-society',20,'Population: 41,840 (July 1990), growth
rate 2 9% (1990)
Birth rate: 41 births/1,000 population
(1990)
Death rate: 4 deaths/1,000 population
(1990)
Net migration rate: —8 immigrants/ 1,000
population (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 11 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
74 years female (1990)
Total fertility rate: 5 4 children born/
woman (1990)
Nationality: noun—American Samoan(s),
adjective—American Samoan
Ethnic divisions: 90% Samoan (Polyne-
sian), 2% Caucasian, 2% Tongan, 6%
other
Religion: about 50% Christian Congrega-
tionalist, 20% Roman Catholic, 30%
mostly Protestant denominations and
other
Language: Samoan (closely related to Ha-
wanian and other Polynesian languages)
and English, most people are bilingual
Literacy: 99%
Labor force: 10,000, 48% government,
33% tuna canneries, 19% other (1986 est )
Organized labor: NA
Note: about 65,000 American Samoans
live in the States of California and Wash-
ington and 20,000 in Hawau','4c0c302c721e65abc38eeba646be2e44385477af0a57caf86ddfc564a216753e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70bd7d6ef2b8739e21b8bdc052e7a21dd77fb66ccefd42a336252ddfc0242af0',1990,'AD','Andorra','people-and-society',25,'Population: 51,895 (July 1990), growth
rate 2 6% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 4 deaths/1,000 population
(1990)
Net migration rate: 18 migrants/1,000
population (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
81 years female (1990)
Total fertility rate: 1 3 children born/
woman (1990)
Nationality: noun—Andorran(s), adjec-
trve—Andorran
Ethnic divisions: Catalan stock, 61% Span-
ish, 30% Andorran, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan (official), many also
speak some French and Castihan
Literacy: 100%
Labor force: NA
Organized labor: none
Approved for Release: 2020/08/12 C06554432','953b5d51fddeb38c24cb86b26b511f39926a680b0a15d6854461f1548bf0fd5a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1f808af57ed363e9e61dc708927c0aef77748489cda9e03302856082f6b67fa',1990,'AO','Angola','people-and-society',31,'Population: 8,534,483 (July 1990), growth
rate 2 9% (1990)
Birth rate: 47 births/1,000 population
(1990)
Death rate: 20 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 158 deaths/ 1,000
live births (1990)
Life expectancy at birth: 42 years male,
46 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 6 7 children born/
woman (1990)
Nationality: noun—Angolan(s),
adyective—Angolan
Ethnic divisions: 37% Ovimbundu, 25%
Kimbundu, 13% Bakongo, 2% Mestico,
1% European
Religion: 47% indigenous beliefs, 38% Ro-
man Catholic, 15% Protestant (est )
Language: Portuguese (official), various
Bantu dialects
Literacy: 41%
Labor force: 2,783,000 economically ac-
tive, 85% agriculture, 15% industry (1985
est )
Organized labor: about 450,695 (1980)','b90b7ab57bb4e19eaffb9a29db7b73c528314bd3730efff57a4812573afdf28d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87472c0766067270194c70967025adc0d8faa2b7356b451c2cf0dad980430d7c',1990,'AI','Anguilla','people-and-society',37,'Population: 6,883 (July 1990), growth rate
0 6% (1990)
Birth rate: 24 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: — 10 migrants/1,000
population (1990)
Infant mortality rate: 18 deaths/1,000 live
births (1990)
Life expectancy at birth: 71 years male,
76 years female (1990)
Total fertility rate: 3 1 children born/
woman (1990)
Nationality: noun—Anguillan(s), adyec-
tive—Anguillan
Ethnic divisions: mainly of black African
descent
10
Approved for Release: 2020/08/12 C06554432
Religion: Anglican, Methodist, and Ro-
man Catholic
Language: English (official)
Literacy: 80%
Labor force: 2,780 (1984)
Organized labor: NA','477b531452e609f6deb3c3c845d8907a23af59ad635b5e06bd631d33f7b4cdec','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4385fd9adacc04c3ddf54d651c6c3e7ca0a66bf70886fa11f2b7dd20bb0be92f',1990,'AQ','Antarctica','people-and-society',42,'Population: no indigenous inhabitants,
staffing of research stations varies season-
ally
Summer (January) population—3,330, Ar-
gentina 179, Australia 216, Brazil 36,
Chile 124, China 62, France 46, FRG 9,
GDR 15, India 59, Italy 121, Japan 52,
NZ 251, Poland 19, South Africa 102,
South Korea 17, UK 72, Uruguay 47, US
1,250, USSR 653 (1986-87)
Winter (July) population—1,148 total; Ar-
gentina 149, Australia 82, Brazil 11,
Chile 59, China 16, France 32, FRG 9,
GDR 9, India 17, Japan 37, NZ 11, Po-
land 19, South Africa 15, UK 61, Uru-
guay 10, US 242, USSR 369 (1986-87)
Year-round stations—43 total, Argentina
7, Australia 3, Brazil 1, Chile 3, China 1,
France 1, FRG 1, GDR 1, India 1, Japan
2, NZ 1, Poland 1, South Africa 1, South
Korea 1, UK 6, Uruguay 1, US 3, USSR
8 (1986-87)
Summer only stations—26 total, Argen-
tina 3, Australia 3, Chile 4, Italy 1, Japan
1, NZ 2, South Africa 2, US 4, USSR 6
(1986-87)','08f468ea88e088b84cb16c15f8de61032194cb6410f8f54f199afffc046843d1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('850787ccade79b536db7af2fc850278ab9f6c1c2d5388f672cc10efc9563fd3a',1990,'AG','Antigua and Barbuda','people-and-society',47,'Population: 63,726 (July 1990), growth
rate 0 3% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: — 10 migrants/1,000
population (1990)
Infant mortality rate: 23 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
74 years female (1990)
Total fertility rate: 1 7 children born/
woman (1990)
Nationality: noun—Antiguan(s), adjec-
tive—Antiguan
Ethnic divisions: almost entirely of black
African origin, some of British, Portu-
guese, Lebanese, and Syrian origin
Religion: Anglican (predominant), other
Protestant sects, some Roman Catholic
Language: English (official), local dialects
Literacy: 90% (est )
Labor force: 30,000, 82% commerce and
services, 11% agriculture, 7% industry
(1983)
Organized labor: Antigua and Barbuda
Public Service Association (ABPSA),
membership 500, Antigua Trades and La-
bor Union (ATLU), 10,000 members,
Antigua Workers Union (AWU), 10,000
members (1986 est )','32dc7bd89e6ed5afd768290ed6a82feee51e8acca94ae7789844781650234dcb','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c97448ce9b50cba0d9c541381b743f3971708dc425f7041fe0517167133dbb5d',1990,'AR','Argentina','people-and-society',52,'Population: 32,290,966 (July 1990),
growth rate | 2% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 32 deaths/1,000 live
births (1990)
Life expectancy at birth: 67 years male,
74 years female (1990)
Total fertility rate: 2 8 children born/
woman (1990)
Nationality: noun—Argentine(s), adjec-
tive—Argentine
Ethnic divisions: 85% white, 15% mestizo,
Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic
(less than 20% practicing), 2% Protestant,
2% Jewish, 6% other
Language: Spanish (official), English, Ital-
ian, German, French
Literacy: 94%
Labor force: 10,900,000, 12% agriculture,
31% industry, 57% services (1985 est )
Organized labor: 3,000,000; 28% of labor
force','24ab43c9b23164e4e26bb4661d84a4a245ac05099fa3e5492ed33dc3bc6f2c2e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9172fc50b36e9d7447dae85d4893d6525be979f6dfdb38aca3a0ed9406cd1089',1990,'AW','Aruba','people-and-society',57,'Population: 62,656 (July 1990), growth
rate 0 2% (1990)
Birth rate: 16 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: —8 migrants/ 1,000
population (1990)
Infant mortality rate: 8 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
80 years female (1990)
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Aruban(s), adjective—
Aruban
Ethnic divisions: 80% mixed European/
Caribbean Indian
Religion: 82% Roman Catholic, 8% Prot-
estant, also small Hindu, Muslim, Confu-
cian, and Jewish minority
16
Approved for Release: 2020/08/12 C06554432
Language: Dutch (official), Papiamento (a
Spanish, Portuguese, Dutch, English dia-
lect), English (widely spoken), Spanish
Literacy: 95%
Labor force: NA, but most employment is
in the tourist industry (1986)
Organized labor: Aruban Workers’ Feder-
ation (FTA)
Population: no permanent inhabitants,
seasonal caretakers','b093299b075c5f206f8431e632ba872499f0cf75f97c4a0b397bbf0e2743122b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bfbc083b15e01de2cec0560ca6acc2dfa329071195a5290fe89120b82e706c5',1990,'AU','Australia','people-and-society',62,'Population: 16,923,478 (July 1990),
growth rate 1 3% (1990)
Birth rate: 15 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Net migration rate: 6 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 8 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
80 years female (1990)
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Australian(s); adjec-
tive—Australian
Ethnic divisions: 95% Caucasian, 4%
Asian, 1% Aboriginal and other
Religion: 26 1% Anglican, 26 0% Roman
Catholic, 24 3% other Christian
Language: English, native languages
Literacy: 98 5%
Labor force: 7,700,000, 33 8% finance and
services, 22 3% public and community ser-
vices, 20 1% wholesale and retail trade,
16 2% manufacturing and industry, 6 1%
agriculture (1987)
Organized labor: 62% of labor force (1986)','13cd3034705dd3f9f676765aa8372674a0687202ad909608b5e4a925af101fd8','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c9a879ffb235db178c0ba3170f53492a07361f92681a0c7991d8314bf7fad8',1990,'AT','Austria','people-and-society',67,'Population: 7,644,275 (July 1990), growth
rate 0 3% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/1,000 pop-
ulation (1990)
20
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
80 years female (1990)
Total fertility rate: 1 5 children born/
woman (1990)
Nationality: noun—Austrian(s),
adjective—Austrian
Ethnic divisions: 99 4% German, 0 3%
Croatian, 0 2% Slovene, 0 1% other
Religion: 85% Roman Catholic, 6% Prot-
estant, 9% other
Language: German
Literacy: 98%
Labor force: 3,037,000, 56 4% services,
35 4% industry and crafts, 8 1% agricul-
ture and forestry, an estimated 200,000
Austrians are employed in other European
countries, foreign laborers 1n Austria
number 177,840, about 6% of labor force
(1988)
Organized labor: 1,672,820 members of
Austrian Trade Union Federation (1984)
Population: 246,491 (July 1990), growth
rate 1 2% (1990)
Birth rate: 17 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 21 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
75 years female (1990)
Total fertility rate: 1 9 children born/
woman (1990)
Nationality: noun—Bahamuan(s), adjec-
tive—Bahamian
Ethnic divisions: 85% black, 15% white
21
Approved for Release: 2020/08/12 C06554432
The Bahamas (continued)
Religion: Baptist 29%, Anglican 23%, Ro-
man Catholic 22%, smaller groups of
other Protestants, Greek Orthodox, and
Jews
Language: English, some Creole among
Haitian tmmigrants
Literacy: 95% (1986)
Labor force: 132,600, 30% government,
25% hotels and restaurants, 10% business
services, 5% agriculture (1986)
Organized labor: 25% of labor force','232bf13fdc5b40c2f457b77b6b259cb67c7e84b62a5b525badb978d8b3109a6e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a971269ed93c625d0f2b36514fc11f2a5ef6d36192f20b306fa8d4476684ab4',1990,'BH','Bahrain','people-and-society',72,'Population: 520,186 (July 1990), growth
rate 3 2% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 3 deaths/1,000 population
(1990)
Net migration rate: 8 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 19 deaths/1,000 live
births (1990)
Life expectancy at birth: 71 years male,
76 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 4 1 children born/
woman (1990)
Nationality: noun—Bahraini(s),
adyective—Bahraini
Ethnic divisions: 63% Bahraim, 13%
Asian, 10% other Arab, 8% Iraman, 6%
other
Religion: Muslim (70% Shi‘a, 30% Sunni)
Language: Arabic (official), English also
widely spoken, Farsi, Urdu
Literacy: 40%
Labor force: 140,000, 42% of labor force
is Bahraim, 85% industry and commerce,
5% agriculture, 5% services, 3% govern-
ment (1982)
Organized labor: General Committee for
Bahrain Workers exists in only eight ma-
jor designated companies
Population: uninhabited
Note: American civilians evacuated in
1942 after Japanese air and naval attacks
during World War II; occupied by US
military during World War II, but aban-
doned after the war, public entry 1s by
special-use permit only and generally re-
stricted to scientists and educators; a cem-
etery and cemetery ruins located near the
middle of the west coast
Approved for Release: 2020/08/12 C06554432','c4e88f1f6ac0d1bb0501165faba0ff00875a260ad360b32fceaef0092c4858d3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f66b6ff400ca76a1105bf3dd64c37e8335ff21ff4e34a3053473a0a5646e716',1990,'IN','India','people-and-society',77,'Population: 118,433,062 (July 1990),
growth rate 2 8% (1990)
Birth rate: 42 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 136 deaths/ 1,000
live births (1990)
Life expectancy at birth: 54 years male,
53 years female (1990)
Total fertility rate: 5 7 children born/
woman (1990)
Nationality: noun—Bangladeshi(s), adjec-
tive—Bangladesh
Ethnic divisions: 98% Bengali, 250,000
Biharts, and less than 1 million tribals
Religion: 83% Muslim, about 16% Hindu,
less than 1% Buddhist, Christian, and
other
Language: Bangla (official), English widely
used
Literacy: 29% (39% men, 18% women)
Labor force: 35,100,000, 74% agriculture,
15% services, 11% industry and
commerce, extensive export of labor to
Saudi Arabia, UAE, Oman, and Kuwait
(FY86)
Organized labor: 3% of labor force belongs
to 2,614 registered unions (1986 est )
Population: 849,746,001 (July 1990),
growth rate 2 0% (1990)
Birth rate: 30 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 89 deaths/1,000 live
births (1990)
Life expectancy at birth: 57 years male,
59 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Nationality: noun—Indian(s), adjective—
Indian
Ethnic divisions: 72% Indo-Aryan, 25%
Dravidian, 3% Mongoloid and other
Religion: 82 6% Hindu, 11 4% Muslim,
2 4% Christian, 2 0% Sikh, 0 7% Bud-
dhist, 0 5% Jains, 0 4% other
Language: Hindi, English, and 14 other
official languages—Bengali, Telgu, Mara-
thi, Tamil, Urdu, Gujarati, Malayalam,
Kannada, Oriya, Punjabi, Assamese,
Kashmiri, Sindhi, and Sanskrit, 24 lan-
guages spoken by a million or more per-
sons each, numerous other languages and
dialects, for the most part mutually unin-
telligible, Hindi 1s the national language
and primary tongue of 30% of the people,
English enjoys associate status but 1s the
most important language for national, po-
htical, and commercial communication,
Hindustani, a popular variant of Hindi/
Urdu, 1s spoken widely throughout north-
ern India
Literacy: 36%
Labor force: 284,400,000; 67% agriculture
(FY85)
Organized labor: less than 5% of the labor
force','c1f81db3fd52c8db6d738a669e2a5eb453c0e098703caaa546d4c08fe9ac5386','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdffa774c83bd81e4724c04e124860e560fb27dac2f027aed8285b749000b263',1990,'BB','Barbados','people-and-society',83,'Population: 262,688 (July 1990), growth
rate 0 6% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: —5 migrants/1,000
population (1990)
Infant mortality rate: 16 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
77 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
Nationality: noun—Barbadian(s), adjec-
tive—Barbadian
Ethnic divisions: 80% African, 16% mixed,
4% European
Religion: 70% Anglican, 9% Methodist,
4% Roman Catholic, 17% other, including
Moravian
Language: English
Literacy: 99%
Labor force: 112,300, 37% services and
government, 22% commerce, 22% manu-
facturing and construction, 9% transporta-
tion, storage, communications, and finan-
cial institutions, 8% agriculture, 2%
utilities (1985 est )
Organized labor: 32% of labor force','70705c0289606618c4cebda75d201dbdad39d42ff5c406d301a53656bcb4153c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('424e61a0c2a6cd31d7bdc372d664ca41c7c637c3e50b294bea9f699b5af9ab64',1990,'MZ','Mozambique','people-and-society',88,'Population: uninhabited
Population: 460,188 (July 1990), growth
rate 3 5% (1990)
Birth rate: 48 births/1,000 population
(1990)
Death rate: 12 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 89 deaths/1,000 live
births (1990)
Life expectancy at birth: 54 years male,
58 years female (1990)
Total fertility rate: 7 0 children born/
woman (1990)
Nationality: noun—Comoran(s), adjec-
tive—Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Approved for Release: 2020/08/12 C06554432
Religion: 86% Sunni Muslim, 14% Roman
Catholic
Language: Shaafi Islam (a Swahili dia-
lect), Malagasy, French
Literacy: 15%
Labor force: 140,000 (1982), 80% agricul-
ture, 3% government, 51% of population
of working age (1985)
Organized labor: NA
Population: uninhabited
Population: 11,800,524 (July 1990),
growth rate 3 2% (1990)
Birth rate: 47 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 97 deaths/1,000 live
births (1990)
Life expectancy at birth: 50 years male,
54 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 6 9 children born/
woman (1990)
Nationality: noun—Malagasy (sing and
p! ), adjective—Malagasy
Ethnic divisions: basic split between high-
landers of predominantly
Malayo-Indonesian origin (Merina
1,643,000 and related Betsileo 760,000) on
the one hand and coastal tribes, collec-
tively termed the Cétiers, with mixed Af-
rican, Malayo-Indonesian, and Arab an-
cestry (Betsimisaraka 941,000, Tsimihety
442,000, Antaisaka 415,000, Sakalava
375,000), on the other, there are also
11,000 European French, 5,000 Indians of
French nationality, and 5,000 Creoles
Religion: 52% indigenous beliefs, about
41% Christian, 7% Muslim
Language: French and Malagasy (official)
Literacy: 67 5%
Labor force: 4,900,000, 90% nonsalaried
family workers engaged in subsistence ag-
riculture, 175,000 wage earners—26%
agriculture, 17% domestic service, 15%
industry, 14% commerce, 11% construc-
tion, 9% services, 6% transportation, 2%
other, 51% of population of working age
(1985)
Organized labor: 4% of labor force
Population: 14,565,656 (July 1990),
growth rate 2 6% (1990)
Birth rate: 47 births/1,000 population
(1990)
Death rate: 18 deaths/1,000 population
(1990)
Net migration rate: —3 migrants/1,000
population (1990)
Infant mortality rate: 138 deaths/ 1,000
live births (1990)
Life expectancy at birth: 45 years male,
49 years female (1990)
Total fertility rate: 6 5 children born/
woman (1990)
Nationality: noun—Mozambican(s), adjec-
tive—Mozambican
Ethnic divisions: majority from indigenous
tribal groups, about 10,000 Europeans,
35,000 Euro-Africans, 15,000 Indians
Approved for Release: 2020/08/12 C06554432
Religion: 60% indigenous beliefs, 30%
Christian, 10% Muslim
Language: Portuguese (official); many in-
digenous dialects
Literacy: 38%
Labor force: NA, but 90% engaged 1n ag-
riculture
Organized labor: 225,000 workers belong
to a single union, the Mozambique Work-
ers’ Organization (OTM)
Note: there are 800,000 Mozambican ref-
ugees in Malawi (1989 est )','05adac949488a7b2918fb4b250f3f80f3c132d2167a277504f8d2ddb5b5efbe7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dfbee43cb39308c1ab1d920306c1e117bc1da0851c437c8eebf846ccf0b17f0',1990,'BE','Belgium','people-and-society',94,'Population: 9,909,285 (July 1990), growth
rate 0 1% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
80 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 1 6 children born/
woman (1990)
Nationality: noun—Belgian(s), adjective—
Belgian
Ethnic divisions: 55% Fleming, 33% Wal-
loon, 12% mixed or other
Religion: 75% Roman Catholic, remainder
Protestant or other
Language: 56% Flemish (Dutch), 32%
French, 1% German; 11% legally bilin-
gual, divided along ethnic lines
Literacy: 98%
Labor force: 4,000,000, 58% services, 37%
industry, 5% agriculture (1987)
Organized labor: 70% of labor force','eae0738625873fbcb537208c01db8b6ebcad1c7c8f358fc8eaebe7c09eae6352','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70195b22d779ff03a0e8ecea2e3a6c2dd53b266bc95815daebd3645d972da0b3',1990,'BZ','Belize','people-and-society',99,'Population: 219,737 (July 1990), growth
rate 3 7% (1990)
Birth rate: 38 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 4 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 35 deaths/1,000 live
births (1990)
Life expectancy at birth: 67 years male,
72 years female (1990)
30
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 4 8 children born/
woman (1990)
Nationality: noun—Belizean(s),
adjective—Belizean
Ethnic divisions: 39 7% Creole, 33 1%
Mestizo, 9 5% Maya, 7 6% Garifuna,
2 1% East Indian, 8 0% other
Religion: 60% Roman Catholic, 40% Prot-
estant (Anglican, Seventh-Day Adventist,
Methodist, Baptist, Jehovah’s Witnesses,
Mennonite)
Language: English (official), Spanish,
Maya, Garifuna (Carib)
Literacy: 93% (est )
Labor force: 51,500, 30 0% agriculture,
16 0% services, 15 4% government, 11 2%
commerce, 10 3% manufacturing, shortage
of skilled labor and all types of technical
personnel (1985)
Organized labor: 30% of labor force, 11
unions currently active','fd3d0efa5c7d1f2b4e8ead3ebc8328038b0e947799bce228565e3d574b18550d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd358b30a7386648f63875fda4e8da92f42042c89e9a10fe8310a8c550e05309',1990,'BJ','Benin','people-and-society',104,'Population: 4,673,964 (July 1990), growth
rate 3 3% (1990)
Birth rate: 50 births/1,000 population
(1990)
Death rate: 16 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 121 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
52 years female (1990)
Total fertility rate: 7.1 children born/
woman (1990)
Nationality: noun—Beninese (sing , pl ),
adjective—Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adja,
Yoruba, Bariba), 5,500 Europeans
Religion: 70% indigenous beliefs, 15%
Muslim, 15% Christian
Language: French (official), Fon and Yo-
ruba most common vernaculars in south,
at least six major tribal languages in
north
Literacy: 25 9%
Labor force: 1,900,000 (1987), 60% agri-
culture, 38% transport, commerce, and
public services, less than 2% industry,
49% of population of working age (1985)
Organized labor: about 75% of wage earn-
ers
Population: 118,819,377 (July 1990),
growth rate 3 0% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
Net migration rate: 1 migrant/1,000 popu-
lation (1990)
Infant mortality rate: 119 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
49 years female (1990)
Total fertility rate: 6 5 children born/
woman (1990)
Nationality: noun—Nigerian(s),
adjective—N)gerian
Ethnic divisions: more than 250 tribal
groups, Hausa and Fulani of the north,
Yoruba of the southwest, and Ibos of the
southeast make up 65% of the population,
about 27,000 non-Africans
Religion: 50% Muslim, 40% Christian,
10% indigenous beliefs
Language: English (official), Hausa, Yo-
tuba, Ibo, Fulani, and several other lan-
guages also widely used
Literacy: 42 4%
Labor force: 42,844,000, 54% agriculture,
19% industry, commerce, and services,
15% government; 49% of population of
working age (1985)
Organized labor: 3,520,000 wage earners
belong to 42 recognized trade unions,
which come under a single national labor
federation—the Nigerian Labor Congress
(NLC)','ac3feec905b4eab65073ec42c23540877bca72e7aac8d0ae6a15d68e4aebed1d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f81ebfcf6cef67aa523548c26653dafcdb2b389d8785c5c554b0769bfcd265b3',1990,'BM','Bermuda','people-and-society',109,'Population: 58,337 (July 1990), growth
rate 1 5% (1990)
Birth rate: 15 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/1,000
population (1990)
Infant mortality rate: 12 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 1 7 children born/
woman (1990)
Nationality: noun—Bermudian(s), adjec-
tive—Bermudian
Ethnic divisions: 61% black, 39% white
and other
Religion: 37% Anglican, 14% Roman
Catholic, 10% African Methodist Episco-
pal (Zion), 6% Methodist, 5% Seventh-
Day Adventist, 28% other
Language: English
Literacy: 98%
Labor force: 32,000, 25% clerical, 22%
services, 21% laborers, 13% professional
and technical, 10% administrative and
managerial, 7% sales, 2% agriculture and
fishing (1984)
Organized labor: 8,573 members (1985),
largest union 1s Bermuda Industrial Union','3b6e69a2af7ce5a77b808f4c6d14cf1156689ea82e47f1f7287dd1061971a8ac','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e27e0c3a64f546ab577ee3231b2b0efb183916b40bf6ab23ed1c0fd06a6ff0',1990,'BT','Bhutan','people-and-society',114,'Population: 1,565,969 (July 1990), growth
rate 2 0% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 137 deaths/ 1,000
live births (1990)
Life expectancy at birth: 50 years male,
48 years female (1990)
Total fertility rate: 5 0 children born/
woman (1990)
Nationality: noun—Bhutanese (sing , pl ),
adjective—Bhutanese
34
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: 60% Bhote, 25% ethnic
Nepalese, 15% indigenous or migrant
tribes
Religion: 75% Lamaistic Buddhism, 25%
Indian- and Nepalese-influenced Hindu-
ism
Language: Bhotes speak various Tibetan
dialects—most widely spoken dialect 1s
Dzongkha (official), Nepalese speak vari-
ous Nepalese dialects
Literacy: 5%
Labor force: NA, 95% agriculture, 1%
industry and commerce, massive lack of
skilled labor (1983)
Organized labor: not permitted
Population: 6,706,854 (July 1990), growth
rate 2 1% (1990)
Birth rate: 35 births/1,000 population
(1990)
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate: —1 migrant/1,000
population (1990)
Infant mortality rate: 125 deaths/1,000
live births (1990)
Life expectancy at birth: 52 years male,
56 years female (1990)
Total fertility rate: 4 7 children born/
woman (1990)
Nationality: noun—Bolivian(s), adjective
Bolivian
Ethnic divisions: 30% Quechua, 25% Ay-
mara, 25-30% mixed, 5-15% European
Religion: 95% Roman Catholic, active
Protestant minority, especially Evangelical
Methodist
Language: Spanish, Quechua, and Ay-
mara (all official)
Literacy: 63%
Labor force: 1,700,000, 50% agriculture,
26% services and utilities, 10% manufac-
turing, 4% mining, 10% other (1983)
Organized labor: 150,000-200,000, concen-
trated in mining, industry, construction,
and transportation, mostly organized un-
der Bolivian Workers’ Central (COB) la-
bor federation','c9251188a923efefaaebc3a799253e23da3d115dadd8f57404b0f3a67141a2a0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b7e0ac1d8f353319c4662d90836028af51de9ea8f6168f2ecb8c66c8bf9b8ac',1990,'ZA','South Africa','people-and-society',120,'Population: 1,224,527 (July 1990), growth
rate 2 8% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 43 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 58 years male,
64 years female (1990)
Total fertility rate: 4 8 children born/
woman (1990)
Nationality: noun and adjective—Mots-
wana (singular), Batswana (plural)
Ethnic divisions: 95% Batswana, about 4%
Kalanga, Basarwa, and Kgalagadi, about
1% white
Religion: 50% indigenous beliefs, 50%
Christian
Language: English (official), Setswana
Literacy: 60%
Labor force: 400,000, 163,000 formal sec-
tor employees, most others are engaged in
cattle raising and subsistence agriculture
(1988 est ), 19,000 are employed 1n various
mines in South Africa (1988)
Organized labor: 19 trade unions
Population: 39,549,941 (July 1990),
growth rate 2 67%, includes the 10 so-
called homelands, which are not recog-
nized by the US
four independent homelands—Bophuthats-
wana 2,352,296, growth rate 2 80%, Cis-
kei 1,025,873, growth rate 2 93%, Trans-
ke1 4,367,648, growth rate 4 19%, Venda
665,197, growth rate 3 86%
six other homelands—Gazankulu 742,361,
growth rate 3 99%, Kangwane 556,009,
growth rate 3 64%, KwaNdebele 348,655,
growth rate 3 35%, KwaZulu 5,349,247,
growth rate 3 62%, Lebowa 2,704,641,
growth rate 3 92%, Qwagwa 268,138,
growth rate 3 59%
Birth rate: 35 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 52 deaths/1,000 live
births (1990)
Life expectancy at birth: 61 years male,
67 years female (1990)
Total fertility rate: 4 5 children born/
woman (1990)
Nationality: noun—South African(s); ad-
jective—South African
Ethnic divisions: 73 8% black, 14 3%
white, 9 1% Colored, 2 8% Indian
Religion: most whites and Coloreds and
roughly 60% of blacks are Christian,
roughly 60% of Indians are Hindu, 20%
Muslim
Language: Afrikaans, English (official),
many vernacular languages, including
Zulu, Xhosa, North and South Sotho, Ts-
wana
Literacy: almost all white population liter-
ate, government estimates 50% of blacks
literate
Labor force: 11,000,000 economically ac-
tive, 34% services, 30% agriculture, 29%
industry and commerce, 7% mining (1985)
Organized labor: about 17% of total labor
force 1s unionized, African unions repre-
sent 15% of black labor force','d950f8a915c23b69d601ca1f98450d9a5553314f7bd0957d1308bc89de4c6222','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df2aa0531137c43bd947c96cb11196a18cb7f99063e42af36000a0cc4ae93957',1990,'EC','Ecuador','people-and-society',127,'Population: 152,505,077 (July 1990),
growth rate 1 9% (1990)
Birth rate: 26 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 69 deaths/1,000 live
births (1990)
Life expectancy at birth: 62 years male,
68 years female (1990)
Total fertility rate: 3 1 children born/
woman (1990)
Nationality: noun—Brazilian(s), adjec-
trve—Brazihan
Ethnic divisions: Portuguese, Italian, Ger-
man, Japanese, black, Amerindian, 55%
white, 38% mixed, 6% black, 1% other
Religion: 90% Roman Catholic (nominal)
Language: Portuguese (official), Spanish,
English, French
Literacy: 76%
Labor force: 57,000,000 (1989 est ), 42%
services, 31% agriculture, 27% industry
Organized labor: 13,000,000 dues paying
members (1989 est )
Population: 10,506,668 (July 1990),
growth rate 2 3% (1990)
Birth rate: 30 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 61 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
68 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Ecuadorian(s), adjec-
tive—Ecuadorian
Ethnic divisions: 55% mestizo (mixed In-
dian and Spanish), 25% Indian, 10%
Spanish, 10% black
Religion: 95% Roman Catholic
Language: Spanish (official), Indian lan-
guages, especially Quechua
Literacy: 85% (1981)
Labor force: 2,800,000, 35% agriculture,
21% manufacturing, 16% commerce, 28%
services and other activities (1982)
Organized labor: less than 15% of labor
force','7b97102d263ccaad063ddb857aa4a37166fde257122d2c71366bc9e4a2c46a70','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6748384a7755c981e78652cade922d6a508dc574abbf1e8d3fdf3b07f573a48d',1990,'MU','Mauritius','people-and-society',133,'Population: no permanent civilian popula-
tion, formerly about 3,000 islanders
Ethnic divisions: civilian inhabitants,
known as the Ilois, evacuated to Mauritius
before construction of UK and US defense
facilities
Population: 12,258 (July 1990), growth
rate 1 1% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: — 3 migrants/1,000
population (1990)
Infant mortality rate: 14 deaths/1,000 live
births (1990)
Life expectancy at birth: 71 years male,
77 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—British Virgin Island-
er(s), adjective—British Virgin Islander
Ethnic divisions: over 90% black, remain-
der of white and Asian origin
Religion: majority Methodist, others in-
clude Anglican, Church of God, Seventh-
Day Adventist, Baptist, and Roman Cath-
olic
Language: English (official)
Literacy: 98%
Labor force: 4,911 (1980)
Organized labor: NA
Population: |,070,005 (July 1990), growth
rate 1 8% (1990)
Birth rate: 21 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 4 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 20 deaths/1,000 live
births (1990)
Life expectancy at birth: 66 years male,
73 years female (1990)
Total fertility rate: 2 0 children born/
woman (1990)
Nationality: noun—Mauritian(s), adjec-
tive—Mauritian
Ethnic divisions: 68% Indo-Mauritian,
27% Creole, 3% Sino-Mauritian, 2%
Franco- Mauritian
Religion: 51% Hindu, 30% Christian
(mostly Roman Catholic with a few Anghi-
cans), 17% Muslim, 2% other
Language: English (official), Creole,
French, Hindi, Urdu, Hakka, Bojpoori
Literacy: 82 8%
Labor force: 335,000, 29% government
services, 27% agriculture and fishing, 22%
manufacturing, 22% other, 43% of popula-
tion of working age (1985)
Organized labor: 35% of labor force in
more than 270 unions','c47317412f03c416f63a74fea88d0d9c58ecf9f43f028bdb5e9591e2399635bb','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3266cd1ab1b5e571473a14688ec7b4f6efae0c6212447a298e13c72babc1dc2a',1990,'MY','Malaysia','people-and-society',137,'Population: 372,108 (July 1990), growth
rate 7 1% (1990)
Birth rate: 23 births/1,000 population
(1990)
Death rate: 4 deaths/1,000 population
(1990)
Net migration rate: 52 migrants/ 1,000
population (1990)
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
77 years female (1990)
Total fertility rate: 2 9 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Brunetan(s), adjec-
tive—Bruneian
Ethnic divisions: 64% Malay, 20% Chi-
nese, 16% other
Religion: 60% Muslim (official), 8% Chris-
tian, 32% Buddhist and indigenous beliefs
Language: Malay (official), English, and
Chinese
Literacy: 45%
Labor force: 89,000 (includes members of
the Army), 33% of labor force 1s foreign
(1988), 50 4% production of oil, natural
gas, and construction, 47 6% trade, ser-
vices, and other, 2 0% agriculture, for-
estry, and fishing (1984)
Organized labor: 2% of labor force
Population: 17,510,546 (July 1990),
growth rate 2 3% (1990)
Birth rate: 29 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 30 deaths/ 1,000 live
births (1990)
Life expectancy at birth: 65 years male,
71 years female (1990)
Total fertility rate: 3 5 children born/
woman (1990)
Nationality: noun—Malaysian(s), adjec-
tive—Malaysian
Ethnic divisions: 59% Malay and other
indigenous, 32% Chinese, 9% Indian
Religion: Peninsular Malaysia—Malays
nearly all Muslim, Chinese predominantly
Buddhists, Indians predominantly Hindu,
Sabah—38% Muslim, 17% Christian, 45%
other; Sarawak—35% tribal religion, 24%
Buddhist and Confucianist, 20% Muslim,
16% Christian, 5% other
Language: Peninsular Malaysia—Malay
(official), English, Chinese dialects, Tamil,
Sabah—English, Malay, numerous tribal
dialects, Mandarin and Hakka dialects
predominate among Chinese, Sarawak—
English, Malay, Mandarin, numerous
tribal languages
Literacy: 65 0% overall, age 20 and up,
Peninsular Malaysia—80%, Sabah—60%,
Sarawak—60%
Labor force: 6,800,000, 30 8% agriculture,
17% manufacturing, 13 6% government,
5 8% construction, 4 3% finance, 3 4%
business services, transport and communi-
cations, 0 6% mining, 24 5% other (1989
est )
Organized labor: 660,000, 10% of total
labor force (1988)','e7ad339168b573479092746da06982d3be31db956f58a4cb2fb03f0889b3701c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8e653fefbafe71602af4391665628a0530b498b14ec84991beaf19ac6db34ca',1990,'BG','Bulgaria','people-and-society',143,'Population: 8,933,544 (July 1990), growth
rate —0 3% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 12 deaths/1,000 population
(1990)
Net migration rate: — 4 migrants/ 1,000
population (1990)
Infant mortality rate: 13 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
76 years female (1990)
43
Approved for Release: 2020/08/12 C06554432
Bulgaria (continued)
Total fertility rate: 1 9 children born/
woman (1990)
Nationality: noun—Bulgarian(s), adjec-
tive—Bulganan
Ethnic divisions: 85 3% Bulgarian, 8 5%
Turk, 2 6% Gypsy, 2 5% Macedonian,
0 3% Armenian, 0 2% Russian, 0 6% other
Religion: religious background of popula-
tion 1s 85% Bulgarian Orthodox, 13%
Mushm, 0 8% Jewish, 0 7% Roman Cath-
olic, 0 5% Protestant, Gregorian-Arme-
nian, and other
Language: Bulgarian, secondary languages
closely correspond to ethnic breakdown
Literacy: 95% (est )
Labor force: 4,300,000, 33% industry,
20% agriculture, 47% other (1987)
Organized labor: all workers are members
of the Central Council of Trade Unions
(CCTU), Pod Krepa (Support), an inde-
pendent trade union, legally registered in
January 1990
Population: 9,077,828 (July 1990), growth
rate 3 1% (1990)
Birth rate: 50 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
45
Approved for Release: 2020/08/12 C06554432
Burkina (continued)
Net migration rate: —3 migrants/1,000
population (1990)
Infant mortality rate: 121 deaths/1,000
live births (1990)
Life expectancy at birth: 51 years male,
52 years female (1990)
Total fertility rate: 7 2 children born/
woman (1990)
Nationality: noun—Burkinabe, adjective—
Burkinabe
Ethnic divisions: more than 50 tribes, prin-
cipal tribe ts Mossi (about 2 5 million),
other important groups are Gurunsi, Se-
nufo, Lobi, Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about
25% Muslim, 10% Christian (mainly Ro-
man Catholic)
Language: French (official), tribal
languages belong to Sudanic family, spo-
ken by 90% of the population
Literacy: 13 2%
Labor force: 3,300,000 residents, 30,000
are wage earners, 82% agriculture, 13%
industry, 5% commerce, services, and gov-
ernment, 20% of male labor force
migrates annually to neighboring coun-
tries for seasonal employment (1984); 44%
of population of working age (1985)
Organized labor: four principal trade
union groups represent less than 1% of
population
Population: 41,277,389 (July 1990),
growth rate 2 0% (1990)
Birth rate: 33 births/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 97 deaths/1,000 live
births (1990)
Life expectancy at birth: 53 years male,
56 years female (1990)
Total fertility rate: 4 2 children born/
woman (1990)
Nationality: noun—Burmese, adjective—
Burmese
Ethnic divisions: 68% Burman, 9% Shan,
7% Karen, 4% Rakhine, 3% Chinese, 2%
Mon, 2% Indian, 5% other
Religion: 85% Buddhist, 15% animist be-
hiefs, Muslim, Christian, or other
Language: Burmese, minority ethnic
groups have their own languages
Literacy: 78%
Labor force: 16,036,000, 65 2% agricul-
ture, 14 3% industry, 10 1% trade, 6 3%
government, 4 1% other (FY89 est )
Organized labor: Workers’ Asiayone (asso-
ciation), 1,800,000 members, and Peas-
ants’ Asiayone, 7,600,000 members','9c8165f1791db468a5614a723cbda87258874d83c625fe4afaa356651f712071','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31429aafcd1facd1aec6ee82c7edae2f9a2373f2ecf18b8b62d1fe5156e7638b',1990,'BI','Burundi','people-and-society',148,'Population: 5,645,997 (July 1990), growth
rate 3 2% (1990)
Birth rate: 47 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 111 deaths/1,000
live births (1990)
Life expectancy at birth: 50 years male,
54 years female (1990)
Total fertility rate: 7 0 children born/
woman (1990)
Nationality: noun—Burundian(s), adjec-
tive—Burundi
Ethnic divisions: Africans—85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include about
70,000 refugees, mostly Rwandans and
Zairians, non-Africans include about
3,000 Europeans and 2,000 South Asians
Religion: about 67% Christian (62% Ro-
man Catholic, 5% Protestant), 32% indige-
nous beliefs, 1% Muslim
Language: Kirundi and French (official),
Swahilt (along Lake Tanganyika and in
the Bujumbura area)
Literacy: 33 8%
Labor force: 1,900,000 (1983 est ), 93.0%
agriculture, 40% government, 1 5% indus-
try and commerce, | 5% services, 52% of
population of working age (1985)
Organized labor: sole group is the Union
of Burund: Workers (UTB), by charter,
membership 1s extended to all Burundi
workers (informally), figures denoting ac-
tive membership unobtainable','ef2d1551298efa4cdbf94c7590c647fe209412b7bbc0ab3a38154a817d260f1e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49fa7f011a6cf58b34eaeafb749e7ca38483c65d13a54b1996e68cfec521ffa3',1990,'TH','Thailand','people-and-society',154,'Population: 6,991,107 (July 1990), growth
rate 2 2% (1990)
Birth rate: 39 births/1,000 population
(1990)
Death rate: 16 deaths/1,000 population
(1990)
50
Approved for Release: 2020/08/12 C06554432
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 128 deaths/ 1,000
live births (1990)
Life expectancy at birth: 47 years male,
50 years female (1990)
Total fertility rate: 4 5 children born/
woman (1990)
Nationality: noun-——Cambodian(s), adjec-
tive—Cambodian
Ethnic divisions: 90% Khmer
(Cambodian), 5% Chinese, 5% other mi-
norities
Religion: 95% Theravada Buddhism, 5%
other
Language: Khmer (official), French
Literacy: 48%
Labor force: 2 5-3 0 million, 80% agricul-
ture (1988 est )
Organized labor: Kampuchea Federation
of Trade Untons (FSC); under government
control
Population: 55,115,683 (July 1990),
growth rate | 3% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 7 deaths/ 1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 34 deaths/1,000 live
births (1990)
305
Thailand (continued)
Life expectancy at birth: 64 years male,
70 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
Nationality: noun—Thai (sing and pl ),
adjective—Tha1
Ethnic divisions: 75% Thai, 14% Chinese,
11% other
Religion: 95 5% Buddhist, 4% Muslim,
0 5% other
Language: Thai, English 1s the secondary
language of the elite, ethnic and regional
dialects
Literacy: 82%
Labor force: 26,000,000, 73% agriculture,
11% industry and commerce, 10% ser-
vices, 6% government (1984)
Organized labor: 300,000 union members
(1986)','3b27eb90044c96448e1c30c7adc1161ed4571de4e0e00f49e0e49d3b081e962d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('665a90ab54e7f500b68a7e9d6014f95661e5c95752521f14c82b8dff8d6661e8',1990,'CM','Cameroon','people-and-society',159,'Population: 11,092,470 (July 1990),
growth rate 2 7% (1990)
Birth rate: 42 births/1,000 population
(1990)
51
Approved for Release: 2020/08/12 C06554432
Cameroon (continued)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 120 deaths/1,000
live births (1990)
Life expectancy at birth: 49 years male,
53 years female (1990)
Total fertility rate: 5 7 children born/
woman (1990)
Nationality: noun—Cameroonian(s), adjec-
trve—Cameroonian
Ethnic divisions: over 200 tribes of widely
differing background, 31% Cameroon
Highlanders, 19% Equatorial Bantu, 11%
Kirdi, 10% Fulam, 8% Northwestern
Bantu, 7% Eastern Nigritic, 13% other
African, less than 1% non-African
Religion: 51% indigenous beliefs, 33%
Christian, 16% Muslim
Language: English and French (official),
24 major African language groups
Literacy: 56 2%
Labor force: NA, 74 4% agriculture,
11 4% industry and transport, 14 2% other
services (1983); 50% of population of
working age (15-64 years) (1985)
Organized labor: under 45% of wage labor
force','ba1fda22ef5b44f736a873e1507a62e4c102f9a91d5fdabba86b26ac62991205','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81978bc0de13c2fb68dccb657516595345563345ddc58eb590965b210d919591',1990,'CA','Canada','people-and-society',165,'Population: 26,538,229 (July 1990),
growth rate 1 1% (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 5 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
81 years female (1990)
Total fertility rate: 1 7 children born/
woman (1990)
Nationality: noun—Canadian(s), adjec-
tive—Canadian
Ethnic divisions: 40% British Isles origin,
27% French origin, 20% other European,
1 5% indigenous Indian and Eskimo
Religion: 46% Roman Catholic, 16%
United Church, 10% Anglican
Language: English and French (both offi-
cial)
Literacy: 99%
Labor force: 13,380,000, services 75%,
manufacturing 14%, agriculture 4%, con-
struction 3%, other 4% (1988)
Organized labor: 30 6% of labor force,
39 6% of nonagricultural paid workers
Population: 374,984 (July 1990), growth
rate 3 0% (1990)
Birth rate: 49 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: —8 migrants/1,000
population (1990)
Infant mortality rate: 65 deaths/1,000 live
births (1990)
Life expectancy at birth: 59 years male,
63 years female (1990)
Total fertility rate: 6 7 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Cape Verdean(s), ad-
Jective—Cape Verdean
Ethnic divisions: about 71% Creole (mu-
latto), 28% African, 1% European
Religion: Roman Catholicism fused with
indigenous beliefs
Language: Portuguese and Crioulo, a
blend of Portuguese and West African
words
Literacy: 48% (1986)
Labor force: 102,000 (1985 est ), 57% ag-
riculture (mostly subsistence), 29% ser-
vices, 14% industry (1981), 51% of popula-
tion of working age (1985)
Organized labor: Trade Unions of Cape
Verde Unity Center (UNTC-CS) closely
associated with ruling party','a1456e6804a93d6f1e42b90ec2cee245df7b4714e8f4381f245e446eec675b27','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c96135238c546b48de729714c0b8d7b2f56b25c129e20e739e48033fe89f188a',1990,'KY','Cayman Islands','people-and-society',170,'Population: 26,356 (July 1990), growth
rate 4 3% (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 33 migrants/1,000
population (1990)
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
80 years female (1990)
Total fertility rate: 1 5 children born/
woman (1990)
Nationality: noun—Caymanian(s), adjec-
tive—Caymanian
Ethnic divisions: 40% mixed, 20% white,
20% black, 20% expatriates of various eth-
nic groups
Approved for Release: 2020/08/12 C06554432
Religion: United Church (Presbyterian
and Congregational), Anglican, Baptist,
Roman Catholic, Church of God, other
Protestant denominations
Language: English
Literacy: 98%
Labor force: 8,061, 18 7% service workers,
18 6% clerical, 12 5% construction, 6 7%
finance and investment, 5 9% directors
and business managers (1979)
Organized labor: Global Seaman’s Union,
Cayman All Trade Union','c5fa2316a85bbb0988b4421f06007ab44cd32f7e40b9b3f5eaa036eb068b418c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('719c3e2e3bb2440789494b4d4f8a70e7a2e5663e517ef997ff3a4b06ad87269f',1990,'CF','Central African Republic','people-and-society',175,'Population: 2,877,365 (July 1990), growth
rate 2 6% (1990)
Birth rate: 44 births/1,000 population
(1990)
Death rate: 18 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 141 deaths/1,000
live births (1990)
Life expectancy at birth: 45 years male,
48 years female (1990)
Total fertility rate: 5 6 children born/
woman (1990)
Nationality: noun—Central African(s),
adjective—Central African
57
Approved for Release: 2020/08/12 C06554432
(continued)
Ethnic divisions: about 80 ethnic groups,
the majority of which have related ethnic
and linguistic characteristics, 34% Baya,
27% Banda, 10% Sara, 21% Mandya, 4%
Mboum, 4% M’Baka, 6,500 Europeans, of
whom 3,600 are French
Religion: 24% indigenous beliefs, 25%
Protestant, 25% Roman Catholic, 15%
Muslim, 11% other, animistic beliefs and
practices strongly influence the Christian
majority
Language: French (official), Sangho (lingua
franca and national language), Arabic,
Hunsa, Swahili
Literacy: 40 2%
Labor force: 775,413 (1986 est ), 85% ag-
riculture, 9% commerce and services, 3%
industry, 3% government, about 64,000
salaried workers, 55% of population of
working age (1985)
Organized labor: 1% of labor force','8f33647ca6f0e2362cc1a82fb3cfa62a9b493010d501978f5f13af10bc48765a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49682224eb8c3107291add070cf853392195e75e6e61eaa35c99a1e5d294d468',1990,'TD','Chad','people-and-society',180,'Population: 5,017,431 (July 1990), growth
rate 2 1% (1990)
Birth rate: 42 births/1,000 population
(1990)
Death rate: 22 deaths/1,000 population
(1990)
Net migration rate; NEGL migrants/
1,000 population (1990)
Infant mortality rate: 136 deaths/1,000
live births (1990)
Life expectancy at birth: 38 years male,
40 years female (1990)
Total fertility rate: 5 3 children born/
woman (1990)
Nationality: noun—Chadian(s),
adjective—Chadian
Ethnic divisions: some 200 distinct ethnic
groups, most of whom are Muslims
(Arabs, Toubou, Fulbe, Kotoko, Hausa,
Kanembou, Baguirmi, Boulala, and Maba)
in the north and center and non-Muslims
(Sara, Ngambaye, Mbaye, Goulaye, Mou-
dang, Moussei, Massa) in the south, some
150,000 nonindigenous, of whom 1,000
are French
Religion: 44% Muslim, 33% Christian,
23% indigenous beliefs, animism
Language: French and Arabic (official),
Sara and Sango in south, more than 100
different languages and dialects are spo-
ken
Literacy: 25 3%
Labor force: NA, 85% agriculture (en-
gaged in unpaid subsistence farming,
herding, and fishing)
Organized labor: about 20% of wage labor
force','d0652409cc256194490c9c344572af26b975c5d50f305711c82331175b7f5a7a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09850ce4c56e5550b71e87685ed32afcfab6c6674790665164493b2c456e5e37',1990,'CL','Chile','people-and-society',185,'Population: 13,082,842 (July 1990),
growth rate 1 6% (1990)
Birth rate: 21 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 18 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
77 years female (1990)
Total fertility rate: 2 5 children born/
woman (1990)
Nationality: noun—Chilean(s), adjective—
Chilean
Ethnic divisions: 95% European and
European-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Prot-
estant, and small Jewish population
Language: Spanish
Literacy: 94%
Labor force: 3,840,000, 38 6% services
(including 12% government), 31 3% indus-
try and commerce, 15 9% agriculture, for-
estry, and fishing, 8 7% mining, 4 4% con-
struction (1985)
Organized labor: 10% of labor force (1989)','d9ff6e4715bdd012be04550e3824b02a0bdbcd37be25cc4258ae2327b133ef80','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d0675547d95ff89bf11a44065bfa625e4b9584128e24928bf9a1715a874674f',1990,'CN','China','people-and-society',190,'Population: 1,118,162,727 (July 1990),
growth rate 1 4% (1990)
Birth rate: 22 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 34 deaths/1,000 hive
births (1990)
Life expectancy at birth: 67 years male,
69 years female (1990)
Total fertility rate: 2 3 children born/
woman (1990)
Nationality: noun—Chinese (sing , pl ),
adyective—Chinese
Ethnic divisions: 93 3% Han Chinese,
67% Zhuang, Uygur, Hu, Yi, Tibetan,
Miao, Manchu, Mongol, Buyi, Korean,
and other nationalities
Religion: officially atheist, but tradition-
ally pragmatic and eclectic, most impor-
tant elements of religion are Confucian-
ism, Taoism, and Buddhism, about 2-3%
Muslim, 1% Christian
Language: Standard Chinese (Putonghua)
or Mandarin (based on the Beiying dia-
lect), also Yue (Cantonese), Wu (Shang-
hainese), Minbe1 (Fuzhou), Minnan
(Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, and minority languages (see eth-
nic divisions)
Literacy: over 75%
Labor force: 513,000,000, 61 1% agricul-
ture and forestry, 25 2% industry and
commerce, 4 6% construction and mining,
4 5% social services, 4 6% other (1986 est )
Organized labor: All-China Federation of
Trade Unions (ACFTU) follows the lead-
ership of the Chinese Communist Party,
membership over 80 million or about 65%
of the urban work force (1985)
Population: 66,117,284 (July 1990),
growth rate 2 5% (1990)
Birth rate: 32 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —1 migrant/1,000
population (1990)
Infant mortality rate: 48 deaths/1,000 live
births (1990)
Life expectancy at birth: 63 years male,
69 years female (1990)
Total fertility rate: 4 3 children born/
woman (1990)
Nationality: noun—Filipino(s), adjectrve—
Philippine
Ethnic divisions: 91 5% Christian Malay,
4% Mushm Malay, 1 5% Chinese, 3%
other
Religion: 83% Roman Catholic, 9% Prot-
estant, 5% Muslim, 3% Buddhist and
other
Language: Pilipino (based on Tagalog) and
English, both official
Literacy: 88% (est )
Labor force: 22,889,000, 47% agriculture,
20% industry and commerce, 13 5% ser-
vices, 10% government, 9 5% other (1987)
Organized labor: 2,064 registered unions,
total membership 4 8 million (includes 2 7
million members of the National Congress
of Farmers Organizations)
Population: 66,170,889 (July 1990),
growth rate 2 1% (1990)
Birth rate: 30 births/1,000 population
(1990)
Death rate: 8 deaths/!,000 population
(1990)
Net migration rate: — 1 migrants/ 1,000
population (1990)
Infant mortality rate: 50 deaths/1,000 live
births (1990)
Life expectancy at birth: 62 years male,
66 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Nationality: noun—Vietnamese (sing and
pl ), adjective— Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese, 3% Chinese, ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham, other mountain tribes
Religion: Buddhist, Confucian, Taoist, Ro-
man Catholic, indigenous beliefs, Islamic,
Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Literacy: 78%
Labor force: 35,000,000 (1989 est )
Organized labor: reportedly over 90% of
wage and salary earners are members of
the Vietnam Federation of Trade Unions
(VFTU)
Population: 99,200 (July 1990), growth
rate —0 3% (1990)
Birth rate: 22 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: — 20 migrants/1,000
population (1990)
Infant mortality rate: 19 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
76 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 2 7 children born/
woman (1990)
Nationality: noun—Virgin Islander(s), ad-
jective—Virgin Islander
Ethnic divisions: 74% West Indian (45%
born in the Virgin Islands and 29% born
elsewhere in the West Indies), 13% US
mainland, 5% Puerto Rican, 8% other,
80% black, 15% white, 5% other, 14% of
Hispanic origin
Religion: 42% Baptist, 34% Roman Catho-
lic, 17% Episcopalian, 7% other
Language: English (official), but Spanish
and Creole are widely spoken
Literacy: 90%
Labor force: 45,000 (1987)
Organized labor: 90% of the government
labor force','e665000d09b026e6d55de9d432c6af1f6006537017e2e7223d016b012e8ea01b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f2c8ce4c4a18a4c75dd2c7a68a6e7c4156714cca74944743548639aa7b1a289',1990,'CX','Christmas Island','people-and-society',196,'Population: 2,278 (July 1990), growth rate
0 0% (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/1,000
population (1990)
Infant mortality rate: NA deaths/ 1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
Nationality: noun—Christmas Islander(s),
adjective—Christmas Island
Ethnic divisions: 61% Chinese, 25% Ma-
lay, 11% European, 3% other, no indige-
nous population
Religion: NA
Language: English
Literacy: NA%
Labor force: NA, all workers are employ-
ees of the Phosphate Mining Company of
Christmas Island, Ltd
Organized labor: NA
Population: uninhabited','2f8a4935dbc26ee14db96ed4d2ed50b622f4105b48fcb0c5d7203e59e25dc05c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f73bcdfa11229921a2c2da0fa8893a86946a17c8659a4be63d963bc13a7565a6',1990,'CC','Cocos (Keeling) Islands','people-and-society',201,'Population: 670 (July 1990), growth rate
2 1% (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/1,000
population (1990)
Infant mortality rate: NA deaths/1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
66
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Cocos Islander(s), ad-
jective—Cocos Islander(s)
Ethnic divisions: mostly Europeans on
West Island and Cocos Malays on Home
Island
Religion: NA
Language: English
Literacy: NA%
Labor force: NA
Organized labor: none','df6eb8ff6d9eafa5b4d7fed63a0f0b472b8574e441d7a7c998e29c2249030cbc','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07fcaa1401f8340f4041db15014ae890d7fa6713aec31a0fa65bbefcdd18e141',1990,'CO','Colombia','people-and-society',206,'Population: 33,076,188 (July 1990),
growth rate 2 1% (1990)
Birth rate: 27 births/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 38 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
73 years female (1990)
Total fertility rate: 2 9 children born/
woman (1990)
Nationality: noun—Colombian(s), adjec-
tive—Colombian
Ethnic divisions: 58% mestizo, 20% white,
14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 88% (1987 est ), Indians about
40%
Labor force: 11,000,000 (1986), 53% ser-
vices, 26% agriculture, 21% industry
(1981)
Organized labor: 1,400,000 members
(1987), about 12% of labor force, the
Communist-backed Unitary Workers Cen-
tral or CUT 1s the largest labor organiza-
tion, with about 725,000 members (in-
cluding all affiliate unions)','4869073e5b32763a40e2f0cbf510eca612c02602e007c6228e4ef9d1d940e6bc','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dd2cf9168b874a2b6d586e40814738b9daafea76426d9d431b7f768bd9498a2',1990,'CG','Congo','people-and-society',212,'Population: 2,242,274 (July 1990), growth
rate 3 0% (1990)
Birth rate: 43 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 110 deaths/1,000
live births (1990)
Life expectancy at birth: 52 years male,
55 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 5 8 children born/
woman (1990)
Nationality: noun—Congolese (sing , pl ),
adjective-—Congolese or Congo
Ethnic divisions: about 15 ethnic groups
divided into some 75 tribes, almost all
Bantu, most important ethnic groups are
Kongo (48%) in the south, Sangha (20%)
and M’Bochi (12%) in the north, Teke
(17%) in the center, about 8,500 Europe-
ans, mostly French
Religion: 50% Christian, 48% animust, 2%
Muslim
Language: French (official), many African
languages with Lingala and Kikongo most
widely used
Literacy: 62 9%
Labor force: 79,100 wage earners, 75%
agriculture, 25% commerce, industry, and
government, 51% of population of working
age, 40% of population economically ac-
tive (1985)
Organized labor: 20% of labor force (1979
est )','7b5be3a6542a181d40c71f1f9eeb6d87e32db0b099db07f360a2ab354a1341b2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ab513b2738af617b58da458a171f711dac7cb1d963175df00ebde5b22f722c9',1990,'CK','Cook Islands','people-and-society',217,'Population: 18,187 (July 1990), growth
rate 0 5% (1990)
Birth rate: 22 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: — 10 migrants/ 1,000
population (1990)
Infant mortality rate: 24 deaths/1!,000 live
births (1990)
Life expectancy at birth: 66 years male,
72 years female (1990)
Total fertility rate: 3 5 children born/
woman (1990)
Nationality: noun—Cook Islander(s), ad-
jective—Cook Islander
Ethnic divisions: 81 3% Polynesian (full
blood), 7 7% Polynesian and European,
77% Polynesian and other, 2 4% Euro-
pean, 0 9% other
72
Approved for Release: 2020/08/12 C06554432
Religion: Christian, majority of populace
members of Cook Islands Christian
Church
Language: English
Literacy: NA%
Labor force: 5,810, agriculture 29%, gov-
ernment 27%, services 25%, industry 15%,
and other 4% (1981)
Organized labor: NA
Population: 3 meteorologists','3eac6f501aeaf0bf1fd6a9bca6d152a514420751b6b276e6c4503a92d63c4342','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66cac76d4200a3decf9226237d036ca1168412ee0152052fee0afb672497f672',1990,'CR','Costa Rica','people-and-society',222,'Population: 3,032,795 (July 1990), growth
rate 2 6% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 4 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 16 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
79 years female (1990)
Total fertility rate: 3 3 children born/
woman (1990)
Nationality: noun—Costa Rican(s), adjec-
tive—Costa Rican
74
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: 96% white (including
mestizo), 2% black, 1% Indian, 1% Chi-
nese
Religion: 95% Roman Catholic
Language: Spanish (official), English spo-
ken around Puerto Limén
Literacy: 93%
Labor force: 868,300, industry and com-
merce 35 1%, government and services
33%, agriculture 27%, other 4 9% (1985
est )
Organized labor: 15 1% of labor force','03591a3ce6020647a43bf679889468e3d53af929d2d739fb535bcc780e498ef3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edfbebd5e604db2e53547d3e47e04c68cfd35a3f8f2af9b39c82aacf5873af08',1990,'CU','Cuba','people-and-society',227,'Population: 10,620,099 (July 1990),
growth rate | 1% (1990)
Birth rate: 18 births/!,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: — 1 migrant/1,000
population (1990)
Infant mortality rate: 12 deaths/1,000 live
births (1990)
75
Approved for Release: 2020/08/12 C06554432
Cuba (continued)
Life expectancy at birth: 73 years male,
78 years female (1990)
Total fertility rate: 1 9 children born/
woman (1990)
Nationality: noun—Cuban(s), adjective—
Cuban
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Literacy: 98 5%
Labor force: 3,400,000 in state sector;
30% services and government, 22% indus-
try, 20% agriculture, 11% commerce, 10%
construction, 7% transportation and com-
munications (1988), economically active
population 4,500,000 (1987)
Organized labor: Workers Central Union
of Cuba (CTC), only labor federation ap-
proved by government, 2,910,000 mem-
bers, the CTC 1s an umbrella organization
composed of 17 member unions','e0f2d9be7a7cd4d04f209a8d7668d197a2abcb663e2b184a515255a075127999','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfa3f15ad179d587544ef026e02d74bbca4472a5f100b44b2886a38121f28784',1990,'CY','Cyprus','people-and-society',232,'Population: 707,776 (July 1990), growth
rate 1 0% (1990)
Birth rate: 19 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
78 years female (1990)
Total fertility rate: 2 4 children born/
woman (1990)
Nationality: noun—Cypriot(s), adyective—
Cypriot
Ethnic divisions: 78% Greek, 18% Turkish,
4% other
Religion: 78% Greek Orthodox, 18% Mus-
lim, 4% Maronite, Armenian, Apostolic,
and other
Language: Greek, Turkish, English
Literacy: 99% (est )
Labor force: Greek area—251,406, 42%
services, 33% industry, 22% agriculture,
Turkish area—NA (1986)
Organized labor: 156,000 (1985 est )','b42c05e5f1f0f724c23d41b2a3abd4260ff2fde3ae2bfbb2ad300830b2824957','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50462dea8342b874b564d625d00722c16227c9d96d83138dce3e77824c621d34',1990,'HU','Hungary','people-and-society',236,'Population: 15,683,234 (July 1990),
growth rate 0 3% (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 11 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
76 years female (1990)
Total fertility rate: 2 0 children born/
woman (1990)
Nationality: noun—Czechoslovak(s), adjec-
tive—Czechoslovak
Ethnic divisions: 64 3% Czech, 30 5% Slo-
vak, 3 8% Hungarian, 0 4% German, 0 4%
Polish, 0 3% Ukrainian, 0 1% Russian,
0 2% other (Jewish, Gypsy)
Religion: 50% Roman Catholic, 20% Prot-
estant, 2% Orthodox, 28% other
Language: Czech and Slovak (official),
Hungarian
Literacy: 99%
Labor force: 8,200,000 (1987), 36 9% in-
dustry, 12 3% agriculture, 50 8% construc-
tion, communications, and other (1982)
Organized labor: Revolutionary Trade
Union Movement (ROH), formerly
regime-controlled, other industry-specific
strike committees, new independent trade
unions forming
Population: 10,568,686 (July 1990),
growth rate —0 1% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 15 deaths/1,000 live
births (1990)
Life expectancy at birth: 67 years male,
75 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Hungarian(s), adyjec-
tive—Hungarian
Ethnic divisions: 96 6% Hungarian, 1 6%
German, 1 1% Slovak, 0 3% Southern
Slav, 0 2% Romanian
Religion: 67 5% Roman Catholic, 20 0%
Calvinist, 5 0% Lutheran, 7 5% atheist
and other
Language: 98 2% Hungarian, 1 8% other
Literacy: 99%
Labor force: 4,860,000, 43 2% services,
trade, government, and other, 30 9% in-
dustry, 18 8% agriculture, 7 1% construc-
tion (1988)
Organized labor: 96 5% of labor force,
Central Council of Hungarian Trade
Unions (SZOT) includes 19 affiliated
unions, all controlled by the government,
independent umions legal, may be as many
as 12 small independent unions in opera-
tion','60c692afd2131f34af949e80cc4ce35be1ce478172b0ae5ff6236b1fc9b9eb72','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab820c9dbf22e9258627873289189b3d303df88b0910e7a3bf037938a5ef535',1990,'DK','Denmark','people-and-society',242,'Population: 5,131,217 (July 1990), growth
rate NEGL% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
79 years female (1990)
Total fertility rate: 1 6 children born/
woman (1990)
Nationality: noun—Dane(s), adjective—
Danish
Ethnic divisions: Scandinavian, Eskimo,
Faroese, German
Religion: 97% Evangelical Lutheran, 2%
other Protestant and Roman Catholic, 1%
other
Language: Danish, Faroese, Greenlandic
(an Eskimo dialect), small
German-speaking minority
Literacy: 99%
Labor force: 2,760,000, 51% services, 34%
industry, 8% government, 7% agriculture,
forestry, and fishing (1988)
Organized labor: 65% of labor force','94395997c033ebc7a03046f5d39bade456232cb22fb0d8ffe910aa8e33e848aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ac13ff5225dabd863530454cf37dab227e0249bbc955fa226693346ee1f968d',1990,'DJ','Djibouti','people-and-society',247,'Population: 337,386 (July 1990), growth
rate 2 6% (1990)
Birth rate: 43 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 119 deaths/1,000
live births (1990)
Life expectancy at birth: 46 years male,
49 years female (1990)
Total fertility rate: 6 4 children born/
woman (1990)
Nationality: noun—Dyiboutian(s), adjec-
tive—Dyiboutian
Ethnic divisions: 60% Somali (Issa); 35%
Afar, 5% French, Arab, Ethiopian, and
Italian
Religion: 94% Muslim, 6% Christian
Language: French (official), Arabic, So-
mah, and Afar widely used
Literacy: 20%
Labor force: NA, but a small number of
semiskilled laborers at the port and 3,000
railway workers, 52% of population of
working age (1983)
Organized labor: 3,000 railway workers','7ac0df5c79dbda896b7d307b6d56e1bb1643dd93dab15506dc0064839c785340','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7666e5a7cf7cf9d08af33d9ea46a18efd8e7fa4572ed9b58e3a293800305b417',1990,'DM','Dominica','people-and-society',252,'Population: 84,854 (July 1990), growth
rate 1 7% (1990)
Birth rate: 26 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: —4 migrants/1,000
population (1990)
Infant mortality rate: 13 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
79 years female (1990)
Total fertility rate: 2 6 children born/
woman (1990)
Nationality: noun—Domunican(s), adjec-
tive—Dominican
Ethnic divisions: mostly black, some Carib
indians
Religion: 80% Roman Catholic, Anglican,
Methodist
84
Approved for Release: 2020/08/12 C06554432
Language: English (official), French patois
widely spoken
Literacy: 80% (est )
Labor force: 25,000, 40% agriculture, 32%
industry and commerce, 28% services
(1984)
Organized labor: 25% of labor force','c82144787b21e39f4e738dd2e2b8284bbeb90fa4e4d820ad1faf4fadd5d94536','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c42b14c98ec8ed390ed20ee63ca9fe61e5738d24b8c59010d24e8da92c144b6c',1990,'DO','Dominican Republic','people-and-society',257,'Population: 7,240,793 (July 1990), growth
rate 2 0% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: — 1 migrant/1,000
population (1990)
Infant mortality rate: 62 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
69 years female (1990)
Total fertility rate: 3 2 children born/
woman (1990)
Nationality: noun—Domunican(s), adjec-
tive—Dominican
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 74%
Labor force: 2,300,000-2,600,000, 49%
agriculture, 33% services, 18% industry
(1986)
Organized labor: 12% of labor force (1989
est )','9edd4f5d225870c1c71d2f551cc8450688cb007e33e6df01e518f744d8d99750','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccc25f7e5fcab1c560307660a337ec7734b14d3cd1c10cd1b73e45d6992ad86e',1990,'EG','Egypt','people-and-society',265,'Population: 54,705,746 (July 1990),
growth rate 2 5% (1990)
Birth rate: 34 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 90 deaths/1,000 live
births (1990)
Life expectancy at birth: 60 years male,
61 years female (1990)
Total fertility rate: 47 children born/
woman (1990)
Nationality: noun—Egyptian(s), adjec-
tive—Egyptian
Ethnic divisions: 90% Eastern Hamitic
stock, 10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim
(mostly Sunni), 6% Coptic Christian and
other
Language: Arabic (official), English and
French widely understood by educated
classes
Literacy: 45%
Labor force: 15,000,000 (1989 est ), 36%
government, public sector enterprises, and
armed forces, 34% agriculture, 20% pri-
vately owned service and manufacturing
enterprises (1984), shortage of skilled la-
bor, 2,500,000 Egyptians work abroad,
mostly in Iraq and the Gulf Arab states
(1988 est )
Organized labor: 2,500,000 (est )
Population: 5,309,865 (July 1990), growth
rate 2 0% (1990)
Birth rate: 34 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —7 migrants/1,000
population (1990)
Infant mortality rate: 49 deaths/1,000 live
births (1990)
Life expectancy at birth: 62 years male,
68 years female (1990)
Total fertility rate: 4 1 children born/
woman (1990)
Nationality: noun—Salvadoran(s), adjec-
tive—Salvadoran
Ethnic divisions: 89% mestizo, 10% In-
dian, 1% white
Religion: about 97% Roman Catholic,
with activity by Protestant groups
throughout the country
Language: Spanish, Nahua (among some
Indians)
Literacy: 65%
Labor force: 1,700,000 (1982 est ); 40%
agriculture, 16% commerce, 15% manu-
facturing, 13% government, 9% financial
services, 6% transportation, shortage of
skilled labor and a large pool of unskilled
labor, but manpower training programs
improving situation (1984 est )
Organized labor: 15% total labor force,
10% agricultural labor force, 7% urban
labor force (1987 est )','3fd3c8e973c3e568d26fd26858ea1e944da2d8be4d8440a378a8af70953b2ba5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a085831ddf170108b877ed761a074f17c364a6e067246b129c5b911c4ac9710f',1990,'GA','Gabon','people-and-society',271,'Population: 368,935 (July 1990), growth
rate 2 6% (1990)
Birth rate: 43 births/1,000 population
(1990)
Death rate: 16 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 118 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
52 years female (1990)
Total fertility rate: 5 5 children born/
woman (1990)
Nationality: noun—Equatorial Guinean(s)
or Equatoguinean(s), adjective—Equato-
rial Guinean or Equatoguinean
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernandinos,
Rio Muni, primarily Fang, less than 1,000
Europeans, mostly Spanish
Religion: natives all nominally Christian
and predominantly Roman Catholic, some
pagan practices retained
Language: Spanish (official), pidgin En-
glish, Fang, Bubi, Ibo
Literacy: 40%
Labor force: 172,000 (1986 est ), 66% ag-
riculture, 23% services, 11% industry
(1980), labor shortages on plantations,
58% of population of working age (1985)
Organized labor: no formal trade unions
Population: 1,068,240 (July 1990), growth
rate 0 8% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/ 1,000
population (1990)
Infant mortality rate: 106 deaths/1,000
live births (1990)
Life expectancy at birth: 50 years male,
56 years female (1990)
Total fertility rate: 4 0 children born/
woman (1990)
Nationality: noun—Gabonese (sing , pl ),
adjective—Gabonese
Ethnic divisions: about 40 Bantu tribes,
including four major tribal groupings
(Fang, Eshira, Bapounou, Bateke), about
100,000 expatriate Africans and Europe-
ans, including 27,000 French
107
Approved for Release: 2020/08/12 C06554432
Gabon (continued)
Religion: 55-75% Christian, less than 1%
Muslim, remainder animist
Language: French (official), Fang, Myene,
Bateke, Bapounou/Eschira, Bandjabi
Literacy: 61 6%
Labor force: 120,000 salaried, 65 0% agri-
culture, 30 0% industry and commerce,
2 5% services, 2 5% government, 58% of
population of working age (1983)
Organized labor: there are 38,000 mem-
bers of the national trade union, the Ga-
bonese Trade Union Confederation
(COSYGA)
Population: 848,147 (July 1990), growth
rate 3 1% (1990)
Birth rate: 48 births/1,000 population
(1990)
Death rate: 18 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 140 deaths/1,000
live births (1990)
Life expectancy at birth: 46 years male,
50 years female (1990)
Total fertility rate: 6 5 children born/
woman (1990)
Nationality: noun—Gambuan(s), adjec-
tive—Gambian
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: 99% African (42% Man-
dinka, 18% Fula, 16% Wolof, 10% Jola,
9% Serahuli, 4% other), 1% non-Gambian
Religion: 90% Muslim, 9% Christian, 1%
indigenous beliefs
Language: English (official), Mandinka,
Wolof, Fula, other indigenous vernaculars
Literacy: 25 1%
Labor force: 400,000 (1986 est ), 75 0%
agriculture, 18 9% industry, commerce,
and services, 6 1% government, 55% popu-
lation of working age (1983)
Organized labor: 25-30% of wage labor
force
Population: 615,575 (July 1990), growth
rate 3 2% (1990); in addition, there are
2,500 Jewish settlers in the Gaza Strip
Birth rate: 47 births/1,000 population
(1990)
Death rate: 7 deaths/ 1,000 population
(1990)
Net migration rate: —7 migrants/1,000
population (1990)
Infant mortality rate: 55 deaths/1,000 live
births (1990)
Life expectancy at birth: 63 years male,
66 years female (1990)
Total fertility rate: 7 0 children born/
woman (1990)
Nationality: NA
Ethnic divisions: 99 8% Palestinian Arab
and other, 0 2% Jewish
Religion: 99% Muslim (predominantly
Sunni), 0 7% Christian, 0 3% Jewish
Language: Arabic, Israel settlers speak
Hebrew, English widely understood
Literacy: NA%
Labor force: (excluding Israeli Jewish set-
tlers) 32 0% small industry, commerce and
business, 24 4% construction, 25 5% ser-
vice and other, and 18 1% agriculture
(1984)
Organized labor: NA
Population: 16,307,170 (July 1990),
growth rate —0 6% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 12 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/ 1,000
population (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 71 years male,
77 years female (1990)
Total fertility rate: 1 7 children born/
woman (1990)
Nationality: noun—German(s), adjyective—
German
Ethnic divisions: 99 7% German, 0 3%
Slavic and other
Religion: 47% Protestant, 7% Roman
Catholic, 46% unaffiliated or other, less
than 5% of Protestants and about 25% of
Roman Catholics active participants
Language: German
Literacy: 99%
Labor force: 8,960,000, 37 5% industry,
21 1% services, 10 8% agriculture and for-
estry, 10 3% commerce, 7 4% transport
and communications, 6 6% construction,
3 1% handicrafts, 3 2% other (1987)
Organized labor: 87 7% of labor force','2de8345ccc7730fbae78afb652bb76659a4d01116e89e2a1a4f1994bef37bc70','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10929f2ddfcb72d9cd616a94d3a0d58233b7c5774762ed79f94e5e7952fda046',1990,'ET','Ethiopia','people-and-society',277,'Population: 51,666,622 (July 1990),
growth rate 3 5% (1990)
Birth rate: 45 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 5 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 116 deaths/1,000
live births (1990)
Life expectancy at birth: 49 years male,
52 years female (1990)
Total fertility rate: 7 0 children born/
woman (1990)
Nationality: noun—Ethiopian(s), adjec-
tive—Ethiopian
Ethnic divisions: 40% Oromo, 32% Am-
hara and Tigrean, 9% Sidamo, 6%
Shankella, 6% Somali, 4% Afar, 2% Gur-
age, 1% other
Religion: 40-45% Muslim, 35-40% Ethio-
pian Orthodox, 15-20% animist, 5% other
Language: Amharic (official), Tigrinya,
Orominga, Arabic, English (major foreign
language taught in schools)
Literacy: 55 2%
Labor force: 18,000,000, 80% agriculture
and animal husbandry, 12% government
and services, 8% industry and construction
(1985)
Organized labor: All Ethiopian Trade
Union formed by the government in Janu-
ary 1977 to represent 273,000 registered
trade union members','ac8edbbeacf9f91189d3d34589844e107f36e471861c45d8014051db130005f9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d215a842905376f7fb737b92b3013de5b20aaf7f4b3694d0347c55dd2d36398a',1990,'FR','France','people-and-society',280,'Population: 1,958 (July 1990), growth rate
0 5% (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/ 1,000
population (1990)
Infant mortality rate: NA deaths/1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: NA children born/
woman (1990)
Nationality: noun—Falkland Islander(s),
adyjective—Falkland Island
Ethnic divisions: almost totally British
Religion: primanly Anglican, Roman
Catholic, and United Free Church, Evan-
gelist Church, Jehovah’s Witnesses, Lu-
theran, Seventh-Day Adventist
Language: English
Literacy: NA%, but compulsory education
up to age 15
Labor force: 1,100 (est ), about 95% in
agriculture, mostly sheepherding
Organized labor: Falkland Islands General
Employees Union, 400 members
Population: 56,358,331 (July 1990),
growth rate 0 4% (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
82 years female (1990)
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Frenchman(men),
Frenchwoman(women), adjective—French
Ethnic divisions: Celtic and Latin with
Teutonic, Slavic, North African, Indochi-
nese, and Basque minorities
Religion: 90% Roman Catholic, 2% Prot-
estant, 1% Jewish, 1% Muslim (North Af-
rican workers), 6% unaffiliated
Language: French (100% of population),
rapidly declining regional dialects (Pro-
vencal, Breton, Alsatian, Corsican, Cata-
lan, Basque, Flemish)
Literacy: 99%
Labor force: 24,170,000, 61 5% services,
31 3% industry, 7 3% agriculture (1987)
Organized labor: 20% of labor force (est )
Population: 210 (July 1990), growth rate
0 00% (1990), mostly researchers
Population: 2,187,275 (July 1990), growth
rate 2 7% (1990)
Birth rate: 35 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 50 deaths/1,000 live
births (1990)
Life expectancy at birth: 62 years male,
67 years female (1990)
Total fertility rate: 4 7 children born/
woman (1990)
Nationality: noun—Mongolian(s), adjec-
tive—Mongolhian
Ethnic divisions: 90% Mongol, 4% Ka-
zakh, 2% Chinese, 2% Russian, 2% other
210
Approved for Release: 2020/08/12 C06554432
Religion: predominantly Tibetan Buddhist,
about 4% Muslim, limited religious activ-
ity because of Communist regime
Language: Khalkha Mongol used by over
90% of population, minor languages 1n-
clude Turkic, Russian, and Chinese
Literacy: 80% (est ), 100% claimed (1985)
Labor force: NA, but primarily agricul-
tural, over half the adult population 1s in
the labor force, including a large percent-
age of women, shortage of skilled labor
Organized labor: 425,000 members of the
Central Council of Mongolian Trade
Unions (CCMTVU) controlled by the gov-
ernment (1984)
Population: 112,646 (July 1990), growth
rate 1 4% (1990)
Birth rate: 27 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: —8 migrants/ 1,000
population (1990)
Infant mortality rate: 32 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
72 years female (1990)
Total fertility rate: 29 children born/
woman (1990)
Nationality: noun—St Vincentian(s) or
Vincentian(s), adyectives—St Vincentian
or Vincentian
269
Approved for Release: 2020/08/12 C06554432
St. Vincent and the Grenadines
(continued)
Ethnic divisions: mainly of black African
descent, remainder mixed, with some
white, East Indian, Carib Indian
Religion: Anglican, Methodist, Roman
Catholic, Seventh-Day Adventist
Language: English, some French patois
Literacy: 82%
Labor force: 67,000 (1984 est )
Organized labor: 10% of labor force
Population: 1,058,122 (July 1990), growth
rate 2 6% (1990), in addition, there are
70,000 Jewish settlers in the West Bank
and 110,000 in East Jerusalem (1989 est )
Birth rate: 37 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: —5 migrants/1,000
population (1990)
Infant mortality rate: 48 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
68 years female (1990)
Total fertility rate: 5 0 children born/
woman (1990)
Nationality: NA
Ethnic divisions: 88% Palestinian Arab
and other, 12% Jewish
Religion: 80% Muslim (predominantly
Sunn), 12% Jewish, 8% Christian and
other
Language: Arabic, Israeli settlers speak
Hebrew, English widely understood
Literacy: NA%
Labor force: NA; excluding Israeli Jewish
settlers—29 8% small industry, commerce,
and business, 24 2% construction, 22 4%
agriculture, 23 6% service and other
(1984)
Organized labor: NA','8c10b4df94fb2d357eb81d4d13b19559fce3025de804e6e5feb8e82782d3dde9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c912648fc3b5842ec7f52dd52e492a1715fa4dc1311442dfc228cbb7211d1f74',1990,'FO','Faroe Islands','people-and-society',285,'Population: 47,715 (July 1990), growth
rate 0 9% (1990)
Birth rate: 17 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
81 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
97
Approved for Release: 2020/08/12 C06554432
Faroe Islands (continued)
Nationality: noun—Faroese (sing , pl ),
adjective—Faroese
Ethnic divisions: homogeneous Scandina-
vian population
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585, largely engaged in
fishing, manufacturing, transportation,
and commerce
Organized labor: NA
Population: 759,567 (July 1990), growth
rate 1 5% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: —7 migrants/1,000
population (1990)
Infant mortality rate: 22 deaths/1,000 live
births (1990)
Life expectancy at birth: 66 years male,
70 years female (1990)
Total fertility rate: 3 3 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Fyian(s), adyective—
Fijian
Ethnic divisions: 49% Indian, 46% Fijian,
5% European, other Pacific Islanders,
overseas Chinese, and others
Religion: Fiyyians are mainly Christian,
Indians are Hindu with a Mushim minor-
ity
Language: English (offictal), Fijian, Hin-
dustani
Literacy: 80%
Labor force: 176,000, 60% subsistence
agriculture, 40% wage earners (1979)
Organized labor: about 45,000 employees
belong to some 46 trade unions, which are
organized along lines of work and ethnic
origin (1983)','9597cb078d3d8d1171ca2279cf66a28866fbb6781431924d2142d464249885aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73b9bfb0309b93d75e5bf8a5972623975287e9e1653b932b60b5b96514ae277e',1990,'FI','Finland','people-and-society',290,'Population: 4,977,325 (July 1990), growth
rate 0 3% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 71 years male,
80 years female (1990)
Total fertility rate: 1 7 children born/
woman (1990)
Nationality: noun—Finn(s), adjective—
Finnish
Ethnic divisions: Finn, Swede, Lapp,
Gypsy, Tatar
Religion: 97% Evangelical Lutheran, 1 2%
Eastern Orthodox, | 8% other
Language: 93 5% Finnish, 6 3% Swedish
(both official), small Lapp- and Russian-
speaking minorities
Literacy: almost 100%
Labor force: 2,556,000, 33 1% services,
22 9% mining and manufacturing, 13 8%
commerce, 10 3% agriculture, forestry,
and fishing, 7 2% construction, 7 1%
transportation and communications (1989
est )
Organized labor: 80% of labor force','684aa80b16219d93ee884fecc863b5f0aba054e19f738c90153501c1dea0d609','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ed1bf568611e8a00e96ff2fa88621e9d7447efb7c9bbf75a11892f38736fde',1990,'GF','French Guiana','people-and-society',298,'Population: 97,781 (July 1990), growth
rate 3 4% (1990)
Birth rate: 29 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 10 migrants/1,000
population (1990)
Infant mortality rate: 19 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
76 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Nationality: noun—French Guianese
(sing , pl ), adyective—French Guiana
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: 66% black or mulatto,
12% Caucasian, 12% East Indian, Chi-
nese, Amerindian, 10% other
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 23,265, 60 6% services, gov-
ernment, and commerce, 2! 2% industry,
18 2% agriculture (1980)
Organized labor: 7% of labor force','ba6ca68772e122d70ea10f2779b7c17810db7160b1ec86e4f99cf9a881b4503e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0366f565cd87f6776a4b0d26b4e374c1dc25fbfaaa7c9468bca4062c485c921',1990,'PF','French Polynesia','people-and-society',303,'Population: 190,181 (July 1990), growth
rate 2 5% (1990)
Birth rate: 31 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 23 deaths/1,000 live
births (1990)
Life expectancy at birth: 66 years male,
71 years female (1990)
Total fertility rate: 3 9 children born/
woman (1990)
Nationality: noun—French Polynesian(s),
adyective—French Polynesian
Ethnic divisions: 78% Polynesian, 12%
Chinese, 6% local French, 4% metropoli-
tan French
105
Approved for Release: 2020/08/12 C06554432
French Polynesia (continued)
Religion: mainly Christian, 55% Protes-
tant, 32% Roman Catholic
Language: French (official), Tahitian
Literacy: NA%
Labor force: 57,863 employed (1983)
Organized labor: NA','19be9b361ecab5300e0939cfbcdd97e606b24acc5d2d92ab3f5d0bb22ed38aa4','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71e04f0e249e010cf9c01e4a816d1e4a83eb1a91df8749c379b6119242b5ddaf',1990,'RO','Romania','people-and-society',310,'Population: 62,168,200 (July 1990),
growth rate 0 5% (1990)
Birth rate: 11 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Net migration rate: 5 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
81 years female (1990)
Total fertility rate: 1 4 children born/
woman (1990)
Nationality: noun—German(s), adjective—
German
Ethnic divisions: primarily German, Dan-
ish minority
Religion: 45% Roman Catholic, 44% Prot-
estant, 11% other
Language: German
Literacy: 99%
Labor force: 27,790,000, 41 6% industry,
35 4% services and other, 18 2% trade and
transport, 4 8% agriculture (1987)
Organized labor: 9,300,000 total,
7,760,000 in German Trade Union Feder-
ation (DGB), union membership consti-
tutes about 40% of union-eligible labor
force, 34% of total labor force, and 35%
of wage and salary earners (1986)
Population: 23,273,285 (July 1990),
growth rate 0 5% (1990)
Birth rate: 16 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: — 1 migrants/1,000
population (1990)
Infant mortality rate: 19 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
75 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Romanian(s), adjec-
tive—Romanian
Ethnic divisions: 89 1% Romanian, 7 8%
Hungarian, 1 5% German, | 6% Ukrai-
nian, Serb, Croat, Russian, Turk, and
Gypsy
Religion: 80% Romanian Orthodox, 6%
Roman Catholic, 4% Calvinist, Lutheran,
Jewish, Baptist
Language: Romanian, Hungarian, Ger-
man
Literacy: 98%
Labor force: 10,690,000, 34% industry,
28% agriculture, 38% other (1987)
Organized labor: until December 1989, a
single trade union system organized by
the General Confederation of Romanian
Trade Unions (UGSR) under control of
the Communist Party, since Ceausescu’s
overthrow, newly-created trade and pro-
fessional trade unions are joining two rival
umbrella organizations—Organization of
Free Trade Unions and Fratia (Brother-
hood)','c35bfbc789d736c4e5eb31fbc6019b31cb3fc57974a8f0e210e3542ca9824cd2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1633e973c51b45cf9b372d8edfd0a5d7b59daf907f66407cb4cc5100b6f2217',1990,'GH','Ghana','people-and-society',314,'Population: 15,165,243 (July 1990),
growth rate 3 2% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate: — 1 migrant/1,000
population (1990)
Infant mortality rate: 89 deaths/1,000 live
births (1990)
Life expectancy at birth: 52 years male,
56 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 6 4 children born/
woman (1990)
Nationality: noun—Ghanaian(s), adjec-
tive—Ghanaian
Ethnic divisions: 99 8% black African
(major tribes—44% Akan, 16% Moshi-
Dagomba, 13% Ewe, 8% Ga), 0 2% Euro-
pean and other
Religion: 38% indigenous beliefs, 30%
Muslim, 24% Christian, 8% other
Language: English (official), African lan-
guages include Akan, Moshi-Dagomba,
Ewe, and Ga
Literacy: 53 2%
Labor force: 3,700,000, 54 7% agriculture
and fishing, 18 7% industry, 15 2% sales
and clerical, 7 7% services, transportation,
and communications, 3 7% professional,
48% of population of working age (1983)
Organized labor: 467,000 (about 13% of
labor force)','0db48edc86b77c67305d8d6ae516d194f41652a8fe51b152f6f085bbc2710339','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a034a6b5226a04ee59d7e2e8ad05ce629d6d9ae8f560d4a8622d5006ee2c9564',1990,'GI','Gibraltar','people-and-society',319,'Population: 29,572 (July 1990), growth
rate 0 1% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: —8 migrants/1,000
population (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 2 4 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Gibraltarian, adjec-
tive—Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8%
Church of England, 2 25% Jewish
Language: English and Spanish are pri-
mary languages, Italian, Portuguese, and
Russian also spoken, English used in the
schools and for official purposes
Literacy: 99% (est )
Labor force: about 14,800 (including non-
Gibraltar laborers), UK military establish-
ments and civil government employ nearly
50% of the labor force
Organized labor: over 6,000
Population: uninhabited
Population: 25,648,241 (July 1990),
growth rate 2 2% (1990)
Birth rate: 31 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: —1 migrants/1,000
population (1990)
Infant mortality rate: 78 deaths/1,000 live
births (1990)
Life expectancy at birth: 63 years male,
66 years female (1990)
Total fertility rate: 4.0 children born/
woman (1990)
Nationality: noun—Moroccan(s), adjec-
tive—Moroccan
Ethnic divisions: 99 1% Arab-Berber, 0 7%
non-Moroccan, 0 2% Jewish
Religion: 98 7% Muslim, | 1% Christian,
0 2% Jewish
Language: Arabic (official), several Berber
dialects, French 1s language of business,
government, diplomacy, and postprimary
education
Literacy: 28%
Labor force: 7,400,000, 50% agriculture,
26% services, 15% industry, 9% other
(1985)
Orgamized labor: about 5% of the labor
force, mainly in the Unton of Moroccan
Workers (UMT) and the Democratic Con-
federation of Labor (CDT)
Population: 39,268,715 (July 1990),
growth rate 0 3% (1990)
Birth rate: 11 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
82 years female (1990)
Total fertility rate: 1 4 children born/
woman (1990)
Nationality: noun—Spaniard(s), adjec-
tive—Spanish
Ethnic divisions: composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other
sects
Language: Castilian Spanish, second lan-
guages include 17% Catalan, 7% Galician,
and 2% Basque
Literacy: 97%
Labor force: 14,621,000, 53% services,
24% industry, 14% agriculture, 9% con-
struction (1988)
Organized labor: less 10% of labor force
(1988)
Population: no permanent inhabitants,
garrisons','e93eaa84aca81d90f594bd7084156282af1d60eb7fdccdd6714fca2d46c13b0c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c462fb958efdd41423e087d2ea6be02e4b8bcc4bc20a767d0ee7e098ccb21c14',1990,'GR','Greece','people-and-society',324,'Population: 10,028,171 (July 1990),
growth rate 0 2% (1990)
Birth rate: 11 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
80 years female (1990)
Total fertility rate: 1 5 children born/
woman (1990)
Nationality: noun—Greek(s), adyective—
Greek
Ethnic divisions: Greek 98%, others 2%,
note—the Greek Government states there
are no ethnic divisions in Greece
Religion: 98% Greek Orthodox, 1 3%
Muslim, 0 7% other
Language: Greek (official), English and
French widely understood
Literacy: 95%
Labor force: 3,860,000, 43% services, 27%
agriculture, 20% manufacturing and min-
ing, 7% construction (1985)
Organized labor: 10-15% of total labor
force, 20-25% of urban labor force
Population: 23,841,608 (July 1990),
growth rate 0 6% (1990)
Birth rate: 15 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
344
Approved for Release: 2020/08/12 C06554432
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 22 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
76 years female (1990)
Total fertility rate: 1 9 children born/
woman (1990)
Nationality: noun—Yugoslav(s), adjec-
tive—Yugoslav
Ethnic divisions: 36 3% Serb, 19 7% Croat,
8 9% Muslim, 7 8% Slovene, 7 7% Alba-
nian, 5 9% Macedonian, 5 4% Yugoslav,
2 5% Montenegrin, 1 9% Hungarian, 3 9%
other (1981 census)
Religion: 50% Eastern Orthodox, 30% Ro-
man Catholic, 9% Muslim, 1% Protestant,
10% other
Language: Serbo-Croatian, Slovene, Ma-
cedonian (all official), Albanian, Hungar-
lan
Literacy: 90 5%
Labor force: 9,600,000, 22% agriculture,
27% mining and manufacturing, about 5%
of labor force are guest workers in West-
ern Europe (1986)
Organized labor: 6,200,000 members in
the Confederation of Trade Unions of Yu-
goslavia (SSJ)
Population: 36,589,468 (July 1990),
growth rate 3 3% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate; NEGL migrants/
1,000 population (1990)
Infant mortality rate: 103 deaths/1,000
live births (1990)
Life expectancy at birth: 51 years male,
55 years female (1990)
Total fertility rate: 6 2 children born/
woman (1990)
Nationality: noun—Zairian(s), adjective—
Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu, four larg-
est tribes—Mongo, Luba, Kongo (all
Bantu), and the Mangbetu-Azande (Ha-
mitic) make up about 45% of the popula-
tion
Religion: 50% Roman Catholic, 20% Prot-
estant, 10% Kimbanguist, 10% Muslim,
10% other syncretic sects and traditional
beliefs
Language: French (official), Lingala, Swa-
hil, Kingwana, Kikongo, Tshiluba
Literacy: 55% males, 37% females
Labor force: 15,000,000, 75% agriculture,
13% industry, 12% services, 13% wage
earners (1981), 51% of population of work-
ing age (1985)
Organized labor: National Union of
Workers of Zaire (UNTZA) 1s the only
trade union','f47a4951caf51784de928737d5524758c606780f87882a61b856f662e58888aa','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ca9d571470ecdf00f03930a70163595c6aa335c5f236f7b938a700c71f2b2aa',1990,'GL','Greenland','people-and-society',329,'Population: 56,078 (July 1990), growth
rate 1 2% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 28 deaths/1,000 live
births (1990)
120
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 62 years male,
68 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Greenlander(s), adjec-
trve—Greenlandic
Ethnic divisions: 86% Greenlander (Es-
kimos and Greenland-born Caucasians),
14% Danish
Religion: Evangelical Lutheran
Language: Eskimo dialects, Danish
Literacy: 99%
Labor force: 22,800, largely engaged in
fishing, hunting, sheep breeding
Organized labor: NA','dbc828e0650fe888d4f095af3680f763016c2fdb30282ec1b34d6b46424a55d9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d572fa1fa2755fb000d51b6a1b671df907cbd1239e23f4c6cdf72f13a781a46d',1990,'GD','Grenada','people-and-society',334,'Population: 84,135 (July 1990), growth
rate —0 4% (1990)
Birth rate: 36 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: — 33 migrants/1,000
population (1990)
Infant mortality rate: 30 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
74 years female (1990)
Total fertility rate: 4 9 children born/
woman (1990)
Nationality: noun—Grenadian(s), adjec-
tive—Grenadian
Ethnic divisions: mainly of black African
descent
Religion: largely Roman Catholic, Angli-
can, other Protestant sects
Language: English (official), some French
patois
Literacy: 85%
Labor force: 36,000, 31% services, 24%
agriculture, 8% construction, 5% manufac-
turing, 32% other (1985)
Organized labor: 20% of labor force','cbe0eab827a44b012378cb450afdb03db00ab0bcb8a61a4fb618c751392b37e7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b038511b6fc95062fba0e7e6932d65376b3dcf6c2e29035a94bf1b86ef00ed6',1990,'GP','Guadeloupe','people-and-society',339,'Population: 342,175 (July 1990), growth
rate 0 8% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/1,000
population (1990)
Infant mortality rate: 17 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
77 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
Nationality: noun—Guadeloupian(s), ad-
jective—Guadeloupe
Ethnic divisions: 90% black or mulatto,
5% white, less than 5% East Indian, Leba-
nese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000, 53 0% services, gov-
ernment, and commerce, 25 8% industry,
21 2% agriculture
Organized labor: 11% of labor force','314f1456666085c20efe9b9712c2171b00418dbb3a381506e920deea027ead0f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c93d81818dd940ff53269942605bbc0eb4b994a8cdfd58307ca06a5018de0711',1990,'GU','Guam','people-and-society',343,'Population: 141,039 (July 1990), growth
rate 2 8% (1990)
Birth rate: 26 births/1,000 population
(1990)
Death rate: 4 deaths/1,000 population
(1990)
124
Approved for Release: 2020/08/12 C06554432
Net migration rate: 5 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 12 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
75 years female (1990)
Total fertility rate: 3 0 children born/
woman (1990)
Nationality: noun—Guamanian(s), adjec-
trve—Guamanian
Ethnic divisions: 47% Chamorro, 25% Fili-
pino, 10% Caucasian, 18% Chinese, Japa-
nese, Korean, and other
Religion: 98% Roman Catholic, 2% other
Language: English and Chamorro, most
residents bilingual, Japanese also widely
spoken
Literacy: 90%
Labor force: 54,000, 42% government,
58% private (1988)
Organized labor: 13% of labor force','0edd09bc134c049e0242777894483543bd172eb2ac775226890017537d57cf1b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7670f1bf4b0fba65030dd5fe5a7ccfdab0b422d8107a353a822b035e5b207e01',1990,'GT','Guatemala','people-and-society',348,'Population: 9,097,636 (July 1990), growth
rate 2 6% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: —3 migrants/1,000
population (1990)
Infant mortality rate: 61 deaths/1,000 live
births (1990)
Life expectancy at birth: 60 years male,
65 years female (1990)
Total fertility rate: 5 1 children born/
woman (1990)
Nationality: noun—Guatemalan(s), adjec-
tive—Guatemalan
Ethnic divisions: 56% Ladino (mestizo—
mixed Indian and European ancestry),
44% Indian
Religion: predominantly Roman Catholic,
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks an Indian language as a
primary tongue (18 Indian dialects, in-
cluding Quiche, Cakchiquel, Kekch1)
Literacy: 50%
Labor force: 2,500,000, 57 0% agriculture,
14 0% manufacturing, 13 0% services,
7 0% commerce, 4 0% construction, 3 0%
transport, 0 8% utilities, 0 4% mining
(1985)
Organized labor: 8% of labor force (1988
est )','afc73f7a46cad78c3f59b8fa7088f7262a290632c6e15788ddec79080426f67d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d34adfc428a105693d2718882978119597dbca1f20993c1ebf1f22276d5578a',1990,'GG','Guernsey','people-and-society',353,'Population: 57,227 (July 1990), growth
rate 0 7% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 6 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 1 6 children born/
woman (1990)
Nationality: noun—Channel Islander(s),
adjective—Channel Islander
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: UK and Norman-French
descent
Religion: Anglican, Roman Catholic, Pres-
byterian, Baptist, Congregational, Meth-
odist
Language: English, French,
Norman-French dialect spoken in country
districts
Literacy: NA%, but universal education
Labor force: NA
Organized labor: NA','4a07e190d637758bee4d2f2829f730660f63e8d1200eea36a5afd9970f46faeb','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('837699eaaea7e96f391642b9459e9b9625de8d546d08e76a802fdacd69e23164',1990,'GN','Guinea','people-and-society',357,'Population: 7,269,240 (July 1990), growth
rate 2 6% (1990)
Birth rate: 47 births/1,000 population
(1990)
Death rate: 22 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 147 deaths/1,000
live births (1990)
Life expectancy at birth: 40 years male,
44 years female (1990)
Total fertility rate: 6 1 children born/
woman (1990)
128
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Guinean(s),
adjective—Guinean
Ethnic divisions: Fulani, Malinke, Sousou,
15 smaller tribes
Religion: 85% Muslim, 5% indigenous be-
hefs, 1 5% Christian
Language: French (official), each tribe has
its own language
Literacy: 20% in French, 48% in local lan-
guages
Labor force: 2,400,000 (1983), 82 0% agni-
culture, 11 0% industry and commerce,
5 4% services, 88,112 civil servants (1987),
52% of population of working age (1985)
Organized labor: virtually 100% of wage
earners loosely affiliated with the National
Confederation of Guinean Workers
Population: 190,136,221 (July 1990),
growth rate 1 8% (1990)
Birth rate: 27 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 75 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 58 years male,
63 years female (1990)
Total fertility rate: 3 1 children born/
woman (1990)
Nationality: noun—Indonesian(s), adjec-
tive—Indonesian
Ethnic divisions: majority of Malay stock
comprising 45 0% Javanese, 14 0% Sunda-
nese, 7 5% Madurese, 7 5% coastal Ma-
lays, 26 0% other
Religion: 88% Muslim, 6% Protestant, 3%
Roman Catholic, 2% Hindu, 1% other
Language: Bahasa Indonesia (modified
form of Malay, official), English and
Dutch leading foreign languages, local
dialects, the most widely spoken of which
is Javanese
Literacy: 62%
Labor force: 67,000,000, 55% agriculture,
10% manufacturing, 4% construction, 3%
transport and communications (1985 est )
Organized labor: 3,000,000 members
(claimed), about 5% of labor force
Population: 55,647,001 (July 1990),
growth rate 3 1% (1990)
Birth rate: 45 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: —5 migrants/ 1,000
population (1990)
Infant mortality rate: 91 deaths/1,000 live
births (1990)
Life expectancy at birth: 62 years male,
63 years female (1990)
Total fertility rate: 6 3 children born/
woman (1990)
Nationality: noun—Iranian(s), adjective—
Iranian
Ethnic divisions: 51% Persian, 25% Azer-
bayam, 9% Kurd, 8% Gilaki and Mazan-
daram, 2% Lur, 1% Baloch, 1% Arab, 3%
other
Religion: 95% Shi‘a Muslim, 4% Sunm
Mushim, 2% Zoroastrian, Jewish, Chris-
tian, and Baha’1
Language: 58% Persian and Persian dia-
lects, 26% Turkic and Turkic dialects, 9%
Kurdish, 2% Lun, 1% Baloch, 1% Arabic,
1% Turkish, 2% other
Literacy: 48% (est )
Labor force: 15,400,000, 33% agriculture,
21% manufacturing, shortage of skilled
labor (1988 est )
Organized labor: none
Population: 124,765 (July 1990), growth
rate 3 0% (1990)
Birth rate: 38 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 61 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
67 years female (1990)
Total fertility rate: 5 4 children born/
woman (1990)
Nationality: noun—Sao Tomean(s), adjec-
tive—Sao Tomean
Ethnic divisions: mestico, angolares (de-
scendents of Angolan slaves), forros (de-
scendents of freed slaves), servicais (con-
tract laborers from Angola, Mozambique,
and Cape Verde), tongas (children of ser-
Approved for Release: 2020/08/12 C06554432
vicais born on the islands), and Europeans
(primarily Portuguese)
Religion: Roman Catholic, Evangelical
Protestant, Seventh-Day Adventist
Language: Portuguese (official)
Literacy: 50% (est )
Labor force: 21,096 (1981), most of popu-
lation engaged 1n subsistence agriculture
and fishing, labor shortages on plantations
and of skilled workers, 56% of population
of working age (1983)
Organized labor: NA','acdcc92eb0e7730415a9f719127b89707c12181d52cad9e9314992bda2fb1922','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b97b06858fe68fe1882178d2bb801e2eca845f612be4183efa351c50e44371a',1990,'GW','Guinea-Bissau','people-and-society',360,'Population: 998,963 (July 1990), growth
tate 2 5% (1990)
Birth rate: 43 births/1,000 population
(1990)
Death rate: 19 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 127 deaths/ 1,000
live births (1990)
Life expectancy at birth: 44 years male,
48 years female (1990)
Total fertility rate: 5 9 children born/
woman (1990)
Nationality: noun—Guinea-Bissauan(s),
adjective—Guinea-Bissauan
Ethnic divisions: about 99% African (30%
Balanta, 20% Fula, 14% Manyaca, 13%
Mandinga, 7% Papel), less than 1% Euro-
pean and mulatto
Religion: 65% indigenous beliefs, 30%
Muslim, 5% Christian
Language: Portuguese (official), Criolo and
numerous African languages
Literacy: 34% (1986)
Labor force: 403,000 (est ), 90% agricul-
ture, 5% industry, services, and commerce,
5% government, 53% of population of
working age (1983)
Organized labor: only one trade union—
the National Union of Workers of
Guinea-Bissau (UNTG)
Population: 764,649 (July 1990), growth
rate —0 1% (1990)
Birth rate: 24 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: — 19 migrants/1,000
population (1990)
Infant mortality rate: 40 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 65 years male,
70 years female (1990)
Total fertility rate: 27 children born/
woman (1990)
Nationality: noun—Guyanese (sing , pl ),
adjyective—Guyanese
Ethnic divisions: 51% East Indian, 43%
black and mixed, 4% Amerindian, 2% Eu-
ropean and Chinese
Religion: 57% Christian, 33% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Literacy: 85%
Labor force: 268,000, 44 5% industry and
commerce, 33 8% agriculture, 21 7% ser-
vices, public-sector employment amounts
to 60-80% of the total labor force (1985)
Organized labor: 34% of labor force','6bdbfdd9e9fd78ef04689dc0259d3abe6ed9160d124ba2e59b7d9fe1b1d78f27','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b769ae81190c92c9bec6e1cfe23d9b0864b884c58869149f83421240af8338a1',1990,'HT','Haiti','people-and-society',365,'Population: 6,142,141 (July 1990), growth
rate 2 3% (1990)
Birth rate: 45 births/1,000 population
(1990)
Death rate: 16 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/1,000
population (1990)
Infant mortality rate: 107 deaths/ 1,000
hive births (1990)
Life expectancy at birth: 52 years male,
55 years female (1990)
Total fertility rate: 6 4 children born/
woman (1990)
Nationality: noun—Haitian(s), adjective—
Haitian
Ethnic divisions: 95% black, 5% mulatto
and European
Religion: 75-80% Roman Catholic (of
which an overwhelming majority also
practice Voodoo), 10% Protestant
Language: French (official) spoken by only
10% of population, all speak Creole
Literacy: 23%
Labor force: 2,300,000, 66% agriculture,
25% services, 9% industry, shortage of
skilled labor, unskilled labor abundant
(1982)
Organized labor: NA
Population: uninhabited','7a0d86c526c5da5774340be840160e2a4acbbd998e35a56f2860970806952fdc','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f0cd62f7175881ac2656856ac66729e8568a9aa8cd46138ae45bde377b7ce25',1990,'HN','Honduras','people-and-society',370,'Population: 5,259,699 (July 1990), growth
rate 3 0% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 62 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 64 years male,
67 years female (1990)
Total fertility rate: 4 8 children born/
woman (1990)
Nationality: noun—Honduran(s), adjec-
tive—Honduran
Ethnic divisions: 90% mestizo (mixed In-
dian and European), 7% Indian, 2% black,
1% white
Religion: about 97% Roman Catholic,
small Protestant minority
Language: Spanish, Indian dialects
Literacy: 56%
Labor force: 1,300,000, 62% agriculture,
20% services, 9% manufacturing, 3% con-
struction, 6% other (1985)
Organized labor: 40% of urban labor
force, 20% of rural work force (1985)','be428b12a0189c19e7b692e3dd3dbdea163318b3461603ebe7387fd7e5a71fcb','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef11afa06c3efad694c1c7a4f35b7ce2242fd90f1123a2fed9ae76f4ec2ddd3',1990,'HK','Hong Kong','people-and-society',376,'Population: 5,759,990 (July 1990), growth
rate 1 0% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/1!,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 76 years male,
82 years female (1990)
Total fertility rate: 1 4 children born/
woman (1990)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 90% eclectic mixture of local
religions, 10% Christian
Language: Chinese (Cantonese), English
Literacy: 75%
Labor force: 2,640,000, 35 8% manufac-
turing, 22 7% wholesale and retail trade,
restaurants and hotel, 17 1% services,
7 5% construction, 8 4% transport and
communications, 6 1% financing, insur-
ance, and real estate (1986)
Organized labor: 15% of labor force (1986)
Population: uninhabited
Note: American civilians evacuated in
1942 after Japanese air and naval attacks
during World War II, occupied by US
military during World War II, but aban-
doned after the war, public entry 1s by
special-use permit only and generally re-
stricted to scientists and educators
Approved for Release: 2020/08/12 C06554432
Population: no permanent population,
there 1s a small military garrison on South
Georgia and the British Antarctic Survey
286
has a biological station on Bird Island, the
South Sandwich islands are uninhabited
Population: 290,938,469 (July 1990),
growth rate 0 7% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 24 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
74 years female (1990)
Total fertility rate: 2 4 children born/
woman (1990)
Nationality: noun—Soviet(s), adjective—
Soviet
Ethnic divisions: Russian 50 78%, Ukrai-
nian 15 45%, Uzbek 5 84%, Byelorussian
3 51%, Kazakh 2 85%, Azerbaijan 2 38%,
Armenian | 62%, Tajik 1 48%, Georgian
1 39%, Moldavian | 17%, Lithuanian
1 07%, Turkmen 0 95%, Kirghiz 0 89%,
Latvian 0 51%, Estonian 0 36%, others
9 75%
Religion: 20% Russian Orthodox, 10%
Muslim, 7% Protestant, Georgian Ortho-
dox, Armeman Orthodox, and Roman
Catholic, less than 1% Jewish, 60% atheist
(est )
Language: Russian (official), more than
200 languages and dialects (at least 18
with more than | million speakers), 75%
Slavic group, 8% other Indo-European,
12% Altaic, 3% Uralian, 2% Caucasian
Literacy: 99%
Labor force: 152,300,000 civilians, 80%
industry and other nonagricultural fields,
20% agriculture, shortage of skilled labor
(1989)
Organized labor: 98% of workers are
union members, all trade unions are orga-
Approved for Release: 2020/08/12 C06554432
nized within the All-Union Central Coun-
cil of Trade Unions (AUCCTU) and con-
duct their work under guidance of the
Communist party','bd02817e45ee45436c0c6d197f8929d32d8fc9f21bc93aa4178f235216cec2a7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('870bb334a30841651c6dcbce6da88fe6e93f441ed62f935d4a22a0c08df5fc29',1990,'IS','Iceland','people-and-society',381,'Population: 257,023 (July 1990), growth
rate 1 1% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
80 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Icelander(s), adjec-
tive—Icelandic
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical Lutheran, 3%
other Protestant and Roman Catholic, 2%
no affiliation
Language: Icelandic
Literacy: 100%
Labor force: 134,429, 55 4% commerce,
finance, and services, 14 3% other manu-
facturing, 5 8% agriculture, 7 9% fish pro-
cessing, 5 0% fishing (1986)
Organized labor: 60% of labor force','efb85a8b58b21982b689fd3405d1fb62179e948a35fecf2affcd1c956a09bff4','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c123f350225f83ed52a5ebe995bf820118fca0458e413f92877b1b286701568',1990,'IQ','Iraq','people-and-society',393,'Population: 18,781,770 (July 1990),
growth rate 3 9% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 67 deaths/1,000 live
births (1990)
Life expectancy at birth: 66 years male,
68 years female (1990)
Total fertility rate: 7 3 children born/
woman (1990)
Nationality: noun—lIraqi(s), adjective—
Iraqi
Ethnic divisions: 75-80% Arab, 15-20%
Kurdish, 5% Turkoman, Assyrian or other
Religion: 97% Muslim (60-65% Shi‘a, 32-
37% Sunni), 3% Christian or other
Language: Arabic (official), Kurdish (of-
ficial in Kurdish regions), Assyrian, Arme-
nian
Literacy: 55-65% (1989 est )
Labor force: 3,400,000 (1984), 39% ser-
vices, 33% agriculture, 28% industry, se-
vere labor shortage (1987), expatriate la-
bor force about 1,000,000 (1989)
Organized labor: less than 10% of the la-
bor force
Population: uninhabited
Population: 3,500,212 (July 1990), growth
rate -0 4% (1990)
Birth rate: 15 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: — 10 migrants/1,000
population (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
Nationality: noun—Irishman(men), Irish
(collective pl ), adjectrve—Irish
Ethnic divisions: Celtic, with English mi-
nority
Religion: 94% Roman Catholic, 4% Anghi-
can, 2% other
Language: Irish (Gaelic) and English, En-
glish 1s the language generally used, with
Gaelic spoken in a few areas, mostly along
the western seaboard
Literacy: 99%
Labor force: 1,310,000, 57 3% services,
19 1% manufacturing and construction,
14 8% agriculture, forestry, and fishing
(1988)
Organized labor: 36% of labor force
Population: 4,409,218 (July 1990), growth
rate 1 5% (1989), includes 70,000 Jewish
settlers in the West Bank, 10,500 1n the
Israeli-occupied Golan Heights, 2,500 in
the Gaza Strip, and 110,000 in East Jeru-
salem (1989 est )
Birth rate: 22 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 9 deaths/1,000 live
births (July 1990)
Life expectancy at birth: 76 years male,
79 years female (July 1990)
Total fertility rate: 2 9 children born/
woman (1990)
Nationality: noun—Israeli(s), adjective—
Israeli
Ethnic divisions: 83% Jewish, 17% non-
Jewish (mostly Arab)
Religion: 83% Judaism, 13 1% Islam
(mostly Sunn: Muslim), 2 3% Christian,
1 6% Druze
Language: Hebrew (official), Arabic used
officially for Arab minority, English most
commonly used foreign language
Literacy: 88% Jews, 70% Arabs
Labor force: 1,400,000 (1984 est ), 29 5%
public services, 22 8% industry, mining,
and manufacturing, 12 8% commerce,
9 5% finance and business, 6 8% transport,
storage, and communications, 6 5% con-
struction and public works, 5 5% agricul-
ture, forestry, and fishing; 5 8% personal
and other services, 1 0% electricity and
water (1983)
Organized labor: 90% of labor force','231828e4a6f07eab6c04160f467c15b755f655995a23e41e70926c2ee37b7078','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ea82591c14585c6230e6fb2cb041d62b7bcd36264b673bfac85985f65f345e',1990,'IT','Italy','people-and-society',398,'Population: 57,664,405 (July 1990),
growth rate 0 2% (1990)
Birth rate: 10 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 1 migrant/1,000 popu-
lation (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
81 years female (1990)
Total fertility rate: 1 4 children born/
woman (1990)
Nationality: noun—Italian(s), adjective—
Italian
Ethnic divisions: primarily Italian but pop-
ulation includes small clusters of German-
,»French-, and Slovene-Italians in the north
and Albanian-Italians 1n the south, Sicil-
1ans, Sardinians
Religion: almost 100% nominally Roman
Catholic
Language: Italian, parts of Trentino-Alto
Adige region are predominantly German
speaking, significant French-speaking mi-
nority in Valle d’Aosta region, Slovene-
speaking minority in the Trieste-Gorizia
area
Literacy: 93%
Labor force: 23,670,000, 56 7% services,
37 9% industry, 5 4% agriculture (1987)
Organized labor: 40-45% of labor force
(est )
Population: 12,478,024 (July 1990),
growth rate 4 0% (1990)
Birth rate: 48 births/1,000 population
(1990)
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate: 4 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 100 deaths/1,000
live births (1990)
Life expectancy at birth: 52 years male,
56 years female (1990)
Total fertility rate: 6 9 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—lIvorian(s), adjective—
Ivonan
Ethnic divisions: over 60 ethnic groups;
most important are the Baoule 23%, Bete
18%, Senoufou 15%, Malinke 11%, and
Agm, about 2 million foreign Africans,
mostly Burkinabe, about 130,000 to
330,000 non-Africans (30,000 French and
100,000 to 300,000 Lebanese)
Religion: 63% indigenous, 25% Muslim,
12% Christian
Language: French (official), over 60 native
dialects, Dioula most widely spoken
Literacy: 42 7%
Labor force: 5,718,000, over 85% of popu-
lation engaged 1n agriculture, for estry,
livestock raising, about 11% of labor force
are wage earners, nearly half in agricul-
ture and the remainder in government,
industry, commerce, and professions, 54%
of population of working age (1985)
Organized labor: 20% of wage labor force','0b351becc68217466d00a27033863c4e03fd719f557a756e8cc635ea4f29b1c1','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63436d3f2317e24fa99dbe0b609161a1ec3de438f070cb6fd3033a8cb55412e9',1990,'JM','Jamaica','people-and-society',403,'Population: 2,441,396 (July 1990), growth
rate 0 6% (1990)
Birth rate: 21 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: —10 migrants/ 1,000
population (1990)
Infant mortality rate: 16 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
79 years female (1990)
Total fertility rate: 2 3 children born/
woman (1990)
Nationality: noun—Jamaican(s), adjec-
tive—Jamaican
Ethnic divisions: 76 3% African, 15 1%
Afro-European, 3 4% East Indian and
Afro-East Indian, 3 2% white, 1 2% Chi-
nese and Afro-Chinese, 0 8% other
Religion: predominantly Protestant (in-
cluding Anglican and Baptist), some Ro-
man Catholic, some spiritualist cults
Language: English, Creole
Literacy: 74%
Labor force: 728,700; 32% agriculture,
28% industry and commerce, 27% ser-
vices, 13% government, shortage of techni-
cal and managerial personnel (1984)
Organized labor: 25% of labor force (1989)
Population: no permanent inhabitants','fa30d9c008b5bcc12dab1ff6b038b153685cab8ee7027c2d5dd010000d7ecf26','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70236d9f6ced3ff8bae956ded2fac4571da1ab8ac943a2be06ae7139b69cf168',1990,'JP','Japan','people-and-society',408,'Population: 123,642,461 (July 1990),
growth rate 0 4% (1990)
Birth rate: 11 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 5 deaths/1,000 live
births (1990)
Life expectancy at birth: 76 years male,
82 years female (1990)
Total fertility rate: 1 6 children born/
woman (1990)
Nationality: noun—Japanese (sing , pl ),
adjective—Japanese
Ethnic divisions: 99 4% Japanese, 0 6%
other (mostly Korean)
Religion: most Japanese observe both
Shinto and Buddhist rites, about 16% be-
long to other faiths, including 0 8% Chris-
tian
Language: Japanese
Literacy: 99%
Labor force: 63,330,000, 54% trade and
services, 33% manufacturing, mining, and
construction, 7% agriculture, forestry, and
fishing, 3% government (1988)
Organized labor: about 29% of employed
workers, 76 4% public service, 57 9%
transportation and telecommunications,
48 7% mining, 33 7% manufacturing,
18 2% services, 9 3% wholesale, retail, and
restaurant
Population: uninhabited
Note: Millersville settlement on western
side of island occasionally used as a
weather station from 1935 until World
War II, when it was abandoned, reoccu-
pied in 1957 during the International
Geophysical Year by scientists who left in
1958, public entry is by special-use permit
only and generally restricted to scientists
and educators
Population: 21,292,649 (July 1990),
growth rate 1 7% (1990)
Birth rate: 22 births/1,000 population
(1990)
Death rate: 5 deaths/ 1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 27 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
75 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism,
religious activities now almost nonexistent
Language: Korean
Literacy: 95% (est )
Labor force: 9,615,000, 36% agricultural,
64% nonagricultural, shortage of skilled
and unskilled labor (mid-1987 est )
Organized labor: 1,600,000 members,
single-trade union system coordinated by
the General Federation of Trade Unions
of Korea under the Central Committee
Population: 43,045,098 (July 1990),
growth rate 0 8% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 6 deaths/!,000 population
(1990)
Net migration rate: — 1 migrants/1,000
population (1990)
Infant mortality rate: 23 deaths/1,000 live
births (1990)
Life expectancy at birth: 66 years male,
73 years female (1990)
Total fertility rate: 1 6 children born/
woman (1990)
Nationality: noun—Korean(s), adjective—
Korean
Ethnic divisions: homogeneous, small Chi-
nese minority (about 20,000)
Religion: strong Confucian tradition, vig-
orous Christian minority (28% of the total
population), Buddhism, pervasive folk reli-
gion (Shamanism), Chondokyo (religion of
the heavenly way), eclectic religion with
nationalist overtones founded in 19th cen-
tury, claims about 1 5 million adherents
Language: Korean, English widely taught
in high school
Literacy: over 90%
Labor force: 16,900,000, 52% services and
other, 27% mining and manufacturing,
21% agriculture, fishing, forestry (1987)
Organized labor: about 10% of nonagricul-
tural labor force in government-sanctioned
unions','c535c9754cc49cac7f56f8918e5f198fea9115027824f937af13701ab8724cb0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5064dfe60b43ebb897ce7c3de39ad2a082609dac774e7324b530ec69debaa6fb',1990,'JE','Jersey','people-and-society',413,'Population: 83,609 (July 1990), growth
rate 0 9% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 7 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 1 3 children born/
woman (1990)
Nationality: noun—Channel Isiander(s),
adyective—Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religion: Anglican, Roman Catholic, Bap-
tist, Congregational New Church, Meth-
odist, Presbyterian
Language: English and French (official),
with the Norman-French dialect spoken in
country districts
Literacy: NA%, but probably high
Labor force: NA
Organized labor: none
Population: 1,203 (December 1989), all
US government personnel and contractors','eafdb303042e1f9d1d4c76a54bcc26636f054d075b6487634bf1a3f6a7ae527b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f5d8edba33b0023d6946913cd2368605a04fb1853ffe05f5b72b0035c54dc53',1990,'JO','Jordan','people-and-society',418,'Population: 3,064,508 (July 1990), growth
rate 3 6% (1990)
Birth rate: 42 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 55 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
71 years female (1990)
Total fertility rate: 6 2 children born/
woman (1990)
Nationality: noun—Jordanian(s), adjec-
tive—Jordanian
Ethnic divisions: 98% Arab, 1% Circas-
sian, 1% Armenian
Religion: 92% Sunm Muslim, 8% Chris-
tian
Language: Arabic (official), English widely
understood among upper and middle
classes
Literacy: 71% (est )
Labor force: 572,000 (1988), 20% agricul-
ture, 20% manufacturing and mining
(1987 est )
Organized labor: about 10% of labor force
Note: 1 5-1 7 million Palestinians live on
the East Bank (55-60% of the population),
most are Jordaman citizens
Population: uninhabited','f0694e74afc71d34fa7bc5243592a55754720fa4657e335b7375c0a8e0c3a21e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e29fca599ec9523d57666e88de41a17393afca6342b3c45cb54540fd00b17de',1990,'KE','Kenya','people-and-society',423,'Population: 24,639,261 (July 1990),
growth rate 3 8% (1990)
Birth rate: 45 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 60 deaths/1,000 live
births (1990)
Life expectancy at birth: 62 years male,
67 years female (1990)
Total fertility rate: 6 5 children born/
woman (1990)
Nationality: noun—Kenyan(s), adjective—
Kenyan
Ethnic divisions: 21% Kikuyu, 14% Luhya,
13% Luo, 11% Kalenyin, 11% Kamba, 6%
Kisn, 6% Meru, 1% Asian, European, and
Arab
Religion: 38% Protestant, 28% Roman
Catholic, 26% indigenous beliefs, 6%
Mushim
Language: English and Swahili (official),
numerous indigenous languages
Literacy: 59 2%
Labor force: 9,003,000, 78% agriculture,
22% nonagriculture (1987 est )
Organized labor: 390,000 (est )
Population: uninhabited','383d525d8023e5c4f1ef06faf0c92b5a44a36447fde5eb2f6045fa0ce19d4cf9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a213ddbe88c8e013537c6b73f5f634a7baecf6feebb13cc46a319fbf0e2d2716',1990,'KI','Kiribati','people-and-society',428,'Population: 70,012 (July 1990), growth
rate 1 7% (1990)
Birth rate: 34 births/1,000 population
(1990)
Death rate: 13 deaths/1,000 population
(1990)
Net migration rate: —5 migrants/ 1,000
population (1990)
Infant mortality rate: 65 deaths/ 1,000 live
births (1990)
Life expectancy at birth: 52 years male,
57 years female (1990)
Total fertility rate: 4 3 children born/
woman (1990)
Nationality: noun—Kiribatian(s), adjec-
tive—Kuiribati
169
Approved for Release: 2020/08/12 C06554432
Kiribati (continued)
Ethnic divisions: Micronesian
Religion: 48% Roman Catholic, 45% Prot-
estant (Congregational), some Seventh-
Day Adventist and Baha’)
Language: English (official), Gilbertese
Literacy: 90%
Labor force: 7,870 economically active
(1985 est )
Organized labor: Kiribati Trades Union
Congress—2,500 members','52c14e4d7f4587fbb7906807b098299179234813d0599adbd88f3c62c9a19634','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bce1ea14759dc40b32ec425bf66d3ed9becc9022ad884748327c62cb046ce92c',1990,'KW','Kuwait','people-and-society',435,'Population: 2,123,711 (July 1990), growth
rate 3 8% (1990)
Birth rate: 29 births/1,000 population
(1990)
Death rate: 2 deaths/1,000 population
(1990)
Net migration rate: 11 migrants/1,000
population (1990)
Infant mortality rate: 15 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
76 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 3 7 children born/
woman (1990)
Nationality: noun—Kuwaiti(s), adjecttrve—
Kuwaiti
Ethnic divisions: 27 9% Kuwaiti, 39%
other Arab, 9% South Asian, 4% Iranian,
20 1% other
Religion: 85% Muslim (30% Shi‘a, 45%
Sunni, 10% other), 15% Christian, Hindu,
Parsi, and other
Language: Arabic (official), English widely
spoken
Literacy: 71% (est.)
Labor force: 566,000 (1986), 45 0% ser-
vices, 20 0% construction, 12 0% trade,
8 6% manufacturing, 2 6% finance and
real estate, 1 9% agriculture, 1 7% power
and water, 1 4% mining and quarrying,
70% of labor force 1s non-Kuwaiti
Organized labor: labor unions exist in oil
industry and among government personnel
Population: 4,023,726 (July 1990), growth
rate 2 2% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 126 deaths/ 1,000
live births (1990)
Life expectancy at birth: 48 years male,
51 years female (1990)
Total fertility rate: 5 1 children born/
woman (1990)
Nationality: noun—Lao (sing , Lao or
Laotian), adjective—Lao or Laotian
175
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Laos (continued)
Ethnic divisions: 50% Lao, 15%
Phoutheung (Kha), 20% tribal Thai, 15%
Meo, Hmong, Yao, and other
Religion: 85% Buddhist, 15% animist and
other
Language: Lao (official), French, and En-
glish
Literacy: 85%
Labor force: 1-1 5 million, 85-90% 1n agri-
culture (est )
Organized labor: Lao Federation of Trade
Unions 1s subordinate to the Communist
party','b8eb8db0cdedf156633aeb81ac052b6ae75f1409df11f4edcebc3e95e1130556','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7345b566848eeb5b55bde779c98fd7fc36ddb7715ae562c0e7ba6b0750a789ee',1990,'LB','Lebanon','people-and-society',440,'Population: 3,339,331 (July 1990), growth
rate 1 3% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —8 migrants/1,000
population (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 49 deaths/1,000 live
births (1990)
Life expectancy at birth: 66 years male,
70 years female (1990)
Total fertility rate: 3 7 children born/
woman (1990)
Nationality: noun—Lebanese (sing , p! ),
adyective—Lebanese
Ethnic divisions: 93% Arab, 6% Armenian,
1% other
Religion: 75% Islam, 25% Christian,
NEGL% Judaism, 17 legally recognized
sects—4 Orthodox Christian (Armenian
Orthodox, Greek Orthodox, Nestorean,
Syriac Orthodox), 7 Uniate Christian (Ar-
menian Catholic, Caldean, Greek Catho-
lic, Maronite, Protestant, Roman Catho-
lic, Syrian Catholic), 5 Islam (Alawite or
Nusayri, Druze, Isma‘ilite, Shi‘a, Sunni),
and 1 Jewish
Language: Arabic and French (both of-
ficial), Armenian, English
Literacy: 75%
Labor force: 650,000, 79% industry, com-
merce, and services, 11% agriculture, 10%
goverment (1985)
Organized labor: 250,000 members (est )','5ab046b9a2c468ca5bed8181a9d347678eee06aeb508c808a23ca76d01077f31','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96f5073d4559a3522da9a88ab79c3168da77fee6743082a6874543bb29593800',1990,'LS','Lesotho','people-and-society',445,'Population: 1,754,664 (July 1990), growth
rate 2 6% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 80 deaths/1,000 live
births (1990)
Life expectancy at birth: 59 years male,
62 years female (1990)
Total fertility rate: 4 9 children born/
woman (1990)
Nationality: noun—Mosotho (sing ), Baso-
tho (pl ), adyective—Basotho
Ethnic divisions: 99 7% Sotho, 1,600 Euro-
peans, 800 Asians
Religion: 80% Christian, rest indigenous
beliefs
Language: Sesotho (southern Sotho) and
English (official), also Zulu and Xhosa
Literacy: 59% (1989)
Labor force: 689,000 economically active,
86 2% of resident population engaged in
subsistence agriculture, roughly 60% of
active male labor force works in South
Africa
Organized labor: there are two trade union
federations, the government favors forma-
tion of a single, umbrella trade union con-
federation','8dcbe18b907e806a928ae3ab9929c49fd2db4f9929e5cf9717336cedd9be7a50','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f67ce3fd0f29c04f0224c47ab6a99b46b2c54ee4fd91ee1dc4da4d9630964c9',1990,'LR','Liberia','people-and-society',450,'Population: 2,639,809 (July 1990), growth
rate 3 4% (1990)
Birth rate: 45 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 126 deaths/ 1,000
live births (1990)
Life expectancy at birth: 54 years male,
58 years female (1990)
Total fertility rate: 6 6 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Luiberian(s),
adjective—Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Gio, Kru,
Grebo, Mano, Krahn, Gola, Gbandi,
Loma, Kissi, Vat, and Bella, 5% descen-
dants of repatriated slaves known as
Americo-Liberians
Religion: 70% traditional, 20% Muslim,
10% Christian
Language: English (official), more than 20
local languages of the Niger-Congo lan-
guage group, English used by about 20%
Literacy: 35%
Labor force: 510,000, including 220,000
in the monetary economy, 70 5% agricul-
ture, 10 8% services, 4 5% industry and
commerce, 14 2% other, non-African for-
eigners hold about 95% of the top-level
management and engineering jobs, 52% of
population of working age
Organized labor: 2% of labor force','085ff8a1043aaa9c4f06dcdfdcf3971145dbe645d1af56c5413f8487b8cd8d47','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a83d85487fd91ba591f1daeffe0c2558d7fdd73b013e80e20d5c1c22f984aa90',1990,'LY','Libya','people-and-society',455,'Population: 4,221,141 (July 1990), growth
rate 3 1% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 64 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
70 years female (1990)
Total fertility rate: 5 2 children born/
woman (1990)
Nationality: noun—Libyan(s), adjective—
Libyan
Ethnic divisions: 97% Berber and Arab,
some Greeks, Maltese, Italians, Egyptians,
Pakistanis, Turks, Indians, and Tunisians
Religion: 97% Sunni Muslim
Language: Arabic, Italian and English
widely understood in major cities
Literacy: 50-60%
Labor force: 1,000,000, includes about
280,000 resident foreigners, 31% industry,
27% services, 24% government, 18% agri-
culture
Organized labor: National Trade Unions’
Federation, 275,000 members, General
Union for Oil and Petrochemicals, Pan-
Africa Federation of Petroleum Energy
and Allied Workers
Population: 8,095,492 (July 1990), growth
rate 2 2% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 40 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
70 years female (1990)
Total fertility rate: 4 0 children born/
woman (1990)
313
Approved for Release: 2020/08/12 C06554432
Tunisia (continued)
Nationality: noun—Tunisian(s),
adjective—Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Language: Arabic (official), Arabic and
French (commerce)
Literacy: 62% (est )
Labor force: 2,250,000, 32% agriculture,
shortage of skilled labor
Organized labor: about 360,000 members
claimed, roughly 20% of labor force, Gen-
eral Umon of Tunisian Workers (UGTT),
quasi-independent of Constitutional Dem-
ocratic Party
Population: 56,704,327 (July 1990),
growth rate 2 2% (1990)
Birth rate: 29 births/1,000 population
(1990)
Death rate: 8 deaths/1!,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 74 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
67 years female (1990)
Total fertility rate: 3 6 children born/
woman (1990)
Nationality: noun—Turk(s), adjective—
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Language: Turkish (official), Kurdish, Ara-
bic
Literacy: 70%
Labor force: 18,800,000, 56% agriculture,
30% services, 14% industry, about
1,000,000 Turks work abroad (1987)
Organized labor: 10-15% of labor force','55d2d42d890944c3a0cd9c5eab5e3276fc8feb1da01209318acb254913294ed5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0169af568a12ab82ee0657099ca9bceafbd3f8134ab70a0032825db04d8d04fa',1990,'LI','Liechtenstein','people-and-society',460,'Population: 28,292 (July 1990), growth
rate 0 7% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 1 migrant/1,000 popu-
lation (1990)
Infant mortality rate: 5 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
81 years female (1990)
Total fertility rate: 1 5 children born/
woman (1990)
Nationality: noun—Liechtensteiner(s), ad-
Jective—Liechtenstein
Ethnic divisions: 95% Alemannic, 5% Ital-
1an and other
Religion: 82 7% Roman Catholic, 7 1%
Protestant, 10 2% other
Language: German (official), Alemannic
dialect
Literacy: 100%
Approved for Release: 2020/08/12 C06554432
Labor force: 12,258; 5,078 forergn work-
ers (mostly from Switzerland and Austria),
54 4% industry, trade, and building,
41 6% services, 4 0% agriculture, fishing,
forestry, and horticulture
Organized labor: NA','41426a5ff39ceb87ae146cae459d59e91daeab9b85a41888122162cc6baeb46c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74750148fcc1e83142e502d8d9b9c656a760e78c22dc09e2596a7029e33ed461',1990,'LU','Luxembourg','people-and-society',464,'Population: 383,813 (July 1990), growth
rate 1 1% (1989)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 9 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/ 1,000 live
births (1990)
Life expectancy at birth: 72 years male,
80 years female (1990)
Total fertility rate: 1 5 children born/
woman (1990)
Nationality: noun—Luxembourger(s), ad-
Jective—Luxembourg
Ethnic divisions: Celtic base, with French
and German blend, also guest and worker
residents from Portugal, Italy, and Euro-
pean countries
185
Approved for Release: 2020/08/12 C06554432
Luxembourg (continued)
Religion: 97% Roman Catholic, 3% Prot-
estant and Jewish
Language: Luxembourgish, German,
French, many also speak English
Literacy: 100%
Labor force: 161,000, one-third of labor
force is foreign workers, mostly from Por-
tugal, Italy, France, Belgium, and FRG,
48 9% services, 24 7% industry, 13 2%
government, 8 8% construction, 4 4% agri-
culture (1984)
Organized labor: 100,000 (est ) members
of four confederated trade unions','8ba5e753403b8b5b264acbfa33dd67299754d165da7fb4ad76c6334466d3cf21','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f450ce8c7a9183159b121d1265bbe861f4dcf0d4c0a656e5af512ebc6e877763',1990,'NL','Netherlands','people-and-society',470,'Population: 441,691 (July 1990), growth
rate 1 1% (1990)
Birth rate: 16 births/1,000 population
(1990)
Death rate: 5 deaths/ 1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
79 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Macanese (sing and
pl ), adjective—Macau
Ethnic divisions: 95% Chinese, 3% Portu-
guese, 2% other
Approved for Release: 2020/08/12 C06554432
Religion: mainly Buddhist, 17,000 Roman
Catholics, of whom about half are Chi-
nese
Language: Portuguese (official), Cantonese
1s the language of commerce
Literacy: almost 100% among Portuguese
and Macanese, no data on Chinese popu-
lation
Labor force: 180,000 (1986)
Organized labor: none
Population: 14,936,032 (July 1990),
growth rate 0 6% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
81 years female (1990)
Total fertility rate: 1 6 children born/
woman (1990)
Nationality’ noun—Dutchman(men),
Dutchwoman(women), adjective—Dutch
Ethnic divisions 96% Dutch, 4% Moroc-
cans, Turks, and others (1988)
Religion: 36% Roman Catholic, 27% Prot-
estant, 4% other, 33% unaffiliated (1986)
Language. Dutch
Literacy: 99%
Labor force: 5,300,000, 50 1% services,
28 2% manufacturing and construction,
15 9% government, 5 8% agriculture
(1986)
Organized labor: 29% of labor force
Population: 183,503 (July 1990), growth
rate 0 2% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: — 11 migrants/ 1,000
population (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
79 years female (1990)
fotal fertility rate: 2 0 children born/
woman (1990)
Nationality: noun—Netherlands Antil-
ean(s), adjective—Netherlands Antillean
Ethnic divisions: 85% mixed African, re-
nainder Carib Indian, European, Latin,
ind Oriental
Religion: predominantly Roman Catholic,
Protestant, Jewish, Seventh-Day Adventist
Language: Dutch (official), Papiamento, a
Spanish-Portuguese-Dutch-English dialect
sredominates, English widely spoken,
Spanish
Literacy: 95%
Labor force: 89,000, 65% government,
28% industry and commerce (1983)
Organized labor: 60-70% of labor force
Sovernment
Long-form name: none
Type: part of the Dutch realm—full au-
onomy in internal affairs granted in 1954
Capital: Willemstad
Administrative divisions: none (part of the
Dutch realm)
Independence: none (part of the Dutch
‘ealm)
Constitution: 29 December 1954, Statute
of the Realm of the Netherlands, as
amended
Legal system: based on Dutch civil law
system, with some English common law
influence
National holiday: Queen’s Day, 30 April
‘1938)
Executive branch: Dutch monarch, gover-
aor, prime minister, vice prime minister,
Council of Ministers (cabinet)
Legislative branch: Parliament (Staten)
Judicial branch: Joint High Court of Jus-
tice
Leaders: Chief of State—Queen BEA-
TRIX Wilhelmina Armgard (since 30
April 1980), represented by Governor
General Jaime SALEH (since October
1989),
Head of Government—Prime Minister
Maria LIBERIA-PETERS (since 17 May
1988, previously served from September
1984 to November 1985)
Political parties and leaders: political par-
ties are indigenous to each island Cu-
racao—National People’s Party (NVP),
Maria Liberia-Peters, New Antilles Move-
ment (MAN), Domenico Felip Martina,
Democratic Party of Curacao (DP), Au-
gustus Diaz, Workers’ Liberation Front
(FOL), Wilson (Papa) Godett, Socialist
Independent (SI), George Hueck and Nel-
son Monte,
Bonaire—New Force, Rudy Ellis, Demo-
cratic Party of Bonaire (PDB), John Evert
(Jopie) Abraham,
Approved for Release: 2020/08/12 C06554432
Sint Maarten—Democratic Party of Sint
Maarten, Claude Wathey, Patriotic Move-
ment of Sint Maarten, Romeo Paplophlet,
Sint Eustatitus—Democratic Party of Sint
Eustatius, Albert K Van Putten, Wind-
ward Islands People’s Movement (WIPM),
Eric Henriquez,
Saba—Windward Islands People’s Move-
ment (WIPM Saba), Will Johnston, Saba
Democratic Labor Movement, Vernon
Hassell, Saba Unity Party, Carmen Sim-
monds
Suffrage: universal at age 18
Elections: Parliament—liast held on 22
November 1985 (next to be held Novem-
ber 1989), results—percent of vote by
party NA, seats—{22 total) PNP 6, MAN
4, DP-Curacao 3, DP-St Maarten 3, DP-
Bonaire 2, DP-St Eustatius 1, FOL 1,
UPB 1, WIPM 1, note—the government
of Prime Minister Maria Liberia-Peters 1s
a coalition of several parties
Communists: small leftist groups
Member of: EC (associate), INTERPOL,
associated with UN through the Nether-
lands, UPU, WMO
Diplomatic representation: as an autono-
mous part of the Netherlands, Nether-
lands Antillean interests in the US are
represented by the Netherlands, US—
Consul General Sharon P WILKINSON,
Consulate General at St Anna Boulevard
19, Willemstad, Curacao (mailing address
P O Box 158, Willemstad, Curacao),
telephone [599] (9) 613066
Flag: white with a horizontal blue stripe
in the center superimposed on a vertical
ted band also centered, five white five-
pointed stars are arranged 1n an oval pat-
tern in the center of the blue band, the
five stars represent the five main islands of
Bonaire, Curacao, Saba, Sint Eustatius,
and Sint Maarten','4f52dd803176172983fef8dc0a612ec69911eb357cb5f55d8c161b2cbd3791ce','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('074371f8bd48ffb37888c730e1efbeae280eeb536b834d36ac61e98ea46b630e',1990,'MW','Malawi','people-and-society',477,'Population: 9,157,528 (July 1990), growth
rate 1 8% (1990)
Birth rate: 52 births/1,000 population
(1990)
Death rate: 18 deaths/1,000 population
(1990)
Net migration rate: — 16 migrants/1,000
population (1990)
Infant mortality rate: 130 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
50 years female (1990)
Total fertility rate: 7 7 children born/
woman (1990)
Nationality: noun—Malawian(s), adjec-
tive—Malawian
190
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: Chewa, Nyanja, Tum-
buko, Yao, Lomwe, Sena, Tonga, Ngont,
Ngonde, Asian, European
Religion: 55% Protestant, 20% Roman
Catholic, 20% Muslim, traditional indige-
nous beliefs are also practiced
Language: English and Chichewa (official),
other languages important regionally
Literacy: 41 2%
Labor force: 428,000 wage earners, 43%
agriculture, 16% manufacturing, 15% per-
sonal services, 9% commerce, 7%
construction, 4% miscellaneous services,
6% other permanently employed (1986)
Organized labor: small minority of wage
earners are unionized
Note: there are 800,000 Mozambican ref-
ugees in Malawi (1989 est )','64ba897d037333aa209ff0982f7edaedd5aa24d919c301bc679db04711f91d0e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25065ed8e94d2245fd74e92e3f6635c912d1a488b5b4cd06c328c89721e6d288',1990,'MV','Maldives','people-and-society',483,'Population: 217,945 (July 1990), growth
rate 3 7% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 76 deaths/1,000 live
births (1990)
Life expectancy at birth: 60 years male,
65 years female (1990)
Total fertility rate: 6 6 children born/
woman (1990)
Nationality: noun—Maldivian(s), adjec-
tive—Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala,
script dertved from Arabic), English spo-
ken by most government officials
Literacy: 36%
Labor force: 66,000 (est ), 80% engaged in
fishing industry
Organized labor: none','7b42fc2dba0fe5638092ca1d016d3127e21eef7cd2dba8362275758b8cb0d283','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('500b0b6f554183a5b6a0a51a70562f6940a88cb22a41e86d3e1c302350b44a9a',1990,'ML','Mali','people-and-society',488,'Population: 8,142,373 (July 1990), growth
rate 2 3% (1990)
Birth rate: 51 births/1,000 population
(1990)
Death rate: 21 deaths/1,000 population
(1990)
Net migration rate: —7 migrants/1,000
population (1990)
Infant mortality rate: 116 deaths/1,000
hve births (1990)
Life expectancy at birth: 45 years male,
47 years female (1990)
Total fertility rate: 7 1 children born/
woman (1990)
Nationality: noun—Malian(s), adjective—
Malian
Ethnic divisions: 50% Mande (Bambara,
Malinke, Sarakole), 17% Peul, 12% Vol-
taic, 6% Songhai, 5% Tuareg and Moor,
10% other
Religion: 90% Muslim, 9% indigenous be-
hefs, 1% Christian
Language: French (official), Bambara spo-
ken by about 80% of the population, nu-
merous African languages
Literacy: 18%
Labor force: 2,666,000 (1986 est ), 80%
agriculture, 19% services, 1% industry and
commerce (1981), 50% of population of
working age (1985)
Organized labor: National Union of Ma-
han Workers (UNTM) is umbrella organi-
zation for over 13 national untons','b14a20729631b4444047dd8d6e12f88e7334369fa46caa4c7cb2fe1cb66a67e3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8ff0d08a48c041171eb1591af656da416393d78905a3677956553096749d340',1990,'MT','Malta','people-and-society',492,'Population: 353,465 (July 1990), growth
rate 0 9% (1990)
Birth rate: 15 births/1,000 population
(1990)
Death rate: 8 deaths/1!,000 population
(1990)
Net migration rate: 1 migrant/1,000 popu-
lation (1990)
Infant mortality rate: 8 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
78 years female (1990)
Total fertility rate: 2 0 children born/
woman (1990)
Nationality: noun—Maltese (sing and pl ),
adjective— Maltese
196
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, English
Religion: 98% Roman Catholic
Language: Maltese and English (official)
Literacy: 83%
Labor force: 125,674, 30% services, 24%
manufacturing, 21% government (except
Job corps), 8% construction, 5% utilities
and drydocks, 4% agriculture (1987)
Organized labor: about 40% of labor force
Population: 64,859 (July 1990), growth
rate 0 2% (1990)
Birth rate: 11 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 5 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Manxman, Manxwo-
man, adjective—Manx
Ethnic divisions: native Manx of Norse-
Celtic descent, British
Religion: Anglican, Roman Catholic,
Methodist, Baptist, Presbyterian, Society
of Friends
Language: English, Manx Gaelic
Literacy: NA%, but compulsory education
between ages of 5 and 15
Labor force: 25,864 (1981)
Organized labor: 22 labor unions
patterned along British lines','b06b2d64073efec16dfaffd773ac4d16f3f15ef234e056fbf61d57bf1273eb8b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f4d4340e9e3a8b50905b999e3a549f3121dffe406318989d120c882ed97caad',1990,'MH','Marshall Islands','people-and-society',497,'Population: 43,417 (July 1990), growth
rate 3 2% (1990)
Birth rate: 39 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: —1 migrant/!,000
population (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 43 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
75 years female (1990)
Total fertility rate: 5 9 children born/
woman (1990)
Nationality: noun—Marshallese, adjec-
tive—Marshallese
Ethnic divisions: almost entirely Microne-
sian
Religion: predominantly Christian, mostly
Protestant
Language: English universally spoken and
1s the official language, two major Mar-
shallese dialects from Malayo-Polynesian
family, Japanese
Literacy: 90%
Labor force: 4,800 (1986)
Organized labor: none
Population: 195 (January 1990), no indige
nous inhabitants, temporary population
consists of 11 US Aur Force personnel, 27
US civilians, and 151 Thai contractors
Note: population peaked about 1970 with
over 1,600 persons during the Vietnam
conflict','0540962983d263c5951801e24ec67411acb5074e68fe5612b4ed7fc8c0654f94','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('123f709de263054eff9a31c3a479489bb21bf91ef581101713eb0202e5a10dd5',1990,'MQ','Martinique','people-and-society',502,'Population: 340,381 (July 1990), growth
rate 0 9% (1990)
Birth rate: 19 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: — 3 migrants/1,000
population (1990)
Infant mortality rate: 1] deaths/1,000 live
births (1990)
Life expectancy at birth: 71 years male,
77 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
199
Approved for Release: 2020/08/12 C06554432
Le Vauclin
Martinique (continued)
Nationality: noun—Martiniquais (sing
and pl ), adjective—Martiniquais
Ethnic divisions: 90% African and
African-Caucasian-Indian mixture, 5%
Caucasian, less than 5% East Indian, Leb-
anese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000, 31 7% service indus-
try, 29 4% construction and public works,
13 1% agriculture, 7 3% industry, 2 2%
fisheries, 16 3% other
Organized labor: 11% of labor force','3199a2682bf729fa7eb765bc0ff319f6ca316fdf87eb64b29a4167e42fa52c34','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da2e3219c57bd011bda28b8b34e5dec1e57b364bf0f510442cd407f830b4dea',1990,'MR','Mauritania','people-and-society',507,'Population: 1,934,549 (July 1990), growth
rate 3 1% (1990)
Birth rate: 49 births/!,000 population
(1990)
Death rate: 18 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 96 deaths/1,000 live
births (1990)
Life expectancy at birth: 44 years male,
49 years female (1990)
Total fertility rate: 7 3 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Mauritanian(s), adjec-
tive—Mauritanian
Ethnic divisions: 40% mixed Maur/black,
30% Maur, 30% black
Religion: nearly 100% Muslim
Language: Hasaniya Arabic (national),
French (official), Toucouleur, Fula, Sara-
kole, Wolof
Literacy: 17%
Labor force: 465,000 (1981 est ), 45,000
wage earners (1980), 47% agriculture, 29%
services, 14% industry and commerce,
10% government, 53% of population of
working age (1985)
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers’
Union','3a909850ff79157b1744a6d03928384d85a06ed1b7c8e4aa906e2b8da9fb6fea','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93032ca87bae248d4735878635ef79d9be882bac021caff4a55f066243f84051',1990,'YT','Mayotte','people-and-society',512,'Population: 72,186 (July 1990), growth
rate 3 9% (1990)
Birth rate: 51 births/1,000 population
(1990)
Death rate: 12 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 89 deaths/1,000 live
births (1990)
Life expectancy at birth: 54 years male,
58 years female (1990)
Total fertility rate: 6 8 children born/
woman (1990)
Nationality: noun—Mahorais (sing , pl ),
adjective—Mahoran
204
Approved for Release: 2020/08/12 C06554432
Religion: 99% Muslim, remainder Chris-
tian, mostly Roman Catholic
Language: Mahorian (a Swahili dialect),
French
Literacy: NA%, but probably high
Labor force: NA
Organized labor’ NA','d2021a7ecdb0addffaa4262a751bd849096b4571ca78552c3f8bca0f4a094d98','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00599ae831e6f38c9abb7334c567684e80bc636ef260bb9c4fed2c54bed1e2f3',1990,'MX','Mexico','people-and-society',516,'Population: 87,870,154 (July 1990),
growth rate 2 2% (1990)
Birth rate: 29 births/ 1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: —2 migrants/1,000
population (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 33 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
76 years female (1990)
Total fertility rate: 3 4 children born/
woman (1990)
Nationality: noun—Mexican(s),
adyective—Mexican
Ethnic divisions: 60% mestizo
(Indian-Spanish), 30% Amerindian or pre-
dominantly Amerindian, 9% white or pre-
dominantly white, 1% other
Religion: 97% nominally Roman Catholic,
3% Protestant
Language: Spanish
Literacy: 88%
Labor force: 26,100,000 (1988), 31 4%
services, 26% agriculture, forestry, hunt-
ing, and fishing, 13 9% commerce, 12 8%
manufacturing, 9 5% construction, 4 8%
transportation, 1 3% mining and quarry-
ing, 0 3% electricity, (1986)
Organized labor: 35% of labor force
Population: 250,410,000 (July 1990),
growth rate 0 9% (1990)
Birth rate: 15 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
80 years female (1990)
Total fertility rate: 1 9 children born/
woman (1990)
Nationality: noun—American(s), adjec-
tive—American
Ethnic divisions: 85% white, 12% black,
3% other (1985)
Religion: Protestant 61% (Baptist 21%,
Methodist 12%, Lutheran 8%, Presbyte-
rian 4%, Episcopalian 3%, other Protes-
tant 13%), Roman Catholic 25%, Jewish
2%, other 5%, none 7%
Language: predominantly English, sizable
Spanish-speaking minority
Literacy: 99%
Labor force: 125,557,000 (includes armed
forces and unemployed), civilian labor
force 123,869,000 (1989)
Organized labor: 16,960,000 members,
16 4% of labor force (1989)','29f43a61f6acae95918db099e6246bb4bbb5ba931af222153a6cfbf311d53a16','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d5b7a8fa2201ad708d3675aac4856096dc31e69f73edecc4bb06ad074fb96a',1990,'FM','Micronesia, Federated States of','people-and-society',520,'Population: 104,937 (July 1990), growth
rate 2 6% (1990)
Birth rate: 34 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: — 2 migrants/1,000
population (1990)
Infant mortality rate: 26 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
73 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 5 0 children born/
woman (1990)
Nationality: noun—Micronesian(s), adjec-
tive—Micronesian, Kosrae(s),
Pohnpeian(s), Trukese, Yapese
Ethnic divisions: nine ethnic Micronesian
and Polynesian groups
Religion: predominantly Christian, divided
between Roman Catholic and Protestant,
other churches include Assembly of God,
Jehovah’s Witnesses, Seventh-Day Ad-
ventist, Latter Day Saints, and the Baha’i
Faith
Language: English is the official and com-
mon language, most indigenous languages
fall within the Austronesian language
family, the exceptions are the Polynesian
languages, major indigenous languages are
Trukese, Pohnpeian, Yapese, and Kosrean
Literacy: NA%, but education compulsory
through eight grades
Labor force: NA, two-thirds are govern-
ment employees, 45,000 people are be-
tween the ages of 15 and 65
Organized labor: NA
Population: 453 US military personnel
(1989)','6cb07656fc9d061beb6c71d6741c9ea1476d0ed6906fe9ba4f592f17455c9cae','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27aa86267449c5a6bcf78e66b47e0960cdc4efe4165e8f18e75d736ed7015e2d',1990,'MC','Monaco','people-and-society',525,'Population: 29,453 (July 1990), growth
rate 0 9% (1990)
Birth rate: 7 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 9 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
80 years female (1990)
Total fertility rate: 1 2 children born/
woman (1990)
Nationality: noun—Monacan(s) or Mone-
gasque(s), adjective—Monacan or Mone-
gasque
Ethnic divisions: 47% French, 16% Mone-
gasque, 16% Italian, 21% other
Religion: 95% Roman Catholic
Language: French (official), English, Ital-
ian, Monegasque
Literacy: 99%
Labor force: NA
Approved for Release: 2020/08/12 C06554432
Organized labor: 4,000 members in 35
unions','cc5297ca66de688d9a7fb70440b4ea7117422a8d62e33396b5f376cdfb58314e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b3754a27684130e8ae29938ab54901c39776ea200d69760f5ed9d98d453113c',1990,'MS','Montserrat','people-and-society',530,'Population: 12,467 (July 1990), growth
rate 0 3% (1990)
Birth rate: 16 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: —4 migrant/!,000
population (1990)
Infant mortality rate: 9 deaths/!,000 live
births (1990)
Life expectancy at birth: 74 years male,
80 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Montserratian(s), ad-
jJective—Montserratian
Ethnic divisions: mostly black with a few
Europeans
Religion: Anglican, Methodist, Roman
Catholic, Pentecostal, Seventh-Day Ad-
ventist, other Christian denominations
Language: English
211
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Montserrat (continued)
Literacy: 77%
Labor force: 5,100, 40 5% community,
social, and personal services, 13 5% con-
struction, 12 3% trade, restaurants, and
hotels, 10 5% manufacturing, 8 8% agri-
culture, forestry, and fishing, 14 4% other
(1983 est )
Organized labor: 30% of labor force, three
trade unions with 1,500 members (1984
est )','2d230e24a8d76eec3b4595412446784d891264c0645e3bb8a40c3d40c3c89ba2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d3ec8b2875b59eadacff689fe2891d6d4c87e3fae0ee77896cb9d24decb09fe',1990,'NA','Namibia','people-and-society',537,'Population: | 452,951 (July 1990), growth
rate 5 6% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 20 migrants/ 1,000
population (1990)
215
Approved for Release: 2020/08/12 C06554432
Namibia (continued)
Infant mortality rate: 71 deaths/1,000 live
births (1990)
Life expectancy at birth: 57 years male,
63 years female (1990)
Total fertility rate: 6 6 children born/
woman (1990)
Nationality: noun—Namibian(s), adjec-
tive—Namibian
Ethnic divisions: 86% black, 6 5% white,
7 5% mixed, about 50% of the population
belong to the Ovambo tribe and 9% from
the Kavangos tribe
Religion: predominantly Christian
Language: Afrikaans principal language of
about 60% of white population, German
of 33%, and English of 7% (all official),
several indigenous languages
Literacy: 100% whites, 16% nonwhites
Labor force: 500,000, 60% agriculture,
19% industry and commerce, 8% services,
7% government, 6% mining (1981 est )
Organized labor: 15 trade unions—largest
is the mineworkers’ union which has a
sizable black membership
Population: 9,202 (July 1990), growth rate
1 5% (1990)
Birth rate: 20 births/1,000 population
(1990)
Death rate: 5 deaths/ 1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 41 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
69 years female (1990)
Total fertility rate: 2 3 children born/
woman (1990)
Nationality: noun—Nauruan(s), adjec-
tive—Nauruan
Ethnic divisions: 58% Nauruan, 26% other
Pacific Islander, 8% Chinese, 8% Euro-
pean
Approved for Release: 2020/08/12 C06554432
Religion: Christian (two-thirds Protestant,
one-third Roman Catholic)
Language: Nauruan, a distinct Pacific Is-
land language (official), English widely
understood, spoken, and used for most
government and commercial purposes
Literacy: 99%
Labor force: NA
Organized labor: NA
Population: uninhabited, transient Haitian
fishermen and others camp on the island','2b83e1df4ea846663759cb8dacd46f0552c83386d8288158cdb2f7c9c9fcdfe0','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e3097c0981cd282c7a6c155f8ced291bf11eaf5c210da4a095a9cfca836dc8',1990,'NP','Nepal','people-and-society',542,'Population: 19,145,800 (July 1990),
growth rate 2 4% (1990)
Birth rate. 39 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 99 deaths/1,000 live
births (1990)
Life expectancy at birth: 50 years male,
50 years female (1990)
Total fertility rate: 5 6 children born/
woman (1990)
Birétnagar
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Nepalese (sing and
pl ), adjective—Nepalese
Ethnic divisions: Newars, Indians, Tibet-
ans, Gurungs, Magars, Tamangs, Bhotias,
Rais, Limbus, Sherpas, as well as many
smaller groups
Religion: only official Hindu state in
world, although no sharp distinction be-
tween many Hindu (about 88% of popula-
tion) and Buddhist groups, small groups of
Muslims and Christians
Language: Nepali (official), 20 languages
divided into numerous dialects
Literacy: 20%
Labor force: 4,100,000, 93% agriculture,
5% services, 2% industry, severe lack of
skilled labor
Organized labor: Teachers’ Union, not of-
ficially recognized','1a708be3961d507903458bae72f5d5f0460f5cb4e58ed3e2d815e4bd24fd1f98','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6287966fb52433aac92b4949d8c38e310835ad81ed5e237117badd3a13a70381',1990,'NC','New Caledonia','people-and-society',547,'Population: 153,215 (July 1990), growth
rate 1 1% (1990)
Birth rate: 24 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —7 migrants/ 1,000
population (1990)
Infant mortality rate: 39 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
71 years female (1990)
Total fertility rate: 3 0 children born/
woman (1990)
Nationality: noun—New Caledonian(s),
adjective—New Caledonian
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: Melanesian 42 5%, Euro-
pean 37 1%, Wallisian 8 4%, Polynesian
3 8%, Indonesian 3 6%, Vietnamese | 6%,
other 3 0%
Religion: over 60% Roman Catholic, 30%
Protestant, 10% other
Language: French, Melanesian-Polynesian
dialects
Labor force: 50,469, foreign workers for
plantations and mines from Wallis and
Futuna, Vanuatu, and French Polynesia
(1980 est )
Organized labor: NA','9f8123f6ee5065025d0a68cb2f8041443887da9fd029c3fe97684662b4d6a9b6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e7c5de8e63f0afd0c9c9eeb5728cfa3be2de4fe3a40a7eeaa872ae6d6d12a70',1990,'NZ','New Zealand','people-and-society',551,'Population: 3,295,866 (July 1990), growth
rate 0 4% (1990)
Birth rate: 16 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: — 3 migrant/1,000
population (1990)
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
225
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
New Zealand (continued)
Total fertility rate: 2 0 children born/
woman (1990)
Nationality: noun—New Zealander(s), ad-
jective—New Zealand
Ethnic divisions: 88% European, 8 9%
Maoni, 2 9% Pacific Islander, 0 2% other
Religion: 81% Christian, 18% none or un-
specified, 1% Hindu, Confucian, and other
Language: English (official), Maor
Literacy: 99%
Labor force: 1,591,900, 67 4% services,
19 8% manufacturing, 9 3% primary pro-
duction (1987)
Organized labor: 681,000 members, 43%
of labor force (1986)
Population: 101,313 (July 1990), growth
rate 0 9% (1990)
Birth rate: 27 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —11 migrants/1,000
population (1990)
Infant mortality rate: 24 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
70 years female (1990)
Total fertility rate: 3 9 children born/
woman (1990)
310
Nationality: noun—Tongan(s), adjective—
Tongan
Ethnic divisions: Polynesian, about 300
Europeans
Religion: Christian, Free Wesleyan
Church claims over 30,000 adherents
Language: Tongan, English
Literacy: 90-95%, compulsory education
for children ages 6 to 14
Labor force: NA, 70% agriculture, 600
engaged in mining
Organized labor: none
Population: 14,910 (July 1990), growth
rate 3 0% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 8 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 32 deaths/1,000
population (1990)
Life expectancy at birth: 69 years male,
70 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Nationality: noun—Wallisian(s), Futu-
nan(s), or Wallis and Futuna Islanders,
adjective—Wallisian, Futunan, or Wallis
and Futuna Islander
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: almost entirely Polyne-
sian
Religion: largely Roman Catholic
Language: French, Wallisian (indigenous
Polynesian language)
Literacy: NA%
Labor force: NA
Organized labor: NA','7be7beb7c6e67238c3735e09498278ad1f95c7a7f15824426c8dadb2da807f1e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9227d6c1270a0db956a60899f5800498d6064cb2205c7218344560a9b9266f8',1990,'NI','Nicaragua','people-and-society',556,'Population: 3,722,683 (July 1990), growth
rate 2 8% (1990)
Birth rate: 40 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: — 3 migrants/1,000
population (1990)
Infant mortality rate: 68 deaths/1,000 live
births (1990)
Life expectancy at birth: 61 years male,
62 years female (1990)
Total fertility rate: 5 0 children born/
woman (1990)
Nationality: noun—Nicaraguan(s), adyec-
tive—Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian
Religion: 95% Roman Catholic, 5% Prot-
estant
Language: Spanish (official), English- and
Indian-speaking minorities on Atlantic
coast
Literacy: 88% (1981)
Labor force: 1,086,000, 43% service, 44%
agriculture, 13% industry (1986)
Organized labor: 35% of labor force','bd83985ac77d372a56452141557d63f01454104b54865fc79767614c2b58255e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c02f566ec4cc1c1c6db9fad35012ebb7208b77a61ca37be1fef005479ee225d1',1990,'NE','Niger','people-and-society',561,'Population: 7,969,309 (July 1990), growth
rate 3 6% (1990)
Birth rate: 52 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 131 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
53 years female (1990)
Total fertility rate: 7 4 children born/
woman (1990)
Nationality: noun—Nigerien(s) adyective—
Nigerien
Ethnic divisions: 56% Hausa, 22%
Dyerma, 8 5% Fula, 8% Tuareg, 4 3% Beri
Ber: (Kanour1), | 2% Arab, Toubou, and
Gourmantche, about 4,000 French expa-
triates
Religion: 80% Muslim, remainder indige-
nous beliefs and Christians
Language: French (official), Hausa,
Dierma
Literacy: 13 9%
Labor force: 2,500,000 wage earners
(1982), 90% agriculture, 6% industry and
commerce, 4% government, 51% of popu-
lation of working age (1985)
Organized labor: negligible','77940ef094329a9f69f6296642e389d84a88d08e3841d0361fbf1658c8adc2f5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('574fd53dc07f2a6edeae12deb9e8117b24bc8fdfeff0a4437c5b21e6528fd3ca',1990,'NU','Niue','people-and-society',567,'Population: 2,019 (July 1990), growth rate
NA (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/1,000
population (1990)
Infant mortality rate: NA deaths/1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
Nationality: noun—Nuuean(s), adjective—
Nivean
Ethnic divisions: Polynesian, with some
200 Europeans, Samoans, and Tongans
Religion: 75% Ekalesia Nieue (Niuean
Church)—a Protestant church closely re-
lated to the London Missionary Society,
10% Mormon, 5% Roman Catholic, Jeho-
vah’s Witnesses, Seventh-Day Adventist
Approved for Release: 2020/08/12 C06554432
Language: Polynesian tongue closely re-
lated to Tongan and Samoan, English
Literacy: NA%, but education compulsory
between 5 and 14 years of age
Labor force: 1,000 (1981 est ), most work
on family plantations, paid work exists
only in government service, small indus-
try, and the Niue Development Board
Organized labor: NA','9260aef382f03171ae24139f4cdaa2807befb41932b6895df9b5d10707611a70','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('589de020a6f5bbf1459adf56551b9c0f1b3793b999992147b2c61ef175b9c767',1990,'NF','Norfolk Island','people-and-society',572,'Population: 2,533 (July 1990), growth rate
1 7% (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/ 1,000
population (1990)
Infant mortality rate: NA deaths/1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
Nationality: noun—Norfolk Islander(s),
adyective—Norfolk Islander(s)
Ethnic divisions: descendants of the
Bounty mutiny, more recently, Australian
and New Zealand settlers
233
Approved for Release: 2020/08/12 C06554432
Norfolk Island (continued)
Religion: Anglican, Roman Catholic,
Uniting Church in Australia, and
Seventh-Day Adventist
Language: English (official) and Norfolk—
a mixture of 18th century English and
ancient Tahitian
Literacy: NA%, but probably high
Labor force: NA
Organized labor: NA','0f536f78a7a6ab5044db2ede5e7336e1fe776bea9deef3d99e19a429d705c253','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1159991693cb3faa7a24e9e9f2d7d977550a1f7f7592f850c66cd3234805f9c5',1990,'MP','Northern Mariana Islands','people-and-society',577,'Population: 22,719 (July 1990), growth
rate 3 4% (1990)
Birth rate: 43 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: — 3 migrants/1!,000
population (1990)
Infant mortality rate: 17 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
70 years female (1990)
Total fertility rate: 5 8 children born/
woman (1990)
Nationality: undetermined
Ethnic divisions: Chamorro majority; Car-
olimans and other Micronesians, Spanish,
German, Japanese admixtures
Religion: Christian with a Roman Catho-
lic majority, although traditional beliefs
and taboos may still be found
Language: English, but Chamorro and
Carolinian are also spoken in the home
and taught in school
Literacy: NA%
Labor force: 17,533, including 10,000 for-
eign workers (1988 est )
Organized labor: NA','0831ee9cc4d5de4cfecd7c244ba8625ce35b488958f0bb9e157bb79c0e2ef1e5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86bdcfe819cf0d91997b036e3adf3d681d54d5568e70766850ba4017f409facd',1990,'NO','Norway','people-and-society',582,'Population: 4,252,806 (July 1990), growth
rate 0 5% (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
81 years female (1990)
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Norwegiarn(s), adjec-
tive—Norwegian
Ethnic divisions: Germanic (Nordic, Al-
pine, Baltic) and racial-cultural minority
of 20,000 Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official), small
Lapp- and Finnish-speaking minorities
Literacy: 100%
Labor force: 2,164,000, 33 6% services,
17 4% commerce, 16 6% mining and man-
ufacturing, 8 4% transportation, 7 8% con-
struction, 6 8% banking and financial ser-
vices, 6 5% agriculture, forestry, and
fishing (1986)
Organized labor: 66% of labor force (1985)','52b1225ade8e5544809871f129693336f7210ca10a6414d165ffaa195b63c059','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dd2e5265dae2117224a25f84b41e39a190d7f8fead3cc41904480e172c694e6',1990,'OM','Oman','people-and-society',587,'Population: 1,457,064 (July 1990), growth
rate 3 1% (1990)
Birth rate: 43 births/ 1,000 population
(1990)
Death rate: 12 deaths/1,000 population
(1990)
237
Approved for Release: 2020/08/12 C06554432
Oman (continued)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 105 deaths/ 1,000
live births (1990)
Life expectancy at birth: 56 years male,
58 years female (1990)
Total fertility rate: 6 8 children born/
woman (1990)
Nationality: noun—Omani(s), adjective—
Omani
Ethnic divisions: almost entirely Arab,
with small Balochi, Zanzibari, and Indian
groups
Religion: 75% Ibadhi Muslim, remainder
Sunni Muslim, Shi‘a Muslim, some Hindu
Language: Arabic (official), English, Balo-
chi, Urdu, Indian dialects
Literacy: 20%
Labor force: 430,000, 60% agriculture
(est ), 58% are non-Omani
Organized labor: trade unions are illegal
Population: 14,310 (July 1990), growth
rate 0 7% (1990)
Birth rate: 25 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: — 12 migrants/1,000
population (1990)
Infant mortality rate: 26 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
74 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 3 3 children born/
woman (1990)
Nationality: noun—Palauan(s), adjective—
Palauan
Ethnic divisions: Palauans are a composite
of Polynesian, Malayan, and Melanesian
Taces
Religion: predominantly Christian, mainly
Roman Catholic
Language: Palauan 1s the official
language, though English is commonplace,
inhabitants of the isolated southwestern
islands speak a dialect of Trukese
Literacy: NA%, but education compulsory
through eight grades
Labor force: NA
Organized labor: NA
Population: 114,649,406 (July 1990),
growth rate 2 2% (1990)
Birth rate: 43 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/1,000
population (1990)
Infant mortality rate: 110 deaths/1,000
live births (1990)
Life expectancy at birth: 56 years male,
57 years female (1990)
Total fertility rate: 6 7 children born/
woman (1990)
Nationality: noun—Pakistani(s), adjec-
tive—Pakistan1
Ethnic divisions: Punjabi, Sindhi, Pashtun
(Pathan), Baloch, Muhayir (immigrants
from India and their descendents)
Religion: 97% Mushm (77% Sunm, 20%
Shi‘a), 3% Christian, Hindu, and other
Language: Urdu and English (official), to-
tal spoken languages—64% Punjabi, 12%
Sindhi, 8% Pashtu, 7% Urdu, 9% Balochi
and other, English 1s lingua franca of Pa-
kistani elite and most government minis-
tries, but official policies are promoting its
gradual replacement by Urdu
Literacy: 26%
Labor force: 28,900,000, 54% agriculture,
13% mining and manufacturing, 33% ser-
vices, extensive export of labor (1987 est )
Organized labor: about 10% of industrial
work force
Population: uninhabited','37f9507be1806a008f017e95477071e6d3b202c9ae55f56f75402b1a6f88101e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6080b38fce0596a1f815fa4cab4ede585803cecca42265a57fabd0017c2e2435',1990,'PA','Panama','people-and-society',592,'Population: 2,425,400 (July 1990), growth
rate 2 1% (1990)
Birth rate: 26 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 22 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
76 years female (1990)
244
Total fertility rate: 3 1 children born/
woman (1990)
Nationality: noun—Panamanian(s), adjec-
tive—Panamanian
Ethnic divisions: 70% mestizo (mixed In-
dian and European ancestry), 14% West
Indian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official), 14% speak
English as native tongue, many Panama-
mans bilingual
Literacy: 90%
Labor force: 770,472 (1987), 27 9% gov-
ernment and community services, 26 2%
agriculture, hunting, and fishing, 16%
commerce, restaurants, and hotels, 10 5%
manufacturing and mining, 5 3%
construction, 5 3% transportation and
communications, 4 2% finance, insurance,
and real estate, 2 4% Canal Zone, short-
age of skilled labor, but an oversupply of
unskilled labor
Organized labor: 17% of labor force (1986)','a27786bf722b3f1ec9d6e994ba0ab6dfdb4363b60e25543675a0755195d5199f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b261a24ec2c30cd38be6c55e725837a706ffdf793575a93e3c55ed8126f4b0ac',1990,'ID','Indonesia','people-and-society',597,'Population: 3,822,875 (July 1990), growth
rate 2 3% (1990)
Birth rate: 34 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 68 deaths/1,000 live
births (1990)
Life expectancy at birth: 54 years male,
56 years female (1990)
245
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Papua New Guinea (continued)
Total fertility rate: 5 0 children born/
woman (1990)
Nationality: noun—Papua New
Guinean(s), adjective—Papua New Gui-
nean
Ethnic divisions: predominantly Melane-
sian and Papuan, some Negrito, Microne-
sian, and Polynesian
Religion: over half of population nominally
Christian (490,000 Roman Catholic,
320,000 Lutheran, other Protestant sects),
remainder indigenous beliefs
Language: 715 indigenous languages, En-
glish spoken by 1-2%, pidgin English
widespread, Motu spoken in Papua region
Literacy: 32%
Labor force: 1,660,000, 732,806 in sala-
ried employment, 54% agriculture, 25%
government, 9% industry and commerce,
8% services (1980)
Organized labor: more than 50 trade
unions, some with fewer than 20 members','0d2a87b02d1cd701e2a7d3463a0a0577504fe214ba9489e7baf38b38c8d2746b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79fa4cdc0805ebe772112af49f8049d468af7ab26a76361518bd497774a0781f',1990,'PY','Paraguay','people-and-society',602,'Population: 4,660,270 (July 1990), growth
rate 3 0% (1990)
Birth rate: 36 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 48 deaths/1,000 live
births (1990)
Life expectancy at birth: 67 years male,
72 years female (1990)
Total fertility rate: 4 8 children born/
woman (1990)
Nationality: noun—Paraguayan(s), adjec-
tive—Paraguayan
Ethnic divisions: 95% mestizo (Spanish
and Indian), 5% white and Indian
Religion: 90% Roman Catholic, Menno-
nite and other Protestant denominations
Language: Spanish (official) and Guarani
Literacy: 81%
Labor force: 1,300,000, 44% agriculture,
34% industry and commerce, 18% ser-
vices, 4% government (1986)
Organized labor: about 2% of labor force','de4472b1955cc2adff60b5b205d16e97860ea2066fca8a37f0a918a393c5f31a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ca91f28f5a2c59f4d8d6d2d812231471892ccbdf0a0cef8e63cf57e0458aadc',1990,'PE','Peru','people-and-society',606,'Population: 21,905,605 (July 1990),
growth rate 2 1% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 67 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 62 years male,
66 years female (1990)
Total fertility rate: 3 6 children born/
woman (1990)
Nationality: noun—Peruvian(s),
adyective—Peruvian
Ethnic divisions: 45% Indian, 37% mestizo
(mixed Indian and European ancestry),
15% white, 3% black, Japanese, Chinese,
and other
Religion: predominantly Roman Catholic
Language: Spanish and Quechua (official),
Aymara
Literacy: 80% (est )
Labor force: 6,800,000 (1986), 44% gov-
ernment and other services, 37% agricul-
ture, 19% industry (1988 est )
Organized labor: about 40% of salaried
workers (1983 est )','83df716ba526c2396ff6ed04993db9fcae95b090f3f735430dcf9cbe40ed8cc3','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd21b7e923d51414749f75a14b3f7c9f4ae012ee2aa456139a620ca6bd0e6a41',1990,'PN','Pitcairn','people-and-society',612,'Population: 56 (July 1990), growth rate
0 0% (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/1,000
population (1990)
Infant mortality rate: NA deaths/1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
Nationality: noun—Pitcairn Islander(s),
adjective—Pitcairn Islander
Ethnic divisions: descendants of Bounty
mutineers
Religion: 100% Seventh-Day Adventist
Language: English (official), also a Tahitian/
English dialect
Literacy: NA%, but probably high
Labor force: NA, no business community
in the usual sense, some public works;
subsistence farming and fishing
Organized labor: NA','c4b2052542e52c29e3174cac43a2a57a23446fc3921d9d348ec114ce06fb0e47','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a33e4420e57327578226d1d75a412c7abd6edf72b617eec894884ab27afb199',1990,'PL','Poland','people-and-society',617,'Population: 37,776,725 (July 1990),
growth rate NEGL (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: —5 migrants/ 1,000
population (1990)
Infant mortality rate: 13 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
77 years female (1990)
Total fertility rate: 2 1 children born/
woman (1990)
253
Approved for Release: 2020/08/12 C06554432
Poland (continued)
Nationality: noun—Pole(s), adjective—
Polish
Ethnic divisions: 98 7% Polish, 0 6%
Ukrainian, 0 5% Byelorussian, less than
005% Jewish
Religion: 95% Roman Catholic (about
75% practicing), 5% Russian Orthodox,
Protestant, and other
Language: Polish
Literacy: 98%
Labor force: 17,128,000 (1988), 36 5%
industry and construction, 28 5% agricul-
ture, 14 7% trade, transport, and commu-
nications, 20 3% government and other
Organized labor: trade union pluralism','559dd0e533d435d53dae8a50f1326cf87d0245a39342041f406ad3b1af581dc2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6158ab941839041eb5901ba528b9e28fa54b7845de62153847a43934aea37330',1990,'PT','Portugal','people-and-society',622,'Population: 10,354,497 (July 1990),
growth rate 0 3% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 1 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 14 deaths/!,000 live
births (1990)
Life expectancy at birth: 71 years male,
78 years female (1990)
255
Approved for Release: 2020/08/12 C06554432
Portugal (continued)
Total fertility rate: 1 5 children born/
woman (1990)
Nationality: noun—Portuguese (sing and
pl ), adjective—Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands, citizens of black African descent
who immigrated to mainland during deco-
lonization number less than 100,000
Religion: 97% Roman Catholic, 1% Prot-
estant denominations, 2% other
Language: Portuguese
Literacy: 83%
Labor force: 4,605,700, 45% services, 35%
industry, 20% agriculture (1988)
Organized labor: about 55% of the labor
force, the Communist-dominated General
Confederation of Portuguese Workers—
Intersindical (CGTP-IN) represents more
than half of the unionized labor force, its
main competition, the General Workers
Union (UGT), 1s organized by the Social-
ists and Social Democrats and represents
less than half of untonized labor','2500871f51467be4b1cfa095a2c468b45c3ced67b0b8c214e2aca9f4ff3e4d57','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc170654ecf85e4512989c5a6a8ac5bb883d765dd6df5c65505dcc1efb10d092',1990,'PR','Puerto Rico','people-and-society',627,'Population: 3,291,207 (July 1990), growth
rate 0 1% (1990)
Birth rate: 19 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: — 11 migrants/1,000
population (1990)
Infant mortality rate: 17 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
76 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Puerto Rican(s), adjec-
tive—Puerto Rican
Ethnic divisions: almost entirely Hispanic
Religion: mostly Christian, 85% Roman
Catholic, 15% Protestant denominations
and other
Language: Spanish (official), English 1s
widely understood
Literacy: 89%
Labor force: 1,062,000; 23% government,
20% trade, 18% manufacturing, 4% agri-
culture, 35% other (1988)
Organized labor: 115,000 members in 4
unions, the largest 1s the General Confed-
eration of Puerto Rican Workers with
35,000 members (1983)
Population: 490,897 (July 1990), growth
rate 5 7% (1990)
Birth rate: 22 births/1,000 population
(1990)
Death rate: 3 deaths/1,000 population
(1990)
Net migration rate: 38 migrants/ 1,000
population (1990)
Infant mortality rate: 25 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
73 years female (1990)
Total fertility rate: 4 2 children born/
woman (1990)
Nationality: noun—Qatari(s), adjective —
Qatari
Ethnic divisions: 40% Arab, 18% Paki-
stam, 18% Indian, 10% Iraman, 14%
other
Religion: 95% Muslim
Language: Arabic (official), English 1s
commonly used as second language
Literacy: 40%
Labor force: 104,000, 85% non-Qatari in
private sector (1983)
Organized labor: trade unions are illegal
Population: 595,583 (July 1990), growth
rate 1 9% (1990)
Birth rate: 24 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
76 years female (1990)
Total fertility rate: 2 6 children born/
woman (1990)
Nationality: noun—Reunionese (sing and
pl ), adjective—Reunionese
260
Ethnic divisions: most of the population 1s
of intermixed French, African, Malagasy,
Chinese, Pakistani, and Indian ancestry
Religion: 94% Roman Catholic
Language: French (official), Creole widely
used
Literacy: NA%, but over 80% among
younger generation
Labor force: NA, 30% agriculture, 21%
industry, 49% services (1981), 63% of pop-
ulation of working age (1983)
Organized labor: General Confederation of
Workers of Reunion (CGTR)','fe7ea798739091cc5c786e4f31c04131b8b3cb7baabe9e53a3e97df4093299d2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70a2d765e9e26ba78a83a1c0acf4a4de33da56f083481fa296a958ae033428a7',1990,'RW','Rwanda','people-and-society',632,'Population: 7,609,119 (July 1990), growth
rate 3 8% (1990)
Birth rate: 53 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 113 deaths/ 1,000
live births (1990)
Life expectancy at birth: 50 years male,
54 years female (1990)
Total fertility rate: 8 5 children born/
woman (1990)
Nationality: noun and adjective—Rwan-
dan(s)
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: Hutu 90%, Tutsi 9%,
Twa (Pygmoid) 1%
Religion: Roman Catholic 65%, Protestant
9%, Muslim 1%, indigenous beliefs and
other 25%
Language: Kinyarwanda, French (official),
Kiswahili used in commercial! centers
Literacy: 46 6%
Labor force: 3,600,000, 93% agriculture,
5% government and services, 2% industry
and commerce, 49% of population of
working age (1985)
Organized labor: NA
Population: 6,657 (July 1990), growth rate
0 6% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 8 deaths/1,000 population
(1990)
Net migration rate: NEGi migrants/1,000
population (1990)
Infant mortality rate: 46 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
75 years female (1990)
Total fertility rate: 1 4 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—St Helenian(s), adjec-
tive—St Helenian
Ethnic divisions: NA
Religion: Anglican majority, also Baptist,
Seventh-Day Adventist, and Roman Cath-
olic
Language: English
Literacy: NA%, but probably high
Labor force: NA
Organized labor: St Helena General
Workers’ Union, 472 members, 17%
crafts, 10% professional and technical,
10% service, 9% management and clerical,
9% farming and fishing, 6% transport, 5%
sales, 1% security, and 33% other
Population: 40,157 (July 1990), growth
rate 0 3% (1990)
Birth rate: 24 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: — 11 migrants/ 1,000
population (1990)
Infant mortality rate: 40 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
71 years female (1990)
Total fertility rate: 27 children born/
woman (1990)
Ethnic divisions: mainly of black African
descent
Nationality: noun—Kittsian(s), Nevisian(s),
adjective—Kittsian, Nevisian
265
Approved for Release: 2020/08/12 C06554432
St. Kitts and Nevis (continued)
Religion: Anglican, other Protestant sects,
Roman Catholic
Language: English
Literacy: 80%
Labor force: 20,000 (1981)
Organized labor: 6,700
Population: 153,196 (July 1990), growth
rate 2 6% (1990)
Birth rate: 33 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: —2 migrants/1,000
population (1990)
Infant mortality rate: 18 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
74 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Nationality: noun—St Lucian(s), adjec-
tive—St Lucian
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: 90 3% African descent,
5 5% mixed, 3 2% East Indian, 0 8% Cau-
casian
Religion: 90% Roman Catholic,,7% Prot-
estant, 3% Anglican
Language: English (official), French patois
Literacy: 78%
Labor force: 43,800, 43 4% agriculture,
38 9% services, 17 7% industry and com-
merce (1983 est )
Organized labor: 20% of labor force
Population: 6,330 (July 1990), growth rate
0 4% (1990)
Birth rate: 17 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —6 migrants/ 1,000
population (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
79 years female (1990)
Total fertility rate: 2 2 children born/
woman (1990)
Nationality: noun—Frenchman(men),
Frenchwoman(women), adjective—French
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: originally Basques and
Bretons (French fishermen)
Religion: 98% Roman Catholic
Language: French
Literacy: NA%, but compulsory education
between 6 and 16 years of age
Labor force: 2,510 (1982)
Organized labor: Workers’ Force trade
union','4d2413055ac4aeec9dbafb7e45592a834459998e9b6c5e1967b42a977c5d285b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b86e67d8877bdbdf325bda440aa99264cbf0391511020a16480b45c13599ad',1990,'SM','San Marino','people-and-society',637,'Population: 23,123 (July 1990), growth
rate 0 6% (1990)
Birth rate: 8 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 5 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 9 deaths/1,000 live
births (1990)
Life expectancy at birth: 74 years male,
79 years female (1990)
Total fertility rate: 1 3 children born/
woman (1990)
Nationality: noun—Sanmarinese (sing
and pl ), adjective—Sanmarinese
Ethnic divisions: Sanmarinese, Italian
Religion: Roman Catholic
Language: Italian
Literacy: 97%
Labor force: about 4,300
Organized labor: Democratic Federation
of Sanmarinese Workers (affihated with
ICFTU) has about 1,800 members,
Communist-dominated General Federa-
tion of Labor, 1,400 members
Approved for Release: 2020/08/12 C06554432','72cd6a2cfabe3f79a4ffa9b8030abacbd9375d88867b80086efc40a28e6f4919','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76c07276ee2e8c574fdc40e9869229d3fcd4e7d75fa4eadab849ec6bf1fcce2b',1990,'SA','Saudi Arabia','people-and-society',644,'Population: 17,115,728 (July 1990),
growth rate 4 4% (1990), note—the popu-
lation figure 1s based on growth since the
last official Saudi census of 1974 reported
a total of 7 million persons and includes
foreign workers, while estimates from
other sources may be 15-30% lower
Birth rate: 37 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: 13 migrants/ 1,000
population (1990)
Infant mortality rate: 71 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
67 years female (1990)
Total fertility rate: 6 8 children born/
woman (1990)
Nationality: noun—Saudi(s), adyective—
Saudi or Saudi Arabian
Ethnic divisions: 90% Arab, 10% Afro-
Asian
Religion: 100% Mushm
Language: Arabic
Literacy: 52%
Labor force: 4,200,000, about 60% are
foreign workers, 34% government, 28%
industry and oil, 22% services, and 16%
agriculture
Organized labor: trade unions are illegal','431ccfd4c42d81ee1e7be331adad30273924c9edfe3ee7d5bd3ba057f2fffd08','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7a3a2eacc5d8b5e6315b96d23df80bc6c70b897b7fe1df1493e1e32e3ce1292',1990,'SN','Senegal','people-and-society',649,'Population: 7,713,851 (July 1990), growth
rate 3 0% (1990)
Birth rate: 44 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 87 deaths/1,000 live
births (1990)
Life expectancy at birth: 53 years male,
56 years female (1990)
Total fertility rate: 6 3 children born/
woman (1990)
Nationality: noun——Senegalese (sing and
pl ), adjective—Senegalese
Ethnic divisions: 36% Wolof, 17% Fulam,
17% Serer, 9% Toucouleur, 9% Diola, 9%
Mandingo, 1% European and Lebanese,
2% other
Religion: 92% Muslim, 6% indigenous be-
hefs, 2% Christian (mostly Roman Catho-
lic)
Language: French (official), Wolof, Pulaar,
Diola, Mandingo
Literacy: 28 1%
Labor force: 2,509,000, 77% subsistence
agricultural workers, 175,000 wage earn-
ers—40% private sector, 60% government
and parapublic, 52% of population of
working age (1985)
Organized labor: majority of wage-labor
force represented by unions, however,
dues-paying membership very limited, ma-
jor confederation 1s National Confedera-
tion of Senegalese Labor (CNTS), an af-
filiate of governing party','77911b2ad51b5d67dd21953d6e1c6cc52e18374eb42d5bd2d5e3c6947b062304','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b981cfb8381adcd8190d1f1a1d33aaec79d823c67d6fd2c3b4f9d045ee9283',1990,'SC','Seychelles','people-and-society',654,'Population: 68,336 (July 1990), growth
rate 0 9% (1990)
Birth rate: 24 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: —8 migrants/1,000
population (1990)
Infant mortality rate: 15 deaths/1,000 live
births (1990)
Life expectancy at birth: 65 years male,
75 years female (1990)
Approved for Release: 2020/08/12 C06554432
Total fertility rate: 2 6 children born/
woman (1990)
Nationality: noun—Seychellois (sing and
pl ), adyective—Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Angli-
can, 2% other
Language: English and French (official),
Creole
Literacy: 60%
Labor force: 27,700, 31% industry and
commerce, 21% services, 20% government,
12% agriculture, forestry, and fishing,
16% other (1985), 57% of population of
working age (1983)
Organized labor: three major trade umons','0b4d09b384de87af660866eb3c6518a4a3af86163af51603382cd6a99eb3973a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37451f00a81b52d1684a01aef2311fde533e64cb24b84f0f4f5e9fcdc13bee72',1990,'SL','Sierra Leone','people-and-society',659,'Population: 4,165,953 (July 1990), growth
rate 2 6% (1990)
Birth rate: 47 births/1,000 population
(1990)
Death rate: 21 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 154 deaths/1,000
live births (1990)
Life expectancy at birth: 42 years male,
47 years female (1990)
Total fertility rate: 6 2 children born/
woman (1990)
Nationality: noun—Sierra Leonean(s), ad-
Jective—Sierra Leonean
Approved for Release: 2020/08/12 C06554432
Ethnic divisions: 99% native African (30%
Temne, 30% Mende), 1% Creole, Euro-
pean, Lebanese, and Asian, 13 tribes
Religion: 30% Muslim, 30% indigenous
beliefs, 10% Christian, 30% other or none
Language: English (official), regular use
limited to literate minority, principal ver-
naculars are Mende in south and Temne
m north, Krio 1s the language of the reset
tled ex-slave population of the Freetown
area and 1s lingua franca
Literacy: 31% (1986)
Labor force: 1,369,000 (est ), 65% agricul-
ture, 19% industry, 16% services (1981),
only about 65,000 earn wages (1985), 55%
of population of working age
Organized labor: 35% of wage earners','cd1c8ee5156640fb75d2f6debcdbf948154fc165da943b86abb93f07522f1e6d','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f3aa6b0b32e3a2f9f0b7f5801c8607f176b5a19d12dfe3e3c5e50e96e18bb09',1990,'SG','Singapore','people-and-society',662,'Population: 2,720,915 (July 1990), growth
rate 1 3% (1990)
Birth rate: 18 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 8 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
77 years female (1990)
Total fertility rate: 2.0 children born/
woman (1990)
Nationality: noun—Singaporean(s), adjec-
tive—Singapore
Ethnic divisions: 76 4% Chinese, 14 9%
Malay, 6 4% Indian, 2 3% other
279
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Singapore (continued)
Religion: majority of Chinese are Bud-
dhists or atheists, Malays nearly all Mus-
lim (minorities include Christians, Hindus,
Sikhs, Taoists, Confucianists)
Language: Chinese, Malay, Tamil, and
English (official), Malay (national)
Literacy: 86 8% (1987)
Labor force: 1,280,000, 34 4% industry,
1 2% agriculture, 61 7% services (1988)
Organized labor: 211,200, 16 5% of labor
force (1988)','b611ce30ead12a2c5679599644af5e9bc975024e7c1a9f142251eb59b84f7c15','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1076639f3f5ac9801b64325802870bc91df1d83a0ddbc474882cc153e7220e19',1990,'SB','Solomon Islands','people-and-society',666,'Population: 335,082 (July 1990), growth
rate 3 5% (1990)
Birth rate: 41 births/1,000 population
(1990)Death rate 5 deaths/1,000 popula-
tion (1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 40 deaths/1,000 live
births (1990)
Life expectancy at birth: 67 years male,
72 years female (1990)
Total fertility rate: 6 3 children born/
woman (1990)
Nationality: noun—Solomon Islander(s),
adyective—Solomon Islander
Ethnic divisions: 93 0% Melanesian, 4 0%
Polynesian, 1 5% Micronesian, 0 8% Euro-
pean, 0 3% Chinese, 0 4% other
Approved for Release: 2020/08/12 C06554432
Religion: almost all at least nominally
Christian, Anglican, Seventh-Day Advent-
ist, and Roman Catholic Churches domi-
nant
Language: 120 indigenous languages, Me-
lanesian pidgin in much of the country 1s
lingua franca, English spoken by 1-2% of
population
Literacy: 60%
Labor force: 23,448 economically active,
32 4% agriculture, forestry, and fishing,
25% services, 7 0% construction, manufac-
turing, and mining, 4 7% commerce,
transport, and finance (1984)
Organized labor: NA, but most of the
cash-economy workers have trade union
representation','ee856ad4d23097e8c3c59e23ca18e9fe8595f184b26d7a07cd7cde922436029e','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b2cd86aee364126ba4541feaca0cf4867532d97efbe75cb0d26f6fdbebb0a5c',1990,'SO','Somalia','people-and-society',671,'Population: 8,424,269 (July 1990), growth
rate 0 8% (1990)
Birth rate: 47 births/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: — 24 migrants/ 1,000
population (1990)
Infant mortality rate: 125 deaths/1,000
lve births (1990)
Life expectancy at birth: 53 years male,
54 years female (1990)
Total fertility rate: 7 3 children born/
woman (1990)
Nationality: noun—Somali(s), adjective—
Somali
Ethnic divisions: 85% Somali, rest mainly
Bantu, 30,000 Arabs, 3,000 Europeans,
800 Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official), Arabic, Ital-
1an, English
Literacy: 11 6% (government est )
Labor force: 2,200,000, very few are
skilled laborers, 70% pastoral nomad, 30%
agriculture, government, trading, fishing,
handicrafts, and other, 53% of population
of working age (1985)
Organized labor: General Federation of
Somali Trade Unions 1s controlled by the','b6547a551b0015367978e2abc7fe739996582b0e7d6e305c68d6e1349ef2c82f','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba823d1be9c8d6d8f6c3826ba2285c6e804413e8020e84b2a6e621822d4d292',1990,'LK','Sri Lanka','people-and-society',678,'Population: 17,196,436 (July 1990),
growth rate 1 5% (1990)
Birth rate: 21 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Infant mortality rate: 31 deaths/1,000 live
births (1990)
Life expectancy at birth: 68 years male,
72 years female (1990)
Total fertility rate: 2 3 children born/
woman (1990)
291
Approved for Release: 2020/08/12 C06554432
Sri Lanka (continued)
Nationality: noun—Sni Lankan(s), adjec-
tive—Sri Lankan
Ethnic divisions: 74% Sinhalese, 18% Ta-
mil, 7% Moor, 1% Burgher, Malay, and
Veddha
Religion: 69% Buddhist, 15% Hindu, 8%
Christian, 8% Muslim
Language: Sinhala (official), Sinhala and
Tamil listed as national languages, Sin-
hala spoken by about 74% of population,
Tamil spoken by about 18%, English com-
monly used in government and spoken by
about 10% of the population
Literacy: 87%
Labor force: 6,600,000, 45 9% agriculture,
13 3% mining and manufacturing, 12 4%
trade and transport, 28 4% services and
other (1985 est )
Organized labor: about 33% of labor force,
over 50% of which are employed on tea,
rubber, and coconut estates','a9fb6111933ef5248590f5887d6cd72ef6d76fbc92b20053a8446cfb9a8f430a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c360c528bbb90cedbcf9eca04e7514cab8e49626d644a43a62a43448e2045942',1990,'SD','Sudan','people-and-society',683,'Population: 24,971,806 (July 1990),
growth rate 2 9% (1990)
Birth rate: 44 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: —2 migrants/1,000
population (1990)
Infant mortality rate: 107 deaths/ 1,000
live births (1990)
Life expectancy at birth: 51 years male,
55 years female (1990)
Total fertility rate: 6 5 children born/
woman (1990)
Nationality: noun—Sudanese (sing and
pl ), adjective—Sudanese
Ethnic divisions: 52% black, 39% Arab,
6% Beja, 2% foreigners, 1% other
Religion: 70% Sunni Muslim (in north),
20% indigenous beliefs, 5% Christian
(mostly in south and Khartoum)
Language: Arabic (official), Nubian, Ta
Bedawie, diverse dialects of Nilotic, Nilo-
Hamitic, and Sudanic languages, English,
program of Arabization in process
Literacy: 31% (1986)
Labor force: 6,500,000, 80% agriculture,
10% industry and commerce, 6% govern-
ment, labor shortages for almost all cate-
gories of skilled employment (1983 est ),
52% of population of working age (1985)
Organized labor: trade unions suspended
following 30 June 1989 coup, now in pro-
cess of being legalized anew','efa87d1d3e8840e8cb7ee117f2c53b7208c21cf8ca42e49a838136947771b0c7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d422a21660020f12b0fa7487f77eeac31015a6079f0409ab45c60ccfad5b96d0',1990,'GE','Georgia','people-and-society',689,'Population: 396,813 (July 1990), growth
rate 1 4% (1990)
Birth rate: 27 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: —7 migrants/ 1,000
population (1990)
Infant mortality rate: 40 deaths/1,000 live
births (1990)
Approved for Release: 2020/08/12 C06554432
Life expectancy at birth: 66 years male,
71 years female (1990)
Total fertility rate: 2 9 children born/
woman (1990)
Nationality: noun—Surinamer(s), adjec-
tive—Surinamese
Ethnic divisions: 37 0% Hindustani (East
Indian), 31 0% Creole (black and mixed),
15 3% Javanese, 10 3% Bush black, 2 6%
Amerindian, 1 7% Chinese, 1 0% Europe-
ans, 1 1% other
Religion: 27 4% Hindu, 19 6% Muslim,
22 8% Roman Catholic, 25 2% Protestant
(predominantly Moravian), about 5% in-
digenous beliefs
Language: Dutch (official), English widely
spoken, Sranan Tongo (Surinamese, some-
times called Taki-Tak1) 1s native language
of Creoles and much of the younger popu-
lation and 1s lingua franca among others,
also Hind: Suriname Hindustani (a vari-
ant of Bhogpuri), and Javanese
Literacy: 65%
Labor force: 104,000 (1984)
Organized labor: 49,000 members of labor
force
Population: 3,942 (July 1990), growth rate
NA% (1990), about one-third of the popu-
lation resides in the Norwegian areas
(Longyearbyen and Svea on Vestspitsber-
gen) and two-thirds in the Soviet areas
(Barentsburg and Pyramiden on Vestspits-
bergen), about 9 persons live at the Polish
research station
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/1,000
population (1990)
Infant mortality rate: NA deaths/ 1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
Ethnic divisions: 64% Russian, 35% Nor-
wegian, 1% other (1981)
Language: Russian, Norwegian
Literacy; NA%
Labor force: NA
Organized labor: none
Population: 778,525 (July 1990), growth
rate 3 1% (1990)
Birth rate: 46 births/1,000 population
(1990)
Death rate: 15 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 126 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
55 years female (1990)
Total fertility rate: 6 0 children born/
woman (1990)
Nationality: noun—Swazi(s), adjective—
Swazi
Ethnic divisions: 97% African, 3% Euro-
pean
297
Approved for Release: 2020/08/12 C06554432
Swaziland (continued)
Religion: 60% Christian, 40% indigenous
beliefs
Language: English and siSwati (official),
government business conducted in English
Literacy: 67 9%
Labor force: 195,000, over 60,000
engaged in subsistence agriculture, about
92,000 wage earners (many only intermit-
tently), with 36% agriculture and forestry,
20% community and social services, 14%
manufacturing, 9% construction, 21%
other, 24,000-29,000 employed in South
Africa (1987)
Organized labor: about 10% of wage earn-
ers','99cdcfdd4026007e39470dd9592b720917a0f5b71d07c65ab34e2d743c1bcc91','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('943ceb139262514f5c8649c080016cea66e5b28bef62a51424cb10c111354f87',1990,'SE','Sweden','people-and-society',695,'Population: 8,526,452 (July 1990), growth
rate 0 5% (1990)
Birth rate: 13 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 3 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 6 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
81 years female (1990)
Total fertility rate: 1 9 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Swede(s), adjective—
Swedish
Ethnic divisions: homogeneous white popu-
lation, small Lappish minority, about 12%
foreign born or first-generation
immigrants (Finns, Yugoslavs, Danes,
Norwegians, Greeks, Turks)
Religion: 93 5% Evangelical Lutheran,
10% Roman Catholic, 5 5% other
Language: Swedish, small Lapp- and
Finnish-speaking minorities, immigrants
speak native languages
Literacy: 99%
Labor force: 4,531,000 (1988), 32 8% pri-
vate services, 30 0% government services,
22 0% mining and manufacturing, 5 9%
construction, 5 0% agriculture, forestry,
and fishing, 0 9% electricity, gas, and wa-
terworks (1986)
Organized labor: 90% of labor force (1985
est )','2c991b3260d30f2278bfbb13409e80a8ce5fb92141f1d5a12e8b25c66f99625a','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48f3f04c604cda30fef68f4e752d293c6aaf27a2d7536500afe8114c0e0f0b2a',1990,'CH','Switzerland','people-and-society',700,'Population: 6,742,461 (July 1990), growth
rate 0 6% (1990)
Birth rate: 12 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 3 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 5 deaths/1,000 live
births (1990)
Life expectancy at birth: 75 years male,
83 years female (1990)
Total fertility rate: 1 6 children born/
woman (1990)
Nationality: noun—Swiss (sing & pl ),
adjective—Swiss
thnic divisions: total population—65%
german, 18% French, 10% Italian, 1%
Xomansch, 6% other, Swiss nationals—
''4% German, 20% French, 4% Italian, 1%
Xomansch, 1% other
teligion: 49% Roman Catholic, 48% Prot-
stant, 0 3% Jewish
uanguage: total population—65% German,
8% French, 12% Itahan, 1% Romansch,
% other, Swiss nationals—74% German,
''0% French, 4% Italian, 1% Romansch,
% other
uiteracy: 99%
.abor force: 3,220,000, 841,000 foreign
vorkers, mostly Italian, 42% services, 39%
ndustry and crafts, 11% government, 7%
griculture and forestry, 1% other (1988)
rganized labor: 20% of labor force
rovernment
,ong-form name: Swiss Confederation
‘ype: federal republic
‘apital: Bern
idministrative divisions: 26 cantons (can-
ons, singular—canton in French, canton,
ingular—cantone in Italian, kantone, sin-
ular—kanton in German), Aargau,
,usser-Rhoden, Basel-Landschaft, Basel-
itadt, Bern, Fribourg, Genéve, Glarus,
iraubunden, Inner-Rhoden, Jura, Luzern,
Veuchatel, Nidwalden, Obwalden, Sankt
allen, Schaffhausen, Schwyz, Solothurn,
‘hurgau, Ticino, Uri, Valais, Vaud, Zug,
Zurich
ndependence: | August 1291
‘onstitution: 29 May 1874
gal system: civil law system influenced
y customary law, judicial review of legis-
itive acts, except with respect to federal
ecrees of general obligatory character,
ccepts compulsory [CJ jurisdiction, with
eservations
ational holiday: Anniversary of the
‘ounding of the Swiss Confederation, 1
.ugust (1291)
‘xecutive branch: president, vice presi-
ent, Federal Council (German—Bundes-
at, French—Conseil Fédéral)
&gislative branch: bicameral Federal As-
embly (German—Bundesversammlung,
‘rench—Assemblée Fédérale) consists of
n upper council or Council of States
Serman—Standerat, French—Conseil
es Etats) and and a lower council or Na-
ional Council (German—Nationalrat,
rench—Conseil National)
udicial branch: Federal Supreme Court
eaders: Chief of State and Head of Gov-
rnment—President Arnold KOLLER
1990 calendar year, presidency rotates
nnually), Vice President Flavio COTTI
erm runs concurrently with that of presi-
ent)
’olitical parties and leaders: Social Demo-
ratic Party (SPS), Helmut Hubacher,
Approved for Release: 2020/08/12 C06554432
chairman, Radical Democratic Party
(FDP), Bruno Hunziker, president, Chris-
tian Democratic People’s Party (CVP),
Eva Segmuller-Weber, president, Swiss
People’s Party (SVP), Hans Uhlmann,
president, Workers’ Party (PdA), Armand
Magnin, secretary general, National Ac-
tion Party (NA), Hans Zwicky, chairman,
Independents’ Party (LdU), Dr Franz
Jaeger, president, Republican Movement
(Rep), Dr James Schworzenboch, Franz
Baumgartner, leaders, Liberal Party
(LPS), Gilbert Coutau, president, Evangel-
ical People’s Party (EVP), Max Dunki,
president, Progressive Organizations of
Switzerland (POCH), Georg Degen, secre-
tary, Federation of Ecology Parties (GP),
Laurent Rebeaud, president, Autonomous
Socialist Party (PSA), Werner Carobbio,
secretary
Suffrage: universal at age 20
Elections: Council of State—last held
throughout 1987 (next to be held NA),
results—percent of vote by party NA,
seats—{46 total) CVP 19, FDP 14, SPS 5,
SVP 4, others 4,
National Council—last held 18 October
1987 (next to be held October 1991), re-
sults—FDP 22 9%, CVP 20 0%, SPS
18 4%, SVP 11 0%, GP 4 8%, others
22 9%, seats—{200 total) FDP 51, CVP
42, SPS 41, SVP 25, GP 9, others 32
Communists: 4,500 members (est )
Member of: ADB, CCC, Council of Eu-
rope, DAC, EFTA, ESA, FAO, GATT,
IAEA, ICAC, ICAO, ICO, IDB—Inter-
American Development Bank, IEA,
IFAD, ILO, IMO, INTELSAT,
INTERPOL, IPU, ITU, IWC—Interna-
tional Wheat Council, OECD, UNESCO,
UPU, WCL, WFTU, WHO, WIPO,
WMO, WSG, WTO, permanent observer
status at the UN
Diplomatic representation: Ambassador
Edouard BRUNNER, Chancery at 2900
Cathedral Avenue NW, Washington DC
20008, telephone (202) 745-7900, there
are Swiss Consulates General in Atlanta,
Chicago, Houston, Los Angeles, New
York, and San Francisco, US—Ambassa-
dor Joseph B GUILDENHORN, Em-
bassy at Jubilaeumstrasse 93, 3005 Bern,
telephone [41] (31) 437011, there 1s a
Branch Office of the Embassy in Geneva
and a Consulate General in Zurich
Flag: red square with a bold, equilateral
white cross in the center that does not ex-
tend to the edges of the flag
Population: 12,483,440 (July 1990),
growth rate 3 8% (1990), in addition, there
Approved for Release: 2020/08/12 C06554432
are 13,500 Druze and 10,500 Jewish set-
tlers in the Israeli-occupied Golan Height
Birth rate: 44 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop
ulation (1990)
Infant mortality rate: 38 deaths/1,000 liv
births (1990)
Life expectancy at birth: 68 years male,
70 years female (1990)
Total fertility rate: 6 7 children born/
woman (1990)
Nationality: noun—Syrian(s), adjective—
Syrian
Ethnic divisions: 90 3% Arab, 9 7% Kurds
Armenians, and other
Religion: 74% Sunni Muslim, 16% Ala-
wite, Druze, and other Muslim sects, 10%
Christian (various sects), tiny Jewish com
munities in Damascus, A] Qamishli, and
Aleppo
Language: Arabic (official), Kurdish, Ar-
menian, Aramaic, Circassian, French
widely understood
Literacy: 49%
Labor force: 2,400,000, 36% miscellaneou
and government services, 32% agriculture
32% industry and construction), majority
unskilled, shortage of skilled labor (1984)
Organized labor: 5% of labor force
Population: 25,970,843 (July 1990),
growth rate 3 4% (1990)
Birth rate: 50 births/1,000 population
(1990)
Death rate: 16 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
304
Infant mortality rate: 107 deaths/1,000
live births (1990)
Life expectancy at birth: 49 years male,
54 years female (1990)
Total fertility rate: 7 1 children born/
woman (1990)
Nationality: noun—Tanzanian(s), adjec-
tive—Tanzanian
Ethnic divisions: mainland—99% native
African consisting of well over 100 tribes,
1% Asian, European, and Arab
Religion: mainland—33% Christian, 33%
Muslim, 33% indigenous beliefs, Zanzi-
bar—almost all Muslim
Language: Swahili and English (official),
English primary language of commerce,
administration, and higher education,
Swahili widely understood and generally
used for communication between ethnic
groups, first language of most people 1s
one of the local languages, primary educa-
tion 1s generally in Swahili
Literacy: 79%
Labor force: 732,200 wage earners, 90%
agriculture, 10% industry and commerce
(1986 est )
Organized labor: 15% of labor force','d10c075a69c98dcb5f33ee835c176f7ead40eec975d3310b11061419b62548d5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5232848d816240a038136b5229eb039d9ba9ebacc3a39a9d3eeef31b0cbf5325',1990,'TG','Togo','people-and-society',705,'Population: 3,674,355 (July 1990), growth
rate 3 7% (1990)
Birth rate: 50 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 112 deaths/ 1,000
live births (1990)
Life expectancy at birth: 53 years male,
57 years female (1990)
Total fertility rate: 7 2 children born/
woman (1990)
Nationality: noun—Togolese (sing and
pl ), adjective—Togolese
307
Approved for Release: 2020/08/12 C06554432
Togo (continued)
Ethnic divisions: 37 tribes, largest and
most important are Ewe, Mina, and
Kabyé, under 1% European and Syrian-
Lebanese
Religion: about 70% indigenous beliefs,
20% Christian, 10% Mushm
Language: French, both official and lan-
guage of commerce, major African lan-
guages are Ewe and Mina in the south
and Dagomba and Kabyé in the north
Literacy: 40 7%
Labor force: NA, 78% agriculture, 22%
industry, about 88,600 wage earners,
evenly divided between public and private
sectors; 50% of population of working age
(1985)
Organized labor: one national union, the
National Federation of Togolese Workers','fb37ea9d7037fc2067f61fcf1513446289b4df68e29ec8c1e77c915ee4bddb7c','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc9de22c4102f04d0a3e970929fe14f1f3c13ccd36682ec961fed9ca99a6792f',1990,'TK','Tokelau','people-and-society',710,'Population: 1,700 (July 1990), growth rate
0 0% (1990)
Birth rate: NA births/1,000 population
(1990)
Death rate: NA deaths/1,000 population
(1990)
Net migration rate: NA migrants/1,000
population (1990)
Infant mortality rate: NA deaths/1,000
live births (1990)
Life expectancy at birth: NA years male,
NA years female (1990)
Total fertility rate: NA children born/
woman (1990)
Nationality: noun—Tokelauan(s), adyec-
tive—Tokelauan
Ethnic divisions: all Polynesian, with cul-
tural ties to Western Samoa
Religion: 70% Congregational Christian
Church, 30% Roman Catholic, on Atafu,
all Congregational Christian Church of
Approved for Release: 2020/08/12 C06554432
Samoa, on Nukunonu, all Roman Catho-
lic, on Fakaofo, both denominations, with
the Congregational Christian Church pre-
dominant
Language: Tokelauan (a Polynesian lan-
guage) and English
Literacy: NA%, but probably high
Labor force: NA
Organized labor: NA','03a8593fb726b07ce5f6920e7972be3ace8fd469a6868f287b223be5fcff1e18','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d507fd2aa0a2c2010081ab1e1b1a30d91cf5644ec3ec073831ba965224745a5',1990,'TT','Trinidad and Tobago','people-and-society',717,'Population: 1,344,639 (July 1990), growth
rate 2 2% (1990)
Birth rate: 28 births/1,000 population
(1990)
Death rate: 6 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 10 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
74 years female (1990)
Total fertility rate: 3 3 children born/
woman (1990)
ee
Scarborough
Nationality: noun—Trinidadian(s), Toba-
goman(s), adjective—Trinidadian, Tobago-
nian
Ethnic divisions: 43% black, 40% East In-
dian, 14% mixed, 1% white, 1% Chinese,
1% other
Religion: 36 2% Roman Catholic, 23 0%
Hindu, 13 1% Protestant, 6 0% Muslim,
21 7% unknown
Language: English (official), Hindi,
French, Spanish
Literacy: 98%
Labor force: 463,900, 18 1% construction
and utilities, 14 8% manufacturing, min-
ing, and quarrying, 10 9% agriculture,
56 2% other (1985 est )
Organized labor: 22% of labor force (1988)
Population: uninhabited','3b5d5b9b6422865e1ebaa012120f6965398da8c13736b4927114d172dad1fcf7','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d578c8b79a3707c940019402a5bae842b93479ee9cc6e25fe1c1c2527824e07',1990,'TC','Turks and Caicos Islands','people-and-society',723,'Population: 9,761 (July 1990), growth rate
2 3% (1990)
Birth rate: 25 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: 4 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 14 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
78 years female (1990)
Total fertility rate: 3 8 children born/
woman (1990)
Nationality: no noun or adjectival forms
Ethnic divisions: majority of African de-
scent
Religion: Anglican, Roman Catholic, Bap-
tist, Methodist, Church of God, Seventh-
Day Adventist
Language: English (official)
Approved for Release: 2020/08/12 C06554432
Literacy: 99% (est )
Labor force: NA, majority engaged in
fishing and tourist industries, some subsis-
tence agriculture
Organized labor: St George’s Industrial
Trade Union','5dd4893512c2e1d637226fe3330f1ac8b24d64f13708201d09bc54e242e88f67','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ff0e40b894ec4752a47f7c7bc3c75a7718a49751f7e7fe6165d9da03923119',1990,'TV','Tuvalu','people-and-society',728,'Population: 9,136 (July 1990), growth rate
2 0% (1990)
Birth rate: 30 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 33 deaths/1,000 live
births (1990)
Life expectancy at birth: 60 years male,
63 years female (1990)
Total fertility rate: 3 1 children born/
woman (1990)
Nationality: noun—Tuvaluans(s), adjec-
tive—Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Christian, predominantly Protes-
tant
Language: Tuvaluan, English
318
Approved for Release: 2020/08/12 C06554432
Literacy: less than 50%
Labor force: NA
Organized labor: none
Population: 17,960,262 (July 1990),
growth rate 3 5% (1990)
Birth rate: 52 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 107 deaths/ 1,000
live births (1990)
Life expectancy at birth: 48 years male,
50 years female (1990)
Total fertility rate: 7 4 children born/
woman (1990)
Nationality: noun—Ugandan(s), adjec-
tive—Ugandan
Ethnic divisions: 99% African, 1% Euro-
pean, Asian, Arab
Approved for Release: 2020/08/12 C06554432
Religion: 33% Roman Catholic, 33% Prot-
estant, 16% Muslim, rest indigenous be-
hefs
Language: English (official), Luganda and
Swahili widely used, other Bantu and Ni-
lotic languages
Literacy: 57 3%
Labor force: 4,500,000 (est ), 94% subsis-
tence activities, 6% wage earners (est ),
50% of population of working age (1983)
Organized labor: 125,000 union members','3833bf6b794b9c175d4a682240673ee949e970cda0386ee521b11ea9172922b9','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae8e5416c7f0fe4e07f57f9317cb5f06edb0af962dfdb053eb4490c5f80764e4',1990,'AE','United Arab Emirates','people-and-society',733,'Population: 2,253,624 (July 1990), growth
rate 6 0% (1990)
Approved for Release: 2020/08/12 C06554432
Birth rate: 31 births/1,000 population
(1990)
Death rate: 3 deaths/1,000 population
(1990)
Net migration rate: 33 migrants/ 1,000
population (1990)
Infant mortality rate: 24 deaths/1,000 live
births (1990)
Life expectancy at birth: 69 years male,
73 years female (1990)
Total fertility rate: 4 9 children born/
woman (1990)
Nationality: noun—Emirian(s), adyective—
Emuirian
Ethnic divisions: 19% Emuirian, 23% other
Arab, 50% South Asian (fluctuating), 8%
other expatriates (includes Westerners and
East Asians), less than 20% of the popula-
tion are UAE citizens (1982)
Religion: 96% Muslim (16% Shi‘a), 4%
Christian, Hindu, and other
Language: Arabic (official), Farsi and En-
glish widely spoken in major cities, Hindi,
Urdu
Literacy: 68%
Labor force: 580,000 (1986 est ), 85% in-
dustry and commerce, 5% agriculture, 5%
services, 5% government, 80% of labor
force 1s foreign
Organized labor: trade unions are illegal','f37f49da0938c0ae77bc08f10ff8f1c1dfb1379c80d8693fbd744b9e0a56efb2','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2582b77df3375d78dedb8021636d428771beeacb5d85dcb8635274f15935f3d',1990,'GB','United Kingdom','people-and-society',738,'Population: 57,365,665 (July 1990),
growth rate 0 3% (1990)
Birth rate: 14 births/1,000 population
(1990)
Death rate: 11 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 7 deaths/1,000 live
births (1990)
Life expectancy at birth: 73 years male,
79 years female (1990)
Total fertility rate: 1 8 children born/
woman (1990)
Nationality: noun—Briton(s), British (col-
lective pl ), adyective—British
Ethnic divisions: 81 5% English, 9 6%
Scottish, 2 4% Irish, 1 9% Welsh, 1 8%
Ulster, 2 8% West Indian, Indian, Paki-
stam, and other
Religion: 27 0 million Anglican, 5 3 mil-
hoon Roman Catholic, 2 0 million Presby-
terian, 760,000 Methodist, 410,000 Jewish
Language: English, Welsh (about 26% of
population of Wales), Scottish form of
Gaelic (about 60,000 in Scotland)
Literacy: 99%
Labor force: 28,120,000, 53 3% services,
23 6% manufacturing and construction,
10 8% self-employed, 6 8% government,
1 0% agriculture (1988)
Organized labor: 37% of labor force (1987)','64b44b414021efc0d5bf362a7df0a6f4e3dda73e4e679d97147187318a8e21f6','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f33e4b63b25a24e31b6d9f8db5b4a9d5cd858e1b98d72e2aa4096ec52712c7d',1990,'UY','Uruguay','people-and-society',744,'Population: 3,036,660 (July 1990), growth
rate 0 6% (1990)
Birth rate: 17 births/1,000 population
(1990)
Death rate: 10 deaths/1,000 population
(1990)
Net migration rate: —2 migrants/1,000
population (1990)
Infant mortality rate: 22 deaths/1,000 live
births (1990)
Life expectancy at birth: 70 years male,
76 years female (1990)
326
Total fertility rate: 2 4 children born/
woman (1990)
Nationality: noun—Uruguayan(s), adjec-
tive—Uruguayan
Ethnic divisions: 88% white, 8% mestizo,
4% black
Religion: 66% Roman Catholic (less than
half adult population attends church regu-
larly), 2% Protestant, 2% Jewish, 30%
nonprofessing or other
Language: Spanish
Literacy: 94%
Labor force: 1,300,000, 25% government,
19% manufacturing, 11% agriculture, 12%
commerce, 12% utilities, construction,
transport, and communications, 21% other
services (1988 est )
Organized labor: Interunion Workers’
Assembly / National Workers’ Confedera-
tion (PIT/CNT) Labor Federation','f24a73e35bd41f169916449657e0abab930990f02e53554e689bf91b1b1e7524','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f433c7b2a036e094f84ada7dacdb9a3172b4089d6f1fb6679abc612da175752c',1990,'VU','Vanuatu','people-and-society',749,'Population: 165,006 (July 1990), growth
rate 3 2% (1990)
Birth rate: 37 births/1,000 population
(1990)
Death rate: 5 deaths/ 1,000 population
(1990)
Net migration rate: 0 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 36 deaths/ 1,000 live
births (1990)
Life expectancy at birth: 67 years male,
72 years female (1990)
327
Approved for Release: 2020/08/12 C06554432
Approved for Release: 2020/08/12 C06554432
Vanuatu (continued)
Total fertility rate: 5 5 children born/
woman (1990)
Nationality: noun—Vanuatuan(s), adjec-
tive—Vanuatuan
Ethnic divisions: 94% indigenous Melane-
sian, 4% French, remainder Vietnamese,
Chinese, and various Pacific Islanders
Religion: most at least nominally Chris-
tian
Language: English and French (official),
pidgin (known as Bislama or Bichelama)
Literacy: 10-20% (est )
Labor force: NA
Organized labor: 7 registered trade
unions-—largest include Oil and Gas
Workers’ Union, Vanuatu Airline Work-
ers’ Union
Population: 774 (July 1990), growth rate
0 5% (1990)
Nationality: no noun or adjectival forms
Ethnic divisions: primarily Italians but
also many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various
other languages
Literacy: 100%
Labor force: about 1,500, Vatican City
employees divided into three categories—
executives, office workers, and salaried
employees
Organized labor: Association of Vatican
Lay Workers, 1,800 members (1987)
Population: 19,698,104 (July 1990),
growth rate 2 5% (1990)
Birth rate: 28 births/1,000 population
(1990)
330
Approved for Release: 2020/08/12 C06554432
Death rate: 4 deaths/1,000 population
(1990)
Net migration rate: | migrant/1,000 popu-
lation (1990)
Infant mortality rate: 27 deaths/1,000 live
births (1990)
Life expectancy at birth: 7] years male,
77 years female (1990)
Total fertility rate: 3 4 children born/
woman (1990)
Nationality: noun—Venezuelan(s), adyec-
tive—Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2% Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (official), Indian dia-
lects spoken by about 200,000 Amerin-
dians in the remote interior
Literacy: 85 6%
Labor force: 5,800,000, 56% services, 28%
industry, 16% agriculture (1985)
Organized labor: 32% of labor force','57c835a42d321c20a9734238b6fc54fcc491820444de5896b5c4bea6af4db0cc','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('848b84f105d3c3af0a80d12b56ec38e9b53a77e17d81b3969b028ae59ac33f97',1990,'EH','Western Sahara','people-and-society',759,'Population: 191,707 (July 1990), growth
rate 2 7% (1990)
Birth rate: 48 births/1,000 population
(1990)
Death rate: 23 deaths/1,000 population
(1990)
Net migration rate: 2 migrants/1,000 pop-
ulation (1990)
Infant mortality rate: 177 deaths/ 1,000
live births (1990)
Life expectancy at birth: 39 years male,
41 years female (1990)
337
Approved for Release: 2020/08/12 C06554432
Western Sahara (continued)
Total fertility rate: 7 3 children born/
woman (1990)
Nationality: noun—Saharan(s), Moroc-
can(s), adjective—Saharan, Moroccan
Ethnic divisions: Arab and Berber
Religion: Muslim
Language: Hassaniya Arabic, Moroccan
Arabic
Literacy: 20% among Moroccans, 5%
among Saharans (est )
Labor force: 12,000, 50% animal
husbandry and subsistence farming
Organized labor: NA
Population: 186,031 (July 1990), growth
rate 2 3% (1990)
Birth rate: 34 births/1,000 population
(1990)
Death rate: 7 deaths/1,000 population
(1990)
Net migration rate: — 5 migrants/1,000
population (1990)
Infant mortality rate: 48 deaths/1,000 live
births (1990)
Life expectancy at birth: 64 years male,
69 years female (1990)
Total fertility rate: 4 6 children born/
woman (1990)
Nationality: noun—Western Samoan(s),
adjective—Western Samoan
Ethnic divisions: Samoan, about 7% Euro-
nesians (persons of European and Polyne-
sian blood), 0 4% Europeans
Religion: 99 7% Christian (about half of
population associated with the London
Missionary Society, includes Congrega-
tional, Roman Catholic, Methodist, Latter
Day Saints, Seventh-Day Adventist)
Language: Samoan (Polynesian), English
Literacy: 90%
Labor force: 37,000, 22,000 employed in
agriculture (1983 est )
Organized labor: Public Service Associa-
tion (PSA)
Population: 5,316,644,000 (July 1990),
growth rate | 7% (1990)
Birth rate: 27 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Infant mortality rate: 70 deaths/1,000 live
births (1990)
Life expectancy at birth: 60 years male,
64 years female (1990)
Total fertility rate: 3 4 children born/
woman (1990)
Literacy: 77% men, 66% women (1980)
Labor force: 1,939,000,000 (1984)
Organized labor: NA
Population: 7,160,981 (July 1990), growth
rate 3 1% (1990)
Birth rate: 52 births/1,000 population
(1990)
Death rate: 17 deaths/1,000 population
(1990)
Approved for Release: 2020/08/12 C06554432
Net migration rate: — 4 migrants/1,000
population (1990)
Infant mortality rate: 129 deaths/1,000
live births (1990)
Life expectancy at birth: 48 years male,
49 years female (1990)
Total fertility rate: 7 6 children born/
woman (1990)
Nationality: noun—Yemeni(s), adjective—
Yemeni
Ethnic divisions: 90% Arab, 10% Afro-
Arab (mixed)
Religion: 100% Muslim (Sunni and Shi‘a)
Language: Arabic
Literacy: 15% (est )
Labor force: NA, 70% agriculture and
herding, 30% expatriate laborers (est )
Population: 2,585,484 (July 1990), growth
rate 3 2% (1990)
Birth rate: 48 births/1,000 population
(1990)
Death rate: 14 deaths/1,000 population
(1990)
Net migration rate: —2 migrants/1,000
population (1990)
Infant mortality rate: 110 deaths/1,000
live births (1990)
Life expectancy at birth: 50 years male,
54 years female (1990)
Total fertility rate: 7 0 children born/
woman (1990)
Nationality: noun—Yemeni(s), adjective—
Yemeni
Ethnic divisions: almost all Arabs, a few
Indians, Somalis, and Europeans
Religion: Sunni Muslim, some Christian
and Hindu
Language: Arabic
Literacy: 25%
Labor force: 477,000, 45 2% agriculture,
21 2% services, 13 4% construction, 10 6%
industry, 9 6% commerce and other (1983)
Organized labor: 348,200, the General
Confederation of Workers of the People’s
Democratic Republic of Yemen has
35,000 members','99efde170b54aa4f8ee61865d4479c49fdea9e550c2259ffadfef5fc79d8d128','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d737c374a3c9fe5cd91fb45ea6065e6227a8b3970ff8b9b71ae4e5c72927728e',1990,'ZM','Zambia','people-and-society',764,'Population: 8,112,782 (July 1990), growth
rate 3 2% (1990)
Birth rate: 49 births/1,000 population
(1990)
Death rate: 12 deaths/1!,000 population
(1990)
Net migration rate: — 6 migrants/1,000
population (1990)
Infant mortality rate: 80 deaths/ 1,000 live
births (1990)
347
Approved for Release: 2020/08/12 C06554432
Zambia (continued)
Life expectancy at birth: 55 years male,
58 years female (1990)
Total fertility rate: 7 0 children born/
woman (1990)
Nationality: noun—Zambian(s), adjec-
tive—Zambian
Ethnic divisions: 98 7% African, 1 1% Eu-
ropean, 0 2% other
Religion: 50-75% Christian, 1% Mushm
and Hindu, remainder indigenous beliefs
Language: English (official), about 70 in-
digenous languages
Literacy: 75 7%
Labor force: 2,455,000, 85% agriculture,
6% mining, manufacturing, and construc-
tion, 9% transport and services
Organized labor: about 238,000 wage
earners are unionized','d0ab869afbeab0529d3f4abf5511fc263274b8096f47b41bcc19b9ab23c9ddfc','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('843cf3cf5ac6b9477a8a7fdb1d1f5ea9496e3695fc1de0be6e28a77312c516e7',1990,'ZW','Zimbabwe','people-and-society',770,'Population: 10,392,161 (July 1990),
growth rate 3 3% (1990)
Birth rate: 42 births/1,000 population
(1990)
Death rate: 9 deaths/1,000 population
(1990)
Net migration rate: 0 migrants/ 1,000 pop-
ulation (1990)
Infant mortality rate: 65 deaths/1,000 live
births (1990)
Life expectancy at birth: 59 years male,
63 years female (1990)
Total fertility rate: 5 8 children born/
woman (1990)
Approved for Release: 2020/08/12 C06554432
Nationality: noun—Zimbabwean(s), adjec-
tive—Zimbabwean
Ethnic divisions: 98% African (71% Shona,
16% Ndebele, 11% other), 1% white, 1%
mixed and Asian
Religion: 50% syncretic (part Christian,
part indigenous beliefs), 25% Christian,
24% indigenous beliefs, a few Muslim
Language: English (official), Shona and
Ndebele
Literacy: 74%
Labor force: 3,100,000, 74% agriculture,
16% transport and services, 10% mining,
manufacturing, construction (1987)
Organized labor: 17% of wage and salary
earners have union membership
Population: 20,546,664 (July 1990),
growth rate 1 1% (1990)
Birth rate: 16 births/1,000 population
(1990)
Death rate: 5 deaths/1,000 population
(1990)
Net migration rate: NEGL migrants/
1,000 population (1990)
Approved for Release: 2020/08/12 C06554432
Infant mortality rate: 17 deaths/1,000 live
births (1990)
Life expectancy at birth: 72 years male,
77 years female (1990)
Total fertility rate: 1 7 children born/
woman (1990)
Nationality: noun—Chinese (sing , pl! ),
adyective—Chinese
Ethnic divisions: 84% Taiwanese, 14%
mainland Chinese, 2% aborigine
Religion: 93% mixture of Buddhist, Con-
fucian, and Taoist, 4 5% Christian, 2 5%
other
Language: Mandarin Chinese (official),
Taiwanese and Hakka dialects also used
Literacy: 94%
Labor force: 7,880,000, 41% industry and
commerce, 32% services, 20% agriculture,
7% civil administration (1986)
Organized labor: 1,300,000 or about
18 4% (government controlled) (1983)
Administration
Long-form name: none
Type: one-party presidential regime, oppo-
sition political parties legalized in March,
1989
Capital: Taipei
Administrative divisions: 16 counties
(hsien, singular and plural), 5
municipalities* (shih, singular and plural),
2 special municipalities** (chuan-shth,
singular and plural), Chang-hua, Chia-1,
Chia-1*, Chi-lung*, Hsin-chu, Hsin-chu’*,
Hua-lien, I-lan, Kao-hsiung,
Kao-hsiung**, Miao-li, Nan-t’ou, P’eng-
hu, P’ing-tung, T’a1-chung, T’ai-chung*,
T’ai-nan, T’ai-nan*, T’ai-pei, T’al-pei**,
T’ai-tung, T’ao-yuan, Yun-lin, note—the
Wade-Giles system 1s used for romaniza-
tion
Constitution: 25 December 1947
Legal system: based on civil law system,
accepts compulsory ICJ jurisdiction, with
reservations
National holiday: National Day (Anniver-
sary of the Revolution), 10 October (1911)
Executive branch: president, vice presi-
dent, premier of the Executive Yuan, vice
premier of the Executive Yuan, Executive
Yuan
Legislative branch: unicameral Legislative
Yuan
Judicial branch: Judicial Yuan
Leaders: Chief of State—President LI
Teng-hui (since 13 January 1988), Vice
President LI Yuan-tzu (will take office 20
May 1990),
Head of Government—Premier (President
of the Executive Yuan) HAO Po-ts’un
(since May 2 1990), Vice Premier (Vice
President of the Executive Yuan) SHIH
Ch’1-yang (since NA July 1988)
Political parties and leaders: Kuomintang
(Nationalist Party), LI Teng-hui, chair-
man, Democratic Socialist Party and
Young China Party controlled by Kuo-
mintang, Democratic Progressive Party
(DPP), Labor Party, 27 other minor par-
ties
Suffrage: universal at age 20
Elections: Pres:dent—iast held 21 March
1990 (next to be held March 1996), re-
sults—President Li Teng-hui was elected
by the National Assembly,
Vice Prestdent—last held 22 March 1990
(next to be held March 1996), results—Li
Yuan-tzu was elected by the Nationa! As-
sembly,
Legislative Yuan—last held 2 December
1989 (next to be held December 1992),
results—KMT 65%, DPP 33%, indepen-
dents 2%, seats—(304 total, 102 elected)
KMT 78, DPP 21, independents 3
Member of: expelled from UN General
Assembly and Security Council on 25 Oc-
tober 1971 and withdrew on same date
from other charter-designated subsidiary
organs, expelled from IMF/World Bank
group April/May 1980, member of ADB
and PECC, seeking to join GATT and/or
MFA, attempting to retain membership in
ICAC, ISO, INTELSAT, INTERPOL,
IWC— International Wheat Council, sus-
pended from IAEA 1n 1972, but still al-
lows IAEA controls over extensive atomic
development
Diplomatic representation: none, unofficial
commercial and cultural relations with the
people of the US are maintained through
a private instrumentality, the Coordina-
tion Council for North American Affairs
(CCNAA) with headquarters in Taipei
and field offices in Washington and 10
other US cities with all addresses and
telephone numbers NA, US—unofficial
commercial and cultural relations with the
people of Taiwan are maintained through
a private institution, the American Insti-
tute in Taiwan (AIT), which has offices in
Taipei at 7 Lane 134, Hsin Y1 Road, Sec-
tion 3 with telephone 002 [886] (2) 709-
2000 and in Kao-hsiung at 88 Wu Fu 3rd
Road with telephone NA
Flag: red with a dark blue rectangle in the
upper hoist-side corner bearing a white
sun with 12 triangular rays','e93952b2dd03d0dd53cdd91ca0b7079cd78ca7d3de7ce932546d52e1463b5b43','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5c953d8b563c977bf7d721f028379c4a21f9d54e703ef98fb900f5148655596',1990,'VU','Vanuatu','environment',266,'GDP: purchasing power parity-$128 billion (1997 est.)
GDP-real growth rate: 8.5% (1997 est.)
GDP-per capita: purchasing power parity-$1,700 (1997 est.)
GDP-composition by sector:
agriculture: 28%
industry: 30%
services: 42% (1996 est.)
Inflation rate-consumer price index: 5% (1997)
Labor force:
total: 32.7 million
by occupation: agriculture 65%, industry and services 35% (1990 est.)
Unemployment rate: 25% (1995 est.)
Budget:
revenues: $5.6 billion
expenditures: $6 billion, including capital expenditures of $1.7
billion (1996 est.)
Industries: food processing, garments, shoes, machine building,
mining, cement, chemical fertilizer, glass, tires, oil
Industrial production growth rate: 12% (1997 est.)
Electricity-capacity: 5.32 million kW (1995)
Electricity-production: 12.3 billion kWh (1995)
Electricity-consumption per capita: 165 kWh (1995)
Agriculture-products: paddy rice, corn, potatoes, rubber, soybeans,
coffee, tea, bananas; poultry, pigs; fish
Exports:
total value: $7.1 billion (f.o.b., 1996 est.)
commodities: crude oil, marine products, rice, coffee, rubber, tea,
garments, shoes
partners: Japan, Germany, Singapore, Taiwan, Hong Kong, France, South
Korea
Imports:
total value: $11.1 billion (f.o.b., 1996 est.)
commodities: machinery and equipment, petroleum products, fertilizer,
steel products, raw cotton, grain, cement, motorcycles
partners: Singapore, South Korea, Japan, France, Hong Kong, Taiwan
Debt-external: $7.3 billion Western countries; $4.5 billion CEMA debts
primarily to Russia; $9 billion to $18 billion nonconvertible debt
(former CEMA, Iraq, Iran)
Economic aid:
recipient: ODA, $NA
note: $2.4 billion in credits and grants pledged by international
donors for 1997
Currency: 1 new dong (D) = 100 xu
Exchange rates: new dong (D) per US$1-12,300 (January 1998), 11,100
(December 1996), 11,193 (1995 average), 11,000 (October 1994), 10,800
(November 1993), 8,100 (July 1991)
Fiscal year: calendar year','273ca682bd3de14b3d049f964e2a96fdfdd0526c9a1c927be97862c46d24880b','internet-archive','the1990ciaworldf00014gut','txt','fa52054bed12de40c7c9f0c78e7f7bfd0303508a3049f9277fd2b1555e5ec706','https://archive.org/download/the1990ciaworldf00014gut/world98.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

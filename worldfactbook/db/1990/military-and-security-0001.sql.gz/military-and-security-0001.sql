SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7071b863086f0b798679a6c3b2a3d50032142119be206ce41ba1085f7b8a44c3',1990,'ZM','Zambia','military-and-security',767,'Military manpower: males 15-49,
1,683,758, 883,283 fit for military service
Defense expenditures: NA','6309f68ee7a9dc7f421864d2e268c2843f5fbec6f6fba92ae15fbfb1acb49df5','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ae028b0f0ddaaade16fae4c167ee90e7e35f1187db8d153f849303149672027',1990,'ZW','Zimbabwe','military-and-security',768,'200 km
Boundary representation is
not necessarily authoritative
» HARARE
*Chitungevizd
*
Hwange
Qweru,
* Bulawayo
See regional map VII','e14a529f7926e341b92623e83c96f19b16efd2c70daf551a30d57eb9395ac18b','internet-archive','cia-readingroom-document-06554432','txt','fe5c6d13098ebd79a9675a723cad2e7eeeeebeec3284e9b39c79fc9102f4282b','https://archive.org/download/cia-readingroom-document-06554432/06554432_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae60e474a6e922a881440c52564da872263bcdb4be55f27fa467701928214d10',2010,'US','United States','transnational-issues',132,'Disputes— international
Refugees and internally displaced
persons
refugees
lDPs
Trafficking in persons
current situation
tier rating
Illicit drugs
xxxv
s
■
'' ■
v V
. . •
''
• •
V
.
«
-
■
r
F .
1
■*
F t
''
Refugees and internally displaced
persons: IDPs: undetermined (the UN does
not estimate there are any IDPs, although
some NGOs estimate over 200,000 IDPs
as a result of over three decades of internal
conflict that ended in 1996) (2007)
Trafficking in persons: current situation:
Guatemala is a source, transit, and destina¬
tion country for Guatemalans and Central
Americans trafficked for the purposes of
commercial sexual exploitation and forced
labor; human trafficking is a significant
and growing problem in the country;
Guatemalan women and children are traf¬
ficked within the country for commercial
sexual exploitation, primarily to Mexico
and the United States; Guatemalan
men, women, and children are also traf¬
ficked within the country, and to Mexico
and the United States, for forced labor
tier rating: Tier 2 Watch List— for a
second consecutive year, Guatemala is
on the Tier 2 Watch List for its failure to
provide evidence of increasing efforts to
combat trafficking in persons, particularly
with respect to ensuring that trafficking
offenders are appropriately prosecuted for
their crimes; while prosecutors initiated
trafficking prosecutions, they continued
to face problems in court with application
of Guatemala’s comprehensive anti-traf¬
ficking law; the government made modest
improvements to its protection efforts, but
assistance remained inadequate overall in
2007 (2008)
284
Disputes— international: the US. has
intensified domestic security measures
and is collaborating closely with its neigh¬
bors, Canada and Mexico, to monitor and
control legal and illegal personnel, trans¬
port, and commodities across the interna¬
tional borders; abundant rainfall in recent
years along much of the Mexico-US border
region has ameliorated periodically strained
water-sharing arrangements; 1 990 Maritime
Boundary Agreement in the Bering Sea still
awaits Russian Duma ratification; managed
maritime boundary disputes with Canada
at Dixon Entrance, Beaufort Sea, Strait of
Juan de Fuca, and around the disputed
Machias Seal Island and North Rock; The
Bahamas and US have not been able to
agree on a maritime boundary; US Naval
Base at Guantanamo Bay is leased from
Cuba and only mutual agreement or US
abandonment of the area can terminate the
lease; Haiti claims US-administered Navassa
Island; US has made no territorial claim in
Antarctica (but has reserved the right to do
so) and does not recognize the claims of
any other states; Marshall Islands claims
Wake Island; Tokelau included American
Samoa’s Swains Island among the islands
listed in its 2006 draff constitution
Refugees and internally displaced
persons: refugees (country of origin ): the US
admitted 62,643 refugees during FY04/05
including; 10,586 (Somalia); 8,549 (Laos);
6,666 (Russia); 6,479 (Cuba); 3,100 (Haiti);
2,136 (Iran) (2006)
Illicit drugs: world’s largest consumer of
cocaine (shipped from Colombia through
Mexico and the Caribbean), Colombian
heroin, and Mexican heroin and marijuana;
major consumer of ecstasy and Mexican
methamphetamine; minor consumer of
high-quality Southeast Asian heroin; illicit
producer of cannabis, marijuana, depres¬
sants, stimulants, hallucinogens, and meth¬
amphetamine; money-laundering center
UNITED STATES PACIFIC ISLAND WILDLIFE REFUGES
msss&w*****™™
v.frv/M \\
USSR
Union of Soviet Socialist Republics (Soviet Union); used for information dated before 25
December 1991
UTC
Coordinated Universal Time
UV
ultra violet
VHF
very-high-frequency
VSAT
very small aperture terminal
WADB
West African Development Bank
WAEMU
West African Economic and Monetary Union
WCL
World Confederation of Labor
WCO
World Customs Organization
Wetlands
Convention on Wedands of International Importance Especially As Waterfowl Habitat
WEU
Western European Union x v
WFP
World Food Program
WFTU
World Federation of Trade Unions
Whaling
International Convention for the Regulation of Whaling
WHO
World Health Organization
WIPO
World Intellectual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact
WTO
World Trade Organization
ZC
Zangger Committee
770
APPENDIX B
INTERNATIONAL ORGANIZATIONS AND GROUPS
advanced developing countries
another term for those less developed countries (LDCs) with particularly rapid industrial development; see newly industrializing economies
(NIEs)
advanced economies
a term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced economies, countries in transition,
and developing countries; it includes the following 28 advanced economies: Australia, Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway,
Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan, UK, US; note— this group would presumably also cover the following seven
smaller countries of Andorra, Bermuda, Faroe Islands, Holy See, Liechtenstein, Monaco, and San Marino that are included in the more
comprehensive group of “developed countries”
African Development Bank Group (AfDB)
note— regional multilateral development finance institution temporarily located in Tunis, Tunisia; the Bank Group consists of the African
Development Bank, the African Development Fund, and the Nigerian Trust Fund
established- 10 September 1964
aim- to promote economic development and social progress
regional members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African Republic,
Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea,
Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania,
Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia,
South Africa, Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members— (24) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France, Germany, India, Italy, Japan,
South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden, Switzerland, UK, US
African Union (AU)
note— replaces Organization of African Unity (OAU)
established-8 July 2001
aim-to achieve greater unity among African States; to defend states’ integrity and independence; to accelerate political, social, and
economic integration; to encourage international cooperation; to promote democratic principles and institutions
members— (5 3) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia,
Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius,
Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic (Western Sahara), Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
African, Caribbean, and Pacific Group of States (ACP Group)
established-6 June 1975
aim-to manage their preferential economic and aid relationship with the EU
members— (79) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon,
Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana,
Grenada, Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali, Marshall Islands,
Mauritania, Mauritius, Federated States of Micronesia, Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau, Papua New Guinea,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sudan, Suriname, Swaziland, Tanzania, Timor-Leste, Togo, Tonga, Trinidad and
Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean (OPANAL)
note— acronym from Organismo para la Proscripcion de las Armas Nucleares en la America Latina y el Caribe (OPANAL)
established- 14 February 1967 under the Treaty of Tlatelolco; effective— 25 April 1969 on the 11th ratification
aim-to encourage the peaceful uses of atomic energy and prohibit nuclear weapons
members— ( 33) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba,
Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua,
Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago,
Uruguay, Venezuela
Andean Community of Nations (CAN)
note— formerly known as the Andean Group (AG) and the Andean Common Market (Ancom)
established-26 May 1969; present name established 1 October 1992; effective— 16 October 1969
aim-to promote harmonious development through economic integration
771
THE CIA WORLD FACTBOOK
members— (4) Bolivia, Colombia, Ecuador, Peru
associate members— (5) Argentina, Brazil, Chile, Paraguay, Uruguay
observers— (2) Mexico, Panama
Arab Bank for Economic Development in Africa (ABEDA)
note— also known as Banque Arabe de Developpement Economique en Afrique (BADEA)
established- 18 February 1974; effective— 16 September 1974
aim- to promote economic development
members— (17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation Organization; note— these are all the members
of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
Arab Fund for Economic and Social Development (AFESD)
established- 16 May 1968 v
aim-to promote economic and social development
members— ( 20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq (suspended 1993), Jordan, Kuwait,
Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia (suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen,
Palestine Liberation Organization
Arab Maghreb Union (AMU)
established-1 7 February 1 989
aim-to promote cooperation and integration among the Arab states of northern Africa
members— (5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF)
established-21 April 1976; effective— 2 February 1977
aim-to promote Arab cooperation, development, and integration in monetary and economic affairs
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arctic Council
established-l 8 September 1996
aim-to address the common concerns and challenges faced by Arctic governments and the people of the Arctic; to protect the Arctic','52b77c211417867396c5d39a86556a6e52cca8f0cdadc7a5063672cdf5aebf52','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14409f0ff5cf403c481e9d552e28c9ba2d2608e363ed9b3eea669bee3f2768d',2010,'TJ','Tajikistan','transnational-issues',133,'rmmmmrm
Kondoz
Bagram
Towraghofidt
H@r&t
KABUL1
Ghazni”
SWndarsd
Kandahar.
Disputes— international: involved in
complex dispute with China, Malaysia,
Philippines, Vietnam, and possibly
Brunei over the Sprady Islands; the 2002
“Declaration on die Conduct of Parties in
the South China Sea” has eased tensions
but falls short of a legally binding “code of
conduct” desired by several of the dispu¬
tants; Paracel Islands are occupied by China,
but claimed by Taiwan and Vietnam; in
2003, China and Taiwan became more
vocal in rejecting both Japan’s claims to
the uninhabited islands of the Senkaku-
shoto (Diaoyu Tai) and Japan’s unilaterally
declared exclusive economic zone in the
East China Sea where all parties engage in
hydrocarbon prospecting
Illicit drugs: regional transit point for
heroin, methamphetamine, and precursor
chemicals; transshipment point for drugs
to Japan; major problem with domestic
consumption of methamphetamine and
heroin; rising problems with use of keta¬
mine and club drugs
Disputes — international: in 2006, China
and Tajikistan pledged to commence
demarcation of the revised boundary
agreed to in the delimitation of 2002; talks
continue with Uzbekistan to delimit border
and remove minefields; disputes in Isfara
Valley delay delimitation with Kyrgyzstan
Trafficking in persons: current situation:
Tajikistan is a source country for women
trafficked through Kyrgyzstan and Russia
to the UAE, Turkey, and Russia for the
purpose of commercial sexual exploita¬
tion; men are trafficked to Russia and
Kazakhstan for the purpose of forced
labor, primarily in the construction and
agricultural industries; boys and girls are
trafficked internally for various purposes,
including forced labor and forced begging
tier rating: Tier 2 Watch List— Tajikistan
is on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat human trafficking, especially
efforts to investigate, prosecute, convict,
and sentence traffickers; despite evidence
of low- and mid-level officials’ complicity
in trafficking, the government did not
punish any public officials for trafficking
complicity during 2007; lack of capacity
and poor coordination between govern¬
ment institutions remained key obstacles
to effective anti-trafficking efforts (2008)
Illicit drugs: major transit country for
Afghan narcotics bound for Russian and, to
a lesser extent, Western European markets;
limited illicit cultivation of opium poppy
for domestic consumption; Tajikistan
seizes roughly 80% of all drugs captured
in Central Asia and stands third worldwide
in seizures of opiates (heroin and raw
opium); significant consumer of opiates
TANZANIA
Disputes — international: Tanzania still
hosts more than a half-million refugees,
more than any other African country,
mainly from Burundi and the Democratic
Republic of the Congo, despite the interna¬
tional community’s efforts at repatriation;
disputes with Malawi over the boundary in
Lake Nyasa (Lake Malawi) and the mean¬
dering Songwe River remain dormant
Refugees and internally displaced
persons: refugees ( country of origin .):
352,640 (Burundi); 127,973 (Democratic
Republic of the Congo) (2007)
Illicit drugs: growing role in transshipment
of Southwest and Southeast Asian heroin
and South American cocaine destined for
South African, European, and US markets
and of South Asian methaqualone bound
for southern Africa; money laundering
remains a problem
669
THE CIA WORLD FACTBOOK','de16fe9a9780fc44a9e2119bb42294e037ba53b37c8181b82d90fab869fafe6d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c553bd000b7c619d98ea773e8412d50bc6c758fba4afb3c46c228f4e939a9cce',2010,'AF','Afghanistan','transnational-issues',142,'Disputes— international: Pakistan has
built fences in some portions of its border
with Afghanistan which remains open in
some areas to foreign terrorists and other
illegal activities
Refugees and internally displaced
persons: IDPs: 132,246 (mosdy Pashtuns
and Kuchis displaced in south and west
due to drought and instability) (2007)
illicit drugs: world’s largest producer of
opium; poppy cultivation decreased 22%
to 157,000 hectares in 2008 but remains
at a historically high level; less favorable
growing conditions in 2008 reduced
potential opium production to 5,500
metric tons, down 31 percent from 2007;
if the entire opium crop were processed,
648 metric tons of pure heroin potentially
could be produced; the Taliban and other
antigovernment groups participate in and
profit from the opiate trade, which is a key
source of revenue for the Taliban inside
Afghanistan; widespread corruption and
instability impede counterdrug efforts;
most of the heroin consumed in Europe
and Eurasia is derived from Afghan opium;
vulnerable to drug money laundering
through informal financial networks;
regional source of hashish (2008)
AKROTIRI
Background: By terms of the 1 960 Treaty of
Establishment that created the independent
Republic of Cyprus, the UK retained full
sovereignty and jurisdiction over two areas
of almost 254 square kilometers— Akrotiri
and Dhekelia. The southernmost and
smallest of these is the Akrotiri Sovereign
Base Area, which is also referred to as the
Western Sovereign Base Area.','df880dbec85450a6750b33e9a1d021b457c583a796a24c5601390b28b83c67a4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8cc01e06c34810d5ae15d0cd84d97bec769a69cbcef53bb1e27fbaeb33c22bf',2010,'DZ','Algeria','transnational-issues',154,'Disputes— international: the Albanian
Government calls for the protection of the
rights of ethnic Albanians in neighboring
countries, and the peaceful resolution of
interethnic disputes; some ethnic Albanian
groups in neighboring countries advocate
for a “greater Albania,” but the idea has
little appeal among Albanian nationals; the
mass emigration of unemployed Albanians
remains a problem for developed countries,
chiefly Greece and Italy
Trafficking in parsons: current situation:
Albania is a source country for women and
girls trafficked for the purpose of commercial
sexual exploitation and forced labor; it is
no longer considered a major country of
transit; Albanian victims are trafficked to
Greece, Italy, Macedonia, and Kosovo,
with many trafficked onward to Western
European countries; children were also
what the secular elite feared would be an
extremist-led government from assuming
power. The army began a crackdown on the
FIS that spurred FIS supporters to begin
attacking government targets. The govern¬
ment later allowed elections featuring pro¬
government and moderate religious-based
parties, but did not appease the activists
who progressively widened their attacks.
The fighting escalated into an insurgency,
which saw intense fighting between 1 992—
98 and which resulted in over 100,000
deaths— many attributed to indiscriminate
massacres of villagers by extremists. The
government gained the upper hand by
the late-1990s and FIS’s armed wing, the
Islamic Salvation Army, disbanded in
January 2000. However, small numbers
of armed militants persist in confronting
government forces and conducting
ambushes and occasional attacks on villages.
The army placed Abdelaziz BOUTEFLIKA
in the presidency in 1999 in a fraudulent
election but claimed neutrality in his 2004
landslide reelection victory. Longstanding
problems continue to face BOUTEFLIKA
in his second term, including large-scale
unemployment, a shortage of housing,
unreliable electrical and water supplies,
government inefficiencies and corruption,
and the continuing activities of extremist
trafficked to Greece for begging and other
forms of child labor; approximately half of
all Albanian trafficking victims are under
age 18; internal sex trafficking of women
and children is on the rise
tier rating: Tier 2 Watch List— Albania is
on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat trafficking in persons in
2007, particularly in the area of victim
protection; the government did not appro¬
priately identify trafficking victims during
2007, and has not demonstrated that it
is vigorously investigating or prosecuting
complicit officials (2008)
Illicit drugs: increasingly active transship¬
ment point for Southwest Asian opiates,
hashish, and cannabis transiting the Balkan
route and— to a lesser extent— cocaine from
South America destined for Western
Europe; limited opium and expanding
cannabis production; ethnic Albanian
narcotrafficking organizations active
and expanding in Europe; vulnerable to
money laundering associated with regional
trafficking in narcotics, arms, contraband,
and illegal aliens
militants. The Salafist Group for Preaching
and Combat (GSPC) in 2006 merged
with al-Qaida to form al-Qaida in the
Lands of the Islamic Maghreb, which
since has launched an ongoing series of
kidnappings and bombings— including
high-profile, mass-casualty suicide attacks
targeted against the Algerian government
and Western interests. Algeria must also
diversify its petroleum-based economy,
which has yielded a large cash reserve
but which has not been used to redress
Algeria’s many social and infrastructure
problems.
Disputes— international: Algeria, and
many other states, rejects Moroccan
administration of Western Sahara; the
Polisario Front, exiled in Algeria, represents
the Sahrawi Arab Democratic Republic;
Algeria’s border with Morocco remains an
irritant to bilateral relations, each nation
accusing the other of harboring militants
and arms smuggling; Algeria remains
concerned about armed bandits operating
throughout the Sahel who sometimes desta¬
bilize southern Algerian towns; dormant
disputes include Libyan claims of about
32,000 sq km still reflected on its maps
of southeastern Algeria and the FLN’s
assertions of a claim to Chirac Pastures in
southeastern Morocco
Refugees and internally displaced
persons: refugees ( country of origin ):
90,000 (Western Saharan Sahrawi, mostly
living in Algerian-sponsored camps in the
southwestern Algerian town of Tindouf)
I DPs: undetermined (civil war during
1990s) (2007)
Trafficking in persons: current situation:
Algeria is a transit country for men and
women trafficked from sub-Saharan Africa
12','3119cd69b93a962d12c11becc89128d8e51c673fa7bba0665c3f40216647eae8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be7adf12c13ca49472c78b1a20acfb0c300841f94c49bfb70cb93a9d373366b9',2010,'AS','American Samoa','transnational-issues',162,'to Europe for the purposes of commercial
sexual exploitation and involuntary
servitude; Algerian children are trafficked
internally for the purpose of domestic
servitude or street vending
tier rating: Tier 3— Algeria did not report any
serious law enforcement actions to punish
traffickers who force women into commer¬
cial sexual exploitation or men into invol¬
untary servitude in 2007; the government
again reported no investigations of traf¬
ficking of children for domestic servitude
or improvements in protection services
available to victims of trafficking; Algeria
still lacks victim protection services, and
its failure to distinguish between trafficking
and illegal migration may result in the
punishment of victims of trafficking (2008)
Background: Settled as early as 1000 B.C.,
Samoa was “discovered” by European
explorers in the 1 8th century. International
rivalries in the latter half of the 19th century
were settled by an 1899 treaty in which
Germany and the US divided the Samoan
archipelago. The US formally occupied its
portion— -a smaller group of eastern islands
with the excellent harbor of Pago Pago— the
following year.','493d2bb7f1bab02d51b29f65a9d3033cf69bfa946ff04606a6902f388803e94f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('885e8409961fa5585a201cf020106bb7c5d2ba4ca172dec7ee8587d15f2f9663',2010,'AD','Andorra','transnational-issues',170,'Disputes— international: Tokelau period¬
ically asserts claims to American Samoa’s
Swains Island (Olohega), such as in its
2006 draft independence constitution','fb904791fc4cd9e8a41acc871ad80a898fe5d62e402db4affd41ba8618d0ba55','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5205f9e4bc9d964a081f1d26e4dfdf724774eb5ddc2c724c9010106a14665340',2010,'AO','Angola','transnational-issues',180,'Disputes— international: none
Climate: semiarid in south and along
coast to Luanda; north has cool, dry season
(May to October) and hot, rainy season
(November to April)
Terrain: narrow coastal plain rises abruptly
to vast interior plateau
Elevation extremes: lowest point. Atlantic
Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds,
iron ore, phosphates, copper, feldspar,
gold, bauxite, uranium
Land use: arable land: 2.65%
permanent crops: 0.23%
other: 97.12% (2005)
Irrigated land: 800 sq km (2003)
Total renewable water resources:
184 cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.35 cu km/yr (23%/17%/60%)
per capita: 22 cu m/yr (2000)
Natural hazards: locally heavy rainfall
causes periodic flooding on die plateau
Environment— current issues: overuse
of pastures and subsequent soil erosion
attributable to population pressures;
desertification; deforestation of tropical rain
forest, in response to both international
demand for tropical timber and to domestic
17
THE CIA WORLD FACTBOOK
use as fuel, resulting in loss of biodiversity;
soil erosion contributing to water pollution
and siltation of rivers and dams; inadequate
supplies of potable water
Environment— internationalagreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography — note: the province of
Cabinda is an exclave, separated from
the rest of the country by the Democratic
Republic of the Congo
Disputes — international: heads of the
Great Lakes states and UN pledged in
2004 to abate tribal, rebel, and militia
fighting in the region, including north¬
east Congo, where the UN Organization
Mission in the Democratic Republic of the
Congo (MONUC), organized in 1999,
maintains over 16,500 uniformed peace¬
keepers; members of Uganda’s Lords
Resistance Army forces continue to seek
refuge in Congo’s Garamba National Park
as peace talks with the Uganda government
evolve; the location of the boundary in the
broad Congo River with the Republic of
the Congo is indefinite except in the Pool
Malebo/Stanley Pool area; Uganda and
DROC dispute Rukwanzi island in Lake
Albert and other areas on the Semliki River
with hydrocarbon potential; boundary
commission continues discussions over
Congolese-administered triangle of land
on the right bank of the Lunkinda river
claimed by Zambia near the DROC village
of Pweto
Refugees and internally displaced
persons: refugees ( country of origin): 1 32,295
(Angola); 37,313 (Rwanda); 17,777
(Burundi); 13, 904 (Uganda); 6,181 (Sudan);
5,243 (Republic of Congo)
IDPs: 1 .4 million (fighting between govern¬
ment forces and rebels since mid-1990s;
most IDPs are in eastern provinces)
(2007)
Trafficking in persons: current situation:
Democratic Republic of the Congo is a
source and destination country for men,
women, and children trafficked for the
purposes of forced labor and sexual
exploitation; much of this trafficking
160
CONGO, REPUBLIC OF THE
occurs within the country’s unstable
eastern provinces and is perpetrated by
armed groups outside government control
tier rating: Tier 2 Watch List— Democratic
Republic of the Congo is on the Tier
2 Watch List for its failure to provide
evidence of increasing efforts to combat
trafficking in persons in 2007; while some
significant initial advances were noted, the
government’s capacity to apprehend, convict,
or imprison traffickers remained weak; the
government lacks sufficient financial, tech¬
nical, and human resources to effectively
address not only trafficking crimes, but also
to provide basic levels of security in some
parts of the country (2008)
Illicit drugs: one of Africa’s biggest
producers of cannabis, but mosdy
for domestic consumption; traffickers
exploit lax shipping controls to transit
pseudoephedrine through the capital;
while rampant corruption and inadequate
supervision leaves the banking system
vulnerable to money laundering, the lack
of a well-developed financial system limits
the country’s utility as a money-laundering
center (2008)
CONGO, REPUBLIC OF THE
Background: Upon independence in 1 960,
the former French region of Middle Congo
became the Republic of the Congo. A quarter
century of experimentation with Marxism
was abandoned in 1 990 and a demo¬
cratically elected government took office in
1992. A brief civil war in 1997 restored
former Marxist President Denis SASSOU-
NGUESSO, and ushered in a period of
ethnic and political unrest. Southern-based
rebel groups agreed to a final peace accord
in March 2003, but the calm is tenuous and
refugees continue to present a humanitarian
crisis. The Republic of Congo was once one
of Africa’s largest petroleum producers, but
with declining production it will need new
offshore oil finds to sustain its oil earnings
over the long term.','e6369f8533150f6a6af2bd99dba34daf513cb9f542cbb748465e57d4f3de6d10','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96b433162d90d31bea80615b5de97a5459cae504463c9d099a47baddd2786cb0',2010,'AI','Anguilla','transnational-issues',184,'Disputes — international: Cabindan sepa¬
ratists continue to return to the Angolan
exclave from exile in neighboring states
and Europe since the 2006 ceasefire and
peace agreement
Refugees and internally displaced
persons: refugees ( country of origin): 12,615
(Democratic Republic of Congo)
IDPs: 61,700 (27-year civil war ending
in 2002; 4 million IDPs already have
returned) (2007)
Illicit drugs: used as a transshipment point
for cocaine destined for Western Europe
and other African states, particularly South
Africa
Disputes — international: none
Illicit drugs: transshipment point for
South American narcotics destined for the
US and Europe','e737f618a022e808d8cb610f227b86d1d1e101ad3f5af5d056c606cbb4aeef08','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd7f4f66d1c6fc25a62cbef30ceb826966cc90fe77664b735f7fdd53eeb434d9',2010,'AQ','Antarctica','transnational-issues',191,'existence of a “southern land” was not
confirmed until the early 1820s when
British and American commercial opera¬
tors and British and Russian national
expeditions began exploring the Antarctic
Peninsula region and other areas south
of the Antarctic Circle. Not until 1840
was it established that Antarctica was
indeed a continent and not just a group
of islands. Several exploration “firsts”
were achieved in the early 20th century.
Following World War II, there was an''
upsurge in scientific research on the
continent. A number of countries have
set up a range of year-round and seasonal
stations, camps, and refuges to support
scientific research in Antarctica. Seven
have made territorial claims, but not all
countries recognize these claims. In order
to form a legal framework for the activities
of nations on the continent, an Antarctic
Treaty was negotiated that neither denies
nor gives recognition to existing territorial
claims; signed in 1959, it entered into
force in 1961 .','bfd2286107905a1b9a731e0c355f6f71d92da2aabe0e2a30acf6dc35141c0e41','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9325ccefd0221af015c9b54e9514d2c6eb461bd6fd39fb505276b288175f097a',2010,'AG','Antigua and Barbuda','transnational-issues',201,'Disputes — international: the Antarctic
Treaty freezes, and most states do not
recognize, the land and maritime territorial
claims made by Argentina, Australia,
Chile, France, New Zealand, Norway, and
the United Kingdom (some overlapping)
for three-fourths of the continent; the
US and Russia reserve the right to make
claims; no claims have been made in the
sector between 90 degrees west and 150
degrees west; the International Whaling
Commission created a sancturary around
the entire continent to deter catches by
countries claiming to conduct scientific
whaling; Australia has established a
similar preserve in the waters around its
territorial claim
Disputes— international : none
Illicit drugs: considered a minor trans¬
shipment point for narcotics bound for
the US and Europe; more significant as an
offshore financial center
27
THE CIA WORLD FACTBOOK
ARCTIC OCEAN','d6e1d17de65f8d1328db08fcf06c4d5e9d1d7d18e9289b42f577f1881a13a164','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac872a7757a6880bf97e7ba04017cad37b5c7a7d61b45012fad8fa1c6f38ffa7',2010,'AR','Argentina','transnational-issues',207,'Disputes— international: the littoral
states are engaged in various stages of
demonstrating the limits of their conti¬
nental shelves beyond 200 nautical miles
from their declared baselines in accord¬
ance with Article 76, paragraph 8, of the
United Nations Convention on the Law
of the Sea; record summer melting of sea
ice in the Arctic has restimulated interest
in maritime shipping lanes and sea floor
exploration
persisted despite numerous challenges,
the most formidable of which was a severe
economic crisis in 2001-02 that led to
violent public protests and the resignation
of several interim presidents.
Disputes— international: Argentina
continues to assert its claims to the UK-
administered Falkland Islands (Islas
Malvinas), South Georgia, and the South
Sandwich Islands in its constitution, forcibly
occupying the Falklands in 1982, but in
1995 agreed no longer to seek settlement
by force; territorial claim in Antarctica
partially overlaps UK and Chilean claims;
unruly region at convergence of Argentina-
Brazil-Paraguay borders is locus of money
laundering, smuggling, arms and illegal
narcotics trafficking, and fundraising
for extremist organizations; uncontested
dispute between Brazil and Uruguay over
Braziliera/Brasiliera Island in the Quarai/
Cuareim River leaves the tripoint with
Argentina in question; in 2006, Argentina
went to the ICJ to protest, on environ¬
mental grounds, the construction of two
pulp mills in Uruguay on the Uruguay
River, which forms the boundary; both
parties presented their pleadings in 2007
with Argentina’s reply in January and
Uruguay’s rejoinder in July 2008; the joint
boundary commission, established by Chile
and Argentina in 2001 has yet to map and
demarcate the delimited boundary in the
inhospitable Andean Southern Ice Field
(Campo de Hielo Sur)
Trafficking in parsons: current situation:
Argentina is a source, transit, and
destination country for men, women, and
children trafficked for the purposes of
commercial sexual exploitation and forced
labor; most victims are trafficked within the
country, from rural to urban areas; child
sex tourism is a problem; foreign women
and children, primarily from Paraguay,
Brazil, and the Dominican Republic, are
trafficked to Argentina for commercial
sexual exploitation; Argentine women
and girls are also trafficked to neigh¬
boring countries, Mexico, and Western
Europe for sexual exploitation; a signifi¬
cant number of Bolivians, Peruvians, and
Paraguayans are trafficked into the country
for forced labor in sweatshops, agriculture,
and as domestic servants
tier rating: Tier 2 Watch List— despite some
progress, Argentina remains on the Tier
2 Watch List for the third consecutive
year for its failure to show evidence of
increasing efforts to combat human traf¬
ficking, particularly in terms of providing
adequate assistance to victims and curbing
official complicity with trafficking activity,
especially on the provincial and local levels;
the Argentine Congress has demonstrated
progress by enacting much-needed and
first-ever federal anti-trafficking legislation
(2008)
Illicit drugs: a transshipment country for
cocaine headed for Europe, heroin headed
for the US, and ephedrine and pseudoephe-
drine headed for Mexico; some money¬
laundering activity, especially in the Tri-
Border Area; law enforcement corruption;
a source for precursor chemicals; increasing
domestic consumption of drugs in urban
centers, especially cocaine base and
synthetic drugs (2008)','73ee5e089ecfa1ad681ab2d630981af197e283e41b4f9256b4ec26c24d66dd6a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdde13b5f6069cb8d87e595304f64e38f037b7c8e73ce425a20327bda4f71a01',2010,'AM','Armenia','transnational-issues',219,'Disputes — international: Armenia
supports ethnic Armenian secessionists
in Nagorno-Karabakh and sincfe the early
1990s, has militarily occupied 16% of
Azerbaijan— Organization for Security and
Cooperation in Europe (OSCE) continues
to mediate dispute; over 800,000 mostly
ethnic Azerbaijanis were driven from
the occupied lands and Armenia; about
230,000 ethnic Armenians were driven
from their homes in Azerbaijan into
Armenia and Nagorno-Karabakh; Azerba¬
ijan seeks transit route through Armenia
to connect to Naxcivan exclave; border
with Turkey remains closed over Nagorno-
Karabakh dispute; ethnic Armenian
groups in Javakheti region of Georgia seek
greater autonomy; Armenians continue
to emigrate, primarily to Russia, seeking
employment
Refugees and internally displaced
persons: refugees ( country of origin .):
1 1 3,295 (Azerbaijan)
IDPs: 8,400 (conflict with Azerbaijan over
Nagorno-Karabakh, majority have returned
home since 1994 ceasefire) (2007)
Trafficking in persons: current situation:
Armenia is primarily a source country for
women and girls trafficked to the UAE
and Turkey for the purpose of commercial
sexual exploitation; Armenian men and
women are trafficked to Turkey and Russia
for the purpose of forced labor
tier rating: Tier 2 Watch List— Armenia is
placed on the Tier 2 Watch List for a fourth
consecutive year; its efforts to increase
compliance with the minimum standards
were assessed based on its commitments to
undertake future actions, particularly in the
areas of improving victim protection and
assistance; while the government elevated
anti-trafficking responsibilities to the
ministerial level, adopted a new National
Action Plan, and drafted a National Referral
Mechanism, it has yet to show tangible
progress in identifying and protecting
victims or in tackling trafficking complicity
of government officials; the Armenian
Government made some notable improve¬
ments in its anti-trafficking law enforcement
efforts, but it failed to demonstrate evidence
of investigations, prosecutions, convictions,
and sentences of officials complicit in traf¬
ficking (2008)
Illicit drugs: illicit cultivation of small
amount of cannabis for domestic consump¬
tion; minor transit point for illicit drugs—
mostly opium and hashish— moving from
Southwest Asia to Russia and to a lesser
extent the rest of Europe','d522c9a9652f1e83cbc91fea18aefb74d4d11ccf1aba5dbe04d741bdcf7eb175','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('944650350093d3ff6a0d0d2702eca5268887444599cb703767e0600ddf86061c',2010,'NL','Netherlands','transnational-issues',228,'Disputes— international: none
Illicit drugs: transit point for US- and
Europe-bound narcotics with some
accompanying money-laundering activity;
relatively high percentage of population
consumes cocaine
ASHMORE AND CARTIER ISLANDS
Disputes — international: as the closest
Australian territory to Indonesia, these
islands became the target of human traf¬
fickers for the landing of illegal immi¬
grants; in 2001 , the Australian government
removed these islands from the Australian
Migration Zone making illegal arrivals
ineligible for temporary visas and entry
into Australia
Labrador Sea, Mediterranean Sea, North
Sea, Norwegian Sea, almost all of the Scotia
Sea, and other tributary water bodies
Area — comparative: slightly less than 6.5
times the size of the US
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes)
develop off the coast of Africa near Cape
Verde and move westward into the Carib¬
bean Sea; hurricanes can occur from May
to December but are most frequent from
August to November
Terrain: surface usually covered with sea
ice in Labrador Sea, Denmark Strait, and
coastal portions of the Baltic Sea from
October to June; clockwise warm-water
gyre (broad, circular system of currents)
in die northern Atlantic, counterclockwise
warm-water gyre in the southern Atlantic;
the ocean floor is dominated by the
Mid-Adantic Ridge, a rugged north-south
centerline for the entire Atlantic basin
39
THE CIA WORLD FACTBOOK
Elevation extremes: lowest point:
Milwaukee Deep in the Puerto Rico Trench
-8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish,
marine mammals (seals and whales), sand
and gravel aggregates, placer deposits, poly¬
metallic nodules, precious stones
Natural hazards: icebergs common
in Davis Strait, Denmark Strait, and
the northwestern Atlantic Ocean from
February to August and have been spotted
as far south as Bermuda and the Madeira
Islands; ships subject to superstructure
icing in extreme northern Adantic from
October to May; persistent fog can be a
maritime hazard from May to September;
hurricanes (May to December)
Environment— current issues: endan¬
gered marine species include the manatee,
seals, sea lions, turdes, and whales; drift
net fishing is hastening the decline of fish
stocks and contributing to international
disputes; municipal sludge pollution off
eastern US, southern Brazil, and eastern
Argentina; oil pollution in Caribbean Sea,
Gulf of Mexico, Lake Maracaibo, Mediter¬
ranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic
Sea, North Sea, and Mediterranean Sea
Disputes— international : none
Illicit drugs: major European producer
of synthetic drugs, including ecstasy, and
cannabis cultivator; important gateway
for cocaine, heroin, and hashish entering
Europe; major source of US-bound
ecstasy; large financial sector vulnerable to
money laundering; significant consumer
of ecstasy
NETHERLANDS ANTILLES
Disputes — international : none
Illicit drugs: transshipment point for
South American drugs bound for the US
and Europe; money-laundering center','a49fed0ecc8c50b9a40b6f77b80f61d74134e72e2b3114ade138bbfa8cae2e73','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a8a7c41742b4b5b60654d96bcf7de078ffb81f194530a38c24c5daf054de8e',2010,'AU','Australia','transnational-issues',233,'Disputes— International: some maritime
disputes (see littoral states)
water: 68,920 sq km
note: includes Lord Howe Island and
Macquarie Island
Area— comparative: slightly smaller than
the US contiguous 48 states
Land boundaries: 0 km
Coastline: 25,760 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: generally arid to semiarid;
temperate in south and east; tropical in
north
Terrain: mostly low plateau with deserts;
fertile plain in southeast
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciuszko 2,229 m
Natural resources: bauxite, coal, iron
ore, copper, tin, gold, silver, uranium,
nickel, tungsten, mineral sands, lead,
zinc, diamonds, natural gas, petroleum
note: Australia is the world’s largest net
exporter of coal accounting for 29% of
global coal exports
40
Land use: arable land: 6.1 5% (includes about
27 million hectares of cultivated grassland)
permanent crops: 0.04%
other: 93.81% (2005)
Irrigated land: 25,450 sq km (2003)
Total renewable water resources:
398 cu km (1995)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 24.06 cu
km/yr (1 5%/l 0%/7 5%)
per capita: 1,193 cu m/yr (2000)
Natural hazards: cyclones along the coast;
severe droughts; forest fires
Environment — current issues: soil erosion
from overgrazing, industrial development,
urbanization, and poor farming practices;
soil salinity rising due to the use of poor
quality water; desertification; clearing for
agricultural purposes threatens the natural
habitat of many unique animal and plant
species; the Great Barrier Reef off the
northeast coast, the largest coral reef in the
world, is threatened by increased shipping
and its popularity as a tourist site; limited
natural fresh water resources
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Con¬
servation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: world’s smallest conti¬
nent but sixth-largest country; population
concentrated along the eastern and south¬
eastern coasts; the invigorating sea breeze
known as the “Fremande Doctor” affects the
city of Perth on the west coast and is one of
the most consistent winds in the world
Disputes— international: Timor-Leste
and Australia agreed in 2005 to defer the
disputed portion of the boundary for 50
years and to split hydrocarbon revenues
evenly outside the Joint Petroleum
Development Area covered by the 2002
Timor Sea Treaty; dispute with Timor-Leste
hampers creation of a revised maritime
boundary with Indonesia in the Timor
Sea; regional states continue to express
concern over Australia’s 2004 declaration
of a 1 ,000-nautical mile-wide maritime
identification zone; Australia asserts land
and maritime claims to Antarctica; in 2004
Australia submitted its claims to Commis¬
sion on the Limits of the Continental
Shelf (CLCS) to extend its continental
margins covering over 3.37 million square
kilometers, expanding its seabed roughly
30 percent more than its claimed exclusive
economic zone; since 2003, Australia has
led the Regional Assistance Mission to the
Solomon Islands (RAMSI) to maintain
civil and political order and reinforce
regional security
Illicit drugs: Tasmania is one of the world’s
major suppliers of licit opiate products;
government maintains strict controls over
areas of opium poppy cultivation and
output of poppy straw concentrate; major
consumer of cocaine and amphetamines
43
THE CIA WORLD FACTBOOK
Disputes — international: none
Disputes — international: claimed by
Haiti, source of subsistence fishing
480','4a26324516b22bbac8fea604a436dd8a9a15e4e409af02e520eda2af51dc436c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9f91b416d77594977797a5bf2bf7456a5cf7ff8686d57944f037b449f8e3476',2010,'AZ','Azerbaijan','transnational-issues',249,'Disputes— international: while threats
of international legal action never materi¬
alized in 2007, 915,220 Austrians, with
the support of die newly elected Lreedom
Party, signed a petition in January 2008,
demanding that Austria block the Czech
Republic’s accession to the EU unless
Prague closed its nuclear power plant in
Temelin, bordering Austria
Illicit drugs: transshipment point for
Southwest Asian heroin and South Amer¬
ican cocaine destined for Western Europe;
increasing consumption of European-
produced synthetic drugs
Background: Azerbaijan— a nation with
a majority-Turkic and majority-Muslim
population— was briefly independent from
1918 to 1920; it regained its independence
after the collapse of the Soviet Union in
1991. Despite a 1994 cease-fire, Azerbaijan
has yet to resolve its conflict with Armenia
over the Azerbaijani Nagorno-Karabakh
enclave (largely Armenian populated).
Azerbaijan has lost 16% of its territory
and must support some 600,000 inter¬
nally displaced persons as a result of the
conflict. Corruption is ubiquitous, and the
government has been accused of authori¬
tarianism. Although the poverty rate has
been reduced in recent years, the promise
of widespread wealth from development of
Azerbaijan’s energy sector remains largely
unfulfilled.
Disputes — international: Armenia
supports ethnic Armenian secessionists
in Nagorno-Karabakh and since the early
1 990s has militarily occupied 1 6% of
Azerbaijan; over 800,000 mostly ethnic
Azerbaijanis were driven from the occupied
lands and Armenia; about 230,000 ethnic
Armenians were driven from their homes
in Azerbaijan into Armenia and Nagorno-
Karabakh; Azerbaijan seeks transit route
through Armenia to connect to Naxcivan
exclave; Organization for Security and
Cooperation in Europe (OSCE) continues
to mediate dispute; Azerbaijan, Kaza¬
khstan, and Russia have ratified Caspian
seabed delimitation treaties based on equi¬
distance, while Iran continues to insist on
an even one-fifth allocation and challenges
Azerbaijan’s hydrocarbon exploration in
disputed waters; bilateral talks continue
with Turkmenistan on dividing the seabed
and contested oilfields in the middle of the
Caspian; Azerbaijan and Georgia continue
to discuss the alignment of their boundary
at certain crossing areas
Refugees and internally displaced
persons: refugees ( country of origin): 2,400
(Russia)
50
/DPs: 580,000-690,000 (conflict with
Armenia over Nagorno-Karabakh) (2007)
Trafficking in persons: current situation:
Azerbaijan is primarily a source and transit
country for men, women, and children
trafficked for the purposes of commer¬
cial sexual exploitation and forced labor;
women and some children from Azerba¬
ijan are trafficked to Turkey and the UAE
for the purpose of sexual exploitation;
men and boys are trafficked to Russia for
the purpose of forced labor; Azerbaijan
serves as a transit country for victims from
Uzbekistan, Kyrgyzstan, Kazakhstan, and
Moldova trafficked to Turkey and the
UAE for sexual exploitation
tier rating: Tier 2 Watch List— Azerbaijan
is on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat trafficking in persons, particu¬
larly efforts to investigate, prosecute, and
punish traffickers; to address complicity
among law enforcement personnel; and
to adequately identify and protect victims
in Azerbaijan; the government has yet to
develop a much-needed mechanism to
identify potential trafficking victims and
refer them to safety and care; poor treat¬
ment of trafficking victims in courtrooms
continues to be a problem (2008)
Illicit drugs: limited illicit cultivation of
cannabis and opium poppy, mostly for
CIS consumption; small government
eradication program; transit point for
Southwest Asian opiates bound for Russia
and to a lesser extent the rest of Europe
51
BAHAMAS, THE
Disputes— international: disagrees with
the US on the alignment the northern
axis of a potential maritime boundary;
continues to monitor and interdict drug
dealers and Haitian and Cuban refugees in
Bahamian waters
Illicit drugs: transshipment point for
cocaine and marijuana bound for US and
Europe; offshore financial center','2ea58de07607627def00f2b5930f75fdfb0f4d96c986e8155c8550d46f38773c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7879b41af27abcc2a431afd78f83dd61702a1a093bbfee3b47d2b2833f14e883',2010,'BD','Bangladesh','transnational-issues',263,'Disputes— international: none
Trafficking in persons: current situation:
Bahrain is a destination country for men and
women trafficked for the purposes of involun¬
tary servitude and commercial sexual exploi¬
tation; men and women from Africa, South
Asia, and Southeast Asia migrate voluntarily
to Bahrain to work as laborers or domestic
servants where some face conditions of
involuntary servitude such as unlawful with¬
holding of passports, restrictions on move¬
ments, non-payment of wages, threats, and
physical or sexual abuse; women from Thai¬
land, Morocco, Eastern Europe, and Central
Asia are trafficked to Bahrain for the purpose
of commercial sexual exploitation
tier rating: Tier 2 Watch List— Bahrain is on
the Tier 2 Watch List for failing to show
evidence of increased efforts to combat
human trafficking, particularly efforts that
enforce laws against trafficking in persons,
and that prevent the punishment of victims
of trafficking; during 2007, Bahrain passed a
comprehensive law prohibiting all forms of
trafficking in persons; the government also
established a specialized anti-trafficking unit
within the Ministry of Interior to investigate
trafficking crimes; however, the government
did not report any prosecutions or convic¬
tions for trafficking offenses during 2007,
despite reports of a substantial problem of
involuntary servitude and sex trafficking
(2008)','1c8dd0b42638040efc40862c2a5fe55961ffb0e11b9657430ebf9bf146194dd1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d7e22b0f151a019eb1428ab274f64633a446347d64d3f60300c904a5365bcdf',2010,'BB','Barbados','transnational-issues',267,'Disputes — international: discussions
with India remain stalled to delimit a
small section of river boundary, exchange
territory for 51 small Bangladeshi exclaves
in India and 111 small Indian exclaves in
Bangladesh, allocate divided villages, and
stop illegal cross-border trade, migration,
violence, and transit of terrorists through
the porous border; Bangladesh protests
India’s fencing and walling off high-traffic
sections of the porous boundary; a joint
Bangladesh-India boundary commission
resurveyed and reconstructed 92 missing
pillars in 2007; dispute with India over
New Moore/South Talpatty/Purbasha
Island in the Bay of Bengal deters maritime
boundary delimitation; after 21 years,
Bangladesh resumes talks with Burma on
delimiting a maritime boundary
Refugees and internally displaced
persons: refugees (country of origin):
26,268 (Burma)
I DPs: 65,000 (land conflicts, religious
persecution) (2007)
Illicit drugs: transit country for illegal
drugs produced in neighboring countries
Disputes— international: Barbados and
Trinidad and Tobago abide by the April
2006 Permanent Court of Arbitration deci¬
sion delimiting a maritime boundary and
limiting catches of flying fish in Trinidad
and Tobago’s exclusive economic zone;
joins other Caribbean states to counter
Venezuela’s claim that Aves Island
sustains human habitation, a criterion
under the UN Convention on the Law
of the Sea (UNCLOS), which permits
Venezuela to extend its EEZ/continental
shelf over a large portion of the eastern
Caribbean Sea
Illicit drugs: one of many Caribbean
transshipment points for narcotics bound
for Europe and the US; offshore financial
center
63
THE CIA WORLD FACTBOOK','d7dee28f2853658b925c552f30aa9bc621a3c3222625237d95657f29666726b3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed6dc21911aad83e5543452bea23c6fc830b42b3f00d6d18f3028080d576e4bf',2010,'BY','Belarus','transnational-issues',275,'Background: After seven decades as a constit¬
uent republic of the USSR, Belarus attained
its independence in 1991. It has retained
closer political and economic ties to Russia
than any of the other former Soviet republics.
Belarus and Russia signed a treaty on a two-
state union on 8 December 1 999 envisioning
greater political and economic integration.
Although Belarus agreed to a framework to
carry out the accord, serious implementa¬
tion has yet to take place. Since his election
in July 1994 as the country’s first president,
Aleksandr LUKASHENKO has steadily
consolidated his power through authoritarian
means. Government restrictions on freedom
of speech and the press, peaceful assembly,
and religion remain in place.','38445d0804aed41ab93b633409d169b0b526e4151888dae0ad456f80651f197c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c576eae5e12caa015d838df327857017e21b20f11fef4bb9f13f6c8cb114fad9',2010,'BE','Belgium','transnational-issues',284,'Disputes — international: Boundary
demarcated with Latvia and Lithuania in
2006; 1997 boundary delimitation treaty
with Ukraine remains unratified over
unresolved financial claims, preventing
demarcation and diminishing border
security
Illicit drugs: limited cultivation of opium
poppy and cannabis, mosdy for the
domestic market; transshipment point
for illicit drugs to and via Russia, and to
the Baltics and Western Europe; a small
and lighdy regulated financial center; anti¬
money-laundering legislation does not meet
international standards and was weakened
further when know-your-customer require¬
ments were curtailed in 2008; few investiga¬
tions or prosecutions of money-laundering
activities (2008)
A N e « s
*
! Mectieien
Aaist ^ * Leuven
BRUSSELS
Ch*tf*«* Ifiamur 4
W w A s: L O H l A','a356cb1e106cfa8689c2089da2dbc5b129d27853fb971c7ad1712579d8d38016','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96cb07cce284ce25c8eb556311d299b2ee91bc264f5510d685abccf950ef9492',2010,'BZ','Belize','transnational-issues',293,'Disputes — international : none
Illicit drugs: growing producer of
synthetic drugs and cannabis; transit point
for US-bound ecstasy; source of precursor
chemicals for South American cocaine
processors; transshipment point for
cocaine, heroin, hashish, and marijuana
entering Western Europe; despite a
strengthening of legislation, the country
remains vulnerable to money laun¬
dering related to narcotics, automobiles,
alcohol, and tobacco; significant domestic
consumption of ecstasy
Background: Belize was the site of several
Mayan city states until their decline at
the end of the first millennium A.D. The
British and Spanish disputed the region
in the 17th and 18th centuries; it formally
became the colony of British Honduras in
1854. Territorial disputes between the UK
and Guatemala delayed the independence
of Belize until 1981. Guatemala refused
to recognize the new nation until 1992.
Tourism has become the mainstay of the
economy. Current concerns include an
unsustainable foreign debt, high unemploy¬
ment, growing involvement in the South
American drug trade, growing urban crime,
and increasing incidences of HIV/AIDS.
Disputes — international: OAS-initiated
Agreement on the Framework for
Negotiations and Confidence Building
Measures saw cooperation in repatriation
of Guatemalan squatters and other areas,
but Guatemalan land and maritime claims
in Belize and the Caribbean Sea remain
unresolved; the Line of Adjacency created
under the 2002 Differendum serves in lieu
of the contiguous international boundary
to control squatting in the sparsely inhal>
ited rain forests of Belize’s border region;
Honduras claims Belizean-administered
Sapodilla Cays in its constitution but
agreed to a joint ecological park under the
Differendum
Illicit drugs: transshipment point for
cocaine; small-scale illicit producer of
cannabis, primarily for local consumption;
offshore sector money-laundering activity
related to narcotics trafficking and other
crimes (2008)','f998bc1b6cd50a28d7db4ceb8d557b2913d79e400d46fbb0ec2a2ddfb4dc209e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f69b6e12f1ef0f1c250e135dc29d950c2167982c0db02b2d09190496900c3a43',2010,'BJ','Benin','transnational-issues',301,'Background: Present day Benin was
the site of Dahomey, a prominent West
African kingdom that rose in the 15th
century. The territory became a French
Colony in 1872 and achieved independ¬
ence on 1 August 1960, as the Republic
of Benin. A succession of military govern¬
ments ended in 1972 with the rise to power
of Mathieu KEREKOU and the establish¬
ment of a government based on Marxist-
Leninist principles. A move to representa¬
tive government began in 1989. Two years
later, free elections ushered in former Prime
Minister Nicephore SOGLO as president,
marking the first successful transfer of
power in Africa from a dictatorship to a
democracy. KEREKOU was returned to
power by elections held in 1996 and 2001,
though some irregularities were alleged.
KEREKOU stepped down at the end of his
second term in 2006 and was succeeded
by Thomas YAY1 Boni, a political outsider
and independent. YAYI has begun a high
profile fight against corruption and has
strongly promoted accelerating Benin’s
economic growth.','fcc8fbd27a4faa239e47ed6b668347238651066cf9a9c14b3ff93cfc7d388a49','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ceb98ef76bd0d2debe7fbb343aa246c2eebb6d66d6c265317b5d38e8247ee7',2010,'BM','Bermuda','transnational-issues',310,'Disputes— international: in September
2007, Economic Community of West
African States (ECOWAS) intervened to
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
total: 53.3 sq km
land: 53.3 sq km
water: 0 sq km
Area — comparative: about one-third the
size of Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims: territorial sea: 1 2 nm
exclusive fishing zone: 200 nm
Climate: subtropical; mild, humid; gales,
strong winds common in winter
Terrain: low hills separated by fertile
depressions
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Town Hill 76 m
Natural resources: limestone, pleasant
climate fostering tourism
Land use: arable land: 20%
permanent crops: 0%
other: 80% (55% developed, 45% rural/
open space) (2005)
irrigated land: NA
Natural hazards:
hurricanes (June to November)
Environment — current issues:
sustainable development
Geography — note: consists of about 138
coral islands and islets with ample rainfall,
but no rivers or freshwater lakes; some
land was leased by US Government from
1941 to 1995
attempt to resolve the dispute over two
villages along the Benin-Burkina Faso
border that remain from 2005 ICJ deci¬
sion; much of Benin-Niger boundary,
including tripoint with Nigeria, remains
undemarcated; in 2005, Nigeria ceded thir¬
teen villages to Benin, but border relations
remain strained by rival cross-border gang
clashes; talks continue between Benin and
Togo on funding the Adjrala hydroelectric
dam on the Mona River
Refugees and internally displaced
persons: refugees (country of origin ): 9,444
(Togo) (2007)
Illicit drugs: transshipment point used by
traffickers for cocaine destined for Western
Europe; vulnerable to money laundering
due to poorly enforced financial regulations
(2008)','b0c147f9284725f5659f1be29ba8d67233927c4c18d41517c71142160136c04f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef24aa388250d2ea57a74e5f52647f3809bc8c6200feab6a629ee14b0b55586b',2010,'BT','Bhutan','transnational-issues',318,'Disputes— international: none
Disputes— international: Bhutan cooper¬
ates with India to expel Indian Nagaland
separatists; lacking any treaty describing
the boundary, Bhutan and China continue
negotiations to establish a common
boundary alignment to resolve territorial
disputes arising from substantial carto¬
graphic discrepancies, the largest of which
lie in Bhutan’s northwest and along the
Chumbi salient
BOLIVIA
Disputes — international: Chile and Peru
rebuff Bolivia’s reactivated claim to restore
the Atacama corridor, ceded to Chile
in 1884, but Chile offers instead unre¬
stricted but not sovereign maritime access
through Chile for Bolivian natural gas
and other commodities; an accord placed
the long-disputed Isla Suarez/Ilha de
Guajara-Mirim, a fluvial island on the Rio
Mamore, under Bolivian administration in
1958, but sovereignty remains in dispute
85
THE CIA WORLD FACTBOOK
Illicit drugs: world’s third-largest cultivator
of coca (after Colombia and Peru) with an
estimated 29,500 hectares under cultivation
in 2007, increased slightly when compared
to 2006; third largest producer of cocaine,
estimated at 120 metric tons potential pure
cocaine in 2007; transit country for Peruvian
and Colombian cocaine destined for Brazil,
Argentina, Chile, Paraguay, and Europe;
cultivation generally increasing since 2000,
despite eradication and alternative crop
programs; weak border controls; some
money-laundering activity related to narcotics
trade; major cocaine consumption (2008)','8d2aa58799e6c65a74c3ea4313547b55b65393c85064147778d95f0a428cae91','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1a782a0419a9225570d2a544e57fc9a78a040f2d5eaa1580edc3627afee3e4a',2010,'BA','Bosnia and Herzegovina','transnational-issues',322,'Background: Bosnia and Herzegovina’s
declaration of sovereignty in October
1991 was followed by a declaration of
independence from the former Yugoslavia
on 3 March 1992 after a referendum
boycotted by ethnic Serbs. The Bosnian
Serbs— supported by neighboring Serbia
and Montenegro— responded with armed
resistance aimed at partitioning the republic
along ethnic lines and joining Serb-held
areas to form a “Greater Serbia.” In March
1994, Bosniaks and Croats reduced the
number of warring factions from three to
two by signing an agreement creating a joint
Bosniak/Croat Federation of Bosnia and
Herzegovina. On 21 November 1995, in
Dayton, Ohio, the warring parties initialed a
peace agreement that brought to a halt three
years of interethnic civil strife (the final agree¬
ment was signed in Paris on 1 4 December
1995). The Dayton Peace Accords retained
Bosnia and Herzegovina’s international
boundaries and created a joint multi-ethnic
and democratic government charged with
conducting foreign, diplomatic, and fiscal
policy. Also recognized was a second tier
of government comprised of two entities
roughly equal in size: the Bosniak/Croat
Federation of Bosnia and Herzegovina and
the Bosnian Serb-led Republika Srpska
(RS). The Federation and RS governments
were charged with overseeing most govern¬
ment functions. The Office of the High
Representative (OHR) was established to
oversee the implementation of the civilian
aspects of the agreement. In 1995-96, a
NATO-led international peacekeeping force
(IFOR) of 60,000 troops served in Bosnia to
implement and monitor the military aspects
of the agreement. IFOR was succeeded by
a smaller, NATO-led Stabilization Force
(SFOR) whose mission was to deter
renewed hostilities. European Union peace¬
keeping troops (EUFOR) replaced SFOR
in December 2004; their mission is to
maintain peace and stability throughout the
country. EUFOR’ s mission changed from
peacekeeping to civil policing in October
2007, with its presence reduced from nearly
7,000 to less than 2,500 troops.
Disputes — international: sections along
the Drina River remain in dispute between
Bosnia and Herzegovina and Serbia; discus¬
sions continue with Croatia on several
small disputed sections of the boundary
related to maritime access that hinder final
ratification of the 1 999 border agreement
Refugees and internally displaced
persons: refugees ( country of origin): 7,269
(Croatia)
IDPs: 131,600 (Bosnian Croats, Serbs,
and Bosniaks displaced in 1992-95 war)
(2007)
Illicit drugs: increasingly a transit point for
heroin being trafficked to Western Europe;
minor transit point for marijuana; remains
highly vulnerable to money-laundering
activity given a primarily cash-based and
unregulated economy, weak law enforce¬
ment, and instances of corruption
89
THE CIA WORLD FACTBOOK','5268b09fbb89ffdc540d983df05a20f303158965b9a34358ba496568bcfbbb3d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('919bf6cf714e8b7ebf909fd1f5b5e424ddd7220fc2fdf86473e428d53d0486bb',2010,'BW','Botswana','transnational-issues',330,'Background: Formerly the British protec¬
torate of Bechuanaland, Botswana adopted
its new name upon independence in 1966.
Four decades of uninterrupted civilian
leadership, progressive social policies, and
significant capital investment have created
one of the most dynamic economies in
Africa. Mineral extraction, principally
diamond mining, dominates economic
activity, though tourism is a growing sector
due to the country’s conservation practices
and extensive nature preserves. Botswana
has one of the world’s highest known rates
of F1IV/AIDS infection, but also one of
Africa’s most progressive and comprehen¬
sive programs for dealing with the disease.
Disputes— international: Botswana still
struggles to seal its border from thou¬
sands of Zimbabweans who flee economic
collapse and political persecution;
Namibia has long supported, and in 2004
Zimbabwe dropped objections to, plans
between Botswana and Zambia to build a
bridge over the Zambezi River at Kazungula
crossing, thereby de facto recognizing the
short, but not clearly delimited, Botswana-
Zambia boundary
92','d35d3321eb0bfcc3a34c412ccad99205772a9a72b7514090e6b21317b0a14fff','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46021cc6f069b247bf033140c2354949e193a5af7ad3177427c2c6d87e7e5cc0',2010,'BV','Bouvet Island','transnational-issues',338,'Background: This uninhabited volcanic
island is almost entirely covered by glaciers
and is difficult to approach. It was discov¬
ered in 1 739 by a French naval officer after
whom the island was named. No claim was
made until 1825, when the British flag was
raised. In 1928, the UK waived its claim in
favor of Norway, which had occupied the
island the previous year. In 1971, Norway
designated Bouvet Island and the adjacent
territorial waters a nature reserve. Since
1977, it has run an automated meteoro¬
logical station on the island.
Disputes— international : none','0cb0c129c34a0cbfeeb7cc43f3bddcf6a9a3e6998785be142c87d81e2817e6f4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b009388a4ab4adf09ffb476fab1f2dbef401f0d6fc6c7e3ab9abb5026762fad',2010,'BR','Brazil','transnational-issues',342,'Background: Following more than three
centuries under Portuguese rule, Brazil
peacefully gained its independence in
1822, maintaining a monarchical system of
government until the abolition of slavery in
1888 and the subsequent proclamation of
a republic by the military in 1889. Brazilian
coffee exporters politically dominated
the country until populist leader Getulio
VARGAS rose to power in 1930. By far
the largest and most populous country in
South America, Brazil underwent more
than half a century of populist and military
government until 1985, when the military
regime peacefully ceded power to civilian
rulers. Brazil continues to pursue indus¬
trial and agricultural growth and develop¬
ment of its interior. Exploiting vast natural
resources and a large labor pool, it is today
South America’s leading economic power
and a regional leader. Highly unequal
income distribution and crime remain
pressing problems.','0151d93d927ab29ecd7a23cb19b082500e1c976718b2a01437c2e9514d84c063','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af46248c598a1cab8206bebd3edcba5c4e89328287e4305ac907e7fe9d251625',2010,'IO','British Indian Ocean Territory','transnational-issues',351,'Disputes — international: unruly region at
convergence of Argentina-Brazil-Paraguay
borders is locus of money laundering,
smuggling, arms and illegal narcotics
trafficking, and fundraising for extremist
organizations; uncontested boundary
dispute with Uruguay over Isla Brasilera
at the confluence of the Quarai/Cuareim
and Invernada rivers, that form a tripoint
with Argentina; the Itaipu Dam reservoir
covers over a once contested section of
Brazil-Paraguay boundary west of Guaira
Falls on the Rio Parana; an accord placed
the long-disputed Isla Suarez/Ilha de
Guajara-Mirim, a fluvial island on the Rio
Mamore, under Bolivian administration in
1958, but sovereignty remains in dispute
Illicit drugs: second-largest consumer
of cocaine in the world; illicit producer
of cannabis; trace amounts of coca culti¬
vation in the Amazon region, used for
domestic consumption; government
has a large-scale eradication program to
control cannabis; important transship¬
ment country for Bolivian, Colombian,
and Peruvian cocaine headed for Europe;
also used by traffickers as a way station for
narcotics air transshipments between Peru
and Colombia; upsurge in drug-related
violence and weapons smuggling; impor¬
tant market for Colombian, Bolivian, and
Peruvian cocaine; illicit narcotics proceeds
are often laundered through the financial
system; significant illicit financial activity in
the Tri-Border Area (2008)
Background: Formerly administered
as part of the British Crown Colony of
Mauritius, the British Indian Ocean
Territory (BIOT) was established as an
overseas territory of the UK in 1965. A
number of the islands of the territory
were later transferred to the Seychelles
when it attained independence in 1976.
Subsequently, BIOT has consisted only
of the six main island groups comprising
the Chagos Archipelago. The largest
and most southerly of the islands, Diego
Garcia, contains a joint UK-US naval
support facility. All of the remaining
islands are uninhabited. Between 1967
and 1973, former agricultural workers,
earlier residents in the islands, were relo¬
cated primarily to Mauritius, but also to
the Seychelles. Negotiations between 1971
and 1982 resulted in the establishment of
a trust fund by the British Government as
compensation for the displaced islanders,
known as Chagossians. Beginning in
1998, the islanders pursued a series of
lawsuits against the British Government
seeking further compensation and the
right to return to the territory. In 2006
and 2007, British court rulings invali¬
dated the immigration policies contained
in the 2004 BIOT Constitution Order
that had excluded the islanders from
the archipelago, but upheld the special
military status of Diego Garcia. In 2008,
the House of Lords, as the final court of
appeal in the UK, ruled in favor of the
British Government by overturning the
lower court rulings and finding no right
of return on the part of the Chagossians.
Disputes— international: Mauritius claims
the Chagos Archipelago including Diego
Garcia; in 2001, the former inhabitants
of the Chagos Archipelago, evicted in
1967 and 1973 and now residing chiefly
in Mauritius, were granted UK citizenship
and the right to repatriation; in May 2007,
the UK Court of Appeals upheld the May
2006 High Court of London judgment
reversing the UK government’s 2004
Orders of Council that banned habita¬
tion on the islands; a small group of
Chagossians visited Diego Garcia in April
2006; repatriation is complicated by the
exclusive US military lease of Diego Garcia
that restricts access to the largest viable
island in the chain
BRITISH VIRGIN ISLANDS
Disputes — international: none
Illicit drugs: transshipment point for
South American narcotics destined for the
US and Europe; large offshore financial
center makes it vulnerable to money
laundering
100
BRUNEI','79f1df37385e95d11858f7d29a601b4417ea2a97be9a960c77db3cfc63205244','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a139ec974bb31e5bfda61a6e8e275957ae4d3d396e0a83841f3ca9fcc60a29c8',2010,'BG','Bulgaria','transnational-issues',367,'Disputes— international: Brunei and
Malaysia agreed in September 2008 to
resolve their offshore and deepwater
seabed dispute, resume hydrocarbon explo¬
ration, and renounce any territorial claims
on land; Brunei established an exclusive
economic fishing zone encompassing
Louisa Reef in the southern Sprady Islands
in 1984, but makes no public territo¬
rial claim to the offshore reefs; the 2002
“Declaration on the Conduct of Parties in
the South China Sea” has eased tensions
in the Sprady Islands but falls short of a
legally binding “code of conduct” desired
by several of the disputants
Illicit drugs: drug trafficking and illegally
importing controlled substances are serious
offenses in Brunei and carry a mandatory
death penalty','80c054b603b7213bc17e50f01831d7c338ffbcf29c2a91ac8a803b52be154975','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3074fe0400da7dadcddd78d6b31d812a86ec68393b9eaa6163f0b07cfa994633',2010,'BF','Burkina Faso','transnational-issues',372,'Disputes — international : none
Illicit drugs: major European transship¬
ment point for Southwest Asian heroin
and, to a lesser degree, South American
cocaine for the European market; limited
producer of precursor chemicals; vulnerable
to money laundering because of corruption,
organized crime; some money laundering
of drug-related proceeds through financial
institutions (2008)
Disputes — international: in September
2007, Economic Community of West
African States (ECOWAS) intervened
to attempt to resolve the dispute over two
villages along the Benin-Burkina Faso
border that remain from 2005 ICJ decision;
in recent years citizens and rogue security
forces rob and harass local populations on
both sides of the poorly-defined Burkina
Faso-Niger border; despite the presence of
over 9,000 UN forces (UNOCI) in Cote
d’Ivoire since 2004, ethnic conflict continues
to spread into neighboring states who can
no longer send their migrant workers to
work in Ivorian cocoa plantations
BURMA
mmmm
i&iiiiiSisiiiiiii&i-
Disputes — international: over half of
Burma’s population consists of diverse
ethnic groups who have substantial
numbers of kin in neighboring countries;
Thailand must deal with Karen and other
ethnic refugees, asylum seekers, and rebels,
as well as illegal cross-border activities from
Burma; Thailand is studying the feasibility
of jointly constructing the Hatgyi Dam on
the Salween River near the border with
Burma; citing environmental, cultural, and
social concerns, China is reconsidering
construction of 13 dams on the Salween
River but energy-starved Burma with
backing from Thailand remains intent on
building five hydro-electric dams down¬
stream, despite identical regional and inter¬
national protests; India seeks Cooperation
from Burma to keep Indian Nagaland sepa¬
ratists, such as the United Liberation Front
of Assam, from hiding in remote Burmese
Uplands; after 21 years, Bangladesh
resumes talks with Burma on delimiting a
maritime boundary in January 2008
Refugees and internally displaced
persons: IDPs: 503,000 (government ofifen-
sives against ethnic insurgent groups near the
eastern borders; most IDPs are ethnic Karen,
Karenni, Shan, Tavoyan, and Mon) (2007)
Trafficking in persons: current situation:
Burma is a source country for women,
children, and men trafficked for the
purpose of forced labor and commercial
sexual exploitation; Burmese women and
children are trafficked to East and South¬
east Asia for commercial sexual exploi¬
tation, domestic servitude, and forced
labor; Burmese children are subjected to
conditions of forced labor in Thailand as
hawkers, beggars, and for work in shops,
agriculture, fish processing, and small-
scale industries; women are trafficked for
commercial sexual exploitation to Malaysia
and China; some trafficking victims transit
Burma from Bangladesh to Malaysia and
from China to Thailand; internal traf¬
ficking occurs primarily from villages to
urban centers and economic hubs for labor
in industrial zones, agricultural estates,
and commercial sexual exploitation;
military and civilian officials continue to
use a significant amount of forced labor;
ethnic insurgent groups also used compul¬
sory labor of adults and unlawful recruit¬
ment of children; the military junta’s
gross economic mismanagement, human
rights abuses, and its policy of using
forced labor are the top causal factors for
Burma’s significant trafficking problem
tier rating: Tier 3— Burma does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so; mili¬
tary and civilian officials remain direcdy
ihvolved in significant acts of forced
labor and unlawful conscription of child
soldiers (2008)
Illicit drugs: remains world’s second
largest producer of illicit opium with
an estimated production in 2008 of
340 metric tons, an increase of 26%,
and poppy cultivation in 2008 totaled
22,500 hectares, a 4% increase from
2007; production in the United Wa State
Army’s areas of greatest control remains
low; Shan state is the source of 94% of
Burma’s poppy cultivation; lack of govern¬
ment will to take on major narcotrafficking
groups and lack of serious commitment
against money laundering continues to
hinder the overall antidrug effort; major
source of methamphetamine and heroin
for regional consumption (2008)','c835967d6b3f65473bd821de5c26061d611263f4aaba6c8f177872afba7c7d80','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73ceced6aa7781838be6a0ed57b089834e308d55b4984bca5ef964bb7fe33640',2010,'BI','Burundi','transnational-issues',386,'Disputes — international: Burundi and
Rwanda dispute sections of border on
the Akanyaru/Kanyaru and the Kagera/
Nyabarongo rivers, which have changed
course since the 1960s, when the boundary
was delimited; cross-border conflicts among
Tutsi, Hutu, other ethnic groups, associ¬
ated political rebels, armed gangs, and
various government forces persist in the
Great Lakes region
Refugees and internally displaced
persons: refugees (country of origin): 9,849
(Democratic Republic of the Congo)
IDPs: 100,000 (armed conflict between
government and rebels; most IDPs in
northern and western Burundi) (2007)
Trafficking in persons: current situation:
Burundi is a source country for children traf¬
ficked for the purposes of child soldiering,
domestic servitude, and commercial sexual
exploitation; a small number of Burun¬
dian children may be trafficked internally
for domestic servitude or commercial
sexual exploitation; in early 2008, Burun¬
dian children were allegedly trafficked
to Uganda, via Rwanda, for agricultural
labor and commercial sexual exploitation
tier rating: Tier 2 Watch List— Burundi is
on the Tier 2 Watch List for the second
consecutive year for its failure to provide
sufficient evidence of increasing efforts to
combat trafficking in persons in 2007; the
government’s inability to provide adequate
protective services to children accused
of association with armed groups and to
conduct anti-trafficking law enforcement
activities continue to be causes for concern;
Burundi has not ratified the 2000 UN TIP
Protocol (2008)
117','0f3fae5e759f742d7ae58c78d7b86c2b8ef0790cec9d6b910f295905c0cb283c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e3d1c760a9408e11a296254a7394b628cf87fd992b10860d56464013441db86',2010,'CM','Cameroon','transnational-issues',396,'Disputes — international: Cambodia and
Thailand dispute sections of boundary
with missing boundary markers and claims
of Thai encroachments into Cambodian
territory; maritime boundary with Vietnam
is hampered by unresolved dispute over
sovereignty of offshore islands; Thailand
accuses Cambodia of obstructing inclusion
of Thai areas near Preah Vihear temple
ruins, awarded to Cambodia by ICJ deci¬
sion in 1962, as part of a planned UN
World Heritage site
Illicit drugs: narcotics-related corruption
reportedly involving some in the govern¬
ment, military, and police; limited meth-
amphetamine production; vulnerable to
money laundering due to its cash-based
economy and porous borders
highest point: Fako 4,095 m
(on Mt. Cameroon)
Natural resources: petroleum, bauxite,
iron ore, timber, hydropower
Land use:
arable land: 12.54%
permanent crops: 2.52%
other: 84.94% (2005)
Irrigated land: 260 sq km (2003)
Total renewable water resources: 285.5
cu km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 0.99 cu km/yr (18%/8%/74%)
per capita: 61 cu m/yr (2000)
Natural hazards: volcanic activity with
periodic releases of poisonous gases from
Lake Nyos and Lake Monoun volcanoes
Environment — current issues:
waterborne diseases are prevalent;
deforestation; overgrazing; desertification;
poaching; overfishing
Environment — international
agreements: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, O zone
Layer Protection, Tropical Timber 83,
121
THE CIA WORLD FACTBOOK
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: sometimes referred
to as the hinge of Africa; throughout the
country there are areas of thermal springs
and indications of current or prior volcanic
activity; Mount Cameroon, the highest
mountain in Sub-Saharan west Africa, is
an active volcano
Disputes— international: Joint Border
Commission with Nigeria reviewed 2002
ICJ ruling on the entire boundary and bilat¬
erally resolved differences, including June
2006 Greentree Agreement that imme¬
diately ceded sovereignty of the Bakassi
Peninsula to Cameroon with a full phase¬
out of Nigerian control and patriation of
residents in 2008; Cameroon and Nigeria
agree on maritime delimitation in March
2008; sovereignty dispute between Equato¬
rial Guinea and Cameroon over an island
at the mouth of the Ntem River; only
Nigeria and Cameroon have heeded the
Lake Chad Commission’s admonition to
ratify the delimitation treaty, which also
includes the Chad-Niger and Niger-Nigeria
boundaries
Refugees and internally displaced
persons: refugees ( country of origin): 20,000-
30,000 (Chad); 3,000 (Nigeria); 24,000
(Central African Republic) (2007)
Trafficking in persons: current situation:
Cameroon is a source, transit, and desti¬
nation country for women and children
trafficked for the purposes of forced labor
and commercial sexual exploitation; most
victims are children trafficked within
country, with girls primarily trafficked for
domestic servitude and sexual exploita¬
tion; both boys and girls are also traf¬
ficked within Cameroon for forced labor
in sweatshops, bars, restaurants, and on
tea and cocoa plantations; children are traf¬
ficked into Cameroon from neighboring
states for forced labor in agriculture,
fishing, street vending, and spare-parts
shops; Cameroon is a transit country for
children trafficked between Gabon and
Nigeria, and from Nigeria to Saudi Arabia;
it is a source country for women trans¬
ported by sex-trafficking rings to Europe
tier rating: Tier 2 Watch List— Cameroon
is on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat human trafficking in 2007,
particularly in terms of efforts to prosecute
and convict trafficking offenders; while
Cameroon reported some arrests of traf¬
fickers, none of them were prosecuted
or punished; the government does not
identify trafficking victims among vulner¬
able populations nor does it monitor the
number of victims it intercepts (2008)','fb32a2d2f28ec8f631f55da2677f53d0ba8422303948cf2569e113c67327dcd5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7266d8726655ced2cf8b77bb107c4b7966bd5c2eaa57d85796f08d61ff73c4eb',2010,'CA','Canada','transnational-issues',407,'Disputes — international: managed mari¬
time boundary disputes with the US at
Dixon Entrance, Beaufort Sea, Strait of Jqan
de Fuca, and the Gulf of Maine including
the disputed Machias Seal Island and North
Rock; Canada, the US, and other coun¬
tries dispute the status of the Northwest
Passage; US works closely with Canada to
intensify security measures for monitoring
and controlling legal and illegal movement
of people, transport, and commodities
across the international border; sovereignty
dispute with Denmark over Flans Island in
the Kennedy Channel between Ellesmere
Island and Greenland; commencing the
collection of technical evidence for submis¬
sion to the Commission on the Limits of the
Continental Shelf in support of claims for
continental shelf beyond 200 nautical miles
from its declared baselines in the Arctic, as
stipulated in Article 76, paragraph 8, of the
United Nations Convention on the Law of
the Sea
iiiicif drugs: illicit producer of cannabis
for the domestic drug market and export
to US; use of hydroponics technology
permits growers to plant large quanti¬
ties of high-quality marijuana indoors;
increasing ecstasy production, some of
which is destined for the US; vulnerable to
narcotics money laundering because of its
mature financial services sector
CAPE VERDE
Samo
0 , , ,
. .
Sam l«z>a
A-
S#o
S&cNicetw
S °o
m
»Sams
mm
xamn&ri&H-uc s*rQ &oa
soTAvemo
w
r%
w''y-''wmmm
Fogo *PRAJA
- -M :
.','cfd4018aac1b5072c8725c2e762d1efcc1b8cf8c64c0f3786380a2af2d4770e3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('382e059111465595de998b00b0a2bb519c520cc6d0229fd6a7a80ca3d5e5261c',2010,'SN','Senegal','transnational-issues',415,'Disputes— international: none
Illicit drugs: used as a transshipment
point for Latin American cocaine destined
for Western Europe, particularly because
of Lusophone links to Brazil, Portugal,
and Guinea-Bissau; has taken steps to
deter drug money laundering, including
a 2002 anti-money laundering reform that
criminalizes laundering die proceeds of
narcotics trafficking and other crimes and
the establishment in 2008 of a Financial
Intelligence Unit (2008)
130
Disputes— international: Saudi Arabia
has reinforced its concrete-filled security
barrier along sections of the now fully
demarcated border with Yemen to stem
illegal cross-border activities; Kuwait and
Saudi Arabia continue discussions on a
maritime boundary with Iran
Refugees and internally displaced
persons: refugees ( country of origin ):
240,015 (Palestinian Territories) (2007)
Trafficking in persons: current situation:
Saudi Arabia is a destination country for
workers from South and Southeast Asia
who are subjected to conditions that consti¬
tute involuntary servitude including being
subjected to physical and sexual abuse,
non-payment of wages, confinement, and
withholding of passports as a restriction
on their movement; domestic workers are
particularly vulnerable because some are
confined to the house in which they work
unable to seek help; Saudi Arabia is also a
destination country for Nigerian, Yemeni,
Pakistani, Afghan, Somali, Malian, and
Sudanese children trafficked for forced
begging and involuntary servitude as street
vendors; some Nigerian women were
reportedly trafficked into Saudi Arabia for
commercial sexual exploitation
tier rating: Tier 3— Saudi Arabia does not
fully comply with the minimum standards
for the elimination of trafficking and is
not making significant efforts to do so; the
government continues to lack adequate
anti-trafficking laws and, despite evidence
of widespread trafficking abuses, did not
report any criminal prosecutions, convic¬
tions, or prison sentences for trafficking
crimes committed against foreign domestic
workers (2008)
Illicit drugs: death penalty for traf¬
fickers; improving anti-money-laundering
legislation and enforcement
Disputes — international: The Gambia
and Guinea-Bissau attempt to stem
separatist violence, cross border raids,
and arms smuggling into their countries
from Senegal’s Casamance region, and
in 2006, respectively accepted 6,000 and
10,000 Casamance residents fleeing the
conflict; 2,500 Guinea-Bissau residents
fled into Senegal in 2006 to escape armed
confrontations along the border
Refugees and internally displaced
persons: refugees ( country of origin): 19,630
(Mauritania)
IDPs: 22,400 (approximately 65% of the
IDP population returned in 2005, but
new displacement is occurring due to
clashes between government troops and
separatists in Casamance region) (2007)
1 1 1 icit drugs: transshipment point for South¬
west and Southeast Asian heroin and South
American cocaine moving to Europe and
North America; illicit cultivator of cannabis','2b338f11f22454023444389bac6d135b2de5a9d7d965923c76826dfa364f54aa','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95c59488a2a5a9a0448459e370e27f8bc5b3d80b55426e7ec283e01531cb21bf',2010,'CF','Central African Republic','transnational-issues',425,'Disputes— international: none
Illicit drugs: major offshore financial
center; vulnerable to drug transshipment
to the US and Europe (2008)
Background: The former French colony
of Ubangi-Shari became the Central
African Republic upon independence in
1960. After three tumultuous decades of
misrule— mostly by military governments—
civilian rule was established in 1993 and
lasted for one decade. President Ange-
Felix PATASSE’s civilian government was
plagued by unrest, and in March 2003
he was deposed in a military coup led by
General Francois BOZIZE, who estab¬
lished a transitional government. Though
the government has the tacit support of
civil society groups and the main parties,
a wide field of candidates contested the
municipal, legislative, and presidential
elections held in March and May of 2005
in which General BOZIZE was affirmed
as president. The government still does
not fully control the countryside, where
pockets of lawlessness persist. Unrest in
neighboring nations, Chad, Sudan, and
the DRC, continues to affect stability in the
Central African Republic as well.
Disputes — international: periodic skir¬
mishes over water and grazing rights
among related pastoral populations along
the border with southern Sudan persist
Refugees and internally displaced
persons: refugees (country of origin ):
7,900 (Sudan); 3,700 (Democratic
Republic of the Congo); note— UNF1CR
resumed repatriation of Southern Suda¬
nese refugees in 2006
135
THE CIA WORLD FACTBOOK
IDPs: 197,000 (ongoing unrest following
coup in 2003) (2007)
Trafficking in persons: current situation:
Central African Republic is a source,
transit, and destination country for men,
women, and children trafficked for the
purposes of forced labor and sexual
exploitation; the majority of victims are
children trafficked within the country for
sexual exploitation, domestic servitude,
street vending, and forced agricultural,
mine, market and restaurant labor; to
a lesser extent, children are trafficked
from the Central African Republic to
Cameroon, Nigeria, and the Democratic
Republic of Congo; rebels conscript chib
dren into armed forces within the country
tier rating: Tier 2 Watch List— Central
African Republic is on the Tier 2 Watch
List for the third consecutive year for its
failure to show evidence of increasing
efforts to combat trafficking in 2007; efforts
to address trafficking through vigorous law
enforcement measures and victim protec¬
tion efforts were minimal, though aware¬
ness about trafficking appeared to be
increasing in the country; the government
does not actively investigate cases, work to
identify trafficking victims among vulner¬
able populations, or rescue and provide
care to victims; the government has not
taken measures to reduce demand for
commercial sex acts (2008)','c4e16e8c0b048d94894a9ec2c8297e52413c2128c1a5bae6e13a98ca554ba155','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2372285d49c59187703f7a220659dc3f93984a7cef91d9e4c3c0b2c00737c79',2010,'CL','Chile','transnational-issues',438,'Disputes — international: since 2003,
Janjawid armed militia and the Sudanese
military have driven hundreds of thou¬
sands of Darfur residents into Chad; Chad
remains an important mediator in the Suda¬
nese civil conflict, reducing tensions with
Sudan arising from cross-border banditry;
Chadian Aozou rebels reside in southern
Libya; only Nigeria and Cameroon have
heeded the Lake Chad Commission’s
admonition to ratify the delimitation treaty,
which also includes the Chad-Niger and
Niger-Nigeria boundaries
Refugees and internally displaced
persons: refugees (country of origin): 234,000
(Sudan); 54,200 (Central African Republic)
I DPs: 178,918 (2007)
Trafficking in persons: current situation:
Chad is a source, transit, and destina¬
tion country for children trafficked for the
purposes of forced labor and commercial
sexual exploitation; the majority of
Chile was under Inca rule while the indig¬
enous Mapuche inhabited central and
southern Chile. Although Chile declared
its independence in 1810, decisive victory
over the Spanish was not achieved until
1818. In the War of the Pacific (187 9 —
83), Chile defeated Peru and Bolivia and
won its present northern regions. It was
not until the 1880s that the Mapuche
Indians were completely subjugated. After
a series of elected governments, a three-
year-old Marxist government of Salvador
ALLENDE was overthrown in 1973 by a
military coup led by Augusto PINOCF1ET,
who ruled until a freely elected president
was installed in 1990. Sound economic
policies, maintained consistently since the
1980s, have contributed to steady growth,
reduced poverty rates by over half, and have
helped secure the country’s commitment to
democratic and representative government.
Chile has increasingly assumed regional
and international leadership roles befitting
its status as a stable, democratic nation.
Disputes— international: Chile and Peru
rebuff Bolivia’s reinvigorated claim to
restore the Atacama corridor, ceded to Chile
in 1884, but Chile has offered instead unre¬
stricted but not sovereign maritime access
through Chile to Bolivian gas and other
commodities; Chile rejects Peru’s unilateral
legislation to change its latitudinal maritime
boundary with Chile to an equidistance
line with a southwestern axis favoring Peru,
in October 2007, Peru took its maritime
complaint with Chile to the ICJ; territorial
claim in Antarctica (Chilean Antarctic Terri¬
tory) partially overlaps Argentine and British
claims; die joint boundary commission,
established by Chile and Argentina in 2001 ,
has yet to map and demarcate the delim¬
ited boundary in the inhospitable Andean
Southern Ice Field (Campo de Hielo Sur)
Illicit drugs: transshipment country for
cocaine destined for Europe and the region;
some money laundering activity, especially
through the Iquique Free Trade Zone;
imported precursors passed on to Bolivia;
domestic cocaine consumption is rising,
making Chile a significant consumer of
cocaine (2008)
142','379be5b71c1967790ea26cc323935b8ca48528624a0dc3fdb10b8b46318a1ce3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('756f9b4f601a06fff3d87d12c64093e68f8a3f55af3c4253eb65d2681c9f0f2e',2010,'CX','Christmas Island','transnational-issues',452,'Disputes— international: continuing talks
and confidence-building measures work
toward reducing tensions over Kashmir
that nonetheless remains militarized
with portions under the de facto admin-
istration of China (Aksai Chin), India
(Jammu and Kashmir), and Pakistan (Azad
Kashmir and Northern Areas); India does
not recognize Pakistan’s ceding historic
Kashmir lands to China in 1964; China
and India continue their security and
foreign policy dialogue started in 2005
related to the dispute over most of their
rugged, militarized boundary, regional
nuclear proliferation, and other matters;
China claims most of India’s Arunachal
Pradesh to the base of the Himalayas;
lacking any treaty describing the boundary,
Bhutan and China continue negotiations
to establish a common boundary align¬
ment to resolve territorial disputes due to
cartographic discrepancies; Chinese maps
show an international boundary symbol off
the coasts of the littoral states of the South
China Seas, where China has interrupted
Vietnamese hydrocarbon exploration;
China asserts sovereignty over the Spratly
Islands together with Malaysia, Philippines,
Taiwan, Vietnam, and possibly Brunei;
the 2002 “Declaration on the Conduct
of Parties in the South China Sea” eased
tensions in the Spratly’s but is not the
legally binding “code of conduct” sought
by some parties; Vietnam and China
continue to expand construction of facili¬
ties in the Spratly’s and in March 2005,
the national oil companies of China, the
Philippines, and Vietnam signed a joint
Disputes — international : none
CLIPPERTON ISLAND
Background: This isolated island was
named for John CLIPPERTON, a pirate
who made it his hideout early in the 1 8th
century. Annexed by France in 1855, it
was seized by Mexico in 1897. Arbitration
eventually awarded the island to France,
which took possession in 1935.
Disputes — international: none','a9e6751bc0834c99da4a86ad0389d12f95a6e50a54107e688e4de6c663fa9c84','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3c3c6b806deeb85c23296489cd6ab6dc4880f224e411e385eea887b43097cb0',2010,'CO','Colombia','transnational-issues',468,'Disputes — international : none
Background: Colombia was one of the
three countries that emerged from the
collapse of Gran Colombia in 1830 (the
others are Ecuador and Venezuela). A
four-decade-long conflict between govern¬
ment forces and anti-government insur¬
gent groups, principally the Revolutionary
Armed Forces of Colombia (FARC) heavily
funded by the drug trade, escalated during
the 1990s. The insurgents lack the military
or popular support necessary to overthrow
the government and violence has been
decreasing since about 2002, but insur¬
gents continue attacks against civilians and
large areas of the countryside are under
guerrilla influence or are contested by secu¬
rity forces. More than 31,000 former para¬
militaries had demobilized by the end of
2006 and the United Self Defense Forces
of Colombia (AUC) as a formal organiza¬
tion had ceased to function. In the wake of
the paramilitary demobilization, emerging
criminal groups arose, whose members
include some former paramilitaries. The
Colombian Government has stepped
up efforts to reassert government control
throughout the country, and now has a
presence in every one of its administrative
departments. However, neighboring coun¬
tries worry about the violence spilling over
their borders.
Disputes— international: in December
2007, ICJ allocates San Andres, Providencia,','8d5202ac44198fcb8920e03084faade7dcad8ddf66c9d3346a3f35e2d6aace66','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8df2e53ecc0b1b860449c2a640ff39f75b0e13e068c8ea66b3af955f2f6f0bde',2010,'KM','Comoros','transnational-issues',475,'gaining independence from France in
1975. In 1997, the islands of Anjouan
and Moheli declared independence from
Comoros. In 1999, military chief Col.
AZALI seized power in a bloodless coup,
and helped negotiate the 2000 Fomboni
Accords power-sharing agreement in
which the federal presidency rotates
among the three islands, and each island
maintains its own local government.
AZAFI won the 2002 Presidential elec-,
tion, and each island in the archipelago
elected its own president. AZAFI stepped
down in 2006 and President SAMBI
was elected to office. In 2007, BACAR
effected Anjouan’ s de-facto secession
from the Union, refusing to step down
in favor of fresh Anjouanais elections
when Comoros’ other islands held
and Santa Catalina islands to Colombia
under 1928 Treaty but does not rule on
82 °W meridian as maritime boundary with
Nicaragua; managed dispute with Venezuela
over maritime boundary and Venezuelan-
administered Los Monjes Islands near the
Gulf of Venezuela; Colombian-organized
illegal narcotics, guerrilla, and paramilitary
activities penetrate all neighboring borders
and have caused Colombian citizens to
flee mostly into neighboring countries;
Colombia, Honduras, Nicaragua, Jamaica,
and the US assert various claims to Bajo
Nuevo and Serranilla Bank
Refugees and infernaliy displaced
persons: IDPs: 1.8— 3.5 million (conflict
between government and illegal armed
groups and drug traffickers) (2007)
Illicit drugs: illicit producer of coca,
opium poppy, and cannabis; world’s
leading coca cultivator with 167,000
hectares in coca cultivation in 2007, a
6% increase over 2006, producing a
potential of 535 mt of pure cocaine; the
world’s largest producer of coca deriva¬
tives; supplies cocaine to nearly all of
the US market and the great majority of
other international drug markets; in 2005,
aerial eradication dispensed herbicide to
treat over 1 30,000 hectares but aggressive
replanting on the part of coca growers
means Colombia remains a key producer;
a significant portion of narcotics proceeds
are either laundered or invested in
Colombia through the black market peso
exchange; important supplier of heroin to
the US market; opium poppy cultivation
is estimated to have fallen 25% between
2006 and 2007; most Colombian heroin
is destined for the US market; (2008)
legitimate elections in July. The African
Union (AU) initially attempted to resolve
the political crisis by applying sanctions
and a naval blockade on Anjouan, but in
March 2008, AU and Comoran soldiers
seized the island. The move was generally
welcomed by the island’s inhabitants.
Disputes — international: claims French''
administered Mayotte and challenges
France’s and Madagascar’s claims to Banc
du Geyser, a drying reef in the Mozambique
Channel; in May 2008, African Union
forces are called in to assist the Comoros
military recapture Anjouan Island from
rebels who seized it in 2001
CONGO, DEMOCRATIC REPUBLIC OF THE
447
THE CIA WORLD FACTBOOK','4f39a465d643ed58e0669e0078ecb41ca10f0306e653fcb83cbd76e4f510a78b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('027def2396c27bf66e42928227a55f0e90e9dd6f1425ca94805d8d4b781a399b',2010,'CG','Congo','transnational-issues',489,'Disputes — international: the location of
the boundary in the broad Congo River
with the Democratic Republic of the
Congo is indefinite except in the Pool
Malebo/Stanley Pool area
Refugees and internally displaced
persons: refugees (country of origin ):
46,341 (Democratic Republic of Congo);
6,564 (Rwanda)
IDPs: 48,000 (multiple civil wars since
1992; most IDPs are ethnic Lari) (2007)
Trafficking in persons: current situation:
Republic of the Congo is a source and
destination country for children traf¬
ficked for the purposes of forced labor
and commercial sexual exploitation; girls
are trafficked from rural areas within the
country for commercial sexual exploita¬
tion, forced street vending, and domestic
servitude; children are trafficked from','d15379ad531942ea61f64edae8b7042cbde8ab5f19acecb20d0eda290c531546','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9f8464a896c27e95fa8c599b31d43fa09ee76422bbe50d264565023498ce623',2010,'CK','Cook Islands','transnational-issues',490,'Area — comparative: 1.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical oceanic; moderated by
trade winds; a dry season from April to
November and a more humid season from
December to March
Terrain: low coral atolls in north; volcanic,
hilly islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use: arable land: 16.67%
permanent crops: 8.33%
other: 75% (2005)
Irrigated land: NA
Natural hazards: typhoons (November to
March)
Environment— current issues: NA
Environment— international
agreements: party to: Biodiversity,
Climate Change, Climate Change-Kyoto ''
Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection
Geography — note: the northern Cook
Islands are seven low-lying, sparsely popu¬
lated, coral atolls; the southern Cook
Islands, where most of the population
lives, consist of eight elevated, fertile,
other African countries for domestic
servitude, forced market vending, and
forced labor in the fishing industry
tier rating: Tier 2 Watch List— Republic of
the Congo is on the Tier 2 Watch List for
its failure to show evidence of increasing
efforts to combat trafficking in persons
in 2007; struggling to recover from six
years of civil conflict that ended in 2003,
the Republic of the Congo’s capacity to
address trafficking is handicapped; the
government neither monitors its borders
for trafficking activity nor provides special¬
ized anti-trafficking training for law enforce¬
ment officials; the government does not
encourage victims to assist in trafficking
investigations or prosecutions, and has
not taken measures to reduce demand for
commercial sex acts in the Republic of the
Congo (2008)
volcanic isles, including the largest, Raro¬
tonga, at 67 sq km','69b2e344083f70329fa35568345e9dc3d77dc4c70bc5d5ead8b0594d21a69674','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab6881d9580d26e8d1669feaeb4d1d775ae374a140bc02831b940750da31fb23',2010,'NZ','New Zealand','transnational-issues',498,'Disputes— international: none
CORAL SEA ISLANDS
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity, see African Union
official development assistance
Organization for Economic Cooperation and Development
Organization of Eastern Caribbean States
Office of the United Nations High Commissioner for Human Rights
Organization of the Islamic Conference
International Organization of the French-speaking World
United Nations Operation in Burundi
other official flows
Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean
Organization for the Prohibition of Chemical Weapons
Organization of Petroleum Exporting Countries
Organization for Security and Cooperation in Europe
Montreal Protocol on Substances That Deplete the Ozone Layer
Permanent Court of Arbitration
Partnership for Peace
Pacific Islands Forum
ABBREVIATIONS
PPP
Ramsar
RG
SAARC
SACU
SACEP
SADC
SCO
SAFE
SECI
SHF
Ship Pollution
Sparteca
SPC
SPF
sq km
sq mi
TAT
TEU
Tropical Timber 83
Tropical Timber 94
UAE
UDEAC
UHF
UK
UMA
UN
UNAMSIL
UNCLOS
UNCTAD
UNDCP
UNDOF
UNDP
UNEP
UNESCO
UNFICYP
UNFPA
UNHCR
UNICEF
UNICRI
UNIDIR
UNIDO
UNIFIL
UNITAR
UNMEE
UNMIK
UNMIL
UNMIT
UNMOGIP
UNMOVIC
UNOCI
UNOMIG
UNOPS
UNRISD
UNRWA
UNSC
UNSSC
UNTSO
UNU
UNWTO
UPU
purchasing power parity
see Wetlands
Rio Group
South Asian Association for Regional Cooperation
Southern African Customs Union
South Asia Co-opeative Environment Programme
Southern African Development Community
Shanghai Cooperation Organization
South African Far East Cable
Southeast European Cooperative Initiative
super-high-frequency
Protocol of 1978 Relating to the International Convention for the Prevention of Pollution
From Ships, 1973 (MARPOL)
South Pacific Regional Trade and Economic Cooperation Agreement
Secretariat of the Pacific Communities
South Pacific Forum
square kilometer
square mile
Trans-Atlantic Telephone
Twenty-Foot Equivalent Unit
International Tropical Timber Agreement, 1983
International Tropical Timber Agreement, 1994','481665e824f06c8f54d8aa124ebd457a8aa872a8662c7b7aa79b94861c575451','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8f90c187940449c88b0b8ce73e296c6d52f9f68f83364d20e8c148e642d96aa',2010,'CR','Costa Rica','transnational-issues',507,'Disputes— international : none
km/yr (29%/l 7%/53%)
per capita: 619 cu m/yr (2000)
Natural hazards: occasional earthquakes,
hurricanes along Atlantic coast; frequent
flooding of lowlands at onset of rainy
season and landslides; active volcanoes
Environment — current issues: deforesta¬
tion and land use change, largely a result of
the clearing of land for cattle ranching and
agriculture; soil erosion; coastal marine
pollution; fisheries protection; solid waste
management; air pollution
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Wetlands, Whaling
signed, but not ratified: Marine Life
Conservation
Geography— note: four volcanoes, two
of them active, rise near the capital of San
Jose in the center of the country; one of
the volcanoes, Irazu, erupted destructively
in 1963-65
Disputes — international: the ICJ has
given Costa Rica until January 2008 to
COTE D’IVOIRE
Disputes— international: despite the
presence of over 9,000 UN forces
(UNOCI) in Cote d’Ivoire since 2004,
ethnic conflict still leaves displaced
hundreds of thousands of Ivorians in and
out of the country as well as driven out
migrants from neighboring states who
worked in Ivorian cocoa plantations; the
March 2007 peace deal between Ivorian
rebels and the government brought signif¬
icant numbers of rebels out of hiding in
neighboring states
Refugees and internally displaced
persons:
refugees (country of origin): 25,615 (Liberia)','7f41028f7afd59f608120b041d23266138713abe51fed8b76eb5790a054b3517','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83fc3a9c8ff467d413f9e84a4f63ec85e48aab76b02dc4518abc7f906e3ce998',2010,'CU','Cuba','transnational-issues',517,'Disputes— international: dispute remains
with Bosnia and Herzegovina over several
small sections of the boundary related to
maritime access that hinders ratification of
the 1999 border agreement; the Croatia-
Slovenia land and maritime boundary agree¬
ment, which would have ceded most of Pirin
Bay and maritime access to Slovenia and
several villages to Croatia, remains unratified
and in dispute; Slovenia also protests Croa¬
tia''s 2003 claim to an exclusive economic
zone in the Adriatic; as a European Union
peripheral state, Slovenia imposed a hard
border Schengen regime with non-member
Croatia in December 2007
Refugees and internally displaced
persons: IDPs: 2,900—7,000 (Croats and
Serbs displaced in 1992—95 war) (2007)
Illicit drugs: transit point along the Balkan
route for Southwest Asian heroin to Western
Europe; has been used as a transit point for
maritime shipments of South American
cocaine bound for Western Europe (2008)','0011805ff81656122a84035c427618351eeea55f5ea40d74acc52be624dcf898','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f222c6e299c9b9697b08ae1d0229da6561ad2625dab9d394afd9ff060da0b281',2010,'CY','Cyprus','transnational-issues',528,'Disputes — international: US Naval Base
at Guantanamo Bay is leased to US and
only mutual agreement or US abandon-
ment of the facility can terminate the lease
Trafficking in persons: current situation:
Cuba is principally a source country for
women and children trafficked within the
country for the purpose of commercial
sexual exploitation and possibly for forced
labor; the country is a destination for
sex tourism, including child sex tourism,
which is a problem in many areas of the
country; some Cuban nationals willingly
migrate to the United States, but are subse-
quendy exploited for forced labor by their
smugglers; Cuba is also a transit point for
the smuggling of migrants from China, Sri
Lanka, Bangladesh, Lebanon, and other
nations to the United States and Canada
tier rating: Tier 3— Cuba does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so; exact
information about trafficking in Cuba
is difficult to obtain because the govern¬
ment does not acknowledge or condemn
human trafficking as a problem in Cuba;
tangible efforts to prosecute offenders,
protect victims, or prevent human traf¬
ficking activity do not appear to have been
made during 2007; Cuba has not ratified
the 2000 UN TIP Protocol (2008)
Illicit drugs: territorial waters and air
space serve as transshipment zone for US-
and European-bound drugs; established
die death penalty for certain drug-related
crimes in 1999 (2008)
Disputes— international: hostilities in
1974 divided the island into two de facto
autonomous entities, the internation¬
ally recognized Cypriot Government and
a Turkish-Cypriot community (north
Cyprus); the 1 ,000-strong UN Peace¬
keeping Force in Cyprus (UNFICYP) has
served in Cyprus since 1 964 and maintains
the buffer zone between north and south;
on 1 May 2004, Cyprus entered the Euro¬
pean Union still divided, with the EU’s
body of legislation and standards (acquis
communitaire) suspended in the north;
Turkey protests Cypriot Government
creating hydrocarbon blocks and maritime
boundary with Lebanon in March 2007
Refugees and internally displaced
persons: IDPs: 210,000 (both Turkish and
Greek Cypriots; many displaced for over
30 years) (2007)
Trafficking in persons: current situation:
Cyprus is primarily a destination country
for a large number of women trafficked
from Eastern and Central Europe, the
Philippines, and the Dominican Republic
for the purpose of sexual exploitation;
traffickers continued to fraudulendy
recruit victims for work as dancers in
cabarets and nightclubs on short-term
“artiste” visas, for work in pubs and bars
on employment visas, or for illegal work
on tourist or student visas
tier rating: Tier 2 Watch List— Cyprus is on
the Tier 2 Watch List for a third consecu¬
tive year for failure to show evidence of
increasing efforts to combat human traf¬
ficking during 2007; although Cyprus
passed a new trafficking law and opened
a government trafficking shelter, these
efforts are outweighed by its failure to show
tangible and critically needed progress in
the areas of law enforcement, victim protec¬
tion, and the prevention of trafficking
(2008)
Illicit drugs: minor transit point for heroin
and hashish via air routes and container
traffic to Europe, especially from Lebanon
and Turkey; some cocaine transits as well;
despite a strengthening of anti-money-laun¬
dering legislation, remains vulnerable to
money laundering; reporting of suspicious
transactions in offshore sector remains
weak (2008)
185
THE CIA WORLD FACTBOOK
CZECH REPUBLIC
Disputes— international: while threats
of international legal action never mate-
rialized in 2007, 915,220 Austrians,
with the support of the popular Freedom
Party, signed a petition in January 2008,
demanding that Austria block the Czech
Republic’s accession to the EU unless
Prague closes its controversial Soviet-
style nuclear plant in Temelin, bordering','d625da995ca140958249f6cc32d1fce33a5e09fcc6f81f3e441fd8fafa0be6d6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('061270aec9aed873e3ada595fe0bbb7e642f51476bf3de08372b32be46e7fa29',2010,'AT','Austria','transnational-issues',535,'Illicit drugs: transshipment point for
Southwest Asian heroin and minor
transit point for Latin American cocaine
to Western Europe; producer of synthetic
drugs for local and regional markets;
susceptible to money laundering related to
drug trafficking, organized crime; signifi¬
cant consumer of ecstasy (2008)
189','b815300973b16bd3903b0f6ebefa9c9f4be6406aa15ade5c7c88ac4356f8bbb6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381e5869339d9c0a1153d314d081cdf89abd27544ab8da7d8fb9b663794051df',2010,'DK','Denmark','transnational-issues',536,'Background: Once the seat of Viking
raiders and later a major north Euro-
pean power, Denmark has evolved into
a modern, prosperous nation that is
participating in the general political and
economic integration of Europe. It joined
NATO in 1949 and the EEC (now the
EU) in 1973. However, the country has
opted out of certain elements of the Euro-
pean Union’s Maastricht Treaty, including
the European Economic and Monetary
Union (EMU), European defense coopera¬
tion, and issues concerning certain justice
and home affairs.','e7d306bf0ee03ba814997f94ff94efbb026c63779565cbbf33c9546bd0bf4d2f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9e729cf4dc14fa107f7092d2fd80c403dad96adad8dc3d6c3b3d436e455efa',2010,'SE','Sweden','transnational-issues',544,'Disputes — international: Iceland, the
UK, and Ireland dispute Denmark’s claim
that the Faroe Islands’ continental shelf
extends beyond 200 nm; Faroese continue
to study proposals for full independence;
sovereignty dispute with Canada over Hans
Island in the Kennedy Channel between
Ellesmere Island and Greenland
DHEKELIA
Disputes — international:
none','f9b4875d4d77fa8adfd3ea5640818761c2f789d06923465078b3f918d786709d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cbede024e8cddd79390469eed58fa9708e45a3a599435ac1318cdedc4171b4b',2010,'DJ','Djibouti','transnational-issues',555,'Disputes— international: Djibouti main¬
tains economic ties and border accords
with “Somaliland” leadership while main¬
taining some political ties to various factions
in Somalia; Kuwait is chief investor in the
2008 restoration and upgrade of the Ethio-
pian-Djibouti rail link
Refugees and internally displaced
persons: refugees ( country of origin): 8,642
(Somalia) (2007)
196','ed04a3e45d5c68746338103b483b5cd912663ad5b39c731ad2b803bd4fc2b563','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee879086c7452317e953fbff6cae9414f25dd97ceba59f22f991aab017254659',2010,'DO','Dominican Republic','transnational-issues',564,'Disputes — international: Dominica is
the only Caribbean state to challenge
Venezuela’s sovereignty claim over Aves
Island and joins the other island nations
in challenging whether the feature sustains
human habitation, a criterion under the
UN Convention on the Law of the Sea
(UNCLOS), which permits Venezuela to
extend its Exclusive Economic Zone (EEZ)
and continental shelf claims over a large
portion of the eastern Caribbean Sea
Illicit drugs: transshipment point for
narcotics bound for the US and Europe;
minor cannabis producer (2008)
FERNANDEZ Reyna won election to a
second term in 2004 following a constitu¬
tional amendment allowing presidents to
serve more than one term.
Disputes — international: Flaitian migrants
cross the porous border into the Domin¬
ican Republic to find work; illegal migrants
from the Dominican Republic cross the
Mona Passage each year to Puerto Rico to
find better work
Trafficking in persons: current situation:
the Dominican Republic is a source, transit,
and destination country for men, women,
and children trafficked for the purposes
of commercial sexual exploitation and
forced labor; a large number of Dominican
women are trafficked into prostitution and
sexual exploitation in Western Europe,
Australia, Central and South America,
and Caribbean destinations; a significant
number of women, boys, and girls are traf¬
ficked within the country for sexual exploi¬
tation and domestic servitude
tier rating: Tier 2 Watch List— for a second
consecutive year, the Dominican Republic
is on the Tier 2 Watch List for its failure
to show evidence of increasing efforts to
combat human trafficking, particularly
in terms of not adequately investigating
and prosecuting public officials who may
be complicit with trafficking activity, and
inadequate government efforts to protect
trafficking victims; the government has
taken measures to reduce demand for
commercial sex acts with children through
criminal prosecutions (2008)
Illicit drugs: transshipment point for
South American drugs destined for the US
and Europe; has become a transshipment
point for ecstasy from the Netherlands and
Belgium destined for US and Canada;
substantial money laundering activity,
in particular by Colombian narcotics
traffickers; significant amphetamine
consumption (2008)
202','003afe3904c8f32cd684182d01e3ddc6c20ae4bef840fc2849ace94c211fb8b0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b30d22b6f1a67a50e5233c526cd22fad8c50265da52d8197846a246657703794',2010,'EC','Ecuador','transnational-issues',576,'Disputes— international: organized illegal
narcotics operations in Colombia penetrate
across Ecuador’s shared border, which
thousands of Colombians also cross to
escape the violence in their home country
Refugees and internally displaced
persons: refugees ( country of origin ): 1 1,526
(Colombia); note— UNHCR estimates as
many as 250,000 Columbians are seeking
asylum in Ecuador, many of whom do not
register as refugees for fear of deportation
(2007)
Illicit drugs: significant transit country
for cocaine originating in Colombia and
Peru, with much of the US-bound cocaine
passing through Ecuadorian Pacific waters;
importer of precursor chemicals used
in production of illicit narcotics; attrac¬
tive location for cash-placement by drug
traffickers laundering money because of
dollarization and weak anti-money-laun-
dering regime; increased activity on the
northern frontier by trafficking groups and
Colombian insurgents (2008)','f9f04a0b75b3094c35bb7ef74630ac155824ae5c6e738554b3d8b1fc3f27e3f0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ade4b558e0651be07e3f96c0bb4a20798efff7f4bf8424521c16aeab64d3e484',2010,'EG','Egypt','transnational-issues',577,'mmi
Ai
*S!wari
Z''/*& ''
Matruh Shufe.
- It
’ CAIRO
A! Fayyitm*
AHWiny^ mim
.nnw. ’1Sf
A»,«- *’»“
Safajan
Ai Khifjjati
.«>*•« .<•
Ttwigse /V
I "JgtgBaThw, m&m
Disputes— international: while Sudan
retains claim to the Hala’ib Triangle north
of the 1899 Treaty boundary along the
22nd Parallel, both states withdrew their
military presence in the 1990s and Egypt
has invested in and effectively adminis¬
ters the area; Egypt no longer shows its
administration of the Bir Tawil trapezoid
in Sudan on its maps; Gazan breaches
in the security wall with Egypt in January
2008 highlight difficulties in monitoring
the Sinai border
Refugees and internally displaced
persons: refugees ( country of origin ):
60,000— 80,000 (Iraq); 70,198 (Palestinian
Territories); 12,157 (Sudan) (2007)
Trafficking in persons: current situation:
Egypt is a transit country for women traf¬
ficked from Eastern European countries
to Israel for sexual exploitation, and is a
source for children trafficked within the
209
THE CIA WORLD FACTBOOK
country for commercial sexual exploita¬
tion and domestic servitude, although
the extent to which children are trafficked
internally is unknown; children were also
recruited for domestic and agricultural
work; some of these children face condi¬
tions of involuntary servitude, such as
restrictions on movement, non-payment of
wages, threats, and physical or sexual abuse
tier rating : Tier 2 Watch List— Egypt is on
the Tier 2 Watch List for the third year in','c42c5fb614086a99ebf353116f392234f6f9d78ade355818955e09754c0af983','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68da985e78bad8b2d8f4ff5a2be80e787fcd8cf42405f86aa83f74920b5734d1',2010,'GQ','Equatorial Guinea','transnational-issues',594,'Disputes — international: International
Court of Justice (ICJ) ruled on the delimita¬
tion of“bolsones” (disputed areas) along the
El Salvador-FIonduras boundary, in 1992,
with final agreement by the parties in 2006
after an Organization of American States
(OAS) survey and a further ICJ ruling in
2003; the 1992 ICJ ruling advised a tripar¬
tite resolution to a maritime boundary in
the Gulf of Fonseca advocating Honduran
access to the Pacific; El Salvador continues
to claim tiny Conejo Island, not identified
in the ICJ decision, off Honduras in the
Gulf of Fonseca
illicit drugs: transshipment point for
cocaine; small amounts of marijuana
produced for local consumption; signifi¬
cant use of cocaine
Background: Equatorial Guinea gained
independence in 1968 after 190 years of
Spanish rule. This tiny country, composed
of a mainland portion plus five inhabited
islands, is one of the smallest on the African
continent. President Teodoro OBIANG
NGUEMA MBASOGO has ruled the
country since 1979 when he seized power
in a coup. Although nominally a consti¬
tutional democracy since 1991, the 1996
and 2002 presidential elections— as well as
the 1999 and 2004 legislative elections—
were widely seen as flawed. The president
exerts almost total control over the polit¬
ical system and has discouraged political
opposition. Equatorial Guinea has expe¬
rienced rapid economic growth due to the
discovery of large offshore oil reserves,
and in the last decade has become sub-
Saharan Africa’s third largest oil exporter.
Despite the country’s economic windfall
from oil production resulting in a massive
increase in government revenue in recent
years, there have been few improvements
in the population’s living standards.
Disputes— international: in 2002, ICJ
ruled on an equidistance settlement of
Cameroon-Equatorial Guinea-Nigeria
maritime boundary in the Gulf of Guinea,
but a dispute between Equatorial Guinea
and Cameroon over an island at the mouth
of the Ntem River and imprecisely defined
maritime coordinates in the ICJ decision
delay final delimitation; UN urges Equa¬
torial Guinea and Gabon to resolve the
sovereignty dispute over Gabon-occupied','01c314ac42d08a59a82f38c73cf4d4dabe409e8129941ab1f42516734d33f501','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8b93382c2596833828616b4fe97632d063890353750158eaea60997a7dc5d8f',2010,'EE','Estonia','transnational-issues',612,'Disputes — international: Eritrea and
Ethiopia agreed to abide by 2002 Ethiopia-
Eritrea Boundary Commission’s (EEBC)
delimitation decision but, neither party
responded to the revised line detailed in
the November 2006 EEBC Demarcation
Statement; UN Peacekeeping Mission to
Ethiopia and Eritrea (UNMEE), which
has monitored the 25-km-wide Temporary
Security Zone in Eritrea since 2000, is
extended for six months in 2007 despite
Eritrean restrictions on its operations and
reduced force of 17,000; Sudan accuses
Eritrea of supporting eastern Sudanese
rebel groups
Refugees and internally displaced
persons: IDPs: 32,000 (border war with
Ethiopia from 1998-2000; most IDPs are
near the central border region) (2007)
Background: After centuries of Danish,
Swedish, German, and Russian rule,
Estonia attained independence in 1918.
Forcibly incorporated into the USSR in
1940— an action never recognized by the
US— it regained its freedom in 1991, with
the collapse of the Soviet Union. Since the
last Russian troops left in 1 994, Estonia has
been free to promote economic and political
ties with Western Europe. It joined both
NATO and the EU in the spring of 2004.','4a6885daf9e7f7a3a5e44681d4610844bc5fe78077a68f4095f55c044b385c70','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6f48312fc66c2e690b9dac21d8523283d0a1fc64352f988e7094e9da12583c6',2010,'ET','Ethiopia','transnational-issues',618,'Disputes— international: Russia recalled
its signature to the 1996 technical border
agreement with Estonia in 2005, rather
than concede to Estonia’s appending
prepared a unilateral declaration refer¬
encing Soviet occupation and territorial
losses; Russia demands better accommo¬
dation of Russian-speaking population in
Estonia; Estonian citizen groups continue
to press for realignment of the boundary
based on the 1920 Tartu Peace Treaty that
would bring the now divided ethnic Setu
people and parts of the Narva region within
Estonia; as a member state that forms part
of the EU’s external border, Estonia must
implement the strict Schengen border rules
with Russia
illicit drugs: growing producer of synthetic
drugs; increasingly important transship¬
ment zone for cannabis, cocaine, opiates,
and synthetic drugs since joining the Euro¬
pean Union and the Schengen Accord;
potential money laundering related to
organized crime and drug trafficking is a
concern, as is possible use of the gambling
sector to launder funds; major use of
opiates and ecstasy
surrender territory considered sensitive to
Ethiopia.
Disputes— international: Eritrea and
Ethiopia agreed to abide by the 2002
Eritrea-Ethiopia Boundary Commission’s
(EEBC) delimitation decision, but neither
party responded to the revised line detailed
in the November 2006 EEBC Demarca¬
tion Statement; UN Peacekeeping Mission
to Ethiopia and Eritrea (UNMEE), which
has monitored the 25-km-wide Temporary
Security Zone in Eritrea since 2000, is
extended for six months in 2007 despite
Eritrean restrictions on its operations and
reduced force of 17,000; the undemarcated
former British administrative line has
little meaning as a political separation to
rival clans within Ethiopia’s Ogaden and
southern Somalia’s Oromo region; Ethio¬
pian forces invaded southern Somalia and
routed Islamist Courts from Mogadishu in
January 2007; “Somaliland” secessionists
provide port facilities in Berbera and trade
ties to landlocked Ethiopia; civil unrest
in eastern Sudan has hampered efforts
to demarcate the porous boundary with
Refugees and internally displaced
persons: refugees ( country of origin): 66,980
(Sudan); 16,576 (Somalia); 13,078 (Eritrea)
IDPs: 200,000 (border war with Eritrea
from 1998-2000, ethnic clashes in
Gambela, and ongoing Ethiopian military
counterinsurgency in Somali region; most
IDPs are in Tigray and Gambela Provinces)
(2007)
Illicit drugs: transit hub for heroin origi¬
nating in Southwest and Southeast Asia
and destined for Europe, as well as cocaine
destined for markets in southern Africa;
cultivates qat (khat) for local use and
regional export, principally to Djibouti and
Somalia (legal in all three countries); the
lack of a well-developed financial system
limits the country’s utility as a money
laundering center
225
THE CIA WORLD FACTBOOK','2bf8a88ea9babe58d7ad04a74d37cb81de06adf5b9249b25fae3a959a14824e6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9101f43dbddbef9f74c3ad1685958d506169c0ec5d4ae70d0dc78f3fdb2ef9a',2010,'IT','Italy','transnational-issues',629,'Disputes— international: as a political
union, the EU has no border disputes
with neighboring countries, but Estonia
has no land boundary agreements with
Russia, Slovenia disputes its land and
maritime boundaries with Croatia, and
Spain has territorial and maritime disputes
with Morocco and with the UK over
Gibraltar; the EU has set up a Schengen
area— consisting of 22 EU member states
that have signed the convention imple¬
menting the Schengen agreements or
“acquis” (1985 and 1990) on the free
movement of persons and the harmoniza¬
tion of border controls in Europe; these
agreements became incorporated into EU
law with the implementation of the 1997
Treaty of Amsterdam on 1 May 1999;
in addition, non-EU states Iceland and
Norway (as part of the Nordic Union)
have been included in the Schengen area
since 1996 (full members in 2001), and
Switzerland since 2008 bringing the total
current membership to 25; the UK (since
2000) and Ireland (since 2002) take part
in only some aspects of the Schengen area,
especially with respect to police and crim¬
inal matters; nine of the 12 new member
states that joined the EU since 2004 joined
Schengen on 21 December 2007; of the
three remaining EU states, Cyprus is
expected to join by 2009, while Romania
and Bulgaria continue to enhance their
border security systems
229
FALKLAND ISLANDS (ISLAS MALVINAS)
Background: Although first sighted by an
English navigator in 1592, the first landing
(English) did not occur until almost a
century later in 1690, and the first settle-
ment (French) was not established until
1 764. The colony was turned over to Spain
two years later and the islands have since
been the subject of a territorial dispute, first
between Britain and Spain, then between
Britain and Argentina. The UK asserted its
claim to the islands by establishing a naval
garrison there in 1833. Argentina invaded
the islands on 2 April 1982. The British
responded with an expeditionary force that
landed seven weeks later and after fierce
fighting forced an Argentine surrender on
14 June 1982.
Disputes— international: Argentina,
which claims the islands in its constitu¬
tion and briefly occupied them by force
in 1982, agreed in 1995 to no longer seek
settlement by force; UK continues to reject
Argentine requests for sovereignty talks
231
THE CIA WORLD FACTBOOK
Disputes— international: Italy’s long
coasdine and developed economy entices
tens of thousands of illegal immigrants
from southeastern Europe and northern
Africa
Illicit drugs: important gateway for and
consumer of Latin American cocaine
and Southwest Asian heroin entering the
European market; money laundering by
organized crime and from smuggling
345
'' >''•>*
fit
Savanna-
ia-Ma?
/, Montego
Say''
Port
mmdK
SiiiS’ : /;
Sain? Ann’s*
Bav Oerto
Mm >
Kx .
Mand«vs?fe
.Black Rr
''
. K«eW , ,. E«Suiv«/ '' ^ -''
3»a?«?
Tow" A
^rt
W”
££ ,*/ KINGSTON
*™&- Mow*
Ba-4 Pcm^ , .
Pen %/%mm
Portmom
PM
S m «km
’mi , ,
■ y?
■ > ,. ./
AtW','0a5be06125ceedccb22da730ac618456caaf3d80fc4737fbd1048a8cad5bea4f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8efa231f9029b5ed95961325339ff9541e6397fe7961e54b8285cfec16742c54',2010,'FO','Faroe Islands','transnational-issues',630,'Stmymey
Fugiafjardti i#r* «Ki sfcstfk
wminaam
Boi yoy
Eysturoy
Vdgar
*T0«$HAYN
W0M
mowm
Smctoy
A! imi ic
V
Tyomyf!
8u»m
% m
Disputes— international: because antici¬
pated offshore hydrocarbon resources have
not been realized, earlier Faroese proposals
for full independence have been deferred;
Iceland, the UK, and Ireland dispute
Denmark’s claim that the Faroe Islands’
continental shelf extends beyond 200 nm','91e571ca05b3140a7f6011eb0b5ca092d4c45512c4ad771aa4dc30776a69cd10','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e26a55ccd66c1df1ca0d7f8fa899946c0721f50811e56a408008521f2e5fb43b',2010,'FJ','Fiji','transnational-issues',638,'1970, after nearly a century as a British
colony. Democratic rule was interrupted
by two military coups in 1987, caused
by concern over a government perceived
as dominated by the Indian community
(descendants of contract laborers brought
to the islands by the British in the 19th
century). The coups and a 1990 consti¬
tution that cemented native Melane¬
sian control of Fiji, led to heavy Indian
emigration; the population loss resulted
in economic difficulties, but ensured that
Melanesians became the majority. A new
constitution enacted in 1997 was more
equitable. Free and peaceful elections in
1999 resulted in a government led by an
Indo-Fijian, but a civilian-led coup in May
2000 ushered in a prolonged period of
political turmoil. Parliamentary elections
held in August 2001 provided Fiji with a
democratically elected government led by
Prime Minister Laisenia QARASE. Re¬
elected in May 2006, QARASE was ousted
in a December 2006 military coup led by
Commodore Voreqe BAINIMARAMA,
who initially appointed himself acting pres¬
ident, but in January 2007 became interim
prime minister. Since taking power, BAIN-
IMARAMA has neutralized his opponents,
crippled Fiji’s democratic institutions, and
refused to hold elections.','b57cdee177e1de95ecc79e0bc8f707cd99f8b004c893dc291287323de4829240','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1af95590bca573ffab331d96323b553ccd13dc41f6c9d7521ba3c442366d20d',2010,'FI','Finland','transnational-issues',647,'Disputes— international: none
Trafficking in persons: current situation: Fiji
is a source country for children trafficked for
the purpose of commercial sexual exploitation
invasions by the Soviet Union— albeit with
some loss of territory. In the subsequent
half century, the Finns made a remark¬
able transformation from a farm/forest
economy to a diversified modern industrial
economy; per capita income is now among
the highest in Western Europe. A member
of the European Union since 1995, Finland
was the only Nordic state to join the euro
system at its initiation in January 1999.','ae6477c6545e703c99ca4e0cebc9d62f638e466f1ceef2ab9eaaca109e948ac1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6770b476e27b8ba86ab76e80322c495234528edcee1fc1dbb2f690e3ea8d6baa',2010,'FR','France','transnational-issues',653,'Disputes— international: various groups
in Finland advocate restoration of Karelia
and other areas ceded to the Soviet Union,
but the Finnish Government asserts no
territorial demands
Disputes— international : none
that both sides had not followed through
on their commitments. Following Pales¬
tinian leader Yasir ARAFAT’s death in late
2004, Mahmud ABBAS was elected PA
president in January 2005. A month later,
Israel and die PA agreed to the Sharm el-
Sheikh Commitments in an effort to move
the peace process forward. In September
2005, Israel unilaterally withdrew all its
setders and soldiers and dismanded its
military facilities in the Gaza Strip and
withdrew settlers and redeployed soldiers
from four small northern West Bank
745
THE CIA WORLD FACTBOOK
settlements. Nonetheless, Israel controls
maritime, airspace, and most access to the
Gaza Strip. A November 2005 PA-Israeli
agreement authorized the reopening of
the Rafah border crossing between the
Gaza Strip and Egypt under joint PA and
Egyptian control. In January 2006, die
Islamic Resistance Movement, HAMAS,
won control of the Palestinian Legislative
Council (PLC). The international commu¬
nity refused to accept the HAMAS-led
government because it did not recognize
Israel, would not renounce violence, and
refused to honor previous peace agree¬
ments between Israel and the PA. HAMAS
took control of the PA government in
March 2006, but President ABBAS had
little success negotiating with HAMAS to
present a political platform acceptable to
the international community so as to lift
economic sanctions on Palestinians. The
PLC was unable to convene throughout
most of 2006 as a result of Israel’s deten¬
tion of many HAMAS PLC members and
Israeli-imposed travel restrictions on other
PLC members. Violent clashes took place
between Fatah and HAMAS supporters
in the Gaza Strip in 2006 and early 2007,
resulting in numerous Palestinian deaths
and injuries. ABBAS and HAMAS Polit¬
ical Bureau Chief MISHAL in February
2007 signed the Mecca Agreement in Saudi
Arabia that resulted in the formation of a
Palestinian National Unity Government
(NUG) headed by HAMAS member Ismail
HANIYA. However, fighting continued
in the Gaza Strip, and in June, HAMAS
militants succeeded in a violent takeover of
all military and governmental institutions
in the Gaza Strip. ABBAS dismissed the
NUG and through a series of presiden¬
tial decrees formed a PA government in
the West Bank led by independent Salam
FAYYAD. HAMAS rejected the NUG’s
dismissal and has called for resuming talks
with Fatah, but ABBAS has ruled out nego¬
tiations until HAMAS agrees to a return
of PA control over the Gaza Strip and
recognizes the FAYYAD-led government.
FAYYAD and his PA government initiated
a series of security and economic reforms
to improve conditions in the West Bank.
ABBAS participated in talks with Israel’s
Prime Minister OLMERT and secured
the release of some Palestinian prisoners
and previously withheld customs revenue.
During a November 2007 international
meeting in Annapolis Maryland, ABBAS
and OLMERT agreed to resume peace
negotiations with the goal of reaching a
final peace settlement.
Disputes— international: West Bank and
Gaza Strip are Israelioccupied with current
status subject to the Israeli-Palestinian
Interim Agreement— permanent status to
be determined through further negotiation;
Israel continues construction of a “seam
line” separation barrier along parts of the
Green Line and within the West Bank;
Israel withdrew from four settlements in
the northern West Bank in August 2005;
since 1948, about 350 peacekeepers from
the UN Truce Supervision Organization
(UNTSO), headquartered in Jerusalem,
monitor ceasefires, supervise armistice
agreements, prevent isolated incidents from
escalating, and assist other UN personnel
in the region
Refugees and internally displaced
persons: refugees (country of origin .):
722,000 (Palestinian Refugees (UNRWA))
(2007)','29405033be374a2e40eeee312f088bea6b7ecd3865b7baadca0ea6f5d43230bc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c5aa3a2988fa5cfc9093355c4b01eb93a1ebf02a101ffa98be2bc82aadcd00d',2010,'PF','French Polynesia','transnational-issues',659,'Disputes— international: Madagascar
claims the French territories of Bassas da
India, Europa Island, Glorioso Islands,
and Juan de Nova Island; Comoros claims
Mayotte; Mauritius claims Tromelin
Island; territorial dispute between Suri¬
name and the French overseas department
of French Guiana; France asserts a terri¬
torial claim in Antarctica (Adelie Land);
France and Vanuatu claim Matthew and
Hunter Islands, east of New Caledonia
Illicit drugs: metropolitan France: trans¬
shipment point for South American
cocaine, Southwest Asian heroin, and
European synthetics
French Guiana: small amount of marijuana
grown for local consumption; minor trans¬
shipment point to Europe
Martinique: transshipment point for
cocaine and marijuana bound for the US
and Europe
HHHW ®P8p
mmm
: . SO''Uft* me
ARCHSPEL
DES TVAMQ7V
o®#s
''
IW , 2“
rV&4?
Mtswmt. ''
a ago -sc.--
1 _
_ |
Disputes — international: none
FRENCH SOUTHERN AND ANTARCTIC LANDS
Disputes — international: French claim
to “Adelie Land” in Antarctica is not
recognized by the US
Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island files Eparses):
claimed by Madagascar
Tromelin Island files Eparses): claimed by','ffdbbb5bc11e55c5158cb9eedbe368d3148a2d770f856720491369302a357948','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a063924bcdccda0424d4144364c1964a95468116748d0272ebc0db38bc56613',2010,'MU','Mauritius','transnational-issues',665,'249
Disputes— international: Mauritanian
claims to Western Sahara remain dormant
Land use:
arable land: 49.02%
permanent crops: 2.94%
other: 48.04% (2005)
Irrigated land: 220 sq km (2003)
Total renewable water resources: 2.2 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.61 cu km/yr
(25%/14%/60%)
per capita: 488 cu m/yr (2000)
Natural hazards: cyclones (November to
April); almost completely surrounded by
reefs that may pose maritime hazards
Environment— current issues: water
pollution, degradation of coral reefs
Environment — international agreements:
party to: Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: the main island, from
which the country derives its name, is
of volcanic origin and is almost entirely
surrounded by coral reefs; home of the
dodo, a large flightless bird related to
pigeons, driven to extinction by the end of
the 1 7th century through a combination of
hunting and the introduction of predatory
species
Disputes — international: Mauritius claims
the Chagos Archipelago (UK-administered
British Indian Ocean Territory), and its
former inhabitants, who reside chiefly in','257d85cd068bfa53dceba15dabb3179d2b5f923dcfde5d0bd23b2d33592e93c3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('583d1d6387d008818ea35f09ae6e55bcf30115b13cde5f8053a3c631effd8e40',2010,'GA','Gabon','transnational-issues',671,'Disputes— international: UN urges Equa¬
torial Guinea and Gabon to resolve the
sovereignty dispute over Gabon-occupied
Mbane Island and lesser islands and to
establish a maritime boundary in hydro-
carbon-rich Corisco Bay
Refugees and internally displaced
persons: refugees (country of origin): 7,178
(Republic of Congo) (2007)
Trafficking in persons: current situation:
Gabon is predominandy a destination
252
country for children trafficked from
other African countries for the purpose
of forced labor; girls are primarily traf
ficked for domestic servitude, forced
market vending, forced restaurant labor,
and sexual exploitation, while boys
GAMBIA, THE
are trafficked for forced street hawking
and forced labor in small workshops
tier rating: Tier 2 Watch List— Gabon is on
the Tier 2 Watch List for its failure to provide
evidence of increasing efforts to combat
human trafficking in 2007, particularly in
terms of efforts to convict and punish traf-
ficking offenders; the government has not
repotted the convictions or sentences of
any trafficking offenders; the government
did not take steps to reduce demand for
commercial sex acts (2008)
GAMBIA, THE
Disputes— international: attempts to stem
refugees, cross-border raids, arms smuggling,
and other illegal activities by separatists from
southern Senegal’s Casamance region, as
well as from conflicts in other west African
states
Refugees and internally displaced
persons: refugees ( country of origin ): 5,955
(Sierra Leone) (2007)
Trafficking in persons: current situation:
The Gambia is a source, transit, and desti¬
nation country for children and women traf¬
ficked for the purposes of forced labor and
commercial sexual exploitation; women
and girls, and to a lesser extent boys, are
trafficked for sexual exploitation— in partic¬
ular to meet the demand for European sex
tourism— and for domestic servitude; boys
are trafficked within the country for forced
begging and street vending; Gambian
women and children may be trafficked
to Europe through trafficking schemes
disguised as migrant smuggling
tier rating: Tier 2 Watch List— for a second
consecutive year, The Gambia is on the
Tier 2 Watch List for its failure to provide
evidence of increasing efforts to eliminate
trafficking; The Gambia failed to report
any trafficking arrests, prosecutions, or
convictions in 2007, and the government
demonstrated weak victim protection
efforts during the reporting period (2008)
255
THE CIA WORLD FACTBOOK
Background: The September 1993
Israel-PLO Declaration of Principles on
Interim Self-Government Arrangements
provided for a transitional period of
Palestinian self-rule in the West Bank and
Gaza Strip. Under a series of agreements
signed between May 1994 and September
1999, Israel transferred to the Palestinian
Authority (PA) security and civilian respon¬
sibility for Palestinian-populated areas of
the West Bank and Gaza. Negotiations
to determine the permanent status of the
West Bank and Gaza stalled following the
outbreak of an intifada in September 2000,
as Israeli forces reoccupied most Palestinian-
controlled areas. In April 2003, the Quartet
(US, EU, UN, and Russia) presented a
roadmap to a final settlement of the conflict
by 2005 based on reciprocal steps by the
two parties leading to two states, Israel and a
democratic Palestine. The proposed date for a
permanent status agreement was postponed
indefinitely due to violence and accusations
that both sides had not followed through on
their commitments. Following Palestinian
leader Yasir ARAFAT’s death in late 2004,
Mahmud ABBAS was elected PA president
in January 2005. A month later, Israel
and the PA agreed to the Sharm el-Sheikh
Commitments in an effort to move the peace
process forward. In September 2005, Israel
unilaterally withdrew all its setders and
soldiers and dismanded its military facili¬
ties in the Gaza Strip and withdrew setders
and redeployed soldiers from four small
northern West Bank setdements. Nonethe¬
less, Israel controls maritime, airspace, and
most access to the Gaza Strip. A November
2005 PA-Israeli agreement authorized the
reopening of the Rafah border crossing
between the Gaza Strip and Egypt under
joint PA and Egyptian control. In January
GAZA STRIP
2006, the Islamic Resistance Movement,
HAMAS, won control of the Palestinian
Legislative Council (PLC). The international
community refused to accept the HAMAS
led government because it did not recognize
Israel, would not renounce violence, and
refused to honor previous peace agree¬
ments between Israel and the PA. HAMAS
took control of the PA government in
March 2006, but President ABBAS had
little success negotiating with HAMAS to
present a political platform acceptable to
the international community so as to lift
economic sanctions on Palestinians. The
PLC was unable to convene throughout
most of 2006 as a result of Israel’s deten¬
tion of many HAMAS PLC members and
Israeli-imposed travel restrictions on other
PLC members. Violent clashes took place
between Fatah and FIAMAS supporters
in the Gaza Strip in 2006 and early 2007,
resulting in numerous Palestinian deaths
and injuries. ABBAS and HAMAS Polit¬
ical Bureau Chief MISHAL in February
2007 signed the Mecca Agreement in Saudi
Arabia that resulted in the formation of a
Palestinian National Unity Government
(NUG) headed by HAMAS member Ismail
HANIYA. However, fighting continued
in the Gaza Strip, and in June, HAMAS
militants succeeded in a violent takeover of
all military and governmental institutions
in the Gaza Strip. ABBAS dismissed the
NUG and through a series of Presidential
decrees formed a PA government in the
West Bank led by independent Salam
FAYYAD. HAMAS rejected the NUG’s
dismissal and has called for resuming talks
with Fatah, but ABBAS has ruled out nego¬
tiations until HAMAS agrees to a return
of PA control over the Gaza Strip and
recognizes the FAYYAD-led government.
FAYYAD and his PA government initiated
a series of security and economic reforms
to improve conditions in the West Bank.
ABBAS participated in talks with Israel’s
Prime Minister OLMERT and secured
the release of some Palestinian prisoners
and previously withheld customs revenue.
During a November 2007 international
meeting in Annapolis Maryland, ABBAS
and OLMERT agreed to resume peace
negotiations with the goal of reaching a final
peace settlement.
Disputes — international: West Bank and
Gaza Strip are Israeli-occupied with current
status subject to the Israeli-Palestinian
Interim Agreement— permanent status
to be determined through further nego¬
tiation; Israel removed settlers and military
personnel from the Gaza Strip in August
2005
Refugees and internally displaced
persons: refugees ( country of origin): 1.017
million (Palestinian Refugees (UNRWA))
(2007)
v','1c9f85c8139b19ede5e07d166cfc90bf557bacf7120284841cb1dc7c014d02ab','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('273c2726b1d62ede3d52732aac5d5602724046feadb5979d2d7fc80cffb15dd6',2010,'GE','Georgia','transnational-issues',679,'Disputes— international: Russia and
Georgia agree on delimiting 80% of their
common border, leaving certain small, stra¬
tegic segments and the maritime boundary
unresolved; OSCE observers monitor
volatile areas such as the Pankisi Gorge in
the Akhmeti region and the Argun Gorge
in Abkhazia; UN Observer Mission in
Georgia has maintained a peacekeeping
force in Georgia since 1993; Meshkheti
Turks scattered throughout the former
Soviet Union seek to return to Georgia;
boundary with Armenia remains undemar-
cated; ethnic Armenian groups in Javakheti
region of Georgia seek greater autonomy
from the Georgian government; Azerbaijan
and Georgia continue to discuss the align¬
ment of their boundary at certain crossing
areas
Refugees and internally displaced
persons:
refugees (country of origin): 1,100 (Russia)
IDPs: 220,000-240,000 (displaced from
Abkhazia and South Ossetia) (2007)
Illicit drugs: limited cultivation of cannabis
and opium poppy, mostly for domestic
consumption; used as transshipment point
for opiates via Central Asia to Western
Europe and Russia
261
THE CIA WORLD FACTBOOK','4a97c5f3034a1262f9a8da38791d8eaf8ceb87737d3868f4a33e2bb82b5a25f1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f82bff01bb81c92f4148e123a3f3feee5f4d5b3efbbef9c2fa88691981b4f9c',2010,'GH','Ghana','transnational-issues',687,'Disputes— international: none
Illicit drugs: source of precursor chemicals
for South American cocaine processors;
transshipment point for and consumer of
Southwest Asian heroin, Latin American
cocaine, and European-produced synthetic
drugs; major financial center
Disputes— international: Ghana strug¬
gles to accommodate returning nationals
who worked in the cocoa plantations and
escaped fighting in Cote d’Ivoire
Refugees and internally displaced
persons: refugees (country of origin): 35,653
(Liberia); 8,517 (Togo) (2007)
Illicit drugs: illicit producer of cannabis
for the international drug trade; major
transit hub for Southwest and Southeast
Asian heroin and, to a lesser extent, South
American cocaine destined for Europe
and the US; widespread crime and money
laundering problem, but the lack of a well
developed financial infrastructure limits
the country’s utility as a money laundering
center; significant domestic cocaine and
cannabis use','3ab866c1757f91139eb4a9c9fd1032825e9006faa37bc2f47d1f79a483535e7c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adda640049d0f7d9ef152e697665b9141ba03bfc2d0ff31e583624e25d4eaa0d',2010,'GR','Greece','transnational-issues',701,'Disputes— international: in 2002,
Gibraltar residents voted overwhelmingly
Area— comparative: slightly smaller than
Alabama
Land boundaries: total: 1,228 km
border countries: Albania 282 km, Bulgaria
494 km, Turkey 206 km, Macedonia
246 km
Coastline: 13,676 km
Maritime Claims: territorial sea: 12 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: temperate; mild, wet winters; hot,
dry summers
Terrain: mostly mountains with ranges
extending into the sea as peninsulas or
chains of islands
Elevation extremes: lowest point: Mediter¬
ranean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: lignite, petroleum, iron
ore, bauxite, lead, zinc, nickel, magnesite,
marble, salt, hydropower potential
Land use: arable land: 20.45%
permanent crops: 8.59%
other: 70.96% (2005)
Irrigated land: 14,530 sq km (2003)
Total renewable water resources: 72 cu
km (2005)
Freshwater withdrawal (domestic/
industriai/agricuitural): total: 8.7 cu
km/yr (16%/3%/81%)
per capita: 782 cu m/yr (1997)
Natural hazards:
severe earthquakes
Environment — current issues: air pollu¬
tion; water pollution
Environment — international agreements:
party to : Air Pollution , Air Pollution-N itrogen
Oxides, Air Pollution-Sulfur 94, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air Pollution-
Volatile Organic Compounds
by referendum to reject any “shared
sovereignty” arrangement; the government
of Gibraltar insists on equal participation
in talks between the UK and Spain; Spain
disapproves of UK plans to grant Gibraltar
even greater autonomy
Geography — note: strategic location
dominating the Aegean Sea and southern
approach to Turkish Straits; a peninsular
country, possessing an archipelago of
about 2,000 islands
Disputes— international: Greece and
Turkey continue discussions to resolve
their complex maritime, air, territorial,
and boundary disputes in the Aegean
Sea; Cyprus question with Turkey; Greece
rejects the use of the name Macedonia or
Republic of Macedonia; the mass migra-
tion of unemployed Albanians still remains
a problem for developed countries, chiefly
Greece and Italy
Illicit drugs: a gateway to Europe for traf¬
fickers smuggling cannabis and heroin
from the Middle East and Southwest Asia
to the West and precursor chemicals to
the East; some South American cocaine
transits or is consumed in Greece; money
laundering related to drug trafficking and
organized crime
Disputes — international: none
Illicit drugs: transshipment point for drugs
going into mainland China; consumer of
opiates and amphetamines
Area: total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area — comparative: slighdy larger than
Vermont
Land boundaries: total: 766 km
border countries: Albania 151 km, Bulgaria
148 km, Greece 246 km, Kosovo 159 km,
Serbia 62 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: warm, dry summers and
autumns; relatively cold winters with heavy
snowfall
Terrain: mountainous territory covered
with deep basins and valleys; three large
lakes, each divided by a frontier line;
country bisected by the Vardar River
Elevation extremes: lowest point: Vardar
River 50 m
highest point: Golem Korab (Maja e Korabit)
2,764 m
Natural resources: low-grade iron ore,
copper, lead, zinc, chromite, manganese,
nickel, tungsten, gold, silver, asbestos,
gypsum, timber, arable land
415
THE CIA WORLD FACTBOOK
Land US6: arable land: 22.01%
permanent crops: 1.79%
other: 76.2% (2005)
Irrigated land: 550 sq km (2003)
Total renewable water resources: 6.4 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 2.27
per capita: 1,118 cu m/yr (2000)
Natural hazards: high seismic risks
Environment — current issues: air pollu¬
tion from metallurgical plants
Environment— international agree¬
ments: party to: Air Pollution, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; major
transportation corridor from Western
and Central Europe to Aegean Sea and
Southern Europe to Western Europe','833994fa1538545cc6028d7a7852284f2dcf61ae9cff2ba1046be31fadc5f3d8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bb4bd2ad631e98464ba8b43c11500f52a1281bb54cebc10a72618cede224071',2010,'GL','Greenland','transnational-issues',714,'Disputes— international: managed
dispute between Canada and Denmark
over Hans Island in the Kennedy Channel
between Canada’s Ellesmere Island and
276','0b6b1e9f0e342d2ff8b03187d6c465b03b14434848daa7c498c86442783fac35','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09d21e65d309c908e04621f215798f4d7a5b746ffa5c2564fad7bf735de24845',2010,'GD','Grenada','transnational-issues',715,'Background: Carib Indians inhabited
Grenada when COLUMBUS discovered
the island in 1498, but it remained uncok>
nized for more than a century. The French
settled Grenada in the 17th century, estab-
lished sugar estates, and imported large
numbers of African slaves. Britain took the
island in 1762 and vigorously expanded
sugar production. In the 19th century,
cacao eventually surpassed sugar as the
main export crop; in the 20th century,
nutmeg became the leading export. In
1967, Britain gave Grenada autonomy over
its internal affairs. Full independence was
attained in 1974, making Grenada one of
the smallest independent countries in the
Western Flemisphere. Grenada was seized
by a Marxist military council on 1 9 October
1983. Six days later the island was invaded
by US forces and those of six other Carib-
bean nations, which quickly captured the
ringleaders and their hundreds of Cuban
advisers. Free elections were reinstituted
the following year and have continued
since that time. Flurricane Ivan struck
Grenada in September of 2004 causing
severe damage.','412269d7274069caa67b36ea7e979bfe263d4cd402a9106f80730cb5b2036204','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47972d72df18e8843c24202a6b9e1fd70dc2d4513f17ae64f0c1226973caa917',2010,'GU','Guam','transnational-issues',724,'Disputes — international: none
Illicit drugs: small-scale cannabis cultiva¬
tion; lesser transshipment point for mari¬
juana and cocaine to US
GWP
Hazardous Wastes
HF
HIV/AIDS
IADB
IAEA
IANA
IBRD
ICAO
ICC
ICCt
ICJ
ICRC
ICRM
ICSID
ICTR
ICTY
IDA
IDB
IDP
IEA
IFAD
IFC
IFRCS
IGAD
IHO
ILO
IMF
IMO
IMSO
Inmarsat
InOC
INSTRAW
Intelsat
Interpol
Intersputnik
IOC
IOM
IPU
ISO
ISP
ITSO
ITU
ITUC
Group of 9
Group of 10
Group of 1 5
Group of 1 1
Group of 24
Group of 77
General Agreement on Tariffs and Trade; now WTO
Gulf Cooperation Council
General Confederation of Trade Unions
gross domestic product
Greenwich Mean Time
gross national product
gross register ton
global system for mobile cellular communications
Organization for Democracy and Economic Development; acronym for member states - Georgia,
Ukraine, Azerbaijan, Moldova
gross world product
Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and
Their Disposal
high-frequency
human immunodeficiency virus/acquired immune deficiency syndrome
Inter-American Development Bank
International Atomic Energy Agency
Internet Assigned Numbers Authority
International Bank for Reconstruction and Development (World Bank)
International Civil Aviation Organization
International Chamber of Commerce
International Criminal Court
International Court of Justice (World Court)
International Committee of the Red Cross
International Red Cross and Red Crescent Movement
International Center for Secretariat of Investment Disputes
International Criminal Tribunal for Rwanda
International Criminal Tribunal for the former Yugoslavia
International Development Association
Islamic Development Bank
Internally Displaced Person
International Energy Agency
International Fund for Agricultural Development
International Finance Corporation
International Federation of Red Cross and Red Crescent Societies
Inter-Governmental Authority on Development
International Hydrographic Organization
International Labor Organization
International Monetary Fund
International Maritime Organization
International Mobile Satellite Organization
International Maritime Satellite Organization
Indian Ocean Commission
International Research and Training Institute for the Advancement of Women
International Telecommunications Satellite Organization
International Criminal Police Organization
International Organization of Space Communications
International Olympic Committee
International Organization for Migration
Inter-parliamentary Union
International Organization for Standardization
Internet Service Provider
International Telecommunications Satellites Organization
International Telecommunication Union
International Trade Union Confederation, the successor to ICFTU (International Confederation
of Free Trade Unions) and the WCL (World Confederation of Labor)
767
THE CIA WORLD FACTBOOK
kHz
km
kW
kWh
LAES
LAIA
LAS
Law of the Sea
LDC
LLDC
London Convention
LOS
m
Marecs
Marine Dumping
Marine Life Conservation
MARPOL
Medarabtel
Mercosur
MHz
MICAH
MINURSO
MIGA
MINUSTAH
MONUC
NA
NAFTA
NAM
NATO
NC
NEA
NEGL
NGA
NIB
NIC
NIE
NIS
nm
NMT
NSG
Nuclear Test Ban
NZ
OAPEC
OAS
OAU
ODA
OECD
OECS
OHCHR
OIC
OIF
ONUB
OOF
OPANAL
OPCW
OPEC
OSCE
Ozone Layer Protection
PCA
PFP
PIF
768
kilohertz
kilometer
kilowatt
kilowatt-hour
Latin American Economic System
Latin American Integration Association
League of Arab States
United Nations Convention on the Law of the Sea (LOS)
less developed country
least developed country
see Marine Dumping
see Law of the Sea
meter s. v
Maritime European Communications Satellite
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter
Convention on Fishing and Conservation of Living Resources of the High Seas
see Ship Pollution
Middle East Telecommunications Project of the International Telecommunications Union
Southern Cone Common Market
megahertz
International Civilian Support Mission in Haiti
United Nations Mission for the Referendum in Western Sahara
Multilateral Investment Geographic Agency
United Nations Stabilization Mission in Haiti
United Nations Organization Mission in the Democratic Republic of the Congo
not available
North American Free Trade Agreement
Nonaligned Movement
North Adantic Treaty Organization
Nordic Council
Nuclear Energy Agency
negligible
National Geospatial-Intelligence Agency
Nordic Investment Bank
newly industrializing country
newly industrializing economy
new independent states
nautical mile
Nordic Mobile Telephone
Nuclear Suppliers Group
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under
Water','0526568889f1d51569bcd4fd2d31f08576c110d24c4a628dd4dd055d6cf0b2e4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfa277e5698312c852a0b020c9f58084be3e4c4f71b76915ad74bb23cc87aaef',2010,'GT','Guatemala','transnational-issues',732,'Disputes — international: none
Background: The Mayan civilization
flourished in Guatemala and surrounding
regions during the first millennium A.D.
After almost three centuries as a Spanish
colony, Guatemala won its independ¬
ence in 1821. During the second half of
the 20th century, it experienced a variety
of military and civilian governments, as
well as a 36-year guerrilla war. In 1996,
the government signed a peace agreement
formally ending the conflict, which had left
more than 100,000 people dead and had
created, by some estimates, some 1 million
refugees.
Disputes — international: annual minis¬
terial meetings under the OAS-initiated
Agreement on the Framework for Negotia¬
tions and Confidence Building Measures
cohtinue to address Guatemalan land and
maritime claims in Belize and the Carib¬
bean Sea; the Line of Adjacency created
under the 2002 Differendum serves in lieu
of the contiguous international boundary
to control squatting in the sparsely inhab¬
ited rain forests of Belize’s border region;
Mexico must deal with thousands of
impoverished Guatemalans and other
Central Americans who cross the porous
border looking for work in Mexico and the','e90bfdb14ee09b95f67190953ced3dc42633237d6a8a3c100fe5fce42a479244','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f94b5f9c9a52dbc3eff1b2a05a3866298c345822b74b5a2032e57082c10032fa',2010,'GG','Guernsey','transnational-issues',736,'Illicit drugs: major transit country for
cocaine and heroin; in 2005, cultivated 100
hectares of opium poppy after reemerging
as a potential source of opium in 2004;
potential production of less than 1 metric
ton of pure heroin; marijuana cultiva¬
tion for mosdy domestic consumption;
proximity to Mexico makes Guatemala a
major staging area for drugs (particularly
for cocaine); money laundering is a serious
problem; corruption is a major problem
« *,5 5 Iro
9 S
Baftim
St Anne*
Alderney
« St Sampson
mm! mm.
ST. PETER: Mteu
PORT Bmchau
Sark
UMeSiWk .
Disputes— international: none','2666838992eaa3ee7ae1d4bdc90452335ea997054bb2f9761802097263dc5ab0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5eb58bd1ab0f3cbe9f5d59690c0d6ab3233a99aee822d5d1eb8be6548312a7c1',2010,'GN','Guinea','transnational-issues',749,'Disputes — international: conflicts among
rebel groups, warlords, and youth gangs in
neighboring states have spilled over into
Guinea, resulting in domestic instability;
Sierra Leone considers Guinea’s definition
of the flood plain limits to define the left
bank boundary of the Makona and Moa
rivers excessive and protests Guinea’s
continued occupation of these lands,
including the hamlet of Yenga, occupied
since 1998
Refugees and internally displaced
persons: refugees ( country of origin): 21,856
(Liberia); 5,259 (Sierra Leone); 3,900 (Cote
d’Ivoire)
IDPs: 19,000 (cross-border incursions
from Cote d’Ivoire, Liberia, Sierra Leone)
(2007)
Trafficking in persons: current situation:
Guinea is a source, transit, and destina¬
tion country for men, women, and chil¬
dren trafficked for the purposes of forced
labor and sexual exploitation; the majority
of victims are children, and internal traf¬
ficking is more prevalent than transna¬
tional trafficking; within the country, girls
are trafficked primarily for domestic servi¬
tude and sexual exploitation, while boys
are trafficked for forced agricultural labor,
and as forced beggars, street vendors, shoe
shiners, and laborers in gold and diamond
mines; some Guinean men are also traf¬
ficked for agricultural labor within Guinea;
transnationally, girls are trafficked into
Guinea for domestic servitude and likely
also for sexual exploitation
tier rating: Tier 2 Watch List— Guinea is
on the Tier 2 Watch List for its failure to
provide evidence of increasing efforts to
eliminate trafficking over 2006; Guinea
demonstrated minimal law enforcement
efforts for a second year in a row, while
protection efforts diminished over efforts
in 2006; die government did not report
any trafficking convictions in 2007; due to
a lack of resources, the government does
not provide shelter services for trafficking
victims; the government took no meas¬
ures to reduce the demand for commercial
sexual exploitation (2008)
289
THE CIA WORLD FACTBOOK','15d607853e8f1e20d928c0c9c851d824fc7faaca1567a6fc7f629335e7b899b3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d120e9104c1c5e04209bb4c450c20e94fd80d381788760a379b04386350baaa6',2010,'GW','Guinea-Bissau','transnational-issues',750,'Background: Since independence from
Portugal in 1974, Guinea-Bissau has expe¬
rienced considerable political and military
upheaval. In 1980, a military coup estab¬
lished authoritarian dictator Joao Bernardo
“Nino” VIEIRA as president. Despite
setting a path to a market economy and
multiparty system, VIEIRA’ s regime was
characterized by the suppression of polit¬
ical opposition and the purging of political
rivals. Several coup attempts through the
1980s and early 1990s failed to unseat
him. In 1994 VIEIRA was elected presi¬
dent in the country’s first free elections.
A military mutiny and resulting civil war
in 1998 eventually led to VIEIRA’s ouster
in May 1999. In February 2000, a tran¬
sitional government turned over power
to opposition leader Kumba YALA, after
he was elected president in transparent
polling. In September 2003, after only
three years in office, YALA was ousted
by the military in a bloodless coup, and
businessman Henrique ROSA was sworn
in as interim president. In 2005, former
President VIEIRA was re-elected president
pledging to pursue economic development
and national reconciliation. He was assas¬
sinated in March 2009; new elections are
to take place in June 2009.
Disputes— international: in 2006, polit¬
ical instability within Senegal’s Casamance
region resulted in thousands of Senegalese
refugees, cross-border raids, and arms
smuggling into Guinea-Bissau
Refugees and internally displaced
persons: refugees (country of origin): 7,454
(Senegal) (2007)
Trafficking in persons: current situation:
Guinea-Bissau is a source country for chil¬
dren trafficked primarily for forced begging
and forced agricultural labor to other West
African countries
292','617ffe1dfd5b3b9bf5f184259c85b6d912a61694114da2e0687e185ad42a7a3c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a0c793102c70b5cf467ef6bab9954b357a640d346e353203c97e712f98fbd44',2010,'GY','Guyana','transnational-issues',758,'tier rating: Tier 2 Watch List— for the second
year in a row, Guinea-Bissau is on the
Tier 2 Watch List for its failure to combat
severe forms of trafficking in persons, as
evidenced by the continued failure to pass
an anti-trafficking law and inadequate
efforts to investigate or prosecute trafficking
crimes or convict and punish trafficking
offenders (2008)
Illicit drugs: increasingly important transit
country for South American cocaine
enroute to Europe; enabling environ¬
ment for trafficker operations thanks to
pervasive corruption; archipelago-like geog¬
raphy around the capital facilitates drug
smuggling
Background: Originally a Dutch colony
in the 17 th century, by 1815 Guyana had
become a British possession. The abolition
of slavery led to black settlement of urban
areas and the importation of indentured
servants from India to work the sugar
plantations. This ethnocultural divide has
persisted and has led to turbulent politics.
Guyana achieved independence from the
UK in 1966, and since then it has been
ruled mostly by socialist-oriented govern¬
ments. In 1992, Cheddi JAGAN was
elected president in what is considered
the country’s first free and fair election
since independence. After his death five
years later, his wife, Janet JAGAN, became
president but resigned in 1 999 due to poor
health. Her successor, Bharrat JAGDEO,
was reelected in 2001 and again in 2006.
Disputes — international: all of the area
west of the Essequibo River is claimed by
Venezuela preventing any discussion of a
maritime boundary; Guyana has expressed
its intention to join Barbados in asserting
claims before UNCLOS that Trinidad
and Tobago’s maritime boundary with
Venezuela extends into their waters; Suri-
name claims a triangle of land between
the New and Kutari/Koetari rivers in a
historic dispute over the headwaters of
the Courantyne; Guyana seeks arbitra¬
tion under provisions of the UN Conven¬
tion on the Law of the Sea (UNCLOS)
to resolve the long-standing dispute with
Suriname over the axis of the territorial sea
boundary in potentially oil-rich waters
Trafficking in persons: current situation:
Guyana is a source, transit, and desti¬
nation country for men, women, and
children trafficked for the purposes of
commercial sexual exploitation and forced
labor; most trafficking appears to take place
in remote mining camps in the country’s
interior; some women and girls are traf¬
ficked from northern Brazil; reporting
from other nations suggests Guyanese
women and girls are trafficked for sexual
exploitation to neighboring countries
and Guyanese men and boys are subject
to labor exploitation in construction
and agriculture; trafficking victims from
Suriname, Brazil, and Venezuela transit
Guyana en route to Caribbean destinations
tier rating: Tier 2 Watch List— for a second
consecutive year, Guyana is on the Tier 2
Watch List for failing to provide evidence
of increasing efforts to combat trafficking,
particularly in the area of law enforcement
actions against trafficking offenders; the
government has yet to produce an anti-traf¬
ficking conviction under the comprehen¬
sive Combating of Trafficking in Persons
Act, which became law in 2005; the govern¬
ment operates no shelters for trafficking
victims, but did include limited funding for
anti-trafficking NGOs in its 2008 budget;
the government did not make any effort
to reduce demand for commercial sex acts
during 2007 (2008)
Illicit drugs: transshipment point for
narcotics from South America— prima¬
rily Venezuela— to Europe and the US;
producer of cannabis; rising money laun¬
dering related to drug trafficking and
human smuggling
296','6e3e2af209bfd3b7505128625b44be69bcc9c63aafdd1a08c16b2ec63c82e9a9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2e39f61d550c9c2ede3d37e3977cac67729f0239bb412b343c4926a7f23b2f7',2010,'HT','Haiti','transnational-issues',771,'Disputes — international: since 2004,
about 8,000 peacekeepers from the
UN Stabilization Mission in Haiti
(MINUSTAH) maintain civil order in
Haiti; despite efforts to control illegal
migration, Haitians cross into the Domin¬
ican Republic and sail to neighboring
countries; Haiti claims US-administered
Navassa Island
Illicit drugs: Caribbean transshipment
point for cocaine en route to the US and
Europe; substantial bulk cash smuggling
activity; Colombian narcotics traffickers
favor Haiti for illicit financial transactions;
pervasive corruption; significant consumer
of cannabis
'' " , Of " . - •''
"■ '' ''Jg" v;0
'' -','bf58b799f14185e86f64fcaa91ec21357e004bd80cb98ee946dcc8a9749eb913','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab27ce71f1c673e0dd1abad9fc0c9165fa29f2ceaa89e174e53b7307b52a0725',2010,'HM','Heard Island and McDonald Islands','transnational-issues',772,'Background: These uninhabited, barren,
sub-Antarctic islands were transferred from
the UK to Australia in 1947. Populated
by large numbers of seal and bird species,
the islands have been designated a nature
preserve.
Location: islands in the Indian Ocean,
about two-thirds of the way from
Madagascar to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area: total: 412 sq km
land: 412 sq km
water: 0 sq km
Area— comparative: slightly more than
two times the size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime Claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: antarctic
Terrain: Heard Island— 80% ice-covered,
bleak and mountainous, dominated by a
large massif (Big Ben) and an active volcano
(Mawson Peak); McDonald Islands— small
and rocky
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Mawson Peak, on Big Ben
2,745 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: Mawson Peak, an active
volcano, is on Heard Island
Environment— current issues: NA
Geography — note: Mawson Peak on Heard
Island is the highest Australian mountain (at
2,745 meters, it is taller than Mt. Kosciuszko
in Australia proper), and one of only two
active volcanoes located in Australian terri¬
tory, the other being McDonald Island; in
1992, McDonald Island broke its dormancy
and began erupting; it has erupted several
times since, the most recent being in 2005
Economy — overview: The islands have
no indigenous economic activity, but the
Australian Government allows limited
fishing in the surrounding waters.
Disputes— international: none','652321ac05d9a264a654e9d69a8fa8138cf094880626340663ff515f4d4213b8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb782e8ffc8f3419d3e408505e4cc551610d2f3075720ca76f4ee0ca150c709f',2010,'HN','Honduras','transnational-issues',786,'Disputes— international: International
Court of Justice (ICJ) ruled on the delimi¬
tation of “bolsones” (disputed areas) along
the El Salvador-Honduras border in 1992
with final settlement by the parties in 2006
after an Organization of American States
(OAS) survey and a further ICJ ruling in
2003; the 1992 ICJ ruling advised a tripar¬
tite resolution to a maritime boundary in
the Gulf of Fonseca with consideration of
Honduran access to the Pacific; El Salvador
continues to claim tiny Conejo Island, not
mentioned in the ICJ ruling, off Honduras
in the Gulf of Fonseca; Honduras
claims the Belizean-administered Sapodilla
Cays off the coast of Belize in its constitu¬
tion, but agreed to a joint ecological park
around the cays should Guatemala consent
to a maritime corridor in the Caribbean
under the OAS-sponsored 2002 Belize-
Guatemala Differendum; memorials and
countermemorials were filed by the parties
in Nicaragua’s 1999 and 2001 proceed¬
ings against Honduras and Colombia at
the ICJ over the maritime boundary and
territorial claims in the western Caribbean
Sea— final public hearings are scheduled
for 2007
Illicit drugs: transshipment point for drugs
and narcotics; illicit producer of cannabis,
cultivated on small plots and used princi¬
pally for local consumption; corruption is
a major problem; some money-laundering
activity
305
THE CIA WORLD FACTBOOK','c3444de1320cb1cf47829b03e7f003e522f912111d9bd1717fa9505c67f7aa19','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e702a1af959a2d1a434a0b6ff9605be99fca52ea320940a0cc4cd375a9108c',2010,'HK','Hong Kong','transnational-issues',787,'Background: Occupied by die UK in
1841, Hong Kong was formally ceded by
China the following year; various adja¬
cent lands were added later in the 19th
century. Pursuant to an agreement signed
by China and the UK on 19 December
1984, Hong Kong became the Hong Kong
Special Administrative Region (SAR) of
the People’s Republic of China on 1 July
1997. In this agreement, China promised
that, under its “one country, two systems”
formula, China’s socialist economic system
would not be imposed on Hong Kong and
that Hong Kong would enjoy a high degree
of autonomy in all matters except foreign
and defense affairs for the next 50 years.
Disputes— international: none
Illicit drugs: despite strenuous law enforce¬
ment efforts, faces difficult challenges in
controlling transit of heroin and metham-
phetamine to regional and world markets;
modem banking system provides conduit
for money laundering; rising indigenous
use of synthetic drugs, especially among
young people
308','f589412a59bb4c812c853d8a84b63c0437057a88dd8c59ea81e20815d7ac571d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90db073ee3d739818dd014021802ecb686f12365c1c2184076f4fecef8e27bf5',2010,'HU','Hungary','transnational-issues',803,'Disputes— international: bilateral govern¬
ment, legal, technical and economic
working group negotiations continue in
2006 with Slovakia over Hungary’s failure
to complete its portion of the Gabcikovo-
Nagymaros hydroelectric dam project along
the Danube; as a member state that forms
part of the EU’s external border, Hungary
has implemented the strict Schengen
border rules
Illicit drugs: transshipment point for
Southwest Asian heroin and cannabis
and for South American cocaine destined
for Western Europe; limited producer
of precursor chemicals, particularly for
amphetamine and methamphetamine;
efforts to counter money laundering,
related to organized crime and drug traf¬
ficking, are improving, but remain vulner¬
able; significant consumer of ecstasy
312','1b1e75f1a35499de37bd56d6cef74bf26f0c2de7c665edc76fff8cc245821adc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9901199d3fbe3b5197cd9e2a7f93c5977ed520aafc874de4f03c36a3b2d57d5d',2010,'IS','Iceland','transnational-issues',804,'Background: Settled by Norwegian and
Celtic (Scottish and Irish) immigrants
during the late 9th and 10th centuries
A.D., Iceland boasts the world’s oldest
functioning legislative assembly, the
Althing, established in 930. Independent
for over 300 years, Iceland was subse-
quendy ruled by Norway and Denmark.
Fallout from the Askja volcano of 1875
devastated the Icelandic economy and
caused widespread famine. (Over the next
quarter century, 20% of the island’s popu¬
lation emigrated, mostly to Canada and the
US. Limited home rule from Denmark was
granted in 1874 and complete independ¬
ence attained in 1944. Literacy, longevity,
and social cohesion are first-rate by world
standards.
Disputes — international: Iceland, the
UK, and Ireland dispute Denmark’s claim
that the Faroe Islands’ continental shelf
extends beyond 200 nm','c307479452ad1e747613aa748aea18af5a91131bf36f5d42dd96b9fb965eda50','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83154fa2a03ce9cb6608d8fbc87a3b2d19a623a1e41ff6515d1e2fdbcfebaf0e',2010,'IN','India','transnational-issues',812,'Background: Aryan tribes from the north¬
west infiltrated onto the Indian subconti¬
nent about 1500 B.C.; their merger with
the earlier Dravidian inhabitants created
the classical Indian culture. The Maurya
Empire of the 4th and 3rd centuries B.C.—
which reached its zenith under ASHOKA—
united much of South Asia. The Golden
Age ushered in by the Gupta dynasty (4th
to 6th centuries A.D.) saw a flowering
of Indian science, art, and culture. Arab
incursions starting in the 8th century and
Turkic in the 12th were followed by those
of European traders, beginning in the late
1 5th century. By the 1 9th century, Britain
had assumed political control of virtually
all Indian lands. Indian armed forces
in the British army played a vital role in
both World Wars. Nonviolent resistance
to British colonialism led by Mohandas
GANDHI and Jawaharlal NEHRU brought
independence in 1947. The subcontinent
was divided into the secular state of India
and the smaller Muslim state of Pakistan.
A third war between the two countries in
1971 resulted in East Pakistan becoming
the separate nation of Bangladesh. India’s
nuclear weapons testing in 1998 caused
Pakistan to conduct its own tests that same
year. Despite impressive gains in economic
investment and output, India faces pressing
problems such as significant overpopula¬
tion, environmental degradation, extensive
poverty, and widespread corruption.
Disputes— international: since China and
India launched a security and foreign policy
dialogue in 2005, consolidated discussions
related to the dispute over most of their
rugged, militarized boundary, regional
nuclear proliferation, Indian claims that
China transferred missiles to Pakistan,
and other matters continue; various talks
and confidence-building measures have
cautiously begun to defuse tensions over
Kashmir, particularly since the October
2005 earthquake in the region; Kashmir
nevertheless remains the site of the world’s
largest and most militarized territorial
dispute with portions under the de facto
administration of China (Aksai Chin),
India (Jammu and Kashmir), and Paki¬
stan (Azad Kashmir and Northern Areas);
India and Pakistan have maintained the
2004 cease fire in Kashmir and initiated
discussions on defusing the armed stand¬
off in the Siachen glacier region; Pakistan
protests India’s fencing the highly milita¬
rized Line of Control and construction of
the Baglihar Dam on the Chenab River
in Jammu and Kashmir, which is part
of the larger dispute on water sharing of
the Indus River and its tributaries; UN
Military Observer Group in India and
Pakistan (UNMOGIP) has maintained a
small group of peacekeepers since 1949;
India does not recognize Pakistan’s ceding
historic Kashmir lands to China in 1964;
to defuse tensions and prepare for discus¬
sions on a maritime boundary, India and
Pakistan seek technical resolution of the
disputed boundary in Sir Creek estuary
at the mouth of the Rann of Kutch in the
Arabian Sea; Pakistani maps continue to
show its Junagadh claim in Indian Gujarat
State; discussions with Bangladesh remain
stalled to delimit a small section of river
boundary, to exchange territory for 51 Bang¬
ladeshi exclaves in India and 111 Indian
exclaves in Bangladesh, to allocate divided
villages, and to stop illegal cross-border
trade, migration, violence, and transit
of terrorists through the porous border;
Bangladesh protests India’s attempts to
fence off high-traffic sections of the border;
dispute with Bangladesh over New Moore/
South Talpatty/Purbasha Island in the
Bay of Bengal deters maritime boundary
delimitation; India seeks cooperation from
Bhutan and Burma to keep Indian Naga¬
land and Assam separatists from hiding
in remote areas along the borders; Joint
Border Committee with Nepal continues
to examine contested boundary sections,
including the 400 square kilometer dispute
over the source of the Kalapani River; India
maintains a strict border regime to keep
out Maoist insurgents and control illegal
cross-border activities from Nepal
Refugees and internally displaced
persons: refugees (country of origin): 77,200
(Tibet/China); 69,609 (Sri Lanka); 9,472
(Afghanistan)
IDPs: at least 600,000 (about half are Kash¬
miri Pandits from Jammu and Kashmir)
(2007)
Trafficking in persons: current situation:
India is a source, destination, and transit
country for men, women, and children traf¬
ficked for the purposes of forced labor and
commercial sexual exploitation; internal
forced labor may constitute India’s largest
trafficking problem; men, women, and
children are held in debt bondage and
face forced labor working in brick kilns,
rice mills, agriculture, and embroidery
factories; women and girls are trafficked
within the country for the purposes of
commercial sexual exploitation and forced
marriage; children are subjected to forced
labor as factory workers, domestic serv¬
ants, beggars, and agriculture workers, and
have been used as armed combatants by
some terrorist and insurgent groups; India
is also a destination for women and girls
from Nepal and Bangladesh trafficked for
the purpose of commercial sexual exploi¬
tation; Indian women are trafficked to
the Middle East for commercial sexual
exploitation; men and women from Bang¬
ladesh and Nepal are trafficked through
India for forced labor and commercial
sexual exploitation in the Middle East
tier rating: Tier 2 Watch List— India is on
the Tier 2 Watch List for a fifth consecu¬
tive year for its failure to provide evidence
of increasing efforts to combat human
trafficking in 2007; despite the reported
extent of the trafficking crisis in India,
government authorities made uneven
efforts to prosecute traffickers and protect
trafficking victims; government authorities
continued to rescue victims of commercial
sexual exploitation and forced child labor
and child armed combatants, and began to
show progress in law enforcement against
these forms of trafficking; a critical chal¬
lenge overall is the lack of punishment for
traffickers, effectively resulting in impunity
for acts of human trafficking; India has not
ratified the 2000 UN TIP Protocol (2008)
illicit drugs: world’s largest producer of
licit opium for the pharmaceutical trade,
but an undetermined quantity of opium is
diverted to illicit international drug markets;
transit point for illicit narcotics produced
in neighboring countries and throughout
Southwest Asia; illicit producer of meth-
aqualone; vulnerable to narcotics money
laundering through the hawala system; licit
ketamine and precursor production
INDIAN OCEAN','0dadbf7df554001e351b90168b374055321e03371e9396b35297a7ad467a8de1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ef086a4e50e52196dbb75625717c692f9008bed3475245540b29e660725406e',2010,'ID','Indonesia','transnational-issues',822,'Disputes — international: some maritime
disputes (see littoral states)
consolidating democracy after four decades
of authoritarianism, implementing
economic and financial reforms, stem¬
ming corruption, holding the military and
police accountable for past human rights
violations, addressing climate change, and
controlling avian influenza. In 2005, Indo¬
nesia reached a historic peace agreement
with armed separatists in Aceh, which led
to democratic elections in December 2006.
Indonesia continues to face a low intensity
separatist movement in Papua.
Disputes— international: Indonesia has
a stated foreign policy objective of estab¬
lishing stable fixed land and maritime
boundaries with all of its neighbors; Timor-
Leste-Indonesia Boundary Committee has
resolved all but a small portion of the land
boundary, but discussions on maritime
boundaries are stalemated over sovereignty
of the uninhabited coral island of Pulau
Batek/Fatu Sinai in the north and align¬
ment with Australian claims in the south;
many refugees from Timor-Leste who left
in 2003 still reside in Indonesia and refuse
repatriation; a 1997 treaty between Indo¬
nesia and Australia settled some parts of
their maritime boundary but outstanding
issues remain; ICJ’s award of Sipadan
and Ligitan islands to Malaysia in 2002
left the sovereignty of Unarang rock and
the maritime boundary in the Ambalat oil
block in the Celebes Sea in dispute; the
IC] decision has prompted Indonesia to
assert claims to and to establish a presence
on its smaller outer islands; Indonesia and
Singapore continue to work on finalization
of their 1973 maritime boundary agree¬
ment by defining unresolved areas north
of Indonesia’s Batam Island; Indonesian
secessionists, squatters, and illegal migrants
create repatriation problems for Papua
New Guinea; piracy remains a problem
in the Malacca Strait; maritime delimita¬
tion talks continue with Palau; Indonesian
groups challenge Australia’s claim to
Ashmore Reef; Australia has closed parts
of the Ashmore and Cartier Reserve to
Indonesian traditional fishing and placed
restrictions on certain catches
Refugees and internally displaced
persons: I DPs: 200,000-350,000 (govern¬
ment offensives against rebels in Aceh;
most IDPs in Aceh, Central Kalimantan,
Central Sulawesi Provinces, and Maluku)
(2007)
Illicit drugs: illicit producer of cannabis
largely for domestic use; producer of meth-
amphetamine and ecstasy
IRAN
Background: Known as Persia until 1935,
Iran became an Islamic republic in 1979
after the ruling monarchy was overthrown
and Shah Mohammad Reza PAHLAVI
was forced into exile. Conservative clerical
forces established a theocratic system of
government with ultimate political authority
vested in a learned religious scholar referred
to commonly as the Supreme Leader who,
according to the constitution, is account¬
able only to the Assembly of Experts. US-
Iranian relations have been strained since
a group of Iranian students seized the US
Embassy in Tehran on 4 November 1979
and held it until 20 January 1981. During
1980-88, Iran fought a bloody, indecisive
war with Iraq that eventually expanded into
the Persian Gulf and led to clashes between
US Navy and Iranian military forces
between 1987 and 1988. Iran has been
designated a state sponsor of terrorism
for its activities in Lebanon and elsewhere
in the world and remains subject to US,
UN, and EU economic sanctions and
export controls because of its continued
involvement in terrorism and its nuclear
weapons ambitions. Following the election
of reformer Hojjat ol-Eslam Mohammad
KHATAMI as president in 1997 and
similarly a reformer Majles (parliament) in
2000, a campaign to foster political reform
in response to popular dissatisfaction
was initiated. The movement floundered
as conservative politicians, through the
control of unelected institutions, prevented
reform measures from being enacted and
increased repressive measures. Starting
with nationwide municipal elections in
2003 and continuing through Majles elec¬
tions in 2004, conservatives reestablished
control over Iran’s elected government
institutions, which culminated with the
August 2005 inauguration of hardliner
Mahmud AHMADI-NEJAD as president.
The UN Security Council has passed
a number of resolutions (1696 in July
2006, 1737 in December 2006, 1747 in
March 2007, 1803 in March 2008, and
1835 in September 2008) calling for Iran
to suspend its uranium enrichment and
reprocessing activities and comply with
its IAEA obligations and responsibilities.
Resolutions 1737, 1477, and 1803 subject
a number of Iranian individuals and enti¬
ties involved in Iran’s nuclear and ballistic
missile programs to sanctions. Addition¬
ally, several Iranian entities are subject
to US sanctions under Executive Order
325
THE CIA WORLD FACTBOOK
13382 designations for proliferation
activities and EO 13224 designations for
support of terrorism.','0118d328050085408b78780e3493b9b4df3602cc900218a3851fae9ab42e75f8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a82066c71dd5fc3b46235d04df8331160d3d2d437a03f2f83967d2a1adebcee',2010,'IQ','Iraq','transnational-issues',826,'Disputes — international: Iran protests
Afghanistan’s limiting flow of dammed
tributaries to the Helmand River in
periods of drought; Iraq’s lack of a mari¬
time boundary with Iran prompts juris¬
diction disputes beyond the mouth of the
Shatt al Arab in the Persian Gulf; Iran
and UAE dispute Tunb Islands and Abu
Musa Island, which are occupied by Iran;
Iran stands alone among littoral states in
insisting upon a division of the Caspian
Sea into five equal sectors
Refugees and internally displaced
persons: refugees ( country of origin): 91 4,268
(Afghanistan); 54,024 (Iraq) (2007)
Trafficking in persons: current situation:
Iran is a source, transit, and destina¬
tion country for women trafficked for the
purposes of sexual exploitation and involun¬
tary servitude; Iranian women are trafficked
internally for the purpose of forced prostitu¬
tion and for forced marriages to settle debts;
Iranian children are trafficked internally
and Afghan children are trafficked into
Iran for the purpose of forced marriages,
commercial sexual exploitation, and invol¬
untary servitude as beggars or laborers
tier rating: Tier 3— Iran did not provide
evidence of law enforcement activities
against trafficking, and credible reports
indicate that Iranian authorities punish
victims of trafficking with beatings, impris¬
onment, and execution; Iran has not rati¬
fied the 2000 UN TIP Protocol (2008)
Illicit drugs: despite substantial interdic¬
tion efforts and considerable control meas¬
ures along the border with Afghanistan,
Iran remains one of the primary transship¬
ment routes for Southwest Asian heroin to
Europe; suffers one of the highest opiate
addiction rates in the world, and has an
increasing problem with synthetic drugs;
lacks anti-money laundering laws; has
reached out to neighboring countries to
share counter-drug intelligence
inspections. Continued Iraqi noncompli-
ance with UNSC resolutions over a period
of 12 years led to the US-led invasion of
Iraq in March 2003 and die ouster of the
SADDAM Husayn regime. US forces
remained in Iraq under a UNSC mandate
until 31 December 2008 and under a bilat¬
eral Security Agreement thereafter, helping
to provide security and to support the freely
elected government. In October 2005,
Iraqis approved a constitution in a national
329
THE CIA WORLD FACTBOOK
referendum and, pursuant to this docu¬
ment, elected a 275-member Council of
Representatives (CoR) in December 2005.
After the election, Ibrahim al-JAAFARI
was selected as prime minister; he was
replaced by Nuri al-MALIKI in May 2006.
The CoR approved most cabinet ministers
in May 2006, marking the transition to
Iraq’s first constitutional government in
nearly a half century. On 31 January 2009,
Iraq held elections for provincial councils
in all provinces except for the three prov¬
inces comprising the Kurdistan Regional
Government and at-Ta’mim (Kirkuk) prov¬
ince.','a5be0cfe1ac47aff4a0f71df0ecb051f7c9cc8920c2c45bfdff5633f84dd8828','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc36facc78931f6630b7c454015400d6702a87c3f662d709de54bb9bbfcfe987',2010,'IE','Ireland','transnational-issues',835,'Disputes— international: coalition forces
assist Iraqis in monitoring internal and
cross-border security; approximately two
million Iraqis have fled the conflict in Iraq,
with the majority taking refuge in Syria
and Jordan, and lesser numbers to Egypt,
Lebanon, Iran, and Turkey; Iraq’s lack of
a maritime boundary with Iran prompts
jurisdiction disputes beyond the mouth
of the Shaft al Arab in the Persian Gulf;
Turkey has expressed concern over the
autonomous status of Kurds in Iraq
Refugees and internally displaced
persons: refugees (country of origin .):
10,000-15,000 (Palestinian Territo¬
ries); 11,773 (Iran); 16,832 (Turkey)
IDPs: 2.4 million (ongoing US-led war and
ethno-sectarian violence) (2007)
Background: Celtic tribes arrived on the
island between 600-150 B.C. Invasions
by Norsemen that began in the late 8th
century were finally ended when King
Brian BORU defeated the Danes in 1014.
English invasions began in the 1 2th
century and set off more than seven centu¬
ries of Anglo-Irish struggle marked by fierce
rebellions and harsh repressions. A failed
1916 Easter Monday Rebellion touched
off several years of guerrilla warfare that in
1921 resulted in independence from the
UK for 26 southern counties; six northern
(Ulster) counties remained part of the UK.
In 1949, Ireland withdrew from the British
Commonwealth; it joined the European
Community in 1973. Irish governments
have sought the peaceful unification of
Ireland and have cooperated with Britain
against terrorist groups. A peace settlement
for Northern Ireland is gradually being
implemented despite some difficulties. In
2006, the Irish and British governments
developed and began to implement the St.
Andrews Agreement, building on the Good
Friday Agreement approved in 1998.
Disputes— international: Ireland, Iceland,
and the UK dispute Denmark’s claim that
the Faroe Islands’ continental shelf extends
beyond 200 nm
Illicit drugs: transshipment point for and
consumer of hashish from North Africa
to the UK and Netherlands and of Euro¬
pean-produced synthetic drugs; increasing
consumption of South American cocaine;
minor transshipment point for heroin
and cocaine destined for Western Europe;
despite recent legislation, narcotics-
related money laundering— using bureaux
de change, trusts, and shell companies
involving the offshore financial commu¬
nity-remains a concern','5caac1fa86328a15c94de371ee79473f937aa189a1994720f98c7b232c2890c8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d63eba6bd7dea495d47e14e0ca918b6fc40815bd641230ee51d780b8355363b4',2010,'IL','Israel','transnational-issues',855,'Disputes — international: West Bank and
Gaza Strip are Israeli-occupied with current
status subject to the Israeli-Palestinian
Interim Agreement— permanent status to
be determined through further negotiation;
Israel continues construction of a “seam
line” separation barrier along parts of the
Green Line and within the West Bank;
Israel withdrew its settlers and military
from the Gaza Strip and from four settle¬
ments in the West Bank in August 2005;
Golan Heights is Israeli-occupied (Lebanon
claims the Shab’a Farms area of Golan
Heights); since 1948, about 350 peace¬
keepers from the UN Truce Supervision
Organization (UNTSO) headquartered
in Jerusalem monitor ceasefires, supervise
armistice agreements, prevent isolated inci¬
dents from escalating, and assist other UN
personnel in the region
Refugees and internally displaced
persons: IDPs: 150,000-420,000 (Arab
villagers displaced from homes in northern
Israel) (2007)
Illicit drugs: increasingly concerned about
ecstasy, cocaine, and heroin abuse; drugs
arrive in country from Lebanon and,
increasingly, from Jordan; money-laun¬
dering center','7e86bc07eb7725ba5bdfd0344dcaa897871190b3e47a7360adcc0570ad564312','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2ca1a006aec968cf05a83ba58d5d247804644f92f5de467b7452dcdfbb6a439',2010,'JM','Jamaica','transnational-issues',863,'Disputes — international: none
Illicit drugs: transshipment point for
cocaine from South America to North
America and Europe; illicit cultivation and
consumption of cannabis; government
has an active manual cannabis eradication
program; corruption is a major concern;
substantial money-laundering activity;
Colombian narcotics traffickers favor
Jamaica for illicit financial transactions
348
JAN MAYEN
JAN MAYEN
Disputes— international : none','31f26df3f3a729193fe63c034452d4085513643cc05ec77e71f7485d4cfcaeaa','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca73886dcd10a79d27ccfd2475a2669d99002612f66da44b574e22284b63684',2010,'JE','Jersey','transnational-issues',875,'Disputes — international: the sovereignty
dispute over the islands of Etorofu, Kuna-
shiri, and Shikotan, and the Habomai
group, known in Japan as the “Northern
Territories” and in Russia as the “Southern
Kuril Islands,” occupied by the Soviet
Union in 1945, now administered by
Russia and claimed by Japan, remains the
primary sticking point to signing a peace
treaty formally ending World War II hostil¬
ities; Japan and South Korea claim Liam
court Rocks (Take-shima/Dokdo) occupied
by South Korea since 1954; China and
Taiwan dispute both Japan’s claims to
the uninhabited islands of the Senkaku-
shoto (Diaoyu Tai) and Japan’s unilaterally
declared exclusive economic zone in the
East China Sea, the site of intensive hydro¬
carbon prospecting
Background: Jersey and the other Channel
Islands represent the last remnants of the
medieval Dukedom of Normandy that held
sway in both France and England. These
islands were the only British soil occupied
by German troops in World War II. Jersey
is a British crown dependency but is not
part of the UK. However, the UK Govern¬
ment is constitutionally responsible for its
defense and international representation.','a66e8dcbf98d513e0bdc56f45d9831b27921cf440f70aa24e5a5a5e46879f1d4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c09fc3e6adce51a61f49f995c1eb901762e12b98781729c253c426c43dfbea4',2010,'JO','Jordan','transnational-issues',884,'Disputes— international: none
Disputes — international: approximately
two million Iraqis have fled the conflict in
Iraq, with the majority taking refuge in Syria
and Jordan; 2004 Agreement setdes border
dispute with Syria pending demarcation
Refugees and internally displaced
persons: refugees ( country of origin ):
1,835,704 (Palestinian Refugees
(UNRWA)); 500,000 (Iraq)
IDPs: 160,000 (1967 Arab-Israeli War)
(2007)
Trafficking in persons: current situation:
Jordan is a destination and transit country
for women and men from South and
Southeast Asia trafficked for the purpose of
forced labor; Jordan is also a destination for
women from Eastern Europe and Morocco
for prostitution; women from Bangladesh,
Sri Lanka, Indonesia, and the Philippines
migrate willingly to work as domestic serv¬
ants, but some are subjected to conditions of
forced labor, including unlawful withholding
of passports, restrictions on movement, non¬
payment of wages, threats, and physical or
sexual abuse
tier rating: Tier 2 Watch List— Jordan is on
the Tier 2 Watch List for its failure to provide
evidence of increasing efforts to combat traf¬
ficking in persons in 2007, particularly in the
area of law enforcement against trafficking
for forced labor; the government made
minimal efforts to investigate or prosecute
numerous allegations related to exploitation
of foreign domestic workers; Jordan failed
for a second year to criminally prosecute and
punish those who committed acts of forced
labor; Jordan also continues to lack victim
protection services; Jordan has not ratified
the 2000 UN TIP Protocol (2008)
358
Refugees and internally displaced
persons: refugees ( country of origin ): 1-
1.4 million (Iraq); 522,100 (Palestinian
Refugees (UNRWA))
IDPs: 305,000 (most displaced from Golan
Heights during 1967 Arab-Israeli War)
(2007)
Trafficking in persons: current situa¬
tion: Syria is a destination and transit
country for women and children traf¬
ficked for commercial sexual exploitation
and forced labor; a significant number
of women and children in the large and
expanding Iraqi refugee community in
Syria are reportedly forced into commer¬
cial sexual exploitation by Iraqi gangs or,
in some cases, their families; women from
Indonesia, Sri Lanka, the Philippines,
Ethiopia, and Sierra Leone are recruited
for work in Syria as domestic servants,
but some face conditions of involun¬
tary servitude, including long hours,
non-payment of wages, withholding of
passports, restrictions on movement,
threats, and physical or sexual abuse
tier rating: Tier 3— Syria again failed to
report any law enforcement efforts to
punish trafficking offenses in 2007; in
addition, the government did not offer
protection services to victims of trafficking
and may have arrested, prosecuted, or
deported some victims for prostitution or
immigration violations; Syria has not rati¬
fied the 2000 UN TIP Protocol (2008)
Illicit drugs: a transit point for opiates,
hashish, and cocaine bound for regional
and Western markets; weak anti-money-
laundering controls and bank privatiza¬
tion may leave it vulnerable to money
laundering
659
TAIWAN','5b254d9a027b874245e052c239ad5c2dedb77620ba6e3e3fafda762a9dc59554','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e0671ed09c776034f966c154456b22768eb3733c7864852120e0be8c203202d',2010,'KZ','Kazakhstan','transnational-issues',890,'WOPWOV:
PsvkHtet
ASTANA
*iAlyrsfefi
{KyzyfsrifeJ
Disputes — international: Kyrgyzstan has
yet to ratify the 2001 boundary delimita¬
tion with Kazakhstan; field demarcation
of the boundaries with Turkmenistan
commenced in 2005, and with Uzbekistan
in 2004; demarcation is scheduled to get
underway with Russia in 2007; demarca¬
tion with China was completed in 2002;
creation of a seabed boundary with Turk¬
menistan in the Caspian Sea remains
under discussion; equidistant seabed trea¬
ties have been ratified with Azerbaijan and
Russia in the Caspian Sea, but no resolu¬
tion has been made on dividing the water
column among any of the littoral states
Refugees and internally displaced
persons: refugees ( country of origin .): 3,700
(Russia); 508 (Afghanistan) (2007)
Illicit drugs: significant illicit cultivation
of cannabis for CIS markets, as well as
limited cultivation of opium poppy and
ephedra (for the drug ephedrine); limited
government eradication of illicit crops;
transit point for Southwest Asian narcotics
bound for Russia and the rest of Europe;
significant consumer of opiates','e1c2c80b5eafe7cef7ff4927c900093374dbda81b919f89d97ac8c05c7191937','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83d2eef989a6b533f0d9ae37c62f9ec455fe812a1b848cca45b73a0cedf1393b',2010,'KE','Kenya','transnational-issues',907,'Disputes— international: Kenya served as
an important mediator in brokering Sudan’ s
north-south separation in February 2005;
Kenya provides shelter to almost a quarter
of a million refugees, including Ugandans
who flee across the border periodically to
seek protection from Lord’s Resistance
Army (LRA) rebels; Kenya works hard to
prevent the clan and militia fighting in
Somalia from spreading across the border,
which has long been open to nomadic
pastoralists; the boundary that separates
Kenya’s and Sudan’s sovereignty is unclear
in the “Ilemi Triangle,” which Kenya has
administered since colonial times
Refugees and internally displaced
persons: refugees (country of origin): 1 73,702
(Somalia); 73, 004(Sudan); 1 6,428 (Ethiopia)
IDPs: 250,000-400,000 (2007 post-election
violence; KANU attacks on opposition
tribal groups in 1990s) (2007)
Illicit drugs: widespread harvesting of small
plots of marijuana; transit country for South
Asian heroin destined for Europe and
North America; Indian methaqualone also
transits on way to South Africa; significant
potential for money-laundering activity given
the country’s status as a regional financial
Center; massive corruption, and relatively
high levels of narcotics-associated activities','2d0b509ba1d761249e76ffb953f2e1e7aa903f9ffaf8e88c10900d9132636c13','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('231e450efa091cd6862dc81729865ea847ed22bac3c08bb026a4aeb41535a38b',2010,'KI','Kiribati','transnational-issues',915,'Disputes — international: none
KOREA, NORTH
Disputes— international: risking arrest,
imprisonment, and deportation, tens of
thousands of North Koreans cross into
China to escape famine, economic priva¬
tion, and political oppression; North Korea
and China dispute the sovereignty of certain
islands in Yalu and Tumen rivers; Military
Demarcation Line within the 4-km wide
Demilitarized Zone has separated North
from South Korea since 1953; periodic inci¬
dents in the Yellow Sea with South Korea
which claims the Northern Limiting Line as
371
THE CIA WORLD FACTBOOK
a maritime boundary; North Korea supports
South Korea in rejecting Japan’s claim to
Liancourt Rocks (T ok-do/T ake-shima)
Refugees and internally displaced
persons: IDPs: undetermined (flooding in
mid-2007 and famine during mid-1990s)
(2007)
Trafficking in persons: current situation:
North Korea is a source country for men,
women, and children trafficked for the
purposes of forced labor and commercial
sexual exploitation; the most common form
of trafficking involves North Korean women
and girls who cross the border into China
voluntarily; additionally, North Korean
women and girls are lured out of North
Korea to escape poor social and economic
conditions by the promise of food, jobs, and
freedom, only to be forced into prostitution,
marriage, or exploitative labor arrangements
once in China
tier rating: Tier 3— North Korea does not fully
comply with minimum standards for the
elimination of trafficking and is not making
significant efforts to do so; the government
does not acknowledge the existence of
human rights abuses in die country or recog¬
nize trafficking, either within the country or
transnational^; North Korea has not ratified
the 2000 UN TIP Protocol (2008)
Illicit drugs: for years, from the 1970s
into the 2000s, citizens of the Democratic
People’s Republic of (North) Korea (DPRK),
many of them diplomatic employees of the
government, were apprehended abroad
while trafficking in narcotics, including
two in Turkey in December 2004; police
investigations in Taiwan and Japan in
recent years have linked North Korea to
large illicit shipments of heroin and meth-
amphetamine, including an attempt by the
North Korean merchant ship Pong Su to
deliver 150 kg of heroin to Australia in
April 2003
KOREA, SOUTH
Disputes— international: Military Demar¬
cation Line within the 4-km wide Demili¬
tarized Zone has separated North from
South Korea since 1953; periodic incidents
with North Korea in the Yellow Sea over
the Northern Limiting Line, which South
Korea claims as a maritime boundary;
South Korea and Japan claim Liancourt
Rocks (Tok-do/Take-shima), occupied by
South Korea since 1954
KOSOVO
Disputes — international: Serbia with
several other states protest the US and other
states’ recognition of Kosovo’s declaring
itself as a sovereign and independent state in
February 2008; ethnic Serbian municipali¬
ties along Kosovo’s northern border chal¬
lenge final status of Kosovo-Serbia boundary;
several thousand NATO-led KFOR peace¬
keepers under UNMIK authority continue
to keep the peace within Kosovo between
die ethnic Albanian majority and the Serb
minority in Kosovo; Kosovo and Macedonia
completed demarcation of their boundary in
September 2008
Refugees and internally displaced
persons: IDP’s: 21,000 (2007)','aee6c315ec6aa99f90943dcf2edf4c7ab5ec9f3671ff9373a5615e38492b762d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf15609b2d8eed3c0d38b1a8a29aadff176c4ca43f9d5ac67e2ff80233b42f08',2010,'KW','Kuwait','transnational-issues',916,'Background: Britain oversaw foreign
relations and defense for die ruling
Kuwaiti ADSABAH dynasty from 1899
until independence in 1961. Kuwait
was attacked and overrun by Iraq on 2
August 1990. Following several weeks of
aerial bombardment, a US-led, UN coali¬
tion began a ground assault on 23 February
1991 that liberated Kuwait in four days.
Kuwait spent more than $5 billion to repair
oil infrastructure damaged during 1990-91.
The AL-SABAH family has ruled since
returning to power in 1991 and reestab¬
lished an elected legislature that in recent
years has become increasingly assertive.','77d0ab6a38bcc85b692e201f0e1092f4f009fe7cfbb01506671fb9dee9ed40f2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d985415cb920858609acb3aa313a4f254f1b0dabf5c2c95b1e474059819a2c1c',2010,'KG','Kyrgyzstan','transnational-issues',925,'Disputes — international: Kuwait and Saudi
Arabia continue negotiating a joint maritime
boundary with Iran; no maritime boundary
exists with Iraq in the Persian Gulf
Trafficking in persons: current situation:
Kuwait is a destination country for men
and women who migrate legally from South
and Southeast Asia for domestic or low-
skilled labor, but are subjected to condi-
tions of involuntary servitude by employers
in Kuwait including conditions of physical
and sexual abuse, non-payment of wages,
confinement to the home, and withholding
of passports to restrict their freedom of
movement; Kuwait is reportedly a transit
point for South and East Asian workers
recruited for low-skilled work in Iraq; some
of these workers are deceived as to the true
location and nature of this work, and others
are subjected to conditions of involuntary
servitude in Iraq
tier rating: Tier 3— insufficient efforts in
2007 to prosecute and punish abusive
employers and those who traffic women for
sexual exploitation; the government failed
for the fourth year in a row to live up to
promises to provide shelter and protective
services for victims of involuntary domestic
servitude and other forms of trafficking
(2008)
Disputes — international: Kyrgyzstan has
yet to ratify the 2001 boundary delimita¬
tion with Kazakhstan; disputes in Isfara
Valley delay completion of delimitation with
Tajikistan; delimitation of 130 km of border
with Uzbekistan is hampered by serious
disputes around enclaves and other areas
Illicit drugs: limited illicit cultivation
of cannabis and opium poppy for CIS
markets; limited government eradication
of illicit crops; transit point for Southwest
Asian narcotics bound for Russia and the
rest of Europe; major consumer of opiates
384
LAOS','932f2dc9c3b00d61e56e6a0c7a63d577b2512d66024d273707e7804acf0eff6e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1643eecfda0d0355023b2206a7171dcadaa316f9e01b745deb1884132dc708e2',2010,'VN','Viet Nam','transnational-issues',932,'*iouang \\ ^
Nam5tsa
Xam*
Nua
t . t>u at ’>gp? i ; a d »%j »
XtaftgWwaftg* <
i .
JStvam','2d23c439716df1fd3ac9d5a473203d227803fc536c77eede9751099077156ea5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e92b6185bb03a9bd610a0d887e846793514f02aed8e18dd43135ba8727e91d0f',2010,'TH','Thailand','transnational-issues',940,'Disputes— international: Southeast Asian
states have enhanced border surveillance
to check the spread of avian flu; talks
continue on completion of demarcation
with Thailand but disputes remain over
islands in the Mekong River; concern
among Mekong Commission members
diat China’s construction of dams on the
Mekong River will affect water levels
Illicit drugs: estimated opium poppy culti¬
vation in 2008 was 1 ,900 hectares, about a
73% increase from 2007; estimated poten¬
tial opium production in 2008 more than
tripled to 17 metric tons; unsubstantiated
reports of domestic mediamphetamine
production; growing domestic metham-
phetamine problem (2007)
387
THE CIA WORLD FACTBOOK
Background: A unified Thai kingdom
was established in the mid-Mth century.
Known as Siam until 1939, Thailand is
the only Southeast Asian country never
to have been taken over by a European
power. A bloodless revolution in 1932 led
to a constitutional monarchy. In alliance
with Japan during World War II, Thai¬
land became a US treaty ally following the
conflict. A military coup in September 2006
ousted then Prime Minister THAKSIN
Chinnawat. The interim government
held elections in December 2007 that saw
the pro-THAKSIN People’s Power Party
(PPP) emerge at the head of a coalition
government. The anti-THAKSIN People’s
Alliance for Democracy (PAD) in May 2008
began street demonstrations against the
new government, eventually occupying the
prime minister’s office in August. Clashes
in October 2008 between PAD protesters
blocking parliament and police resulted in
the death of at least two people. The PAD
occupied Bangkok’s international airports
briefly, ending their protests in early
December 2008 following a court ruling
that dissolved the ruling PPP and two other
coalition parties for election violations.
The Democrat Party then formed a new
coalition government with the support
of some of THAKSIN’s former political
allies, and ABHISIT Wetchachiwa became
prime minister. Since January 2004, thou¬
sands have been killed as separatists in
Thailand’s southern ethnic Malay-Muslim
provinces increased the violence associated
with their cause.','52ff06f74b5114a77b8e4c70965b32eea7fd6fee1cd48a67b7592b00522e3e37','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e8f02f1aa3f65c0f34fbef5b385b6bceb4b9c9887d8e944852c3cc7045b70b9',2010,'LB','Lebanon','transnational-issues',949,'Disputes— international: Russia demands
better Latvian treatment of ethnic Russians
in Latvia; as of January 2007, ground
demarcation of the boundary with Belarus
was complete and mapped with final ratifi¬
cation documentation in preparation; the
Latvian parliament has not ratified its 1 998
maritime boundary treaty with Lithuania,
primarily due to concerns over oil explora-
tion rights; as a member state that forms
part of the EU’s external border, Latvia has
implemented the strict Schengen border
rules with Russia
Illicit drugs: transshipment and destination
point for cocaine, synthetic drugs, opiates,
and cannabis from Southwest Asia,
Western Europe, Latin America, and
neighboring Balkan countries; despite
improved legislation, vulnerable to money
laundering due to nascent enforcement
capabilities and comparatively weak regula¬
tion of offshore companies and the gaming
industry; CIS organized crime (including
counterfeiting, corruption, extortion,
stolen cars, and prostitution) accounts for
most laundered proceeds
Background: Following the capture of
Syria from the Ottoman Empire by Anglo-
French forces in 1918, France received a
mandate over this territory and separated
out the region of Lebanon in 1 920. France
granted this area independence in 1943. A
lengthy civil war (1975-1990) devastated
the country, but Lebanon has since made
progress toward rebuilding its political
institutions . U nder the Ta’ if Accord— the blue-
print for national reconciliation— the Leba¬
nese established a more equitable political
system, particularly by giving Muslims a
greater voice in the political process while
institutionalizing sectarian divisions in the
government. Since the end of the war,
Lebanon has conducted several successful
elections. Most militias have been
disbanded, with the exception of Hizballah,
designated by the US State Department as a
Foreign Terrorist Organization, and Pales¬
tinian militant groups. During Lebanon’s
civil war, the Arab League legitimized in
the Ta’if Accord Syria’s troop deployment,
numbering about 16,000 based mainly east
of Beirut and in the Bekaa Valley. Israel’s
withdrawal from southern Lebanon in May
2000 and the passage in September 2004
of UNSCR 1 559— a resolution calling for
Syria to withdraw from Lebanon and end
its interference in Lebanese affairs— encour¬
aged some Lebanese groups to demand
that Syria withdraw its forces as well. The
assassination of former Prime Minister
Rafiq HARIRI and 22 others in February
2005 led to massive demonstrations in
Beirut against the Syrian presence (“the
Cedar Revolution”), and Syria withdrew
the remainder of its military forces in April
2005. In May-June 2005, Lebanon held
its first legislative elections since the end
of the civil war free of foreign interference,
handing a majority to the bloc led by Saad
HARIRI, the slain prime minister’s son.
In July 2006, Hizballah kidnapped two
Israeli soldiers leading to a 34-day conflict
with Israel in which approximately 1,200
Lebanese civilians were killed. UNSCR
1701 ended the war in August 2006, and
Lebanese Armed Forces (LAF) deployed
throughout the country for the first time
in decades, charged with securing Leba¬
non’s borders against weapons smuggling
and maintaining a weapons-free zone in
south Lebanon with the help of the UN
Interim Force in Lebanon (UNIFIL). The
LAF in May-September 2007 battled Sunni
extremist group Fatah al-Islam in the Nahr
al-Barid Palestinian refugee camp, winning a
decisive victory, but destroying the camp
and displacing 30,000 Palestinian resi¬
dents. Lebanese politicians in November
2007 were unable to agree on a successor
to Emile LAHUD when he stepped down
as president, creating a political vacuum
until the election of Army Commander
Michel SULAYMAN in May 2008 and
the formation of a new unity government
in July 2008.
Disputes— international: lacking a treaty
or other documentation describing the
boundary, portions of the Lebanon-Syria
boundary are unclear with several sections
in dispute; since 2000, Lebanon has claimed
Shab’a Farms area in the Israeli-occupied
Golan Heights; the roughly 2, 000-strong
UN Interim Force in Lebanon (UNIFIL)
has been in place since 1978
Refugees and internally displaced
persons: refugees ( country of origin ):
405,425 (Palestinian refugees (UNRWA));
50,000-60,000 (Iraq)
IDPs: 17,000 (1975-90 civil war, Israeli
invasions); 200,000 (July-August 2006 war)
(2007)
Illicit drugs: cannabis cultivation dramati¬
cally reduced to 2,500 hectares in 2002
despite continued significant cannabis
consumption; opium poppy cultivation
minimal; small amounts of Latin American
cocaine and Southwest Asian heroin transit
country on way to European markets and
for Middle Eastern consumption; money
laundering of drug proceeds fuels concern
that extremists are benefiting from drug
trafficking
394','0b802ade3e72fcd62162317b6fa1d9ae6d0acc1a9b68c9cce1bd60a8c3d96fb6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da5ba3da220db0047c08b6ac3d5a66532075aecc7618c70ccc46423d880f56e6',2010,'LS','Lesotho','transnational-issues',952,'Background: Basutoland was renamed the
Kingdom of Lesotho upon independence
from the UK in 1966. The Basuto National
Party ruled for the first two decades. King
MOSHOESHOE was exiled in 1990, but
returned to Lesotho in 1 992 and was rein¬
stated in 1995. Constitutional government
was restored in 1993 after seven years of
military rule. In 1998, violent protests and
a military mutiny following a contentious
election prompted a brief but bloody inter¬
vention by South African and Botswanan
military forces under the aegis of the
Southern African Development Commu¬
nity. Subsequent constitutional reforms
restored relative political stability. Peaceful
parliamentary elections were held in 2002,
but the National Assembly elections of
February 2007 were hody contested and
aggrieved parties continue to periodically
demonstrate their distrust of the results.','e93c3866a5867a77e072a2ed7d1cd91e4bda67165b480a3875f30a209ca1eb41','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35dcf4a202776a0a9835637af19ed6dd312d932f6a996987296fc88b234e74fe',2010,'LR','Liberia','transnational-issues',961,'Disputes — international: none
Charles TAYLOR launched a rebel¬
lion against DOE’s regime that led to a
prolonged civil war in which DOE himself
was killed. A period of relative peace in
1997 allowed for elections that brought
TAYLOR to power, but major fighting
resumed in 2000. An August 2003 peace
397
THE CIA WORLD FACTBOOK
agreement ended the war and prompted
the resignation of former president Charles
TAYLOR, who faces war crimes charges in
The Hague related to his involvement in
Sierra Leone’s civil war. After two years of
rule by a transitional government, demo¬
cratic elections in late 2005 brought Presi¬
dent Ellen JOHNSON SIRLEAF to power.
The UN Mission in Liberia (UNMIL)
maintains a strong presence throughout
the country, but the security situation is
still fragile and the process of rebuilding
the social and economic structure of this
war-tom country will take many years.
Disputes — international: although civil
unrest continues to abate with the assist¬
ance of 18,000 UN Mission in Liberia
(UNMIL) peacekeepers, as of January 2007,
Liberian refugees still remain in Guinea,
Cote d’Ivoire, Sierra Leone, and Ghana;
Liberia, in turn, shelters refugees fleeing
turmoil in Cote d’Ivoire; despite the pres¬
ence of over 9,000 UN forces (UNOCI)
in Cote d’Ivoire since 2004, ethnic conflict
continues to spread into neighboring states
who can no longer send their migrant
workers to Ivorian cocoa plantations;
UN sanctions ban Liberia from exporting
diamonds and timber
Refugees and internally displaced
persons: refugees ( country of origin): 12,600
(Cote d’Ivoire)
IDPs: 13,000 (civil war from 1990-2004;
IDP resetdement began in November
2004) (2007)
Illicit drugs: transshipment point for
Southeast and Southwest Asian heroin and
South American cocaine for the European
and US markets; corruption, criminal
activity, arms-dealing, and diamond trade
provide significant potential for money
laundering, but the lack of well-developed
financial system limits the country’s utility
as a major money-laundering center
400','387ae97706af44f2ec42651a5e62da4a1a8239c77f09b986c03a76ccf732423e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94d33c356109fe0d72eb535b5549b1cd1946e5d2999d7882d68fdfa2b2a61dda',2010,'LY','Libya','transnational-issues',965,'Background: The Italians supplanted the
Ottoman Turks in the area around Tripoli
in 1911 and did not relinquish their hold
until 1943 when defeated in World War
II. Libya then passed to UN administra¬
tion and achieved independence in 1951.
Following a 1969 military coup, Col.
Muammar Abu Minyar al-QADHAFI
began to espouse his own political system,
the Third Universal Theory. The system
is a combination of socialism and Islam
derived in part from tribal practices and
is supposed to be implemented by the
Libyan people themselves in a unique
form of “direct democracy.” QADHAFI
has always seen himself as a revolutionary
and visionary leader. He used oil funds
during the 1970s and 1980s to promote
his ideology outside Libya, supporting
subversives and terrorists abroad to hasten
the end of Marxism and capitalism. In
addition, beginning in 1973, he engaged
in military operations in northern Chad’s
Aozou Strip— to gain access to minerals and
to use as a base of influence in Chadian
politics— but was forced to retreat in 1987.
UN sanctions in 1992 isolated QADHAFI
politically following the downing of Pan
AM Flight 103 over Lockerbie, Scotland.
During the 1990s, QADHAFI began to
rebuild his relationships with Europe.
UN sanctions were suspended in April
1 999 and finally lifted in September 2003
after Libya accepted responsibility for the
Lockerbie bombing. In December 2003,
Libya announced that it had agreed to
reveal and end its programs to develop
weapons of mass destruction and to
renounce terrorism. QADHAFI has made
significant strides in normalizing relations
with Western nations since then. He
has received various Western European
leaders as well as many working-level and
commercial delegations, and made his first
trip to Western Europe in 15 years when
he traveled to Brussels in April 2004.
The US rescinded Libya’s designation as
a state sponsor of terrorism in June 2006.
In January 2008, Libya assumed a nonper¬
manent seat on the UN Security Council
for the 2008-09 term. In August 2008, the
US and Libya signed a bilateral compre¬
hensive claims settlement agreement to
compensate claimants in both countries
who allege injury or death at the hands of
the other country, including the Lockerbie
bombing, the LaBelle disco bombing, and
the UTA 772 bombing. In October 2008,
the US Government received $1.5 billion
pursuant to the agreement to distribute
to US national claimants, and as a result
effectively normalized its bilateral relation¬
ship with Libya. The two countries then
exchanged ambassadors for the first time
since 1973 in January 2009.
Disputes— international: Libya has
claimed more than 32,000 sq km in south¬
eastern Algeria and about 25,000 sq km in
the Tommo region of Niger in a currently
dormant dispute; various Chadian rebels
from the Aozou region reside in southern
V V
Refugees and internally displaced
persons: refugees ( country of origin): 8,000
(Palestinian Territories) (2007)
Trafficking in persons: current situation:
Libya is a transit and destination country
for men and women from sub-Saharan
Africa and Asia trafficked for the purposes
of forced labor and commercial sexual
exploitation
tier rating: Tier 2 Watch List— Libya is on
the Tier 2 Watch List for its failure to
provide evidence of increasing efforts to
address trafficking in persons in 2007 when
compared to 2006, particularly in the area
of investigating and prosecuting trafficking
offenses; Libya did not publicly release any
data on investigations or punishment of
any trafficking offenses (2008)
%','6615aa39d5113b145a604e49a1bb82287e3b0b500e573a6a098628f2b4c8ff30','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7741bf412540ae2654bbccde1352452077474d4d0649afb5aec76ad261588918',2010,'LI','Liechtenstein','transnational-issues',972,'Background: The Principality of Liech¬
tenstein was established within the Holy
Roman Empire in 1719. Occupied by
both French and Russian troops during
the Napoleanic wars, it became a sovereign
state in 1806 and joined the Germanic
Confederation in 1815. Liechtenstein
became fully independent in 1 866 when the
Confederation dissolved. Until the end of
World War I, it was closely tied to Austria,
but the economic devastation caused by
that conflict forced Liechtenstein to enter
into a customs and monetary union with
Switzerland. Since World War II (in which
Liechtenstein remained neutral), the coun¬
try’s low taxes have spurred outstanding
economic growth. In 2000, shortcomings
in banking regulatory oversight resulted in
concerns about the use of financial insti¬
tutions for money laundering. However,
Liechtenstein implemented anti-money¬
laundering legislation and a Mutual Legal
Assistance Treaty with the US that went
into effect in 2003.
Disputes — international: none
Illicit drugs: has strengthened money laun¬
dering controls, but money laundering
remains a concern due to Liechtenstein’s
sophisticated offshore financial services sector','e76786d1308a0dece4f51453fe3d5cdf2763ddcdf0b549f9dc45d3eba35927d0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66eaea8ac76ca124fe198d9fb3850131c9e0788fcacfe902f012fd616484f511',2010,'LU','Luxembourg','transnational-issues',988,'Disputes — international: Lithuania and
Russia committed to demarcating their
boundary in 2006 in accordance with the
land and maritime treaty ratified by Russia
in May 2003 and by Lithuania in 1999;
Lithuania operates a simplified transit
regime for Russian nationals traveling from
the Kaliningrad coastal exclave into Russia,
while still conforming, as a EU member
state having an external border with a non-
EU member, to strict Schengen border
rules; the Latvian parliament has not rati¬
fied its 1998 maritime boundary treaty
with Lithuania, primarily due to concerns
over potential hydrocarbons; as of January
2007, ground demarcation of the boundary
with Belarus was complete and mapped
with final ratification documents in prepa¬
ration
Illicit drugs: transshipment and destina¬
tion point for cannabis, cocaine, ecstasy,
and opiates from Southwest Asia, Latin
America, Western Europe, and neigh¬
boring Baltic countries; growing production
of high-quality amphetamines, but limited
production of cannabis, methampheta-
mines; susceptible to money laundering
despite changes to banking legislation
Disputes— international : none
412
MACAU','38d1ec86c7c44f9c53b10554a7828ce58b78343bfaba35a90d0c88ec1ec7376c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('136c7680aaebbb65652f8d57f3aae4677a7bd6a56a359ba36c237d04e3479cf8',2010,'MG','Madagascar','transnational-issues',994,'Disputes— international: Kosovo and
Macedonia completed demarcation of
their boundary in September 2008; Greece
continues to reject the use of the name
Macedonia or Republic of Macedonia
Refugees and infernally displaced
persons: IDPs: fewer than 1,000 (ethnic
conflict in 2001) (2007)
Illicit drugs: major transshipment point
for Southwest Asian heroin and hashish;
minor transit point for South American
cocaine destined for Europe; although
not a financial center and most criminal
activity is thought to be domestic, money
laundering is a problem due to a mosdy
cash-based economy and weak enforce¬
ment
In 1997, in the second presidential race,
Didier RATSIRAKA, the leader during
the 1970s and 1980s, was returned to the
presidency. The 2001 presidential election
418
i .
was contested between the followers of
Didier RATSIRAKA and Marc RAVALO-
MANANA, nearly causing secession of
half of the country. In April 2002, the
High Constitutional Court announced
RAVALOMANANA the winner. RAVAD
OMANANA is now in his second term
following a landslide victory in the gener¬
ally free and fair presidential elections of
2006.','e5b6e0a470ab84747717c91f908cd81a5669cd01921717cf1562ec634ce1cc74','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b456e2131623aa3188876df5d457ef4ebf120bb206e134cea93d0d9fefa2371',2010,'MW','Malawi','transnational-issues',1003,'Disputes — international: claims Bassas
da India, Europa Island, Glorioso Islands,
and Juan de Nova Island (all administered
by France)
Illicit drugs: illicit producer of cannabis
(cultivated and wild varieties) used mostly
for domestic consumption; transshipment
point for heroin
Disputes— international: disputes with
Tanzania over the boundary in Lake Nyasa
(Lake Malawi) and the meandering Songwe
River remain dormant
424','b6c50ac69b871eb79d74289c7b0eb50e417a2e13a1daa302dcacfef4e9799e04','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebb419a3d2cd45b3188b2d597184e7d763811bf0402265505d671f4587c046f1',2010,'MY','Malaysia','transnational-issues',1014,'Disputes— international: Malaysia has
asserted sovereignty over the Spratly Islands
together with China, Philippines, Taiwan,
Vietnam, and possibly Brunei; while the
2002 “Declaration on the Conduct of
Parties in the South China Sea” has eased
tensions over the Spratly Islands, it is
not the legally binding “code of conduct”
sought by some parties; Malaysia was not
party to the March 2005 joint accord among
the national oil companies of China, the
Philippines, and Vietnam on conducting
marine seismic activities in the Spratly
Islands; disputes continue over deliveries
of fresh water to Singapore, Singapore’s
land reclamation, bridge construction,
and maritime boundaries in the Johor and
Singapore Straits; in November 2007, the
ICJ will hold public hearings in response to
the memorials and countermemorials filed
by the parties in 2003 and 2005 over sover¬
eignty of Pedra Branca Island/Pulau Batu
Puteh, Middle Rocks and South Ledge; ICJ
awarded Ligitan and Sipadan islands, also
claimed by Indonesia and Philippines, to
Malaysia but left maritime boundary and
•sovereignty of Unarang rock in the hydro¬
carbon-rich Celebes Sea in dispute; separa¬
tist violence in Thailand’s predominandy
Muslim southern provinces prompts
measures to close and monitor border with
Malaysia to stem terrorist activities; Philip¬
pines retains a dormant claim to Malaysia’s
Sabah State in northern Borneo; Brunei
and Malaysia agreed in September 2008
428','e4c134cd133334a7e06112d99ee3dbfa6d384ebd3cf3a750086dae71c38ae5a3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('179b7ed6d25773449db113711f47f8be6b437e474cacef4eaae730cc59edad59',2010,'MV','Maldives','transnational-issues',1015,'to resolve their offshore and deepwater
seabed dispute, resume hydrocarbon explo-
ration and renounce any territorial claims
on land; piracy remains a problem in the
Malacca Strait
Refugees and infernally displaced
persons: refugees (country of origin): 15,174
(Indonesia); 21,544 (Burma) (2007)
Trafficking in persons: current situation:
Malaysia is a destination and, to a lesser
extent, a source and transit country for
women and children trafficked for the
purpose of commercial sexual exploitation,
and men, women, and children for forced
Background: The Maldives was long a
sultanate, first under Dutch and then under
British protection. It became a republic
in 1968, three years after independence.
President Maumoon Abdul GAYOOM
dominated the islands’ political scene for
30 years, elected to six successive terms by
single-party referendums. Following riots
in the capital Male in August 2004, the
president and his government pledged to
embark upon democratic reforms including
a more representative political system and
expanded political freedoms. Progress was
sluggish, however, and many promised
reforms were slow to be realized. Nonethe-
less, political parties were legalized in 2005.
In June 2008, a constituent assembly-
termed the “Special Majlis”— finalized a
new constitution, which was ratified by the
president in August. The first-ever presi¬
dential elections under a multi-candidate,
multi-party system were held in October
2008. GAYOOM was defeated in a runoff
poll by Mohamed NASHEED, a political
activist who had been jailed several years
earlier by the former regime. Challenges
labor; Malaysia is mainly a destination
country for men, women, and children
who migrate willingly from South and
Southeast Asia to work, some of whom
are subjected to conditions of involuntary
servitude by Malaysian employers in the
domestic, agricultural, construction, plan¬
tation, and industrial sectors; to a lesser
extent, some Malaysian women, primarily
of Chinese ethnicity, are trafficked abroad
for commercial sexual exploitation
tier rating: Tier 2 Watch List— Malaysia
improved from Tier 3 to the Tier 2 Watch
List for 2008 when it enacted comprehensive
facing the new president include strength¬
ening democracy and combating poverty
and drug abuse.
Disputes — international : none
Refugees and internally displaced
persons: IDPs: 1,000-10,000 (December
2004 tsunami victims) (2007)
431
THE CIA WORLD FACTBOOK','9c940c3688def4a2803e71b3a93b00ee96c7fc0e78d394717d2bb5be502cf56d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caacd673021bb57c2fb22fbe7371e4e30a9c7153bcd0777d7ca4c2ad1357d2f7',2010,'ML','Mali','transnational-issues',1021,'Background: The Sudanese Republic and
Senegal became independent of France in
1 960 as the Mali Federation. When Senegal
withdrew after only a tew months, what
formerly made up the Sudanese Republic
was renamed Mali. Rule by dictatorship
was brought to a close in 1991 by a military
coup— led by the current president Amadou
TOURE— enabling Mali’s emergence as
one of the strongest democracies on the
continent. President Alpha KONARE won
Mali’s first democratic presidential elec¬
tion in 1992 and was reelected in 1997.
In keeping with Mali’s two-term consti¬
tutional limit, KONARE stepped down
in 2002 and was succeeded by Amadou
TOURE, who was subsequently elected to
a second term in 2007. The elections were
widely judged to be free and fair.','e2d02e333b0b643dd3f9b19a8d9d4816d891d0323251123e595f5f411e89eebc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99c8bc0d88644650e9f8783b3c37bdadc7fcd9eb764c327ca15830d709aa0fd5',2010,'MH','Marshall Islands','transnational-issues',1033,'Disputes — international: none
Illicit drugs: minor transshipment point
for hashish from North Africa to Western
Europe
Disputes — international: claims US terri¬
tory of Wake Island','cf9e8815601acef9c3cfaaab9dd1368d660b16edcef7e9da5781cd9d0708aba5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c29a2230d02a509cf347a1af4b5a7ec20395e990b3ec9b500f24999dddcef5b3',2010,'MR','Mauritania','transnational-issues',1038,'Background: Independent from France in
1960, Mauritania annexed the southern
third of the former Spanish Sahara (now
Western Sahara) in 1976, but relinquished
it after three years of raids by the Polisario
guerrilla front seeking independence for
the territory. Maaouya Ould Sid Ahmed
TAYA seized power in a coup in 1 984 and
ruled Mauritania with a heavy hand for
over two decades. A series of presidential
elections that he held were widely seen as
flawed. A bloodless coup in August 2005
deposed President TAYA and ushered in
a military council that oversaw a transition
to democratic rule. Independent candidate
Sidi Ould Cheikh ABDALLAHI was inau¬
gurated in April 2007 as Mauritania’s first
freely and fairly elected president. His term
ended prematurely in August 2008 when a
military junta deposed him and ushered in
a military council government. Meanwhile,
the country continues to experience ethnic
tensions among its black population (Afro-
Mauritanians) and White and Black Moor
(Arab-Berber) communities.','dc5d3d9a6048b5730800dd57bbc41f63333d61f92f6ca013a58a933190ada602','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a50fa910b8ed00fe27b9db16e3a3f8e3eb7d013b2186fecd3ea311be35960fea',2010,'YT','Mayotte','transnational-issues',1052,'Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use: arable land: NA%
permanent crops: NA%
other: NA%
Irrigated land: NA
Natural hazards: cyclones during rainy
season
Environment — current issues: NA
Geography — note: part of Comoro Archi¬
pelago (18 islands)
Disputes— international: claimed by','c28af8874d71b3b7b0e376e22b17cfb2b19f54b6f122c9b9b0945678cc457327','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb8c19072e92f59850280d6019eae6d1968109a3dac6503441cecd84568443ef',2010,'MX','Mexico','transnational-issues',1063,'Disputes — international: abundant rain¬
fall in recent years along much of the
Mexico-US border region has ameliorated
periodically strained water-sharing arrange¬
ments; the US has intensified security
measures to monitor and control legal and
illegal personnel, transport, and commodi¬
ties across its border with Mexico; Mexico
must deal widi thousands of impoverished
Guatemalans and other Central Americans
who cross the porous border looking for
work in Mexico and the United States
Refugees and internally displaced
persons: IDPs: 5,500-10,000 (govern¬
ment’s quashing of Zapatista uprising in
1994 in eastern Chiapas Region) (2007)
Illicit drugs: major drug-producing nation;
cultivation of opium poppy in 2007 rose to
6,900 hectares yielding a potential produc¬
tion of 18 metric tons of pure heroin, or
50 metric tons of “black tar” heroin, the
dominant form of Mexican heroin in the
western United States; marijuana cultiva¬
tion increased to 8,900 hectares in 2007
and yielded a potential production of
15,800 metric tons; government conducts
the largest independent illicit-crop eradica¬
tion program in the world; continues as the
primary transshipment country for US-
bound cocaine from South America, with
an estimated 90% of annual cocaine move¬
ments toward the US stopping in Mexico;
major drug syndicates control the majority
of drug trafficking throughout the country;
producer and distributor of ecstasy; signifi¬
cant money-laundering center; major
supplier of heroin and largest foreign
supplier of marijuana and methampheta-
mine to the US market (2007)
451
THE CIA WORLD FACTBOOK','423b6882c82607d8bb28514d05d4d0bcba43dc5d30e6c5c45f7ff7d3cec1fd83','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b2f86619f61d4ffdd96176f7adfed9beec4c960db7ab5e4de41dac1394b149b',2010,'FM','Micronesia, Federated States of','transnational-issues',1064,'Background: In 1979 the Federated States
of Micronesia, a UN Trust Territory under
US administration, adopted a constitution.
In 1 986 independence was attained under
a Compact of Free Association with the
US, which was amended and renewed in
2004. Present concerns include large-scale
unemployment, overfishing, and overde¬
pendence on US aid.
Disputes— international : none
Illicit drugs: major consumer of cannabis
MOLDOVA','e96616ea7d75d782f0644f59a88ec2a95da93ab8ead107c54891f78ac476ef94','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('206beddc638121381e8218167ac11f739405f506b474fcf63bf86c933fe14429',2010,'MC','Monaco','transnational-issues',1077,'Disputes — international: Moldova and
Ukraine operate joint customs posts to
monitor the transit of people and commod¬
ities through Moldova’s break-away
the principality’s mild climate, splendid
scenery, and gambling facilities have made
Monaco world famous as a tourist and
recreation center.
Disputes— international: none','7a42880400f08e777360f068cfdb857ecb41e10b6af871fc6ab41fcf39061845','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e824742f0e6f3dc77bcd7b602fe664a4cc779cd02a11dc54bd5534968b3e3fc3',2010,'MS','Montserrat','transnational-issues',1095,'Disputes— international : none
Refugees and infernally displaced
persons: refugees (country of origin): 7,000
(Kosovo); note— mostly ethnic Serbs and
Roma who fled Kosovo in 1 999
IDPs: 16,192 (ethnic conflict in 1999 and
riots in 2004) (2007)
Trafficking in persons: current situation:
Montenegro is primarily a transit country
for the trafficking of women and girls
to Western Europe for the purpose of
commercial sexual exploitation; women
and girls from tire Balkans and Eastern
Europe are trafficked across Montenegro
to Western European countries
tier rating: Tier 2 Watch List— Montenegro
is on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat trafficking in persons in 2007;
public attention to the issue of traf¬
ficking has diminished considerably in
Montenegro in recent years (2008)
Background: English and Irish colonists
from St. Kitts first settled on Montserrat
in 1632; the first African slaves arrived
three decades later. The British and French
fought for possession of the island for
most of the 1 8th century, but it finally was
confirmed as a British possession in 1783.
The island’s sugar plantation economy was
converted to small farm landholdings in
the mid-19th century. Much of this island
was devastated and two-thirds of the popu¬
lation fled abroad because of the eruption
of the Soufriere Hills Volcano that began
on 18 July 1995. Montserrat has endured
volcanic activity since, with the last eruption
occurring in July 2003.','0ada4094d3f648fd6bd625dc8174dca7f5c3cb5facaeada6dd3ffd11919f678c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33df9f2ac5a442b48ada0836d71f10eec5e9cca570556d43e41e6c27f0466a4c',2010,'MA','Morocco','transnational-issues',1103,'Disputes — international : none
Illicit drugs: transshipment point for
South American narcotics destined for the
US and Europe','c10f41b3617bb441fb56441762fb102a8237ffd79127d0fd42d8bfb2005e34bd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('554d52f77d446f8f567dfadd00efe56822941ae9bf944bc3a8bd471673c2c6de',2010,'MZ','Mozambique','transnational-issues',1108,'Disputes— international: claims and
administers Western Sahara whose sover¬
eignty remains unresolved— UN-adminis¬
tered cease-fire has remained in effect since
September 1991, but attempts to hold a
referendum have failed and parties thus
far have rejected all brokered proposals;
Morocco protests Spain’s control over
the coastal enclaves of Ceuta, Melilla, and
Penon de Velez de la Gomera, the islands
of Penon de Alhucemas and Islas Chafa-
rinas, and surrounding waters; discussions
have not progressed on a comprehensive
maritime delimitation, setting limits on
resource exploration and refugee interdic¬
tion, since Morocco’s 2002 rejection of
Spain’s unilateral designation of a median
line from the Canary Islands; Morocco
serves as one of the primary launching
areas of illegal migration into Spain from
North Africa
Illicit drugs: one of the world’s largest
producers of illicit hashish; shipments
of hashish mostly directed to Western
Europe; transit point for cocaine from
South America destined for Western
Europe; significant consumer of
cannabis
Background: Almost five centuries as a
Portuguese colony came to a close with inde¬
pendence in 1975. Large-scale emigration,
economic dependence on South Africa, a
severe drought, and a prolonged civil war
hindered the country’s development until
the- mid-1990s. The ruling Front for the
Liberation of Mozambique (FRELIMO)
party formally abandoned Marxism in
1 989, and a new constitution the following
year provided for multiparty elections and
a free market economy. A UN-negotiated
peace agreement between FRELIMO and
rebel Mozambique National Resistance
(RENAMO) forces ended the fighting in
1992. In December 2004, Mozambique
underwent a delicate transition as Joaquim
CHISSANO stepped down after 18 years
in office. His elected successor, Armando
Emilio GUEBUZA, promised to continue
the sound economic policies that have
encouraged foreign investment. Mozam¬
bique has seen very strong economic
growdi since the end of the civil war largely
due to post-conflict reconstruction.
Disputes — international: none
Trafficking in persons: current situation:
Mozambique is a source and, to a much
lesser extent, a destination country for
men, women, and children trafficked for
the purposes of forced labor and sexual
exploitation; the use of forced and bonded
child laborers is a common practice in
Mozambique’s rural areas; women and
girls are trafficked from rural to urban
areas of Mozambique, as well as to South
Africa, for domestic servitude and commer¬
cial sexual exploitation; young men and
boys are trafficked to South Africa for farm
work and mining
tier rating: Tier 2 Watch List— for the second
consecutive year, Mozambique is on the
Tier 2 Watch List for its failure to provide
evidence of increasing efforts to combat
human trafficking in 2007; while the
government conducted investigations into
cases of human trafficking, there were no
prosecutions or convictions of traffickers;
government efforts to protect victims of
trafficking continued to suffer from limited
resources and a lack of political commit¬
ment (2008)
Illicit drugs: southern African transit
point for South Asian hashish and heroin,
and South American cocaine probably
destined for the European and South
African markets; producer of cannabis
(for local consumption) and methaqualone
(for export to South Africa); corruption
and poor regulatory capability makes the
banking system vulnerable to money laun¬
dering, but the lack of a well-developed
financial infrastructure limits the country’s
utility as a money-laundering center
474','364359e52eda97092db921d9aa4ed5ee146bdfd4522c5b9d5a89a2aad3ab7bf2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d58b02659f47421f69e91bc21d6e02e5dd58fcf89ae14315459133acee925fc',2010,'NA','Namibia','transnational-issues',1120,'Disputes — international: concerns from
international experts and local popula¬
tions over the Okavango Delta ecology
in Botswana and human displacement
scuttled Namibian plans to construct a
hydroelectric dam on Popa Falls along
the Angola-Namibia border; managed
dispute with South Africa over the loca¬
tion of the boundary in the Orange
River; Namibia has supported, and in
2004 Zimbabwe dropped objections to,
plans between Botswana and Zambia to
build a bridge over the Zambezi River,
thereby de facto recognizing a short, but
not clearly delimited, Botswana-Zambia
boundary in the river
Refugees and internally displaced
persons: refugees ( country of origin): 4,700
(Angola) (2007)','51282d5527b8131d0ad3dc2c11225fd929bb5d2e4aa99736e3609cd9cad33eb8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2b865039f9708bb0c2db5f2b2bb9872dcfcd8fc1c6ba89279c4c5e02f5a374d',2010,'NP','Nepal','transnational-issues',1135,'Disputes — international: joint border
commission continues to work on
contested sections of boundary with India,
including the 400 square kilometer dispute
over the source of the Kalapani River; India
has instituted a stricter border regime to
restrict transit of Maoist insurgents and
illegal cross-border activities; approxi¬
mately 106,000 Bhutanese Lhotshampas
(Hindus) have been confined in refugee
camps in southeastern Nepal since 1990
Refugees and internally displaced
persons:
refugees ( country of origin): 107,803
(Bhutan); 20,153 (Tibet/China)
lDPs: 50,000-70,000 (remaining from
ten-year Maoist insurgency that officially
ended in 2006; displacement spread
across the country) (2007)
Illicit drugs: illicit producer of cannabis
and hashish for the domestic and inter¬
national drug markets; transit point for
opiates from Southeast Asia to the West','73f1f0c0378126403738c8fe5ab512aa37a2c24d7c7097e36cdff84433f0f3e7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b880986c0e238d36b759bc4ae134405565aa60e739081868f84fe4f192d6220',2010,'NC','New Caledonia','transnational-issues',1136,'Background: Settled by both Britain and
France during the first half of the 19th
century, the island was made a French
possession in 1853. It served as a penal
colony for four decades after 1864.
Agitation for independence during the
1980s and early 1990s ended in the 1998
Noumea Accord, which over a period of
15 to 20 years will transfer an increasing
amount of governing responsibility from
France to New Caledonia. The agreement
also commits France to conduct as many as
three referenda between 2013 and 2018,
to decide whether New Caledonia should
assume full sovereignty and independence.
Disputes — international: Matthew and
Hunter Islands east of New Caledonia
claimed by France and Vanuatu','628e1de1577b03bf1c19789b9588d0f945bb4f93ad23147c3bde5e77abe55a00','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73f5abd80754832144058059ee7aea4715e5f3a0b93f436133ce4487e9d1bb2f',2010,'NI','Nicaragua','transnational-issues',1150,'Disputes — international: asserts a territo¬
rial claim in Antarctica (Ross Dependency)
Illicit drugs: significant consumer of
amphetamines
Disputes— international: memorials and
countermemorials were filed by the parties
in Nicaragua’s 1999 and 2001 proceedings
against Honduras and Colombia at the ICJ
over the maritime boundary and territorial
claims in the western Caribbean Sea, final
public hearings are scheduled for 2007;
the 1992 ICJ ruling for El Salvador and
Honduras advised a tripartite resolution to
establish a maritime boundary in the Gulf
of Fonseca, which considers Honduran
access to the Pacific; legal dispute over navi¬
gational rights of San Juan River on border
with Costa Rica
Illicit drugs: transshipment point for
cocaine destined for the US and transship¬
ment point for arms-for-drugs dealing
498','3ae7a6051f0797a26450b38988d5ac628e71717d43123891ba11b5506cc94834','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92ab9892345b939eaf25aa6bbbdcbc2025199f2c98719e0ee943eb8886f2980f',2010,'NE','Niger','transnational-issues',1159,'Disputes— international: Libya claims
about 25,000 sq km in a currently dormant
dispute in the Tommo region; much of
Benin-Niger boundary, including tripoint
with Nigeria, remains undemarcated; only
Nigeria and Cameroon have heeded the
Lake Chad Commission’s admonition to
ratify the delimitation treaty which also
includes the Chad-Niger and Niger-Nigeria
boundaries
Trafficking in persons: current situation:
Niger is a source, transit, and destination
country for children and women traf¬
ficked for forced labor and sexual exploi¬
tation; caste-based slavery practices, rooted
in ancestral master-slave relationships,
continue in isolated areas of the country—
an estimated 8,800 to 43,000 Nigeriens
live under conditions of traditional slavery;
children are trafficked within Niger for
forced begging, forced labor in gold mines,
domestic servitude, sexual exploitation,
and possibly for forced labor in agriculture
and stone quarries; women and children
from neighboring states are trafficked to
501
THE CIA WORLD FACTBOOK
and through Niger for domestic servitude,
sexual exploitation, forced labor in mines
and on farms, and as mechanics and
welders
tier rating: Tier 2 Watch List— Niger is on the
Tier 2 Watch List for its failure to provide','78a1a39da35c7dad1b456d2748999a2554b6894f6e80f295fd07f1f78cf910cf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fb6290253e257b4a8d4fd09b6c64cdcbf87a6db5569b2407980ef539238dedb',2010,'NU','Niue','transnational-issues',1168,'Disputes— international: Joint Border
Commission with Cameroon reviewed
2002 ICJ ruling on the entire boundary
and bilaterally resolved differences,
including June 2006 Greentree Agreement
that immediately cedes sovereignty of the
Bakassi Peninsula to Cameroon with a
phase-out of Nigerian control within two
years while resolving patriation issues; the
ICJ ruled on an equidistance settlement of
Cameroon-Equatorial Guinea-Nigeria mari¬
time boundary in the Gulf of Guinea, but
imprecisely defined coordinates in the ICJ
decision and a sovereignty dispute between
Equatorial Guinea and Cameroon over an
island at the mouth of the Ntem River all
contribute to the delay in implementation;
only Nigeria and Cameroon have heeded
the Lake Chad Commission’s admonition
to ratify the delimitation treaty which also
includes the Chad-Niger and Niger-Nigeria
boundaries
Refugees and internally displaced
persons: refugees ( country of origin ): 5,778
(Liberia)
IDPs: undetermined (communal violence
between Christians and Muslims since
President OBASANJO’s election in 1999;
displacement is mostly short-term) (2007)
Illicit drugs: a transit point for heroin and
cocaine intended for European, East Asian,
and North American markets; consumer
of amphetamines; safe haven for Nige¬
rian narcotraffickers operating worldwide;
major money-laundering center; massive
corruption and criminal activity; Nigeria
has improved some anti-money-laun-
dering controls, resulting in its removal
from the Financial Action Task Force’s
(FATF’s) Noncoopera tive Countries and
Territories List in June 2006; Nigeria’s
anti-money-laundering regime continues to
be monitored by FATF
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast
trade winds
Terrain: steep limestone cliffs along coast,
central plateau
Elevation extremes: lowest point: Pacific
Ocean 0 m
505
THE CIA WORLD FACTBOOK
highest point: unnamed location near
Mutalau settlement 68 m
Natural resources: fish, arable land
Land use: arable land: 11.54%
permanent crops: 15.38%
other: 73.08% (2005)
Irrigated land: NA
Natural hazards: typhoons
Environment — current issues: increasing
attention to conservationist practices to
counter loss of soil fertility from traditional
slash and burn agriculture
Environment— international
agreements: party to: Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Law of the Sea,
Ozone Layer Protection
Geography — note: one of world’s largest
coral islands','fef2e59a6f776f0005619ceedd70fe99005af05517fe6b2fdb49ff0bb23e42de','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('927c7e235a96e651fa23cffba880b68cc6a843c604facf5eac307bbc643ea331',2010,'NF','Norfolk Island','transnational-issues',1174,'Disputes— international: none
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 1 00% (2005)
Irrigated land: NA
Natural hazards:
typhoons (especially May to July)
Environment — current issues: NA
Geography — note: most of die 32 km
coastline consists of almost inaccessible
cliffs, but the land slopes down to the sea
507
THE CIA WORLD FACTBOOK
in one small southern area on Sydney Bay,
where the capital of Kingston is situated','fd9db46593efe1a80d23d11901df3fca1291b5211bb516b60307167a04aadfac','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33fe7fd4cc91ca208d8368730dfb4c2f4deca7bbaed49a4b08466c6642bc996d',2010,'NO','Norway','transnational-issues',1186,'Disputes — international: none
Disputes — international: Norway asserts
a territorial claim in Antarctica (Queen
Maud Land and its continental shelf);
despite dialogue, Russia and Norway
continue to dispute their maritime limits in
the Barents Sea and Russia’s fishing rights
beyond Svalbard’s territorial limits within
the Svalbard Treaty zone
514','14e3f59d7c0ec89add82c4ab1b0ffe7950fbe5f964e5e7ad61b8d6e31e03455e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa98fe84923a3b76cff12111f45fe1c596b3ab4f933c4ec631298000236933c',2010,'OM','Oman','transnational-issues',1195,'Disputes — international: boundary agree¬
ment reportedly signed and ratified with
UAE in 2003 for entire border, including
Oman’s Musandam Peninsula and A1
Madhah exclave, but details of the align¬
ment have not been made public
Trafficking in persons: current situation:
Oman is a destination country for men and
women primarily from Bangladesh, India,
Sri Lanka, and Pakistan who migrate will¬
ingly, but some of whom become victims of
trafficking when subjected to conditions of
involuntary servitude as domestic workers
and laborers; mistreatment includes non¬
payment of wages, restrictions on move¬
ment and withholding of passports, threats,
and physical or sexual abuse; Oman may
also be a destination country for women
from Asia, Eastern Europe, and North
Africa for commercial sexual exploitation
tier rating: Tier 3— Oman was rated as Tier
3 for the second consecutive year because
it did not report any law enforcement
efforts to prosecute and punish trafficking
offenses in 2007 and continues to lack
victim protection services or a systematic
procedure to identify victims of trafficking
(2008)
517
PACIFIC OCEAN
Disputes — international: some maritime
disputes (see littoral states)
518','2ddbeaa0dc40b3f9ce27f717dc147018d04a8e5914f4cf12625d6ca152acffc4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d84e33232ecb176d10dc5b2de8d670a151de45571af5cfd6cb1705673ac86484',2010,'PK','Pakistan','transnational-issues',1197,'Background: The Indus Valley civilization,
one of the oldest in the world and dating
back at least 5,000 years, spread over much
of what is presently Pakistan. During the
second millennium B.C., remnants of this
culture fused with the migrating Indo-Aryan
peoples. The area underwent successive
invasions in subsequent centuries from the
Persians, Greeks, Scythians, Arabs (who
brought Islam), Afghans, and Turks. The
Mughal Empire flourished in the 1 6th and
17th centuries; the British came to domi¬
nate the region in the 18th century. The
separation in 1947 of British India into the
Muslim state of Pakistan (with West and
East sections) and largely Hindu India was
never satisfactorily resolved, and India and
Pakistan fought two wars— in 1947 through
48, and 1965— over the disputed Kashmir
territory. A third war between these coun¬
tries in 1971— in which India capitalized
on Islamabad’s marginalization of Bengalis
in Pakistani politics— resulted in East
Pakistan becoming the separate nation of
Bangladesh. In response to Indian nuclear
weapons testing, Pakistan conducted its
own tests in 1998. The dispute over the
state of Kashmir is ongoing, but discus¬
sions and confidence-building measures
have led to decreased tensions since 2002.
Mounting public dissatisfaction with Presi¬
dent MUSHARRAF, coupled with the
assassination of the prominent and popular
political leader, Benazir BHUTTO, in late
2007, and MUSHARRAF’s resignation in
August 2008, led to the September presi¬
dential election of Asif ZARDARI, BHUT-
TO’s widower. Pakistani government and
military leaders are struggling to control
Islamist militants, many of whom are
located in the tribal areas adjacent to die
border with Afghanistan. The November
2008 Mumbai attacks again inflamed Indo-
Pakistan relations. The Pakistani Govern¬
ment is also faced with a deteriorating
economy as foreign exchange reserves
decline, the currency depreciates, and the
current account deficit widens.
Disputes— international: various talks
and confidence-building measures
cautiously have begun to defuse tensions
over Kashmir, particularly since the
October 2005 earthquake in the region;
Kashmir nevertheless remains the site of
the world’s largest and most militarized
territorial dispute with portions under the
de facto administration of China (Aksai
Chin), India (Jammu and Kashmir), and
Pakistan (Azad Kashmir and Northern
Areas); UN Military Observer Group in
India and Pakistan (UNMOGIP) has main¬
tained a small group of peacekeepers since
1949; India does not recognize Pakistan’s
ceding historic Kashmir lands to China
in 1964; India and Pakistan have main¬
tained their 2004 cease fire in Kashmir
and initiated discussions on defusing the
armed stand-off in the Siachen glacier
region; Pakistan protests India’s fencing
the highly militarized Line of Control and
construction of the Baglihar Dam on the
Chenab River in Jammu and Kashmir,
which is part of the larger dispute on
water sharing of the Indus River and its
tributaries; to defuse tensions and prepare
for discussions on a maritime boundary,
India and Pakistan seek technical reso¬
lution of the disputed boundary in Sir
Creek estuary at the mouth of the Rann of
Kutch in the Arabian Sea; Pakistani maps
continue to show the Junagadh claim in
India’s Gujarat State; by 2005, Pakistan,
with UN assistance, repatriated 2.3 million
Afghan refugees leaving slightly more than
a million, many of whom remain at their
own choosing; Pakistan has proposed and
Afghanistan protests construction of a fence
and laying of mines along portions of their
porous border; Pakistan has sent troops
into remote tribal areas to monitor and
control the border with Afghanistan and to
stem terrorist or other illegal activities
Refugees and internally displaced
persons: refugees ( country of origin ):
1,043,984 (Afghanistan)
IDPs: undetermined (government strikes
on Islamic militants in South Waziristan);
34,000 (October 2005 earthquake; most
of those displaced returned to their home
villages in the spring of 2006) (2007)
Illicit drugs: significant transit area
for Afghan drugs, including heroin,
opium, morphine, and hashish, bound
for Iran, Western markets, the Gulf States,
Africa, and Asia; financial crimes related to
drug trafficking, terrorism, corruption, and
smuggling remain problems; opium poppy
cultivation estimated to be 2,300 hectares
in 2007 with 600 of those hectares eradi¬
cated; federal and provincial authorities
continue to conduct anti-poppy campaigns
that utilizes forced eradication, fines, and
arrests
522','5cc44f458a0ca5a6bd5ed27b093b1f593c1b3260d6418195cf4f0fdc7054864c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb3e9fb19d5ab1d5f0cde6b66e998b6c40b17b6311848b9774743f5149c89b86',2010,'PW','Palau','transnational-issues',1205,'. KAYAW5&.
,>MAHOS
MIMJ ISLANDS ■ ^
^ELEKEOKi
cmuueHm
■
somoftAi
mm :
?$mw
PuksAms
mama
QCMAH . t
t(M . Hmt
o m mm
$ m mm','bf19fbad621cdba8824b3f4cea521c050547089b7db9ba5bf54e01e589963e6b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('986d935f1a90376fc0bbe969d2ba440ed22ddb71aac7ed8362c00fa73cf4b5aa',2010,'PA','Panama','transnational-issues',1214,'Disputes— international: maritime deline¬
ation negotiations continue with Philip¬
pines, Indonesia
Trafficking in persons: current situation:
Panama is a source, transit, and destina¬
tion country for women and children traf¬
ficked for the purpose of commercial sexual
exploitation; the majority of victims are
Panamanian women and children trafficked
within the country into the sex trade; rural
children in Panama may be trafficked inter¬
nally to urban areas for labor exploitation
tier rating: Tier 2 Watch List— Panama is on
the Tier 2 Watch List for failing to show
evidence of increasing efforts to combat
human trafficking, particularly with respect
to prosecuting, convicting, and sentencing
human traffickers for their crimes, and for
failing to provide adequate victim assist¬
ance (2008)
Illicit drugs: major cocaine transshipment
point and primary money-laundering center
for narcotics revenue; money-laundering
activity is especially heavy in the Colon
Free Zone; offshore financial center; negli¬
gible signs of coca cultivation; monitoring
of financial transactions is improving; offi¬
cial corruption remains a major problem
Geographic coordinates: 6 00 s, 147 00 E
Map references: Oceania
Area: total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area — comparative: slightly larger than
California
Land boundaries: total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
528','9c1e86cac5af923ee29493a73c479a64f75178ab3baf0fc7c1772fe5489ecb1f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('610aacbee67b5d5e43b42405dbe4108228764e3d737b0991b8158e09f61ad632',2010,'PG','Papua New Guinea','transnational-issues',1220,'Disputes — international: organized illegal
narcotics operations in Colombia operate
within the remote border region with
wait** rAg&te
IIIMlIMIlil
W . m . im r
iiiiii
illiillii
Wewak*
''
Ratau,
*«G ."''•kjt
ls%
Mount
Hagen
/ ~ PORT . ;
0»>i‘ MORESBY
. * £ 4,
8ougmr?vi%&
- A. '';;,
, -
k , ■
AmtmttK
Maritime claims: measured from claimed
archipelagic baselines
territorial sea : 12 nm
continental shelf: 200 m depth or to the
depth of exploitation
exclusive fishing zone: 200 nm
Climate: tropical; northwest monsoon
(December to March), southeast monsoon
(May to October); slight seasonal tempera¬
ture variation
Terrain*, mosdy mountains with coastal
lowlands and rolling foothills
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver,
natural gas, timber, oil, fisheries
Land use: arable land: 0.49%
permanent crops: 1 .4%
other: 98.11% (2005)
Irrigated land: NA
Total renewable water resources: 801 cu
km (1987)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.1 cu km/yr
(56%/43%/l%)
per capita: 17 cu m/yr (1987)
Natural hazards: active volcanism; situated
along the Pacific “Ring of Fire”; the country
is subject to frequent and sometimes severe
earthquakes; mud slides; tsunamis
Environment — current issues: rain forest
subject to deforestation as a result of
growing commercial demand for tropical
timber; pollution from mining projects;
severe drought
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: shares island of New
Guinea with Indonesia; one of world’s
largest swamps along southwest coast
Disputes — international: relies on assist¬
ance from Australia to keep out illegal
cross-border activities from primarily Indo¬
nesia, including goods smuggling, illegal
narcotics trafficking, and squatters and
secessionists
Refugees and internally displaced
persons: refugees ( country of origin): 10,177
(Indonesia) (2007)
Trafficking in persons: current situation .-
Papua New Guinea is a country of desti¬
nation for women and children from
Malaysia, the Philippines, Thailand,
and China trafficked for the purpose of
commercial sexual exploitation; internal
trafficking of women and children for the
purposes of sexual exploitation and invol¬
untary domestic servitude occurs as well
tier rating: Tier 3— Papua New Guinea does
not fully comply with the minimum stand¬
ards for the elimination of trafficking and is
not making significant efforts to do so; the
current legal framework does not contain
elements of crimes that characterize traf¬
ficking; the government lacks victim protec¬
tion services or a systematic procedure to
identify victims of trafficking; the govern¬
ment did not prosecute anyone in 2007 for
trafficking; Papua New Guinea has not rati¬
fied the 2000 UN TIP Protocol (2008)
Illicit drugs: major consumer of cannabis
531
THE CIA WORLD FACTBOOK
I
PARACEL ISLANDS
Background: The Paracel Islands are
surrounded by productive fishing grounds
and by potential oil and gas reserves. In
1932, French Indochina annexed the
islands and set up a weather station on
Pattle Island; maintenance was continued
by its successor, Vietnam. China has
occupied the Paracel Islands since 1974,
when its troops seized a South Vietnamese
garrison occupying the western islands.
China built a military installation on
Mischief Reef in 1999. The islands are
claimed by Taiwan and Vietnam.
Disputes— international: occupied
by China, also claimed by Taiwan and
Vietnam','56dd0eeff4e10fbbcb9a824f5a8209ca5bacc9e3466cdd6d512cf6b891b5e640','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63a465bc9b217e40df5ba3ef729388d4e12e0f7e6bb142f510b1333a0a49e3ab',2010,'PE','Peru','transnational-issues',1234,'Disputes — international: unruly region at
convergence of Argentina-Brazil-Paraguay
borders is locus of money laundering,
smuggling, arms and illegal narcotics traf¬
ficking, and fundraising for extremist
organizations
Illicit drugs: major illicit producer of
cannabis, most or all of which is consumed
in Brazil, Argentina, and Chile; transship¬
ment country for Andean cocaine headed
for Brazil, other Southern Cone markets,
and Europe; weak border controls, exten¬
sive corruption and money-laundering
activity, especially in the Tri-Border Area;
weak anti-money-laundering laws and
enforcement
Disputes — international: Chile and
Ecuador rejected Peru’s November 2005
unilateral legislation to shift the axis of
their joint treaty-defined maritime bound¬
aries along the parallels of latitude to equi¬
distance lines which favor Peru; organized
illegal narcotics operations in Colombia
have penetrated Peru’s shared border;
Peru rejects Bolivia’s claim to restore
538','5e86ff1bbcf8f02033c27a90be4ca64ef4e8501830512a4ba03d957307c181bb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86a58ed4ce28e2620e27064687260aa8c15f69efec3d6edad865ed9fc7f6f07a',2010,'PH','Philippines','transnational-issues',1238,'maritime access through a sovereign
corridor through Chile along the Peru¬
vian border
Refugees and internally displaced
persons: lDPs : 60,000-150,000 (civil war
from 1980-2000; most IDPs are indig¬
enous peasants in Andean and Amazonian
regions) (2007)
Illicit drugs: until 1996 the world’s largest
coca leaf producer, Peru is now the world’s
second largest producer of coca leaf,
though it lags far behind Colombia; culti¬
vation of coca in Peru declined to 36,000
hectares in 2007; second largest producer
of cocaine, estimated at 210 metric tons of
potential pure cocaine in 2007; finished
cocaine is shipped out from Pacific ports to
the international drug market; increasing
amounts of base and finished cocaine,
however, are being moved to Brazil,
Chile, Argentina, and Bolivia for use in
the Southern Cone or transshipment to
Europe and Africa; increasing domestic
drug consumption
Disputes— international: Philippines
claims sovereignty over certain of the
Spratly Islands, known locally as the
Kalayaan (Freedom) Islands, also claimed
by China, Malaysia, Taiwan, and Vietnam;
the 2002 “Declaration on the Conduct of
Parties in the South China Sea,” has eased
tensions in the Spratly Islands but falls
short of a legally binding “code of conduct”
desired by several of the disputants; in
March 2005, the national oil companies
of China, the Philippines, and Vietnam
signed a joint accord to conduct marine
seismic activities in the Spratly Islands;
Philippines retains a dormant claim to
Malaysia’s Sabah State in northern Borneo
based on the Sultanate of Sulu’s granting
PITCAIRN ISLANDS
Land boundaries: 0 km
Coastline: 51 km
Maritime Claims: territorial sea: 3 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; modi¬
fied by southeast trade winds; rainy season
(November to March)
Terrain: rugged volcanic formation; rocky
coastline with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold, silver,
and zinc have been discovered offshore
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Natural hazards: typhoons (especially
November to March)
Environment — current issues: deforesta¬
tion (only a small portion of the original
forest remains because of burning and
clearing for settlement)
Geography— note: Britain’s most isolated
dependency; only the larger island of
Pitcairn is inhabited but it has no port or
natural harbor; supplies must be trans¬
ported by rowed longboat from larger ships
stationed offshore','e20a082f80126953cc05ac7ca93770fa4e437b5600c51a29f88a32486c10d755','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('863e72b2527d7c3fe9b7e5b35819aaa0f1e6bee9a4219cae69726f27c25624a8',2010,'PL','Poland','transnational-issues',1244,'Disputes— international: none
tolerant and progressive. Labor turmoil
in 1980 led to die formation of the inde¬
pendent trade union “Solidarity” that
over time became a political force and by
1990 had swept parliamentary elections
and the presidency. A “shock therapy”
program during the early 1990s enabled
the country to transform its economy into
544
one of the most robust in Central Europe,
but Poland still faces the lingering chal¬
lenges of high unemployment, underdevel¬
oped and dilapidated infrastructure, and a
poor rural underclass. Solidarity suffered
a major defeat in the 2001 parliamentary
elections when it failed to elect a single
deputy to the lower house of Parliament,
and the new leaders of the Solidarity Trade
Union subsequendy pledged to reduce the
Trade Union’s political role. Poland joined
NATO in 1999 and the European Union
in 2004. With its transformation to a
democratic, market-oriented country largely
completed, Poland is an increasingly active
member of Euro-Atlantic organizations.
Disputes— international: as a member
state that forms part of the EU’s external
border, Poland has implemented the strict
Schengen border rules to restrict illegal
immigration and trade along its eastern
borders with Belarus and Ukraine
Illicit drugs: despite diligent counternar-
cotics measures and international infor¬
mation sharing on cross-border crimes, a
major illicit producer of synthetic drugs for
the international market; minor transship¬
ment point for Southwest Asian heroin
and Latin American cocaine to Western
Europe','c35d56c8e6734b39f626ecdd31eb1b1defdfb2916bbefad39b03252de91a715d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8af92e3c01bc45623323a06e2818f9a54e8fbd6efe3f1a8632b1b54886398cb1',2010,'PT','Portugal','transnational-issues',1253,'Disputes— international: Portugal does
not recognize Spanish sovereignty over the
territory of Olivenza based on a difference
of interpretation of die 1815 Congress of
Vienna and the 1801 Treaty of Badajoz
Illicit drugs: seizing record amounts
of Latin American cocaine destined for
Europe; a European gateway for South¬
west Asian heroin; transshipment point
for hashish from North Africa to Europe;
consumer of Southwest Asian heroin
551
THE CIA WORLD FACTBOOK','14dc6dbbd4f3dbb2990434f67b52f7ca0283fe60f9e9e29ef37a7655366d8bdf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bae5ec7274c554f9eb5de967d4310599c2e1f45c5ab1b6be4ab4ca1da8b6bad6',2010,'PR','Puerto Rico','transnational-issues',1261,'Disputes— international: increasing
numbers of illegal migrants from the
Dominican Republic cross the Mona
Passage to Puerto Rico each year looking
for work
554
Background: Ruled by the al-Thani family
since the mid''1800s, Qatar transformed
itself from a poor British protectorate noted
mainly for pearling into an independent
state with significant oil and natural gas
revenues. During the late 1980s and early
1990s, the Qatari economy was crippled by
a continuous siphoning off of petroleum
revenues by the Amir, who had ruled the
country since 1972. His son, the current
Amir HAMAD bin Khalifa al-Thani, over¬
threw him in a bloodless coup in 1995.
In 2001, Qatar resolved its longstanding
border disputes with both Bahrain and
Saudi Arabia. As of 2007, oil and natural
gas revenues had enabled Qatar to attain
the second-highest per capita income in the
world.','14c37b1efd77fd5665694fa00348bb0b22ce5d3adf1a45c22c5341daeb03ca16','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ed3a72a8adcb781db753998e0ac49028e08737bb0aa3c43119634551834a85b',2010,'QA','Qatar','transnational-issues',1266,'Disputes — international: none
Trafficking in persons: current situation:
Qatar is a destination country for men and
women from South and Southeast Asia
who migrate willingly, but are subsequendy
trafficked into involuntary servitude as
domestic workers and laborers, and, to
a lesser extent, commercial sexual exploi¬
tation; the most common offense was
forcing workers to accept worse contract
terms than those under which they were
recruited; other conditions include bonded
labor, withholding of pay, restrictions on
movement, arbitrary detention, and phys¬
ical, mental, and sexual abuse
tier rating: Tier 3— Qatar failed, for the
second consecutive year, to enforce crim¬
inal laws against traffickers, or to provide
an effective mechanism to identify and
protect victims; it continues to detain
and deport victims rather than providing
them protection; the government made
little progress to increase prosecutions for
trafficking in a meaningful way in 2007;
workers complaining of working condi¬
tions or non-payment of wages were some¬
times penalized (2008)
557','e268f1d9c3f887a2ceb3179d2848d04f03649c0656627a1b08545d6a83075278','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86f7c62fa2c13744f65cd06cb7d36ea0ec7ff15cee9e15a6a665c65274fe6bc8',2010,'RO','Romania','transnational-issues',1267,'Background: The principalities of Walla-
chia and Moldavia— for centuries under
the suzerainty of the Turkish Ottoman
Empire— secured their autonomy in 1856;
they united in 1859 and a few years later
adopted the new name of Romania. The
country gained recognition of its independ¬
ence in 1878. It joined the Allied Powers
in World War I and acquired new territo¬
ries— most notably Transylvania— following
die conflict. In 1940, Romania allied
with the Axis powers and participated in
the 1941 German invasion of the USSR.
Three years later, overrun by the Soviets,
Romania signed an armistice. The post¬
war Soviet occupation led to the forma¬
tion of a Communist “people’s republic”
in 1947 and the abdication of the king.
The decades-long rule of dictator Nicolae
CEAUSESCU, who took power in 1965,
and his Securitate police state became
increasingly oppressive and draconian
through the 1980s. CEAUSESCU was
overthrown and executed in late 1989.
Former Communists dominated the
government until 1996 when they were
swept from power. Romania joined NATO
in 2004 and the EU in 2007.
Disputes— international: the ICJ gave
Ukraine until December 2006 to reply,
and Romania until June 2007 to issue a
rejoinder, in their dispute submitted in
2004 over Ukrainian-administered Zmiy-
inyy/Serpilor (Snake) Island and Black Sea
maritime boundary delimitation; Romania
also opposes Ukraine’s reopening of a
navigation canal from the Danube border
through Ukraine to the Black Sea
Illicit drugs: major transshipment point
for Southwest Asian heroin transiting the
Balkan route and small amounts of Latin
American cocaine bound for Western
Europe; although not a significant financial
center, role as a narcotics conduit leaves it
vulnerable to laundering, which occurs via
the banking system, currency exchange
houses, and casinos
RUSSIA
★MOSCOW
Saratov *P»m’
N*ua* •','b35b758f5eb543e2cc24d2901d8e88172611ee991077a71103aa77874cee451e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcbbf8ea54fbff2953413c2dc48b99ae3e6be7818af2b3e433b748029a2c3671',2010,'RU','Russian Federation','transnational-issues',1277,'Disputes — international: China and
Russia have demarcated the once disputed
islands at the Amur and Ussuri conflu¬
ence and in the Argun River in accord¬
ance with the 2004 Agreement, ending
their centuries-long border disputes; the
sovereignty dispute over the islands of
Etorofu, Kunashiri, Shikotan, and the
Habomai group, known in Japan as the
“Northern Territories” and in Russia as
the “Southern Kurils,” occupied by the
Soviet Union in 1945, now administered
by Russia, and claimed by Japan, remains
the primary sticking point to signing a
peace treaty formally ending World War
II hostilities; Russia and Georgia agree on
delimiting all but small, strategic segments
of the land boundary and the maritime
boundary; OSCE observers monitor vola¬
tile areas such as the Pankisi Gorge in the','b9e332d012a554df13ac4a0c86382e6a75b0ddef66f60fe8d73439aa5e7deb57','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('847ede4f82bf70e56e79af9266b8e321d68d7a62d8330d5a6d9514555cf150d7',2010,'RW','Rwanda','transnational-issues',1285,'Disputes— international: fighting among
ethnic groups - loosely associated political
rebels, armed gangs, and various govern¬
ment forces in Great Lakes region tran¬
scending the boundaries of Burundi,
Democratic Republic of the Congo,
Rwanda, and Uganda - abated substan¬
tially from a decade ago due largely to UN
peacekeeping, international mediation, and
efforts by local governments to create civil
societies; nonetheless, 57,000 Rwandan
refugees still reside in 21 African states,
including Zambia, Gabon, and 20,000
who fled to Burundi in 2005 and 2006 to
escape drought and recriminations from
traditional courts investigating the 1994
massacres; the 2005 DROC and Rwanda
border verification mechanism to stem
rebel actions on both sides of the border
remains in place
Refugees and internally displaced
persons: refugees ( country of origin): 46,272
(Democratic Republic of die Congo); 4,400
(Burundi) (2007)
569
SAINT BARTHELEMY
h Hwitxxi
f V >*
ta Peate
m’mftMmvxi
mfrMgm ^ toss mb#
iUf c/wa * • ''
f -M,;"
, '' i .
“ST6VIA*
MSwre ; \\ j
Ik Samt-
Barmismy
CMf&h''mr*','1b6a00772d622ae670ad192dba21f644e00c1a6317dbd2c6d04095c4679c23e1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0271210a5d1a940c1e72aa5f062d7c99978312c4a54912213ae453645a8e2b2e',2010,'KN','Saint Kitts and Nevis','transnational-issues',1299,'Disputes— international: none
Disputes — international: joins other
Caribbean states to counter Venezuela’s
claim that Aves Island sustains human
habitation, a criterion under UNCLOS,
which permits Venezuela to extend its
EEZ/continental shelf over a large portion
of the eastern Caribbean Sea
Illicit drugs: transshipment point for
South American drugs destined for the
US and Europe; some money-laundering
activity','253c8e34f0f20c19befe318f668f1ee4040c781a59d5a1acb401c16deeb40f68','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12936910bcf52784bb156c0469c82e2cfd36b826ae46884ed228de6924f785d9',2010,'LC','Saint Lucia','transnational-issues',1303,':
Background: The island, with its fine
natural harbor at Castries, was contested
between England and France throughout
the 1 7th and early 18th centuries (changing
possession 1 4 times); it was finally ceded to
the UK in 1814. Even after the abolition
of slavery on its plantations in 1834, Saint
Lucia remained an agricultural island,
dedicated to producing tropical commodity
crops. Self-government was granted in
1967 and independence in 1979.
Disputes — international: joins other
Caribbean states to counter Venezuela’s
claim that Aves Island sustains human
habitation, a criterion under UNCLOS,
which permits Venezuela to extend its
EEZ/ continental shelf over a large portion
of the eastern Caribbean Sea
Illicit drugs: transit point for South
American drugs destined for the US and
Europe
SAINT MARTIN','53398bbaeb0f96e90b45aea63e02c306f6b31c376e9bb946ededd6a61de5fd4e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0464f72ef11fd7a7bf37fb067cc5361e1a18beccf8b2ba2ab8139787f35f765f',2010,'VC','Saint Vincent and the Grenadines','transnational-issues',1318,'Background: Resistance by native Caribs
prevented colonization on St. Vincent
until 1719. Disputed between France and
the United Kingdom for most of the 18th
century, the island was ceded to the latter
in 1783. Between 1960 and 1962, Saint
Vincent and the Grenadines was a separate
administrative unit of the Federation of the
West Indies. Autonomy was granted in
1969 and independence in 1979.','13bfd30c696c7d6887ed0162f6f5403d5709b1722f9fe8bab2fcd762637e3870','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5443e9526f58b843ce6b099b75d1bda64f6168b7ac4fb981407d0df4c2a3d4c4',2010,'WS','Samoa','transnational-issues',1328,'Disputes— international: joins other
Caribbean states to counter Venezuela’s
claim that Aves Island sustains human
habitation, a criterion under UNCLOS,
which permits Venezuela to extend its
EEZ/ continental shelf over a large portion
of the eastern Caribbean Sea
Illicit drugs: transshipment point for South
American drugs destined for the US and
Europe; small-scale cannabis cultivation
Land boundaries: 0 km
Coastline: 403 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (November
to April), dry season (May to October)
Terrain: two main islands (Savaii, Upolu)
and several smaller islands and uninhabited
islets; narrow coastal plain with volcanic,
rocky, rugged mountains in interior
584
SOUmPAcmb
OCEAN
;y\\-- ''
t''-H
»&''<
Satefologa^
-• *#**» *Mul»fanua
APIA
&omw mcmc
OCEAN
?. . ?JLgm.&£ .
o te ao 3»wi
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili
(Savaii) 1,857 m
Natural resources: hardwood forests, fish,
hydropower
Land use: arable land: 21.13%
permanent crops: 24.3%
other: 54.57% (2005)
Irrigated land: NA
Natural hazards: occasional typhoons;
active volcanism
Environment — current issues: soil
erosion, deforestation, invasive species,
overfishing
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: occupies an almost
central position widfin Polynesia','3f22c9eb3914f7f2c71afe06486585e5d7633c648a6edc5ffe97aac01b1d4660','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8202ffcd99497e214b5a9d6e14175637c71f4774741db08b493b87585ce1aef8',2010,'SM','San Marino','transnational-issues',1336,'Disputes— international: none
Background: The third smallest state in
Europe (after the Holy See and Monaco),
San Marino also claims to be the world’s
oldest republic. According to tradition, it
was founded by a Christian stonemason
named Marinus in A.D. 301. San Mari¬
no’s foreign policy is aligned with that
of Italy; social and political trends in the
republic also track closely with those of its
larger neighbor.','7918dfcfd15ab259da4527dc5005ab6994a863f6be26e8989c4ed1d3be4af67d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a583fd8bcfe8dcfe002e6fcd58fad20a4754ae2a7d0873238624e56ac4ac49a',2010,'ST','Sao Tome and Principe','transnational-issues',1345,'Disputes — international: none
Disputes — international : none
591
THE CIA WORLD FACTBOO K','dafa02e310589bb321f9a8e83b77ecef72a94358648b32ba4f378c1d27c75eef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccaef50a4f96d74674ef4008a273a8663f4bd985784d4446e77b19c2beaef50a',2010,'RS','Serbia','transnational-issues',1356,'Background: The Kingdom of Serbs, Croats,
and Slovenes was formed in 1918; its name
was changed to Yugoslavia in 1929. Various
paramilitary bands resisted Nazi Germany’s
occupation and division of Yugoslavia from
1941 to 1945, but fought each other and
ethnic opponents as much as die invaders.
The military and political movement
headed by Josip TITO (Partisans) took full
control of Yugoslavia when German and
Croatian separatist forces were defeated
in 1945. Although Communist, TITO’s
new government and his successors (he
died in 1980) managed to steer their own
padi between the Warsaw Pact nations
and the West for the next four and a half
decades. In 1989, Slobodan MILOSEVIC
became president of the Serbian Republic
and his ultranationalist calls for Serbian
domination led to the violent breakup of
Yugoslavia along ethnic lines. In 1991,
Croatia, Slovenia, and Macedonia declared
independence, followed by Bosnia in
1992. The remaining republics of Serbia
and Montenegro declared a new Federal
Republic of Yugoslavia (FRY) in April 1992
and under MILOSEVIC’S leadership,
Serbia led various military campaigns to
unite ethnic Serbs in neighboring republics
into a “Greater Serbia.” These actions led
to Yugoslavia being ousted from the UN in
1992, but Serbia continued its— ultimately
unsuccessful— campaign until signing the
Dayton Peace Accords in 1995. MILOS¬
EVIC kept tight control over Serbia and
eventually became president of the FRY in
1997. In 1998, an ethnic Albanian insur¬
gency in the formerly autonomous Serbian
province of Kosovo provoked a Serbian
counterinsurgency campaign that resulted
in massacres and massive expulsions of
ethnic Albanians living in Kosovo. The
MILOSEVIC government’s rejection of a
proposed international settlement led to
NATO’s bombing of Serbia in the spring
of 1999 and to the eventual withdrawal
of Serbian military and police forces from
Kosovo in June 1999. UNSC Resolution
1 244 in June 1 999 authorized the stationing
of a NATO-led force (KFOR) in Kosovo to
provide a safe and secure environment for
the region’s ethnic communities, created
598
a UN interim Administration Mission in
Kosovo (UNMIK) to foster self-governing
institutions, and reserved the issue of
Kosovo’s final status for an unspecified date
in the future. In 2001, UNMIK promul¬
gated a constitutional framework that
allowed Kosovo to establish institutions
of self-government and led to Kosovo’s
first parliamentary election. FRY elec¬
tions in September 2000 led to the ouster
of MILOSEVIC and installed Vojislav
KOSTUNICA as president. A broad coali¬
tion of democratic reformist parties known
as DOS (die Democratic Opposition of
Serbia) was subsequendy elected to parlia¬
ment in December 2000 and took control
of the government. DOS arrested MILOS¬
EVIC in 2001 and allowed for him to
be tried in The Hague for crimes against
humanity. (MILOSEVIC died in March
2006 before the completion of his trial.) In
2001, the country’s suspension from the
UN was lifted. In 2003, the FRY became
Serbia and Montenegro, a loose federation
of the two republics with a federal level
parliament. Widespread violence predomi¬
nantly targeting ethnic Serbs in Kosovo
in March 2004 caused the international
community to open negotiations on the
future status of Kosovo in January 2006. In
May 2006, Montenegro invoked its right to
secede from the federation and— following a
successful referendum— it declared itself an
independent nation on 3 June 2006. Two
days later, Serbia declared that it was the
successor state to the union of Serbia and
Montenegro. A new Serbian constitution
was approved in October 2006 and adopted
the following month. After 15 months of
inconclusive negotiations mediated by the
UN and four months of further incon¬
clusive negotiations mediated by the US,
EU, and Russia, on 1 7 February 2008, the
UNMIK-administered province of Kosovo
declared itself independent of Serbia.
Disputes — international: Serbia with
several other states protest the U.S. and
other states’ recognition of Kosovo’s
declaring itself as a sovereign and inde¬
pendent state in February 2008; ethnic
Serbian municipalities along Kosovo’s
northern border challenge final status of
Kosovo-Serbia boundary; several thousand
NATO-led KFOR peacekeepers under
UNMIK authority continue to keep the
peace within Kosovo between the ethnic
Albanian majority and the Serb minority
in Kosovo; Serbia delimited about half
of the boundary with Bosnia and Herze¬
govina, but sections along the Drina River
remain in dispute
Refugees and internally displaced
persons: refugees (country of origin ): 71,111
(Croatia); 27,414 (Bosnia and Herze¬
govina); 206,000 (Kosovo), note— mosdy
ethnic Serbs and Roma who fled Kosovo
in 1999 (2007)
Illicit drugs: transshipment point for
Southwest Asian heroin moving to Western
Europe on the Balkan route; economy
vulnerable to money laundering
601
THE CIA WORLD FACTBOOK','5f3a5dfde8d9a438e4ddf931576adb1bd4aeb069b9dbcfa97d5792b7929e55ba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5399b6c9b2a760d01523b3c2bc465c3f8ab424b5cadcfd131c3ddc069f577811',2010,'SC','Seychelles','transnational-issues',1371,'Disputes— international: together with
Mauritius, Seychelles claims the Chagos
Archipelago (UK-administered British
Indian Ocean Territory)','6b2498001860cc850a614f0f2d005630a72e03cd83df6a623e636fedc8ce7385','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42b1dbe1aabe4ddd06918c36653f507d5f31d0ff3f3ff4d3261eda427811e929',2010,'SG','Singapore','transnational-issues',1380,'Disputes — international: as domestic
fighting among disparate ethnic groups,
rebel groups, warlords, and youth gangs in
Cote d’Ivoire, Guinea, Liberia, and Sierra
Leone gradually abate, the number of refu¬
gees in border areas has begun to slowly
dwindle; UN Mission in Sierra Leone
(UNAMSIL) has maintained over 4,000
peacekeepers in Sierra Leone since 1999;
Sierra Leone considers excessive Guinea’s
definition of the flood plain limits to define
the left bank boundary of the Makona and
Moa rivers and protests Guinea’s continued
occupation of these lands including the
hamlet of Yenga occupied since 1998
Refugees and internally displaced
persons: refugees ( country of origin): 27,311
(Liberia) (2007)
Disputes — international: disputes persist
with Malaysia over deliveries of fresh water
to Singapore, Singapore’s extensive land
reclamation works, bridge construction,
and maritime boundaries in the Johor and
Singapore Straits; in November 2007, the
ICJ will hold public hearings as a conse¬
quence of the Memorials and Counterme¬
morials filed by the parties in 2003 and
2005 over sovereignty of Pedra Branca
Island/Pulau Batu Puteh, Middle Rocks
and South Ledge; Indonesia and Singa¬
pore continue to work on finalization of
their 1973 maritime boundary agreement
by defining unresolved areas north of
Indonesia’s Batam Island; piracy remains
a problem in the Malacca Strait
Illicit drugs: drug abuse limited because
of aggressive law enforcement efforts; as a
transportation and financial services hub,
Singapore is vulnerable, despite strict laws
and enforcement, as a venue for money
laundering','a355a9cacf25b5a4d1ddb6e600fbb3ed18ee75579b5f05b57472a2c54f6a9d18','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae863ccafacd5e504a44e1a42e1f30c3aa5a7b5f01352df9bd9355278c0fa29d',2010,'SK','Slovakia','transnational-issues',1383,'INTRODUCTION SLOVAKIA
Background: The dissolution of the Austro-
Hungarian Empire at the close of World
War I allowed the Slovaks to join the
closely related Czechs to form Czechoslo¬
vakia. Following the chaos of World War
II, Czechoslovakia became a Communist
nation within Soviet-dominated Eastern
Europe. Soviet influence collapsed in 1 989
and Czechoslovakia once more became
free. The Slovaks and the Czechs agreed
to separate peacefully on 1 January 1993.
Slovakia joined both NATO and the EU
in the spring of 2004 and the eurozone on
1 January 2009.','f3ee2f3ab5eb085a074f802dfbb02be788e143551ecbef404cbe793d9fdbd069','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0943e2c800ef5e771d9d57964777ef0324985582ccb82bd93b50606ba70cdad',2010,'SI','Slovenia','transnational-issues',1390,'Disputes— international: bilateral
government, legal, technical and economic
working group negotiations continued in
2006 between Slovakia and Hungary over
Hungary’s completion of its portion of the
Gabcikovo-Nagymaros hydroelectric dam
project along the Danube; as a member
state that forms part of dre EU’s external
border, Slovakia has implemented the
strict Schengen border rules
Illicit drugs: transshipment point for
Souda west Asian heroin bound for Western
Europe; producer of synthetic drugs for
regional market; consumer of ecstasy
INTRODUCTION SLOVENIA
Background: The Slovene lands were part
of the Austro-Hungarian Empire until the
latter’s dissolution at the end of World War
I. In 1918, the Slovenes joined the Serbs
and Croats in forming a new multinational
state, which was named Yugoslavia in 1 929.
After World War II, Slovenia became
a republic of the renewed Yugoslavia,
which though Communist, distanced itself
from Moscow’s rule. Dissatisfied widr the
613
THE CIA WORLD FACTBOOK
exercise of power by the majority Serbs, the
Slovenes succeeded in establishing their
independence in 1991 after a short 10-day
war. Historical ties to Western Europe, a
strong economy, and a stable democracy
have assisted in Slovenia’s transformation
to a modern state. Slovenia acceded to both
NATO and the EU in the spring of 2004.','48154fce20d26b19144246afb9de41aa58d536a37c09b76d61e37313c56a4f22','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddecc06e7bd6e6995661d66e2633cce2925d69033744fef872832329985017a5',2010,'SB','Solomon Islands','transnational-issues',1396,'Disputes— international: the Croatia-
Slovenia land and maritime boundary
agreement, which would have ceded
most of Piran Bay and maritime access to
Slovenia and several villages to Croatia,
remains unratified and in dispute; Slovenia
also protests Croatia’s 2003 claim to an
exclusive economic zone in the Adriatic; as
a member state that forms part of the EU’s
external border, Slovenia has implemented
the strict Schengen border rules to curb
illegal migration and commerce through
southeastern Europe while encouraging
close cross-border ties with Croatia
Illicit drugs: minor transit point for
cocaine and Southwest Asian heroin
bound for Western Europe, and for
precursor chemicals
protectorate over the Solomon Islands
in the 1890s. Some of the bitterest
fighting of World War II occurred on
this archipelago. Self-government was
achieved in 1976 and independence two
years later. Ethnic violence, government
malfeasance, and endemic crime have
undermined stability and civil society.
In June 2003, then Prime Minister Sir
Allan KEMAKEZA sought the assistance
of Australia in reestablishing law and
order; the following month, an Austra¬
lian-led multinational force arrived to
restore peace and disarm ethnic militias.
The Regional Assistance Mission to the
Solomon Islands (RAMSI) has generally
been effective in restoring law and order
and rebuilding government institutions.
Disputes — international: since 2003,
the Regional Assistance Mission to die
Solomon Islands (RAMSI), consisting
of police, military, and civilian advisors
drawn from 1 5 countries, has assisted in
reestablishing and maintaining civil and
political order while reinforcing regional
stability and security
Refugees and internally displaced
persons: I DPs: 5,400 (displaced by tsunami
on 2 April 2007) (2007)
619
THE CIA WORLD FACTBOOK','bfeb1747f3d6bc9fbc9a2f754b6d8f8210109d060ba788ae79ad7a49055d2c96','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1b816c20e3cca471fa9ccf956acba97959b43c329ecf40229ef77543fedb630',2010,'ZA','South Africa','transnational-issues',1406,'Disputes — international: Ethiopian forces
invaded southern Somalia and routed
Islamist Courts from Mogadishu in January
2007; “Somaliland” secessionists provide
port facilities in Berbera to landlocked
Ethiopia and have established commercial
ties with other regional states; “Pundand”
and “Somaliland” “governments” seek
international support in their secessionist
aspirations and overlapping border
claims; the undemarcated former British
administrative line has little meaning as
a political separation to rival clans within
Ethiopia’s Ogaden and southern Soma¬
lia’s Oromo region; Kenya works hard
to prevent the clan and militia fighting
in Somalia from spreading south across
the border, which has long been open to
nomadic pastoralists
Refugees and internally displaced persons:
IDPs: 1.1 million (civil war since 1988, clan-
based competition for resources) (2007)
Background: Dutch traders landed at the
southern tip of modem day South Africa in
1652 and established a stopover point on
the spice route between the Netherlands and
the East, founding the city of Cape Town.
After the British seized the Cape of Good
Hope area in 1806, many of the Dutch
settlers (the Boers) trekked north to found
their own republics. The discovery of
diamonds (1867) and gold (1886) spurred
wealth and immigration and intensified
the subjugation of the native inhabitants.
The Boers resisted British encroachments
but were defeated in the Boer War (1 899-
1902); however, the British and the Afri¬
kaners, as the Boers became known, ruled
together under the Union of South Africa.
In 1948, tlae National Party was voted into
power and instituted a policy of apartheid—
the separate development of the races. The
first multi-racial elections in 1994 brought
an end to apartheid and ushered in black
majority rule under the African National
Congress (ANC). ANC infighting, which
has grown in recent years, came to a head
in September 2008 after President Thabo
MBEKI resigned. Kgalema MOTLANTHE,
the party’s General-Secretary, succeeded as
interim president until general elections
scheduled for 2009.
GEOGRAPHY SOUTH AFRICA
Location: Southern Africa, at the southern
tip of the continent of Africa
Geographic coordinates:
29 00 S, 24 00 E
Map references: Africa
Area: total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands
(Marion Island and Prince Edward Island)
Area — comparative: slightly less than
twice the size of Texas
Land boundaries: total: 4,862 km
border countries: Botswana 1,840 km,
Lesotho 909 km, Mozambique 491 km,
Namibia 967 km, Swaziland 430 km,
Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims: territorial sea : 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the
continental margin
Climate: mostly semiarid; subtropical
along east coast; sunny days, cool nights
Terrain: vast interior plateau rimmed by
rugged hills and narrow coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, anti¬
mony, coal, iron ore, manganese, nickel,
phosphates, tin, uranium, gem diamonds,
platinum, copper, vanadium, salt, natural gas
Land use: arable land: 12.1%
permanent crops: 0.79%
other: 87.11% (2005)
Irrigated land:
14,980 sq km (2003)
Total renewable water resources:
50 cu km (1990)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 12.5 cu
km/yr (3 1 %/ 6%/ 63%)
per capita: 264 cu m/yr (2000)
Natural hazards: prolonged droughts
Environment — current issues: lack of
important arterial rivers or lakes requires
extensive water conservation and control
measures; growth in water usage outpacing
supply; pollution of rivers from agricultural
runoff and urban discharge; air pollution
resulting in acid rain; soil erosion; deserti¬
fication
Environment — international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conserva¬
tion, Ozone Layer Protection, Ship Pollu¬
tion, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: South Africa completely
surrounds Lesotho and almost completely
surrounds Swaziland
Disputes — international: South Africa
has placed military along the border
to apprehend the thousands of Zimba¬
bweans fleeing economic dysfunction and
political persecution; as of January 2007,
South Africa also supports large numbers
of refugees and asylum seekers from
the Democratic Republic of the Congo
(33,000), Somalia (20,000), Burundi
(6,500), and other states in Africa (26,000);
managed dispute with Namibia over the
location of the boundary in the Orange
River; in 2006, Swazi king advocates resort
to ICJ to claim parts of Mpumalanga and
KwaZulu-Natal from South Africa
Refugees and internally displaced
persons: refugees ( country of origin): 10,772
(Democratic Republic of Congo); 7,818
(Somalia); 5,759 (Angola) (2007)
Trafficking in persons: current situa¬
tion: South Africa is a source, transit, and
destination country for men, women,
and children trafficked for forced labor and
sexual exploitation; women and girls are
trafficked internally— and occasionally to
European and Asian countries— for sexual
exploitation; women from other African
countries are trafficked to South Africa
and, less frequently, onward to Europe
for sexual exploitation; men and boys are
trafficked from neighboring countries for
forced agricultural labor; Asian and Eastern
European women are trafficked to South
Africa for debt-bonded sexual exploitation
tier rating: Tier 2 Watch List— South Africa is
on the Tier 2 Watch List for a fourth consec¬
utive year for its failure to show increasing
efforts to address trafficking; the government
provided inadequate data in 2007 on traf¬
ficking crimes investigated or prosecuted, or
on resulting convictions or sentences; it also
did not provide information on its efforts
to protect victims of trafficking; die country
continues to deport and/or prosecute
suspected foreign victims without providing
appropriate protective services (2008)
Illicit drugs: transshipment center for
heroin, hashish, and cocaine, as well as a
major cultivator of marijuana in its own
right; cocaine and heroin consumption on
the rise; world’s largest market for illicit
methaqualone, usually imported illegally
from India through various east African
countries, but increasingly producing its own
synthetic drugs for domestic consumption;
attractive venue for money launderers given
the increasing level of organized criminal
and narcotics activity in the region and the
size of die South African economy
626','7f406e2633d03c5d208b0c4815c6abc26884aec81c3f2b2a2f92b53e7d240693','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b94bf39e304373984f2ff721971f1c635e22d05eda5ecbf89f9a0339089f6db6',2010,'GS','South Georgia and the South Sandwich Islands','transnational-issues',1415,'Disputes— international: Argentina,
which claims the islands in its constitu¬
tion and briefly occupied them by force
in 1982, agreed in 1995 to no longer seek
settlement by force
627
THE CIA WORLD FACTBOOK
SOUTHERN OCEAN','9909eb8cc266b79d148ca127e8521b36c1e3b3fd078451cc237a1dfcb7f03685','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed33fdb6cd6d8ebd91cb6ea51bbb18ea520054af686df345c8b1d5303e319844',2010,'ES','Spain','transnational-issues',1418,'Disputes — international: Antarctic Treaty
defers claims (see Antarctica entry), but
Argentina, Australia, Chile, France, NZ,
Norway, and UK assert claims (some over¬
lapping), including the continental shelf
in the Southern Ocean; several states have
expressed an interest in extending those
continental shelf claims under the United
Nations Convention on the Law of the Sea
(UNCLOS) to include undersea ridges; the
US and most other states do not recognize
the land or maritime claims of other states
and have made no claims themselves (the
US and Russia have reserved the right to
do so); no formal claims exist in die waters
in the sector between 90 degrees west and
1 50 degrees west
Chafarinas, Penon de Alhucemas, and
Penon de Velez de la Gomera
Area — comparative: slightly more than
twice the size of Oregon
Land boundaries: total: 1,917.8 km
border countries: Andorra 63.7 km, France
623 km, Gibraltar 1.2 km, Portugal 1,214
km, Morocco (Ceuta) 6.3 km, Morocco
(Melilla) 9.6 km
Coastline: 4,964 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm (applies
only to the Atlantic Ocean)
Climate: temperate; clear, hot summers in
interior, more moderate and cloudy along
coast; cloudy, cold winters in interior,
partly cloudy and cool along coast
Terrain: large, flat to dissected plateau
surrounded by rugged hills; Pyrenees in
north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on
Canary Islands 3,718 m
Natural resources: coal, lignite, iron
ore, copper, lead, zinc, uranium, tung¬
sten, mercury, pyrites, magnesite, fluor-
629
THE CIA WORLD FACTBOOK
spar, gypsum, sepiolite, kaolin, potash,
hydropower, arable land
Land use: arable land: 27.18%
permanent crops: 9.85%
other: 62.97% (2005)
Irrigated land: 37,800 sq km (2003)
Total renewable water resources:
111.1 cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 37.22 cu
km/yr (1 3%/19%/68%)
per capita: 864 cu m/yr (2002)
Natural hazards: periodic droughts
Environment — current issues: pollution
of the Mediterranean Sea from raw sewage
and effluents from the offshore production
of oil and gas; water quality and quantity
nationwide; air pollution; deforestation;
desertification
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Sulfur 94,
Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography — note: strategic location
along approaches to Strait of Gibraltar;
Spain controls a number of territories in
northern Morocco including the enclaves
of Ceuta and Melilla, and the islands of
Penon de Velez de la Gomera, Penon de
Alhucemas, and Islas Chafarinas
Disputes — international: in 2002,
Gibraltar residents voted overwhelmingly
by referendum to remain a British colony
and against a “total shared sovereignty”
arrangement while demanding participa¬
tion in talks between the UK and Spain;
Spain disapproves of UK plans to grant
Gibraltar greater autonomy; Morocco
protests Spain’s control over the coastal
enclaves of Ceuta, Melilla, and the islands
of Penon de Velez de la Gomera, Penon
de Alhucemas, and Islas Chafarinas, and
surrounding waters; Morocco serves as the
primary launching site of illegal migration
into Spain from North Africa; Portugal
does not recognize Spanish sovereignty
over the territory of Olivenza based on a
difference of interpretation of the 1815
Congress of Vienna and the 1801 Treaty
of Badajoz
lliicif drugs: despite rigorous law enforce¬
ment efforts, North African, Latin
American, Galician, and other European
traffickers take advantage of Spain’s long
coasdine to land large shipments of cocaine
and hashish for distribution to the Euro¬
pean market; consumer for Latin American
cocaine and North African hashish; desti¬
nation and minor transshipment point for
Southwest Asian heroin; money-laundering
site for Colombian narcotics trafficking
organizations and organized crime
SPRATLY ISLANDS
Background: The Spratly Islands consist of
more than 100 small islands or reefs. They
are surrounded by rich fishing grounds and
potentially by gas and oil deposits. They are
claimed in their entirety by China, Taiwan,
and Vietnam, while portions are claimed
by Malaysia and the Philippines. About
45 islands are occupied by relatively small
numbers of military forces from China,
Malaysia, the Philippines, Taiwan, and
Vietnam. Brunei has established a fishing
zone that overlaps a southern reef but has
not made any formal claim.
Disputes — international: all of the Spratly
Islands are claimed by China, Taiwan, and
Vietnam; parts of them are claimed by
Malaysia and the Philippines; in 1984,
Brunei established an exclusive fishing
zone that encompasses Louisa Reef in
the southern Spratly Islands but has not
publicly claimed the reef; claimants in
November 2002 signed the “Declaration
on the Conduct of Parties in the South
China Sea,” which has eased tensions but
falls short of a legally binding “code of
conduct”; in March 2005, the national oil
companies of China, the Philippines, and
Vietnam signed a joint accord to conduct
marine seismic activities in the Spratly
Islands
Disputes— international: in April 2006,
die Permanent Court of Arbitration issued a
decision that delimited a maritime boundary
with Trinidad and Tobago and compelled
Barbados to enter a fishing agreement that
limited Barbadian fishermen’s catches of
flying fish in Trinidad and Tobago’s exclu¬
sive economic zone; in 2005, Barbados and
Trinidad and Tobago agreed to compulsory
international arbitration under UNCLOS
challenging whether the northern limit of
Trinidad and Tobago’s and Venezuela’s
maritime boundary extends into Barbadian
waters; Guyana has also expressed its inten¬
tion to include itself in the arbitration as the
Trinidad and Tobago-Venezuela maritime
boundary may extend into its waters as well
Illicit drugs: transshipment point for
South American drugs destined for the US
and Europe; producer of cannabis
686','6957613e25a0ff5a31424f111ddeb4c7c56de6fccd3218d73b7fea55084db0a7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6876db110fc7b31e4712b74839fb95bfb18b8b30b6cdd10e8ae23f20dd813a0a',2010,'SD','Sudan','transnational-issues',1427,'Disputes — international: none
Refugees and internally displaced
persons: IDPs: 460,000 (both Tamils and
non-Tamils displaced due to long-term
civil war between the government and the
separatist Liberation Tigers of Tamil Eelam
(LTTE)) (2007)
Trafficking in persons: current situation:
Sri Lanka is a source and destination
country for men and women trafficked for
the purposes of involuntary servitude and
commercial sexual exploitation; Sri Lankan
men and women migrate willingly to the
Persian Gulf, Middle East, and East Asia
to work as construction workers, domestic
servants, or garment factory workers, where
some find themselves in situations of invol¬
untary servitude when faced with restrictions
on movement, withholding of passports,
threats, physical or sexual abuse, and debt
bondage; children are trafficked internally
for commercial sexual exploitation and,
less frequently, for forced labor
tier rating: Tier 2 Watch List— for a second
consecutive year, Sri Lanka is on the Tier 2
Watch List for failing to provide evidence of
increasing efforts to combat severe forms of
human trafficking, particularly in the area
of law enforcement; the government failed
to arrest, prosecute, or convict any person
for trafficking offenses and continued to
punish some victims of trafficking for
crimes committed as a result of being traf¬
ficked; Sri Lanka has not ratified the 2000
UN TIP Protocol (2008)','e76c8b9b9d203af1b1d5ea8e1345f3aa489c0b4ed2101408140e60ba7d6d3119','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af3a95304238e2581de528b8700c0dbcc978b0092f9d0cf1ea4a85a49a056d22',2010,'SR','Suriname','transnational-issues',1432,'Disputes — international: the effects of
Sudan’s almost constant ethnic and rebel
militia fighting since the mid-20th century
have penetrated all of the neighboring
states; as of 2006, Chad, Ethiopia, Kenya,
Central African Republic, Democratic
Republic of the Congo, and Uganda
provided shelter for over half a million
Sudanese refugees, which includes 240,000
Darfur residents driven from their homes
by Janjawid armed militia and the Suda¬
nese military forces; Sudan, in turn, hosted
about 1 1 6,000 Eritreans, 20,000 Chadians,
and smaller numbers of Ethiopians, Ugan¬
dans, Central Africans, and Congolese as
refugees; in February 2006, Sudan and
DROC signed an agreement to repatriate
13,300 Sudanese and 6,800 Congolese;
Sudan accuses Eritrea of supporting Suda¬
nese rebel groups; efforts to demarcate the
porous boundary with Ethiopia proceed
slowly due to civil and ethnic fighting in
eastern Sudan; the boundary that separates
Kenya and Sudan’s sovereignty is unclear
in the “Ilemi Triangle,” which Kenya has
administered since colonial times; while
Sudan claims to administer the Hala’ib
Triangle north of the 1 899 Treaty boundary
along the 22nd Parallel; both states with¬
drew their military presence in the 1990s,
and Egypt has invested in and effectively
administers the area; periodic violent skir¬
mishes with Sudanese residents over water
and grazing rights persist among related
pastoral populations along the border with
the Central African Republic
Refugees and internally displaced
persons: refugees ( country of origin):
157,220 (Eritrea); 25,023 (Chad); 11,009
(Ethiopia); 7,895 (Uganda); 5,023
(Central African Republic)
IDPs: 5.3— 6.2 million (civil war
1983-2005; ongoing conflict in Darfur
region) (2007)
Trafficking in persons: current situa¬
tion: Sudan is a source country for men,
women, and children trafficked internally
for the purposes of forced labor and sexual
exploitation; Sudan is also a transit and
destination country for Ethiopian women
trafficked abroad for domestic servitude;
Sudanese women and girls are trafficked
within the country, as well as possibly to
Middle Eastern countries for domestic
servitude; the terrorist rebel organization,
Lord’s Resistance Army, continues to
harbor small numbers of Sudanese and
Ugandan children in the southern part of
the country for use as cooks, porters, and
combatants; some of these children are also
trafficked across borders into Uganda or the
Democratic Republic of the Congo; militia
groups in Darfur, some of which are linked
to the government, abduct women for short
periods of forced labor and to perpetrate
sexual violence; during the two decades-
long north-south civil war, thousands of
Dinka women and children were abducted
and subsequently enslaved by members
of the Missiriya and Rezeigat tribes; while
there have been no known new abductions
of Dinka by members of Baggara tribes in
the last few years, inter-tribal abductions
continue in southern Sudan
tier rating: Tier 3— Sudan does not fully
comply with the minimum standards
for the elimination of trafficking and is
not making significant efforts to do so;
combating human trafficking through law
enforcement or prevention measures was
not a priority for die government in 2007
(2008)
Disputes — international: area claimed by
French Guiana between Riviere Litani and
Riviere Marouini (both headwaters of the
Lawa); Suriname claims a triangle of land
between the New and Kutari/Koetari rivers
in a historic dispute over the headwaters
of the Courantyne; Guyana seeks United
Nations Convention on the Law of the
Sea (UNCLOS) arbitration to resolve the
long-standing dispute with Suriname over
the axis of the territorial sea boundary in
potentially oil-rich waters
Illicit drugs: growing transshipment point
for South American drugs destined for
Europe via the Netherlands and Brazil;
transshipment point for arms-for-drugs
dealing
SVALBARD
Disputes— international: despite recent
discussions, Russia and Norway dispute
their maritime limits in the Barents Sea
and Russia’s fishing rights beyond Sval¬
bard’s territorial limits within the Svalbard
Treaty zone
645
THE CIA WORLD FACTBOOK
SWAZILAND
Disputes— international: in 2006, Swazi
king advocates resort to ICJ to claim parts
of Mpumalanga and KwaZulu-Natal from','fad72e67633306f142d02f0ff32361e501339a2f5ed6783ce757c4f01fd3281f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c8583b296e4a27455d4adffb237fe791b4ed15340ffbddd2d44191497dfeec3',2010,'CH','Switzerland','transnational-issues',1441,'Disputes — international: none
Illicit drugs: a major international financial
center vulnerable to the layering and
integration stages of money laundering;
despite significant legislation and reporting
requirements, secrecy rules persist and
nonresidents are permitted to conduct
business through offshore entities and
various intermediaries; transit country for
and consumer of South American cocaine,
Soudiwest Asian heroin, and Western
European synthetics; domestic cannabis
cultivation and limited ecstasy production
SYRIA
Disputes — international: Golan Heights
is Israeli-occupied with the almost 1, 000-
strong UN Disengagement Observer Force
(UNDOF) patrolling a buffer zone since
1964; lacking a treaty or other documenta¬
tion describing the boundary, portions of
the Lebanon-Syria boundary are unclear
with several sections in dispute; since
2000, Lebanon has claimed Shabaa farms
in the Golan Heights; 2004 Agreement
and pending demarcation setdes border
dispute with Jordan; approximately two
million Iraqis have fled the conflict in Iraq
with the majority taking refuge in Syria and','f4d8f3f7b995b17353bf1a71aaf724c95828e1ea96750eceaed3c8f1c9147632','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c88878710cbfe05e5eab1644d745d91d80500e0abe03a69bcedf1ee0f84af2fc',2010,'TL','Timor-Leste','transnational-issues',1449,'Disputes— international: separatist
violence in Thailand’s predominantly
Muslim southern provinces prompt border
closures and controls with Malaysia to stem
terrorist activities; Southeast Asian states
have enhanced border surveillance to check
the spread of avian flu; talks continue on
completion of demarcation with Laos but
disputes remain over several islands in the
Mekong River; despite continuing border
committee talks, Thailand must deal with
Karen and other ethnic rebels, refugees,
and illegal cross-border activities, and as of
2006, over 116,000 Karen, Hmong, and
other refugees and asylum seekers from
Burma; Cambodia and Thailand dispute
sections of historic boundary with missing
boundary markers; Cambodia claims Thai
encroachments into Cambodian territory
and obstructing access to Preah Vihear
temple ruins awarded to Cambodia by ICJ
decision in 1962; Thailand is studying the
feasibility of jointly constructing the Hatgyi
Dam on the Salween river near the border
with Burma; in 2004, international envi¬
ronmentalist pressure prompted China
to halt construction of 13 dams on the
Salween River that flows through China,
Burma, and Thailand
Refugees and internally displaced
persons: refugees ( country of origin ):
132,241 (Burma) (2007)
Illicit drugs: a minor producer of opium,
heroin, and marijuana; transit point
for illicit heroin en route to the inter¬
national drug market from Burma and
Laos; eradication efforts have reduced the
area of cannabis cultivation and shifted
some production to neighboring coun¬
tries; opium poppy cultivation has been
reduced by eradication efforts; also a drug
money-laundering center; minor role in
methamphetamine production for regional
consumption; major consumer of metham¬
phetamine since the 1 990s despite a series
of government crackdowns
Disputes — international: Timor-Leste-
Indonesia Boundary Committee has
resolved all but a small portion of the
land boundary, but discussions on mari¬
time boundaries are stalemated over sover¬
eignty of the uninhabited coral island of
Pulau Batek/Fatu Sinai in the north and
alignment with Australian claims in the
south; many refugees who left Timor-
Leste in 2003 still reside in Indonesia
and refuse repatriation; Australia and
Timor-Leste agreed in 2005 to defer the
disputed portion of the boundary for 50
years and to split hydrocarbon revenues
evenly outside the Joint Petroleum Devel¬
opment Area covered by the 2002 Timor
Sea Treaty
Refugees and internally displaced
persons: IDPs: 100,000 (2007)
Illicit drugs: NA','bbd6f4918aafc1d89274e548be0d6b5dacb00ad0592abd2848e7a8c9fce805a1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97b72734795e92adbe01396a6efbbf5995b37a3a20cd8cd10ab2fb0993eb5212',2010,'TK','Tokelau','transnational-issues',1461,'Disputes— international: in 2001, Benin
claimed Togo moved boundary monu¬
ments— joint commission continues to
resurvey the boundary; in 2006 14,000
Togolese refugees remain in Benin and
Ghana out of the 40,000 who fled there
in 2005
Refugees and internally displaced
persons: refugees ( country of origin): 5,000
(Ghana)
IDPs: 1,500 (2007)
Illicit drugs: transit hub for Nigerian
heroin and cocaine traffickers; money laun¬
dering not a significant problem','c05c03fe2138a57bd767ce9a1ecd05650871ad6f2fe77f191d045ab505e261c7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b71d3c6d9647093f7ff7d59f65f598535591c7aaa008d431d363d58b86f8b3d3',2010,'TO','Tonga','transnational-issues',1467,'Disputes— international: Tokelau
included American Samoa’s Swains Island
(Olohega) in its 2006 draft constitution
Background: Tonga— unique among Pacific
nations— never completely lost its indig¬
enous governance. The archipelagos of
“The Friendly Islands” were united into
a Polynesian kingdom in 1845. Tonga
became a constitutional monarchy in 1875
and a British protectorate in 1900; it with¬
drew from the protectorate and joined the
Commonwealth of Nations in 1970. Tonga
remains the only monarchy in the Pacific.
Disputes— international : none
683
THE CIA WORLD FACTBOOK','93e1583cd09e100a74ad1b43b626eb648190acad2b5a08cce7d637fad4b1f620','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f1e19d23264e89fa42a8b5268bdd8d24eab0e2ab7dd5b797f4901e0db155240',2010,'TN','Tunisia','transnational-issues',1475,'Background: Rivalry between French and
Italian interests in Tunisia culminated in a
French invasion in 1881 and the creation
of a protectorate. Agitation for independ¬
ence in the decades following World War I
was finally successful in getting the French
to recognize Tunisia as an independent
state in 1956. The country’s first president,
Habib BOURGUIBA, established a strict
one-party state. He dominated the country
for 31 years, repressing Islamic fundamen¬
talism and establishing rights for women
unmatched by any other Arab nation.
In November 1987, BOURGUIBA was
removed from office and replaced by Zine
el Abidine BEN ALI in a bloodless coup.
BEN ALI is currently serving his fourth
consecutive five-year term as president; the
next elections are scheduled for October
2009. Tunisia has long taken a moderate,
non-aligned stance in its foreign relations.
Domestically, it has sought to defuse rising
pressure for a more open political society.
Disputes— international: none
TURKEY
Disputes — international: complex mari¬
time, air, and territorial disputes with
Greece in the Aegean Sea; status of north
Cyprus question remains; Syria and Iraq
protest Turkish hydrological projects to
control upper Euphrates waters; Turkey
has expressed concern over the status
of Kurds in Iraq; border with Armenia
remains closed over Nagorno-Karabakh
Refugees and internally displaced
persons: IDPs: 1-1.2 million (fighting
1984-99 between Kurdish PKK and
Turkish military; most IDPs in south¬
eastern provinces) (2007)
illicit drugs: key transit route for South¬
west Asian heroin to Western Europe
and, to a lesser extent, the US— via air,
land, and sea routes; major Turkish and
other international trafficking organiza¬
tions operate out of Istanbul; laboratories
to convert imported morphine base into
heroin exist in remote regions of Turkey
and near Istanbul; government maintains
strict controls over areas of legal opium
poppy cultivation and over output of poppy
straw concentrate; lax enforcement of
money-laundering controls','6243d50ed8cc2d18cf47be684ef4aad9b614eec8861cc94734bb059f7c8e2261','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2013c7e7ff438254b4d710e0837f32c3f92189f95396f26e46f29af98a8f45cc',2010,'TC','Turks and Caicos Islands','transnational-issues',1487,'Disputes — international: cotton monocul¬
ture in Uzbekistan and Turkmenistan creates
water-sharing difficulties for Amu Darya river
states; field demarcation of the boundaries
with Kazakhstan commenced in 2005, but
Caspian seabed delimitation remains stalled
with Azerbaijan, Iran, and Kazakhstan due
to Turkmenistan’s indecision over how to
allocate the sea’s waters and seabed
Refugees and internally displaced
persons: refugees ( country of origin): 11,173
(Tajikistan); less than 1,000 (Afghanistan)
(2007)
Illicit drugs: transit country for Afghan
narcotics bound for Russian and Western
European markets; transit point for
heroin precursor chemicals bound for','132f5b29e6c2d68a6e5d36fc391cb425c342b4b89f428d4df6fcae044643f021','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e2f96377726cdc20ace6867966faee461fe12825763e5fe47feb3975ca164d9',2010,'TV','Tuvalu','transnational-issues',1496,'Disputes — international: have received
Haitians fleeing economic and civil disorder
Illicit drugs: transshipment point for
South American narcotics destined for the
US and Europe
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sq km
land: 26 sq km
water: 0 sq km
Area— comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
699
THE CIA WORLD FACTBOOK
Coastline: 24 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by easterly
trade winds (March to November); westerly
gales and heavy rain (November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 66.67%
other: 33.33% (2005)
Irrigated land: NA
Natural hazards: severe tropical storms
are usually rare, but, in 1997, there were
three cyclones; low level of islands make
them sensitive to changes in sea level
Environment — current issues: since there
are no streams or rivers and groundwater is
not potable, most water needs must be met
by catchment systems with storage facili¬
ties (the Japanese Government has built
one desalination plant and plans to build
one other); beachhead erosion because
of the use of sand for building materials;
excessive clearance of forest undergrowth
for use as fuel; damage to coral reefs from
the spread of the Crown of Thorns star¬
fish; Tuvalu is concerned about global
increases in greenhouse gas emissions
and their effect on rising sea levels, which
threaten the country’s underground water
table; in 2000, the government appealed
to Australia and New Zealand to take in
Tuvaluans if rising sea levels should make
evacuation necessary
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Law of the Sea, Ozone Layer Protec¬
tion, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: one of the smallest and
most remote countries on Earth; six of the
nine coral atolls— Nanumea, Nui, Vaitupu,
Nukufetau, Funafuti, and Nukulaelae— have
i
lagoons open to the ocean; Napumaya and
Niutao have landlocked lagoons; Niulakita
does not have a lagoon
Disputes — international: none
701','5e7f530098b532a1482bf74afa508eef66d89b241d2dc3800eceaead6bb57f0d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbc68f7f0ecd9313bc9f07a397c865bb6d8e4afc8a64ac6653f488e2e125991d',2010,'UA','Ukraine','transnational-issues',1508,'Disputes— international: Uganda is
subject to armed fighting among hostile
ethnic groups, rebels, armed gangs, militias,','b1ab860cea0cb849c7242a5ee36584df88cf151b9e40da3c9c88db2b3cc94e80','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('860abf92b6b7fdbc7385a6908690502809808bde2a448e9d7a02238e6db0508e',2010,'AE','United Arab Emirates','transnational-issues',1515,'Disputes — international: 1997 boundary
delimitation treaty with Belarus remains
un-ratified due to unresolved financial
claims, stalling demarcation and reducing
border security; delimitation of land
boundary with Russia is complete with
preparations for demarcation underway; the
dispute over the boundary between Russia
and Ukraine through the Kerch Strait and
Sea of Azov remains unresolved despite a
December 2003 framework agreement and
ongoing expert-level discussions; Moldova
and Ukraine operate joint customs posts to
monitor transit of people and commodities
through Moldova’s break-away Transnis-
tria Region, which remains under OSCE
supervision; the ICJ gave Ukraine until
December 2006 to reply, and Romania
until June 2007 to rejoin, in their dispute
submitted in 2004 over Ukrainian-
administered Zmiyinyy/Serpilor (Snake)
Island and Black Sea maritime boundary;
Romania opposes Ukraine’s reopening of
a navigation canal from the Danube border
through Ukraine to the Black Sea
Illicit drugs: limited cultivation of
cannabis and opium poppy, mostly for
CIS consumption; some synthetic drug
production for export to the West; limited
government eradication program; used as
transshipment point for opiates and other
illicit drugs from Africa, Latin America, and
Turkey to Europe and Russia; Ukraine has
improved anti-money-laundering controls,
resulting in its removal from the Financial
Action Task Force’s (FATF’s) Noncoop¬
erative Countries and Territories List in
February 2004; Ukraine’s anti-money-laun-
dering regime continues to be monitored
by FATF
Disputes — international: boundary agree¬
ment was signed and ratified with Oman in
2003 for entire border, including Oman’s
Musandam Peninsula and Al Madhah
enclaves, but contents of the agreement
and detailed maps showing the alignment
have not been published; Iran and UAE
dispute Tunb Islands and Abu Musa
Island, which Iran occupies
Illicit drugs: the UAE is a drug transship¬
ment point for traffickers given its prox¬
imity to Southwest Asian drug-producing
countries; the UAE’s position as a major
financial center makes it vulnerable to
money laundering; anti-money-laundering
controls improving, but informal banking
remains unregulated
Central African Customs and Economic Union
ultra-high-frequency','8fd14df168c1df8dfa4540b82460068cb0807ff1239535cf6862b3fcb238041b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60945bb6082a72e214986c7e32c3638c6bc4394c2489ac8ca8895f18bdec0380',2010,'GB','United Kingdom','transnational-issues',1531,'Disputes— international: in 2002,
Gibraltar residents voted overwhelmingly
by referendum to reject any “shared sover¬
eignty” arrangement between the UK and
Spain; the Government of Gibraltar insists
on equal participation in talks between
the two countries; Spain disapproves
of UK plans to grant Gibraltar greater
autonomy; Mauritius and Seychelles claim
the Chagos Archipelago (British Indian
Ocean Territory), and its former inhabit¬
ants since their eviction in 1965; most
Chagossians reside in Mauritius, and in
2001 were granted UK citizenship, where
some have since resettled; in May 2006,
the High Court of London reversed the
UK Government’s 2004 orders of council
that banned habitation on the islands;
UK rejects sovereignty talks requested by
Argentina, which still claims the Falkland
Islands (Islas Malvinas) and South Georgia
and the South Sandwich Islands; territorial
claim in Antarctica (British Antarctic Terri¬
tory) overlaps Argentine claim and partially
overlaps Chilean claim; Iceland, the UK,
and Ireland dispute Denmark’s claim that
the Faroe Islands’ continental shelf extends
beyond 200 nm
Illicit drugs: producer of limited amounts
of synthetic drugs and synthetic precursor
chemicals; major consumer of Southwest
Asian heroin, Latin American cocaine, and
synthetic drugs; money-laundering center
716
Arab Maghreb Union
United Nations
United Nations Mission in Sierra Leone
United Nations Convention on the Law of the Sea, also know as LOS
United Nations Conference on Trade and Development
United Nations Drug Control Program
United Nations Disengagement Observer Force
United Nations Development Program
United Nations Environment Program
United Nations Educational, Scientific, and Cultural Organization
United Nations Peace-keeping Force in Cyprus
United Nations Population Fund
United Nations High Commissioner for Refugees
United Nations Children’s Fund
United Nations Interregional Crime and Justice Research Institute
United Nations Institute for Disarmament Research
United Nations Industrial Development Organization
United Nations Interim Force in Lebanon
United Nations Institute for Training and Research
United Nations Mission in Ethiopia and Eritrea
United Nations Interim Administration Mission in Kosovo
United Nations Mission in Liberia
United Nations Integrated Mission in Timor-Leste
United Nations Military Observer Group in India and Pakistan
United Nations Monitoring, Verification, and Inspection Commission
United Nations Operation in Cote d’Ivoire
United Nations Observer Mission in Georgia
United Nations Office of Project Services
United Nations Research Institute for Social Development
United Nations Relief and Works Agency for Palestine Refugees in the Near East
United Nations Security Council
Untied Nations System Staff College
United Nations Truce Supervision Organization
United Nations University
World Tourism Organization
Universal Postal Union
769
THE CIA WORLD FACTBOOK
us','f19e72cc4dd2dde03870959c13306f86e347977ccec11d68288b713bafa32d9d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('544a819781644db080e88d0f3fa8f9aead421d1c5f034763b3f1b04a6b12605d',2010,'UY','Uruguay','transnational-issues',1538,'Disputes — international: none
Background: Montevideo, founded by the
Spanish in 1 726 as a military stronghold,
soon took advantage of its natural harbor
to become an important commercial center.
Claimed by Argentina but annexed by
Brazil in 1821, Uruguay declared its inde¬
pendence four years later and secured its
freedom in 1 828 after a three-year struggle.
The administrations of President Jose
BATLLE in the early 20th century estab¬
lished widespread political, social, and
economic reforms that established a statist
tradition. A violent Marxist urban guer¬
rilla movement named the Tupamaros,
launched in the late 1960s, led Uruguay’s
president to cede control of the govern¬
ment to the military in 1973. By yearend,
the rebels had been crushed, but the mili¬
tary continued to expand its hold over the
government. Civilian rule was not restored
until 1985. In 2004, the left-of-center
Frente Amplio Coalition won national
elections that effectively ended 170 years
of political control previously held by the
Colorado and Blanco parties. Uruguay’s
political and labor conditions are among
the freest on the continent.
Disputes— international: in Jan 2007,
ICJ provisionally ruled Uruguay may begin
construction of two paper mills on the
Uruguay River, which forms the border
with Argentina, while the court examines
further whether Argentina has the legal right to stop such construction with potential environmental implications to both countries;
uncontested dispute with Brazil over
certain islands in the Quarai/Cuareim
and Invernada streams and the resulting
tripoint with Argentina
Illicit drugs: small-scale transit country for
drugs mainly bound for Europe, often through
sea-borne containers; law enforcement corrup¬
tion; money laundering because of strict
banking secrecy laws; weak border control
along Brazilian frontier; increasing consump¬
tion of cocaine base and synthetic drugs','ea8817d55798c2757cd109908ee9f1cd1ec9941f6dd979774377b4b4492952ab','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bbc5dbef93e4364064e590398a7bb1d61cdbabab5ccad40e756939e0adeb52c',2010,'UZ','Uzbekistan','transnational-issues',1547,'Disputes — international: prolonged
drought and cotton monoculture in
729
THE CIA WORLD FACTBOOK
Uzbekistan and Turkmenistan creates
water-sharing difficulties for Amu Darya
river states; field demarcation of the
boundaries with Kazakhstan commenced
in 2004; border delimitation of 130 km
of border with Kyrgyzstan is hampered by
serious disputes around enclaves and other
areas
Refugees and internally displaced
persons: refugees ( country of origin): 39,202
(Tajikistan); 1,060 (Afghanistan)
IDPs: 3,400 (forced population transfers by
government from villages near Tajikistan
border) (2007)
Trafficking in persons: current situation:
Uzbekistan is a source country for women
and girls trafficked to Kazakhstan, Russia,
Middle East, and Asia for the purpose of
commercial sexual exploitation; men are
trafficked to Kazakhstan and Russia for
purposes of forced labor in the construc¬
tion, cotton, and tobacco industries; men
«
and women are also trafficked internally for
the purposes of domestic servitude, forced
labor in the agricultural and construction
industries, and for commercial sexual
exploitation
tier rating: Tier 2 Watch List— Uzbekistan
is on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat severe forms of trafficking in
2007; the government did not amend
its criminal code to increase penalties
for convicted traffickers; in March 2008,
Uzbekistan adopted ILO Conventions
on minimum age of employment and
on the elimination of the worst forms of
child labor and is working with the ILO
on implementation; the government also
demonstrated its increasing commitment
to combat trafficking in March 2008 by
adopting a comprehensive anti-trafficking
law; Uzbekistan has not ratified the 2000
UN TIP Protocol (2008)
Illicit drugs: transit country for Afghan
narcotics bound for Russian and, to a lesser
extent, Western European markets; limited
illicit cultivation of cannabis and small
amounts of opium poppy for domestic
consumption; poppy cultivation almost
wiped out by government crop eradication
program; transit point for heroin precursor
chemicals bound for Afghanistan
730','eb53d7c05c657f770c15d44397d2930c262aa606b6c22a6c4551b77150e7b019','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec824d2db01f95512181fb21f6d9e697b59504564e34e54f6249ffbd9a4bd432',2010,'VU','Vanuatu','transnational-issues',1555,'Disputes— international: Matthew and
Hunter Islands east of New Caledonia
claimed by Vanuatu and France
VENEZUELA
Background: Venezuela was one of three
countries that emerged from the collapse of
Gran Colombia in 1830 (the others being
Ecuador and New Granada, which became
Colombia). For most of the first half of the
20th century, Venezuela was ruled by gener-
ally benevolent military strongmen, who
promoted the oil industry and allowed for
some social reforms. Democratically elected
governments have held sway since 1959.
Hugo CHAVEZ, president since 1 999, seeks
to implement his “21st Century Socialism,”
which purports to alleviate social ills while
at the same time attacking globalization and
undermining regional stability. Current
concerns include: a weakening of demo¬
cratic institutions, political polarization, a
politicized military, drug-related violence
along the Colombian border, increasing
internal drug consumption, overdepend¬
ence on the petroleum industry with its
price fluctuations, and irresponsible mining
operations that are endangering the rain
forest and indigenous peoples.
Disputes— international: claims all of
the area west of the Essequibo River in
Guyana, preventing any discussion of a
maritime boundary; Guyana has expressed
its intention to join Barbados in asserting
claims before die United Nations Conven¬
tion on the Law of the Sea (UNCLOS) that
Trinidad and Tobago’s maritime boundary
with Venezuela extends into their waters;
dispute with Colombia over maritime
boundary and Venezuelan-administered
Los Monjes islands near the Gulf of
Venezuela; Colombian-organized illegal
narcotics and paramilitary activities pene¬
trate Venezuela’s shared border region; in
2006, an estimated 139,000 Colombians
sought protection in 1 50 communities
along die border in Venezuela; US, France,
and the Netherlands recognize Venezuela’s
granting full effect to Aves Island, thereby
claiming a Venezuelan EEZ/continental
736
VIETNAM
shelf extending over a large portion of the
eastern Caribbean Sea; Dominica, Saint
Kitts and Nevis, Saint Lucia, and Saint
Vincent and the Grenadines protest Vene¬
zuela’s full effect claim
Trafficking in persons: current situa¬
tion: Venezuela is a source, transit, and
destination country for men, women,
and children trafficked for the purposes
of commercial sexual exploitation and
forced labor; Venezuelan women and
girls are trafficked within the country for
sexual exploitation, lured from the nation’s
interior to urban and tourist areas; child
prostitution in urban areas and child sex
tourism in resort destinations appear to
be growing; Venezuelan women and girls
are trafficked for commercial sexual exploi¬
tation to Western Europe, Mexico, and
Caribbean destinations
tier rating: Tier 2 Watch List— Venezuela
is placed on the Tier 2 Watch List, up
from Tier 3, as it showed greater resolve
to address trafficking through law enforce¬
ment measures and prevention efforts in
2007, although stringent punishment of
offenders and victim assistance remain
lacking (2008)
Illicit drugs: small-scale illicit producer
of opium and coca for the processing of
opiates and coca derivatives; however, large
quantities of cocaine, heroin, and mari¬
juana transit the country from Colombia
bound for US and Europe; significant
narcotics-related money-laundering activity,
especially along the border with Colombia
and on Margarita Island; active eradica¬
tion program primarily targeting opium;
increasing signs of drug-related activities by
Colombian insurgents on border
VIETNAM
Background: The conquest of Vietnam by
France began in 1 858 and was completed by
1884- It became part of French Indochina
in 1887. Vietnam declared independence
after World War II, but France continued
to rule until its 1954 defeat by Commu¬
nist forces under Ho Chi MINH. Under
the Geneva Accords of 1954, Vietnam
was divided into the Communist North
and anti-Communist South. US economic
and military aid to South Vietnam grew
through the 1 960s in an attempt to bolster
the government, but US armed forces were
withdrawn following a cease-fire agreement
in 1973. Two years later, North Viet¬
namese forces overran the South reuniting
the country under Communist rule. Despite
the return of peace, for over a decade the
country experienced little economic growth
because of conservative leadership policies,
the persecution and mass exodus of indi¬
viduals— many of them successful South
Vietnamese merchants— and growing inter¬
national isolation. However, since the enact¬
ment of Vietnam’s “doi moi” (renovation)
policy in 1986, Vietnamese authorities have
committed to increased economic liberaliza¬
tion and enacted structural reforms needed
to modernize the economy and to produce
more competitive, export-driven industries.
The country continues to experience small-
scale protests from various groups, the vast
majority connected to land-use issues and the
lack of equitable mechanisms for resolving
disputes. Various ethnic minorities, such as
the Montagnards of the Central Highlands
and the Khmer Krom in the southern delta
region, have also held protests. In January
2008, Vietnam assumed a nonpermanent
seat on the UN Security Council for the
2008-09 term.
Disputes— international: southeast Asian
states have enhanced border surveillance
to check the spread of avian flu; Cambodia
and Laos protest Vietnamese squatters
and armed encroachments along border;
an estimated 300,000 Vietnamese refu¬
gees reside in China; establishment of
a maritime boundary with Cambodia is
hampered by unresolved dispute over the
sovereignty of offshore islands; demarcation
of the China-Vietnam boundary proceeds
slowly and although the maritime boundary
delimitation and fisheries agreements were
ratified in June 2004, implementation has
been delayed; China occupies the Paracel
Islands also claimed by Vietnam and
Taiwan; involved in complex dispute with
China, Malaysia, Philippines, Taiwan, and
possibly Brunei over the Sprady Islands;
the 2002 “Declaration on the Conduct of
Parties in the South China Sea” has eased
tensions but falls short of a legally binding
“code of conduct” desired by several of the
disputants; Vietnam continues to expand
construction of facilities in the Sprady
Islands; in March 2005, the national oil
•companies of China, the Philippines, and
Vietnam signed a joint accord to conduct
marine seismic activities in the Sprady
Islands
Illicit drugs: minor producer of opium
poppy; probable minor transit point for
Southeast Asian heroin; government
continues to face domestic opium/heroin/
methamphetamine addiction problems
despite longstanding crackdowns
740
VIRGIN ISLANDS
VIRGIN ISLANDS
Disputes— international: none
742
WAKE ISLAND
Disputes — international: claimed by','78faca310ceb1d7cd05c238b2277be934dbd29458ce6eb0935505e67ad87ad62','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b0dc762d6999c80c8f8e20f54bf33a570da55e5dd58f4da2807f7b5846a49c8',2010,'EH','Western Sahara','transnational-issues',1566,'Disputes— international: Morocco claims
and administers Western Sahara, whose
sovereignty remains unresolved; UN-
administered cease-fire has remained in
effect since September 1991, administered
by the UN Mission for die Referendum in
Western Sahara (MINURSO), but attempts
to hold a referendum have failed and parties
thus far have rejected all brokered proposals;
several states have extended diplomatic
relations to the “Sahrawi Arab Democratic
Republic” represented by the Polisario
Front in exile in Algeria, while odiers recog¬
nize Moroccan sovereignty over Western
Sahara; most of the approximately 102,000
Sahrawi refugees are sheltered in camps in
Tindouf, Algeria
749
THE CIA WORLD FACTBOOK
WORLD
Disputes — international: stretching over
250,000 km, the world’s 322 international
land boundaries separate 1 94 independent
states and 71 dependencies, areas of special
sovereignty, and other miscellaneous enti¬
ties; ethnicity, culture, race, religion, and
language have divided states into sepa¬
rate political entities as much as history,
physical terrain, political fiat, or conquest,
resulting in sometimes arbitrary and
imposed boundaries; most maritime states
have claimed limits that include territorial
seas and exclusive economic zones; over¬
lapping limits due to adjacent or opposite
coasts create the potential for 430 bilateral
maritime boundaries of which 209 have
agreements that include contiguous and
noncontiguous segments; boundary,
borderland/ resource, and territorial
disputes vary in intensity from managed
or dormant to violent or militarized; unde¬
marcated, indefinite, porous, and unman¬
aged boundaries tend to encourage illegal
cross-border activities, uncontrolled migra¬
tion, and confrontation; territorial disputes
may evolve from historical and/or cultural
claims, or they may be brought on by
resource competition; ethnic and cultural
clashes continue to be responsible for much
of the territorial fragmentation and internal
displacement of the estimated 6.6 million
people and cross-border displacements of
8.6 million refugees around the world as of
early 2006; just over one million refugees
were repatriated in the same period; other
sources of contention include access to
water and mineral (especially hydrocarbon)
resources, fisheries, and arable land; armed
conflict prevails not so much between the
uniformed armed forces of independent
states as between stateless armed entities
that detract from the sustenance and welfare
of local populations, leaving the commu¬
nity of nations to cope with resultant refu¬
gees, hunger, disease, impoverishment,
and environmental degradation
Refugees and internally displaced
persons: the United Nations High
Commissioner for Refugees (UNHCR)
estimated that in December 2006 there was
a global population of 8.8 million regis¬
tered refugees and as many as 24.5 million
IDPs in more than 50 countries; the actual
global population of refugees is probably
closer to 10 million given the estimated 1 .5
million Iraqi refugees displaced throughout
the Middle East (2007)
Trafficking in persons: current situation:
approximately 800,000 people, mosdy
women and children, are trafficked annu¬
ally across national borders, not including
millions trafficked within their own
countries; at least 80% of the victims are
female and up to 50% are minors; 75%
of all victims are trafficked into commercial
sexual exploitation; almost two-thirds of the
global victims are trafficked intra-regionally
within East Asia and the Pacific (260,000
to 280,000 people) and Europe and Eurasia
(170,000 to 210,000 people)
Tier 2 Watch List: Albania, Argentina,
Armenia, Azerbaijan, Bahrain, Burundi,
Cameroon, Central African Republic, Chad,
China, Costa Rica, Cote d’Ivoire, Cyprus,
Democratic Republic of the Congo,
Dominican Republic, Egypt, Equatorial
Guinea, Gabon, The Gambia, Guatemala,
Guinea, Guinea-Bissau, Guyana, India,
Jordan, Libya, Malaysia, Montenegro,
Mozambique, Niger, Panama, Republic
of the Congo, Russia, South Africa, Sri
Lanka, Tajikistan, Uzbekistan, Venezuela,
Zambia, Zimbabwe
Tier 3: Algeria, Burma, Cuba, Fiji,
Iran, Kuwait, Moldova, North Korea,
Oman, Papua New Guinea, Qatar, Saudi
Arabia, Sudan, Syria (2008)
illicit drugs: cocaine: worldwide coca leaf
cultivation in 2007 amounted to 232,500
hectares; Colombia produced slightly more
than two-thirds of the worldwide crop,
followed by Peru and Bolivia; potential
pure cocaine production decreased 7%
to 865 metric tons in 2007; Colombia
conducts an aggressive coca eradication
campaign, but both Peruvian and Bolivian
Governments are hesitant to eradicate coca
in key growing areas; 551 metric tons of
export-quality cocaine (85% pure) is docu¬
mented to have been seized or destroyed
in 2005; US consumption of export
quality cocaine is estimated to have been
in excess of 380 metric tons
opiates: worldwide illicit opium poppy culti¬
vation continued to increase in 2007, with a
potential opium production of 8,400 metric
tons, reaching the highest levels recorded
since estimates began in mid-1980s; Afghan¬
istan is world’s primary opium producer,
accounting for 95% of the global supply;
Southeast Asia— responsible for 9% of global
opium— saw marginal increases in produc¬
tion; Latin America produced 1% of global
opium, but most was refined into heroin
destined for the US market; if all potential
opium was processed into pure heroin, the
potential global production would be 1 ,000
metric tons of heroin in 2007
753
Y','c46ea9d2369ad0fc3393c386d38cbad658954ae5fc30fd8e8cee24ebd7af3ff4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa02fb565f219045db31d0bceb9ae85f0f56e20bf4c8ba39dedef06957d95db',2010,'YE','Yemen','transnational-issues',1574,'Disputes— international: Saudi Arabia
has reinforced its concrete-filled security
barrier along sections of the fully demar¬
cated border with Yemen to stem illegal
cross-border activities
Refugees and internally displaced
persons: refugees ( country of origin): 91,587
(Somalia) (2007)
756','08dbdf3a76aacf41eae7140b3eaf44189f5420c862221e5e0a25180d2f11364b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13360fbaa2ecb401b7e62ec63e32ea4006456897ae123357e84db8ec1f6ef728',2010,'ZM','Zambia','transnational-issues',1582,'Disputes — international: in 2004,
Zimbabwe dropped objections to plans
between Botswana and Zambia to build a
bridge over the Zambezi River, thereby de
facto recognizing a short, but not clearly
delimited, Botswana-Zambia boundary in
the river; 42,250 Congolese refugees in
Zambia are offered voluntary repatriation
in November 2006, most of whom are
expected to return in the next two years;
Angolan refugees too have been repatriating
but 26,450 still remain with 90,000 others
from other neighboring states in 2006
Refugees and infernally displaced
persons: refugees (country of origin): 42,565
(Angola); 60,874 (Democratic Republic of
the Congo); 4,100 (Rwanda) (2007)
Trafficking in persons: current situation:
Zambia is a source, transit, and destination
country for women and children trafficked
for the purposes of forced labor and sexual
exploitation; many Zambian child laborers,
particularly those in the agriculture,
domestic service, and fishing sectors, are
also victims of human trafficking; Zambian
women, lured by false employment or
marriage offers abroad, are trafficked to
South Africa via Zimbabwe and to Europe
via Malawi for sexual exploitation; Zambia
\\ v
is a transit point for regional trafficking
of women and children, particularly from
Angola to Namibia and from the Demo¬
cratic Republic of the Congo to South
Africa for agricultural labor
tier rating: Tier 2 Watch List— Zambia is on
the Tier 2 Watch List for failing to provide
evidence of increasing efforts to combat
severe forms of trafficking, particularly
in regard to its inability to bring alleged
traffickers to justice through prosecutions
and convictions; unlike 2006, there were no
new prosecutions or convictions of alleged
traffickers in 2007; government efforts
to protect victims of trafficking remained
extremely limited throughout the year
(2008)
Illicit drugs: transshipment point for
moderate amounts of methaqualone, small
amounts of heroin, and cocaine bound
for southern Africa and possibly Europe;
a poorly developed financial infrastructure
coupled with a government commitment to
combating money laundering make it an
uViattractive venue for money launderers;
major consumer of cannabis','ace5854f5b9424603a81cbb81d42dd38d81a05c3f587d9bb54dab20c046f976d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec3ed3e175b7df2707947e6ee0a1dbdce7fc295be679187e31f6ebe8f9ccf1e',2010,'ZW','Zimbabwe','transnational-issues',1583,'Background: The UK annexed Southern
Rhodesia from the [British} South Africa
Company in 1923. A 1961 constitution
was formulated that favored whites in
power. In 1965 the government unilater¬
ally declared its independence, but the UK
did not recognize the act and demanded
more complete voting rights for the black
African majority in the country (then called
Rhodesia). UN sanctions and a guerrilla
uprising finally led to free elections in 1979
and independence (as Zimbabwe) in 1 980.
Robert MUGABE, the nation’s first prime
minister, has been the country’s only ruler
(as president since 1987) and has domi¬
nated the country’s political system since
independence. His chaotic land redistribu¬
tion campaign, which began in 2000, caused
an exodus of white farmers, crippled the
economy, and ushered in widespread short¬
ages of basic commodities. Ignoring inter¬
national condemnation, MUGABE rigged
the 2002 presidential election to ensure his
reelection. The ruling ZANU-PF party used
fraud and intimidation to win a two-thirds
majority in the March 2005 parliamentary
election, allowing it to amend the constitu¬
tion at will and recreate the Senate, which
had been abolished in the late 1980s. In
April 2005, Harare embarked on Opera¬
tion Restore Order, ostensibly an urban
rationalization program, which resulted in
the destruction of the homes or businesses
of 700,000 mostly poor supporters of the
opposition. President MUGABE in June
2007 instituted price controls on all basic
commodities causing panic buying and
leaving store shelves empty for months.
General elections held in March 2008
contained irregularities but still amounted
to a censure of the ZANU-PF-led govern¬
ment with significant gains in opposition
seats in parliament. MDC opposition
leader Morgan TSVANGIRAI won the
presidential polls, and may have won an
out right majority, but official results posted
by the Zimbabwe Electoral Committee did
not reflect dais. In die lead up to a run¬
off election in late June 2008, consider¬
able violence enacted against opposition
party members led to the withdrawal of
TSVANGIRAI from the ballot. Extensive
evidence of vote tampering and ballot-box
stuffing resulted in international condem¬
nation of the process. Difficult negotiations
over a power sharing agreement, allowing
MUGABE to remain as president and
creating the new position of prime minister
for TSVANGIRAI, were finally setded in
February 2009.
Disputes— international: Botswana built
electric fences and South Africa has placed
military along the border to stem the flow
of thousands of Zimbabweans fleeing to
find work and escape political persecu¬
tion; Namibia has supported, and in 2004
Zimbabwe dropped objections to, plans
between Botswana and Zambia to build a
bridge over the Zambezi River, thereby de
facto recognizing a short, but not clearly
delimited, Botswana-Zambia boundary in
the river
Refugees and internally displaced
persons: refugees (country of origin ): 2,500
(Democratic Republic of Congo)
I DPs: 569,685 (MUGABE-led political
violence, human rights violations, land
reform, and economic collapse) (2007)
Trafficking in persons: current situation:
Zimbabwe is a source, transit, and destina¬
tion country for men, women, and chil¬
dren trafficked for the purposes of forced
labor and sexual exploitation; large scale
migration of Zimbabweans to surrounding
countries— as they flee a progressively more
desperate situation at home— has increased;
rural Zimbabwean men, women, and chil¬
dren are trafficked internally to farms for
agricultural labor and domestic servitude
and to cities for domestic labor and commer¬
cial sexual exploitation; young men and
boys are trafficked to South Africa for farm
work, often laboring for months in South
Africa without pay before “employers” have
them arrested and deported as illegal immi¬
grants; young women and girls are lured
abroad with false employment offers that
result in involuntary domestic servitude
or commercial sexual exploitation; men,
women, and children from neighboring
states are trafficked through Zimbabwe
en route to South Africa
tier rating: Tier 2 Watch List— Zimbabwe
is on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts to
combat severe forms of human trafficking,
and because the absolute number of victims
of severe forms of trafficking is significantly
increasing; the trafficking situation in the
country is worsening as more of the popu¬
lation is made vulnerable by declining
socio-economic conditions (2008)
Illicit drugs: transit point for cannabis and
South Asian heroin, mandrax, and meth-
amphetamines en route to South Africa
763
/
1
\\ * < 1 ■
V
i
''
*
•
4
•
*■ ■ >.
V v
i
V
•
.• i
•
''V
-
! ■
4
:
''
''
’
APPENDIX A
ABBREVIATIONS
ABEDA
ACCT
ACP Group
AfDB
AFESD
Air Pollution
Air Pollution-Nitrogen Oxides
Air Pollution-Persistent
Organic Pollutants
Air Pollution-Sulphur 85
Air Pollution-Sulphur 94
Air Pollution-Volatile
Organic Compounds
AMF
Antarctic-Environmental Protocol
Antarctic Marine Living Resources
Antarctic Seals
ANZUS
APEC
Arabsat
ARF
ADB
ASEAN
AU
Autodin
BA
bbl/day
BCIE
BDEAC
Benelux
BIMSTEC
Biodiversity
BGN
BIS
BSEC
C
c.i.f.
CACM
CAEU
CAN
Caricom
CB
CBSS
CCC
CDB
CE
CEI
CEMAC
CEPGL
CERN
CEPT
CIS
CITES
Climate Change
Arab Bank for Economic Development in Africa
Agency for the French-Speaking Community (see International Organization of the French-
speaking World)
African, Caribbean, and Pacific Group of States
African Development Bank
Arab Fund for Economic and Social Development
Convention on Long-Range Transboundary Air Pollution
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the
Control of Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent
Organic Pollutants
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the
Reduction of Sulphur Emissions or Their Transboundary Fluxes by at Least 30%
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further
Reduction of Sulphur Emissions
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the
Control of Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Arab Monetary Fund
Protocol on Environmental Protection to the Antarctic Treaty
Convention on the Conservation of Antarctic Marine Living Resources
Convention for the Conservation of Antarctic Seals
Australia-New Zealand-United States Security Treaty
Asia-Pacific Economic Cooperation
Arab Satellite Communications Organization
ASEAN Regional Forum
Asian Development Bank
Association of Southeast Asian Nations
African Union
Automatic Digital Network
Baltic Assembly
barrels per day
Central American Bank for Economic Integration
Central African States Development Bank
Benelux Economic Union
Bay of Bengal Initiative for Multisectoral Technical and Economic Cooperation
Convention on Biological Diversity
United States Board on Geographic Names
Bank for International Settlements
Black Sea Economic Cooperation Zone
Commonwealth
cost, insurance, and freight
Central American Common Market
Council of Arab Economic Unity
Andean Community of Nations
Caribbean Community and Common Market
citizen’s band mobile radio communications
Council of the Baltic Sea States
Customs Cooperation Council
Caribbean Development Bank
Council of Europe
Central European Initiative
Economic and Monetary Community of Central Africa
Economic Community of the Great Lakes Countries
European Organization for Nuclear Research
Conference Europeanne des Poste et Telecommunications
Commonwealth of Independent States
see Endangered Species
United Nations Framework Convention on Climate Change
765
THE CIA WORLD FACTBOOK
Climate Change-Kyoto Protocol
COCOM
Comsat
COMESA
CP
CPLP
CSTO
CTBTO
CY
DC
DDT
Desertification
Kyoto Protocol to the United Nations Framework Convention on Climate Change
Coordinating Committee on Export Controls
Communications Satellite Corporation
Common Market for Eastern and Southern Africa
Colombo Plan
Comunidade dos Paises de Lingua Portuguesa
Collective Security Treaty Organization
Preparation commission for the Nuclear-Ban-Treaty Operation
calendar year
developed country
dichloro-diphenyl-trichloro-e thane
United Nations Convention to Combat Desertification in Those Countries Experiencing
Serious Drought and/or Desertification, Particularly in Africa
DIA
DSN
DST
DWT
EAC
EADB
EAEC
EAPC
EBRD
EC
ECA
ECE
ECLAC
ECO
ECOSOC
ECOWAS
ECSC
EEC
EFTA
EEZ
EIB
EMU
Endangered Species
United States Defense Intelligence Agency
Defense Switched Network
daylight savings time
deadweight ton
East African Community
East African Development Bank
Eurasian Economic Community
Euro-Atlantic Partnership Council
European Bank for Reconstruction and Development
European Community
Economic Commission for Africa
Economic Commission for Europe
Economic Commission for Latin America and the Caribbean
Economic Cooperation Organization
Economic and Social Council
Economic Community of West African States
European Coal and Steel Community
European Economic Community
European Free Trade Association
exclusive economic zone
European Investment Bank
European Monetary Union
Convention on the International Trade in Endangered Species of Wild Flora and Fauna
(CITES)
Entente
Environmental Modification
Council of the Entente
Convention on the Prohibition of Military or Any Other Hostile Use of Environmental
Modification Techniques
ESA
ESCAP
ESCWA
est.
EU
Euratom
Eutelsat
Ex-lm
f.o.b.
FAO
FAX
FLS
FOC
FSU
FY
FZ
G-2
G-3
G-5
G-6
G-7
G-8
European Space Agency
Economic and Social Commission for Asia and the Pacific
Economic and Social Commission for Western Asia
estimate
European Union
European Atomic Energy Community
European Telecommunications Satellite Organization
Export-Import Bank of the United States
free on board
Food and Agriculture Organization
facsimile
Front Line States
flags of convenience
former Soviet Union
fiscal year
Franc Zone
Group of 2
Group of 3
Group of 5
Group of 6
Group of 7
Group of 8
766
ABBREVIATIONS
6-9
G-10
G-15
G-ll
G-24
G-77
GATT
GCC
GCTU
GDP
GMT
GNP
GRT
GSM','069605c0c53224b00dc893826e1a0299677bfa62833a416d13ead2cfa4156e9e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ec9a45af20cfdc083395aa07ad94505217fd06fb5b8395289538999228e129f',2010,'','','transnational-issues',9,'Disputes - international:
Refugees and internally displaced persons:
refugees
IDPs
Trafficking in persons:
current situation
tier rating
Illicit drugs:
======================================================================
The World Factbook (2010) - Country Listing
[Transcriber''s note: To search on a country in this file, prefix the
country''s name with "@", e.g. "@Afghanistan". "Afghanistan" will find
all occurrences; prefixing it with "@" will find the correct location.]
World
A','e2c312d6be6f40f6c42b61340472603fc6f2f5f69a1dcc35f9967c29f49216cf','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('467eb629b8553ea16a2130627b28a06898e6722d912b6e743f1de626f5357442',2010,'ZW','Zimbabwe','transnational-issues',10,'T
Taiwan
E
European Union
======================================================================
Field Listings
[Transcriber''s note: To search on a field code in this file, prefix
the code number with "@", e.g. "@2001". "2001" will find all
occurrences; prefixing it with "@" will find the correct location.]
Code Field Description
2001 GDP (purchasing power parity)
2002 Population growth rate
2003 GDP - real growth rate
2004 GDP - per capita (PPP)
2005 Affiliation
2006 Dependency status
2007 Diplomatic representation from the US
2008 Transportation - note
2010 Age structure
2011 Geographic coordinates
2012 GDP - composition by sector
2013 Radio broadcast stations
2014
2015 Television broadcast stations
2016
2018 Sex ratio
2019 Heliports
2020 Elevation extremes
2021 Natural hazards
2022 People - note
2023 Area - comparative
2024 Military service age and obligation
2025 Manpower fit for military service
2026 Manpower reaching militarily significant age
2028 Background
2030 Airports - with paved runways
2031 Airports - with unpaved runways
2032 Environment - current issues
2033 Environment - international agreements
2034 Military expenditures
2038 Electricity - production
2042 Electricity - consumption
2043 Electricity - imports
2044 Electricity - exports
2045 Electricity - production by source
2046 Population below poverty line
2047 Household income or consumption by percentage share
2048 Labor force - by occupation
2049 Exports - commodities
2050 Exports - partners
2051 Administrative divisions
2052 Agriculture - products
2053 Airports
2054 Birth rate
2055 Military branches
2056 Budget
2057 Capital
2058 Imports - commodities
2059 Climate
2060 Coastline
2061 Imports - partners
2062
2063 Constitution
2064
2065
2066 Death rate
2068 Dependent areas
2070 Disputes - international
2075 Ethnic groups
2076 Exchange rates
2077 Executive branch
2078 Exports
2079 Debt - external
2080
2081 Flag description
2085 Roadways
2086 Illicit drugs
2087 Imports
2088 Independence
2089 Industrial production growth rate
2090 Industries
2091 Infant mortality rate
2092 Inflation rate (consumer prices)
2093 Waterways
2094 Judicial branch
2095 Labor force
2096 Land boundaries
2097 Land use
2098 Languages
2100 Legal system
2101 Legislative branch
2102 Life expectancy at birth
2103 Literacy
2105 Manpower available for military service
2106 Maritime claims
2107 International organization participation
2108 Merchant marine
2109 National holiday
2110 Nationality
2111 Natural resources
2112 Net migration rate
2113 Geography - note
2115 Political pressure groups and leaders
2116 Economy - overview
2117 Pipelines
2118 Political parties and leaders
2119 Population
2120 Ports and terminals
2121 Railways
2122 Religions
2123 Suffrage
2124 Telephone system
2125 Terrain
2127 Total fertility rate
2128 Government type
2129 Unemployment rate
2137 Military - note
2138 Communications - note
2140 Government - note
2141 Group
2142 Country name
2144 Location
2145 Map references
2146 Irrigated land
2147 Area
2149 Diplomatic representation in the US
2150 Telephones - main lines in use
2151 Telephones - mobile cellular
2152
2153 Internet users
2154 Internet country code
2155 HIV/AIDS - adult prevalence rate
2156 HIV/AIDS - people living with HIV/AIDS
2157 HIV/AIDS - deaths
2158
2172 Distribution of family income - Gini index
2173 Oil - production
2174 Oil - consumption
2175 Oil - imports
2176 Oil - exports
2177 Median age
2178 Oil - proved reserves
2179 Natural gas - proved reserves
2180 Natural gas - production
2181 Natural gas - consumption
2182 Natural gas - imports
2183 Natural gas - exports
2184 Internet hosts
2185 Investment (gross fixed)
2186 Public debt
2187 Current account balance
2188 Reserves of foreign exchange and gold
2189 Union name
2190 Political structure
2191 Member states
2192 Preliminary statement
2193 Major infectious diseases
2194 Refugees and internally displaced persons
2195 GDP (official exchange rate)
2196 Trafficking in persons
2198 Stock of direct foreign investment - at home
2199 Stock of direct foreign investment - abroad
2200 Market value of publicly traded shares
2201 Total renewable water resources
2202 Freshwater withdrawal
2203 Geographic overview
2204 Economy of the area administered by Turkish Cypriots
2205 School life expectancy (primary to tertiary
2206 Education expenditures
2207 Central bank discount rate
2208 Commercial bank prime lending rate
2209 Stock of money
2210 Stock of quasi money
2211 Stock of domestic credit
2212 Urbanization
2213 Broadcast media
2214 Stock of narrow money
2215 Stock of broad money
======================================================================
References :: Guide to Country Comparisons
Country Comparison pages are presorted lists of data from selected
Factbook data fields. Country Comparison pages are generally given
in descending order - highest to lowest - such as Population and
Area. The two exceptions are Unemployment Rate and Inflation Rate,
which are in ascending - lowest to highest - order. Country
Comparison pages are available for the following 58 fields in six of
the nine Factbook categories.','5fb14c0884a922c7d88a7489910e218bedc63e0c496c34ff268bc1112c710439','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10e4e1b619657613e845ac0f68e00fcb251aa04a1af47b15bfec3ac26ea742a1',2010,'TC','Turks and Caicos Islands','transnational-issues',29,'This category includes four entries - Disputes - international,
Refugees and internally displaced persons, Trafficking in persons,
and Illicit drugs - that deal with current issues going beyond
national boundaries.','89418a796b4285152b71e5f5bd753c4443456c4e6f9d7deec68e012a1d5041f8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

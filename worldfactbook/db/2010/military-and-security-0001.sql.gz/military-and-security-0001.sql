SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d92840b8ed842aa421e342e8df48a60a8f8f6530bf6c874236d0fbdd78beb836',2010,'US','United States','military-and-security',131,'Military branches
Military service age and obligation
Manpower available for military
service
males age 15-49
females age 15-49
Manpower fit for military service
males age 15-49
females age 15-49
Manpower reaching militarily
significant age annually
males
females
Military expenditures— percent of
GDP
Military— note
Military branches: United States Armed
Forces: US Army, US Navy (includes
Marine Corps), US Air Force, US Coast
Guard; note— Coast Guard administered in
peacetime by the Department of Homeland
Security, but in wartime reports to the
Department of the Navy (2009)
Military service age and obligation: 18
years of age (17 years of age with parental
consent) for male and female voluntary
service; maximum enlistment age 42 (Army),
720
UNITED STATES PACIFIC ISLAND WILDLIFE REFUGES
27 (Air Force), 34 (Navy), 28 (Marines);
service obligation 8 years, including 2-5 years
active duty (Army), 2 years active (Navy), 4
years active (Air Force, Marines) (2008)
Manpower available for military
Service: males age 16-49: 72,715,332
females age 16-49: 71,638,785 (2008 est.)
Manpower fit for military service:
males age 16-49: 59,764,677
females age 16-49: 59,437,663 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 2,196,124
female: 2,085,085 (2009 est.)
Military expenditures: 4.06% of GDP
(2005 est.)','95173bfec546eac6d748c0ca54a6258bf826097beb83818a10c83f830a995548','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60b09567ff3847a0661688822604633cb0ab421b76178ec77bb95cc659f5cd06',2010,'AF','Afghanistan','military-and-security',141,'Military branches: Afghan Armed Forces:
Afghan National Army (ANA, includes
Afghan National Army Air Corps) (2009)
Military service age and obligation: 22
years of age; inductees are contracted into
service for a 4-year term (2005)
Manpower available for military
service: males age 16-49: 7,431,147
females age 16-49: 7,004,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,371,193
females age 16-49: 4,072,945 (2009 est.)
Manpower reaching militarily
significant age annually: male. 382,720
female: 361,733 (2009 est.)
4
AKROTI RI
Military expenditures:
1.9% of GDP (2006 est.)
Military — note: Akrotiri has a foil RAF
base, Headquarters for British Forces
Cyprus, and Episkopi Support Unit
5
THE CIA WORLD FACTBOOK','b028261ae2e5b757ddcbbee6c1798da0823da390d9f16a7ee40fb6f078956b27','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85f91141aaea6fab899406c10522b22b3fb2828fa3ff6c9d8fa937a56c82247b',2010,'DZ','Algeria','military-and-security',152,'Military branches:
Joint Force Command (includes Land,
Naval, and Aviation Brigade Commands),
Joint Support Command (includes Logistic
Command), Training and Doctrine
Command (2009)
Military service age and obligation:
1 9 years of age (2004)
Manpower available for military
Service: males age 16-49: 944,592
females age 16-49: 908,527 (2008 est.)
Manpower fit for military service: males
age 16-49: 800,665
females age 16-49: 768,536 (2009 est.)
Military branches: National Popular Army
(ANP; includes Land Forces), Algerian
National Navy (MRA), Air Force (QJJ),
Territorial Air Defense Force (2005)
Military service age and obligation:
19-30 years of age for compulsory military
service; conscript service obligation— 1 8
months (6 months basic training, 12
months civil projects) (2006)
Manpower available for military
Service: males age 16-49: 9,736,757
females age 16-49: 9,590,978 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,317,473
females age 16-49: 8,367,005 (2009 est.)
Manpower reaching militarily significant
age annually: male: 375,852
female: 362,158 (2009 est.)
Militaryexpenditures:3.3%ofGDP(2006)','d4d3dbd5a1164b30d10b5b85fa0db44df8eecf97919d4cb4dd583bc14fdd8ee8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b7704ac80a61b93d946feb7cb36bd550d9f7ccd5714fd889a960109f9dd1b00',2010,'AD','Andorra','military-and-security',169,'Manpower fit for military service:
males age 16-49: 13,875
females age 16-49: 13,517 (2009 est.)
Manpower reaching militarily
significant age annually: male: 820
female : 802 (2009 est.)
Military— note: defense is the responsi¬
bility of the US','cfc333c2bc703544f0620c643dff9b9bf1454983a0f2c4aa7cf9ab0c861bb5c4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ff94729251e1fc2c0486a13b172d3f07151b7c4ca592b5a41864905c1a885a1',2010,'AO','Angola','military-and-security',179,'Military branches: no regular military
forces, Police Service of Andorra (2008)
Manpower available for military service:
males age 16-49: 18,685 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,617
females age 16-49: 17,613 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 402
female: 373 (2009 est.)
Military — note: defense is the responsibility
of France and Spain
Military branches: Armed Forces of the
Democratic Republic of the Congo (Forces
d’Armees de la Republique Democratique
du Congo, FARDC): Army, National Navy
(La Marine Nationale), Congolese Air
Force (Force Aerienne Congolaise, FAC)
(2008)
Military service age and obligation:
1 8—45 years of age for military service
Manpower available for military service:
males age 16-49: 14,101,263 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,925,355
females age 16-49: 9,047,356 (2009 est.)
Manpower reaching militarily
significant age annually: male. 814,199
female: 81 1 ,238 (2009 est.)
Military expenditures: 2.5% of GDP
(2006)','dd2fdb1312ee6d8c8f9fbe1fb6ba4149bc544351c581853f44d43990f5d9ba2a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36aac8b0bdad22cc272e94e346b8f5c81c66f6fa85d0a3942bf0b8e9f9ed451f',2010,'AI','Anguilla','military-and-security',183,'Military branches: Angolan Armed Forces
(FAA): Army, Navy (Marinha de Guerra
Angola, MGA), Angolan National Air
Force (Forca Aerea Nacional Angolana,
FANA) (2009)
Military service age and obligation:
22-24 years of age for compulsory military
service; conscript service obligation— 2
years; Angolan citizenship required (2009)
Manpower available for military service:
males age 16-49: 2,856,492
females age 16-49: 2,755,864 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,467,833
females age 16-49: 1,411,468 (2009 est.)
Manpower reaching militarily significant
age annually: male: 146,738
female: 143,478 (2009 est.)
Military expenditures:
5.7% of GDP (2006)
Manpower available for military service:
males age 16-49: 3,538 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,955
females age 16-49: 3,308 (2009 est.)
Manpower reaching militarily
significant age annually: male: 107
female: 106 (2009 est.)
Military — note: defense is the responsibility
of the UK','e4c918527c19c5c8e800b36558d0af3b30fd49dfd6cf94f4e879a339e6c3dfa7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d1b3b213608d1b034e4ba3d558c7156ebeb34e6dc39f761ce67ff58ed9f2882',2010,'AG','Antigua and Barbuda','military-and-security',200,'Military — note: the Antarctic Treaty
prohibits any measures of a military nature,
such as the establishment of military
bases and fortifications, the carrying out
of military maneuvers, or the testing of
any type of weapon; it permits the use
of military personnel or equipment for
scientific research or for any other peaceful
purposes
Military branches: Royal Antigua and
Barbuda Defense Force (2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military
Service: males age 16-49: 19,560
females age 16-49: 18,977 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,271
females age 16-49: 19,586 (2009 est.)
Manpower reaching militarily
significant age annually: male: 744
female: 743 (2009 est.)
Military expenditures: NA','757ba4d710d93376c638c9b8962876e804b6775409ad6c9977a5823223f9eef6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cf729f06ccf8522cc5769389e30c0da3561f20f820cb9edf218b4a895a9af9b',2010,'AR','Argentina','military-and-security',210,'Military branches: Argentine Army
(Ejercito Argentino), Navy of die Argentine
Republic (Armada Republica; includes naval
aviation and naval infantry), Argentine
Air Force (Fuerza Aerea Argentina, FAA)
(2009)
Military service age and obligation:
18-24 years of age for voluntary
military service (18-21 requires parental
permission); no conscription (2001)
Manpower available for military service:
males age 16-49: 10,029,488
females age 1 6-49: 9,889,002 (2008 est.)
Manpower fit for military service:
males age 1 6-49: 8,264,853
females age 1 6-49: 8,268,498 (2009 est.)
Manpower reaching militarily significant
age annually: male: 341,590
female: 326,342 (2009 est.)
Military expenditures:
1.3% of GDP (2005 est.)
Military — note: the Argentine military is
a well-organized force constrained by the
country’s prolonged economic hardship;
the country has recently experienced a
strong recovery, and the military is imple¬
menting a modernization plan aimed at
making the ground forces lighter and more
responsive (2008)','0847261f76f3df771b59bcbc55dbcaea228bb0fa84a0c533135f4b8f480c8d66','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d06eb100d69ed0d9a8690aefbfd0b2d87730146ede8f67cb93ba1b5b1a4eb6a8',2010,'AM','Armenia','military-and-security',218,'Military branches: Armed Forces: Ground
Forces, Air Force and Air Defense,
Nagorno-Karabakh Self Defense Force
(NKSDF) (2009)
Military service age and obligation:
1 8-27 years of age for voluntary or compul¬
sory military service; 2-year conscript service
obligation (2007)
Manpower available for military
Service: males age 16-49: 809,576
females age 16-49: 870,864 (2008 est.)
Manpower fit for miiifary service:
males age 16-49: 642,734
females age 16-49: 729,047 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 27,293
female: 25,574 (2009 est.)
Military expenditures:
6.5% of GDP (FY01)','e9378c6038e7aa1e9076a789b62bf2c1f2f8dd1e01a78d82d7c8f543c8893fd3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcbbcbdc98f1ba542bde873b7267502eceeebb6318c787c9449f806f6a0ff2a0',2010,'NL','Netherlands','military-and-security',227,'Military branches: no regular military
forces; the Netherlands maintains a detach¬
ment of marines, a frigate, and an amphib¬
ious combat detachment in the neigh¬
boring Netherlands Antilles (2009)
Manpower available for military
service: males age 16-49: 24,585
females age 16-49: 25,742 (2008 est.)
Manpower fit for military service:
males age 16-49: 20,287
females age 16-49: 21,232 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 722
female: 711 (2009 est.)
Military — note: defense is the responsibility
of the Kingdom of the Netherlands
Military — note: defense is the responsibility
of Australia; periodic visits by the Royal
Australian Navy and Royal Australian Air
Force
Military branches: Royal Netherlands
Army, Royal Netherlands Navy (includes
Naval Air Service and Marine Corps),
Royal Netherlands Air Force (Koninklijke
Luchtmacht, KLu), Royal Military Police
(2009)
Military service age and obligation:
20 years of age for an all-volunteer force
(2004)
Manpower available for military service:
males age 16-49: 3,950,825
females age 16-49: 3,850,800 (2008 est.)
Manpower fit for military service: males
age 16-49: 3,224,79 0
females age 16-49: 3,143,096 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 105,194
female: 100,341 (2009 est.)
Military expenditures: 1.6% of GDP
(2005 est.)
Military branches: no regular military
forces; National Guard (2008)
Military service age and obligation: 16
years of age for National Guard recruit-
ment; no conscription (2004)
Manpower available for military service:
males age 16-49: 55,365
females age 16-49: 57,060 (2008 est.)
Manpower fit for military service: males
age 16-49: 46,461
females age 16-49: 47,325 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 1,920
female: 1,827 (2009 est.)
Military — note:
defense is the responsibility of the
Kingdom of the Netherlands','fe5907f8548015a9b91aa0e51e78131049253bf3eba33edbc2608dd0aa1316b7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15a795b215364a1342de9eb68f292abe6e1995f71f7de25c4bd53af7a7b4e40b',2010,'AU','Australia','military-and-security',240,'Military branches: Australian Defense
Force (ADF): Australian Army, Royal
Australian Navy, Royal Australian Air
Force, Special Operations Command
(2006)
Military service age and obligation: 17
years of age for voluntary military service
(with parental consent); no conscription;
women allowed to serve in Army combat
units in non-combat support roles (2008)
Manpower available for military
service: males age 16-49: 4,999,988
females age 16-49: 4,870,043 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,341,591
females age 16-49: 4,179,659 (2009 est.)
Manpower reaching militarily
significant age annually: male: 144,959
female: 137,333 (2009 est.)
Military expenditures:
2.4% of GDP (2006)
Military— note: defense is the responsi¬
bility of die US','edae03a3ddcffc72fdadf9d17bc705f2a43d8fe8c1edfe390549be389a303e91','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52017f534c40b017fc5bbf811ab49021601c7ed2fc3d9597fb78fcecd0a72f36',2010,'AZ','Azerbaijan','military-and-security',248,'Military branches: Land Lorces
(KdoLdSK), Air Lorces (KdoLuSK)
Military service age and obligation:
18-35 years of age for compulsory military
service; 16 years of age for male or female
voluntary service; service obligation 6
months of training, followed by an 8-year
reserve obligation (2008)
Manpower available for military service:
males age 16-49: 1,986,411
females age 1 6-49: 1 ,944,834 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,607,456
females age 16-49: 1,576,335 (2009 est.)
Manpower reaching militarily
significant age annually: male. 50,540
female: 48,042 (2009 est.)
Military expenditures:
0.9% of GDP (2005 est.)
Military branches: Army, Navy, Air and
Air Defense Forces (2008)
Military service age and obligation: men
between 18 and 35 are liable for military
service; 18 years of age for voluntary mili¬
tary service; length of military service is
18 months and 12 months for university
graduates (2006)
Manpower available for military
service: males age 16-49: 2,278,888
females age 16-49: 2,291,770 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,727,464
females age 16-49: 1,944,260 (2009 est.)
Manpower reaching militariiy
significant age annually:
male: 90,416
female: 85,344 (2009 est.)
Military expenditures:
2.6% of GDP (2005 est.)
Military branches: Royal Bahamian
Defense Force: Land Force, Navy, Air
Wing (2009)
Military service age and obligation: 18
years of age (est.); no conscription (2008)
Manpower available for military service:
males age 16-49: 80,200 (2008 est.)
Manpower fit for military service:
males age 16-49: 50,764
females age 16-49: 51,690 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 2,992
female: 3,003 (2009 est.)
Military expenditures:
0.5% of GDP (2006)','c07be20eeb8c24107192beae76112463cb27d74f040f17ccbb0eecadf4274584','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e740062022059831f33f2cd86a6e842f79146b7d5206e6e54cf6ddd463c5d87d',2010,'BD','Bangladesh','military-and-security',262,'Military branches: Bahrain Defense
Forces (BDF): Ground Force (includes Air
Defense), Naval Force, Air Force, National
Guard
Military service age and obligation: 17
years of age for voluntary military service;
1 5 years of age for NCOs, technicians, and
cadets; no conscription (2008)
Manpower available for military
service: males age 16-49: 210,938
females age 16-49: 170,471 (2008 est.)
Manpower fit for military service: males
age 16-49: 171,004
females age 16-49: 144,555 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 6,612
female : 6,499 (2009 est.)
Military expenditures: 4.5% of GDP (2006)
Military branches: Bangladesh Defense
Force: Bangladesh Army (Sena Bahini),
Bangladesh Navy (Noh Bahini, BN), Bang¬
ladesh Air Force (Biman Bahini, BAF)
(2009)
Military service age and obligation: 16
years of age for voluntary military service;
17 years of age for officers (both with
parental consent); conscription legally
possible in emergency, but has never been
implemented (2008)
Manpower available for military service:
males age 16-49: 41,199,340 (2008 est.)
Manpower fit for military service:
males age 16-49: 24,946,041
females age 16-49: 31,409,069 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 1,538,865
female: 1,666,67 0 (2009 est.)
Military expenditures:
1.5% of GDP (2006)
60','27023a01ef535e70eeff731450d80f8c004085d651b23e5c38b2ed64796f76b4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80d898c31496e01ca7388b5c55b4ee3626443108d942825eed484bb90de47173',2010,'BB','Barbados','military-and-security',274,'Military branches: Royal Barbados Defense
Force: Troops Command, Barbados Coast
Guard (2007)
Military service age and obligation: 18
years of age for voluntary military service
(younger requires parental consent); no
conscription (2008)
Manpower available for military
Service: males age 16-49: 75,265
females age 16-49: 75,389 (2008 est.)
Manpower fit for military service: males
age 16-49: 58,596
females age 1 6-49: 58,866 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 2,015
female: 2,007 (2009 est.)
Military expenditures:
0.5% of GDP (2006 est.)
Military — note: the Royal Barbados
Defense Force includes a land-based
Troop Command and a small Coast
Guard; the primary role of the land
element is to defend the island against
external aggression; the Command
consists of a single, part-time battalion
with a small regular cadre that is deployed
throughout the island; it increasingly
supports the police in patrolling the
coastline to prevent smuggling and other
illicit activities (2007)','527103aaaeac232e41fe735ab14b38e579a9dea0e7e423de0012a97c3e6e790e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26290c39e7fe213722b275e74b28d4479499ff4d7114a6da2cca9a1bf4fd2a2c',2010,'BE','Belgium','military-and-security',283,'Military branches: Belarus Armed Forces:
Land Force, Air and Air Defense Force
(2009)
Military service age and obligation:
18-27 years of age for compulsory military
service; conscript service obligation— 1 8
months (2005)
Manpower available for military
service:
males age 16-49: 2,491,643
females age 16-49: 2,528,779 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,720,049
females age 16-49: 2,069,898 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 60,009
female: 56,834 (2009 est.)
Military expenditures:
1.4% of GDP (2005 est.)','0a0a43d0054524ea7cd2f8eef1ee7ce9c74ad19715c9a12eca2725090b828860','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9381ec42b0de91dff3d8fe82d859f18de7edfe37f69517412726dff371455085',2010,'FR','France','military-and-security',291,'Military branches: Belgian Armed Forces:
Land Operations Command, Naval
70
Military branches: Finnish Defense Forces
(FDF): Army, Navy (includes Coastal
Defense Forces), Air Force (Suomen Ilma-
voimat) (2007)
Military service age and obligation: 18
years of age for male voluntary and compul¬
sory— and female voluntary— national mili¬
tary and nonmilitary service; service obliga¬
tion 6-12 months; mandatory retirement at
age 60 (2008)
Manpower available for military service:
males age 16-49: 1,169,910
females age 16-49: 1,121,187 (2008 est.)
Manpower fit for military service: males
age 16-49: 962,479
females age 16-49: 920,297 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 33,784
female: 32,621 (2009 est.)
Military expenditures: 2% of GDP (2005
est.)
Manpower fit for military service: males
age 16-49: 3,273
females age 16-49: 3,297 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 175
female: 164 (2009 est.)
Military — note: defense is the responsi¬
bility of France
Manpower fit for military service:
males age 16-49: 545,653
females age 16-49: 515,102 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 30,233
female: 28,745 (2009 est.)
Military expenditures: NA
747
THE CIA WORLD FACTBOOK','ca33d7d9d718304be60147a6ff1f006b7cd8ffd1e9c401f28d862674acb0b245','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1510341e50c62b62f168e491dbda0f3f98dfd39f3ac9107e7c09eb1409fa32c8',2010,'BZ','Belize','military-and-security',292,'Operations Command, Air Operations
Command (2009)
Military service age and obligation: 18
years of age for voluntary military service;
conscription suspended (2008)
Manpower available for military
Service: males age 16-49: 2,407,128
females age 16-49: 2,340,039 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,962,409
females age 16-49: 1,905,178 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 62,722
female: 59,969 (2009 est.)
Military expenditures:
1.3% of GDP (2005 est.)
Military branches: Belize Defense Force
(BDF): Army, BDF Air Wing, BDF
Volunteer Guard (2009)
Military service age and obligation: 18
years of age for voluntary military service;
laws allow for conscription only if volunteers
are insufficient; conscription has never been
implemented; volunteers typically outnumber
available positions by 3:1 (2008)
Manpower available for military service:
males age 16-49: 74,605
females age 1 6-49: 72,926 (2008 est.)
Manpower fit for military service:
males age 16-49: 56,135
females age 16-49: 54,732 (2009 est.)
73
THE CIA WORLD FACTBOOK
Manpower reaching militarily
significant age annually: male: 3,632
female: 3,500 (2009 est.)
Military expenditures:
1.4% of GDP (2006)','8fa7cda387a7f1ece3ca963e6b4f87f96f8ae50b845b75db084464481f886ca7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab84842adfdd052737a2745d7c6cb3a8de12a9e6b4a8e70bf70766345076ac8b',2010,'BM','Bermuda','military-and-security',308,'Military branches: Benin Armed Forces
(FAB): Army (l’Arme de Terre), Benin
Navy (Forces Navales Beninois, FNB),
Benin People’s Air Force (Force Aerienne
Populaire de Benin, FAPB) (2008)','1dabb052a4b0f522b2adbe33438e59838ece351cf30e3ffa87e26d3f8e3cf1bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d22410db36fed0d0b0e1bf3447ad76c07a030088b9fdef86e00507a04a24a325',2010,'BT','Bhutan','military-and-security',317,'Military branches:
Bermuda Regiment (2008)
Military service age and obligation:
18-23 years of age; eligible men required
to register for conscription as needed into
the Bermuda Regiment, which is largely
voluntary; term of service 39 months
(2007)
Manpower available for military service:
males age 16-49: 15,623 (2008 est.)
Manpower fit for military service:
males age 1 6-49: 1 2,496
females age 16-49: 12,486 (2009 est.)
Manpower reaching militarily
significant age annually: male: 426
female: 413 (2009 est.)
Military expenditures: 0.11% of GDP
(2005 est.)
Military — note: defense is the responsi¬
bility of the UK
Military branches: Royal Bhutan Army
(includes Royal Bodyguard and Royal
Bhutan Police) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military
Service: males age 16-49: 190,104
females age 16-49: 167,289 (2008 est.)
Manpower fit for military service:
males age 16-49: 150,210
females age 16-49: 135,991 (2009 est.)
Manpower reaching militarily significant
age annually: male. 7,668
female: 7,379 (2009 est.)
Military expenditures:
1% of GDP (2005 est.)
Military branches: Bolivian Armed Forces:
Bolivian Army (Ejercito Boliviano, EB),
Bolivian Navy (Fuerza Naval Boliviana,
FNB; includes marines), Bolivian Air Force
(Fuerza Aerea Boliviana, FAB) (2009)
Military service age and obligation:
1 8-49 years of age for 1 2-month compulsory
military service; when annual number of
volunteers falls short of goal, compulsory
recruitment is effected, including conscrip¬
tion of boys as young as 14; 15-19 years
of age for voluntary premilitary service,
provides exemption from further military
service (2009)
Manpower available for military
service: males age 16-49: 2,295,746
females age 1 6-49: 2,366,828 (2008 est.)
Manpower fit for military service:
males age 1 6-49: 1 ,666,697
females age 16-49: 1,906,396 (2009 est.)
Manpower reaching militarily
significant age annually: male: 108,304
female: 104,882 (2009 est.)
Military expenditures:
1.9% of GDP (2006)','86f783e322fb85f4b8038304eb088881d4621f58ea2861b15f93e9bdde790f02','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e8677a9feda041fe656115b9c39c4d2334b766c2c38ae677ad042674c72e1db',2010,'BA','Bosnia and Herzegovina','military-and-security',329,'Military branches: Bosnia and
Herzegovina Armed Forces (OSBiH):
Army of Bosnia and Herzegovina, Air
and Air Defense Forces of Bosnia and
Herzegovina (Zrakoplovstvo i Protuzracna
Obrana, ZPO) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
conscription abolished January 2006;
4-month service obligation (2009)
Manpower available for military
service:
males age 16-49: 1,212,007
females age 16-49: 1,170,645 (2008 est.)
Manpower fit for military service:
males age 16-49: 991,953
females age 1 6-49: 959,226 (2009 est.)
Manpower reaching militarily
significant age annually: male: 27,368
female: 25,644 (2009 est.)
Military expenditures: 4.5% of GDP
(2005 est.)','b6d85e244e8ee4c689ae79f553a3b72258aea0f7e7b348e88d36723bb5f3f073','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4bb3cf309e5fae1efffa5987012046eb8b6f9b2d2f6a676ec3f511a8433be2b',2010,'BW','Botswana','military-and-security',337,'Military branches: Botswana Defense
Force: Ground Forces (includes Air Arm)
(2009)
Military service age and obligation: 18
is the apparent age of voluntary military
service; the official qualifications for
determining minimum age are unknown
(2001)
Manpower available for military
service: males age 16-49: 487,853
females age 16-49: 464,278 (2008 est.)
Manpower fit for military service:
males age 16-49: 341,190
females age 16-49: 315,588 (2009 est.)
Manpower reaching militarily
significant age annually: male: 23,420
female: 22,904 (2009 est.)
Military expenditures: 3.3% of GDP
(2006)','a815e49d6cb648c297f377b8fdf41b501cc15390f4f74398617010ef15d1387f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dfe126df5902dea70947347182c51c7dcbd6a7733fe97b7f34015aaa561c52b',2010,'IO','British Indian Ocean Territory','military-and-security',350,'Military branches: Brazilian Army
(Exercito Brasileiro, EB), Brazilian Navy
(Marinha do Brasil (MB), includes Naval
Air and Marine Corps (Corpo de Fuzileiros
Navais)), Brazilian Air Force (Forca Aerea
Brasileira, FAB) (2009)
Military service age and obligation:
21-45 years of age for compulsory military
service; conscript service obligation— 9 to
12 months; 17-45 years of age for volun¬
tary service; an increasing percentage of the
ranks are “long-service” volunteer profes¬
sionals; women were allowed to serve in the
armed forces beginning in early 1 980s when
the Brazilian Army became the first army in
South America to accept women into career
ranks; women serve in Navy and Air Force
only in Women’s Reserve Corps (2001)
Manpower available for military
Service: males age 16-49: 52,449,957
females age 16-49: 52,375,921 (2008 est.)
Manpower fit for military service: males
age 16-49: 38,043,555
females age 16-49: 44,267,520 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 1,690,031
female: 1,630,851 (2009 est.)
Military expenditures: 2.6% of GDP
(2006 est.)
Military — note: defense is the responsibility
of the UK; the US lease on Diego Garcia
expires in 2016
Manpower available for military service:
males age 16-49: 7,101 (2008 est.)
Manpower fit for military service: males
age 16-49: 5,979
females age 16-49: 5,738 (2009 est.)
Manpower reaching militarily
significant age annually: male: 178
female: 173 (2009 est.)
Military — note: defense is the responsi¬
bility of die UK','68ecaadfa58a9874a08bda594bafb437fdca27e71681a3594251e4c5da0c5968','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('340581bb2e4d63287bbdcdeb7243acc4f05b332af991dd5745228d0ff0df114a',2010,'BG','Bulgaria','military-and-security',366,'Military branches: Royal Brunei Armed
Forces (RBAF): Royal Brunei Land Forces,
Royal Brunei Navy, Royal Brunei Air Force
(Tentera Udara Diraja Brunei) (2009)
Military service age and obligation: 18
years of age (est.) for voluntary military
service; non-Malays are ineligible to serve
(2007)
Manpower available for military
service:
males age 16-49: 108,356
females age 16-49 : 110,153 (2008 est.)
Manpower fit for military service:
males age 16-49: 92,543
females age 16-49: 95,301 (2009 est.)
Manpower reaching militarily
significant age annually: male: 3,460
female: 3,399 (2009 est.)
Military expenditures: 4.5% of GDP
(2006)
Military branches: Bulgarian Armed
Forces: Ground Forces, Naval Forces,
106','7da17d03ed6eb414f8a04b875d4575921a21deb96241156a82f5f2f8e657b378','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1904e8227914c00056bf19c76f119184e133b51f302ef3d8c05e25519d928c41',2010,'BF','Burkina Faso','military-and-security',371,'Bulgarian Air Forces (Bulgarski
Voennovazdyshni Sily, BWS) (2009)
Military service age and obligation:
18-27 years of age for voluntary mili¬
tary service; as of May 2006, 67% of the
Bulgarian Army comprised of professional
soldiers; conscription ended January 2008;
Air Forces and Naval Forces became fully
professional at the end of 2006 (2008)
Manpower available for military
Service: males age 16-49: 1,701,979
females age 16-49: 1,691,092 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,351,312
females age 16-49: 1,381,017 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 38,263
female: 36,374 (2009 est.)
Military expenditures:
2.6% of GDP (2005 est.)
Military branches: Army, Air Force of
Burkina Faso (Force Aerienne de Burkina
Faso, FABF), National Gendarmerie (2009)
Military service age and obligation: 18
years of age for voluntary military service;
women may serve in supporting roles (2009)
Manpower available for military service:
males age 16-49: 3,364,288 (2008 est.)
Manpower fit for military service: males
age 16-49: 2,197,557
females age 16-49: 2,191,978 (2009 est.)
Manpower reaching militarily
significant age annually: male: 182,540
female: 180,051 (2009 est.)
Military expenditures:
1.2% of GDP (2006)
Military branches: Myanmar Armed
Forces (Tatmadaw): Army, Navy, Air Force
(Tatmadaw Lay) (2008)
Military service age and obligation: 18
years of age for voluntary military service
for both sexes; forced conscription of chil¬
dren, although officially prohibited, report¬
edly continues (2007)
Manpower available for military
Service: males age 16-49: 13,402,788
females age 16-49: 13,437,042 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,146,312
females age 16-49: 9,520,852 (2009 est.)
Manpower reaching militarily
significant age annually: male: 426,110
female: 417,674 (2009 est.)
Military expenditures: 2.1% of GDP
(2005 est.)','6d17bc54b766bce70aa8405e9d40c75828731a09fd9d6f940b865a4b651e3ea2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ac6fe88fbca1933d67e7b5aec9b9f395455b180ebf682a1c46a24a439dcbf56',2010,'BI','Burundi','military-and-security',385,'Military branches: National Defense
Force (Forces de Defense Nationales,
FDN): Army (includes Naval Detachment
and Air Wing), Gendarmerie (2008)
Military service age and obligation: 16
years of age for compulsory and voluntary
military service; children as young as 10
years of age have been conscripted into the
armed forces; the enrollment of children is
still not prohibited (2007)
Manpower available for military
Service: males age 16-49: 1,878,544
females age 16-49: 1,851,676 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,124,072
females age 16-49: 1,102,729 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 101,402
female: 101,897 (2009 est.)
Military expenditures: 5.9% of GDP
(2006 est.)','125b17d182a0e0d590ed263302ecc0666a24a8ef402e8c1d93b0d1ffb270369c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c376104e52bf4ac0fe44c084bff627bdb31e3168dc79a7f95cb370342c328df8',2010,'CM','Cameroon','military-and-security',394,'Military branches: Royal Cambodian
Armed Forces: Royal Cambodian Army,
Royal Khmer Navy, Royal Cambodian Air
Force (2009)
Military service age and obligation:
conscription law of October 2006 requires
all males between 1 8—30 to register
for military service; 18-month service
obligation (2006)
Manpower available for military
Service: males age 16-49: 3,759,034
females age 16-49: 3,784,333 (2008 est.)
Military branches: Cameroon Armed
Forces: Army, Navy (includes naval
infantry), Air Force (Armee de l’Air du
Cameroun, AAC) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription; the government makes
periodic calls for volunteers (2006)
Manpower available for military
service: males age 16-49: 4,321,175
females age 16-49: 4,228,625 (2008 est.)
Manpower fit for military service:
males age 1 6-49: 2,645,601
females age 16-49: 2,574,948 (2009 est.)
Manpower reaching militarily
significant age annually: male. 213,027
female: 208,642 (2009 est.)
Military expenditures: 1.3% of GDP
(2006)','6acde4ff03de152bdbffeaa3041498c3215cab4f49cd489a429f5e6306fed3dc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cef91151860ab7766227b1b07709ede45cc0a9578f7d36dfab319f6a0c6193d',2010,'CA','Canada','military-and-security',406,'Military branches: Canadian Forces:
Land Forces Command (LFC), Maritime
Command (MARCOM), Air Command
(AIRCOM), Canada Command (home¬
land security) (2009)
Military service age and obligation: 17
years of age for male and female voluntary
military service (with parental consent); 16
years of age for reserve and military college
applicants; Canadian citizenship or perma¬
nent residence status required; maximum
34 years of age; service obligation 3—9
years (2008)
Manpower available for military service:
males age 16-49: 8,072,010
females age 16—49: 7,813,462 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,647,513
females age 16-49: 6,413,748 (2009 est.)
Manpower reaching militarily
significant age annually: male: 223,238
female: 210,797 (2009 est.)
Military expenditures: 1.1% of GDP
(2005 est.)','179d0309537071344d1b625bbc0605a298817ef56e1bd9fe1aa7283e9b3fbc82','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0beed935c4468bd35fcbf84dd38c58b5689826944d7075844337298257bfa448',2010,'SN','Senegal','military-and-security',414,'Military branches: People’s Revolutionary
Armed Forces (FARP): Army, Coast Guard
(includes maritime air wing) (2007)
Military service age and obligation: 18
years of age (est.) for selective compulsory
military service; 1 4-month conscript service
obligation (2006)
Manpower available for military
Service: males age 16-49: 103,650
females age 16-49: 103,553 (2008 est.)
Manpower fit for military service:
males age 16-49: 84,967
females age 16-49: 90,154 (2009 est.)
Manpower reaching militarily
significant age annually: male: 5,471
female: 5,349 (2009 est.)
Military expenditures: 0.7%ofGDP(2005)
Military service age and obligation: 18
years of age (est.); no conscription (2004)
Manpower available for military service:
males age 16-49: 8,547,441
females age 16-49: 6,381,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,486,622
females age 16-49: 5,652,819 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 278,179
female: 267,905 (2009 est.)
Military expenditures: 10% of GDP
(2005 est.)
Military branches: Army, Senegalese Navy
(Marine Senegalaise), Senegalese Air Force
(Armee de 1’ Air du Senegal) (2008)
Military service age and obligation:
1 8 years of age for compulsory and
voluntary military service; conscript service
obligation— 2 years (2004)
Manpower available for military
service: males age 16-49: 2,943,619
females age 16-49: 2,955,179 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,038,508
females age 16-49: 2,207,510 (2009 est.)
Manpower reaching militarily
significant age annually: male. 154,249
female: 153,679 (2009 est.)
Military expenditures:
1.4% of GDP (2005 est.)','b9c32d61f8b878327191b496c988c41eed62b23ccf1827af8bddc2b1f7750c25','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1bc38ed8b064d4b82a8c414993a248c060f322a79052381e72c35f2a7b8a3d9',2010,'CF','Central African Republic','military-and-security',424,'Military branches: no regular military
forces; Royal Cayman Islands Police Force
(2007)
Manpower available for military service:
males age 16-49: 11,790 (2008 est.)
Manpower fit for military service:
males age 16-49: 9,735
females age 16-49: 10,145 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 334
female: 345 (2009 est.)
Military — note: defense is the responsi¬
bility of the UK
Military branches: Central African
Armed Forces (Forces Armees Centrafric-
aines, FACA): Ground Forces, General
Directorate of Gendarmerie Inspection
(DGIG), Military Air Service, National
Police (2008)
Military service age and obligation: 18
years of age for selective military service; 2-
year conscript service obligation (2008)
Manpower available for military service:
males age 16—49: 1,032,828
females age 16-49: 999,330 (2008 est.)
Manpower fit for military service:
males age 16-49: 552,907
females age 16-49: 512,611 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 55,484
female: 55,168 (2009 est.)
Military expenditures: 1.1% of GDP
(2006 est.)','f2c7799ea574637dada174fed5f3052ba8172adad44d94f170bd5286a46ccbac','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d7b0ac22d34753b60242afc06c03f28425210bbe261da7f0dacfe78e4a7ed60',2010,'CL','Chile','military-and-security',437,'Military branches: Armed Forces: Chadian
National Army (Armee Nationale du Tchad,
ANT), Chadian Air Force (Force Aerienne
Tchadienne, FAT), Gendarmerie (2008)
Military service age and obligation: 20
years of age for conscripts, with 3-year
service obligation; 18 years of age for
volunteers; no minimum age restriction for
volunteers with consent from a guardian;
women are subject to 1 year of compulsory
military or civic service at age of 21 (2004)
Manpower available for military
Service: males age 1 6-49 : 1 ,906,545
females age 16-49: 2,258,758 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,103,006
females age 16—49: 1,315,620 (2009 est.)
Manpower reaching militarily
significant age annually: male. 121,080
female: 121,585 (2009 est.)
Military expenditures: 4.2% of GDP
(2006)
Background: Prior to the coming of the
Spanish in the 16th century, northern
Military branches: Army of the Nation,
Chilean Navy (Armada de Chile, includes
naval air, marine corps, and Maritime
Territory and Merchant Marine Directorate
(Directemar)), Chilean Air Force (Fuerza
Aqrea de Chile, FACh), Carabineros
Corps (Cuerpo de Carabineros) (2008)
Military service age and obligation:
1 8—45 years of age for voluntary male and
female military service, although the right
to compulsory recruitment is retained;
service obligation— 1 2 months for Army,
22 months for Navy and Air Force (2008)
Manpower available for military
Service: males age 16-49: 4,242,912
females age 16-49: 4,182,509 (2008 est.)
Manpower fit for military service: males
age 16-49: 3,573,165
females age 16—49: 3,523,649 (2009 est.)
Manpower reaching militarily
significant age annually: male. 145,766
female: 1 39,648 (2009 est.)
Military expenditures^. 7%ofGDP(2006)','322d073ffa7b2d3b2c2180e53274b539e45d60c0d5f2a6f2b1466bddd4e3c761','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452732b01c6e29a3490dacdd845a82a6eaeabd1a2e34848321d80fd68279d3ba',2010,'CN','China','military-and-security',450,'Military branches: People’s Liberation
Army (PLA): Ground Forces, Navy
(includes marines and naval aviation),
Air Force (includes airborne forces), and
Second Artillery Corps (strategic missile
force); People’s Armed Police (PAP); PLA
Reserve Force (2009)
Military service age and obligation:
18—22 years of age for selective compul¬
sory military service, with 24-month service
obligation; no minimum age for voluntary
service (all officers are volunteers); 18—19
years of age for women high school gradu¬
ates who meet requirements for specific
military jobs (2007)
Manpower available for military
service: males age 16—49: 375,009,345
146
Military branches: Army, Navy (includes
Marine Corps), Air Force, Coast Guard
Administration, Armed Forces Reserve
Command, Combined Service Forces
Command, Armed Forces Police
Command
Military service age and obligation: 19-
35 years of age for male compulsory mili¬
tary service; service obligation 14 months
(reducing to 1 year in 2009); women
may enlist; women in Air Force service
are restricted to noncombat roles; reserve
obligation to age 30 (Army); the Ministry
of Defense has announced plans to imple¬
ment an incremental voluntary enlistment
system beginning 2010, with 10% fewer
conscripts each year thereafter, although
nonvolunteers will still be required to
perform alternative service or go through
3-4 months of military training (2009)
Manpower available for military
service: males age 16-49: 6,283,134
females age 16-49: 6,098,599 (2008 est.)
Manpower fit for military service: males
age 16-49: 5,106,730
females age 1 6-49: 5,008,563 (2009 est.)
662','42b5e4571ee8c45fd6a089ada34b040606d4255325b5402cd347469222347849','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d11f7c0fad36c51737762843a05a7e9971b60c4294bc1db1e4313cb752bcc260',2010,'CX','Christmas Island','military-and-security',451,'females age 16-49: 354,314,328
(2008 est.)
Manpower fit for military service:
males age 16-49: 314,459,083
females age 16-49: 296,763,134
(2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 10,621,373
female: 9,533,880 (2009 est.)
Military expenditures: 4.3% of GDP
(2006)
Military — note: defense is the responsi¬
bility of Australia
.
Military — note: defense is the
bility of France
responsi-','e30a07da0b21d5edf2648b66e61d7fdb74a84433f35da9bf7e714c854c66739c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e57621a46d6ceaa5104bcc11759d6a20375009dc9fc64e35005d537e1b845371',2010,'CO','Colombia','military-and-security',467,'Military— note: defense is the response
bility of Australia; the territory has a five-
person police force
Military branches: National Army
(Ejercito Nacional), National Navy (Armada
Nacional, includes Naval Aviation, Naval
Infantry (Infanteria de Marina, Colmar),
and Coast Guard), Colombian Air Force
(Fuerza Aerea de Colombia, FAC) (2008)
Military service age and obligation: 18-
24 years of age for compulsory and volun¬
tary military service; service obligation— 1 8
months (2004)
Manpower available for military service:
males age 16-49: 11,478,109
females age 16—49: 11,809,279 (2008 est.)
Manpower fit for military service: males
age 16-49: 8,212,944
females age 16-49: 10,045,435 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 446,432
female: 437,164 (2009 est.)
Military expenditures: 3.4% of GDP
(2005 est.)','c5ac5a93a8fb695961fc2c489f11c4e8aabd3e4b32f40fa548cdc82d6494e1e8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79e5179a97eef7b95555fcb33d74a820e63a894329fe6abe72d1903c07ea4f2d',2010,'KM','Comoros','military-and-security',482,'Military branches: National Development
Army (AND): Comoran Security Force;
Comoran Federal Police (2008)
Manpower available for military
Service: males age 16—49: 167,850
females age 16-49: 167,362 (2008 est.)
Manpower fit for military service:
males age 16-49: 125,747
females age 16-49: 135,707 (2009 est.)
Manpower reaching militarily
significant age annually: male: 8,203
female: 8,188 (2009 est.)
Military expenditures: 2.8% of GDP
(2006)','f1933ec6088c03cb0431a3b3295e45298acf96330850dd7f4ba5ff7b7eefa75c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9197827052d9e13f50817c44f17a456e9eeb47528c8334c95f0175ab0dce3b37',2010,'CG','Congo','military-and-security',487,'Military branches: Congolese Armed
Forces (Forces Armees Congolaises,
FAC): Army, Navy, Congolese Air Force
(Armee de l’Air Congolaise), Gendar¬
merie, Special Presidential Security Guard
(GSSP) (2008)
Military service age and obligation: 18
years of age for voluntary military service;
women allowed to serve (2007)
Manpower available for military
Service: males age 16-49: 842,771
females age 16-49: 833,624 (2008 est.)
Manpower fit for military service: males
age 16-49: 538,202
females age 16-49: 527,649 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 46,976
female: 46,490 (2009 est.)
Military expenditures: 3.1% of GDP
(2006)
Background: Named after Captain
COOK, who sighted them in 1770, the
islands became a British protectorate in
1888. By 1900, administrative control was
transferred to New Zealand; in 1965, resi¬
dents chose self-government in free associa¬
tion with New Zealand. The emigration of
skilled workers to New Zealand and govern¬
ment deficits are continuing problems.','0b98abf52f742e4da5a569d420a26f46f2508e70076a640b6eda7e86e100160d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ce915f57ead05616de21ce68ffa37d3badd6133a0cb5bd99665a4a0861c3c11',2010,'NZ','New Zealand','military-and-security',497,'Military branches: no regular military
forces; National Police Department (2007)
Manpower fit for military service:
males age 16-49: 2,334
females age 16-49: 2,286 (2009 est.)
Manpower reaching militarily
significant age annually: male: 148
female: 1 25 (2009 est.)
Military— note: defense is the responsi¬
bility of New Zealand in consultation with
the Cook Islands and at its request','2a3bd9d54bdad86395222fa4627e323cbb559c99604a51c0844795863d0c9631','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('140e0a6a1af39bb8c6834cbfdc843573ca2354ae6677f0044f0ef28e005fea10',2010,'CR','Costa Rica','military-and-security',506,'Military — note: defense is the responsi¬
bility of Australia
Military branches: no regular military
forces; Ministry of Public Security, Govern¬
ment, and Police (2009)
Manpower available for military
Service: males age 16-49: 1,134,205
females age 16-49: 1,095,763 (2008 est.)
Manpower fit for military service:
males age 16-49: 971,224
females age 16-49: 936,978 (2009 est.)
Manpower reaching militarily
significant age annually: male: 40,698
female: 38,808 (2009 est.)
Military expenditures: 0.4% of GDP
(2006)
Military branches: Cote d’Ivoire Defense
and Security Forces (FDSCI): Army, Navy,
Air Force (2006)
Military service age and obligation: 18
years of age for compulsory and voluntary
male and female military service (2008)
Manpower available for military service:
males age 16-49: 4,369,735
females age 16-49: 4,287,042 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,122,106
females age 16-49: 2,936,391 (2009 est.)
173
THE CIA WORLD FACTBOOK
Manpower reaching militarily
significant age annually: male: 236,159
female: 232,617 (2009 est.)
Military expenditures: 1.6% of GDP
(2005 est.)','4a46324916b429c81bf562591aa92a47fbbf7c0e92848a13ee4ee81392d93ce7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c222a18d903c7b1ef2259271edcb69a0f5517357fd84af7bd9eb4078c41685a4',2010,'CU','Cuba','military-and-security',516,'Military branches: Armed Forces of
the Republic of Croatia (Oruzane Snage
Republike Hrvatske, OSRH), consists of
five major commands directly subordi¬
nate to a General Staff: Ground Forces
(Hrvatska Kopnena Vojska, HKoV), Naval
Forces (Hrvatska Ratna Mornarica, HRM;
includes coast guard), Air Force and Air
Defense Command, Joint Education and
Training Command, Logistics Command;
Military Police Force supports each of the
three Croatian military forces (2009)
Military service age and obligation:
18-27 years of age for compulsory mili¬
tary service; 16 years of age with consent
for voluntary service; 6-month conscript
service obligation; full conversion to volun¬
tary military service by 2010 (2006)
Manpower available for military
Service: males age 16-49: 1,035,712
females age 16-49: 1,037,896 (2008 est.)
Manpower fit for military service:
males age 16-49: 770,798
females age 16-49: 849,957 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 27,620
female: 26,154 (2009 est.)
Military expenditures: 2.39% of GDP
(2005 est.)','a0ba4a5525a9862e17ed8bda976f1e48e629b84ef20e4a6d20dabef330447ce6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0b080fff8fd131ad449d7cf66730fe1cc1c2ad442078b6178e920792ee7f5bb',2010,'CH','Switzerland','military-and-security',526,'Military branches: Revolutionary Armed
Forces (Fuerzas Armadas Revolucionarias,
FAR): Revolutionary Army (ER; includes
Territorial Militia Troops (Milicia de
Tropas de Territoriales, MTT)), Revolu¬
tionary Navy (Marina de Guerra Revolu-
cionaria, MGR; includes Marine Corps),
Revolutionary Air and Air Defense Force
(DAAFAR), Youth Labor Army (Ejercito
Juvenil del Trabajo, EJT) (2009)
Military service age and obligation:
1 7—28 years of age for compulsory military
service; 2-year service obligation; both sexes
subject to military service (2006)
Manpower available for military
Service: males age 16-49: 3,094,388
females age 16-49: 3,024,876 (2008 est.)
Manpower fit for military service: males
age 16-49: 2,532,495
females age 16-49: 2,468,631 (2009 est.)
Manpower reaching militarily
significant age annually: male: 75,969
female: 72,253 (2009 est.)
Military expenditures: 3.8% of GDP
(2006 est.)
Military — note: the collapse of the Soviet
Union deprived the Cuban Army of its
major economic and logistic support, and
had a significant impact on equipment
numbers and serviceability; the army
remains well trained and professional in
nature; while the lack of replacement parts
180
Military branches: Swiss Armed Forces:
Land Forces, Swiss Air Force (Schweizer
Luftwaffe) (2009)
Military service age and obligation: 19
years of age for male compulsory military
service; 1 8 years of age for voluntary male
and female military service; the Swiss
Constitution states that “every Swiss male
is obliged to do military service”; every
Swiss male has to serve at least 260 days
in the armed forces; conscripts receive
18 weeks of mandatory training, followed
by seven 3-week intermittent recalls for
training during the next 1 0 years (2008)
Manpower available for military
Service: males age 16-49: 1,852,580
females age 16-49: 1,807,667 (2008 est.)
Manpower fit for military service:
males age 16-49 : 1,510,259
females age 16-49: 1,475,993 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 48,076
female: 44,049 (2009 est.)
Military expenditures:
1% of GDP (2005 est.)
Military branches: Syrian Armed Forces:
Syrian Arab Army, Syrian Arab Navy,
Syrian Arab Air and Air Defense Forces
(includes Air Defense Command) (2008)
Military service age and obligation: 18
years of age for compulsory military service;
conscript service obligation— 30 months (18
months in the Syrian Arab Navy); women
are not conscripted but may volunteer to
serve (2004)
Manpower available for military
Service: males age 16-49: 5,251,875
females age 16-49: 4,966,367 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,360,934
females age 16-49: 4,344,895 (2009 est.)
Manpower reaching militarily
significant age annually: male: 213,513
female: 201 ,055 (2009 est.)
Military expenditures:
5.9% of GDP (2005 est.)','93bfe7e8f6ec180e6cc44837cf0520fb0f145ca01d8a8ccbfe260f725af00960','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19ab301454adef8f860c67c140e1b6bd080db720685c6926b9dce672d66770f4',2010,'CY','Cyprus','military-and-security',527,'for its existing equipment and the current
severe shortage of fuel have increasingly
affected operational capabilities, Cuba
remains able to offer considerable resis-
tance to any regional power (2008)
Military branches: Republic of Cyprus:
Greek Cypriot National Guard (Ethniki
Forea, EF; includes naval and air elements);
northern Cyprus: Turkish Cypriot Security
Force (GKK) (2009)
Military service age and obligation:
Greek Cypriot National Guard (GCNG):
1 8—50 years of age for compulsory military
service for all Greek Cypriot males; 17
years of age for voluntary service; women
may volunteer for a 3-year term; length of
normal service is 25 months (2009)
Manpower available for military service:
Greek Cypriot National Guard (GCNG):
males age 16-49: 199,767
females age 16-49: 190,665 (2008 est.)
Manpower fit for military service:
Greek Cypriot National Guard (GCNG):
males age 16-49: 165,615
females age 16-49: 159,362 (2009 est.)
Manpower reaching militarily
significant age annually: male: 6,241
female: 5,979 (2009 est.)
Military expenditures: 3.8% of GDP
(2005 est.)
Military branches: Army of the Czech
Republic (ACR): Joint Forces Command
(includes Land Forces and Air Forces),
Support and Training Forces Command
(2009)
Military service age and obligation: 18-
28 years of age for voluntary and 19—28 for
compulsory military service (2008)
Manpower available for military
Service: males age 16-49: 2,522,383
females age 16-49: 2,425,095 (2008 est.)
Manpower fit for military service: males
age 16-49: 2,095,038
females age 16-49: 2,011,531 (2009 est.)
Manpower reaching militarily
significant age annually: male: 60,150
female: 57,157 (2009 est.)
Military expenditures: 1.46% of GDP
(2007 est.)','87ea4639c47c2343c5e8b5e79b5d665e8022f5a393f505ab0778f5e134d1fd98','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4e191242dafec7ca3079816f4cce851472fa9b0e57a89ba03c32af381ad6f5b',2010,'SE','Sweden','military-and-security',543,'Military branches: Defense Command:
Army Operational Command, Admiral
Danish Fleet, Island Command Green¬
land, Tactical Air Command, Home
Guard (2008)
Military service age and obligation: 18
years of age for compulsory and volun¬
tary military service; conscripts serve an
initial training period that varies from 4
to 12 months according to specialization;
reservists are assigned to mobilization units
following completion of their conscript
service; women eligible to volunteer for
military service (2004)
Manpower available for military
Service: males age 16-49: 1,235,067
females age 16-49: 1,215,418 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,013,223
females age 16-49: 998,837 (2009 est.)
Manpower reaching militarily
significant age annually: male: 37,231
female: 35,306 (2009 est.)
Military expenditures: 1.3% of GDP
(2007 est.)
Military— note: includes Dhekelia
Garrison and Ayios Nikolaos Station
connected by a roadway
Military branches: Swedish Armed Forces
(Forsvarsmakten): Army (Armen), Royal
Swedish Navy (Marinen), Swedish Air
Force (Svenska Flygvapnet) (2008)
651
THE CIA WORLD FACTBOOK
Military service age and obligation: 18-47
years of age for male compulsory or voluntary
military service; conscript service obligation:
7.5 months (Army), 7-15 months (Navy),
8-12 months (Air Force); after completing
initial service, soldiers have a reserve commit¬
ment until age 47; women are eligible for
voluntary military service (2009)
Manpower available for military
Service: males age 16-49: 2,052,890
females age 16-49: 1,980,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,705,746
females age 16-49: 1,645,070 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 62,262
female: 59,340 (2009 est.)
Military expenditures:
1.5% of GDP (2005 est.)','947852fa4f0a47bd6dbce8204def2c69ac382008965f6221a9e87b5e484b5bf7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2099c5e89a0913df2048be3120f932adb50d4ecf341973c2cc65a2a865494433',2010,'DJ','Djibouti','military-and-security',548,'Background: The French Territory of the
Afars and the Issas became Djibouti in
1977. Flassan Gouled APTIDON installed
an authoritarian one-party state and
proceeded to serve as president until 1999.
Unrest among the Afars minority during
the 1990s led to a civil war that ended in
2001 following the conclusion of a peace
accord between Afar rebels and the Issa-
dominated government. In 1999, Djibou¬
ti’s first multi-party presidential elections
resulted in the election of Ismail Omar
GUELLEH; he was re-elected to a second
and final term in 2005. Djibouti occupies a
strategic geographic location at the mouth
of the Red Sea and serves as an important
transshipment location for goods entering
and leaving the east African highlands.
The present leadership favors close ties
to France, which maintains a significant
military presence in the country, but also
has strong ties with the US. Djibouti hosts
the only US military base in sub-Saharan
Africa and is a front-line state in the global
war on terrorism.
Military branches: Djibouti National
Army (includes Navy and Air Force)
Military service age and obligation: 18
years of age for voluntary military service;
16-25 years of age for voluntary military
training; no conscription (2008)
Manpower available for military
service: males age 16-49: 111,274
females age 16-49: 105,168 (2008 est.)
Manpower fit for military service: males
age 16-49: 55,173
females age 16-49: 52,825 (2009 est.)
Manpower reaching militarily
significant age annually: male: 5,778
female: 5,771 (2009 est.)
Military expenditures: 3.8% of GDP
(2006)','68992df4cdd882934f0c4b25ec002fa7011a6707cd77ab8839100e0ba204b235','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bad0641a874ec67b4b3f09ed542c6dd898abe7a1fbf2424e658d7f23cdc8b39f',2010,'DO','Dominican Republic','military-and-security',563,'Military branches: no regular military
forces; Commonwealth of Dominica Police
Force (includes Coast Guard) (2008)
Manpower available for military service:
males age 16-49: 18,584 (2008 est.)
Manpower fit for military service: males
age 16-49: 15,821
females age 16-49: 15,291 (2009 est.)
Manpower reaching militarily
significant age annually: male. 776
female: 731 (2009 est.)
Military expenditures:
NA (2006)
Military branches: Army, Navy, Air Force
(Fuerza Aerea Dominicana, FAD) (2007)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military
service: males age 16-49: 2,440,203
females age 1 6-49: 2,326,694 (2008 est.)
Manpower fit for military service: males
age 16-49: 2,056,774
females age 16-49: 1,921,836 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 97,766
female: 93,922 (2009 est.)
Military expenditures: 0.8% of GDP (2006)','2f872d84e58a390d5438c437b82cc6ec3bf5efe3b151c684c29ca092b190f217','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e85712f7088c16cb813c329ee3a6b94fcf09cdfbca3e21f28ecd8dfa06617950',2010,'EC','Ecuador','military-and-security',575,'Military branches: Army, Navy (includes
Naval Infantry, Naval Aviation, Coast
Guard), Air Force (Fuerza Aerea Ecuato-
riana, FAE) (2007)
Military service age and obligation: 20
years of age for selective conscript military
service; 1 2-month service obligation (2008)
Manpower available for military
Service: males age 16-49: 3,536,602
females age 16-49: 3,559,188 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,708,470
females age 16-49: 3,165,489 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 148,010
female: 143,291 (2009 est.)
Military expenditures: 2.8% of GDP
(2006)','716971b0c2f6ff4184b663d6a4cf80e5ed824753cb2439602949f7ee2fde6287','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f48ada5646dd7e12b8f1633720be803cfe099e572a594aea3e7dcdd7452aebe7',2010,'EG','Egypt','military-and-security',585,'Military branches: Army, Navy, Air Force,
Air Defense Command
Military service age and obligation: 18-
30 years of age for male conscript military
service; service obligation 12-36 months,
followed by a 9-year reserve obligation
(2008)
Manpower available for military service:
males age 16-49: 21,247,777
females age 1 6-49: 20,406,408 (2008 est.)
Manpower fit for military service: males
age 16-49: 18,490,522
females age 16-49: 17,719,905 (2009 est.)
Manpower reaching militarily
significant age annually: male. 831,157
female: 792,330 (2009 est.)
Military expenditures: 3.4% of GDP
(2005 est.)','20927b807018eff141a3f43c54799d7d41b568c756ebdcefc9df763fba2e84de','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f551df2ac87ba15bfe1f35d0ae9c63c91fc67eb83f32c7dc43231d089694521',2010,'SV','El Salvador','military-and-security',592,'Military branches: Salvadoran Army (ES),
Salvadoran Navy (FNES), Salvadoran Air
212','197103c43c5406e69a877202f1cbd1b90f33ca7f9a4ad53e6dd1b62b8a28db45','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3832e3531f88369589fc613cde64c9d55a32684d84a6afa0a3dbdeb7b32adaa6',2010,'GQ','Equatorial Guinea','military-and-security',593,'t
Force (Fuerza Aerea Salvadorena, FAS)
(2008)
Military service age and obligation: 18
years of age for selective compulsory mili¬
tary service; 16 years of age for voluntary
service; service obligation— 8 months, but
1 1 months for officers and NCOs (2008)
Manpower available for military service:
males age 16-49: 1,634,816
females age 16-49: 1,775,474 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,201,290
females age 16-49: 1,547,278 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 77,473
female: 74,655 (2009 est.)
Military expenditures: 5% of GDP
(2006)
Military branches: National Guard
(Guardia Nacional (Army), with Coast
Guard (Navy) and Air Wing) (2008)
Military service age and obligation: 18
years of age (est.) for compulsory military
service (2008)
Manpower available for military service:
males age 16-49: 136,725
females age 16-49: 138,018 (2008 est.)
Manpower fit for military service:
males age 16-49: 105,468
females age 16-49: 107,919 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 6,983
female: 6,726 (2009 est.)
215
THE CIA WORLD FACTBOOK
Military expenditures: 0.1% of GDP
(2006 est.)','3bcd8a850f6ca37ec5b5b884c677c862aadfeaf6cbe7b5354bfad8ffdd5337e6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f9be47e9d13fbe671e8f791e5c7977853dc49b09f63780bee12257d45566144',2010,'EE','Estonia','military-and-security',611,'Military branches: Eritrean Armed Forces:
Ground Forces, Navy, Air Force (2008)
Military service age and obligation:
18-40 years of age for male and female
voluntary and compulsory military service;
16-month conscript service obligation
(2006)
Manpower available for military
service: males age 16-49: 1,108,836
females age 16-49: 1,096,120 (2008 est.)
Manpower fit for military service:
males age 16-49: 834,018
females age 16-49: 887,495 (2009 est.)
Manpower reaching militarily
significant age annually: male: 62,265
female: 62,328 (2009 est.)
Military expenditures: 6.3% of GDP
(2006 est.)
Military branches: Estonian Defense
Forces: Land Force, Navy, Air Force (Eesti
Ohuvagi), Volunteer Defense League (Kait-
seliit, KL) (2009)
Military service age and obligation:
obligation for compulsory service ages
16-60, with conscription “likely” ages
18-27; service requirement 8-11 months
(2009)
Manpower available for military
Service: males age 16-49: 306,273
females age 16-49: 317,852 (2008 est.)','67d4267f2813e99fc764ee3e70237bd04bc327a8c0a20bc8150222dedec76662','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd8a01d0f85eff2b9b3e778ce410485791e12ff09281a9b86060f9e66db5f91',2010,'ET','Ethiopia','military-and-security',617,'occupation from 1936 to 1941. In 1974, a
military junta, the Derg, deposed Emperor
Flaile SELASSIE (who had ruled since
1930) and established a socialist state.
Torn by bloody coups, uprisings, wide-scale
drought, and massive refugee problems,
the regime was finally toppled in 1991 by
a coalition of rebel forces, the Ethiopian
People’s Revolutionary Democratic Front
(EPRDF). A constitution was adopted
in 1994, and Ethiopia’s first multiparty
elections were held in 1995. A border
war with Eritrea late in the 1990s ended
with a peace treaty in December 2000.
The Eritrea-Ethiopia Border Commission
in November 2007 remotely demarcated
the border by geographical coordinates,
but final demarcation of the boundary on
the ground is currendy on hold because
of Ethiopian objections to an interna¬
tional commission’s finding requiring it to
Manpower fit for military service:
males age 16-49: 216,483
females age 16-49: 260,408 (2009 est.)
Manpower reaching militarily
significant age annually: male: 7,583
female: 7,111 (2009 est.)
Military expenditures:
2% of GDP (2005 est.)
Military branches: Ethiopian National
Defense Force (ENDF): Ground Forces,
Ethiopian Air Force (ETAF) (2008)
note: Ethiopia is landlocked and has no
navy; following the secession of Eritrea,
Ethiopian naval facilities remained in
Eritrean possession
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; theoretically, no compul¬
sory military service, but the military can
conduct call-ups when necessary and
compliance is compulsory (2008)
Manpower available for military service:
males age 16-49: 17,666,967
females age 16-49: 17,530,211 (2008 est.)
Manpower fit for military service: males
age 16-49: 11,078,847
females age 16-49: 12,017,073 (2009 est.)
Manpower reaching militarily
significant age annually: male: 908,384
female: 916,354 (2009 est.)
Military expenditures: 3% of GDP
(2006)','64cdbef6b9f86b69753d3b537f0da4dae92e88f00634ef61b69b0629253d0823','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f2cb88a9236ea2a9550df972ab54751c39afe1bb6059d810b655dfe7f825b87',2010,'IT','Italy','military-and-security',628,'Military— note: the five-nation Eurocorps—
created in 1992 by France, Germany,
Belgium, Spain, and Luxembourg— has
deployed troops and police on peace¬
keeping missions to Bosnia-Herzegovina,
Macedonia, and the Democratic Republic
of the Congo and assumed command of
the ISAF in Afghanistan in August 2004;
Eurocorps directly commands the 5,000-
man Franco-German Brigade, the Multi¬
national Command Support Brigade,
and EUFOR in Bosnia and Herzegovina;
in November 2004, the EU Council of
Ministers formally committed to creating
13 1 ,500-man battle groups by the end of
2007, to respond to international crises on
a rotating basis; 22 of the EU’s 27 nations
have agreed to supply troops; France, Italy,
and the UK formed the first of three battle
groups in 2005; Norway, Sweden, Estonia,
and Finland established the Nordic Battle
Group effective 1 January 2008; nine other
groups are to be formed; a rapid-reaction
naval EU Maritime Task Group was stood
up in March 2007 (2007)
Military branches: no regular military forces
Military expenditures: NA
Military — note: defense is the responsi¬
bility of the UK
Military branches: Italian Army (Esercito
Italiano, El), Italian Navy (Marina Militare
Italiana, MMI), Italian Air Force (Aeronau-
tica Militare Italiana, AMI), Carabinieri
Corps (Arma dei Carabinieri, CC) (2009)
Military service age and obligation:
18-27 year of age for voluntary military
service; conscription abolished January
2005; women may serve in any military
branch; 10-month service obligation, with
a reserve obligation to age 45 (Army and
Air Force) or 39 (Navy) (2006)
Manpower available for military
Service: males age 16-49: 13,884,079
females age 16-49: 13,158,378 (2008 est.)
Manpower fit for military service: males
age 16-49: 11,197,487
females age 16-49: 10,574,250 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 287,845
female: 270,384 (2009 est.)
Military expenditures: 1.8% of GDP
(2005 est.)','0d5774e18369adf7dc551d2c1e7e2c8cdd31c5a17d91ee7169bb827c69ef3334','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba04d722ca64a3dffc3287f81c8e6a54daed2aa62961055e61f651c520e5b616',2010,'FO','Faroe Islands','military-and-security',637,'Military branches: no regular military
forces
Manpower available for military service:
males age 16-49: 11,725 (2008 est.)
Manpower fit for military service: males
age 16-49: 9,759
females age 16-49: 8,311 (2009 est.)
Manpower reaching militarily
significant age annually: male: 386
female: 375 (2009 est.)
Military expenditures: NA
Military — note: defense is the responsi¬
bility of Denmark','114d33272c3704d0de7b388d9a773d5834386a07a89a8db469da71b007116057','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab7a07d233a141e742b86f88ba83fa2a2cfb126507b691fb00958b288788fdc',2010,'FI','Finland','military-and-security',646,'Military branches: Republic of Fiji Milk
tary Forces (RFMF): Land Forces, Naval
Forces (2009)
Military service age and obligation: 18
years of age for voluntary military service;
reserve obligation to age 45 (2006)
Background: Finland was a province and
then a grand duchy under Sweden from
the 12th to the 19th centuries, and an
autonomous grand duchy of Russia after
1809. It won its complete independence in
1917. During World War II, it was able to
successfully defend its freedom and resist
Manpower available for military
service:
males age 16-49 : 242,567
females age 16-49: 238,556 (2008 est.)
Manpower fit for military service:
males age 16-49: 192,363
females age 16-49: 204,410 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 9,107
female: 8,755 (2009 est.)
Military expenditures: 2.2% of GDP
(2005 est.)','25640c54d941e9020c03df8db1876c6826adde846a0dec5d4a97255171008098','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19cd53f42ec5cd3ae9900833bb6f9f1b242daa7780723a4889d2e8ace01edf20',2010,'PF','French Polynesia','military-and-security',658,'Military branches: Army (Armee de Terre;
includes Marines, Foreign Legion, Army
Light Aviation), Navy (Marine Nationale,
includes Naval Air, Maritime Gendarmerie
(Coast Guard)), Air Force (Armee de l’Air,
includes Air Defense), National Gendar¬
merie (2009)
Military service age and obligation:
17-40 years of age for male or female
voluntary military service; no conscription;
12-month service obligation; women serve
in noncombat military posts (2008)
Manpower available for military
service: males age 16-49: 14,646,427
females age 16-49: 14,379,630 (2008 est,)
Manpower fit for military service: males
age 16-49: 12,087,606
females age 16-49: 11,811,260 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 391,480
female: 373,334 (2009 est.)
Military expenditures: 2.6% of GDP
(2005 est.)
Military branches: no regular military
forces (2009)
Manpower available for military service:
males age 16-49: 79,540 (2008 est.)
Manpower fit for military service:
males age 16-49: 65,408
females age 16-49: 64,421 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 2,665
female: 2,552 (2009 est.)
Military — note: defense is the responsi¬
bility of France
Military — note: defense is tire responsi¬
bility of France','1c9ce5224fb42a2a4f1bc219116f58bbb4bb64616554cb9480070cf4c0174ae6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d035e1da3e6a081a4eeaf13ec4cc7162f2bf6c080d5ecc05d74579e3eec0d1fa',2010,'GA','Gabon','military-and-security',670,'Military branches: Army, Navy, Air Force,
National Gendarmerie, National Police
Military service age and obligation: 20
years of age for compulsory and voluntary
military service (2007)
Manpower available for military
Service: males age 16-49: 331,181
females age 16-49: 332,498 (2008 est.)
Manpower fit for military service: males
age 16-49: 195,519
females age 16-49: 190,519 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 16,933
female : 16,942 (2009 est.)
Military expenditures: 3.4% of GDP
(2005 est.)
Military branches: Office of the Chief of
Defense: Gambian National Army (National
Guard, GNA), Gambian Navy (GN) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military
Service: males age 16-49: 379,668
females age 16-49: 384,438 (2008 est.)
Manpower fit for military service: males
age 16-49: 238,454
females age 16-49: 253,680 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 20,238
female: 20,167 (2009 est.)
Military expenditures: 0.5% of GDP
(2006)
Military branches: Palestinian Authority
security forces have operated only in the
West Bank, not in the Gaza Strip, since
Hamas seized power in June 2007; law
and order and other security functions are
performed by Hamas security organizations
(2008)
Manpower available for military service:
males age 16 -49: 337,670 (2008 est.)
Manpower fit for military service:
males age 16-49: 312,003
females age 16-49: 297,380 (2009 est.)
Manpower reaching militarily
significant age annually: male: 19,147
female: 18,200 (2009 est.)
Military expenditures: NA','c2a8e18db905cae6d2ffbdcb7a2b71d46cc0c085d28f4a48dd06fe8d7f3f66e8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1591ed975b6fefa9176c421ac2c16eccc3d7f6044ed42e3a49007d0f72fb456f',2010,'GE','Georgia','military-and-security',678,'Military branches: Georgian Armed Forces:
Land Forces, Air and Air Defense Forces
note: naval forces have been incorporated
into the coast guard (2009)
Military service age and obligation: 1 8 to
34 years of age for compulsory and volun¬
tary active duty military service; conscript
service obligation— 1 8 months (2005)
Manpower available for military
service:
males age 16-49: 1,113,251
females age 16-49: 1,168,021 (2008 est.)
Manpower fit for military service:
males age 16-49: 908,282
females age 16-49: 959,290 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 32,355
female: 30,809 (2009 est.)
Military expenditures: 0.59% of GDP
(2005 est.)
Military— note: a CIS peacekeeping
force of Russian troops is deployed in the
Abkhazia region of Georgia together with
a UN military observer group; a Russian
peacekeeping battalion is deployed in
South Ossetia','92c55ad259068bfbe5621384c968221daab8da3725862bcb32ec57f474d36103','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ae93f55de5ea2a73f83ee4b4d6950d8ef601fbd19054bf4c03ede2295955405',2010,'GH','Ghana','military-and-security',686,'Military branches: Federal Armed Forces
(Bundeswehr): Army (Heer), Navy (Deut¬
sche Marine, includes naval air arm), Air
Force (Luftwaffe), Joint Support Services
(Streitkraeftbasis), Central Medical Service
(Zentraler Sanitaetsdienst) (2009)
Military service age and obligation: 18
years of age (conscripts serve a 9-month
tour of compulsory military service) (2004)
Manpower available for military
service:
males age 16-49: 19,594,118
females age 16-49: 18,543,955 (2008 est.)
Manpower fit for military service:
males age 16-49: 15,747,493
females age 16-49: 14,899,416 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 431,508
female: 409,111 (2009 est.)
Military expenditures: 1.5% of GDP
(2005 est.)
Military branches: Ghanaian Army,
Ghanaian Navy, Ghanaian Air Force (2008)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military
Service: males age 16-49: 5,802,096
females age 16-49: 5,729,939 (2008 est.)
Manpower fit for military service: males
age 16-49: 3,849,113
females age 16-49: 3,840,083 (2009 est.)
Manpower reaching militarily
significant age annually: male: 272,954
female: 266,186 (2009 est.)
Military expenditures: 0.8% of GDP
(2006 est.)','5b9f0a7dc2d03a02ad96bc6391262989f3a75c0e5bf69205b676c33260b3b307','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ad7dc1a646708844d2f8c53ef5054fe150edf42ec53887d0cd24ab29d85e0c0',2010,'GI','Gibraltar','military-and-security',698,'Military branches: Royal Gibraltar Regi¬
ment (2007)
Manpower available for military service:
males age 1 6-49: 6,308 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,234
females age 16-49: 5,242 (2009 est.)
270','a5f8f1810c91ae199dfa22bce369b1a1deae00eb18f69c699d321e30e4f09856','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf9fea186731c3292bdd0b3ba19dfe4b66bdc1ca3c5460f05edc6f20dcde451',2010,'GR','Greece','military-and-security',699,'Manpower reaching militarily
significant age annually:
male: 186
female: 179 (2009 est.)
Military— note: defense is the respon¬
sibility of the UK; the Royal Gibraltar
Military branches: Hellenic Army
(Ellinikos Stratos, ES), Hellenic Navy
(Ellinikos Polemiko Navtiko, EPN),
Hellenic Air Lorce (Elliniki Polimiki
Aeroporia, EPA) (2009)
Military service age and obligation:
19-45 years of age for compulsory military
service; during wartime the law allows for
recruitment beginning January of the year
of inductee’s 18th birthday, thus including
1 7 year olds; 1 7 years of age for volunteers;
conscript service obligation— 1 year for all
services; women are eligible for voluntary
military service (2008)
Manpower available for military service:
males age 16-49: 2,535,174
females age 16-49: 2,517,273 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,067,878
females age 16-49: 2,050,289 (2009 est.)
Manpower reaching militarily
significant age annually: male: 53,401
female: 50,084 (2009 est.)
Military expenditures: 4.3% of GDP
(2005 est.)
Military branches: no regular military
forces; defense is the responsibility of
China (2009)
Manpower available for military service:
males age 16-49: 121,825 (2008 est.)
Manpower fit for military service:
males age 1 6-49: 1 22,962
females age 16-49: 148,809 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male 4,578
female: 4,052 (2009 est.)
Military — note: defense is the responsi¬
bility of China','3d210ba456d122ed70a7d6facf893ccc870109c89362e1c4bfa1836e36904867','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39873c47cdea639d6e3a90b3175e93424ae4e938c459d119655bbe76fd6e177c',2010,'GL','Greenland','military-and-security',713,'Military branches: no regular military
forces
Manpower available for military service:
males age 16-49: 15,221 (2008 est.)
Manpower fit for military service:
males age 16-49: 10,809
females age 16-49: 11,437 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 532
female: 491 (2009 est.)
Military — note: defense is the responsi¬
bility of Denmark','06d7fe577a4a16acb4eda171b6b5a233ae7de5d27d60c15001cb153d5ed81144','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c8bbe820a260f3d8a697892a8b87c213c4f80ee35710d93c76dc9e222d3f233',2010,'GU','Guam','military-and-security',723,'Military branches: no regular mili¬
tary forces; Royal Grenada Police Force
(includes Coast Guard) (2007)
Manpower available for military service:
males age 16-49: 27,309 (2008 est.)
Manpower fit for military service: males
age 16-49: 20,483
females age 1 6-49: 20,923 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 982
female: 937 (2009 est.)
Military expenditures: NA','9762cd7131c937423487f0a3a64522733bf5f69d478fc6c7b9e4d425536cdbd8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23a1ef5a3ef40bd6c59897359de9b37affcd93a28bbd4b29493f4e3c8c165518',2010,'GT','Guatemala','military-and-security',731,'Manpower fit for military service: males
age 16-49: 37,563
females age 16-49: 36,083 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 1 ,677
female: 1,581 (2009 est.)
Military — note: defense is the responsi¬
bility of the US
Military branches: Army, Navy (includes
Marines), Air Force
Military service age and obligation: all
male citizens between the ages of 18 and
50 are liable for military service; conscript
service obligation varies from 12 to 24
months; women can serve as officers (2008)
Manpower available for military
service: males age 16-49: 2,861,696
females age 16-49: 3,062,967 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,401,297
females age 16-49: 2,725,572 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 165,910
female: 163,760 (2009 est.)
Military expenditures: 0.4% of GDP
(2006)','baf53f7d6747030974ee98ec75ca24d960a3eb1ca6cc8c492d8590d08274dede','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3da2c13ac603b84895a45252cf0b6e6104c14199bd49cd197fa49290e7549339',2010,'GG','Guernsey','military-and-security',743,'Manpower fit for military service: males
age 16-49: 12,447
females age 16-49: 12,566 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 362
female: 351 (2009 est.)
Military — note: defense is the responsi¬
bility of the UK','e0cf1120a12f59502b35efc0568b141c51c223d96daa5a251c6c9319b9bdf905','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c1d30d7d9955a39ac954015cbbe15c0ada40b5b5160e34bde7ff61a9b8be5b3',2010,'GN','Guinea','military-and-security',748,'Military branches: National Armed Forces:
Army, Navy (Armee de Mer or Marine
Guineenne, includes Marines), Air Force
(2009)
Military service age and obligation:
1 8-25 years of age for compulsory or volun¬
tary military service; 18-month conscript
service obligation (2009)
Manpower available for military
service: males age 16-49: 2,230,049
females age 16-49: 2,193,236 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,396,278
females age 16-49: 1,435,387 (2009 est.)
Manpower reaching militarily
significant age annually: male. 110,281
female: 107,879 (2009 est.)
Military expenditures: 1.7% of GDP
(2006)','fe99116ec462f7fd8ddc7b551897ff1aaf0939a47d1aabda968a7709070046e2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('473bfaad1e4a3e6a54e2123ae3423513325a744cfdc470ff059bf9e4ab2eb434',2010,'GW','Guinea-Bissau','military-and-security',757,'Military branches: People’s Revolutionary
Armed Force (FARP): Army, Navy, Air
Force; paramilitary force
Military service age and obligation:
18-25 years of age for selective compulsory
military service; 1 6 years of age or younger
with parental consent, for voluntary service
(2009)
Manpower available for military
Service: males age 16-49: 344,087
females age 16-49: 347,886 (2008 est.)
Manpower fit for military service:
males age 16-49: 194,110
females age 16-49: 200,660 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 16,957
female: 17,172 (2009 est.)
Military expenditures: 3.1% of GDP
(2005 est.)','75e19c3670d6781e6712f2b35567f50950aa723ce9dc6d1c22feea3d42b2ec42','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7d99560d5ee16003a3136cdfbc6ab5c98a3bca2e833ea0855d58dce5a765a84',2010,'GY','Guyana','military-and-security',765,'Military branches: Guyana Defense Force:
Army (includes Coast Guard, Air Corps)
(2008)
Military service age and obligation:
18-25 years of age for voluntary military
service; no conscription (2008)
295
THE CIA WORLD FACTBOOK
Manpower available for military service:
males age 16-49: 220,797 (2008 est.)
Manpower fit for military service:
males age 16-49: 150,307
females age 16-49: 144,622 (2009 est.)
Manpower reaching militarily
significant age annually: male: 6,625
female: 6,365 (2009 est.)
Military expenditures: 1.8% of GDP
(2006)','3e5439f7c06349b678acc53a30a7b968ec7fc347ab7cfe664ca908717572c3f4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f7461ad72ef1b3dfa5a1546522dc3eb66dccc9e3bc42b49bcf5d5231b9b979c',2010,'HM','Heard Island and McDonald Islands','military-and-security',776,'Military— note: defense is the respon¬
sibility of Australia; Australia conducts
fisheries patrols
Disputes — international: none
HOLY SEE (VATICAN CITY)
Background: Popes in their secular role
ruled portions of the Italian peninsula
for more than a thousand years until
the mid 1 9th century, when many of
the Papal States were seized by the newly
united Kingdom of Italy. In 1870, the
pope’s holdings were further circum¬
scribed when Rome itself was annexed.
Disputes between a series of “prisoner”
popes and Italy were resolved in 1929 by
three Lateran Treaties, which established
the independent state of Vatican City and
granted Roman Catholicism special status
in Italy. In 1984, a concordat between
the Holy See and Italy modified certain
of the earlier treaty provisions, including
the primacy of Roman Catholicism as the
Italian state religion. Present concerns of
the Holy See include religious freedom,
international development, the environ¬
ment, the Middle East, China, the decline
of religion in Europe, terrorism, interreli¬
gious dialogue and reconciliation, and the
application of church doctrine in an era
of rapid change and globalization. About
one billion people worldwide profess the
Catholic faith.
Military branches: Pontifical Swiss Guard
(Corpo della Guardia Svizzera Pontificia)
(2009)
Military — note: defense is the responsi¬
bility of Italy; ceremonial and limited secu¬
rity duties performed by Pontifical Swiss
Guard','d278d70706cb6e6fe92fba5df4798e78cf62010ed796e8d4b0af37b527b9a00b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d5af4ece8d131ed799e6111b985b751df5a64406d6e0e6fed456a590b281047',2010,'HN','Honduras','military-and-security',785,'Military branches: Army, Navy (includes
Naval Infantry), Honduran Air Force
(Fuerza Aerea Hondurena, FAH) (2008)
Military service age and obligation:
18 years of age for voluntary 2 to 3-year
military service (2004)
Manpower available for military
service: males age 16-49: 1,868,940
females age 16-49: 1,825,77 0 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,397,938
females age 16-49: 1,402,398 (2009 est.)
Manpower reaching militarily
significant age annually: male. 92,638
female: 88,993 (2009 est.)
Military expenditures: 0.6% of GDP
(2006 est.)','3eb1f119659e3c43c9b2740b0491b25a909e7827ba267779e2c9dc436e7110e9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('155777d728cdd124586012e626e8a3b8bc80d1150a386496bf0346ac3860695e',2010,'HK','Hong Kong','military-and-security',794,'Military branches: no regular indigenous
military forces; Hong Kong garrison of
China’s People’s Liberation Army (PLA)
includes elements of the PLA Ground
Forces, PLA Navy, and PLA Air Force;
these forces are under the direct leadership
of the Central Military Commission in
Beijing and under administrative control
of the adjacent Guangzhou Military Region
(2009)
Manpower available for military service:
males age 16-49: 1,772,820
females age 16-49: 1,941,448 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,421,406
females age 16-49: 1,543,443 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 42,330
female: 38,797 (2009 est.)
Military expenditures: NA
Military — note: defense is the responsi¬
bility of China','0aa6d5aac2d0bf5395982e03e169e0cabf728d3a7300951f4b452c86d3107a6a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('397265d3f12e4e337da8403288be790cc98a041426b6fb6f56b82b54405df5af',2010,'HU','Hungary','military-and-security',802,'Military branches: Ground Forces,
Hungarian Air Force (Magyar Legiero,
ML) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
conscription abolished in June 2004; 6-
month service obligation (2008)
Manpower available for military
service: males age 16-49: 2,391,400
females age 16-49: 2,337,240 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,887,755
females age 16-49: 1,934,019 (2009 est.)
Manpower reaching militarily
significant age annually: male: 60,248
female: 57,280 (2009 est.)
Military expenditures: 1.75% of GDP
(2005 est.)','602e41bc4fa1f34ce23ecdf24aa489651671dfccaca6379bdf6d320c6fddcaa3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75ce10004fb1bc56e2b7bf12a52bb85517d3a81490f6189cb4f7880254e14058',2010,'IS','Iceland','military-and-security',811,'Military branches: no regular military
forces; Icelandic National Police (2008)
Manpower available for military service:
males age 16-49: 74,896 (2008 est.)
Manpower fit for military service: males
age 16-49: 62,576
females age 16-49: 61,159 (2009 est.)
Manpower reaching militarily
significant age annually: male: 2,369
female: 2,349 (2009 est.)
Military expenditures: 0% of GDP (2005
est.)
315
THE CIA WORLD FACTBOOK
Military — note: Iceland has no standing
military force; under a 1951 bilateral
agreement— still valid— its defense was
provided by the US-manned Icelandic
Defense Force (IDF) headquartered at
Keflavik; however, all US military forces
in Iceland were withdrawn as of October
2006; although wartime defense of Iceland
remains a NATO commitment, in April
2007, Iceland and Norway signed a bilat¬
eral agreement providing for Norwegian
aerial surveillance and defense of Icelandic
airspace (2008)','7385e6befa2ab1a32feaa2282defd1fac4fe446c91fb442bab8cb302dcf1a329','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5926193179969ff9cc7a055a161c080478fc63d24ac92b1ef9d3cea48d9389b9',2010,'IN','India','military-and-security',819,'Military branches: Army, Navy (includes
naval air arm), Air Force (Bharatiya Vayu
Sena), Coast Guard (2009)
Military service age and obligation: 16
years of age for voluntary military service;
no conscription; women officers allowed in
noncombat roles only (2008)
Manpower available for military service:
males age 16-49: 301 ,094,084
females age 16-49: 283,047,141 (2008
est.)
319
THE CIA WORLD FACTBOOK
Manpower fit for military service: males
age 16-49: 237,042,868
females age 16-49: 243,276,310 (2009
est.)
Manpower reaching militarily
significant age annually:
male: 11.795 million
female: 10,820,590 (2009 est.)
Military expenditures: 2.5% of GDP
(2006)','9264a74b52b12a3efefd5c1624a9d400611a17a7bcaf543a034d682096b1c9c4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('925148d70a3b578c7d6b5dbd748df1347c0d113ae970c79845006bbca6dc3453',2010,'ID','Indonesia','military-and-security',824,'Military branches: Indonesian Armed
Forces (Tentara Nasional Indonesia,
TNI): Army (TNI-Angkatan Darat (TNI-
AD)), Navy (TNI-Angkatan Laut (TNI-
AL); includes marines, naval air arm),
Air Force (TNI-Angkatan Udara (TNI-
AU)), National Air Defense Command
(Kommando Pertahanan Udara Nasional
(Kohanudnas)) (2009)
Military service age and obligation: 18
years of age for selective compulsory and
voluntary military service; 2-year conscript
service obligation, with reserve obligation
to age 45 (officers); Indonesian citizens
only (2008)
Manpower available for military
Service: males age 16-49: 63,800,825
females age 16-49: 61,729,717 (2008 est.)
Manpower fit for military service: males
age 16-49: 52,997,922
females age 16-49: 52,503,046 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 2,197,323
female: 2,126,412 (2009 est.)
Military expenditures: 3% of GDP (2005
est.)
Military branches: Islamic Republic of
Iran Regular Forces (Artesh): Ground
Forces, Navy, Air Force of the Military
of the Islamic Republic of Iran (Niru-ye
Hava’i-ye Artesh-e Jomhuri-ye Eslami-ye
Iran, IRIAF; Air Defense Command being
formed); Islamic Revolutionary Guard
Corps (Sepah-e Pasdaran-e Enqelab-e
Eslami, IRGC): Ground Forces, Navy, Air
Force, Qods Force (special operations), and
Basij Force (Popular Mobilization Army);
Law Enforcement Forces (2008)
Military service age and obligation: 19
years of age for compulsory military service;
16 years of age for volunteers; 17 years of
age for Law Enforcement Forces; 15 years
of age for Basij Forces (Popular Mobiliza¬
tion Army); conscript military service obli¬
gation— 18 months; women exempt from
military service (2008)
Manpower available for military service:
males age 16-49: 20,212,275
females age 16-49: 19,638,751 (2008 est.)
Manpower fit for military service:
males age 16-49: 17,658,573
females age 16-49: 17,148,290 (2009 est.)
Manpower reaching militarily
significant age annually: male: 700,213
female: 664,846 (2009 est.)
Military expenditures: 2.5% of GDP
(2006)','f6ca010b8fc1b4bd01624e55bfa7b3f8d6b1a98bafe7a8ea7836158996b029b9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f0f3e13ea0250b4e2fe0ae64f551c2a17b1a7f26ddf0066d25774dbc09f89ce',2010,'IQ','Iraq','military-and-security',825,'ruled the country until 2003. The last was
SADDAM Husayn. Territorial disputes
with Iran led to an inconclusive and costly
eight-year war (1980-88). In August 1990,
Iraq seized Kuwait but was expelled by US-
led, UN coalition forces during the Gulf
War of January-February 1991. Following
Kuwait’s liberation, the UN Security
Council (UNSC) required Iraq to scrap
all weapons of mass destruction and long-
range missiles and to allow UN verification','0c9f2c26276e3fed63484d6cbc2e7f6ee84860ff9e3766d2e16746d53310b693','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('499f3c72721957235663107fa5c35d70407fe2a45c69fea10d88a0c82609b48a',2010,'IE','Ireland','military-and-security',834,'Military branches: Iraqi Armed Forces:
Iraqi Army (includes Iraqi Special Opera¬
tions Force, Iraqi Intervention Force), Iraqi
Navy (former Iraqi Coastal Defense Force),
Iraqi Air Force (former Iraqi Army Air
Corps) (2005)
Military service age and obligation:
18-49 years of age for voluntary military
service (2008)
Manpower available for military
service:
males age 16-49: 7,086,200
females age 16-49: 6,808,954 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,203,425
females age 16-49: 6,065,009 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 313,500
female: 304,923 (2009 est.)
Militaryexpenditures:8.6%ofGDP(2006)
Military branches: Irish Defense Forces
(Oglaigh na h-Eireann): Army (includes
Naval Service and Air Corps (Aer-Chor na
h-Eireann)) (2009)
Military service age and obligation: 17-
25 years of age for male or female voluntary
military service (17-27 years of age for the
Naval Service); enlistees 16 years of age
can be recruited for apprentice specialist
positions; maximum obligation 1 2 years;
17-35 years of age for the Reserve Defense
Forces; EU citizenship or 5-year residence
in Ireland required (2008)
Manpower available for military
Service: males age 16-49: 1,024,635
females age 16-49: 1,024,276 (2008 est.)
Manpower fit for military service:
males age 16-49: 857,162
females age 16-49: 854,416 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 28,072
female: 26,400 (2009 est.)
Military expenditures: 0.9% of GDP
(2005 est.)','66ee404cf6ff75df010d2263cc4458459c8f50d319a5a717d896b935c293793d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd420ae9402df954035059b2ca1de4ed3dbbc7a3a0442a827a1de2bb153598c2',2010,'IM','Isle of Man','military-and-security',845,'Manpower fit for military service:
males age 16-49: 14,691
females age 16-49: 14,338 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 466
female: 446 (2009 est.)
Military — note: defense is the responsi¬
bility of the UK','b82a8a75fa7dc5e466957cd2231446abf4020960d1962b9f9263c39b6b755a4a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e56d4ae61a2c271bf30be26b6376dc37674e13ba742069a19a4698a36be49fc',2010,'IL','Israel','military-and-security',854,'Military branches: Israel Defense Forces
(IDF), Israel Naval Forces (INF), Israel Air
Force (IAF) (2007)
Military service age and obligation: 18
years of age for compulsory (Jews, Druzes)
and voluntary (Christians, Muslims,
Circassians) military service; both sexes
are obligated to military service; conscript
service obligation— 36 months for enlisted
men, 21 months for enlisted women, 48
months for officers; reserve obligation to
age 41-51 (men), 24 (women) (2008)
Manpower available for military
service: males age 16-49: 1,717,362
females age 16-49: 1,636,574 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,474,966
females age 16-49: 1,404,712 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 61,223
female: 58,219 (2009 est.)
Militaryexpenditures:7.3%ofGDP(2006)','5014ed60e6089519708a6ba262c8492bcc9c3c9c241098f0d6aa4f474e410650','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff2a7069451f1fcecababd61fcb18dcb19bbd0234d1625c54553b0b1240792c0',2010,'JM','Jamaica','military-and-security',862,'Military branches: Jamaica Defense Force:
Ground Forces, Coast Guard, Air Wing
(2007)
Military service age and obligation: 18
years of age for voluntary military service;
younger recruits may be conscripted with
parental consent (2001)
Manpower available for military
Service: males age 16-49: 688,480
females age 16-49: 709,548 (2008 est.)
Manpower fit for military service:
males age 16-49: 573,520
females age 1 6-49: 586,426 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 31,833
female: 31,257 (2009 est.)
Military expenditures: 0.6% of GDP
(2006 est.)
Military — note: defense is the responsi¬
bility of Norway','b2322fb44ac95186d34f5e0681f6287ddb5af525123105c5030ee3a9379f3c66','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d127f6abf15eb82531e9ecd72e6a393a9f371211d6fc439174e8f71ea54ad046',2010,'JE','Jersey','military-and-security',874,'Military branches: Japanese Ministry of
Defense (MOD): Ground Self-Defense
Force (Rikujou Jietai, GSDF), Maritime
Self-Defense Force (Kaijou Jietai, MSDF),
Air Self-Defense Force (Koku Jieitai,
ASDF) (2009)
Military service age and obligation: 18
years of age for voluntary military service
(2001)
Manpower available for military
service: males age 16-49: 27,819,804
females age 16-49: 26,863,794 (2008 est.)
Manpower fit for military service: males
age 16-49: 22,757,136
females age 16-49: 21,920,703 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 621,254
female: 589,270 (2009 est.)
Military expenditures: 0.8% of GDP
(2006)','96f06d84c4e84c7e3f8de6bc7e2a328004c1b2cfb9d05f9af4f9e0582c3a8bb4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b80b0a1a658a8d93896186a83f080ba1819d0efd97e0d84185f2eaa5e3ed4e',2010,'JO','Jordan','military-and-security',883,'Manpower fit for military service:
males age 16-49: 16,920
females age 16-49: 16,826 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 586
female: 541 (2009 est.)
Military — note: defense is the response
bility of the UK
Military branches: Jordanian Armed
Forces (JAF): Royal Jordanian Land Force,
Royal Jordanian Navy, Royal Jordanian Air
Force (Al-Quwwat al-Jawwiya al-Malakiya
al-Urduniya, RJAF), Special Operations
Command (Socom); Public Security Direc¬
torate (normally falls under Ministry of
Interior, but comes under JAF in wartime
or crisis) (2008)
Military service age and obligation: 17
years of age for voluntary military service;
conscription at age 18 was suspended in
1999, although all males under age 37 are
required to register; women not subject to
conscription, but can volunteer to serve in
non-combat military positions (2004)
Manpower available for military service:
males age 16-49: 1,812,551
females age 16-49: 1,559,155 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,593,919
females age 16-49: 1,382,097 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 69,830
female: 67,292 (2009 est.)
Military expenditures: 8.6% of GDP
(2006)','f13eb39324e33e17345fa11ab2ed91b3b7140b81267e806ff2aba164ca17f848','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f31fc721a27f762880946515369eb211bec30de68d73b1f79f2e4f8efc0472d3',2010,'KZ','Kazakhstan','military-and-security',898,'Military branches: Kazakh Armed Forces:
Ground Forces, Navy, Air Mobile Forces,
Air Defense Forces (2009)
Military service age and obligation: 18
years of age for compulsory military service;
conscript service obligation— 2 years;
minimum age for volunteers NA (2004)
Manpower available for military
service: ales age 16-49: 4,176,731
females age 16-49: 4,219,636 (2008 est.)
Manpower fit for military service: males
age 16-49: 2,888,931
females age 16-49: 3,550,014 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 139,262
female: 133,047 (2009 est.)
Military expenditures: 0.9% of GDP
(Ministry of Defense expenditures) (FY02)','01a2cef25984f1838907ba9180bb7b43b6b50a208a1bc466712d62fe6356906d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1825473bb2fc691ac586ec8eb3ed5776f0bb7b09513c122c22a14468afb10f32',2010,'KE','Kenya','military-and-security',906,'Military branches: Kenyan Armed Forces:
Kenyan Army, Kenyan Navy, Kenyan Air
Force (2008)
Military service age and obligation: 18
years of age (est.) for voluntary service, with
a 9-year obligation (2007)
Manpower available for military
Service: males age 16-49: 9,044,685
females age 16-49: 8,805,736 (2008 est.)
Manpower fit for military service: males
age 16-49: 5,935,480
females age 16-49: 5,662,755 (2009 est.)
Manpower reaching militarily
significant age annually: male: 412,656
female: 408,657 (2009 est.)
Military expenditures: 2.8% of GDP
(2006)','2a727e747c075c2f739ec53312d7f5c1cbf4fb257c12263751d5121d17fcb546','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcff7e93af688ac6178f8e565f31fca5ac9a219d590553d30fdd165422ecb141',2010,'KI','Kiribati','military-and-security',914,'Military branches: no regular military
forces (constitutionally prohibited); Police
Force (2009)
Manpower available for military service:
males age 16-49: 26,377 (2008 est.)
Manpower fit for military service:
males age 16-49: 18,129
females age 16-49: 20,643 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 1,264
female: 1,242 (2009 est.)
Military expenditures: NA
Military— note: Kiribati does not have
military forces; defense assistance is
provided by Australia and NZ
Military branches: North Korean People s
Army: Ground Forces, Navy, Air Force;
civil security forces (2005)
Military service age and obligation: 17
years of age (2004)
Manpower available for military
Service: males age 16-49: 6,225,747
females age 16-49: 6,188,270 (2008 est.)
Manpower fit for military service: males
age 16-49: 4,104,964
females age 16-49: 4,492,374 (2009 est.)
Manpower reaching militarily significant
age annually: male: 191,759
female: 184,641 (2009 est.)
Military expenditures: NA
Military branches: Republic of Korea
Army, Navy (includes Marine Corps), Air
Force (2009)
Military service age and obligation:
20-30 years of age for compulsory mili¬
tary service, with middle school educa¬
tion required; conscript service obliga¬
tion— 24-28 months, depending on the
military branch involved (to be reduced
to 18 months beginning 2016); 18-26
years of age for voluntary military service;
women, in service since 1950, admitted to
7 service branches, including infantry, but
excluded from artillery, armor, anti-air, and
chaplaincy corps; some 4,000 women serve
as commissioned and noncommissioned
officers, approx. 2.3% of all officers (2008)
Manpower available for military service:
males age 16-49: 13,691,809
females age 16-49: 13,029,859 (2008 est.)
Manpower fit for military service: males
age 16-49: 10,991,263
females age 16-49: 10,356,604 (2009 est.)
Manpower reaching militarily significant
age annually: male. 371,728
female: 322,605 (2009 est.)
Military expenditures: 2.7% of GDP
(2006)
Manpower fit for military service:
males age 16-49: 428,685
females age 16-49: 388,848 (2009 est.)','a6d6b17eb5222fb0ffcdc182f21b6995fec0fcf463512f192ff46284fab72473','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ca05f6c6238bc60ec65866caedda7aa61d7d46904a403ec9ae8e299d069794b',2010,'KW','Kuwait','military-and-security',923,'Military branches: Kuwaiti Land Forces
(KLF), Kuwaiti Navy, Kuwaiti Air Force (Al-
Quwwat al-Jawwiya al-Kuwaitiya), Kuwaiti
. National Guard (KNG) (2008)
Military service age and obligation: 18-30
years of age for compulsory and 18-25 years
of age for voluntary military service; women
age 18-30 may be subject to compulsory
military service; conscription suspended in
2001 (2009)
Manpower available for military service:
males age 16-49: 1,032,408
females age 16-49: 568,657 (2008 est.)
380','05c31f8b5ef6a4bc8e3e6eb5df20f81ff7e716a968bc1d32604ee49f8efcf002','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d98ccfad55a916295076b71b86b024fa05b49294dea65993d23bb3074b68e83',2010,'KG','Kyrgyzstan','military-and-security',924,'Manpower fit for military service: males
age 16-49: 935,525
females age 16-49: 519,854 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 18,122
female: 18,865 (2009 est.)
Military expenditures: 5.3% of GDP
(2006)
Military branches: Ground Forces, Air
Force (includes Air Defense Forces),
National Guard (2009)
Military service age and obligation: 18
years of age for compulsory military service
(2001)
Manpower available for military
service: males age 16-49: 1,398,878
females age 16-49: 1,419,374 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,083,777
females age 16-49: 1,229,406 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 57,659
female: 55,557 (2009 est.)
Military expenditures: 1.4% of GDP
(2005 est.)','2bc26856f1d050aa1d5783c510c17eb2eb0f02e89c11d577369c9041993ae539','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73efb3ceaea6a2c7ff5fbcbc4d0aa3449ed46befb12db67c7ba4dcda04526545',2010,'TH','Thailand','military-and-security',939,'Military branches: Lao People’s Armed
Forces (LPAF): Lao People’s Army (LPA;
includes Riverine Force), Air Force (2009)
Military service age and obligation: 15
years of age for compulsory military service;
minimum 1 8-month conscript service obli¬
gation (2006)
Manpower available for military service:
males age 16-49: 1,549,774
females age 16-49: 1,570,702 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,023,205
females age 16-49: 1,085,197 (2009 est.)
Manpower reaching militarily significant
age annually: male: 75,310
female: 74,498 (2009 est.)
Military expenditures: 0.5% of GDP
(2006)
Military — note: serving one of the world’s
least developed countries, the Lao People’s
Armed Forces (LPAF) is small, poorly
funded, and ineffectively resourced; its
mission focus is border and internal secu¬
rity, primarily in countering ethnic Hmong
insurgent groups; together with the Lao
People’s Revolutionary Party and the
government, die Lao People’s Army (LPA)
is the third pillar of state machinery, and as
such is expected to suppress political and
civil unrest and similar national emergen¬
cies, but die LPA also has upgraded skills to
respond to avian influenza outbreaks; there
is no perceived external direat to the state
and the LPA maintains strong ties with die
neighboring Vietnamese military (2008)','45ffd36c19e9c879157e3b70b6e81118e360396cce0e061ddafe617c5f032afc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1760676ed4c27b8885aa5b96f22a9d0f40048d21eb5115fb17dcb5500aaa6c48',2010,'LV','Latvia','military-and-security',947,'Military branches: National Armed Forces
(Nacionalo Brunoto Speku): Ground
Forces, Navy (Latvijas Juras Speki; includes
Coast Guard (Latvijas Kara Flotes)), Latvian
Air Force (Latvijas Gaisa Speki), Border
390','5e0141b3cc5569c4683eb0f36a7ace57cbd538eff11124f12205c2b2623bcf96','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f65278940edee81fb8650e91baaf519ba993ded535a94f488176624ccd7ab393',2010,'LB','Lebanon','military-and-security',948,'Guard, Latvian Home Guard (Latvijas
Zemessardze) (2009)
Military service age and obligation: 18
years of age for voluntary male and female
military service; conscription abolished
January 2007; under current law, every
citizen is entitled to serve in the armed
forces for life (2009)
Manpower available for military service:
males age 16-49 : 568,683
females age 16-49: 565,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 410,374
females age 16-49: 463,144 (2009 est.)
Manpower reaching militarily significant
age annually: male: 12,901
female: 12,497 (2009 est.)
Military expenditures: 1.2% of GDP
(2005 est.)
Military branches: Lebanese Armed
Forces (LAF): Army (includes Navy), Air
Force (Al Quwwat al Jawwiya al Lubnaniya)
(2009)
Military service age and obligation:
18-30 years of age for voluntary military
service; no conscription (2007)
Manpower available for military service:
males age 16-49: 1,106,879
females age 16-49: 1,122,595 (2008 est.)
Manpower fit for military service:
males age 16-49: 948,765
females age 16-49: 954,663 (2009 est.)
Manpower reaching militarily significant
age annually: male: 33,018
female: 31,800 (2009 est.)
Military expenditures: 3.1% of GDP
(2005 est.)','5841afaecdb293c7f1372bf0d35c0b34c3eec42eb99da1372847cb416f309696','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cc8248caa2724eb0de85e89ea41f334b551d91d78c326d0bf5d105606cc67bc',2010,'LR','Liberia','military-and-security',960,'Military branches: Lesotho Defense Force
(LDF): Army (includes Air Wing) (2008)
Military service age and obligation:
18-24 years of age for voluntary military
service; no conscription (2008)
Manpower available for military
service: males age 16-49: 525,203
females age 16-49: 522,485 (2008 est.)
Manpower fit for military service:
males age 16-49: 267,083
females age 1 6-49: 240,868 (2009 est.)
Manpower reaching militarily
significant age annually: male: 26,039
female: 25,964 (2009 est.)
Military expenditures:
2.6% of GDP (2006)
Military — note: Lesotho’s declared policy
is maintenance of its independent sover¬
eignty and preservation of internal security;
in practice, external security is guaran¬
teed by South Africa; restructuring of the
Lesotho Defense Force (LDF) and Ministry
of Defense and Public Service over the past
five years has focused on subordinating the
defense apparatus to civilian control and
restoring the LDF’s cohesion; the restruc¬
turing has considerably improved capabili¬
ties and professionalism, but the LDF is
disproportionately large for a small, poor
country; the government has outlined a
reduction to a planned 1 ,500-man strength,
but these plans have met with vociferous
resistance from the political opposition and
from inside the LDF (2008)
Military branches: Armed Forces of
Liberia (AFL): Army, Navy, Air Force
Military service age and obligation: 16
years of age for voluntary military service;
no conscription (2008)
Manpower available for military service:
males age 16-49: 729,813
females age 16-49: 741,223 (2008 est.)
Manpower fit for military service:
males age 16-49: 387,417
females age 16-49: 382,334 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 34,059
female: 33,281 (2009 est.)
Military expenditures: 1.3% of GDP
(2006 est.)','f544958c3a94e0237074524b1ef805f491494473a102f5672203f58eee598156','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d33ca3399d00e00938f420a0b0f4b4f24fa5d0c32dd0acb691c6d9ddb6c0b21e',2010,'LY','Libya','military-and-security',971,'Military branches: Armed Peoples on
Duty (APOD, Army), Libyan Arab Navy,
Libyan Arab Air Force (Al-Quwwat al-
Jawwiya abjamahiriya al-Arabia al-Libyya,
LAAF), Libyan Coast Guard (2008)
Military service age and obligation: 17
years of age (2004)
Manpower available for military
service:
males age 16-49: 1,682,183
females age 16-49: 1,611,001 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,466,578
females age 1 6-49: 1 ,409,684 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 60,710
female: 58,219 (2009 est.)
Militaryexpenditures:3.9%ofGDP(2005esu)','5f44486084a8aed504cc560c4ec0ade4015e6d91da013b49fc4ef284ec0336f8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71250918df904f9f1ab23a8e85c5024d0f8bb006c95b6066949c5cc3f124e75a',2010,'LI','Liechtenstein','military-and-security',979,'Military branches: no regular military
forces (constitutionally prohibited); Prin¬
cipality of Liechtenstein National Police
(Landespolizei, LP) (2008)
Manpower available for military service:
males age 16-49: 8,102 (2008 est.)
Manpower fit for military service:
males age 16-49: 6,584
females age 16-49: 6,801 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 199
female: 222 (2009 est.)
Military — note: Liechtenstein has no mili¬
tary forces, but is interested in European
security policy and is an active member of
the Organization for Security and Coopera¬
tion in Europe (OSCE)','6a8d98b022850bf24624f8109f95e1789a51eb4daca9cd4fe0a3d8f8bb504fde','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d93571c73b2f3d7f910fee13ab0bf8b49b8141a112cc7133a22d80f46531e920',2010,'LU','Luxembourg','military-and-security',987,'Military branches: Ground Forces, Naval
Forces, Air Forces (Karines Oro Pajegos),
National Defense Volunteer Forces (2009)
Military service age and obligation:
19-26 years of age for compulsory military
service; 1 8 years of age for volunteers; 1 2-
month conscript service obligation; male
registration required at age 1 6 (2009)
Manpower available for military
Service: males age 16-49: 915,187
females age 16-49: 906,097 (2008 est.)
Manpower fit for military service:
males age 16-49: 677,689
females age 16-49: 743,468 (2009 est.)
Manpower reaching militarily significant
age annually: male: 23,556
female : 22,404 (2009 est.)
Military expenditures: 1.2% of GDP
(2007 est.)
Military branches: Army (2009)
Military service age and obligation:
17-25 years of age for male and female
voluntary military service; soldiers under
18 are not deployed into combat or with
peacekeeping missions; no conscription;
Luxembourg citizen or EU citizen with 3-
year residence in Luxembourg (2008)
Manpower available for military service:
males age 16-49: 116,305
females age 16-49: 114,566 (2008 est.)
Manpower fit for military service: males
age 16-49: 95,840
females age 16-49: 94,641 (2009 est.)
Manpower reaching militarily significant
age annually: male. 3,170
female: 2,995 (2009 est.)
Military expenditures: 0.9% of GDP
(2005 est.)','79ff62466d134f44c217e2c96bea0adc0979cc36ff2849f1a642e72bf728b5e1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cc5181a137452b187affcd968625c36705ce3b8d3dd9a313c48e3d1f60b6e24',2010,'MG','Madagascar','military-and-security',993,'Military branches: Army of the Republic
of Macedonia (ARM): Joint Operational
Command, with subordinate Air Wing
(Makedonsko Voeno Vozduhoplovstvo,
MW), Special Operations Regiment
(2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2007)
Manpower available for military
Service: males age 16-49: 532,856
females age 16-49: 513,684 (2008 est.)
Manpower fit for military service:
males age 16-49: 444,247
females age 16-49: 427,556 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 14,596
female: 13,881 (2009 est.)
Military expenditures: 6% of GDP (2005
est.)','93504517f3cc36200126cfd231b26dc9454d881dce6a9cb125716102fb822701','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91b16de53e7a14f1a26f39f470ba7246eda6689c1e0fecb8fc942a0495ec60de',2010,'MW','Malawi','military-and-security',1002,'Military branches: People’s Armed
Forces: Intervention Force, Development
Force, and Aeronaval Force (navy and air);
National Gendarmerie
Military service age and obligation: 18-
25 years of age for male-only compulsory
military service; 1 8-month conscript service
obligation (either military or equivalent civil
service); 20-30 years of age for National
Gendarmerie recruits (35 years of age for
those with military experience) (2008)
Manpower available for military
Service: males age 16-49: 4,443,341
females age 16-49: 4,441,124 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,150,043
females age 1 6-49: 3,404,988 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 236,500
female: 235,994 (2009 est.)
Military expenditures: 1% of GDP
(2006)
Military branches: Malawi Armed Forces:
Army (includes Air Wing and Naval
Detachment) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
standard obligation is 2 years of active duty
and 5 years of reserve service (2007)
Manpower available for military service:
males age 1 6-49: 3,050,444 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,732,621
females age 16-49: 1,562,107 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 174,044
female: 173,828 (2009 est.)
Military expenditures: 1.3% of GDP
(2006)','df311ab1c6a9474f77889d491ab693a6b988a5229da3c78a1ecbec4ac8cab2b9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('344c52644627f404db9d2b61f32747799fc74dc71d452957a29263b43fef9c13',2010,'MY','Malaysia','military-and-security',1013,'Military branches: Malaysian Armed
Forces (Angkatan Tentera Malaysia, ATM):
Malaysian Army (Tentera Darat Malaysia),
Royal Malaysian Navy (Tentera Laut Diraja
Malaysia, TLDM), Royal Malaysian Air
Force (Tentera Udara Diraja Malaysia,
TUDM) (2009)
Military service age and obligation: 18
years of age for voluntary military service
(2005)
Manpower available for military
service:
males age 16-49: 6,440,338
females age 16-49: 6,280,826 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,493,946
females age 16-49: 5,409,524 (2009 est.)
Manpower reaching miiitarily signifi¬
cant age annually:
male: 266,267
female: 252,543 (2009 est.)
Military expenditures: 2.03% of GDP
(2005 est.)','b44e2f8043532bbab6e729b9946cf0def4a183a4567adc77da7643834925b808','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e85f0a7cfb5cfdbc94fd10e178140fbf7017f7f028fea1d5322bb95c217362ee',2010,'MV','Maldives','military-and-security',1020,'Military branches: Maldives National
Defense Force (MNDF): Rapid Reaction
Force, Security Protection Group, Coast
Guard (2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military
service: males age 1 6-49: 89,505
females age 16-49: 85,745 (2008 est.)
Manpower fit for military service:
males age 16-49: 138,746
females age 1 6-49: 82,247 (2009 est.)
Manpower reaching militarily
significant age annually: male: 4,576
female: 3,942 (2009 est.)
Military expenditures: 5.5% of GDP
(2005 est.)
Military — note: the Maldives National
Defense Force (MNDF), with its small size
and with little serviceable equipment, is inad¬
equate to prevent external aggression and is
primarily tasked to reinforce the Maldives
Police Service (MPS) and ensure security in
the exclusive economic zone (2008)','30dc19d53e0ab683a8c8c9536b0367f51b436c2ef44b8bdf9c727fa8ec809f41','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80624b5fc4fb797c139f68f986ddcd9698b95c9ebe23417017d1976334f09f6e',2010,'MH','Marshall Islands','military-and-security',1032,'Military branches: Armed Forces of Malta
(AFM; includes air and maritime elements)
(2007)
Military service age and obligation: 17
years 6 months of age for voluntary military
service; no conscription (2008)
Manpower available for military
service: males age 16-49: 96,309
females age 16-49: 92,242 (2008 est.)
Manpower fit for military service: males
age 16-49: 80,186
females age 16-49: 76,426 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 2,695
female: 2,533 (2009 est.)
Military expenditures: 0.7% of GDP
(2006 est.)
Military branches: no regular military
forces; under the 1983 Compact of Free
Association, the US has full authority and
responsibility for security and defense of
the Marshall Islands; Marshall Islands
Police (2009)
Manpower available for military service:
males age 16-49: 15,708 (2008 est.)
Manpower fit for military service:
males age 16-49: 13,041
females age 16-49: 13,199 (2009 est.)
Manpower reaching militarily
significant age annually: male: 540
female: 521 (2009 est.)
Military expenditures: NA
Military— note: defense is the responsi¬
bility of the US','147d0d861c2f640fe526be67a351791aecad22fa654ae68374e1ed425b39cb8a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1783e5e31420e1d9b19e8ed54ae4544c11287351881185f8a182f4e285e12b12',2010,'MU','Mauritius','military-and-security',1047,'Military branches: Mauritanian Armed
Forces: Army, Mauritanian Navy (Marine
Mauritanienne; includes naval infantry),
Islamic Air Force of Mauritania (Force
Aerienne Islamique de Mauritanie, FAIM)
(2008)
Military service age and obligation:
18 years of age (est.); conscript service
obligation— 2 years; majority of servicemen
Africa’s highest per capita incomes. Recent
poor weather, declining sugar prices, and
declining textile and apparel production,
have slowed economic growth, leading to
some protests over standards of living in
the Creole community.
Military branches: no regular military
forces; National Police Force, Special
Mobile Force, National Coast Guard
(2008)
Manpower available for military service:
males age 16-49: 341,018 (2008 est.)
Manpower fit for military service:
males age 16-49: 277,690
females age 16-49: 282,211 (2009 est.)
Chmioi
M''Zamtxsra
T''" >, by
e
?
A
O'': (.
MAMOUDZOU*
Mayotte ''
, .$a<s« v J
:
% $
i
/, /;£ ¥
/''• . r ''/
*> '' ^
0 ts W
Av,.','543a8627ea384e9d2a1f6a8c580707f2fb0a384672e67a56b32fdcf1308088d5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5124bed09e432e8d32ca960a29227dba1a769f30da85cd89fab1a8a98d28a0',2010,'YT','Mayotte','military-and-security',1058,'Manpower fit for military service:
males age 1 6-49: 35,849
females age 16-49: 34,456 (2009 est.)
Manpower reaching militarily
significant age annually: male: 2,51 7
female: 2,511 (2009 est.)
Military — note: defense is the respon¬
sibility of France; a small contingent of
French forces is stationed on the island','213f02a9b2ffd90b216994f27a23b8768facb65a8546bce2fc9977bbced7adea','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbca041e65878652183a075b7ccf3099745909d5c006bf575e9d70eae355af89',2010,'MX','Mexico','military-and-security',1062,'Military branches: Secretariat of National
Defense (Secretaria de Defensa Nacional,
Sedena): Army (Ejercito, includes Mexican
Air Force (Fuerza Aerea Mexicana, FAM));
Secretariat of the Navy (Secretaria de
Marina, Semar): Mexican Navy (Armada
de Mexico, ARM, includes Naval Air Force
(FAN) and naval infantry) (2009)
Military service age and obligation: 18
years of age for compulsory military service,
conscript service obligation— 1 2 months;
1 6 years of age with consent for voluntary
enlistment; conscripts serve only in the
Army; Navy and Air Force service is all
voluntary; women are eligible for voluntary
military service (2007)
Manpower available for military
Service: males age 16-49: 27,774,688
females age 16-49: 29,376,791 (2008 est.)
Manpower fit for military service: males
age 16-49: 22,541,654
females age 16-49: 25,149,027 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 1,109,981
female : 1,072,094 (2009 est.)
Military expenditures: 0.5% of GDP
(2006 est.)','cf8938dcda10ec7083d864a4eefbb0a39b733da161e8d2f334f6dd24f08fd17f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40bb2b2c093f54164ca33989b801786e5879665a1b56f9d76ec30df500c5cd04',2010,'FM','Micronesia, Federated States of','military-and-security',1071,'Military branches: no regular military
forces; defense is the responsibility of the
US (2009)
Manpower available for military service:
males age 16-49: 26,686 (2008 est.) v
Manpower fit for military service:
males age 16-49: 21,845
females age 16-49: 23,401 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 1,273
female: 1,212 (2009 est.)
Military— note: defense is the responsi¬
bility of the US','7a88970c1d297879634452f66c62eb10109cc3215a3e77bd07efbe0e1a1d9e4c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50ace3f16412a1d01a4e63365697aec49503fa81dc212ab087759c7d5008cdaa',2010,'MC','Monaco','military-and-security',1076,'Military branches: National Army: Land
Forces, Rapid Reaction Forces, Air and Air
Defense Forces (2009)
Military service age and obligation: 18
years of age for compulsory military service;
1 7 years of age for voluntary service; male
registration required at age 16; 12-month
service obligation (2009)
Manpower available for military
service: males age 16-49: 1,161,924
females age 16-49: 1,187,771 (2008 est.)
Manpower fit for military service:
males age 16-49: 877,665
females age 16-49: 987,356 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 31,633
female: 30,214 (2009 est.)
Military expenditures: 0.4% of GDP
(2005 est.)
Military branches: no regular military7
forces; the Palace Guard performs ceremo¬
nial duties
Manpower available for military service:
males age 16-49: 6,687 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,495
females age 16-49: 5,406 (2009 est.)
Manpower reaching militarily significant
age annually: male: 190
female: 182 (2009 est.)
Military — note: defense is the responsi¬
bility of France','9e3be0f38e87a716906b565a063e99d0549562e98b0fa9157914fe69e61a8075','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4db0cf30b9aa5612a55252e27556b46fc0f345a89e3aef7c68033ba2a6b87c3e',2010,'MN','Mongolia','military-and-security',1088,'Military branches: Mongolian Armed
Forces: Mongolian Army, Mongolian Air
Force; there is no navy (2009)
Military service age and obligation:
18-25 years of age for compulsory military
service; conscript service obligation— 12
months in land or air defense forces or
police; a small portion of Mongolian land
forces (2.5 percent) is comprised of contract
soldiers; women cannot be deployed over¬
seas for military operations (2006)
Manpower available for military service:
males age 16-49: 865,425
females age 16-49: 860,669 (2008 est.)
Manpower fit for military service:
males age 16-49: 706,774
females age 16-49: 740,550 (2009 est.)
Manpower reaching militarily significant
age annually: male: 28,251
female: 27,344 (2009 est.)
Military expenditures: 1.4% of GDP
(2006)','50afdd470dcfcd95883f9afd9f9d6fd60808bbac9893c7201a22d36d31d0a305','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc2437286647c935ada3f8f64e0829307b74c91420d744a4128c94cdbe7cd4c6',2010,'MS','Montserrat','military-and-security',1094,'Military branches: Armed Forces of the
Republic of Montenegro: Army, Navy, Air
Force (2009)
Military service age and obligation:
compulsory national military service abol¬
ished August 2006
Manpower fit for military service:
males age 16-49: 154,029
females age 16-49: 136,847 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 3,945
female: 3,907 (2009 est.)
Military — note: Montenegrin plans call
for the establishment of a fully professional
armed forces','859a4608b4e598b47d7155719482196826187383a4ebdc46f46aeb9304d66274','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1affa46ecce0f455b6c2043b985f5e9e017a2febfac1d4008d7284b3a401ef56',2010,'MA','Morocco','military-and-security',1102,'Military branches: no regular military
forces; Royal Montserrat Police Force
(2008)
Manpower available for military service:
males age 16-49: 2,528 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,126
females age 16-49: 1,226 (2009 est.)
Manpower reaching militarily
significant age annually: male: 36
female: 33 (2009 est.)
Military— note: defense is the responsi¬
bility of the UK
Military branches: Royal Armed Forces
(Forces Armees Royales, FAR): Royal
Moroccan Army (includes Air Defense),
Navy (includes Marines), Royal Moroccan
Air Force (A1 Quwwat al Jawyiya al
470','de3f3474eb8d7b72e6581aedfa634b519815dd91d06b991181de5f15429b4e0d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e284dcbd74e11c70207fde3056529f1a4dcbfeed5ee7f4e033e7736e6f3f784',2010,'MZ','Mozambique','military-and-security',1107,'Malakiya Marakishiya; Force Aerienne
Royale Marocaine) (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion— 18 months (2004)
Manpower available for military service:
males age 16-49: 9,152,58 0
females age 16-49: 9,080,830 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,779,589
females age 16-49: 7,881,024 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 356,014
female: 343,520 (2009 est.)
Military expenditures: 5% of GDP (2003
est.)
Military branches: Mozambique Armed
Defense Forces (FADM): Mozambique
Army, Mozambique Navy (Marinha Mocarn-
bique, MM), Mozambique Air Force (Forca
Aerea de Mocambique, FAM) (2006)
Military service age and obligation:
19-35 years of age for compulsory mili¬
tary service; 18 years of age for voluntary
service; 2-year service obligation (2009)
Manpower available for military service:
males age 16-49: 4,545,975 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,366,897
females age 16-49: 2,209,764 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 263,994
female: 265,058 (2009 est.)
Military expenditures: 0.8% of GDP
(2006)','9df337c14104fe3e77f8cb99caef87b9dc9fb9968bd3d539a7c72b710a8d8bba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43469dbec7f1f3520750fb93ea1aca1db896b8b7395d60e18e683d7c7b154eea',2010,'NA','Namibia','military-and-security',1119,'Military branches: Namibian Defense
Force: Army, Navy, Air Wing (2008)
Military service age and obligation:
18-25 years of age for voluntary military
service; no conscription (2008)
Manpower available for military service:
males age 16-49: 527,948 (2008 est.)
Manpower fit for military service:
males age 16-49: 329,614
females age 16-49: 294,490 (2009 est.)
Manpower reaching militarily significant
age annually: male: 25,857
female: 25,505 (2009 est.)
Military expenditures:
3.7% of GDP (2006)
477
THE CIA WORLD FACTBOOK','dd24e2164bcb5fe84b80581eea2f2df860b5dc8574d7f35581d84a29ecf5823d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9465e72a406751a4260cf4e0eda07ca1a1ea00acbeae17ba2d2cd1b86dce97ee',2010,'NR','Nauru','military-and-security',1127,'Military branches: no regular military
forces; Nauru Police Force (2009)
Manpower available for military service:
males age 16-49: 3,470 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,592
females age 16-49: 2,966 (2009 est.)
NAVASSA ISLAND
Map references: Central America and the
Caribbean
Area: total: 5.4 sq km
land: 5.4 sq km
water: 0 sq km
Area— comparative: about nine times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: marine, tropical
Terrain: raised coral and limestone plateau,
flat to undulating; ringed by vertical white
cliffs (9 to 1 5 m high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on south¬
west side 77 m
Natural resources: guano
Land use: arable land: 0%
permanent crops: 0%
other : 100% (2005)
Natural hazards: hurricanes
Environment— current issues: NA
Geography— note: strategic location 160
km south of the US Naval Base at Guan¬
tanamo Bay, Cuba; mosdy exposed rock
with numerous solution holes but with
enough grassland to support goat herds; ''
dense stands of fig trees, scattered cactus','71938b1a386c01074701201ceaf874af1db77a49b7ba207add901a1cf460ef92','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd23c3608617314b70dfa9062def2d6567d7357f2f2049af991a22d6fbac6f9e',2010,'NP','Nepal','military-and-security',1134,'Military branches: Nepal Army (2009)
Military service age and obligation: 18
years of age for voluntary military service;
15 years of age for military training; no
conscription (2008)
Manpower available for military service:
males age 16-49: 7,322,965
females age 16-49: 6,859,064 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,886,103
females age 16-49: 5,525,764 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 365,567
female: 352,643 (2009 est.)
Military expenditures: 1.6% of GDP
(2006)','895f5c99e335f26a7488b7a3e3d871e9c74e40458f162b884ae87c0c8b7e20f2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c399933d31cc3f83756ae14987d6922421b31d45892fa6452178e1274a67efc6',2010,'NC','New Caledonia','military-and-security',1143,'Military branches: no regular military
fortes (2009)
Manpower available for military service:
males age 16-49: 57,738 (2008 est.)
Manpower fit for military service: moles
age 16-49: 48,288
females age 16-49: 48,959 (2009 est.)
Manpower reaching militarily
significant age annually: mole. 2,160
female: 2,087 (2009 est.)
Military expenditures: NA
Military — note: defense is the responsibility
of France','5b27ee1a718aa2978802c44fd1ba1e5afd2ae3fc387412ade54d8b314eaa8fa2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50c9028398e0f30b2c81203ed25be386b5d051cab44a506dc64d88cc0a7ec561',2010,'NI','Nicaragua','military-and-security',1149,'Military branches: New Zealand Defense
Force (NZDF): New Zealand Army, Royal
New Zealand Navy, Royal New Zealand
Air Force (2009)
Military service age and obligation: 17
years of age for voluntary military service;
soldiers cannot be deployed until the age
of 18; no conscription (2008)
Manpower available for military service:
males age 16-49: 1,009,298
females age 16-49: 997,134 (2008 est.)
Manpower fit for military service: males
age 16-49: 837,553
females age 16-49: 825,981 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male 31,461
female: 29,809 (2009 est.)
Military expenditures:
1% of GDP (2005 est.)
Military branches: National Army of
Nicaragua (ENN; includes Navy, Air
Force) (2008)
Military service age and obligation: 17
years of age for voluntary military service;
tour of duty 18-36 months (2008)
Manpower available for military service:
males age 16-49: 1,513,312
females age 16-49: 1,507,999 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,277,878
females age 16-49: 1,339,413 (2009 est.)
Manpower reaching militarily
significant age annually:
'' male: 72,366
female: 70,118 (2009 est.)
Military expenditures:
0.6% of GDP (2006)','81cf7e302d5874080ee08432d35b0a8ec7ea4c4553bce67d0c2aeb1924ee7586','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f16ec3f2684f163a3fc425657768f9bf994f61397190eea737169221ff4b3db7',2010,'NE','Niger','military-and-security',1158,'Military branches: Nigerien Armed Forces
(Forces Armees Nigeriennes, FAN): Army,
Niger Air Force (Force Aerienne du Niger)
(2008)
Military service age and obligation:
17-21 years of age for voluntary military
service; 2-year service term; women may
serve in health care (2008)
Manpower available for military service:
males age 16-49: 2,871,868
females age 16-49: 2,696,966 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,019,553
females age 16-49: 2,046,906 (2009 est.)
Manpower reaching militarily significant
age annually: male: 170,060
female: 163,996 (2009 est.)
Military expenditures: 1.3% of GDP
(2006)','603b8da83e4d67028434de7f8b0a3875be17a0aa49011681b59fe8411be22a94','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ed2ff50235fe26c7c7da613346ed15b7e5ad30f3e9e4f40ab72dfbb2d6478ba',2010,'NU','Niue','military-and-security',1167,'Military branches: Nigerian Armed
Forces: Army, Navy, Air Force (2008)
Military service age and obligation:
1 8 years of age for voluntary military service
(2007)
Manpower available for military service:
males age 16-49: 31,929,204
females age 16-49: 30,638,979 (2008 est.)
Manpower fit for military service:
males age 16-49: 19,763,535
females age 16-49: 18,850,650 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 1,697,030
female: 1,618,561 (2009 est.)
Military expenditures:
1.5% of GDP (2006)
GEOGRAPHY NIUE
Location: Oceania, island in the South
Pacific Ocean, east of Tonga
Geographiccoordinates:1902S,16952W
Map references: Oceania
Area: total: 260 sq km
land: 260 sq km
water: 0 sq km
Area — comparative: 1.5 times the size of
Washington, DC','f76f744ce2b7e3c5479a7ae3e9a23b29dab2d16d93f8a356b449c38207c2ea5a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7752cd9e96ce192f3e8f2317e88fbf2e000aaa4dfae5a164da6f4520198b1f8',2010,'MP','Northern Mariana Islands','military-and-security',1178,'Military — note: defense is the responsibility
of Australia
TRANSNATIONAL
Disputes — international: none','9b08bac95cac5d48bc4e27db0cc0ed35c5baa081619c7920fd3890829cd4eced','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed2cc7ab1e3553d60d3478ec17601d82154ac64c2e6b446e81dbc95b37113330',2010,'NO','Norway','military-and-security',1185,'Manpower fit for military service:
males age 16-49: 19,209
females age 16-49: 33,074 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 570
female: 587 (2009 est.)
Military — note: defense is the responsi¬
bility of the US
Military branches: Norwegian Army
(Haeren), Royal Norwegian Navy
(Kongelige Norske Sjoeforsvaret, RNoN;
includes Coastal Rangers and Coast Guard
(Kystvakt)), Royal Norwegian Air Force
(Kongelige Norske Luffforsvaret, RNoAF),
Home Guard (Heimevernet, HV) (2007)
Military service age and obligation:
18-44 years of age for male compulsory
military service; 1 6 years of age in wartime;
17 years of age for male volunteers; 18
years of age for women; 1 2-month service
obligation, in practice shortened to 8 to 9
months; although all males between ages of
1 8 and 44 are liable for service, in practice
they are seldom called to duty after age 30;
reserve obligation to age 35-60; 16 years
of age for volunteers to the Home Guard,
who serve 6-month duty tours (2009)
Manpower available for military service:
males age 16-49: 1,078,181
females age 16-49: 1,046,550 (2008 est.)
Manpower fit for military service:
males age 16-49: 888,219
females age 16-49: 863,255 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 31,980
female: 30,543 (2009 est.)
Military expenditures:
1.9% of GDP (2005 est.)','b81ce01af1c71179801c9ab08ceb76956d6cfe46a1067f4c5f002cafc940bff1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c30b804eaf33953ce1a31aead886684789031551f17b47c7c99227e7987ed8f1',2010,'OM','Oman','military-and-security',1194,'Military branches: Sultan’s Armed Forces
(SAF): Royal Army of Oman, Royal Navy of
Oman, Royal Air Force of Oman (2008)
Military service age and obligation:
18-30 years of age for voluntary military
service; no conscription (2008)
Manpower available for military
Service: males age 1 6-49: 802,455
females age 16-49: 626,841 (2008 est.)
Manpower fit for military service:
males age 16-49: 675,454
females age 16-49: 563,890 (2009 est.)
Manpower reaching militarily significant
age annually: male. 35,647
female: 34,407 (2009 est.)
Military expenditures: 11.4% of GDP
(2005 est.)','3de43cfe3960838b334f6c0a93158a787fdfd46c37888a1454c696a4c0533893','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6626069b2542cd56e225f64e923ae4ee491ced81c4a49d2771a9e034fe50e0cb',2010,'PK','Pakistan','military-and-security',1204,'Military branches: Army (includes
National Guard), Navy (includes Marines
and Maritime Security Agency), Pakistan
Air Force (Pakistan Fiza’ya) (2008)
Military service age and obligation:
17-23 years of age for voluntary military
service; soldiers cannot be deployed for
combat until age 18; the Pakistani Air
Force and Pakistani Navy have inducted
their first female pilots and sailors (2009)
Manpower available for military
service: males age 16-49: 42,633,765
females age 16-49: 40,114,017 (2008 est.)
Manpower fit for military service: males
age 16-49: 33,690,322
females age 16-49: 32,602,910 (2009 est.)
Manpower reaching militarily significant
age annually: male: 2,089,936
female: 1,964,090 (2009 est.)
Military expenditures: 3% of GDP (2007
est.)','67637b652ef42185049237e24663278ee3a5178026ffa57433ab77fa27a9c10c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b89f74192ca3e8ae821e1f2ce247e0a39cdc2b115c692834c035fa87c64bb9',2010,'PA','Panama','military-and-security',1213,'Military branches: no regular military
forces; Palau National Police (2009)
Manpower available for military service:
males age 16-49: 5,973 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,177
females age 16-49: 3,936 (2009 est.)
Manpower reaching militarily
significant age annually: male: 207
female: 214 (2009 est.)
Military expenditures: NA
Military — note: defense is the responsi¬
bility of the US; under a Compact of Free
Association between Palau and the US, the
US military is granted access to the islands
for 50 years, but it has not stationed any
military forces there (2008)
Military branches: no regular military forces;
Panamanian public forces include: Panama¬
nian National Police (PNP), National Air-
Naval Service (SENAN), National Border
Service (SENAFRONT) (2009)
Manpower available for military service:
males age 16-49: 851,044 (2008 est.)
Manpower fit for military service:
males age 16-49: 705,160
females age 16-49: 710,521 (2009 est.)','23a6d8dceb8bac2d8802240500b9901767895a251975d40a01c13e724f99b751','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68bde0d0f237edce3526e1996c71e36672e9937facdb56dc0b037f93e4891a28',2010,'PG','Papua New Guinea','military-and-security',1218,'areas until independence in 1975. A nine-
year secessionist revolt on the island of
Bougainville ended in 1997 after claiming
some 20,000 lives.
Military branches: Papua New Guinea
Defense Force (PNGDF; includes Maritime
Operations Element, Air Operations
Element) (2009)
Military service age and obligation: 16
years of age for voluntary military service
(with parental consent); no conscription
(2008)
Manpower available for military service:
males age 16-49: 1,481,417
females age 16-49: 1,385,040 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,110,175
females age 16-49: 1,127,758 (2009 est.)
Manpower reaching militarily significant
age annually: male: 64,636
female: 62,803 (2009 est.)
Military expenditures: 1.4% of GDP
(2005 est.)
Military— note: occupied by China','a91fd5448a92454b377b80cb3a5ca3b12a37855f33edf8867a81a9438f883ff5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1dd9aaf1d9586b6074b74ec5e124b1a4ac322f7d92ec61148bbd4775fcd37b',2010,'PE','Peru','military-and-security',1233,'Military branches: Army, National Navy
(Armada Nacional, includes Naval Avia¬
tion, Marine Corps, General Naval Prefec¬
ture), Air Force (Fuerza Aerea Paraguay,
FAP) (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion— 1 2 months for Army, 24 months for
Navy (2007)
Manpower available for military service:
males age 16-49: 1,589,873
females age 16-49: 1,585,573 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,363,746
females age 16-49: 1,390,799 (2009 est.)
Manpower reaching militarily significant
age annually: male: 73,660
female: 72,046 (2009 est.)
Military expenditures: 1% of GDP (2006
est.)
Military branches: Army of Peru (Ejercito
Peruano), Navy of Peru (Marina de Guerra
del Peru, MGP (includes naval air, naval
infantry, and Coast Guard)), Air Force of
Peru (Fuerza Aerea del Peru, FAP) (2008)
Military service age and obligation:
1 8-30 years of age for voluntary male and
female military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 7,653,898
females age 16-49: 7,531,329 (2008 est.)
Manpower fit for military service: males
age 16-49: 5,920,716
females age 16-49: 6,359,803 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 310,575
female: 300,838 (2009 est.)
Military expenditures: 1.5% of GDP
(2006)','5390e17e560806907326bf0b5b13e7a10c7a9f1238c04851c6e901a0f9260e79','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de414de7a3df0101b084091866e6a84203bc6ebe70bb67ce78d9b0f9d259223e',2010,'PH','Philippines','military-and-security',1239,'Military branches: Armed Forces of the
Philippines (AFP): Army, Navy (includes
542
PITCAIRN ISLANDS
Marine Corps and Coast Guard), Air
Force (2009)
Military service age and obligation:
18-25 years of age (officers 21-29) for
compulsory and voluntary military service;
applicants must be single male or female
Philippine citizens (2007)
Manpower available for military
service:
males age 16-49: 23,547,252
females age 16-49: 23,177,487 (2008 est.)
Manpower fit for military service:
males age 16-49: 19,169,298
females age 16-49: 20,636,853 (2009 est.)
Manpower reaching militarily significant
age annually: male: 1,023,431
female: 986,434 (2009 est.)
Military expenditures: 0.9% of GDP
(2005 est.)
Background: Pitcairn Island was discov¬
ered in 1767 by the British and settled in
1790 by the Bounty mutineers and their
Tahitian companions. Pitcairn was the first
Pacific island to become a British colony
(in 1838) and today remains the last vestige
of that empire in the South Pacific. Outmi¬
gration, primarily to New Zealand, has
thinned the population from a peak of 233
in 1937 to less than 50 today.','b85148b45358226091a260c5fb8295f777c84ee4600881c73e1d43064ac6299b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ff8866abdcc1493699f4b85d0b57a3728488a04cc85acd2a8bcbb6d95730ade',2010,'PL','Poland','military-and-security',1243,'Military— note: defense is the responsi¬
bility of the UK
Military branches: Polish Armed Forces:
Land Forces, Navy, Air and Air Defense
Aviation Forces, Special Forces (2008)
Military service age and obligation:
18-28 years of age for male voluntary or
compulsory military service; service obli¬
gation shortened from 12 to 9 months
in 2005; conscription is to end in 2012;
only soldiers who have completed their
conscript service are allowed to volunteer
for professional service; as of April 2004,
women are only allowed to serve as officers
and noncommissioned officers; reserve
obligation to age 50 (2009)
Manpower available for military
service: males age 16-49: 9,741,508
females age 16-49: 9,514,843 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,898,892
females age 16-49: 7,888,035 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 246,667
female: 235,698 (2009 est.)
Military expenditures: 1.71% of GDP
(2005 est.)','5154c5acbd208bb242df6ecc940c4328a7f29b4f82cdd1ab92556adc557f1854','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be452265e8f406f8299fa971e5332f8d098f6a2d7d34803a208692ebab3cc90',2010,'PT','Portugal','military-and-security',1252,'Military branches: Portuguese Army
(Exercito Portugues), Portuguese Navy
(Marinha Portuguesa; includes Marine
Corps), Portuguese Air Force (Forca Aerea
Portuguesa, FAP) (2009)
Military service age and obligation: 18
years of age for voluntary military service;
compulsory military service ended in 2004;
women serve in the armed forces, on naval
ships since 1993, but are prohibited from
serving in some combatant specialties;
reserve obligation to age 35 (2007)
Manpower available for military
Service: males age 16-49: 2,573,913
females age 16-49: 2,498,262 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,103,558
females age 16-49: 2,049,032 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male 64,047
female: 57,630 (2009 est.)
Military expenditures: 2.3% of GDP
(2005 est.)','6609c2145c5bbf86b3e768f8d47ab4724fca7755f96c89b3c1031e296866e1cd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9c1d6f9fd5b11edca7a8818f752136266a1e79b51af4cd46848543a19855f6c',2010,'PR','Puerto Rico','military-and-security',1260,'Military branches: no regular indigenous
military forces; paramilitary National
Guard, Police Force
Manpower fit for military service:
males age 16-49: 699,784
females age 16-49: 790,482 (2009 est.)
Manpower reaching militarily significant
age annually: male. 30,422
female: 29,396 (2009 est.)
Military — note: defense is the responsi¬
bility of the US
Manpower fit for military service:
males age 16-49: 6,336
females age 16-49: 6,925
(2009 est.)
Manpower reaching militarily
significant age annually: male. 177
female: 162 (2009 est.)
Military — note: defense is the responsibility
of France CENTRAL AMERICA AND
CARIBBEAN SAINT MARTIN (OVER¬
SEAS COLLECTIVITY OF FRANCE)','384f4e611189a71f8f6c1ab06f1f957fe1adad9eb82c9817fe1a283192ea7068','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808ac2b691164c975f6f587d0f7beebedca0f1745677c04ed3e5b3bd0fa72224',2010,'QA','Qatar','military-and-security',1265,'Military branches: Qatari Amiri Land
Force (QALF), Qatari Amiri Navy (QAN),
Qatari Amiri Air Force (QAAF) (2007)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military service:
males age 16-49: 320,383
females age 16-49: 167,475 (2008 est.)
Manpower fit for military service: males
age 16-49: 318,388
females age 16-49: 136,841 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 6,337
female: 5,059 (2009 est.)
Military expenditures: 10% of GDP
(2005 est.)','54c9874f1f137b84088e8b3263b8ee4a05f1e890e96a21f1a70dcf5323ca0969','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1d08a2371b2976f3e40e2e535b719390895f2697b78be8bb8d93c7275f28eb1',2010,'RO','Romania','military-and-security',1271,'Military branches: Land Forces, Naval
Forces, Romanian Air Force (Fortele
Aeriene Romane, FAR), Special Opera¬
tions (2009)
Military service age and obligation: 18-
35 years of age for male and female volun¬
tary military service; conscription officially
ended October 2006; all military inductees
(including women) contract for an initial
5-year term of service, with subsequent
successive contracts for 3-year terms until
age 36 (2009)
Manpower available for military service:
males age 16-49: 5,682,299
females age 16-49: 5,557,098 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,542,720
females age 16-49: 4,604,484 (2009 est.)
Manpower reaching militarily significant
age annually: male: 124,356
female: 118,430 (2009 est.)
Military expenditures: 1.9% of GDP
(2007 est.)','82b78b4479312e4b9f597c4f68d0118b81c95151364e10e08b46222ee1ded757','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa804e8880f029f7cbff24f3fa71349cfd6360553abe46d9502fb46ebd504543',2010,'RU','Russian Federation','military-and-security',1276,'Military branches: Ground Forces
(Sukhoputnyye Voyskia, SV), Navy
(Voyenno-Morskoy Flot, VMF), Air
Forces (Voyenno-Vozdushniye Sily, WS);
565
THE CIA WORLD FACTBOOK
Airborne Troops (VDV), Strategic Rocket
Forces (Raketnyye Voyska Strategicheskogo
Naznacheniya, RVSN), and Space Troops
(Kosmicheskiye Voyska, KV) are inde¬
pendent “combat arms,” not subordinate to
any of the three branches; Russian Ground
Forces include the following combat arms:
motorized-rifle troops, tank troops, missile
and artillery troops, air defense of ground
troops (2009)
Military service age and obligation: 18-
27 years of age for compulsory or voluntary
military service; males are registered for
the draff at 1 7 years of age; service obliga¬
tion— 1 year; reserve obligation to age 50;
as of July 2008, a draff military strategy
called for the draff to continue up to the
year 2030 (2009)
Manpower available for military service:
males age 16-49: 36,219,908
females age 16-49: 37,019,853 (2008 est.)
Manpower fit for military service: males
age 16-49: 21,098,306
females age 16-49: 27,968,883 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 741,692
female: 706,081 (2009 est.)
Military expenditures: 3.9% of GDP
(2005)','c4ec1b25a5a7b78eee3c056891d32838bfc2a1ab863480f8e0387961d4ce2c17','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0eb2873ebdca4a68a6e0661533c7ae0128ece449643bdf582bb87316fa6f61a',2010,'RW','Rwanda','military-and-security',1284,'Military branches: Rwandan Defense
Forces: Army, Air Force
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military service:
males age 16-49: 2,430,469
females age 16-49: 2,392,933 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,452,768
females age 16-49: 1,456,207 (2009 est.)
Manpower reaching militarily significant
age annually:
male: 106,741
female: 106,935 (2009 est.)
Military expenditures: 2.9% of GDP
(2006 est.)','752ed8c3a2f5abf8607e6789b1890071b42858c63b65d1fed9426b5fb625b942','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09216f76ec6398434b494ab1f80c8dd4892904d36f57189979052565debd20e2',2010,'GP','Guadeloupe','military-and-security',1289,'Manpower fit for military service:
males age 16-49: 1,594
females age 16-49: 1,340 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 21
female: 20 (2009 est.)
Military — note: defense is the responsibility
of France
SAINT HELENA','b97c71366c6957c69ca1a50055cadabf2d862ef91a3ee10f0e00cb58a9bc2273','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd327eef961e747b0dcde3dffe9f49d0645e582725f092a84c6dbf1b550b27b',2010,'KN','Saint Kitts and Nevis','military-and-security',1298,'Manpower fit for military service:
males age 1 6-49: 1 ,586
females age 16-49: 1,600 (2009 est.)
Manpower reaching militarily
significant age annually: male: 47
female: 45 (2009 est.)
Military — note: defense is the responsi¬
bility of the UK
Military branches: Royal Saint Kitts
and Nevis Defense Force (includes Coast
Guard), Royal Saint Kitts and Nevis Police
Force (2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military service:
males age 16-49: 10,095
females age 16-49: 10,081 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,159
females age 16-49: 8,517 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 376
female: 362 (2009 est.)
Military expenditures:
NA','20b50b8341d1de29e3d5c3a03529fbcf437e2143e3b9be4213eb0e868afad2d3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d04be53acaedf8c8e195259fb1a69dc1a3658e53ba7a16d337eb3c47b0e428bb',2010,'LC','Saint Lucia','military-and-security',1310,'Military branches: no regular military
forces; Royal Saint Lucia Police Force
(includes Special Service Unit and Coast
Guard) (2007)
Manpower available for military service:
males age 16-49: 48,358 (2008 est.)
Manpower fit for military service:
males age 16-49: 32,094
females age 16-49: 36,110 (2009 est.)
Manpower reaching militarily
significant age annually: male: 1,607
female: 1,511 (2009 est.)
Military expenditures: NA','6db6f541f235731171ba36ecf5e6b150dba393c354768fab812fe5c43e9b093d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d05d6dac854ecb67c0f178fc81a482a5f452f6c10e7d8f5ccf465d90f975bd8',2010,'PM','Saint Pierre and Miquelon','military-and-security',1311,'Background: First settled by the French in
the early 17th century, the islands repre¬
sent the sole remaining vestige of France’s
once vast North American possessions.
Manpower fit for military service:
males age 16-49: 1,427
females age 16-49: 1,406 (2009 est.)
Manpower reaching militarily
significant age annually: male: 61
female: 57 (2009 est.)
Military — note: defense is the
responsibility of France','5a5fe87a1473b43fa14b65f3a62c25519b9bcfe84dc831f36a8ab9f07ab6548f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('161477a570db152c43e1c5d339cebd1d161b81048723fc03e510d984135dca5a',2010,'WS','Samoa','military-and-security',1327,'Military branches: no regular military
forces; Royal Saint Vincent and the
Grenadines Police Force, Coast Guard
(2007)
Manpower available for military service:
males age 16-49: 34,373 (2008 est.)
Manpower fit for military service:
males age 16-49: 22,975
females age 16-49: 22,250 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 1,020
female: 1 ,009 (2009 est.)
Military expenditures:
NA','8e9caef8bb5adcedeeac6de454d0ce79201da8ab14542ea4260995b09215b800','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad0ba53175910ba17f6bef4474ba25557fb7512d89e3ca1635ab2e13f0698291',2010,'SM','San Marino','military-and-security',1335,'Military branches: no regular military
forces; Samoa Police Force (2008)
Manpower available for military service:
males age 16-49: 53,417 (2008 est.)
Manpower fit for military service:
males age 16-49: 43,169
females age 16-49: 40,957 (2009 est.)
Manpower reaching militarily
significant age annually: male: 2,597
female: 2,477 (2009 est.)
Military expenditures:
NA
Military — note: Samoa has no formal
defense structure or regular armed forces;
informal defense ties exist with NZ, which
is required to consider any Samoan request
for assistance under the 1962 Treaty of
Friendship','447920103068f96662b51a0561ea63118b3c023c00976d2d1cb0799c38eb56ff','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cc5f756c8329426b9883b701639e472f024ce500c00556d032ba731bd738841',2010,'ST','Sao Tome and Principe','military-and-security',1344,'Military branches: no regular military
forces; Voluntary Military Force (Corpi
Militari Voluntar) performs ceremonial
duties and limited police support functions
(2008)
Military service age and obligation:
16-55 for voluntary service in Voluntary
Military Force (2006)
Manpower available for military service:
males age 16-49: 6,613 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,343
females age 16-49: 6,048 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 161
female: 160 (2009 est.)
Military expenditures:
NA
Military — note: defense is the responsi¬
bility of Italy
Military branches: Armed Forces of Sao
Tome and Principe (FASTP): Army, Coast
Guard of Sao Tome e Principe (Guarda
Costeira de Sao Tome e Principe, GCSTP),
Presidential Guard (2007)
Military service age and obligation: 18
years of age (est.) (2004)
Manpower available for military service:
males age 16-49: 42,340
females age 16-49: 43,781 (2008 est.)
Manpower fit for military service:
males age 16-49: 35,216
females age 16-49: 38,329 (2009 est.)
Manpower reaching militarily
significant age annually: male: 2,534
female: 2,485 (2009 est.)
Military expenditures: 0.8% of GDP
(2006)
Military — note: Sao Tome and Principe’s
army is a tiny force with almost no resources
at its disposal and would be wholly inef¬
fective operating unilaterally; infantry
equipment is considered simple to operate
and maintain but may require refurbish¬
ment or replacement after 25 years in trop¬
ical climates; poor pay, working conditions,
and alleged nepotism in the promotion of
officers have been problems in the past, as
reflected in the 1995 and 2003 coups; these
issues are being addressed with foreign
assistance aimed at improving the army
and its focus on realistic security concerns;
command is exercised from the president,
through the Minister of Defense, to the
Chief of the Armed Forces staff (2005)','391467e9de29843c07171d955de95c0a8adb5110d3ae1f3b6c40b0984242b62f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e646b865b22b7c2097254cb17df83f1fa8d64493e69cb1b08dd98499502fc5c',2010,'SA','Saudi Arabia','military-and-security',1355,'Military branches: Land Forces (Army),
Navy, Air Force, Air Defense Force,
National Guard, Ministry of Interior
Forces (paramilitary)
594','cee0c2b0f528a944dc4193f5b61886ea2072354f103e4406c91a1b90dc427c10','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b816533a77eddc9a934fb0294781c218e78162c791b4c5cad30167bb93397003',2010,'RS','Serbia','military-and-security',1363,'Military branches: Serbian Armed
Forces (Vojska Srbije, VS): Land Forces
Command (includes Riverine Component,
consisting of a river flotilla on the Danube),
Joint Operations Command, Air and Air
Defense Forces Command (2008)
Military service age and obligation:
19-35 years of age for compulsory military
service; under a state of war or impending
war, conscription can begin at age 16;
conscription is to be abolished in 2010;
9-month service obligation, with a reserve
obligation to age 60 for men and 50 for
women (2007)
Manpower reaching militarily
significant age annually:
male: 66,263
female: 62,165 (2008 est.)','43ef2d1afadc8ac22dc8370321c5893211317372c6a107b0a6783101ccb8ec31','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea03512b5d910fe55d844b07e4f26bedbaf42cac20b7713b327ee85c36ce5490',2010,'SC','Seychelles','military-and-security',1370,'Military branches: Seychelles Defense
Force: Army, Coast Guard (includes Naval
Wing, Air Wing), National Guard (2005)
Military service age and obligation: 18
years of age for voluntary military service
(younger with parental consent); no
conscription (2008)
Manpower available for military service:
males age 16-49: 23,598
females age 1 6-49: 24,424 (2008 est)
Manpower fit for military service:
males age 16-49: 19,702
females age 16-49: 19,780 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 714
female: 685 (2009 est.)
Military expenditures:
2% of GDP (2006 est.)','0b4c5ef0243ca850c9fa53a1c30c228251536be0b3c50ca436f2bd998c5bb63d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8937eb7c425127f281b31e2368eb3e3ad6b93f82c0d80cdba1772b5d3d8a6b9b',2010,'SG','Singapore','military-and-security',1379,'Military branches: Republic of Sierra
Leone Armed Forces (RSLAF): Army
(includes Maritime Wing and Air Wing)
(2008)
Military service age and obligation: 17
years 6 months of age for voluntary military
service (younger with parental consent); no
conscription (2008)
Manpower available for military service:
males age 16-49: 1,315,561 (2008 est.)
Manpower fit for military service:
males age 16-49: 692,469
females age 16-49: 762,239 (2009 est.)
Manpower reaching militarily
significant age annually: male: 71,524
female : 75,491 (2009 est.)
Military expenditures:
2.3% of GDP (2006)
Military branches: Singapore Armed
Forces: Army, Navy, Air Force (includes
Air Defense) (2009)
Military service age and obligation:
1 8-21 years of age for male compulsory mili¬
tary service; 16 years of age for volunteers;
2-year conscript service obligation, with a
reserve obligation to age 40 (enlisted) ''or
age 50 (officers) (2008)
Manpower available for military service:
males age 16-49: 1,277,862 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,033,961
females age 16-49: 1,104,952 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 27,715
female: 26,290 (2009 est.)
Military expenditures:
4.9% of GDP (2005 est.)','581221dbac3af43a57d9d46addd3e6259f66a9be8dabda787234ab7430f22578','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('610e131b2fa9e75ec97dcb4429cd04c310974a0885f9af120f2e03ac4c11d10e',2010,'SI','Slovenia','military-and-security',1389,'Military branches: Armed Forces of the
Slovak Republic (Ozbrojene Sily Sloven-
skej Republiky): Land Forces (Pozemne
Sily), Air Forces (Vzdusne Sily) (2009)
Military service age and obligation:
17—30 years of age for voluntary military
service; conscription abolished in 2006;
women are eligible to serve (2007)
Manpower available for military
service: males age 16-49: 1,420,966
females age 16-49: 1,386,259 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,165,470
females age 16-49: 1,152,941 (2009 est.)
Manpower reaching militarily
significant age annually: male: 36,552
female: 34,783 (2009 est.)
Military expenditures:
1.87% of GDP (2005 est.)','c90ac3e860eb907c73f5d037654597ecaa8480c9273f445b497cccf088a6cd6c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fe1fbe83a3e1544f2ccd8c88de1f6260a2244de9b76a08d0e39d9758a9b4f2f',2010,'SB','Solomon Islands','military-and-security',1395,'Military branches: Slovenian Army
(includes air and naval forces)
Military service age and obligation: 17
years of age for voluntary military service;
conscription abolished in 2003 (2007)
Manpower available for military service:
males age 1 6-49: 494,496
females age 16-49: 481,180 (2008 est.)
Manpower fit for military service:
males age 16-49: 402,484
females age 1 6-49: 390,559 (2009 est.)
Manpower reaching militarily
significant age annually: male: 10,192
female: 9,717 (2009 est.)
Military expenditures:
1.7% of GDP (2005 est.)
Military branches: no regular military
forces; Solomon Islands Police Force
(2009)
Manpower available for military service:
males age 16-49: 141,051 (2008 est.)
Manpower fit for military service:
males age 16-49: 121,368
females age 16-49: 122,821 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 7,091
female: 6,837 (2009 est.)
Military expenditures:
3% of GDP (2006)','87e7347f158e88bcc4763106960e7fdcd3d497cf2998c1935bac07210e7679ff','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d463cb1147b8a28060283830585d1361579c2af284d643a797552f37916ce44',2010,'ZA','South Africa','military-and-security',1405,'Manpower available for military service:
males age 16-49: 2,181,050
females age 16-49: 2,125,558 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,301,026
females age 16-49: 1,351,649 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 93,763
female: 93,738 (2009 est.)
Military expenditures:
0.9% of GDP (2005 est.)
Military branches: South African
National Defense Force (SANDF): South
African Army, South African Navy (SAN),
South African Air Force (SAAF), Joint
Operations Command, Military Intel¬
ligence, South African Military Health
Services (2009)
Military service age and obligation: 18
years of age for voluntary military service;
women are eligible to serve in noncombat
roles; 2-year service obligation (2007)
Manpower available for military service:
males age 16-49: 11,622,507
females age 16-49: 11,501,537 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,641,557
females age 16-49: 6,518,793 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 51 1,616
female: 510,540 (2009 est.)
Military expenditures:
1.7% of GDP (2006)
Military — note: with the end of apartheid
and die establishment of majority rule,
former military, black homelands forces,
and ex-opposition forces were integrated
into the South African National Defense
Force (SANDF); as of 2003 the integration
process was considered complete','511c8cf35785ea9050096befb33e0f9a59b1dbfeb09717e5cc553542b7e8c796','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7faeac02691451c368aa3f59de78cd8f00d1cd9239f2fdaab67fbd5a9e0eaea6',2010,'ES','Spain','military-and-security',1422,'Military branches: Spanish Armed Forces:
Army (Ejercito de Tierra), Spanish Navy
(Armada Espanola, AE; includes Marine
Corps), Spanish Air Force (Ejercito del
Aire Espanola, EdA) (2009)
Military service age and obligation: 20
years of age (2004)
Manpower available for military
Service: males age 16-49: 10,033,069
females age 16-49: 9,764,937 (2008 est.)
Manpower fit for military service:
males age 16-49: 8,139,020
females age 16-49: 7,899,157 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 199,124
female: 187,224 (2009 est.)
Military expenditures:
1.2% of GDP (2005 est.)
Military — note: Spratly Islands consist of
more than 100 small islands or reefs of
which about 45 are claimed and occupied
by China, Malaysia, the Philippines,
Taiwan, and Viemam
Military branches: Trinidad and Tobago
Defense Force (TTDF): Trinidad and
Tobago Army, Coast Guard, Air Guard,
Trinidad and Tobago Police Service (2008)
Military service age and obligation: 18
years of age for voluntary military service
(16 years of age with parental consent); no
conscription (2008)
Manpower available for military service:
males age 16-49: 301,561
females age 16-49: 264,225 (2008 est.)
Manpower fit for military service:
males age 16-49: 276,224
females age 16-49: 271,677 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 9,183
female: 8,662 (2009 est.)
Military expenditures: 0.3% of GDP (2006)','90d5dbff6c51af82cf69160b39e190eb9ac67201bbd28fb77d57ad01017be862','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6443fb083823f55cba8bab493979e9cc85469b4004ec105984d4e4fce62b5783',2010,'SD','Sudan','military-and-security',1426,'Military branches: Sri Lanka Army, Sri
Lanka Navy, Sri Lanka Air Force (2009)
Military service age and obligation: 18
years of age for voluntary military service;
5-year service obligation (2007)
Manpower available for military service:
males age 16-49: 5,458,72 0
females age 16-49: 5,594,006 (2008 est.)
Manpower fit for military service:
males age 16-49: 4,498,667
females age 16-49: 4,693,895
(2009 est.)
Manpower reaching militarily
significant age annually:
male: 173,256
female: 167,645 (2009 est.)
Military expenditures:
2.6% of GDP (2006)
Military branches: Sudanese Armed
Forces (SAF): Land Forces, Navy, Sudanese
Air Force (Sikakh al-Jawwiya as-Sudaniya),
Popular Defense Forces; Sudan People’s
Liberation Army (SPLA): Land Forces
(2009)
Military service age and obligation:
18-33 years of age for compulsory and
voluntary military service; 12-24 month
service obligation (2009)
Manpower available for military service:
males age 16-49: 9,639,923
females age 16-49: 9,321,106 (2008 est.)
640','6446097b970e70ac2646cb4fe04927de5ecbfc2ed2f294ad72fd5ee800c08721','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c125a4b0cbf52a9719d650df689bfabbb8a9ff09ce1a58f53977325115aac4',2010,'SR','Suriname','military-and-security',1431,'Manpower fit for military service:
males age 16-49: 5,836,971
females age 16-49: 5,942,043 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 498,376
female: 479,005 (2009 est.)
Military expenditures:
3% of GDP (2005 est.)
Military branches: National Army
(Nationaal Leger, NL; includes Naval
Wing, Air Wing) (2007)
Military service age and obligation:
18 years of age (est.); recruitment is
voluntary, with personnel drawn almost
exclusively from the Creole community
(2007)
Manpower available for military
Service: males age 16-49: 130,534
females age 16-49: 130,243 (2008 est.)
Manpower fit for military service:
males age 16-49: 107,367
fefnales age 16-49: 111,000 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 4,251
female: 4,265 (2009 est.)
Military expenditures:
0.6% of GDP (2006 est.)
Military branches:
no regular military forces
Military — note: Svalbard is a territory
of Norway, demilitarized by treaty on 9
February 1920
Military branches: Umbutfo Swaziland
Defense Force (USDF): Ground Force
(includes air wing) (2008)
Military service age and obligation:
18-30 years of age for male and female
voluntary military service; no conscription
(2008)
Manpower available for military service:
males age 16-49: 266,311 (2008 est.)
Manpower fit for military service:
males age 16-49: 124,132
females age 16-49: 118,570 (2009 est.)
Manpower reaching militarily
significant age annually: male: 15,985
female: 15,754 (2009 est.)
Military expenditures:
4.7% of GDP (2006)','19c1b4b557e925d86e3d216a132e63e8903af51f58f9dcc2d85d5f9f422b70f8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4abb25cd85254c8e318aed6752c3f601c73007fbfc10cdf1057e8bd5634b85af',2010,'TJ','Tajikistan','military-and-security',1442,'Manpower reaching militarily
significant age annually: male: 165,738
female: 154,123 (2009 est.)
Military expenditures: 2 2% of GDP
(2006)
Military branches: Ground Forces, Air
and Air Defense Forces, Mobile Forces
(2008)
Military service age and obligation: 18
years of age for compulsory military service;
2-year conscript service obligation (2007)
Manpower available for military
service:
males age 16-49: 1,897,356
females age 16-49: 1,911,594 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,428,218
females age 16-49: 1,603,779 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 80,819
female: 78,460 (2009 est.)
Military expenditures: 3.9% of GDP
(2005 est.)
Military branches: Tanzanian People’s
Defense Force Qeshi la Wananchi la
Tanzania, JWTZ): Army, Naval Wing
(includes Coast Guard), Air Defense
Command (includes Air Wing), National
Service (2007)
Military service age and obligation: 18
years of age for voluntary military service
(2007)
Manpower available for military service:
males age 16-49: 9,108,177 (2008 est.)
Manpower fit for military service: males
age 16-49: 5,473,552
females age 16-49: 5,493,188 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 487,742
female: 489,462 (2009 est.)
Military expenditures: 0.2% of GDP
(2005 est.)','f228bbb7bc72bc5ebecdb99da7f17aa81d5782654bf1170bf3dc5d0bbab8d972','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29933a968a2e0b39b1c655424eaa4a760fd258232e5206038b313b3118b37685',2010,'TL','Timor-Leste','military-and-security',1448,'Military branches: Royal Thai Army
(Kongthap Bok Thai, RTA), Royal Thai
Navy (Kongthap Ruea Thai, RTN, includes
Royal Thai Marine Corps), Royal Thai Air
Force (Kongtap Agard Thai, RTAF) (2009)
Military service age and obligation:
21 years of age for compulsory military
service; 18 years of age for voluntary mili¬
tary service; males are registered at 1 8 years
of age; 2-year conscript service obligation
(2007)
Manpower available for military service:
males age 16-49: 17,553,410
females age 16-49: 17,751,268 (2008 est.)
Manpower fit for military service: males
age 16-49: 13,086,106
females age 16-49: 14,126,398 (2009 est.)
Manpower reaching militarily significant
age annually: mate. 532,977
female: 510,737 (2009 est.)
Military expenditures: 1.8% of GDP
(2005 est.)
Military branches: Timor-Leste Defense
Force (Forcas de Defesa de Timor-L’este,
Falintil (F-FDTL)): Army, Navy (Armada)
(2009)
Military service age and obligation: 18
years of age for voluntary military service;
no conscription (2008)
Manpower available for military service:
males age 1 6-49: 284,903
females age 16-49: 272,212 (2008 est.)
Manpower fit for military service:
males age 16-49: 230,534
females age 16-49: 238,610 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 12,887
female: 12,529 (2009 est.)
Military expenditures: NA','218d20161ccb3d4dc6b17aa5aa75643099a140bada3097ff97e49973f021fccb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214924479000b15332ba63e9297bb81420ab40121b9b52b105991d7485bca5ba',2010,'TK','Tokelau','military-and-security',1460,'Military branches: Togolese Armed
Forces (Forces Armees Togolaise, FAT):
Ground Forces, Togolese Navy (Marine du
Togo), Togolese Air Force (Force Aerienne
Togolaise, FAT), National Gendarmerie
(2009)
Military service age and obligation: 18
years of age for selective compulsory and
voluntary military service; 2-year service
obligation (2006)
Manpower available for military
service: males age 16-49: 1 ,365,505
females age 16-49: 1,374,993 (2008 est.)
Manpower fit for military service: males
age 16-49: 929,395
females age 16-49: 943,967 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 70,775
female: 70,051 (2009 est.)
Military expenditures: 1.6% of GDP
(2005 est.)','8ee203bd3ff71ef151f2bb77669f7e8cd2d84d3816f07cd7d47a2ad818404370','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e987c30e5e7578c93b972ec87b7807598b37b0a257fe5af001139e8abc3193c9',2010,'TO','Tonga','military-and-security',1471,'Military branches: Tonga Defense Serv¬
ices (TDS): Land Force (Royal Guard),
Naval Force (includes Royal Marines, Air
Wing) (2009)
Military service age and obligation: 18
years of age (est.); no conscription (2008)
Manpower available for military
service:
males age 16-49: 32,053
females age 16-49: 30,981 (2008 est.)
Manpower fit for military service:
males age 16-49: 26,471
females age 16-49: 27,715 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 1 ,458
female: 1 ,403 (2009 est.)
Military expenditures: 0.9% of GDP
(2006 est.)','8b59785a48529dddd6b31f2d53b06673f2d65242e708ebd98ec056bddaf479b2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('055ce82f36b79331d63a7f5afc73e9ba2e393597c61e74673c9a6e32ba575725',2010,'TN','Tunisia','military-and-security',1478,'Military branches: Army, Navy, Republic
of Tunisia Air Force (Al-Quwwat abjawwiya
abjamahiriyah At’tunisia) (2008)
Military service age and obligation: 20
years of age for compulsory military service,
1 8 years of age for voluntary military service;
1-year conscript service obligation (2007)
Manpower available for military
service: males age 1649: 2,992,249
females age 16-49: 2,912,819 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,569,403
females age 16-49: 2,489,651 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 100,478
female: 94,055 (2009 est.)
Military expenditures: 1.4% of GDP
(2006)
Military branches: Turkish Armed Forces
(TSK): Turkish Land Forces (Turk Kara
Kuwetleri), Turkish Naval Forces (Turk
Deniz Kuwetleri; includes naval air and
naval infantry), Turkish Air Force (Turk
Hava Kuwederi) (2009)
Military service age and obligation: 20
years of age (2004)
Manpower available for military service:
males age 16-49 : 20,213,205
females age 16-49: 19,432,688 (2008 est.)
Manpower fit for military service: males
age 16-49: 17,223,506
females age 16-49: 16,995,299 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 692,592
female: 663,689 (2009 est.)
Military expenditures: 5.3% of GDP
(2005 est.)
Military — note: a “National Security
Policy Document” adopted in October
2005 increases the Turkish Armed
Forces (TSK) role in internal security,
augmenting the General Directorate
of Security and Gendarmerie General
Command (Jandarma); the TSK leader¬
ship continues to play a key role in politics
and considers itself guardian of Turkey’s
secular state; in April 2007, it warned the
ruling party about any pro-Islamic appoint¬
ments; despite on-going negotiations
on EU accession since October 2005,
progress has been limited in establishing
required civilian supremacy over the mili¬
tary; primary domestic threats are listed
as fundamentalism (with the definition
in some dispute with the civilian govern¬
ment), separatism (the Kurdish problem),
and the extreme left wing; Ankara strongly
opposed establishment of an autonomous
Kurdish region; an overhaul of the Turkish
Land Forces Command (TLFC) taking
place under the “Force 2014” program is
to produce 20-30% smaller, more highly
trained forces characterized by greater
mobility and firepower and capable of joint
and combined operations; the TLFC has
taken on increasing international peace¬
keeping responsibilities, and took charge of
a NATO International Security Assistance
Force (ISAF) command in Afghanistan in
April 2007; the Turkish Navy is a regional
naval power that wants to develop the capa¬
bility to project power beyond Turkey’s
coastal waters; the Navy is heavily involved
in NATO, multinational, and UN opera¬
tions; its roles include control of territorial
waters and security for sea lines of commu¬
nications; the Turkish Air Force adopted an
“Aerospace and Missile Defense Concept”
in 2002 and has initiated project work on
an integrated missile defense system; Air
Force priorities include attaining a modern
deployable, survivable, and sustainable
force structure, and establishing a sustain¬
able command and control system (2008)','207b7cf86c1a6da8e946039454779e0205b92220176624863c97ea485a24bc4b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d57928448a3406ac3d80a5df0f8e502d7076367aa3b9156fab6dc3efd9311f31',2010,'TC','Turks and Caicos Islands','military-and-security',1486,'Military branches: Army, Navy, Air and
Air Defense Forces (2009)
Military service age and obligation:
18-30 years of age for compulsory military
service; 2-year conscript service obligation
(2007)
Manpower available for military service:
males age 16-49: 1,316,698
females age 16-49: 1,331,005 (2008 est.)
Manpower fit for military service: males
age 16-49: 1,024,884
females age 16-49: 1,147,714 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 57,021
female: 56,064 (2009 est.)
Military expenditures: 3.4% of GDP
(2005 est.)','ca4f1b4799a2aeee5f96a5838de94699037be4fd455e09c4cfffa8a54422648e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32eda2ef8436fe9a616b7814c4c27716a6b4bd278bce99f01422acbcb9d217a1',2010,'TV','Tuvalu','military-and-security',1495,'Manpower fit for military service:
males age 16-49: 4,937
females age 16-49: 4,648 (2009 est.)
Manpower reaching militarily
significant age annually: male: 226
female: 218 (2009 est.)
Military — note: defense is the responsi¬
bility of the UK
Military branches: no regular military
forces; Tuvalu Police Force (2008)
Manpower fit for military service: males
age 16-49: 2,462
females age 16-49: 2,631 (2009 est.)
Manpower reaching militarily
significant age annually: male: 125
female: 121 (2009 est.)
Military expenditures: NA','0ad10d11024bee5501755b76883fbe6e875c6ae8731fee4c3aa0ddc470fa0dcd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cf5da093474ece932858d7c978e7eb9a12ffe037993fe7204d9130b1be561d2',2010,'UG','Uganda','military-and-security',1506,'Military branches: Uganda Peoples
Defense Force (UPDF): Army (includes
Marine Unit), Air Force (2007)
Military service age and obligation:
18-26 years of age for compulsory and
voluntary military duty; 18-30 years of age
for professionals; 9-year service obligation;
the government has stated that recruitment
below 18 years of age could occur with
proper consent and that “no person under
the apparent age of 1 3 years shall be enrolled
in die armed forces”; Ugandan citizenship
and secondary education required (2008)
Manpower available for military
Service: males age 16-49: 6,532,894
females age 16-49: 6,352,416 (2008 est.)
Manpower fit for military service: males
age 16-49: 3,996,597
females age 16-49: 3,899,717 (2009 est.)
704','1dcdd735d2ba9dab0959061cb8df1d0b584ab2a5fbfc15b99d7e2b81b0d23ff6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3bb6c997309c5de98d1eb93e3d8250c0910b6a8ef140dc4b8d6e57235b3719e',2010,'UA','Ukraine','military-and-security',1507,'Manpower reaching militarily significant
age annually: male: 399,134
female: 395,505 (2009 est.)
Military expenditures: 2.2% of GDP
(2006)
Military branches: Ground Forces,
Naval Forces, Air and Air Defense Forces
(Viyskovo-Povitryani Syly, VPS) (2009)
708','599a5c06c577e17b2bde8c297a17a3f192cdaf16c2c4ba6547946d5369883351','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e64894b9ef6cb216f05ab3cb3aeb15985980289381bca6d821aae84a5685a64a',2010,'AE','United Arab Emirates','military-and-security',1514,'Military service age and obligation:
18-25 years of age for compulsory and
voluntary military service; conscript service
obligation— 1 8 months for Army and Air
Force, 24 months for Navy (2004)
Manpower available for military service:
males age 16-49: 11,457,562
females age 16-49: 11,767,357 (2008 est.)
Manpower fit for military service:
males age 16-49: 7,056,742
females age 16-49: 9,234,591 (2009 est.)
Manpower reaching militarily significant
age annually: male: 269,311
female: 257,656 (2009 est.)
Military expenditures: 1.4% of GDP
(2005 est.)
Military branches: United Arab Emir¬
ates Armed Forces: Army, Navy (includes
Marines), Air Force and Air Defense,
National Coast Guard (2008)
Military service age and obligation: 18
years of age (est.) for voluntary military
service; 18 years of age for officers and
women; no conscription (2008)
Manpower available for military service:
males age 16-49: 2,405,884 (includes non¬
nationals)
females age 16-49: 884,853 (2008 est.)
Manpower fit for military service:
males age 16-49: 2,081,491
females age 16-49: 788,632 (2009 est.)
Manpower reaching militarily significant
age annually: male: 26,659
female: 23,793 (2009 est.)
Military expenditures: 3.1% of GDP
(2005 est.)','369829b7669c9d22738a69394ccbab65687882a53089c153470f66c1e94fce89','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3907fbe165f5edc7cac5fe06f873e41345600317917bb2e5031207e829a10c2c',2010,'GB','United Kingdom','military-and-security',1530,'Military branches: Army, Royal Navy
(includes Royal Marines), Royal Air Force
(2009)
Military service age and obligation:
16-33 years of age (officers 17-28) for
voluntary military service (with parental
consent under 18); women serve in mili¬
tary services, but are excluded from ground
combat positions and some naval postings;
must be citizen of the UK, Commonwealth,
or Republic of Ireland; reservists serve a
minimum of 3 years, to age 45 or 55; 16
years of age for voluntary military service
by Nepalese citizens in the Brigade of the
Gurkhas; 16-34 years of age for voluntary
military service by Papua New Guinean citi¬
zens (2008)
Manpower available for military service:
rhales age 16-49: 14,729,500
females age 16-49: 14,125,600 (2008 est.)
Manpower fit for military service: males
age 16-49: 12,123,9 00
females age 16-49: 11,616,769 (2009 est.)
Manpower reaching militarily
significant age annually: male: 393,892
female: 376,351 (2009 est.)
Military expenditures: 2.4% of GDP
(2005 est.)','61be9960caaec3f0bd3492314487011b5f2d615f78b0de28091dc249ce6a3cef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21a87c73f17655735d377cd5cf5c7aa0d8788e96576d5eb905b59571bc2fca41',2010,'UY','Uruguay','military-and-security',1537,'Military — note: defense is the responsi¬
bility of the US
Military branches: Uruguayan Armed
Forces: Army (Ejercito), National Navy
(Armada Nacional; includes naval air
arm, Marine Corps (Cuerpo de Fusileros
Navales, FUSNA), Maritime Prefecture
in wartime), Air Force (Fuerza Aerea
Uruguaya, FAU) (2008)
Military service age and obligation: 18
years of age for voluntary and compulsory
military service; enlistment is voluntary
in peacetime, but the government has the
authority to conscript in emergencies (2007)
Manpower available for military
Service: males age 16-49: 837,252
females age 16-49: 824,096 (2008 est.)
Manpower fit for military service: males
age 16-49: 708,545
females age 16-49: 693,622 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 27,452
female: 26,479 (2009 est.)
Military expenditures: 1.6% of GDP
(2006)','4daa34b7d32db79deaad68ecb6f5147718b0e15c796d83e6fe5d7368bdadd203','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f249106c187719a93de400b7480d3f145c8191de396c6c9bdaf0b0d5b00b9b4f',2010,'UZ','Uzbekistan','military-and-security',1546,'Military branches: Army, Air and Air
Defense Forces, National Guard
Military service age and obligation:
18 years of age for compulsory military
service; 1-year conscript service obligation;
moving toward a professional military, but
conscription will continue; the military
cannot accommodate everyone who wishes
to enlist, and competition for entrance into
the military is similar to the competition
for admission to universities (2007)
Manpower available for military service:
males age 16-49: 7,480,484
females age 16-49: 7,542,017 (2008 est.)
Manpower fit for military service: males
age 16-49: 6,340,446
females age 16-49: 6,559,769 (2009 est.)
Manpower reaching militarily significant
age annually: male: 313,131
female: 310,442 (2009 est.)
Military expenditures: 2% of GDP (2005
est.)','b171f11c5a733985751fbca825a2e845fc341b3f35621874692cd87292465131','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8574d2c2a08a28c54a20fc1c7bffcdb7d5ad24c2c18e1f410441a7444b772df',2010,'VU','Vanuatu','military-and-security',1554,'Military branches: no regular military
forces; Vanuatu Police Force (VPF),
Vanuatu Mobile Force (VMF; includes
Police Maritime Wing (PMW)) (2009)
Manpower available for military service:
males age 16-49: 58,900 (2008 est.)
Manpower fit for military service:
males age 16-49: 41,533
females age 16-49: 42,837 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 2,368
female: 2,272 (2009 est.)
Military expenditures: NA
Military branches: National Bolivarian
Armed Forces (Fuerza Armada Nacional
Bolivariana, FANB): National Bolivarian
Army (Ejercito Nacional Bolivariano,
EHB), Bolivarian Navy (Fuerza Armada
Bolivariana (FAB); includes Naval Infantry,
Coast Guard, Naval Aviation), Bolivarian
National Military Aviation (Aviacion
Militar Nacional Bolivariana, AMNB),
Bolivarian National Guard (Guardia
Nacional Bolivaria, GNB) (2009)
Military service age and obligation: 18-
30 years of age for compulsory and volun¬
tary military service; 30-month conscript
service obligation; all citizens 18-50 years
old are obligated to register for military
service (2008)
Manpower available for military service:
males age 16-49: 6,647,124
females age 16-49: 6,801,133 (2008 est.)
Manpower fit for military service:
males age 16-49: 5,391,582
females age 16-49: 5,873,563 (2009 est.)
Manpower reaching militarily significant
age annually: male: 276,051
female: 274,162 (2009 est.)
Military expenditures: 1.2% of GDP
(2005 est.)
Military branches: People’s Armed
Forces: People’s Army of Vietnam (PAVN)
(includes People’s Navy Command (with
naval infantry, coast guard), Air and Air
Defense Force (Kon Quan Nhan Dan),
Border Defense Command), People’s
Public Security Forces, Militia Force, Self-
Defense Forces (2005)
Military service age and obligation: 18
years of age (male) for compulsory military
service; females may volunteer for active
duty military service; conscript service obli¬
gation— 2 years (3 to 4 years in the navy);
18-45 years of age (male) or 18-40 years
of age (female) for Militia Force or Self
Defense Forces (2006)
Manpower available for military service:
males age 16-49: 24,586,328
females age 16-49: 24,335,132 (2008 est.)
Manpower fit for military service: males
age 16-49: 19,190,676
females age 16-49: 20,768,508 (2009 est.)
Manpower reaching militarily significant
age annually: male: 893,726
female: 834,279 (2009 est.)
Military expenditures: 2.5% of GDP
(2005 est.)
Manpower fit for military service:
males age 16-49: 17,820
females age 16-49: 21,193 (2009 est.)
Manpower reaching militarily
significant age annually: male. 831
female: 873 (2009 est.)
Military — note: defense is the responsi¬
bility of the US
Military — note: defense is the respon¬
sibility of the US; the US Air Force is
responsible for overall administration and
operation of the island; the launch support
facility is administered by the US Missile
Defense Agency (MDA)','2281efee2a838aa93474556b84058d5b36895cfd84f036d492d924292e824139','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37d2dd92c0526a40fc28b3935dd36b7259b533285ac0be9e4aa16dcc5707cf27',2010,'EH','Western Sahara','military-and-security',1565,'Manpower fit for military service:
males age 16-49: 52,267
females age 16-49: 59,221 (2009 est.)
Manpower reaching militarily
significant age annually:
male: 4,796
female: 4,679 (2009 est.)
Military expenditures: roughly 2% of
GDP of gross world product (2005 est.)','b6ed3ed62eee8574e3e0685202e2d6a60d8f7da6c0cabfa5cdc9a40347b8c431','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0c320c4424574926242556898a10097629fc777da039109f1ded89fdf945e52',2010,'YE','Yemen','military-and-security',1573,'Military branches: Army (includes Repub¬
lican Guard), Navy (includes Marines),
Yemen Air Force (A1 Quwwat al Jawwiya
al Jamahiriya al Yemeniya; includes Air
Defense Force) (2009)
Military service age and obligation:
voluntary military service program autho¬
rized in 2001; 2-year service obligation
(2006)
Manpower available for military service:
males age 16-49: 5,080,038
females age 16-49: 4,852,555 (2008 est.)
Manpower fit for military service:
males age 16-49: 3,733,704
females age 16-49: 3,773,626 (2009 est.)
Manpower reaching militarily
significant age annually: male: 273,624
female: 263,402 (2009 est.)
Military expenditures:
6.6% of GDP (2006)
Military — note: a Coast Guard was
established in 2002','e33c362b1e78421fe90701eb208c1b6ae4a6013fe918e1e05e8c372ca61d136f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad13d09b6260d46e21422c861d6032cf4101cf4c96b05943f22cf8516bb0f6a9',2010,'ZM','Zambia','military-and-security',1581,'Military branches: Zambian National
Defense Force (ZNDF): Zambian Army,
Zambian Air Force, National Service (2009)
Military service age and obligation: 18
years of age for voluntary military service
(16 years of age with parental consent);
mandatory HIV testing on enlistment; no
conscription (2009)
Manpower available for military
service: males age 16-49: 2,678,668
females age 16-49: 2,567,433 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,364,173
females age 16-49: 1,245,220 (2009 est.)
Manpower reaching militarily
significant age annually: male. 149,567
female: 148,889 (2009 est.)
759
THE CIA WORLD FACTBOOK
Military expenditures: 1.8% of GDP
(2005 est.)','6bb8be2fff5504c49697007298427cecf9a1e476b93d86c200004570d85ad613','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e277270bb24e411c982304082ea9ffd505e4952c72d29b1f87ddaec449ab368f',2010,'ZW','Zimbabwe','military-and-security',1590,'Military branches: Zimbabwe Defense
Forces (ZDF): Zimbabwe National Army
(ZNA), Air Force of Zimbabwe (AFZ),
Zimbabwe Republic Police (ZRP) (2009)
Military service age and obligation: 18-
24 years of age for compulsory military
service; women are eligible to serve (2007)
Manpower available for military service:
males age 16*49: 3,264,258
females age 16-49: 3,048,049 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,198,727
females age 16-49: 1,436,232 (2009 est.)
Manpower reaching militarily
significant age annually: male: 149,592
female: 149,717 (2009 est.)
Military expenditures: 3.8% of GDP
(2006)','b93d940813a0109973e8e8a639c20d6bf99729c3da4402408f7893cd9755c01f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9840c6c560d846f911e02783f7f9c095c61ce1143615020736b6dd79604f0140',2010,'','','military-and-security',8,'Military branches:
Military service age and obligation:
Manpower available for military service:
males age 16-49
females age 16-49
Manpower fit for military service:
males age 16-49
females age 16-49
Manpower reaching military age annually:
males
females
Military expenditures - percent of GDP:
Military - note:','1a1bd2e5f9166652fa259b803d156fda0bc3382e0e1406d01d1b2a9876cb3524','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9751f0864dea08d9bc2924ed6a635ecdda5634f8191de769b140214c8cd578a0',2010,'ZW','Zimbabwe','military-and-security',14,'Military expenditures - percent of GDP:
Not all Country Comparisons include the same number of entries
because information for a particular field is not available for all
countries. In addition, not all data fields are suitable for
displaying as Country Comparisons, such as those containing textual
information. Textual information is more readily viewed by clicking
on the Field Listing icon next to the Data field title.
All of the Country Comparisons'' pages can be downloaded as
tab-delimited data files and can be opened in other applications
such as spreadsheets and databases. To save a Country Comparisons
page in a spreadsheet, first click on the ''Download Datafile'' choice
above the Country Comparisons page you selected; then, at the top of
your browser window, click on ''File'' and ''Save As''. After saving the
file, open the spreadsheet, find the saved file, and ''Open'' it.
======================================================================
Appendixes
Appendix A - Abbreviations
Appendix B - International Organizations and Groups
Appendix C - Selected International Environmental Agreements
Appendix D - Cross-Reference list of Country Data Codes
Appendix E - Cross-Reference List of Hydrographic Data Codes
Appendix F - Cross-Reference List of Geographic Names
Appendix G - Weights and Measures
======================================================================
References :: Definitions and Notes
A
Abbreviations
This information is included in Appendix A: Abbreviations, which
includes all abbreviations and acronyms used in the Factbook, with
their expansions.
Acronyms
An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up
solely from the first letter of the major words in the expanded form
is rendered in all capital letters (NATO from North Atlantic Treaty
Organization; an exception would be ASEAN for Association of
Southeast Asian Nations). In general, an acronym made up of more
than the first letter of the major words in the expanded form is
rendered with only an initial capital letter (Comsat from
Communications Satellite Corporation; an exception would be NAM from
Nonaligned Movement). Hybrid forms are sometimes used to distinguish
between initially identical terms (ICC for International Chamber of
Commerce and ICCt for International Criminal Court).
Administrative divisions
This entry generally gives the numbers, designatory terms, and
first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet
acted on by the BGN are noted.
Age structure
This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64
years, 65 years and over). The age structure of a population affects
a nation''s key socioeconomic issues. Countries with young
populations (high percentage under age 15) need to invest more in
schools, while countries with older populations (high percentage
ages 65 and over) need to invest more in the health sector. The age
structure can also be used to help predict potential political
issues. For example, the rapid growth of a young adult population
unable to find employment can lead to unrest.
Agriculture - products
This entry is an ordered listing of major crops and products
starting with the most important.
Airports
This entry gives the total number of airports or airfields
recognizable from the air. The runway(s) may be paved (concrete or
asphalt surfaces) or unpaved (grass, earth, sand, or gravel
surfaces) and may include closed or abandoned installations.
Airports or airfields that are no longer recognizable (overgrown, no
facilities, etc.) are not included. Note that not all airports have
accommodations for refueling, maintenance, or air traffic control.
Airports - with paved runways
This entry gives the total number of airports with paved runways
(concrete or asphalt surfaces) by length. For airports with more
than one runway, only the longest runway is included according to
the following five groups - (1) over 3,047 m (over 10,000 ft), (2)
2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000
to 8,000 ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5) under
914 m (under 3,000 ft). Only airports with usable runways are
included in this listing. Not all airports have facilities for
refueling, maintenance, or air traffic control. The type aircraft
capable of operating from a runway of a given length is dependent
upon a number of factors including elevation of the runway, runway
gradient, average maximum daily temperature at the airport, engine
types, flap settings, and take-off weight of the aircraft.
Airports - with unpaved runways
This entry gives the total number of airports with unpaved runways
(grass, dirt, sand, or gravel surfaces) by length. For airports with
more than one runway, only the longest runway is included according
to the following five groups - (1) over 3,047 m (over 10,000 ft),
(2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m
(5,000 to 8,000 ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5)
under 914 m (under 3,000 ft). Only airports with usable runways are
included in this listing. Not all airports have facilities for
refueling, maintenance, or air traffic control. The type aircraft
capable of operating from a runway of a given length is dependent
upon a number of factors including elevation of the runway, runway
gradient, average maximum daily temperature at the airport, engine
types, flap settings, and take-off weight of the aircraft.
Appendixes
This section includes Factbook-related material by topic.
Area
This entry includes three subfields. Total area is the sum of all
land and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of the
surfaces of all inland water bodies, such as lakes, reservoirs, or
rivers, as delimited by international boundaries and/or coastlines.
Area - comparative
This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of
the 50 states based on area measurements (1990 revised) provided by
the US Bureau of the Census. The smaller entities are compared with
Washington, DC (178 sq km, 69 sq mi) or The Mall in Washington, DC
(0.59 sq km, 0.23 sq mi, 146 acres).
B','c04f13b47bf9df9182b3da96f8714760cb80e008d1ba3176b6dfce650e4663e9','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c780e19027140823a69db5ff20f4d88dbc47e5775d2e748f6dd61dbfcf53b24',2010,'TC','Turks and Caicos Islands','military-and-security',26,'This category includes the entries dealing with a country''s military
structure, manpower, and expenditures.
Military - note
This entry includes miscellaneous military information of
significance not included elsewhere.
Military branches
This entry lists the service branches subordinate to defense
ministries or the equivalent (typically ground, naval, air, and
marine forces).
Military expenditures
This entry gives spending on defense programs for the most recent
year available as a percent of gross domestic product (GDP); the GDP
is calculated on an exchange rate basis, i.e., not in terms of
purchasing power parity (PPP).
Military service age and obligation
This entry gives the required ages for voluntary or conscript
military service and the length of service obligation.
Money figures
All money figures are expressed in contemporaneous US dollars unless
otherwise indicated.
N
National anthem
A generally patriotic musical composition - usually in the form of a
song or hymn of praise - that evokes and eulogizes the history,
traditions, or struggles of a nation or its people. National anthems
can be officially recognized as a national song by a country''s
constitution or by an enacted law, or simply by tradition. Although
most anthems contain lyrics, some do not.
National holiday
This entry gives the primary national day of celebration - usually
independence day.
Nationality
This entry provides the identifying terms for citizens - noun and
adjective.
Natural gas - consumption
This entry is the total natural gas consumed in cubic meters (cu m).
The discrepancy between the amount of natural gas produced and/or
imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
Natural gas - exports
This entry is the total natural gas exported in cubic meters (cu m).
Natural gas - imports
This entry is the total natural gas imported in cubic meters (cu m).
Natural gas - production
This entry is the total natural gas produced in cubic meters (cu m).
The discrepancy between the amount of natural gas produced and/or
imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
Natural gas - proved reserves
This entry is the stock of proved reserves of natural gas in cubic
meters (cu m). Proved reserves are those quantities of natural gas,
which, by analysis of geological and engineering data, can be
estimated with a high degree of confidence to be commercially
recoverable from a given date forward, from known reservoirs and
under current economic conditions.
Natural hazards
This entry lists potential natural disasters. For countries where
volcanic activity is common, a volcanism subfield highlights
historically active volcanoes.
Natural resources
This entry lists a country''s mineral, petroleum, hydropower, and
other resources of commercial importance, such as rare earth
elements (REEs).
Net migration rate
This entry includes the figure for the difference between the number
of persons entering and leaving a country during the year per 1,000
persons (based on midyear population). An excess of persons entering
the country is referred to as net immigration (e.g., 3.56
migrants/1,000 population); an excess of persons leaving the country
as net emigration (e.g., -9.26 migrants/1,000 population). The net
migration rate indicates the contribution of migration to the
overall level of population change. The net migration rate does not
distinguish between economic migrants, refugees, and other types of
migrants nor does it distinguish between lawful migrants and
undocumented migrants.
O
Oil - consumption
This entry is the total oil consumed in barrels per day (bbl/day).
The discrepancy between the amount of oil produced and/or imported
and the amount consumed and/or exported is due to the omission of
stock changes, refinery gains, and other complicating factors.
Oil - exports
This entry is the total oil exported in barrels per day (bbl/day),
including both crude oil and oil products.
Oil - imports
This entry is the total oil imported in barrels per day (bbl/day),
including both crude oil and oil products.
Oil - production
This entry is the total oil produced in barrels per day (bbl/day).
The discrepancy between the amount of oil produced and/or imported
and the amount consumed and/or exported is due to the omission of
stock changes, refinery gains, and other complicating factors.
Oil - proved reserves
This entry is the stock of proved reserves of crude oil in barrels
(bbl). Proved reserves are those quantities of petroleum which, by
analysis of geological and engineering data, can be estimated with a
high degree of confidence to be commercially recoverable from a
given date forward, from known reservoirs and under current economic
conditions.
P','e8837e02d0b65ac000e0125cd44d0c592e9a5585a8d9741be95a4ae272efbe53','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

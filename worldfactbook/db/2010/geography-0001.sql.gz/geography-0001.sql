SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6fd3ce469597ccae1daaea5c1b1e14289f349e549d0f5c63d105da4e1713d1d',2010,'US','United States','geography',126,'Location
Geographic coordinates
Map references
Area
total
land
water
Area— comparative
Land boundaries
total
border countries
Coastline
Maritime claims
territorial sea
contiguous zone
exclusive economic zone
exclusive fishing zone
Climate
Terrain
Elevation extremes
lowest point
highest point
Natural resources
Land use
arable land
permanent crops
other
Irrigated land
Total renewable water resources
Freshwater withdrawal (domestic/
industrial/agricultural)
total
per capita
Natural hazards
Environment— current issues
Environment— international
agreements
party to
signed, but not ratified
Geography— note
Location: North America, bordering both
the North Adantic Ocean and the North
Pacific Ocean, between Canada and Mexico
Geographic coordinates: 38 00 N, 97 00
W
Map references: North America
Area: total: 9,826,63 0 sq km
land: 9,161,923 sq km
water: 664,707 sq km
note: includes only the 50 states and
District of Columbia
Area — comparative: about half the size of
Russia; about three-tenths the size of Africa;
about half the size of South America (or
slightly larger than Brazil); slightly larger
than China; more than twice the size of the
European Union
Land boundaries: total: 12,034 km
border countries: Canada 8,893 km
(including 2,477 km with Alaska), Mexico
3,141 km
note: US Naval Base at Guantanamo Bay,
Cuba is leased by the US and is part of
Cuba; the base boundary is 28 km
Coastline: 19,924 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: mostly temperate, but tropical in
Hawaii and Florida, arctic in Alaska, semi-
arid in the great plains west of the Missis¬
sippi River, and arid in the Great Basin of
the southwest; low winter temperatures in
the northwest are ameliorated occasionally
in January and February by warm chinook
winds from the eastern slopes of the Rocky
Mountains
Terrain: vast central plain, mountains in
west, hills and low mountains in east; rugged
mountains and broad river valleys in Alaska;
rugged, volcanic topography in Hawaii
Elevation extremes: lowest point: Death
Valley -86 m
highest point: Mount McKinley 6,198 m
Natural resources: coal, copper, lead, molyb¬
denum, phosphates, uranium, bauxite, gold,
iron, mercury, nickel, potash, silver, tung¬
sten, zinc, petroleum, natural gas, timber
note: the US has the world’s largest coal
reserves with 491 billion short tons
accounting for 27% of the world’s total
Land use: arable land: 18.01%
permanent crops: 0.21%
other: 81.78% (2005)
Irrigated land: 223,850 sq km (2003)
Total renewable water resources: 3,069
cu km (1 985)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 477 cu km/
yr ( 1 3%/ 46%/ 41%)
per capita: 1,600 cu m/yr (2000)
Natural hazards: tsunamis; volcanoes;
earthquake activity around Pacific Basin;
hurricanes along the Atlantic and Gulf of
Mexico coasts; tornadoes in the midwest
and southeast; mud slides in California;
forest fires in the west; flooding; perma¬
frost in northern Alaska, a major impedi¬
ment to development
Environment — current issues: air pollu¬
tion resulting in acid rain in both the US
and Canada; the US is the largest single
emitter of carbon dioxide from the burning
of fossil fuels; water pollution from runoff
of pesticides and fertilizers; limited natural
fresh water resources in much of the
western part of the country require careful
management; desertification
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Antarctic-Environ¬
mental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic
Treaty, Climate Change, Desertification,
Endangered Species, Environmental Modi¬
fication, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wedands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air Pollution-
Volatile Organic Compounds, Biodiversity,
Climate Change-Kyoto Protocol, Hazardous
Wastes
Geography — note: world’s third-largest
country by size (after Russia and Canada)
and by population (after China and India);
Mt. McKinley is highest point in North
America and Death Valley die lowest point
on the continent
Location: Oceania
Baker Island: atoll in the North Pacific
Ocean 1,830 nm (3,389 km) southwest of
Honolulu, about half way between Hawaii
and Australia
Howland Island: island in the North Pacific
Ocean 1,815 nm (3,361 km) southwest of
Honolulu, about half way between Hawaii
and Australia
Jarvis Island: island in the South Pacific
Ocean 1,305 nm (2,417 km) south of
Honolulu, about half way between Hawaii
and Cook Islands
Johnston Atoll: atoll in the North Pacific
Ocean 717 nm (1,328 km) soudiwest of
Honolulu, about one-third of the way from
Hawaii to the Marshall Islands
Kingman Reef: reef in the North Pacific
Ocean 930 nm (1,722 km) south of Hono¬
lulu, about half way between Hawaii and','98e42b05919b2a78d813b02268466df80ad407d4e809186861da424ec4bea8bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f209f725d0d323f633c94452693ea539e865ef7952c3cb5d3260f6e6daa5ea',2010,'TJ','Tajikistan','geography',134,'Location: Southern Asia, north and west
of Pakistan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area: total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area— comparative:
slighdy smaller than Texas
Land boundaries: total: 5,529 km
border countries: China 76 km, Iran 936 km,
Pakistan 2,430 km, Tajikistan 1,206 km,
Turkmenistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: arid to semiarid; cold winters and
hot summers
Terrain: mosdy rugged mountains; plains
in north and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum,
coal, copper, chromite, talc, barites, sulfur,
lead, zinc, iron ore, salt, precious and semi¬
precious stones
Land use: arable land: 12.13%
permanent crops: 0.21%
other: 87.66% (2005)
Irrigated land: 27,200 sq km (2003)
Total renewable water resources:
65 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 23.26 cu
km/yr (2%/0%/98%)
per capita: 779 cu m/yr (2000)
Natural hazards: damaging earthquakes
occur in Hindu Kush mountains; flooding;
droughts
Environment— current issues: limited
natural fresh water resources; inadequate
supplies of potable water; soil degradation;
overgrazing; deforestation (much of the
remaining forests are being cut down for
fuel and building materials); desertification;
air and water pollution
Environment— international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Envi¬
ronmental Modification, Marine Dumping,
Ozone Layer Protection
signed, but not ratified: Hazardous Wastes,
Law of the Sea, Marine Life Conservation
Geography — note: landlocked; the Hindu
Kush mountains that run northeast to
southwest divide the northern provinces
from the rest of the country; the highest
peaks are in the northern Vakhan (Wakhan
Corridor)
Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Asia
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area— comparative: slightly smaller than
Wisconsin
Land boundaries: total: 3,651 km
border countries: Afghanistan 1,206 km,
China 414 km, Kyrgyzstan 870 km,
Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot
summers, mild winters; semiarid to polar
in Pamir Mountains
Terrain: Pamir and Alay Mountains domi¬
nate landscape; western Fergana Valley in
north, Kofarnihon and Vakhsh Valleys in
southwest
Elevation extremes: lowest point: Syr
Darya (Sirdaryo) 300 m
highest point: Qullai Ismoili Somoni 7,495 m
Natural resources: hydropower, some petro¬
leum, uranium, mercury, brown coal, lead,
zinc, antimony, tungsten, silver, gold
Land use: arable land: 6.52%
permanent crops: 0.89%
other: 92.59% (2005)
Irrigated land: 7,220 sq km (2003)
Total renewable water resources: 99.7 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total : 11.96 cu km/yr
(4%/5%/92%)
per capita: 1,837 cu m/yr (2000)
Natural hazards: earthquakes; floods
Environment— current issues: inadequate
sanitation facilities; increasing levels of soil
salinity; industrial pollution; excessive
pesticides
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Environmental Modification, Ozone
Layer Protection, Wetlands
signed , but not ratified: none of the selected
agreements
Geography— note: landlocked; moun¬
tainous region dominated by the Trans-
Alay Range in the north and the Pamirs in
the southeast; highest point, Qullai Ismoili
Somoni (formerly Communism Peak), was
the tallest mountain in the former USSR
Location: Eastern Africa, bordering the
Indian Ocean, between Kenya and Mozam¬
bique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,087 sq km
land: 886,037 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba,
and Zanzibar
Area— comparative: slightly larger than
twice the size of California
Land boundaries:
total: 3,861 km
border countries: Burundi 451 km, Demo¬
cratic Republic of the Congo 459 km,
Kenya 769 km, Malawi 475 km, Mozam¬
bique 756 km, Rwanda 217 km, Uganda
396 km, Zambia 338 km
Coastline: 1,424 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau;
highlands in north, south
666
TANZANIA
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower, tin,
phosphates, iron ore, coal, diamonds,
gemstones, gold, natural gas, nickel
Land use:
arable land: 4.23%
permanent crops: 1 . 1 6%
other: 94.61% (2005)
Irrigated land: 1,840 sq km (2003)
Total renewable water resources: 91 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 5.18 cu km/yr
(10%/0%/89%)
per capita: 135 cu m/yr (2000)
Natural hazards: flooding on the central
plateau during the rainy season; drought
Environment — current Issues: soil
degradation; deforestation; desertification;
destruction of coral reefs threatens marine
habitats; recent droughts affected marginal
agriculture; wildlife threatened by illegal
hunting and trade, especially for ivory
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: Kilimanjaro is highest
point in Africa; bordered by three of
the largest lakes on the continent: Lake
Victoria (the world’s second-largest fresh''
water lake) in the north, Lake Tanganyika
(the world’s second deepest) in the west,
and Lake Nyasa in the southwest','abb888cdecae4aaaac3f21977e12de683d9e0bed391d6b6fbda2c6433ae9f257','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7c30dcaaa08d9ec945045b82ed8c1bb68d40b3b41068da8b372ec43fc18af9',2010,'AF','Afghanistan','geography',143,'Location: Eastern Mediterranean, peninsula
on the southwest coast of Cyprus
Geographic coordinates: 34 37 N, 32 58 E
Map references: Middle East
Area: total: 123 sq km
note: includes a salt lake and wetlands
Area — comparative: about 0.7 times the
size of Washington, DC
Land boundaries: total: 47.4 km
border countries: Cyprus 47.4 km
Coastline: 56.3 km
Climate: temperate; Mediterranean with
hot, dry summers and cool winters
Environment — current issues: hunting
around the salt lake; note— breeding place
for loggerhead and green turtles; only
remaining colony of griffon vultures is on
the base
Geography — note: British extraterritorial
rights also extended to several small
off-post sites scattered across Cyprus; of the
Sovereign Base Area (SBA) land, 60% is
privately owned and farmed, 20% is owned
by the Ministry of Defense, and 20% is
SBA Crown land','d1f771313d293a526146de521259bf8812fcaf84dd411ab7d12cf0dd68858bef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2324ce581d803a2386f7fb041c13eebc8fd1f7a2ac2c92b3fee942f263d67fb9',2010,'AL','Albania','geography',145,'Location: Southeastern Europe; bordering
the Adriatic Sea and Ionian Sea, between
Greece in the south and Montenegro and
Kosovo to the north
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Area: total: 28,748 sq km
land: 27,398 sq km
water: 1 ,350 sq km
Area— comparative:
slightly smaller than Maryland
Land boundaries: total: 717 km
border countries: Greece 282 km,
Macedonia 151 km, Montenegro 172 km,
Kosovo 112 km
Coastline: 362 km
Maritime claims: territorial sea: 12 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: mild temperate; cool, cloudy, wet
winters; hot, clear, dry summers; interior is
cooler and wetter
Terrain: mostly mountains and hills; small
plains along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem
Korab) 2,764 m
Natural resources: petroleum, natural gas,
coal, bauxite, chromite, copper, iron ore,
nickel, salt, timber, hydropower
Land use: arable land: 20.1%
permanent crops: 4.21%
other: 75.69% (2005)
Irrigated land: 3,530 sq km (2003)
Total renewable water resources: 41.7 cu
km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.71 cu
km/yr (27%/l l%/62%)
per capita: 546 cu m/yr (2000)
Natural hazards: destructive earthquakes;
tsunamis occur along southwestern coast;
floods; drought
Environment — current issues: deforesta¬
tion; soil erosion; water pollution from
industrial and domestic effluents
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate ,
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location along
Strait of Otranto (links Adriatic Sea to
Ionian Sea and Mediterranean Sea)
Location: Southeastern Europe, between
the Adriatic Sea and Serbia
Geographic coordinates: 42 30 N, 19 18
E
Map references: Europe
Area: total: 14,026 sq km
land: 13,812 sq km
water: 214 sq km
Area — comparative: shghdy smaller than
Connecticut
Land boundaries: total: 625 km
border countries: Albania 172 km, Bosnia
and Herzegovina 225 km, Croatia 25 km,
Kosovo 79 km, Serbia 124 km
Coastline: 293.5 km
Maritime Claims: territorial sea: 12 nm
continental shelf: defined by treaty
Climate: Mediterranean climate, hot dry
summers and autumns and relatively cold
winters with heavy snowfalls inland
Terrain: highly indented coasdine with
narrow coastal plain backed by rugged high
limestone mountains and plateaus
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Bobotov Kuk 2,522 m
Natural resources: bauxite, hydroelec-
tricity
Land use: arable land: 13.7%
permanent crops: 1%
other: 85.3%
Irrigated land: NA
Natural hazards: destructive earthquakes
Environment — current issues: pollution
of coastal waters from sewage outlets, espe-
dally in tourist-related areas such as Kotor
Environment — international agree¬
ments: party to: Air Pollution, Biodi¬
versity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location along
the Adriatic coast','f6de58f0415209d936160b538cc0afdf7531cf44501b6c0acda95eca6700e481','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69becd10b63b1fa0a8cae68fac0196142700f789fdeeab8c436975d81984a614',2010,'DZ','Algeria','geography',155,'Location: Northern Africa, bordering the
Mediterranean Sea, between Morocco and
Geographic coordinates: 17 00 N,
4 00 W
Map references: Africa
Area: total: 1.24 million sq km
land: 1.22 million sq km
water: 20,000 sq km
Area — comparative: slightly less than
twice die size of Texas
Land boundaries: total. 7,243 km
border countries: Algeria 1,376 km, Burkina
Faso 1,000 km, Guinea 858 km, Cote
d’Ivoire 532 km, Mauritania 2,237 km,
Niger 821 km, Senegal 419 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: subtropical to arid; hot and dry
(February to June); rainy, humid, and
mild (June to November); cool and dry
(November to February)
Terrain: mosdy flat to rolling northern
plains covered by sand; savanna in south,
rugged hills in northeast
Elevation extremes:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155 m
Natural resources: gold, phosphates,
kaolin, salt, limestone, uranium, gypsum,
granite, hydropower
note: bauxite, iron ore, manganese, tin, and
copper deposits are known but not exploited
Land use: arable land: 3.76%
permanent crops: 0.03%
other: 96.21% (2005)
Irrigated land: 2,360 sq km (2003)
Total renewable water resources: 100 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 6.55 cu km/yr
(9%/l%/90%)
per capita: 484 cu m/yr (2000)
Natural hazards: hot, dust-laden harmattan
haze common during dry seasons; recurring
droughts; occasional Niger River flooding
Environment — current issues: deforesta¬
tion; soil erosion; desertification; inade¬
quate supplies of potable water; poaching
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; divided
into three natural zones: the southern,
cultivated Sudanese; the central, semiarid
Sahelian; and the northern, arid Saharan
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area: total: 1.267 million sq km
land: 1,266,7 00 sq km
water: 300 sq km
Area — comparative: slighdy less than
twice the size of Texas
Land boundaries: total: 5,697 km
border countries: Algeria 956 km, Benin
266 km, Burkina Faso 628 km, Chad
1,175 km, Libya 354 km, Mali 821 km,
Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty;
tropical in extreme south
Terrain: predominately desert plains and
sand dunes; flat to rolling plains in south;
hills in north
Elevation extremes: lowest point: Niger
River 200 m
highest point : Mont Bagzane 2,022 m
Natural resources: uranium, coal, iron
ore, tin, phosphates, gold, molybdenum,
gypsum, salt, petroleum
Land use: arable land: 11.43%
permanent crops: 0.01%
other: 88.56% (2005)
Irrigated land: 730 sq km (2003)
Total renewable water resources:
33.7 cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.18
cu km/yr (4%/0%/95%)
per capita: 156 cu m/yr (2000)
Natural hazards: recurring droughts
Environment— current issues: over-
grazing; soil erosion; deforestation; deserti¬
fication; wildlife populations (such as
elephant, hippopotamus, giraffe, and lion)
threatened because of poaching and habitat
destruction
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Ozone Layer Protection, Wedands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; one of the
hottest countries in the world; northern
four-fifths is desert, southern one-fifth is
savanna, suitable for livestock and limited
agriculture','dcc2543dbe322d5327e8d7667314e69aa67d819b8724c15a252ac0570e607ac1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('231127a59693915dfa2d33aad9f327c778bd2e4442f8cbd0f6a7e32995742cd1',2010,'TN','Tunisia','geography',156,'Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area: total: 2,381,740 sq km
land: 2,381,740 sq km
water: 0 sq km
Area— comparative: slighdy less than 3.5
times the size of Texas
Land boundaries: total: 6,343 km
border countries: Libya 982 km, Mali 1,376
km, Mauritania 463 km, Morocco 1,559
km, Niger 956 km, Tunisia 965 km,
Western Sahara 42 km
9
THE CIA WORLD FACTBOOK
Coastline: 998 km
Maritime Claims: territorial sea: 12 nm
exclusive fishing zone: 32-52 nm
Climate: arid to semiarid; mild, wet winters
with hot, dry summers along coast; drier
with cold winters and hot summers on
high plateau; sirocco is a hot, dust/ sand-
laden wind especially common in summer
Terrain: mostly high plateau and desert;
some mountains; narrow, discontinuous
coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas,
iron ore, phosphates, uranium, lead, zinc
Land use: arable land: 3.17%
permanent crops: 0.28%
other: 96.55% (2005)
Irrigated land: 5,690 sq km (2003)
Total renewable water resources:
14.3 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 6.07 cu
km/yr (22%/l 3%/65%)
per capita: 185 cu m/yr (2000)
Natural hazards: mountainous areas
subject to severe earthquakes; mudslides
and floods in rainy season
Environment — current issues: soil
erosion from overgrazing and other poor
farming practices; desertification; dumping
of raw sewage, petroleum refining wastes,
and other industrial effluents is leading to
the pollution of rivers and coastal waters;
Mediterranean Sea, in particular, becoming
polluted from oil wastes, soil erosion, and
fertilizer runoff; inadequate supplies of
potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Envi-
ronmental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: second-largest country
in Africa (after Sudan)
Geographic coordinates: 25 00 N, 1 7 00 E
Map references: Africa
Area: total: 1,759,540 sq km
land: 1,759,540 sq km
water: 0 sq km
Area — comparative: slightly larger than
Alaska
Land boundaries: total: 4,348 km
border countries: Algeria 982 km, Chad
1,055 km, Egypt 1,115 km, Niger 354 km,
Sudan 383 km, Tunisia 459 km
Coastline: 1,770 km
Maritime claims: territorial sea: 12 nm
note: Gulf of Sidra closing line— 32 degrees,
30 minutes north
exclusive fishing zone: 62 nm
Climate: Mediterranean along coast; dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas,
gypsum
Land use: arable land: 1 .03%
permanent crops: 0.1 9%
other: 98.78% (2005)
Irrigated land: 4,700 sq km (2003)
Total renewable water resources: 0.6 cu
km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 4.27 cu
km/yr (14%/3%/83%)
per capita: 730 cu m/yr (2000)
Natural hazards: hot, dry, dust-laden
ghibli is a southern wind lasting one to
four days in spring and fall; dust storms,
sandstorms
Environment — current issues: desertifica¬
tion; limited natural fresh water resources;
the Great Manmade River Project, the
largest water development scheme in the
world, is being built to bring water from
large aquifers under the Sahara to coastal
cities
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: more than 90% of the
country is desert or semidesert
Location: Northern Africa, bordering the
Mediterranean Sea, between Algeria and
Location: Southeastern Europe and South¬
western Asia (that portion of Turkey west
of the Bosporus is geographically part of
Europe), bordering the Black Sea, between
Bulgaria and Georgia, and bordering the
Aegean Sea and the Mediterranean Sea,
between Greece and Syria
Geographic coordinates:
39 00 N, 35 00 E
Map references: Middle East
Area: total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
Area— comparative: slightly larger than
Texas
Land boundaries: total 2,648 km
border countries: Armenia 268 km, Azerba¬
ijan 9 km, Bulgaria 240 km, Georgia 252
km, Greece 206 km, Iran 499 km, Iraq
352 km, Syria 822 km
Coastline: 7,200 km
Maritime claims: territorial sea: 6 nm in
the Aegean Sea; 12 nm in Black Sea and
in Mediterranean Sea
exclusive economic zone: in Black Sea only:
to the maritime boundary agreed upon
with the former USSR
Climate: temperate; hot, dry summers with
mild, wet winters; harsher in interior
Terrain: high central plateau (Anatolia);
narrow coastal plain; several mountain
ranges
Elevation extremes: lowest point:
Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: coal, iron ore, copper,
chromium, antimony, mercury, gold,
barite, borate, celestite (strontium), emery,
feldspar, limestone, magnesite, marble,
690
TURKEY
perlite, pumice, pyrites (sulfur), clay, arable
land, hydropower
Land use: arable land: 29.81%
permanent crops: 3.39%
other: 66.8% (2005)
Irrigated land: 52,150 sq km (2003)
Total renewable water resources: 234 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 39.78 cu
km/yr (1 5%/l 1 %/74%)
per capita: 544 cu m/yr (2001)
Natural hazards: severe earthquakes,
especially in northern Turkey, along an
arc extending from the Sea of Marmara to
Lake Van
Environment — current issues: water pollu¬
tion from dumping of chemicals and deter¬
gents; air pollution, particularly in urban
areas; deforestation; concern for oil spills
from increasing Bosporus ship traffic
Environment— international agree¬
ments: party to: Air Pollution, Antarctic
Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protec¬
tion, Ship Pollution, Wedands
signed, but not ratified: Environmental
Modification
Geography — note: strategic location
controlling the Turkish Straits (Bosporus,
Sea of Marmara, Dardanelles) that link
Black and Aegean Seas; Mount Ararat, the
legendary landing place of Noah’s ark, is in
the far eastern portion of the country','98fced28530f0432d78897756102bd7f95fecc3f15e1287d4b6c7e8eaa289fbd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8238e67d29e9e353e8cdf8f775dec8b3a5d21635e2321dee21f69da404031847',2010,'AS','American Samoa','geography',163,'Location: Oceania, group of islands in
the South Pacific Ocean, about half way
between Hawaii and New Zealand
Geographiccoordinates: 1 4 20S, 1 7000 W
Map references: Oceania
Area:
total: 199 sq km
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains
Island
Area — comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine, moderated by
southeast trade winds; annual rainfall aver¬
ages about 3 m; rainy season (November to
April), dry season (May to October); little
seasonal temperature variation
Terrain: five volcanic islands with rugged
peaks and limited coastal plains, two coral
atolls (Rose Island, Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata Mountain 964 m
Natural resources: pumice, pumicite
Land use:
arable land: 10%
permanent crops: 15%
other: 75% (2005)
Irrigated land: NA
Natural hazards: typhoons common from
December to March
Environment-current issues: limited
natural fresh water resources; the water
division of the government has spent
substantial funds in the past few years to
improve water catchments and pipelines
Geography — note: Pago Pago has one of
the best natural deepwater harbors in the
South Pacific Ocean, sheltered by shape
from rough seas and protected by periph¬
eral mountains from high winds; strategic
location in the South Pacific Ocean
Midway Islands: atoll in the North Pacific
Ocean 1,260 nm (2,334 km) northwest of
Honolulu near the end of the Hawaiian
Archipelago, about one-third of the way
from Honolulu to Tokyo
Palmyra Atoll: atoll in the North Pacific
Ocean 960 nm (1,778 km) south of Hono¬
lulu, about half way between Hawaii and
Geographic coordinates: Baker Island: 0
13 N, 176 28 W
Howland Island: 0 48 N, 176 38 W
Jarvis Island: 0 23 S, 160 01 W
Johnston Atoll: 16 45 N, 169 31 W
Kingman Reef: 6 23 N, 162 25 W
Midway Islands: 28 12 N, 177 22 W
Palmyra Atoll: 5 53 N, 162 05 W
Map references: Oceania
Area: total— 6,959.41 sq km; emergent
land— 22.41 sq km; submerged— 6,937 sqkm
Baker Island: total— 129.1 sq km; emergent
land— 2.1 sq km; submerged— 127 sq km
Howland Island: total— 138.6 sq km; emer¬
gent land— 2.6 sq km; submerged— 1 36 sq
km
Jarvis Island: total— 152 sq km; emergent
land— 5 sq km; submerged— 147 sq km
Johnston Atoll: total— 276.6 sq km; emergent
land— 2.6 sq km; submerged— 274 sq km
Kingman Reef: total— 1 ,958.01 sq km; emer¬
gent land— 0.01 sq km; submerged— 1 ,958
sq km
Midway Islands: total— 2,355.2 sq km;
emergent land— 6.2 sq km; submerged—
2,349 sq km
Palmyra Atoll: total— 1 ,949.9 sq km; emer¬
gent land— 3.9 sq km; submerged— 1 ,946
sq km
Area — comparative: Baker Island: about
two and a half times the size of The
Mall in Washington, DC
Howland Island: about three times the size
of The Mall in Washington, DC
Jarvis Island: about eight times the size of
The Mall in Washington, DC
Johnston Atoll: about four and a half times
the size of The Mall in Washington, DC
Kingman Reef: a little more than one and
a half times the size of The Mall in Wash¬
ington, DC
Midway Islands: about nine times the size
of The Mall in Washington, DC
Palmyra Atoll: about 20 times the size of
The Mall in Washington, DC
Land boundaries: none
Coastline: Baker Island: 4.8 km
Howland Island: 6.4 km
Jarvis Island: 8 km
Johnston Atoll: 34 km
Kingman Reef: 3 km
Midway Islands: 15 km
Palmyra Atoll: 14.5 km
Maritime Claims: territorial sea; 12 nm
exclusive economic zone: 200 nm
Climate: Baker, Howland, and Jarvis
Islands: equatorial; scant rainfall, constant
wind, burning sun
Johnston Atoll and Kingman Reef: tropical,
but generally dry; consistent northeast
trade winds with little seasonal tempera¬
ture variation
Midway Islands: subtropical with cool,
moist winters (December to February) and
warm, dry summers (May to October);
moderated by prevailing easterly winds;
most of the 1,067 mm (42 in) of annual
rainfall occurs during the winter
Palmyra Atoll: equatorial, hot; located within
the low pressure area of the Intertropical
Convergence Zone (ITCZ) where the north¬
east and southeast trade winds meet, it is
extremely wet with between 4,000-5,000
mm (160-200 in) of rainfall each year
Terrain: low and nearly level sandy coral
islands with narrow fringing reefs that have
developed at the top of submerged volcanic
mountains, which in most cases rise steeply
from the ocean floor
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Baker Island, unnamed loca¬
tion— 8 m; Howland Island, unnamed
location— 3 m; Jarvis Island, unnamed loca¬
tion— 7 m; Johnston Atoll, Sand Island— 10
m; Kingman Reef, unnamed location— less
than 2 m; Midway Islands, unnamed
location— 13 m; Palmyra Atoll, unnamed
location— 3 m
Natural resources: terrestrial and aquatic
wildlife
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2008)
Natural hazards: Baker, Howland, and
Jarvis Islands: the narrow fringing reef
surrounding the island can be a maritime
hazard
Kingman Reef: wet or awash most of the time,
maximum elevation of less than 2 m makes
Kingman Reef a maritime hazard
Midway Islands, Johnston, and Palmyra
Atolls: NA
Environment — current issues: Baker,
Howland, and Jarvis Islands, and Johnston
Atoll: no natural fresh water resources
Kingman Reef: none
Midway Islands and Palmyra Atoll: NA
Geography— note: Baker, Howland,
and Jarvis Islands: scattered vegetation
consisting of grasses, prostrate vines, and
low growing shrubs; primarily a nesting,
roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife; closed to
the public
Johnston Atoll: Johnston Island and Sand
Island are natural islands, which have
been expanded by coral dredging; North
Island (Akau) and East Island (Hikina)
are manmade islands formed from coral
dredging; the egg-shaped reef is 34 km in
circumference; closed to the public
Kingman Reef: barren coral atoll with deep
interior lagoon; closed to die public
Midway Islands: a coral atoll managed as
a national wildlife refuge and open to the
722','1ceb8e848dec74d5a2f307bc368070056e454d04a10da5bc52901e1fb31d0a3a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('164658c54d92dac7ec9ca965bbb38cfad8fc708d29298e311645c2275c680a8d',2010,'AD','Andorra','geography',171,'Location: Southwestern Europe, between
France and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area: total: 468 sq km
land: 468 sq km
water: 0 sq km
Area— comparative:
2.5 times the size of Washington, DC
Land boundaries: total 120.3 km
border countries: France 56.6 km, Spain
63.7 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; snowy, cold winters
and warm, dry summers
Terrain: rugged mountains dissected by
narrow valleys
Elevation extremes: lowest point: Riu
Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral
water, timber, iron ore, lead
Land use: arable land: 2.13%
permanent crops: 0%
Other: 97.87% (2005)
Irrigated land: NA
Natural hazards: avalanches
Environment — current issues: deforesta¬
tion; overgrazing of mountain meadows
contributes to soil erosion; air pollution;
wastewater treatment and solid waste
disposal
Environment— international agreements:
party to: Biodiversity, Desertification,
Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; straddles
a number of important crossroads in the
Pyrenees','b479f15d65921ec54a69cfb6977c7ec6ecb9fa6e3b527ee3cc8ca95bbff133ef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef283ac0be507c5c2d5dd856ea6d6afccae823b1e1c4d0c905e7be2bf6bcd99',2010,'AO','Angola','geography',177,'Location: Southern Africa, bordering the
South Atlantic Ocean, between Namibia
and Democratic Republic of the Congo
Geographic coordinates:
12 30 S, 18 30 E
Map references: Africa
Area: total: 1,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area — comparative: slightly less than
twice the size of Texas
Land boundaries: total: 5,198 km
border countries: Democratic Republic of
the Congo 2,511 km (of which 225 km
is the boundary of discontiguous Cabinda
Province), Republic of the Congo 201 km,
Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Radios: 16,000(1997)
Television broadcast stations: 1 (2007)
Televisions: 27,000 (1997)
Internet country code: ad
Internet hosts: 23,368 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 58,900 (2007)
Geographic coordinates:
0 00 N, 25 00 E
Map references: Africa
Area: total: 2,345,410 sq km
land: 2,267,600 sq km
water: 77,810 sq km
Area — comparative: slightly less than
one-fourth the size of the US
Land boundaries: total: 10,730 km
border countries: Angola 2,511 km (of
which 225 km is the boundary of Angola’s
discontiguous Cabinda Province), Burundi
233 km, Central African Republic 1,577
km, Republic of the Congo 2,410 km,
Rwanda 217 km, Sudan 628 km, Tanzania
459 km, Uganda 765 km, Zambia 1,930
km
Coastline: 37 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: boundaries with
neighbors
Climate: tropical; hot and humid in
equatorial river basin; cooler and drier
in southern highlands; cooler and wetter
in eastern highlands; north of Equator-
wet season (April to October), dry season
(December to February); south of Equator-
wet season (November to March), dry
season (April to October)
Terrain: vast central basin is a low-lying
plateau; mountains in east
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Pic Marguerite on Mont
Ngaliema (Mount Stanley) 5,1 10 m
Natural resources: cobalt, copper,
niobium, tantalum, petroleum, industrial
and gem diamonds, gold, silver, zinc,
manganese, tin, uranium, coal, hydro¬
power, timber
Land use: arable land: 2.86%
permanent crops: 0.47%
other: 96.67% (2005)
157
THE CIA WORLD FACTBOOK
Irrigated land: 110 sq km (2003)
Total renewable water resources: l ,283
cu km (2001)
Freshwater withdrawal (domestic/
Industrial/agricultural): total: 0.36 cu
km/yr (53%/l 7%/31%)
per capita: 6 cu m/yr (2000)
Natural hazards: periodic droughts in
south; Congo River floods (seasonal); in
the east, in the Great Rift Valley, there are
active volcanoes
Environment — current issues: poaching
threatens wildlife populations; water pollu¬
tion; deforestation; refugees responsible
for significant deforestation, soil erosion,
and wildlife poaching; mining of minerals
(coltan— a mineral used in creating capaci¬
tors, diamonds, and gold) causing environ¬
mental damage
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental
Modification
Geography — note: straddles equator; has
narrow strip of land that controls the lower
Congo River and is only outlet to South
Adantic Ocean; dense tropical rain forest in
central river basin and eastern highlands
Location: Western Africa, bordering the
South Atlantic Ocean, between Angola
and Gabon
Geographic coordinates: 1 00 S, 1 5 00 E
Map references: Africa
Area: total: 342,000 sq km
land: 341,500 sq km
water: 500 sq km
Area — comparative: slightly smaller than
Montana
Land boundaries: total: 5,504 km
border countries: Angola 201 km, Cameroon
523 km, Central African Republic 467 km,
Democratic Republic of the Congo 2,410
km, Gabon 1 ,903 km
Coastline: 169 km
Maritime Claims: territorial sea: 200 nm
Climate: tropical; rainy season (March to
June); dry season (June to October); persistent
high temperatures and humidity; particularly
enervating climate astride die Equator
Terrain: coastal plain, southern basin,
central plateau, northern basin
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber,
potash, lead, zinc, uranium, copper, phos¬
phates, gold, magnesium, natural gas,
hydropower
Land use: arable land: 1 .45%
permanent crops: 0.15%
other: 98.4% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 832 cu
km (1987)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.03 cu km/yr
(59%/29%/l 2%)
per capita: 8 cu m/yr (2000)
Natural hazards: seasonal Hooding
Environment — current issues: air pollu¬
tion from vehicle emissions; water pollu¬
tion from the dumping of raw sewage; tap
water is not potable; deforestation
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: about 70% of the popu¬
lation lives in Brazzaville, Pointe-Noire, or
along the railroad between them','cba5b92d8a7ab7290c0cd07e0d579a89240f166336428a931878846b237beae1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8c9a67357d5148b3737f1cf308607668d61cdb759bc3c9e50239c7ef1efbe2b',2010,'AI','Anguilla','geography',185,'Location: Caribbean, islands between the
Caribbean Sea and North Atlantic Ocean,
east of Puerto Rico
Geographic coordinates: 1 8 1 5 N, 63 1 0 W
Map references: Central America and the
Caribbean
Area: total: 102 sq km
land: 102 sq km
water: 0 sq km
Area — comparative: about one-half the
size of Washington, DC
Land boundaries: 0 km
20
Coastline: 61 km
Maritime Claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; moderated by northeast
trade winds
Terrain: flat and low-lying island of coral
and limestone
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use: arable land: 0%
permanent crops: 0%
other: 100% (mostly rock with sparse
scrub oak, few trees, some commercial salt
ponds) (2005)
Irrigated land: NA
Natural hazards: frequent hurricanes and
other tropical storms (July to October)
Environment — current issues: supplies
of potable water sometimes cannot meet
increasing demand largely because of poor
distribution system
Geography — note: the most northerly of
the Leeward Islands in the Lesser Antilles','022b3ba5093af8b6b4a1db897b3034fb1b22e61bd953912d62cbb664f89cf209','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('671729f4dbbc153b0cde6ca080398685c469206647ffa3a78ec1e68ad8831733',2010,'AQ','Antarctica','geography',192,'Location: continent mosdy south of the
Antarctic Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area: total: 14 million sq km
land: 14 million sq km (280,000 sq km
ice-free, 13.72 million sq km ice-covered)
(est.)
note: fifth-largest continent, following
Asia, Africa, North America, and South
America, but larger than Australia and the
subcontinent of Europe
22
Area — comparative: slightly less than 1.5
times the size of the US
Land boundaries: 0 km
note: see entry on Disputes— international
Coastline: 17,968 km
Maritime Claims: Australia, Chile, and
Argentina claim Exclusive Economic
Zone (EEZ) rights or similar over 200 nm
extensions seaward from their continental
claims, but like the claims themselves, these
zones are not accepted by other countries;
21 of 28 Antarctic consultative nations
have made no claims to Antarctic territory
(although Russia and the US have reserved
the right to do so) and do not recognize
the claims of the other nations; also see the
Disputes— international entry
Climate: severe low temperatures vary with
latitude, elevation, and distance from the
ocean; East Antarctica is colder than West
Antarctica because of its higher elevation;
Antarctic Peninsula has the most moderate
climate; higher temperatures occur in
January along the coast and average slightly
below freezing
Terrain: about 98% thick continental ice
sheet and 2% barren rock, with average
elevations between 2,000 and 4,000
meters; mountain ranges up to nearly 5,000
meters; ice-free coastal areas include parts
of southern Victoria Land, Wilkes Land,
the Antarctic Peninsula area, and parts of
Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the
coasdine, and floating ice shelves constitute
1 1 % of the area of the continent
Elevation extremes: lowest point: Bentley
Subglacial Trench -2,540 m
highest point: Vinson Massif 4,897 m
note: the lowest known land point in
Antarctica is hidden in the Bentley Subgla¬
cial Trench; at its surface is the deepest ice
yet discovered and the world’s lowest eleva¬
tion not under seawater
Natural resources: iron ore, chromium,
copper, gold, nickel, platinum and other
minerals, and coal and hydrocarbons have
been found in small uncommercial quanti¬
ties; none presently exploited; krill, finfish,
and crab have been taken by commercial
fisheries
Land use: arable land: 0%
permanent crops: 0%
other: 100% (ice 98%, barren rock 2%)
(2005)
Natural hazards: katabatic (gravity-driven)
winds blow coastward from the high
interior; frequent blizzards form near the
foot of the plateau; cyclonic storms form
over the ocean and move clockwise along
the coast; volcanism on Deception Island
and isolated areas of West Antarctica;
other seismic activity rare and weak; large
icebergs may calve from ice shelf
Environment— current issues: in 1998,
NASA satellite data showed that the
Antarctic ozone hole was the largest on
record, covering 27 million square kilom¬
eters; researchers in 1997 found that
increased ultraviolet light passing through
the hole damages the DNA of icefish, an
Antarctic fish lacking hemoglobin; ozone
depletion earlier was shown to harm one-
celled Antarctic marine plants; in 2002,
significant areas of ice shelves disintegrated
in response to regional warming
Geography — note: the coldest, windiest,
highest (on average), and driest continent;
during summer, more solar radiation
reaches the surface at the South Pole than
is received at the Equator in an equivalent
period; mostly uninhabitable','146c8908c358821689f475e71cccd7da80d37a25cf236af44f48339e4f0d2738','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8562c5cf05c561f301edb7d0a9aa1e7a85ad51f50b64329495facb29a961942',2010,'AG','Antigua and Barbuda','geography',202,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic
Ocean, east-southeast of Puerto Rico
Geographic coordinates: 1 7 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area: total: 442.6 sq km (Antigua 280 sq
km; Barbuda 161 sq km)
land: 442.6 sq km
water: 0 sq km
note: includes Redonda, 1 .6 sq km
Area — -comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical maritime; little seasonal
temperature variation
Terrain: mostly low-lying limestone and coral
islands, with some higher volcanic areas
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant
climate fosters tourism
Land use:
arable land: 18.18%
permanent crops: 4.55%
other: 77.27% (2005)
Irrigated land: NA
Total renewable water resources:
0.1 cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.005 cu
km/yr (60%/20%/20%)
per capita: 63 cu m/yr (1990)
Natural hazards: hurricanes and tropical
storms (July to October); periodic droughts
Environment — current issues: water
management— a major concern because of
limited natural fresh water resources— is
further hampered by the clearing of trees to
increase crop production, causing rainfall
to run off quickly
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands,
Whaling
25
THE CIA WORLD FACTBOOK
signed, but not ratified: none of the selected
agreements
Geography— note: Antigua has a deeply
indented shoreline with many natural
harbors and beaches; Barbuda has a large
western harbor
Location: body of water between Europe,
Asia, and North America, mostly north of
the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area: total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea,
Beaufort Sea, Chukchi Sea, East Siberian
Sea, Greenland Sea, Hudson Bay, Hudson
Strait, Kara Sea, Laptev Sea, Northwest
Passage, and other tributary water bodies
Area — comparative: slightly less than 1.5
times the size of the US
Coastline: 45,389 km','b83cf2740ef64bf498147b3a39723a08503edfa7abe68207b3b2a44aef0c7992','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfc15870e65a0c65b8a572e5376fbc3bf14ac60f4df82faae4900c43474a2eb3',2010,'AR','Argentina','geography',208,'Location: Southern South America,
bordering the South Atlantic Ocean,
between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
28
Area: total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area — comparative: slightly less than
three-tenths the size of the US
Land boundaries: total: 9,861 km
border countries: Bolivia 832 km, Brazil
1,261 km, Chile 5,308 km, Paraguay 1,880
km, Uruguay 580 km
Coastline: 4,989 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: mosdy temperate; arid in south¬
east; subantarctic in southwest
Terrain: rich plains of the Pampas in
northern half, flat to rolling plateau of
Patagonia in south, rugged Andes along
western border
Elevation extremes: lowest point: Laguna
del Carbon -105 m (located between Puerto
San Julian and Comandante Luis Piedra
Buena in the province of Santa Cruz)
highest point: Cerro Aconcagua 6,960 m
(located in the northwestern corner of the
province of Mendoza)
Natural resources: fertile plains of the
pampas, lead, zinc, tin, copper, iron ore,
manganese, petroleum, uranium
Land use: arable land: 10.03%
permanent crops: 0.36%
other: 89.61% (2005)
Irrigated land: 15,500 sq km (2003)
Total renewable water resources:
814 cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 29.19 cu
km/yr (1 7%/9%/74%)
per capita: 753 cu m/yr (2000)
Natural hazards: San Miguel de Tucuman
and Mendoza areas in the Andes subject
to earthquakes; pamperos are violent wind¬
storms that can strike the pampas and
northeast; heavy flooding
Environment — current issues: environ¬
mental problems (urban and rural) typical
of an industrializing economy such as defor¬
estation, soil degradation, desertification,
air pollution, and water pollution
note: Argentina is a world leader in setting
voluntary greenhouse gas targets
Environment— internationalagreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: Marine Life
Conservation
Geography — note: second-largest country
in South America (after Brazil); strategic loca¬
tion relative to sea lanes between the South
Atlantic and the South Pacific Oceans
(Strait of Magellan, Beagle Channel, Drake
Passage); diverse geophysical landscapes
range from tropical climates in the north to
tundra in the far south; Cerro Aconcagua
is the Western Hemisphere’s tallest moun¬
tain, while Laguna del Carbon is the lowest
point in the Western Hemisphere','a710c46779e8d10432eb4f9af56ce084ab4e23864baf67752387a4cc9c2dbe7c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f856e2302c84bb82d66ee87a18c51552bd1ddb806fd726e91f6bdda11e4fdf1',2010,'AM','Armenia','geography',211,'Location: Southwestern Asia, east of
Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Asia
Area: total: 29,743 sq km
land: 28,454 sq km
water: 1 ,289 sq km
Area — comparative: slightly smaller than
Maryland
Land boundaries: total: l ,254 km
border countries: Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia
164 km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot
summers, cold winters
Terrain: Armenian Highland with moun¬
tains; little forest land; fast flowing rivers;
good soil in Aras River valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lermagagat’ 4,090 m
Natural resources: small deposits of gold,
copper, molybdenum, zinc, bauxite
Land USe: arable land: 16.78%
permanent crops: 2.01%
other: 81.21% (2005)
Irrigated land: 2,860 sq km (2003)
Total renewable water resources:
10.5 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.95 cu
km/yr (30%/4%/66%)
per capita: 977 cu m/yr (2000)
Natural hazards:
occasionally severe earthquakes; droughts
Environment — current issues: soil
pollution from toxic chemicals such as
DDT; the energy crisis of the 1990s led to
deforestation when citizens scavenged for
firewood; pollution of Hrazdan (Razdan)
and Aras Rivers; the draining of Sevana
Lich (Lake Sevan), a result of its use as a
source for hydropower, threatens drinking
water supplies; restart of Metsamor nuclear
power plant in spite of its location in a seis-
mically active zone
Environment— international agreements:
party to: Air Pollution, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection, Wedands
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography — note: landlocked in the
Lesser Caucasus Mountains; Sevana Lich
(Lake Sevan) is the largest lake in this
mountain range','58aaba5ff9a917564ac54ac5e2659c8316710e59532f460deffe17f20fddfc15','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5487d2fc13c76e5eaa6965a5dc922128dc31e551c1aea8781e9515fb82e9fe7a',2010,'AW','Aruba','geography',220,'Location: Caribbean, island in the Carib¬
bean Sea, north of Venezuela
Geographic coordinates:
12 30 N, 69 58 W
Map references: Central America and the
Caribbean
Area: total: 193 sq km
land: 193 sq km
water: 0 sq km
Area — comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime Claims: territorial sea: 12 nm
Climate: tropical marine; little seasonal
temperature variation
Terrain: flat with a few hills; scant
vegetation
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources:
NEGL; white sandy beaches
Land use: arable land: 10.53%
permanent crops: 0%
other: 89.47% (2005)
Irrigated land: 0.01 sq km (1998 est.)
Natural hazards: hurricanes; lies outside
the Caribbean hurricane belt and is rarely
threatened
Environment— current issues: NA
Geography— note: a flat, riverless island
renowned for its white sand beaches; its
tropical climate is moderated by constant
trade winds from the Atlantic Ocean; the
temperature is almost constant at about 27
degrees Celsius (81 degrees Fahrenheit)','f2b3d5e57676bc10c0ac86091c951da3ee06d4f8a9a39909712f1e2f6f8a21ab','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef148094bf67d905bdf6a6ab62f6af80244e35961890d20f34c955685ebe306e',2010,'NL','Netherlands','geography',229,'Location: Southeastern Asia, islands in
the Indian Ocean, midway between north¬
western Australia and Timor island
38
ATLANTIC OCEAN
Geographic coordinates:
12 14 S, 123 05 E
Map references: Southeast Asia
Area: total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle,
and East Islets) and Cartier Island
Area — comparative: about eight times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims: territorial sea: 1 2 nm
contiguous zone: 1 2 nm
exclusive fishing zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical
Terrain: low with sand and coral
Location: body of water between Africa,
Europe, the Southern Ocean, and the
Western Hemisphere
Geographic coordinates:
0 00 N, 25 00 W
Map references:
Political Map of the World
Area: total: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Carib¬
bean Sea, Davis Strait, Denmark Strait,
part of the Drake Passage, Gulf of Mexico,
Legal system: the laws of the Common¬
wealth of Australia and the laws of the
Northern Territory of Australia, where
applicable, apply
Diplomatic representation in the US:
none (territory of Australia)
Diplomatic representation from the US:
none (territory of Australia)
Flag description:
the flag of Australia is used
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area: total: 30,528 sq km
land: 30,278 sq km
water: 250 sq km
Area — comparative: about the size of
Maryland
Land boundaries:
total: 1 ,385 km
67
THE CIA WORLD FACTBOOK
border countries: France 620 km, Germany
167 km, Luxembourg 148 km, Netherlands
450 km
Coastline: 66.5 km
Maritime claims:
territorial sea : 12 nm
contiguous zone: 24 nm
exclusive economic zone: geographic coordi¬
nates define outer limit
continental shelf: median line with
neighbors
Climate: temperate; mild winters, cool
summers; rainy, humid, cloudy
Terrain: flat coastal plains in northwest,
central rolling hills, rugged mountains of
Ardennes Forest in southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
Natural resources: construction materials,
silica sand, carbonates
Land use:
arable land: 27.42%
permanent crops: 0.69%
other: 71.89%
note: includes Luxembourg (2005)
Irrigated land: 400 sq km (2003)
Total renewable water resources:
20.8 cu km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 7.44 cu km/yr (1 3%/85%/l %)
per capita: 714 cu m/yr (1998)
Natural hazards: flooding is a threat along
rivers and in areas of reclaimed coastal land,
protected from the sea by concrete dikes
Environment — current issues: the envi¬
ronment is exposed to intense pressures
from human activities: urbanization, dense
transportation network, industry, extensive
animal breeding and crop cultivation; air
and water pollution also have repercussions
for neighboring countries; uncertainties
regarding federal and regional responsibili¬
ties (now resolved) had slowed progress in
tackling environmental challenges
Environment — international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulfur 85, Air
Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environ¬
mental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conserva¬
tion, Ozone Layer Protection, Ship Pollu¬
tion, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: crossroads of Western
Europe; most West European capitals
within 1,000 km of Brussels, the seat of
both the European Union and NATO
Location: Western Europe, bordering
the North Sea, between Belgium and
Location: Caribbean, two island groups
in the Caribbean Sea— composed of five
islands, Curacao and Bonaire located off
the coast of Venezuela, and Sint Maarten,
Saba, and Sint Eustatius lie east of the US
Virgin Islands
Geographic coordinates:
Bonaire: 12 12 N, 68 15 W
Curacao: 12 10N, 69 00 W
Saba: 17 38 N, 63 14 W
Sint Eustatius: 17 30 N, 62 58 W
Sint Maarten: 18 04 N, 63 04 W
Map references: Central America and the
Caribbean
Area: total: 960 sq km
land: 960 sq km
water: 0 sq km
note: includes Bonaire, Curacao, Saba, Sint
Eustatius, and Sint Maarten (Dutch part of
the island of Saint Martin)
Area — comparative: more than five times
the size of Washington, DC
Land boundaries: total 15 km
border countries: Saint Martin 15 km
Coastline: 364 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 12 nm
487
THE CIA WORLD FACTBOOK
Climate: tropical; ameliorated by northeast
trade winds
Terrain: generally hilly, volcanic interiors
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Mount Scenery 862 m
Natural resources: phosphates (Curacao
only), salt (Bonaire only)
Land use: arable land: 10%
permanent crops: 0%
other: 90% (2005)
Irrigated land: NA
Natural hazards: Sint Maarten, Saba, and
Sint Eustatius are subject to hurricanes
from July to October; Curacao and Bonaire
are south of Caribbean hurricane belt and
are rarely threatened
Environment — current issues: NA
Geography — note: the five islands of
the Netherlands Antilles are divided
geographically into the Leeward Islands
(northern) group (Saba, Sint Eustatius, and
Sint Maarten) and the Windward Islands
(southern) group (Bonaire and Curacao);
the island of Saint Martin is the smallest
landmass in the world shared by two
independent states, the French territory
of Saint Martin and the Dutch territory of
Sint Maarten','4858d93c16e7ca7185fdb298e7691b09a2e2fb85820401ffd385c42ac1a6d9a2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16dff67fef08c66a4daccabc812ef45fa3e9137dcf80f0ff81bbb61e21a25deb',2010,'AU','Australia','geography',232,'Location: Oceania, continent between
the Indian Ocean and the South Pacific
Ocean
Geographic coordinates:
27 00 S, 133 00 E
Map references: Oceania
Area: total: 7,686,850 sq km
land: 7,617,93 0 sq km
Islands, Spain), Le Havre (France), Lisbon
(Portugal), London (UK), Marseille (France),
Montevideo (Uruguay), Montreal (Canada),
Naples (Italy), New Orleans (US), New
York (US), Oran (Algeria), Oslo (Norway),
Peiraiefs or Piraeus (Greece), Rio de Janeiro
(Brazil), Rotterdam (Netherlands), Saint
Petersburg (Russia), Stockholm (Sweden)
Transportation — note: Kiel Canal and
Saint Lawrence Seaway are two important
waterways; significant domestic commercial
and recreational use of Intracoastal
Waterway on central and south Atlantic
seaboard and Gulf of Mexico coast of US;
the International Maritime Bureau reports
ti\\e territorial waters of littoral states and
offshore Adantic waters as high risk for
piracy and armed robbery against ships,
particularly in the Gulf of Guinea off
West Africa, the east coast of Brazil, and
the Caribbean Sea; numerous commercial
vessels have been attacked and hijacked
both at anchor and while underway;
hijacked vessels are often disguised and
cargoes stolen; crews have been robbed
and stores or cargoes stolen','5793595beed2a08eedd61aa1ec2f02fa3285fbe792f2885272499d753602d74f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbe16540b8bc6e98b42c28c6123727fba34250f8a43a388f90e4187ca27c03f0',2010,'AT','Austria','geography',241,'Location: Central Europe, north of Italy
and Slovenia
Geographic coordinates:
47 20 N, 13 20 E
Map references: Europe
Area: total: 83,870 sq km
land: 82,444 sq km
water: 1 ,426 sq km
Area— comparative:
slightly smaller than Maine
Land boundaries: total: 2,562 km
border countries: Czech Republic 362 km,
Germany 784 km, Hungary 366 km, Italy
430 km, Liechtenstein 35 km, Slovakia 91
km, Slovenia 330 km, Switzerland 1 64 km
Coastline: 0 km (landlocked)
Maritime claims:
none (landlocked)
Climate: temperate; continental, cloudy;
cold winters with frequent rain and some
snow in lowlands and snow in moun¬
tains; moderate summers with occasional
showers
Terrain: in the west and south mosdy
mountains (Alps); along the eastern and
northern margins mosdy flat or gendy
sloping
Elevation extremes:
lowest point: Neusiedler See 115m
highest point: Grossglockner 3,798 m
Natural resources: oil, coal, lignite, timber,
iron ore, copper, zinc, antimony, magne¬
site, tungsten, graphite, salt, hydropower
Land use:
arable land: 16.59%
permanent crops: 0.85%
other: 82.56% (2005)
Irrigated land:
40 sq km (2003)
Total renewable water resources:
84 cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 3.67 cu km/yr (35%/64%/l%)
per capita: 448 cu m/yr (1999)
Natural hazards:
landslides; avalanches; earthquakes
Environment— current issues: some
forest degradation caused by air and soil
pollution; soil pollution results from the
use of agricultural chemicals; air pollution
results from emissions by coal- and oil-
fired power stations and industrial plants
and from trucks transiting Austria between
northern and southern Europe
Environment— internationalagreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulphur 94, Air Pollution-
Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; strategic
location at the crossroads of central Europe
with many easily traversable Alpine passes
and valleys; major river is the Danube;
population is concentrated on eastern
lowlands because of steep slopes, poor
soils, and low temperatures elsewhere','3ed8705451d4f64057792cbb101df0e6253a15de7b296029b324300a4e1889c7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa6dfea378c3ba81abab466618c521c2634a7d887a488c900e3a3f0c350b24fc',2010,'AZ','Azerbaijan','geography',250,'Location: Southwestern Asia, bordering
the Caspian Sea, between Iran and Russia,
with a small European portion north of the
Caucasus range
Geographic coordinates: 40 30 N, 47 30 E
Map references: Asia
Area: total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan
Autonomous Republic and the Nagorno-
Karabakh region; the region’s autonomy
was abolished by Azerbaijani Supreme
Soviet on 26 November 1991
Area — comparative: slightly smaller than
Maine
Land boundaries: total: 2,013 km
border countries: Armenia (with Azerbaijan-
proper) 566 km, Armenia (with Azerbaijan-
Naxcivan exclave) 221 km, Georgia 322
km, Iran (with Azerbaijan-proper) 432 km,
Iran (with Azerbaijan-Naxcivan exclave)
179 km, Russia 284 km, Turkey 9 km
Coastline: 0 km (landlocked); note—
Azerbaijan borders the Caspian Sea (713 km)
Maritime Claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-
Araks Lowland) (much of it below sea
level) with Great Caucasus Mountains
to the north, Qarabag Yaylasi (Karabakh
Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts
into Caspian Sea
Elevation extremes: lowest point:
Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas,
iron ore, nonferrous metals, bauxite
Land use: arable land: 20.62%
permanent crops: 2.61%
other: 76.77% (2005)
Irrigated land: 14,550 sq km (2003)
Total renewable water resources:
30.3 cu km (1997)
Freshwater withdrawal
(domestic/industrial/agricultural):
total: 17.25 cu km/yr (5%/28%/68%)
per capita: 2,051 cu m/yr (2000)
Natural hazards: droughts
Environment— current issues: local
scientists consider the Abseron Yasaqligi
(Apsheron Peninsula) (including Baku
and Sumqayit) and the Caspian Sea to be
the ecologically most devastated area in
the world because of severe air, soil, and
water pollution; soil pollution results from
oil spills, from the use of DDT pesticide,
and from toxic defoliants used in the
production of cotton
Environment — international
agreements: party to: Air Pollution,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: bodi the main area of
the country and the Naxcivan exclave are
landlocked
Location: Caribbean, chain of islands in
the North Adantic Ocean, southeast of
Florida, northeast of Cuba
Geographic coordinates: 24 15 N, 76 00 w
Map references: Central America and the
Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area — comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; moderated by
warm waters of Gulf Stream
Terrain: long, flat coral formations with
some low rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat
Island 63 m
Natural resources: salt, aragonite, timber,
arable land
Land use: arable land: 0.58%
permanent crops: 0.29%
other: 99.13% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: NA
Natural hazards: hurricanes and other
tropical storms cause extensive flood and
wind damage
Environment — current issues: coral reef
decay; solid waste disposal
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti''
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protec¬
tion, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location adja¬
cent to US and Cuba; extensive island
chain of which 30 are inhabited','91c434450976e27c8b1fe7db4f306f73fe2b08c24635723738f9d03937409916','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b55783c2386664e2f6f19645ee5116f6066ebc8be961f51abcda865e57d5afd',2010,'BH','Bahrain','geography',255,'Location: Middle East, archipelago in the
Persian Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area:
total: 665 sq km
land: 665 sq km
water: 0 sq km
Area — comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
continental shelf: extending to boundaries
to be determined
Climate: arid; mild, pleasant winters; very
hot, humid summers
Terrain: mostly low desert plain rising
gendy to low central escarpment
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and
nonassociated natural gas, fish, pearls
Land use:
arable land: 2.82%
permanent crops: 5.63%
other: 91.55% (2005)
Irrigated land: 40 sq km (2003)
Total renewable water resources:
0.1 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.3 cu
km/yr (40%/3%/57%)
per capita: 41 1 cu m/yr (2000)
Natural hazards:
periodic droughts; dust storms
Environment — current issues: desertifi¬
cation resulting from the degradation of
limited arable land, periods of drought, and
dust storms; coastal degradation (damage
to coastlines, coral reefs, and sea vegeta¬
tion) resulting from oil spills and other
discharges from large tankers, oil refineries,
and distribution stations; lack of freshwater
resources (groundwater and seawater are
the only sources for all water needs)
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wedands
, signed, but not ratified: none of the selected
agreements
Geography — note: close to primary
Middle Eastern petroleum sources; strategic
location in Persian Gulf, through which
much of the Western world’s petroleum
must transit to reach open ocean','deb9fba865fc4b92f8fc68238a1794c5dae3f8400b85b99b383090086d7a6fa2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8eb2653d672418f29588865226a7c11b86c7abfcf71552ec735ac037748017b',2010,'BD','Bangladesh','geography',264,'Location: Southern Asia, bordering the
Bay of Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
total: 144,000 sq km
land: 133,910 sq km
water: 10,090 sq km
Area— comparative:
slightly smaller than Iowa
Land boundaries: total: 4,246 km
border countries: Burma 193 km, India
4,053 km
Coastline: 580 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 18 nm
exclusive economic zone: 200 nm
continental shelf: up to the outer limits of
the continental margin
Climate: tropical; mild winter (October
to March); hot, humid summer (March to
June); humid, warm rainy monsoon (June
to October)
Terrain: mostly flat alluvial plain; hilly in
southeast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Keokradong 1,230 m
Natural resources: natural gas, arable land,
timber, coal
Land use:
arable land: 55.39%
permanent crops: 3.08% >
other: 41.53% (2005)
Irrigated land: 47,250 sq km (2003)
Total renewable water resources:
1,210.6 cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 79.4 cu
km/yr (3%/l%/96%)
per capita: 560 cu m/yr (2000)
Natural hazards: droughts; cyclones;
much of the country routinely inundated
during the summer monsoon season
Environment — current issues: many
people are landless and forced to live on
and cultivate flood-prone land; waterborne
diseases prevalent in surface water; water
pollution, especially of fishing areas, results
from the use of commercial pesticides;
ground water contaminated by naturally
occurring arsenic; intermittent water short¬
ages because of falling water tables in the
northern and central parts of the country;
soil degradation and erosion; deforestation;
severe overpopulation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Elazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: most of the country is
situated on deltas of large rivers flowing
from the Himalayas: the Ganges unites
with the Jamuna (main channel of the
Brahmaputra) and later joins the Meghna
to eventually empty into the Bay of Bengal','cb993a8c79636e180c1b9cdd0e25d4c35a7d967bba8776bb5866ef6f1ea6c503','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a1ae052bc0909892312fa2d05bd7ff4ff70097ce53cba25d06dc6fe0f29837f',2010,'BB','Barbados','geography',268,'Location: Caribbean, island in the North
Atlantic Ocean, northeast of Venezuela
Geographic coordinates:
13 10N, 59 32 W
Map references: Central America and the
Caribbean
Area: total: 431 sq km
land: 431 sq km
water: 0 sq km
Area — comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime Claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate:
tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central
highland region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish,
natural gas
Land use: arable land: 37.21%
permanent crops: 2.33%
other: 60.46% (2005)
Irrigated land: 50 sq km (2003)
Total renewable water resources:
0.1 cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.09 cu km/yr (33%/44%/22%)
per capita: 333 cu m/yr (2000)
Natural hazards: infrequent hurricanes;
periodic landslides
Environment— current issues: pollution of
coastal waters from waste disposal by ships;
soil erosion; illegal solid waste disposal
threatens contamination of aquifers
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Wetlands signed, but not ratified: none of
the selected agreements
Geography — note:
easternmost Caribbean island','f206c8bb6fde08cbe2c78fc132f0158c3a410bc6ca101c73f2eca27ec970a6cf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d4800c311e1f487c0b6037cf21bc69775b89e397ac5a2245870755e67b83c36',2010,'BY','Belarus','geography',276,'Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Europe
Area: total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Kansas
Land boundaries:
total: 3,306 km
border countries: Latvia 171 km, Lithuania
680 km, Poland 605 km, Russia 959 km,
Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: cold winters, cool and moist
summers; transitional between continental
and maritime
Terrain: generally flat and contains much
marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits,
small quantities of oil and natural gas,
granite, dolomitic limestone, marl, chalk,
sand, gravel, clay
Land use: arable land: 26.77%
permanent crops: 0.6%
other: 72.63% (2005)
Irrigated land: 1,310 sq km (2003)
Total renewable water resources:
58 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 2.79 cu km/yr (23%/47%/30%)
per capita: 286 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: soil
pollution from pesticide use; southern part
of the country contaminated with fallout
from 1986 nuclear reactor accident at
Chernobyl’ in northern Ukraine
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Sulfur 85,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the
selected agreements
Geography— note: landlocked; glacial
scouring accounts for the flatness of Bela¬
rusian terrain and for its 1 1 ,000 lakes','14d0461b070d003ebaa1549e9e7aeca09ed2c939eba4835d1c56448bc4f59a7d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1483ac8ee1f2f189e82617336ee8edca90bf3d2a0437f146cc2f8b952afdd1cd',2010,'FR','France','geography',286,'Location: Western Europe, bordering
the North Sea, between France and the
Location: metropolitan France: Western
Europe, bordering die Bay of Biscay and
English Channel, between Belgium and
Spain, southeast of the UK; bordering
the Mediterranean Sea, between Italy and
Geographic coordinates: metropolitan
France: 46 00 N, 2 00 E
French Guiana: 4 00 N, 53 00 W
Guadeloupe: 16 15 N, 61 35 W
Martinique: 14 40 N, 61 00 W
Reunion: 21 06 S, 55 36 E
Map references: metropolitan France:
Europe
French Guiana: South America
Guadeloupe: Central America and the
Caribbean
Martinique: Central America and the
Caribbean
Reunion: World
Area:
total: 643,427 sq km; 547,030 sq km
(metropolitan France)
land: 640,053 sq km; 545,630 sq km
(metropolitan France)
water: 3,374 sq km; 1,400 sq km (metro¬
politan France)
note: the first numbers include the overseas
regions of French Guiana, Guadeloupe,
Martinique, and Reunion
Area— comparative: slightly less than the
size of Texas
Land boundaries: metropolitan France-
total: 2,889 km
border countries: Andorra 56.6 km,
Belgium 620 km, Germany 451 km, Italy
488 km, Luxembourg 73 km, Monaco 4.4
km, Spain 623 km, Switzerland 573 km
French Guiana— total: 1,183 km
border countries: Brazil 673 km, Suriname
510 km
Coastline:
total 4,668 km
metropolitan France: 3,427 km
Maritime Claims: territorial sea: 12 nm
contiguous zone : 24 nm
exclusive economic zone: 200 nm (does not
apply to the Mediterranean)
continental shelf: 200 m depth or to the
depth of exploitation
Climate: metropolitan France: generally
cool winters and mild summers, but mild
winters and hot summers along the Mediter¬
ranean; occasional strong, cold, dry, north-
to-north westerly wind known as mistral
French Guiana: tropical; hot, humid; little
seasonal temperature variation
Guadeloupe and Martinique: subtropical
tempered by trade winds; moderately high
humidity; rainy season (June to October);
vulnerable to devastating cyclones (hurri¬
canes) every eight years on average
Reunion: tropical, but temperature moder¬
ates with elevation; cool and dry (May to
November), hot and rainy (November to
April)
Terrain: metropolitan France: mostly flat
plains or gently rolling hills in north and
west; remainder is mountainous, especially
Pyrenees in south, Alps in east
French Guiana: low-lying coastal plains
rising to hills and small mountains
Guadeloupe: Basse-Terre is volcanic in
origin with interior mountains; Grande-
Terre is low limestone formation; most of
the seven other islands are volcanic in origin
Martinique: mountainous with indented
coastline; dormant volcano
Reunion: mostly rugged and mountainous;
fertile lowlands along coast
Elevation extremes: lowest point: Rhone
River delta -2 m
highest point: Mont Blanc 4,807 m
Natural resources: metropolitan France:
coal, iron ore, bauxite, zinc, uranium, anti¬
mony, arsenic, potash, feldspar, fluorspar,
gypsum, timber, fish
French Guiana : gold deposits, petroleum,
kaolin, niobium, tantalum, clay
Land use: arable land: 33.46%
permanent crops: 2.03%
other: 64.51%
note: French Guiana— arable land 0.13%,
permanent crops 0.04%, other 99.83%
(90% forest, 10% other); Guadeloupe-
arable land 11.70%, permanent crops
2.92%, other 85.38%; Martinique— arable
land 9.09%, permanent crops 10.0%,
other 80.91%; Reunion— arable land
13.94%, permanent crops 1.59%, other
84.47% (2005)
Irrigated land: total 26,190 sq km;
metropolitan France: 26,000 sq km (2003)
Total renewable water resources: 189 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total 33.16 cu
km/yr (1 6%/74%/l 0%)
per capita: 548 cu m/yr (2000)
Natural hazards: metropolitan France:
flooding; avalanches; midwinter wind¬
storms; drought; forest fires in south near
the Mediterranean
overseas departments: hurricanes (cyclones);
flooding; volcanic activity (Guadeloupe,
Martinique, Reunion)
Environment — current issues: some
forest damage from acid rain; air pollu¬
tion from industrial and vehicle emissions;
water pollution from urban wastes, agricul¬
tural runoff
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: largest West European
nation
Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area: total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient,
and the northwest quarter of the Dead Sea,
but excludes Mt. Scopus; East Jerusalem
and Jerusalem No Man’s Land are also
included only as a means of depicting the
entire area occupied by Israel in 1967
Area — comparative: slighdy smaller than
Delaware
Land boundaries: total: 404 km
border countries: Israel 307 km, Jordan 97
km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; temperature and
precipitation vary with altitude, warm to
hot summers, cool to mild winters
Terrain: mostly rugged dissected upland,
some vegetation in west, but barren in east
Elevation extremes: lowest point: Dead
Sea -408 m
highest point: Tall Asur 1 ,022 m
Natural resources: arable land
Land use: arable land: 16.9%
permanent crops: 18.97%
other: 64.13% (2001)
Irrigated land: 150 sq km; note— includes
Gaza Strip (2003)
Natural hazards: droughts
Environment — current issues: adequacy
of fresh water supply; sewage treatment
Geography — note: landlocked; highlands
are main recharge area for Israel’s coastal
aquifers; there are about 340 Israeli civilian
sites— including 1 00 small outpost commu¬
nities in the West Bank and 29 sites in
East Jerusalem (July 2008 est.)','6b65dd31f4a9ceb275ff46fa2e9d6e88dc6921945a1d564dac8bd7db055a06b7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f758e04a0b07e84ce7b51de87458cad21b57d9a2de9a6796bd215cb5cafa2482',2010,'MX','Mexico','geography',294,'Geographic coordinates: 1 7 15 N, 88 45 W
Map references: Central America and the
Caribbean
Area:
total: 22,966 sq km
land: 22,806 sq km
water: 1 60 sq km
Area — comparative: slightly smaller than
Massachusetts
Land boundaries: total: 516 km
border countries: Guatemala 266 km,
Mexico 250 km
Coastline: 386 km
Maritime Claims: territorial sea: 12 nm
in the north, 3 nm in the south; note—
from the mouth of the Sarstoon River to
Ranguana Cay, Belize’s territorial sea is 3
nm; according to Belize’s Maritime Areas
Act, 1992, the purpose of this limitation
is to provide a framework for negoti¬
ating a definitive agreement on territorial
differences with Guatemala
exclusive economic zone: 200 nm
Climate: tropical; very hot and humid;
rainy season (May to November); dry
season (February to May)
Terrain: flat, swampy coastal plain; low
mountains in south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Doyle’s Delight 1,160 m
Natural resources: arable land potential,
timber, fish, hydropower
Land use: arable land: 3.05%
permanent crops: 1.39%
other: 95.56% (2005)
Irrigated land: 30 sq km (2003)
Total renewable wafer resources:
18.6 cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.15 cu km/yr (7%/73%/20%)
per capita: 556 cu m/yr (2000)
Natural hazards: frequent, devastating
hurricanes (June to November) and coastal
flooding (especially in south)
Environment — current issues: defor¬
estation; water pollution from sewage,
industrial effluents, agricultural runoff;
solid and sewage waste disposal
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protec¬
tion, Ship Pollution, Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: only country in Central
America without a coasdine on the North
Pacific Ocean
Location: Middle America, bordering the
Caribbean Sea and the Gulf of Mexico,
between Belize and the United States
and bordering the North Pacific Ocean,
between Guatemala and the United States
Geographic coordinates: 23 00 N, 102
00 w
Map references: North America
Area: total: 1,972,550 sq km
land: 1,923,040 sq km
water: 49,510 sq km
Area— comparative: slightly less than
three times the size of Texas
Land boundaries: total: 4,353 km
border countries: Belize 250 km, Guatemala
962 km, US 3,141 km
Coastline: 9,330 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low
coastal plains; high plateaus; desert
Elevation extremes: lowest point: Laguna
Salada -10 m
highest point: Volcan Pico de Orizaba
5,700 m
Natural resources: petroleum, silver,
copper, gold, lead, zinc, natural gas, timber
Land use: arable land: 12.66%
permanent crops: 1.28%
other: 86.06% (2005)
Irrigated land: 63,200 sq km (2003)
Total renewable water resources: 457.2
cu km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 78.22 cu km/yr
(1 7%/5%/77%)
per capita: 731 cu m/yr (2000)
Natural hazards: tsunamis along the
Pacific coast, volcanoes and destructive
earthquakes in the center and south, and
hurricanes on the Pacific, Gulf of Mexico,
and Caribbean coasts
Environment — current issues: scarcity of
hazardous waste disposal facilities; rufal
to urban migration; natural fresh water
resources scarce and polluted in north,
inaccessible and poor quality in center and
extreme southeast; raw sewage and indus¬
trial effluents polluting rivers in urban
areas; deforestation; widespread erosion;
desertification; deteriorating agricultural
lands; serious air and water pollution in the
national capital and urban centers along US-
Mexico border; land subsidence in Valley
of Mexico caused by groundwater depletion
note: the government considers the lack
of clean water and deforestation national
security issues
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location on
southern border of US; com (maize), one
of the world’s major grain crops, is thought
to have originated in Mexico','cd678cf34909307169f05738b303cee6dbc529a8a1b0d4e2f8e268c9f07ca465','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6baafc4575e345da52c3fa9d4f03412ba2cd67fcd4b858e867b56d330377d6a8',2010,'BJ','Benin','geography',302,'Location: Western Africa, bordering the
Bight of Benin, between Nigeria and Togo
Geographic coordinates: 9 30 N, 2 15 E
Map references: Africa
Area:
total: 1 12,620 sq km
land: 110,620 sq km
water: 2,000 sq km
Area — comparative: slightly smaller than
Pennsylvania
Land boundaries: total: 1,989 km
border countries: Burkina Faso 306 km,
Niger 266 km, Nigeria 773 km, Togo
644 km
Coastline: 121 km
Maritime Claims: territorial sea: 200 nm
Climate: tropical; hot, humid in south;
semiarid in north
Terrain: mostly flat to undulating plain;
some hills and low mountains
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Mont Sokbaro 658 m
Natural resources: small offshore oil
deposits, limestone, marble, timber
Land use: arable land: 23.53%
permanent crops: 2.37%
other: 74.1% (2005)
Irrigated land:
1 20 sq km (2003)
Total renewable water resources:
25.8 cu km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.13 cu
km/yr (32%/23%/45%)
per capita: 15 cu m/yr (2001)
Natural hazards: hot, dry, dusty harmattan
wind may affect north from December to
March
Environment— current issues:
inadequate supplies of potable water;
poaching threatens wildlife populations;
deforestation; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: sandbanks create
difficult access to a coast with no natural
harbors, river mouths, or islands','031800840ea2153434ad9bff99f87ccff58e7e7edf3adda2da5b5c110b0af03c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('541279fe7cc0df36909d981d57ca056f807a880d5b5c34a315ba97db73df66d8',2010,'BM','Bermuda','geography',309,'Location: North America, group of islands
in the North Atlantic Ocean, east of South
Carolina (US)
Military service age and obligation: 21
years of age for compulsory and voluntary
military service; in practice, volunteers may
be taken at the age of 18; both sexes are
eligible for military service; conscript tour
of duty— 1 8 months (2006)
Manpower available for military service:
males age 16-49: 1,908,457
females age 16-49: 1,882,421 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,279,053
females age 16-49: 1,292,438 (2009 est.)
Manpower reaching militarily
significant age annually: male: 101,549
female: 97,856 (2009 est.)
Military expenditures:
1.7% of GDP (2006)','db068d6bba6fcbf7e2e71d82434a75186f1d8772bd39a29f9f08ada79204e7b4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('432d71ab2cc1f178f909e161ab8bfb2f7d5b741d6593136e03094bf1d8320caf',2010,'BT','Bhutan','geography',319,'Location:
Soudaem Asia, between China and India
Geographic coordinates:
27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area — comparative:
about one-half the size of Indiana
Land boundaries:
total: 1,075 km
border countries: China 470 km, India
605 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: varies; tropical in southern
plains; cool winters and hot summers in
central valleys; severe winters and cool
summers in Himalayas
Terrain: mosdy mountainous with some
fertile valleys and savanna
Elevation extremes:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower,
gypsum, calcium carbonate
Land use:
arable land: 2.3%
permanent crops: 0.43%
other: 97.27% (2005)
Irrigated land: 400 sq km (2003)
Total renewable water resources:
95 cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.43 cu
km/yr (5%/l%/94%)
per capita: 199 cu m/yr (2000)
Natural hazards: violent storms from die
Himalayas are the source of the country’s
name, which translates as Land of the
Thunder Dragon; frequent landslides
during the rainy season
Environment — current issues: soil
erosion; limited access to potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography— note: landlocked; strategic
location between China and India; controls
several key Himalayan mountain passes
Location: Central South America, south¬
west of Brazil
Geographic coordinates:
17 00 S, 65 00 W
82
BOLIVIA
Map references: South America
Area: total: 1,098,580 sq km
land: 1 ,084,390 sq km
water: 14,190 sq km
Area — comparative: slightly less than
three times the size of Montana
Land boundaries: total: 6,940 km
border countries: Argentina 832 km, Brazil
3,423 km, Chile 860 km, Paraguay 750
km, Peru 1,075 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: varies with altitude; humid and
tropical to cold and semiarid
Terrain: rugged Andes Mountains with a
highland plateau (Altiplano), hills, lowland
plains of the Amazon Basin
Elevation extremes:
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Natural resources: tin, natural gas, petro¬
leum, zinc, tungsten, antimony, silver,
iron, lead, gold, timber, hydropower
Land USe: arable land: 2.78%
permanent crops: 0.19%
other: 97.03% (2005)
Irrigated land: 1 ,320 sq km (2003)
Total renewable water resources:
622.5 cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 1.44 cu km/yr (13%/7%/81%)
per capita: 157 cu m/yr (2000)
Natural hazards: flooding in the northeast
(March-April)
Environment— current issues: the clearing
of land for agricultural purposes and the
international demand for tropical timber
are contributing to deforestation; soil
erosion from overgrazing and poor culti¬
vation methods (including slash-and-burn
agriculture); desertification; loss of biodiver¬
sity; industrial pollution of water supplies
used for drinking and irrigation
Environment— international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental
Modification, Marine Life Conservation
Geography— note: landlocked; shares
control of Lago Titicaca, world’s highest
navigable lake (elevation 3,805 m), with Peru','2894b125f5198dedbe7fd9cf3b1e10ccb0c93f8c753e41a76d684cc653fceb58','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27c75f06866d4b23cb56b06ab4408fd8b748ae1af345fd4fb81dd07d8286e61b',2010,'BA','Bosnia and Herzegovina','geography',323,'Location: Southeastern Europe, bordering
the Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 1 8 00 E
Map references: Europe
Area: total: 51,209.2 sq km
land: 51,197 sq km
water: 12.2 sq km
Area — comparative: slightly smaller than
West Virginia
Land boundaries: total: 1,538 km
border countries: Croatia 932 km,
Montenegro 249 km, Serbia 357 km
Coastline: 20 km
Maritime claims: no data available
Climate: hot summers and cold winters;
areas of high elevation have short, cool
summers and long, severe winters; mild,
rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron ore, bauxite,
copper, lead, zinc, chromite, cobalt, manga¬
nese, nickel, clay, gypsum, salt, sand,
forests, hydropower
Land use: arable land: 19.61%
permanent crops: 1.89%
other: 78.5% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources:
37.5 cu km (2003)
Natural hazards: destructive earthquakes
Environment— current issues: air pollu¬
tion from metallurgical plants; sites for
disposing of urban waste are limited; water
shortages and destruction of infrastructure
because of the 1992-95 civil strife; defor¬
estation
Environment — international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law of
the Sea, Marine Life Conservation, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: within Bosnia and
Herzegovina’s recognized borders, the
country is divided into a joint Bosniak/
Croat Federation (about 51% of the
territory) and the Bosnian Serb-led Repub¬
lika Srpska or RS (about 49% of the terri¬
tory); the region called Herzegovina is
contiguous to Croatia and Montenegro,
and traditionally has been setded by an
ethnic Croat majority in the west and an
ethnic Serb majority in the east','534cf62c0dd5809a6432e6efc3e15dead8ee7b63831269e60734c290ed6559df','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d180de28854b01cc8d8b5d90a1bf3c7695ea75a325f6bf0ccee701c4a554e3ae',2010,'BW','Botswana','geography',331,'Location: Southern Africa, north of South
Africa
Geographic coordinates: 22 oo s, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
water: 15,000 sq km
Area — comparative: slighdy smaller than
Texas
Land boundaries:
total: 4,01 3 km
border countries: Namibia 1,360 km, South
Africa 1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims:
none (landlocked)
Climate: semiarid; warm winters and hot
summers
Terrain: predominandy flat to gently rolling
tableland; Kalahari Desert in southwest
Elevation extremes: lowest point: junction
of the Limpopo and Shashe Rivers 513 m
highest point: Tsodilo Hills 1,489 m
Natural resources: diamonds, copper,
nickel, salt, soda ash, potash, coal, iron ore,
silver
Land use: arable land: 0.65%
permanent crops: 0.01%
other: 99.34% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 14.7 cu
km (2001)
Freshwater withdrawal (domestic/ v v
industrial/agricultural):
total: 0.19 cu km/yr (4 1 %/l 8%/41 %)
per capita: 107 cu m/yr (2000)
Natural hazards: periodic droughts;
seasonal August winds blow from the west,
carrying sand and dust across the country,
which can obscure visibility
Environment— current issues: over-
grazing; desertification; limited fresh water
resources
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protec¬
tion, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; population
concentrated in eastern part of the country','536e56916af9fd2b54e8429f7c3b096f8429073faf4d7967ae2d5c90e8dc00a2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d07480c57c6fb48a4e0ed920bd4bfb965b429cb3d5e83bdca63c7a6417a698e',2010,'BV','Bouvet Island','geography',339,'Location: island in the South Adantic
Ocean, southwest of the Cape of Good
Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total: 49 sq km
land: 49 sq km
water: 0 sq km
Area— comparative: about 0.3 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime Claims: territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; coast is mosdy inaccessible
Elevation extremes:
lowest point: South Adantic Ocean 0 m
highest point: Olav Peak 935 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (93% ice) (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment — current issues: NA
Geography— note: covered by glacial ice;
declared a nature reserve by Norway','66d532f4142d9495d77501363f00442cb0d89a329103d6d4fb6e69b575e9349b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13474ef56af2c49b6340b42de32cb646f4c84e2b611dfaef8bef53b6a7264c79',2010,'BR','Brazil','geography',343,'Location: Eastern South America,
bordering the Atlantic Ocean
Geographic coordinates:
10 00 S, 55 00 W
Map references: South America
Area:
total: 8,511,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando
de Noronha, Atol das Rocas, Ilha da
Trindade, Ilhas Martin Vaz, and Penedos
de Sao Pedro e Sao Paulo
Area — comparative: slightly smaller than
the US
93
THE CIA WORLD FACTBOOK
Land boundaries:
total: 16,885 km
border countries: Argentina 1,261 km,
Bolivia 3,423 km, Colombia 1 ,644 km,
French Guiana 730 km, Guyana 1,606
km, Paraguay 1,365 km, Peru 2,995 km,
Suriname 593 km, Uruguay 1,068 km,
Venezuela 2,200 km
Coastline: 7,491 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the
continental margin
Climate: mostly tropical, but temperate in
south
Terrain: mostly flat to rolling lowlands in
north; some plains, hills, mountains, and
narrow coastal belt
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore,
manganese, nickel, phosphates, platinum,
tin, uranium, petroleum, hydropower,
timber
Land use: arable land: 6.93%
permanent crops: 0.89%
other: 92.18% (2005)
Irrigated land: 29,200 sq km (2003)
Total renewable water resources: 8,233
cu km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 59.3 cu km/yr
(20%/l 8%/62%)
per capita: 318 cu m/yr (2000)
Natural hazards: recurring droughts in
northeast; floods and occasional frost in
south
Environment— current issues: deforesta-
tion in Amazon Basin destroys the habitat
and endangers a multitude of plant and
animal species indigenous to the area;
there is a lucrative illegal wildlife trade; air
and water pollution in Rio de Janeiro, Sao
Paulo, and several other large cities; land
degradation and water pollution caused by
improper mining activities; wetland degra¬
dation; severe oil spills
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endan¬
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
GOOgraphy — note: largest country in
South America; shares common bounda¬
ries with every South American country
except Chile and Ecuador','240e9cff92c1795f3c660fd0f56044be3a507912f92255aa048e43409c95229a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21ca8472b8f8c8bba57ce80eb6c935a05b8924a17bd1d915e8b48a541bdf562c',2010,'IO','British Indian Ocean Territory','geography',352,'Location: archipelago in the Indian Ocean,
south of India, about halfway between
Africa and Indonesia
Geographic coordinates: 6 00 S, 71 30 E;
note— Diego Garcia 7 20 S, 72 25 E
97
THE CIA WORLD FACTBOOK
Map references: Political Map of the
World
Area: total: 54,400 sq km
land: 60 sq km; Diego Garcia 44 sq km
water: 54,340 sq km
note: includes the entire Chagos Archi-
pelago of 55 islands
Area — comparative: land area is about
0.3 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime Claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical marine; hot, humid,
moderated by trade winds
Terrain: flat and low (most areas do not
exceed two meters in elevation)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego
Garcia 15 m
Natural resources: coconuts, fish,
sugarcane
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment — current issues: NA
Geography — note: archipelago of 55
islands; Diego Garcia, largest and south¬
ernmost island, occupies strategic location
in central Indian Ocean; island is site of
joint US-UK military facility
Location: Caribbean, between the
Caribbean Sea and the North Adantic
Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
98
BRITISH VIRGIN ISLANDS
Map references: Central America and the
Caribbean
Area:
total: 1 53 sq km
land: 153 sq km
water: 0 sq km
note: comprised of 16 inhabited and more
than 20 uninhabited islands; includes the
islands of Tortola, Anegada, Virgin Gorda,
Jost van Dyke
Area — comparative: about 0.9 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volcanic
islands steep, hilly
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use: arable land: 20%
permanent crops: 6.67%
other: 73.33% (2005)
Irrigated land: NA
Natural hazards: hurricanes and tropical
storms (July to October)
Environment — current issues: limited
natural fresh water resources (except
for a few seasonal streams and springs
on Tortola, most of the islands’ water
supply comes from wells and rainwater
catchments)
Geography — note: strong ties to nearby
US Virgin Islands and Puerto Rico
Location: Southeastern Asia, bordering
the South China Sea and Malaysia
Geographic coordinates: 4 30 N, 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5,270 sq km
water: 500 sq km
Area — comparative: slightly smaller than
Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm or to
median line
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to moun¬
tains in east; hilly lowland in west
Elevation extremes: lowest point: South
China Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas,
timber
BRUNEI
Land use:
arable land: 2.08%
permanent crops: 0.87%
other: 97.05% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 8.5 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 0.09
per capita: 243 cu m/yr (1994)
Natural hazards: typhoons, earthquakes,
and severe flooding are rare
Environment— current issues: seasonal
smoke/haze resulting from forest fires in','0e04fe8caaa9aa4bdc810fdd264aec771bbd96e88e5d19e1540a5f12cc93aedc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dbe1bb705ce720c659457432243a5b2cfb56c21671238ff39eaa3cabefe85e9',2010,'ID','Indonesia','geography',358,'Environment— international agreements:
party to: Biodiversity, Climate Change, Deser¬
tification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protec¬
tion, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography — note: close to vital sea lanes
through South China Sea linking Indian
and Pacific Oceans; two parts physically
separated by Malaysia; almost an enclave
within Malaysia
Bight, Gulf of Aden, Gulf of Oman, Java
Sea, Mozambique Channel, Persian Gulf,
Red Sea, Savu Sea, Strait of Malacca, Timor
Sea, and other tributary water bodies
Area— comparative: about 5.5 times the
size of the US
Coastline: 66,526 km
Climate: northeast monsoon (December
to April), southwest monsoon (June to
October); tropical cyclones occur during
May/June and October/November in
the northern Indian Ocean and January/
February in the southern Indian Ocean
Terrain: surface dominated by counter¬
clockwise gyre (broad, circular system of
currents) in the southern Indian Ocean;
unique reversal of surface currents in the
northern Indian Ocean; low atmospheric
pressure over southwest Asia from hot,
rising, summer air results in the south¬
west monsoon and southwest-to-northeast
winds and currents, while high pressure
over northern Asia from cold, falling,
winter air results in the northeast monsoon
and northeast-to-southwest winds and
currents; ocean floor is dominated by the
Mid-Indian Ocean Ridge and subdivided
by the Southeast Indian Ocean Ridge,
Southwest Indian Ocean Ridge, and Nine-
tyeast Ridge
Elevation extremes:
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Location: Southeastern Asia, archipelago
between the Indian Ocean and the Pacific
Ocean
Geographic coordinates: 5 00 S, 1 20 00 E
Map references: Southeast Asia
Area: total: 1,919,440 sq km
land: 1 ,826,440 sq km
water: 93,000 sq km
Area — comparative: slightly less than
three times the size of Texas
■''■Mi''
. MALAYSIA
taten . . MALAYSIA
*
«Padimg '' mmmtm summ®
Sumatra _ (Gmtwai
**•1. •***<» 1 f -M,
- ....
£
''•
m pua
SS5 • ■■ ■»'' ■ '' ,t ‘ 0«*‘
=w, ■kst ■
, V , ■ , .. «-
V . — , .% > *. ,V
*». ^ Aa -\\
- _ '' . . _
i
. - . .
. . . . . . . — .
321
THE CIA WORLD FACTBOOK
Land boundaries: total: 2,830 km
border countries: Timor-Leste 228 km,
Malaysia 1,782 km, Papua New Guinea
820 km
Coastline: 54,716 km
Maritime Claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; more
moderate in highlands
Terrain: mostly coastal lowlands; larger
islands have interior mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural
gas, nickel, timber, bauxite, copper, fertile
soils, coal, gold, silver
Land use: arable land: 11.03%
permanent crops: 7.04%
other: 81.93% (2005)
Irrigated land: 45,000 sq km (2003)
Total renewable water resources: 2,838
cu km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 82.78 cu km/yr
(8%/l %/9 1 %)
per capita: 372 cu m/yr (2000)
Natural hazards: occasional floods; severe
droughts; tsunamis; earthquakes; volca¬
noes; forest fires
Environment— current issues: deforesta¬
tion; water pollution from industrial wastes,
sewage; air pollution in urban areas; smoke
and haze from forest fires
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conser¬
vation
Geography — note: archipelago of 17,508
islands (6,000 inhabited); straddles equator;
strategic location astride or along major sea
lanes from Indian Ocean to Pacific Ocean
Location: Middle East, bordering the
Gulf of Oman, the Persian Gulf, and the
Caspian Sea, between Iraq and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area: total: 1.648 million sq km
land: 1 .636 million sq km
water: 12,000 sq km
Area — comparative: slightly larger than
Alaska
Land boundaries: total: 5,440 km
border countries: Afghanistan 936 km,
Armenia 35 km, Azerbaijan-proper 432
km, Azerbaijan-Naxcivan exclave 179 km,
Iraq 1,458 km, Pakistan 909 km, Turkey
499 km, Turkmenistan 992 km
Coastline: 2,440 km; note— Iran also
borders the Caspian Sea (740 km)
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: bilateral agree¬
ments or median lines in the Persian Gulf
continental shelf: natural prolongation
Climate: mostly arid or semiarid,
subtropical along Caspian coast
Terrain: rugged, mountainous rim; high,
central basin with deserts, mountains;
small, discontinuous plains along both
coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Kuh-e Damavand 5,671 m
Natural resources: petroleum, natural gas,
coal, chromium, copper, iron ore, lead,
manganese, zinc, sulfur
Land use: arable land: 9.78%
permanent crops: 1.29%
other: 88.93% (2005)
Irrigated land: 76,500 sq km (2003)
Total renewable water resources: 137.5
cu km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 72.88 cu km/yr
(7%/2%/91%)
per capita: 1,048 cu m/yr (2000)
Natural hazards: periodic droughts, floods;
dust storms, sandstorms; earthquakes
Environment— current issues: air
pollution, especially in urban areas, from
vehicle emissions, refinery operations, and
industrial effluents; deforestation; over-
grazing; desertification; oil pollution in the
Persian Gulf; wedand losses from drought;
soil degradation (salination); inadequate
supplies of potable water; water pollution
from raw sewage and industrial waste;
urbanization
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental
Modification, Law of the Sea, Marine Life
Conservation
Geography — note: strategic location on
the Persian Gulf and Strait of Hormuz,
which are vital maritime pathways for
crude oil transport
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, O zone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: focal point for
Southeast Asian sea routes','f7e1c7f186defdf7667ff4cd4082e06841aba0c381fe85d2e349f29aae713b33','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79658ee185fe607465d659b045e70e3d0436cc71d47dc2d590b6a98a4c5059e7',2010,'BG','Bulgaria','geography',368,'Location: Southeastern Europe, bordering
the Black Sea, between Romania and
Turkey
Geographic coordinates: 43 00 N, 25 00
E
Map references: Europe
Area:
total: 110,910 sq km
land: 110,550 sq km
water: 36 0 sq km
Area — comparative: slightly larger than
Tennessee
Land boundaries: total: l ,808 km
border countries: Greece 494 km, Macedonia
148 km, Romania 608 km, Serbia 318 km,
Turkey 240 km
Coastline: 354 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: temperate; cold, damp winters;
hot, dry summers
Terrain: mosdy mountains with lowlands
in north and southeast
Elevation extremes: lowest point: Black
Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead,
zinc, coal, timber, arable land
Land use:
arable land: 29.94%
permanent crops: 1.9%
other: 68.16% (2005)
Irrigated land: 5,880 sq km (2003)
Total renewable water resources: 19.4 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 6.92 cu km/yr (3%/78%/19%)
per capita: 895 cu m/yr (2003)
Natural hazards: earthquakes; landslides
Environment — current issues: air pollu¬
tion from industrial emissions; rivers
polluted from raw sewage, heavy metals,
detergents; deforestation; forest damage
from air pollution and resulting acid rain;
soil contamination from heavy metals from
metallurgical plants and industrial wastes
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endan¬
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location near
Turkish Straits; controls key land routes
from Europe to Middle East and Asia','504f4076b832680597b14c126c3610b80b69b89c941d5bf3a3d142ae6e861ac6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e18b7debc53cdeaca915b1a999b5cc039d26e9740e7358af46ba6751eedb33e7',2010,'BF','Burkina Faso','geography',373,'Location: Western Africa, north of Ghana
Geographic coordinates: 1 3 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area — comparative: slighdy larger than
Colorado
Land boundaries:
total: 3,193 km
border countries: Benin 306 km, Cote
d’Ivoire 584 km, Ghana 549 km, Mali
1,000 km, Niger 628 km, Togo 126 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; warm, dry winters; hot,
wet summers
Terrain: mosdy dat to dissected, undulating
plains; hills in west and southeast
Elevation extremes: lowestpoint: Mouhoun
(Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, limestone,
marble; small deposits of gold, phosphates,
pumice, salt
Land use:
arable land: 17.66%
permanent crops: 0.22 %
other: 82.12% (2005)
Irrigated land: 250 sq km (2003)
Total renewable water resources: 17.5 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.8 cu km/yr
(1 3%/l %/86%)
per capita: 60 cu m/yr (2000)
Natural hazards: recurring droughts
Environment— current issues: recent
droughts and desertification severely
affecting agricultural activities, population
distribution, and the economy; overgrazing;
soil degradation; deforestation
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conser¬
vation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked savanna cut
by the three principal rivers of the Black,
Red, and White Voltas
Location: Southeastern Asia, bordering
the Andaman Sea and the Bay of Bengal,
between Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area: total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area — comparative: slighdy smaller than
Texas
Land boundaries: total: 5,876 km
border countries: Bangladesh 193 km,
China 2,185 km, India 1,463 km, Laos
235 km, Thailand 1 ,800 km
Coastline: 1,930 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical monsoon; cloudy, rainy,
hot, humid summers (southwest monsoon,
June to September); less cloudy, scant rain¬
fall, mild temperatures, lower humidity
no
BURMA
during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep,
rugged highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber,
tin, antimony, zinc, copper, tungsten, lead,
coal, marble, limestone, precious stones,
natural gas, hydropower
Land use:
arable land: 14.92%
permanent crops: 1.31%
other: 83.77% (2005)
Irrigated land: 18,700 sq km (2003)
Total renewable water resources: l ,045.6
cu km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 33.23 cu km/yr (1 %/l %/98%)
per capita: 658 cu m/yr (2000)
Natural hazards: destructive earthquakes
and cyclones; flooding and landslides
common during rainy season (June to
September); periodic droughts
Environment — current issues: deforesta¬
tion; industrial pollution of air, soil, and
water; inadequate sanitation and water
treatment contribute to disease
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Law
of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location near
major Indian Ocean shipping lanes','6d22e54cfed23c1f90c1b4d15ff84ac7164b9cb3f5e7b167abbb56c1187acf32','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cd38bbfe2ff8cdb1b1de2c53d1123e9db00d251f6af4972bddf956d630ba1ba',2010,'BI','Burundi','geography',379,'Location: Central Africa, east of Demo¬
cratic Republic of the Congo
Geographic coordinates: 3 30 s, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,6 50 sq km
water: 2,180 sq km
Area — comparative: slightly smaller than
Maryland
Land boundaries: total: 974 km
border countries: Democratic Republic of
the Congo 233 km, Rwanda 290 km,
Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: equatorial; high plateau with
considerable altitude variation (772 m to
2,670 m above sea level); average annual
temperature varies with altitude from 23
to 17 degrees centigrade but is generally
moderate as the average altitude is about
1,700 m; average annual rainfall is about
114
1 50 cm; two wet seasons (February to May
and September to November), and two dry
seasons (June to August and December to
January)
Terrain: hilly and mountainous, dropping
to a plateau in east, some plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Heha 2,670 m
Natural resources: nickel, uranium, rare
earth oxides, peat, cobalt, copper, plat¬
inum, vanadium, arable land, hydropower,
niobium, tantalum, gold, tin, tungsten,
kaolin, limestone
Land use:
arable land: 35.57%
permanent crops: 13.12%
Other: 51.31% (2005)
Irrigated land: 210 sq km (2003)
Total renewable water resources: 3.6 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.29 cu km/yr (1 7%/6%/77%)
per capita: 38 cu m/yr (2000)
Natural hazards: flooding; landslides;
drought
Environment— current Issues: soil erosion
as a result of overgrazing and the expansion
of agriculture into marginal lands; deforesta¬
tion (little forested land remains because of
uncontrolled cutting of trees for fuel); habitat
loss threatens wildlife populations
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; straddles
crest of the Nile-Congo watershed; the
Kagera, which drains into Lake Victoria, is
the most remote headstream of the White
Nile','4be5c131152f18920897569bfd2ec99845f4e7f99e8242b55c025d4e2867d3ec','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2552fa32f95bff4ffbacbe345561addccd89f00941836562f8e35ce7516385d',2010,'KH','Cambodia','geography',387,'Location: Southeastern Asia, bordering
the Gulf of Thailand, between Thailand,
Vietnam, and Laos
Geographic coordinates:
13 00 N, 105 00 E
Map references: Southeast Asia
Area: total: 181,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area — comparative: slighdy smaller than
Oklahoma
Land boundaries: total: 2,572 km
border countries: Laos 541 km, Thailand
803 km, Vietnam 1,228 km
Coastline: 443 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; rainy, monsoon season
(May to November); dry season (December
to April); little seasonal temperature
variation
Terrain: mostly low, flat plains; mountains
in southwest and north
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phnum Aoral 1,810 m
Natural resources: oil and gas, timber,
gemstones, iron ore, manganese, phos¬
phates, hydropower potential
Land use: arable land: 20.44%
permanent crops: 0.59%
other: 78.97% (2005)
Irrigated land: 2,700 sq km (2003)
Total renewable water resources: 476.1
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 4.08 cu
km/yr (l%/0%/98%)
per capita: 290 cu m/yr (2000)
Natural hazards: monsoonal rains (June to
November); flooding; occasional droughts
Environment — current issues: illegal
logging activities throughout the country
and strip mining for gems in the western
region along the border with Thailand
have resulted in habitat loss and declining
biodiversity (in particular, destruction
of mangrove swamps threatens natural
fisheries); soil erosion; in rural areas, most
of the population does not have access to
potable water; declining fish stocks because
of illegal fishing and overfishing
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 94, Wetlands, Whaling signed, but
not ratified: Law of the Sea
Geography — note: a land of paddies and
fb rests dominated by the Mekong River
and Tonle Sap','5074aaa37872ab924f6cc99dba25dfda2684571316e4d4c15fd73e1e383a230d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5514edcb1431bdeb173f522ee72da5dbe62d3c85eb7d583a9f793d3f1d33eead',2010,'CM','Cameroon','geography',395,'Location: Western Africa, bordering the
Bight of Biafra, between Equatorial Guinea
and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area:
total: 475,440 sq km
land: 469,440 sq km
water: 6,000 sq km
Area — comparative: slighdy larger than
California
Land boundaries: total 4,591 km
border countries: Central African Republic
797 km, Chad 1,094 km, Republic of the
Congo 523 km, Equatorial Guinea 189
km, Gabon 298 km, Nigeria 1,690 km
Coastline: 402 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
Climate: varies with terrain, from tropical
along coast to semiarid and hot in north
Terrain: diverse, with coastal plain in
southwest, dissected plateau in center,
mountains in west, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
Manpower fit for military service: males
age 16-49: 2,673,383
females age 16-49: 2,763,256 (2009 est.)
Manpower reaching militarily
significant age annually: male 177,881
female: 175,332 (2009 est.)
Military expenditures: 3% of GDP
(2005 est.)
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area: total: 923,768 sq km
land: 910,768 sq km
water: 13,000 sq km
evidence of increasing efforts to eliminate
trafficking in 2007; in particular, measures
to combat and eliminate traditional slavery
practices were weak; the government’s
overall law enforcement efforts have
stalled from 2006; while efforts to protect','37d21d9a7a5b3a88a056d56d6d22a6546d132766802da0437472e1bc0c95cf2f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14cbae6a1db5f0821b449ad13840a8ffbc7878d02d56270f737b446404d1a5d7',2010,'CA','Canada','geography',400,'Location: Northern North America,
bordering the North Atlantic Ocean on the
east, North Pacific Ocean on the west, and
the Arctic Ocean on the north, north of the
conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area: total: 9,984,670 sq km
land: 9,093,507 sq km
water: 891,163 sq km
Area — comparative: somewhat larger
than the US
Land boundaries: total: 8,893 km
border countries: US 8,893 km (includes
2,477 km with Alaska)
Coastline: 202,080 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: varies from temperate in south to
subarctic and arctic in north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Mount Logan 5,959 m
Natural resources: iron ore, nickel, zinc,
copper, gold, lead, molybdenum, potash,
diamonds, silver, fish, timber, wildlife,
coal, petroleum, natural gas, hydropower
Land use: arable land: 4.57%
permanent crops: 0.65%
other: 94.78% (2005)
Irrigated land: 7,850 sq km (2003)
Total renewable water resources: 3,300
cu km (1985)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 44 72 cu km/yr
(20%/69%/l 2%)
per capita : 1,386 cu m/yr (1996)
Natural hazards: continuous permafrost
in north is a serious obstacle to develop-
ment; cyclonic storms form east of the
Rocky Mountains, a result of the mixing
of air masses from the Arctic, Pacific, and
North American interior, and produce
most of the country’s rain and snow east
of the mountains
Environment — current issues: air pollu¬
tion and resulting acid rain severely
affecting lakes and damaging forests; metal
smelting, coal-burning utilities, and vehicle
emissions impacting on agricultural and
forest productivity; ocean waters becoming
contaminated due to agricultural, indus¬
trial, mining, and forestry activities
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Vola¬
tile Organic Compounds, Marine Life
Conservation
Geography— note: second-largest country
in world (after Russia); strategic location
between Russia and US via north polar
route; approximately 90% of the popula¬
tion is concentrated within 1 60 km of the
US border
Location: Western Africa, group of islands
in the North Atlantic Ocean, west of','9c301f7bc196072a106ed1b172ff2e75b0e12aba2ee33ef098cb03cd5c2042af','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0258fa090452977f3c1b67bd9909b4df2f25fe50874455587a6749f29c8ee2c2',2010,'SN','Senegal','geography',408,'Geographic coordinates: 1 6 00 N, 24 00 W
Map references: Political Map of the
World
Area: total: 4,033 sq km
land: 4,033 sq km
water: 0 sq km
Area — comparative: slightly larger than
Rhode Island
Land boundaries: 0 km
Coastline: 965 km
■ .
Maritime Claims: measured from claimed
archipelagic baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: temperate; warm, dry summer;
precipitation meager and very erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano
on Fogo Island)
Natural resources: salt, basalt rock, lime¬
stone, kaolin, fish, clay, gypsum
Land use: arable land: 11.41%
permanent crops: 0.74%
Other: 87.85% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 0.3 cu
km (1990)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.02 cu km/yr
(7%/2%/91%)
per capita: 39 cu m/yr (2000)
Natural hazards: prolonged droughts;
seasonal harmattan wind produces obscuring
dust; volcanically and seismically active
Environment — current issues: soil
erosion; deforestation due to demand for
wood used as fuel; water shortages; deserti¬
fication; environmental damage has threat¬
ened several species of birds and reptiles;
illegal beach sand extraction; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location 500
km from west coast of Africa near major
north-south sea routes; important commu¬
nications station; important sea and air
refueling site
Location: Western Africa, bordering the
North Atlantic Ocean, between Guinea-
Bissau and Mauritania
Geographic coordinates:
14 00 N, 14 00 W
Map references: Africa
Area: total: 196,190 sq km
land: 192,000 sq km
water: 4,190 sq km
Area — comparative: slighdy smaller than
South Dakota
Land boundaries: total: 2,640 km
border countries: The Gambia 740 km,
Guinea 330 km, Guinea-Bissau 338 km,
Mali 419 km, Mauritania 813 km
Coastline: 531 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical; hot, humid; rainy season
(May to November) has strong southeast
winds; dry season (December to April)
dominated by hot, dry, harmattan wind
Terrain: generally low, rolling, plains rising
to foothills in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen
Diakha 581 m
Natural resources: fish, phosphates, iron ore
Land use: arable land: 12.51%
permanent crops: 0.24%
Other: 87.25% (2005)
Irrigated land: 1,200 sq km (2003)
Total renewable water resources:
39.4 cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 2.22 cu km/yr (4%/3%/93%)
per capita: 190 cu m/yr (2002)
Natural hazards: lowlands seasonally
flooded; periodic droughts
Environment — current issues: wildlife
populations threatened by poaching;
deforestation; overgrazing; soil erosion;
desertification; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: westernmost country
on the African continent; The Gambia is
almost an enclave widiin Senegal','17b32ade0e4c7fe6c33dc03e4bbc039a3313e29be79c85c2375f13fec0b26e36','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15cd4291b7b4e93bcf1e1aec9fd6cce210a9f8a6ee3db879e5b405f19ed36ce3',2010,'KY','Cayman Islands','geography',417,'Location: Caribbean, three-island group
(Grand Cayman, Cayman Brae, Little
Cayman) in Caribbean Sea, 240 km south
of Cuba and 268 km northwest of Jamaica
Geographic coordinates: 19 30 N, 80 30 W
Map references: Central America and the
Caribbean
Area: total: 262 sq km
land: 262 sq km
water: 0 sq km
Area — comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime Claims: territorial sea: 1 2 nm
exclusive fishing zone: 200 nm
Climate: tropical marine; warm, rainy
summers (May to October) and cool,
relatively dry winters (November to April)
Terrain: low-lying limestone base
surrounded by coral reefs
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: The Bluff (Cayman Brae)
43 m
Natural resources: fish, climate and
beaches that foster tourism
Land use: arable land: 3.85%
permanent crops: 0%
Other: 96.15% (2005)
Irrigated land: NA
Natural hazards: hurricanes (July to
November)
Environment — current issues: no
natural fresh water resources; drinking
water supplies must be met by rainwater
catchments
Geography — note: important location
between Cuba and Central America','f8cb4cccde5e93710a7685dd1ca979ab280d8601dafc23806d465e31a6f30282','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af27aee5a604dfb62d574e0e739fbd3c1bf5e4b6149beb661db78b1d1a336328',2010,'CF','Central African Republic','geography',426,'Location: Central Africa, north of Demo¬
cratic Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area: total: 622,984 sq km
land: 622,984 sq km
water: 0 sq km
Area— comparative: slightly smaller than
Texas
Land boundaries: total: 5,203 km
border countries: Cameroon 797 km, Chad
1,197 km, Democratic Republic of the
Congo 1,577 km, Republic of the Congo
467 km, Sudan 1,165 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to
hot, wet summers
Terrain: vast, flat to rolling, monotonous
plateau; scattered hills in northeast and
soudiwest
Elevation extremes: lowest point:
Oubangui River 335 m
highest point: Mont Ngaoui 1 ,420 m
Natural resources: diamonds, uranium,
timber, gold, oil, hydropower
Land use: arable land: 3.1%
permanent crops: 0.15%
other: 96.75% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 144.4
cu km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.03 cu km/yr
(80%/l 6%/4%)
per capita: 7 cu m/yr (2000)
Natural hazards: hot, dry, dusty harmattan
winds affect northern areas; floods are
common
Environment — current issues: tap water
is not potable; poaching has diminished
the country’s reputation as one of the last
great wildlife refuges; desertification; defor¬
estation
Environment— internationalagreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Trop¬
ical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: landlocked; almost the
precise center of Africa','8a54e524aa698b85f6241a64e4776839c07c68c9a2bf1d862ebabd532df6e330','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4ea8c0d3819f6b9abdf6cbfc5be5e705c53dc4e878e326ba7ad9e58599f56c6',2010,'TD','Chad','geography',431,'Location: Central Africa, south of Libya
Geographic coordinates:
15 00 N, 19 00 E
Map references: Africa
Area: total: 1.284 million sq km
land: 1,259,2 00 sq km
water: 24,800 sq km
Area— comparative: slightly more than
three times the size of California
Land boundaries: total: 5,968 km
border countries: Cameroon 1,094 km,
Central African Republic 1,197 km, Libya
1,055 km, Niger 1,175 km, Nigeria 87 km,
Sudan 1 ,360 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center,
desert in north, mountains in northwest,
lowlands in south
Elevation extremes: lowest point: Djourab
Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum, uranium,
natron, kaolin, fish (Lake Chad), gold,
limestone, sand and gravel, salt
Land use: arable land: 2.8%
permanent crops: 0.02%
other: 97.18% (2005)
Irrigated land: 300 sq km (2003)
Total renewable water resources: 43 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.23 cu
km/yr (1 7%/0%/83%)
per capita: 24 cu m/yr (2000)
Natural hazards: hot, dry, dusty harmattan
winds occur in north; periodic droughts;
locust plagues
Environment — current issues: inadequate
supplies of potable water; improper waste
disposal in rural areas contributes to soil
and water pollution; desertification
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea,
Marine Dumping
Geography — note: landlocked; Lake Chad
is the most significant water body in the
Sahel','216a914a335d6aa45f66e066661401a05a444a56c7a3b813acc9512fdb6e73c1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21118dbd6c8789e151f6794074ab77eb785cf4f1f058752e3c9aecee979aa89c',2010,'CL','Chile','geography',439,'Location: Southern South America,
bordering the South Pacific Ocean, between
Argentina and Peru
Geographic coordinates: 30 00 s, 7 1 00 w
Map references: South America
Area: total: 756,950 sq km
land: 748,800 sq km
water: 8,150 sq km
children are trafficked within Chad for
involuntary domestic servitude, forced
cattle herding, forced begging, forced
labor in petty commerce or the fishing
industry, or for commercial sexual exploi¬
tation; to a lesser extent, Chadian children
are also trafficked to Cameroon, die
Central African Republic, and Nigeria for
cattle herding; children may also be traf¬
ficked from Cameroon and the Central
African Republic to Chad’s oil producing
regions for sexual exploitation
tier rating: Tier 2 Watch List— Chad is
on the Tier 2 Watch List for its failure
to provide evidence of increasing efforts
to combat human trafficking in 2007;
Chad was destabilized during 2007 by
civil conflict leading to a declared state of
emergency in February 2008, and a steady
influx of refugees fleeing Sudan and the
Central African Republic; the government
demonstrated insufficient overall efforts to
combat trafficking; Chad has not ratified
the 2000 UN TIP Protocol (2008)
note: includes Easter Island (Isla de
Pascua) and Isla Sala y Gomez
Area — comparative: slightly smaller than
twice the size of Montana
Land boundaries: total: 6,339 km
border countries: Argentina 5,308 km,
Bolivia 860 km, Peru 171 km
Coastline: 6,435 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200/350 nm
Climate: temperate; desert in north;
Mediterranean in central region; cool and
damp in south
Terrain: low coastal mountains; fertile
central valley; rugged Andes in east
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Nevado Ojos del Salado
6,880 m
Natural resources: copper, timber, iron
ore, nitrates, precious metals, molyb¬
denum, hydropower
Land use: arable land: 2.62%
permanent crops: 0.43%
other: 96.95% (2005)
Irrigated land: 19,000 sq km (2003)
Total renewable water resources: 922 cu
km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 12.55 cu
km/yr (1 1%/25%/64%)
per capita: 770 cu m/yr (2000)
139
THE CIA WORLD FACTBOOK
Natural hazards: severe earthquakes;
active volcanism; tsunamis
Environment— current issues: wide¬
spread deforestation and mining threaten
natural resources; air pollution from indus¬
trial and vehicle emissions; water pollution
from raw sewage
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living '' Resources,
Antarctic Seals, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location rela¬
tive to sea lanes between Atlantic and
Pacific Oceans (Strait of Magellan, Beagle
Channel, Drake Passage); Atacama Desert
is one of world’s driest regions
Population:
16,601,707 (July 2009 est.)
Age Structure: 0-14 years: 23.2% (male
1,966,017/female 1,877,963)
15-64 years: 67.8% (male 5,625,963/
female 5,628,146)
65 years and over: 9.1% (male 627,746/
female 875,872) (2009 est.)
Median age: total : 31.4 years
male: 30.4 years
female: 32.4 years (2009 est.)
Population growth rate: 0.881% (2009 est.)
Birth rate: 14.64 births/1,000 population
(2009 est.)
Death rate: 5.77 deaths/1,000 population
(2008 est.)
Net migration rate: NA (2009 est.)
Urbanization: urban population: 88% of
total population (2008)
rate of urbanization: 1.3% annual rate of
change (2005— 1 0 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (2009
est.)
Infant mortality rate: total: 7.71
deaths/1 ,000 live births
male: 8.49 deatlas/1 ,000 live births
female: 6.88 deaths/1,000 live births
(2009 est.)
Life expectancy at birth:
total population: 77.34 years
male: 74.07 years
female: 80.77 years (2009 est.)
Total fertility rate: 1.92 children born/
woman (2009 est.)
HIV/AIDS — adult prevalence rate: 0.3%
(2007 est.)
HIV/AIDS— people living with HIV/AIDS:
31,000 (2007 est.)
HIV/AIDS— deaths: 1,100 (2007 est.)
Nationality: noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerin-
dian 95.4%, Mapuche 4%, other indig¬
enous groups 0.6% (2002 census)
Religions: Roman Catholic 70%, Evangel¬
ical 15.1%, Jehovah’s Witness 1.1%, other
Christian 1%, other 4.6%, none 8.3%
(2002 census)
Languages: Spanish (official), Mapu-
dungun, German, English
Literacy: definition: age 1 5 and over can
read and write
total population: 95.7%
male: 95.8%
female: 95.6% (2002 census)
School life expectancy (primary to
tertiary education): total: 14 years
male: 14 years
female: 14 years (2006)
Education expenditures: 3.2% of GDP
(2006)','9160b0cd242cff77412841a0ca1678353cdbd6155e53065734e5e1747b8ea1a1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18bc46f893f055979548f21bb83bef0a3785d20324ef19f9fb95635b9b76cb39',2010,'CN','China','geography',444,'Location: Eastern Asia, bordering the East
China Sea, Korea Bay, Yellow Sea, and
South China Sea, between North Korea
and Vietnam
Geographic coordinates: 35 00 N,
105 00 E
Map references: Asia
Area: total: 9,596,960 sq km
land: 9,326,410 sq km
water: 270,550 sq km
Area — comparative: slightly smaller than
the US
Land boundaries: total 22,117 km
border countries: Afghanistan 76 km,
Bhutan 470 km, Burma 2,185 km, India
3,380 km, Kazakhstan 1,533 km, North
Korea 1,416 km, Kyrgyzstan 858 km, Laos
423 km, Mongolia 4,677 km, Nepal 1,236
km, Pakistan 523 km, Russia (northeast)
3,605 km, Russia (northwest) 40 km,
Tajikistan 414 km, Vietnam 1,281 km
regional borders: Hong Kong 30 km, Macau
0.34 km
Coastiine: 14,500 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: extremely diverse; tropical in south
to subarctic in north
Terrain: mostly mountains, high plateaus,
deserts in west; plains, deltas, and hills in
east
Elevation extremes: lowest point: Turpan
Pendi -1 54 m
highest point: Mount Everest 8,850 m
Natural resources: coal, iron ore, petro¬
leum, natural gas, mercury, tin, tungsten,
antimony, manganese, molybdenum, vana¬
dium, magnetite, aluminum, lead, zinc,
uranium, hydropower potential (world’s
largest)
Land use: arable land: 14.86%
permanent crops: 1.27%
other: 83.87% (2005)
Irrigated land: 545,960 sq km (2003)
Total renewable water resources: 2,829.6
cu km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 549.76 cu km/yr
(7%/26%/68%)
per capita: 415 cu m/yr (2000)
Natural hazards: frequent typhoons (about
five per year along southern and eastern
coasts); damaging floods; tsunamis; earth¬
quakes; droughts; land subsidence
Environment — current issues: air pollu¬
tion (greenhouse gases, sulfur dioxide
particulates) from reliance on coal produces
acid rain; water shortages, particularly in
the north; water pollution from untreated
wastes; deforestation; estimated loss of
one-fifth of agricultural land since 1949 to
soil erosion and economic development;
desertification; trade in endangered species
Environment — international agree¬
ments: party to: Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: world’s fourth largest
country (after Russia, Canada, and US);
Mount Everest on the border with Nepal is
the world’s tallest peak
Geographic coordinates: 23 30 N, 121
00 E
Map references: Southeast Asia
Area: total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and
Quemoy islands
Area— Comparative: slighdy smaller than
Maryland and Delaware combined
Land boundaries: 0 km
Coastline: 1,566.3 km
Maritime Claims: territorial sea. 12 nm
exclusive economic zone: 200 nm
Climate: tropical; marine; rainy season
during southwest monsoon (June to
August); cloudiness is persistent and exten¬
sive all year
Terrain: eastern two-thirds mostly rugged
mountains; tiat to gendy rolling plains in
west
Elevation extremes: lowest point: South
China Sea 0 m
highest point: Yu Shan 3,952 m
Natural resources: small deposits of
coal, natural gas, limestone, marble, and
asbestos
Land use: arable land: 24%
permanent crops: 1%
other: 75% (2001)
Irrigated land: NA
Total renewable water resources: 67 cu
km (2000)
Natural hazards: earthquakes; typhoons
Environment— current issues: air pollu¬
tion; water pollution from industrial
emissions, raw sewage; contamination of
drinking water supplies; trade in endan¬
gered species; low-level radioactive waste
disposal
Environment— international agreements:
party to: none of the selected agreements
because of Taiwan’s international status
Geography— note: strategic location adja¬
cent to both the Taiwan Strait and the
Luzon Strait','2a56d4c62b0533ae592930ccd314ccdc23fb0a8f7dc42cae30e8a61ce7176a74','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45a06eaa58dd0d8d73d346baa2951625a73821e6063ec6cc2c071fa262af0b84',2010,'CX','Christmas Island','geography',453,'Location: Southeastern Asia, island in the
Indian Ocean, south of Indonesia
Geographic coordinates: 10 30 S, 10540E
country for men, women, and children
trafficked for the purposes of sexual exploi¬
tation and forced labor; the majority of
trafficking in China occurs within the coun¬
try’s borders, but there is also considerable
international trafficking of Chinese citizens
to Africa, Asia, Europe, Latin America, the
Middle East, and North America; Chinese
women are lured abroad through false prom¬
ises of legitimate employment, only to be
forced into commercial sexual exploitation,
largely in Taiwan, Thailand, Malaysia, and
Japan; women and children are trafficked
to China from Mongolia, Burma, North
Korea, Russia, and Vietnam for forced
labor, marriage, and prostitution; some
North Korean women and children seeking
to leave their country voluntarily cross the
border into China and are then sold into
prostitution, marriage, or forced labor
tier rating: Tier 2 Watch List— China is
on the Tier 2 Watch List for the fourth
consecutive year for its failure to provide
evidence of increasing efforts to combat
human trafficking, particularly in terms
of punishment of trafficking crimes and
the protection of Chinese and foreign
victims of trafficking; victims are some¬
times punished for unlawful acts that were
committed as a direct result of their being
trafficked, such as violations of prostitution
or immigration/emigration controls; the
Chinese Government continued to treat
North Korean victims of trafficking solely
as economic migrants, routinely deporting
them back to horrendous conditions in
North Korea; additional challenges facing
the Chinese Government include the
enormous size of its trafficking problem
and the significant level of corruption and
complicity in trafficking by some local
government officials (2008)
illicit drugs: major transshipment point
for heroin produced in the Golden
Triangle region of Southeast Asia; growing
domestic consumption of synthetic drugs,
and heroin from Southeast and Southwest
Asia; source country for methamphetamine
and heroin chemical precursors, despite
new regulations on its large chemical
industry (2008)
Map references: Southeast Asia
Area: total: 135 sq km
land: 135 sq km
water: 0 sq km
Area — comparative: about three-quarters
the size of Washington, DC
Land boundaries: 0 km
147
THE CIA WORLD FACTBOOK
Coastline: 138.9 km
Maritime Claims: territorial sea : 12 nm
contiguous zone: 1 2 nm
exclusive fishing zone: 200 nm
Climate: tropical with a wet season
(December to April) and dry season; heat
and humidity moderated by trade winds
Terrain: steep cliffs along coast rise abruptly
to central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Murray Hill 361 m
Natural resources:
phosphate, beaches
Land use: arable land: 0%
permanent crops: 0%
other: 1 00% (mainly tropical rainforest;
63% of the island is a national park)
(2005)
Irrigated land: NA
Natural hazards: the narrow fringing reef
surrounding the island can be a maritime
hazard
Environment — current issues: loss of
rainforest; impact of phosphate mining
Geography — note: located along major
sea lanes of Indian Ocean
Location: Middle America, atoll in the
North Pacific Ocean, 1,120 km southwest
of Mexico
Geographiccoordinates: 1 0 1 7 N, 1 09 1 3 W
Map references: Political Map of the
World
Area: total: 6 sq km
land: 6 sq km
water: 0 sq km
Area — comparative: about 12 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; humid, average tempera¬
ture 20—32 degrees C, wet season (May to
October)
Terrain: coral atoll
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 1 00% (all coral) (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Geography — note: reef 12 km in circum¬
ference','dc64e97b027e970732630b2a3ba1824fd4d757c76b1f3f8898cdc22cb6aeaadb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0938e04875d87bb0a8c27f5ce71cc8b20ae32f80d7a4ba164d4f679f9bfa071',2010,'CC','Cocos (Keeling) Islands','geography',459,'Location: Southeastern Asia, group of
islands in the Indian Ocean, southwest of
Indonesia, about halfway from Australia to','adf116c8fe0f396fbdc3a1c28303222b3e579467e729bfcd7a2c31325222cab9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8153441a3e317855d264121a146413020f9fe6d9ca09b7c3f5e63b5b69703d7',2010,'LK','Sri Lanka','geography',460,'Geographic coordinates:
12 30 S, 96 50 E
Map references: Southeast Asia
Area: total: 14 sq km
land: 14 sq km
water: 0 sq km
note: includes die two main islands of
West Island and Home Island
149
THE CIA WORLD FACTBOOK
North Keeling
Island
<i 4
« « 8 mi
tn-d''M.
mmmm fill
Homburgh
Island
South
tty
Islands
■ %
vvwfrt
South Island
Area — comparative: about 24 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 26 km
Maritime Claims: territorial sea : 12 nm
exclusive fishing zone: 200 nm
Climate: tropical with high humidity,
moderated by the southeast trade winds for
about nine months of the year
Terrain: flat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: cyclone season is
October to April
Environment — current issues: fresh water
resources are limited to rainwater accumu¬
lations in natural underground reservoirs
Geography— note: islands are thickly
covered with coconut palms and other
vegetation; site of a World War I naval
battle in November 1914 between the
Australian light cruiser HMAS Sydney
and the German raider SMS Emden; after
being heavily damaged in the engagement,
the Emden was beached by her captain on
North Keeling Island
Location: Southern Asia, island in the
Indian Ocean, south of India
Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area: total: 65,610 sq km
land: 64,740 sq km
water: 870 sq km
Area— comparative: slightly larger than
West Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical monsoon; northeast
monsoon (December to March); southwest
monsoon (June to October)
Terrain: mostly low, flat to rolling plain;
mountains in south-central interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite,
mineral sands, gems, phosphates, clay,
hydropower
Land use: arable land: 13.96%
permanent crops: 15.24%
other: 70.8% (2005)
Irrigated land:
7,430 sq km (2003)
Total renewable water resources:
50 cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 12.61 cu km/yr (2%/2%/95%)
per capita: 608 cu m/yr (2000)
Natural hazards:
occasional cyclones and tornadoes
Environment — current issues: defores¬
tation; soil erosion; wildlife populations
threatened by poaching and urbanization;
coastal degradation from mining activities
and increased pollution; freshwater
resources being polluted by industrial
wastes and sewage runoff; waste disposal;
air pollution in Colombo
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conser¬
vation
Geography — note: strategic location near
major Indian Ocean sea lanes','19bf70e0fa9544d7ae6b87bf44fd4efc42dc6eee60d6f313229321c56dd56087','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e296035fd7cb9bb03264e8c36d14c8eb48f9c72342e89c80747862cc8c5a7b',2010,'CO','Colombia','geography',469,'Location: Northern South America,
bordering the Caribbean Sea, between
Panama and Venezuela, and bordering the
North Pacific Ocean, between Ecuador and','8212b748ff003dd9f8ae88daff0b6009cc7f2aaa9a46969d566af905007102b1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('769751a9f2cf536a380f0c9b37bca3d6e96f9991676dc2f603476dc99b4ee40e',2010,'PA','Panama','geography',470,'Geographic coordinates: 4 00 N, 72 00 W
Map references: South America
Area: total: 1,138,910 sq km
land: 1,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador
Cay, and Serrana Bank
Area — comparative: slightly less than
twice the size of Texas
Land boundaries: total: 6,309 km
border countries: Brazil 1,644 km, Ecuador
590 km, Panama 225 km, Peru 1,800 km,
Venezuela 2,050 km
Coastline: 3,208 km (Caribbean Sea 1 ,760
km, North Pacific Ocean 1 ,448 km)
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical along coast and eastern
plains; cooler in highlands
Terrain: flat coastal lowlands, central high¬
lands, high Andes Mountains, eastern
lowland plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pico Cristobal Colon 5,775 m
note: nearby Pico Simon Bolivar also has
the same elevation
Natural resources: petroleum, natural gas,
coal, iron ore, nickel, gold, copper, emer¬
alds, hydropower
Land use:
arable land: 2.01%
permanent crops: 1.37%
Other: 96.62% (2005)
Irrigated land: 9,000 sq km (2003)
Total renewable water resources: 2,132
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 10.71 cu
km/ yr (50%/ 4%/ 46%)
per capita: 235 cu m/yr (2000)
Natural hazards: highlands subject to
volcanic eruptions; occasional earthquakes;
periodic droughts
Environment— current issues: deforesta¬
tion; soil and water quality damage from
overuse of pesticides; air pollution, espe¬
cially in Bogota, from vehicle emissions
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: only South American
country with coastlines on both the North
Pacific Ocean and Caribbean Sea
Background: Explored and settled by the
Spanish in the 1 6th century, Panama broke
with Spain in 1821 and joined a union
of Colombia, Ecuador, and Venezuela-
named the Republic of Gran Colombia.
When the latter dissolved in 1 830, Panama
remained part of Colombia. With US
backing, Panama seceded from Colombia
in 1 903 and promptly signed a treaty with
the US allowing for the construction of a
canal and US sovereignty over a strip of
land on either side of the structure (the
Panama Canal Zone). The Panama Canal
was built by the US Army Corps of Engi¬
neers between 1904 and 1914. In 1977,
an agreement was signed for the complete
transfer of the Canal from the US to
Panama by the end of the century. Certain
portions of the Zone and increasing
responsibility over the Canal were turned
over in the subsequent decades. With
US help, dictator Manuel NORIEGA
was deposed in 1989. The entire Panama
Canal, the area supporting the Canal, and
remaining US military bases were trans¬
ferred to Panama by the end of 1999. In
October 2006, Panamanians approved an
ambitious plan to expand the Canal. The
project, which began in 2007 and could
double the Canal’s capacity, is expected to
be completed in 2014-15.
Location: Central America, bordering both
the Caribbean Sea and the North Pacific
Ocean, between Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 78,200 sq km
land: 75,990 sq km
water: 2,210 sq km
Area — comparative: slightly smaller than
South Carolina
Land boundaries: total: 555 km
border countries: Colombia 225 km, Costa
Rica 330 km
Coastline: 2,490 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm or edge of
continental margin
Climate: tropical maritime; hot, humid,
cloudy; prolonged rainy season (May to
January), short dry season (January to May)
Terrain: interior mostly steep, rugged
mountains and dissected, upland plains;
coastal areas largely plains and rolling hills
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Volcan Baru 3,475 m
Natural resources: copper, mahogany
forests, shrimp, hydropower
Land use: arable land: 7.26%
permanent crops: 1.95%
Other: 90.79% (2005)
Irrigated land: 430 sq km (2003)
Total renewable water resources: 148 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.82 cu km/yr
(67%/5%/28%)
per capita: 254 cu m/yr (2000)
Natural hazards: occasional severe storms
and forest fires in the Darien area
Environment — current issues: water
pollution from agricultural runoff threatens
fishery resources; deforestation of tropical
rain forest; land degradation and soil
erosion threatens siltation of Panama
Canal; air pollution in urban areas; mining
threatens natural resources
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping,
O zone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Marine Life
Conservation
Geography— note: strategic location on
eastern end of isthmus forming land bridge
connecting North and South America;
controls Panama Canal that links North
Atlantic Ocean via Caribbean Sea with
North Pacific Ocean','da9e47f4d32be9fcc0aa3e8b4654fb739b08d8e0910e6eb226edbe6377c69c4b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a011a307a0f6d0ea561abad2bbd006328be33fe0ae6f568a96cc8f6590819079',2010,'KM','Comoros','geography',476,'Location: Southern Africa, group of
islands at the northern mouth of the
Mozambique Channel, about two-thirds of
the way between northern Madagascar and
northern Mozambique
Geographic coordinates: 1 2 1 0 S, 44 1 5 E
Map references: Africa
Area: total: 2,170 sq km
land: 2,170 sq km
water : 0 sq km
154
Area — comparative: slightly more than
12 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims: territorial sea : 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; rainy season
(November to May)
Terrain: volcanic islands, interiors vary
from steep mountains to low hills
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Le Karthala 2,360 m
Natural resources: NEGL
Land use: arable land: 35.87%
permanent crops: 23.32%
other: 40.81% (2005)
Irrigated land: NA
Total renewable water resources: 1.2 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.01 cu
km/yr (48%/5%/47%)
per capita: 13 cu m/yr (1999)
Natural hazards: cyclones possible during
rainy season (December to April); Le
Karthala on Grand Comore is an active
volcano
Environment — current issues: soil
degradation and erosion results from
crop cultivation on slopes without proper
terracing; deforestation
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: important location at
northern end of Mozambique Channel
Location: Central Africa, northeast of','105896be808439de9716b7bec8b48c14934241402b2adfb1e94fb065b25057d0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e14d24c798cf99d55ab6e12e6c01c7604914159c642f24a9e0ed8fc9be4e583e',2010,'CG','Congo','geography',488,'Location: Oceania, group of islands in
the South Pacific Ocean, about half way
between Hawaii and New Zealand
Geographiccoordinates: 21 1 4 S, 1 5946 W
Map references: Oceania
Area: total: 236.7 sq km
land: 236.7 sq km
water: 0 sq km','2385fa0eeff9958285b564ceefbf3f44831a3683a3f96e928ff856e009f427bd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c24a1013bc0dec2c923f231b1753441bfacfa2dcc3e2fd3613a9e01f8143cec9',2010,'NZ','New Zealand','geography',499,'Location: Oceania, islands in the Coral
Sea, northeast of Australia
Geographic coordinates: 1 8 00 S, 1 52 00 E
Map references: Oceania
Area: total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and
reefs scattered over a sea area of about
780,000 sq km with the Willis Islets the
most important
Area — comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime Claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical
Terrain: sand and coral reefs and islands
(or cays)
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location on Cato
Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
other: 1 00% (mostly grass or scrub cover)
(2005)
Irrigated land: 0 sq km
Natural hazards:
occasional tropical cyclones
Environment — current issues: no perma¬
nent fresh water resources
Geography— note: important nesting area
for birds and turtles
Area: total: 268,680 sq km
land: 268,021 sq km
water: NA
note: includes Antipodes Islands, Auck¬
land Islands, Bounty Islands, Campbell
Island, Chatham Islands, and Kermadec
Islands
Area — comparative: about the size of
Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: temperate with sharp regional
contrasts
Terrain: predominately mountainous with
some large coastal plains
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Aoraki-Mount Cook 3,754 m
Natural resources: natural gas, iron ore,
sand, coal, timber, hydropower, gold, lime¬
stone
Land use: arable land: 5.54%
permanent crops: 6.92%
other: 87.54% (2005)
Irrigated land: 2,850 sq km (2003)
Total renewable water resources:
397 cu km (1995)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.11 cu
km/yr (48%/9%/42%)
per capita: 524 cu m/yr (2000)
Natural hazards: earthquakes are common,
though usually not severe; volcanic activity
Environment— current issues: deforesta¬
tion; soil erosion; native flora and fauna
hard-hit by invasive species
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wedands, Whaling
492
signed, but not ratified: Antarctic Seals,
Marine Life Conservation
Geography — note: about 80% of the
population lives in cities; Wellington is
the southernmost national capital in the
world','e95c433750b60fe3322e340259e14f28c3f08dc1830912851cfc22c550940ec8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d57be63de1b342b9fae2b9aca0a95e0edf6e45be90cb9e69bccc0ddaaa1ab6ca',2010,'CR','Costa Rica','geography',504,'Location: Central America, bordering both
the Caribbean Sea and the North Pacific
Ocean, between Nicaragua and Panama
Geographic coordinates: 1 0 00 N, 84 00 W
Map references: Central America and the
Caribbean
Area: total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area— comparative: slightly smaller than
West Virginia
Land boundaries: total: 639 km
border countries: Nicaragua 309 km, Panama
330 km
Coastline: 1,290 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical and subtropical; dry
season (December to April); rainy season
(May to November); cooler in highlands
Terrain: coastal plains separated by
rugged mountains including over 100
volcanic cones, of which several are major
volcanoes
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use: arable land: 4.4%
permanent crops: 5.87%
other: 89.73% (2005)
Irrigated land: 1,080 sq km (2003)
Total renewable water resources: 112.4
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.68 cu
Location: Western Africa, bordering the
North Atlantic Ocean, between Ghana
and Liberia
Geographic coordinates:
8 00 N, 5 00 W
Map references: Africa
Area: total: 322,460 sq km
land: 318,000 sq km
water: 4,460 sq km
Area — comparative: slightly larger than
New Mexico
Land boundaries: total. 3,110 km
border countries: Burkina Faso 584 km,
Ghana 668 km, Guinea 610 km, Liberia
716 km, Mali 532 km
Coastline: 515 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical along coast, semiarid in
far north; three seasons— warm and dry
(November to March), hot and dry (March
to May), hot and wet (June to October)
Terrain: mosdy flat to undulating plains;
mountains in northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1,752 m
Natural resources: petroleum, natural gas,
diamonds, manganese, iron ore, cobalt,
bauxite, copper, gold, nickel, tantalum,
silica sand, clay, cocoa beans, coffee, palm
oil, hydropower
Land use: arable land: 10.23%
permanent crops: 11.16%
other: 78.61% (2005)
Irrigated land: 730 sq km (2003)
Total renewable water resources:
81 cu km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.93 cu km/yr
(24%/l 2%/65%)
per capita: 51 cu m/yr (2000)
Natural hazards: coast has heavy surf and
no natural harbors; during the rainy season
torrential flooding is possible
Environment — current issues: deforesta¬
tion (most of the country’s forests— once the
largest in West Africa— have been heavily
logged); water pollution from sewage and
industrial and agricultural effluents
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: most of the inhabitants
live along the sandy coastal region; apart
from the capital area, the forested interior
is sparsely populated','71f997d8cc08dc568f3fcd8e769f4b6bc8766fff729f707ca5c6c8af991c2431','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c30bdf6ceb202d2c697d22c5ed64358a5274eab532b4987e5d277c1e2f200c',2010,'HR','Croatia','geography',509,'Location: Southeastern Europe, bordering
die Adriatic Sea, between Bosnia and
Herzegovina and Slovenia
Geographic coordinates: 45 10 N,
15 30 E
Map references: Europe
Area: total: 56,542 sq km
land: 56,414 sq km
water: 1 28 sq km
Area — comparative: slighdy smaller than
West Virginia
Land boundaries: total, l ,982 km
border countries: Bosnia and Herzegovina
932 km, Hungary 329 km, Serbia 241 km,
Montenegro 25 km, Slovenia 4 55 km
Coastline: 5,835 km (mainland 1,777 km,
islands 4,058 km)
Maritime Claims: territorial sea: 1 2 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: Mediterranean and continental;
continental climate predominant with hot
summers and cold winters; mild winters,
dry summers along coast
Terrain: geographically diverse; flat plains
along Hungarian border, low mountains
and highlands near Adriatic coastline and
islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1 ,830 m
Natural resources: oil, some coal, bauxite,
low-grade iron ore, calcium, gypsum,
natural asphalt, silica, mica, clays, salt,
hydropower
to provide evidence of increasing efforts to
eliminate trafficking in 2007, particularly
with regard to its law enforcement efforts
and protection of sex trafficking victims;
in addition, Ivoirian law does not prohibit
all forms of trafficking, and Cote d’Ivoire
has not ratified the 2000 UN TIP Protocol
(2008)
Illicit drugs: illicit producer of cannabis,
mostly for local consumption; utility as a
narcotic transshipment point to Europe
reduced by ongoing political instability;
while rampant corruption and inadequate
supervision leave the banking system
vulnerable to money laundering, the lack
qf a developed financial system limits the
country’s utility as a major money-laun¬
dering center (2008)
Land use: arable land: 25.82%
permanent crops: 2.19%
other: 71.99% (2005)
Irrigated land: 110 sq km (2003)
Total renewable water resources: 105.5
cu km (1998)
Natural hazards: destructive earthquakes
Environment— current issues: air pollu¬
tion (from metallurgical plants) and
resulting acid rain is damaging the forests;
coastal pollution from industrial and
domestic waste; landmine removal and
reconstruction of infrastructure consequent
to 1992—95 civil strife
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollu¬
tion-Persistent Organic Pollutants, Air
Pollution-Sulfur 94, Air Pollution-Vola¬
tile Organic Compounds, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: controls most land
routes from Western Europe to Aegean
Sea and Turkish Straits; most Adriatic Sea
islands lie off the coast of Croatia— some
1 ,200 islands, islets, ridges, and rocks','5478b0fb680968d89c309a53bca571dcd686a2fefceea99b790710e7041205c0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a846cba5ee91a8ca7368031fec3cbd6d6458be6ba6fbd963df8ac993cc4ec572',2010,'CU','Cuba','geography',519,'Location: Caribbean, island between the
Caribbean Sea and the North Atlantic
Ocean, 150 km south of Key West,
Florida
Geographic coordinates: 21 30N,8000W
Map references: Central America and the
Caribbean
Area: total: 110,860 sq km
land: 110,860 sq km
water: 0 sq km
Area— comparative: slightly smaller than
Pennsylvania
Land boundaries: total: 29 km
border countries: US Naval Base at Guanta¬
namo Bay 29 km
note: Guantanamo Naval Base is leased by
the US and remains part of Cuba
Coastline: 3,735 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade
winds; dry season (November to April);
rainy season (May to October)
Terrain: mostly flat to rolling plains, with
rugged hills and mountains in the south¬
east
Elevation extremes: lowest point: Carib¬
bean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron
ore, chromium, copper, salt, timber, silica,
petroleum, arable land
Land use: arable land: 27.63%
permanent crops: 6.54%
other: 65.83% (2005)
Irrigated land: 8,700 sq km (2003)
Total renewable water resources: 38.1 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 8.2 cu km/yr
(1 9%/l 2%/ 69%)
per capita: 728 cu m/yr (2000) s .
Natural hazards: the east coast is subject
to hurricanes from August to November
(in general, the country averages about one
hurricane every other year); droughts are
common
Environment — current issues: air
and water pollution; biodiversity loss;
deforestation
Environment — international agree¬
ments: party to: Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conser¬
vation
Geography— note: largest country in
Caribbean and westernmost island of the
Greater Antilles','dbf6a5845f3f807eddd9e3441e5920a0e30b349bd39c709c012e0dbbea9da5be','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8e892db1d35913730faad71c255358cb20fb7488e72b092e48ab69894640563',2010,'CY','Cyprus','geography',529,'Location: Middle East, island in the Medi¬
terranean Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area: total: 9,250 sq km (of which 3,355
sq km are in north Cyprus)
land: 9,240 sq km
water: 10 sq km
Area — comparative: about 0.6 times the
size of Connecticut
Land boundaries: total: 150.4 km
(approximately)
border sovereign base areas: Akrotiri 47.4
km, Dhekelia 103 km (approximately)
Coastline: 648 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: temperate; Mediterranean with
hot, dry summers and cool winters
Terrain: central plain with mountains to
north and south; scattered but significant
plains along southern coast
Elevation extremes: lowest point: Mediter¬
ranean Sea 0 m
highest point: Mount Olympus 1,951 m
Natural resources: copper, pyrites,
asbestos, gypsum, timber, salt, marble, clay
earth pigment
Land use: arable land: 10.81%
permanent crops: 4.32%
other: 84.87% (2005)
Irrigated land: 400 sq km (2003)
Total renewable water resources: 0.4 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.21 cu km/yr
(27 %/l %/7 1 %)
per capita: 250 cu m/yr (2000)
Natural hazards: moderate earthquake
activity; droughts
Environment — current issues: water
resource problems (no natural reservoir
catchments, seasonal disparity in rain¬
fall, sea water intrusion to island’s largest
aquifer, increased salination in the north);
water pollution from sewage and industrial
wastes; coastal degradation; loss of wildlife
habitats from urbanization
Environment— international agreements:
party to: Air Pollution, Air Pollution-
181
THE CIA WORLD FACTBOOK
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
94, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: the third largest island
in the Mediterranean Sea (after Sicily and
Sardinia)
Location: Central Europe, between
Germany, Poland, Slovikia, and Austria
Geographic coordinates: 49 45 N, 1 5 30 E
Map references: Europe
Area: total: 78,866 sq km
land: 77,276 sq km
water: 1 ,590 sq km
Area — comparative: slightly smaller than
South Carolina
Land boundaries: total: 1,989 km
border countries: Austria 362 km, Germany
815 km, Poland 615 km, Slovakia 197 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: Bohemia in the west consists
of rolling plains, hills, and plateaus
surrounded by low mountains; Moravia in
the east consists of very hilly country
Elevation extremes: lowest point: Elbe
River 115m
highest point: Snezka 1 ,602 m
Natural resources: hard coal, soft coal,
kaolin, clay, graphite, timber
Land use: arable land: 38.82%
permanent crops: 3%
other: 58.18% (2005)
Irrigated land: 240 sq km (2003)
Total renewable water resources: 16 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.91 cu
km/yr (41%/57%/2%)
per capita: 187 cu m/yr (2002)
Natural hazards: flooding
Environment— current issues: air and
water pollution in areas of northwest
Bohemia and in northern Moravia around
Ostrava present health risks; acid rain
damaging forests; efforts to bring industry
up to EU code should improve domestic
pollution
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; strategically
located astride some of oldest and most
significant land routes in Europe; Mora¬
vian Gate is a traditional military corridor
between the North European Plain and die
Danube in central Europe','c52196774fc2dd055dad04b7a64b46885f54075c13c74b580bcfaca7a01fa2e4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('331497ebee48bffba508b20b9b22d9304d60715e5ab07bbd3ed001dbbf3142d4',2010,'DK','Denmark','geography',537,'Location: Northern Europe, bordering
the Baltic Sea and the North Sea, on a
peninsula north of Germany (Jutland);
also includes two major islands (Sjaelland
and Fyn)
Geographic coordinates: 56 00 N, 1 0 00 E
Map references: Europe
Area: total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in
the Baltic Sea and the rest of metropolitan
Denmark (the Jutland Peninsula, and the
major islands of Sjaelland and Fyn), but
excludes the Faroe Islands and Greenland
Area— comparative: slightly less than
twice the size of Massachusetts
Land boundaries: total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: temperate; humid and overcast;
mild, windy winters and cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes:
lowest point: Lammefjord -7 m ''
highest point: Yding Skovhoej 173 m
Natural resources: petroleum, natural gas,
fish, salt, limestone, chalk, stone, gravel
and sand
Land use: arable land: 52.59%
permanent crops: 0.19%
other: 47.22% (2005)
Irrigated land: 4,490 sq km (2003)
Total renewable water resources: 6.1 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.67 cu
km/yr (32%/26%/42%)
per capita: 123 cu m/yr (2002)
Natural hazards: flooding is a threat in
some areas of the country (e.g., parts of
Jutland, along the southern coast of the
island of Lolland) that are protected from
the sea by a system of dikes
Environment — current issues: air pollu¬
tion, principally from vehicle and power
plant emissions; nitrogen and phosphorus
pollution of the North Sea; drinking and
surface water becoming polluted from
animal wastes and pesticides
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine
Life Conservation, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: controls Danish Straits
(Skagerrak and Kattegat) linking Baltic and
North Seas; about one-quarter of the popu¬
lation lives in greater Copenhagen
Geographic coordinates: 51 00 N, 9 00 E
Map references: Europe
Area:
total: 357,021 sq km
land: 349,223 sq km
water: 7,798 sq km
Area — comparative: slightly smaller than
Montana
Land boundaries: total: 3,621 km
border countries : Austria 784 km,
Belgium 167 km, Czech Republic 646
km, Denmark 68 km, France 451 km,
Luxembourg 138 km, Netherlands 577
km, Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to th£
depth of exploitation
Climate: temperate and marine; cool,
cloudy, wet winters and summers; occasional
warm mountain (foehn) wind
Terrain: lowlands in north, uplands in
center, Bavarian Alps in south
Elevation extremes: lowest point: Neuen¬
dorf bei Wilster -3.54 m
highest point: Zugspitze 2,963 m
Natural resources: coal, lignite, natural
gas, iron ore, copper, nickel, uranium,
potash, salt, construction materials, timber,
arable land
Land use: arable land: 33.13%
permanent crops: 0.6%
other: 66.27% (2005)
Irrigated land: 4,850 sq km (2003)
Total renewable water resources: 188 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 38.01 cu km/yr (12%/68%/20%)
per capita: 460 cu m/yr (2001)
Natural hazards: flooding
Environment — current issues: emissions
from coal-burning utilities and indus¬
tries contribute to air pollution; acid rain,
resulting from sulfur dioxide emissions, is
damaging forests; pollution in the Baltic Sea
from raw sewage and industrial effluents
from rivers in eastern Germany; hazardous
waste disposal; government established a
mechanism for ending the use of nuclear
power over the next 15 years; government
working to meet EU commitment to iden¬
tify nature preservation areas in line with the
EU’s Flora, Fauna, and Habitat directive
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber
83, T ropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location
on North European Plain and along the
entrance to the Baltic Sea','f11b37fd3bab21711a2a4436af22599f3f67acfc48ed20e56db4ea354862d4d4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22bcb145cfdab86fe126ec9d8fbd989dbc399960230fa21ccbdcfea68ab0ed78',2010,'SE','Sweden','geography',545,'Location: Eastern Mediterranean, on the
southeast coast of Cyprus near Famagusta
Geographic coordinates: 34 59 N, 33
45 E
Map references: Middle East
Area:
total: 1 30.8 sq km
note: area surrounds three Cypriot
enclaves
Area — comparative: about three-quarters
the size of Washington, DC
Land boundaries: total: 103 km (approxi¬
mately)
border countries: Cyprus 103 km (approxi¬
mately)
Coastline: 27.5 km
Climate: temperate; Mediterranean with
hot, dry summers and cool winters
Environment — current issues: netting
and trapping of small migrant songbirds in
the spring and autumn
Geography — note: British extraterritorial
rights also extended to several small off-
post sites scattered across Cyprus; of the
Sovereign Base Area land 60% is privately
owned and farmed, 20% is owned by the
Ministry of Defense, and 20% is SBA
Crown land
Location: Northern Europe, bordering the
Baltic Sea, Gulf of Bothnia, Kattegat, and
Skagerrak, between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
648
land: 410,934 sq km
water: 39,030 sq km
Area — comparative:
slightly larger than California
Land boundaries:
total: 2,233 km
border countries: Finland 614 km, Norway
1,619 km
Coastline: 3,218 km
Maritime Claims: territorial sea: 12 nm
(adjustments made to return a portion of
straits to high seas)
exclusive economic zone: agreed boundaries
or midlines
continental shelf: 200 m depth or to the
depth of exploitation
Climate: temperate in south with cold,
cloudy winters and cool, partly cloudy
summers; subarctic in north
Terrain: mosdy flat or gently rolling
lowlands; mountains in west
Elevation extremes:
lowest point: reclaimed bay of Lake
Hammarsjon, near Kristianstad -2.4 m
highest point: Kebnekaise 2,111 m
Natural resources: iron ore, copper,
lead, zinc, gold, silver, tungsten, uranium,
arsenic, feldspar, timber, hydropower
Land use: arable land: 5.93%
permanent crops: 0.01%
other: 94.06% (2005)
Irrigated land: 1,150 sq km (2003)
Total renewable water resources:
1 79 cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 2.68 cu km/yr (37%/54%/9%)
per capita: 296 cu m/yr (2002)
Natural hazards: ice floes in the
surrounding waters, especially in the Gulf
of Bothnia, can interfere with maritime
traffic
Environment — current issues: acid rain
damage to soils and lakes; pollution of the
North Sea and the Baltic Sea
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endan¬
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location along
Danish Straits linking Baltic and North
Seas','e470b7f78df02c2b0730665c9537b860e69c9aea697af97275b0ba5658b4d8ee','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc24c7809be242a4dcf2bb6e78431e6a9a76b2bb29c2f7b954034c12f62fc7bd',2010,'DJ','Djibouti','geography',549,'Location: Eastern Africa, bordering the
Gulf of Aden and the Red Sea, between
Eritrea and Somalia
Geographic coordinates: 1 1 30 N, 43 00 E
Map references: Africa
Area: total: 23,000 sq km v v
land: 22,980 sq km
water: 20 sq km
Area — comparative: slighdy smaller than
Massachusetts
Land boundaries: total: 516 km
border countries: Eritrea 109 km, Ethiopia
349 km, Somalia 58 km
Coastline: 314 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated
by central mountains
Elevation extremes: lowest point: Lac
Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas, gold,
clay, granite, limestone, marble, salt, diat-
omite, gypsum, pumice, petroleum
Land use: arable land: 0.04%
permanent crops: 0%
other: 99.96% (2005)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 0.3 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.02 cu km/yr
(84%/0%/16%)
per capita: 25 cu m/yr (2000)
Natural hazards: earthquakes; droughts;
occasional cyclonic disturbances from the
Indian Ocean bring heavy rains and flash
floods
Environment — current issues: inadequate
supplies of potable water; limited arable
land; desertification; endangered species
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location near
world’s busiest shipping lanes and close
to Arabian oilfields; terminus of rail traffic
into Ethiopia; mostly wasteland; Lac Assal
(Lake Assal) is the lowest point in Africa','e5587fc74e5722fddcd54a73094c66505a3b7bf07a4749b9c52ef25b1bf26e21','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7f0ade19aea615be5d6c3ffefc12e4dd769ea752f719bff3c46ce5629615802',2010,'DM','Dominica','geography',556,'Location: Caribbean, island between the
Caribbean Sea and the North Atlantic
Ocean, about half way between Puerto Rico
and Trinidad and Tobago
Geographic coordinates:
15 25 N, 61 20 W
Map references: Central America and the
Caribbean
Area: total: 754 sq km
land: 754 sq km
water: 0 sq km
Area — comparative: slightly more than
four times the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by northeast
trade winds; heavy rainfall
Terrain: rugged mountains of volcanic
origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1,447 m
Natural resources: timber, hydropower,
arable land
Land use: arable land: 6.67%
permanent crops: 21.33%
other: 72% (2005)
Irrigated land: NA
Total renewable water resources: NA
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.02 cu km/yr
per capita: 213 cu m/yr (1996)
Natural hazards: flash floods are a constant
threat; destructive hurricanes can be
expected during the late summer months
Environment — current issues: NA
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: known as “The Nature
Island of the Caribbean” due to its spec¬
tacular, lush, and varied flora and fauna,
which are protected by an extensive natural
park system; the most mountainous of the
Lesser Antilles, its volcanic peaks are cones
of lava craters and include Boiling Lake,
the second-largest, thermally active lake in
the world','297332ef64168f03b4097b57b5f340e4300ecb836cab6e0b2f0d1afb44688033','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('612b7824f366650b5e2bbde709b7576a0dcee22cb53458b5ed83db7f4b47fda1',2010,'DO','Dominican Republic','geography',565,'Location: Caribbean, eastern two-drirds
of the island of Hispaniola, between the
Caribbean Sea and the North Adantic
Ocean, east of Haiti
Geographic coordinates: 1900 N, 7040 W
Map references: Central America and the
Caribbean
Area: total: 48,730 sq km
land: 48,380 sq km
•water: 350 sq km
Area — comparative: slightly more than
twice the size of New Hampshire
Land boundaries: total: 360 km
border countries: Haiti 360 km
Coastline: 1,288 km
Maritime Claims: measured from claimed
archipelagic straight baselines
territorial sea: 6 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
199
THE CIA WORLD FACTBOOK
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation
in rainfall
Terrain: rugged highlands and mountains
with fertile valleys interspersed
Elevation extremes: lowest point: Lago
Enriquillo 46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold,
silver
Land use: arable land: 22.49%
permanent crops: 10.26%
other: 67.25% (2005)
Irrigated land: 2,750 sq km (2003)
Total renewable water resources: 21 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 3.39 cu km/yr
(32%/2%/66%)
per capita: 381 cu m/yr (2000)
Natural hazards: lies in the middle of the
hurricane belt and subject to severe storms
from June to October; occasional flooding;
periodic droughts
Environment — current issues: water
shortages; soil eroding into the sea damages
coral reefs; deforestation
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wedands
signed, but not ratified: Law of the Sea
Geography — note: shares island of Hispa¬
niola with Haiti','3104d2998768b54da3a6a3a0b27ed025e7e170b1d60114d24dd3a4b89b658fc8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ccb5435b6a985002f54e398765f16d89d415397ff0f93d6924df952c690994a',2010,'EC','Ecuador','geography',569,'Location: Western South America,
bordering the Pacific Ocean at the Equator,
between Colombia and Peru
Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area: total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area — comparative: slightly smaller than
Nevada
Land boundaries: total: 2,010 km
border countries: Colombia 590 km, Peru
1,420 km
Coastline: 2,237 km
Maritime Claims: territorial sea: 200 nm
continental shelf: 100 nm from 2,500-m
isobath
Climate: tropical along coast, becoming
cooler inland at higher elevations; tropical
in Amazonian jungle lowlands
Terrain: coastal plain (costa), inter-Andean
central highlands (sierra), and flat to rolling
eastern jungle (oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
note: due to the fact that the earth is not a
perfect sphere and has an equatorial bulge,
the highest point on the planet furthest
from its center is Mount Chimborazo
not Mount Everest, which is merely the
highest point above sea-level
Natural resources: petroleum, fish,
timber, hydropower
Land use: arable land: 5.71%
permanent crops: 4.81%
other: 89.48% (2005)
Irrigated land: 8,650 sq km (2003)
Total renewable water resources: 432 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 16.98 cu km/yr
(12%/5%/82%)
per capita: 1,283 cu m/yr (2000)
Natural hazards: frequent earthquakes;
landslides; volcanic activity; floods; peri¬
odic droughts
Environment — current issues: deforesta¬
tion; soil erosion; desertification; water
pollution; pollution from oil production
wastes in ecologically sensitive areas of the
Amazon Basin and Galapagos Islands
Environment— international agree¬
ments: party to: Antarctic-Environmental
Protocol, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: Cotopaxi in Andes is
highest active volcano in world','36c845e1d46ec3eb8ed684d5c3fb9be60236f9976338a88ead4cd83d9138d3cb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce203957325621715712841d571d2bdb688a1381f3eb83a9545f5d5c4674b2e8',2010,'EG','Egypt','geography',579,'Location: Northern Africa, bordering the
Mediterranean Sea, between Libya and
the Gaza Strip, and the Red Sea north
of Sudan, and includes the Asian Sinai
Peninsula
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area: total: 1 ,001 ,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area— comparative: slightly more than
three times the size of New Mexico
Land boundaries: total: 2,665 km
border countries: Gaza Strip 1 1 km, Israel
266 km, Libya 1,115 km, Sudan 1,273
km
Coastline: 2,450 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: desert; hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
Elevation extremes:
lowest point: Qattara Depression -1 33 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas,
iron ore, phosphates, manganese, lime¬
stone, gypsum, talc, asbestos, lead, zinc
Land USe: arable land: 2.92%
permanent crops: 0.5%
other: 96.58% (2005)
Irrigated land: 34,220 sq km (2003)
Total renewable water resources: 86.8 cu
km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 68.3 cu km/yr (8%/6%/86%)
per capita: 923 cu m/yr (2000)
Natural hazards: periodic droughts;
frequent earthquakes; flash floods; land¬
slides; hot, driving windstorm called
khamsin occurs in spring; dust storms;
sandstorms
Environment — current issues: agricultural
land being lost to urbanization and wind¬
blown sands; increasing soil salination
below Aswan High Dam; desertification; oil
pollution threatening coral reefs, beaches,
and marine habitats; other water pollution
from agricultural pesticides, raw sewage,
and industrial effluents; limited natural
fresh water resources away from the Nile,
which is the only perennial water source;
rapid growth in population overstraining
the Nile and natural resources
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
206
Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: controls Sinai Penin¬
sula, only land bridge between Africa and
remainder of Eastern Hemisphere; controls
Suez Canal, a sea link between Indian
Ocean and Mediterranean Sea; size, and
juxtaposition to Israel, establish its major
role in Middle Eastern geopolitics; depend¬
ence on upstream neighbors; dominance
of Nile basin issues; prone to influxes of
refugees
Location: Central America, bordering the
North Pacific Ocean, between Guatemala
and Honduras
Geographic coordinates: 1 3 50 N, 88 55 W
Map references: Central America and the
Caribbean
Area: total: 21,040 sq km
land: 20,720 sq km
water: 320 sq km
Area — comparative: slightly smaller than
Massachusetts
Land boundaries: total: 545 km
border countries: Guatemala 203 km,
Honduras 342 km
Coastline: 307 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (May to
October); dry season (November to April);
tropical on coast; temperate in uplands
a row because it did not provide evidence
of increasing efforts to investigate and pros¬
ecute traffickers; however, in July 2007,
the government established the “National
Coordinating Committee to Combat and
Prevent Trafficking in Persons,” which
improved inter-governmental coordination
on anti-trafficking initiatives; Egypt made
no discernible efforts to punish trafficking
crimes in 2007 and the Egyptian penal
code does not prohibit all forms of traf¬','4a7ae3a72527d1e44cb1baade5a78eede08cc931bcace3e6b39d17a9ca755674','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('face6fe7760debf50c7e183a772a71a045e2a1fe9a22161a8e18ff16e6a26433',2010,'SV','El Salvador','geography',586,'Terrain: mostly mountains with narrow
coastal belt and central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower,
geothermal power, petroleum, arable land
Land use: arable land: 31.37%
permanent crops: 11.88%
other: 56.75% (2005)
Irrigated land: 450 sq km (2003)
Total renewable water resources: 25.2 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.28 cu km/yr
(25%/l 6%/59%)
per capita: 186 cu m/yr (2000)
Natural hazards: known as the Land
of Volcanoes; frequent and sometimes
destructive earthquakes and volcanic
activity; extremely susceptible to hurri¬
canes
Environment— current issues: defor¬
estation; soil erosion; water pollution;
contamination of soils from disposal of
toxic wastes
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: smallest Central
American country and only one without a
coastline on Caribbean Sea','696005a9657ff4017caa4752783d92e352e9764aba0bba9a7df2f711c997e2df','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a5784da51a5ba472185d49ab0c3f7e78767f4658b07ee4b4d8214d21688d6c9',2010,'GA','Gabon','geography',595,'Geographic coordinates:
2 00 N, 10 00 E
Map references: Africa
Area: total: 28,051 sq km
land: 28,051 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Maryland
Land boundaries: total: 539 km
border countries: Cameroon 189 km, Gabon
350 km
Coastline: 296 km
Maritime claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills;
islands are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: petroleum, natural gas,
timber, gold, bauxite, diamonds, tantalum,
sand and gravel, clay
Land use:
arable land: 4.63%
permanent crops: 3.57%
other: 91.8% (2005)
Irrigated land: NA
Total renewable water resources: 26 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.11 cu km/yr
(83%/l 6%/l%)
per capita: 220 cu m/yr (2000)
Natural hazards: violent windstorms;
flash floods
Environment— current issues: tap water
is not potable; deforestation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: insular and continental
regions widely separated
Location: Western Africa, bordering the
Atlantic Ocean at the Equator, between
Republic of the Congo and Equatorial
Location: Western Africa, bordering the
North Atlantic Ocean and Senegal
Geographic coordinates: 1 3 28 N, 16 34 W
Map references: Africa
Area: total: 1 1 ,300 sq km
land: 10,000 sq km *
water: 1 ,300 sq km
Area — comparative: slightly less than
twice the size of Delaware
Land boundaries: total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime Claims: territorial sea: 12 nm •
contiguous zone: 18 nm
exclusive fishing zone: 200 nm
continental shelf: extent not specified
Climate: tropical; hot, rainy season (June to
November); cooler, dry season (November
to May)
Terrain: flood plain of the Gambia River
flanked by some low hills
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish, titanium (rutile
and ilmenite), tin, zircon, silica sand, clay,
petroleum
Land use: arable land: 27.88%
permanent crops: 0.44%
other: 71.68% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 8 cu
km (1982)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.03 cu
km/yr (23%/l 2%/65%)
per capita: 20 cu m/yr (2000)
Natural hazards: drought (rainfall has
dropped by 30% in the last 30 years)
Environment — current issues: deforesta¬
tion; desertification; water-borne diseases
prevalent
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: almost an enclave of
Senegal; smallest country on the continent
of Africa
Location: Middle East, bordering the Medi¬
terranean Sea, between Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area: total: 360 sq km
land: 360 sq km
water: 0 sq km
Area — comparative: slightly more than
twice the size of Washington, DC
Land boundaries: total: 62 km
border countries: Egypt 11 km, Israel
51 km
Coastline: 40 km
Maritime Claims: Israeli-occupied with
current status subject to the Israeli-
Palestinian Interim Agreement— permanent
status to be determined through further
negotiation
Climate: temperate, mild winters, dry and
warm to hot summers
Terrain: flat to rolling, sand- and dune-
covered coastal plain
Elevation extremes: lowest point: Mediter¬
ranean Sea 0 m
highest point: Abu ‘Awdah (Joz Abu ‘Auda)
105 m
Natural resources: arable land, natural
gas
Land USe: arable land: 29%
permanent crops: 21%
other: 50% (2002)
Irrigated land: 155 sq km; (note— includes
West Bank) (2003)
Natural hazards: droughts
Environment — current issues: deserti¬
fication; salination of fresh water; sewage
treatment; water-borne disease; soil degra¬
dation; depletion and contamination of
underground water resources
Geography — note: strategic strip of land
along Mideast-North African trade routes
has experienced an incredibly turbulent
history; the town of Gaza itself has been
besieged coundess times in its history','b48ad20fdbabe12b8e1ed413c3033fbbc08e02c0412f3c99e85745e0dbe7829c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5530132898e03e8392ce8844ec98538f6638e99c891b8fc4acd829be2e22f2d3',2010,'ER','Eritrea','geography',603,'Location: Eastern Africa, bordering the
Red Sea, between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area: total: 121,320 sq km
land: 121,320 sq km
water: 0 sq km
Area — comparative: slightly larger than
Pennsylvania
Land boundaries: total: 1 ,626 km
border countries: Djibouti 109 km, Ethiopia
912 km, Sudan 605 km
Coastline: 2,234 km (mainland on
Red Sea 1,151 km, islands in Red Sea
1,083 km)
Maritime Claims: territorial sea: 12 nm
Climate: hot, dry desert strip along Red
Sea coast; cooler and wetter in the central
highlands (up to 61 cm of rainfall annu¬
ally, heaviest June to September); semiarid
in western hills and lowlands
Terrain: dominated by extension of Ethio¬
pian north-south trending highlands,
descending on the east to a coastal desert
plain, on the northwest to hilly terrain and
on the southwest to flat-to-rolling plains
Elevation extremes: lowest point: near
Kulul within the Danakil depression -75 m
highest point: Soira 3,018 m
Natural resources: gold, potash, zinc,
copper, salt, possibly oil and natural gas,
fish
Land use: arable land: 4.78%
permanent crops: 0.03%
Other: 95.19% (2005)
China for sexual exploitation
tier rating: Tier 2 Watch List— Equatorial
Guinea is on the Tier 2 Watch List for its
failure to provide evidence of increasing
efforts to eliminate trafficking, particu¬
larly in the areas of prosecuting and
convicting trafficking offenders and failing
to formalize mechanisms to provide assist¬
ance to victims; although the government
made some effort to enforce laws against
child labor exploitation, it failed to report
any trafficking prosecutions or convic¬
tions in 2007; the government continued
to lack shelters or formal procedures for
providing care to victims (2008)
Irrigated land: 210 sq km (2003)
Total renewable water resources: 6.3 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.3 cu km/yr
(3%/0%/97%)
per capita: 68 cu m/yr (2000)
Natural hazards: frequent droughts; locust
swarms
Environment — current issues: defor¬
estation; desertification; soil erosion; over-
grazing; loss of infrastructure from civil
warfare
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: strategic geopolitical
position along world’s busiest shipping
lanes; Eritrea retained the entire coastline
of Ethiopia along die Red Sea upon de jure
independence from Ethiopia on 24 May
1993','198da67a1880630fb39f085f06247077df8812b9d42da3b7202e756cc9e5f793','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf5e56981cd2be2756ed6abfdb7a47de8688d057ae74fca3684d7fbe702efac6',2010,'EE','Estonia','geography',613,'Location: Eastern Europe, bordering the
Baltic Sea and Gulf of Finland, between
Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
Area: total: 45,226 sq km
land: 43,21 1 sq km
water: 2,015 sq km
note: includes 1 ,520 islands in the Baltic Sea
Area — comparative: slightly smaller than
New Flampshire and Vermont combined
Land boundaries: total: 633 km
border countries: Latvia 343 km, Russia 290 km
Coastline: 3,794 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: limits fixed in coor¬
dination with neighboring states
Climate: maritime, wet, moderate winters,
cool summers
Terrain: marshy, lowlands; flat in the
north, hilly in the south
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Suur Munamagi 318 m
Natural resources: oil shale, peat, phos¬
phorite, clay, limestone, sand, dolomite,
arable land, sea mud
Land use: arable land: 12.05%
permanent crops: 0.35%
other: 87.6% (2005)
Irrigated land: 40 sq km (2003)
Total renewable water resources: 21.1 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.41 cu
km/yr (56%/39%/5%)
per capita: 1 ,060 cu m/yr (2002)
Natural hazards: sometimes flooding
occurs in the spring
Environment — current issues: air
polluted with sulfur dioxide from oil-
shale burning power plants in northeast;
however, the amount of pollutants emitted
to the air have fallen steadily, die emis¬
sions of 2000 were 80% less than in 1980;
the amount of unpurified wastewater
discharged to water bodies in 2000 was
one-20th the level of 1980; in connection
with the start-up of new water purification
plants, the pollution load of wastewater
decreased; Estonia has more than 1,400
natural and manmade lakes, the smaller
of which in agricultural areas need to be
monitored; coastal seawater is polluted in
certain locations
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Volatile Organic
Compounds, Antarctic Treaty, Biodiver¬
sity, Climate Change, Climate Change-
Kyoto Protocol, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
219
THE CIA WORLD FACTBOOK
Geography — note: the mainland terrain is
flat, boggy, and partly wooded; offshore lie
more than 1,500 islands','36f2b9eb79a59edea32a80917693932780a7c8d743f01dcc78f9dca1373a3167','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('672fe84b7ebf95fc9d8a49df4180f64f93bbb9983566930771b876447ae26e68',2010,'ET','Ethiopia','geography',619,'Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N,
38 00 E
Map references: Africa
Area: total: 1,127,127 sq km
land: 1,119,683 sq km
water: 7,444 sq km
Area— comparative: slightly less than
twice the size of Texas
Land boundaries: total 5,328 km
border countries: Djibouti 349 km, Eritrea
912 km, Kenya 861 km, Somalia 1,600
km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
222
Terrain: high plateau with central moun¬
tain range divided by Great Rift Valley
Elevation extremes:
lowest point: Danakil Depression -1 25 m
highest point: Ras Dejen 4,533 m
Natural resources: small reserves of gold,
platinum, copper, potash, natural gas,
hydropower
Land use: arable land: 10.01%
permanent crops: 0.65%
other: 89.34% (2005)
Irrigated land: 2,900 sq km (2003)
Total renewable water resources: no cu
km (1987)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 5.56 cu km/yr
(6%/0%/94%)
per capita: 72 cu m/yr (2002)
Natural hazards: geologically active Great
Rift Valley susceptible to earthquakes,
volcanic eruptions; frequent droughts
Environment— current issues: deforesta¬
tion; overgrazing; soil erosion; desertifica¬
tion; water shortages in some areas from
water-intensive farming and poor manage¬
ment
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Environmental
Modification, Law of the Sea
Geography— note: landlocked— entire
coastline along the Red Sea was lost with
the de jure independence of Eritrea on 24
May 1993; the Blue Nile, the chief head-
stream of the Nile by water volume, rises
in T’ana Hayk (Lake Tana) in northwest
Ethiopia; three major crops are believed to
have originated in Ethiopia: coffee, grain
sorghum, and castor bean
Location: Europe between the North
Adantic Ocean in the west and Russia,
Belarus, and Ukraine to the east
Map references: Europe
Area: total: 4,324,782 sq km
Area — comparative: less than one-half the
size of the US
Land boundaries: total: 12,440.8 km
border countries: Albania 282 km, Andorra
120.3 km, Belarus 1,050 km, Croatia 999
km, Holy See 3.2 km, Liechtenstein 34.9
km, Macedonia 394 km, Moldova 450 km,
Monaco 4.4 km, Norway 2,348 km, Russia
2,257 km, San Marino 39 km, Serbia 945
km, Switzerland 1,811 km, Turkey 446
km, Ukraine 1,257 km
note: data for European Continent only
Coastline: 65,992.9 km
Maritime claims: NA
Climate: cold temperate; potentially subar¬
ctic in the north to temperate; mild wet
winters; hot dry summers in the south
Terrain: fairly flat along the Baltic and
Atlantic coast; mountainous in the central
and southern areas
Elevation extremes: lowest point: Lammef-
jord, Denmark -7 m; Zuidplaspolder, Neth¬
erlands -7 m
highest point: Mont Blanc 4,807 m; note-
situated on the border between France and','b6d624f066383d7626f2ee597db4ca7d64ee1f4c58f2f98497f3938c26a9d91a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dea3d5faa92098106e0c47737714e7bfd982fde0ed38ff8b253d3945c479364c',2010,'IT','Italy','geography',622,'Natural resources: iron ore, natural gas,
petroleum, coal, copper, lead, zinc, bauxite,
uranium, potash, salt, hydropower/arable
land, timber, fish
Land use:
.arable land: NA
permanent crops: NA
other: NA
Irrigated land: 168,050 sq km (2003 est.)
Natural hazards: flooding along coasts;
avalanches in mountainous area; earth¬
quakes in the south; volcanic eruptions in
Italy; periodic droughts in Spain; ice floes
in the Baltic
Environment— current issues: NA
226
EUROPEAN UNION
Environment— international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulphur 94,
Antarctic-Marine Living Resources, Biodiver¬
sity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94
signed but not ratified: Air Pollution-Volatile
Organic Compounds
Location: Southern South America,
islands in the South Adantic Ocean, east
of southern Argentina
Geographic coordinates:
51 45 S, 59 00 W
Map references: South America
Area:
total: 12,173 sq km
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East
and West Falkland and about 200 small
islands
Area — comparative: slighdy smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime Claims: territorial sea: 12 nm
continental shelf: 200 nm
exclusive fishing zone: 200 nm
Climate: cold marine; strong westerly
winds, cloudy, humid; rain occurs on more
than half of days in year; average annual
rainfall is 24 inches in Stanley; occasional
snow all year, except in January and
February, but does not accumulate
Terrain: rocky, hilly, mountainous with
some boggy, undulating plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, squid, wildlife,
calcified seaweed, sphagnum moss
Land use: arable land: 0%
permanent crops: 0% \\ v
other: 100% (99% permanent pastures,
1% odaer) (2005)
irrigated land: NA
Natural hazards: strong winds persist
diroughout the year
Environment — current issues: overfishing
by unlicensed vessels is a problem; rein¬
deer were introduced to the islands in
2001 for commercial reasons; this is the
only commercial reindeer herd in the
world unaffected by the 1986 Chornobyl
disaster
Geography — note: deeply indented coast
provides good natural harbors; short
growing season
Location: Caribbean, island in the Carib¬
bean Sea, south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the
Caribbean
Area:
total: 10,991 sq km
land: 10,831 sq km
water: 1 60 sq km
Area— comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,022 km
Maritime Claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the
continental margin
Climate: tropical; hot, humid; temperate
interior
Terrain: mostly mountains, with narrow,
discontinuous coastal plain
Elevation extremes: lowest point: Carib¬
bean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, lime¬
stone
Land use: arable land: 15.83%
permanent crops: 10.01%
other: 74.16% (2005)
Irrigated land: 250 sq km (2002)
Total renewable water resources: 9.4 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.41 cu km/yr
(34%/l 7%/49%)
per capita: 155 cu m/yr (2000)
Natural hazards: hurricanes (especially
July to November)
Environment — current issues: heavy rates
of deforestation; coastal waters polluted by
industrial waste, sewage, and oil spills;
damage to coral reefs; air pollution in King¬
ston results from vehicle emissions
Environment— international agreements:
party to: Biodiversity, Climate Change,,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location
between Cayman Trench and Jamaica
Channel, the main sea lanes for the
Panama Canal','81a2c21e49827232c9ee503a3b55d403337e083f455f8d32cc2cdc36a88913dd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2b870ccee3bef7a3b0cf84bcf5d2eac71cfadb394671eceba554f828c16cea6',2010,'FO','Faroe Islands','geography',631,'Location: Northern Europe, island group
between the Norwegian Sea and the North
Atlantic Ocean, about half way between
Iceland and Norway
Geographic coordinates: 62 00 N, 7 00 w
Map references: Europe
Area:
total: 1,399 sq km
land: 1,399 sq km
water: 0 sq km (some lakes and streams)
Area— comparative: eight times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims: territorial sea: 3 nm
continental shelf: 200 nm or agreed
boundaries or median line
exclusive fishing zone: 200 nm or agreed
boundaries or median line
Climate: mild winters, cool summers;
usually overcast; foggy, windy
Terrain: rugged, rocky, some low peaks;
cliffs along most of coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales, hydro¬
power, possible oil and gas
Land use: arable land: 2.14%
permanent crops: 0%
other: 97.86% (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment— current issues: NA
Environment— international agreements:
party to: Marine Dumping— associate
member to the London Convention and
Ship Pollution
Geography— note: archipelago of 17
inhabited islands and one uninhabited
island, and a few uninhabited islets; strate¬
gically located along important sea lanes in
northeastern Atlantic; precipitous tertain
limits habitation to small coastal lowlands','f82cd16486c7f2bb2c3ecb6dbc7c9141e82c30c1f99b4fe5f6cb31271bbaf45f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d60c1f8dbd0d00affb0148af0c73cffed33443457aa423d04f7e1acf18af12a',2010,'FJ','Fiji','geography',639,'Location: Oceania, island group in the
South Pacific Ocean, about two-thirds of
the way from Flawaii to New Zealand
Geographic coordinates: 18 00 S, 175
00 E
Map references: Oceania
Area:
total: 18,270 sq km
land: 18,270 sq km
water: 0 sq km
Area — comparative: slightly smaller than
New Jersey
Land boundaries: 0 km
Coastline: 1,129 km
Maritime Claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation; rectilinear shelf
claim added
Climate: tropical marine; only slight
seasonal temperature variation
Terrain: mosdy mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1 ,324 m
Natural resources: timber, fish, gold,
copper, offshore oil potential, hydropower
Land use: arable land: 10.95%
permanent crops: 4.65%
other: 84-4% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 28.6 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.07 cu
km/yr (1 4%/l 4%/7 1 %)
per capita: 82 cu m/yr (2000)
Natural hazards: cyclonic storms can
occur from November to January
Environment — current issues:
deforestation; soil erosion
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Law
of the Sea, Marine Life Conservation,
Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: includes 332 islands;
approximately 1 1 0 are inhabited','0fcc99e0728d0b391dade4f64d5e80502a35287e27fa0933f30c65c4e4607e85','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b9ec487ded3034a51478bec91060b589dee3e016b17527c44b08c8509be1748',2010,'FI','Finland','geography',648,'Location: Northern Europe, bordering the
Baltic Sea, Gulf of Bothnia, and Gulf of
Finland, between Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area: total: 338,145 sq km
land: 304,473 sq km
water: 33,672 sq km
Area — comparative: slightly smaller than
Montana
Land boundaries: total: 2,654 km
border countries: Norway 727 km, Sweden
614 km, Russia 1,313 km
Coastline: 1,250 km
Maritime Claims: territorial sea: 12 nm (in
the Gulf of Finland— 3 nm)
contiguous zone: 24 nm
exclusive fishing zone: 12 nm; extends to
continental shelf boundary with Sweden
continental shelf: 200 m depth or to the
depth of exploitation
Climate: cold temperate; potentially subar¬
ctic but comparatively mild because of
moderating influence of the North Atlantic
Current, Baltic Sea, and more than 60,000
lakes
and a destination country for a small number
of women from China and India trafficked
for the purposes of forced labor and commer¬
cial sexual exploitation
tier rating: Tier 3— Fiji does not fully comply
with the minimum standards for the elimi¬
nation of trafficking and is not making
significant efforts to do so; the government
has demonstrated no action to investigate or
prosecute traffickers, assist victims, take steps
to reduce the demand for commercial sex acts,
or support any anti-trafficking information or
education campaigns; Fiji has not ratified the
2000 UN TIP Protocol (2008)
Terrain: mostly low, flat to rolling plains
interspersed with lakes and low hills
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Haltiatunmri 1,328 m
Natural resources: timber, iron ore,
copper, lead, zinc, chromite, nickel, gold,
silver, limestone
Land use: arable land: 6.54%
permanent crops: 0.02%
other: 93.44% (2005)
Irrigated land: 640 sq km (2003)
Total renewable wafer resources: 110 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 2.33 cu km/yr
(14%/84%/3%)
per capita: 444 cu m/yr (1999)
Natural hazards: NA
Environment — current issues: air pollu¬
tion from manufacturing and power plants
contributing to acid rain; water pollu¬
tion from industrial wastes, agricultural
chemicals; habitat loss threatens wildlife
populations
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine
237
THE CIA WORLD FACTBOOK
Life Conservation, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selecteci
agreements
Geography — note: long boundary with
Russia; Helsinki is northernmost national
capital on European continent; popula¬
tion concentrated on small southwestern
coastal plain','1471a40c6cf1abeeb9fd584de6dff1fc37c0997b22c28b14636d248ff4d6d09b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8344d25c5c1028a503939e65a06039c83e1e9ee9af40319ac984077bed432f20',2010,'ES','Spain','geography',654,'French Guiana: Northern South America,
bordering the North Adantic Ocean,
between Brazil and Suriname
Guadeloupe: Caribbean, islands between
die Caribbean Sea and the North Adantic
Ocean, southeast of Puerto Rico
Martinique: Caribbean, island between the
Caribbean Sea and North Adantic Ocean,
north of Trinidad and Tobago
Reunion: Southern Africa, island in the
Indian Ocean, east of Madagascar
240
north; the Front and the Current extend
entirely around Antarctica, reaching south
of 60 degrees south near New Zealand and
near 48 degrees south in the far South
Adantic coinciding with the path of the
maximum westerly winds
Location: Southwestern Europe, bordering
the Bay of Biscay, Mediterranean Sea,
North Atlantic Ocean, and Pyrenees
Mountains, southwest of France
Geographic coordinates:
40 00 N, 4 00 W
Map references: Europe
Area: total: 504,782 sq km
land: 499,542 sq km
water: 5,240 sq km
note: there are two autonomous cities—
Ceuta and Melilla— and 17 autonomous
communities including Balearic Islands and
Canary Islands, and three small Spanish
possessions off the coast of Morocco— Islas
acceded to the Antarctic Treaty and which
contributes resources and/or data to IHO
Chart coverage of die area; members of
HCA are Argentina, Australia, Brazil,
Chile, China, Ecuador, France, Germany,
Greece, India, Italy, NZ, Norway, Russia,
South Africa, Spain, UK, and US (2007)
Transportation— note: Drake Passage
offers alternative to transit through the
Panama Canal
Location: Southeastern Asia, group of
reefs and islands in the South China Sea,
about two-thirds of the way from southern
Vietnam to the southern Philippines
Geographic coordinates:
8 38 N, 111 55 E
Map references:
Southeast Asia
Area:
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs,
and sea mounts scattered over an area of
nearly 410,000 sq km of the central South
China Sea
Area — comparative: NA
Land boundaries: 0 km
Coastline:
926 km
Maritime claims: NA
Climate:
tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on
Southwest Cay 4 m
Natural resources: fish, guano, undeter¬
mined oil and natural gas potential
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land:
0 sq km
Natural hazards: typhoons; numerous
reefs and shoals pose a serious maritime
hazard
Environment — current issues: NA
Geography — note: strategically located
near several primary shipping lanes in
the central South China Sea; includes
numerous small islands, atolls, shoals, and
coral reefs','9fa17973ee44e4dfc94bfbfcce024dac106f66ed59f55862838a07d41c83a3da','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b27fa4daa618fde7c45625611fa006921d321da1e6ddc2656942af30b4d50dd',2010,'PF','French Polynesia','geography',660,'Location: Oceania, archipelagoes in
the South Pacific Ocean about half way
between South America and Australia
Geographic coordinates: 15 00 S, 140
00 w
Map references: Oceania
Area: total: 4,167 sq km (118 islands and
atolls)
land: 3,660 sq km
water: 50 7 sq km
Area — comparative: slighdy less than
one-third the size of Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands
and low islands with reefs
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Mont Orohena 2,241 m
Natural resources: timber, fish, cobalt,
hydropower
Land use: arable land: 0.75%
permanent crops: 5.5%
other: 93.75% (2005)
Irrigated land: 10 sq km (2003)
Natural hazards: occasional cyclonic
storms in January
Environment— current issues: NA
Geography — note: includes five archipela¬
goes (four volcanic, one coral); Makatea
in French Polynesia is one of the three
great phosphate rock islands in the Pacific
Ocean— the others are Banaba (Ocean
Island) in Kiribati and Nauru
Location: southeast and east of Africa,
islands in the southern Indian Ocean,
some near Madagascar and others about
equidistant between Africa, Antarctica,
and Australia; note— French Southern and
Antarctic Lands include He Amsterdam,
He Saint-Paul, lies Crozet, lies Kerguelen,
Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island, and
Tromelin Island in the southern Indian
Ocean, along with the French-claimed
sector of Antarctica, “Adelie Land”; the
US does not recognize the French claim to
“Adelie Land”
Geographic coordinates: lie Amsterdam
file Amsterdam et lie Saint-Paul ): 37 50 S,
77 32 E
He Saint-Paul file Amsterdam et He Saint-
Paul): 38 72 S, 77 53 E
lies Crozet: 46 25 S, 51 00 E
lies Kerguelen: 49 15 S, 69 35 E
Bassas da India files Eparses): 21 30 S, 39 50 E
Europa Island files Eparses): 22 20 S, 40 22 E
Glorioso Islands files Eparses): 1 1 30 S, 47 20 E
Juan de Nova Island files Eparses): 17 03
S, 42 45 E
Tromelin Island files Eparses): 15 52 S, 54
25 E
Map references: Antarctic Region, Africa
Area: He Amsterdam file Amsterdam et He
Saint-Paul): total— 55 sq km; land— 55 sq
km; water— 0 sq km
He Saint-Paul file Amsterdam et He Saint-
Paul): total— 7 sq km; land— 7 sq km;
water— 0 sq km
lies Crozet: total— 352 sq km; land— 352 sq
km; water— 0 sq km
lies Kerguelen: total— 7,215 sq km; land—
7,215 sq km; water— 0 sq km
Bassas da India files Eparses): total— 80 sq km;
land— 0.2 sq km; water— 79.8 sq km (lagoon)
Europa Island files Eparses): total— 28 sq km;
land— 28 sq km; water— 0 sq km
Glorioso Islands files Eparses ): total— 5 sq km;
land— 5 sq km; water— 0 sq km
Juan de Nova Island files Eparses): total— 4-4
sq km; land^L4 sq km; water— 0 sq km
Tromelin Island files Eparses): total— 1 sq
km; land— 1 sq km; water— 0 sq km
note: excludes “Adelie Land” claim of
about 500,000 sq km in Antarctica that is
not recognized by the US
Area — comparative: He Amsterdam file
Amsterdam et He Saint-Paul): less than one-
half the size of Washington, DC
lie Saint-Paul file Amsterdam et He Saint-
Paul): more than 10 times the size of The
Mall in Washington, DC
lies Crozet: about twice the size of Wash¬
ington, DC
lies Kerguelen: slightly larger than Delaware
Bassas da India files Eparses): land area
about one-third the size of The Mall in
Washington, DC
Europa Island files Eparses): about one-sixth
the size of Washington, DC
Glorioso Islands files Eparses): about eight
times the size of The Mall in Wash¬
ington, DC
Juande Nova Island files Eparses): about seven
times the size ofThe Mall in W ashington , DC
Tromelin Island files Eparses): about 1 .7 times
the size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: lie Amsterdam (lie Amsterdam et
lie Saint-Paul): 28 km
He Saint-Paul file Amsterdam et He Saint-Paul):
lies Kerguelen: 2,800 km
Bassas da India (lies Eparses): 35.2 km
Europa Island files Eparses): 22.2 km
Glorioso Islands files Eparses): 35.2 km
Juan de Nova Island files Eparses): 24.1 km
Tromelin Island files Eparses): 3.7 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm from
lies Kerguelen and lies Eparses (does not
include the rest of French Southern and
Antarctic Lands); Juan de Nova Island and
Tromelin Island claim a continental shelf of
200-m depth or to the depth of exploitation
Climate: He Amsterdam et He Saint-Paul:
oceanic with persistent westerly winds and
high humidity
lies Crozet: windy, cold, wet, and cloudy
lies Kerguelen: oceanic, cold, overcast, windy
lies Eparses: tropical
Terrain: He Amsterdam file Amsterdam et
lie Saint-Paul): a volcanic island with steep
coastal cliffs; the center floor of the volcano
is a large plateau
He Saint-Paul file Amsterdam et He Saint-
Paul): triangular in shape, the island is the
top of a volcano, rocky with steep cliffs on
the eastern side; has active thermal springs
248
FRENCH SOUTHERN AND ANTARCTIC LANDS
lies Crozet: a large archipelago formed
from the Crozet Plateau is divided into two
groups of islands
lies Kerguelen: the interior of the large
island of lie Kerguelen is composed of
rugged terrain of high mountains, hills,
valleys, and plains with a number of penin¬
sulas stretching off its coasts
Bassas da India ( lies Eparses): atoll, awash
at high tide; shallow (1 5 m) lagoon
Europa Island, Glorioso Islands, Juan de
Nova Island: low, flat, and sandy
Tromelin Island ( lies Eparses ): low, flat,
sandy; likely volcanic seamount
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Mont de la Dives on lie
Amsterdam (He Amsterdam et He Saint-
Paul) 867 m; unnamed location on He
Saint-Paul (He Amsterdam et He Saint-Paul)
272 m; Pic Marion-Dufresne in lies Crozet
1,090 m; Mont Ross in lies Kerguelen
1,850 m; unnamed location on Bassas de
India (lies Eparses) 2.4 m; unnamed loca¬
tion on Europa Island (lies Eparses) 24
m; unnamed location on Glorioso Islands
(lies Eparses) 12 m; unnamed location on
Juan de Nova Island (lies Eparses) 10 m;
unnamed location on Tromelin Island
(lies Eparses) 7 m
Natural resources: fish, crayfish
note: Glorioso Islands and Tromelin
Island (lies Eparses) have guano, phos¬
phates, and coconuts
Land use: He Amsterdam (He Amsterdam
et He Saint-Paul)— 1 00% trees, grasses, ferns,
and moss; He Saint-Paul (He Amsterdam
et He Saint-Paul)— 1 00% grass, ferns, and
moss; lies Crozet— 100% tossock grass,
heath, and fern; lies Kerguelen— 100%
tossock grass and Kerguelen cabbage;
Bassas da India (lies Eparses)— 100%
rock, coral reef, and sand; Europa Island
(lies Eparses)— 1 00% mangrove swamp
and dry woodlands; Glorioso Islands
(lies Eparses)— 1 00% lush vegetation and
coconut palms; Juan de Nova Island (lies
Eparses)— 90% forest, 10% other; Tromelin
Island (lies Eparses)— 1 00% grasses and
scattered brush (2005)
Irrigated land: 0 sq km
Natural hazards: He Amsterdam and
He Saint-Paul are inactive volcanoes; lies
Eparses subject to periodic cyclones; Bassas
da India is a maritime hazard since it is
under water for a period of three hours
prior to and following the high tide and
surrounded by reefs
Environment — current issues: intro¬
duction of foreign species on lies Crozet
has caused severe damage to the original
ecosystem; overfishing of Patagonian
toothfish around lies Crozet and lies
Kerguelen
Geography — note: islands component is
widely scattered across remote locations in
the southern Indian Ocean
Bassas da India ( lies Eparses ): the atoll is
a circular reef that sits atop a long-extinct,
submerged volcano
Europa Island and Juan de Nova Island files
Eparses ): wildlife sanctuary for seabirds and
sea turtles
Glorioso Island files Eparses): the islands and
rocks are surrounded by an extensive reef
system
Tromelin Island files Eparses ): climato-
logically important location for forecasting
cyclones in the western Indian Ocean;
wildlife sanctuary (seabirds, tortoises)','c0207cd62a746ac60f2bf405e8996acbd8c47f763a536b43af22e1bf0a0768f4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('597178396009dd2546e3daa8022ce3ff6acc9bb4f740573942a7fa21f34baa67',2010,'GN','Guinea','geography',666,'Geographic coordinates: 1 00 S, 1 1 45 E
Map references: Africa
Area:
total: 267,667 sq km
land: 257,667 sq km
water: 10,000 sq km
Area— comparative: slightly smaller than
Colorado
Land boundaries: total: 2,551 km
border countries: Cameroon 298 km,
Republic of the Congo 1 ,903 km,
Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior;
savanna in east and south
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mont Iboundji 1,575 m
Natural resources: petroleum, natural gas,
diamond, niobium, manganese, uranium,
gold, timber, iron ore, hydropower
Land use: arable land: 1.21%
permanent crops: 0.64%
Other: 98.15% (2005)
Irrigated land: 70 sq km (2003)
Total renewable water resources: 164 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.12 cu
km/yr (50%/8%/42%)
per capita: 87 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: deforesta¬
tion; poaching
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: a small population
and oil and mineral reserves have helped
Gabon become one of Africa’s wealthier
countries; in general, these circumstances
have allowed the country to maintain and
conserve its pristine rain forest and rich
biodiversity
Location: Western Africa, bordering the
North Adantic Ocean, between Guinea-
Bissau and Sierra Leone
Geographic coordinates: li oo N, 10 00 w
Map references: Africa
Area: total: 245,857 sq km
land: 245,857 sq km
water: 0 sq km
Area — comparative: slighdy smaller than
Oregon
Land boundaries: total. 3,399 km
border countries: Cote d’Ivoire 610 km,
Guinea-Bissau 386 km, Liberia 563 km,
Mali 858 km, Senegal 330 km, Sierra
Leone 652 km
Coastline: 320 km
Maritime claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: generally hot and humid;
monsoonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeast¬
erly harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
Elevation extremes: lowest point: Adantic
Ocean 0 m
highest point: Mont Nimba 1,752 m
Natural resources: bauxite, iron ore,
diamonds, gold, uranium, hydropower,
fish, salt
Land use: arable land: 4.47%
permanent crops: 2.64%
other: 92.89% (2005)
Irrigated land: 950 sq km (2003)
Total renewable water resources: 226 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.51 cu
km/yr (8%/2%/90%)
per capita : 161 cu m/yr (2000)
Natural hazards: hot, dry, dusty harmattan
haze may reduce visibility during dry
season
Environment — current issues: deforests
don; inadequate supplies of potable water;
desertification; soil contamination and
erosion; overfishing, overpopulation in
forest region; poor mining practices have
led to environmental damage
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protec¬
tion, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: the Niger and its
important tributary the Milo have their
sources in the Guinean highlands
Geographic coordinates:
8 00 S, 159 00 E
Map references: Oceania
Area: total: 28,450 sq km
land: 27,540 sq km
water: 910 sq km
Area — comparative:
slighdy smaller than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime Claims: measured from
claimed archipelagic baselines
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical monsoon; few extremes
of temperature and weather
Terrain: mostly rugged mountains with
some low coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu
2,447 m
Natural resources: fish, forests, gold,
bauxite, phosphates, lead, zinc, nickel
Land use: arable land: 0.62%
permanent crops: 2.04%
other: 97.34% (2005)
Irrigated land: NA
Total renewable water resources:
44.7 cu km (1987)
Natural hazards: typhoons, but rarely
destructive; geologically active region
with frequent earthquakes, tremors, and
volcanic activity; tsunamis
Environment — current issues: deforesta¬
tion; soil erosion; many of the surrounding
coral reefs are dead or dying
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Environmental Modifica¬
tion, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location
on sea routes between the South Pacific
Ocean, the Solomon Sea, and the Coral
Sea; on 2 April 2007 an undersea earth¬
quake measuring 8.1 on the Richter scale
occurred 345 km WNW of the capital
Honiara, the resulting tsunami devas¬
tated coastal areas of Western and Choi-
seul provinces with dozens of deaths and
thousands dislocated; the provincial capital
of Gizo was especially hard hit','7b40b38e7f84a4d60e75a6a18a21dc251b3923076aba656df461e34641769a16','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b26ae3f8fa5a05998c0b15ada2cc581e53afaf4a8f51edefed7ea1ffdaf134',2010,'GE','Georgia','geography',672,'Location: Southwestern Asia, bordering
the Black Sea, between Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Asia
Area:
total: 69,700 sq km
land: 69,700 sq km
water: 0 sq km
Area — comparative: slighdy smaller than
South Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km,
Azerbaijan 322 km, Russia 723 km, Turkey
252 km
Coastline: 310 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: warm and pleasant; Mediterra-
nean-like on Black Sea coast
Terrain: largely mountainous with Great
Caucasus Mountains in the north and
Lesser Caucasus Mountains in the south;
Kolkhet’is Dablobi (Kolkhida Lowland)
opens to the Black Sea in the west; Mtkvari
River Basin in the east; good soils in river
valley flood plains, foothills of Kolkhida
Lowland
Elevation extremes: lowest point: Black
Sea 0 m
highest point: Mt’a Shkhara 5,201 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper,
minor coal and oil deposits; coastal climate
and soils allow for important tea and citrus
growth
Land use: arable land: 11.51%
permanent crops: 3.79%
other: 84.7% (2005)
Irrigated land: 4,690 sq km (2003)
Total renewable water resources: 63.3 cu
km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.61 cu
km/yr (20%/21%/59%)
per capita: 808 cu m/yr (2000)
Natural hazards: earthquakes
Environment — current issues: air
pollution, particularly in Rust’avi; heavy
258
pollution of Mtkvari River and the Black
Sea; inadequate supplies of potable water;
soil pollution from toxic chemicals
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: strategically located
east of the Black Sea; Georgia controls
much of the Caucasus Mountains and the
routes through them
Land boundaries: total: 1,703 km
border countries: Brazil 593 km, French
Guiana 510 km, Guyana 600 km
Coastline: 386 km
Maritime claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade
winds
Terrain: mostly rolling hills; narrow coastal
plain with swamps
Elevation extremes: lowest point: unnamed
location in the coastal plain -2 m
highest point: Juliana Top 1,230 m
Natural resources: timber, hydropower,
fish, kaolin, shrimp, bauxite, gold, and
small amounts of nickel, copper, platinum,
iron ore
Land use: arable land: 0.36%
permanent crops: 0.06%
other: 99.58% (2005)
Irrigated land:
510 sq km (2003)
Total renewable water resources:
1 22 cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.67 cu
km/yr (4%/3%/93%)
per capita: 1 ,489 cu m/yr (2000)
Natural hazards: NA
Environment — current issues:
deforestation as timber is cut for export;
641
THE CIA WORLD FACTBOOK
pollution of inland waterways by small-scale
mining activities
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Law
of the Sea, Marine Dumping, O zone
Layer Protection, Ship Pollution, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: smallest independent
country on South American continent;
mostly tropical rain forest; great diversity
of flora and fauna that, for the most part,
is increasingly threatened by new develop¬
ment; relatively small population, mostly
along the coast
Land boundaries:
total: 1 ,424 km
border countries: Algeria 965 km, Libya 459
km
Coastline: 1,148 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 1 2 nm
Climate: temperate in north with mild,
rainy winters and hot, dry summers; desert
in south
Terrain: mountains in north; hot, dry
central plain; semiarid south merges into
the Sahara
Elevation extremes: lowest point: shatt al
Gharsah -1 7 m
highest point: Jebel ech Chambi 1,544 m
Natural resources: petroleum, phos¬
phates, iron ore, lead, zinc, salt
Land use: arable land: 17.05%
permanent crops: 13.08%
other : 69.87% (2005)
Irrigated land: 3,940 sq km (2003)
Total renewable water resources: 4.6 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.64 cu
km/yr (1 4%/4%/82%)
per capita: 261 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: toxic and
hazardous waste disposal is ineffective and
poses health risks; water pollution from
raw sewage; limited natural fresh water
resources; deforestation; overgrazing; soil
erosion; desertification
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Lawofthe
Sea, Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conser¬
vation
Geography — note: strategic location in
central Mediterranean; Malta and Tunisia
are discussing the commercial exploitation
of the continental shelf between their coun¬
tries, particularly for oil exploration','b7048877164155a176cb819cea7d6a1e58a4f26188d1abcfa881867df7dc5ec0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3eff81eed5b0a3bc47948a7545bdfc69cecf5d4f138f86a59fe764d306bb8b6',2010,'DE','Germany','geography',680,'Location: Central Europe, bordering the
Baltic Sea and the North Sea, between
the Netherlands and Poland, south of
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area: total: 41,526 sq km
land: 33,883 sq km
water: 7,643 sq km
Area— comparative: slightly less than
twice the size of New Jersey
Land boundaries: total 1,027 km
border countries: Belgium 450 km, Germany
577 km
Coastline: 451 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive fishing zone: 200 nm
Climate: temperate; marine; cool summers
and mild winters
Terrain: mostly coastal lowland and
reclaimed land (polders); some hills in
southeast
Elevation extremes:
lowest point: Zuidplaspolder -7 m
highest point: Vaalserberg 322 m
Natural resources: natural gas, petroleum,
peat, limestone, salt, sand and gravel,
arable land
Land use: arable land: 21.96%
permanent crops: 0.77%
other: 77.27% (2005)
Irrigated land: 5,650 sq km (2003)
Total renewable water resources:
89.7 cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total 8.86 cu
km/ yr (6%/ 60%/34%)
per capita: 544 cu m/yr (2001)
Natural hazards: flooding
Environment — current issues: water
pollution in the form of heavy metals,
organic compounds, and nutrients such as
nitrates and phosphates; air pollution from
vehicles and refining activities; acid rain
Environment— international agreements:
party to : Air Pollution , Air Pollution-N itrogen
Oxides, Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulfur 85, Air
Pollution-Sulfur 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environ¬
mental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Kyoto Protocol, Law
of the Sea, Marine Dumping, Marine
Life Conservation, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: located at mouths of
three major European rivers (Rhine, Maas
or Meuse, and Schelde)','b69d4906c5634a75a4605d2cb13f175f4b1059479dd5764ffc2a74911ef6cd66','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e8375cdb2886280c0fa8243608bdf70df462c597c3c1718e679cefb302de2f0',2010,'GH','Ghana','geography',688,'Location: Western Africa, bordering the Gulf
of Guinea, between Cote d’Ivoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area: total: 239,460 sq km
land: 230,940 sq km
water: 8,520 sq km
Area — comparative: slightly smaller than
Oregon
Land boundaries:
total: 2,094 km
border countries: Burkina Faso 549 km,
Cote d’Ivoire 668 km, Togo 877 km
Coastline: 539 km
265
THE CIA WORLD FACTBOOK
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; warm and comparatively
dry along southeast coast; hot and humid
in southwest; hot and dry in north
Terrain: mostly low plains with dissected
plateau in south-central area
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, indus¬
trial diamonds, bauxite, manganese, fish,
rubber, hydropower, petroleum, silver,
salt, limestone
Land use:
arable land: 17.54%
permanent crops: 9.22%
other: 73.24% (2005)
Irrigated land: 310 sq km (2003)
Total renewable water resources: 53.2 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 0.98 cu km/yr (24%/l 0%/66%)
per capita: 44 cu m/yr (2000)
Natural hazards: dry, dusty, northeastern
harmattan winds occur from January to
March; droughts
Environment— current issues: recurrent
drought in north severely affects agricul¬
tural activities; deforestation; overgrazing;
soil erosion; poaching and habitat destruc¬
tion threatens wildlife populations; water
pollution; inadequate supplies of potable
water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wedands
signed, but not ratified: Marine Life
Conservation
Geography — note: Lake Volta is the
world’s largest artificial lake','638b81ce000a0b5e853db01842b6c1c4d41a27cbb43083d36e9befff2ee324e7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1958fe3d7b273c174acb0fcc8c24d2f16fde81c3376cc84336fddb1fbab26ab',2010,'GI','Gibraltar','geography',692,'Location: Southwestern Europe, bordering
the Strait of Gibraltar, which links the
Mediterranean Sea and the North Adantic
Ocean, on the southern coast of Spain
Geographic coordinates: 36 08 N, 5 21 w
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
■water: 0 sq km
Area — comparative: slightly less than
one-half the size of Rhode Island
Land boundaries: total: 1.2 km
border countries: Spain 1.2 km
Coastline: 12 km
Maritime Claims: territorial sea: 3 nm
Climate: Mediterranean with mild winters
and warm summers
Terrain: a narrow coastal lowland borders
the Rock of Gibraltar
Elevation extremes: lowest point: Mediter¬
ranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: limited
natural freshwater resources: large concrete
or natural rock water catchments collect
rainwater (no longer used for drinking
water) and adequate desalination plant
Geography — note: strategic location on
Strait of Gibraltar that links the North
Atlantic Ocean and Mediterranean Sea','5c6cdd0d970b8c64c1575ec034e308a813aff3e6247a68fcd51ccaabf6ca2cc0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('418dee56652f1377c55a34b07930cea0f314c9b6a77e79edaf0e19bb38ae61c8',2010,'GR','Greece','geography',700,'Location: Southern Europe, bordering the
Aegean Sea, Ionian Sea, and the Mediter¬
ranean Sea, between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
total: 131,940 sq km
land: 1 30,800 sq km
water: 1,140 sq km
Regiment replaced the last British regular
infantry forces in 1 992
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Infernet Service Providers (ISPs): 1 (2000)
Internet users: 300,000 (2007)','2a7649cdcb62354313a4b514dfd898aef4a9da61847ef055e18b5f70ce240a31','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1640aa424879adedb131bc866756064081c67ed3a6c2f559b8cc06fa4d17092e',2010,'GL','Greenland','geography',707,'Location: Northern North America, island
between the Arctic Ocean, and the North
Atlantic Ocean, northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area: total: 2,166,086 sq km
land: 2,166,086 sq km (410,449 sq km ice-
free, 1,755,637 sq km ice-covered) (2000
est.)
Area— comparative: slightly more than
three times the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime Claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm or agreed
boundaries or median line
continental shelf: 200 nm or agreed bound¬
aries or median line
Climate: arctic to subarctic; cool summers,
cold winters
Terrain: flat to gradually sloping icecap
covers all but a narrow, mountainous,
barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Natural resources: coal, iron ore, lead, zinc,
molybdenum, diamonds, gold, platinum,
niobium, tantalite, uranium, fish, seals,
whales, hydropower, possible oil and gas
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: continuous permafrost
over northern two-thirds of the island
Environment— current issues: protection
of the arctic environment; preservation of
274
the Inuit traditional way of life, including
whaling and seal hunting
Geography — note: dominates North
Adantic Ocean between North America
and Europe; sparse population confined to
small setdements along coast; close to one-
quarter of the population lives in the capital,
Nuuk; world’s second largest ice cap','ec4d9c1ecfade2f68af63a575d568ae640f81e06eade1e17bb4966e4ef751fcb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3e332f4fab095a40251baa3fae141528a0830e5e12d98c1e743f92a501639a8',2010,'GD','Grenada','geography',716,'Location: Caribbean, island between the
Caribbean Sea and Atlantic Ocean, north
of Trinidad and Tobago
Geographic coordinates: 12 07 N, 61 40
W
Map references: Central America and the
Caribbean
Area:
total: 344 sq km
land: 344 sq km
water: 0 sq km
Area — comparative: twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; tempered by northeast
trade winds
Terrain: volcanic in origin with central
mountains
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit,
deepwater harbors
Land use: arable land: 5.88%
permanent crops: 29.41%
other: 64.71% (2005)
Irrigated land: NA
Total renewable water resources: NA
Natural hazards: lies on edge of hurricane
belt; hurricane season lasts from June to
November
Environment— current issues: NA
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change- Kyoto Protocol, Deserti¬
fication, Endangered Species, Law of the
Sea, Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: die administration
of the islands of the Grenadines group is
divided between Saint Vincent and the
Grenadines and Grenada','5f753c17c3b45768fcf67a4db60d10c2b4784014f421aea9957072a3462e4670','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e82060f655f794849265ac36e1a5a734af0a41f174f45edf020ba2cb36a49f',2010,'GU','Guam','geography',725,'Location: Oceania, island in the North
Pacific Ocean, about three-quarters of the
way from Hawaii to the Philippines
Geographic coordinates:
13 28 N, 144 47 E
Map references: Oceania
Area:
total: 541 .3 sq km
land: 541.3 sq km
water: 0 sq km
Area — comparative: three times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; generally warm
and humid, moderated by northeast trade
winds; dry season (January to June), rainy
season (July to December); litde seasonal
temperature variation
Terrain: volcanic origin, surrounded by
coral reefs; relatively flat coralline lime¬
stone plateau (source of most fresh water),
with steep coastal cliffs and narrow coastal
plains in north, low hills in center, moun¬
tains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: aquatic wildlife
(supporting tourism), fishing (largely unde¬
veloped)
Land use:
arable land: 3.64%
permanent crops: 18.18%
other: 78.18% (2005)
Irrigated land: NA
Natural hazards: frequent squalls during
rainy season; relatively rare, but poten¬
tially very destructive typhoons (June—
December)
Environment — current issues: extirpa¬
tion of native bird population by the rapid
proliferation of the brown tree snake, an
exotic, invasive species
Geography — note: largest and southern¬
most island in the Mariana Islands archi¬
pelago; strategic location in western North
Pacific Ocean','7e51386db9ab9255008eed5b4d64b9d1e52d61bcf82af44074d060891d177603','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d91f32c7c079ec9d6c768681f836633131a3ce9627baf90f11fd3d4002d7e8a',2010,'GT','Guatemala','geography',733,'Location: Central America, bordering the
North Pacific Ocean, between El Salvador
and Mexico, and bordering the Gulf
of Honduras (Caribbean Sea) between
Honduras and Belize
Geographic coordinates: 15 30 N, 90 1 5
W
Map references: Central America and the
Caribbean
Area:
total: 108,890 sq km
land: 108,430 sq km
water: 460 sq km
Area — comparative: slightly smaller than
Tennessee
Land boundaries:
total: 1,687 km
border countries: Belize 266 km, El Salvador
203 km, Honduras 256 km, Mexico 962
km
Coastline: 400 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical; hot, humid in lowlands;
cooler in highlands
Terrain: mosdy mountains with narrow
coastal plains and rolling limestone plateau
281
THE CIA WORLD FACTBOOK
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Volcan Tajumulco 4,211 m
Natural resources: petroleum, nickel, rare
woods, fish, chicle, hydropower
Land use: arable land: 13.22%
permanent crops: 5.6%
Other: 81.18% (2005)
Irrigated land: 1,300 sq km (2003)
Total renewable water resources: 111.3
cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 2.01 cu
km/yr (6%/13%/80%)
per capita: 160 cu m/yr (2000)
Natural hazards: numerous volcanoes in
mountains, with occasional violent earth¬
quakes; Caribbean coast extremely suscep¬
tible to hurricanes and other tropical storms
Environment — current issues: deforesta¬
tion in the Peten rainforest; soil erosion;
water pollution
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: no natural harbors on
west coast','bc82b3ff2d7843f9de2b90c9d71026942454e3d68cdc0a93a365c70089b2f4c5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0734a409bbac68fc1c03ea631707e3c5a6a356bf923da855f9dbb7660bc61bc1',2010,'GG','Guernsey','geography',737,'Location: Western Europe, islands in the
English Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35
W
Map references: Europe
Area: total: 78 sq km
land: 78 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm,
Sark, and some other smaller islands
Area — comparative: about one-half the
size of Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 1 2 nm
Climate: temperate with mild winters and
cool summers; about 50% of days are over¬
cast
Terrain: mosdy level with low hills in
southwest
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed location on Sark
114 m
Natural resources: cropland
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Natural hazards: NA
Environment— current issues: NA
Geography — note: large, deepwater harbor
at Saint Peter Port','9dc3ed37de3641c89e2bf2f336399baa98d01d5a47d2773e38a5cdc3313fe10e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b35cb06d5983280f2dc4664b21a1bb7c84703018e920a69995e4e6892fc04489',2010,'GW','Guinea-Bissau','geography',751,'Location: Western Africa, bordering the
North Adantic Ocean, between Guinea
and Senegal
Geographic coordinates: 12 00 N, 1 5 00 W
Map references: Africa
Area: total: 36,120 sq km
land: 28,000 sq km
water: 8,120 sq km
Area— comparative: slightly less than
three times the size of Connecticut
Land boundaries: total: 724 km
border countries: Guinea 386 km, Senegal
338 km
Coastline: 350 km
Maritime Claims: territorial sea : 12 nm
exclusive economic zone: 200 nm
Climate: tropical; generally hot and
humid; monsoonal-type rainy season (June
to November) with southwesterly winds;
dry season (December to May) with north¬
easterly harmattan winds
Terrain: mostly low coastal plain rising to
savanna in east
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed location in the
northeast corner of the country 300 m
Natural resources: fish, timber, phos¬
phates, bauxite, clay, granite, limestone,
unexploited deposits of petroleum
Land use: arable land: 8.31%
permanent crops : 6.92%
other: 84.77% (2005)
Irrigated land: 250 sq km (2003)
Total renewable water resources: 31 cu
km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.18 cu km/yr
(1 3%/5%/82%)
per capita: 113 cu m/yr (2000)
Natural hazards: hot, dry, dusty harmattan
haze may reduce visibility during dry
season; brush fires
Environment — current issues: deforesta¬
tion; soil erosion; overgrazing; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: this small country is
swampy along its western coast and low-
lying inland','fd10ed2a8a771437dbd7c6a97cd1ac569f0b69207fa7a28be3ab624a23e76643','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b95259c053a3868e7445be36a77a9760e9e33669bdc5b81d381954b3e1c56d6f',2010,'GY','Guyana','geography',759,'Location: Northern South America,
bordering the North Atlantic Ocean,
between Suriname and Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area: total: 214,970 sq km
land: 196,850 sq km
•water: 18,120 sq km
Area — comparative: slightly smaller than
Idaho
Land boundaries: total: 2,949 km
border countries: Brazil 1,606 km, Suriname
600 km, Venezuela 743 km
Coastline: 459 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the outer
edge of the continental margin
Climate: tropical; hot, humid, moderated
by northeast trade winds; two rainy seasons
(May to August, November to January)
Terrain: mosdy rolling highlands; low
coastal plain; savanna in south
Elevation extremes: lowest point: Adantic
Ocean 0 m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold,
diamonds, hardwood timber, shrimp, fish
Land use: arable land: 2.23%
permanent crops: 0.14%
other: 97.63% (2005)
Irrigated land: 1,500 sq km (2003)
Total renewable water resources: 241 cu
km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.64 cu
km/yr (2%/l%/98%)
per capita: 2,187 cu m/yr (2000)
Natural hazards: flash floods are a
constant threat during rainy seasons
Environment — current issues: water
pollution from sewage and agricultural and
industrial chemicals; deforestation
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of die selected
agreements
Geography— note: the third-smallest
country in South America after Suriname
and Uruguay; substantial portions of its
western and eastern territories are claimed
by Venezuela and Suriname respectively','a2c12f8d150461664dfaf3eb3629866ed36d3324dee2a1b9b27da65284df39a9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e47b9092fc4d8a1e47af023c8e9626949401f4e0064e4f8992c0e27120d57b0',2010,'HT','Haiti','geography',766,'Location: Caribbean, western one-third
of the island of Hispaniola, between the
Caribbean Sea and the North Atlantic
Ocean, west of the Dominican Republic
Geographic coordinates: 19 00 N,
72 25 W
Map references: Central America and the
Caribbean
Area: total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
Area — comparative: slighdy smaller than
Maryland
Land boundaries:
total: 360 km
border countries: Dominican Republic
360 km
Coastline: 1,771 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical; semiarid where moun¬
tains in east cut off trade winds
Terrain:
mosdy rough and mountainous
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: bauxite, copper,
calcium carbonate, gold, marble, hydro-
power
Land use: arable land: 28.11%
permanent crops: 11.53%
other: 60.36% (2005)
Irrigated land: 920 sq km (2003)
Total renewable water resources: 14 cu
km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.99 cu km/yr (5%/l%/94%)
per capita: 1 16 cu m/yr (2000)
Natural hazards: lies in the middle of the
hurricane belt and subject to severe storms
from June to October; occasional flooding
and earthquakes; periodic droughts
Environment — current issues: extensive
deforestation (much of the remaining
forested land is being cleared for agricul¬
ture and used as fuel); soil erosion; inad¬
equate supplies of potable water
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection
signed, but not ratified: Hazardous Wastes
Geography — note: shares island of Hispa¬
niola with Dominican Republic (western
one-third is Haiti, eastern two-thirds is the
Dominican Republic)','73f3586e4e89d351b31ad3207cf712ca533ea49c2a7b68fbd238d7867752d020','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('023e71a00243f79852bccbdee0f59b182fd86dc12e7bf19e75ae66641c7d2445',2010,'HM','Heard Island and McDonald Islands','geography',777,'Location: Southern Europe, an enclave of
Rome (Italy)
Geographic coordinates: 41 54 N,
12 27 E
Map references: Europe
Area: total: 0.44 sq km
land: 0.44 sq km
water: 0 sq km
Area — comparative: about 0.7 times the
size of The Mall in Washington, DC
Land boundaries: total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; mild, rainy winters
(September to May) with hot, dry summers
(May to September)
Terrain: urban; low hill
Elevation extremes:
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 1 00% (urban area) (2005)
Irrigated land: 0 sq km
Natural hazards: NA
Environment — current issues: NA
Environment — international agreements:
party to: O zone Layer Protection
signed, but not ratified: Air Pollution, Envi¬
ronmental Modification
Geography — note: landlocked; enclave in
Rome, Italy; world’s smallest state; beyond
the territorial boundary of Vatican City, the
Lateran Treaty of 1929 grants the Holy See
extraterritorial authority over 23 sites in
Rome and five outside of Rome, including
the Pontifical Palace at Castel Gandolfo
(the Pope’s summer residence)','e84751aab2be9d4c249bfc1cb24e983d0a0b16490fc0a6750e05fda0701be92c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce1bf38b8c0f05dc1e997fae1d72d7cb08b8c78ad1e061247d6e9c5882f28aa8',2010,'HN','Honduras','geography',779,'Location: Central America, bordering
the Caribbean Sea, between Guatemala
and Nicaragua and bordering the Gulf of
Fonseca (North Pacific Ocean), between El
Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30
w
Map references: Central America and the
Caribbean
Area: total: 112,090 sq km
land: 111 ,890 sq km
water: 200 sq km
Area— comparative: slightly larger than
Tennessee
Land boundaries: total: 1,520 km
border countries: Guatemala 256 km, El
Salvador 342 km, Nicaragua 922 km
302
Coastline: 820 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: natural extension of terri¬
tory or to 200 nm
Climate: subtropical in lowlands,
temperate in mountains
Terrain: mostly mountains in interior,
narrow coastal plains
Elevation extremes: lowest point:
Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver,
copper, lead, zinc, iron ore, antimony, coal,
fish, hydropower
Land use: arable land: 9.53%
permanent crops: 3.21%
other: 87.26% (2005)
Irrigated land: 800 sq km (2003)
Total renewable water resources: 95.9 cu
km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total:
0.86 cu km/yr (8%/12%/80%)
per capita: 119 cu m/yr (2000)
Natural hazards: frequent, but generally
mild, earthquakes; extremely susceptible to
damaging hurricanes and floods along the
Caribbean coast
Environment— current issues: urban
population expanding; deforestation results
from logging and die clearing of land for
agricultural purposes; further land degrada¬
tion and soil erosion hastened by uncon¬
trolled development and improper land
use practices such as farming of marginal
lands; mining activities polluting Lago de
Yojoa (the country’s largest source of fresh
water), as well as several rivers and streams,
with heavy metals
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: has only a short Pacific
coast but a long Caribbean shoreline,
including the virtually uninhabited eastern
Mosquito Coast
Geographic coordinates:
13 00 N, 85 00 W
Map references: Central America and the
Caribbean
Area: total: 1 29,494 sq km
land: 120,254 sq km
water: 9,240 sq km
Area — comparative: slightly smaller than
New York state
Land boundaries: total: 1,231 km
border countries: Costa Rica 309 km,
Honduras 922 km
Coastline: 910 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: natural prolongation
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive Atlantic coastal plains
rising to central interior mountains;
narrow Pacific coastal plain interrupted by
volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper,
tungsten, lead, zinc, timber, fish
Land use: arable land: 14.81%
permanent crops: 1.82%
other: 83.37% (2005)
Irrigated land:
610 sq km (2003)
Total renewable water resources:
196.7 cu km (2000)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.3 cu
km/yr (15%/2%/83%)
per capita: 237 cu m/yr (2000)
Natural hazards: destructive earthquakes;
volcanoes; landslides; extremely susceptible
to hurricanes
Environment — current issues:
deforestation; soil erosion; water pollution
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertb
fication, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: largest country in
Central America; contains the largest fresh¬
water body in Central America, Lago de','fc55fc7b787d94bf3ed80e745ab22d7dd277b8e5113d742fb221920632072129','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c96f89ed4d3208adb49c65912cb20a8d7d6abdf31b92e5f16a990610d13344db',2010,'HK','Hong Kong','geography',788,'Location: Eastern Asia, bordering the
South China Sea and China
Geographic coordinates:
22 15 N, 114 10 E
Map references: Southeast Asia
Area: total: 1,092 sq km
land: 1 ,042 sq km
water: 50 sq km
Area — comparative: six times the size of
Washington, DC
Land boundaries: total: 30 km
regional border: China 30 km
Coastline: 733 km
Maritime Claims: territorial sea: 3 nm
Climate: subtropical monsoon; cool and
humid in winter, hot and rainy from spring
through summer, warm and sunny in fall
Terrain: hilly to mountainous with steep
slopes; lowlands in north
Elevation extremes: lowest point: South
China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater
harbor, feldspar
Land use: arable land: 5.05%
permanent crops: 1.01%
other: 93.94% (2001)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: occasional typhoons
Environment— current issues: air and
water pollution from rapid urbanization
Environment— international agree¬
ments: party to: Marine Dumping (asso^
ciate member), Ship Pollution (associate
member)
Geography — note: more than 200 islands
Location: Southeastern Europe, north of','056b0733bcaf387692e96c752934370f6cec372185eed94b66cea3e745600640','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('819414495a25b2319db251dbe347d0f889e2266dd8502d4770719a81c72ec020',2010,'RO','Romania','geography',795,'Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area: total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area — comparative: slightly smaller than
Indiana
Land boundaries: total: 2,185 km
border countries: Austria 366 km, Croatia
329 km, Romania 443 km, Serbia 166
km, Slovakia 676 km, Slovenia 102 km,
Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; cold, cloudy, humid
winters; warm summers
Terrain: mosdy flat to rolling plains; hills and
low mountains on the Slovakian border
Elevation extremes:
lowest point: Tisza River 78 m
highest point: Kekes 1,014 m
Natural resources: bauxite, coal, natural
gas, fertile soils, arable land
Land use: arable land: 49.58%
permanent crops: 2.06%
other: 48.36% (2005)
Irrigated land:
2,300 sq km (2003)
Total renewable water resources:
120 cu km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 21.03 cu km/yr
(9%/59%/32%)
per capita: 2,082 cu m/yr (2001)
Environment — current issues: the
upgrading of Hungary’s standards in
waste management, energy efficiency, and
air, soil, and water pollution to meet EU
requirements will require large invest¬
ments
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Air Pollution-Vola¬
tile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; strategic
location astride main land routes between
Western Europe and Balkan Peninsula as
well as between Ukraine and Mediterra¬
nean basin; the north-south flowing Duna
(Danube) and Tisza Rivers divide the
country into three large regions
Geographic coordinates: 47 00 N, 29 00 E
Map references: Europe
Area: total: 33,843 sq km
land: 33,371 sq km
water : 472 sq km
Area— comparative: slightly larger than
Maryland
Land boundaries: total: 1,390 km
border countries: Romania 450 km,
Ukraine 940 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: moderate winters, warm
summers
Terrain: rolling steppe, gradual slope south
to Black Sea
Elevation extremes:
lowest point: Dniester River 2 m
highest point: Dealul Balanesti 430 m
Natural resources: lignite, phosphorites,
gypsum, arable land, limestone
Land use: arable land: 54.52%
permanent crops: 8.81%
other: 36.67% (2005)
Irrigated land: 3,000 sq km (2003)
Total renewable water resources: 1 1 .7 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 2.31 cu km/yr
(10%/58%/33%)
per capita: 549 cu m/yr (2000)
Natural hazards: landslides
Environment— current issues: heavy use
of agricultural chemicals, including banned
pesticides such as DDT, has contaminated
soil and groundwater; extensive soil erosion
from poor farming methods
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Persistent Organic Pollutants, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; well
endowed with various sedimentary rocks
and minerals including sand, gravel,
gypsum, and limestone
Location: Southeastern Europe, bordering
the Black Sea, between Bulgaria and
Location: Northern Asia (dre area west of
the Urals is considered part of Europe),
bordering the Arctic Ocean, between
Europe and the North Pacific Ocean
Geographic coordinates: 60 00 N, 100
00 E
Map references: Asia
Area: total: 17,075,200 sq km
land: 16,995,8 00 sq km
water: 79,400 sq km
Area — comparative: approximately 1 .8
times the size of the US
Land boundaries: total: 20,241.5 km
border countries: Azerbaijan 284 km,
Belarus 959 km, China (southeast) 3,605
561
THE CIA WORLD FACTBOOK
km, China (south) 40 km, Estonia 290
km, Finland 1,313 km, Georgia 723 km,
Kazakhstan 6,846 km, North Korea 17.5
km, Latvia 292 km, Lithuania (Kalinin¬
grad Oblast) 227 km, Mongolia 3,441
km, Norway 1 96 km, Poland (Kaliningrad
Oblast) 432 km, Ukraine 1,576 km
Coastline: 37,653 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: ranges from steppes in the south
through humid continental in much of
European Russia; subarctic in Siberia to
tundra climate in the polar north; winters
vary from cool along Black Sea coast to
frigid in Siberia; summers vary from warm
in the steppes to cool along Arctic coast
Terrain: broad plain with low hills west of
Urals; vast coniferous forest and tundra
in Siberia; uplands and mountains along
southern border regions
Elevation extremes: lowest point: Caspian
Sea -28 m
highest point: Gora El’brus 5,633 m
Natural resources: wide natural resource
base including major deposits of oil, natural
gas, coal, and many strategic minerals, timber
note: formidable obstacles of climate,
terrain, and distance hinder exploitation of
natural resources
Land use: arable land: 7.17%
permanent crops: 0.11%
other: 92.72% (2005)
Irrigated land:
46,000 sq km (2003)
Total renewable water resources: 4,498
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 76.68 cu
km/yr (1 9%/63%/l 8%)
per capita: 535 cu m/yr (2000)
Natural hazards: permafrost over much
of Siberia is a major impediment to devel¬
opment; volcanic activity in the Kuril
Islands; volcanoes and earthquakes on the
Kamchatka Peninsula; spring floods and
summer/autumn forest fires throughout
Siberia and parts of European Russia
Environment— current issues: air pollu¬
tion from heavy industry, emissions of
coal-fired electric plants, and transportation
in major cities; industrial, municipal, and
agricultural pollution of inland waterways
and seacoasts; deforestation; soil erosion;
soil contamination from improper appli¬
cation of agricultural chemicals; scattered
areas of sometimes intense radioactive
contamination; groundwater contamina¬
tion from toxic waste; urban solid waste
management; abandoned stocks of obsolete
pesticides
Environment— international agree¬
ments: party to: Air Pollution, Air Pollu¬
tion-Nitrogen Oxides, Air Pollution-Sulfur
85, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber
83, Wetlands, Whaling
signed, but not ratified: Air Pollution-Sulfur 94
Geography — note: largest country in the
world in terms of area but unfavorably
located in relation to major sea lanes of the
world; despite its size, much of the country
lacks proper soils and climates (either too
cold or too dry) for agriculture; Mount
El’brus is Europe’s tallest peak','7e402022f96c1eb7b3c35d1987b14f0f6099c3ad4ed45347ea5fbd241e9b3901','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3946bc89f8011c9d0b15ed03bd44d5644d84abcaee9e7cc815caad8b49049f30',2010,'IS','Iceland','geography',805,'Location: Northern Europe, island between
the Greenland Sea and the North Atlantic
Ocean, northwest of the United Kingdom
Geographic coordinates:
65 00 N, 18 00 W
Map references: Arctic Region
Area: total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Area — comparative: slightly smaller than
Kentucky
Land boundaries: 0 km
Coastline: 4,970 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone : 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: temperate; moderated by North
Atlantic Current; mild, windy winters;
damp, cool summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields; coast deeply
indented by bays and fiords
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Hvannadalshnukur 2,110 m
(at Vatnajokull glacier)
Natural resources: fish, hydropower,
geothermal power, diatomite
Land use: arable land: 0.07%
permanent crops: 0%
other: 99.93% (2005)
Irrigated land: NA
Total renewable water resources: 170 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.17 cu km/yr
(34%/66%/0%)
per capita: 567 cu m/yr (2003)
Natural hazards: earthquakes and volcanic
activity
Environment — current issues: water
pollution from fertilizer runoff; inadequate
wastewater treatment
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Persistent Organic Pollutants, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Kyoto Protocol,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Trans-
boundary Air Pollution, Wetlands, Whaling
signed, but not ratified: Environmental
Modification, Marine Life Conservation
Geography— note: strategic location
between Greenland and Europe; western¬
most European country; Reykjavik is the
northernmost national capital in the world;
more land covered by glaciers than in all of
continental Europe','33f39a6cfe986dda479a9820d65aacf87e51639b956510da2876dadfd752ab37','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aec95d59a1efcf368d3efc3ded8cfa15585a0aef28ca2154b700c38516b4da3d',2010,'IN','India','geography',813,'Location: Southern Asia, bordering
the Arabian Sea and the Bay of Bengal,
between Burma and Pakistan
Geographic coordinates:
20 00 N, 77 00 E
Map references: Asia
Area: total: 3,287,590 sq km
land: 2,973,19 0 sq km
water: 314,400 sq km
Area — comparative: slightly more than
one-third the size of the US
Land boundaries: total. 14,103 km
border countries: Bangladesh 4,053 km,
Bhutan 605 km, Burma 1,463 km, China
3,380 km, Nepal 1,690 km, Pakistan 2,912
km
Coastline: 7,000 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the Ganges,
deserts in west, Himalayas in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest
reserves in the world), iron ore, manga¬
nese, mica, bauxite, titanium ore, chromite,
natural gas, diamonds, petroleum, lime¬
stone, arable land
Land use: arable land: 48.83%
permanent crops: 2.8%
other: 48.37% (2005)
Irrigated land: 558,080 sq km (2003)
Total renewable water resources: 1,907.8
cu km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 645.84 cu km/yr
(8%/5%/86%)
per capita: 585 cu m/yr (2000)
Natural hazards: droughts; flash floods, as
well as widespread and destructive flooding
from monsoonal rains; severe thunder¬
storms; earthquakes
Environment — current issues: deforesta¬
tion; soil erosion; overgrazing; desertifica¬
tion; air pollution from industrial effluents
and vehicle emissions; water pollution from
raw1 sewage and runoff of agricultural pesti¬
cides; tap water is not potable throughout
the country; huge and growing population
is overstraining natural resources
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: dominates South
Asian subcontinent; near important Indian
Ocean trade routes; Kanchenjunga, third
tallest mountain in the world, lies on the
border with Nepal
Location: body of water between Africa,
the Southern Ocean, Asia, and Australia
Geographic coordinates: 20 00 S, 80 00 E
Map references: Political Map of the
World
Area: total: 68.556 million sq km
note: includes Andaman Sea, Arabian Sea,
Bay of Bengal, Flores Sea, Great Australian
320
Geographic coordinates: 3 15 N, 73 00 E
Map references: Asia
Area: total: 300 sq km
land: 300 sq km
water: 0 sq km
Area — comparative: about 1.7 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime Claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; dry, north¬
east monsoon (November to March); rainy,
southwest monsoon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: unnamed location on Wilin-
gili island in the Addu Atoll 2.4 m
Natural resources: fish
Land use: arable land: 13.33%
permanent crops: 30%
other: 56.67% (2005)
Irrigated land: NA
Total renewable water resources: 0.03 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 0.003 cu km/yr (98%/2%/0%)
per capita: 9 cu m/yr (1987)
Natural hazards: low level of islands
makes them sensitive to sea level rise
anti-trafficking legislation in July 2007;
however, it did not take action against
exploitative employers or labor traffickers
in 2007; the government has not ratified
the 2000 UN TIP Protocol (2008)
Illicit drugs: drug trafficking prosecuted
vigorously and carries severe penalties;
heroin still primary drug of abuse, but
synthetic drug demand remains strong;
continued ecstasy and methamphetamine
producer for domestic users and, to a lesser
extent, the regional drug market
Environment — current issues: depletion
of freshwater aquifers threatens water
supplies; global warming and sea level rise;
coral reef bleaching
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law
of the Sea, O zone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: 1,190 coral islands
grouped into 26 atolls (200 inhabited
islands, plus 80 islands with tourist resorts);
archipelago with strategic location astride
and along major sea lanes in Indian Ocean','a50210d0da7faf42835490152a4f12707fda084548d68cbb5dde897d70f7b3e4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6c85466003b3c26155fd01475893dab21a64bc873e5f12117148da3aca791b8',2010,'IQ','Iraq','geography',827,'Location: Middle East, bordering the
Persian Gulf, between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area: total: 437,072 sq km
land: 432,162 sq km
water: 4,910 sq km
Area — comparative: slighdy more than
twice the size of Idaho
Land boundaries: total: 3,650 km
border countries: Iran 1,458 km, Jordan 181
km, Kuwait 240 km, Saudi Arabia 814 km,
Syria 605 km, Turkey 352 km
Coastline: 58 km
Maritime Claims: territorial sea: 12 nm
continental shelf: not specified
Climate: mosdy desert; mild to cool winters
with dry, hot, cloudless summers; northern
mountainous regions along Iranian and
Turkish borders experience cold winters
with occasionally heavy snows that melt in
early spring, sometimes causing extensive
flooding in central and southern Iraq
Terrain: mostly broad plains; reedy
marshes along Iranian border in south
with large flooded areas; mountains along
borders with Iran and Turkey
Elevation extremes: lowest point: Persian
Gulf 0 m
highest point: unnamed peak; 3,611
m; note— this peak is neidaer Gundah
Zhur 3,607 m nor Kuh-e Hajji-Ebrahim
3,595 m
Natural resources: petroleum, natural gas,
phosphates, sulfur
Land USe: arable land: 13.12%
permanent crops: 0.61%
other: 86.27% (2005)
Irrigated land: 35,250 sq km (2003)
Total renewable water resources: 96.4 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 42.7 cu km/yr
(3%/5%/92%)
per capita: 1,482 cu m/yr (2000)
Natural hazards: dust storms; sandstorms;
floods
Environment — current issues: govern¬
ment water control projects have drained
most of the inhabited marsh areas east of
An Nasiriyah by drying up or diverting the
feeder streams and rivers; a once sizable
population of Marsh Arabs, who inhab¬
ited these areas for thousands of years, has
been displaced; furthermore, the destruc¬
tion of the natural habitat poses serious
threats to the area’s wildlife populations;
inadequate supplies of potable water; devel¬
opment of the Tigris and Euphrates rivers
system contingent upon agreements with
upstream riparian Turkey; air and water
pollution; soil degradation (salination) and
erosion; desertification
Environment— international agreements:
party to: Biodiversity, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: Environmental
Modification
Geography — note: strategic location on
Shatt al Arab waterway and at the head of
the Persian Gulf','abd2af6d3dddc19f023876c1f05b0588d52bbf3f403942fcff8ca56183237a8a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('529ea4104105a67d907c4db306d0f384a8d147d22748b8086d04a3bee61fe777',2010,'IE','Ireland','geography',836,'Location: Western Europe, occupying five-
sixths of the island of Ireland in the North
Atlantic Ocean, west of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area: total: 70,280 sq km
land: 68,890 sq km
water: 1,390 sq km
Area — comparative: slightly larger than
West Virginia
Land boundaries: total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime Claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: temperate maritime; modified by
North Atlantic Current; mild winters, cool
summers; consistendy humid; overcast
about half the time
Terrain: mostly level to rolling interior
plain surrounded by rugged hills and low
mountains; sea cliffs on west coast
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Carrauntoohil 1,041 m
Natural resources: natural gas, peat,
copper, lead, zinc, silver, barite, gypsum,
limestone, dolomite
Land use: arable land: 16.82%
permanent crops: 0.03%
other: 83.15% (2005)
Irrigated land: NA
Total renewable water resources: 46.8 cu
km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.18 cu km/yr
(23%/77%/0%)
per capita: 284 cu m/yr (1994)
Natural hazards: NA
Environment — current issues: water
pollution, especially of lakes, from agricul¬
tural runoff
Environment— international agree¬
ments: party to: Air Pollution, Air Pollu¬
tion-Nitrogen Oxides, Air Pollution-Sulfur
94, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
333
THE CIA WORLD FACTBOOK
Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Marine Life
Conservation
Geography — note: strategic location on
major air and sea routes between North
America and northern Europe; over 40%
of the population resides within 100 km
of Dublin
Geographic coordinates: 54 15 N,
4 30 W
Map references: Europe
Area: total: 572 sq km
land: 572 sq km
water: 0 sq km
Area — comparative: slightly more than
three times the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims: territorial sea: 1 2 nm
exclusive fishing zone: 1 2 nm
336','539c74f0182d8a8d38f9d2e02ef6e056f2cc5aebf12c129ac562128fde6b6dad','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c73f7317da620a64d01a0d0e57df1653311c41b98fe5b5f2721b3361c14e63f7',2010,'IM','Isle of Man','geography',841,'Location: Western Europe, island in
the Irish Sea, between Great Britain and
A % W
. iQm
0 9
Ramsey*
DOUGLAS*
Cuff of
Mm
Chicken
Rock
Climate: temperate; cool summers and
mild winters; overcast about a third of the
time
Terrain: hills in north and south bisected
by central valley
Elevation extremes:
lowest point: Irish Sea 0 m
highest point: Snaefell 621 m
Natural resources: none
Land use: arable land: 9%
permanent crops: 0%
other: 91% (permanent pastures, forests,
mountain, and heathland) (2002)
Irrigated land: 0 sq km
Natural hazards: NA
Environment — current issues: waste
disposal (both household and industrial);
transboundary air pollution
Geography-note: one small islet, the
Calf of Man, lies to the southwest and is
a bird sanctuary
Population: 76,512 (July 2009 est.)
Age Structure: 0-14 years: 16.9% (male
6,612/female 6,300)
15-64 years: 66% (male 25,433/female
25,083)
65 years and over: 17.1% (male 5,408/
female 7,676) (2009 est.)
Median age: total. 40.2 years
male: 39 years
female: 41.4 years (2009 est.)
Population growth rate: 0.524% (2009 est.)
Birth rate: 10.77 births/1,000 population
(2009 est.)
Death rate: 11.02 deaths/1,000 popula-
tion (2008 est.)
Net migration rate: 5.23 migrant(s)/l,000
population (2009 est.)
Urbanization: urban population: 51% of
total population (2008)
rate of urbanization: - 0.2 % annual rate of
change (2005-1 0 est.)
Sex ratio: at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (2009
est.)
Infant mortality rate: total: 5.37
deaths/1 ,000 live births
male: 6.11 deaths/1,000 live births
female: 4.58 deaths/1,000 live births
(2009 est.)
Life expectancy at birth:
total population: 78.82 years
male: 75.86 years
female: 81.93 years (2009 est.)
Total fertility rate: 1 .65 children born/
woman (2009 est.)
HIV/AIDS — adult prevalence rate: NA
HIV/AIDS— people living with HIV/AIDS:
NA
HIV/AIDS— deaths: NA
Nationality: noun: Manxman (men),
Manxwoman (women)
adjective: Manx
Ethnic groups: Manx (Norse-Celtic
descent), Britons
Religions: Anglican, Roman Catholic,
Methodist, Baptist, Presbyterian, Society
of Friends
Languages: English, Manx Gaelic
Literacy: NA
Education expenditures: NA
Country name: conventional long form: none
conventional short form: Isle of Man
abbreviation: I.O.M.
Dependency status: British crown
dependency
Government type: parliamentary democ¬
racy
Capital: name: Douglas
geographic coordinates: 54 09 N, 4 29 W
time difference: UTC 0 (five hours ahead of
Washington, DC during Standard Time)
daylight saving time: +1 hr, begins last
Sunday in March; ends last Sunday in
October
Administrative divisions: none; there are
no first-order administrative divisions as
defined by the US Government, but there
are 24 local authorities each with its own
elections
Independence: none (British crown
dependency)
National holiday: Tynwald Day, 5 July
Constitution: unwritten; note— The Isle of
Man Constitution Act of 1961 does not
embody the unwritten Manx Constitution
Legal system: the laws of the UK, where
applicable, apply and Manx statutes
Suffrage: 1 6 years of age; universal
Executive branch: chief of state. Lord
of Mann Queen ELIZABETH II (since
6 February 1952); represented by Lieu¬
tenant Governor Sir Paul K. HADDACKS
(since 1 7 October 2005)
head of government: Chief Minister Tony
BROWN (since 14 December 2006)
cabinet: Council of Ministers
elections: the monarch is hereditary;
lieutenant governor appointed by the
monarch; the chief minister is elected by
the Tynwald for a five-year term; election
last held 14 December 2006 (next to be
held in December 2011)
election results: House of Keys speaker
Tony BROWN elected chief minister by
the Tynwald
Legislative branch: bicameral Tynwald
consists of the Legislative Council (1 1
seats; members composed of the President
of Tynwald, the Lord Bishop of Sodor and
Man, a nonvoting attorney general, and 8
others named by the House of Keys) and die
House of Keys (24 seats; members are elected
by popular vote to serve five-year terms)
elections: House of Keys— last held 23
November 2006 (next to be held in
November 2011)
election results: House of Keys— percent of
vote by party— NA; seats by party— Liberal
Vannin Party 2, Man Labor Party 1, inde¬
pendents 21
Judicial branch: High Court of Justice
(justices are appointed by the Lord Chan¬
cellor of England on the nomination of die
lieutenant governor)
Political parties and leaders: Alliance
for Progressive Government; Liberal
Vannin Party [Peter KARRANJ; Man
Labor Party; Man Nationalist Party
(Mec Vannin) [Bernard MOFFATTJ
note: most members sit as independents
Political pressure groups and leaders:
Alliance for Progressive Government
or APG (a government watchdog); Mec
Vannin (political party advocating a
sovereign state and environment policies);
note— has only had one member elected to
the Tynwald
International organization participation:
UPU
Diplomatic representation in the US:
none (British crown dependency)
Diplomatic representation from the US:
none (British crown dependency)
Flag description: red with the Three Legs
of Man emblem (Trinacria), in the center;
the three legs are joined at die thigh and
bent at the knee; in order to have die toes
pointing clockwise on both sides of die
flag, a two-sided emblem is used','a341143c63ac3fec084fcebd424fed7ce7bc94cec854b44c01a7b1700c14a7e2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b2c66cee816ce17d956120caaddd5efae3a111ad2c7b3e7a92c82c744d168d7',2010,'LB','Lebanon','geography',847,'Geographic coordinates:
31 30 N, 34 45 E
Map references: Middle East
Area: total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area — comparative: slightly smaller than
New Jersey
Land boundaries: total: 1,017 km
border countries: Egypt 266 km, Gaza Strip
51 km, Jordan 238 km, Lebanon 79 km,
Syria 76 km, West Bank 307 km
Coastline: 273 km
Maritime Claims: territorial sea: 12 nm
continental shelf: to depth of exploitation
Climate: temperate; hot and dry in
southern and eastern desert areas
Terrain: Negev desert in the south; low
coastal plain; central mountains; Jordan
Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1,208 m
Natural resources: timber, potash, copper
ore, natural gas, phosphate rock, magne¬
sium bromide, clays, sand
Land use: arable land: 15.45%
permanent crops: 3.88%
other: 80.67% (2005)
Irrigated land: 1,940 sq km (2003)
Total renewable water resources: 1.7 cu
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 2.05 cu km/yr
(3 1 %/7%/ 62%)
per capita: 305 cu m/yr (2000)
Natural hazards: sandstorms may occur
during spring and summer; droughts; peri¬
odic earthquakes
Environment — current issues: limited
arable land and natural fresh water
resources pose serious constraints; deserti¬
fication; air pollution from industrial and
vehicle emissions; groundwater pollution
from industrial and domestic waste, chem¬
ical fertilizers, and pesticides
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Ozone Layer Protec¬
tion, Ship Pollution, Wedands, Whaling
signed, but not ratified: Marine Life Conser¬
vation
Geography — note: there are about 340
Israeli civilian sites— including 100 small
outpost communities in the West Bank¬
as well as 42 sites in the Golan Heights,
0 in the Gaza Strip, and 29 in East Jeru¬
salem Only 2008 est.); Lake Tiberias (Sea
of Galilee) is an important freshwater
source
Location: Middle East, bordering the Medi¬
terranean Sea, between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area: total: 10,400 sq km
land: 10,230 sq km
water: 170 sq km
Area — comparative: about 0.7 times the
size of Connecticut
Land boundaries: total: 454 km
border countries: Israel 79 km, Syria 375
km
Coastline: 225 km
Maritime claims: territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet
winters with hot, dry summers; Lebanon
mountains experience heavy winter snows
Terrain: narrow coastal plain; El Beqaa
(Bekaa Valley) separates Lebanon and
Anti-Lebanon Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda’ 3,088 m
Natural resources: limestone, iron ore,
salt, water-surplus state in a water-deficit
region, arable land
Land use: arable land: 16.35%
permanent crops: 13.75%
other: 69.9% (2005)
Irrigated land: 1,040 sq km (2003)
Total renewable water resources: 4.8 cu
km (1997)
391
THE CIA WORLD FACTBOOK
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.38 cu
km/yr (33%/l %/67%)
per capita: 385 cu m/yr (2000)
Natural hazards: dust storms, sandstorms
Environment— current issues: defor¬
estation; soil erosion; desertification; air
pollution in Beirut from vehicular traffic
and the burning of industrial wastes; pollu¬
tion of coastal waters from raw sewage and
oil spills
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental
Modification, Marine Life Conservation
Geography— note: Nahr el Litani is the
only major river in Near East not crossing
an international boundary; rugged terrain
historically helped isolate, protect, and
develop numerous factional groups based
on religion, clan, and ethnicity','701a17456dc2a4af83db7df09322a54fc51dc990f392abccfedec77f15c3d6b9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('612eef720a8a1c114a5fa6c3d5047e043b5e35d55e9f2df640cf6b945f59e8f8',2010,'JM','Jamaica','geography',865,'Location: Northern Europe, island between
the Greenland Sea and the Norwegian Sea,
northeast of Iceland
Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area: total. 377 sq km
land: 377 sq km
water: 0 sq km
Area — comparative: slightly more than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime Claims: territorial sea: 4 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 2 00 m depth or to the
depth of exploitation
Climate: arctic maritime with frequent
storms and persistent fog
Terrain: volcanic island, partly covered by
glaciers
Elevation extremes: lowest point: Norwe¬
gian Sea 0 m
highest point: Haakon VII Toppen/Beeren-
berg 2,277 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: dominated by the
volcano Haakon VII Toppen/Beerenberg;
volcanic activity resumed in 1970; the most
recent eruption occurred in 1 985
Environment— current issues: NA
Geography — note: barren volcanic island
with some moss and grass','9bb8aad7291fc862e0728fea47df11032a658c8492b900553542c0310faf7aed','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a75cd526b462fe9612073e6b99132949b148e129fb712b2a0917a4eb85e74b75',2010,'JP','Japan','geography',867,'Location: Eastern Asia, island chain
between the North Pacific Ocean and the
Sea of Japan, east of the Korean Peninsula
Geographic coordinates: 36 00 N, 138
00 E
Map references: Asia
Area: total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-
gunto), Daito-shoto, Minami-jima, Okino-
tori-shima, Ryukyu Islands (Nansei-shoto),
and Volcano Islands (Kazan-retto)
Area — comparative: slighdy smaller than
California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims: territorial sea: 12 nm;
between 3 nm and 12 nm in the interna¬
tional straits— La Perouse or Soya, Tsugaru,
Osumi, and Eastern and Western Chan¬
nels of the Korea or Tsushima Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: varies from tropical in south to
cool temperate in north
Terrain: mosdy rugged and mountainous
Elevation extremes: lowest point:
Hachiro-gata A m
highest point: Mount Fuji 3,776 m
Natural resources: negligible mineral
resources, fish
note: with virtually no energy natural
resources, Japan is the world’s largest
importer of coal and liquefied natural gas
as well as the second largest importer of
oil
Land use: arable land: 1 1 .64%
permanent crops: 0.9%
other : 87.46% (2005)
Irrigated land: 25,920 sq km (2003)
Total renewable water resources: 430 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 88.43 cu km/yr
(20%/l 8%/62%)
per capita: 690 cu m/yr (2000)
Natural hazards: many dormant and
some active volcanoes; about 1 ,500 seismic
occurrences (mostly tremors) every year;
tsunamis; typhoons
Environment — current issues: air pollu¬
tion from power plant emissions results
in acid rain; acidification of lakes and
reservoirs degrading water quality and
threatening aquatic life; Japan is one
of the largest consumers of fish and trop¬
ical timber, contributing to the depletion of
these resources in Asia and elsewhere
Environment — international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodi¬
versity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endan¬
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location in
northeast Asia','24c8c23a287ff31653ac5356ace58e97c9d9fe0b6fa1c7edf2c2f92dbded0aa7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0071d288ffc8f7b12dc68f42e8128710ad5e7c94be822524a9a92443d179a1db',2010,'JE','Jersey','geography',876,'Location: Western Europe, island in the
English Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area: total: 116 sq km
land: 1 16 sq km
water: 0 sq km
Area — comparative: about two-thirds the
size of Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime Claims: territorial sea: 3 nm
exclusive fishing zone: 12 nm
Climate: temperate; mild winters and cool
summers
Terrain: gently rolling plain with low,
rugged hills along north coast
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed location 1 43 m
Natural resources: arable land
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: NA
Geography — note: largest and southern¬
most of Channel Islands; about 30% of
population concentrated in Saint Helier','723e3ef0bf7183c57a94f6e96b5e5ab496596c6d20d6feac0a7e1998ef5c88ab','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('080f7d5836629206744e3c1aaf39f9f5d9fe617530ca4448264424baec4e4bd1',2010,'JO','Jordan','geography',886,'Location: Middle East, northwest of Saudi
Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area: total: 92,300 sq km
land: 91,971 sq km
water: 329 sq km
Area — comparative: slightly smaller than
Indiana
Land boundaries: total: 1 ,635 km
border countries: Iraq 181 km, Israel 238
km, Saudi Arabia 744 km, Syria 375 km,
West Bank 97 km
Coastline: 26 km
Maritime claims: territorial sea: 3 nm
Climate: mostly arid desert; rainy season
in west (November to April)
Terrain: mostly desert plateau in east, high¬
land area in west; Great Rift Valley separates
East and West Banks of die Jordan River
Elevation extremes: lowest point: Dead
Sea -408 m
highest point: Jabal Ram 1,734 m
Natural resources: phosphates, potash,
shale oil
Land use: arable land: 3.32%
permanent crops: 1.18%
other: 95.5% (2005)
Irrigated land: 750 sq km (2003)
Total renewable water resources: 0.9 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.01 cu km/yr
(21%/4%/75%)
per capita: 177 cu m/yr (2000)
Natural hazards: droughts; periodic earth¬
quakes
Environment — current issues: limited
natural fresh water resources; deforestation;
overgrazing; soil erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location at the
head of the Gulf of Aqaba and as the Arab
country that shares the longest border with
Israel and the occupied West Bank
Location: Eastern Asia, islands bordering
die East China Sea, Philippine Sea, South
China Sea, and Taiwan Strait, north of the
Philippines, off the southeastern coast of','3cfaca5a30709238e832eb4dbdf327c11e8bbe4a520aa1ea373615118be572df','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('833894f575ee1f10d6e4c139d6ff8b1e12a8045d927629b69df2bc458bf7b175',2010,'KZ','Kazakhstan','geography',892,'Location: Central Asia, northwest of
China; a small portion west of the Ural
River in eastern-most Europe
Geographic coordinates: 48 00 N, 68 00 E
Map references: Asia
Area:
total: 2,717,3 00 sq km
land: 2,669,800 sq km
water: 47,500 sq km
Area — comparative: slightly less than four
times the size of Texas
Land boundaries: total ■ 12,185 km
border countries: China 1,533 km,
Kyrgyzstan 1,224 km, Russia 6,846 km,
Turkmenistan 379 km, Uzbekistan 2,203
km
Coastline: 0 km (landlocked); note— Kaza¬
khstan borders the Aral Sea, now split into
two bodies of water (1,070 km), and the
Caspian Sea (1 ,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot
summers, arid and semiarid
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western
Siberia to oases and desert in Central Asia
Elevation extremes: lowest point: Vpadina
Kaundy -132 m
highest point: Khan Tangiri Shyngy (Pik
Khan-Tengri) 6,995 m
Natural resources: major deposits of
petroleum, natural gas, coal, iron ore,
manganese, chrome ore, nickel, cobalt,
copper, molybdenum, lead, zinc, bauxite,
gold, uranium
Land use: arable land: 8.28%
permanent crops: 0.05%
other: 91.67% (2005)
Irrigated land: 35,560 sq km (2003)
Total renewable water resources: 109.6
cu km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total: 35 cu km/yr (2%/17%/82%)
per capita: 2,360 cu m/yr (2000)
Natural hazards: earthquakes in the south;
mudslides around Almaty
Environment — current issues: radioactive
or toxic chemical sites associated with former
defense industries and test ranges scattered
throughout the country pose health risks
for humans and animals; industrial pollu¬
tion is severe in some cities; because the two
main rivers that flowed into the Aral Sea
have been diverted for irrigation, it is drying
up and leaving behind a harmful layer of
chemical pesticides and natural salts; these
substances are then picked up by the wind
and blown into noxious dust storms; pollu¬
tion in the Caspian Sea; soil pollution from
overuse of agricultural chemicals and salina¬
tion from poor infrastructure and wasteful
irrigation practices
Environment — international agree¬
ments: party to: Air Pollution, Biodiversity,
Climate Change, Desertification, Endan¬
gered Species, Environmental Modification,
Hazardous Wastes, Ozone Layer Protec¬
tion, Ship Pollution, Wedands
signed, but not ratified: Climate Change-
Kyoto Protocol
Geography— note: landlocked; Russia
leases approximately 6,000 sq km of terri¬
tory enclosing the Baykonur Cosmodrome;
in January 2004, Kazakhstan and Russia
extended the lease to 2050','33f4a558e6b69118192fbbe20466713c8d1c8a5a6c405900a900b641df6d9bb2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f023f6a5ea01022bed01b7d7f4664c928760bbb0f8a3a6cc76d36244e6699ce',2010,'KE','Kenya','geography',900,'Location: Eastern Africa, bordering the
Indian Ocean, between Somalia and
Tanzania
Geographic coordinates: l 00 N, 38 00
E
Map references: Africa
Area: total: 582,650 sq km
land: 569,250 sq km
water: 13,400 sq km
Area — comparative: slighdy more than
twice the size of Nevada
Land boundaries: total: 3,477 km
border countries: Ethiopia 861 km, Somalia
682 km, Sudan 232 km, Tanzania 769 km,
Uganda 933 km
Coastline: 536 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: varies from tropical along coast to
arid in interior
Terrain: low plains rise to central high¬
lands bisected by Great Rift Valley; fertile
plateau in west
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: limestone, soda ash,
salt, gemstones, fluorspar, zinc, diatomite,
gypsum, wildlife, hydropower
Land use: arable land: 8.01%
permanent crops: 0.97%
other: 91.02% (2005)
Irrigated land: 1,030 sq km (2003)
Total renewable water resources: 30.2 cu
km (1990)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.58 cu km/yr
(30%/6%/64%)
per capita: 46 cu m/yr (2000)
Natural hazards: recurring drought;
flooding during rainy seasons
Environment — current issues: water
pollution from urban and industrial
wastes; degradation of water quality from
increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria;
deforestation; soil erosion; desertification;
poaching
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wedands,
Whaling
signed, but not ratified: none of the selected
agreements
GfiOgraphy — note: the Kenyan Highlands
comprise one of the most successful agricul¬
tural production regions in Africa; glaciers
are found on Mount Kenya, Africa’s
second highest peak; unique physiography
supports abundant and varied wildlife of
scientific and economic value','3d1722a7ff986941b6ae3591ab95e1353e579319cf486a5dd2b27e31b6441962','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8de52bf6df333cfdeba4761684b7e5128e641c205fa931ecc144dca5a4f130cc',2010,'KI','Kiribati','geography',908,'Location: Oceania, group of 33 coral
atolls in the Pacific Ocean, straddling the
Equator; the capital Tarawa is about half
way between Hawaii and Australia; note-
on 1 January 1995, Kiribati proclaimed
that all of its territory was in the same time
zone as its Gilbert Islands group (UTC
+12) even though the Phoenix Islands and
the Line Islands under its jurisdiction were
on the other side of the International Date
Line
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area: total: 811 sq km
land: 811 sq km
water: 0 sq km
note: includes three island groups— Gilbert
Islands, Line Islands, Phoenix Islands
Area— comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; marine, hot and humid,
moderated by trade winds
Terrain: mostly low-lying coral atolls
surrounded by extensive reefs
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location on Banaba
81 m
Natural resources: phosphate (production
discontinued in 1979)
Land use: arable land: 2.74%
permanent crops: 47.95%
other: 49.31% (2005)
Irrigated land: NA
Natural hazards: typhoons can occur any
time, but usually November to March;
occasional tornadoes; low level of some of
the islands make them sensitive to changes
in sea level
Environment— current issues: heavy
pollution in lagoon of south Tarawa atoll
due to heavy migration mixed with tradi¬
tional practices such as lagoon latrines and
open-pit dumping; ground water at risk
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: 21 of the 33 islands
are inhabited; Banaba (Ocean Island) in
Kiribati is one of the three great phosphate
rock islands in the Pacific Ocean— the
others are Makatea in French Polynesia,
and Nauru
Location: Eastern Asia, northern half of
the Korean Peninsula bordering the Korea
Bay and the Sea of Japan, between China
and South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area: total: 120,540 sq km
land: 120,410 sq km
water: 1 30 sq km
Area — comparative: slightly smaller than
Mississippi
Land boundaries: total, l ,673 km
border countries: China 1,416 km, South
Korea 238 km, Russia 19 km
Coastline: 2,495 km
Maritime claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
note: military boundary line 50 nm in the
Sea of Japan and the exclusive economic
zone limit in the Yellow Sea where all
foreign vessels and aircraft without permis¬
sion are banned
Climate: temperate with rainfall concen¬
trated in summer
Terrain: mosdy hills and mountains sepa¬
rated by deep, narrow valleys; coastal plains
wide in west, discontinuous in east
Elevation extremes: lowest point: Sea of
Japan 0 m
highest point: Paektu-san 2,744 m
Natural resources: coal, lead, tungsten,
zinc, graphite, magnesite, iron ore, copper,
gold, pyrites, salt, fluorspar, hydropower
Land use: arable land: 22.4%
permanent crops: 1 .66%
other: 75.94% (2005)
irrigated land: 14,600 sq km (2003)
Total renewable water resources: 77.1 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 9.02 cu km/yr
(20%/25%/55%)
per capita: 401 cu m/yr (2000)
Natural hazards: late spring droughts
often followed by severe flooding; occa¬
sional typhoons during the early fall
Environment — current issues: water
pollution; inadequate supplies of potable
water; waterborne disease; deforestation;
soil erosion and degradation
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Environmental
Modification, Hazardous Wastes, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: Law of the Sea
Geography— note: strategic location
bordering China, South Korea, and
Russia; mountainous interior is isolated
and sparsely populated
Location: Eastern Asia, southern half of
the Korean Peninsula bordering the Sea of
Japan and the Yellow Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area: total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Area— comparative: slightly larger than
Indiana
Land boundaries: total. 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims: territorial sea: 12 nm;
between 3 nm and 12 nm in the Korea
Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: temperate, with rainfall heavier
in summer than winter
Terrain: mostly hills and mountains; wide
coastal plains in west and south
Elevation extremes: lowest point: Sea of
Japan 0 m
highest point: Halla-san 1 ,950 m
Natural resources: coal, tungsten,
graphite, molybdenum, lead, hydropower
potential
Land use: arable land: 16.58%
permanent crops: 2.01%
other: 81.41% (2005)
Irrigated land: 8,780 sq km (2003)
Total renewable water resources: 69.7 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 18.59 cu km/yr
(36%/l 6%/48%)
per capita: 389 cu m/yr (2000)
Natural hazards: occasional typhoons
bring high winds and floods; low-level
seismic activity common in southwest
Environment— current issues: air pollu¬
tion in large cities; acid rain; water pollu¬
tion from die discharge of sewage and
industrial effluents; drift net fishing
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifica¬
tion, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location on
Korea Strait
Location: Southeast Europe, between
Serbia and Macedonia
Geographic coordinates: 42 35 N, 21 00 E
Map references: Europe
Area: total: 10,887 sq km
land: 10,887 sq km
water: 0 sq km
Area— comparative: slighdy larger than
Delaware
Land boundaries: total: 702 km
border countries: Albania 112 km, Mace¬
donia 159 km, Montenegro 79 km, Serbia
352 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: influenced by continental air
masses resulting in relatively cold winters
with heavy snowfall and hot, dry summers
and autumns; Mediterranean and alpine
influences create regional variation;
maximum rainfall between October and
December
Terrain: flat fluvial basin with an elevation
of 400-700 m above sea level surrounded
by several high mountain ranges with eleva¬
tions of 2,000 to 2,500 m
Elevation extremes: lowest point: Drini i
Bardhe/Beli Drim 297 m (located ori the
border with Albania)
highest point: Gjeravica/Deravica 2,656 m
Natural resources: nickel, lead, zinc,
magnesium, lignite, kaolin, chrome,
bauxite','e4e894b4e56114b9a894ccc60cc30a18e931dcc91b6a64bb640815c946ed95f0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84892946743dd8275d2498bbf2780f1800aa7fc50b085d19035b18564483705a',2010,'KW','Kuwait','geography',917,'Location: Middle East, bordering die Persian
Gulf, between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
Area— comparative: slightly smaller than
New Jersey
Land boundaries: total 462 km
border countries: Iraq 240 km, Saudi Arabia
222 km
Coastline: 499 km
Maritime Claims: territorial sea : 12 nm
Climate: dry desert; intensely hot summers;
short, cool winters
Terrain: flat to slightly undulating desert
plain
Elevation extremes: lowest point: Persian
Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish,
shrimp, natural gas
Land use: arable land: 0.84%
permanent crops: 0.17%
other: 98.99% (2005)
Irrigated land: 130 sq km (2003)
Total renewable water resources: 0.02 qu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.44 cu km/yr
(45%/2%/52%)
per capita: 164 cu m/yr (2000)
Natural hazards: sudden cloudbursts are
common from October to April and bring
heavy rain, which can damage roads and
houses; sandstorms and dust storms occur
throughout the year but are most common
between March and August
Environment — current issues: limited
natural fresh water resources; some of
world’s largest and most sophisticated desal¬
ination facilities provide much of the water;
air and water pollution; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: Marine Dumping
Geography— note: strategic location at
head of Persian Gulf','f6d8e86f92042cb72d5258c9145b7c8f051ddde3546d4f7630736f53f7321b69','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7290f588ab91428f9a7cc8e2a56a842c45dafd38203ef0328b8cf10fbac88da',2010,'KG','Kyrgyzstan','geography',926,'Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Asia
Area: total: 198,500 sq km
land: 191 ,300 sq km
water: 7,200 sq km
Area — comparative: slightly smaller than
South Dakota
Land boundaries: total: 3,051 km
border countries: China 858 km, Kazakhstan
1,224 km, Tajikistan 870 km, Uzbekistan
1,099 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: dry continental to polar in
high Tien Shan; subtropical in southwest
(Fergana Valley); temperate in northern
foothill zone
Terrain: peaks of Tien Shan and associated
valleys and basins encompass entire nation
Elevation extremes: lowest point: Kara-
Daryya (Karadar’ya) 132 m
highest point: Jengish Chokusu (Pik Pobedy)
7,439 m
Natural resources: abundant hydropower;
significant deposits of gold and rare earth
metals; locally exploitable coal, oil, and
natural gas; other deposits of nepheline,
mercury, bismuth, lead, and zinc
Land use: arable land: 6.55%
permanent crops: 0.28%
other: 93.1 7%
note: Kyrgyzstan has the world’s largest
natural-growth walnut forest (2005)
Irrigated land: 10,720 sq km (2003)
Totai renewable water resources: 46.5 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 10.08 cu km/yr
(3%/3%/94%)
per capita: 1,916 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: water
pollution; many people get their water
directly from contaminated streams and
wells; as a result, water-borne diseases
are prevalent; increasing soil salinity from
faulty irrigation practices
Environment— international agreements:
party to: Air Pollution, Biodiversity, Climate
381
THE CIA WORLD FACTBOOK
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; entirely
mountainous, dominated by the Tien Shan
range; many tall peaks, glaciers, and high-
altitude lakes','082b189ece8c09aea6e66ad111b9b22ddbb93afd8824ebd541fa1b078e63dd4d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('122adb057250a4b9bfe471bee5af8128dd4b54dc5d6c8d99077c41c5c4300db5',2010,'TH','Thailand','geography',933,'Location: Southeastern Asia, northeast of
Thailand, west of Vietnam
Geographiccoordinates: 1800N, 10500E
Map references: Southeast Asia
Area: total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area— comparative: slightly larger than
Utah
Land boundaries: total: 5,083 km
border countries: Burma 235 km, Cambodia
541 km, China 423 km, Thailand 1 ,754
km, Vietnam 2,1 30 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical monsoon; rainy season
(May to November); dry season (December
to April)
Terrain: mostly rugged mountains; some
plains and plateaus
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,81 7 m
Natural resources: timber, hydropower,
gypsum, tin, gold, gemstones
Land use: arable land : 4.01%
permanent crops: 0.34%
other: 95.65% (2005)
Irrigated land: 1,750 sq km (2003)
Total renewable water resources: 333.6
cu km (2003)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 3 cu km/yr
(4%/6%/90%)
per capita: 507 cu m/yr (2000)
Natural hazards: floods, droughts
Environment— current issues: unex¬
ploded ordnance; deforestation; soil
erosion; most of the population does not
have access to potable water
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; most of the
country is mountainous and thickly forested;
the Mekong River forms a large part of the
western boundary with Thailand
Location: Southeastern Asia, bordering
the Andaman Sea and the Gulf of Thai¬
land, southeast of Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area: total: 514,000 sq km
land: 511,770 sq km
water: 2,230 sq km
Area — comparative: slightly more than
twice the size of Wyoming
Land boundaries: total 4,863 km
border countries: Burma 1,800 km,
Cambodia 803 km, Laos 1,754 km,
Malaysia 506 km
Coastline: 3,219 km
Maritime Claims: territorial sea : 12 nm
exclusive economic zone : 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical; rainy, warm, cloudy
southwest monsoon (mid-May to
September); dry, cool northeast monsoon
(November to mid-March); southern
isthmus always hot and humid
Terrain: central plain; Khorat Plateau in
the east; mountains elsewhere
Elevation extremes: lowest point: Gulf of
Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural
gas, tungsten, tantalum, timber, lead, fish,
gypsum, lignite, fluorite, arable land
Land use: arable land: 27.54%
permanent crops: 6.93%
other : 65.53% (2005)
Irrigated land: 49,860 sq km (2003)
Total renewable water resources: 409.9
cu km (1999)
Freshwater withdrawal (domestic/indus- .
trial/agricultural): total: 82.75 cu km/yr
(2%/2%/95%)
per capita: 1 ,288 cu m/yr (2000)
Natural hazards: land subsidence in
Bangkok area resulting from the depletion
of the water table; droughts
Environment— current issues: air pollution
from vehicle emissions; water pollution
from organic and factory wastes; defor¬
estation; soil erosion; wildlife populations
threatened by illegal hunting
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Marine Life Conservation, Ozone
Layer Protection, Tropical Timber 83,
Tropical Timber 94, Wedands
signed, but not ratified: Law of the Sea
Geography — note: controls only land
route from Asia to Malaysia and Singapore','4ed3c132ff7608ac6f96ca0ef271c41551ca755034f3a1f6c4581cf02f3b63cd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd633fc9bda7f9229c6a3d5ca1040dcd79e4659f0971fe6166ade342ecb44fe4',2010,'LV','Latvia','geography',941,'Location: Eastern Europe, bordering the
Baltic Sea, between Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area: total: 64,589 sq km
land: 63,589 sq km
water: 1 ,000 sq km
Area — comparative: slighdy larger than
West Virginia
Land boundaries: total: 1,382 km
border countries: Belarus 171 km, Estonia
343 km, Lithuania 576 km, Russia 292
km
Coastline: 498 km
Maritime claims:
territorial sea : 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Galzina Kalns 312 m
Natural resources: peat, limestone, dolo¬
mite, amber, hydropower, wood, arable
land
Land use: arable land: 28.19%
permanent crops: 0.45%
other: 71.36% (2005)
Irrigated land: 200 sq km
note: land in Latvia is often too wet and
in need of drainage not irrigation; approxi¬
mately 16,000 sq km or 85% of agricul¬
tural land has been improved by drainage
(2003)
Total renewable water resources: 49.9 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.25 cu
km/yr (55%/33%/12%)
per capita: 108 cu m/yr (2003)
Natural hazards: NA
Environment — current issues: Latvia’s
environment has benefited from a shift to
service industries after the country regained
independence; the main environmental
priorities are improvement of drinking
water quality and sewage system, house¬
hold, and hazardous waste management, as
well as reduction of air pollution; in 2001 ,
Latvia closed the EU accession negotiation
chapter on environment committing to full
enforcement of EU environmental direc¬
tives by 2010
Environment— international agreements'':
party to : Air Pollution, Air Pollution-Persistent
Organic Pollutants, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of die Sea, Ozone
Layer Protection, Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: most of the country is
composed of fertile, low-lying plains, with
some hills in the east','e468b5746efa20ca895a8076c4e07a946b54550ad144ff0db0f19a338d11cc24','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb7f5482951240ffa3eb92d4ef108c44c4c326f6d7f483fc858f844b103ce6f7',2010,'ZA','South Africa','geography',953,'Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; cool to cold, dry
winters; hot, wet summers
Terrain: mostly highland with plateaus,
hills, and mountains
Elevation extremes: lowest point: junc¬
tion of the Orange and Makhaleng Rivers
1,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural
and grazing land, diamonds, sand, clay,
building stone
Land use: arable land: 10.87%
permanent crops: 0.13%
other: 89% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 5.2 cu
km (1987)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.05 cu km/yr
(40%/40%/20%)
per capita: 28 cu m/yr (2000)
Natural hazards: periodic droughts
Environment — current issues: population
pressure forcing settlement in marginal
areas results in overgrazing, severe soil
erosion, and soil exhaustion; desertifica¬
tion; Highlands Water Project controls,
stores, and redirects water to South Africa
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conser¬
vation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — -note: landlocked, completely
surrounded by South Africa; mountainous,
more than 80% of the country is 1 ,800 m
above sea level','fec562d0fe36493097324d11945f268f349d2f33b66922ea58c4d86e75be1e0f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57cf4ff8376c8ae185a75224b283143eb5b1f5db54a44df92b93b7e2cc225355',2010,'LR','Liberia','geography',962,'Location: Western Africa, bordering
the North Adantic Ocean, between Cote
d’Ivoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area: total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
Area — comparative: slighdy larger than
Tennessee
Land boundaries: total: 1,585 km
border countries: Guinea 563 km, Cote
d’Ivoire 716 km, Sierra Leone 306 km
Coastline: 579 km
Maritime Claims: territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters
with hot days and cool to cold nights;
wet, cloudy summers with frequent heavy
showers
Terrain: mostly dat to rolling coastal plains
rising to rolling plateau and low mountains
in northeast
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber,
diamonds, gold, hydropower
Land use: arable land: 3.43%
permanent crops: 1.98%
other: 94.59% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 232 cu
km (1987)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.11 cu km/yr
(27%/18%/55%)
per capita: 34 cu m/yr (2000)
Natural hazards: dust-laden harmattan
winds blow from the Sahara (December to
March)
Environment — current issues: tropical
rain forest deforestation; soil erosion; loss
of biodiversity; pollution of coastal waters
from oil residue and raw sewage
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental
Modification, Marine Life Conservation
Geography — note: facing the Atlantic
Ocean, the coastline is characterized by
lagoons, mangrove swamps, and river-
deposited sandbars; the inland grassy
plateau supports limited agriculture','de2793ca84c5beb35ac8e92fbc52c08803deb254b611844e56e9b2082c46bf69','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48dba35f35afa1e51eba9126847db6d60f9c2fefe5aa91ddde951fe116313e39',2010,'LY','Libya','geography',966,'Location: Northern Africa, bordering the
Mediterranean Sea, between Egypt and
Geographic coordinates:
34 00 N, 9 00 E
Map references: Africa
Area:
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Area — comparative: slightly larger than','987c4c5278fb9286c99413aafb0daa41546e715338fb73a109d393772479dc45','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4b876234179dbb3bf7701e21d956d2ffef652fec017dfce59b70dd9cc985b14',2010,'LI','Liechtenstein','geography',973,'Location: Central Europe, between Austria
and Switzerland
Geographic coordinates: 47 16 N, 9 32 E
Map references: Europe
Area: total: 160 sq km
land: 1 60 sq km
water: 0 sq km
Area — comparative: about 0.9 times the
size of Washington, DC
Land boundaries: total. 76 km
border countries: Austria 34.9 km, Switzer¬
land 41.1 km
Coastline: 0 km (doubly landlocked)
Maritime Claims: none (landlocked)
Climate: continental; cold, cloudy winters
with frequent snow or rain; cool to moder¬
ately warm, cloudy, humid summers
Terrain: mosdy mountainous (Alps) with
Rhine Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Vorder-Grauspitz 2,599 m
Natural resources: hydroelectric potential,
arable land
Land use: arable land: 25%
permanent crops: 0%
other: 75% (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: NA
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollu¬
tion-Volatile Organic Compounds,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography — note: along with Uzbekistan,
one of only two doubly landlocked coun¬
tries in the world; variety of microclimatic
variations based on elevation','0b8bffe117071beae3b267b581c04eb27bb8d5d28439cd3f6922a39a2f45bc2f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff4fa07dad44e575067bbd5e990caacc2851561cf03536499402f589a8f6ef45',2010,'LT','Lithuania','geography',980,'Location: Eastern Europe, bordering the
Baltic Sea, between Latvia and Russia
Geographic coordinates: 56 00 N,
24 00 E
Map references: Europe
Area: total: 65,300 sq km
land: NA sq km
water: NA sq km
Area — comparative: slightly larger than
West Virginia
Land boundaries: total: 1,574 km
border countries: Belarus 680 km, Latvia
576 km, Poland 91 km, Russia (Kalinin¬
grad) 111 km
Coastline: 90 km
Maritime claims: territorial sea: 12 nm
Climate: transitional, between maritime
and continental; wet, moderate winters
and summers
Terrain: lowland, many scattered small
lakes, fertile soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines Kalnas 294 m
Natural resources: peat, arable land,
amber
Land use: arable land: 44.81%
permanent crops: 0.9%
other: 54.29% (2005)
Irrigated land: 70 sq km (2003)
Total renewable water resources: 24.5 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 3.33 cu km/yr
(78%/15%/7%)
per capita: 971 cu m/yr (2003)
406
Natural hazards: NA
Environment— current issues: contami¬
nation of soil and groundwater with petro¬
leum products and chemicals at military
bases
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulphur
85, Air Pollution-Sulphur 94, Air Pollution-
Volatile Organic Compounds, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: fertile central plains are
separated by hilly uplands that are ancient
glacial deposits','1bf9d4f43c44930db0f1ca1c19be5ccc4bc01081583bf7f01bc8efeb7e99dcc9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ce31b76c70b8e16e5070ffd82c2189a7a2e00d77d3398b2ccb5482d56afb43b',2010,'LU','Luxembourg','geography',989,'Location: Western Europe, between France
and Germany
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area: total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Rhode Island
Land boundaries:
total: 359 km
409
THE CIA WORLD FACTBOOK
border countries: Belgium 148 km, France
73 km, Germany 138 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: modified continental with mild
winters, cool summers
Terrain: mostly gently rolling uplands
with broad, shallow valleys; uplands to
slighdy mountainous in the north; steep
slope down to Moselle flood plain in the
southeast
Elevation extremes: lowest point: Moselle
River 133 m
highest point: Buurgplaatz 559 m
Natural resources: iron ore (no longer
exploited), arable land
Land use: arable land: 27.42%
permanent crops: 0.69%
other: 71.89% (includes Belgium) (2005)
Irrigated land: NA
Total renewable water resources: 1.6 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.06 cu km/yr
(42%/45%/13%)
per capita: 121 cu m/yr (1999)
Natural hazards: NA
Environment — current issues: air and
water pollution in urban areas, soil pollu-
tion of farmland
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollu¬
tion-Volatile Organic Compounds,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wedands
signed, but not ratified: Environmental
Modification
Geography — note: landlocked; the only
Grand Duchy in the world
Location: Eastern Asia, bordering the
South China Sea and China
Geographic coordinates: 22 ION, 113
33 E
Map references:
Southeast Asia
Area: total: 28.2 sq km
land: 28.2 sq km
water: 0 sq km
Area — comparative: less than one-sixth
the size of Washington, DC
Land boundaries: total: 0.34 km
regional border: China 0.34 km
Coastline: 41 km
Maritime claims: not specified
Climate: subtropical; marine with cool
winters, warm summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 172 m
Natural resources: NEGL
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: typhoons
Environment — current issues: NA
Environment— international agreements:
party to: Marine Dumping (associate
member), Ship Pollution (associate
member)
Geography — note: essentially urban; an
area of land reclaimed from the sea meas¬
uring 5.2 sq km and known as Cotai now
connects the islands of Coloane and Taipa;
the island area is connected to the main¬
land peninsula by three bridges','39cbf024897122e56cedfab4da1a51de5b6a6f2438037b2a1e03dafc30e2dfe3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b4693ea7f69f00eafc8f3096a4669b065747855b184c8431bdcfaea8602c52e',2010,'MG','Madagascar','geography',995,'Location: Southern Africa, island in the
Indian Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area: total: 587,040 sq km
land: 581,540 sq km
water: 5,500 sq km
Area — comparative: slightly less than
twice the size of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone : 200 nm
continental shelf: 200 nm or 100 nm from
the 2,500-m isobath
Climate: tropical along coast, temperate
inland, arid in south
Terrain : narrow coastal plain, high plateau
and mountains in center
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite,
coal, bauxite, salt, quartz, tar sands, semi¬
precious stones, mica, fish, hydropower
Land use: arable land: 5.03%
permanent crops: 1.02%
other: 93.95% (2005)
Irrigated land: 10,860 sq km (2003)
Total renewable water resources: 337 cu
km (1984)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 14.96 cu km/yr
(3%/2%/96%)
per capita: 804 cu m/yr (2000)
Natural hazards: periodic cyclones;
drought; and locust infestation
Environment — current issues: soil
erosion results from deforestation and
overgrazing; desertification; surface water
contaminated with raw sewage and other
organic wastes; several endangered species
of flora and fauna unique to the island
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: world’s fourth-largest
island; strategic location along Mozam¬
bique Channel','96ac9262fdab8cb8471ea261843eb38a3c5ae220073c161339a225499612c904','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cac67c954b225aa0a2fe22e19706b491604ec7ed07d4c8fc387a9bfc308526b',2010,'MW','Malawi','geography',1004,'Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area: total: 118,480 sq km
land: 94,080 sq km
water: 24,400 sq km
Area — comparative: slightly smaller than
Pennsylvania
Land boundaries: total: 2,881 km
border countries: Mozambique 1,569 km,
Tanzania 475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: sub-tropical; rainy season
(November to May); dry season (May to
November)
Terrain: narrow elongated plateau with
rolling plains, rounded hills, some moun¬
tains
Elevation extremes: lowest point: junc¬
tion of the Shire River and international
boundary with Mozambique 37 m
highest point: Sapitwa (Mount. Mlanje)
3,002 m
Natural resources: limestone, arable
land, hydropower, unexploited deposits of
uranium, coal, and bauxite
Land use: arable land: 20.68%
permanent crops: 1.18%
other: 78.14% (2005)
Irrigated land: 560 sq km (2003)
Total renewable water resources: 1 7.3''th
km (2001)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.01 cu km/yr
(15%/5%/80%)
per capita: 78 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: defor¬
estation; land degradation; water pollution
from agricultural runoff, sewage, indus¬
trial wastes; siltation of spawning grounds
endangers fish populations
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Wedands
signed, but not ratified: Law of the Sea
Geography— note: landlocked; Lake
Nyasa, some 580 km long, is the country’s
most prominent physical feature','73d5e3bacc101ebf93c00cf7dda5fe2799ac0c727b32ae493d3fb8102b619aef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab6c25ba74fdf88f353679d0562e2a558120623aa646596bb964e966611720bc',2010,'MY','Malaysia','geography',1007,'Location: Southeastern Asia, peninsula
bordering Thailand and northern one-
third of the island of Borneo, bordering
Indonesia, Brunei, and the South China
Sea, south of Vietnam
Geographic coordinates: 2 30 N, 112 30 E
Map references: Southeast Asia
Area: total: 329,750 sq km
land: 328,550 sq km
■water: 1 ,200 sq km
Area — comparative: slightly larger than
New Mexico
Land boundaries: total 2,669 km
border countries: Brunei 381 km, Indonesia
1,782 km, Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia
2,068 km, East Malaysia 2,607 km)
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation; specified boundary
in the South China Sea
Climate: tropical; annual southwest (April
to October) and northeast (October to
February) monsoons
Terrain: coastal plains rising to hills and
mountains
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum, timber,
copper, iron ore, natural gas, bauxite
Land use: arable land: 5.46%
permanent crops: 17.54%
other: 77% (2005)
Irrigated land: 3,650 sq km (2003)
Total renewable water resources: 580 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 9.02 cu km/yr
(1 7%/21%/62%)
per capita: 356 cu m/yr (2000)
Natural hazards: flooding; landslides;
forest fires
Environment— current issues: air pollu¬
tion from industrial .and vehicular emis¬
sions; water pollution from raw sewage;
deforestation; smoke/haze from Indone¬
sian forest fires
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location along
Strait of Malacca and southern South
China Sea','b91cab5c376d4819c49fce8fdffe4f071acc89309bd57d4c7b65b63bc005b98e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6c30981129db76b04424f7b0dce0396bd9ba197c7f41a461368296af348fa55',2010,'MV','Maldives','geography',1016,'Location: Southern Asia, group of atolls
in the Indian Ocean, south-southwest of','8590cd2bacda37a8c62496aa1397ac6a3ad3528377c4a7c597e1c7f1176793bd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2c2aab481f3069b99b47ac678172ca567640ffbcb4e6146a09e992882f7f0d9',2010,'MT','Malta','geography',1025,'Location: Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 1 4 35 E
Map references: Europe
Area: total: 316 sq km
land: 316 sq km
water: 0 sq km
Area — comparative: slightly less than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 196.8 km (excludes 56.01 km
for the island of Gozo)
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: 200 m depth or to the
depth of exploitation
exclusive fishing zone: 25 nm
Climate: Mediterranean; mild, rainy
winters; hot, dry summers
Terrain: mostly low, rocky, flat to dissected
plains; many coastal cliffs
Elevation extremes: lowest point: Mediter¬
ranean Sea 0 m
highest point: Ta’Dmejrek 253 m (near
Dingli)
Natural resources: limestone, salt, arable
land
Land use: arable land: 31.25%
permanent crops: 3.13%
other: 65.62% (2005)
Irrigated land: 20 sq km (2003)
Total renewable water resources: 0.07 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.02 cu km/yr
(74%/l%/25%)
per capita: 50 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: limited
natural fresh water resources; increasing
reliance on desalination
Environment — international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: the country comprises
an archipelago, with only the three largest
islands (Malta, Ghawdex or Gozo, and
Kemmuna or Comino) being inhabited;
numerous bays provide good harbors;
Malta and Tunisia are discussing the
commercial exploitation of the continental
shelf between their countries, particularly
for oil exploration','5320c907904091b52c759dbc78cc5ced2a3f50b1a8692f8264f93bff311c78cc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('347fa3efcdf3e505ee32effbb5cbc1768ed7263ac2ca8ebdfdefe73a14642489',2010,'MH','Marshall Islands','geography',1035,'Location: Oceania, two archipelagic island
chains of 29 atolls, each made up of many
small islets, and five single islands in
the North Pacific Ocean, about half way
between Hawaii and Australia
Geographic coordinates: 9 00 N, 1 68 00 E
Map references: Oceania
Area: total: 181.3 sq km
land: 181.3 sq km
water: 0 sq km
note: the archipelago includes 11,673 sq
km of lagoon waters and includes the atolls
437
THE CIA WORLD FACTBOOK
of Bikini, Enewetak, Kwajalein, Majuro,
Rongelap, and Utirik
Area — comparative: about the size of
Washington, DC
Land boundaries: 0 km
Coastline: 370.4 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; wet
season May to November; islands border
typhoon belt
Terrain: low coral limestone and sand
islands
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location on Likiep
10 m
Natural resources: coconut products,
marine products, deep seabed minerals
Land use: arable land: 11.11%
permanent crops: 44.44%
other: 44.45% (2005)
Irrigated land: 0 sq km
Natural hazards: infrequent typhoons
Environment — current issues: inadequate
supplies of potable water; pollution of
Majuro lagoon from household waste and
discharges from fishing vessels
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution,
Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: the islands of Bikini
and Enewetak are former US nuclear test
sites; Kwajalein atoll, famous as a World
War II battleground, surrounds the world’s
largest lagoon and is used as a US missile
test range; the island city of Ebeye is the
second largest settlement in the Marshall
Islands, after the capital of Majuro, and
one of the most densely populated loca¬
tions in the Pacific','9148fcbb5ee53a50391714ad7c919d8d4440fa80e9190db2b9f1d7b3d7ad7823','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c66c2c32baa245ad9b35d79159de999dbe113e5ac117c11e61c6943d3d94970',2010,'MR','Mauritania','geography',1039,'Location: Northern Africa, bordering the
North Adantic Ocean, between Senegal
and Western Sahara
Geographiccoordinates:2000N,l200W
Map references: Africa
Area: total: 1,030,700 sq km
land: 1 ,030,400 sq km
water: 300 sq km
Area — comparative: slightly larger than
three times the size of New Mexico
Land boundaries: total: 5,074 km
border countries: Algeria 463 km, Mali
2,237 km, Senegal 813 km, Western
Sahara 1,561 km
Coastline: 754 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the
Sahara; some central hills
Elevation extremes: lowest point: Sebkhet
Te-n-Dghamcha -5 m
highest point: Kediet Ijill 915 m
Natural resources: iron ore, gypsum,
copper, phosphate, diamonds, gold, oil, fish
Land use: arable land: 0.2%
permanent crops: 0.01%
other: 99.79% (2005)
Irrigated land: 490 sq km (2002)
Total renewable water resources: 1 1 .4 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.7 cu km/yr
(9%/3%/88%)
per capita: 554 cu m/yr (2000)
Natural hazards: hot, dry, dust/sand-laden
sirocco wind blows primarily in March and
April; periodic droughts
Environment — current issues: over-
grazing, deforestation, and soil erosion
aggravated by drought are contributing to
desertification; limited natural fresh water
resources away from the Senegal, which is
the only perennial river; locust infestation
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: most of the population
concentrated in the cities of Nouakchott
and Nouadhibou and along the Senegal
River in the southern part of the country','02841877cff047fe6494b601c224239a39d43a3c18efb04a5cf317e1116c7d4b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75d3a3b063f566e899283db083887b95dce9b558fdafc73929cd23553ab8adee',2010,'MU','Mauritius','geography',1048,'Location: Southern Africa, island in the
Indian Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: Political Map of the
World
Area: total: 2,040 sq km
land: 2,030 sq km
water: 1 0 sq km
note: includes Agalega Islands, Cargados
Carajos Shoals (Saint Brandon), and
Rodrigues
Area— comparative: almost 1 1 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 177 km
Maritime Claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 20 0 nm or to the edge of
the continental margin
Climate: tropical, modified by southeast
trade winds; warm, dry winter (May to
November); hot, wet, humid summer
(November to May)
Terrain: small coastal plain rising to
discontinuous mountains encircling central
plateau
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Mont Piton 828 m
Natural resources: arable land, fish
believed to be volunteers; service in Air
Force and Navy is voluntary (2006)
Manpower available for military
Service: males age 16-49: 740,675
females age 1 6-49: 744,709 (2008 est.)
Manpower fit for military service:
males age 16-49: 450,289
females age 16-49: 544,598 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male: 34,546
female: 35,272 (2009 est.)
Miljtaryexpenditures:5.5%ofGDP(2006)
Location: Southern Indian Ocean, island
in the Mozambique Channel, about half
way between northern Madagascar and
northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area: total: 374 sq km
land: 374 sq km
water: 0 sq km
Area — comparative: slighdy more than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; marine; hot, humid,
rainy season during northeastern monsoon
(November to May); dry season is cooler
(May to November)
Terrain: generally undulating, with deep
ravines and ancient volcanic peaks
Manpower reaching militarily significant
age annually: male: 10,901
female: 10,796 (2009 est.)
Military expenditures: 0.3% of GDP
(2006 est.)','d4347ffaff73907ba7384eeb1290c7c1a402efc2c5766a596ab30205f8d5e11b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7924cd0e4d32d3e7b5432ceee3e381107c4affb974bc72461baaed4df302cb99',2010,'FM','Micronesia, Federated States of','geography',1065,'Location: Oceania, island group in the
North Pacific Ocean, about three-quarters
of the way from Hawaii to Indonesia
Geographic coordinates: 6 55 N, 1 58 1 5 E
Map references: Oceania
Area: total: 702 sq km
land: 702 sq km
water: 0 sq km (fresh water only)
note: includes Pohnpei (Ponape), Chuuk
(Truk) Islands, Yap Islands, and Kosrae
(Kosaie)
Area — comparative: four times the size of
Washington, DC (land area only)
Land boundaries: 0 km
Coastline: 6,112 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; heavy year-round rain¬
fall, especially in the eastern islands;
located on southern edge of the typhoon
belt with occasionally severe damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls;
volcanic outcroppings on Pohnpei, Kosrae,
and Chuuk
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Dolohmwar (Totolom) 791
m
Natural resources: forests, marine prod¬
ucts, deep-seabed minerals, phosphate
Land use: arable land: 5.71% •
permanent crops: 45.71%
Other: 48.58% (2005)
Irrigated land: NA
Natural hazards: typhoons (June to
December)
Environment — current issues: over¬
fishing, climate change, pollution
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: four major island
groups totaling 607 islands
Location: Eastern Europe, northeast of','b317f76de2d9a126dd97617ec16cb9254c13204f209663863d7dfbec94e4f24c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f18698b60f6603a8bb81bfd737b73e11ba6e6a322ae76f9305c7d7c03c85e2f',2010,'MC','Monaco','geography',1078,'Location: Western Europe, bordering the
Mediterranean Sea on the southern coast
of France, near the border with Italy
Geographic coordinates:
43 44 N, 7 24 E
Map references: Europe
Area:
total: 1 .95 sq km
land: 1 .95 sq km
water: 0 sq km
Area — comparative: about three times the
size of The Mall in Washington, DC
Land boundaries: total: 4.4 km
border countries: France 4.4 km
Coastline: 4.1 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 12 nm
Climate: Mediterranean with mild, wet
winters and hot, dry summers
Transnistria region, which remains under
OSCE supervision
Trafficking in persons: current situa¬
tion: Moldova is a major source and, to a
lesser extent, a transit country for women
and girls trafficked for the purpose of
commercial sexual exploitation; Moldovan
women are trafficked to the Middle East,
Eastern Europe, and Western Europe;
girls and young women are trafficked
within the country from rural areas to
Chisinau; children are also trafficked to
neighboring countries for forced labor and
begging; labor trafficking of men to work
in the construction, agriculture, and service
sectors of Russia is increasingly a problem
tier rating: Tier 3— Moldova does not fully
comply with the minimum standards for
the elimination of trafficking and is not
making significant efforts to do so; the
government failed to follow-up on allega¬
tions of officials complicit in trafficking
cited in the 2007 Report, and it did not
demonstrate proactive efforts to identify
trafficking victims (2008)
Illicit drugs: limited cultivation of opium
poppy and cannabis, mostly for CIS
consumption; transshipment point for
illicit drugs from Southwest Asia via
Central Asia to Russia, Western Europe,
and possibly the US; widespread crime
and underground economic activity
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (urban area) (2005)
Irrigated land: NA
Natural hazards: NA
Environment — current issues: NA
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Sulfur 94, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: second-smallest inde¬
pendent state in the world (after Holy See);
almost entirely urban
457
THE CIA WORLD FACTBOOK','bd5c512e9e34f235ae7d4b31b3000eafdbf1d2ab17b827e4f20dada82a80a8c4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d041a916daaab3570ed0a68d911dfb3ef9ae88fee81921b28e0b68a095839803',2010,'MN','Mongolia','geography',1082,'Location: Northern Asia, between China
and Russia
Geographic coordinates: 46 00 N,
105 00 E
Map references: Asia
Area: total: 1,564,116 sq km
land: 1,554,731 sq km
water: 9,385 sq km
459
THE CIA WORLD FACTBOOK
Area— comparative: slightly smaller than
Alaska
Land boundaries: total: 8,220 km
border countries: China 4,677 km, Russia
3,543 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: desert; continental (large daily
and seasonal temperature ranges)
Terrain: vast semidesert and desert plains,
grassy steppe, mountains in west and
southwest; Gobi Desert in south-central
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Nayramadlin Orgil (Huyten
Orgil) 4,374 m
Natural resources: oil, coal, copper,
molybdenum, tungsten, phosphates, tin,
nickel, zinc, fluorspar, gold, silver, iron
Land use: arable land: 0.76%
permanent crops: 0%
Other: 99.24% (2005)
Irrigated land: 840 sq km (2003)
Total renewable water resources: 34.8 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.44 cu km/yr
(20%/27%/52%)
per capita : 166 cu m/yr (2000)
Natural hazards: dust storms; grassland
and forest fires; drought; “zud,” which is
harsh winter conditions
Environment— current issues: limited
natural fresh water resources in some areas;
file policies of former Communist regimes
promoted rapid urbanization and indus¬
trial growth that had negative effects on the
environment; the burning of soft coal in
power plants and the lack of enforcement
of environmental laws severely polluted
the air in Ulaanbaatar; deforestation, over-
grazing, and the converting of virgin land
to agricultural production increased soil
erosion from wind and rain; desertifica¬
tion and mining activities had a deleterious
effect on the environment
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; strategic
location between China and Russia','1c06b4c40546886eb1f11767a841e32215078a5a4125c585fc205c8a04cf92fe','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('324f00c0fed79c46897770a1fb5a00c3a658ff1ef8eb49f7cac3f73a91aa28e1',2010,'MS','Montserrat','geography',1096,'Location: Caribbean, island in the Carib¬
bean Sea, southeast of Puerto Rico
Geographic coordinates: 1 6 45 N, 62 1 2 W
Map references: Central America and the
Caribbean
Area: total: 102 sq km
country comparison to the world: 233
land: 102 sq km
water: 0 sq km
Area — comparative: about 0.6 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; little daily or seasonal
temperature variation
Terrain: volcanic island, mostly moun¬
tainous, with small coastal lowland
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: lava dome in English’s Crater
(in the Soufriere Hills volcanic complex)
estimated at over 930 m (2006)
Natural resources: NEGL
Land use: arable land: 20%
permanent crops: 0%
other: 80% (2005)
irrigated land: NA
Natural hazards: severe hurricanes (June to
November); volcanic eruptions (Soufriere
Hills volcano has erupted continuously
since 1995)
Environment — current issues: land
erosion occurs on slopes that have been
cleared for cultivation
Geography— note: the island is entirely
volcanic in origin and comprised of three
major volcanic centers of differing ages','f1fb68e431ef305517625818b28c50d2cafc71df711d89d213053c0990d35498','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('243e68eb00e9c2b473a7731ccd68d86a973f6ed1fdadbd1b229d0ca3044b5d2c',2010,'MA','Morocco','geography',1104,'Location: Northern Africa, bordering the
North Adantic Ocean and the Mediterra¬
nean Sea, between Algeria and Western
Sahara
Geographic coordinates: 32 00 N,
5 00 W
Map references: Africa
Area: total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
Area — comparative: slighdy larger than
California
Land boundaries: total: 2,017.9 km
border countries: Algeria 1 ,559 km, Western
Sahara 443 km, Spain (Ceuta) 6.3 km,
Spain (Melilla) 9.6 km
Coastline: 1,835 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: northern coast and interior are
mountainous with large areas of bordering
plateaus, intermontane valleys, and rich
coastal plains
Elevation extremes: lowest point: Sebkha
Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use: arable land: 19%
permanent crops: 2%
other: 19% (2005)
Irrigated land: 14,450 sq km (2003)
Total renewable water resources: 29 cu
km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 12.6 cu km/yr
(10%/3%/87%)
per capita: 400 cu m/yr (2000)
Natural hazards: northern mountains
geologically unstable and subject to earth¬
quakes; periodic droughts
Environment — current issues: land
degradation/ desertification (soil erosion
resulting from farming of marginal areas,
overgrazing, destruction of vegetation);
water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution
of coastal waters
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Environmental
Modification
Geography — note: strategic location along
Strait of Gibraltar','29799259d65f65b5c2cde0fe7fa7983aaa8c5e46d9b570a998ab47132af7e520','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3cc95fc512f308db1367fca60c8e6f8749bc8134f562475544f504b3ddc8ef0',2010,'MZ','Mozambique','geography',1109,'Location: Southeastern Africa, bordering
the Mozambique Channel, between South
Africa and Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area: total: 801,590 sq km
land: 784,090 sq km
water: 17,500 sq km
Area — comparative: slightly less than
twice the size of California
Land boundaries: total: 4,571 km
border countries: Malawi 1,569 km, South
Africa 491 km, Swaziland 1 05 km, Tanzania
756 km, Zambia 419 km, Zimbabwe 1,231
km
Coastline: 2,470 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands
in center, high plateaus in northwest,
mountains in west
Elevation extremes: lowest point: Indian
Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural
gas, hydropower, tantalum, graphite
Land use: arable land: 5.43%
permanent crops: 0.29%
other: 94.28% (2005)
Irrigated land: 1,180 sq km (2003)
Total renewable water resources: 216 cu
km (1992)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.63 cu km/yr
(ll%/2%/87%)
per capita: 32 cu m/yr (2000)
Natural hazards: severe droughts; devas¬
tating cyclones and floods in central and
southern provinces
Environment — current issues: a long civil
war and recurrent drought in the hinter¬
lands have resulted in increased migration
of the population to urban and coastal areas
with adverse environmental consequences;
desertification; pollution of surface and
coastal waters; elephant poaching for ivory
is a problem
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: die Zambezi flows
through the north-central and most fertile
part of the country
Location: Southern Africa, bordering the
South Atlantic Ocean, between Angola
and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area: total: 825,418 sq km
land: 825,418 sq km
water: 0 sq km
Area — comparative: slightly more than
half the size of Alaska
Land boundaries: total: 3,936 km
border countries: Angola 1,376 km,
Botswana 1,360 km, South Africa 967 km,
Zambia 233 km
Coastline: 1,572 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; hot, dry; rainfall sparse
and erratic
Terrain: mostly high plateau; Namib Desert
along coast; Kalahari Desert in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper,
uranium, gold, silver, lead, tin, lithium,
cadmium, tungsten, zinc, salt, hydropower,
fish
note: suspected deposits of oil, coal, and
iron ore
Land use:
arable land: 0.99%
permanent crops: 0.01%
other: 99% (2005)
Irrigated land:
80 sq km (2003)
Total renewable water resources: 45.5
cu km (1991)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.3 cu km/yr (24%/ 5%/7 1 %)
per capita: 148 cu m/yr (2000)
Natural hazards: prolonged periods of
drought
Environment — current issues: limited
natural fresh water resources; desertification;
wildlife poaching; land degradation has led
to few conservation areas
Environment — international agree¬
ments: party to: Antarctic-Marine Living
Resources, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected
agreements
GOOgraphy — note: first country in the
world to incorporate the protection of
the environment into its constitution;
some 14% of the land is protected,
including virtually the entire Namib Desert
coastal strip','e2633e462f18e65c5aefb530aa964c15537f14a9bd64919c5b04392152e7ab81','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e09026f514c4947de7a50e2c7ec86b7a31922ba131d02979159398e935ca8b5c',2010,'NR','Nauru','geography',1121,'Location:
Oceania, island in the South
Pacific Ocean, south of the Marshall
Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area: total: 21 sq km
land: 21 sq km
water: 0 sq km
Area— comparative: about 0.1 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical with a monsoonal pattern;
rainy season (November to February)
Terrain: sandy beach rises to fertile ring
V v.
around raised coral reefs with phosphate
plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along
plateau rim 61 m
Natural resources: phosphates, fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: periodic droughts
Environment — current issues: limited
natural fresh water resources, roof storage
tanks collect rainwater, but mostly depen¬
dent on a single, aging desalination plant;
intensive phosphate mining during the
past 90 years— mainly by a UK, Australia,
and NZ consortium— has left the central
90% of Nauru a wasteland and threatens
limited remaining land resources
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone
Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: Nauru is one of the
three great phosphate rock islands in
the Pacific Ocean— the others are Banaba
(Ocean Island) in Kiribati and Makatea
in French Polynesia; only 53 km south of
Equator
Location: Caribbean, island in the
Caribbean Sea, 35 miles west of Tiburon
Peninsula of Haiti
Geographic coordinates:
18 25 N, 75 02 W','c37b97d80fff99428f214037d2863d00bc8be9bd95d68ee17f95c384bee7d502','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25ffe92efd4164fdbb91ad875420b863332fe77f3731599d8a66636e6b918eaf',2010,'NP','Nepal','geography',1128,'Location: Southern Asia, between China
and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area: total: 147,181 sq km
land: 143,181 sq km
water: 4,000 sq km
Area — comparative: slightly larger than
Arkansas
Land boundaries: total: 2,926 km
border countries: China 1,236 km, India
1 ,690 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: varies from cool summers and
severe winters in north to subtropical
summers and mild winters in south
Terrain: Tarai or flat river plain of the
Ganges in south, central hill region, rugged
Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,850 m
Natural resources: quartz, water, timber,
hydropower, scenic beauty, small deposits
of lignite, copper, cobalt, iron ore
Land use: arable land: 16.07%
permanent crops: 0.85%
other: 83.08% (2005)
Irrigated land:
11,700 sq km (2003)
Total renewable water resources: 210.2
cu km (1999)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 10.18 cu km/yr (3%/l%/96%)
per capita: 375 cu m/yr (2000)
Natural hazards: severe thunderstorms;
flooding; landslides; drought and famine
depending on the timing, intensity, and
duration of the summer monsoons
Environment — current issues: defores¬
tation (overuse of wood for fuel and lack
of alternatives); contaminated water (with
human and animal wastes, agricultural
runoff, and industrial effluents); wildlife
conservation; vehicular emissions
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Marine Life
Conservation
Geography — note: landlocked; strategic
location between China and India;
contains eight of world’s 10 highest peaks,
including Mount Everest and Kanchen-
junga— the world’s tallest and third tallest-
on the borders with China and India
respectively','6528329c514dad32ceb2736d3c93b42e25bf574e0137c7a74c6ae139cf3b147f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db486367bcd5fa7c42ade8492b8548100aa79f8e4eae2a54089669afd4bc0939',2010,'NC','New Caledonia','geography',1137,'Location: Oceania, islands in the South
Pacific Ocean, east of Australia
Geographic coordinates: 21 30 S, 1 65 30 E
Map references: Oceania
Area: total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
Area — comparative: slightly smaller than
New Jersey
Land boundaries: 0 km
Coastline: 2,254 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast
trade winds; hot, humid
Terrain:
coastal plains with interior mountains
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Mont Panie 1,628 m
Natural resources: nickel, chrome, iron,
cobalt, manganese, silver, gold, lead,
copper
Land use: arable land: 0.32%
permanent crops: 0.22%
other: 99.46% (2005)
Irrigated land: 100 sq km (2003)
Natural hazards: cyclones, most frequent
from November to March
Environment— current issues: erosion
caused by mining exploitation and forest
fires
Geography— note: consists of die main
island of New Caledonia (one of the largest
in the Pacific Ocean), the archipelago of
lies Loyaute, and numerous small, sparsely
populated islands and atolls
Location: Oceania, islands in the South
Pacific Ocean, southeast of Australia
Geographic coordinates:
41 00 S, 174 00 E
Map references: Oceania','bf66ba6e1ad98af9e1aa5e99a9725da5ef55b4dcdc91eaf2dfd00eb529c54e35','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beeb02a77ca6d8e0a8e9df8fb30bc43d5120dddaea66ebd5dff8b7713d6c5ab9',2010,'NI','Nicaragua','geography',1151,'Location: Central America, bordering
both the Caribbean Sea and the North
Pacific Ocean, between Costa Rica and','a215d0d51c4a1f7485cc0e721363452437ca98c1ab7e37f3aeac23cf6468c0c7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d2a88611d50efeb9b3c3b3dee4ec045bbba4e498cf14a94db856925e3d1d578',2010,'NE','Niger','geography',1154,'Location: Western Africa, southeast of
Location: Western Africa, bordering
the Gulf of Guinea, between Benin and','3ed157ea0bfa8504ac280ee87c4866d2af28efb3ac37c252f0dd7e9a85273720','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e500215ebc05070279912c42e662b5349032c0446570b74bd8fdc58859f00c2',2010,'NG','Nigeria','geography',1160,'child trafficking victims were steady, the
government failed to provide services to or
rescue adult victims subjected to traditional
slavery practices, and made poor efforts to
educate the public about traditional slavery
practices in general (2008)
Area — comparative: slighdy more than
twice the size of California
Land boundaries: total: 4,047 km
border countries: Benin 773 km, Cameroon
1,690 km, Chad 87 km, Niger 1,497 km
Coastline: 853 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: varies; equatorial in south,
tropical in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus; mountains in
southeast, plains in north
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources: natural gas, petroleum,
tin, iron ore, coal, limestone, niobium,
lead, zinc, arable land
Land use: arable land: 33.02%
permanent crops: 3.14%
other: 63.84% (2005)
Irrigated land: 2,820 sq km (2003)
Total renewable water resources: 286.2
cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 8.01 cu
km/yr (21%/10%/69%)
per capita: 61 cu m/yr (2000)
Natural hazards: periodic droughts;
flooding
Environment— current issues: soil degra¬
dation; rapid deforestation; urban air
and water pollution; desertification; oil
pollution— water, air, and soil; has suffered
serious damage from oil spills; loss of
arable land; rapid urbanization
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
Goography — note: the Niger enters the
country in the northwest and flows south¬
ward through tropical rain forests and
swamps to its delta in the Gulf of Guinea','dac29780394a70d660356188aebea85544dc0fa266b6f20ed13c3659d827ffad','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96f66094e7c76daa0c9bf9c6e97ddc9f3821e60d861a24149ff3bb16dfb2427d',2010,'MP','Northern Mariana Islands','geography',1179,'Location: Oceania, islands in the North
Pacific Ocean, about three-quarters of the
way from Hawaii to the Philippines
Geographiccoordinates: 1 5 1 2 N, 14545 E
Map references: Oceania
Area: total: 477 sq km
land: 477 sq km
water: 0 sq km
note: consists of 14 islands including
Saipan, Rota, and Tinian
Area — comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,482 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; moderated
by northeast trade winds, little seasonal
temperature variation; dry season December
to June, rainy season July to October
Terrain: southern islands are limestone
with level terraces and fringing coral reefs;
northern islands are volcanic
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location on Agrihan
965 m
Natural resources: arable land, fish
Land use: arable land: 13.04%
permanent crops: 4.35%
other: 82.61% (2005)
Irrigated land: NA
Natural hazards: active volcanoes on
Pagan and Agrihan; typhoons (especially
August to November)
Environment — current issues: contami¬
nation of groundwater on Saipan may
contribute to disease; clean-up of landfill;
protection of endangered species conflicts
with development
Geography— note: strategic location in the
North Pacific Ocean','060508ca341f95ce5080a39efe3e2846a12642746529bd1d747b0d3c27e857fa','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9ae37e17ca9df20ec96b5e5e91752bd194cf46a1d3ad156abc7b28d126cd6b3',2010,'NO','Norway','geography',1187,'Location: Northern Europe, bordering the
North Sea and the North Adantic Ocean,
west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area: total: 323,802 sq km
land: 307,442 sq km
water: 16,360 sq km
Area — comparative: slighdy larger than
New Mexico
Land boundaries: total: 2,542 km
border countries: Finland 727 km, Sweden
1,619 km, Russia 196 km
Coastline: 25,148 km (includes mainland
2,650 km, as well as long fjords, numerous
small islands, and minor indentations
22,498 km; length of island coastlines
58,133 km)
Maritime Claims: territorial sea: 12 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: temperate along coast, modified
by North Atlantic Current; colder interior
with increased precipitation and colder
summers; rainy year-round on west coast
Terrain: glaciated; mostly high plateaus and
rugged mountains broken by fertile valleys;
small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Galdhopiggen 2,469 m
Natural resources: petroleum, natural
gas, iron ore, copper, lead, zinc, titanium,
pyrites, nickel, fish, timber, hydropower
Land Use: arable land: 2.7%
permanent crops: 0%
other: 97.3% (2005)
Irrigated land: 1,270 sq km (2003)
Total renewable water resources:
381.4 cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 2.4 cu km/yr (23%/67%/10%)
per capita: 519 cu m/yr (1996)
Natural hazards: rockslides, avalanches
Environment— current issues: water
pollution; acid rain damaging forests and
adversely affecting lakes, threatening fish
stocks; air pollution from vehicle emissions
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
511
THE CIA WORLD FACTBOOK
signed, but not ratified: none of the selected
agreements
Geography — note: about two-thirds moun¬
tains; some 50,000 islands off its much
indented coastline; strategic location adja¬
cent to sea lanes and air routes in North
Atlantic; one of most rugged and longest
coasdines in the world
Location: Middle East, bordering the
Arabian Sea, Gulf of Oman, and Persian
Gulf, between Yemen and UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area: total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Kansas
Land boundaries: total: 1,374 km
border countries: Saudi Arabia 676 km,
UAE 410 km, Yemen 288 km
Coastline: 2,092 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: dry desert; hot, humid along
coast; hot, dry interior; strong southwest
summer monsoon (May to September) in
far south
Terrain: central desert plain, rugged moun¬
tains in north and south
Elevation extremes: lowest point: Arabian
Sea 0 m
highest point: Jabal Shams 2,980 m
Natural resources: petroleum, copper,
asbestos, some marble, limestone, chro¬
mium, gypsum, natural gas
Land use: arable land: 0.12%
permanent crops: 0.14%
other: 99.74% (2 005)
Irrigated land: 720 sq km (2003)
Total renewable water resources: 1 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 1.36 cu km/yr
(7%/2%/90%)
per capita : 529 cu m/yr (2000)
Natural hazards: summer winds often
raise large sandstorms and dust storms in
interior; periodic droughts
Environment— current issues: rising sod
salinity; beach pollution from oil spills;
limited natural fresh water resources
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location on
Musandam Peninsula adjacent to Strait
of Hormuz, a vital transit point for world
crude oil','dd696e4634c76c6c22ab550fba51cfd03da276e4695c14e8f4e2097aa24efc7c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa73f5cf713936607d91bba67a1c8a868d2e9eee0d7637f0dca13384fdb7b0f3',2010,'OM','Oman','geography',1196,'Location: body of water between the
Southern Ocean, Asia, Australia, and the
Western Hemisphere
Geographic coordinates: 0 00 N, 160 00 W
Map references: Political Map of the
World
Area: total: 155.557 million sq km
note: includes Bali Sea, Bering Sea, Bering
Strait, Coral Sea, East China Sea, Gulf of
Alaska, Gulf of Tonkin, Philippine Sea,
Sea of Japan, Sea of Okhotsk, South China
Sea, Tasman Sea, and other tributary water
bodies
Area— comparative: about 15 times the
size of the US; covers about 28% of the
global surface; almost equal to the total
land area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems
and resultant wind patterns exhibit remark¬
able uniformity in the south and east; trade
winds and westerly winds are well-devel¬
oped patterns, modified by seasonal fluc¬
tuations; tropical cyclones (hurricanes) may
form south of Mexico from June to October
and affect Mexico and Central America;
continental influences cause climatic
uniformity to be much less pronounced
in the eastern and western regions at the
same latitude in the North Pacific Ocean;
the western Pacific is monsoonal— a rainy
season occurs during the summer months,
when moisture-laden winds blow from
the ocean over the land, and a dry season
during the winter months, when dry winds
blow from the Asian landmass back to the
ocean; tropical cyclones (typhoons) may
strike southeast and east Asia from May to
December
Terrain: surface currents in the northern
Pacific are dominated by a clockwise,
warm-water gyre (broad circular system
of currents) and in the southern Pacific
by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in
the Bering Sea and Sea of Okhotsk in
winter; in the southern Pacific, sea ice
from Antarctica reaches its northernmost
extent in October; the ocean floor in the
eastern Pacific is dominated by the East
Pacific Rise, while the western Pacific is
dissected by deep trenches, including the
Mariana Trench, which is the world’s
deepest
Elevation extremes: lowest point:
Challenger Deep in the Mariana Trench
-10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, poly¬
metallic nodules, sand and gravel aggre¬
gates, placer deposits, fish
Natural hazards: surrounded by a zone
of violent volcanic and earthquake activity
sometimes referred to as the “Pacific
Ring of Fire”; subject to tropical cyclones
(typhoons) in southeast and east Asia from
May to December (most frequent from
July to October); tropical cyclones (hurri¬
canes) may form south of Mexico and
strike Central America and Mexico from
June to October (most common in August
and September); cyclical El Nino/La Nina
phenomenon occurs in die equatorial
Pacific, influencing weather in the Western
Hemisphere and the western Pacific; ships
subject to superstructure icing in extreme
north from October to May; persistent fog
in the northern Pacific can be a maritime
hazard from June to December
Environment— current issues: endan¬
gered marine species include the dugong,
sea lion, sea otter, seals, turtles, and whales;
oil pollution in Philippine Sea and South
China Sea
Geography — note: the major chokepoints
are the Bering Strait, Panama Canal, Luzon
Strait, and the Singapore Strait; the Equator
divides the Pacific Ocean into the North
Pacific Ocean and the South Pacific Ocean;
dotted with low coral islands and rugged
volcanic islands in the southwestern Pacific
Ocean','d93800a880442751e51449af80d6fac6a1790056ab0fea5c140acd193c10c31a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5e49a9e0b2c04482eb71e51686b9b6b337e986b6fa1b5824b773c155210d26e',2010,'PK','Pakistan','geography',1198,'Location: Southern Asia, bordering the
Arabian Sea, between India on the east
and Iran and Afghanistan on the west and
China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area: total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area — comparative: slighdy less than
twice the size of California
Land boundaries: total: 6,774 km
border countries: Afghanistan 2,430 km,
China 523 km, India 2,912 km, Iran 909
km
Coastline: 1,046 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: mosdy hot, dry desert; temperate
in northwest; arctic in north
Terrain: flat Indus plain in east; moun¬
tains in north and northwest; Balochistan
plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen)
8,61 1 m
Natural resources: land, extensive natural
gas reserves, limited petroleum, poor quality
coal, iron ore, copper, salt, limestone
Land use: arable land: 24.44%
permanent crops: 0.84%
other: 74-72% (2005)
Irrigated land: 182,300 sq km (2003)
Total renewable water resources: 233.8
cu km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 169.39 cu km/yr
(2%/2%/96%)
per capita: 1,072 cu m/yr (2000)
Natural hazards: frequent earthquakes,
occasionally severe especially in north and
west; flooding along the Indus after heavy
rains (July and August)
Environment — current issues: water
pollution from raw sewage, industrial
wastes, and agricultural runoff; limited
natural fresh water resources; most of the
population does not have access to potable
water; deforestation; soil erosion; desertifi¬
cation
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conser¬
vation
Geography — note: controls Khyber Pass
and Bolan Pass, traditional invasion routes
between Central Asia and die Indian
Subcontinent','f2b594449e4c5b99625f2057ab6857fd2da0bb85ee2d6513c45882ae6ba8518c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e7e4f8e1bde11d7c3a3fa9cb0d8e6ca9b7e9d86ca25b1a281006a5b6aab35b8',2010,'PW','Palau','geography',1206,'Location: Oceania, group of islands in
the North Pacific Ocean, southeast of the','ce013309097e1f13a540e22aa826581dcd18abbebd688eb5e9f572e21aeece04','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('168ecce271d95e2dd52131c1043c6f4747fe92cec607810b64bafcbc3833a517',2010,'PH','Philippines','geography',1207,'Geographic coordinates: 7 30 N, 1 34 30 E
Map references: Oceania
Area: total: 458 sq km
land: 458 sq km
water: 0 sq km
Area — comparative: slightly more than
2.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims: territorial sea : 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; hot and humid; wet
season May to November
Terrain: varying geologically from the high,
mountainous main island of Babelthuap to
low, coral islands usually fringed by large
barrier reefs
Elevation extremes: lowest
point: Pacific Ocean 0 m
highest point: Mount Ngerchelchuus 242 m
Natural resources: forests, minerals (espe¬
cially gold), marine products, deep-seabed
minerals
Land use: arable land: 8.7%
permanent crops: 4.35%
other: 86.95% (2005)
Irrigated land: NA
Natural hazards: typhoons (June to
December)
Environment— current issues: inadequate
facilities for disposal of solid waste; threats
to the marine ecosystem from sand and
coral dredging, illegal fishing practices, and
overfishing
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Law of the Sea, Ozone
Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: westernmost archi¬
pelago in the Caroline chain, consists of
six island groups totaling more than 300
islands; includes World War II battle¬
ground of Beliliou (Peleliu) and world-
famous rock islands
Location: Southeastern Asia, archipelago
between the Philippine Sea and the South
China Sea, east of Vietnam
Geographic coordinates:
13 00 N,
122 00 E
Map references: Southeast Asia
Area: total: 300,000 sq km
land : 298,170 sq km
water: 1 ,830 sq km
Area — comparative: slightly larger than
Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime Claims: territorial sea: irregular
polygon extending up to 100 nm from
coastline as defined by 1898 treaty; since
late 1970s has also claimed polygonal¬
shaped area in South China Sea up to 285
nm in breadth
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical marine; northeast
monsoon (November to April); southwest
monsoon (May to October)
Terrain: mostly mountains with narrow to
extensive coastal lowlands
Elevation extremes: lowest point: Philip¬
pine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum,
nickel, cobalt, silver, gold, salt, copper
Land use: arable land: 19%
permanent crops: 16,67%
other: 64.33% (2005)
Irrigated land: 15,500 sq km (2003)
Total renewable water resources: 479 cu
km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 28.52 cu km/yr
(1 7%/9%/74%)
per capita: 343 cu m/yr (2000)
Natural hazards: astride typhoon belt,
usually affected by 15 and struck by five
to six cyclonic storms per year; landslides;
active volcanoes; destructive earthquakes;
tsunamis
Environment — current issues: uncon¬
trolled deforestation especially in water¬
shed areas; soil erosion; air and water
pollution in major urban centers; coral
reef degradation; increasing pollution of
coastal mangrove swamps that are impor¬
tant fish breeding grounds
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants
Geography — note: the Philippine archi¬
pelago is made up of 7,107 islands;
favorably located in relation to many of
539
THE CIA WORLD FACTBOOK
Southeast Asia’s main water bodies: the
South China Sea, Philippine Sea, Sulu Sea,
Celebes Sea, and Luzon Strait
Population: 97,976,603 (July 2009 est.)
Age structure: 0-14 years: 35.2% (male
17,606,352/female 16,911,376)
15-64 years: 60.6% (male 29,679,327/
female 29,737,919)
65 years and over: 4.1% (male 1,744,248/
female 2,297,381) (2009 est.)
Median age: total: 22.5 years
male: 22 years
female: 23 years (2009 est.)
Population growth rate: 1.957% (2009
est.)
Birth rate: 26.01 births/1,000 population
(2009 est.)
Death rate: 5.15 deaths/1,000 population
(2008 est.)
Net migration rate: 4 .34 migrant(s)/l ,000
population (2009 est.)
Urbanization: urban population: 65% of
total population (2008)
rate of urbanization: 3% annual rate of
change (2005-10 est.)
Sex ratio: at birth: 1 .05 male(s)/ female
under 15 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 male(s)/female (2009 est.)
Infant mortality rate: total: 20.56 deaths/
1 ,000 live births
male: 23.17 deaths/1,000 live births
female: 17.83 deaths/1,000 live births
(2009 est.)
Life expectancy at birth:
total population: 71.09 years
male: 68.17 years
female: 74-15 years (2009 est.)
Total fertility rate: 3.27 children born/
woman (2009 est.)
HIV/AIDS — adult prevalence rate: less
than 0.1% (2003 est.)
HIV/AIDS— people living with HIV/AIDS:
8,300 (2007 est.)
HIV/AIDS — deaths: fewer than 200 (2007
est.)
Major infectious diseases: degree of risk:
high
food or waterborne diseases: bacterial
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria,
and Japanese encephalitis
water contact disease: leptospirosis (2009)
Nationality: noun: Filipino(s)
adjective: Philippine
Ethnic groups: Tagalog 28.1%, Cebuano
13.1%, Ilocano 9%, Bisaya/Binisaya
7.6%, Hiligaynon Ilonggo 7.5%, Bikol 6%,
Waray 3.4%, other 25.3% (2000 census)
Religions: Roman Catholic 80.9%,
Muslim 5%, Evangelical 2.8%, Iglesia ni
Kristo 2.3%, Aglipayan 2%, other Chris¬
tian 4.5%, other 1.8%, unspecified 0.6%,
none 0.1% (2000 census)
Languages: Filipino (official; based on
Tagalog) and English (official); eight major
dialects— Tagalog, Cebuano, Ilocano,
Hiligaynon or Ilonggo, Bicol, Waray,
Pampango, and Pangasinan
Literacy: definition: age 15 and over can
read and write
total population: 92.6%
male: 92.5%
female: 92.7% (2000 census)
School life expectancy (primary to
tertiary education): total: 1 2 years
male: 11 years
female: 12 years (2006)
Education expenditures: 2.5% of GDP
(2005)
Location: Oceania, islands in the South
Pacific Ocean, about midway between Peru
and New Zealand
Geographic coordinates:
25 04 S, 130 06 W
Map references: Oceania
Area: total: 47 sq km
land: 47 sq km
water: 0 sq km
Area — comparative: about 0.3 times the
size of Washington, DC','ca546e76e93c1cbe4b29a2e39897e168d181a0c987e0b7b64f2d17f892fb00ea','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bebd016c001d9c744157ccf7b398a669676b3e187d2e3895ac9794627e04254',2010,'PG','Papua New Guinea','geography',1219,'Location: Oceania, group of islands
including the eastern half of the island of
New Guinea between the Coral Sea and
the South Pacific Ocean, east of Indonesia
Manpower reaching militarily
significant age annually: male: 31,089
female: 29,939 (2009 est.)
Military expenditures: 1% of GDP (2006)
Military — note: on 10 February 1990, the
government of then President ENDARA
abolished Panama’s military and reformed
the security apparatus by creating the Pana¬
manian Public Forces; in October 1994,
Panama’s Legislative Assembly approved
a constitutional amendment prohibiting
the creation of a standing military force
but allowing the temporary establishment
of special police units to counter acts of
“external aggression”
Location: Southeastern Asia, group of
small islands and reefs in the South China
Sea, about one-third of the way from central
Vietnam to the northern Philippines
Geographiccoordinates: 1 6 30 N, 1 1 2 00 E
Map references: Southeast Asia
Area: total: NA sq km
land: NA sq km v ^
water: 0 sq km
Area — comparative: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
Climate: tropical
Terrain: mostly low and flat
Elevation extremes: lowest point: South
China Sea 0 m
highest point: unnamed location on Rocky
Island 14 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: typhoons
Environment — current issues: NA
Geography — note: composed of 1 30
small coral islands and reefs divided into
the northeast Amphitrite Group and the
western Crescent Group','2051674658917ed0f1defdbd2667baf6c41bae59bfd6c796a4b69b75df875950','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e77baaccbcdceb4f7d14ae8bafdfcf0a4d0bf2872a695ffee36676f607ff063',2010,'PY','Paraguay','geography',1226,'Location: Central South America, north¬
east of Argentina
Geographic coordinates:
23 00 S, 58 00 W
Map references: South America
Area: total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area— comparative: slightly smaller than
California
Land boundaries: total: 3,995 km
border countries: Argentina 1,880 km,
Bolivia 750 km, Brazil 1,365 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: subtropical to temperate;
substantial rainfall in the eastern portions,
becoming semiarid in the far west
Terrain: grassy plains and wooded hills
east of Rio Paraguay; Gran Chaco region
west of Rio Paraguay mostly low, marshy
plain near the river, and dry forest and
thorny scrub elsewhere
Elevation extremes: lowest point: junction
of Rio Paraguay and Rio Parana 46 m
highest point: Cerro Pero (Cerro Tres
Kandu) 842 m
Natural resources: hydropower, timber,
iron ore, manganese, limestone
Land use: arable land: 7.47%
permanent crops: 0.24%
other: 92.29% (2005)
Irrigated land: 670 sq km (2003)
Total renewable water resources: 336 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.49 cu km/yr
(20%/8%/71%)
per capita: 80 cu m/yr (2000)
532
Natural hazards: local flooding in southeast
(early September to June); poorly drained
plains may become boggy (early October
to June)
Environment — current Issues: deforesta¬
tion; water pollution; inadequate means for
waste disposal pose health risks for many
urban residents; loss of wetlands
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; lies
between Argentina, Bolivia, and Brazil;
population concentrated in southern part
of country','2b08b34b6d54b4cc9bef327529901d8e15330a2418b65385f5a3aa95a5fa69af','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eda6f175c0fa4528fc9f71b1cb0e1585c4a29ae42465de5623c3c8d8b38d1752',2010,'PE','Peru','geography',1235,'Location: Western South America,
bordering the South Pacific Ocean, between
Chile and Ecuador
Geographic coordinates: 1 0 00 S, 76 00 W
Map references: South America
Area: total: 1,285,220 sq km
land: 1.28 million sq km
•water: 5,220 sq km
Area — comparative: slightly smaller than
Alaska
Land boundaries: total: 7,461 km
border countries: Bolivia 1,075 km, Brazil
2,995 km, Chile 1 71 km, Colombia 1,800
km, Ecuador 1 ,420 km
535
THE CIA WORLD FACTBOOK
Coastline: 2,414 km
Maritime claims: territorial sea: 200 am
continental shelf: 200 nm
Climate: varies from tropical in east to
dry desert in west; temperate to frigid in
Andes
Terrain: western coastal plain (costa), high
and rugged Andes in center (sierra), eastern
lowland jungle of Amazon Basin (selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold,
petroleum, timber, fish, iron ore, coal,
phosphate, potash, hydropower, natural
gas
Land use: arable land: 2.88%
permanent crops: 0.47%
other: 96.65% (2005)
Irrigated land: 12,000 sq km (2003)
Total renewable water resources: 1,913
cu km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 20.13 cu km/yr
(8%/10%/82%)
per capita: 720 cu m/yr (2000)
Natural hazards: earthquakes, tsunamis,
flooding, landslides, mild volcanic activity
Environment— current issues: deforesta¬
tion (some the result of illegal logging);
overgrazing of the slopes of the costa and
sierra leading to soil erosion; desertifica¬
tion; air pollution in Lima; pollution of
rivers and coastal waters from municipal
and mining wastes
Environment — international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: shares control of Lago
Titicaca, world’s highest navigable lake,
with Bolivia; a remote slope of Nevado
Mismi, a 5,316 m peak, is the ultimate
source of the Amazon River','6975d850aa6fe7778fc4ec26e5e6dbf4e4b2c146921fa559acce330696eaed7b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b500116a888cdac52494792bc611794f5b41e16c9f4c0ace3909885cedb42b2f',2010,'PL','Poland','geography',1245,'Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N,
20 00 E
Map references: Europe
Area:
total: 312,679 sq km
land: 304,459 sq km
water: 8,220 sq km
Area — comparative: slightly smaller than
New Mexico
Land boundaries: total: 3,047 km
border countries: Belarus 605 km, Czech
Republic 615 km, Germany 456 km,
Lithuania 91 km, Russia (Kaliningrad
Oblast) 432 km, Slovakia 420 km, Ukraine
428 km
Coastiine: 440 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: defined by interna¬
tional treaties
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation; mild summers with frequent
showers and thundershowers
Terrain: mostly flat plain; mountains along
southern border
Elevation extremes: lowest point: near
Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper,
natural gas, silver, lead, salt, amber, arable
land
Land use: arable land: 40.25%
permanent crops: 1%
Other: 58.75% (2005)
Irrigated land: 1,000 sq km (2003)
Total renewable water resources: 63.1 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 11.73 cu km/yr
(13%/79%/8%)
per capita: 304 cu m/yr (2002)
Natural hazards: flooding
Environment — current issues: situation
has improved since 1 989 due to decline in
heavy industry and increased environmental
concern by post-Communist governments;
air pollution nonetheless remains serious
because of sulfur dioxide emissions from
coal-fired power plants, and the resulting
acid rain has caused forest damage; water
pollution from industrial and municipal
sources is also a problem, as is disposal of
hazardous wastes; pollution levels should
continue to decrease as industrial establish¬
ments bring their facilities up to EU code,
but at substantial cost to business and the
Location: Southwestern Europe, bordering
the North Atlantic Ocean, west of Spain
Geographic coordinates:
39 30 N, 8 00 W
Map references: Europe
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area: total: 48,845 sq km
land: 48,800 sq km
•water: 45 sq km
Area— comparative: about twice the size
of New Hampshire
Land boundaries: total. 1,474 km
border countries: Austria 91 km, Czech
Republic 197 km, Hungary 676 km,
Poland 420 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: rugged mountains in the central
and northern part and lowlands in the
south
Elevation extremes: lowest point: Bodrok
River 94 m
highest point: Gerlachovsky Stit 2,655 m
Natural resources: brown coal and lignite;
small amounts of iron ore, copper and
manganese ore; salt; arable land
Land use: arable land: 29.23%
permanent crops: 2.67%
other: 68.1% (2005)
Irrigated land: 1,830 sq km (2003b
Total renewable water resources:
50.1 cu km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total 1.04
per capita: 193 cu m/yr (2003)
Natural hazards: NA
Environment— current issues: air
pollution from metallurgical plants presents
human health risks; acid rain damaging
forests
Environment— international agreements:
party to: Air Pollution , Air Pollution-N itrogen
Oxides, Air Pollution-Persistent Organic
Pollutants, Air Pollution-Sulfur 85, Air
Pollution-Sulfur 94, Air Pollution-Volatile
610','1fe34b24754902dea596fe28ae7b9c6dbdca71c1fddccb0c562eed64227a432f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cc4400d2ba5cb0aa2d9006067ecdd9735e9200f648cc6a75a26a11a97182a3b',2010,'PT','Portugal','geography',1248,'Area:
total: 92,391 sq km
land: 91,951 sq km
water: 440 sq km
note: includes Azores and Madeira Islands
Area— comparative: slightly smaller than
Indiana
Land boundaries: total: 1,214 km
border countries: Spain 1,214 km
Coastline: 1,793 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: maritime temperate; cool and
rainy in north, warmer and drier in south
Terrain: mountainous north of the Tagus
River, rolling plains in south
Elevation extremes: lowest point: Adantic
Ocean 0 m
highest point: Ponta do Pico (Pico or Pico
Alto) on Ilha do Pico in the Azores 2,351 m
Natural resources: fish, forests (cork),
iron ore, copper, zinc, tin, tungsten, silver,
gold, uranium, marble, clay, gypsum, salt,
arable land, hydropower
Land USe: arable land: 17.29%
permanent crops: 7.84%
other: 74.87% (2005)
Irrigated land: 6,500 sq km (2003)
Total renewable water resources: 73.6 cu
km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 11.09 cu km/yr
(10%/12%/78%)
per capita: 1,056 cu m/yr (1998)
Natural hazards: Azores subject to severe
earthquakes
Environment— current issues: soil erosion;
air pollution caused by industrial and vehicle
emissions; water pollution, especially in
coastal areas
Environment— international agreements:
party to: Air Pollution, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection,
548
Ship Pollution, Tropical Timber 83, Trop-
ical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile
Organic Compounds, Environmental Modi¬
fication
Geography — note: Azores and Madeira
Islands occupy strategic locations along
western sea approaches to Strait of','d903cc572b571a33d2e8d24afd3044b7d2116a075eeab550837dd67c22bb55a6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('376d470d8e0ff73d5dc29bc0befce61e6c93e8cc7d222c741cb360346fb060b7',2010,'PR','Puerto Rico','geography',1254,'Location: Caribbean, island between the
Caribbean Sea and the North Adantic
Ocean, east of the Dominican Republic
Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the
Caribbean
Area:
total: .13,790 sq km
land: 8,870 sq km
water: 4,921 sq km
Area — comparative: slightly less than
three times the size of Rhode Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine, mild; little
seasonal temperature variation
Terrain: mostly mountains with coastal
plain belt in north; mountains precipitous
to sea on west coast; sandy beaches along
most coastal areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1 ,339 m
Natural resources: some copper and
nickel; potential for onshore and offshore
oil
Land use: arable land: 3.69%
permanent crops: 5.59%
other: 90.72% (2005)
Irrigated land: 400 sq km (2003)
Natural hazards: periodic droughts ; hurri¬
canes
Environment — current issues: erosion;
occasional drought causing water short¬
ages
Geography— note: important location
along the Mona Passage— a key shipping
lane to die Panama Canal; San Juan is
one of the biggest and best natural harbors
in the Caribbean; many small rivers and
high central mountains ensure land is well
watered; soudi coast relatively dry; fertile
coastal plain belt in north
Location: Middle East, peninsula bordering
the Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15
E
Map references: Middle East
Area: total: 11,437 sq km
land: 1 1 ,437 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Connecticut
Land boundaries: total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: as determined by
bilateral agreements or the median line
Climate: arid; mild, pleasant winters; very
hot, humid summers
Terrain: mostly flat and barren desert
covered with loose sand and gravel
Elevation extremes: lowest point: Persian
Gulf 0 m
highest point: Qurayn Abu al Bawl 1 03 m
Natural resources: petroleum, natural gas,
fish
Land USe: arable land: 1.64%
permanent crops: 0.27%
other: 98.09% (2005)
Irrigated land: 130 sq km (2002)
Total renewable water resources: 0.1 cu
km (1997)
Freshwater withdrawal (domestic/ indus¬
trial/agricultural): total: 0.29 cu km/yr
(24%/3%/72%)
per capita: 358 cu m/yr (2000)
Natural hazards: haze, dust storms, sand¬
storms common
Environment— current issues: limited
natural fresh water resources are increasing
dependence on large-scale desalination
facilities
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography— note: strategic location in
central Persian Gulf near major petroleum
deposits
Geographic coordinates: 1 8 05 N, 63 57 W
Map references: Central America and the
Caribbean
Area: total: 54.4 sq km
country comparison to the world: 237
land: 54.4 sq km
water: NEGL
Area — comparative: more than one-third
the size of Washington, DC
Land boundaries:
total: 15 km
border countries: Netherlands Antilles (Sint
Maarten) 15 km
Coastline: 58.9 km (for entire island)
578
SAINT MARTIN
Climate: temperature averages 80-85
degrees all year long; low humidity, gende
trade winds, brief, intense rain showers;
July-November is the hurricane season
Elevation extremes:
lowest point: Caribbean Ocean 0 m
highest point: Pic du Paradis 424 m
Natural resources: salt
Environment— current issues: fresh water
supply is dependent on desalinization of
sea water
Geography — note: the island of Saint
Martin is the smallest landmass in the
world shared by two independent states,
the French territory of Saint Martin and
the Dutch territory of Sint Maarten','c6856ba1e5a5d6b0889635c3943eece0c41c425b7a605d3b893df034954117f6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13ebcf66c3491c881c38c31c9c82c6d19795abcc424a3d7623fff0a9e93957a5',2010,'UA','Ukraine','geography',1268,'Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area: total: 237,500 sq km
land: 230,340 sq km
water: 7,160 sq km
Area — comparative: slighdy smaller than
Oregon
Land boundaries: total: 2,508 km
border countries: Bulgaria 608 km, Hungary
443 km, Moldova 450 km, Serbia 476 km,
Ukraine (north) 362 km, Ukraine (east)
169 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: temperate; cold, cloudy winters
with frequent snow and fog; sunny
summers with frequent showers and thun¬
derstorms
Terrain: central Transylvanian Basin is
separated from the Moldavian Plateau on the
east by the Eastern Carpathian Mountains
and separated from the Walachian Plain
on the south by the Transylvanian Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves
declining), timber, natural gas, coal, iron
ore, salt, arable land, hydropower
Land use: arable land: 39.49%
permanent crops: 1.92%
other: 58.59% (2005)
Irrigated land: 30,770 sq km (2003)
Total renewable water resources: 42.3 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 6.5 cu
km/yr (9%/34%/57%)
per capita: 299 cu m/yr (2003)
Natural hazards: earthquakes, most severe
in south and southwest; geologic structure
and climate promote landslides
Environment— current issues: soil
erosion and degradation; water pollution;
air pollution in south from industrial
effluents; contamination of Danube delta
wedands
Environment— internationalagreements:
party to: Air Pollution, Air Pollution-
Persistent Organic Pollutants, Antarctic-
Environmental Protocol, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection,
Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
Geography— note: controls most easily
traversable land route between the Balkans,
Moldova, and Ukraine
Location: Eastern Europe, bordering the
Black Sea, between Poland, Romania, and
Moldova in the west and Russia in the
east
Geographic coordinates: 49 00 N, 32 00 E
Map references: Asia, Europe
Area: total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Refugees and internally displaced
persons: refugees ( country of origin ):
215,700 (Sudan); 28,880 (Democratic
Republic of Congo); 24,900 (Rwanda)
IDPs: 1.27 million (350,000 IDPs returned
in 2006 following ongoing peace talks
between the Lord’s Resistance Army (LRA)
and the Government of Uganda) (2007)
Area — comparative: slighdy smaller than
Texas
Land boundaries: total. 4,566 km
border countries: Belarus 891 km, Hungary
103 km, Moldova 940 km, Poland 428
km, Romania (south) 176 km, Romania
(southwest) 362 km, Russia 1,576 km,
Slovakia 90 km
Coastline: 2,782 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m or to the depth of
exploitation
Climate: temperate continental; Mediterra¬
nean only on the southern Crimean coast;
precipitation disproportionately distrib¬
uted, highest in west and north, lesser in
east and southeast; winters vary from cool
along the Black Sea to cold farther inland;
summers are warm across the greater part
of the country, hot in the south
Terrain: most of Ukraine consists of
fertile plains (steppes) and plateaus, moun¬
tains being found only in the west (the
Carpathians), and in the Crimean Penin¬
sula in the extreme south
Elevation extremes: lowest point: Black
Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manga¬
nese, natural gas, oil, salt, sulfur, graphite,
titanium, magnesium, kaolin, nickel,
mercury, timber, arable land
Land use: arable land: 53.8%
permanent crops: 1.5%
other: 44.7% (2005)
Irrigated land: 22,080 sq km (2003)
Total renewable water resources: 139.5
cu km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 37.53 cu km/yr
(1 2%/35%/52%)
per capita: 807 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: inadequate
supplies of potable water; air and water pollu¬
tion; deforestation; radiation contamination
705
THE CIA WORLD FACTBOOK
in the northeast from 1986 accident at
Chornobyl’ Nuclear Power Plant
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Sulfur 85,
Antarctic-EnvironmentalProtocol, Antarctic-
Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air Pollution-
Sulfur 94, Air Pollution-Volatile Organic
Compounds
Geography— note: strategic position at
the crossroads between Europe and Asia;
second-largest country in Europe','7da0c7e1534a8e952753f9f77efaeb61e06cbe049145897df9da2218e4bb684f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8cbcc46241cf7e4b938c83af193967c7aa9b8c489304435aacc4444419e8d7b',2010,'RW','Rwanda','geography',1279,'Location: Central Africa, east of Demo¬
cratic Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,338 sq km
land: 24,948 sq km
water: 1 ,390 sq km
Area — comparative: slighdy smaller than
Maryland
Land boundaries:
total: 893 km
border countries: Burundi 290 km, Demo¬
cratic Republic of the Congo 217 km,
Tanzania 217 km, Uganda 169 km
Coastline:
0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: temperate; two rainy seasons
(February to April, November to January);
mild in mountains with frost and snow
possible
Terrain: mostly grassy uplands and
hills; relief is mountainous with altitude
declining from west to east
Elevation extremes: lowest point: Rusizi
River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin
ore), wolframite (tungsten ore), methane,
hydropower, arable land
Land use: arable land: 45.56%
permanent crops: 10.25%
other: 44.19% (2005)
Irrigated land: 90 sq km (2003)
Total renewable water resources: 5.2 cu
km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.15 cu
km/yr (24%/8%/68%)
per capita: 17 cu m/yr (2000)
Natural hazards: periodic droughts; the
volcanic Virunga mountains are in the
northwest along the border with Demo¬
cratic Republic of the Congo
Environment— current issues: deforesta¬
tion results from uncontrolled cutting of
trees for fuel; overgrazing; soil exhaustion;
soil erosion; widespread poaching
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography— note: landlocked; most of
the country is savanna grassland with the
population predominantly rural
Location: located approximately 125 miles
northwest of Guadeloupe
Geographic coordinates: 1 7 90 N, 62 85 W
Map references: Central America and the
Caribbean
Area: 21 sq km
Area — comparative: less than an eighth
of the size of Washington, DC
Land boundaries: 0 km
Climate: tropical, with practically no varia¬
tion in temperature; has two seasons (dry
and humid)
Terrain: hilly, almost completely
surrounded by shallow-water reefs, with 20
beaches
Elevation extremes:
lowest point: Caribbean Ocean 0 m
highest point: Morne du Vitet 286 m
Natural resources: has few natural
resources, its beaches being the most
important
Environment— current issues: with no
natural rivers or streams, fresh water is in
short supply, especially in summer, and
provided by desalinization of sea water,
collection of rain water, or imported via
water tanker','6fbbc9ca744eb3f297d3a86bb4edf69d7a288bbd046c1c176b29fa9a771d6ea0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75d055faed016be28d909b37e02339311b16f3aa537a1f5e4fd8d9286803fa5d',2010,'GP','Guadeloupe','geography',1291,'Location: islands in the South Atlantic
Ocean, about midway between South
America and Africa; Ascension Island lies
700 nm northwest of Saint Helena; Tristan
da Cunha lies 2,300 nm southwest of Saint
Helena
Geographic coordinates:
Saint Helena: 15 57 S, 5 42 W
Ascension Island: 7 57 S, 14 22 W
TristandaCunhaislandgroup: 37 1 5 S, 1 230W
Map references: Africa
Area: total: 413 sq km
land: Saint Helena Island 122 sq km;
Ascension Island 90 sq km; Tristan da
Cunha island group 201 sq km
water: 0 sq km
Area — comparative: slightly more than
twice the size of Washington, DC
Land boundaries: 0 km
Coastline: Saint Helena: 60 km
Ascension Island: NA
Tristan da Cunha: 40 km
Maritime Claims, territorial sea. 12 nm
exclusive fishing zone: 200 nm
Climate: Saint Helena: tropical marine;
mild, tempered by trade winds
Ascension Island: tropical marine; mild,
semi-arid
Tristan da Cunha: temperate marine; mild,
tempered by trade winds (tends to be cooler
than Saint Helena)
Terrain: the islands of this group result
from volcanic activity associated with the
Atlantic Mid-Ocean Ridge
Saint Helena: rugged, volcanic; small
scattered plateaus and plains
Ascension: surface covered by lava flows
and cinder cones of 44 dormant volcanoes;
571
THE CIA WORLD FACTBOOK
ground rises to the east
Tristan da Cunha: sheer cliffs line the coast¬
line of the nearly circular island; the flanks
of the central volcanic peak are deeply
dissected; narrow coastal plain lies between
The Peak and the coastal cliffs
Elevation extremes: ,
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary’s Peak on Tristan
da Cunha 2,062 m; Green Mountain
on Ascension Island 859 m; Mount
Actaeon on Saint Helena Island 818 m
Natural resources: fish, lobster
Land use: arable land: 12.9%
permanent crops: 0%
other: 87.1% (2005)
Irrigated land: NA
Natural hazards: active volcanism on
Tristan da Cunha, last eruption in 1961
Environment — current issues: NA
Geography — note: Saint Helena harbors
at least 40 species of plants unknown
anywhere else in the world; Ascension is a
breeding ground for sea turdes and sooty
terns; Queen Mary’s Peak on Tristan da
Cunha is the highest island mountain in the
South Atlantic and a prominent landmark
on the sea lanes around southern Africa •','8d4e78f810f6f8fba5243173cf34011d34010174780e4c1eebf8155dbad45a56','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2222d64e8e4e51f6d318aed55f192f8d85f0a898ce17a5a031affc65853a2242',2010,'KN','Saint Kitts and Nevis','geography',1300,'Location: Caribbean, islands in the
Caribbean Sea, about one-third of the way
from Puerto Rico to Trinidad and Tobago
Geographic coordinates:
17 20 N, 62 45 W
Map references:
Central America and the Caribbean
Area: total: 261 sq km (Saint Kitts 168
sq km; Nevis 93 sq km)
land: 261 sq km
water: 0 sq km
Area — comparative:
1.5 times the size of Washington, DC
573
THE CIA WORLD FACTBOOK
Land boundaries: 0 km
Coastline: 135 km
Maritime Claims: territorial sea : 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical, tempered by constant
sea breezes; little seasonal temperature
variation; rainy season (May to November)
Terrain:
volcanic with mountainous interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: arable land
Land use: arable land: 19.44%
permanent crops: 2.78%
other: 77.78% (2005)
Irrigated land: NA
Total renewable water resources:
0.02 cu km (2000)
Natural hazards:
hurricanes (July to October)
Environment — current issues: NA
Environment — international
agreements: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: with coastlines in the
shape of a baseball bat and ball, the two
volcanic islands are separated by a 3-km-
wide channel called The Narrows; on the
southern tip of long, baseball bat-shaped
Saint Kitts lies the Great Salt Pond;
Nevis Peak sits in the center of its almost
circular namesake island and its ball shape
complements that of its sister island','4a566c2f9aad153e6ee0fdd5f89c3ce0d9ff913b0b5b0d9b73f2151c42b30185','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d70c52b92d25e86dbcfa9dfc43710f2b6e570771cfda0be68fa209e3f5a140ab',2010,'LC','Saint Lucia','geography',1304,'Location: Caribbean, island between the
Caribbean Sea and North Atlantic Ocean,
north of Trinidad and Tobago
Geographic coordinates: 13 53 N, 60 58 W
Map references: Central America and the
Caribbean
Area: total: 616 sq km
land: 606 sq km
water: 10 sq km
Area— comparative:
3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical, moderated by northeast
trade winds; dry season January to April,
rainy season May to August
Terrain: volcanic and mountainous with
some broad, fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs,
geothermal potential
Land use: arable land: 6.45%
permanent crops: 22.58%
other: 70.97% (2005)
Irrigated land:
30 sq km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.01
per capita: 81 cu m/yr (1997)
Natural hazards:
hurricanes; volcanic activity
Environment — current issues:
deforestation; soil erosion, particularly in
the northern region
Environment — internationaiagreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the''
Sea, Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: the twin Pitons (Gros
Piton and Petit Piton), striking cone-shaped
peaks south of Soufriere, are one of the
scenic natural highlights of the Caribbean
Location: island 300 km southeast of','abe7cf4ddb2128451c67c1df35cafc24cb6ab271153695275e74243784347ca7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8a0c28b6c59105148af08217e089e50aea603baf34d85ebe0e260da4dae456d',2010,'PM','Saint Pierre and Miquelon','geography',1312,'Location: Northern North America,
islands in the North Atlantic Ocean, south
of Newfoundland (Canada)
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area: total: 242 sq km
land: 242 sq km
water: 0 sq km
note: includes eight small islands in the
Saint Pierre and the Miquelon groups
Area — comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime Claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: cold and wet, with much mist
and fog; spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande
Montagne 240 m
Natural resources: fish, deepwater ports
Land use: arable land: 12.5%
permanent crops: 0%
other: 87.5% (2005)
Irrigated land: NA
Natural hazards: persistent fog throughout
the year can be a maritime hazard
Environment — current issues: recent test
drilling for oil in waters around Saint Pierre
and Miquelon may bring future develop¬
ment that would impact the environment
Geography— note: vegetation scanty','501192f40b9db1f5ca3f8efb4c26d56a6c48f4f4c19215c133731668a7758cb7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce0663bd67c478bab4df9f984345ec7a0a8574bcb6358d2517066abc85c9826a',2010,'VC','Saint Vincent and the Grenadines','geography',1319,'Location: Caribbean, islands between the
Caribbean Sea and North Adantic Ocean,
north of Trinidad and Tobago
Geographiccoordinates: 1 3 1 5 N, 61 1 2 w
Map references: Central America and the
Caribbean
Area: total: 389 sq km (Saint Vincent 344
sq km)
land: 389 sq km
water: 0 sq km
Area — comparative: twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims: territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; litde seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: La Soufriere 1,234 m
Natural resources: hydropower, cropland
Land use: arable land: 17.95%
permanent crops: 17.95%
other: 64.1% (2005)
Irrigated land: 10 sq km (2003)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.01
per capita: 83 cu m/yr (1995)
Natural hazards: hurricanes; Soufriere
volcano on the island of Saint Vincent is
a constant threat
Environment — current issues: pollution
of coastal waters and shorelines from
discharges by pleasure yachts and other
effluents; in some areas, pollution is severe
enough to make swimming prohibitive
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protec¬
tion, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: the administration
of the islands of the Grenadines group is
divided between Saint Vincent and the
Grenadines and Grenada; Saint Vincent
and the Grenadines is comprised of 32
islands and cays','c6895bfb160d29a851bae2540fd1ff8204f655793bf6f476f0868d7b2a46d540','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1eb710e02ffff962aa982df529a4098bc2ffc95763beca9ea87f4005299efe5',2010,'WS','Samoa','geography',1326,'Location: Oceania, group of islands in
the South Pacific Ocean, about half way.
between Hawaii and New Zealand
Geographic coordinates: 1 3 35 S, 1 72 20 W
Map references: Oceania
Area: total: 2,944 sq km
land: 2,934 sq km
water: 10 sq km
Area— comparative: slighdy smaller than
Rhode Island
Belgium 8, Bulgaria 15, Canada 1, China
94, Croatia 7, Cyprus 1, Czech Republic
1, Denmark 16, Egypt 3, Estonia 16,
France 6, Germany 3, Gibraltar 1, Greece
71, Guyana 2, Hong Kong 6, Iceland 7,
India 7, Iran 1, Israel 2, Italy 17, Japan 3,
Kenya 2, Latvia 17, Lebanon 6, Lithuania
9, Monaco 5, Montenegro 1, Namibia
1, Netherlands 3, Norway 13, Poland 1,
Puerto Rico 1, Romania 1, Russia 21,
Singapore 4, Slovenia 5, South Africa 1,
Sweden 2, Switzerland 6, Syria 13, Turkey
20, Ukraine 11, UAE 9, UK 14, US 18,
Venezuela 1) (2008)
Ports and terminals:
Kingstown','223a109434818821d3f6100aecc2fc5d07aa1388664a9eadd8ac9832804ac82d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6e7c2e069331da7ea288608141bf5de3ced430e2e8444d1d94223e582b71c37',2010,'SM','San Marino','geography',1337,'Location: Southern Europe, an enclave in
central Italy
Geographic coordinates: 43 46 N, 1 2 25 E
Map references: Europe
Area:
total: 61 .2 sq km
land: 61 .2 sq km
water: 0 sq km
Area — comparative: about one third
times the size of Washington, DC
Land boundaries: total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool
winters; warm, sunny summers
Terrain: rugged mountains
Elevation extremes:
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 755 m
Natural resources: building stone
Land use: arable land: 16.67%
permanent crops : 0%
other: 83.33% (2005)
Irrigated land: NA
Natural hazards: NA
Environment— current issues: NA
Environment— international
agreements: party to: Biodiversity,
Climate Change, Desertification, Whaling
signed, but not ratified: Air Pollution
Geography— note: landlocked; smallest
independent state in Europe after the
Holy See and Monaco; dominated by the
Apennines','e63eaff182360512d94dcfaee0418b8afc70cabe6f264102e1b82ec3e9c99b19','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa7636f7b0e142d61b6c9850f1b5d8732cc7b7fefc4cf98531f490c7343b8686',2010,'ST','Sao Tome and Principe','geography',1346,'Location: Western Africa, islands in the
Gulf of Guinea, straddling the Equator,
west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area: total: 1 ,001 sq km
land: 1 ,001 sq km
water: 0 sq km
Area — comparative: more than five times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime Claims: measured from
claimed archipelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; one rainy
season (October to May)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish, hydropower
Land use: arable land: 8.33%
permanent crops: 48.96%
other: 42.71% (2005)
Irrigated land: 100 sq km (2003)
Natural hazards: NA
Environment— current issues:
deforestation; soil erosion and exhaustion
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: the smallest country in
Africa; the two main islands form part of
a chain of extinct volcanoes and both are
mountainous','55a56efbda8d34e97ce58cde17c9ddba70b2d5efcd123ccef3cc639a8995cb34','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('592e0f6eca5f125eef8c282cafe25b17724ec060b61f3932c0e4e8c997c4c1bf',2010,'SA','Saudi Arabia','geography',1349,'Location : Middle East, bordering the Persian
Gulf and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area: total: 2,149,690 sq km
land: 2,149,690 sq km
water: 0 sq km
Area — comparative: slighdy more than
one-fifth the size of the US
Land boundaries: total: 4,431 km
border countries: Iraq 814 km, Jordan 744
km, Kuwait 222 km, Oman 676 km, Qatar
60 km, UAE 457 km, Yemen 1,458 km
Coastline: 2,640 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 18 nm
continental shelf: not specified
Climate: harsh, dry desert with great
temperature extremes
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda’ 3,133 m
Natural resources: petroleum, natural gas,
iron ore, gold, copper
Land use: arable land: 1 .67%
permanent crops: 0.09%
other: 98.24% (2005)
Irrigated land: 16,200 sq km (2003)
Total renewable water resources:
2.4 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 17.32 cu
km/yr (10%/l%/89%)
per capita: 705 cu m/yr (2000)
Natural hazards:
frequent sand and dust storms
Environment— current issues: desertifi¬
cation; depletion of underground water
resources; the lack of perennial rivers or
permanent water bodies has prompted the
development of extensive seawater desalina¬
tion facilities; coastal pollution from oil spills
Environment— international agreements:
party to : Biodiversity , ClimateChange, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography — note: extensive coasdines on
Persian Gulf and Red Sea provide great
leverage on shipping (especially crude oil)
through Persian Gulf and Suez Canal','cef6915b732ea3174a14beeccc70c2721d0e8ea9b480b3abaf763430e507dc29','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88407a11c1bf6d22dfb77bf555c06cf856ed3435d524a7bcc9f31baa8e44169d',2010,'RS','Serbia','geography',1357,'Location: Southeastern Europe, between
Macedonia and Hungary
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area: total: 77,474 sq km
land: 77,474 sq km
water: 0 sq km
Area — comparative: slightly smaller than
South Carolina
Land boundaries: total 2,026 km
border countries: Bosnia and Herzegovina
302 km, Bulgaria 318 km, Croatia 241
km, Hungary 151 km, Kosovo 352 km,
Macedonia 62 km, Montenegro 124 km,
Romania 476 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: in the north, continental climate
(cold winters and hot, humid summers with
well distributed rainfall); in other parts,
continental and Mediterranean climate
(relatively cold winters with heavy snowfall
and hot, dry summers and autumns)
Terrain: extremely varied; to the north,
rich fertile plains; to the east, limestone
ranges and basins; to the southeast, ancient
mountains and hills
Elevation extremes: lowest point: NA
highest point: Midzor 2,169 m
Natural resources: oil, gas, coal, iron
ore, copper, zinc, antimony, chromite,
gold, silver, magnesium, pyrite, limestone,
marble, salt, arable land
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Total renewable water resources: 208.5
cu km (note— includes Kosovo) (2003)
Natural hazards: destructive earthquakes
Environment— current issues:
air pollution around Belgrade and other
industrial cities; water pollution from
industrial wastes dumped into the Sava
which flows into the Danube
Environment — internafionalagreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine
Life Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: controls one of the
major land routes from Western Europe to
Turkey and the Near East','79e6f85270050077204276240ddea1b63e90d37bb2bf340ceae872d7a3fe2174','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d72ea656e64c0fc95319aa9126330ece4eff5a61c224c0426c7b68508154b0bd',2010,'SC','Seychelles','geography',1364,'Location: archipelago in the Indian Ocean,
northeast of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area: total: 455 sq km
land: 455 sq km
water: 0 sq km
Area— comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical marine; humid; cooler
season during southeast monsoon (late
May to September); warmer season during
northwest monsoon (March to May)
Terrain: Mahe Group is granitic, narrow
coastal strip, rocky, hilly; others are coral,
flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychellois 905 m
Natural resources:
fish, copra, cinnamon trees
Land use: arable land: 2.17%
permanent crops: 13.04%
other: 84.79% (2005)
Irrigated land: NA
Natural hazards: lies outside the cyclone
belt, so severe storms are rare; short
droughts possible
Environment— current issues: water
supply depends on catchments to collect
rainwater
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollu¬
tion, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: 41 granitic and about
75 coralline islands','324293f067ca75e4bb56f39e912cb50ba7cf1ef6795abf616f0f35e1322de58a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41b03f5200346121f171c67f0cf5bc4d6dea6c838a16e3b3640388f489e45f1e',2010,'SL','Sierra Leone','geography',1372,'Location: Western Africa, bordering the
North Adantic Ocean, between Guinea
and Liberia 4
Geographic coordinates: 8 30 N, 1 1 30 W
Map references: Africa
Area:
total: 71,740 sq km
land: 71,620 sq km
water: 1 20 sq km
Area — comparative: slighdy smaller than
South Carolina
Land boundaries: total: 958 km
border countries: Guinea 652 km, Liberia
306 km
Coastline:
402 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; hot, humid; summer
rainy season (May to December); winter
dry season (December to April)
604
Terrain: coastal belt of mangrove swamps,
wooded hill country, upland plateau,
mountains in east
Elevation extremes:
lowest point: Adantic Ocean 0 m
highest point: Loma Mansa (Bintimani)
1,948 m
Natural resources: diamonds, titanium
ore, bauxite, iron ore, gold, chromite
Land use: arable land: 7.95%
permanent crops: 1 .05%
other: 91% (2005)
Irrigated land: 300 sq km (2003)
Total renewable water resources: 160 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.38 cu km/yr (5%/3%/92%)
per capita: 69 cu m/yr (2000)
Natural hazards: dry, sand-laden
harmattan winds blow from the Sahara
(December to February); sandstorms, dust
storms
Environment— current issues: rapid popu¬
lation growth pressuring the environment;
overharvesting of timber, expansion of
cattie grazing, and slash-and-burn agricul¬
ture have resulted in deforestation and
soil exhaustion; civil war depleted natural
resources; overfishing
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Law of the
Sea, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Wedands
signed, but not ratified: Environmental
Modification
Geography— note: rainfall along the coast
can reach 495 cm (195 inches) a year,
making it one of the wettest places along
coastal, western Africa','dc249c5adf686d632d4a14488e7f02977d4e1e8dd61bb2d1f139bd9f92922969','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f570e9dba050bee33c5c7a01668285a74def2ecda99e06208ab0241d48a34c5',2010,'SG','Singapore','geography',1381,'Location: Southeastern Asia, islands
between Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area: total: 692.7 sq km
land: 682.7 sq km
water: 10 sq km
Area — comparative: slightly more than
3.5 times the size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: within and beyond
territorial sea, as defined in treaties and
practice
Climate: tropical; hot, humid, rainy; two
distinct monsoon seasons— Northeastern
monsoon (December to March) and South¬
western monsoon (June to September);
inter-monsoon— frequent afternoon and
early evening thunderstorms
Terrain: lowland; gently undulating central
plateau contains water catchment area and
nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 1 66 m
Natural resources: fish, deepwater ports
Land use: arable land: 1.47%
permanent crops: 1 .47%
other: 97.06% (2005)
Irrigated land: NA
Total renewable water resources:
0.6 cu km (1975)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.19 cu
km/yr (45%/51%/4%)
per capita: 44 cu m/yr (1975)
Natural hazards: NA
Environment— current issues: industrial
pollution; limited natural fresh water
resources; limited land availability
presents waste disposal problems; seasonal
smoke/haze resulting from forest fires in','f69b380cc8b92fc3b6f733823e2b2db970c4f30732a15757b08ddef9844f9e11','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcef704bef8bf581879b823f8cf222cf82c7b044987fc12b1adf59d94594317e',2010,'SK','Slovakia','geography',1384,'Location: Central Europe, south of
Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental
Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship
Pollution, Wedands, Whaling
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; most of
the country is rugged and mountainous;
the Tatra Mountains in the north are inter¬
spersed with many scenic lakes and valleys','0911a8b7a36119862f2233aa7a7b92f5c1fa0842468413094e1b1eeaecef2efe','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('955b331b7921c921f43566026ad7a79d61066bfba9a83246ade0c5c2956cff74',2010,'SI','Slovenia','geography',1391,'Location: Central Europe, eastern Alps
bordering the Adriatic Sea, between Austria
and Croatia
Geographic coordinates: 46 07 N, 14 49 E
Map references: Europe
Area: total: 20,273 sq km
land: 20,151 sq km
water: 122 sq km
Area — comparative:
slightly smaller than New Jersey
Land boundaries: total: 1,086 km
border countries: Austria 330 km, Croatia
455 km, Hungary 102 km, Italy 199 km
Coastline: 46.6 km
Maritime Claims: territorial sea: 12 nm
Climate: Mediterranean climate on the
coast, continental climate with mild to hot
summers and cold winters in the plateaus
and valleys to the east
Terrain: a short coastal strip on the Adriatic,
an alpine mountain region adjacent to Italy
and Austria, mixed mountains and valleys
with numerous rivers to the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead, zinc,
building stone, hydropower, forests
Land use: arable land: 8.53%
permanent crops: 1.43%
other: 90.04% (2005)
Irrigated land: 30 sq km (2003)
Total renewable water resources:
32.1 cu km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.9
per capita: 457 cu m/yr (2002)
Natural hazards: flooding; earthquakes
Environment — current issues: Sava River
polluted with domestic and industrial
waste; pollution of coastal waters with
heavy metals and toxic chemicals; forest
damage near Koper from air pollution
(originating at metallurgical and chemical
plants) and resulting acid rain
Environment— international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
94, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modi¬
fication, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: despite its small size,
this eastern Alpine country controls some
of Europe’s major transit routes','bce34af149d311979e9efd6aa4765ba05bb3745cff6513e450b119f6868fc646','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('395cc74744f17cc69be323dee218e85f154bb8a852a2b1e3e00eeee0dc524e9a',2010,'SB','Solomon Islands','geography',1397,'Location: Oceania, group of islands in the
South Pacific Ocean, east of Papua New','6d7ef37486cda226953e0f89cae3d156f0d25288b845adaa115c1ea556007eca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('067692764e14086bed51ca1bf00882764e73df35936d76cb7c21fbf1d8980c6a',2010,'SO','Somalia','geography',1400,'Location: Eastern Africa, bordering the
Gulf of Aden and the Indian Ocean, east
of Ethiopia
Geographic coordinates: 1 0 00 N, 49 00 E
Map references: Africa
Area: total: 637,657 sq km
land: 627,337 sq km
water: 10,320 sq km
Area— comparative:
slightly smaller than Texas
Land boundaries: total: 2,340 km
border countries: Djibouti 58 km, Ediiopia
1 ,600 km, Kenya 682 km
Coastline: 3,025 km
Maritime Claims: territorial sea: 200 nm
Climate: principally desert; northeast
monsoon (December to February),
moderate temperatures in north and hot
in south; southwest monsoon (May to
October), torrid in the north and hot in
the south, irregular rainfall, hot and humid
periods (tangambili) between monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Shimbiris 2,416 m
Natural resources: uranium and largely
unexploited reserves of iron ore, tin,
gypsum, bauxite, copper, salt, natural gas,
likely oil reserves
Land use: arable land: 1.64%
permanent crops: 0.04%
Other: 98.32% (2005)
Irrigated land: 2,000 sq km (2003)
Total renewable water resources:
15.7 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 3.29 cu
km/yr (0%/0%/100%)
per capita: 400 cu m/yr (2000)
Natural hazards: recurring droughts;
frequent dust storms over eastern plains in
summer; floods during rainy season
Environment — current issues: famine;
use of contaminated water contributes to
human health problems; deforestation;
overgrazing; soil erosion; desertification
Environment — international
agreements: party to: Biodiversity, Deserti¬
fication, Endangered Species, Law of the
Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location on
Horn of Africa along southern approaches
to Bab el Mandeb and route through Red
Sea and Suez Canal','f4cec9ff156c242f8d7f8fbc1999595fccaa093666c1076c2caa95e969d8756f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('226674e3bdcc70165166aaa1ad07af700b232276075f1809992c960875a678d7',2010,'GS','South Georgia and the South Sandwich Islands','geography',1410,'Location: Southern South America, islands
in the South Atlantic Ocean, east of the tip
of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area: total: 3,903 sq km
land: 3,903 sq km
water: 0 sq km
note: includes Shag Rocks, Black Rock,
Clerke Rocks, South Georgia Island, Bird
Island, and the South Sandwich Islands,
which consist of 1 1 islands
Area — comparative: slightly larger than
Rhode Island
Land boundaries: 0 km
Coastline: NA
Maritime Claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: variable, with mostly westerly
winds throughout the year interspersed
with periods of calm; nearly all precipitation
falls as snow
Terrain: most of the islands, rising steeply
from the sea, are rugged and mountainous;
South Georgia is largely barren and has
steep, glacier-covered mountains; the South
Sandwich Islands are of volcanic origin
with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget (South Georgia)
2,934 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 1 00% (largely covered by permanent
ice and snow with some sparse vegetation
consisting of grass, moss, and lichen)
(2005)
Irrigated land: 0 sq km
Natural hazards: the South Sandwich
Islands have prevailing weather conditions
that generally make them difficult to
approach by ship; they are also subject
to active volcanism
Environment— current issues: NA
Geography — note: the north coast of
South Georgia has several large bays,
which provide good anchorage; reindeer,
introduced early in the 20th century, live
on South Georgia
Location: body of water between 60 degrees
south latitude and Antarctica
Geographic coordinates: 60 oo s, 90 00
E (nominally), but the Southern Ocean
has the unique distinction of being a
large circumpolar body of water totally
encircling the continent of Antarctica; this
ring of water lies between 60 degrees south
latitude and the coast of Antarctica and
encompasses 360 degrees of longitude
Map references: Antarctic Region
Area: total: 20.327 million sq km
note: includes Amundsen Sea, Belling¬
shausen Sea, part of the Drake Passage,
Ross Sea, a small part of the Scotia Sea,
Weddell Sea, and other tributary water
bodies
Area — comparative: slighdy more than
twice the size of the US
Coastline: 17,968 km
Climate: sea temperatures vary from
about 10 degrees Celsius to -2 degrees
Celsius; cyclonic storms travel eastward
around the continent and frequendy are
intense because of the temperature contrast
between ice and open ocean; the ocean
area from about latitude 40 south to the
Antarctic Circle has the strongest average
winds found anywhere on Earth; in winter
the ocean freezes outward to 65 degrees
south latitude in the Pacific sector and
55 degrees south latitude in the Atlantic
sector, lowering surface temperatures well
below 0 degrees Celsius; at some coastal
points intense persistent drainage winds
from the interior keep the shoreline ice-free
throughout the winter
Terrain: the Southern Ocean is deep,
4,000 to 5,000 m over most of its extent
with only limited areas of shallow water;
the Antarctic continental shelf is generally
narrow and unusually deep, its edge lying
at depths of 400 to 800 m (the global mean
is 1 33 m); the Antarctic icepack grows from
an average minimum of 2.6 million sq km
in March to about 18.8 million sq km in
September, better than a sixfold increase
in area; the Antarctic Circumpolar Current
(21,000 km in length) moves perpetually
eastward; it is the world’s largest ocean
current, transporting 1 30 million cubic
meters of water per second— 1 00 times the
flow of all the world’s rivers
Elevation extremes: lowest point: -7,235
m at the southern end of the South
Sandwich Trench
highest point: sea level 0 m
Natural resources: probable large and
possible giant oil and gas fields on the
continental margin; manganese nodules,
possible placer deposits, sand and gravel,
fresh water as icebergs; squid, whales, and
seals— none exploited; krill, fish
Natural hazards: huge icebergs with drafts
up to several hundred meters; smaller bergs
and iceberg fragments; sea ice (generally
0.5 to 1 m thick) with sometimes dynamic
short-term variations and with large
annual and interannual variations; deep
continental shelf floored by glacial deposits
varying widely over short distances; high
winds and large waves much of the year;
ship icing, especially May-October; most
of region is remote from sources of search
and rescue
Environment — current issues: increased
solar ultraviolet radiation resulting from
the Antarctic ozone hole in recent years,
reducing marine primary productivity
(phytoplankton) by as much as 15% and
damaging the DNA of some fish; illegal,
unreported, and unregulated fishing
in recent years, especially the landing of an
estimated five to six times more Patagonian
toothfish than the regulated fishery,
which is likely to affect the sustainability
of the stock; large amount of incidental
mortality of seabirds resulting from long-
line fishing for toothfish
note: the now-protected fur seal population
is making a strong comeback after severe
overexploitation in the 18th and 19th
centuries
Environment— international agreements:
the Southern Ocean is subject to all inter¬
national agreements regarding the world’s
oceans; in addition, it is subject to these
agreements specific to the Antarctic region:
International Whaling Commission
(prohibits commercial whaling south of
40 degrees south [south of 60 degrees
south between 50 degrees and 1 30 degrees
westj); Convention on the Conservation
of Antarctic Seals (limits sealing); Conven¬
tion on the Conservation of Antarctic
Marine Living Resources (regulates fishing)
note: many nations (including the US)
prohibit mineral resource exploration and
exploitation south of the fluctuating Polar
Front (Antarctic Convergence), which is in
the middle of the Antarctic Circumpolar
Current and serves as the dividing line
between the cold polar surface waters to
the south and the warmer waters to the
north
Geography — note: the major chokepoint is
the Drake Passage between South America
and Antarctica; the Polar Front (Antarctic
Convergence) is the best natural definition
of the northern extent of the Southern
Ocean; it is a distinct region at the middle
of the Antarctic Circumpolar Current that
separates the cold polar surface waters to
the south from the warmer waters to the
628','7a9e3a887e4b5171ee36d20dc83ec8778ea69a6f181c4dfd0607d9b9bc2643dc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dcb16e060a39b35c176eeb76af9927f99fe093f34a74e208b945f0d4b4d64ab',2010,'SD','Sudan','geography',1428,'Location: Northern Africa, bordering the
Red Sea, between Egypt and Eritrea
Geographic coordinates: 1 5 oo N, 30 00 E
Map references: Africa
Area: total: 2,505,810 sq km
land: 2.376 million sq km
water: 129,810 sq km
Area — comparative: slightly more than
one-quarter the size of the US
Land boundaries: total: 7,687 km
border countries: Central African Republic
1,165 km, Chad 1,360 km, Democratic
Republic of the Congo 628 km, Egypt
1,273 km, Eritrea 605 km, Ethiopia
1,606 km, Kenya 232 km, Libya 383 km,
Uganda 435 km
Coastline: 853 km
Maritime claims: territorial sea: 1 2 nm
contiguous zone: 1 8 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical in south; arid desert in
north; rainy season varies by region (April
to November)
Terrain: generally flat, featureless plain;
mountains in far south, northeast and
west; desert dominates the north
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small
reserves of iron ore, copper, chromium
ore, zinc, tungsten, mica, silver, gold,
hydropower
Land use: arable land: 6.78%
permanent crops: 0.17%
other: 93.05% (2005)
Irrigated land: 18,630 sq km (2003)
Total renewable water resources:
154 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 37.32 cu km/yr (3%/l%/97%)
per capita: 1,030 cu m/yr (2000)
Natural hazards: dust storms and periodic
persistent droughts
Environment — current issues: inadequate
supplies of potable water; wildlife popula¬
tions threatened by excessive hunting; soil
erosion; desertification; periodic drought
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: largest country in
Africa; dominated by the Nile and its
tributaries','8be6297b27bfd80c22377b6299ef13ba737dfcaf9f19950fac71059888d8be68','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa177208af3a1c4a73ee8e924109942166cfdb8406f193c94054592fb35dff9',2010,'SR','Suriname','geography',1433,'Location: Northern South America,
bordering the North Adantic Ocean,
between French Guiana and Guyana
Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
total: 163,270 sq km
land: 161,470 sq km
water: 1 ,800 sq km
Area— comparative: slightly larger than
Location: Northern Europe, islands
between the Arctic Ocean, Barents Sea,
Greenland Sea, and Norwegian Sea, north
of Norway
Geographic coordinates:
78 00 N, 20 00 E
Map references: Arctic Region
Area: total: 61,020 sq km
land: 61,020 sq km
ivater: 0 sq km
note: includes Spitsbergen and Bjornoya
(Bear Island)
Area— comparative: slightly smaller than
West Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims: territorial sea: 4 nm
exclusive fishing zone: 200 nm unilaterally
644
SVALBARD
claimed by Norway but not recognized by
Russia
Climate: arctic, tempered by warm North
Atlantic Current; cool summers, cold
winters; North Adantic Current flows
along west and north coasts of Spitsbergen,
keeping water open and navigable most of
the year
Terrain: wild, rugged mountains; much of
high land ice covered; west coast clear of ice
about one-half of the year; fjords along west
and north coasts
Elevation extremes:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717 m
Natural resources: coal, iron ore, copper,
zinc, phosphate, wildlife, fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (no trees; the only bushes are
crowberry and cloudberry) (2005)
Irrigated land: NA
Natural hazards: ice floes often block the
entrance to Bellsund (a transit point for coal
export) on the west coast and occasionally
make parts of the northeastern coast inac¬
cessible to maritime traffic
Environment— current issues: NA
Geography— note: northernmost part of
the Kingdom of Norway; consists of nine
main islands; glaciers and snowfields cover
60% of the total area; Spitsbergen Island is
the site of the Svalbard Global Seed Vault,
a seed repository established by the Global
Crop Diversity Trust and the Norwegian
Location: Southern Africa, between
Mozambique and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area: total: 17,363 sq km
land: 17,203 sq km
water: 160 sq km
Area— comparative: slightly smaller than
New Jersey
Land boundaries: total: 5 35 km
border countries: Mozambique 105 km,
South Africa 430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near
temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21m
highest point: Emlembe 1 ,862 m
Natural resources: asbestos, coal, clay,
cassiterite, hydropower, forests, small gold
and diamond deposits, quarry stone, and
talc
Land use: arable land: 10.25%
permanent crops: 0.81%
other: 88.94% (2005)
Irrigated land: 500 sq km (2003)
Total renewable water resources:
4.5 cu km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 1.04 cu
km/yr (2%/l%/97%)
per capita: 1,010 cu m/yr (2000)
Natural hazards:
drought
Environment — current issues: limited
supplies of potable water; wildlife popula¬
tions being depleted because of excessive
hunting; overgrazing; soil degradation; soil
erosion
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography— note: landlocked; almost
completely surrounded by South Africa','ac9b83396e11915c742e17e10f57afcc121674fbb423a1f727a303347e000439','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e49ee1c039b4d31de974c0f7394e60f8977429abf8fb1879b3703cc836631c4',2010,'CH','Switzerland','geography',1439,'Location: Central Europe, east of France,
north of Italy
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area: total: 41,290 sq km
land: 39,770 sq km
water: 1,520 sq km
Area — comparative: slightly less than
twice the size of New Jersey
Land boundaries: total: 1,852 km
border countries: Austria 164 km, France
573 km, Italy 740 km, Liechtenstein 41
km, Germany 334 km
Coastline: 0 km (landlocked)
Maritime claims:
none (landlocked)
Climate: temperate, but varies with
altitude; cold, cloudy, rainy/snowy winters;
cool to warm, cloudy, humid summers
with occasional showers
Terrain: mosdy mountains (Alps in south,
Jura in northwest) with a central plateau of
rolling hills, plains, and large lakes
Elevation extremes:
lowest point: Lake Maggiore 1 95 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential,
timber, salt
Land use: arable land: 9.91%
permanent crops: 0.58%
other: 89.51% (2005)
Irrigated land: 250 sq km (2003)
Total renewable wa ter resources: 53.3 cu
km (2005)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 2.52 cu km/yr (24%/74%/2%)
per capita: 348 cu m/yr (2002)
Natural hazards: avalanches, landslides;
flash floods
Environment — current issues: air
pollution from vehicle emissions and
open-air burning; acid rain; water pollution
from increased use of agricultural fertilizers;
loss of biodiversity
Environment — international agreements:
party to: Air Pollution, Air Pollution-
Nitrogen Oxides, Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur
85, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94,
Wedands, Whaling
signed, but not ratified: Law of the Sea
Geography — nofe: landlocked; crossroads
of northern and southern Europe; along
with southeastern France, northern Italy,
and southwestern Austria, has the highest
elevations in the Alps
Location: Middle East, bordering the
Mediterranean Sea, between Lebanon and
Turkey
Geographic coordinates: 35 00 N, 38 00 E
Map references: Middle East
Area: total: 185,180 sq km
land: 184,050 sq km
water: 1,130 sq km
note: includes 1,295 sq km of Israeli-
occupied territory
Area — comparative: slightly larger than
North Dakota
Land boundaries: total: 2,253 km
border countries: Iraq 605 km, Israel 76 km,
Jordan 375 km, Lebanon 375 km, Turkey
822 km
Coastline: 193 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
Climate: mosdy desert; hot, dry, sunny
summers (June to August) and mild, rainy
winters (December to February) along
coast;, cold weather with snow or sleet peri¬
odically in Damascus
Terrain: primarily semiarid and desert
plateau; narrow coastal plain; mountains
in west
Elevation extremes: lowest point: unnamed
location near Lake Tiberias -200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum, phos¬
phates, chrome and manganese ores,
asphalt, iron ore, rock salt, marble, gypsum,
hydropower
Land use: arable land: 24.8%
permanent crops: 4.47%
other: 70.73% (2005)
Irrigated land: 13,330 sq km (2003)
Total renewable water resources: 46.1
cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural): total. 19.95 cu
km/yr (3%/2%/95%)
per capita: 1,048 cu m/yr (2000)
Natural hazards: dust storms, sandstorms
Environment— current issues: defor¬
estation; overgrazing; soil erosion;
desertification; water pollution from raw
sewage and petroleum refining wastes;
inadequate potable water
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Environmental
Modification
Geography — note: there are 42 Israeli
settlements and civilian land use sites in
the Israeli-occupied Golan Heights (August
2005 est.)','89b04dfbd8d979996ed0303b0af22076e83a26955e1e76fefda7f96967e985fa','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50e1f0932883b940d27cbee367e9d25fa37dfa554f6fd1904b4fe6cb7143c081',2010,'TL','Timor-Leste','geography',1450,'Location: Southeastern Asia, northwest of
Australia in the Lesser Sunda Islands at the
eastern end of the Indonesian archipelago;
note— Timor-Leste includes the eastern
half of the island of Timor, the Oecussi
(Ambeno) region on the northwest portion
of the island of Timor, and the islands of
Pulau Atauro and Pulau Jaco
Geographic coordinates:
8 50 S, 125 55 E
Map references: Southeast Asia
Area: total: 15,007 sq km
land: NA sq km
water: NA sq km
Area— comparative: slightly larger than
Connecticut
Land boundaries: total: 228 km
border countries: Indonesia 228 km
Coastline: 706 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive fishing zone: 200 nm
Climate: tropical; hot, humid; distinct
rainy and dry seasons
Terrain: mountainous
Elevation extremes: lowest point: Timor
Sea, Savu Sea, and Banda Sea 0 m
highest point: Foho Tatamailau 2,963 m
Natural resources: gold, petroleum,
natural gas, manganese, marble
Land use: arable land: 8.2%
permanent crops: 4.57%
other: 87.23% (2005)
Irrigated land: 1,065 sq km (2003)
Natural hazards: floods and landslides are
common; earthquakes; tsunamis; tropical
cyclones
Environment — current issues: widespread
use of slash and bum agriculture has led to
deforestation and soil erosion
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification
signed, but not ratified: none of the selected
agreements
Geography— note: Timor comes from the
Malay word for “East”; the island of Timor
is part of the Malay Archipelago and is
the largest and easternmost of the Lesser
Sunda Islands','abf334b9bac9b1a71067873e0996d5317a2b6a5ea5a0037256f080884f27b56a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54d686797832357ba2a640aabbd23da4222eefd2fba98ed838b4d09e72679493',2010,'TG','Togo','geography',1454,'Location: Western Africa, bordering the
Bight of Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, l 10 E
Map references: Africa
Area:
total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
Area — comparative: slightly smaller dran
West Virginia
Land boundaries: total: 1 ,647 km
border countries: Benin 644 km, Burkina
Faso 126 km, Ghana 877 km
Coastline: 56 km
Maritime Claims: territorial sea: 30 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid in south;
semiarid in north
Terrain: gently rolling savanna in north;
central hills; southern plateau; low coastal
plain with extensive lagoons and marshes
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mont Agou 986 m
Natural resources: phosphates, limestone,
marble, arable land
Land use: arable land: 44.2%
permanent crops: 2.11%
other: 53.69% (2005)
Irrigated land: 70 sq km (2003)
Total renewable water resources: 14.7 cu
km (2001)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 0.17 cu
km/yr (53%/2%/45%)
per capita: 28 cu m/yr (2000)
Natural hazards: hot, dry harmattan wind
can reduce visibility in north during winter;
periodic droughts
Environment — current issues: defor¬
estation attributable to slash-and-burn
agriculture and the use of wood for fuel;
water pollution presents health hazards
and hinders the fishing industry; air pollu¬
tion increasing in urban areas
Environment— international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Law
of the Sea, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: the country’s length
allows it to stretch through six distinct
geographic regions; climate varies from
tropical to savanna','b1b0a4b8b26f647c8d568288f23da5819b49f0505d3832032e64b9dc93e21c48','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbb7d034f4e0e5750205463bbc93a481481f447b54b0e96f29920cdc66d26528',2010,'TK','Tokelau','geography',1462,'Location: Oceania, group of three atolls in
the South Pacific Ocean, about one-half of
the way from Hawaii to New Zealand
Geographic coordinates: 9 00 S, 1 72 00 W
Map references: Oceania
679
THE CIA WORLD FACTBOOK
0 18 4<> m
0 20 40 s-,1
Atafu
Nukumm [ .
F&kmf b
Area: total: 10 sq km
land: 1 0 sq km
water: 0 sq km
Area— comparative: about 17 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime Claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade
winds (April to November)
Terrain: low-lying coral atolls enclosing
large lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use: arable land: 0% (soil is thin
and infertile)
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: lies in Pacific typhoon belt
Environment — current issues: limited
natural resources and overcrowding are
contributing to emigration to New Zealand
Geography— note: consists of three atolls
(Atafu, Fakaofo, Nukunonu), each with a
lagoon surrounded by a number of reef-
bound islets of varying length and rising to
over 3 m above sea level','5b5cae4646cf671d73a9f38b75a21b928fc12f180e88fc5faf8e7d40d8c3016f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbb3ec4c13b37bf06d5dc50d4db843d0eac7703fe07c396a2f65de8c1363c2a8',2010,'TO','Tonga','geography',1468,'Location: Oceania, archipelago in the
South Pacific Ocean, about two-thirds of
the way from Hawaii to New Zealand
Geographic coordinates: 20 00 S, 1 75 00 W
Map references: Oceania
Area:
total: 748 sq km
land: 718 sq km
water: 30 sq km
Area — comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime Claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depdi of exploitation
Climate: tropical; modified by trade winds;
warm season (December to May), cool
season (May to December)
Terrain: most islands have limestone base
formed from uplifted coral formation; others
have limestone overlying volcanic base
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location on Kao
Island 1,033 m
Natural resources: fish, fertile soil
Land use: arable land: 20%
permanent crops: 14.67%
other: 65.33% (2005)
Irrigated land: NA
Natural hazards: cyclones (October to
April); earthquakes and volcanic activity on
Fonuafo’ou
Environment — current issues: deforesta¬
tion results as more and more land is being
cleared for agriculture and settlement;
some damage to coral reefs from starfish
and indiscriminate coral and shell collec¬
tors; overhunting threatens native sea turtle
populations
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Law of the Sea, Marine
Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography — note: archipelago of 169
islands (36 inhabited)
681
THE CIA WORLD FACTBOOK','71c83536147bb951141eddb9e3f6c1a085d6904ede7cea005c8da6e1f7a674d9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60dad800c09543eb88d1b2f23ac68af60ab379563555cac3ea16edaa2be7baa0',2010,'TT','Trinidad and Tobago','geography',1472,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic
Ocean, northeast of Venezuela
Geographic coordinates: 1 1 00 N, 61 00 W
Map references: Central America and the
Caribbean
Area: total: 5,128 sq km
land: 5,128 sq km
water: 0 sq km
Area — comparative: slightly smaller than
Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime Claims: measured from claimed
archipelagic baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the outer
edge of the continental margin
Climate: tropical; rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas,
asphalt
Land use: arable land: 14.62%
permanent crops: 9.16%
other: 76.22% (2005)
Irrigated land: 40 sq km (2003)
Total renewable water resources: 3.8 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 0.31 cu km/yr
(68%/26%/6%)
per capita: 237 cu m/yr (2000)
Natural hazards: outside usual path of
hurricanes and other tropical storms
Environment — current issues: water pollu¬
tion from agricultural chemicals, industrial
wastes, and raw sewage; oil pollution of
beaches; deforestation; soil erosion
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography— note: Pitch Lake, on Trini¬
dad’s southwestern coast, is the world’s
largest natural reservoir of asphalt','01b00bb7cb3ded2fa5c2d9c5bf1326d7c55fd2292c526febbc742417774cd185','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d42c13c1aade0ffea164e63a9a0cce5875e5c0fac7d2c4d21ab5d83aaafb5dad',2010,'TM','Turkmenistan','geography',1479,'Location: Central Asia, bordering the
Caspian Sea, between Iran and Kaza¬
khstan
Geographic coordinates: 40 00 N, 60 00
E
Map references: Asia
Area: total: 488,100 sq km
land: 488,100 sq km
water: NEGL
Area — comparative: slightly larger than
California
Land boundaries: total: 3,736 km
border countries: Afghanistan 744 km, Iran
992 km, Kazakhstan 379 km, Uzbekistan
1,621 km
Coastline: 0 km; note— Turkmenistan
borders the Caspian Sea (1,768 km)
Maritime Claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with
dunes rising to mountains in the south;
low mountains along border with Iran;
borders Caspian Sea in west
Elevation extremes: lowest point: Vpadina
Akchanaya -81 m; note— Sarygamysh Koli
is a lake in northern Turkmenistan with a
water level that fluctuates above and below
the elevation of Vpadina Akchanaya (the
lake has dropped as low as -1 1 0 m)
highest point: Gora Ayribaba 3,139 m
Natural resources: petroleum, natural gas,
sulfur, salt
Land use: arable land: 4.51%
permanent crops: 0.14%
other: 95.35% (2005)
Irrigated land: 18,000 sq km (2003)
Total renewable water resources: 60.9 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 24 65 cu km/yr
(2%/l%/98%)
per capita: 5,104 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: contami¬
nation of soil and groundwater with agri¬
cultural chemicals, pesticides; salination,
water logging of soil due to poor irrigation
methods; Caspian Sea pollution; diversion
of a large share of the flow of the Amu
Darya into irrigation contributes to that
river’s inability to replenish the Aral Sea;
desertification
Environment — international agree¬
ments: party to: Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Hazardous Wastes,
O zone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; the western
and central low-lying desolate portions of
the country make up the great Garagum
(Kara-Kum) desert, which occupies over
80% of the country; eastern part is plateau','4171f7136d200f999af70e0562601cae1120ef87eeea44c2aedc2a86a077a42f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd7ef82a006548d09001dd7cdb9ad5f26a620bfdc9bb630714273c1eb676ab0c',2010,'TC','Turks and Caicos Islands','geography',1488,'Location: Caribbean, two island groups
in the North Atlantic Ocean, southeast of
The Bahamas, north of Haiti
Geographic coordinates:
21 45 N, 71 35 W
697
THE CIA WORLD FACTBOOK
Map references: Central America and the
Caribbean
Area: total: 430 sq km
land: 430 sq km
water: 0 sq km
Area — comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime Claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical; marine; moderated by
trade winds; sunny and relatively dry
Terrain: low, flat limestone; extensive
marshes and mangrove swamps
Elevation extremes: lowest point: Carib¬
bean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land USe: arable land: 2.33%
permanent crops: 0%
other: 97.67% (2005)
Irrigated land: NA
Natural hazards: frequent hurricanes
Environment — current issues: limited
natural fresh water resources, private
cisterns collect rainwater
Geography — note: about 40 islands (eight
inhabited)','5197c37e4530ba794fa93b870195d6c1f6df622c7b25302057c1ef263afedb87','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e22222be8c2f25eb6c2ed63bf6879dcf48fa5d64bb0cf641aa68f99e44903c1',2010,'TV','Tuvalu','geography',1493,'Location: Oceania, island group consisting
of nine coral atolls in the South Pacific
Ocean, about one-half of the way from
Hawaii to Australia
Radio broadcast stations: AM 2, FM 7,
shortwave 0 (2003)
Radios: 8,000 (1997)
Television broadcast stations: 0 (broad¬
casts received from The Bahamas; 2 cable
television networks) (2003)
Televisions: NA
Internet country code: tc
Internet hosts: 2,352 (2008)
Internet Service Providers (ISPs): 14
(2000)
Internet users: NA','1bb027d715d48ff5a13ae430ce3b113a47c939060f886a58862845190d808cd3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('162647a87fc61177b0d2b52295de7879baeaf91fa29dbfbb9cb4d91a4c39d8a1',2010,'UG','Uganda','geography',1500,'Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00
E
Map references: Africa
Area: total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
Area— comparative: slightly smaller than
Oregon
Land boundaries: total. 2,698 km
border countries: Democratic Republic of the
Congo 765 km, Kenya 933 km, Rwanda
169 km, Sudan 435 km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; generally rainy with two
dry seasons (December to February, June
to August); semiarid in northeast
Terrain: mostly plateau with rim of moun¬
tains
Elevation extremes: lowest point: Lake
Albert 621 m 1
highest point: Margherita Peak -on Mount
Stanley 5,1 10 m
Natural resources: copper, cobalt, hydro¬
power, limestone, salt, arable land
Land use: arable land: 21.57%
permanent crops: 8.92%
other: 69.51% (2005)
Irrigated land: 90 sq km (2003)
Total renewable water resources: 66 cu
km (1970)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 0.3 cu km/yr (43%/l 7%/ 40%)
per capita: 10 cu m/yr (2002)
Natural hazards: NA
Environment — current issues: draining of
wedands for agricultural use; deforestation;
overgrazing; soil erosion; water hyacinth
infestation in Lake Victoria; widespread
poaching
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deserti¬
fication, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conser¬
vation, Ozone Layer Protection, Wedands
signed, but not ratified: Environmental
Modification
Geography— note: landlocked; fertile, well-
watered country with many lakes and rivers','6c50c4978c4e654fa92b7b774f06b9b4e2ac77c9c7d547489f3c73f870c00510','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('129dcc85df14c8fdcadad5aff9dc7ae7534ab65a68d8f6a738cf37b229e2d0d7',2010,'AE','United Arab Emirates','geography',1517,'Location: Middle East, bordering the Gulf
of Oman and the Persian Gulf, between
Oman and Saudi Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area: total: 83,600 sq km
land: 83,600 sq km
water: 0 sq km
Area— comparative: slightly smaller than
Maine
Land boundaries: total. 867 km
border countries: Oman 410 km, Saudi
Arabia 457 km
Coastline: 1,318 km
Maritime Claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging
into rolling sand dunes of vast desert waste¬
land; mountains in east
Elevation extremes: lowest point: Persian
Gulf 0 m
highest point: Jabal Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use: arable land: 0.77%
permanent crops: 2.27%
other: 96.96% (2005)
Irrigated land: 760 sq km (2003)
Total renewable water resources: 0.2 cu
km (1997)
Freshwater withdrawal (domestic/indus¬
trial/agricultural):
total 2.3 cu km/yr (23%/9%/68%)
per capita: 511 cu m/yr (2000)
Natural hazards: frequent sand and dust
storms
Environment — current issues: lack of
natural freshwater resources compensated
by desalination plants; desertification;
beach pollution from oil spills
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping,
Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography— note: strategic location along
southern approaches to Strait of Hormuz, a
vital transit point for world crude oil','5b9580aff04ce105a2f40e2c66167a71efc5b91a6ddad9a34b58a52ff50c6932','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be457170a63aea1c5eb0eae0507d58c42f389c3c63ecd95067c5ffc749252c54',2010,'GB','United Kingdom','geography',1524,'Location: Western Europe, islands
including the northern one-sixdi of the
island of Ireland between the North
Atlantic Ocean and the North Sea, north¬
west of France
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area: total: 244,820 sq km
land: 241,590 sq km
water: 3,230 sq km
note: includes Rockall and Shedand
Islands
Area — comparative: shghdy smaller than
Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
territorial sea: 1 2 nm
exclusive fishing zone: 200 nm
continental shelf: as defined in continental
shelf orders or in accordance with agreed
upon boundaries
Climate: temperate; moderated by
prevailing southwest winds over the North
Adantic Current; more than one-half of the
days are overcast
Terrain: mosdy rugged hills and low
mountains; level to rolling plains in east
and southeast
Elevation extremes: lowest point: The
Fens -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum,
natural gas, iron ore, lead, zinc, gold, tin,
limestone, salt, clay, chalk, gypsum, potash,
silica sand, slate, arable land
Land use: arable land: 23.23%
permanent crops: 0.2%
other: 76.57% (2005)
Irrigated land: 1,700 sq km (2003)
712
Total renewable water resources: 160.6
cu km (2005)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 11.75 cu km/yr
(22%/7 5%/3%)
per capita: 197 cu m/yr (1994)
Natural hazards: winter windstorms;
floods
Environment — current issues: continues
to reduce greenhouse gas emissions (has
met Kyoto Protocol target of a 1 2.5% reduc¬
tion from 1990 levels and intends to meet
the legally binding target and move toward
a domestic goal of a 20% cut in emissions
by 2010); by 2005 the government reduced
the amount of industrial and commercial
waste disposed of in landfill sites to 85%
of 1998 levels and recycled or composted
at least 25% of household waste, increasing
to 33% by 201 5
Environment— international agree¬
ments: party to: Air Pollution, Air
Pollution-Nitrogen Oxides, Air Pollu¬
tion-Persistent Organic Pollutants, Air
Pollution-Sulflir 94, Air Pollution-Volatile
Organic Compounds, Antarctic-Environ¬
mental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine
Life Conservation, Ozone Layer Protec¬
tion, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography — note: lies near vital North
Atlantic sea lanes; only 35 km from France
and linked by tunnel under the English
Channel; because of heavily indented
coastline, no location is more than 125 km
from tidal waters','7ecf37fe62dccd82976b21ee55228d6e89bec10473121d3c146c47e6879a9fd8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('483b4ec85e6e3d90ecfb89f09ebbb2c72d00add5936566dc3442966c2fa326eb',2010,'UY','Uruguay','geography',1532,'public for wildlife-related recreation in the
form of wildlife observation and photog¬
raphy
Palmyra Atoll: the high rainfall and
resulting lush vegetation make the environ¬
ment of this atoll unique among the US
Pacific Island territories; supports a large
undisturbed stand of Pisonia beach forest
Location: Southern South America,
bordering the South Atlantic Ocean,
between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00
W
Map references: South America
Area: total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area — comparative: slightly smaller than
the state of Washington
Land boundaries: total: 1 ,648 km
border countries: Argentina 580 km, Brazil
1 ,068 km
Coastline: 660 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or edge of conti¬
nental margin
Climate: warm temperate; freezing temper¬
atures almost unknown
Terrain: mostly rolling plains and low hills;
fertile coastal lowland
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: arable land, hydro¬
power, minor minerals, fisheries
723
THE CIA WORLD FACTBOOK
Land use: arable land: 1.11%
permanent crops: 0.24%
other: 91.99% (2005)
Irrigated land: 2,100 sq km (2003)
Total renewable water resources: 1 39 cu
km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 3.15 cu km/yr
(2%/l%/96%)
per capita: 910 cu m/yr (2000)
Natural hazards: seasonally high winds
(the pampero is a chilly and occasional
violent wind that blows north from the
Argentine pampas), droughts, floods;
because of the absence of mountains,
which act as weather barriers, all locations
are particularly vulnerable to rapid changes
from weather fronts
Environment — current issues: water
pollution from meat packing/tannery
industry; inadequate solid/hazardous waste
disposal
Environment— international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species,
Environmental Modification, Hazardous
Wastes, Law of die Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Dumping,
Marine Life Conservation
Geography— note: second-smallest South
American country (after Suriname); most
of the low-lying landscape (diree-quarters
of the country) is grassland, ideal for cattle
and sheep raising','628bbd1e462f609bd9eb125ae744640c66bd78d885670731d52478c657bb210f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbc740130107786879d14328bc6d51be94a3dd436420873593387bbdf7319755',2010,'UZ','Uzbekistan','geography',1540,'726
portion of the Aral Sea with a 420 km shoreline
Maritime Claims: none (doubly landlocked)
Climate: mosdy midlatitude desert, long,
hot summers, mild winters; semiarid grass-
land in east
Terrain: mosdy flat-to-rolling sandy desert
with dunes; broad, dat intensely irrigated
river valleys along course of Amu Darya,
Syr Darya (Sirdaryo), and Zarafshon;
Fergana Valley in east surrounded by
mountainous Tajikistan and Kyrgyzstan;
shrinking Aral Sea in west
Elevation extremes: lowest point: Sariqar-
nish Kuli -1 2 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum,
coal, gold, uranium, silver, copper, lead
and zinc, tungsten, molybdenum
Land USe: arable land: 10.51%
permanent crops: 0.76%
other: 88.73% (2005)
Irrigated land: 42,810 sq km (2003)
Total renewable water resources: 72.2 cu
km (2003)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 58.34 cu km/yr
(5%/2%/93%)
per capita: 2,194 cu m/yr (2000)
Natural hazards: NA
Environment — current issues: shrinkage
of the Aral Sea is resulting in growing
concentrations of chemical pesticides and
natural salts; these substances are then
blown from the increasingly exposed lake
bed and contribute to desertification; water
pollution from industrial wastes and the
heavy use of fertilizers and pesticides is the
cause of many human health disorders;
increasing soil salination; soil contamina¬
tion from buried nuclear processing and
agricultural chemicals, including DDT
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: along with Liechten¬
stein, one of the only two doubly land¬
locked countries in the world','d52aa689465f9b0d0f7c7bdb55a99d5b4bb6002bb485c969a7730b5edb7bde9e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0487be086ae0e4c4bca7d54699ba368b321e7a417d3912af522499d22f97e1ca',2010,'VU','Vanuatu','geography',1548,'Location: Oceania, group of islands in the
South Pacific Ocean, about three-quarters
of the way from Hawaii to Australia
Geographic coordinates: 16 00 S, 167
00 E
Map references: Oceania
Area: total: 12,200 sq km
land: 1 2,200 sq km
water: 0 sq km
note: includes more than 80 islands, about
65 of which are inhabited
Area — comparative: slightly larger than
Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime Claims: measured from claimed
archipelagic baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical; moderated by south¬
east trade winds from May to October;
moderate rainfall from November to April;
may be affected by cyclones from December
to April
Terrain: mostly mountainous islands of
volcanic origin; narrow coastal plains
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Tabwemasana 1,877 m
Natural resources: manganese, hardwood
forests, fish
Land use: arable land: 1.64%
permanent crops: 6.97%
other: 91.39% (2005)
Irrigated land: NA
Natural hazards: tropical cyclones or
typhoons (January to April); volcanic erup¬
tion on Aoba (Ambae) island began 27
November 2005, volcanism also causes
minor earthquakes; tsunamis
Environment — current issues: most of the
population does not have access to a reliable
supply of potable water; deforestation
Environment — international agreements:
party to: Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography — note: a Y-shaped chain of
four main islands and 80 smaller islands;
several of the islands have active volcanoes
Location: Northern South America,
bordering the Caribbean Sea and the
North Atlantic Ocean, between Colombia
and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America
Area: total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area — comparative: slightly more than
twice the size of California
Land boundaries: total: 4,993 km
border countries: Brazil 2,200 km, Colombia
2,050 km, Guyana 743 km
Coastline: 2,800 km
733
THE CIA WORLD FACTBOOK
Maritime Claims: territorial sea : 12 nm
contiguous zone: 15 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the
depth of exploitation
Climate: tropical; hot, humid; more
moderate in highlands
Terrain: Andes Mountains and Marac¬
aibo Lowlands in northwest; central plains
(llanos); Guiana Highlands in southeast
Elevation extremes: lowest point: Carib¬
bean Sea 0 m
highest point: Pico Bolivar (La Columna)
5,007 m
Natural resources: petroleum, natural
gas, iron ore, gold, bauxite, other minerals,
hydropower, diamonds
Land use: arable land: 2.85%
permanent crops: 0.88%
other: 96.27% (2005)
Irrigated land: 5,750 sq km (2003)
Total renewable water resources: 1 ,233.2
cu km (2000)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 8.37 cu km/yr
(6%/7%/47%)
per capita: 313 cu m/yr (2000)
Natural hazards: subject to floods, rock-
slides, mudslides; periodic droughts
Environment — current issues: sewage
pollution of Lago de Valencia; oil and urban
pollution of Lago de Maracaibo; deforesta¬
tion; soil degradation; urban and industrial
pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem
from irresponsible mining operations
Environment— international agreements:
party to: Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Trop¬
ical Timber 83, Tropical Timber 94, Wetlands
signed but not ratified:: none of the selected
agreements
Geography— note: on major sea and air
routes linking North and South America;
Angel Falls in the Guiana Highlands is the
world’s highest waterfall
Location: Southeastern Asia, bordering
the Gulf of Thailand, Gulf of Tonkin, and
South China Sea, alongside China, Laos,
and Cambodia
Geographic coordinates: 16 10 N, 107
50 E
Map references: Southeast Asia
Area: total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area — comparative: slighdy larger than
New Mexico
Land boundaries: total 4,639 km
border countries: Cambodia 1,228 km,
China 1,281 km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims: territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: tropical in south; monsoonal
in north with hot, rainy season (May to
September) and warm, dry season (October
to March)
Terrain: low, flat delta in south and north;
central highlands; hilly, mountainous in
far north and northwest
Elevation extremes: lowest point: South
China Sea 0 m
highest point: Fan Si Pan 3,144 m
Natural resources: phosphates, coal,
manganese, bauxite, chromate, offshore oil
and gas deposits, forests, hydropower
Land USe: arable land: 20.14%
permanent crops: 6.93%
other: 72.93% (2005)
Irrigated land: 30,000 sq km (2003)
Total renewable water resources: 891.2
cu km (1999)
Freshwater withdrawal (domestic/indus¬
trial/agricultural): total: 71.39 cu km/yr
(8%/24%/68%)
per capita: 847 cu m/yr (2000)
Natural hazards: occasional typhoons
(May to January) with extensive flooding,
especially in the Mekong River delta
Environment — current issues: logging
and slash-and-burn agricultural prac¬
tices contribute to deforestation and soil
degradation; water pollution and over¬
fishing threaten marine life populations;
737
THE CIA WORLD FACTBOOK
groundwater contamination limits potable
water supply; growing urban industrializa¬
tion and population migration are rapidly
degrading environment in Hanoi and Ho
Chi Minh City
Environment — international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Deser¬
tification, Endangered Species, Environ¬
mental Modification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography — note: extending 1,650 km
north to south, the country is only 50 km
across at its narrowest point
Location: Caribbean, islands between the
Caribbean Sea and the North Adantic
Ocean, east of Puerto Rico
Geographic coordinates: 18 20 N, 64 50
W
Map references: Central America and the
Caribbean
Area:
total: 1 ,910 sq km
land: 346 sq km
1 water : 1 ,564 sq km
Area — comparative: twice the size of
Washington, DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: subtropical, tempered by east¬
erly trade winds, relatively low humidity,
little seasonal temperature variation; rainy
season September to November
Terrain: mostly hilly to rugged and moun¬
tainous with little level land
Elevation extremes: lowest point: Carib¬
bean Sea 0 m
highest point: Crown Mountain 475 m
Natural resources: sun, sand, sea, surf
Land use: arable land: 5.71%
permanent crops: 2.86%
other: 91.43% (2005)
Irrigated land: NA
Natural hazards: several hurricanes in
recent years; frequent and severe droughts
and floods; occasional earthquakes
Environment — current issues: lack of
natural freshwater resources
Geography— note: important location
along the Anegada Passage— a key shipping
lane for the Panama Canal; Saint Thomas
has one of die best natural deepwater
harbors in the Caribbean
Location: Oceania, atoll in the North
Pacific Ocean, about two-thirds of the way
from Hawaii to the Northern Mariana
Islands
Geographic coordinates: 19 17 N, 166
39 E
Map references: Oceania
Area: total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area— comparative: about 11 times the
size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime Claims: territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical
Terrain: atoll of three low coral islands,
Peale, Wake, and Wilkes, built up on
an underwater volcano; central lagoon is
former crater, islands are part of the rim
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: unnamed location 6 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km
Natural hazards: occasional typhoons
Environment— current issues: NA
Geography— note: strategic location in the
North Pacific Ocean; emergency landing
location for transpacific flights','b886c84f389973b462125f2988155d729267e6851b65fc35764b84db220cb099','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c445c1966bf358dad65f11ec75d4713c9809bad0fdc5602cfd64f2f275bafb2',2010,'WF','Wallis and Futuna','geography',1556,'Location: Oceania, islands in the South
Pacific Ocean, about two-thirds of the way
from Hawaii to New Zealand
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total: 274 sq km
land: 274 sq km
water: 0 sq km
note: includes lie Uvea (Wallis Island), lie
Futuna (Futuna Island), He Alofi, and 20
islets
Area— comparative: 1.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
743
THE CIA WORLD FACTBOOK
0 SO fcm
>2 2f>
lies
VVBUtS
MATA-UTU*
lie Uv6z
lies d® Home
FiJtum
»§Ipav» (L«av»)
he AM
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, rainy season
(November to April); cool, dry season
(May to October); rains 2,500-3,000 mm
per year (80% humidity); average tempera¬
ture 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes: lowest point: Pacific
Ocean 0 m
highest point: Mont Singavi (on Futuna)
765 m
Natural resources: NEGL
Land use: arable land: 7.14%
permanent crops: 35.71%
other: 57.15% (2005)
Irrigated land: NA
Natural hazards: NA
Environment— current issues: deforesta¬
tion (only small portions of the original
forests remain) largely as a result of the
continued use of wood as the main fuel
source; as a consequence of cutting down
the forests, the mountainous terrain of
Futuna is particularly prone to erosion;
there are no permanent settlements on
Alofi because of the lack of natural fresh
water resources
Geography— note: both island groups
have fringing reefs','1d31b9129b15b4576ce255d01fcca76d64c99cad014deafcae4f8562eb4f5daf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('412f53fa181f1fa4ad30ba8425285df81196fae92d0bd5e8d9d53395e727bf9e',2010,'EH','Western Sahara','geography',1559,'Location: Nordiern Africa, bordering the
North Atlantic Ocean, between Mauritania
and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area— comparative: about the size of
Colorado
Land boundaries: total: 2,046 km
border countries: Algeria 42 km, Mauritania
1,561 km, Morocco 443 km
Coastline: 1,110 km
Maritime Claims: contingent upon resolu¬
tion of sovereignty issue
Climate: hot, dry desert; rain is rare; cold
offshore air currents produce fog and heavy
dew
Terrain: mostly low, tiat desert with large
areas of rocky or sandy surfaces rising to
small mountains in south and northeast
Elevation extremes: lowest point: Sebjet
Tah -55 m
highest point: unnamed elevation 805 m
Natural resources: phosphates, iron ore
Land use: arable land: 0.02%
permanent crops: 0%
other: 99.98% (2005)
Irrigated land: NA
Natural hazards: hot, dry, dust/sand-laden
sirocco wind can occur during winter and
spring; widespread harmattan haze exists
60% of time, often severely restricting visi¬
bility
Environment— current issues: sparse
water and lack of arable land
Environment — international agreements:
party to: none of the selected agreements
Geography— note: the waters off the coast
are particularly rich fishing areas
Geographic overview: The surface of
the earth is approximately 70.9% water
and 29.1% land. The former portion is
divided into large water bodies termed
oceans. The World Factbook recognizes
and describes five oceans, which are
in decreasing order of size: the Pacific
Ocean, Adantic Ocean, Indian Ocean,
Southern Ocean, and Arctic Ocean.
The land portion is generally divided into
several, large, discrete landmasses termed
continents. Depending on the convention
used, the number of continents can vary
from five to seven. The most common clas¬
sification recognizes seven, which are (from
largest to smallest): Asia, Africa, North
America, South America, Antarctica,
Europe, and Australia. Asia and Europe
are sometimes lumped together into a Eura¬
sian continent resulting in six continents.
Alternatively, North and South America
are sometimes grouped as simply the Amer¬
icas, resulting in a continent total of six (or
five, if the Eurasia designation is used).
North America is commonly understood to
include the island of Greenland, the isles of
the Caribbean, and to extend south all the
way to the Isthmus of Panama. The eastern¬
most extent of Europe is generally defined
as being the Ural Mountains and the Ural
River; on the southeast the Caspian Sea;
and on the south the Caucasus Mountains,
the Black Sea, and the Mediterranean.
Africa’s northeast extremity is frequently
delimited at the Isthmus of Suez, but for
geopolitical purposes, the Egyptian Sinai
Peninsula is often included as part of
Africa. Asia usually incorporates all the
islands of the Philippines, Malaysia, and
Indonesia. The islands of the Pacific are
often lumped with Australia into a “land
mass” termed Oceania or Australasia.
Although the above groupings are the most
common, different continental dispositions
are recognized or taught in certain parts of
the world, with some arrangements more
heavily based on cultural spheres rather
than physical geographic considerations.
Map references: Physical Map of the
World, Political Map of the World,
Standard Time Zones of the World
Area: total: 510.072 million sq km
land: 148.94 million sq km
water: 361.132 million sq km
note: 70.9% of the world’s surface is water,
29.1% is land
Area— comparative: land area about 16
times the size of the US
Land boundaries: the land boundaries in
the world total 251,060 km (not counting
shared boundaries twice); two nations , China
and Russia, each border 1 4 other countries
note: 45 nations and other areas are
landlocked, these include: Afghanistan,
Andorra, Armenia, Austria, Azerbaijan,
Belarus, Bhutan, Bolivia, Botswana,
Burkina Faso, Burundi, Central African
Republic, Chad, Czech Republic, Ethiopia,
Holy See (Vatican City), Hungary, Kaza¬
khstan, Kosovo, Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Luxembourg, Macedonia,
Malawi, Mali, Moldova, Mongolia,
Nepal, Niger, Paraguay, Rwanda, San
Marino, Serbia, Slovakia, Swaziland,
Switzerland, Tajikistan, Turkmenistan,
Uganda, Uzbekistan, West Bank, Zambia,
Zimbabwe; two of these, Liechtenstein and
Uzbekistan, are doubly landlocked
Coastline: 356,000 km
note: 94 nations and other entities are
islands that border no other countries,
they include: American Samoa, Anguilla,
Antigua and Barbuda, Aruba, Ashmore
and Cartier Islands, The Bahamas,
Bahrain, Baker Island, Barbados,
Bermuda, Bouvet Island, British Indian
Ocean Territory, British Virgin Islands,
Cape Verde, Cayman Islands, Christmas
Island, Clipperton Island, Cocos (Keeling)
Islands, Comoros, Cook Islands, Coral
Sea Islands, Cuba, Cyprus, Dominica,
Falkland Islands (Islas Malvinas), Faroe
Islands, Fiji, French Polynesia, French
Southern and Antarctic Lands, Greenland,
Grenada, Guam, Guernsey, Heard Island
and McDonald Islands, Howland Island,
Iceland, Isle of Man, Jamaica, Jan Mayen,
Japan, Jarvis Island, Jersey, Johnston Atoll,
Kingman Reef, Kiribati, Madagascar,
Maldives, Malta, Marshall Islands, Marti¬
nique, Mauritius, Mayotte, Federated
States of Micronesia, Midway Islands,
Montserrat, Nauru, Navassa Island, New
Caledonia, New Zealand, Niue, Norfolk
Island, Northern Mariana Islands, Palau,
Palmyra Atoll, Paracel Islands, Philippines,
Pitcairn Islands, Puerto Rico, Reunion,
Saint Barthelemy, Saint Helena, Saint Kitts
and Nevis, Saint Lucia, Saint Pierre and
Miquelon, Saint Vincent and the Gren¬
adines, Samoa, Sao Tome and Principe,
Seychelles, Singapore, Solomon Islands,
South Georgia and the South Sandwich
Islands, Spratly Islands, Sri Lanka, Svalbard,
Tokelau, Tonga, Trinidad and Tobago, Turks
and Caicos Islands, Tuvalu, Vanuatu,
Virgin Islands, Wake Island, Wallis and
Futuna, Taiwan
Maritime claims: a variety of situations
exist, but in general, most countries make
the following claims measured from the
750
WORLD
mean low-ride baseline as described in
the 1982 UN Convention on the Law of
the Sea: territorial sea— 12 nm, contiguous
zone— 24 nm, and exclusive economic
zone— 200 nm; additional zones provide for
exploitation of continental shelf resources
and an exclusive fishing zone; boundary
situations with neighboring states prevent
many countries from extending their fishing
or economic zones to a full 200 nm
Climate: a wide equatorial band of hot
and humid tropical climates— bordered
north and south by subtropical temperate
zones— that separate two large areas of cold
and dry polar climates
Terrain: the greatest ocean depth is the
Mariana Trench at 10,924 m in the Pacific
Ocean
Elevation extremes: lowest point: Bentley
Subglacial Trench -2,555 m
note: in the oceanic realm, Challenger
Deep in the Mariana Trench is the lowest
point, lying -10,924 m below the surface of
the Pacific Ocean
highest point: Mount Everest 8,850 m
Natural resources: the rapid depletion
of nonrenewable mineral resources, the
depletion of forest areas and wetlands, the
extinction of animal and plant species, and
the deterioration in air and water quality
(especially in some countries of Eastern
Europe, the former USSR, and China)
pose serious long-term problems that
governments and peoples are only begin¬
ning to address
Land use: arable land: 10.57%
permanent crops: 1.04%
other: 88.38% (2005)
irrigated land: 2,770,980 sq km (2003)
Natural hazards: large areas subject
to severe weather (tropical cyclones);
natural disasters (earthquakes, landslides,
tsunamis, volcanic eruptions)
Environment — current issues: large
areas subject to overpopulation, indus¬
trial disasters, pollution (air, water, acid
rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertification),
loss of wildlife, soil degradation, soil deple¬
tion, erosion; global warming becoming a
greater concern
Geography — note: the world is now
thought to be about 4.55 billion years old,
just about one-third of the 13.7-billion-year
age estimated for the universe','d145ed9fd58498bfaed73867fd447b419a528a40c89a434a4c809e0b4382deba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a200736f8c1b3d0eaa6078a680aef4839d59d4e4e8f4d8b9f07be65c120971a1',2010,'YE','Yemen','geography',1567,'Location: Middle East, bordering the
Arabian Sea, Gulf of Aden, and Red Sea,
between Oman and Saudi Arabia
Geographic coordinates: 1 5 00 N, 48 00 E
Map references: Middle East
Area: total: 521,910 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former
Yemen Arab Republic (YAR or North
Yemen), and the former People’s Demo¬
cratic Republic of Yemen (PDRY or South
Yemen)
Area— comparative: slightly larger than
twice the size of Wyoming
Land boundaries: total: 1,746 km
border countries: Oman 288 km, Saudi
Arabia 1 ,458 km
Coastline: 1,906 km
Maritime claims: territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of
the continental margin
Climate: mostly desert; hot and humid
along west coast; temperate in western
mountains affected by seasonal monsoon;
extraordinarily hot, dry, harsh desert in east
Terrain: narrow coastal plain backed by
flat-topped hills and rugged mountains;
dissected upland desert plains in center
slope into the desert interior of the Arabian
Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu’ayb
3,760 m
Natural resources: petroleum, fish, rock
salt, marble; small deposits of coal, gold,
lead, nickel, and copper; fertile soil in
west
Land use: arable land: 2.91%
permanent crops: 0.25%
Other: 96.84% (2005)
Irrigated land: 5,500 sq km (2003)
Total renewable water resources:
4.1 cu km (1997)
Freshwater withdrawal (domestic/
industrial/agricultural):
total: 6.63 cu km/yr (4%/l%/95%)
per capita: 316 cu m/yr (2000)
Natural hazards: sandstorms and dust
storms in summer
Environment — current issues: limited
natural fresh water resources; inadequate
supplies of potable water; overgrazing; soil
erosion; desertification
Environment— international agreements:
party to: Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertifi¬
cation, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography — note: strategic location on
Bab el Mandeb, the strait linking the Red
Sea and the Gulf of Aden, one of world’s
most active shipping lanes','503833b8f7fffd7e2a31a54db15699945754f2ccff3e08bd753dfc961fe03a1b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22795acf5ca5c74ae0775649f5700d51d398b30f95ff33537592c852daa15364',2010,'ZM','Zambia','geography',1575,'Location: Southern Africa, east of Angola
Geographic coordinates: 15 00 s, 30 00 E
Map references: Africa
Area:
total: 752,614 sq km
land: 740,724 sq km
water: 1 1 ,890 sq km
Area — comparative: slightly larger than
Texas
Land boundaries: total: 5,664 km
border countries: Angola 1,110 km, Demo¬
cratic Republic of the Congo 1,930 km,
Malawi 837 km, Mozambique 419 km,
Namibia 233 km, Tanzania 338 km,
Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; modified by altitude;
rainy season (October to April)
Terrain: mostly high plateau with some
hills and mountains
Elevation extremes: lowest point: Zambezi
river 329 m
highest point: unnamed location in Mafinga
Hills 2,301 m
Natural resources: copper, cobalt, zinc,
lead, coal, emeralds, gold, silver, uranium,
hydropower
Land use: arable land: 6.99%
permanent crops: 0.04%
other: 92.97% (2005)
Irrigated land: 1,560 sq km (2003)
Total renewable water resources: 105.2
cu km (2001)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total 1.74 cu km/yr
(17%/7%/76%)
per capita: 149 cu m/yr (2000)
Natural hazards: periodic drought; trop¬
ical storms (November to April)
Environment — current issues: air pollu¬
tion and resulting acid rain in the mineral
extraction and refining region; chemical
runoff into watersheds; poaching seriously
threatens rhinoceros, elephant, antelope,
and large cat populations; deforesta¬
tion; soil erosion; desertification; lack of
adequate water treatment presents human
health risks
Environment — international
agreements: party to: Biodiversity,
Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Wedands
signed, but not ratified: none of the selected
agreements
Geography — note: landlocked; the
Zambezi forms a natural riverine boundary
with Zimbabwe','0a50653131ce5d4554d68ea762a83a1d4f84ad9b83f648735842b6a4ea607b3b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74fc027bc51c7ad2fae14c1615b9d920c7bc15dc1589a8ab369a82ba696b024e',2010,'ZW','Zimbabwe','geography',1584,'Location: Southern Africa, between South
Africa and Zambia
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area: total: 390,580 sq km
land: 386,670 sq km
water: 3,910 sq km
Area — comparative: slightly larger than
Montana
Land boundaries: total: 3,066 km
border countries: Botswana 813 km, Mozam¬
bique 1,231 km, South Africa 225 km,
Zambia 797 km
Coastline: 0 km (landlocked)
Maritime Claims: none (landlocked)
Climate: tropical; moderated by altitude;
rainy season (November to March)
Terrain: mosdy high plateau with higher
central plateau (high veld); mountains in
east
Elevation extremes: lowest point: junction of
the Runde and Save rivers 162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore,
asbestos, gold, nickel, copper, iron ore, vana¬
dium, lithium, tin, platinum group metals
Land use: arable land: 8.24%
permanent crops: 0.33%
other: 91.43% (2005)
760
Irrigated land: 1,740 sq km (2003)
Total renewable water resources: 20 cu
km (1987)
Freshwater withdrawal (domestic/
industrial/agricultural): total: 4.21 cu
km/yr (14%/7%/79%)
per capita: 324 cu m/yr (2002)
Natural hazards: recurring droughts;
floods and severe storms are rare
Environment — current issues: deforesta¬
tion; soil erosion; land degradation; air and
water pollution; die black rhinoceros herd—
once die largest concentration of the species
in the world— has been significantly reduced
by poaching; poor mining practices have led
to toxic waste and heavy metal pollution
Environment— international agreements:
party to: Biodiversity'', Climate Change,
Desertification, Endangered Species, Law of
the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography— note: landlocked; the
Zambezi forms a natural riverine boundary
with Zambia; in full flood (February-April)
the massive Victoria Falls on the river
forms the world’s largest curtain of falling
water','4223ad21c39bcbf27961b33be7fbdb59cc8e1f9f2fe23df2cf9bf28dd3206610','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a463656fc8cda3708430934d3c3d38d3500d7b3818af8a6ee12384d70cdebf0',2010,'','','geography',2,'Location:
Geographic coordinates:
Map references:
Area:
total
land
water
Area - comparative:
Land boundaries:
total
border countries
Coastline:
Maritime claims:
territorial sea
contiguous zone
exclusive economic zone
continental shelf
exclusive fishing zone
Climate:
Terrain:
Elevation extremes:
lowest point
highest point
Natural resources:
Land use:
arable land
permanent crops
other
Irrigated land:
Total Renewable Water Resources:
Freshwater withdrawal (domestic/industrial/agricultural):
total
per capita
Natural hazards:
volcanism
Environment - current issues:
Environment - international agreements:
party to
signed, but not ratified
Geography - note:','065e9e553dfdfba1ac7f4b837b012309ff61481232bb7372566f0d1a3d7f75c8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98c99d3ad23f5d03dba5b6559db8bec87126d9c39b84831fb251a7e78ed7d7aa',2010,'TC','Turks and Caicos Islands','geography',18,'This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note
This entry includes miscellaneous geographic information of
significance not included elsewhere.
Gini index
See entry for Distribution of family income - Gini index
GNP
Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income
earned by its citizens abroad, minus income earned by foreigners
from domestic production. The Factbook, following current practice,
uses GDP rather than GNP to measure national production. However,
the user must realize that in certain countries net remittances from
citizens working abroad may be important to national well-being.
Why can''t I find a geographic name for a particular country?
The World Factbook is not a gazetteer (a dictionary or index of
places, usually with descriptive or statistical information) and
cannot provide more than the names of the administrative divisions
(in the Government category) and major cities/towns (on the country
maps). Our expanded Cross-Reference List of Geographic Names
(Appendix F), however, includes many of the world''s major geographic
features as well as historic (former) names of countries and cities
mentioned in The World Factbook.
Why are Taiwan and the European Union listed out of alphabetical
order at the end of the Factbook entries?
Taiwan is listed after the A-Z country entries because even though
the mainland People''s Republic of China claims Taiwan, elected
Taiwanese authorities de facto administer the island and reject
mainland sovereignty claims. With the establishment of diplomatic
relations with China on January 1, 1979, the US Government
recognized the People''s Republic of China as the sole legal
government of China, acknowledging the Chinese position that there
is only one China and that Taiwan is part of China.
The European Union (EU) is not a country, but it has taken on many
nation-like attributes and these may be expanded in the future. A
more complete explanation on the inclusion of the EU into the
Factbook can be found in the Preliminary statement.
Since we have an ambassador who represents the US at the Vatican,
why is this entity not listed in the Factbook?
Vatican City is found under Holy See. The term "Holy See" refers to
the authority and sovereignty vested in the Pope and his advisors to
direct the worldwide Catholic Church. As the jurisdictional equal of
a state, the Holy See can enter into treaties and sends and receives
diplomatic representatives. Vatican City, created in 1929 to
administer properties belonging to the Holy See in Rome, is
recognized under international law as a sovereign state, but it does
not send or receive diplomatic representatives. Consequently, Holy
See is included as a Factbook entry, with Vatican City
cross-referenced in the Geographic Names appendix.
Why is Palestine not listed in The World Factbook?
The Palestinian areas of Gaza Strip and West Bank are listed in the
Factbook.
Why are the Golan Heights not shown as part of Israel or Northern
Cyprus with Turkey?
Territorial occupations/annexations not recognized by the United
States Government are not shown on US Government maps.
Why don''t you include information on entities such as Tibet or
Kashmir?
The World Factbook provides information on the administrative
divisions of a country as recommended by the United States Board on
Geographic Names (BGN). The BGN is a component of the US Government
that develops policies, principles, and procedures governing the
spelling, use, and application of geographic names - domestic,
foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to have access to
uniform names of geographic features.
Also included in the Factbook are entries on parts of the world
whose status has not yet been resolved (e.g., West Bank, Spratly
Islands). Specific regions within a country or areas in dispute
among countries are not covered.
What do you mean when you say that a country is "doubly landlocked"?
A doubly landlocked country is one that is separated from an ocean
or an ocean-accessible sea by two intervening countries. Uzbekistan
and Liechtenstein are the only countries that fit this definition.
Why is the area of the United States described as "slightly larger
than China" in the Factbook , while other sources list China as
larger in area than the United States?
It all depends on whether one is looking at total area (land and
water) when making the comparison (which is the criterion used by
the Factbook) or just land area (which excludes inland water
features such as rivers and lakes).
Total area (combining land and water)
United States = 9,826,630 sq km China = 9,596,960 sq km
Land only (without any water features)
United States = 9,161,923 sq km China = 9,326,410 sq km
Why has The World Factbook dropped the four French departments of
Guadeloupe, Martinique, Reunion, and French Guiana?
The four entities are no longer in The World Factbook because their
status has changed. While they are overseas departments of France,
they are also now recognized as French regions, having equal status
to the 22 metropolitan regions that make up European France. In
other words, they are now recognized as being part of France proper.
Their status is somewhat analogous to Alaska and Hawaii vis-a-vis
the contiguous United States. Although separated from the larger
geographic entity, they are still considered to be an integral part
of it.
Photos ::
Why do you not have pictures for every country?
Inclusion of photos in The World Factbook is a new feature that
premiered with the unveiling of the redesigned online World Factbook
in June 2009. This is a long-term project, and we plan to
continuously add more photos to the site over time. Eventually, we
hope to have images for every country in the Factbook.
Could you include photos of people from different locations around
the world?
Factbook policy is to not include photos showing identifiable
individuals.
I have great travel photos from my trips abroad. Can I submit them
to your website to enhance your photo collection?
We appreciate the many offers from the public to contribute to our
photo collection. However, we only use photos from US Government
sources.
Spelling and Pronunciation ::
Why is the spelling of proper names such as rulers, presidents, and
prime ministers in The World Factbook different than their spelling
in my country?
The Factbook staff applies the names and spellings from the Chiefs
of State link on the CIA Web site. The World Factbook is prepared
using the standard American English computer keyboard and does not
use any special characters, symbols, or most diacritical markings in
its spellings. Surnames are always spelled with capital letters;
they may appear first in some cultures.
Why does the spelling of geographic names, features, cities,
administrative divisions, etc. in the Factbook differ from those
used in my country?
The United States Board on Geographic Names (BGN) recommends and
approves names and spellings. The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic names -
domestic, foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to use uniform names
of geographic features. (A note is usually included where changes
may have occurred but have not yet been approved by the BGN). The
World Factbook is prepared using the standard American English
computer keyboard and does not use any special characters, symbols,
or most diacritical markings in its spellings.
Why does The World Factbook omit pronunciations of country or leader
names?
There are too many variations in pronunciation among
English-speaking countries, not to mention English renditions of
non-English names, for pronunciations to be included. American
English pronunciations are included for some countries such as Qatar
and Kiribati.
Why is the name of the Labour party misspelled?
When American and British spellings of common English words differ,
The World Factbook always uses the American spelling, even when
these common words form part of a proper name in British English.
Policies and Procedures ::
What is The World Factbook''s source for a specific subject field?
The Factbook staff uses many different sources to publish what we
judge are the most reliable and consistent data for any particular
category. Space considerations preclude a listing of these various
sources.
The names of some geographic features provided in the Factbook
differ from those used in other publications. For example, in Asia
the Factbook has Burma as the country name, but in other
publications Myanmar is used; also, the Factbook uses Sea of Japan
whereas other publications label it East Sea. What is your policy on
naming geographic features?
The Factbook staff follows the guidance of the United States Board
on Geographic Names (BGN). The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic names -
domestic, foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to have access to
uniform names of geographic features. The position of the BGN is
that the names Burma and Sea of Japan be used in official US
Government maps and publications.
Why is most of the statistical information in the Factbook given in
metric units, rather than the units standard to US measure?
US Federal agencies are required by the Metric Conversion Act of
1975 (Public Law 94-168) and by Executive Order 12770 of July 1991
to use the International System of Units, commonly referred to as
the metric system or SI. In addition, the metric system is used by
over 95 percent of the world''s population.
Why don''t you include information on minimum and maximum temperature
extremes?
The Factbook staff judges that this information would only be useful
for some (generally smaller) countries. Larger countries can have
large temperature extremes that do not represent the landmass as a
whole.
What information sources are used for the country flags?
Flag designs used in The World Factbook are based on various
national and vexillological sources.
Why do your GDP (Gross Domestic Product) statistics differ from
other sources?
We have two sets of GDP dollar estimates in The World Factbook , one
derived from purchasing power parity (PPP) calculations and the
other derived from official exchange rates (OER). Other sources
probably use one of the two. See the Definitions and Notes section
on GDP and GDP methodology for more information.
On the CIA Web site, Chiefs of State is updated weekly, but the last
update for the Factbook was an earlier date. Why the discrepancy?
Although Chiefs of State and The World Factbook both appear on the
CIA Web site, they are produced and updated on different weekly
schedules. Chiefs of State includes fewer countries but more
leaders, whereas The World Factbook has a much larger database and
includes all countries.
Some percentage distributions do not add to 100. Why not?
Because of rounding, percentage distributions do not always add
precisely to 100%. Rounding of numbers always results in a loss of
precision - i.e., error. This error becomes apparent when percentage
data are totaled, as the following two examples show:
Original Data Rounded to whole integer
Example 1 43.2 43
30.4 30
26.4 26
---- --
100.0 99
Example 2 42.8 43
31.6 32
25.6 26
---- --
100.0 101
When this occurs, we do not force the numbers to add exactly to 100,
because doing so would introduce additional error into the
distribution.
What rounding convention does The World Factbook use?
In deciding on the number of digits to present, the Factbook staff
assesses the accuracy of the original data and the needs of US
Government officials. All of the economic data are processed by
computer - either at the source or by the Factbook staff. The
economic data presented in The Factbook, therefore, follow the
rounding convention used by virtually all numerical software
applications, namely, any digit followed by a "5" is rounded up to
the next higher digit, no matter whether the original digit is even
or odd. Thus, for example, when rounded to the nearest integer, 2.5
becomes 3, rather than 2, as occurred in some pre-computer rounding
systems.
Why do you list "Independence" dates for countries such as France,
Germany, and the United Kingdom?
For most countries, this entry presents the date that sovereignty
was achieved and from which nation, empire, or trusteeship. For
other countries, the date may be some other significant nationhood
event such as the traditional founding date or the date of
unification, federation, confederation, establishment, or state
succession and so may not strictly be an "Independence" date.
Dependent entities have the nature of their dependency status noted
in this same entry.
Technical ::
Does The World Factbook comply with Section 508 of the
Rehabilitation Act regarding accessibility of Web pages?
The World Factbook home page has a link entitled "Text/Low Bandwidth
Version." The country data in the text version is fully accessible.
We believe The World Factbook is compliant with the Section 508 law.
If you are experiencing difficulty, please use our comment form to
provide us details of the specific problem you are experiencing and
the assistive software and/or hardware you are using so that we can
work with our technical support staff to find and implement a
solution. We welcome visitors'' suggestions to improve accessibility
of The World Factbook and the CIA Web site.
I am using the Factbook online and it is not working. What is wrong?
Hundreds of "Factbook" look-alikes exist on the Internet. You can
access The World Factbook at: www.cia.gov, which is the only
official site.
When I attempt to download a PDF (Portable Document Format) map file
(or some other map) the file has no image. Can you fix this?
Some of the files on The World Factbook Web site are large and could
take several minutes to download on a dial-up connection. The screen
might be blank during the download process.
When I open a map on The World Factbook site, it is fuzzy or
granular, or too big or too small. Why?
Adjusting the resolution setting on your monitor should correct this
problem.
Is The World Factbook country data available in machine-readable
format? All I can find is HTML, but I''m looking for simple tabular
data.
The Factbook Web site now features Country Comparison pages for
selected Factbook entries. All of the Country Comparison pages can
be downloaded as tab-delimited data files that can be opened in
other applications such as spreadsheets and databases.
======================================================================
@Afghanistan (South Asia)
Introduction ::Afghanistan','696801382f57d2e0f56ae3624ede9f9474ad61c2c9cee141800c68c9e73ca1de','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

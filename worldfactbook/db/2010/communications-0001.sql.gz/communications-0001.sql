SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308ac5b7a3af2fed0fc14d426985b015c90604d0ed471dd99b95cf384f6e8507',2010,'US','United States','communications',129,'Telephones — main lines in use
Telephones— mobile cellular
Telephone system
general assessment
domestic
international
Radio broadcast stations
Television broadcast stations
Internet country code
Internet hosts
Internet users
Communications— note
Telephones— main lines in use: 163.2
million (2007)
Telephones — mobile cellular: 255
million (2007)
Telephone system: general assessment: a
large, technologically advanced, multipur¬
pose communications system
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and
domestic satellites carries every form of
telephone traffic; a rapidly growing cellular
system carries mobile telephone traffic
throughout the country
international: country code— 1; multiple
ocean cable systems provide international
connectivity; satellite earth stations— 61
Intelsat (45 Adantic Ocean and 1 6 Pacific
Ocean), 5 Intersputnik (Atlantic Ocean
region), and 4 Inmarsat (Pacific and
Atlantic Ocean regions) (2000)
Radio broadcasf stations: AM 4,789, FM
8,961, shortwave 19 (2006)
Radios: 575 million (1997)
Television broadcast stations: 2,218 (2006)
Televisions: 219 million (1997)
Internet country code: us
Internet hosts: 316 million (2008);
note— the US Internet total host count
includes the following top level domain
host addresses: .us, .com, .edu, .gov, .mil,
.net, and .org
Internet Service Providers (ISPs): 7,000
(2002 est.)
Internet users: 223 million (2008)','01ed7d5b8c8f6329f2f7a7efa76f344bb5600e59a2914bee2c862c0638c26e3c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48f48c5d1bbb420b3fb8ba6088a4a1bf6be0601acbb77ec962d373a6ba07ce4c',2010,'AF','Afghanistan','communications',139,'Telephones— main lines in use:
280,000 (2005)
Telephones— mobile cellular:
5.4 million (2008)
Telephone system: general assessment:
limited landline telephone service; an
increasing number of Afghans utilize
mobile-cellular phone networks in major
cities domestic: aided by the presence of
multiple providers, mobile-cellular tele¬
phone service is improving rapidly
international: country code— 93; five VSAT’s
installed in Kabul, Herat, Mazar-e-Sharif,
Kandahar, and Jalalabad provide inter¬
national and domestic voice and data
connectivity (2007)
Radio broadcast stations: AM 21, FM
5, shortwave 1 (broadcasts in Pashto, Dari
(Afghan Persian), Urdu, and English)
(2006)
Radios: 167,000 (1999)
Television broadcast stations: at least 7
(1 government-run central television station
in Kabul and regional stations in 6 of the
34 provinces) (2006)
Televisions: 100,000 (1999)
Internet country code: af
Internet hosts: 31 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 580,000 (2007)
Communications — note: Internet access
is growing through Internet cafes as well as
public “telekiosks” in Kabul (2005)
Radio broadcast stations: AM NA, FM 1 ,
shortwave NA (British Forces Broadcasting
Service (BFBS) provides Radio 1 and
Radio 2 service to Akrotiri, Dhekelia, and
Nicosia) (2006)
Television broadcast stations: 0 (British
Forces Broadcasting Service (BFBS)
provides multi-channel satellite service to
Akrotiri, Dhekelia, and Nicosia) (2006)','78b52c9b1354db2f906957a7bfbf6f2b796ed38025304d787060fccf414ba515','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d92eb0d9558531a31462600cd83a1169149f95c26ae9c64735795b48b7c2adc3',2010,'AL','Albania','communications',149,'_
Telephones — main lines in use:
353,600 (2005)
Telephones — mobile cellular:
2.3 million (2007)
Telephone system: general assessment:
despite new investment in fixed lines, the
density of main lines remains low with
roughly 10 lines per 100 people; cellular
telephone use is widespread and generally
effective; combined fixed line and mobile
telephone density is approximately 75
telephones per 100 persons
domestic: offsetting the shortage of fixed
line capacity, mobile phone service has
been available since 1996; by 2003,
two companies were providing mobile
services at a greater density than some of
Albania’s neighbors; Internet broadband
services initiated in 2005; Internet cafes
are popular in Tirana and have started to
spread outside the capital
international: country code— 355; subma¬
rine cable provides connectivity to Italy,
Croatia, and Greece; the Trans-Balkan
Line, a combination submarine cable and
land fiber-optic system, provides additional
connectivity to Bulgaria, Macedonia, and
Turkey; international traffic carried by
fiber-optic cable and, when necessary, by
microwave radio relay from the Tirana
exchange to Italy and Greece (2007)
Radio broadcast stations:
AM 13, FM 46, shortwave 1 (2005)
Radios: 1 million (2001)
Television broadcast stations:
65 (3 national, 62 local); 2 cable networks
(2005)
Televisions: 700,000 (2001)
Internet country code: al
Internet hosts: 10,162 (2008)
Internet Service Providers (ISPs):
10 (2001)
Internet users:
471,200 (2006)','469b591756984ce556eceec5f2bec096dffc085520f31a063c47c35f1005e764','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b508fb0e8d2e823df51811d8bb7b0b91a03e03750277ac1d32a90bb867b30ebc',2010,'DZ','Algeria','communications',161,'Telephones — main lines in use:
3.068 million (2007)
Telephones— mobile cellular:
27.563 million (2007)
Telephone system: general assessment: a
weak network of fixed-main lines, which
remains low at less than 1 0 telephones per
100 persons, is partially offset by the rapid
increase in mobile cellular subscribership;
in 2007, combined fixed-line and
mobile telephone density surpassed 90
telephones per 100 persons
domestic: privatization of Algeria’s tele¬
communications sector begari in 2000;
three mobile cellular licenses have been
issued and, in 2005, a consortium led
by Egypt’s Orascom Telecom won a
15-year license to build and operate a
fixed-line network in Algeria; the license
will allow Orascom to develop high¬
speed data and other specialized services
and contribute to meeting the laYge
unfulfilled demand for basic residential
telephony; Internet broadband services
began in 2003 with approximately
200,000 subscribers in 2006
international: country code— 213; landing
point for the SEA-MEWE-4 fiber-optic
submarine cable system that provides
links to Europe, the Middle East, and
Asia; microwave radio relay to Italy,
France, Spain, Morocco, and Tunisia;
coaxial cable to Morocco and Tunisia;
participant in Medarabtel; satellite earth
stations— 51 (Intelsat, Intersputnik, and
Arabsat) (2007)
Radio broadcast stations:
AM 25, FM 1, shortwave 8 (1999)
Radios: 7.1 million (1997)
Television broadcast stations:
46 (plus 216 repeaters) (1995)
Televisions: 3.1 million (1997)
Internet country code: dz
Internet hosts: 477 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users: 3.5 million (2007)','e5984647752d3f5d1fed3021becdac59701ee4134e674f8506a13b983660e67e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69c74b05827264a501cc431ec8fd30cb234c0f754fd09ae027e3fe2dc66d64cd',2010,'AD','Andorra','communications',167,'Telephones — main lines in use:
10,400 (2004)
Telephones— mobile cellular:
2,200 (2004)
Telephone system: general assessment: NA
domestic: good telex, telegraph, facsimile,
and cellular telephone services; domestic
satellite system with 1 Comsat earth station
international: country code— 1-684; satellite
earth station— 1 (Intelsat-Pacific Ocean)
Radio broadcast stations: AM 2, FM 3,
shortwave 0 (2005)
Radios: 57,000 (1997)
Television broadcast stations: 1 (2006)
Televisions: 14,000 (1997)
Internet country code: as
Internet hosts: 1,923 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: NA','ddf8728985cc1440b374af86e437843c1c16d1068f67c1af542b601706a2101a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83397a9d70f6c95860422a0608f20f2ab147c386319754b5387b6459081661d8',2010,'AO','Angola','communications',176,'Telephones — main lines in use:
37,200 (2007)
Telephones — mobile cellular:
68,500 (2007)
Telephone system: general assessment: NA
domestic: modern system with microwave
radio relay connections between exchanges
international: country code— 376; landline
circuits to France and Spain
Radio broadcast stations: AM 0, FM 1,
shortwave 0 (easy access to radio and televi¬
sion broadcasts originating in France and
Spain) (2007)
people displaced— in the quarter century of
fighting. SAVIMBI’s death in 2002 ended
UNITA’s insurgency and strengthened the
MPLA’s hold on power. President DOS
SANTOS held legislative elections in
September 2008, and announced plans to
hold presidential elections in 2009.
Telephones — main lines in use:
98,200 (2006)
Telephones — mobile cellular:
3.307 million (2007)
Telephone system: general assessment:
system inadequate; fewer than one fixed-line
per 100 persons; combined fixed line and
mobile telephone density exceeded 25 tele¬
phones per 100 persons in 2007
domestic: state-owned telecom had monopoly
for fixed-lines until 2005; demand
outstripped capacity, prices were high, and
services poor; Telecom Namibia, through
an Angolan company, became the first
private licensed operator in Angola’s fixed-
line telephone network; Angola Telecom
established mobile-cellular service in
Luanda in 1993 and the network has been
extended to larger towns; a privately-owned,
t> f !>?•
6 5 ?9 r-v:
1 M . ;
OC&fiM
Hill . Blii 1
dm
IS j^THE VALLEY
, l''- >>
Bowing Point
'' -J
mobile-cellular service provider began
operations in 2001
international: country code— 244; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connectivity
to Europe and Asia; satellite earth stations—
29 (2007)
Radio broadcasf sfations: AM 21, FM 6,
shortwave 7 (2001)
Radios: 815,000 (2000)
Television broadcast stations: 6 (2000)
Televisions: 196,000 (2000)
Internet country code: ao
Internet hosts: 3,562 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 100,000 (2007)
Telephones — main lines in use: 9,700
(2006)
Telephones— mobile cellular: 6.592
million (2007)
Telephone system: general assessment: inad¬
equate; state-owned fixed-line operator has
been unable to expand fixed-line connec¬
tions and there are now fewer than 10,000
connections— less than 1 per 1000 persons;
given the backdrop of a wholly inadequate
fixed-line infrastructure, the use of cellular
services has surged and subscribership in
2007 reached 6.6 million— 1 0 per 1 00 persons
domestic: barely adequate wire and microwave
radio relay service in and between urban
areas; domestic satellite system with 14 earth
stations
international : country code— 243; satellite
earth station— 1 Intelsat (Adantic Ocean)
(2007)
Radio broadcast stations: AM 3, FM 11,
shortwave 2 (2001)
Radios: 18.03 million (1997)
Television broadcast stations: 4 (2001)
Televisions: 6.478 million (1997)
Internet country code: cd
Internet hosts: 3,211 (2008)
Internet Service Providers (ISPs): l (2001)
Internet users: 230,400 (2007)','e54d61769d627df893d15a987b9423ec32c3493bac12929e952f43ae3bf42bea','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aefcabd33becb16cbf2334fd87fd6e8e7bf66de35e0eb87eb4bd505ac85fe61a',2010,'AI','Anguilla','communications',189,'Telephones— mainlinesinusefo, 200(2002)
Telephones — mobile cellular:
1,800 (2002)
Telephone system: general assessment: NA
domestic: modern internal telephone system
international: country code— 1-264; landing
point for the East Caribbean Fiber System
(ECFS) submarine cable with links to 13
other islands in the eastern Caribbean
extending from the British Virgin Islands
to Trinidad; microwave radio relay to
island of Saint Martin (Guadeloupe and
Netherlands Antilles) (2007)
Radio broadcast stations: AM 2, FM 7,
shortwave 0 (2004)
Radios: 3,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 1,000 (1997)
Internet country code: ai
Internet hosts: 205 (2008)
InternetServiceProviders(ISPs): 1 6(2000)
Internet users: 3,000 (2002)','4525560a2e16e395c64a9f4fbeb73a8e8546b9b43548f51626cce7d3b0250bd6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af5791f74d34eaf6df78fb5d521b204711505b717d8d1ac57b4791dd9c7405e3',2010,'AR','Argentina','communications',197,'Telephones— main lines in use: 0; note-
information for US bases only (2001)
Telephone system: general assessment: local
systems at some research stations
domestic: commercial cellular networks
operating in a small number of locations
international: country code— none allocated;
via satellite (including mobile Inmarsat and
Iridium systems) to and from all research
stations, ships, aircraft, and most field
parties (2007)
Radio broadcast stations: FM 2,
shortwave 1 (information for US bases
only); note— many research stations have a
local FM radio station (2007)
Radios: NA
Television broadcast stations: l (cable
system with 6 channels; American Forces
Antarctic Network-McMurdo— information
for US bases only) (2002)
Televisions: several hundred at McMurdo
Station (US)
note: information for US bases only
(2001)
Internet country code: aq
Internet hosts: 7,748 (2008)
Internet Service Providers (ISPs): NA
Telephones— main lines in use:
9.5 million (2007)
Telephones — mobile cellular:
40.402 million (2007)
Telephone system: general assessment: by
opening the telecommunications market to
competition and foreign investment with
the “Telecommunications Liberalization
Plan of 1998,” Argentina encouraged the
growth of modern telecommunications
technology; fiber-optic cable trunk lines
are being installed between all major
cities; major networks are entirely digital
and the availability of telephone service
is improving; fixed-line telephone density
is gradually increasing reaching nearly 25
lines per 100 people in 2007; mobile tele¬
phone subscribership has been increasing
rapidly and has reached a level of 100
telephones per 100 persons
domestic: microwave radio relay, fiber-optic
cable, and a domestic satellite system with
40 earth stations serve the trunk network;
more than 110,000 pay telephones are
installed and mobile telephone use is
rapidly expanding; broadband serv¬
ices are gaining ground
international: country code— 54; landing
point for the Adantis-2, UN1SUR, and
South America-1 optical submarine cable
systems that provide links to Europe,
Africa, South and Central America, and
US; satellite earth stations— 1 1 2; 2 interna¬
tional gateways near Buenos Aires (2007)
31
THE CIA WORLD FACT BOOK
Radio broadcast stations: AM 260, FM
(probably more than 1,000, mostly unli¬
censed), shortwave 6 (1998)
Radios: 24.3 million (1997)
Television broadcast stations:
42 (plus 444 repeaters) (1997)
Televisions: 7.95 million (1997)
Internet country code: ar
Internet hosts: 3.813 million (2008)
lnternetServiceProviders(ISPs):33(2000)
Internet users: 9.309 million (2007)','d920eae277dab1ea31c4bf3139b2f570af2e8b4c2d46229b5451fa5911ccf0ae','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d6531d25583e64a1838864289c3ab95e334c33e36373c265ee35867a6da68c9',2010,'AG','Antigua and Barbuda','communications',206,'Telephones— main lines in use:
37,500 (2006)
Telephones— mobile cellular:
110,200 (2006)
Telephone system: general assessment: NA
domestic: good automatic telephone system
international: country code— 1-268; landing
point for the East Caribbean Fiber System
(ECFS) submarine cable with links to 13
other islands in the eastern Caribbean
extending from the British Virgin Islands
to Trinidad; satellite earth stations— 2;
tropospheric scatter to Saba (Netherlands
Antilles) and Guadeloupe (2007)
Radio broadcasf stations: AM 4, FM 2,
shortwave 0 (1998)
Radios: 36,000 (1997)
Television broadcasf sfations: 2 (1997)
Televisions: 31,000 (1997)
Internef country code: ag
Internet hosts: 2,215 (2008)
Internet Service Providers (ISPs):
16 (2000)
Internet users: 60,000 (2007)','9ecdb4ecea6df836cf78c4809431437ec0c5762ba72a5af06def8e85170845d6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28dcedd6a6879c8280a249c70468a07136cc59a1e915a940078b0368006cbed1',2010,'AM','Armenia','communications',216,'Telephones— main lines in use:
603,900 (2006)
Telephones— mobile cellular:
1,185,400 (2006)
Telephone system: general assessment:
telecommunications investments have
made major inroads in modernizing and
upgrading the outdated telecommunica¬
tions network inherited from the Soviet
era; now 1 00% privately owned and
undergoing modernization and expansion;
mobile-cellular services monopoly termi¬
nated in late 2004 and a second provider
began operations in mid-2005
domestic: reliable modern landline and
mobile-cellular services are available across
Yerevan in major cities and towns; significant
but ever-shrinking gaps remain in mobile-
cellular coverage in rural areas
international: country code— 374; Yerevan is
connected to the Trans-Asia-Europe fiber¬
optic cable through Iran; additional inter¬
national service is available by microwave
radio relay and landline connections to the
other countries of the Commonwealth of
Independent States, through the Moscow
international switch, and by satellite to the
rest of the world; satellite earth stations— 3
(2007)
Radio broadcast stations: AM 9, FM 16,
shortwave 1 (2006)
Radios: 850,000 (1997)
Television broadcast stations: 48 (private
television stations alongside 2 public
networks; major Russian channels widely
available) (2006)
Televisions: 825,000 (1997)
Internet country code: am
Internet hosts: 26,081 (2008)
Internet Service Providers (ISPs):
9 (2001)
Internet users: 172,800 (2006)','3803d8af7c7328ea1f7e3e9bbeb3134e64462b15c3281f7c425ec802d74af905','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feda111ae57171ddb1fa84193bc3b462431319cc41a2d1b41b2fa519f6211dd0',2010,'NL','Netherlands','communications',225,'Telephones — main lines in use:
38.700 (2006)
Telephones — mobile cellular:
105.700 (2006)
Telephone system: general assessment:
modern fully automatic telecommunica-
tions system
domestic: increased competition through
privatization; 3 wireless service providers
are now licensed
international: country code— 297; landing
site for the PAN-AM submarine telecom¬
munications cable system that extends
from the US Virgin Islands through Aruba
to Venezuela, Colombia, Panama, and the
west coast of South America; extensive
interisland microwave radio relay links
(2007)
Radio broadcast stations: AM 2, FM 16,
shortwave 0 (2004)
Radios:
50,000 (1997)
Television broadcast stations: l (1997)
Televisions: 20,000 (1997)
Internet country code: aw
Internet hosts: 17,661 (2008)
Internet Service Providers (ISPs): NA
Internet users: 24,000 (2007)
NETHERLANDS ANTILLES
Telephones — main lines in use:
7.334 million (2007)
Telephones — mobile cellular:
17.3 million (2006)
Telephone system: general assessment:
highly developed and well maintained
domestic: extensive fixed-line fiber-optic
network; large cellular telephone system
with 5 major operators utilizing the third
generation of the Global System for Mobile
Communications (GSM) technology; one
in five households now use Voice over the
Internet Protocol (VoIP) services
international: country code— 31; submarine
cables provide links to the US and Europe;
satellite earth stations— 5 (3 Intelsat— 1
Indian Ocean and 2 Atlantic Ocean, 1
Eutelsat, and 1 Inmarsat (2007)
Radio broadcast stations: AM 4, FM
567, shortwave 1 (2008)
Radios: 15.3 million (1996)
Television broadcast stations:
342 (2008)
Televisions: 8.1 million (1997)
Internet country code: .nl
Internet hosts: 10.983 million (2008)
Internet Service Providers (ISPs):
52 (2000)
Internet users: 15 million (2007)
Telephones — main lines in use:
81,000 (2001)
Telephones— mobile cellular:
200,000 (2004)
Telephone system: general assessment:
generally adequate facilities
domestic: extensive interisland microwave
radio relay links
international: country code— 599; the
Americas Region Caribbean Ring System
(ARCOS-1) and the Americas-2 subma¬
rine cable systems provide connectivity to
Central America, parts of South America
and the Caribbean, and the US; satellite
earth stations— 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 8, FM 19,
shortwave 0 (2003)
Radios: 217,000 (1997)
Television broadcast stations: 3 (there is
also a cable service that supplies programs
489
THE CIA WORLD FACTBOOK
received from various US satellite networks
and 4 Venezuelan channels) (2003)
Televisions:
69,000 (1997)
Internet country code: an
Internet hosts: 47,597 (2008)
Internet Service Providers (ISPs): 6
Internet users: 2,000 (2000)','3acc189a90362ca573d5c17c5a91e045fc6ac2b30cb99055084578182411d9bc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a90ee264afa5819998d6b214d1613e4c0fb00b0af672f31a493e483e964aa8f8',2010,'AU','Australia','communications',239,'Telephones — main lines in use:
9.76 million (2007)
Telephones — mobile cellular:
21.26 million (2007)
Telephone system: general assessment:
excellent domestic and international service
domestic: domestic satellite system; signifi¬
cant use of radiotelephone in areas of
low population density; rapid growth of
mobile cellular telephones
international: country code— 61; landing
point for the SEA-ME-WE-3 optical tele¬
communications submarine cable with
links to Asia, the Middle East, and Europe;
the Southern Cross fiber optic submarine
cable provides links to New Zealand and
the United States; satellite earth stations—
19 (10 Intelsat— 4 Indian Ocean and 6
Pacific Ocean, 2 Inmarsat— Indian and
Pacific Ocean regions, 2 Globalstar, 5
other) (2007)
Radio broadcast stations: AM 262, FM
345, shortwave 1 (1998)
Radios: 25.5 million (1997)
Television broadcast stations: 104 (1997)
Televisions: 10.15 million (1997)
Internet country code: au
Internet hosts: 11.134 million (2008)
Internet Service Providers (ISPs):
571 (2002)
Internet users: 11.24 million (2007)','6275c0f5cb832ecc3e88207e7f38a31806b9ef25a2c691212fa1de75f323412d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a2596204151591fbc618bbdbe14224ca2390fba8cbf4c3cc40409068d5e6b03',2010,'AT','Austria','communications',245,'Telephones— main lines in use:
3.374 million (2007)
Telephones— mobile cellular:
9.768 million (2007)
Telephone system: general assessment:
highly developed and efficient
domestic: fixed-line subscribership has
been in decline since the mid-1990s with
mobile-cellular subscribership eclipsing it
by the late 1990s; the fiber-optic net is very
extensive; all telephone applications and
Internet services are available
international: country code— 43; satellite
earth stations— 15; in addition, there are
about 600 VSATs (very small aperture
terminals) (2007)
Radio broadcast stations: AM 2, FM 65
(plus several hundred repeaters), shortwave
1 (2001)
Radios: 6.08 million (1997)
Television broadcast stations: 10 (plus
more than 1,000 repeaters) (2001)
Televisions: 4.25 million (1997)
Internet country code: at
Internet hosts: 2.806 million (2008)
Internet Service Providers (ISPs):
37 (2000)
Internet users: 4.277 million (2007)','158e5e3f3f62a2ab694560b9548995bab902703351386904643486cc4c21d0f4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f08eec37876dd3ed46421278ac19fe06db60c64a6b7475e721e6991e5b5f6030',2010,'AZ','Azerbaijan','communications',254,'Telephones — main lines in use:
1.254 million (2007)
Telephones— mobile cellular:
4.3 million (2007)
Telephone system: general assessment: inad¬
equate; requires considerable expansion
and modernization; teledensity of 1 5 main
lines per 100 persons is low; mobile-cellular
penetration is increasing and is currently
about 50 telephones per 1 00 persons
domestic: fixed-line telephony and a
broad range of other telecom services are
controlled by a state-owned telecommuni¬
cations monopoly and growth has been
stagnant; more competition exists in the
mobile-cellular market with three providers
in 2006; satellite service connects Baku to
a modern switch in its exclave of Naxcivan
international: country code— 994; the Trans-
Asia-Europe (TAE) fiber-optic link transits
Azerbaijan providing international connec¬
tivity to neighboring countries; the old
Soviet system of cable and microwave is
still serviceable; satellite earth stations— 2
(2007)
Radio broadcast stations: AM 10, FM
17, shortwave 1 (1998)
Radios: 175,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 170,000 (1997)
Internet country code: .az
Internet hosts: 6,995 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users: 1 .036 million (2007)
Telephones — main lines in use:
132,900 (2007)
Telephones— mobile cellular:
374,000 (2007)
Telephone system: general assessment:
modern facilities
domestic: totally automatic system; highly
developed; the Bahamas Domestic Subma-
rine Network links 14 of the islands and
is designed to satisfy increasing demand
for voice and broadband internet services
international: country code— B242; landing
point for the Americas Region Caribbean
Ring System (ARCOS-1) fiber-optic subma¬
rine cable that provides links to South and
Central America, parts of the Caribbean,
and the US; satellite earth stations— 2
(2007)
Radio broadcast stations: AM 3, FM 5,
shortwave 0 (2006)
Radios: 215,000 (1997)
Television broadcast stations: 2 (2006)
Televisions: 67,000 (1997)
Internet country code: bs
Internet hosts: 41 (2008)
Internet Service Providers (ISPs):
19(2000)
Internet users: 1 20,000 (2007)','b40a403ec30de69d7fe5a84bf43c03d26abb4ba0af4aaad1de31a58856238ebb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6812297a628877aea34bf07c5c0bef902bb4358c93b2c564187a668e3347e9be',2010,'BD','Bangladesh','communications',260,'Telephones — main lines in use:
194,200 (2006)
Telephones— mobile cellular:
1.116 million (2007)
Telephone system:
general assessment: modern system
domestic: modern fiberoptic integrated
services; digital network with rapidly growing
use of mobile-cellular telephones
international: country code— 973; landing
point for the Fiber-Optic Link Around the
Globe (FLAG) submarine cable network that
provides links to Asia, Middle East, Europe,
and US; tropospheric scatter to Qatar
and UAE; microwave radio relay to Saudi
Arabia; satellite earth station— 1 (2007)
Radio broadcast stations: AM 2, FM 3,
shortwave 0 (1 998)
Radios: 338,000 (1997)
Television broadcast stations: 4 (1997)
Televisions: 275,000 (1997)
Internet country code: bh
Internet hosts: 2,621 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 250,000 (2007)
Telephones — main lines in use:
1.187 million (2007)
Telephones — mobile cellular:
34.37 million (2007)
Telephone system: general assessment:
inadequate for a modem country; fixed-
line telephone density remains less than 1
per 1 00 persons; mobile-cellular telephone
subscribership has been increasing rapidly
and is approaching 25 per 100 persons
domestic: modernizing; introducing digital
systems; trunk systems include VHF and
UHF microwave radio relay links, and
some fiber-optic cable in cities
international: country code— 880; landing
point for the SEA-ME-WE-4 fiber-optic
submarine cable system that provides links
to Europe, the Middle East, and Asia;
satellite earth stations— 6; international
radiotelephone communications and
landline service to neighboring countries
(2007)
Radio broadcast stations: AM 15, FM
1 3, shortwave 2 (2006)
Radios: 6.15 million (1997)
Television broadcast stations: 15 (1999)
Televisions: 770,000 (1997)
Internet country code: bd
Internet hosts: 1,440 (2008)
Internet Service Providers (ISPs):
10 (2000)
Internet users: 500,000 (2007)','3ec5f6d2f33bcc14cc09820b4a11303111d27eb5b06357614a8672cdd8fc5a94','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b717b0eb436d8dd42ce116dcb7707eeaea606bf82704883298f5a2720620289',2010,'BB','Barbados','communications',272,'Telephones — main lines in use:
134,900 (2005)
Telephones — mobile cellular:
237,100 (2006)
Telephone system: general assessment:
fixed-line teledensity of roughly 50 per 1 00
persons; mobile-cellular telephone density
of about 85 per 100 persons
domestic: island-wide automatic telephone
system
international: country code— 1-246; landing
point for the East Caribbean Fiber System
(ECFS) submarine cable with links to 13
other islands in the eastern Caribbean
extending from the British Virgin Islands
to Trinidad; satellite earth stations— 1
(Intelsat-Atlantic Ocean); tropospheric
scatter to Trinidad and Saint Lucia
(2007)
Radio broadcasf sfafions: AM 2, FM 6,
shortwave 0 (2004)
Radios: 237,000 (1997)
Television broadcast stations:
1 (plus 2 cable channels) (2004)
Televisions: 76,000 (1997)
Internet country code: bb
Internet hosts: 104 (2008)
Internet Service Providers (ISPs):
19(2000)
Internet users: 160,000 (2005)','80a1d83d17c8c9eff1f478421887e36f78fbbd6030f99c26960c39c8522f53f2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ee8d7231e977d4511f20a01e05463b724113c75128ee138fb4338cefa803a69',2010,'BY','Belarus','communications',280,'Telephones — main lines in use:
3.672 million (2007)
Telephones— mobile cellular:
6.96 million (2007)
66','38aaec92cdcd1eacf9f66302d7f9cba57d2ae99957e79c6598e7557211c48bf4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf7be3fe8f4e7911307ff8578f3a320853859f7a4775ed698414e9560189415c',2010,'BE','Belgium','communications',281,'Telephone system: general assessment:
Belarus lags behind its neighbors in
upgrading telecommunications infra¬
structure; state-owned Beltelcom is the
sole provider of fixed-line local and long
distance service; fixed-line teledensity
of roughly 35 per 100 persons; mobile-
cellular telephone density of about 70 per
100 persons; modernization of the network
progressing with roughly two-thirds of
switching equipment now digital
domestic: fixed-line penetration is improving
although rural areas continue to be
underserved; 3 GSM wireless networks
are experiencing rapid growth; strict
government controls on telecommunications
technologies
international: country code— 375; Belarus is a
member of the Trans-European Line (TEL),
T rans-Asia-Europe (TAE) fiber-optic line, and
has access to the Trans-Siberia Line (TSL); 3
fiber-optic segments provide connectivity to
Latvia, Poland, Russia, and Ukraine; world¬
wide service is available to Belarus through
this infrastructure; additional analog lines to
Russia; Intelsat, Eutelsat, and Intersputnik
earth stations (2007)
Radio broadcast stations:
AM 28, FM 37, shortwave 11 (1998)
Radios: 3.02 million (1997)
Television broadcast stations:
47 (plus 27 repeaters) (1995)
Televisions: 2.52 million (1997)
Internet country code: by
internet hosts: 68,118 (2008)
Internet Service Providers (ISPs):
23 (2002)
Internet users: 6 million (2007)','b7fb07c3831a6e63b208f5b317155c5d4f87ee81270a24dd5bc78d3d137d9b2a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a79a80c8c44c0019dcb604bf630b9cd9e16d5882ef336c72ccadc661a01a0b40',2010,'FR','France','communications',289,'Telephones— main lines in use:
4.668 million (2007)
Telephones— mobile cellular:
10.23 million (2007)
TelephonesyStem:generalassessment:highly
developed, technologically advanced, and
completely automated domestic and inter¬
national telephone and telegraph facilities
domestic: nationwide cellular telephone
system; extensive cable network; limited
microwave radio relay network
international: country code— 32; landing
point for a number of submarine cables
that provide links to Europe, the Middle
East, and Asia; satellite earth stations— 7
(Intelsat— 3) (2007)
Radio broadcast stations: AM 7, FM 79,
shortwave 1 (1998)
Radios: 8.075 million (1997)
Television broadcast stations:
25 (plus 10 repeaters) (1997)
Televisions: 4.72 million (1997)
Internet country code: be
Internet hosts: 3.841 million (2008)
Internet Service Providers (ISPs):
61 (2000)
Internet users:
5.22 million (2007)
Telephones — main lines in use: 35.533
million; 34.8 million (metropolitan France)
(2007)
Telephones — mobile cellular: 56.719
million; 55.358 million (metropolitan
France) (2007)
Telephone system: general assessment:
highly developed
domestic: extensive cable and microwave
radio relay; extensive introduction of
fiber-optic cable; domestic satellite system
international: country code— 33; numerous
submarine cables provide links throughout
Europe, Asia, Australia, the Middle East,
and US; satellite earth stations— more than
3 (2 Intelsat (with total of 5 antennas— 2 for
Indian Ocean and 3 for Atlantic Ocean),
NA Eutelsat, 1 Inmarsat— Adantic Ocean
region); HF radiotelephone communi¬
cations with more than 20 countries
overseas departments: country codes: French
Guiana— 594; Guadeloupe— 590; Marti¬
nique— 596; Reunion— 262
Radio broadcast stations: AM 41, FM
about 3,500 (this figure is an approxima¬
tion and includes many repeaters), short¬
wave 2 (1998)
Radios: 55.3 million (1997)
Television broadcast stations: 584 (plus
9,676 repeaters) (1995)
Televisions: 34.8 million (1997)
Internet country code: metropolitan
France— .fr; French Guiana— .gf; Guade¬
loupe— .gp; Martinique— .mq; Reunion— .re
Internet hosts: 14.256 million; 14,256,000
(metropolitan France) (2008)
Internet Service Providers (ISPs): 62
(2000)
Internet users: 31.295 million; 30.838
million (metropolitan France) (2007)
Telephones— main lines in use: 1,900
(2002)
Telephones — mobile cellular: NA
Telephone system: general assessment: NA
domestic: NA
international: country code— 681
Radio broadcast stations: AM l , FM 0,
shortwave 0 (2000)
Radios: NA
Television broadcast stations: 2 (2000)
Televisions: NA
Internet country code: wf
Internet hosts: 1 (2008)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 900 (2002)
Telephones — main lines in use: 350,400
(includes Gaza Strip) (2007)
Telephones — mobile cellular: 1.026
million (includes Gaza Strip) (2007)
Telephone system: general assessment: NA
domestic: Israeli company BEZEK and the
Palestinian company PALTEL are respon¬
sible for fixed line services; the Palestinian
JAWAL company provides cellular services
international: country code— 970 (2004)
Radio broadcast stations: AM 0, FM 25,
shortwave 0 (2008)
Radios: NA; note— most Palestinian house¬
holds have radios (1999)
Television broadcast stations: 30 (2008)
Televisions: NA; note— many Palestinian
households have televisions (1999)
Internet country code: .ps; note— same as
Gaza Strip
Internet Service Providers (ISPs): 8
(1999)
Internet users: 355,500 (includes Gaza
Strip) (2007)','8d0cab438d9d74c987b5ce866a9a68868ff7e4bb28ed46cde3770a5d220a1bf8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5758f07548a4d221a650440dbd18e2b54a09b4cdecba0de5e7346fa3e15d67a7',2010,'BZ','Belize','communications',299,'Telephones — main lines in use:
33,900 (2007)
Telephones — mobile cellular:
118,300 (2007)
Telephone system: general assessment:
above-average system; fixed-line teledensity
of 1 2 per 1 00 persons; mobile-cellular tele¬
phone density of about 40 per 100 persons
domestic: trunk network depends primarily
on microwave radio relay
international: country code— 501 ; landing
point for the Americas Region Caribbean
Ring System (ARCOS-1 ) fiber-optic telecom¬
munications submarine cable that provides
links to South and Central America, parts
of the Caribbean, and the US; satellite earth
station— 8 (Intelsat— 2, unknown— 6) (2007)
Radio broadcasf sfations: AM 1, FM 16,
shortwave 0 (2006)
Radios: 133,000 (1997)
Television broadcasf stations: 5 (2006)
Televisions: 41,000 (1997)
Internet country code: bz
Internet hosts: 2,751 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 32,000 (2007)','8dcd11ea2025772112022e657a1161e2dfef83d4d2d71074b63024807b913130','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57607c4fdf7ab0a98afcec09ecadfa3ee9264e271478340cddc853df4685a4b2',2010,'BJ','Benin','communications',306,'Telephones — main lines in use:
110,300 (2007)
Telephones — mobile cellular:
1.895 million (2007)
Telephone system: general assess¬
ment: inadequate; fixed-line network
characterized by aging, deteriorating
equipment with fixed-line teledensity
stuck at 1 per 1 00 persons; mobile-cellular
telephone subscribership is increasing
domestic: system of open-wire, microwave
radio relay, and cellular connections;
multiple mobile-cellular providers
international: country code— 229; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connectivity
to Europe and Asia; satellite earth stations—
7 (Intelsat-Adantic Ocean) (2007)
Radio broadcast stations: AM l , FM 34,
shortwave 1 (2007)
Radios: 660,000 (2000)
Television broadcast stations: 6 (2007)
Televisions: 66,000 (2000)
Internet country code: bj
Internet hosts: 848 (2008)
Internet Service Providers (ISPs):
4 (2002)
Internet users: 150,000 (2007)','edbcf3ca78f9dfc5d3f33cd4ee70eb0c5b1548d4d5dae1331f0a37291828ea91','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b1d81c0619a5434292276c6097993d3b1e896aa3ee9b934ac5ffa16b936d1f',2010,'BT','Bhutan','communications',315,'Telephones — main lines in use:
57,700 (2006)
Telephones — mobile cellular:
60,100 (2006)
Telephone system: general assessment: good
domestic: fully automatic digital telephone
system; fiber optic trunk lines
international: country code— 1-441; landing
point for the Adantica-1 telecommunications
submarine cable that extends from the US
to Brazil; satellite earth stations— 3 (2007)
Radio broadcast stations: AM 5, FM 3,
shortwave 0 (2005)
Radios: 82,000 (1997)
Television broadcast stations: 3 (2005)
Televisions: 66,000 (1997)
Internet country code: .bm
Internet hosts: 1,628 (2008)
Internet Service Providers (ISPs):
20 (2000)
Internet users: 48,000 (2007)
Telephones— main lines in use:
29,900 (2007)
Telephones — mobile cellular:
149,400 (2007)
Telephone system: general assessment:
urban towns and district headquarters
have telecommunications services
domestic: very low teledensity; domestic
service is very poor especially in rural
areas; wireless service available since 2003
international: country code— 975; inter¬
national telephone and telegraph service
via landline and microwave relay through
India; satellite earth station— 1 Intelsat
(2007)
Radio broadcast stations: AM 0, FM 9,
shortwave 1 (2007)
Radios: 37,000 (1997)
Television broadcast stations: 1 (2007)
Televisions: 11,000 (1997)
Internet country code: bt
Internet hosts: 9,046 (2008)
Internet Service Providers (ISPs): NA
Internet users: 40,000 (2007)
Telephones— main lines in use:
678,200 (2007)
Telephones— mobile cellular:
3.254 million (2007)
Telephone system: general assessment:
privatization begun in 1995; reliability has
steadily improved; new subscribers face
bureaucratic difficulties; most telephones
are concentrated in La Paz and other cities;
mobile-cellular telephone use expanding
rapidly; fixed-line teledensity of 7 per
100 persons; mobile-cellular telephone
density of 35 per 100 persons
domestic: primary trunk system, which is
being expanded, employs digital micro-
wave radio relay; some areas are served
by fiberoptic cable; mobile cellular
systems are being expanded
international: country code— 591; satellite
earth station— 1 Intelsat (Atlantic Ocean)
(2007)
Radio broadcast stations: AM 171, FM
73, shortwave 77 (1999)
Radios: 5.25 million (1997)
Television broadcast stations:
48 (1997)
Televisions: 900,000 (1997)
Internet country code: bo
Internet hosts: 68,428 (2008)
Internet Service Providers (ISPs): 9 (2000)
Internet users: 1 million (2007)','90db3be29be8edf2d6dde947c483199c250af853703344690228a1d9e08e8f99','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21025f0bd1ee7ffce93b567b38e43c04e894bbc0ac089c733a22d8703b8320de',2010,'BA','Bosnia and Herzegovina','communications',327,'Telephones — main lines in use: 1.065
million (2007)
Telephones — mobile cellular: 2.45
million (2007)
Telephone system: general assessment: post¬
war reconstruction of the telecommunica¬
tions network, aided by a internationally
sponsored program under ERBD, resulted
in sharp increases in the number of main
telephone lines available; mobile cellular
subscribership has been increasing rapidly
domestic: fixed-line teledensity roughly
25 per 100 persons; mobile-cellular tele¬
phone density exceeds 50 per 1 00 persons
international: country code— 387; no satel¬
lite earth stations (2007)
Radio broadcast stations: AM 8, FM 16,
shortwave 1 (1998)
Radios: 940,000 (1997)
Television broadcast stations: 33 (plus
277 repeaters) (September 1995)
Televisions: NA
Internet country code: ba
Internet hosts: 56,032 (2008)
Internet Service Providers (ISPs): 3 (2000)
Internet users:
1.055 million (2007)','81c2c3f25557d16393016ef51921e86f34a1e9a20978c478e3fb0ecd69a6dc9e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f8b1a7f6e0aef221225e965002945b843a90203527d60fe9dcbe7e89f5212c1',2010,'BW','Botswana','communications',335,'Telephones— main lines in use: 136,900
(2006)
Telephones— mobile cellular: 1.427
million (2007)
Telephone system: general assessment: the
system is expanding with the growth of
mobile-cellular service and participation in
regional development; system is fully digital
with fiber-optic cables linking the major
population centers in die east; fixed-line
connections declined in recent years and
now stand at roughly 8 per 100 persons;
mobile-cellular telephone density currently
is about 80 per 1 00 persons
domestic: small system of open-wire lines,
microwave radio relay links, and a few radio¬
telephone communication stations; mobile-
cellular service is growing fast
international: country code— 267; interna¬
tional calls are made via satellite, using
international direct dialing; 2 international
exchanges; digital microwave radio relay
links to Namibia, Zambia, Zimbabwe,
and South Africa; satellite earth station— 1
Intelsat (Indian Ocean) (2007)
Radio broadcast stations: AM 8, FM 13,
shortwave 4 (2001)
Radios: 252,720 (2000)
Television broadcast stations: 2 (1 state-
owned, 1 private)
Televisions: 31,000 (1997)
Internet country code: bw
Internet hosts: 6,374 (2008)
Internet Service Providers (ISPs): 11
(2001)
Internet users: 80,000 (2007)','2e8c76d32ffcfe4d0e67514ff8f0e66c52ad266a11701b674643d73068825ee0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('224d051963f5c0fec36de9197748120030ac23337a392194b494e6336d17b7a3',2010,'BV','Bouvet Island','communications',341,'Internet country code: bv
Internet hosts: 6 (2008)
Communications — note: automatic mete¬
orological station','6fe736d1c300a3b9ef0b0aa01e46fdc2a7d07251d30621d3cad54676b878ef04','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6fd1fd576b1c38ca2e24d707bc723f127737c2578f23735bfe5af882941372f',2010,'BR','Brazil','communications',347,'Telephones— main lines in use: 39.4
million (2007)
Telephones — mobile cellular: 120.98
million (2007)
Telephone system: general assessment: good
working system; fixed-line connections have
remained relatively stable in recent years and
stand at about 20 per 1 00 persons; less expen¬
sive mobile cellular technology is a major
driver in expanding telephone service to the
lowdncome segment of the population with
mobile-cellular telephone density reaching
nearly 65 per 100 persons
domestic: extensive microwave radio relay
system and a domestic satellite system with 64
earth stations; mobile-cellular usage has more
than tripled in the past 5 years
international: country code— 55; landing point
for a number of submarine cables, including
Atlantis 2, that provide direct links to South
and Central America, the Caribbean, the US,
Africa, and Europe; satellite earth stations— 3
Intelsat (Adantic Ocean), 1 Inmarsat (Adantic
Ocean region east), connected by microwave
relay system to Mercosur Brazilsat B3 satellite
earth station (2007)
Radio broadcast sfafions: AM 1,365, FM
296, shortwave 161 (of which 91 are collo¬
cated with AM stations) (1999)
Radios: 71 million (1997)
Television broadcast stations:
138 (1997)
Televisions: 36.5 million (1997)
Internet country code: br
Internet hosts: 9.573 million (2008)
Internet Service Providers (ISPs): 50
(2000)
Internet users: 50 million (2007)','b1b4c6da203e4ea72336fe36f09bbb2e69e7b41086b897655325155374fe1a79','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('747b13cc4025b4fdd9528f722890da560ab9feb4b98558047c15e97e75887e46',2010,'IO','British Indian Ocean Territory','communications',356,'Telephones— main lines in use: NA
Telephone system: general assessment:
separate facilities for military and public
needs are available
domestic: all commercial telephone serv¬
ices are available, including connection to
the Internet
international: country code (Diego Garcia)—
246; international telephone service is
carried by satellite (2000)
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (1998)
Radios: NA
Television broadcast stations: 1 (1997)
Televisions: NA
Internet country code: io
Internet hosts: 89 (2008)
Internet Service Providers (ISPs): 1 (2000)
Telephones — main lines in use: 11,700
(2002)
Telephones — mobile cellular: 8,000
(2002)
Telephone system: general assessment:
worldwide telephone service
domestic: NA
international: country code— 1-284;
connected via submarine cable to Bermuda;
the East Caribbean Fiber System (ECFS)
submarine cable provides connectivity to
1 3 other islands in the eastern Caribbean
(2007)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (2004)
Radios: 9,000 (1997)
Television broadcast stations: 1 (plus 1
cable company) (1997)
Televisions: 4,000 (1997)
Internet country code: vg
Internet hosts: 465 (2008)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 4,000 (2002)','995a1a6c1145a13160748a5904848b4225ee70f57263a7996a393facffacfbae','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb1e4d19b9aa51d3e46aed3384f294ee8475f0267609787371393be792f244c9',2010,'BG','Bulgaria','communications',364,'Telephones— main lines in use: 79,200
(2007)
Telephones— mobile cellular: 339,800
(2007)
Telephone system: general assessment:
service throughout the country is excellent;
international service is good to Southeast
Asia, Middle East, Western Europe,
and the US
domestic: every service available
international: country code— 673; landing
point for the SEA-ME-WEC optical tele¬
communications submarine cable that
provides links to Asia, the Middle East,
and Europe; the Asia-America Gateway
submarine cable network, scheduled for
completion by late 2008, will provide new
links to Asia and the US; satellite earth
stations— 2 Intelsat (1 Indian Ocean and 1
Pacific Ocean) (2007)
Radio broadcast stations: AM 1, FM 2
(transmitting on 18 different frequencies),
shortwave 0 (British Forces Broadcasting
Service (BFBS) station transmits two FM
signals with English and Nepali service)
(2006)
Radios: 329,000 (1998)
Television broadcast stations: 4 (includes
2 UHF stations broadcasting a subscription
service) (2006)
Televisions: 201,900 (1998)
Internet country code: bn
Internet hosts: 14,950 (2008)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 199,532 (2007)
Telephones— main lines in use: 2.3
million (2007)
Telephones — mobile cellular: 9.897
million (2007)
Telephone system: general assessment: an
extensive but antiquated telecommunica¬
tions network inherited from the Soviet
era; quality has improved; the Bulgaria
Telecommunications Company’s fixed-
line monopoly terminated in 2005 when
alternative fixed-line operators were given
access to its network; a drop in fixed-line
connections in recent years has been
more than offset by a sharp increase in
mobile-cellular telephone use fostered by
multiple service providers; the number
of cellular telephone subscriptions now
exceeds the population
domestic: a fairly modern digital cable
trunk line now connects switching centers
in most of the regions; the others are
connected by digital microwave radio relay
international: country code— 359; subma¬
rine cable provides connectivity to Ukraine
and Russia; a combination submarine
cable and land fiber-optic system provides
connectivity to Italy, Albania, and Mace¬
donia; satellite earth stations— 3 (1 Inter-
sputnik in the Adantic Ocean region, 2
Intelsat in the Adantic and Indian Ocean
regions) (2007)
Radio broadcasf stations: AM 31, FM
63, shortwave 2 (2001)
Radios: 4.51 million (1997)
Television broadcast stations: 39 (plus
1,242 repeaters) (2001)
Televisions: 3.31 million (1997)
Internet country code: bg
Internet hosts: 513,470 (2008)
Internet Service Providers (ISPs): 200
(2001)
Internet users: 1 .899 million (2007)','07a5fde9379974cee98dfff2fa0ddb41305248bc0e5466c0a0eefd5c50791e90','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcee75147895519ef0f81f57b4387ccfe56ec0bdbdd42a42bf87077faebfb607',2010,'BF','Burkina Faso','communications',377,'Telephones— main lines in use: 94,800
(2006)
Telephones— mobile cellular: 1.611
million (2007)
Telephone system: general assessment:
services only fair; in 2006 the government
sold a 51 percent stake in the national
telephone company and ultimately plans
to retain only a 23 percent stake in the
company; fixed-line connections .stand at
less than 1 per 100 persons; mobile-cellular
usage, fostered by multiple providers, is
increasing rapidly from a low base
domestic: microwave radio relay, open-wire,
and radiotelephone communication stations
109
THE CIA WORLD FACTBOOK
international: country code— 226; satellite earth
station— 1 Intelsat (Atlantic Ocean) (2007)
Radio broadcast stations: AM 2, FM 26,
shortwave 3 (2007)
Radios: 394,020 (2000)
Television broadcast stations: 3 (1 national,
2 private)
Televisions: 131,340 (2002)
Internet country code: bf
Internet hosts: 116 (2008)
Internet Service Providers (ISPs): 1 (2002)
Internet users: 80,000 (2006)
Telephones — main lines in use: 503,900
(2005)
Telephones — mobile cellular: 214,200
(2006)
Telephone system: general assessment:
meets minimum requirements for local
and intercity service for business and','0e183130d9b75501d5dce5e709e274e9fdcfc41bbc7f08ea8eaf00940754b700','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b33c3a1c775e7df080ad1a877c868c4afc54176b604b1936d6d81e81ccd34c65',2010,'BI','Burundi','communications',383,'Telephones — main lines in use: 35,000
(2006)
Telephones — mobile cellular: 250,000
(2007)
Telephone system: general assessment:
primitive system; telephone density one
of the lowest in the world; fixed-line
connections stand at well less than 1
per 100 persons; mobile-cellular usage is
increasing but remains at a meager 3 per
100 persons
domestic: sparse system of open-wire,
radiotelephone communications, and low-
capacity microwave radio relay
international: country code— 257; satellite
earth station— 1 Intelsat (Indian Ocean)
(2007)
Radio broadcast stations: AM 0, FM 4,
shortwave 1 (2001)
Radios:
440,000 (2001)
Television broadcast stations: 1 (2001)
Televisions: 25,000 (1997)
Internet country code: bi
Internet hosts: 162 (2008)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 60,000 (2006)','6c9d173696e8cbc2ec8f02790fe3dc63ee1660d8fbe7016cbee97b26d6a3c5e5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0482b4cdd91b3024060a7d5c75e6527b8e06d3dc53d7c18b19543292610ec33',2010,'KH','Cambodia','communications',391,'Telephones— main lines in use: 37,500
(2007)
Telephones— mobile cellular: 2.583
million (2007)
Telephone system: general assessment:
mobile-phone systems are widely used in
urban areas to bypass deficiencies in the
fixed-line network; fixed-line connections
stand at well less than 1 per 1 00 persons;
mobile-cellular usage, aided by increasing
competition among service providers, is
increasing and stands at nearly 20 per
100 persons domestic: adequate landline
and/or cellular service in Phnom Penh
and other provincial cities; mobile-phone
coverage is rapidly expanding in rural areas
international: country code— 855; adequate
but expensive landline and cellular service
available to all countries from Phnom
Penh and major provincial cities; satel¬
lite earth station— 1 Intersputnik (Indian
Ocean region) (2007)
Radio broadcast stations: AM 1 , FM 50,
shortwave NA (2008)
Radios: 1.34 million (1997)
Television broadcast stations: 8
(including 2 TV relay stations with French
120','dead9634cfd6db4ccb1a3f43f38b74a299cbf3bcfcbfb3712ead8129b8763e6c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef7b6f55c0697c4bd7c0da9d0af8e83b1e7063763399c5e0805cd5e8dd292726',2010,'CM','Cameroon','communications',392,'and Vietnamese broadcasts); excludes 18
regional relay stations (2008)
Televisions: 94,000 (1997)
Internet country code: kh
Internet hosts: 1,230 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users: 70,000 (2007)
Telephones — main lines in use:
130,700 (2006)
Telephones— mobile cellular:
4.536 million (2007)
123
THE CIA WORLD FACTBOOK
Telephone system: general assessment:
fixed-line connections stand at less than
1 per 100 persons; equipment is old and
outdated, and connections with many parts
of the country are unreliable; mobile-cellular
usage, in part a reflection of the poor condi¬
tion and general inadequacy of the fixed-
line network, increased more than 6-fold
between 2002 and 2007 reaching a subscrib-
ership base of 25 per 100 persons
domestic: cable, microwave radio relay,
and tropospheric scatter
international: country code— 237; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connectivity
to Europe and Asia; satellite earth stations—
2 Intelsat (Adantic Ocean) (2007)
Radio broadcast stations: AM 2, FM 9,
shortwave 3 (2001)
Radios: 2.27 million (1997)
Television broadcast stations: 1 (2001)
Televisions: 450,000 (1997)
Internet country code: cm
Internet hosts: 69 (2008)
Internet Service Providers (ISPs):
1 (2002)
Internet users: 370,000 (2006)','202025d92648e0833c406c876b2b168e98ad70d8f986acc73e82d27cdf1c0822','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4614598de335dacc5bbe3c3d2a33b3c07ac8e59552a989751c4693b76e65974',2010,'CA','Canada','communications',404,'Telephones — main lines in use: 21
million (2006)
Telephones — mobile cellular: 18.749
million (2006)
Telephone system: general assessment:
excellent service provided by modern
technology
domestic: domestic satellite system with
about 300 earth stations
international: country code— 1 ; subma¬
rine cables provide links to the US and
Europe; satellite earth stations— 7 (5
Intelsat— 4 Atlantic Ocean and 1 Pacific
Ocean, and 2 Intersputnik— Atlantic Ocean
region) (2007)
Radio broadcast stations: AM 245, FM
582, shortwave 6 (2004)
Radios: 32.3 million (1997)
Television broadcast stations: 148 (2007)
Televisions: 21.5 million (1997)
Internet country code: ca
Internet hosts: 5.119 million (2008)
Internet Service Providers (ISPs): 760
(2000 est.)
Internet users: 28 million (2007)','4d4f6132169518f5580421de81c9fc660b3a118216d74b705f866b32930ddd70','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0cd8e3b603e48d41b7dd7ea338c81c6831ca5a0d088a30cbefef545b1b605c1',2010,'SN','Senegal','communications',412,'Telephones— main lines in use: 71,600
(2006)
Telephones— mobile cellular: 148,000
(2007)
Telephone system: general assessment:
effective system, extensive modernization
from 1996— 2000 following partial privati¬
zation in 1995
domestic: major service provider is Cabo
Verde Telecom (CVT); fiber-optic ring,
completed in 2001, links all islands
providing Internet access and ISDN
services; cellular service introduced in
1 998; broadband services launched in 2004
international: country code— 238; landing
point for die Atlantis-2 fiber-optic trans-
adantic telephone cable diat provides
links to South America, Senegal, and
Europe; HF radiotelephone to Senegal and
Guinea-Bissau; satellite earth station— 1
Intelsat (Atlantic Ocean) (2007)
Radio broadcast stations: AM 0, FM 22
(plus 12 repeaters), shortwave 0 (2001)
Radios: 100,000 (2002 est.)
Television broadcast stations: l (plus 7
repeaters) (2001)
Televisions: 15,000 (2002 est.)
Internet country code: cv
Internet hosts: 20 (2008)
Internet Service Providers (ISPs):
1 (2002)
Internet users: 37,000 (2007)
Telephones— main lines in use:
269,100 (2007)
Telephones— mobile cellular:
4.123 million (2007)
Telephone system: general assessment:
good system
domestic: above-average urban system with a
fiber-optic network; nearly two-thirds of all
fixed-line connections are in Dakar where a
call-center industry is emerging; expansion
of fixed-line services in rural areas needed;
mobile-cellular service is expanding rapidly;
microwave radio relay, coaxial cable and
fiber-optic cable in trunk system
international: country code— 221; the
SAT-3/WASC fiber optic cable provides
connectivity to Europe and Asia while
Atlantis-2 provides connectivity to South
America; satellite earth station— 1 Intelsat
(Adantic Ocean) (2007)
Radio broadcast stations: AM 8, FM 20,
shortwave 1 (2001)
Radios: 1.24 million (1997)
Television broadcast stations: 4 (2007)
Televisions: 361,000 (1997)
Internet country code: sn
Internet hosts: 217 (2008)
Internet Service Providers (ISPs): 1 (2002)
Internet users: 820,000 (2007)','93ead023f76a1220137d1780c95b5da5d945f2f5b0bed1c7ad5b3dfbb711b586','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11256762b416274be77e2839027175bb6f644d9fde97ea006167af5b327f7a4a',2010,'KY','Cayman Islands','communications',421,'Telephones— main lines in use: 38,000
(2002)
Telephones— mobile cellular: 33,800
(2004)
Telephone system: general assessment:
reasonably good system
domestic: liberalization of telecom market in
2003; introduction of competition in the
mobile-cellular market in 2004
international: country code— 1-345; landing
point for the MAYA-1 submarine telephone
cable network that provides links to the US
and parts of Central and South America;
submarine cable provides connectivity to
Jamaica; satellite earth station— 1 Intelsat
(Adantic Ocean) (2007)
Radio broadcast stations: AM l, FM 4,
shortwave 0 (2004)
Radios: 36,000 (1997)
Television broadcast stations: 4 with
cable system (2004)
Televisions: 7,000 (1997)
Internet country code: ky
Internet hosts: 4,648 (2008)
Internet Service Providers (ISPs):
16(2000)
Internet users: 22,000 (2007)','f79f2047aff04592d43ceb5fce5bae51fbb42947e49aa3ae03902f15846bc1b5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c9c3c21d3cc374f61bdc59480b2605d25fd6c5f7c81118446172a2be8e6cd2',2010,'CF','Central African Republic','communications',430,'Telephones— main lines in use: 12,000
(2006)
Telephones— mobile cellular: 130,000
(2007)
Telephone system: general assessment:
limited telephone service; fixed-line
connections for well less than 1 per 100
persons coupled with mobile-cellular
usage of only about 3 per 100 persons;
most fixed-line and cellular telephone
services are concentrated in Bangui
domestic: network consists principally of
microwave radio relay and low-capacity, low-
powered radiotelephone communication
international: country code— 236; satellite
earth station— 1 Intelsat (Atlantic Ocean)
(2007)
Radio broadcast stations: AM 1, FM 5,
shortwave 1 (2001)
Radios: 283,000 (1997)
Television broadcast stations: 1 (2001)
Televisions: 18,000 (1997)
Internet country code: cf
Internet hosts: 21 (2008)
Internet Service Providers (ISPs): 1 (2002)
Internet users: 13,000 (2006)','8e2e00d035f58a78ea092c3df036be87b08eccb0eae1b3e2bc32c4b92c13d51d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a23f2677fc3b792746d102d751a07abd2ac357dea193d224008f8a9233fa498',2010,'TD','Chad','communications',435,'Telephones— main lines in use: 13,000
(2006)
Telephones— mobile cellular: 918,400
(2007)
Telephone system: general assessment:
primitive system with high costs and
low telephone density; fixed-line connec¬
tions for only about 1 per 1000 persons
coupled with mobile-cellular usage of only
about 9 per 100 persons
domestic: fair system of radiotelephone
communication stations
international: country code— 235; satellite
earth station— 1 Intelsat (Atlantic Ocean)
(2007)
Radio broadcast stations: AM 2, FM 4,
shortwave 5 (2001)
Radios: 1.67 million (1997)
Television broadcast stations: l (2001)
Televisions: 10,000 (1997)
Internet country code: td
Internet hosts: 5 (2008)
Internet Service Providers (ISPs): 1 (2002)
Internet users: 60,000 (2006)','c3daf7dbe1f9fd9ac37566b59ebd387ea82a4ca7e2716c92ce3d5d456eb2193f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d48a5ab64c7514e5735a89620cd542f167032df39f6d9f284e6a2f87b56be80',2010,'CL','Chile','communications',442,'Telephones— main lines in use: 3.379
million (2007)
Telephones— mobile cellular: 13.955
million (2007)
Telephone system: general assessment:
privatization begun in 1988; most
advanced telecommunications infrastruc¬
ture in South America; modern system
based on extensive microwave radio relay
facilities; fixed-line connections have
dropped in recent years as mobile-cellular
usage continues to increase, reaching a
level of 85 telephones per 100 persons
domestic: extensive microwave radio relay
links; domestic satellite system with 3
earth stations
international: country code— 56; subma¬
rine cables provide links to the US and to
Central and South America; satellite earth
stations— 2 Intelsat (Adantic Ocean) (2007)
Radio broadcast stations: AM 180, FM
64, shortwave 17 (1998)
Radios: 5.18 million (1997)
Television broadcast stations: 63 (plus
121 repeaters) (1997)
Televisions: 3.15 million (1997)
Internet country code: cl
Internet hosts: 847,215 (2008)
Internet Service Providers (ISPs): 7 (2000)
Internet users: 5.57 million (2007)','9192554b745737e4caee347c340c62149e8af681b6e9ae93d55056128a3ea626','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57762ba9e9d79b6f067c86448d18470ee9c1e8e0436bcfc4ddddc3eeb5512538',2010,'CN','China','communications',448,'Telephones— main lines in use: 365.4
million (2007)
Telephones — mobile cellular: 547.286
million (2007)
Telephone system: general assessment:
domestic and international services are
increasingly available for private use;
unevenly distributed domestic system serves
principal cities, industrial centers, and many
towns; China continues to develop its tele¬
communications infrastructure, and is part¬
nering with foreign providers to expand
its global reach; China in the summer of
2008 began a major restructuring of its
telecommunications industry, resulting in
the consolidation of its six telecom service
operators to three, China Telecom, China
Mobile and China Unicom, each providing
both fixed-line and mobile services
domestic: interprovincial fiber-optic trunk
lines and cellular telephone systems have
been installed; mobile-cellular subscrib-
ership is increasing rapidly; the number
of Internet users exceeded 250 million
by summer 2008; a domestic satellite
system with 55 earth stations is in place
international: country code— 86; a number
of submarine cables provide connectivity
to Asia, the Middle East, Europe, and the
US; satellite earth stations— 7 (5 Intelsat— 4
Pacific Ocean and 1 Indian Ocean; 1
Intersputnik— Indian Ocean region; and
1 Inmarsat— Pacific and Indian Ocean
regions) (2007)
Radio broadcast stations: AM 369, FM
259, shortwave 45 (1998)
Radios: 417 million (1997)
Television broadcast stations: 3,240 (of
which 209 are operated by China Central
Television, 31 are provincial TV stations, and
nearly 3,000 are local city stations) (1997)
Televisions: 400 million (1997)
Internet country code: cn
Internet hosts: 14.306 million (2008)
Internet Service Providers (ISPs):
3 (2000)
Internet users: 253 million (2008)
Telephones— main lines in use: 14.313
million (2007)
Telephones— mobile cellular: 24.302
million (2007)
Telephone system: general assessment:
provides telecommunications service for
every business and private need
domestic: thoroughly modern; completely
digitalized
international: country code— 886; numerous
submarine cables provide links throughout
Asia, Australia, the Middle East, Europe,
and the US; satellite earth stations— 2
Radio broadcast stations: AM 21, FM
143, shortwave 1 (2008)
Radios: 16 million (1994)
Television broadcast stations: 76 (5
television networks with 46 digital and 30
analog stations) (2007)
Televisions: 8.8 million (1998)
Internet country code: tw
Internet hosts: 5.225 million (2008)
Internet Service Providers (ISPs):
8 (2000)
Internet users: 14.76 million (2007)','f43ec0898b28796d15403489c1a7d8911ef22b8647a89f4979e8390092676a3c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a690d7b65be2d809e3cf45ea1f93501b2c3fac6254d1b53831de372d2268cb10',2010,'CX','Christmas Island','communications',457,'Telephones — main lines in use: NA
Telephone system: general assessment:
service provided by the Australian network
domestic: GSM mobile telephone service
replaced older analog system in February 2005
international: country code— 61-8; satellite
148
CLIPPERTON ISLAND
earth station— 1 (Intelsat provides tele¬
phone and telex service) (2005)
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (2006)
Radios: 1,000 (1997)
Television broadcast stations: 0 (TV
broadcasts received via satellite from main¬
land Australia) (2006)
Televisions: 600 (1997)
Internet country code: ,cx
Internet hosts: 1,821 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 464 (2001)','55207452e96b8d0a0f159e3c541fa08f07d772df15e0b8d83d8aa824ee0848ba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('145b39f87d79d3da30bb8a4824e6da79d7046b4fec7fe10a7572fadc500b0d84',2010,'LK','Sri Lanka','communications',464,'Telephones — main lines in use: 287
(1992)
Telephone system: general assessment:
connected within Australia’s telecommu¬
nication system; a local mobile-cellular
network is in operation
domestic: NA
international: country code— 61; telephone,
telex, and facsimile communications with
Australia and elsewhere via satellite; satel¬
lite earth station— 1 (Intelsat) (2001)
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (2004)
150','2ba742673f9bcb90db864a0a418a8ac2be7f4d2f65797dc6c1a0b76dd175f012','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf8cdb9e9faa98041b0d17caa6f6704fc79c1c9f253a0b135323a6d458f77ff7',2010,'CO','Colombia','communications',465,'Radios: 300 (1992)
Television broadcast stations:
4 (2007)
Televisions: NA
Internet country code: cc
Internet Service Providers (ISPs):
2 (2000)
Internet users: NA
Telephones — main lines in use: 7.936
million (2007)
Telephones— mobile cellular: 33.941
million (2007)
Telephone system: general assessment:
modern system in many respects; telecom¬
munications sector liberalized during die
1990s; multiple providers of both fixed-
line and mobile-cellular services; fixed-line
connections stand at about 18 per 100
persons; mobile cellular usage is about
75 per 100 persons; competition among
cellular service providers is resulting in
falling local and international calling rates
153
THE CIA WORLD FACTBOOK
and contributing to the steep decline in the
market share of fixed line services
domestic: nationwide microwave radio relay
system; domestic satellite system with 41
earth Stations; fiber-optic network linking
50 cities
international: country code— 57; subma¬
rine cables provide links to the US, parts
of the Caribbean, and Central and South
America; satellite earth stations— 10 (6
Intelsat, 1 Inmarsat, 3 fully digitalized
international switching centers) (2007)
Radio broadcast stations: AM 454, FM
34, shortwave 27 (1999)
Radios: 21 million (1997)
Television broadcast stations: 60 (1997)
Televisions: 4.59 million (1997)
internet country code: .CO
internet hosts: 1 .554 million (2008)
Internet Service Providers (ISPs): 18
(2000)
Internet users: 12.1 million (2007)','d391c1cf03bc4e406b6f3c26af57fc13b1e02f2e8f7594fb78e5bbed7f3da41e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de26dd67e903aeaf5b9eda4b898eda32ead13b7f227a1666a6210e8629fa6fe9',2010,'KM','Comoros','communications',480,'Telephones — main lines in use: 19,100
(2006)
Telephones — mobile cellular: 40,000
(2007)
Telephone system: general assessment:
sparse system of microwave radio relay
and HF radiotelephone communication
stations; fixed-line connections only
about 3 per 100 persons; mobile cellular
usage about 5 per 1 00 persons
domestic: HF radiotelephone communica¬
tions and microwave radio relay
international: country code— 269; HF radio¬
telephone communications to Madagascar
and Reunion
Radio broadcast stations: AM 1, FM 4,
shortwave 1 (2001)
Radios: 90,000 (1997)
Television broadcast stations: NA
Televisions: 1,000 (1997)
Internet country code: .km
Internet hosts: 8 (2008)
Internet Service Providers (ISPs):
1 (2000)
156
CONGO, DEMOCRATIC REPUBLIC OF THE
Internet users: 21,000 (2006)','6e7d8f040fb926028c77123b6af3966da6eab5540ef93a0c654b095843c37094','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad0994a6798567de3743019d0ce16cfddf6d299e7062c32d61a46df75a14669',2010,'CG','Congo','communications',485,'Telephones — main lines in use: 15,900
(2005)
Telephones — mobile cellular: 1.334
million (2007)
Telephone system: general assessment:
services barely adequate for government
use; key exchanges are in Brazzaville,
Pointe-Noire, and Loubomo; intercity
lines frequently out of order; fixed-line
infrastructure inadequate providing less
than 1 connection per 100 persons; in the
absence of an adequate fixed line infra¬
structure, mobile-cellular subscribership
has surged reaching 35 per 100 persons
domestic: primary network consists of
microwave radio relay and coaxial cable
international: country code— 242; satel¬
lite earth station— 1 Intelsat (Atlantic
Ocean)
Radio broadcast stations: AM l, FM 5,
shortwave 3 (2001)
Radios: 341,000 (1997)
Television broadcast stations: l (2001)
Televisions: 33,000 (1997)
Internet country code: eg
Internet hosts: 5 (2008)
Internet Service Providers (ISPs): l (2000)
Internet users: 7 0,000 (2006)','539f1d0a60b98d8aa945aa12d3738ce862eea465ae5683e60af5e2552fab698b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8874bd874faeaa0e57f4ca55466e1eab0d31b42ab7ec68295c2de8ab0122e142',2010,'NZ','New Zealand','communications',495,'Telephones — main lines in use: 6,200
(2002)
Telephones — mobile cellular: 1,500
(2002)
Telephone system: general assessment:
Telecom Cook Islands offers international
direct dialing, Internet, email, fax, andTplex
domestic: individual islands are connected
by a combination of satellite earth stations,
microwave systems, and VHF and HF
radiotelephone; within the islands, service
is provided by small exchanges connected
to subscribers by open-wire, cable, and
fiberoptic cable
international: country code— 682; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (2004)
Radios: 14,000 (1997)
Television broadcast stations: l (outer
islands receive satellite broadcasts) (2004)
Televisions: 4,000 (1997)
Internet country code: ck
Internet hosts: 2,234 (2008)
Internet Service Providers (ISPs): 3 (2000)
Internet users: 3,600 (2002)','f21359e262cff7b4806e27284d7d450c0640de57de0c704b28ba8149871a3ce2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d9eb2e589b29a55ddca3345b78a77c3c3fa17406e5c1bcae4981b653ae93767',2010,'CR','Costa Rica','communications',503,'Communications— note: there are auto¬
matic weather stations on many of the isles
and reefs relaying data to the mainland
widespread. In January 2008, Costa Rica
assumed a nonpermanent seat on the UN
Security Council for the 2008—09 term.
Telephones — main lines in use: 1.437
million (2007)
Telephones— mobile cellular: 1.503
million (2007)
Telephone system: general assessment:
good domestic telephone service in terms
of breadth of coverage; restricted cellular
telephone service; state-run monopoly
provider is struggling with the demand for
new lines, resulting in long waiting times
domestic: point-to-point and point-to-multi-
pointmicrowave, fiber-optic, andcoaxial cable
link rural areas; Internet service is available
international: country code— 506; landing
point for the Americas Region Carib¬
bean Ring System (ARCOS-1) fiber-optic
telecommunications submarine cable and
the MAYA-1 submarine cable that provide
links to South and Central America, parts
of the Caribbean, and the US; connected
to Central American Microwave System;
satellite earth stations— 2 Intelsat (Atlantic
Ocean) (2007)
Radio broadcast stations: AM 65, FM
51, shortwave 19 (2002)
Radios: 980,000 (1997)
Television broadcast stations: 20 (plus
43 repeaters) (2002)
Televisions: 525,000 (1997)
Internet country code: cr
Internet hosts: 16,440 (2008)
Internet Service Providers (ISPs): 3 (of
which only one is legal) (2000)
Internet users: 1.5 million (2007)
Telephones — main lines in use: 730,000
(2007)
Telephones — mobile cellular: 7.05
million (2007)
Telephone system: general assessment: well
developed by African standards; telecom¬
munications sector privatized in late 1 990s
and operational fixed-lines have more than
quadrupled since that time; with multiple
cellular service providers competing in
the market, cellular usage has increased
sharply to roughly 40 per 100 persons
domestic: open-wire lines and micro-
wave radio relay; 90% digitalized
international: country code— 225; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connec¬
tivity to Europe and Asia; satellite earth
stations— 2 Intelsat (1 Adantic Ocean and 1
Indian Ocean) (2007)
Radio broadcast stations: AM 2, FM 9,
shortwave 3 (1998)
Radios: 2.26 million (1997)
Television broadcast stations: 14 (1998)
Televisions: 1 .09 million (2000)
Internet country code: d
Internet hosts: 5,569 (2008)
Internet Service Providers (ISPs): 5 (2001 )
Internet users: 300,000 (2006)','941276de20fcbaee099b0b64058b918d67c6b08824017d0f03fc6b94c2ae9316','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e40de5d4dcdcff025dbe0c55ab7c48e7a0703ac36e46632c06765b8d8f29b1ae',2010,'CU','Cuba','communications',514,'Telephones— main lines in use: 1.825
million (2007)
Telephones— mobile cellular: 5.035
million (2007)
Telephone system: general assessment: the
telecommunications network has improved
steadily since the mid-1990s; the number
of fixed telephone lines holding steady at
about 40 per 100 persons; the number of
cellular telephone subscriptions exceeds the
population
domestic: more than 90 percent of local lines
are digital
international: country code— 385; digital
international service is provided through
the main switch in Zagreb; Croatia partici¬
pates in the Trans-Asia-Europe (TEL) fiber¬
optic project, which consists of 2 fiber-optic
trunk connections with Slovenia and a
fiber-optic trunk line from Rijeka to Split
and Dubrovnik; the ADRLA-1 submarine
cable provides connectivity to Albania and
Greece (2007)
Radio broadcast stations: am 16, fm
98, shortwave 5 (1999)
Radios: 1.51 million (1997)
Television broadcast stations: 36 (plus
321 repeaters) (1995)
Televisions: 1.22 million (1997)
Internet country code: hr
Internet hosts: 1.111 million (2008)
Internet Service Providers (ISPs): 9 (2000)
Internet users: l .995 million (2007)','5344c319ca15c4dde53391f943456bddf518364ab8e45b5eefdcef184dc2cdf8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4ca80f4651573b3f94a88ec4594a26420c08bf4013bc58a20cadcf83127f175',2010,'CH','Switzerland','communications',524,'( ■
Telephones— main lines in use: 1.043
million (2007)
Telephones — mobile cellular: 198,300
(2007)
Telephone system: general assessment:
greater investment beginning in 1 994
and the establishment of a new Ministry
of Information Technology and Commu¬
nications in 2000 has resulted in
improvements in the system; wireless
service is expensive and must be paid in
convertible pesos which effectively limits
mobile cellular subscribership
domestic: national fiber-optic system under
development; 95% of switches digitized by
end of 2006; fixed telephone line density
remains low, at less than 10 per 100 inhab¬
itants; domestic cellular service expanding
but remains at only about 2 per 1 00 persons
international: country code— 53; fiber-optic
cable laid to but not linked to US network;
satellite earth station— 1 Intersputnik
(Adantic Ocean region) (2007)
Radio broadcasf sfafions: AM 169, FM
55, shortwave 1 (1998)
Radios: 3.9 million (1997)
Television broadcasf sfafions: 58 (1997)
Televisions: 2.64 million (1997)
Internet country code: cu
Internet hosts: 3,664 (2008)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 1.31 million
note: private citizens are prohibited from
buying computers or accessing the Internet
without special authorization; foreigners
may access the Internet in large hotels
but are subject to firewalls; some Cubans
buy illegal passwords on the black market
or take advantage of public oudets to
access limited email and the government-
controlled “intranet” (2007)
Telephones — main lines in use:
5 million (2007)
Telephones — mobile cellular:
8.096 million (2007)
Telephone system: general assessment:
highly developed telecommunications
infrastructure with excellent domestic
and international services
domestic: ranked among leading coun¬
tries for fixed-line teledensity and infra¬
structure; mobile-cellular subscribership
roughly 100 per 100 persons; extensive
cable and microwave radio relay networks
international: country code— 41; satellite
earth stations— 2 Intelsat (Atlantic Ocean
and Indian Ocean)
Radio broadcasf sfations: AM 3, FM 106
(plus many low-power stations), shortwave
3 (2008)
Radios: 7.1 million (1997)
Television broadcast stations:
106 (2007)
Televisions: 3.31 million (1997)
Internet country code: ch
Internet hosts: 3.437 million (2008)
Internet Service Providers (ISPs): 44
(Switzerland and Liechtenstein) (2000)
Internet users: 4.61 million (2007)
Telephones— main lines in use:
3.452 million (2007)
Telephones— mobile cellular:
6.7 million (2007)
Telephone system: general assessment: fair
system currently undergoing significant
improvement and digital upgrades , including
fiberoptic technology
domestic: the number of fixed-line connec¬
tions has increased markedly since 2000;
v mobile-cellular service growing rapidly with
teledensity reaching 35 wireless telephones
per 100 persons in 2007; coaxial cable and
microwave radio relay network still in use
international: country code— 963; submarine
cable connection to Egypt, Lebanon, and
Cyprus; satellite earth stations— 1 Intelsat
(Indian Ocean) and 1 Intersputnik (Adantic
Ocean region); coaxial cable and microwave
radio relay to Iraq, Jordan, Lebanon, and
Turkey; participant in Medarabtel
Radio broadcast stations: AM 14, FM 2,
shortwave 1 (1998)
Radios: 4.15 million (1997)
Television broadcast stations: 44 (plus
17 repeaters) (1995)
Televisions: 1.05 million (1997)
Internet country code: sy
Internet hosts: 7,857 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 3.47 million (2007)','67035ef666f2bf43fc7dfd6792a80bfebe664cb4c8038a0e49b66365e4bec13f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc48a82b48ea77f3477cd971f3741d2bf6faee3b2995d51f4064428824c0f024',2010,'CY','Cyprus','communications',533,'Telephones— main lines in use: area
under government control: 376,000
(2007); area administered by Turkish
Cypriots: 86,228 (2002)
184
Telephones— mobile cellular: area under
government control: 962,200 (2007); area
administered by Turkish Cypriots: 147,522
(2002)
Telephone system: general assessment: excel¬
lent in both area under government control
and area administered by Turkish Cypriots
domestic: open-wire, fiber-optic cable,
and microwave radio relay
international: country code— 357 (area
administered by Turkish Cypriots uses the
country code of Turkey— 90); a number of
submarine cables, including the SEA-ME-
WE-3, combine to provide connectivity
to Western Europe, the Middle East, and
Asia; tropospheric scatter; satellite earth
stations— 8 (3 Intelsat— 1 Adantic Ocean
and 2 Indian Ocean, 2 Eutelsat, 2 Inter¬
sputnik, and 1 Arabsat)
Radio broadcast stations: area under
government control: AM 5, FM 76, short¬
wave 0
area administered by Turkish Cypriots: AM
1, FM 20, shortwave 1 (2004)
Radios: Greek Cypriot area: 310,000
(1997); Turkish Cypriot area: 56,450
(1994)
Television broadcast stations: area under
government control: 8
area administered by Turkish Cypriots: 2
(plus 4 relay) (2004)
Televisions: Greek Cypriot area: 248,000
(1997); Turkish Cypriot area: 52,300
(1994)
Internet country code: cy
Internet hosts: 143,099 (2008)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 380,000 (2007)
Telephones — main lines in use: 2.888
million (2006)
Telephones— mobile cellular: 13.075
million (2007)
Telephone system: general assessment:
privatization and modernization of the
Czech telecommunication system got a late
start but is advancing steadily; access to
the fixed-line telephone network expanded
throughout the 1990s but the number of
fixed line connections has been dropping
since then; mobile telephone usage increased
sharply beginning in the mid-1990s and
the number of cellular telephone subscrip¬
tions now greatly exceeds the population
domestic: virtually all exchanges now digital;
existing copper subscriber systems enhanced
with Asymmetric Digital Subscriber Line
(ADSL) equipment to accommodate
Internet and other digital signals; trunk
systems include fiber-optic cable and micro¬
wave radio relay
international: country code— 420; satellite
earth stations— 6 (2 Intersputnik— Adantic
and Indian Ocean regions, 1 Intelsat, 1
Eutelsat, 1 Inmarsat, 1 Globalstar) (2007)
Radio broadcast stations: AM 31, FM
304, shortwave 17 (2000)
Radios: 3,159,134 (December 2000)
Television broadcast stations: 71 (2008)
Televisions: 3,405,834 (December 2000)
Internet country code: cz
Internet hosts: 2.434 million (2008)
Internet Service Providers (ISPs): more
than 300 (2000)
Internet users: 4.4 million (2007)','980cea499575b68a0fffaa1cc12dcad672126bf45ffecebdacc5f75705c03eca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa62ff4b0cdd2ce6d44a0dd18966beaa2f03aa2cd317436e2d37ef2031a59526',2010,'SE','Sweden','communications',541,'Telephones — main lines in use: 2.824
million (2007)
Telephones— mobile cellular: 6.243
million (2007)
Telephone system: general assessment:
excellent telephone and telegraph services
domestic: buried and submarine cables and
microwave radio relay form trunk network,
4 cellular mobile communications systems
international: country code— 45; a series
of fiber-optic submarine cables link
Denmark with Canada, Faroe Islands,
Germany, Iceland, Netherlands, Norway,
Poland, Russia, Sweden, and UK;
satellite earth stations— 18 (6 Intelsat, 10
Eutelsat, 1 Orion, 1 Inmarsat (Blaavand-
Atlantic-East)); note— the Nordic countries
(Denmark, Finland, Iceland, Norway, and
Sweden) share the Danish earth station
and the Eik, Norway, station for worldwide
Inmarsat access
Radio broadcast stations: AM 1, FM
355, shortwave 0 (1998)
Radios: 6.02 million (1997)
Television broadcast stations: 172 (2008)
Televisions: 3.121 million (1997)
Internet country code: dk
Internet hosts: 3.642 million (2008)
InternetService Providers(ISPs): 1 3(2000)
Internet users: 3.5 million (2007)
Radio broadcast stations: AM NA, FM
1 (located in Akrotiri), shortwave NA
(British Forces Broadcasting Service (BFBS)
provides Radio 1 and Radio 2 service to
Akrotiri, Dhekelia, and Nicosia) (2006)
Television broadcast stations: 0
(British Forces Broadcasting Service
(BFBS) provides multi-channel satel¬
lite service to Akrotiri, Dhpkelia, and
Nicosia) (2006)
Telephones— main lines in use:
5.506 million (2007)
Telephones— mobile cellular:
10.371 million (2007)
Telephone system: general assessment:
highly developed telecommunications infra¬
structure; ranked among leading countries
for fixed-line, mobile-cellular, Internet and
broadband penetration
domestic: coaxial and multiconductor cables
carry most of the voice traffic; parallel
microwave radio relay systems carry some
additional telephone channels
international: country code— 46; subma¬
rine cables provide links to other Nordic
countries and Europe; satellite earth
stations— 1 Intelsat (Adantic Ocean), 1
Eutelsat, and 1 Inmarsat (Atlantic and
Indian Ocean regions); note— Sweden
shares the Inmarsat earth station with the
other Nordic countries (Denmark, Finland,
Iceland, and Norway)
Radio broadcast stations:
AM 1, FM 124, shortwave 0 (2008)
Radios: 8.25 million (1997)
Television broadcast stations:
252 (2008)
Televisions:
4.6 million (1997)
Internet country code: se
Internet hosts:
3.579 million (2008)
Internet Service Providers (ISPs):
29 (2000)
Internet users: 7 million (2007)','bdaf49c6c87914c7ab4a993d66614497aad6e6c1c6d052ae1b66489e78d45234','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e6c3ffedee6472ff3e08d5d1bf4180653520cdaa6bb2fe340ede83b809aa036',2010,'DJ','Djibouti','communications',553,'Telephones — main lines in use: 10,800
(2005)
Telephones— mobile cellular: 45,000
(2007)
Telephone system: general assessment: tele¬
phone facilities in the city of Djibouti are
adequate, as are the microwave radio relay
connections to oudying areas of the country
domestic: microwave radio relay network;
mobile cellular coverage is primarily limited
to the area in and around Djibouti city
international: country code— 253; landing
point for the SEA-ME-WE-3 optical tele¬
communications submarine cable with
links to Asia, the Middle East, and Europe;
satellite earth stations— 2 (1 Intelsat— Indian
Ocean and 1 Arabsat); Medarabtel regional
microwave radio relay telephone network
(2007)
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (2001)
Radios: 52,000 (1997)
Television broadcast stations: 1 (2001)
Televisions: 28,000 (1997)
Internet country code: dj
Internet hosts: 161 (2008)
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 1 ,000 (2006)','1a4951e2352b98f906064f7fce73b201ed620a3aa71f337bfdab5694fe5ff011','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f54b34d3b736de1bfc70fbb3aa1430f0e04064a74a219f37ac495575fe5f58e',2010,'DO','Dominican Republic','communications',561,'Telephones — main lines in use: 21,000
(2004)
Telephones — mobile cellular: 41,800
(2004)
Telephone system: general assessment: NA
domestic: fully automatic network
international: country code— D767; landing
point for the East Caribbean Fiber Optic
System (ECFS) submarine cable with links
Telephones— main lines in use: 907,000
(2007)
Telephones — mobile cellular: 5.513
million (2007)
Telephone system: general assessment: rela¬
tively efficient system based on island-wide
microwave radio relay network
domestic: fixed telephone line density is about
10 per 100 persons; multiple providers of
mobile cellular service with a subscribership
of roughly 60 per 1 00 persons
international: country code— 1-809; landing
point for the Americas Region Caribbean
Ring System (ARCOS-1) fiber-optic
telecommunications submarine cable
that provides links to South and Central
America, parts of the Caribbean, and US;
satellite earth station— 1 Intehat (Atlantic
Ocean) (2007)
Radio broadcasf sfafions: AM 120, FM
56, shortwave 4 (1998)
Radios: 1.44 million (1997)
Television broadcast stations: 25 (2003)
Televisions: 770,000 (1997)
Internet country code: do
Internet hosts: 105,546 (2008)
Internet Service Providers (ISPs):
24 (2000)
Internet users: 1.677 million (2007)','aa1001a371b92f35d940bd9cae86e8dc691acacfa3117bef662760aa67660285','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84c2c11c4857447b3d68ad139bcda33c6bfc0c5c471edc2c2f6d669ef37e0114',2010,'EC','Ecuador','communications',573,'Telephones— main lines in use: 1.805
million (2007)
Telephones— mobile cellular: 10.086
million (2007)
Telephone system: general assessment:
generally elementary but being expanded
domestic: fixed-line services provided by
three state-owned enterprises; plans to
transfer the state-owned operators to private
ownership have repeatedly failed; fixed-line
density stands at about 1 3 per 100 persons;
mobile cellular use has surged and has a
subscribership of nearly 7 5 per 1 00 persons
international: country code— 593; landing
point for the PAN-AM submarine telecom¬
munications cable that provides links to
the west coast of South America, Panama,
Colombia, Venezuela, and extending
onward to Aruba and the US Virgin
Islands in the Caribbean; satellite earth
station— 1 Intelsat (Atlantic Ocean) (2007)
Radio broadcast stations: AM 392, FM
35, shortwave 29 (2001)
Radios: 5 million (2001)
Television broadcast stations: 7 (plus 14
repeaters) (2000)
Televisions: 2.5 million (2001)
internet country code: ec
Internet hosts: 45,404 (2008)
Internet Service Providers (ISPs): 31
(2001)
Internet users: 1.549 million (2006)','2d1c17a484fe25fa7f49c88ab17c67d3ed507aedf8e9a7ed33ad1a08e03ddfce','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54967586b325b1e95cc842ec8994ac1de1123308f0b453e58cb4e9ed452c2f9b',2010,'EG','Egypt','communications',583,'Telephones— main lines in use: 11.229
million (2007)
Telephones — mobile cellular: 30.065
million (2007)
Telephone system: general assess¬
ment: large system; underwent exten¬
sive upgrading during 1990s and is
reasonably modem; Telecom Egypt, the
landline monopoly, has been increasing
service availability and in 2007 fixed-line
density stood at 14 per 100 persons; as
of 2007 there were three mobile-cellular
networks and service is expanding rapidly
domestic: principal centers at Alexandria,
Cairo, A1 Mansurah, Ismailia, Suez, and
Tanta are connected by coaxial cable and
microwave radio relay
international: country code— 20; landing
point for both the SEA-ME-WE-3 and
SEA-ME-WE''4 submarine cable networks;
linked to the international submarine
cable FLAG (Fiber-Optic Link Around
the Globe); satellite earth stations— 4
(2 Intelsat— Atlantic Ocean and Indian
Ocean, 1 Arabsat, and 1 Inmarsat); tropo¬
spheric scatter to Sudan; microwave radio
relay to Israel; a participant in Medarabtel
(2007)
Radio broadcast stations: AM 42 (plus
15 repeaters), FM 11, shortwave 3 (1999)
Radios: 20.5 million (1997)
Television broadcast stations:
98 (September 1995)
Televisions: 7.7 million (1997)
Internet country code: eg
Internet hosts: 175,342 (2008)
Internet Service Providers (ISPs):
50 (2000)
Internet users: 8.62 million (2007)','25a86d31da0598a18f7ba448a938d2b122d3b54bb8cf787cb029362289a7d4e0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88743e2e2bbfb1388f21d4d328332c066623a11328cb99ba6e77b80314082b6f',2010,'SV','El Salvador','communications',590,'Telephones — main lines in use: 1.08
million (2007)
Telephones— mobile cellular: 6.137
million (2007)
Telephone system: general assessment:
multiple mobile-cellular service providers
are expanding services rapidly and in
2007 mobile-cellular density stood at
nearly 90 per 100 persons; growth in
fixed-line services has slowed in the face of
mobile-cellular competition
dbmestic: nationwide microwave radio
relay system
international: country code— 503; satellite
earth station— 1 Intelsat (Adantic Ocean);
connected to Central American Microwave
System (2007)
Radio broadcast stations: AM 52, FM
144, shortwave 0 (2005)
Radios: 2.75 million (1997)
Television broadcast stations: 5 (1997)
Televisions: 600,000 (1990)
Internet country code: sv
Internet hosts: 1 1 ,434 (2008)
Internet Service Providers (ISPs): 4
(2000)
Internet users: 700,000 (2006)','955f1926d9afc8b6a35cbaea7c97737d044ce4f3c9893b95aa67dd4927ff0e62','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('011aaf4c0d4c9a8e710b0928dbb2f7c217590e475c88034844bd9b1928a137f6',2010,'GQ','Equatorial Guinea','communications',600,'Telephones — main lines in use: 10,000
(2005)
Telephones— mobile cellular: 220,000
(2007)
Telephone system: general assessment:
digital fixed-line network in most major
urban areas and good mobile coverage
domestic: fixed-line density is about 2 per
100 persons; mobile-cellular subscriber-
ship has been increasing and in 2007
stood at about 40 percent of the population
international: country code— 240; inter¬
national communications from Bata and
Malabo to African and European coun¬
tries; satellite earth station— 1 Intelsat
(Indian Ocean) (2007)
Radio broadcast stations: AM 0, FM 3,
shortwave 5 (2001)
Radios: 180,000 (1997)
Television broadcast stations:
1 (2001)
Televisions: 4,000 (1997)
Internet country code: gq
Internet hosts: 9 (2008)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 8,000 (2006)','2dcc66c49ddbf06e122608f6cff24433fe453a3e965d1408b08b9bd223f424dc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4381afd5e67b86d87370de4e030751e2e388ae793b15631623a589291397caae',2010,'ET','Ethiopia','communications',608,'Telephones— main lines in use: 37,500
(2006)
Telephones— mobile cellular: 70,000
(2007)
Telephone system: general assessment:
inadequate; combined fixed-line and
mobile cellular subscribership is only about
2 per 100 persons
218
Telephones — main lines in use: 880,100
(2007)
Telephones — mobile cellular: 1.208
million (2007)
Telephone system: general assessment:
inadequate telephone system; the number
of fixed lines and mobile telephones is
increasing from a very small base; combined
fixed and mobile-cellular teledensity is only
about 2 per 1 00 persons
domestic: open-wire; microwave radio relay;
radio communication in the HF, VHF,
and UHF frequencies; 2 domestic satellites
provide the national trunk service
international: country code— 251; open-wire
to Sudan and Djibouti; microwave radio
relay to Kenya and Djibouti; satellite earth
stations— 3 Intelsat (1 Atlantic Ocean and
2 Pacific Ocean)
Radio broadcast stations: AM 8, FM 0,
shortwave 1 (2001)
Radios: 15.2 million (2002)
Television broadcast stations: l (plus 24
repeaters) (2001)
Televisions: 682,000 (2002)
internet country code: et
Internet hosts: 128 (2008)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 291,000 (2007)
Telephones — main lines in use: 85,000
(2007)
Telephones— mobile cellular: 2.483
million (2007)
Telephone system: general assessment:
domestic system unreliable but improving;
provides only minimal service
domestic: fixed-line availability is gradually
increasing, but subscribership remains
less than 1 per 100 persons; increasing
use of local radio loops to extend network
coverage to remote areas; mobile-cellular
subscribership has increased sharply to 20
per 100 persons
international: country code— 223; satellite
earth stations— 2 Intelsat (1 Atlantic Ocean,
1 Indian Ocean) (2007)
Radio broadcast stations: AM 1, FM 230
(27 regional and government stations, and
203 private stations), shortwave 1 (2001)
Radios: 570,000 (1997)
Television broadcast stations: 2 (plus
repeaters) (2007)
Televisions: 45,000 (1997)
Internet country code: ml
Internet hosts: 387 (2008)
Internet Service Providers (ISPs): 13
(2001)
Internet users: 100,000 (2007)','1d0a5643dbc69c3cf81ed39d75eeb8011312eba219e5713b540b55c8da8e2065','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf2de6ae95aebd3eca6956c8ca4ba048822860780890fe1af1a477362b7687af',2010,'EE','Estonia','communications',609,'domestic: inadequate; most telephones are in
Asmara; governmentis seeking international
tenders to improve the system (2002)
international: country code— 291; note-
international connections exist
Radio broadcast stations: AM 2, FM
NA, shortwave 2 (2000)
Radios: 345,000 (1997)
Television broadcast stations: 2 (2006)
Televisions: 1,000 (1997)
Internet country code: er
Internet hosts: 1,074 (2008)
Internet Service Providers (ISPs): 5 (2001 )
Internet users: 120,000 (2007)
Telephones — main lines in use: 495,500
(2007)
Telephones — mobile cellular: 1.982
million (2007)
Telephone system: general assessment:
foreign investment in die form of joint
business ventures greatly improved
telephone service; substantial fiber-optic
cable systems carry telephone, TV, and
221
THE CIA WORLD FACTBOO K
radio traffic in the digital mode; Internet
services are widely available; schools and
libraries are connected to the Internet,
a large percentage of the population files
income-tax returns online, and online
voting was used for the first time in the
2005 local elections
domestic: a wide range of high quality voice,
data, and Internet services is available
throaughout the country
international: country code— 372; fiberoptic
cables to Finland, Sweden, Latvia, and
Russia provide worldwide packet-switched
service; 2 international switches are located
in Tallinn (2001)
Radio broadcast stations: AM 0, FM 32,
shortwave 0 (2007)
Radios: 1.01 million (1997)
Television broadcast stations: 4 (2007)
Televisions: 605,000 (1997)
Internet country code: .ee
Internet hosts: 645,495 (2008)
Internet Service Providers (ISPs):
38 (2001)
Internet users: 780,000 (2007)','c92ad12af0cb0817be7533b7bcb2cf97923cf2d6cdb5f1b62c4ede557a1f5a34','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b670c39e699fcacd153ba4a9e39d40b87cb94a1a5ba6311baf917d9721459d43',2010,'IT','Italy','communications',626,'Telephones — main lines in use: 238
million (2005)
Telephones — mobile cellular: 466
million (2005)
Telephone system: note— see individual
country entries of member states
Radio broadcast stations: AM 930, FM
13,655, shortwave 71 (1998); note— sum of
individual country radio broadcast stations;
there is also a European-wide station (Euro-
radio)
Television broadcast stations: 2,700
(1995); note— sum of individual country
television broadcast stations excluding
repeaters; there is also a European-wide
station (Eurovision)
Internet country code: .eu; note— see
country entries of member states for indi¬
vidual country codes
Internet hosts: 31,693 (2008); note-this
sum reflects the number of internet hosts
assigned the .eu internet country code
Internet users: 247 million (2006)
Telephones— main lines in use: 2,400
(2002)
Telephones— mobile cellular: 0 (2001)
Telephone system: general assessment: NA
domestic: government-operated radiotel¬
ephone and private VHF/CB radiotele¬
phone networks provide effective service to
almost all points on both islands
international: country code— 500; satellite
earth station— 1 Intelsat (Atlantic Ocean)
with links through London to other
countries
Radio broadcast stations: AM 1, FM 7,
shortwave 0 (British Forces Broadcasting
Service (BFBS) provides Radio 1 and Radio
2 service) (2006)
Radios: 1,000 (1997)
Television broadcast stations: 2 (British
Forces Broadcasting Service (BFBS)
provides multi-channel satellite service
to members of UK Forces as well as
islanders); cable television is available in
Stanley (2006)
Televisions: 1,000 (1997)
Internet country code: fk
Internet hosts: 91 (2008)
Internet Service Providers (ISPs): 2
(2000)
Internet users: l ,900 (2002)
Telephones— main lines in use: 26.89
million (2006)
Telephones — mobile cellular: 78.571
million (2006)
Telephone system: general assessment:
modern, well developed, fast; fully auto¬
mated telephone, telex, and data services
domestic: high-capacity cable and micro-
wave radio relay trunks
international: country code— 39; a series of
submarine cables provide links to Asia,
Middle East, Europe, North Africa, and
US; satellite earth stations— 3 Intelsat (with
a total of 5 antennas— 3 for Atlantic Ocean
and 2 for Indian Ocean), 1 Inmarsat
(Atlantic Ocean region), and NA Eutelsat
Radio broadcast stations: AM about 100,
FM about 4,600, shortwave 9 (1998)
Radios: 50.5 million (1997)
Television broadcast stations: 358 (plus
4,728 repeaters) (1995)
Televisions: 30.3 million (1997)
internet country code: it
Internet hosts: 17.702 million (2008)
Internet Service Providers (ISPs): 93
(Italy and Holy See) (2000)
Internet users: 32 million (2007)','b0c4d7ae8d5f3d161727ef5a7427c2edfdb4a2ea34668776617d5dfc3c1dcbd2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd2a8ef561d8e52b07bb2e81ec065d051743977c34a967308b9254980bf30a02',2010,'FO','Faroe Islands','communications',635,'Telephones— main lines in use: 23,000
(2006)
Telephones— mobile cellular: 50,000
(2006)
Telephone system: general assessment:
good international communications; good
domestic facilities
domestic: digitalization was completed in
1 998; both NMT (analog) and GSM (digital)
mobile telephone systems are installed
international: country code— 298; satel¬
lite earth stations— 1 Orion; 1 fiber-optic
submarine cable to the Shetland Islands,
linking the Faroe Islands with Denmark
and Iceland; fiber-optic submarine cable
connection to Canada-Europe cable
Radio broadcast stations: AM 1, FM 13,
shortwave 0 (1998)
Radios: 26,000 (1997)
Television broadcast stations: 3 (plus 43
repeaters) (September 1995)
Televisions: 15,000 (1997)
Internet country code: fo
Internet hosts: 8,516 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users: 34,000 (2006)','4c768cc5d410881206e1eb7817e48c272bd68d46c4f0cd0eb4d1ac43ba7e74db','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdd5db9d50b3b7f0f32d46a74fe44c6dcf66aed9bcb09dadd90687fe0a86d0af',2010,'FJ','Fiji','communications',643,'Telephones— main lines in use: 108,400
(2007)
Tejephones— mobile cellular: 437,000
(2007)
Telephone system: general assessment:
modem local, interisland, and interna¬
tional (wire/radio integrated) public and
special-purpose telephone, telegraph,
and teleprinter facilities; regional radio
communications center
domestic: telephone or radio telephone
links to almost all inhabited islands; most
towns and large villages have automatic
telephone exchanges and direct dialing;
combined fixed and mobile-cellular density
is about 60 per 1 00 persons
international: country code— 679; access
to important cable links between US
and Canada as well as between NZ and
Australia; satellite earth stations— 2 Inmarsat
(Pacific Ocean) (2007)
Radio broadcast stations: AM 13, FM
40, shortwave 0 (1998)
Radios: 541,476 (1999)
Television broadcast stations: NA
Televisions: 88,110 (1999)
Internet country code: fj
Internet hosts: 12,592 (2008)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 80,000 (2006)','056c1eadbb33dabc3ffd81af64c293fedabde4514b84c3e0dfede3e793c344f9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfc43d7c52bd56a22788791d73187e4d9e2b611232a116f9714597484535b010',2010,'FI','Finland','communications',652,'Telephones— main lines in use: 1.74
million (2007)
Telephones— mobile cellular: 6.08
million (2007)
Telephone system: general assessment :
modem system with excellent service
domestic: digital fiber-optic fixed-line
network and an extensive cellular network
provide domestic needs
international: country code— 358; subma¬
rine cables provide links to Estonia and
Sweden; satellite earth stations— access to
Intelsat transmission service via a Swedish
satellite earth station, 1 Inmarsat (Adantic
and Indian Ocean regions); note— Finland
shares the Inmarsat earth station with the
other Nordic countries (Denmark, Iceland,
Norway, and Sweden)
Radio broadcasf sfafions: AM 2, FM 59,
shortwave 2 (2008)
Radios: 7.7 million (1997)
Television broadcast stations: 120
(plus 431 repeaters) (1999); note— on 1
September 2007, Finland began broad¬
casting all television signals digitally;
analog broadcasts via cable networks were
discontinued 29 February 2008
Televisions: 3.2 million (1997)
Background: Although ultimately a
victor in World Wars I and II, France
Internet country code: .fi; note-Aland
Islands assigned .ax
Internet hosts: 3.877 million (2008)
Internet Service Providers (ISPs): 3 (2002)
Internet users: 3.6 million (2007)','a02091c7950ab2440772d95ea1337b3d97f0f1f9a51929ce39a1c98786cc7f14','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('232114aa5d0dafa596eec2d5f1ebfb0a15a51ed4febd8455fdbbfb95dbdd0b85',2010,'PF','French Polynesia','communications',664,'Telephones — main lines in use: 53,600
(2006)
Telephones— mobile cellular: 174,800
(2007)
Telephone system: general assessment: NA
domestic: NA
international: country code— 689; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 14,
shortwave 2 (1998)
Radios: 128,000 (1997)
Television broadcast stations: 7 (plus 17
repeaters) (1997)
Televisions: 40,000 (1997)
Internet country code: pf
Internet hosts: 14,070 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 75,000 (2007)
Internet country code: tf
Internet hosts: 38 (2008)
Communications— note: one or more
meteorological stations on each possession;
note— meteorological station on Tromelin
Island (lies Eparses) is important for fore¬
casting cyclones','76a94b0d5347740085135d96ef3ad0d81d3748dbe39fa349644af48b63321c84','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad848cd5f40c081d3324de5a8c4b59a17a51668cb885cb8435388c7184b05c87',2010,'GA','Gabon','communications',668,'Telephones— main lines in use: 26,500
(2007)
Telephones— mobile cellular: 1.169
million (2007)
Telephone system: general assessment:
adequate service by African standards and
improving with the help of a growing mobile
cell network system with multiple providers;
mobile-cellular subscribership reached 80
per 100 persons in 2007
domestic: adequate system of cable, micro¬
wave radio relay, tropospheric scatter,
radiotelephone communication stations,
and a domestic satellite system with 12
earth stations
international: country code— 241; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connectivity
to Europe and Asia; satellite earth stations—
3 Intelsat (Atlantic Ocean) (2007)
Radio broadcast stations: AM 6, FM 7
(plus 1 1 repeaters), shortwave 4 (2001)
Radios: 208,000 (1997)
Television broadcast stations: 4 (plus 4
repeaters) (2001)
Televisions: 63,000 (1997)
Internet country code: ga
Internet hosts: 88 (2008)
Internet Service Providers (ISPs): 1
(2001)
Internet users: 145,000 (2007)
Telephones— main lines in use: 76,400
(2007)
Telephones — mobile cellular: 795,900
(2007)
Telephone system: general assessment:
adequate; a packet switched data network
is available; two mobile-cellular service
providers
domestic: adequate network of microwave
radio relay and open-wire; combined fixed-
line and mobile-cellular teledensity reached
50 telephones per 100 persons in 2007
international: country code— 220; micro¬
wave radio relay links to Senegal and
Guinea-Bissau; satellite earth station— 1
Intelsat (Atlantic Ocean) (2007)
Radio broadcast stations: AM 3, FM 2,
shortwave 0 (2001)
Radios: 196,000(1997)
Television broadcast stations: 1 (govern¬
ment-owned) (1997)
Televisions: 5,000 (2000)
Internet country code: gm
Internet hosts: 320 (2008)
Internet Service Providers (ISPs): 2 (2001)
Internet users: 100,200 (2007)
Telephones — main lines in use: 350,400
(includes West Bank) (2007)
Telephones — mobile cellular: 1.026
million (includes West Bank) (2007)
Telephone system: general assessment: NA
domestic: Israeli company BEZEK and the
Palestinian company PALTEL are respon¬
sible for fixed line services; the Palestinian
JAWAL company provides cellular
services
international: country code— 970 (2004)
Radio broadcast stations: AM 0, FM 10,
shortwave 0 (2008)
Radios: NA; note— most Palestinian house¬
holds have radios (1999)
Television broadcast stations: 1 (2008)
Televisions: NA, note— most Palestinian
households have televisions (1997)
Internet country code: .ps; note— same as
West Bank
Internet Service Providers (ISPs): 3
(1999)
Internet users: 355,500 (includes West
Bank) (2007)','f05e4eb8111dd228207db08a8ed8a9da0964b28ce4c5b9cc3c302cab1fb55851','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8e6fd8e4f5b545ddedc37b2c18e19608c5ead2e0a0a32c58578dfbb1ad59f8d',2010,'GE','Georgia','communications',676,'Telephones — main lines in use: 556,100
(2007)
Telephones— mobile cellular: 2.6 million
(2007)
Telephone system: general assessment: fixed-
line telecommunications network has only
limited coverage outside Tbilisi; long list of
people waiting for fixed line connections;
multiple mobile-cellular providers provide
services to an increasing subscribership
throughout the country
domestic: cellular telephone networks now
cover the entire country; mobile-cellular
teledensity approaching 60 per 1 00 people;
urban fixed-line telephone density is about
20 per 100 people; rural telephone density
is about 4 per 100 people; intercity facilities
include a fiber-optic line between T’bilisi and
K’ut’aisi; nationwide pager service is available
international: country code— 995; the Georgia-
Russia fiber optic submarine cable provides
connectivity to Russia; international service
is available by microwave, landline, and
satellite through the Moscow switch; inter¬
national electronic mail and telex service are
available
Radio broadcast stations: AM 7, FM 12,
shortwave 4 (1998)
Radios: 3.02 million (1997)
Television broadcast stations: 12 (plus
repeaters) (1998)
Televisions: 2.57 million (1997)
Internet country code: ge
Internet hosts: 27,905 (2008)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 360,000 (2007)','db6c176ba4d3b832599fd5a139c2f2e9ce2c4a9c0921563c2241eb54b79a3ee4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb2a5f17f23f8be1b1bafa76c4ece7c7f1efc24df6586f29616e21d6bcac2e9e',2010,'GH','Ghana','communications',684,'Telephones — main lines in use: 53.75
million (2007)
Telephones— mobile cellular: 97.151
million (2007)
Telephone system: general assessment:
Germany has one of the world’s most
technologically advanced telecommuni¬
cations systems; as a result of intensive
capital expenditures since reunification, the
formerly backward system of the eastern
part of the country, dating back to World
War II, has been modernized and inte¬
grated with that of the western part
domestic: Germany is served by an extensive
system of automatic telephone exchanges
connected by modem networks of fiber¬
optic cable, coaxial cable, microwave radio
relay, and a domestic satellite system;
cellular telephone service is widely available,
expanding rapidly, and includes roaming
service to many foreign countries
international: country code— 49; Germany’s
international service is excellent worldwide,
consisting of extensive land and undersea
cable facilities as well as earth stations in
the Inmarsat, Intelsat, Eutelsat, and Inter¬
sputnik satellite systems (2001)
Radio broadcast stations: AM 51, FM
787, shortwave 4 (1998)
Radios: 77.8 million (1997)
Television broadcast stations: 373 (plus
8,042 repeaters) (1995)
Televisions: 51.4 million (1998)
Internet country code: de
Internet hosts: 22.606 million (2008)
Internet Service Providers (ISPs): 200
(2001)
Internet users: 42.5 million (2007)
Telephones— main lines in use: 376,500
(2007)
Telephones— mobile cellular: 7.604
million (2007)
Telephone system: general assessment:
outdated and unreliable fixed-line infra¬
structure heavily concentrated in Accra;
competition among multiple mobile-cellular
providers has spurred growth with subscrib-
ership about 35 per 1 00 persons and rising
domestic: primarily microwave radio relay;
wireless local loop has been installed
international: country code— 233; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connectivity
to Europe and Asia; satellite earth stations—
4 Intelsat (Atlantic Ocean); microwave
radio relay link to Panaffel system connects
Ghana to its neighbors (2007)
Radio broadcast stations: AM 0, FM 86,
shortwave 3 (2007)
Radios: 12.5 million (2001)
Television broadcast stations: 7 (2007)
Televisions: 1.9 million (2001)
Internet country code: gh
Internet hosts: 24,018 (2008)
Internet Service Providers (ISPs): 12
(2000)
Internet users: 650,000 (2007)','ff68679525ae347f7592abc2ee42682ed75dbb16f2653d20032a92878d09e19b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c3c5b2ab3faa412d8ac2e736a96a8884b84845e58b4242508d0d47ae984440a',2010,'GI','Gibraltar','communications',696,'Telephones— main lines in use: 24,512
(2002)
Telephones— mobile cellular: 9,797
(2002)
Telephone system: general assessment:
adequate, automatic domestic system and
adequate international facilities
ddmestic: automatic exchange facilities
international: country code— 350; radiotel¬
ephone; microwave radio relay; satellite
earth station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (1 998)
Radios: 37,000 (1997)
Television broadcast stations: l (plus 3
repeaters) (1997)
Televisions: 10,000 (1997)
Internet country code: gi
Internet hosts: 1,904 (2008)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 6,200 (2002)','90eb44f1ef003e8d9c7060e21123b6b7ca7e8e88ab43a5e28dfff0a378e4b537','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aad7d7c2e186e605961ed2c410a15c7d9ed2345f93d28caa32f03f1324fdc784',2010,'GR','Greece','communications',705,'Telephones— main lines in use: 6.227
million (2007)
Telephones— mobile cellular: 11.997
million (2007)
Telephone system: general assessment:
adequate, modern networks reach all areas;
good mobile telephone and international
service
domestic: microwave radio relay trunk
system; extensive open-wire connections;
submarine cable to offshore islands
international: country code— 30; landing
point for the SEA-ME-WE-3 optical tele¬
communications submarine cable that
provides links to Europe, Middle East,
and Asia; a number of smaller subma¬
rine cables provide connectivity to various
parts of Europe, the Middle East, and
Cyprus; tropospheric scatter; satellite earth
stations— 4 (2 Intelsat— 1 Atlantic Ocean
and 1 Indian Ocean, 1 Eutelsat, and 1
Inmarsat— Indian Ocean region)
Radio broadcast stations: AM 26, FM
88, shortwave 4 (1998)
Radios: 5.02 million (1997)
Television broadcast stations: 36 (plus
1,341 repeaters); also 2 stations in the
US Armed Forces Radio and Television
Service (1995)
273
THE CIA WORLD FACTBOOK
Televisions: 2.54 million (1997)
Internet country code: gr
Internet hosts: 1 .626 million (2008)
Internet Service Providers (ISPs): 27
(2000)
Internet users: 2.54 million (2007)
Telephones— main lines in use: 463,600
(2007)
Telephones— mobile cellular: 1.518
million (2007)
Telephone system: general assessment:
competition from the mobile-cellular
segment of the telecommunications market
has led to a drop in fixed-line telephone
subscriptions
domestic: combined fixed line and mobile
telephone density approaching 100 per
100 persons
international: country code— 389 (2007)
Radio broadcast stations: AM 29, FM
32, shortwave 0 (2008)
Radios: 410,000 (1997)
Television broadcast stations: 52 (2007)
Televisions: 510,000 (1997)
Internet country code: .mk
Internet hosts: 36,905 (2008)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 685,000 (2007)','b6e243ac13a852622c0ea72f008d7e53a5e85bec3f7e2942065c0d54e649e23b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba359c3506e7f947e0d569a20c56759d650e7aa697f33b24b1479f5290ac1b01',2010,'GL','Greenland','communications',711,'Telephones— main lines in use: 36,000
(2006)
Telephones— mobile cellular: 66,400
(2007)
Telephone system: general assessment:
adequate domestic and international service
provided by satellite, cables and microwave
radio relay; totally digitalized in 1995
domestic: microwave radio relay and satellite
international: country code— 299; satellite
earth stations— 15 (12 Intelsat, 1 Eutelsat,
2 Americom GE-2 (all Atlantic Ocean))
(2000)
Radio broadcast stations: AM 5, FM 14,
shortwave 0 (2008)
Radios: 30,000 (1998 est.)
Television broadcast stations: l (plus
some local low-power stations, and 3
Armed Forces Radio and Television Service
(AFRTS) stations (1997)
Televisions: 30,000 (1998 est.) 1
Internet country code: gl
Internet hosts: 14,132 (2008)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 52,000 (2007)','1be2833875feb3888cc1a69d2754e94ffdad3aeae21a72860cad35ab85cfaba5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9900fa99aa096a929de1b88fa2f381da89643594a4741a36a046708d87d44220',2010,'GU','Guam','communications',721,'Telephones— main lines in use: 27,700
(2006)
Telephones — mobile cellular: 46,200
(2006)
Telephone system: general assessment:
automatic, islandwide telephone system
domestic: interisland VHF and UHF radio¬
telephone links
international: country code— 1-473; landing
point for the East Caribbean Fiber Optic
System (ECFS) submarine cable with links
to 1 3 other islands in the eastern Caribbean
extending from the British Virgin Islands
to Trinidad; SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent;
VHF and UHF radio links to Trinidad
Radio broadcast stations: AM 2, FM 13,
shortwave 0 (1998)
Radios: 57,000 (1997)
Television broadcast stations: 2 (1997)
Televisions: 33,000 (1997)
Internet country code: gd
Internet hosts: 9 (2008)
Internet Service Providers (ISPs): 14
(2000)
Internet users: 23,000 (2007)','d42a48beb52efb8579391ea5d051e6d54b74033927123c03e1f68de27a61e767','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec068841208271b802dccc8d8881820b698a46081ab7b99f54429e87e6c4394c',2010,'GT','Guatemala','communications',729,'Telephones— main lines in use: 65,500
(2003)
Telephones — mobile cellular: 98,000
(2004)
Telephone system: general assessment:
modem system, integrated with US
facilities for direct dialing, including
free use of 800 numbers
domestic: modern digital system, including
cellular mobile service and local access to
the Internet
international: country code— 1-671; major
landing point for submarine cables between
Asia and the US (Guam is a trans-Pacific
communications hub for major carriers
linking the US and Asia); satellite earth
stations— 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 3, FM 11,
shortwave 2 (2005)
Radios: 221,000 (1997)
Television broadcast stations: 3 (2006)
Televisions: 106,000 (1997)
Internet country code: gu
Internet hosts: 36 (2008)
Internet Service Providers (ISPs): 20
(2000)
Internet users: 65,000 (2005)
Telephones— main lines in use: 1.355
million (2006)
Telephones— mobile cellular: 10.15
million (2007)
Telephone system: general assessment:
fairly modern network centered in the city
of Guatemala
domestic: state-owned telecommunications
company privatized in the late 1 990s
opening the way for competition; fixed-line
teledensity 11 per 100 persons; fixed-line
investments are being concentrated on
improvingrural connectivity; mobile-cellular
teledensity 80 per 100 persons
international: country code— 502; landing
point for both the Americas Region Carib¬
bean Ring System (ARCOS-1) and the
SAM-1 fiber optic submarine cable system
that together provide connectivity to South
and Central America, parts of the Carib¬
bean, and the US; connected to Central
American Microwave System; satellite earth
station— 1 Intelsat (Adantic Ocean)
Radio broadcast stations: AM 130, FM
487, shortwave 15 (2000)
Radios: 835,000 (1997)
Television broadcast stations: 26 (plus
27 repeaters) (1997)
Televisions: 1.323 million (1997)
Internet country code: gt
Internet hosts: 124,095 (2008)
Internet Service Providers (ISPs): 5 (2000)
Internet users: 1.32 million (2006)','c34aa28b687bb11747f37be6f1c81a0c74530268ef4591675edab09c552848bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('622903199d4483270ce148d999bddd2d87dd22615f7e8f0132de35c542fcce5e',2010,'GG','Guernsey','communications',741,'Telephones — main lines in use: 45,100
(2005)
Telephones — mobile cellular: 43,800
(2004)
Telephone system:
general assessment: NA
domestic: NA
international: 1 submarine cable
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (1 998)
Radios: NA
Television broadcast stations: l (1997)
Televisions: NA
Internet country code: .gg
Internet hosts: 156 (2008)
Internet Service Providers (ISPs): NA
Internet users: 36,000 (2005)','efe88f0b4b19e59dfba82d6769e10255e3027ba0290715a01af09f81bbcfb9ea','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3617cf4c4dc45492a89e292efcc0cdda6113732680432da07a431102330ce68b',2010,'GN','Guinea','communications',746,'Telephones— main lines in use: 26,300
(2005)
Telephones— mobile cellular: 189,000
(2005)
Telephone system: general assessment:
inadequate system of open-wire lines, small
radiotelephone communication stations,
and new microwave radio relay system
domestic: Conakry reasonably well served;
coverage elsewhere remains inadequate and
large companies tend to rely on their own
systems for nationwide links; combined
fixed and mobile-cellular teledensity is
about 2 per 1 00 persons
international: country code— 224; satellite
earth station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 0, FM 5,
shortwave 3 (2006)
Radios: 357,000 (1997)
Television broadcast stations: 6 (2001)
Televisions: 85,000 (1997)
Internet country code: gn
Internet hosts: 16 (2008)
Internet Service Providers (ISPs): 4
(2001)
Internet users: 50,000 (2006)','2f8b9d0f0b196b391e9e2ddb7d135a3ea84ef10914be5c9af6e26371c670b153','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06ed386d9bbb5d10fb2e6a0a185f0b448bcbdd9fded5113421a030be31508268',2010,'GW','Guinea-Bissau','communications',755,'Telephones— main lines in use: 4,600
(2007)
Telephones — mobile cellular: 296,200
(2007)
Telephone system: general assessment:
small system
domestic: combination of microwave radio
relay, open-wire lines, radiotelephone, v
and cellular communications; fixed-line
teledensity less than 1 per 100 persons;
mobile-cellular teledensity reached 20 per
100 in 2007
international: country code— 245
Radio broadcast stations: AM 1 (trans¬
mitter out of service), FM 4, shortwave 0
(2001)
Radios: 49,000 (1997)
Television broadcast stations: 1 (2007)
Televisions: NA
Internet country code: gw
Internet hosts: 82 (2008)
Internet Service Providers (ISPs): 2
(2002)
Internet users: 37,000 (2006)','fe82a7d88cbefa8f069f67d10e5af469a6d942f4eebaf059cf104c928b9c9be7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41193647b54903cd50136e0f7ff94d76982a7919ab3e1ceb89348e084bd281d5',2010,'GY','Guyana','communications',763,'Telephones— main lines in use: 110,100
(2005)
Telephones — mobile cellular: 281,400
(2005)
Telephone system: general assessment: fair
system for long-distance service
domestic: microwave radio relay network
for trunk lines; fixed-line teledensity is
about 15 per 100 persons; many areas still
lack fixed-line telephone services; mobile-
cellular teledensity reached 37 per 100
persons in 2005
international: country code— 592; tropo¬
spheric scatter to Trinidad; satellite earth
station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 3, FM 3,
shortwave 1 (1998)
Radios: 420,000 (1997)
Television broadcast stations: 3 (1 public
station; 2 private stations which relay US
satellite services) (1997)
Televisions:
46,000 (1997)
Internet country code: gy
Internet hosts: 6,218 (2008)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 190,000 (2007)','7c2c98527cd05cf882d722f8e8bc95cf24e0c668cca1d59506e8606df8fa08c2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8549a4f51ee49f8ea8978fefe1fc1a89b96e1b4e0d0d7832b7f5cb33f1cbb91',2010,'HT','Haiti','communications',770,'Telephones — main lines in use: 108,300
(2007)
Telephones — mobile cellular: 2.5 million
(2007)
Telephone system: general assessment: tele¬
communications infrastructure is among
the least developed in Latin America and
299
THE CIA WORLD FACTBOOK
die Caribbean; domestic facilities barely
adequate; international facilities slightly
better; mobile-cellular telephone services are
expanding rapidly due, in part, to the intro¬
duction of low-cost GSM phones in 2006
domestic: coaxial cable and microwave
radio relay trunk service
international: country code— 509; satellite
earth station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 41, FM
26, shortwave 0 (1999)
Radios: 415,000 (1997)
Television broadcast stations: 2 (plus a
cable TV service) (1997)
Televisions: 38,000 (1997)
Internet country code: .ht
Internet hosts: 7 (2008)
Internet Service Providers (ISPs):
3 (2000)
Internet users: 1 million (2007)
Airports: 14 (2008)
Airports— with paved runways:
total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2008)
Airports— with unpaved runways:
total: 10
914 to 1,523 m: 1
under 914 m: 9 (2008)
Roadways: total 4,160 km
paved: 1,011 km
unpaved : 3,149 km (2000)
Ports and terminals: Cap Haitien
Military branches: no regular military
forces— small Coast Guard; the regular
Haitian Armed Forces (FAdH)— Army,
Navy, and Air Force— have been demo¬
bilized but still exist on paper until or
unless they are constitutionally abolished
(2009)
Manpower available for military
service: males age 16-49: 2,047,083
females age 16-49: 2,047,953 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,518,840
females age 16-49: 1,530,043 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually:
male: 108,444
female: 106,243 (2009 est.)
Military expenditures: 0.4% of GDP
(2006)','325e80c799828cdff221aba46203cbed2046b62681cbcc26109fdb56dea76fef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2de16e4e7863cd6634af8451cc95fde78876726b9ee4596805e5b3b2f58a6f6b',2010,'HM','Heard Island and McDonald Islands','communications',775,'Internet country code: hm
Ports and terminals: none; offshore
anchorage only
Telephones — main lines in use:
5,120 (2005)
Telephone system: general assessment:
automatic digital exchange
domestic: connected via fiber optic cable to
Telecom Italia network
international: country code— 39; uses Italian
system
Radio broadcast stations: AM 5, FM 3,
shortwave 5 (2008)
Radios: NA
Television broadcast stations: 1 (2008)
Televisions: NA
Internet country code: va
Internet hosts: 55 (2008)
Internet Service Providers (ISPs): NA
Internet users: 93 (2000)','0158c9d517dd966dc56a032e37b0994f240f273a4d64e5f3071a9dac053139cd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7407fd453a80f2174e3b5b46458e684654fc1f4d21b743ec8561c68a55e27075',2010,'HN','Honduras','communications',783,'Telephones — main lines in use: 821,200
(2007)
Telephones— mobile cellular: 4.185
million (2007)
Telephone system: general assessment: tele¬
communications infrastructure is among
the least developed in Latin America;
fixed-line connections are limited; multiple
providers of mobile-cellular services
domestic: beginning in 2003, private sub¬
operators allowed to provide fixed-lines
in order to expand telephone coverage;
fixed-line teledensity has increased to
about 10 per 100 persons; mobile-cellular
telephone service has been increasing
rapidly and subscribership in 2007
approached 60 per 100 persons
international: country code— 504; landing
point for both the Americas Region Carib¬
bean Ring System (ARCOS-1) and the
MAYA-1 fiber optic submarine cable system
that together provide connectivity to South
and Central America, parts of the Carib¬
bean, and the US; satellite earth stations— 2
Intelsat (Adantic Ocean); connected to
Central American Microwave System
Radio broadcast stations: AM 241, FM
53, shortwave 12 (1998)
Radios: 2.45 million (1997)
Television broadcast stations: ll (plus
17 repeaters) (1997)
Televisions: 570,000 (1997)
Internet country code: hn
Internet hosts: 13,370 (2008)
Internet Service Providers (ISPs):
8 (2000)
Internet users: 424,200 (2007)','51f1fd79083c23b9e5a271b48cf3e9faff03a61a34a0588d1ad047edb7552f60','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18f0e119bc97162f88682a81af48aceabf38db63b3864448ae3588ca32ee858c',2010,'HK','Hong Kong','communications',792,'Telephones — main lines in use: 3.875
million (2007)
Telephones— mobile cellular: 10.55
million (2007)
Telephone system: general assessment:
modern facilities provide excellent domestic
and international services
domestic: microwave radio relay links and
extensive fiber-optic network
international: country code— 852; multiple
international submarine cables provide
connections to Asia, US, Australia, the
Middle East, and Western Europe; satellite
earth stations— 3 Intelsat (1 Pacific Ocean
and 2 Indian Ocean); coaxial cable to
Guangzhou, China
Radio broadcast stations: AM 6, FM 10,
shortwave 0 (2008)
Radios: 4.45 million (1997)
Television broadcast stations: 2 (2 TV
networks, each broadcasting on 2 chan¬
nels) (2008)
Televisions:
1.84 million (1997)
Internet country code: hk
Internet hosts: 817,766 (2008)
Internet Service Providers (ISPs): 17
(2000)
Internet users: 3.961 million (2007)
Telephones— main lines in use: 177,851
(2008)
Telephones— mobile cellular: 856,200
(2008)
Telephone system: general assessment :
fairly modern communication facilities
maintained for domestic and international
services
domestic: termination of monopoly over
mobile-cellular telephone services in 2001
spurred sharp increase in subscriptions
with mobile-cellular teledensity approaching
190 per 100 persons in 2008; fixed-line
subscribership appears to have peaked and
is now in decline
international: country code— 853; landing
point for the SEA-ME-WE-3 submarine
cable network that provides links to Asia,
the Middle East, and Europe; HF radiotele¬
phone communication facility; satellite earth
station— 1 Intelsat (Indian Ocean) (2008)
Radio broadcasf stations: AM 1, FM 2,
shortwave 0 (2008)
Radios: 160,000 (1997)
Television broadcasf stations: l (2008)
Televisions: 49,000 (1997)
Internet country code: mo
Internet hosts: 263 (2008)
MACEDONIA
embargo and the two countries agreed to
normalize relations. The United States
began referring to Macedonia by its consti¬
tutional name, Republic of Macedonia, in
2004 and negotiations continue between
Greece and Macedonia to resolve the name
issue. Some ethnic Albanians, angered by
perceived political and economic inequities,
launched an insurgency in 2001 that even¬
tually won the support of the majority of
Macedonia’s Albanian population and led
to the internationally brokered Framework
Agreement, which ended the fighting by
establishing a set of new laws enhancing
the rights of minorities. Fully implementing
the Framework Agreement and stimu¬
lating economic growth and development
continue to be challenges for Macedonia,
although progress has been made on both
fronts over the past several years.','a64d24f8ac15f15c607d4bac541fec11ab796625a96c802bd978e00d4aef8926','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcfa324303f2d23617b8f43dc900e7ea213b0d255686e070aeb0102bee771fc4',2010,'HU','Hungary','communications',800,'Telephones — main lines in use: 3.251
million (2007)
Telephones — mobile cellular: 11.03
million (2007)
Telephone system: general assessment: the
telephone system has been modernized
and is capable of satisfying all requests for
telecommunication service
domestic: the system is digitalized and
highly automated; trunk services are
carried by fiber-optic cable and digital
microwave radio relay; a program for
fiber-optic subscriber connections was
initiated in 1996; competition among
mobile-cellular service providers has led
to a sharp increase in the use of mobile
cellular phones since 2000 and a decrease
in the number of fixed-line connections
international: country code— 36; Hungary
has fiber-optic cable connections with all
neighboring countries; die international
switch is in Budapest; satellite earth
stations— 2 Intelsat (Atlantic Ocean and
Indian Ocean regions), 1 Inmarsat, 1 very
small aperture terminal (VSAT) system of
ground terminals
Radio broadcasf stations: AM 5, FM 90,
shortwave 1 (2008)
Radios: 7.01 million (1997)
Television broadcast stations: 95 (2008)
Televisions: 4.42 million (1997)
Internet country code: bu
Internet hosts: 1.879 million (2008)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 4.2 million (2007)','d7346addea9b533e88aeed015435934dd38480e76399cbb072f7184f20343b55','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83ce9ab6fc91262c1d72ea05e3a2769cad98b4424a2bc0324cb4642902fa25a4',2010,'IS','Iceland','communications',809,'Telephones— main lines in use: 186,700
(2007)
Telephones— mobile cellular: 347,500
(2007)
Telephone system: general assessment: tele¬
communications infrastructure is modern
and fully digitized, with satellite-earth
stations, fiber-optic cables, and an extensive
broadband network
domestic: liberalization of die telecommuni¬
cations sector beginning in the late 1990s
has led to increased competition especially
in the mobile services segment of the market
international: country code— 354; the
CANTATA and FARICE-1 submarine
cable systems provide connectivity to
Canada, the Faroe Islands, UK, Denmark,
and Germany; a planned new section of
the Fhbernia-Atlantic submarine cable will
provide additional connectivity to Canada,
US, and Ireland; satellite earth stations— 2
Intelsat (Atlantic Ocean), 1 Inmarsat
(Atlantic and Indian Ocean regions);
note— Iceland shares the Inmarsat earth
station with the other Nordic countries
(Denmark, Finland, Norway, and Sweden)
Radio broadcast stations: AM 3, FM
about 70, shortwave 1 (2008)
Radios: 260,000 (1997)
Television broadcast stations: 14 (plus
156 repeaters) (1997)
Televisions: 98,000 (1997)
Internet country code: is
Internet hosts: 263,980 (2008)
InternetService Providers(ISPs): 20(2001 )
Internet users: 202,300 (2007)','cd3105e7ffd1c40261574b55365415835d69cf65288b691c9ba15c0830261680','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fc93cc6e0b8c9d3ee2917bd6e86776324d45358d206d80abd7cd9a29434b226',2010,'IN','India','communications',817,'Telephones — main lines in use: 37.75
million (2009)
Telephones — mobile cellular: 362.3
million (2009)
Telephone system: general assessment:
recent deregulation and liberalization of
telecommunications laws and policies
have prompted rapid growth; local and
long distance service provided throughout
all regions of the country, with services
primarily concentrated in the urban areas;
steady improvement is taking place wida
the recent admission of private and private-
public investors, but combined fixed and
mobile telephone density remains low
at about 35 for each 100 persons nation¬
wide and much lower for persons in rural
areas; extremely rapid growth in cellular
service with modest declines in fixed lines
domestic: mobile cellular service introduced
in 1 994 and organized nationwide into four
metropolitan areas and 19 telecom circles
each with multiple private service providers
and one or more state-owned service
providers; in recent years significant trunk
capacity added in the form of fiber-optic cable
and one of the world’s largest domestic satel¬
lite systems, the Indian National Satellite
system (INSAT), with 6 satellites supporting
33,000 very small aperture terminals (VSAT)
international: country code— 91; a number of
major international submarine cable systems,
including Sea-Me-We-3 with landing sites at
Cochin and Mumbai (Bombay), Sea-Me-
We-4 with a landing site at Chennai, Fiber-
Optic Link Around the Globe (FLAG) with
a landing site at Mumbai (Bombay), South
Africa— Far East (SAFE) with a landing site
at Cochin, the i2i cable network linking to
Singapore with landing sites at Mumbai
(Bombay) and Chennai (Madras), and Tata
Indicom linking Singapore and Chennai
(Madras), provide a significant increase
in the bandwidth available for both voice
and data traffic; satellite earth stations— 8
Intelsat (Indian Ocean) and 1 Inmarsat
(Indian Ocean region); 9 gateway exchanges
operating from Mumbai (Bombay),
New Delhi, Kolkata (Calcutta), Chennai
(Madras), Jalandhar, Kanpur, Gandhinagar,
Hyderabad, and Ernakulam (2008)
Radio broadcast stations: AM 153, FM
91, shortwave 68 (1998)
Radios: 116 million (1997)
Television broadcast stations: 562 (1997)
Televisions: 63 million (1997)
Internet country code: in
Internet hosts: 2.707 million (2008)
Internet Service Providers (ISPs): 43
(2000)
Internet users: 80 million (2007)','9def15360d03163b5df406022b16cf094e06a3a3225789b39c55777ebce9a65b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3684dafcde5f965aa99f9b8c2e84f9556efd40f8dff9cec4887d12c1e655936',2010,'ID','Indonesia','communications',823,'Telephones— main lines in use: 17.828
million (2007)
Telephones— mobile cellular: 81.835
million (2007)
Telephone system: general assessment:
domestic service fair, international service
good
domestic: interisland microwave system
and HF radio police net; domestic satellite
communications system; coverage provided
by existing network has been expanded by
use of over 200,000 telephone kiosks many
located in remote areas; mobile cellular
subscribership growing rapidly
international: country code— 62; landing
point for both die SEA-ME-WE-3 and
SEA-ME-WE-4 submarine cable networks
that provide links throughout Asia, the
Middle East, and Europe; satellite earth
stations— 2 Intelsat (1 Indian Ocean and 1
Pacific Ocean)
Radio broadcast stations: AM 678, FM
43, shortwave 82 (1998)
Radios: 31.5 million (1997)
Television broadcast stations: 54 local
TV stations (11 national TV networks;
each with its group of local transmitters)
(2006)
Televisions: 13.75 million (1997)
Internet country code: id
Internet hosts: 753,200 (2008)
Internet Service Providers (ISPs): 24
(2000)
Internet users: 13 million (2007)
Telephones— main lines in use: 23.835
million (2007)
Telephones— mobile cellular: 29.77
million (2007)
Telephone system: general assessment:
currendy being modernized and expanded
with the goal of not only improving the
efficiency and increasing the volume of
the urban service but also bringing tele¬
phone service to several thousand villages,
not presendy connected
domestic: the addition of new fiber cables
and modern switching and exchange
systems installed by Iran’s state-owned
telecom company have improved and
expanded the main line network gready;
main line availability has more than
doubled to nearly 24 million lines since
2000; additionally, mobile service has
increased dramatically serving nearly 30
million subscribers in 2007
international: country code— 98; subma¬
rine fiber-optic cable to UAE with access
to Fiber-Optic Link Around the Globe
(FLAG); Trans-Asia-Europe (TAE) fiber¬
optic line runs from Azerbaijan through the
328
I RAQ
northern portion of Iran to Turkmenistan
with expansion to Georgia and Azerbaijan;
HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan,
Turkmenistan, Syria, Kuwait, Tajikistan,
and Uzbekistan; satellite earth stations— 1 3
(9 Intelsat and 4 Inmarsat) (2007)
Radio broadcast stations: AM 72, FM 6,
shortwave 5 (1998)
Radios: 17 million (1997)
Television broadcast stations: 29 (plus
450 repeaters) (1997)
Televisions: 4.61 million (1997)
Internet country code: ir
Internet hosts: 2,860 (2008)
Internet Service Providers (ISPs): 100
(2002)
Internet users: 23 million (2007)','322aabb155c4fbcd400581d5786510ae7314708427911d52105ac9933bea1b94','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f256976a5a2eb2d8327c244e71a37dadf0487e89586981f59f0d04a197383533',2010,'IQ','Iraq','communications',831,'Telephones— main lines in use: 1.547
million (2005)
Telephones — mobile cellular: 14.021
million (2007)
Telephone system: general assessment:
the 2003 liberation of Iraq severely
disrupted telecommunications throughout
Iraq including international connec¬
tions; widespread government efforts
to rebuild domestic and international
communications through fiber optic links
are in progress; the mobile cellular market
has expanded rapidly with an estimated 14
million current users in 2007
domestic: repairs to switches and lines
destroyed during 2003 continue; addi¬
tional switching capacity is improving
access; cellular service is available and
centered on 3 GSM networks which are
being expanded beyond their regional
roots, improving country-wide connec¬
tivity; wireless local loop licenses have been
issued with the hope of overcoming the
lack of fixed-line infrastructure
international: country code— 964; satellite
earth stations— 4 (2 Intelsat— 1 Adantic
Ocean and 1 Indian Ocean, 1 Intersputnik—
Adantic Ocean region, and 1 Arabsat
(inoperative)); local microwave radio relay
connects border regions to Jordan, Kuwait,
Syria, and Turkey; planned international
fiber-optic connections to Iran (terrestrial)
with a link to the Fiber-Optic Link Around
the Globe (FLAG) submarine fiber-optic
cable (2007)
Radio broadcast stations: 52 (station
frequency types NA) (2008)
Radios: 4.85 million (1997)
Television broadcast stations: 47 (2008)
Televisions: 1.75 million (1997)
332','148af22cee55152cb20128e717d1584715d675183e6561e46a4a58cc5448434d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd0f390d99ab91a97171ef29ef89f2a34f77d22cbe86d105b0e0bb14c3359b89',2010,'IE','Ireland','communications',832,'Internet country code: iq
Internet hosts: 3 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 54,000 (2007)
Telephones— main lines in use: 2.112
million (2007)
Telephones— mobile cellular: 4.94
million (2007)
Telephone system: general assessment:
modern digital system using cable and
microwave radio relay
domestic: system privatized but dominated
by ■ former state monopoly operator;
increasing levels of broadband access
international: country code— 353; landing
point for the Fhbernia-Adantic subma¬
rine cable with links to the US, Canada,
and UK; satellite earth station— 1 Intelsat
(Atlantic Ocean)
Radio broadcast stations: AM 9, FM
106, shortwave 0 (1998)
Radios: 2.55 million (1997)
Television broadcast stations: 4 (many
repeaters); (projected digital broadcasting
scheduled to be launched in 2009) (2008)
Televisions: 1.82 million (2001)
Internet country code: ie
Internet hosts: 1.242 million (2008)
Internet Service Providers (ISPs): 22
(2000)
Internet users: 1.708 million (2007)','da82cec717ac90bacaedc92efc4afa58171ca23bb407bad56762b8d7bd594109','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ae34f99c41a2241f1f97dd70c3b52eaf73fb2e1ef484324f44818759a771f19',2010,'IM','Isle of Man','communications',843,'Telephones— main lines in use: 51,000
(1999)
Telephone system: general assessment: NA
domestic: landline, telefax, mobile cellular
telephone system
international: fiber-optic cable, microwave
radio relay, satellite earth station, subma¬
rine cable
Radio broadcast stations: AM l, FM 1,
shortwave 0 (1 998)
Radios: NA
Television broadcast stations: 0 (receives
broadcasts from the UK and satellite)
(1999)
Televisions: 27,490 (1999)
Internet country code: im
Internet hosts: 426 (2008)
Internet Service Providers (ISPs): NA
Internet users: NA','e64d97329e7fc8266c9552ff19700af9d955a08cb5b57e8b9bc149e5d5ae4827','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d51f1947b8416cf673f005ca50a1454cde58c9aca11bb3dc0702df449b2783c',2010,'IL','Israel','communications',852,'Telephones — main lines in use: 3.005
million (2006)
Telephones— mobile cellular: 8.902
million (2007)
Telephone system: general assessment: most
highly developed system in the Middle East
although not the largest
domestic: good system of coaxial cable
and microwave radio relay; all systems
are digital; four privately-owned mobile-
cellular service providers with countrywide
coverage; mobile-cellular teledensity is 140
per 100 persons
international: country code— 972; submarine
cables provide links to Europe, Cyprus,
and parts of the Middle East; satellite earth
stations— 3 Intelsat (2 Atlantic Ocean and 1
Indian Ocean) (2007)
Radio broadcast stations: AM 23, FM
15, shortwave 2 (1998)
Radios: 3.07 million (1997)
Television broadcast stations: 17 (plus
36 repeaters) (1995)
Televisions: 1.69 million (1997)
Internet country code: il
Internet hosts:
1.415 million (2008)
Internet Service Providers (ISPs): 21
(2000)
Internet users: 2 million (2007)','85b3344dfba3cf3f199ab761434a0fe6f87540dcf0fe93556a73a4a78a832105','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3858376e258cc8c34d4bf932a5d07b50879ec46cb57ae47df32e86d8c3034631',2010,'JM','Jamaica','communications',860,'Industrial production growth rate: 1.5%
(2008 est.)
Electricity— production: 7.04 billion kWh
(2006 est.)
Electricity — consumption: 6.1 billion
kWh (2006 est.)
Electricity— exports: 0, kWh (2007 est.)
Electricity— imports: 0 kWh (2007 est.)
Electricity— production by source:
fossil fuel: 96.8%
hydro: 1.8%
nuclear: 0%
other: 1.4% (2001)
Oil — production: 0 bbl/day (2005 est.)
Oil— consumption: 73,370 bbl/day (2006
est.)
Oil— exports: 1,535 bbl/day (2005)
Oil— imports: 71,280 bbl/day (2005)
Oil— proved reserves: 0 bbl (l January
2006 est.)
Natural gas — production: Ocum (2007
est.)
Natural gas — consumption: 0 cu m (2007
est.)
Natural gas — exports: Ocum (2007 est.)
Natural gas— imports: Ocum (2007 est.)
Natural gas— proved reserves: 0 cu m (l
January 2006 est.)
Current account balance: $2,448 billion
(2008 est.)
Exports: $2,569 billion f.o.b. (2008 est.)
Exports — Commodities: alumina, bauxite,
sugar, rum, coffee, yams, beverages, chemi¬
cals, wearing apparel, mineral fuels
Exports— partners: US 37.2%, Canada
15%, UK 9.7%, Netherlands 9.1% (2007)
Imports: $7,191 billion f.o.b. (2008 est.)
Imports — commodities: food and other
consumer goods, industrial supplies, fuel,
parts and accessories of capital goods,
machinery and transport equipment,
construction materials
Imports — partners: US 37.2%, Trinidad
and Tobago 14.5%, Grenada 9.7%, Vene¬
zuela 8.3%, Brazil 4.2% (2007)
Reserves of foreign exchange and gold:
$2.05 billion (31 December 2008 est.)
Debt — external: $10.38 billion (31
December 2008 est.)
Currency (code): Jamaican dollar (JMD)
Currency code: JMD
Exchange rates: Jamaican dollars (JMD)
per US dollar— 72.236 (2008 est.), 69.034
(2007), 65.768 (2006), 62.51 (2005),
61.197 (2004)
Telephones — main lines in use: 342,000
(2006)
Telephones— mobile cellular: 2.495
million (2006)
Telephone system: general assessment: fully
automatic domestic telephone network
domestic: the 1999 agreement to open the
market for telecommunications services
resulted in rapid growth in mobile-cellular
telephone usage while the number of
fixed-lines in use has declined; combined
mobile-cellular teledensity now exceeds
100 per 100 persons
international: country code— 1-876; the
Fibralink submarine cable network provides
enhanced delivery of business and broad¬
band traffic and is linked to the Americas
Region Caribbean Ring System (ARCOS-
1) submarine cable in the Dominican
Republic; the link to ARCOS-1 provides
seamless connectivity to US, parts of the
Caribbean, Central America, and South
America; satellite earth stations— 2 Intelsat
(Atlantic Ocean) (2006)
Radio broadcast stations: AM 10, FM
13, shortwave 0 (1998)
Radios: 1.215 million (1997)
Television broadcast stations: 7 (1997)
Televisions: 460,000 (1997)
Internet country code: jm
Internet hosts: 1,292 (2008)
Internet Service Providers (ISPs): 21
(2000)
Internet users: 1 .5 million (2007)
Radio broadcast stations: NA, note— there
is one radio and meteorological station
(1998)
Internet Service Providers (ISPs): 13
(Jan Mayen and Svalbard) (2000)','90ede25720df030ab9875c37414e45168bb9b0e5e882a706dedb0a93450239b8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec100bd2a746f8c7c7590f5659d1d199078ca217793728cb3cb8f0f19576512d',2010,'JP','Japan','communications',871,'Telephones— main lines in use: 51.232
million (2007)
Telephones— mobile cellular: 107.339
million (2007)
Telephone system: general assessment:
excellent domestic and international
service
domestic: high level of modem technology
and excellent service of every kind
international: country code— 81; numerous
submarine cables provide links throughout
Asia, Australia, the Middle East, Europe,
and US; satellite earth stations— 5 Intelsat
(4 Pacific Ocean and 1 Indian Ocean), 1
Intersputnik (Indian Ocean region), and
1 Inmarsat (Pacific and Indian Ocean
regions
Radio broadcast stations: AM 215 (plus
370 repeaters), FM 89 (plus 485 repeaters),
shortwave 21 (2001)
Radios: 120.5 million (1997)
Television broadcast stations: 211 (plus
7,341 repeaters); in addition, US Forces
are served by 3 TV stations and 2 TV cable
services (1999)
Televisions: 86.5 million (1997)
Internet country code: jp
Internet hosts: 39.909 million (2008)
Internet Service Providers (ISPs): 73
(2000)
Internet users: 88.11 million (2007)','84ce2a5e61f80059d187dd7a98db67c0a0bd992a9e230e0d054b1826740219da','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b4fa376ac535acab9f7cd25a582a857116a31d7f534fdfc02b5e6f58c00485c',2010,'JE','Jersey','communications',880,'Telephones— main lines in use: 73,900
(2001)
Telephones— mobile cellular: 83,900
(2004)
Telephone system: general assessment:
state owned, partially-competitive market;
increasingly modern, with some broad¬
band access
domestic: digital telephone system launch
announced in 2006 and currendy being
implemented
international: submarine cable connectivity
to Guernsey, the UK, and France (2008)
354','595a183d563514344c202884a7126f271d901416fc9591bc0a3951214f996df1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ccba63d04c58d628282799b1301fa1f6d2ff8f8578bf535bad2c900a87049b2',2010,'JO','Jordan','communications',881,'Radio broadcast stations: AM NA, FM 1 ,
shortwave 0 (UK radio broadcasts carried
via local relays) (2008)
Radios: NA
Television broadcast stations: 2 (UK
television carried by local relays with a
switch to digital broadcasts scheduled for
2010) (2008)
Televisions: NA
Internet country code: je
Internet hosts: 190 (2008)
Internet Service Providers (ISPs): NA
Internet users: 27,000 (2005)
Telephones— main lines in use: 585,500
(2007)
Telephones— mobile cellular: 4.771
million (2007)
Telephone system: general assessment:
service has improved recendy with increased
use of digital switching equipment; micro¬
wave radio relay transmission and coaxial
and fiber-optic cable are employed on
trunk lines; growing mobile-cellular usage
in both urban and rural areas is reducing
use of fixed-line services; Internet penetra¬
tion remains modest and slow-growing
domestic: 1995 telecommunications law
opened all non-fixed-line services to private
competition; in 2005, monopoly over
fixed-line services terminated and the entire
telecommunications sector was opened
to competition; mobile-cellular usage is
increasing rapidly and teledensity reached
80 per 100 persons in 2007
international: country code— 962; landing
point for the Fiber-Optic Link Around the
Globe (FLAG) submarine cable network
that provides links to Asia, Middle East,
Europe; satellite earth stations— 33 (3
Intelsat, 1 Arabsat, and 29 land and mari¬
time Inmarsat terminals); fiber-optic cable
to Saudi Arabia and microwave radio relay
link with Egypt and Syria; participant in
Medarabtel (2007)
Radio broadcast stations: FM 31 (2007)
Radios: 1.66 million (1997)
Television broadcast stations: 22 (2007)
Televisions: 500,000 (1997)
Internet country code: jo
Internet hosts: 21,150 (2008)
Internet Service Providers (ISPs): 5
(2000)
Internet users: 1.127 million (2007)','ad83316e5c18b5757b4fa98a937cbe7e4428ad602409087395769d8a2402c189','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19534c3025e9d15da9658b53bfb2718b8aca8fe6175d2df141e95c20f26f427f',2010,'KZ','Kazakhstan','communications',896,'Telephones— main lines in use: 3.237
million (2007)
Telephones— mobile cellular: 12.588
million (2007)
Telephone system: general assessment:
inherited an outdated telecommunications
network from the Soviet era requiring
modernization
domestic: intercity by landline and micro¬
wave radio relay; number of fixed-line
connections is gradually increasing and
fixed-line teledensity is about 20 per 100
persons; mobile-cellular usage is increasing
rapidly and subscriptions now exceed 80
per 100 persons
international: country code— 7 ; international
traffic with other former Soviet republics
and China carried by landline and micro-
wave radio relay and with other countries
by satellite and by the Trans-Asia-Europe
(TAE) fiber-optic cable; satellite earth
stations— 2 Intelsat (2007)
Radio broadcasf sfafions: AM 60, FM
18, shortwave 9 (2008)
Radios: 6.47 million (1997)
Television broadcast stations: 12 (plus 9
repeaters) (1998)
Televisions: 3.88 million (1997)
Internet country code: kz
Internet hosts: 36,417 (2008)
Internet Service Providers (ISPs): 10 (with
their own international channels) (2001)
Internet users: 1.901 million (2006)','137ba36db2ec9f1aafc34930d42371990f4aa8a6851c3222ebe33831a37815db','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9ee2e6ace4fcfba1d497de4fc16487a09a118dbd898bf3fb5326f9431824ce2',2010,'KE','Kenya','communications',904,'Telephones — main lines in use: 264,800
(2007)
Telephones— mobile cellular: 11.44
million (2007)
Telephone system: general assessment:
inadequate; fixed-line telephone system
is small and inefficient; trunks are prima¬
rily microwave radio relay; business data
commonly transferred by a very small aper¬
ture terminal (VSAT) system
domestic: no recent growth in fixed-line
infrastructure and the sole provider,
Telkom Kenya, is slated for privatization;
multiple providers in the mobile-cellular
segment of the market fostering a boom in
mobile-cellular telephone usage
international: country code— 254; satellite
earth stations— 4 Intelsat
Radio broadcasf sfalions: AM 24, FM
18, shortwave 6 (2001)
Radios: 3.07 million (1997)
Television broadcast stations: 8 (2001)
Televisions: 730,000 (1997)
Internet country code: ke
Internet hosts: 27,376 (2008)
Internet Service Providers (ISPs): 65
(2001)
Internet users: 3 million (2007)','42309c8f85d3577976b4cd97e6bd7714680760ca58ddb1a86c07411646640e1e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7410203f491c22c3219d14584e679ede52b7a7f25b7ab8db7a934e714d975c7f',2010,'KI','Kiribati','communications',912,'Telephones — main lines in use: 4,500
(2002)
Telephones — mobile cellular: 700 (2005)
Telephone system: general assessment:
generally good quality national and inter¬
national service
domestic: wire line service available on
Tarawa and Kiritimati (Christmas Island);
connections to outer islands by HF/VHF
radiotelephone; wireless service available in
Tarawa since 1999
international: country code— 686; Kiribati is
being linked to the Pacific Ocean Coopera¬
tive Telecommunications Network, which
should improve telephone service; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 2,
shortwave 1 (may be inactive) (2002)
Radios: 17,000 (1997)
Television broadcast stations: l (possibly
inactive) (2002)
Televisions: 1,000 (1997)
Internet country code: ki
Internet hosts: 9 (2008)
Internet Service Providers (ISPs): l
(2000)
Internet users: 2,000 (2007)
Telephones— main lines in use: 1.18
million (2007)
Telephone system: general assessment:
inadequate system; currendy mobile
cellular telephone services are available in
Pyongyang only
domestic: fiberoptic links installed between
cities; telephone directories unavailable;
mobile cellular service, initiated in 2002,
suspended in 2004; Orascom Telecom,
an Egyptian company, launched mobile
service on December 15, 2008 for the
Pyongyang area only
international: country code— 850; satellite
earth stations— 2 (1 Intelsat— Indian Ocean,
1 Russian— Indian Ocean region); other
international connections through Moscow
and Beijing (2008)
Radio broadcast stations: AM 17
(including 11 stations of Korean Central
Broadcasting Station; North Korea has a
“national intercom” cable radio station
wired throughout the country that is a
significant source of information for the
average North Korean citizen; it is wired
into most residences and workplaces and
carries news and commentary), FM 14,
shortwave 14 (2006)
Radios: 3.36 million (1997)
Television broadcast stations: 4 (includes
Korean Central Television, Mansudae Tele¬
vision, Korean Educational and Cultural
Network, and Kaesong Television targeting
South Korea) (2003)
Televisions: 1.2 million (1997)
Internet country code: kp
Internet Service Providers (ISPs): 1
(2000)
Internet users: NA
Telephones— main lines in use: 23.905
million (2007)
Telephones— mobile cellular: 43.5
million (2007)
Telephone system: general assessment:
excellent domestic and international serv¬
ices featuring rapid incorporation of new
technologies
domestic: combined fixed-line and mobile-
cellular telephone subscribership roughly
140 per 100 persons; rapid assimilation
of a full range of telecommunications
technologies leading to a boom in e-
commerce
international: country code— 82; numerous
submarine cables provide links throughout
Asia, Australia, the Middle East, Europe,
and US; satellite earth stations— 66
Radio broadcast stations: AM 96, FM
322, shortwave 1 (2008)
Radios: 47.5 million (2000)
Television broadcast stations: 57 (plus
103 cable operators and 119 relay cable
operators) (2008)
Televisions:
15.9 million (1997)
Internet country code: kr
Internet hosts:
333,823 (2008)
Internet Service Providers (ISPs):
11 (2000)
Internet users: 35.59 million (2007)
Telephones— main lines in use: 106,300
(2006)
Telephones— mobile cellular: 562,000
(2006)','34793a1027005f8b29f66e97e9d6c54aaab596aa9d5b641b26600031f027e0ca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7ef025cc01f88d06c004224bec8fcb38d44a256d1f5b725403c6509348f4f20',2010,'KW','Kuwait','communications',921,'Telephones— main lines in use: 517,000
(2006)
Telephones — mobile cellular: 2.774
million (2007)
Telephone system: general assessment: the
quality of service is excellent
domestic: new telephone exchanges provide
a large capacity for new subscribers; trunk
traffic is carried by microwave radio relay,
coaxial cable, and open-wire and fiber-optic
cable; a cellular telephone system operates
throughout Kuwait, and the country is well
supplied with pay telephones
international: country code— 965; linked to
international submarine cable Fiber-Optic
Link Around the Globe (FLAG); linked to
Bahrain, Qatar, UAE via the Fiber-Optic
Gulf (FOG) cable; coaxial cable and micro-
wave radio relay to Saudi Arabia; satellite
earth stations— 6 (3 Intelsat— 1 Adantic
Ocean and 2 Indian Ocean, 1 Inmarsat—
Atlantic Ocean, and 2 Arabsat)
Radio broadcasf stations: AM 6, FM 11,
shortwave 1 (1998)
Radios: 1.175 million (1997)
Television broadcast stations: 13 (plus
several satellite channels) (1997)
Televisions: 875,000 (1997)
Internet country code: kw
Internet hosts: 3,289 (2008)
Internet Service Providers (ISPs): 3
(2000)
Internet users: 900,000 (2007)','f2bf27b0fbbc06983fa8bb64234f5f26a1fa65a469c6b7cd7d3af8a73ead42a4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d213e8a08efab1b284421b372f2e326e6e8ece6a7277d11a05fd96c867aac277',2010,'KG','Kyrgyzstan','communications',930,'Telephones— main lines in use: 482,100
(2007)
Telephones— mobile cellular: 2.152
million (2007)
Telephone system: general assessment:
telecommunications infrastructure is
being upgraded; loans from the European
Bank for Reconstruction and Develop¬
ment (EBRD) are being u£ed to install
a digital network, digital radio-relay
stations, and fiber-optic links
domestic: fixed line penetration remains
low and concentrated in urban areas;
multiple mobile cellular service providers
with growing coverage; mobile cellular
subscribership reached 40 per 100 persons
in 2007
international: country code— 996; connec¬
tions with other CIS countries by land¬
line or microwave radio relay and with
other countries by leased connections with
Moscow international gateway switch and
by satellite; satellite earth stations— 2 (1
Intersputnik, 1 Intelsat); connected inter¬
nationally by the Trans-Asia-Europe (TAE)
fiber-optic line (2007)
Radio broadcast stations: AM 3 (plus 10
repeater stations), FM 23, shortwave NA
(2007)
Radios: 520,000 (1997)
Television broadcast stations: 8 (2
countrywide and 6 regional stations; state-
owned); note— there are about 20 private
TV stations, most of which rebroadcast
other channels (2007)
Televisions: 210,000 (1997)
Internet country code: kg
internet hosts: 56,905 (2008)
Internet Service Providers (ISPs): NA
Internet users: 750,000 (2007)','e3f73251fdf24ba81405ca28e7fe36d9782b278e117c3f14edef12362680a946','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7998a5d3cc36e893d1a6651bc6dd5e1ab10291a6320eb8be62d4266eae079d24',2010,'TH','Thailand','communications',937,'Telephones — main lines in use:
94,800 (2007)
Telephones— mobile cellular: 1.478
million (2007)
Telephone system: general assessment:
service to general public is poor but
improving; the government relies on a
radiotelephone network to communicate
with remote areas
domestic: multiple service providers; mobile
cellular usage growing rapidly; combined
fixed-line and mobile-cellular subscriber-
ship about 25 per 100 persons
international: country code— 856; satel¬
lite earth station— 1 Intersputnik (Indian
Ocean region) (2007)
Radio broadcast stations: AM 7, FM 14,
shortwave 2 (2006)
Radios: 730,000 (1997)
Television broadcast stations: 7 (includes
1 station relaying Vietnam Television from
Hanoi) (2006)
Televisions: 52,000 (1997)
Internet country code: la
Internet hosts: 1,015 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 100,000 (2007)
Telephones — main lines in use: 7.024
million (2007)
Telephones— mobile cellular: 51.377
million (2007)
672','de2833b636c14e6b8e132576015938aee7343f94cf2de9a2956e7105c30c78c2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ec4c020a1c5441841e138088e30560df7c3d573766c613d7c0362e00b8633e',2010,'LV','Latvia','communications',945,'Telephones — main lines in use: 644,000
(2007)
Telephones — mobile cellular: 2.217
million (2007)
Telephone system: general assessment:
recent efforts focused on bringing competi¬
tion to the telecommunications sector; the
number of fixed lines is decreasing as wire¬
less telephone service expands
domestic: number of telecommunications
operators has grown rapidly since the
fixed-line market opened to competition
in 2003; combined fixed-line and mobile-
cellular subscribership is roughly 125 per
100 persons
international: country code— 371; the
Latvian network is now connected via
fiber optic cable to Estonia, Finland, and
Sweden (2007)
Radio broadcast stations: AM 8, FM 62,
shortwave 1 (2008)
Radios: 1.76 million (1997)
Television broadcast stations: 37 (plus
31 repeaters) (2008)
Televisions: 1.22 million (1997)
Internet country code: lv
Internet hosts: 220,082 (2008)
lnternetServiceProviders(ISPs):4l(200l)
Internet users: 1.177 million (2007)','424baffb7533f317555af4133261f8c6a04ee9be48dc7c05cebcb17ff7eea4ef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12e333756c215f197e7e581d06e6e856357478d442674c547d7c6b8514ec3124',2010,'LB','Lebanon','communications',950,'Telephones— main lines in use: 681,400
(2006)
Telephones— mobile cellular: 1.26
million (2007)
Telephone system: general assessment:
repair of the telecommunications system,
severely damaged during the civil war, now
complete
domestic: two wireless networks provide
good service; combined fixed-line and
mobile-cellular subscribership 50 per 100
persons
international: country code— 961; subma¬
rine cable links to Cyprus, Egypt, and
Syria; satellite earth stations— 2 Intelsat
(1 Indian Ocean and 1 Adantic Ocean);
coaxial cable to Syria (2007)
Radio broadcast stations: AM 20, FM
32 (plus about a dozen unlicensed stations
operating), shortwave 4 (2007)
Radios: 2.85 million (1997)
Television broadcast stations: 15 (plus 5
repeaters) (1 995)
Televisions: 1.18 million (1997)
Internet country code: lb
Internet hosts: 36,681 (2008)
Internet Service Providers (ISPs): 22
(2000)
Internet users: 950,000 (2006)','4136de85e03ce1217bb61287a3623d294eebebaf362dea82c9c83680435e80c6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a328e0c7f78389b86747db9762ad25eb5fd47cc07b261861e4a6de9000db6076',2010,'LR','Liberia','communications',958,'Telephones — main lines in use: 53,100
(2006)
Telephones— mobile cellular: 456,000
(2007)
Telephone system: general assessment: rudi¬
mentary system consisting of a modest but
growing number of landlines, a small micro¬
wave radio relay system, and a small radio¬
telephone communication system; mobile-
cellular telephone system is expanding
domestic: privatized in 2001, Telecom
Lesotho tasked with providing an addi¬
tional 50,000 fixed-line connections within
five years, a target not met; mobile-cellular
service is expanding with a subscribersbip
approaching 25 per 100 persons; rural
services are scant
international: country code— 266; satellite
earth station— 1 Intelsat (Atlantic Ocean)
(2007)
Radio broadcast stations: AM 1, FM 3,
shortwave 1 (2007)
Radios: NA (2002)
Television broadcast stations: l (2007)
Televisions: NA
Internet country code: Is
Internet hosts: 83 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 70,000 (2007)
did much to promote foreign investment
and to bridge the economic, social, and
political gaps between the descendents of
the original settlers and the inhabitants
of the interior. In 1980, a military coup
led by Samuel DOE ushered in a decade
of authoritarian rule. In December 1989,
Telephones— main lines in use: 6,900
(2002)
Telephones— mobile cellular: 563,000
(2007)
Telephone system: general assessment:
the limited services available are found
almost exclusively in the capital Monrovia;
coverage extended to a number of other
towns and rural areas by four mobile''
cellular network operators
domestic: fixed line service stagnant
and extremely limited; mobile-cellular
subscription base growing and teledensity
approaching 20 per 100 persons
international: country code— 231; satellite
earth station— 1 Intelsat (Atlantic Ocean)
(2007)
Radio broadcast stations: AM 0, FM 10,
shortwave 2 (2007)
Radios: 790,000 (1997)
Television broadcast stations: 4 (plus 4
repeaters) (2007)
Televisions: 70,000 (1997)
Internet country code: lr
Internet hosts: 7 (2008)
Internet Service Providers (ISPs): 2 (2001 )
Internet users: 1 ,000 (2002)','38c8de353d0e7ba99aa44548760bbc38b70fb702103a70f8779aa5c3d156ac7e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23cf95348e7b45c07573696a7f3623f5de3ba00b0f3f50f404e01bbf38c3a3e9',2010,'LY','Libya','communications',969,'Telephones — main lines in use: 852,300
(2005)
Telephones — mobile cellular: 4.5 million
(2007)
Telephone system: general assessment:
telecommunications system is state-owned
and service is poor, but investment is being
made to upgrade; state retains monopoly in
fixed-line services; mobile cellular telephone
system became operational in 1 996; multiple
providers for a mobile telephone system that
is growing rapidly; combined fixed line and
mobile telephone density approached 90
telephones per 100 persons in 2007
domestic: microwave radio relay, coaxial cable,
cellular, tropospheric scatter, and a domestic
satellite system with 1 4 earth stations
international: country code— 218; satellite
earth stations— 4 Intelsat, NA Arabsat, and
NA Intersputnik; submarine cables to France
and Italy; microwave radio relay to Tunisia
and Egypt; tropospheric scatter to Greece;
participant in Medarabtel (2007)
Radio broadcast stations: AM 16, FM 3,
shortwave 3 (2001)
Radios: 1.35 million (1997)
Television broadcast stations: 1 2 (plus 1
repeater) (1999)
Televisions: 730,000 (1997)
Internet country code: ly
Internet hosts: 31 (2008)
Internet Service Providers (ISPs): 1
(2002)
Internet users: 260,000 (2006)','ef1dd4c4c3cfc35d124890fc71c621650e2468729c3746c913b000303aa77ab4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67afafd9674c2032a17195a544b0985e82a2f1be89a3657847947cc2066aafc0',2010,'LI','Liechtenstein','communications',977,'Telephones — main lines in use: 20,000
(2005)
Telephones — mobilecellular:27, 500(2005)
Telephone system: general assessment:
automatic telephone system
domestic: NA
international: country code— 423; linked to
Swiss networks by cable and microwave
radio relay
Radio broadcast stations: AM 0, FM 4,
shortwave 0 (1998)
Radios: 21,000 (1997)
Television broadcast stations: NA (linked
to Swiss networks) (1997)
Televisions: 12,000 (1997)
Internet country code: U
Internet hosts: 7,639 (2008)
Internet Service Providers (ISPs): 44
(Liechtenstein and Switzerland) (2000)
Internet users: 22,000 (2006)','bd014e84aead7b86cac9eac6fb66ebc5e3381846ca3077b01d842d6594d6c622','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44ced00a7a2aa2e4794dd59a4e75b210527eabfc55b87c5b3618c7008395cd4d',2010,'LU','Luxembourg','communications',985,'Telephones— main lines In use: 799,400
(2007)
Telephones — mobile cellular: 4.912
million (2007)
Telephone system: general assessment:
adequate; being modernized to provide
improved international capability and
better residential access
domestic: rapid expansion of mobile-cellular
services has resulted in a steady decline in the
number of main line subscriptions; mobile-
cellular teledensity has increased to about
135 per 100 persons while fixed-line teleden-
sity has dropped to 22 per 100 persons
international: country code— 370; major
international connections to Denmark,
Sweden, and Norway by submarine cable
for further transmission by satellite; landline
connections to Latvia and Poland (2007)
Radio broadcast stations: AM 29, FM
142, shortwave 1 (2001)
Radios: 1.9 million (1997)
Television broadcast stations: 44 (may
have as many as 100 transmitters, including
repeater stations) (2008)
Televisions: 1.7 million (1997)
Internet country code: .It
Internet hosts: 812,083 (2008)
Internet Service Providers (ISPs): 32
(2001)
Internet users: 1 .333 million (2007)
Telephones — main lines in use: 248,200
(2007)
Telephones — mobile cellular: 604,200
(2007)
Telephone system: general assessment :
highly developed, completely automated
and efficient system, mainly buried cables
domestic: fixed line teledensity over 50 per
100 persons; nationwide cellular telephone
system with market for mobile-cellular
phones virtually saturated
international: country code— 352 (2007)
Radio broadcast stations: AM 2, FM 9,
shortwave 2 (1999)
Radios: 285,000 (1997)
Television broadcast stations: 5 (1999)
Televisions: 285,000 (1998 est.)
Internet country code: lu
Internet hosts: 180,756 (2008)
Internet Service Providers (ISPs):
8 (2000)
Internet users:
345,000 (2007)','0e26633bcb4279e89751cd0e64de1de01e22d51357cb4e3f75bcfd23865a3f68','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37d1b887720e2cb60a3f745fca35b632035d262ef24286db0c405e669cb464eb',2010,'MW','Malawi','communications',1000,'Telephones — main lines in use: 133,900
(2007)
Telephones— mobile cellular: 2.218
million (2007)
Telephone system: general assessment:
system is above average for the region;
Antananarivo’s main telephone exchange
modernized in the late 1990s, but the rest
of the analogue-based telephone system is
poorly developed; have added more than
50,000 new fixed lines since 2005
domestic: combined fixed-line and mobile
telephone density only about 12 per 100
persons
international: country code— 261; submarine
cable to Bahrain; satellite earth stations— 2
(1 Intelsat— Indian Ocean, 1 Intersputnik—
Adantic Ocean region) (2007)
Radio broadcast stations: AM 2, FM 9,
shortwave 6 (2001)
Radios: 3.05 million (1997)
Television broadcast stations: 1 (plus 36
repeaters) (2001)
Televisions: 325,000 (1997)
Internet country code: mg
Internet hosts: 11,016 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 110,000 (2006)
Telephones— main lines in use: 175,200
(2007)
Telephones— mobile cellular: 1.051
million (2007)
Telephone system: general assessment:
rudimentary
domestic: fixed-line subscribership about 1
per 100 persons; privatization of Malawi
Telecommunications (MTL), a necessary
step in bringing improvement to telecom¬
munications services, completed in 2006;
mobile-cellular services are expanding but
cellular network coverage is limited and
is based around the main urban areas;
mobile cellular subscribership roughly 8
per 100 persons
international: country code— 265; satellite
earth stations— 2 Intelsat (1 Indian Ocean,
1 Adantic Ocean)
Radio broadcast stations: AM 9, FM 5
(plus 15 repeater stations), shortwave 2
(plus one shortwave station on standby)
(2001)
Radios: 2.6 million (1997)
Television broadcast stations: l (2001)
Televisions: NA
Internet country code: mw
Internet hosts: 107 (2008)
Internet Service Providers (ISPs): 3
(2002)
Internet users: 139,500 (2007)','39fd4659a5fad2e3971167aca1257c10f36313ebbe5185c6fcef108b7cf4b8dc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d95c78b8bccfbbe4082a2c4ebc7700f4d7e29b3e89beff2fdb0b6232bc329a73',2010,'MY','Malaysia','communications',1011,'Telephones— main lines in use: 4.35
million (2007)
Telephones — mobile cellular: 23.347
million (2007)
Telephone system: general assessment:
modern system; international service excel¬
lent
domestic: good intercity service provided on
Peninsular Malaysia mainly by microwave
radio relay; adequate intercity microwave
radio relay network between Sabah and
Sarawak via Brunei; domestic satellite
system with 2 earth stations; combined
fixed-line and mobile cellular teledensity
exceeds 110 per 1 00 persons
international: country code— 60; landing
point for several major international
submarine cable networks that provide
connectivity to Asia, Middle East, and
Europe; satellite earth stations— 2 Intelsat
(1 Indian Ocean, 1 Pacific Ocean) (2007)
Radio broadcast stations: AM 35, FM
391, shortwave 15 (2001)
Radios: 10.9 million (1999)
Television broadcast stations: 88 (main¬
land Malaysia 51, Sabah 16, and Sarawak
21) (2006)
Televisions: 10.8 million (1999)
Internet country code: .my
Internet hosts: 377,716 (2008)
Internet Service Providers (ISPs): 7
(2000)
Internet users: 15.868 million (2007)','b6ee237abd7fff6224d0f3e40a81190cc1be1df9c0bbfc98b91a5c8db48fc772','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63e3fc43ed8353809acffca8b052cd6d9a057a6b500e1db22fdaf691fee91c33',2010,'MV','Maldives','communications',1018,'Telephones — main lines in use: 33,200
(2007)
Telephones— mobile cellular: 317,800
(2007)
Telephone system: general assessment: tele¬
phone services have improved; each island
now has at least 1 public telephone, and there
are mobile cellular networks with a rapidly
expanding subscribership approaching 90
per 1 00 persons
domestic: interatoll communication through
microwave links; all inhabited islands and
resorts are connected with telephone and
fax service
international: country code— 960; linked to
international submarine cable Fiber-Optic
Link Around the Globe (FLAG); satellite
earth station— 3 Intelsat (Indian Ocean) (2007)
Radio broadcast stations: AM 1 , FM 1 ,
shortwave 1 (1998)
Radios: 35,000 (1999)
Television broadcast stations: 1 (2006)
Televisions: 10,000 (1999)
Internet country code: mv
Internet hosts: l ,600 (2008)
Internet Service Providers (ISPs): 1 (2000)
Internet users: 33,000 (2007)','e7a1f03cb00a658c22f2f39540ec88209e7104f50d34e933f9df70883d68b8d0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d895c3d8a9e1ce408284a2bb93e5fa9a35bce26bee0b020d645b0003548cb0',2010,'MH','Marshall Islands','communications',1030,'Telephones — main lines in use: 198,100
(2007)
Telephones — mobile cellular: 371,500
(2007)
Telephone system: general assessment :
automatic system satisfies normal require¬
ments; fixed-line teledensity 50 per 100
persons; mobile-cellular teledensity about
90 per 100 persons
domestic: submarine cable and microwave
radio relay between islands
international: country code— 356; subma¬
rine cable connects to Italy; satellite earth
station— 1 Intelsat (Atlantic Ocean) (2007)
Radio broadcast stations: AM 1, FM 18,
shortwave 6 (1999)
Radios: 255,000 (1997)
Television broadcast stations: 5 (2006)
Televisions: 280,000 (1997)
Internet country code: mt
Internet hosts: 26,494 (2008)
Internet Service Providers (ISPs): 6
(2002)
Internet users: 158,000 (2007)
Telephones— main lines in use: 4,500
(2004)
Telephones — mobile cellular: 700 (2005)
Telephone system: general assessment:
digital switching equipment; modem services
include telex, cellular, Internet, international
calling, caller ID, and leased data circuits
domestic: Majuro Atoll and Ebeye and
Kwajalein islands have regular, seven¬
digit, direct-dial telephones; other islands
interconnected by high frequency radio¬
telephone (used mostly for government
purposes) and mini-satellite telephones
international: country code— 692; satellite
earth stations— 2 Intelsat (Pacific Ocean);
US Government satellite communications
system on Kwajalein (2005)
Radio broadcast stations: AM 1, FM 3,
shortwave 0 (additionally, the American
Armed Forces Radio and Television
Service (Central Pacific Network) operates
one FM and one AM station on Kwajalein
Island) (2005)
Radios: NA
Television broadcast stations: 2 (both
are US military stations; Marshalls Broad¬
casting Service, a cable company, operates
on Majuro) (2005)
Televisions: NA
Internet country code: .mh
Internet hosts: 3 (2008)
Internet Service Providers (ISPs): 1 (2002)
Internet users: 2,200 (2006)','177feb87dbbe89f62b577986968f37f22796731ec755b3fbd89b167115d743a0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f465eea1813c3a6cf1bcc577c282ce430f3115d744f4319da8f827a383a34d3',2010,'MR','Mauritania','communications',1043,'Telephones — main lines in use: 34,900
(2006)
Telephones — mobile cellular: 1.3 million
(2007)
Telephone system: general assessment:
limited system of cable and open-wire lines,
minor microwave radio relay links, and
radiotelephone communications stations;
mobile-cellular services expanding rapidly
domestic: Mauritel, the national telecom¬
munications company, was privatized in
2001 but remains the monopoly provider
of fixed-line services; fixed-line teledensity
1 per 100 persons; mobile-cellular network
coverage extends mainly to urban areas
with a teledensity approaching 40 per 100
persons; mostly cable and open-wire lines;
a domestic satellite telecommunications
system links Nouakchott with regional
capitals
international: country code— 222; satel¬
lite earth stations— 3 (1 Intelsat— Atlantic
Ocean, 2 Arabsat)
Radio broadcast stations: AM l, FM 14,
shortwave 1 (2001)
Radios: 410,000 (2001)
Television broadcast stations:
1 (2002)
442','932202601378d4f041d714cfcc0af1f696ffb552446e6b4b067d8c8d2c88680e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a77312f7098f3245302c21097f0f13396cc283d1c0c456fb19e5ae76aacbf4a',2010,'MU','Mauritius','communications',1044,'Televisions: 98,000 (2001)
Internet country code: mr
Internet hosts: 34 (2008)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 30,000 (2006)
Telephones— main lines in use: 357,300
(2006)
Telephones — mobile cellular: 936,000
(2007)
Telephone system: general assessment:
small system with good service
domestic: monopoly over fixed-line services
terminated in 2005; fixed-line teledensity
roughly 30 per 100 persons; mobile-cellular
services launched in 1989 with teledensity
in 2007 reaching 75 per 100 persons
international : country code— 230; landing
point for the SAFE submarine cable that
provides links to Asia and South Africa
where it connects to the SAT-3/WASC
submarine cable that provides further links
to parts of East Africa, and Europe; satellite
earth station— 1 Intelsat (Indian Ocean);
new microwave link to Reunion; HF radio¬
telephone links to several countries
Radio broadcast stations: AM 4, FM 9,
shortwave 0 (2001)
Radios: 420,000 (1997)
Television broadcast stations: 2 (plus
several repeaters) (1997)
Televisions: 258,000 (1997)
Internet country code: mu
Internet hosts: 9,609 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 340,000 (2007)','1b2fe3f1ce3a6bf33e25e0a62f8ca764d56f0cf6cf60ee2f8cbe693e2b09f858','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4539c809a043cda45d13feeeec6ccd2b0d8c3698d22ef6aa72a39fb5297dba0d',2010,'YT','Mayotte','communications',1056,'Telephones— main lines in use: 10,000
(2002)
Telephones— mobile cellular: 48,100
(2005)
Telephone system: general assessment:
small system administered by French
Department of Posts and Telecommunica¬
tions
domestic: NA
international: country code— 262; micro-
wave radio relay and HF radiotelephone
communications to Comoros
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (2001)
Radios: NA
Television broadcast stations: 3 (2001)
Televisions: 3,500 (1994)
Internet country code: yt
Internet hosts: l (2008)
Internet Service Providers (ISPs): NA
Internet users: NA','86d94776c7b8abd74aadbad16119cc2373c806942d10bb5beab624400555e708','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac4b1940a04d933d11112d2003ed470d4690e642a8ef9c232f89cc30b732e30',2010,'MX','Mexico','communications',1060,'Telephones — main lines in use: 19.754
million (2007)
Telephones — mobile cellular: 68.254
million (2007)
Telephone system: general assessment-
adequate telephone service for business and
government, but the population is poorly
served; mobile subscribers far outnumber
fixed-line subscribers; domestic satellite
system with 120 earth stations; extensive
microwave radio relay network; considerable
use of fiber-optic cable and coaxial cable
domestic: low telephone density with about
18 fixed lines per 100 persons; privatized
in December 1990; despite the opening
to competition in January 1997, Telmex
remains dominant; legal challenges to
Telmex’ s alleged anti-competitive behavior
in the mobile and fixed-line markets culmi¬
nated in a World Trade Organization
ruling in 2004 against Mexico prompting
some strengthening of the powers granted
Mexico’s telecom regulator; mobile cellular
teledensity approaching 65 per 100 persons
international: country code— 52; Columbus-
2 fiber-optic submarine cable with access
to the US, Virgin Islands, Canary Islands,
Spain, and Italy; the Americas Region
Caribbean Ring System (ARCOS-1 ) and the
MAYA-1 submarine cable system together
provide access to Central America, parts of
South America and the Caribbean, and the
US; satellite earth stations— 120 (32 Intelsat,
2 Solidaridad (giving Mexico improved
access to South America, Central America,
and much of the US as well as enhancing
domestic communications), 1 Panamsat,
numerous Inmarsat mobile earth stations);
linked to Central American Microwave
System of trunk connections (2007)
Radio broadcast stations: AM 850, FM
545, shortwave 1 5 (2003)
Radios: 31 million (1997)
Television broadcast stations: 236 (plus
repeaters) (1997)
Televisions: 25.6 million (1997)
Internet country code: mx
Internet hosts: 10.653 million (2008)
InternetService Providers(ISPs): 5 1 (2000)
Internet users: 22.812 million (2007)','fa7f91006b2cc6766109e60dc4cc7394e02d074d6d5a756daf8cdef00435216c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72eb6b1b5e7180a340c54dd130acebc88701d2027464b5e91e434d614caf2f48',2010,'FM','Micronesia, Federated States of','communications',1069,'Telephones— main lines in use: 8,700
(2007)
Telephones— mobile cellular: 27,400
(2007)
Telephone system: general
assessment: adequate system
domestic: islands interconnected by short¬
wave radiotelephone (used mosdy for
government purposes), satellite (Intelsat)
ground stations, and some coaxial and
fiber-optic cable; cellular service available
on Kosrae, Pohnpei, and Yap
international: country code— 691; satellite
earth stations— 5 Intelsat (Pacific Ocean)
(2002)
Radio broadcast stations: AM 5, FM 1,
shortwave 0 (2004)
Radios: 9,400 (1996)
453
THE CIA WORLD FACTBOOK
Television broadcast stations: 3 (cable
TV also available) (2004)
Televisions: 2,800 (1999)
Internet country code: .fm
Internet hosts: 866 (2008)
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1 5,000 (2007)','b456d5699591b1ea4a7734bd725e56829cf671e096d3038ce71bb9e1073af942','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05412bee30ab81487a63cad75bb1808de1adf00265dc8d737b3945eb7166744',2010,'RO','Romania','communications',1073,'Telephones — main lines in use: 1.08
million (2007)
Telephones— mobile cellular: 1.883
million (2007)
Telephone system: general assessment:
inadequate, outmoded, poor service
outside Chisinau; some modernization is
under way
domestic: depending on location, new
subscribers may face long wait for service;
multiple private operators of GSM mobile-
cellular telephone service are operating;
GPRS system is being introduced; a
CDMA mobile telephone network began
operations in 2007; combined fixed-line
and mobile-cellular teledensity 70 per 100
persons
456
Telephones— main lines in use: 4.3
million (2007)
Telephones — mobile cellular: 22.875
million (2007)
Telephone system: general assessment:
the telecommunications sector is being
expanded and modernized; domestic and
international service improving rapidly,
especially in wireless telephony
domestic: more than 90 percent of tele¬
phone network is automatic; fixed-line
teledensity is roughly 20 telephones per
100 persons; mobile-cellular teledensity,
expanding rapidly, now slightly exceeds
1 00 telephones per 1 00 persons
international: country code— 40; the Black
Sea Fiber Optic System provides connec¬
tivity to Bulgaria and Turkey; satellite
earth stations— 10; digital, international,
direct-dial exchanges operate in Bucharest
(2007)
Radio broadcast stations: 698 (station
frequency type NA) (2006)
Radios: 7.2 million (1997)
Television broadcast stations: 623 (plus
200 repeaters) (2006)
Televisions: 5.25 million (1997)
Internet country code: ro
Internet hosts: 2.195 million (2008)
Internet Service Providers (ISPs): 38
(2000)
Internet users: 12 million (2007)','a610e79ab879895de9c567cd1fd8e42b36a0ecdf1db945c535b59847792b542b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3192dc8b6e0416f707521edcee7287143ed33e026a917c007c8cb2540b6527e',2010,'MC','Monaco','communications',1074,'international: country code— 373; service
through Romania and Russia via landline;
satellite earth stations— at least 3 (Intelsat,
Eutelsat, and Intersputnik) (2007)
Radio broadcast stations: AM 2, FM 29,
shortwave NA (2006)
Radios: 3.22 million (1997)
Television broadcast stations: 40 (2006)
Televisions: 1.26 million (1997)
Internet country code: md
Internet hosts: 223,869 (2008)
Internet Service Providers (ISPs): 2 (l 999)
Internet users: 700,000 (2007)
Telephones — main lines in use: 34,000
(2005)
Telephones— mobile cellular: 17,200
(2005)
Telephone system: general assessment:
modern automatic telephone system; the
country’s sole fixed line operator offers
a full range of services to residential and
business customers
domestic: combined fixed line and mobile
telephone density exceeds 1 00%
international: country code— 377; no satel¬
lite earth stations; connected by cable into
the French communications system
Radio broadcast stations: AM 1 , FM 1 1 ,
shortwave 1 (2008)
Radios: 34,000 (1997)
Television broadcast stations: 5 (1998)
Televisions: 25,000 (1997)
Internet country code: me
Internet hosts: 21,058 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 20,000 (2006)','30d3e7ebb4bd3618c05f30d7b2d5103e2af2227081ffb305767d02e0f4d9d2e4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4beb0a262beca9d283daf2988097f0e22f2035dfd2fa915e9ed4498dfaf55f6',2010,'MN','Mongolia','communications',1086,'Telephones — main lines in use: 148,200
(2008)
Telephones — mobile cellular: 1.796
million (2008)
Telephone system: general assessment:
network is improving with international
direct dialing available in many areas
domestic: very low fixeddine density; there
are multiple mobile cellular service providers
and subscribership is increasing rapidly; a
fiberoptic network has been installed that
is improving broadband and communica-
tion services between major urban centers
with multiple companies providing inter¬
city fiberoptic cable services
international: country code— 976; satellite
earth stations— 7
Radio broadcast stations: AM 7, FM 115
(includes 20 national radio broadcaster
repeaters), shortwave 4 (2006)
Radios: 155,900 (1999)
Television broadcast stations: 68 (2008)
Televisions: 168,800 (1999)
Internet country code: ,mn
Internet hosts: 356 (2008)
Internet Service Providers (ISPs): 5
(2001)
Internet users: 320,000 (2007)','941191166cf25a08ebd0ec5ba2b65e0bf5b3de045c202369d339d6f0d2b87358','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4635f6c381d7498a910ba8212d1a9b492f6c3e4013503fe845dffc683bebfe90',2010,'ME','Montenegro','communications',1091,'Telephones— main lines in use: 353,300
(2006)
Telephones— mobile cellular: 643,700
(2006)
Telephone system: general assessment:
modern telecommunications system with
access to European satellites
domestic: GSM wireless service, available
through 3 providers with national coverage,
is growing rapidly
international: country code— 382; 2 inter¬
national switches connect the national
system
Radio broadcast stations: 31 (station
frequency types NA) (2004)
Television broadcast stations: 13 (2004)
Internet country code: me
Internet users:
280,000 (2007)','2926744c3410e008810a561b3cee24f526752bd8765e13cdd5060f087ee1a550','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('793c14d34066acb23bac81dae9c436f05dc45b4e48000af60568badf94e7a4e7',2010,'MA','Morocco','communications',1100,'Telephones— main lines in use: NA
Telephones— mobile cellular: NA
Telephone system: general assessment:
modem and fully digitalized
domestic: NA
international: country code— 1-664; landing
point for the East Caribbean Fiber System
(ECFS) optic submarine cable with links to
13 other islands in die eastern Caribbean
extending from the British Virgin Islands
to Trinidad
Radio broadcast stations: AM 1, FM 2,
shortwave 0 (1998)
Television broadcast stations: 1 (1997)
Internet country code: ms
Internet hosts:
409 (2008)
country comparison to the world: 164
Internet users: NA
Telephones— main lines in use: 2.394
million (2007)
Telephones— mobile cellular: 20.029
million (2007)
Telephone system: general assessment:
modern system with all important capa¬
bilities; however, density is low with only 7
fixed lines available for each 100 persons;
mobile-cellular subscribership reached 60
per 100 persons in 2007
domestic: good system composed of open-
wire lines, cables, and microwave radio
relay links; Internet available but expen¬
sive; principal switching centers are
Casablanca and Rabat; national network
nearly 100% digital using fiber-optic links;
improved rural service employs microwave
radio relay
international: country code— 212; landing
point for the SEA-ME-WE-3 optical tele¬
communications submarine cable that
provides connectivity to Asia, the Middle
East, and Europe; satellite earth stations— 2
Intelsat (Adantic Ocean) and 1 Arabsat;
microwave radio relay to Gibraltar, Spain,
and Western Sahara; coaxial cable and
microwave radio relay to Algeria; partici¬
pant in Medarabtel; fiber-optic cable link
from Agadir to Algeria and Tunisia (2007)
Radio broadcast stations: AM 27, FM
25, shortwave 6 (1998)
Radios:
6.64 million (1997)
Television broadcast stations: 35 (plus
66 repeaters) (1995)
Televisions: 3.1 million (1997)
Internet country code: ma
Internet hosts: 275,889 (2008)
Internet Service Providers (ISPs): 8 (2000)
Internet users: 7.3 million (2007)','d0c955ab3d48200eb6f6afe1415e4b37228ef9cfa1cf40acd54ef3891a76ad40','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('216c2968f0d0b888d9326e82c9bc5689900ae3b1a853a025a0ec4915b3559de7',2010,'MZ','Mozambique','communications',1113,'Telephones — main lines in use:
67,000 (2006)
Telephones — mobile cellular:
3.3 million (2007)
473
THE CIA WORLD FACTBOOK
Telephone system: general assessment: fair
system with an extremely low density of
less than 1 fixed line per 1 00 persons
domestic: the telecommunications sector
is shackled with a heavy state presence,
lack of competition, and high operating
costs and charges; stagnation in the fixed-
line network contrasts with rapid growth
in the mobile-cellular network; mobile-
cellular coverage now includes all the main
cities and key roads, including those from
Maputo to the South African and Swazi¬
land borders, the national highway through
Gaza and Inhambane provinces, the Beira
corridor, and from Nampula to Nacala
international: country code— 258; satellite
earth stations— 5 Intelsat (2 Atlantic Ocean
and 3 Indian Ocean)
Radio broadcast stations: AM 13, FM
17, shortwave 11 (2001)
Radios:
730,000 (1997)
Television broadcast stations: 4 (2008)
Televisions: 67,600 (2000)
Internet country code: mz
Internet hosts: 22,532 (2008)
lnternetServiceProviders(ISPs):l 1(2002)
Internet users: 200,000 (2007)','6a5be8c35d30aebb2fc9f34afc5abeb3697e96bbea49ec8425deb0f18ac8b916','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f8b3023b8365858d777242d180c0ef085a11b6b0fca08f552f57a48b61ced2e',2010,'NA','Namibia','communications',1117,'Telephones — main lines in use: 138,100
(2007)
Telephones — mobile cellular: 800,300
(2007)
Telephone system: general assessment:
good system with a combined fixed-
line and mobile-cellular teledensity of
about 45 per 100 persons
domestic: core fiber-optic network links most
centers and connections are now digital;
Namibia’s first mobile-cellular network,
launched in 1994, provides coverage to 86
percent of Namibia by area
international: country code— 264; fiber-optic
cable to South Africa, microwave radio
relay link to Botswana, direct links to other
neighboring countries; connected to the
South African Far East (SAFE) submarine
cable through South Africa; satellite earth
stations— 4 Intelsat (2007)
Radio broadcast stations: AM 2, FM 39,
shortwave 4 (2001)
Radios: 232,000 (1997)
Television broadcast stations: 2 (2007)
Televisions: 60,000 (1997)
Internet country code: .na
Internet hosts: 6,296 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 101,000 (2007)','13fceb3ebdf04723057d54322c76175d6b02c435b265c29d2a9bc149e913cf3c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('952e0125e8feb6842d3c92bc58215360f748de1e96410fe92e82101fa9bc322e',2010,'NR','Nauru','communications',1125,'Telephones — main lines in use:
1,900 (2002)
Telephones— mobile cellular:
1 ,500 (2002)
479
THE CIA WORLD FACTBOOK
Telephone system: general assessment:
adequate local and international radio¬
telephone communication provided via
Australian facilities
domestic: NA
international: country code— 674; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 0,
shortwave 0 (1998)
Radios: 7,000 (1997)
Television broadcast stations: 1 (1997)
Televisions: 500 (1997)
Internet country code: nr
Internet hosts: 42 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 3 00 (2002)','908fdc7f4c1a205311bc97f86ddaa1ca793040e90feb048f481f95085f7001b1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a58a60b0e3c989c413014c3c5a8784af1d2fe0f67201ee15f41a6893a2be75c5',2010,'NP','Nepal','communications',1132,'Telephones — main lines in use: 766,400
(2007)
Telephones— mobile cellular: 1.157
million (2006)
Telephone system: general assessment:
poor telephone and telegraph service; fair
radiotelephone communication service and
mobile-cellular telephone network
domestic: NA
international: country code— 977; radio¬
telephone communications; microwave
landline to India; satellite earth station— 1
Intelsat (Indian Ocean)
Radio broadcast stations: AM 6, FM 80,
shortwave 4 (2008)
Radios: 840,000 (1997)
Television broadcast stations:
9 (plus 9 repeaters) (2008)
Televisions: 130,000 (1997)
Internet country code: np
Internet hosts: 42,219 (2008)
Internet Service Providers (ISPs):
6 (2000)
Internet users:
337,100 (2007)','b26106f2ea553f66ddbe6d2493e8a1b3d9a8003460651e0b8a2c937c45728ecd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4945b8e06e50845f1c3eac130cae45ba87b7df59e2be53cbda81e32c7e59798f',2010,'NC','New Caledonia','communications',1141,'Telephones— main lines in use:
60,200 (2007)
Telephones— mobile cellular: 176,400
(2007)
Telephone system: general assessment: NA
domestic: a submarine cable network
connection between New Caledonia and
Australia, completed in 2007, is expected
to significantly increase network capacity
and improve high-speed connectivity7 and
access to international networks
international: country code— 687; satellite
earth station— 1 Intelsat(PacificOcean) (2007)
Radio broadcast stations: AM 1, FM 5,
shortwave 0 (1998)
Radios: 107,000 (1997)
Television broadcast stations: 6 (plus 25
repeaters) (1997)
Televisions: 52,000 (1997)
Internet country code: .nc
Internet hosts:
15,487 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 80,000 (2006)','0a20e588b3ab6b55ece817af53aeff9ab1a986927751d3e6b31b9806cc5ecb78','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7821b114729c7bcb66db67be34ab7ccab6b917d235d334bf296fc34ee22a31c',2010,'NI','Nicaragua','communications',1147,'Telephones — main lines in use: 1.706
million (2007)
Telephones— mobile cellular: 4.245
million (2007)
Telephone system: general assessment:
excellent domestic and international systems
domestic: NA
international: country code— 64; the
Southern Cross submarine cable system
provides links to Australia, Fiji, and the
US; satellite earth stations— 8 (1 Inmarsat-
Pacific Ocean, 7 other)
Radio broadcast stations: AM 124, FM
290, shortwave 4 (1998)
Radios: 3.75 million (1997)
Television broadcast stations: 41 (plus
about 700 repeaters) (1997)
Televisions: 1.926 million (1997)
Internet country code: nz
Internet hosts:
1.72 million (2008)
Internet Service Providers (ISPs):
36 (2000)
Internet users:
3.36 million (2007)
Telephones — main lines in use:
247,900 (2006)
Telephones— mobile cellular:
2.123 million (2007)
Telephone system: general assess -
ment: system being upgraded by foreign
investment; nearly all installed telecom¬
munications capacity now uses digital
technology, owing to investments since
privatization of the formerly state-owned
telecommunications company
domestic: since privatization, access to
fixed-line and mobile-cellular services
has improved but teledensity still lags
behind other Central American countries;
connected to Central American Microwave
System
international: country code— 505; the
Americas Region Caribbean Ring System
(ARCOS-1) fiber optic submarine cable
provides connectivity to South and Central
America, parts of the Caribbean, and the
US; satellite earth stations— 1 Intersputnik
(Adantic Ocean region) and 1 Intelsat
(Adantic Ocean) (2007)
Radio broadcasf sfafions: AM 63, FM
32, shortwave 1 (1998)
Radios: 1.24 million (1997)
Television broadcast stations: 3 (plus 7
repeaters) (1997)
Televisions: 320,000 (1997)
Internet country code: ni
Internet hosts: 58,157 (2008)
Internet Service Providers (ISPs):
3 (2000)
Internet users: 155,000 (2006)','6a132bca41b4ce4cb919dfd8f458e0a375cade01368b01989da4c4426d017159','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6618d04161f8add0729cca41bb2a4e4ca563fcc7bc0e1ada5df5b3cce27d2f2',2010,'NE','Niger','communications',1156,'Telephones — main lines in use:
24,000 (2005)
Telephones — mobile cellular:
900,000 (2007)
Telephone system: general assessment:
inadequate; small system of wire, radio
telephone communications, and micro¬
wave radio relay links concentrated in the
southwestern area of Niger
domestic: combined fixed-line and mobile-
cellular teledensity only about 7 per 100
persons; domestic satellite system with 3
earth stations and 1 planned
international: country code— 227; satellite
earth stations— 2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean)
Radio broadcasf sfafions: AM 5, FM 6,
shortwave 4 (2001)
Radios: 680,000 (1997)
Television broadcasf sfafions: 5 (2007)
Televisions: 125,000 (1997)
Internet country code: ne
Internet hosts: 216 (2008)
Internet Service Providers (ISPs):
1 (2002)
Internet users: 40,000 (2006)','7306625afa99aa99bc2cd2d34ec2dbce45ba6a0b2ceb9b341bb1de4f7fa411ff','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa431a43fa3f61f198eaec4aed5cf64bed5ffa1a064bdc3f4f01f18b74074aad',2010,'NG','Nigeria','communications',1164,'Telephones— main lines in use:
1.58 million (2007)
Telephones — mobile cellular:
40.395 million (2007)
Telephone system: general assessment:
further expansion and modernization
of the fixed-line telephone network is
needed
504','92faab10cc0de0497dbe3775527bf74cca780f0a1cf821d27163eba93bf8a4e8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b5eb1578cae30872633186bc8bdc4adfc53a445e45acef6ccf2bddbef3d1395',2010,'NU','Niue','communications',1165,'domestic: the addition of a second fixed-line
provider in 2002 resulted in faster growth
but subscribership remains only about 1
per 100 persons; wireless telephony has
grown rapidly, in part responding to the
shortcomings of the fixed-line network;
multiple service providers operate nation¬
ally; mobile-cellular teledensity reached 30
per 100 persons in 2007
international: country code— 234; landing
point for the SAT-3/WASC fiber-optic
submarine cable that provides connectivity
to Europe and Asia; satellite earth stations—
3 Intelsat (2 Adantic Ocean and 1 Indian
Ocean) (2007)
Radio broadcast stations: AM 83, FM
36, shortwave 11 (2001)
Radios: 23.5 million (1997)
Television broadcast stations: 3 (the
government controls 2 of the broadcasting
stations and 15 repeater stations) (2001)
Televisions: 6.9 million (1997)
Internet country code: ng
Internet hosts: l ,048 (2008)
Internet Service Providers (ISPs):
11 (2000)
Internet users: 10 million (2007)','259b81816871c2f68e627420c2b8f7113fbcc2be12949ca61b5f6925d0d9e068','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bff28c9e32a0d4892bee94e282c20cf3057a9e210c58d13bc2cd7a5c0d17ba95',2010,'NF','Norfolk Island','communications',1172,'Telephones — main lines in use:
1,100 (2002 est.)
Telephones — mobile cellular:
400 (2002)
Telephone system: domestic: single-line tele¬
phone system connects all villages on island
international: country code— 683 (2001)
Radio broadcast stations: AM 1, FM l,
shortwave 0 (1998)
Radios: 1,000 (1997)
Television broadcast stations: l (1997)
Televisions: NA
Internet country code: nu
Internet hosts: 382,599 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 900 (2002)
Telephones — main lines in use: 2,532;
note— a mix of analog (2500) and digital
(32) circuits (2004)
Telephones— mobile cellular: 0; note-
proposed cellular service disallowed in
August 2002 island referendum (2002)
Telephone system:
general assessment: adequate
domestic: free local calls
international: country code— 672; undersea
coaxial cable links with Australia and New
Zealand; satellite earth station— 1
Radio broadcast stations: AM 1, FM 3,
shortwave 0 (2005)
Radios: 2,500 (1996)
508','c9e3a8ea36c0f95c1711f14e6fbf450fed8f10a29dc267f727ff1cc317ac2306','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f00c7a3d84eeae510397e991e9841dc4c2f8ea73b4878f7d137a0592ff9bb01',2010,'MP','Northern Mariana Islands','communications',1176,'Television broadcast stations: 1 (local
programming station plus 2 repeaters that
air Australian programs by satellite) (2005)
Televisions: 1,200 (1996)
Internet country code: .nf
Internet hosts: 51 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users: 700 (2002 est.)
Telephones— main lines in use: 21,000
(2000)
Telephones— mobile cellular: 20,500
(2004)
Telephone system:
general assessment: NA
domestic: NA
510','72a5c322fc041bf485e00afc0920cc580539db689d973ab94a3ae3917133606d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0af6fe19771c1b8d848c9b866ea88504a5240637832d34d3a0e1c3632711fa0a',2010,'NO','Norway','communications',1183,'international: country code— 1-670; satellite
earth stations— 2 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 6,
shortwave 1 (2005)
Radios: NA
Television broadcast stations: l (on
Saipan; in addition, 2 cable services on
Saipan provide varied programming from
satellite networks) (2006)
Televisions: NA
internet country code: .mp
Internet hosts: 6 (2008)
Internet Service Providers (ISPs): 1 (2001)
Internet users: 10,000 (2003)
Telephones— main lines in use: 1.988
million (2007)
Telephones— mobile cellular: 5.192
million (2007)
513
THE CIA WORLD FACTBOOK
Telephone system: general assessment:
modern in all respects; one of the most
advanced telecommunications networks in
Europe
domestic: Norway has a domestic satellite
system; moreover, the prevalence of rural
areas encourages the wide use of cellular-
mobile systems instead of fixed-wire
systems
international : country code— 47; 2 buried
coaxial cable systems; submarine cables
provide links to other Nordic countries
and Europe; satellite earth stations— NA
Eutelsat, NA Intelsat (Atlantic Ocean), and
1 Inmarsat (Adantic and Indian Ocean
regions); note— Norway shares the Inmarsat
earth station with the other Nordic coun¬
tries (Denmark, Finland, Iceland, and
Sweden) (1999)
Radio broadcast stations: AM 5, FM
160, shortwave 1 (2008)
Radios: 4.03 million (1997)
Television broadcast stations: 69 (2008)
Televisions: 2.03 million (1997)
Internet country code: no
Internet hosts: 2.995 million (2008)
Internet Service Providers (ISPs):
13(2000)
Internet users: 3.8 million (2007)','bf3f52be09a914b62512419ad1ee2f3e62c99cb45c7bdb2f7be88dfb5831bf46','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bc49b7c7bb1109254e5011fad50adfe3f61ceb8e5945b39c1c594faa459c9a8',2010,'OM','Oman','communications',1192,'Telephones — main lines in use: 268,100
(2007)
Telephones— mobile cellular: 2.5 million
(2007)
Telephone system: general assessment:
modern system consisting of open-wire,
microwave, and radiotelephone communi¬
cation stations; limited coaxial cable
domestic: fixed-line phone service gradu¬
ally being introduced to remote villages
using wireless local loop systems; fixed-line
and mobile-cellular subscribership both
increasing; open-wire, microwave, radiotel¬
ephone communications, and a domestic
satellite system with 8 earth stations
international: country code— 968; the
Fiber-Optic Link Around the Globe
(FLAG) and the SEA-ME-WE-3 subma¬
rine cable provide connectivity to Asia,
the Middle East, and Europe; satellite
earth stations— 2 Intelsat (Indian Ocean),
1 Arabsat (2007)
Radio broadcast stations: AM 3, FM 9,
shortwave 2 (1999)
Radios: 1.4 million (1997)
Television broadcast stations: 13 (plus
25 repeaters) (1999)
Televisions: 1.6 million (1997)
Internet country code: om
Internet hosts: 4,785 (2008)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 340,000 (2007)','3f5600c2d756599c0fa5ef77ee2f2d6ef9e6a9fb9ba7e9a456ae4e9a25f8f3d6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee925bc1e5203ae7729c683535a83312ef5f7f407b71b3fe3bad8d9c9143a5d',2010,'PK','Pakistan','communications',1202,'Telephones — main lines in use: 4.546
million (2008)
Telephones— mobile cellular: 88.02
million (2008)
Telephone system: general assessment:
the telecommunications infrastructure is
improving dramatically with foreign and
domestic investments into fixeddine and
mobile networks; mobile-cellular subscrib-
ership has skyrocketed, reaching some
88 million in 2008, up from only about
300,000 in 2000; fiber systems are being
constructed throughout the country to aid
in network growth; main line availability
has risen only marginally over the same
period and there are still difficulties getting
main line service to rural areas
domestic: microwave radio relay, coaxial
cable, fiber-optic cable, cellular, and satel¬
lite networks
international: country code— 92; landing
point for the SEA-ME-WE-3 and SEA-
ME-WE-4 submarine cable systems that
provide links to Asia, the Middle East, and
Europe; satellite earth stations— 3 Intelsat
(1 Atlantic Ocean and 2 Indian Ocean); 3
operational international gateway exchanges
(1 at Karachi and 2 at Islamabad); micro¬
wave radio relay to neighboring countries
(2008)
Radio broadcasf stafions: AM 31, FM
68, shortwave NA (2006)
Radios: 13.5 million (1997)
Television broadcasf stafions: 20 (5 state-
run channels and 15 privately-owned satel¬
lite channels) (2006)
Televisions: 3.1 million (1997)
Internet country code: pk
Internet hosts: 197,264 (2008)
Internet Service Providers (ISPs): 30
(2000)
Internet users: 17.5 million (2007)','9a630a959472279cacfeeeb0bb54cb9e31571eb4e4b9102f87e12954784c1fac','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60631641cd614fb6457e42e3ccf04bcaac59b00c9794dab5c82ad6816b885893',2010,'PH','Philippines','communications',1211,'Telephones — main lines in use: 6,700
(2002)
Telephones— mobile cellular: 1 ,000 (2002)
Telephone system: general assessment: NA
domestic: NA
international: country code— 680; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 4,
shortwave 1 (2001)
Radios: 12,000 (1997)
Television broadcast stations: l (cable)
(2005)
Televisions: 11,000 (1997)
Internet country code: .pw
Internet hosts: 0 (2008)
Internet Service Providers (ISPs): 1 (2002)
Telephones— main lines in use: 3.633
million (2006)
Telephones — mobile cellular: 51.795
million (2007)
Telephone system: general assessment:
good international radiotelephone and
submarine cable services; domestic and
interisland service adequate
domestic: domestic satellite system with 11
earth stations; cellular communications
now dominate the industry; combined
fixed-line and mobile-cellular telephone
density about 60 telephones per 1 00
persons
international: country code— 63; a series of
submarine cables together provide connec¬
tivity to Asia, US, the Middle East, and
Europe; multiple international gateways
(2007)
Radio broadcast stations: AM 381, FM
628, shortwave 4 (2007)
Radios:
11.5 million (1997)
Television broadcast stations: 250 (plus
1,501 CATV networks) (2007)
Televisions: 3.7 million (1997)
Internet country code: ph
Internet hosts: 283,579 (2008)
Internet Service Providers (ISPs): 33 (2000)
Internet users: 5.3 million (2007)','064cb43f25e45efcac28f0ba74f82f0501d3e7feb51af0e377e32015d704a105','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ea78150bf7389f72022dec768603ed30dc8572cbb66e6524a8eb149a7abf912',2010,'PA','Panama','communications',1216,'Telephones — main lines in use: 491,900
(2007)
Telephones — mobile cellular: 2.392
million (2007)
527
THE CIA WORLD FACTBOOK
Telephone system: general assessment:
domestic and international facilities well
developed
domestic: combined fixed-line and mobile-
cellular teledensity is approaching 90 per
100 persons
international: country code— 507; landing
point for the Americas Region Caribbean
Ring System (ARCOS-1), the MAYA-1,
and PAN-AM submarine cable systems that
together provide links to the US and parts of
the Caribbean, Central America, and South
America; satellite earth stations— 2 Intelsat
(Atlantic Ocean); connected to the Central
American Microwave System (2007)
Radio broadcast stations: AM 101, FM
134, shortwave 0 (1998)
Radios: 815,000 (1997)
Television broadcast stations: 38
(including repeaters) (1998)
Televisions: 510,000 (1997)
Internet country code: pa
Internet hosts: 7,858 (2008)
Internet Service Providers (ISPs): 6 (2000)
Internet users: 525,200 (2007)','ddf9875c03e4a27339e25217da14f75630ad823a302c58e8cf762f9b5eda3f65','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f4bb25bdae7a2ad5054ab41f7989585404dc0be9fa991019de735c078a57d01',2010,'PG','Papua New Guinea','communications',1224,'Telephones— main lines in use: 60,000
(2007)
Telephones — mobile cellular: 300,000
(2007)
Telephone system: general assessment:
services are minimal; facilities provide radi¬
otelephone and telegraph, coastal radio,
aeronautical radio, and international radio
communication services
domestic: access to telephone services is
now widely available; combined fixed-line
and mobile-cellular teledensity is 6 per 1 00
persons
international: country code— 675; submarine
cables to Australia and Guam; satellite earth
station— 1 Intelsat (Pacific Ocean); interna¬
tional radio communication service (2007)
Radio broadcast stations: AM 8, FM 19,
shortwave 28 (1998)
Radios: 410,000 (1997)
Television broadcast stations: 3 (all in the
Port Moresby area; stations at Mt. Hagen,
Goroka, Lae, and Rabaul are planned)
(2004)
Televisions: 59,841 (1999)
Internet country code: pg
Internet hosts: 3,422 (2008)
Internet Service Providers (ISPs): 3 (2000)
Internet users: 110,000 (2006)','43c02c0c90281124ba7fec129424d9f4bb667b6f8c607406f9ff846652c876bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d60fad94ab76cca34e437efd6c6ef64abbabf93e4a3b2cc994945ac0b329e3b2',2010,'PE','Peru','communications',1231,'Telephones — main lines in use: 453,800
(2007)
Telephones — mobile cellular: 4.33
million (2007)
Telephone system: general assessment:
meager telephone service; principal
switching center is in Asuncion
domestic: the fixed-line market is a state
monopoly; deficiencies in provision of
fixed-line service have resulted in a rapid
expansion of mobile-cellular services
fostered by competition among multiple
providers
international : country code— 595; satellite
earth station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 41, FM
121, shortwave 6 (2006)
Radios: 925,000 (1997)
Television broadcast stations: 5 (2007)
Televisions: 990,000 (2001)
Internet country code: py
Internet hosts: 19,691 (2008)
Internet Service Providers (ISPs): 4
(2000)
Internet users: 280,000 (2007)
Telephones — main lines in use: 2.673
million (2007)
Telephones— mobile cellular: 15.417
million (2007)
Telephone system: general assessment:
adequate for most requirements
domestic: fixed-line teledensity is only about
9 per 100 persons; mobile-cellular teleden¬
sity, spurred by competition among multiple
providers, has increased to roughly 55 tele¬
phones per 1 00 persons; nationwide micro-
wave radio relay system and a domestic satel¬
lite system with 1 2 earth stations
international: country code— 51; the South
America-1 (SAM-1) and Pan American
(PAN-AM) submarine cable systems
provide links to parts of Central and South
America, the Caribbean, and US; satellite
earth stations— 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 472, FM
198, shortwave 189 (1999)
Radios: 6.65 million (1997)
Television broadcast stations: 13 (plus
112 repeaters) (1997)
Televisions: 3.06 million (1997)
Internet country code: pe
Internet hosts: 271,745 (2008)
Internet Service Providers (ISPs): 10
(2000)
Internet users: 7.636 million (2007)','02b7d449e42b0412066b6d009fbba9aea5e0372e267066f98bd3f5036b0d4169','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a29ba3749f7d1e6c56bb5b0ec4abc58b26c273a39c5e06b5e4296c21e9045e8',2010,'PL','Poland','communications',1241,'Telephones— main lines in use: 1 (there
are 1 7 telephones on one party line); (2004)
Telephone system: general assessment:
satellite phone services
domestic: domestic communication via
radio (CB)
international: country code— 872; satellite
earth station— 1 (Inmarsat)
Radio broadcast stations: AM 1, FM
0, shortwave 0 (15 ham radio operators
(VP6)) (2004)
Radios: NA
Televisions: NA
Internet country code: pn
Internet hosts: 1 2 (2008)
Internet Service Providers (ISPs): NA
Internet users: NA
Telephones — main lines in use: 10.336
million (2007)
Telephones— mobile cellular: 41.389
million (2007)
Telephone system: general assessment:
modernization of the telecommunications
network has accelerated with market based
competition finalized in 2003; fixed-line
service, dominated by the former state-
owned company, is dwarfed by the growth
in wireless telephony
domestic: mobile-cellular service available
since 1993 and provided by three nation¬
wide networks with a fourth provider
beginning operations in late 2006; cellular
coverage is generally good with some gaps
in the east; fixed-line service is growing
slowly and still lags in rural areas
international: country code— 48; inter¬
national direct dialing wida automated
547
THE CIA WORLD FACTBOOK
exchanges; satellite earth station— 1 with
access to Intelsat, Eutelsat, Inmarsat, and
Intersputnik (2007)
Radio broadcast stations: AM 14, FM
63, shortwave 2 (2008)
Radios: 20.2 million (1997)
Television broadcast stations: 75 (2008)
Televisions: 13.05 million (1997)
Internet country code: pi
Internet hosts: 7.808 million (2008)
internet Service Providers (ISPs):
19(2000)
Internet users: 16 million (2007)','9d554a82cb1ddf4f360da25b45b1c40ed7ab6b10136d69419e12676199019e49','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bd617d8a564a07b1dbb1f5d8d3cb6f6ec287aec1dba3c93496bdf59e373d4ef',2010,'PT','Portugal','communications',1250,'Telephones — main lines in use: 4.139
million (2007)
Telephones— mobile cellular: 13.413
million (2007)
Telephone system: general assessment:
Portugal’s telephone system has achieved
a state-of-the-art network with broadband,
high-speed capabilities
domestic: integrated network of coaxial
cables, open-wire, microwave radio relay,
and domestic satellite earth stations
international: country code— 351; a combi¬
nation of submarine cables provide connec¬
tivity to Europe, North and East Africa,
South Africa, the Middle East, Asia, and
the US; satellite earth stations— 3 Intelsat
(2 Atlantic Ocean and 1 Indian Ocean),
NA Eutelsat; tropospheric scatter to Azores
(1998)
Radio broadcast stations: AM 2, FM 63,
shortwave 1 (2008)
Radios: 3.02 million (1997)
Television broadcast stations:
42 (2008)
Televisions: 3.31 million (1997)
Internet country code: pt
Internet hosts: 1 .858 million (2008)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 3.549 million (2007)','23ffaa604bffce5f1107892a40cdc3cd9265f7094eec92aaa3eb326e1b490cf7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b77cedc94622e3494edc58bf62a30db304b33d9ab5a675d70edf6ce022e9d5eb',2010,'PR','Puerto Rico','communications',1258,'Telephones— main lines in use: 1.038
million (2005)
Telephones— mobile cellular: 3.354
million (2005)
Telephone system: general assessment:
modem system integrated with that of the
US by high-capacity submarine cable and
Intelsat with high-speed data capability
domestic: digital telephone system; cellular
telephone service
international: country code— 1-787, 939;
submarine cables provide connectivity to
the US, Caribbean, Central and South
America; satellite earth station— 1 Intelsat
Radio broadcast stations: AM 74, FM
53, shortwave 0 (2008)
Radios: 2.7 million (1997)
Television broadcast stations: 34 (2008)
Televisions: 1.021 million (1997)
Internet country code: pr
Internet hosts: 404 (2008)
Internet Service Providers (ISPs): 76
(2000)
Internet users: l million (2007)
Telephone system: general assessment:
fully integrated access
domestic: direct dial capability with both
fixed and wireless systems
international: country code— 590; undersea
fiber-optic cable provides voice and data
connectivity to Puerto Rico and Guade¬
loupe
Radio broadcast stations: AM 0, FM 3,
shortwave 0 (2007)
Internet country code: .mf; note— .gp, the
internet country code for Guadeloupe, and
.fr, die internet country code for France,
might also be encountered','e6282988bb27309c473f7cfe9895e30ee3da1da46c6e42b169bd6ab07d277247','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7b2d23bab547cf013c19cec823a8e2264fe658d5732d17c8958ee7631ba36e9',2010,'QA','Qatar','communications',1263,'Telephones— main lines in use: 237,400
(2007)
Telephones— mobile cellular:
1.264 million (2007)
Telephone system: general assessment:
modern system centered in Doha
domestic: combined fixed-line and mobile-
cellular telephone density is roughly 165
telephones per 100 persons
international: country code— 974; landing
point for the Fiber-Optic Link Around the
Globe (FLAG) submarine cable network
that provides links to Asia, Middle East,
Europe, and the US; tropospheric scatter
to Bahrain; microwave radio relay to
Saudi Arabia and the UAE; satellite earth
stations— 2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean) and 1 Arabsat
Radio broadcast stations: AM 6, FM 5,
shortwave 1 (1998)
Radios: 256,000 (1997)
Television broadcast stations: 1 (plus 3
repeaters) (2001)
Televisions: 230,000 (1997)
Internet country code: qa
Internet hosts: 563 (2008)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 351,000 (2007)','637a766a96efedd950d8f057f8b34f62c9bb1fe2e69386268852075e6a80ed97','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ce803cb7da0ea2f9a338683d3bdb31781b86a046bce8f5b0896155ed81437a4',2010,'RU','Russian Federation','communications',1274,'Telephones — main lines in use: 43.9
million (2006)
Telephones— mobile cellular: 170
million (2007)
Telephone system: general assessment: the
telephone system is experiencing significant
changes; there are more than 1 ,000 compa¬
nies licensed to offer communication serv¬
ices; access to digital lines has improved,
particularly in urban centers; Internet and
e-mail services are improving; Russia has
made progress toward building the telecom¬
munications infrastructure necessary for a
market economy; the estimated number
of mobile subscribers jumped from fewer
than 1 million in 1998 to 170 million in
2007; a large demand for main line service
remains unsatisfied, but fixed-line operators
continue to grow their services
domestic: cross-country digital trunk lines
run from Saint Petersburg to Khabarovsk,
and from Moscow to Novorossiysk; the tel¬
ephone systems in 60 regional capitals have
modem digital infrastructures; cellular serv¬
ices, both analog and digital, are available
in many areas; in rural areas, the telephone
services are still outdated, inadequate, and
low density
international: country code— 7; Russia is
connected internationally by undersea fiber
optic cables; digital switches in several cities
provide more than 50,000 lines for interna¬
tional calls; satellite earth stations provide
access to Intelsat, Intersputnik, Eutelsat,
Inmarsat, and Orbita systems
Radio broadcast stations: AM 323, FM
1,500 est., shortwave 62 (2004)
Radios: 61.5 million (1997)
Television broadcast stations: 7,306
(1998)
Televisions: 60.5 million (1997)
Internet country code: ru; note-Russia
also has responsibility for a legacy domain
“.su” that was allocated to the Soviet Union
and is being phased out
Internet hosts: 4.822 million (2008)
Internet Service Providers (ISPs): 300
(June 2000)
Internet users: 30 million (2007)','3cf64666f681a98b491f59225c6a88060ab9c5abe9b2052d1519b1c340ebb941','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76f9eab2da9e0333415d0ba8d32955f90c8a3970dbbddab454d0092476a47434',2010,'RW','Rwanda','communications',1282,'Telephones — main lines in use: 23,100
(2007)
Telephones — mobile cellular: 635,100
(2007)
Telephone system: general assessment:
small, inadequate telephone system prima¬
rily serves business and government
domestic: the capital, Kigali, is connected
to the centers of the provinces by micro-
wave radio relay and, recently, by cellular
telephone service; much of the network
depends on wire and HF radiotelephone;
combined fixed-line and mobile-cellular
telephone density is only about 7 tele¬
phones per 100 persons
international: country code— 250; inter¬
national connections employ microwave
radio relay to neighboring countries and
satellite communications to more distant
countries; satellite earth stations— 1 Intelsat
(Indian Ocean) in Kigali (includes telex
and telefax service)
Radio broadcast stations: AM 0, FM
10 (two main FM programs are broadcast
through a system of repeaters; international
FM programming includes the BBC,
VOA, and Deutchewelle) (2007)
Radios: 601,000 (1997)
Television broadcast stations: 2 (2004)
Televisions: NA; probably less than 1 ,000
(1997)
Internet country code: rw
Internet hosts: 2,363 (2008)
Internet Service Providers (ISPs): 2
(2002)
Internet users: 100,000 (2007)
Telephone system: general assessment :
fully integrated access
domestic: direct dial capability with both
fixed and wireless systems
international: country code— 590; undersea
fiber-optic cable provides voice and
data connectivity to Puerto Rico and','abf7d62acb9eb1fa6eb2e4965980d9820e379b49e8438a54a6ad9ebaae11a44e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43240c7c40ea77bf9797d7f3c550bbb00ab26be091e527f5c87cbda5bff4341f',2010,'GP','Guadeloupe','communications',1287,'Internet country code: bl; note-.gp, the
internet country code for Guadeloupe, and
.fr, the internet country code for France,
might also be encountered','0602884dff271880f29b66bed5bb6131dc1a152997b0557591844bccf1737662','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab1483ffa80e28e6eaaee562b84d5d72fc82b800a4314c28be434537a68b42c2',2010,'KN','Saint Kitts and Nevis','communications',1296,'Telephones — main lines in use:
2,200 (2002)
Telephone system: general assessment: can
communicate worldwide
domestic: automatic digital network
international: country code (Saint Helena)—
290, (Ascension Island)— 247; interna¬
tional direct dialing; satellite voice and data
communications; satellite earth stations— 5
(Ascension Island— 4, Saint Helena— 1)
Radio broadcast stations: Saint Helena:
AM 1 , FM 1 , shortwave 0
Ascension: AM 1, FM 1,
shortwave 1 (2005)
Radios:
3,000 (1997)
Television broadcast stations: 0 (3
television channels are received via satellite
and distributed by UHF) (2005)
Televisions: 2,000 (1997)
Internet country code: sh; note-
Ascension Island assigned .ac
Internet hosts: 306 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 1 ,000; note— includes
Ascension Island (2003)
Communications— note: South Africa
maintains a meteorological station on
Gough Island
Telephones — main lines in use:
25,000 (2004)
Telephones — mobile cellular:
10,000 (2004)
Telephone system: general assessment: good
interisland and international connections
domestic: interisland links via Eastern
Caribbean Fiber Optic cable; construction
of enhanced wireless infrastructure launched
in November 2004
international: country code— 1-869;
connected internationally by the East
Caribbean Fiber Optic System (ECFS)
and Southern Caribbean fiber optic system
(SCF) submarine cables
Radio broadcast stations: AM 3, FM 3,
shortwave 0 (2003)
Radios: 28,000 (1997)
Television broadcast stations:
1 (plus 3 repeaters) (2003)
Televisions: 10,000(1997)
Internet country code: kn
Internet hosts: 45 (2008)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 10,000 (2002)','f6dca19ec81e9e18d2d06f2f30296a1d99c3053d327c826c2ea94f22a7e59e5f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70be60fd32401bcee58a9b2cbe38790c5a66f2a595e4ebd68e2e2d2d8c59b1c3',2010,'LC','Saint Lucia','communications',1308,'Telephones— main lines in use:
51,100 (2002)
Telephones— mobile cellular:
105,700 (2005)
Telephone system: general assessment:
adequate system
domestic: system is automatically switched
international: country code— 1-758; the East
Caribbean Fiber Optic System (ECFS) and
Southern Caribbean fiber optic system
(SCF) submarine cables, along with
Intelsat from Martinique, carry calls inter¬
nationally; direct microwave radio relay
link with Martinique and Saint Vincent
and the Grenadines; tropospheric scatter
to Barbados
Radio broadcast stations: AM 2, FM 7,
shortwave 0 (2003)
Radios: 111,000 (1997)
Television broadcast stations: 2 (1
commercial broadcast station and 1
community antenna television or CATV
channel) (2003)
Televisions: 32,000 (1997)
Internet country code: ,1c
Internet hosts: 1 7 (2008)
InternetServiceProviders(ISPs): 1 5(2000)
Internet users: 1 10,000 (2007)','d12a99f937f4018a12f9fbe330aabd9881589c4f5171895cc8586a568475c394','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e6212e7aaf6585948420be84eb9c1aa556c02c3fdcdaa7cb48116dcef0260c0',2010,'PM','Saint Pierre and Miquelon','communications',1316,'Telephones — main lines in use:
4,800 (2002)
Telephone system:
general assessment: adequate
domestic: NA
international: country code— 508; radiotele¬
phone communication with most countries
in the world; satellite earth station— 1 in
French domestic satellite system
Radio broadcast stations: AM 1 , FM 4,
shortwave 0 (1998)
Radios: 4,000(1997)
Television broadcast stations: 0 (2
repeaters rebroadcast programs from
France, Canada, and the US) (1997)
Televisions: 4,000 (1997)
Internet country code: pm
Internet hosts: 0 (2008)
581
THE CIA WORLD FACTBOOK
Internet Service Providers (ISPs):
1 (2000)
Internet users: NA','37f29e46758e34b0807b8341bb94ee80842ac633e546b51997fc64a90e883ce1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa6a45bcfe58ff47f2a034042635f634f9fc59f4ff53f5a81233c2d26e25b46d',2010,'VC','Saint Vincent and the Grenadines','communications',1323,'Telephones — main lines in use:
22,800 (2007)
Telephones — mobile cellular:
104,000 (2007)
Telephone system: general assessment:
adequate system','2fdc44b219340552315f050e9dc7e0fc52e73eda41d307cfc77a4b98c00a213c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69da6c8cc013cf917c9e1f781f390be5513e5418b238275475ca059fff6ce33',2010,'WS','Samoa','communications',1332,'Telephones — main lines in use:
19,500 (2005)
Telephones— mobile cellular:
86,000 (2007)
Telephone system:
general assessment: adequate
domestic: combined fixed-line and mobile-
cellular teledensity roughly 50 telephones
per 1 00 persons
international: country code— 685; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 5,
shortwave 0 (2004)
Radios: 174,849 (1997)
586','83a7b642984cba515bfe35ce38118f04c90a23e278f1d5363070a135953730a0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f0e20c0492d8d08f85ce031a421287082d2e6dad479ce14b2147f2f7e8ce858',2010,'SM','San Marino','communications',1333,'Television broadcast stations: 2 (2002)
Televisions: 8,634 (1999)
Internet country code: ws
Internet hosts: 11,307 (2008)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 8,000 (2006)','5e4fa2603be6dc6dab4853331244437dddd5f1008c2cb1f7b9c611b965537a0e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbba6354745b54b14efde0e2b88f17fad1ae171559354bae027ef0e13e83bc28',2010,'ST','Sao Tome and Principe','communications',1342,'Telephones— main lines in use:
21,000 (2006)
Telephones— mobile cellular:
17,390 (2006)
Telephone system: general assess¬
ment: adequate connections
domestic: automatic telephone system
completely integrated into Italian system;
combined fixed-line and mobile-cellular
teledensity exceeds 130 telephones per
100 persons
international: country code— 378; connected
to Italian international network
Radio broadcast stations: AM 0, FM 2,
shortwave 0 (2008)
Radios: 16,000 (1997)
Television broadcast stations: 1 (San
Marino residents also receive broadcasts
from Italy) (1997)
Televisions: 9,000 (1997)
Internet country code: sm
Internet hosts: 6,665 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users: 15,400 (2006)
Telephones — main lines in use:
7,700 (2007)
Telephones — mobilecelluiar: 30, 100(2007)
Telephone system: general assessment: local
telephone network of adequate quality with
most lines connected to digital switches
domestic: combined fixed-line and mobile-
cellular teledensity approaching 20
telephones per 100 persons
international: country code— 239; satellite
earth station— 1 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 1, FM 5,
shortwave 1 (2001)
Radios: 38,000 (1997)
Television broadcast stations: 2 (2001)
Televisions: 23,000 (1997)
Internet country code: st
Internet hosts: 1,355 (2008)
Internet Service Providers (ISPs): 1 (2002)
Internet users: 23,000 (2007)','930994458c8e48b351946a8f58c6b98c605f670514c5e8882bee2d9505655816','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81802b13746e13b14a4bfd8af909c60231c8b14e5b62bf5d8033f3501c3add15',2010,'SA','Saudi Arabia','communications',1353,'Telephones— main lines in use:
3.996 million (2007)
Telephones— mobile cellular:
28.381 million (2007)
Telephone system: general assessment:
modern system
domestic: extensive microwave radio
relay, coaxial cable, and fiber-optic cable
systems; mobile-cellular subscribership has
been increasing rapidly
international: country code— 966; landing
point for the international submarine
cable Fiber-Optic Link Around the Globe
(FLAG) and for both the SEA-ME-WE-
3 and SEA-ME-WE-4 submarine cable
networks providing connectivity to Asia,
Middle East, Europe, and US; microwave
radio relay to Bahrain, Jordan, Kuwait,
Qatar, UAE, Yemen, and Sudan; coaxial
cable to Kuwait and Jordan; satellite earth
stations— 5 Intelsat (3 Atlantic Ocean and 2
Indian Ocean), 1 Arabsat, and 1 Inmarsat
(Indian Ocean region)
Radio broadcast stations: AM 43, FM
31, shortwave 2 (1998)
Radios: 6.25 million (1997)
Television broadcast stations: 117
(1997)
Televisions: 5.1 million (1997)
Internet country code: sa
Internet hosts: 141,232 (2008)
Internet Service Providers (ISPs): 22
(2003)
Internet users: 6.2 million (2007)','7b03c27ef9925f296d034a9bd52796fd45220033090d46da8d806ba13964ea0b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f88ba8a4befebf28143ab68d7dc479b528cdfc377bd14e6018457b143f3ebc1f',2010,'RS','Serbia','communications',1361,'Telephones — main lines in use:
2.993 million (2007)
Telephones — mobile cellular:
8.453 million (2007)
Telephone system: general assessment:
modernization of the telecommunications
network has been slow as a result of damage
stemming from the 1999 war and transi¬
tion to a competitive market-based system;
network was only 65% digitalized in 2005
domestic: teledensity remains below the
average for neighboring states; GSM wire¬
less service, available through multiple
providers with national coverage, is growing
very rapidly; best telecommunications
service limited to urban centers
international: country code— 381
Radio broadcast stations:
153 (station types NA) (2001)
Internet country code: rs
Internet hosts: NA
Internet users:
1.5 million (2007)','e4327dbb286d6db84823c0ce903f047b0029458c0f95ef707c607bd82eaa06bd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c32e686545dda64fb9bbe00df2b23317b5ac4e416d17d711856bcbf629adb2',2010,'SC','Seychelles','communications',1368,'Telephones — main lines in use:
22,700 (2007)
Telephones— mobile cellular:
77,300 (2007)
Telephone system: general assessment:
effective system
domestic: combined fixed-line and mobile-
cellular teledensity is nearly 1 25 telephones
per 100 persons; radiotelephone communi¬
cations between islands in the archipelago
international : country code— 248; direct
radiotelephone communications with adja¬
cent island countries and African coastal
countries; satellite earth station— 1 Intelsat
(Indian Ocean)
Radio broadcast stations:
AM 1, FM 1, shortwave 2 (2001)
Radios: 42,000 (1997)
Television broadcast stations:
2 (plus 9 repeaters) (1997)
Televisions: 11,000 (1997)
Internet country code: .sc
Internet hosts: 284 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 32,000 (2007)','12875ba774d9832d2aff2c6451154a1ce8cc0b229f92cbf210520b9b511f626c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('511be71a0be67ab67cf6fb3b52a47ade00f92314c048e5806a381f4cd6c0edb2',2010,'SL','Sierra Leone','communications',1376,'Telephones — main lines in use:
24,000 (2002)
Telephones— mobile cellular:
776,000 (2007)
Telephone system: general assessment:
marginal telephone service
domestic: the national microwave radio
relay trunk system connects Freetown to
Bo and Kenema; mobile-cellular service is
growing rapidly from a small base
international: country code— 232; satellite
earth station— 1 Intelsat (Adantic Ocean)
Radio broadcast stations:
AM 1, FM 9, shortwave 1 (2001)
Radios: 1.12 million (1997)
Television broadcast stations: 2 (1999)
Televisions: 53,000 (1997)
Internet country code: si
Internet hosts: 8 (2008)
606','8738366aa6b63be8f372f11509f2365247dc02e324242d7abba57c98a8976019','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('065fb2c37ac3d6f37ea4609361550b4db823565223c0df337a2ba443ce7663d3',2010,'SG','Singapore','communications',1377,'Internet Service Providers (ISPs):
1 (2001)
Internet users:
1 3,000 (2007)
Telephones— main lines in use:
1.859 million (2007)
Telephones — mobile cellular:
5.619 million (2007)
Telephone system: general assessment:
excellent service
domestic: excellent domestic facilities;
launched 3G wireless service in February
2005; combined fixed-line and mobile-
cellular teledensity is about 1 65 telephones
per 100 persons
international: country code— 65; numerous
submarine cables provide links throughout
Asia, Australia, the Middle East, Europe,
and US; satellite earth stations -4; supple¬
mented by VSAT coverage (2007)
Radio broadcast stations: AM 0, FM 19,
shortwave 1 (2008)
Radios: 2.6 million (2000)
Television broadcast stations: 1 (broad¬
casting on 8 channels); additional reception
of numerous UHF and VHF signals origi¬
nating in Malaysia and Indonesia (2008)
Televisions: 1.33 million (1997)
Internet country code: sg
Internet hosts: 837,559 (2008)
Internet Service Providers (ISPs):
9 (2000)
Internet users: 3.105 million (2007)','fed665e603778bbea141ed06b90e8cb76f7cc4e108c0019efcd62890c12ca541','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19080857a110888ebeb3067eed2aa50a52bd9de8fa4e8b75c8a9b8e7f4f090a7',2010,'SI','Slovenia','communications',1387,'Telephones — main lines in use:
1.151 million (2007)
Telephones — mobile cellular:
6.068 million (2007)
Telephone system: general assessment:
Slovakia has a modern telecommunications
system that has expanded dramatically in
recent years with the growth in cellular
services
domestic: analog system is now receiving
digital equipment and is being enlarged
with fiber-optic cable, especially in the
larger cities; 3 companies provide nation¬
wide cellular services
international: country code— 421; 3 interna¬
tional exchanges (1 in Bratislava and 2 in
Banska Bystrica) are available; Slovakia is
participating in several international tele¬
communications projects that will increase
the availability of external services
Radio broadcast stations:
AM 1, FM 22, shortwave 1 (2008)
Radios: 3.12 million (1997)
Television broadcast stations: 37 (2008)
Televisions: 2.62 million (1997)
internet country code: sk
Internet hosts: 717,744 (2008)
Internet Service Providers (ISPs):
6 (2000)
Internet users: 2.35 million (2007)
Telephones — main lines in use:
857,100 (2007)
Telephones— mobile cellular:
1.928 million (2007)
Telephone system: general assessment:
well-developed telecommunications infra¬
structure
domestic: combined fixed-line and mobile-
cellular teledensity roughly 140 telephones
per 100 persons
international: country code— 386
Radio broadcast stations: AM 10, FM
230, shortwave 0 (2006)
Radios: 805,000 (1997)
Television broadcast stations: 31 (2006)
Televisions: 710,000 (1997)
Internet country code: si
Internet hosts: 75,984 (2008)
Internet Service Providers (ISPs):
11 (2000)
Internet users: 1.3 million (2007)','c64e73e451b276c912c07380216bffb8d2c3df6ed3db0e4bda478bcb553daccc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3055b557e503041433651df45c4fc64984378f775b74ffa2fecf4b61470c6680',2010,'SB','Solomon Islands','communications',1399,'Telephones — main lines in use:
7,600 (2006)
Telephones— mobile cellular:
10,900 (2007)
Telephone system: general assessment: NA
domestic: NA
international: country code— 677; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 1, FM 1,
shortwave 1 (2004)
Radios: 57,000 (1997)
Televisions: 3,000 (1997)
Internet country code: sb
Internet hosts: 3,804 (2008)
Internet Service Providers (ISPs): 1
(2000)
Internet users: 8,000 (2006)','684a529f52e7ed54b34a7e33920d8510a8d3ddb9e16d01237b03a3250d15c0b8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08fa141d033da2829f958dc8249a951c45c5c6bf93c6d1d946a503d9de04d54d',2010,'ZA','South Africa','communications',1407,'Telephones — main lines in use:
4.642 million (2007)
Telephones— mobile cellular: 42.3
million (2007)
Telephone system: general assessment:
the system is the best developed and
most modern in Africa
domestic: combined fixed-line and mobile-
cellular teledensity is nearly 110 telephones
per 1 00 persons; consists of carrier-equipped
open-wire lines, coaxial cables, microwave
radio relay links, fiber-optic cable, radio¬
telephone communication stations, and
wireless local loops; key centers are Bloem¬
fontein, Cape Town, Durban, Johannes¬
burg, Port Elizabeth, and Pretoria
international: country code— 27; the SAT-3/
WASC and SAFE fiber optic cable systems
connect South Africa to Europe and Asia;
satellite earth stations— 3 Intelsat (1 Indian
Ocean and 2 Atlantic Ocean)
Radio broadcast stations: AM 14, FM
347 (plus 243 repeaters), shortwave 1
(1998)
Radios: 17 million (2001)
Television broadcast stations:
556 (plus 144 network repeaters) (1997)
Televisions: 6 million (2000)
Internet country code: za
Internet hosts: 1.297 million (2008)
Internet Service Providers (ISPs):
150 (2001)
Internet users:
5.1 million (2005)','3a449e101668ae2b405f76fdda458a945e735a8ccaa5d3e9cf712489bd026322','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fafb990e7c6cee23c635711da94a510241d95de887b68863118fabdd20311e8',2010,'GS','South Georgia and the South Sandwich Islands','communications',1414,'Telephone system: general assessment: NA
domestic: NA
international: coastal radiotelephone station
at Grytviken
Radio broadcast stations:
0 (2003)
Television broadcast stations: 0 (2003)
Internet country code: gs
Internet hosts: 196 (2008)','bc8ddc854d5290e473bd7baf2bff4642cc398e8d6046c3ebc26edcdfecf211bc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf0856b5298225bb83c36c66e5a7dcecf15c4b8e0ad824782b0f5c0aa203e556',2010,'ES','Spain','communications',1421,'Telephones — main lines in use:
18.583 million (2007)
Telephones — mobile cellular:
48.813 million (2007)
Telephone system: general assessment:
well developed, modern facilities; fixed-line
teledensity is about 45 per 100 persons
domestic: combined fixed-line and mobile-
cellular teledensity is nearly 170 telephones
per 100 persons
international: country code— 34; submarine
cables provide connectivity to Europe,
Middle East, Asia, and US; satellite earth
stations— 2 Intelsat (1 Adantic Ocean and 1
Indian Ocean), NA Eutelsat; tropospheric
scatter to adjacent countries
Radio broadcast stations: AM 18, FM
250, shortwave 2 (2008)
Radios: 13.1 million (1997)
Television broadcast stations:
379 (2008)
Televisions: 16.2 million (1997)
Internet country code: es
Internet hosts: 3.264 million (2008)
Internet Service Providers (ISPs):
56 (2000)
Internet users: 19.69 million (2007)
Telephones— main lines in use: 323,800
(2007)
Telephones— mobile cellular: 1.008
million (2007)
Telephone system: general assessment: excel¬
lent international service; good local service
domestic: mobile-cellular teledensity exceeds
125 telephones per 100 persons
international : country code— 1-868; subma¬
rine cable systems provide connectivity to
US and parts of the Caribbean and South
America; satellite earth station— 1 Intelsat
(Atlantic Ocean); tropospheric scatter to
Barbados and Guyana
Radio broadcast stations: AM 4, FM 18,
shortwave 0 (2001)
Radios: 680,000 (1997)
Television broadcast stations: 6 (2005)
Televisions: 425,000 (1997)
Internet country code: tt
Internet hosts: 155,722 (2008)
Internet Service Providers (ISPs): 17
(2000)
Internet users:
430,800 (2007)','7ef1e8ec9743c7876c0715088ec8b86de578d5da342eeb57b523e7e73a66bba6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('584b581eaf48c2afbf4b7df786b4641470d18912ffb2841ae510f006ca5b0d19',2010,'SD','Sudan','communications',1424,'Telephones— main lines in use:
2.742 million (2007)
Telephones — mobile cellular:
7.983 million (2007)
Telephone system: general assessment : tele¬
phone services have improved significantly
and are available in most parts of the country
domestic: national trunk network consists
mostly of digital microwave radio relay;
fiber-optic links now in use in Colombo
area and fixed wireless local loops have
been installed; competition is strong in
mobile cellular systems and mobile cellular
subscribership is increasing
international: country code— 94; the SEA-
MEWR3 and SEA-ME-WE-4 submarine
cables provide connectivity to Asia,
Australia, Middle East, Europe, US; satellite
earth stations— 2 Intelsat (Indian Ocean)
Radio broadcast stations: AM 15, FM
52, shortwave 4 (2007)
Radios: 3.85 million (1997)
Television broadcast stations: 14 (2006)
Televisions: 1.53 million (1997)
Internet country code: Ik
Internet hosts: 4,940 (2008)
Internet Service Providers (ISPs):
5 (2000)
Internet users:
771,700 (2007)
Telephones— main lines in use:
345,200 (2007)
Telephones — mobile cellular:
7.464 million (2007)
Telephone system: general assess¬
ment: well-equipped system by regional
standards and being upgraded; cellular
communications started in 1996 and
have expanded substantially with wide
coverage of most major cities
domestic: consists of microwave radio relay,
cable, fiber optic, radiotelephone communi¬
cations, tropospheric scatter, and a domestic
satellite system with 14 earth stations
international: country code— 249; linked to
international submarine cable Fiber-Optic
Link Around the Globe (FLAG); satellite
earth stations— 1 Intelsat (Adantic Ocean),
1 Arabsat (2000)
Radio broadcasf stations: AM 12, FM 1,
shortwave 1 (1998)
Radios: 7.55 million (1997)
Television broadcast stations: 3 (1997)
Televisions: 2.38 million (1997)
Internet country code: sd
Internet hosts: 33 (2008)
Internet Service Providers (ISPs):
2 (2002)
Internet users: 1.5 million (2007)','990fb40850eea0650fca8c80192243c06add33da52d344258c423166bb778465','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3fd79a3c9327efcb940a5fbbdf24657f15161f407d4008f070d358521cf2da3',2010,'SR','Suriname','communications',1436,'Telephones — main lines in use:
81,500 (2006)
Telephones— mobile cellular:
320,000 (2006)
Telephone system: general assessment:
international facilities are good
domestic: combined fixed-line and mobile-
cellular teledensity about 90 telephones per
1 00 persons; microwave radio relay network
international: country code— 597; satellite
earth stations— 2 Intelsat (Atlantic Ocean)
Radio broadcast stations: AM 4, FM 13,
shortwave 1 (1998)
Radios:
300,000 (1997)
Television broadcast stations:
3 (plus 7 repeaters) (2000)
Televisions: 63,000 (1997)
Internet country code: .sr
Internet hosts: 33 (2008)
Internet Service Providers (ISPs):
2 (2000)
Internet users:
44,000 (2007)
Telephones— main lines in use: NA
Telephone system: general assessment:
probably adequate
domestic: local telephone service
international: country code— 47-790; satel¬
lite earth station— 1 of unknown type (for
communication with Norwegian mainland
only)
Radio broadcast stations: AM l, FM l
(plus 2 repeaters), shortwave 0 (1998)
Radios: NA
Television broadcast stations: NA
Televisions: NA
Internet country code: sj
Internet Service Providers (ISPs): 13
(Svalbard and Jan Mayen) (2000)
Internet users: NA
Telephones— main lines in use:
44,000 (2006)
Telephones— mobile cellular:
380,000 (2007)
Telephone system: general assessment: a
somewhat modern but not an advanced
system
domestic: mobile-cellular subscribership is
increasing; combined fixed-line and mobile
cellular teledensity approaching 40 tele¬
phones per 100 persons; telephone system
consists of carrier-equipped, open-wire lines
and low-capacity, microwave radio relay
international: country code— 268; satellite
earth station— 1 Intelsat (Adantic Ocean)
(2007)
Radio broadcast stations: AM 3, FM 2
(plus 4 repeaters), shortwave 3 (2004)
Radios: 170,000 (1999)
Television broadcast stations: 12
(includes 7 relay stations) (2004)
Televisions: 23,000 (2000)
Internet country code: .sz
Internet hosts: 2,582 (2008)
Internet Service Providers (ISPs):
5 (2002)
Internet users:
42,000 (2006)','45d29f3467e5335c5ac299dbea7388c2923e9c4edd767fc591d4b358f3bf17bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d78a2433c0f2b9495584319f522c533dc26afc0c57a1d95479f4992274f8a75a',2010,'TJ','Tajikistan','communications',1444,'Telephones— main lines in use: 340,000
(2007)
Telephones — mobile cellular: 3.5 million
(2007)
Telephone system: general assessment:
foreign investment in the telephone system
has resulted in major improvements
665
THE CIA WORLD FACTBOOK
domestic: die domestic telecommunica¬
tions network has historically been under
funded and poorly maintained; main line
availability has not changed significandy
since 1998; mobile cellular use, aided by
competition among multiple operators, has
expanded rapidly; coverage now extends to
all major cities and towns
international: country code— 992; linked by
cable and microwave radio relay to other
CIS republics and by leased connections to
the Moscow international gateway switch;
Dushanbe linked by Intelsat to interna¬
tional gateway switch in Ankara (Turkey);
satellite earth stations— 3 (2 Intelsat and 1
Orbita) (2008)
Radio broadcast stations: 16 (number of
licensed stations with only about 1 0 broad¬
casting) (2009)
Radios: 1.291 million (1991)
Television broadcast stations: 24
(number of licensed stations with only
about 1 5 active) (2009)
Televisions: 820,000 (1997)
Internet country code: .tj
Internet hosts: 1,158 (2008)
Internet Service Providers (ISPs): 4
(2002)
Internet users: 19,500 (2005)
Telephones— main lines in use: 165,013
(2008)
Telephones — mobile cellular: 9.358
million (2008)
Telephone system: general assessment:
telecommunications services are inadequate;
system operating below capacity and being
modernized for better service; small aperture
terminal (VSAT) system under construction
domestic: fixed-line telephone network
inadequate with less than 1 connection per
100 persons; mobile-cellular service, aided
by multiple providers, is increasing; trunk
service provided by open-wire, microwave
radio relay, tropospheric scatter, and fiber¬
optic cable; some links being made digital
international: country code— 255; satellite
earth stations— 2 Intelsat (1 Indian Ocean,
1 Atlantic Ocean)
Radio broadcast stations: AM 12, FM
11, shortwave 2 (1998)
Radios: 8.8 million (1997)
Television broadcast stations: 3 (1999)
Televisions: 103,000 (1997)
Internet country code: tz
Internet hosts: 24,271 (2008)
Internet Service Providers (ISPs): 6
(2000)
Internet users: 400,000 (2007)','c4e6d00e9414f6d5b1e87ae4869bd9e870f57e787111dfb2e3d2457e4bebdcba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d1c1ec87d73058ffe86d8a0423d8e350e96861b0c9add9836f03f5118069365',2010,'TL','Timor-Leste','communications',1446,'Telephone system: general assessment: high
quality system, especially in urban areas like
Bangkok
domestic: fixed line system provided by
both a government owned and commercial
provider; wireless service expanding rapidly
and outpacing fixed lines
international: country code— 66; connected
to major submarine cable systems providing
links diroughout Asia, Australia, Middle East,
Europe, and US; satellite earth stations— 2
Intelsat (1 Indian Ocean, 1 Pacific Ocean)
Radio broadcast stations: AM 238, FM
351, shortwave 6 (2007)
Radios: 13.96 million (1997)
Television broadcast stations: 1 1 1 (2006)
Televisions: 15.19 million (1997)
Internet country code: th
Internet hosts: 1.116 million (2008)
Internet Service Providers (ISPs): 15
(2000)
Internet users: 13.416 million (2007)
Telephones— main lines in use: 2,400
(2006)
Telephones— mobile cellular: 69,000
(2007)
Telephone system: general assessment:
rudimentary service limited to urban areas
domestic: system suffered significant damage
during the violence associated with inde¬
pendence; extremely limited fixed-line serv¬
ices; mobile-cellular services and coverage
limited primarily to urban areas
international: country code— 670; interna¬
tional service is available in major urban
centers
Radio broadcast stations: at least 21
(Timor-Leste has one national public broad¬
caster and 20 community and church radio
stations— station frequency types NA) (2007)
Radios: NA
Television broadcast stations: l (Timor-
Leste has one national public broadcaster)
Televisions: NA
Internet country code: tl
Internet hosts: 285 (2008)
Internet Service Providers (ISPs): NA
Internet users: 1,200 (2006)','08b14fe74b0e36dc3fbc58dd799a6fd143607cbf2b2acc8d0cea41ef7631fd05','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b56ff4f5d0a6a48ef10177eebd0e89a72bb46c076c2964bde7d82e18f922522a',2010,'TK','Tokelau','communications',1458,'Telephones — main lines in use: 82,100
(2006)
Telephones— mobile cellular: 1.19
million (2007)
Telephone system: general assessment: fair
system based on a network of microwave
radio relay routes supplemented by open-
wire lines and a mobile-cellular system
domestic: microwave radio relay and
open-wire lines for conventional system;
combined fixed-line and mobile-cellular
teledensity roughly 1 5 telephones per 1 00
persons
international: country code— 228; satellite
earth stations— 1 Intelsat (Atlantic Ocean),
1 Symphonie
Radio broadcast stations: AM 2, FM 9,
shortwave 4 (1998)
Radios: 940,000 (1997)
Television broadcast stations: 3 (plus 2
repeaters) (1997)
Televisions: 73,000 (1997)
Internet country code: tg
Internet hosts: 769 (2008)
Internet Service Providers (ISPs): 3
(2001)
Internet users: 320,000 (2006)','a9d3c5a887774755161a78e0780bc01a5e779f840fa324c1c771a80958cc7bf6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60a72f90dda38c2cb78fcbc0f778729167cb4231e4f4be11ab29bfbef428aa7d',2010,'TO','Tonga','communications',1465,'Telephones— main lines in use: 300 (2002)
Telephone system: general assessment:
modern satellite-based communications
system
domestic: radiotelephone service between
islands
international: country code— 690;
radiotelephone service to Samoa;
government-regulated telephone service
(TeleTok); satellite earth stations— 3
Radio broadcast stations: AM NA, FM
NA, shortwave NA (one radio station
provides service to all islands) (2002)
Radios: 1,000 (1997)
Internet country code: tk
Internet hosts: 273 (2008)
Internet Service Providers (ISPs): l (2000)
Internet users: NA
Telephones— main lines in use: 21,000
(2007)
Telephones— mobile cellular: 46,500
(2007)
Telephone system: general assessment:
competition between Tonga Telecommuni¬
cations Corporation (TCC) and Shoreline
Communications Tonga (SCT) is acceler¬
ating expansion of telecommunications;
SCT recently granted authority to develop
high-speed digital service for telephone,
Internet, and television
domestic: combined fixed-line and
mobile-cellular teledensity roughly 40
telephones per 100 persons; fully auto¬
matic switched network
international: country code— 676; satellite
earth station— 1 Intelsat (Pacific Ocean)
(2004)
Radio broadcast stations: AM 1 , FM 4,
shortwave 1 (2001)
Radios: 61,000 (1997)
Television broadcast stations: 3 (2004)
Televisions: 2,000 (1997)
Internet country code: to
Internet hosts: 19,231 (2008)
Internet Service Providers (ISPs): 2
(2000)
Internet users: 8,400 (2007)','9cb3038de81b9d52eab93359395801aa1893fd9844e6606c023b8efc3783c7a5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6744d12b8b8cfbaa8ed64b6d6f65bce0ebf5b883cf2ef181faa05f178ff6acf0',2010,'TN','Tunisia','communications',1476,'Telephones — main lines in use: 1.273
million (2007)
Telephones — mobile cellular: 7.842
million (2007)
Telephone system: general assessment:
above the African average and continuing to
be upgraded; key centers are Sfax, Sousse,
Bizerte, and Tunis; Internet access available
domestic: in an effort jumpstart expansion of
the fixed-line network, the government has
awarded a concession to build and operate
a VSAT network with international connec¬
tivity; competition between the two mobile-
cellular service providers has resulted in
lower activation and usage charges and a
strong surge in subscribership; expansion
of mobile-cellular services to include multi-
media messaging and e-mail and Internet
to mobile phone services also leading to a
surge in subscribership; overall fixed-line
and mobile-cellular teledensity is about 90
telephones per 100 persons
international: country code— 216; a landing
point for the SEA-ME-WE-4 submarine
cable system that provides links to Europe,
Middle East, and Asia; satellite earth
stations— 1 Intelsat (Adantic Ocean) and 1
Arabsat; coaxial cable and microwave radio
relay to Algeria and Libya; participant in
Medarabtel; 2 international gateway digital
switches
Radio broadcasf sfafions: AM 7, FM 38,
shortwave 2 (2007)
Radios: 2.06 million (1997)
Television broadcast stations: 26 (plus
76 repeaters) (1995)
Televisions: 920,000 (1997)
Internet country code: tn
Internet hosts: 376 (2008)
Internet Service Providers (ISPs): l (2000)
Internet users: 1.722 million (2007)
Telephones— main lines in use: 18.413
million (2007)
Telephones— mobile cellular: 61.976
million (2007)
Telephone system: general assessment:
comprehensive telecommunications
network undergoing rapid modernization
and expansion especially in mobile-cellular
services
domestic: additional digital exchanges are
permitting a rapid increase in subscribers;
the construction of a network of technolog¬
ically advanced intercity trunk lines, using
both fiber-optic cable and digital microwave
radio relay, is facilitating communication
between urban centers; remote areas are
reached by a domestic satellite system; the
number of subscribers to mobile-cellular
telephone service is growing rapidly
international: country code— 90; interna¬
tional service is provided by the SEA-ME-
WE-3 submarine cable and by submarine
fiber-optic cables in the Mediterranean
and Black Seas that link Turkey with Italy,
Greece, Israel, Bulgaria, Romania, and
Russia; satellite earth stations— 12 Intelsat;
mobile satellite terminals— 328 in the
Inmarsat and Eutelsat systems (2002)
Radio broadcasf sfations: AM 16, FM
107, shortwave 6 (2001)
Radios: 11.3 million (1997)
Television broadcast stations: 635 (plus
2,934 repeaters) (1995)
Televisions: 20.9 million (1997)
Internet country code: tr
Internet hosts: 2.667 million (2008)
Internet Service Providers (ISPs): 50
(2001)
Internet users: 13.15 million (2006)','cfb45cc33414795abb8b1dcec40a836bfa5abb0fd59108fdd5b42cf743cbf493','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c241fefa85a815449b200f4745105b40107d9c8942032c06f0f4fcd7a4f73bb',2010,'TC','Turks and Caicos Islands','communications',1484,'Telephones — main lines in use: 457,900
(2007)
Telephones— mobile cellular: 810,000
(2008)
Telephone system: general assessment: tele¬
communications network remains under¬
developed and progress toward improve¬
ment is slow; strict government control
and censorship inhibits liberalization and
modernization
domestic: Turkmentelekom, in cooperation
with foreign partners, has installed high
speed fiber-optic lines and has upgraded
most of die country’s telephone exchanges
and switching centers with new digital
technology; mobile telephone usage is
expanding with Russia’s Mobile Telesys¬
tems (MTS) the primary service provider
international: country code— 993; linked by
fiber-optic cable and microwave radio relay
to other CIS republics and to other coun-
i
tries by leased connections to the Moscow
international gateway switch; an exchange
in Ashgabat switches international traffic
through Turkey via Intelsat; satellite earth
stations— 1 Orbita and 1 Intelsat (2008)
Radio broadcast sfations: AM 16, FM 8,
shortwave 2 (1998)
Radios: 1.225 million (1997)
Television broadcast stations: 4 (govem-
ment-owned and programmed) (2004)
Televisions: 820,000 (1997)
Internet country code: tm
Internet hosts: 640 (2008)
Internet Service Providers (ISPs): 1
Internet users: 70,000 (2007)','5ced1e68f3922f524a7b92b984610dcbde9cf60282cf4e6181d77f84457df3c2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c5f0176dc7460411294713eabd58347a06b5989d4ac09d068922cebee04b1f4',2010,'TV','Tuvalu','communications',1492,'Telephones — main lines in use: 5,700
(2002)
Telephones— mobile cellular: 1,700
(1999)
Telephone system: general assessment:
fully digital system with international direct
dialing
domestic: full range of services available;
GSM wireless service available
international: country code— 1-649; the
Americas Region Caribbean Ring System
(ARCOS-1) fiber optic telecommunications
submarine cable provides connectivity to
South and Central America, parts of the
Caribbean, and the US; satellite earth
station— 1 Intelsat (Atlantic Ocean)
Tuvalu negotiated a contract leasing its
Internet domain name “.tv” for $50 million
in royalties over a 1 2-year period.
Telephones — main lines in use: 900 (2005)
Telephones— mobile cellular: 1,300
(2005)
Telephone system: general assessment:
serves particular needs for internal commu¬
nications
domestic: radiotelephone communications
between islands
international: country code— 688; interna¬
tional calls can be made by satellite
Radio broadcast stations: AM 1, FM 1,
shortwave 0 (2004)
Radios: 4,000 (1997)
Television broadcast stations: 0 (2004)
Televisions: 800
Internet country code: tv
Internet hosts: 56,209 (2008)
Internet Service Providers (ISPs): 1 (2000)
Internet users: 1,300 (2002)','8a26338853ec5504f527f751bca8b5055c3e3021b236ce5f475ac5f3f5ac347e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ec320aa24636aa20682d875cfda6f3956d667fef2a5b82a69df28b5b8077022',2010,'UG','Uganda','communications',1504,'Telephones— main lines in use: 162,300
(2007)
Telephones — mobile cellular: 4.195
million (2007)
Telephone system: general assessment: seri¬
ously inadequate; mobile cellular service is
increasing rapidly, but the number of main
lines is still deficient; e-mail and Internet
services are available
domestic: intercity traffic by wire, microwave
radio relay, and radiotelephone communi¬
cation stations, fixed and mobile-cellular
systems for short-range traffic
international: country code— 256; satellite
earth stations— 1 Intelsat (Adantic Ocean)
and 1 Inmarsat; analog links to Kenya and
Tanzania
Radio broadcasf stations: AM 7, FM 33,
shortwave 2 (2001)
Radios: 5 million (2001)
Television broadcast stations: 8 (plus l
repeater) (2001)
Televisions: 500,000 (2001)
Internet country code: ug
Internet hosts: l ,090 (2008)
Internet Service Providers (ISPs): 2 (2000)
Internet users: 2 million (2007)','ed89fbe78732face4475cf3e0621362d89d82c7b2eb39eb46b5754f6f6bf2b98','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('775fda66eb174b492e2763437bc2f1e8b8c4bdb49c40a2c6a7bd8ac7162f9bc3',2010,'UA','Ukraine','communications',1512,'Telephones — main lines in use: 12.858
million (2007)
Telephones— mobile cellular: 55.24
million (2007)
Telephone system: general assessment:
Ukraine’s telecommunication develop¬
ment plan emphasizes improving domestic
trunk lines, international connections, and
the mobile-cellular system
domestic: at independence in December
1991, Ukraine inherited a telephone system
that was antiquated, inefficient, and in disre¬
pair; more than 3.5 million applications for
telephones could not be satisfied; telephone
density is rising and the domestic trunk
system is being improved; about one-third of
Ukraine’s networks are digital and a majority
of regional centers now have digital switching
stations; improvements in local networks
and local exchanges continue to lag; the
mobile-cellular telephone system’s expan¬
sion has slowed, largely due to saturation of
the market which had reached 100 mobile
phones per 1 00 people by early 2007
international: country code— 380; 2 new.
domestic trunk lines are a part of the fiber¬
optic Trans-Asia-Europe (TAE) system and
3 Ukrainian links have been installed in
the fiber-optic Trans-European Lines (TEL)
project that connects 18 countries; addi¬
tional international service is provided by
the Italy-Turkey-Ukraine-Russia (ITUR)
fiber-optic submarine cable and by an
unknown number of earth stations in the
Intelsat, Inmarsat, and Intersputnik satel¬
lite systems
Radio broadcast stations: 524 (station
frequency types NA) (2006)
Radios: 45.05 million (1997)
Television broadcast stations: 647 (2006)
Televisions: 18.05 million (1997)
Internet country code: ua
Internet hosts: 524,202 (2008)
Internet Service Providers (ISPs): 260
(2001)
Internet users: 10 million (2007)','cc6a0ef83cf3b2fcfd275d9448b0602f10c18048b8f01e86bcdc6d98698ad37c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef0970302c78704c3d044c871fc97b600f6345ee26fd0297bffc7b710ed6873',2010,'AE','United Arab Emirates','communications',1521,'Telephones— main lines in use: 1.385
million (2007)
Telephones— mobile cellular: 7.595
million (2007)
Telephone system: general assessment:
modem fiber-optic integrated services;
digital network with rapidly growing use of
mobile-cellular telephones; key centers are
Abu Dhabi and Dubai
domestic: microwave radio relay, fiber optic
and coaxial cable
international: country code— 971; linked to
the international submarine cable FLAG
(Fiber-Optic Link Around the Globe);
landing point for both the SEA-ME-WE-
3 and SEA-ME-WE-4 submarine cable
networks; satellite earth stations— 3 Intelsat
(1 Adantic Ocean and 2 Indian Ocean) and
1 Arabsat; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
Radio broadcast stations: AM 1 3, FM 8,
shortwave 2 (2004)
Radios: 820,000 (1997)
Television broadcast stations: 1 5 (2004)
Televisions: 310,000(1997)
Internet country code: ae
711
THE CIA WORLD FACTBOOK
Internet hosts: 381,915 (2008)
Internet Service Providers (ISPs): 1 (2000)
Internet users: 2.3 million (2007)','f0565972853730f92f4e57b9c58beb6f934c215b9f1ef32a5b3f5bf1756237d4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb2406df27362d6672eb85e337adffe12021e4d1e434181b5cc7097551f35ca1',2010,'GB','United Kingdom','communications',1528,'Telephones — main lines in use: 33.682
million (2007)
Telephones— mobile cellular: 71.992
million (2007)
Telephone system: general assessment:
technologically advanced domestic and
international system
domestic: equal mix of buried cables, micro¬
wave radio relay, and fiber-optic systems
international: country code— 44; numerous
submarine cables provide links throughout
Europe, Asia, Australia, the Middle East,
and US; satellite earth stations— 10 Intelsat
(7 Atlantic Ocean and 3 Indian Ocean),
1 Inmarsat (Atlantic Ocean region), and
1 Eutelsat; at least 8 large international
switching centers
Radio broadcast stations: AM 206, FM
696, shortwave 3 (2008)
Radios: 84.5 million (1997)
Television broadcast stations: 940 (2008)
Televisions: 30.5 million (1997)
Internet country code: uk
Internet hosts: 8.269 million (2008)
Internet Service Providers (ISPs): more
than 400 (2000)
Internet users: 40.2 million (2007)','07a646182154e0df934d0d76c4d9c8247c8d3128b80a5e65e3817616b68e8547','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61545ada3bda9a7825dc8f1e5dc7f7ada50d3ad482da8cea4577b28329997b57',2010,'UY','Uruguay','communications',1539,'Telephones — main lines in use: 965,200
(2007)
Telephones — mobile cellular: 3.004
million (2007) <
Telephone system: general assessment:
fully digitalized
domestic: most modern facilities concen¬
trated in Montevideo; new nationwide
microwave radio relay network; overall
fixed-line and mobile-cellular teleden-
sity is 115 telephones per 100 persons
international: country code— 598; the
UNISOR submarine cable system provides
direct connectivity to Brazil and Argentina;
satellite earth stations— 2 Intelsat (Atlantic
Ocean) (2002)
Radio broadcast stations: AM 93, FM
191, shortwave 7 (2005)
Radios: 1.97 million (1997)
Television broadcast stations: 62 (2005)
Televisions: 782,000 (1997)
Internet country code: uy
Internet hosts: 480,593 (2008)
Internet Service Providers (ISPs): 14
(2001)
Internet users: 968,000 (2007)','a0e2a1969528562c9090d100cbc51d48062560075266d9578f96e34296757235','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa0c83d9284ec3ac8ad7f1664f9ab9d76c9e489201df82e0544b74c63ac6a0ec',2010,'UZ','Uzbekistan','communications',1544,'Telephones — main lines in use: 1.821
million (2007)
Telephones— mobile cellular: 10.4
million (2008)
Telephone system: general assessment:
antiquated and inadequate; in serious need
of modernization
domestic: the main line telecommunications
system is dilapidated and telephone density
is low; the state-owned telecommunications
company, Uzbektelecom, is using loans from
the Japanese government and the China
Development Bank to improve mainline
services; completion of conversion to digital
exchanges planned for 2010; mobile serv¬
ices are growing rapidly, with the subscriber
base reaching 1 0.4 million in 2008
international: country code— 998; linked
by fiber-optic cable or microwave radio
relay with CIS member states and to other
countries by leased connection via the
Moscow international gateway switch; after
the completion of the Uzbek link to the
Trans-Asia-Europe (TAE) fiber-optic cable,
Uzbekistan plans to establish a fiber-optic
connection to Afghanistan (2008)
Radio broadcast stations: AM 4, FM 1 2,
shortwave 3 (2008)
Radios: 10.8 million (1997)
Television broadcast stations: 28
(includes 1 cable rebroadcaster in Tashkent
and approximately 20 stations in regional
capitals) (2006)
Televisions: 6.4 million (1997)
Internet country code: uz
Internet hosts: 38,183 (2008)
Internet Service Providers (ISPs): 42
(2000)
Internet users: 2.1 million (2008)','48992483368afbd1350366aeda77308b2a0554f79aba08dc7e87b76144168eed','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d601ac2b1b9bf2b1de88bcfbb711383fbeb6824c33b63c4b707aa2f031421d',2010,'VU','Vanuatu','communications',1552,'Telephones — main lines in use: 8,8 00
(2007)
Telephones — mobile cellular: 26,000
(2007)
Telephone system: general assessment: NA
domestic: NA
international: country code— 678; satellite
earth station— 1 Intelsat (Pacific Ocean)
Radio broadcast stations: AM 2, FM 4,
shortwave 1 (2001)
Radios: 67,000 (1997)
Television broadcast stations: 1 (2004)
Televisions: 2,300 (1999)
Internet country code: vu
Internet hosts: 990 (2008)
Internet Service Providers (ISPs): l (2000)
Internet users: 17,000 (2007)
Telephones— main lines in use: 5.082
million (2007)
Telephones — mobile cellular: 23.82
million (2007)
Telephone system: general assessment:
modern and expanding
domestic: domestic satellite system with 3
earth stations; recent substantial improve¬
ment in telephone service in rural areas;
substantial increase in digitalization
of exchanges and trunk lines; installa¬
tion of a national interurban fiber-optic
THE CIA WORLD FACTBOOK
network capable of digital multimedia
services; fixed-line teledensity 20 per 100
persons; mobile-cellular teledensity more
than 90 per 100 persons ,
international: country code— 58; submarine
cable systems provide connectivity to the
Caribbean, Central and South America,
and US; satellite earth stations— 1 Intelsat
(Atlantic Ocean) and 1 PanAmSat; partici¬
pating with Colombia, Ecuador, Peru, and
Bolivia in the construction of an interna¬
tional fiber-optic network (2007)
Radio broadcast stations: AM 201, FM
unknown, but at least 25 in Caracas, short¬
wave 1 1 (1998)
Radios: 10.75 million (1997)
Television broadcast stations: 66 (plus
45 repeaters) (1997)
Televisions: 4.1 million (1997)
Internet country code: ve
Internet hosts: 145,394 (2008)
Internet Service Providers (ISPs): 16
(2000)
Internet users: 5.72 million (2007)
Telephones— main lines in use: 10.8
million (2007)
Telephones— mobile cellular: 33.2
million (2007)
Telephone system: general assessment :
Vietnam is putting considerable effort
into modernization and expansion of its
telecommunication system, but its perform¬
ance continues to lag behind that of its
more modern neighbors
domestic: all provincial exchanges are digital¬
ized and connected to Hanoi, Da Nang, and
Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; main lines
have been substantially increased, and die
use of mobile telephones is growing rapidly
international: country code— 84; a landing
point for the SEA-ME-WE-3, the C2C, and
Thailand-Vietnam-Hong Kong submarine
cable systems; the Asia-America Gateway
submarine cable system, scheduled for
completion by the end of 2008, will
provide new access links to Asia and the
US; satellite earth stations— 2 Intersputnik
(Indian Ocean region)
Radio broadcasf sfations: AM 65, FM 7,
shortwave 29 (1999)
Radios: 8.2 million (1997)
Television broadcast stations: 67
(includes 61 relay, provincial, and city TV
stations) (2006)
Televisions: 3.57 million (1997)
Internet country code: .vn
Internet hosts: 84,151 (2008)
Internet Service Providers (ISPs): 5
(2000)
Internet users: 17.87 million (2007)
Telephones— main lines in use: 71,700
(20*05)
Telephones— mobile cellular: 80,300
(2005)
Telephone system: general assessment:
modern system with total digital switching,
uses fiber-optic cable and microwave radio
relay
domestic: frill range of services available
international: country code— 1-340; subma¬
rine cable connections to US, the Carib¬
bean, Central and South America; satellite
earth stations— NA
Radio broadcast stations: AM 6, FM 16,
shortwave 0 (2005)
Radios: 107,000 (1997)
Television broadcast stations: 5 (2006)
Televisions: 68,000 (1997)
Internet country code: vi
Internet hosts: 4,610(2008)
Internet Service Providers (ISPs): 50
(2000)
Internet users: 30,000 (2007)
Telephone system: general assessment:
satellite communications; 2 DSN circuits
off the Overseas Telephone System (OTS)
domestic: NA
international: NA
Radio broadcast stations: AM 0, FM
0, shortwave 0 (American Armed Forces
Radio and Television Service (AFRTS))
provides satellite radio service (2005)
Television broadcast stations: 0 (2005)','dbdb69102574d7d46f21a71cfda8f441574bbcb2280d09b1a70195453ec80f32','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a97cd84497ca513c8f95973430e00b5dd4b10c8a74ff5fbc6e6cfa07c30df70',2010,'EH','Western Sahara','communications',1563,'Telephones — main lines in use: about
2,000 (1999 est.)
Telephones— mobile cellular: 0 (1999)
Telephone system: general assessment:
sparse and limited system
domestic: NA
international: country code— 212; tied into
Morocco’s system by microwave radio
relay, tropospheric scatter, and satellite;
satellite earth stations— 2 Intelsat (Adantic
Ocean) linked to Rabat, Morocco
Radio broadcast stations: AM 2, FM 0,
shortwave 0 (1998)
Radios: 56,000 (1997)
Television broadcast stations: NA
Televisions: 6,000 (1997)
Internet country code: eh
Internet Service Providers (ISPs): 1 (2000)
Internet users: NA
Telephones— main lines in use:
1.263.367.600 (2005)
Telephones— mobile cellular:
2.168.433.600 (2005)
Telephone system: general assessment: NA
domestic: NA
international: NA
Radio broadcast stations: AM NA, FM
NA, shortwave NA
Radios: NA
Television broadcast stations: NA
Televisions: NA
Internet Service Providers (ISPs): 10,350
(2000 est.)
Internet users: 1,018,057,389 (2005)','5299f97258dafe51363a7d77df5df165b717d5405a04822bf2239daf64317ad7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef9b11cb1b43514c3331f2942586d4a28b46cf4ce4dea46e1290d886d2f09987',2010,'YE','Yemen','communications',1571,'Telephones— main lines in use:
968,300 (2006)
Telephones— mobile cellular:
2.978 million (2006)
Telephone system: general assessment: since
unification in 1 990, efforts have been made
to create a national telecommunications
network
domestic: the national network consists of
microwave radio relay, cable, tropospheric
scatter, GSM and CDMA mobile-
cellular telephone systems; fixed-line
and mobile-cellular teledensity remains
low by regional standards
international: country code— 967; landing
point for the international submarine
cable Fiber-Optic Link Around the Globe
(FLAG); satellite earth stations— 3 Intelsat
(2 Indian Ocean and 1 Adantic Ocean), 1
Intersputnik (Adantic Ocean region), and
2 Arabsat; microwave radio relay to Saudi
Arabia and Djibouti
Radio broadcasf sfafions: AM 6, EM 1,
shortwave 2 (1998)
Radios: 1.05 million (1997)
Television broadcasf sfafions: 3 (including
one Egypt-based station that broadcasts in
Yemen); plus several repeaters (2007)
Televisions: 470,000 (1997)
Internet country code: ye
Internet hosts: 167 (2008)
Internet Service Providers (ISPs):
1 (2000)
Internet users: 320,000 (2007)','65e8d8dbdc69c5e94824cedec3a95ed99a5c5a1dd8ccee13bf1c804a1343772f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3adf2dd5468d533ecc24c20c03a057229b2c32779eca2cd6465ecd7b8591d80',2010,'ZM','Zambia','communications',1579,'Telephones— main lines in use: 91,800
(2007)
Telephones— mobile cellular: 2.639
million (2007)
Telephone system: general assessment:
facilities are aging but still among the best
in sub-Saharan Africa
domestic: high-capacity microwave radio
relay connects most larger towns and cities;
several cellular telephone services in opera¬
tion and network coverage is improving;
Internet service is widely available; very
small aperture terminal (VSAT) networks
are operated by private firms
international: country code— 260; satellite
earth stations— 2 Intelsat (1 Indian Ocean
and 1 Atlantic Ocean)
Radio broadcasf sfafions: AM 19, FM 5,
shortwave 4 (2001)
Radios: 1.2 million (2001)
Television broadcasf sfafions: 9 (2001)
Televisions: 277,000 (1997)
Internet counfry code: zm
Infernef hosfs: 7,610 (2008)
Infernef Service Providers (ISPs): 5
(2001)
Infernef users: 500,000 (2007)','c47830a72250b1d64e51e0f6d2f76bc306352b547217f51502e39fa9b0b070a9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3a0c6f6b6983c2bab0801c041b561944bd5cefebd255a557774c06f7885a0eb',2010,'ZW','Zimbabwe','communications',1588,'Telephones — main lines in use: 344,500
(2007)
Telephones — mobile cellular: 1.226
million (2007)
Telephone system: general assessment:
system was once one of the best in Africa,
but now suffers from poor maintenance;
more than 100,000 outstanding requests
for connection despite an equally large
number of installed but unused main lines
domestic: consists of microwave radio relay
links, open-wire lines, radiotelephone
communication stations, fixed wireless
local loop installations, and a substantial
mobile-cellular network; Internet connec¬
tion is available in Harare and planned
for all major towns and for some of the
smaller ones
international: country code— 263; satellite
earth stations— 2 Intelsat; 2 international
digital gateway exchanges (in Harare and
Gweru)
Radio broadcast stations: AM 7, FM 20
(plus 1 7 repeater stations), shortwave 1
(1998)
Radios: 1.14 million (1997)
Television broadcast stations: 16 (1997)
Televisions:
370,000 (1997)
Internet country code: zw
Internet hosts: 19,157 (2008)
Internet Service Providers (ISPs):
6 (2000)
Internet users:
1.351 million (2007)','e5cf446d1482c77fa3f83eb49bfb91347103f6671dbcb4cdac87a51f1e1978b4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad32b2c7b14fc54f6afaeda6c94d6e1953a58275ee330deca6b1434139ff36db',2010,'','','communications',6,'Telephones - main lines in use:
Telephones - mobile cellular:
Telephone system:
general assessment
domestic
international
Broadcast media:
Internet country code:
Internet hosts:
Internet users:
Communications - note:','fde38277ba99384b1b5ad9506b1829be3b705976f2c83612e78a005a975314d7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8634b7f61fe3f09156b5e42f24326733c33d9de3542ac90b418f63f251626f93',2010,'ZW','Zimbabwe','communications',13,'Telephones - main lines in use:
Telephones - mobile cellular:
Internet hosts:
Internet users:
This category deals with the means of exchanging information and
includes the telephone, radio, television, and Internet host entries.
Communications - note
This entry includes miscellaneous communications information of
significance not included elsewhere.
Constitution
This entry includes the dates of adoption, revisions, and major
amendments.
Coordinated Universal Time (UTC)
UTC is the international atomic time scale that serves as the basis
of timekeeping for most of the world. The hours, minutes, and
seconds expressed by UTC represent the time of day at the Prime
Meridian (0 deg. longitude) located near Greenwich, England as reckoned
from midnight. UTC is calculated by the Bureau International des
Poids et Measures (BIPM) in Sevres, France. The BIPM averages data
collected from more than 200 atomic time and frequency standards
located at about 50 laboratories worldwide. UTC is the basis for all
civil time with the Earth divided into time zones expressed as
positive or negative differences from UTC. UTC is also referred to
as "Zulu time." See the Standard Time Zones of the World map
included with the Reference Maps.
Country data codes
See Data codes.
Country map
Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time
of preparation. Names and/or boundaries may have changed
subsequently.
Country name
This entry includes all forms of the country''s name approved by the
US Board on Geographic Names (Italy is used as an example):
conventional long form (Italian Republic), conventional short form
(Italy), local long form (Repubblica Italiana), local short form
(Italia), former (Kingdom of Italy), as well as the abbreviation.
Also see the Terminology note.
Crude oil
See entry for oil.
Current account balance
This entry records a country''s net trade in goods and services, plus
net earnings from rents, interest, profits, and dividends, and net
transfer payments (such as pension funds and worker remittances) to
and from the rest of the world during the period specified. These
figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
D
Data codes
This information is presented in This information is presented in <a
href = "../appendix/appendix-d.html"Appendix D: Cross-Reference List
of Country Data Codes and and <a href =
"../appendix/appendix-e.html" Appendix E: Cross-Reference List of
Hydrographic Data Codes.
Date of information
In general, information available as of January in a given year is
used in the preparation of the printed edition.
Daylight Saving Time (DST)
This entry is included for those entities that have adopted a policy
of adjusting the official local time forward, usually one hour, from
Standard Time during summer months. Such policies are most common in
mid-latitude regions.
Death rate
This entry gives the average annual number of deaths during a year
per 1,000 population at midyear; also known as crude death rate. The
death rate, while only a rough indicator of the mortality situation
in a country, accurately indicates the current mortality impact on
population growth. This indicator is significantly affected by age
distribution, and most countries will eventually show a rise in the
overall death rate, in spite of continued decline in mortality at
all ages, as declining fertility results in an aging population.
Debt - external
This entry gives the total public and private debt owed to
nonresidents repayable in internationally accepted currencies,
goods, or services. These figures are calculated on an exchange rate
basis, i.e., not in purchasing power parity (PPP) terms.
Dependency status
This entry describes the formal relationship between a particular
nonindependent entity and an independent state.
Dependent areas
This entry contains an alphabetical listing of all nonindependent
entities associated in some way with a particular independent state.
Diplomatic representation
The US Government has diplomatic relations with 189 independent
states, including 187 of the 192 UN members (excluded UN members are
Bhutan, Cuba, Iran, North Korea, and the US itself). In addition,
the US has diplomatic relations with 2 independent states that are
not in the UN, the Holy See and Kosovo, as well as with the EU.
Diplomatic representation from the US
This entry includes the chief of mission, embassy address, mailing
address, telephone number, FAX number, branch office locations,
consulate general locations, and consulate locations.
Diplomatic representation in the US
This entry includes the chief of mission, chancery, telephone, FAX,
consulate general locations, and consulate locations.
Disputes - international
This entry includes a wide variety of situations that range from
traditional bilateral boundary disputes to unilateral claims of one
sort or another. Information regarding disputes over international
terrestrial and maritime boundaries has been reviewed by the US
Department of State. References to other situations involving
borders or frontiers may also be included, such as resource
disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or
recognition by the US Government.
Distribution of family income - Gini index
This index measures the degree of inequality in the distribution of
family income in a country. The index is calculated from the Lorenz
curve, in which cumulative family income is plotted against the
number of families arranged from the poorest to the richest. The
index is the ratio of (a) the area between a country''s Lorenz curve
and the 45 degree helping line to (b) the entire triangular area
under the 45 degree line. The more nearly equal a country''s income
distribution, the closer its Lorenz curve to the 45 degree line and
the lower its Gini index, e.g., a Scandinavian country with an index
of 25. The more unequal a country''s income distribution, the farther
its Lorenz curve from the 45 degree line and the higher its Gini
index, e.g., a Sub-Saharan country with an index of 50. If income
were distributed with perfect equality, the Lorenz curve would
coincide with the 45 degree line and the index would be zero; if
income were distributed with perfect inequality, the Lorenz curve
would coincide with the horizontal axis and the right vertical axis
and the index would be 100.
E
general assessment: system was once one of the best in
Africa, but now suffers from poor maintenance
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile-cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; 2 international digital gateway exchanges (in Harare and
Gweru)
======================================================================
@2125
Field Listing :: Terrain
This entry contains a brief description of the topography.
Country
Terrain
mostly high plateau with higher central plateau (high
veld); mountains in east
======================================================================
@2127
Field Listing :: Total fertility rate
This entry gives a figure for the average number of children that
would be born per woman if all women lived to the end of their
childbearing years and bore children according to a given fertility
rate at each age. The total fertility rate (TFR) is a more direct
measure of the level of fertility than the crude birth rate, since
it refers to births per woman. This indicator shows the potential
for population change in the country. A rate of two children per
woman is considered the replacement rate for a population, resulting
in relative stability in terms of total numbers. Rates above two
children indicate populations growing in size and whose median age
is declining. Higher rates may also indicate difficulties for
families, in some situations, to feed and educate their children and
for women to enter the labor force. Rates below two children
indicate populations decreasing in size and growing older. Global
fertility rates are in general decline and this trend is most
pronounced in industrialized countries, especially Western Europe,
where populations are projected to decline dramatically over the
next 50 years.
Country Comparison to the World
Country
Total fertility rate(children born/woman)
3.66 children born/woman (2010 est.)
======================================================================
@2128
Field Listing :: Government type
This entry gives the basic form of government. Definitions of the
major governmental terms are as follows. (Note that for some
countries more than one definition applies.):
Absolute monarchy - a form of government where the monarch rules
unhindered, i.e., without any laws, constitution, or legally
organized opposition.
Anarchy - a condition of lawlessness or political disorder brought
about by the absence of governmental authority.
Authoritarian - a form of government in which state authority is
imposed onto many aspects of citizens'' lives.
Commonwealth - a nation, state, or other political entity founded on
law and united by a compact of the people for the common good.
Communist - a system of government in which the state plans and
controls the economy and a single - often authoritarian - party
holds power; state controls are imposed with the elimination of
private ownership of property or capital while claiming to make
progress toward a higher social order in which all goods are equally
shared by the people (i.e., a classless society).
Confederacy (Confederation) - a union by compact or treaty between
states, provinces, or territories, that creates a central government
with limited powers; the constituent entities retain supreme
authority over all matters except those delegated to the central','d80ffc1b9301e41db3b1ea5d2e0fff8d49b9ff028431c1ee56a52d2aa198916a','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c69dacc7ab269bd6c5e50af6fb401359836894676a85f1172193812ca9cf1f9e',2010,'MZ','Mozambique','communications',275,'domestic: radiotelephone communications between islands
international: country code - 688; international calls can be made
by satellite
Broadcast media:
no television broadcast stations; many households use satellite
dishes to watch foreign TV stations; 1 government-owned radio
station, Radio Tuvalu, includes relays of programming from
international broadcasters (2009)
Internet country code:
.tv
Internet hosts:
109,478 (2010)
country comparison to the world: 77
Internet users:
4,200 (2008)
country comparison to the world: 205
Transportation ::Tuvalu
Airports:
1 (2010)
country comparison to the world: 213
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2010)
Roadways:
total: 8 km
country comparison to the world: 221
paved: 8 km (2002)
Merchant marine:
total: 66
country comparison to the world: 64
by type: bulk carrier 7, cargo 20, chemical tanker 16, container 3,
passenger 2, passenger/cargo 1, petroleum tanker 15, refrigerated
cargo 1, vehicle carrier 1
foreign-owned: 49 (Thailand 1, Vietnam 6, Turkey 1, Switzerland 1,
South Korea 1, Singapore 25, Maldives 1, Malaysia 1, Kenya 1, Hong
Kong 1, China 9, Ukraine 1) (2010)
Ports and terminals:
Funafuti
Military ::Tuvalu
Military branches:
no regular military forces; Tuvalu Police Force (2009)
Manpower fit for military service:
males age 16-49: 1,981
females age 16-49: 2,005 (2010 est.)
Manpower reaching militarily significant age annually:
male: 120
female: 110 (2010 est.)
Military expenditures:
NA
Transnational Issues ::Tuvalu
Disputes - international:
none
page last updated on January 20, 2011
======================================================================
@Uganda (Africa)
Introduction ::Uganda
mostly coastal lowlands, uplands in center, high plateaus
in northwest, mountains in west
5.13 children born/woman (2010 est.)','20c2c43feb40643d52fe808ca477c71c01fcc7db5d018b7d1929ed5148630e4f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bf3878bfb702cde3082c25d14c2bb4747d638c570685bdccb123d094e82ad2e',2010,'TV','Tuvalu','communications',1181,'domestic: radiotelephone communications between islands
international: country code - 688; international calls can be made
by satellite
low-lying and narrow coral atolls
3.14 children born/woman (2010 est.)','074af36e4c1c69cf443b24433d3a27b4039772d42068e1f8e22b7426caeb6218','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16b7b5587ccf82f9a56cd1520c9e8793f37ddd9c5d383c8a0219d57b5619a343',2010,'UG','Uganda','communications',1182,'general assessment: mobile cellular service is increasing
rapidly, but the number of main lines is still deficient; work
underway on a national backbone information and communications
technology infrastructure; international phone networks and Internet
connectivity provided through satellite and VSAT applications
domestic: intercity traffic by wire, microwave radio relay, and
radiotelephone communication stations, fixed and mobile-cellular
systems for short-range traffic; mobile-cellular teledensity about
30 per 100 persons in 2009
international: country code - 256; satellite earth stations - 1
Intelsat (Atlantic Ocean) and 1 Inmarsat; analog links to Kenya and
Tanzania
mostly plateau with rim of mountains
6.73 children born/woman (2010 est.)','f0c6b14f845ff2e7b6ca44b7cd6e477dead2765be3f86d8e51fa4e6191e0b0c5','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e37df63dc2774579c775259e21966bd3422fab492ecfde38bbea3130346f7fa2',2010,'UA','Ukraine','communications',1183,'general assessment: Ukraine''s telecommunication development
plan emphasizes improving domestic trunk lines, international
connections, and the mobile-cellular system
domestic: at independence in December 1991, Ukraine inherited a
telephone system that was antiquated, inefficient, and in disrepair;
more than 3.5 million applications for telephones could not be
satisfied; telephone density is rising and the domestic trunk system
is being improved; about one-third of Ukraine''s networks are digital
and a majority of regional centers now have digital switching
stations; improvements in local networks and local exchanges
continue to lag; the mobile-cellular telephone system''s expansion
has slowed, largely due to saturation of the market which has
reached 120 mobile phones per 100 people
international: country code - 380; 2 new domestic trunk lines are a
part of the fiber-optic Trans-Asia-Europe (TAE) system and 3
Ukrainian links have been installed in the fiber-optic
Trans-European Lines (TEL) project that connects 18 countries;
additional international service is provided by the
Italy-Turkey-Ukraine-Russia (ITUR) fiber-optic submarine cable and
by an unknown number of earth stations in the Intelsat, Inmarsat,
and Intersputnik satellite systems
most of Ukraine consists of fertile plains (steppes) and
plateaus, mountains being found only in the west (the Carpathians),
and in the Crimean Peninsula in the extreme south
1.27 children born/woman (2010 est.)','c58b3073c2646de36dbe287e3f8d2d14fa33472ea783f184e4e55963e9f9ea9d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e9094f14782a6c1d9cf2d78ef1c8620a9140bcf175279e1d0cecd54cdee819f',2010,'AE','United Arab Emirates','communications',1184,'general assessment: modern fiber-optic
integrated services; digital network with rapidly growing use of
mobile-cellular telephones; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay, fiber optic and coaxial cable
international: country code - 971; linked to the international
submarine cable FLAG (Fiber-Optic Link Around the Globe); landing
point for both the SEA-ME-WE-3 and SEA-ME-WE-4 submarine cable
networks; satellite earth stations - 3 Intelsat (1 Atlantic Ocean
and 2 Indian Ocean) and 1 Arabsat; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia
flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in east
2.41 children born/woman (2010 est.)','9fc9fc7a2ce55e193112fea4331dcb1ac1e1be512e1c931817390f2e3f9235e1','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82cc794a459e3a1db73f8f6702ceced0a6a573af10f6439f8ddfe0c7ed8cc43b',2010,'GB','United Kingdom','communications',1185,'general assessment: technologically advanced domestic
and international system
domestic: equal mix of buried cables, microwave radio relay, and
fiber-optic systems
international: country code - 44; numerous submarine cables provide
links throughout Europe, Asia, Australia, the Middle East, and US;
satellite earth stations - 10 Intelsat (7 Atlantic Ocean and 3
Indian Ocean), 1 Inmarsat (Atlantic Ocean region), and 1 Eutelsat;
at least 8 large international switching centers
mostly rugged hills and low mountains; level to
rolling plains in east and southeast
1.92 children born/woman (2010 est.)','b5a5559d9b31f9f1e0e8908e90bcec8d95f5a3433236cff1463d069430e6a789','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84f1b266f6e0881b9bbd5ac8a9264bccc644e917d7bc0e316af6a419bc97ccc9',2010,'US','United States','communications',1186,'general assessment: a large, technologically advanced,
multipurpose communications system
domestic: a large system of fiber-optic cable, microwave radio
relay, coaxial cable, and domestic satellites carries every form of
telephone traffic; a rapidly growing cellular system carries mobile
telephone traffic throughout the country
international: country code - 1; multiple ocean cable systems
provide international connectivity; satellite earth stations - 61
Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5 Intersputnik
(Atlantic Ocean region), and 4 Inmarsat (Pacific and Atlantic Ocean
regions) (2000)
vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in
Alaska; rugged, volcanic topography in Hawaii
United States Pacific Island Wildlife Refuges
low and nearly level
sandy coral islands with narrow fringing reefs that have developed
at the top of submerged volcanic mountains, which in most cases rise
steeply from the ocean floor
2.06 children born/woman (2010 est.)','124057af3834b77486af8ea9e771531509dcc4a10642b75f72238f7d0021f744','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c5592296aa81f6a597730bb69a2e989b56895b5ab56110bd19a038a09995d8c',2010,'UY','Uruguay','communications',1187,'general assessment: fully digitalized
domestic: most modern facilities concentrated in Montevideo; new
nationwide microwave radio relay network; overall fixed-line and
mobile-cellular teledensity is 135 telephones per 100 persons
international: country code - 598; the UNISOR submarine cable system
provides direct connectivity to Brazil and Argentina; satellite
earth stations - 2 Intelsat (Atlantic Ocean) (2009)
mostly rolling plains and low hills; fertile coastal lowland
1.89 children born/woman (2010 est.)','518359c38266e58e6e4def8d57b900fc95cc062e78a118640ca911ee5e749424','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c7fc0e21f167329b4c2bd7bf2874e00b4a84fccb460f29b70b889ff428532b7',2010,'UZ','Uzbekistan','communications',1188,'general assessment: digital exchanges in large cities but
still antiquated and inadequate in rural areas
domestic: the state-owned telecommunications company, Uzbektelecom,
owner of the fixed line telecommunications system, has used loans
from the Japanese government and the China Development Bank to
upgrade fixed-line services including conversion to digital
exchanges; mobile-cellular services are growing rapidly, with the
subscriber base exceeding 16 million in 2009
international: country code - 998; linked by fiber-optic cable or
microwave radio relay with CIS member states and to other countries
by leased connection via the Moscow international gateway switch;
after the completion of the Uzbek link to the Trans-Asia-Europe
(TAE) fiber-optic cable, Uzbekistan plans to establish a fiber-optic
connection to Afghanistan (2009)
mostly flat-to-rolling sandy desert with dunes; broad,
flat intensely irrigated river valleys along course of Amu Darya,
Syr Darya (Sirdaryo), and Zarafshon; Fergana Valley in east
surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral
Sea in west
1.92 children born/woman (2010 est.)','cc226110e1c7f95819fce2d0fcc3dab83a30a3a17bcc9284c3742cca726ae578','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45246a45c521f28bd458d59cd7616675aed0efbdf02daf8055bd77cbc8a3fc56',2010,'VU','Vanuatu','communications',1189,'general assessment: NA
domestic: NA
international: country code - 678; satellite earth station - 1
Intelsat (Pacific Ocean)
Venezuela
general assessment: modern and expanding
domestic: domestic satellite system with 3 earth stations; recent
substantial improvement in telephone service in rural areas;
substantial increase in digitalization of exchanges and trunk lines;
installation of a national interurban fiber-optic network capable of
digital multimedia services; combined fixed and mobile-cellular
telephone subscribership 130 per 100 persons
international: country code - 58; submarine cable systems provide
connectivity to the Caribbean, Central and South America, and US;
satellite earth stations - 1 Intelsat (Atlantic Ocean) and 1
PanAmSat; participating with Colombia, Ecuador, Peru, and Bolivia in
the construction of an international fiber-optic network (2009)
Vietnam
general assessment: Vietnam is putting considerable effort
into modernization and expansion of its telecommunication system
domestic: all provincial exchanges are digitalized and connected to
Hanoi, Da Nang, and Ho Chi Minh City by fiber-optic cable or
microwave radio relay networks; main lines have been increased, and
the use of mobile telephones is growing rapidly
international: country code - 84; a landing point for the
SEA-ME-WE-3, the C2C, and Thailand-Vietnam-Hong Kong submarine cable
systems; the Asia-America Gateway submarine cable system, scheduled
for completion by the end of 2008, will provide new access links to
Asia and the US; satellite earth stations - 2 Intersputnik (Indian
Ocean region)
Virgin Islands
general assessment: modern system with total digital
switching, uses fiber-optic cable and microwave radio relay
domestic: full range of services available
international: country code - 1-340; submarine cable connections to
US, the Caribbean, Central and South America; satellite earth
stations - NA
Wake Island
general assessment: satellite communications; 2 DSN
circuits off the Overseas Telephone System (OTS); located in the
Hawaii area code - 808
domestic: NA
international: NA
mostly mountainous islands of volcanic origin; narrow
coastal plains
Venezuela
Andes Mountains and Maracaibo Lowlands in northwest;
central plains (llanos); Guiana Highlands in southeast
Vietnam
low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
Virgin Islands
mostly hilly to rugged and mountainous with little
level land
Wake Island
atoll of three low coral islands, Peale, Wake, and
Wilkes, built up on an underwater volcano; central lagoon is former
crater, islands are part of the rim
2.43 children born/woman (2010 est.)
Venezuela
2.45 children born/woman (2010 est.)
Vietnam
1.93 children born/woman (2010 est.)
Virgin Islands
1.81 children born/woman (2010 est.)','d6a04da2be5dc41210c3894f88d680769792a53c8e30c86f93666c548b38c131','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e338e1523d8889a00a4c65057365fd8fa40ea63c36eae54885d77637bf5310be',2010,'WF','Wallis and Futuna','communications',1190,'general assessment: NA
domestic: NA
international: country code - 681
West Bank
general assessment: continuing political and economic
instability has impeded significant liberalization of the
telecommunications industry
domestic: Israeli company BEZEK and the Palestinian company PALTEL
are responsible for fixed line services; PALTEL plans to establish a
fiber-optic connection to Jordan to route domestic mobile calls; the
Palestinian JAWWAL company and WATANIYA PALESTINE provide cellular
services
international: country code - 970; 1 international switch in
Ramallah (2009) (2009)
volcanic origin; low hills
West Bank
mostly rugged dissected upland, some vegetation in west,
but barren in east
1.84 children born/woman (2010 est.)
West Bank
3.12 children born/woman (2010 est.)','6763efe3ab79de4efc8a464200b04c26aae59a8ac9d54a98a30368f234fc21c1','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('553a386a9a7b47789b2557c3df90cf080799f4cf824ffcdbcbbdffe241d156f0',2010,'EH','Western Sahara','communications',1191,'general assessment: sparse and limited system
domestic: NA
international: country code - 212; tied into Morocco''s system by
microwave radio relay, tropospheric scatter, and satellite;
satellite earth stations - 2 Intelsat (Atlantic Ocean) linked to
Rabat, Morocco
World
general assessment: NA
domestic: NA
international: NA
mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
World
the greatest ocean depth is the Mariana Trench at 10,924 m in
the Pacific Ocean
4.37 children born/woman (2010 est.)
World
2.56 children born/woman (2009 est.)','a6ee9ac9d15b3797c42f4a2bdbb041d6fa0aaa66f5795ea4f931513e7e2ec04f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8ff13589e4825c2dc913acc0d5698695bbcf6867949f8c46ee25c628e778ffb',2010,'YE','Yemen','communications',1192,'general assessment: since unification in 1990, efforts have
been made to create a national telecommunications network
domestic: the national network consists of microwave radio relay,
cable, tropospheric scatter, GSM and CDMA mobile-cellular telephone
systems; fixed-line and mobile-cellular teledensity remains low by
regional standards
international: country code - 967; landing point for the
international submarine cable Fiber-Optic Link Around the Globe
(FLAG); satellite earth stations - 3 Intelsat (2 Indian Ocean and 1
Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region), and 2
Arabsat; microwave radio relay to Saudi Arabia and Djibouti
narrow coastal plain backed by flat-topped hills and rugged
mountains; dissected upland desert plains in center slope into the
desert interior of the Arabian Peninsula
4.81 children born/woman (2010 est.)','cfc0661f5ae183f22be84560144e9870fb5539a35d577a5753dd09699cc6e027','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f8e87b54020af1cb211cc89afa9f25c3e6c69abfd32724de0df0c21da767df6',2010,'ZM','Zambia','communications',1193,'general assessment: among the best in Sub-Saharan Africa
domestic: high-capacity microwave radio relay connects most larger
towns and cities; several cellular telephone services in operation
and network coverage is improving; domestic satellite system being
installed to improve telephone service in rural areas; Internet
service is widely available; very small aperture terminal (VSAT)
networks are operated by private firms
international: country code - 260; satellite earth stations - 2
Intelsat (1 Indian Ocean and 1 Atlantic Ocean), 3 owned by Zamtel
mostly high plateau with some hills and mountains
6.07 children born/woman (2010 est.)','4d0f76ec499548a8efe53b82a082c52a6881ada4c64a2eeb6f6e2ced020f2fa0','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b71b8ec0320e60d9cfb51050f9ccce5623bb1d7b0cb0073b4dc4ee5d2b0759b8',2010,'AF','Afghanistan','communications',1194,'mostly rugged mountains; plains in north and southwest
5.5 children born/woman (2010 est.)','d86b14d245aab4d9896525fdf39d03b252e633b5d11426ce7187cfea388bb286','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fac6294deefd942fb5920891d1c386f9ac37d8b07bba8bd9cc792aecb294080',2010,'AL','Albania','communications',1195,'mostly mountains and hills; small plains along coast
1.47 children born/woman (2010 est.)','be4668cc486839b183c214da36ce11435c24b66bd947a931f6606e63326e0f52','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8391a14da55c49005019bb4a571f2face303e71d153bb254ae7789a54f19a0f',2010,'DZ','Algeria','communications',1196,'mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
1.76 children born/woman (2010 est.)','25a49f5573386660e4bb911056f7903434e22ebc3f9255a98922bf69af60e8ad','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3afda7e32b844471e0448e2e0f919c700ad7ec37f67a052cf1ae077eb07beb4d',2010,'AS','American Samoa','communications',1197,'five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls (Rose Island, Swains Island)
3.22 children born/woman (2010 est.)','758bcd9928fcf477fcd2522b69bb4a3f36653e6bafa26689429b0cc78609186e','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b410eea2d602e45f34ff84f5f1675045142c20add2bf7a43f498ebbe294ddc68',2010,'AD','Andorra','communications',1198,'rugged mountains dissected by narrow valleys
1.34 children born/woman (2010 est.)','c4c2a6fd32ace4947c16eb60cd89abc14eae919075a590a674aca938bd8705c0','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76b1b816198cbbe0d231898a1bc13b7e77320613d44ffd841ebc450682111f9c',2010,'AO','Angola','communications',1199,'narrow coastal plain rises abruptly to vast interior plateau
6.05 children born/woman (2010 est.)','70656463c04fa80a3aa1de6b7d2f6af7b7a4aa96a4da462cdc8a15709145ce0f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('916926fd0c8821d7bdddf3a8d92e3d8557c1a8b99c37756bf8501d0fcb90069a',2010,'AI','Anguilla','communications',1200,'flat and low-lying island of coral and limestone
1.75 children born/woman (2010 est.)','62e39694e9f77bb2fae3f248a7cd946d2f8be60b07955180d287ddf6ced18c84','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b743f26e0664a89e3399b3020205a510db32c4eb8fb0a07c87cf77dfa42fa175',2010,'AQ','Antarctica','communications',1201,'about 98% thick continental ice sheet and 2% barren rock,
with average elevations between 2,000 and 4,000 meters; mountain
ranges up to nearly 5,000 meters; ice-free coastal areas include
parts of southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers
form ice shelves along about half of the coastline, and floating ice
shelves constitute 11% of the area of the continent','7eb85f57b812692abdb6fea991f259c9799890e2192d3aeb68071391ae0c18b0','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aa1b5d055581052548715da1c3587bc6e100bf882591721d27507e983405d9c',2010,'AG','Antigua and Barbuda','communications',1202,'mostly low-lying limestone and coral islands,
with some higher volcanic areas
Arctic Ocean
central surface covered by a perennial drifting polar
icepack that, on average, is about 3 meters thick, although pressure
ridges may be three times that thickness; clockwise drift pattern in
the Beaufort Gyral Stream, but nearly straight-line movement from
the New Siberian Islands (Russia) to Denmark Strait (between
Greenland and Iceland); the icepack is surrounded by open seas
during the summer, but more than doubles in size during the winter
and extends to the encircling landmasses; the ocean floor is about
50% continental shelf (highest percentage of any ocean) with the
remainder a central basin interrupted by three submarine ridges
(Alpha Cordillera, Nansen Cordillera, and Lomonosov Ridge)
2.06 children born/woman (2010 est.)','fc8abad46e46c8bd4adeeb0394ad425f647810d3590a7f0c816dd0b629502ed5','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb44bdb8638c75f0028f049f23b9f0870511f49eeac3942360a9b0c7fabddf88',2010,'AR','Argentina','communications',1203,'rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western
border
2.33 children born/woman (2010 est.)','93b0fb8e8db03f0d64cd148aa88eadcaf03c19742ed6d2f8c1cdd2293de41bb7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('314aabc40e7ee3caf11c7d9fcd3f583d1c0cca1181fde6a5ac95f34ece4d4f03',2010,'AM','Armenia','communications',1204,'Armenian Highland with mountains; little forest land; fast
flowing rivers; good soil in Aras River valley
1.36 children born/woman (2010 est.)','27758893da929ac1564acd13baee364fa6a584e406cb7b0378a55c76c59ca2f1','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d90f1e54de624f346970455594b92fbbe0894b16d4b10a5312a1bcbbd5c9545',2010,'AW','Aruba','communications',1205,'flat with a few hills; scant vegetation
Ashmore and Cartier Islands
low with sand and coral
Atlantic Ocean
surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and coastal portions of the Baltic Sea from October
to June; clockwise warm-water gyre (broad, circular system of
currents) in the northern Atlantic, counterclockwise warm-water gyre
in the southern Atlantic; the ocean floor is dominated by the
Mid-Atlantic Ridge, a rugged north-south centerline for the entire
Atlantic basin
1.85 children born/woman (2010 est.)','70459764f4ae95674cacb03e9f4a6e72afc1595a072b2bb10f944af2556a7f1e','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff531ff2e710dcc0532e6d261bb207560b68b338be3473693587b3f001e870a2',2010,'AU','Australia','communications',1206,'mostly low plateau with deserts; fertile plain in southeast
1.78 children born/woman (2010 est.)','526234db4cfea84ae5a7102d7237757baea2b4fe25e0c0535b9b01f25b3a30b1','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b2086c9fe258323f5594a99ec8793836b7c9a258468d9ce25d11110dd1068a7',2010,'AT','Austria','communications',1207,'in the west and south mostly mountains (Alps); along the
eastern and northern margins mostly flat or gently sloping
1.39 children born/woman (2010 est.)','2cee02bca16bae647fe0b722a07e3a16785e72977f234e0d77b4e15a9617a3d6','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('563bc1983830f56e54367596630c779bcd64c98dbee3e20d9f96b8b29a3c6449',2010,'AZ','Azerbaijan','communications',1208,'large, flat Kur-Araz Ovaligi (Kura-Araks Lowland) (much
of it below sea level) with Great Caucasus Mountains to the north,
Qarabag Yaylasi (Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Bahamas, The
long, flat coral formations with some low rounded hills
2.03 children born/woman (2010 est.)
Bahamas, The
2 children born/woman (2010 est.)','b8b1d0ad18f426f39017529e126f371c12e1378130e0438b0ac4eca30a675123','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75d13b4059fdfc7b8ec379ccb4e7090282cd53a5e7a5009e41bd71ff0fb35c00',2010,'BH','Bahrain','communications',1209,'mostly low desert plain rising gently to low central
escarpment
2.47 children born/woman (2010 est.)','505daec936e20997ad78d0a4d3dade59308bed3f4e3d71ed50b49b50bcc601af','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07d3ae3366b6fc6de8f7cee3fa667a908cccd168093c890d436cef21ba83e2a2',2010,'BD','Bangladesh','communications',1210,'mostly flat alluvial plain; hilly in southeast
2.65 children born/woman (2010 est.)','fe6128244dcd44a016ae9e337f445ae2f1ce6f3a968202825e860bd2ebbccfce','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9294cf61e79960b4b530cfc7ab96a1a9917a0985aeced06b7a6ab1569885a87',2010,'BB','Barbados','communications',1211,'relatively flat; rises gently to central highland region
1.68 children born/woman (2010 est.)','bb37801bd88d602aeb9c9a3a48786b07c5bdc9c4c5305258df6b4a2ab282d28d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('176e8f7a867af78ce26b69a0aa9aefc04212c6fe8089fe4c4fe1c961b4d8e182',2010,'BE','Belgium','communications',1212,'flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
1.65 children born/woman (2010 est.)','034aed5118edcad10545c61a3ac3b83ca672b674d86ce119fd8691ac62c65f61','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d1ccb50b3a4e88206627325abca235adf8696709bf1c012c14ec6b4e9b8450',2010,'BZ','Belize','communications',1213,'flat, swampy coastal plain; low mountains in south
3.28 children born/woman (2010 est.)','1700cd9436bfb0116ea7210ec1d1cefe0828c48d8c56f2ee6c7e34e35c2a0001','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06eca11dab605ad2b02c9e90ac2248d73a9529d9be86edfa72fb057a6e9dde20',2010,'BJ','Benin','communications',1214,'mostly flat to undulating plain; some hills and low mountains
5.4 children born/woman (2010 est.)','45df7c910dcbfc430edeb34c1fb9e0141c6896029b24cf6939f25cff1d000d1f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd147b77b170511a605f1103f51d163eef5f983554eee61d406493b36d673fc5',2010,'BT','Bhutan','communications',1215,'mostly mountainous with some fertile valleys and savanna
Bolivia
rugged Andes Mountains with a highland plateau (Altiplano),
hills, lowland plains of the Amazon Basin
2.29 children born/woman (2010 est.)
Bolivia
3.07 children born/woman (2010 est.)','ae5d7f633ff39c317ae893cdf6108e55ec872a8f4b58ca69ed36a97f324b2344','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7e5f3edc2405c12b7ca6ee965cdecc69774d571dec567a83962ca8c4a6eb6a4',2010,'BW','Botswana','communications',1216,'predominantly flat to gently rolling tableland; Kalahari
Desert in southwest
2.54 children born/woman (2010 est.)','54c55e7fc90c3db9ab2a3e184941dd263120789c995e8a4a6f80c1f3e15719c5','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ef0cd22a09198727820c2949281fc1ef4c6280823603b92f752a9ef543cf44',2010,'BR','Brazil','communications',1217,'mostly flat to rolling lowlands in north; some plains, hills,
mountains, and narrow coastal belt
2.19 children born/woman (2010 est.)
British Virgin Islands
1.71 children born/woman (2010 est.)
Brunei
1.88 children born/woman (2010 est.)','87f943d71145ff4cd6570470fde3da0228da4d2ee9fcb4a7b2449a4b99238b97','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a8ef450538bbe152dcb38c267b844748421033754f60cffd4f3215fd0173549',2010,'IO','British Indian Ocean Territory','communications',1218,'flat and low (most areas do not
exceed two meters in elevation)
British Virgin Islands
coral islands relatively flat; volcanic
islands steep, hilly
Brunei
flat coastal plain rises to mountains in east; hilly lowland
in west','3bee8daba069d82f1d764222691f66ab7e16cf1ed99bfea710ac331670e3949b','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b84e5fc359abcbea31fc4e3d719b7d784734725cfc21e8c496ef037417d6cc4',2010,'BG','Bulgaria','communications',1219,'mostly mountains with lowlands in north and southeast
1.41 children born/woman (2010 est.)','ee97e656e4551e6a16799a081886d71f37176e9ea290f8d26892d5f8f24559d4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('068948b178554686b46ef7897ebb8d55d77e95c949ee55b28bd5d4557eef6aaa',2010,'BF','Burkina Faso','communications',1220,'mostly flat to dissected, undulating plains; hills in
west and southeast
Burma
central lowlands ringed by steep, rugged highlands
6.21 children born/woman (2010 est.)
Burma
2.28 children born/woman (2010 est.)','5d3dfe806a62eb57dd51337864e6d066d4eb03984d352cff25f2e8e6ec05ac7e','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6d1507791436c069d8b92ab933f147247a09d230b7480b1d1ee90fbc0381f44',2010,'BI','Burundi','communications',1221,'hilly and mountainous, dropping to a plateau in east, some
plains
6.25 children born/woman (2010 est.)','3491c9174a2be7dbe00ec68f6e69594728fb4188a343a9bbff6e7555a6e0d92f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb45e5ca1e86b6cfba98b7b2fad7e8f4703ca16ab2211787bebcccc6e437626b',2010,'KH','Cambodia','communications',1222,'mostly low, flat plains; mountains in southwest and north
2.9 children born/woman (2010 est.)','cae52306a910141d0c7ee3ba4d9ecc868c296c452f621a1332aae94ec251b9f7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e47ddd724a63649d51412c59158bac88eec06efbbd9f186bd93426a3605b172e',2010,'CM','Cameroon','communications',1223,'diverse, with coastal plain in southwest, dissected plateau
in center, mountains in west, plains in north
4.25 children born/woman (2010 est.)','12d9ee5a61b2ae668f2a803cd5fa32d6441b29ad515b43b064f80541e36d2142','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad6f161b97ad82010297e3ca041c8f929d64039a1d16ade42bbc479497ccb819',2010,'CA','Canada','communications',1224,'mostly plains with mountains in west and lowlands in southeast
Cape Verde
steep, rugged, rocky, volcanic
1.58 children born/woman (2010 est.)
Cape Verde
2.54 children born/woman (2010 est.)','5057315f03030dd9b6311ccace9edb1530b1a1d5fab7770ade7d37e48b80d02d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45acbdd2fea8bdee103da5bd0f5ca692c7b5aa3b6afd56c9e040db35d9fd7fee',2010,'KY','Cayman Islands','communications',1225,'low-lying limestone base surrounded by coral reefs
1.88 children born/woman (2010 est.)','6e568e2e3c7c3a7a14d7ea883edda9748a79377ee4d8bedb907d9a3bb0ec5551','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70fcaae3dd41e5bb698e75ee53abc7388e9802b076497a6d0e820dbdc9735216',2010,'CF','Central African Republic','communications',1226,'vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
4.68 children born/woman (2010 est.)','6157c839758da88b0ff4d2f436be223c8b38001e04ef7df617e7f34c4d29ee6c','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('425dc87745175870643f948c78e6673ed0de6f36f06cd33a5a3e4f395382c5bf',2010,'TD','Chad','communications',1227,'broad, arid plains in center, desert in north, mountains in
northwest, lowlands in south
5.18 children born/woman (2010 est.)','10b5e42b8577679b573abecd679906140c3725233f799b7b84ef1e424b82faad','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cce7129594b1babf12f3f24a8d9c96583b3f8efe239a8c759ac3e20d83aa1f80',2010,'CL','Chile','communications',1228,'low coastal mountains; fertile central valley; rugged Andes in
east
1.9 children born/woman (2010 est.)','ec4dfba02e915a02fee090e14c2e2d9fc884be455999aecae18d670ad8f43b50','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a19b2a6d40e41c8941441fc8a1cf9afd652a17d641f4110147f606b8b4651db',2010,'CN','China','communications',1229,'mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
1.54 children born/woman (2010 est.)','9bbe757099612836eec1dd1a276443dc7ae40db09a17c59e49f60df7c82081bb','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('978fe37773398261f5cfcf309dcb2da16d7bc8605fa8984f5db5b6be99b94f7e',2010,'CX','Christmas Island','communications',1230,'steep cliffs along coast rise abruptly to central
plateau
Clipperton Island
coral atoll
NA','57e2e6015417b17b7915b5175143c4a034360dd14ceab8cf8eb621d98ebd39f4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac4505ac40d03ccc319b13ab22f09113c5a0eb89ec141874296c986b7bc29061',2010,'CO','Colombia','communications',1231,'flat coastal lowlands, central highlands, high Andes
Mountains, eastern lowland plains
2.18 children born/woman (2010 est.)','e3834da30007dbf79d6c6afae04d19174f7abebc02929e9c4c25ccbab6fd37d8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51b23724cdd729beee7dae75e8a5b86fae11e5efe4c3648b126aaf1cc32022fd',2010,'KM','Comoros','communications',1232,'volcanic islands, interiors vary from steep mountains to low
hills
Congo, Democratic Republic of the
vast central basin is a low-lying
plateau; mountains in east
Congo, Republic of the
coastal plain, southern basin, central
plateau, northern basin
4.78 children born/woman (2010 est.)
Congo, Democratic Republic of the
6.11 children born/woman (2010
est.)
Congo, Republic of the
5.77 children born/woman (2010 est.)','d6555b63cacce35318c3224869504182228afb4ce5a8ec9c2f169fd4fee3a4b8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fc47460d0260c17d71ee8d8b490231a544ef4ac23d7f8bc414baa212688e2e9',2010,'CK','Cook Islands','communications',1233,'low coral atolls in north; volcanic, hilly islands in
south
Coral Sea Islands
sand and coral reefs and islands (or cays)
2.43 children born/woman (2010 est.)','a49dcfc06bae3dac2290d290ab7fe239dcb26b5074e546a6297d60c86b3884a0','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7bf88b86110ed980813024019313fbfc314474a9f93b40aafa050effe8c014c',2010,'CR','Costa Rica','communications',1234,'coastal plains separated by rugged mountains including
over 100 volcanic cones, of which several are major volcanoes
Cote d''Ivoire
mostly flat to undulating plains; mountains in
northwest
1.93 children born/woman (2010 est.)
Cote d''Ivoire
4.01 children born/woman (2010 est.)','f444b81629ffaf9e889e9b055127ef3054819a6a087b93bef8e39332219feb78','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8deb7b5942fdbf1f1a22dea32bd4182ffdbba2f349bda2bdb7c23e7d9116f5ec',2010,'HR','Croatia','communications',1235,'geographically diverse; flat plains along Hungarian border,
low mountains and highlands near Adriatic coastline and islands
1.43 children born/woman (2010 est.)','8ebbee9335d6bb5ed0cfa054917e7bac9e0a5985525482e6f88f0a51b7b61c29','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4f4051603e9adf60ac38f5f561af9ebf042609c4fdeb015cd04bef0e7a266c0',2010,'CU','Cuba','communications',1236,'mostly flat to rolling plains, with rugged hills and mountains
in the southeast
Curacao
generally low, hilly terrain
1.61 children born/woman (2010 est.)
Curacao
2.1 children born/woman (2009)','30aaace43063bfc1e4565df3d4cb6b4b2f0c103ec7a271513eadad55e47ffedb','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b651d28625c5ae8a0c0a85180187b0d8b2b1fe4f03cb05561f709588ee719cea',2010,'CY','Cyprus','communications',1237,'central plain with mountains to north and south; scattered
but significant plains along southern coast
Czech Republic
Bohemia in the west consists of rolling plains,
hills, and plateaus surrounded by low mountains; Moravia in the east
consists of very hilly country
1.45 children born/woman (2010 est.)
Czech Republic
1.25 children born/woman (2010 est.)','fec3ba7e341a6c5e9a76906adc4178737b7879ab0c53628b1f25d82a33857894','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e58ae958a56a77b9220ae056671c255b35adecfa86699a7ee778d24610addee3',2010,'DJ','Djibouti','communications',1238,'coastal plain and plateau separated by central mountains
2.79 children born/woman (2010 est.)','578fe3c714964cb3b78109b1a627c35d71057e5096e6d2cb262a674e1c74a260','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b7aef5b1ed8efa41b194335f68402ecfbc7652d8fee642391f0dde9885faaf8',2010,'DO','Dominican Republic','communications',1239,'rugged highlands and mountains with fertile
valleys interspersed
2.47 children born/woman (2010 est.)','3912fa664fefe54c3f8aafde7013473e9664e837c83c02e0705bb6595cee89cc','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edf09f183a3b52eeafa99c9dd2526def0b2cc3574de4e60f613c95484f58a9ca',2010,'EC','Ecuador','communications',1240,'coastal plain (costa), inter-Andean central highlands
(sierra), and flat to rolling eastern jungle (oriente)
2.46 children born/woman (2010 est.)','e5e1a505fddf3182c3b522f27e8b4827d7966f951d69dd3b1b97ec5d71518344','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79e5a3e9f44efbc0580d53ea050c10f1d5f5f4895b03a7ecd5ff11294d6e3511',2010,'EG','Egypt','communications',1241,'vast desert plateau interrupted by Nile valley and delta
3.01 children born/woman (2010 est.)','5fb6ab0ee957137bac8d0f270a3390d11206b34f526bbb607c86f3a3595bbcd7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7820e28fa862966fbfd06b3fa4242e191ff696be9c515e3f995dbe124149d6d3',2010,'SV','El Salvador','communications',1242,'mostly mountains with narrow coastal belt and central
plateau
2.12 children born/woman (2010 est.)','8a962d41e53536be4dd1c049e0605956034059598d3718094bdfe3677cba4685','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c55cbe22f733f6111ca11d73548be0323c3168c35afe2732ca40c6b00d88c9ec',2010,'GQ','Equatorial Guinea','communications',1243,'coastal plains rise to interior hills; islands are
volcanic
5 children born/woman (2010 est.)','74791dc1580340b45d865015eb0cfb091404cdbc09e76ebbc440b8bfa2af06d4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a975441911494cd86fc5e3147e967b1e75efb52ff7969823768cbd86a37f506',2010,'ER','Eritrea','communications',1244,'dominated by extension of Ethiopian north-south trending
highlands, descending on the east to a coastal desert plain, on the
northwest to hilly terrain and on the southwest to flat-to-rolling
plains
4.6 children born/woman (2010 est.)','f3fbf02c4bdf0c114abf4a1ad0c1f2e01b249eff3561895c9a1d78dc7b49aabd','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60609f9c2f8e0f996a21e5e64e3b6108da5279f6e6e36f23a0d54a8f1a0646c7',2010,'EE','Estonia','communications',1245,'marshy, lowlands; flat in the north, hilly in the south
1.43 children born/woman (2010 est.)','e6c59e0383964ab41e1a9dfc87f6719f1ea815d94cfe3fe13eeeaba96fd5e80f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cfcb285a94941a3625c2a69d349988e5fc01c9e8a97739f429b0f1286b4c5fe',2010,'ET','Ethiopia','communications',1246,'high plateau with central mountain range divided by Great
Rift Valley
European Union
fairly flat along the Baltic and Atlantic coast;
mountainous in the central and southern areas
Falkland Islands (Islas Malvinas)
rocky, hilly, mountainous with
some boggy, undulating plains
6.07 children born/woman (2010 est.)
European Union
1.51 children born/woman (2010 est.)
Falkland Islands (Islas Malvinas)
NA','cb1e5f57e7057be9c03f596c59800054ec8bb25016da1df3490464830d54d82a','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dffe6c7992d29c5b3ede650908ca17fb1e7a2799a84ab7bc8cf01bcca7bdacaf',2010,'FO','Faroe Islands','communications',1247,'rugged, rocky, some low peaks; cliffs along most of
coast
2.43 children born/woman (2010 est.)','ac977b964381d750f19040818c8e96329c82b40cfd812596087de6562118cb47','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2788586958a2ec7f07a237db3ce43bd6a2a0d38176674697f291b6640275ff7',2010,'FI','Finland','communications',1248,'mostly low, flat to rolling plains interspersed with lakes
and low hills
1.73 children born/woman (2010 est.)','2636d5e9ff25120b23ef78e42e4e566a28203f580b07556f539f8dcb90387b31','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b81dc18218eb38324d9f3ca994073ec4f23516aafd76f5be8317e8ebdca1c27',2010,'FR','France','communications',1249,'metropolitan France: mostly flat plains or gently rolling
hills in north and west; remainder is mountainous, especially
Pyrenees in south, Alps in east
French Guiana: low-lying coastal plains rising to hills and small
mountains
Guadeloupe: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation; most of the
seven other islands are volcanic in origin
Martinique: mountainous with indented coastline; dormant volcano
Reunion: mostly rugged and mountainous; fertile lowlands along coast
1.97 children born/woman (2010 est.)','b43dc97fcd7ab76dfbe3241ff71eb78a4f03fe8b78e0529aad0e120bc75c6257','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('509042ddd5b0ae118e8b140bd0f68d40f3d62e29fdb0dbbcde3c261de239d3a2',2010,'PF','French Polynesia','communications',1250,'mixture of rugged high islands and low islands with
reefs
French Southern and Antarctic Lands
Ile Amsterdam (Ile Amsterdam et
Ile Saint-Paul): a volcanic island with steep coastal cliffs; the
center floor of the volcano is a large plateau
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul): triangular in
shape, the island is the top of a volcano, rocky with steep cliffs
on the eastern side; has active thermal springs
Iles Crozet: a large archipelago formed from the Crozet Plateau is
divided into two groups of islands
Iles Kerguelen: the interior of the large island of Ile Kerguelen is
composed of rugged terrain of high mountains, hills, valleys, and
plains with a number of peninsulas stretching off its coasts
Bassas da India (Iles Eparses): atoll, awash at high tide; shallow
(15 m) lagoon
Europa Island, Glorioso Islands, Juan de Nova Island: low, flat, and
sandy
Tromelin Island (Iles Eparses): low, flat, sandy; likely volcanic
seamount
1.89 children born/woman (2010 est.)','3cf06ea1cab84851ea9511c8bad490390d94de4f987b1eeeb031bb166d563ddb','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b57621a9ce83625526199371f0a1510c5a669dfbc6bf8eabbbb7379d75489223',2010,'GA','Gabon','communications',1251,'narrow coastal plain; hilly interior; savanna in east and south
Gambia, The
flood plain of the Gambia River flanked by some low hills
Gaza Strip
flat to rolling, sand- and dune-covered coastal plain
4.62 children born/woman (2010 est.)
Gambia, The
4.96 children born/woman (2010 est.)
Gaza Strip
4.9 children born/woman (2010 est.)','1b6490121f88fd5c20ce213ef80e16d39048886d174d09123524f5bc2779d107','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52f4d0c71e57200bfe87ea44110456dda2243b8a140607b37f0d1f0c12546aab',2010,'GE','Georgia','communications',1252,'largely mountainous with Great Caucasus Mountains in the
north and Lesser Caucasus Mountains in the south; Kolkhet''is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River
Basin in the east; good soils in river valley flood plains,
foothills of Kolkhida Lowland
1.44 children born/woman (2010 est.)','a8287e57400df36e659ba3f042f48476e2e397cbf581f959f03fc0f108ef8d47','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd90302900a3238a308f80303a41134a59ab35e40cbe5ebcf9a2e1a1d01f3959',2010,'DE','Germany','communications',1253,'lowlands in north, uplands in center, Bavarian Alps in south
1.42 children born/woman (2010 est.)','6b44f93507b7de28ac75645bd38410e57aebf0621306b96bc02934f35973ba03','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc0c1287189a46cf0dc19b8ae86e8746e94558ff211031f40ae956f14725211',2010,'GH','Ghana','communications',1254,'mostly low plains with dissected plateau in south-central area
3.57 children born/woman (2010 est.)','41254cdcbb85c09ef0213f373ee5bade5e05192abaf23d9d6a15788ff02fddc4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33ffba6a15fc2955edc82375eed6d6335250d885efcaf2721fd1fd6e10bfa02d',2010,'GI','Gibraltar','communications',1255,'a narrow coastal lowland borders the Rock of Gibraltar
1.96 children born/woman (2010 est.)','4f39ec4be05e5660ca99470747d19bd28ce7c19b2f2f15df2cbb1a5ec88a8b9a','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66720d2b8c5b1e42d8d5432a705a1546ba4da994273817a4ae9f47079debc499',2010,'GR','Greece','communications',1256,'mostly mountains with ranges extending into the sea as
peninsulas or chains of islands
1.37 children born/woman (2010 est.)','9b45ffcaf491f9f795338378408ba8045a8b2b93daa8ae8ab07d3555f2c4d1d9','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fbdd5d0a86163c83bcdebcea0820364335f6ebe8e34ef07af0536433b571120',2010,'GL','Greenland','communications',1257,'flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
2.16 children born/woman (2010 est.)','854514e5b6c5a3cd982724bcaef987ef35be20ecbbcd325c55970d15825542dc','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9ee6c6e26cf2449d157d585d795c7c2f25805a74c800f2587cf37a73b799d78',2010,'GU','Guam','communications',1258,'volcanic origin, surrounded by coral reefs; relatively flat
coralline limestone plateau (source of most fresh water), with steep
coastal cliffs and narrow coastal plains in north, low hills in
center, mountains in south
2.52 children born/woman (2010 est.)','ef34e27796b9a5b6d0e912399b4d5001b38e8e57adf4e190cba5284f2ed955af','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b97dbec5eeb8ba34567ca2f0edd140e8f8a3f470b8d916860fbfa0ad4babf98',2010,'GT','Guatemala','communications',1259,'mostly mountains with narrow coastal plains and rolling
limestone plateau
3.36 children born/woman (2010 est.)','203db20fe83eb848afdec244a167565d35f6b40046c588cae163127ecf7bbcd4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49bb972a0a1f549c662541f139dec9aa53e22ec67e621c5085455783363a9a17',2010,'GN','Guinea','communications',1260,'generally flat coastal plain, hilly to mountainous interior
5.15 children born/woman (2010 est.)','cc4d23cdfb2c23ce4fed35cb5609c8233847ca63c951b166684e83ad3256d9df','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('167e45ec3618f33c840716564fa4ed2a174dcb5e4ccc83abcd1da2caa42a6ee8',2010,'GW','Guinea-Bissau','communications',1261,'mostly low coastal plain rising to savanna in east
4.58 children born/woman (2010 est.)','fce5731e7de7b7cbdd2fe53d55c43f974e3edb56ccffc458c753c16fdb0aed29','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18b4726d407a03f43c71fe2c992487a986f5e2fd28526cda901ec639ed135ec1',2010,'GY','Guyana','communications',1262,'mostly rolling highlands; low coastal plain; savanna in south
2.4 children born/woman (2010 est.)','2f96e48777a698ea2c94dc9601f858063b2c5da44bbac44e1fe93795c22518e5','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bc14fc677597f9503c4348622d170326607dcc577e86d64cd5c8c73e334badc',2010,'HM','Heard Island and McDonald Islands','communications',1263,'Heard Island - 80% ice-covered,
bleak and mountainous, dominated by a large massif (Big Ben) and an
active volcano (Mawson Peak); McDonald Islands - small and rocky
Holy See (Vatican City)
urban; low hill','b78d3d0211fb87858cf4fd42f566034bc6c27fa382f881365ebb5b83d82ff96d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b208b19b6e27b6b1c02a3f2108417cc1c17c2d506e58a84cae87b46843278260',2010,'HN','Honduras','communications',1264,'mostly mountains in interior, narrow coastal plains
3.17 children born/woman (2010 est.)','ec9b202b6573605bd3c4b6a50c57dfcc96bbd825c6201894429fb45fc31e6137','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da4c7edb2ecad817cfaa4e2ca0ffa5c9a85d526aa7b7f87bde2e77a1eae9f023',2010,'HK','Hong Kong','communications',1265,'hilly to mountainous with steep slopes; lowlands in north
1.04 children born/woman (2010 est.)','d199786756ad0c62c7fc3daa8b65c5172ece2cf79d333b28f7f24f0f11a1f6f8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c01a3250594073a70d71931b3ae08a57ae228fc3dafaf498481fb00865d7f592',2010,'HU','Hungary','communications',1266,'mostly flat to rolling plains; hills and low mountains on
the Slovakian border
1.39 children born/woman (2010 est.)','46d2305bc6fd3c3db0b90ed5ff85db426ba69074a679b46603a752f23e5f065f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baa926444fb4c54954e139fe651dc39f822e4dcf490c8ff89da5e1cd978456f4',2010,'IS','Iceland','communications',1267,'mostly plateau interspersed with mountain peaks, icefields;
coast deeply indented by bays and fiords
1.9 children born/woman (2010 est.)','2f57291cecada6a643c642ff6e99afffde5303eb13d62a8a41f733640188f405','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3247395bd6dc5c6e7367800c873a6d576c417e097f9a4e1378cfe9337238a0aa',2010,'IN','India','communications',1268,'upland plain (Deccan Plateau) in south, flat to rolling plain
along the Ganges, deserts in west, Himalayas in north
Indian Ocean
surface dominated by counterclockwise gyre (broad,
circular system of currents) in the southern Indian Ocean; unique
reversal of surface currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-to-northeast
winds and currents, while high pressure over northern Asia from
cold, falling, winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean floor is dominated
by the Mid-Indian Ocean Ridge and subdivided by the Southeast Indian
Ocean Ridge, Southwest Indian Ocean Ridge, and Ninetyeast Ridge
2.65 children born/woman (2010 est.)','5c34747f4634a5be32746e63af8c5a113e72968524b0539f0559cc0288dcf5a3','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d1a2aec4063f0f12f3d74f88b6851b1322b86fb65e9fb6f5b086f3c2d053d0',2010,'ID','Indonesia','communications',1269,'mostly coastal lowlands; larger islands have interior
mountains
Iran
rugged, mountainous rim; high, central basin with deserts,
mountains; small, discontinuous plains along both coasts
2.28 children born/woman (2010 est.)
Iran
1.89 children born/woman (2010 est.)','9842928e08c82458de07821bf98d592de624c967bdaad1e4f1b49b6c8d89bde1','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('248522d7389a28d7025f79dfd74bebb434b799cb227b7416300c39ff3138b28c',2010,'IQ','Iraq','communications',1270,'mostly broad plains; reedy marshes along Iranian border in
south with large flooded areas; mountains along borders with Iran
and Turkey
3.76 children born/woman (2010 est.)','0733bdc443582d5ae2bb6fe862563b82c6737205f0217bd2a2c93db01cd69e42','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb03d78f66e7b9170c7eb68b73f3905bbc01b16a5d49fb57272d1e16abbe45fb',2010,'IE','Ireland','communications',1271,'mostly level to rolling interior plain surrounded by rugged
hills and low mountains; sea cliffs on west coast
2.03 children born/woman (2010 est.)','9450d5b5f16d8983114ce1163617cfed7521b69e1f87219a8b2d3fae57812bd2','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e28297706b6e133cf6fe1a5c6bbe35d4ccfb3a6752bc83e6874198437577c2d',2010,'IM','Isle of Man','communications',1272,'hills in north and south bisected by central valley
1.97 children born/woman (2010 est.)','d1921023ad27929ef81ae344d9d567033357330acbff8fdf6c6a339913e680b4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d55d504707624a9dd69e6aac71b57bfbeb3c23174177021a2855ad08848627e4',2010,'IL','Israel','communications',1273,'Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
2.72 children born/woman (2010 est.)','79662a6dc20e1376c969dfa867d73aa0a64cea9a0f7faab6669897f13caf6f24','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19de63fb0eb54156b7214f3db874445c1998017a785183af97865718979fbf30',2010,'IT','Italy','communications',1274,'mostly rugged and mountainous; some plains, coastal lowlands
1.32 children born/woman (2010 est.)','9f97e377ec69d251383e0ee9192104b5d8723477d7fdd684a0e8c07b78293c3f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba70968b38162efea300594746fc4de3adcce8991616495cb206dc03c8fe7a7',2010,'JM','Jamaica','communications',1275,'mostly mountains, with narrow, discontinuous coastal plain
Jan Mayen
volcanic island, partly covered by glaciers
2.21 children born/woman (2010 est.)','b410ad387cfeb6a6bf0bd1f18470b63673825db40091cb5cf29f6ab52f497aa8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d652c9e8b903bdb148882dab005d916122d10de4a8c64af68b8b75f29f13007',2010,'JE','Jersey','communications',1276,'gently rolling plain with low, rugged hills along north coast
1.66 children born/woman (2010 est.)','33ebd12494b91bee923c7bc5cbc60570ddce61605534a222133891d1f9f69266','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fe9971c5f054e200316a4f7f85679ee39e6eca4cd90a21d709e2e71acd20bc7',2010,'JO','Jordan','communications',1277,'mostly desert plateau in east, highland area in west; Great
Rift Valley separates East and West Banks of the Jordan River
3.42 children born/woman (2010 est.)','ab8b6b109925984832143896f6434490609e8409fb15f42e3b574064bf4a1255','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d0d65e0173e0ea320ca663788fea20a66bddb54bd5a2e2ac85a6d79e8374569',2010,'KZ','Kazakhstan','communications',1278,'vast flat steppe extending from the Volga in the west to
the Altai Mountains in the east and from the plains of western
Siberia in the north to oases and deserts of Central Asia in the
south
1.87 children born/woman (2010 est.)','a751534467bfec62fc1f00df594cab6f7c1fedefe30d677f2b6b3f13796fb245','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d63baab65101d7fe1edcff2806f88c2a3537af57c98531293dd78b5910cf29f',2010,'KE','Kenya','communications',1279,'low plains rise to central highlands bisected by Great Rift
Valley; fertile plateau in west
4.38 children born/woman (2010 est.)','c42665a1d1f9eea160ecc8fa0f01a43ad57311b2923cc0927368f80343921d91','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0aa60ee6b2179142339492960d2ae092e050f2db5def3e6c36cfaa028644c5ff',2010,'KI','Kiribati','communications',1280,'mostly low-lying coral atolls surrounded by extensive reefs
Korea, North
mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
Korea, South
mostly hills and mountains; wide coastal plains in west
and south
Kosovo
flat fluvial basin with an elevation of 400-700 m above sea
level surrounded by several high mountain ranges with elevations of
2,000 to 2,500 m
2.86 children born/woman (2010 est.)
Korea, North
1.94 children born/woman (2010 est.)
Korea, South
1.22 children born/woman (2010 est.)','d0a953f066bc8dd3fff02ff799962715ea0609b5905bca9d2eb46458756e32d0','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5cfc536e440dc29a6913807a84a29190776017d23c354392de010039b070c68',2010,'KG','Kyrgyzstan','communications',1281,'peaks of Tien Shan and associated valleys and basins
encompass entire nation
Laos
mostly rugged mountains; some plains and plateaus
2.64 children born/woman (2010 est.)
Laos
3.22 children born/woman (2010 est.)','659aea3bb89b692e1af978ccc474425a7b28f4b8d3acd55fda7213f3f7a6a7a4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d239ea33ec2cadb5785c3957e98433eaf50de1f5f8beae3a54bcb60d6582eaf2',2010,'LB','Lebanon','communications',1282,'narrow coastal plain; El Beqaa (Bekaa Valley) separates
Lebanon and Anti-Lebanon Mountains
1.78 children born/woman (2010 est.)','9d848b70249404a5db49d682632781e78ce4e1206649b330ce993c0d2889c973','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('987fcadf8d46e9b14f5cf7845820d8c02edfb63d6eaf1e0063f02c03a97391bc',2010,'LS','Lesotho','communications',1283,'mostly highland with plateaus, hills, and mountains
3 children born/woman (2010 est.)','b358b636b3f45ada96e30fae3d31970977f91eb502e8ba8666e1e5dcf71521c4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea4f80c1e67b54aa1ac62fb889fd8361ea6dadc837a2b01e87057dc2739ecea',2010,'LR','Liberia','communications',1284,'mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
5.24 children born/woman (2010 est.)','bb182cd5ad42214bebc42fc1ffe95e8ba69f1fe322900ba158f36345e51d52eb','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2105b1bc19494237a3c59ada4642a04b58ffdd516832c306e9641e808d12150',2010,'LY','Libya','communications',1285,'mostly barren, flat to undulating plains, plateaus, depressions
3.01 children born/woman (2010 est.)','76683d1a785ce457caba3c2ab6546b363440bdd34d1fe6c4940f335b184ba5ff','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b2496c7d7fd587aeb2482f359b96f6373d15cbc61038cb5fdd81a45f91c3d38',2010,'LI','Liechtenstein','communications',1286,'mostly mountainous (Alps) with Rhine Valley in western
third
1.53 children born/woman (2010 est.)','956c634b9a8a3a2741bbed06e41ad824f7954603c30a947861611ca6f54140df','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a7be8c0dc1e6c69061170043d689d4b013e9ea398516a38951b7073e39716d6',2010,'LT','Lithuania','communications',1287,'lowland, many scattered small lakes, fertile soil
1.24 children born/woman (2010 est.)','8ab75e644ba2f1cd213a2e3e769c97d256675a81ffd6911516d0c09785b14d61','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c8d9ec31a500b9496e29bad0c4653fea37526ef1cd49392fee520327907f497',2010,'LU','Luxembourg','communications',1288,'mostly gently rolling uplands with broad, shallow
valleys; uplands to slightly mountainous in the north; steep slope
down to Moselle flood plain in the southeast
Macau
generally flat
Macedonia
mountainous territory covered with deep basins and
valleys; three large lakes, each divided by a frontier line; country
bisected by the Vardar River
1.78 children born/woman (2010 est.)
Macau
0.91 children born/woman (2010 est.)
Macedonia
1.58 children born/woman (2010 est.)','2bd6860261872e0619c48975d5e3ec6f4d3aeb34ce056a983e259709b1aab16d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06a706620f91719557075bfacc27ee60743ccb161c19bcad645d51e662664c68',2010,'MG','Madagascar','communications',1289,'narrow coastal plain, high plateau and mountains in center
5.09 children born/woman (2010 est.)','8301103e049c4bd52e4efefe60f3e654c3072862f1c012b4fe769e2b43ce9aaf','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6786e3dbf166717bb209e54605ee2c1ac686814d60b75d21f7f535c60f260bc',2010,'MW','Malawi','communications',1290,'narrow elongated plateau with rolling plains, rounded hills,
some mountains
5.51 children born/woman (2010 est.)','8202580c971df44d3b39896cf20c9f460f854bc30d1b2f71f835bc7391bb0fe6','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f632ec8218c160584a0c1331d5f781eacb9453e5c453f58e5f9401f80b4ecdc',2010,'MY','Malaysia','communications',1291,'coastal plains rising to hills and mountains
2.7 children born/woman (2010 est.)','ed51fa03f4f70a29aced99d91c4f8e6d4ed156b6360ee1959d14a7d1e3e94017','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65605732c4c6a54d6734a058454bf10039982022265ceb25f5b23a8672e3b570',2010,'ML','Mali','communications',1292,'mostly flat to rolling northern plains covered by sand; savanna
in south, rugged hills in northeast
6.54 children born/woman (2010 est.)','5081592cec3c29002dd5062c9297b6dc3c96ebcc9968e91343be2541e9d5e133','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1557e78c7bd2513c2cdfda364f6427e2c68fd00652d5ed2bd90321f9078e25a',2010,'MT','Malta','communications',1293,'mostly low, rocky, flat to dissected plains; many coastal
cliffs
1.52 children born/woman (2010 est.)','9bc54240c297f507a06524d964a33cd4245882197a5d35e081bed207d3ca80d3','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97a6420a5c2031b37c88227ce222b3cb0f5dfad4ff0e15c27bf653f40fb0a88d',2010,'MR','Mauritania','communications',1294,'mostly barren, flat plains of the Sahara; some central
hills
4.37 children born/woman (2010 est.)','4549e94b496ebfcb9510be6cd18d57bfe96c87547b2597bbe47070cedd91e79c','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9274682c400a39287a27c40ca07e5eda5591892be69d9220ae4c370913023435',2010,'MU','Mauritius','communications',1295,'small coastal plain rising to discontinuous mountains
encircling central plateau
1.8 children born/woman (2010 est.)','bbb384d463edf88121837f4ccde4bbdbdaae7c9896bde6ea01a1999630e5ff0f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5466c02a630bf84ee82ff0d3dd3700cfb1902906911d3130f362fed32f0403',2010,'YT','Mayotte','communications',1296,'generally undulating, with deep ravines and ancient volcanic
peaks
5.4 children born/woman (2010 est.)','e2b4c55f2f0bad051f669f0e19f75648a904ebe8bca3c9702e76c96e78173124','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4662da94dc598c2e51feb8d5f74fdd9cac2bf61d7df1348f70ebf179381d2b5',2010,'MX','Mexico','communications',1297,'high, rugged mountains; low coastal plains; high plateaus;
desert
2.31 children born/woman (2010 est.)','9293a539fb1a927a5171619e41c4a69891bfcd9e0c3c0f4e11108a4c74d95c28','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3d902d88b7bc60929c184b38f98793783b46a92a118f20034b7799c56bbcaa7',2010,'FM','Micronesia, Federated States of','communications',1298,'islands vary geologically from high
mountainous islands to low, coral atolls; volcanic outcroppings on
Pohnpei, Kosrae, and Chuuk
Moldova
rolling steppe, gradual slope south to Black Sea
2.8 children born/woman (2010 est.)
Moldova
1.28 children born/woman (2010 est.)','eca4b08a41c34de81eab8870cb9d791b9ce7cf1a323fb740413442d0201f552c','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88667d2ff97223a6ca2b849e5d7ea0f5cbb02562f20f551326d095fd998f8fb6',2010,'MN','Mongolia','communications',1299,'vast semidesert and desert plains, grassy steppe, mountains
in west and southwest; Gobi Desert in south-central
2.22 children born/woman (2010 est.)','6e07ca4ee54d49735bee922d4cac5f17844a768fad2de718448773a0656a8b18','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c171524c0e7764168bda085e56ca762f6eddf0869f33ba4d50c70be02f1210',2010,'ME','Montenegro','communications',1300,'highly indented coastline with narrow coastal plain
backed by rugged high limestone mountains and plateaus','0c1dd50e28101a4206dc207079ba08659ecfddd001b9c61343af6c180af218c4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50e4d1f43ae0a46623de6250bb6ff40845d3b5f77f657f422b676d38c9f945e6',2010,'MS','Montserrat','communications',1301,'volcanic island, mostly mountainous, with small coastal
lowland
1.25 children born/woman (2010 est.)','75bffdc77cdda947971396dfcebb1c70f5b922072acfe614d3e5c6a647094343','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29219d9bf0b96cef10ab5b2f7b46b09fbbb4b34296a6aa775880dee7bfbb8a42',2010,'MA','Morocco','communications',1302,'northern coast and interior are mountainous with large areas
of bordering plateaus, intermontane valleys, and rich coastal plains
2.23 children born/woman (2010 est.)','f705c33ecf33c811218f1150872f141b810569a2248b939362825bffa55a3143','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6706d73f9d1a718d1153ea2359277795ac31d9d2e35976a075e9baed1d31457f',2010,'NA','Namibia','communications',1303,'mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
2.57 children born/woman (2010 est.)','ca6b0e9104b3fadbbcfb28d70f4743ca968ba247a7973aacf4c8322a358cd2ce','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5f1b778a20a336c5e51c2df470dac729364ed9db739b3c82770451ee98abae',2010,'NR','Nauru','communications',1304,'sandy beach rises to fertile ring around raised coral reefs
with phosphate plateau in center
Navassa Island
raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m high)
3.13 children born/woman (2010 est.)','0fc88dcae8697b5d1502df1d5888b80e1fb1764d72e24d92c737d95cda2d6a13','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8760a7eb715d641c11d8ca8476ace9b044d0b2cf5b44c955e1a475bbdbc8e0d',2010,'NP','Nepal','communications',1305,'Tarai or flat river plain of the Ganges in south, central hill
region, rugged Himalayas in north
2.53 children born/woman (2010 est.)','0badd69be7c2e75cf2d3d3e5ebeab2666ca09e7e729d35da5a0e7f50ffe90c39','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36421f84f685acb3cd043f60f1d57272b57bb1e450954ac98bbce2931f702038',2010,'NL','Netherlands','communications',1306,'mostly coastal lowland and reclaimed land (polders);
some hills in southeast
1.66 children born/woman (2010 est.)','7bccaad735471f963a589285a7003879ba04cc3e158e038799a89ef284d8470b','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea9432d3f36dfceacacfae2afc64456e150083e4bb096bea03b24965a5678e00',2010,'NZ','New Zealand','communications',1307,'predominately mountainous with some large coastal plains
2.09 children born/woman (2010 est.)','a51c67db82ee1625f560f382cf1f043f294ef83d4fdf90aabdb526164f4effee','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5a0d2fe22677710f008acc7b17cf9236214ad2b9d306fd6eaa178fa844931b2',2010,'NI','Nicaragua','communications',1308,'extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by
volcanoes
2.51 children born/woman (2010 est.)','06c1a5d26861741cea5b8294bba651a80a2879edb25635caf8cdc69f2b07f547','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaac49af1055d26bd86d1022b7f61dd8200375dc41c9fdebb676460f8d4007c3',2010,'NE','Niger','communications',1309,'predominately desert plains and sand dunes; flat to rolling
plains in south; hills in north
7.68 children born/woman (2010 est.)','11285b6e7d9badc19605843fb68514460722d7ea33dccbe93f0be15cf2ee8e6b','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('040a1d83b73022e29168c2ef4e435f5e6f069ee43e2ff7507e9bf23887506622',2010,'NG','Nigeria','communications',1310,'southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
4.82 children born/woman (2010 est.)','26c8967b88721c5ba7f1cca0e35b5207f1b5f811caf764c25990ff45e0c325f2','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cae3f9a4478465b05ed9c8c1dd670477d2d3d5d791137121f9d5d3eff5d31b83',2010,'MP','Northern Mariana Islands','communications',1311,'southern islands are limestone with level
terraces and fringing coral reefs; northern islands are volcanic
2.18 children born/woman (2010 est.)','f2f7f37814d3034bb419fb697995db0b3c4b94ab83799677b80bbafd2a6c8a33','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50f3c7b771458e253b781e33bbef22ecb0580892c6713e50a5843aab78b61127',2010,'NO','Norway','communications',1312,'glaciated; mostly high plateaus and rugged mountains broken
by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
1.77 children born/woman (2010 est.)','9a25b173058f706c30980f6c8c94803fde0e7bfb2fb5399554f727cc41308f6b','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc755a117ca09d4be6a57d21e8fcbc843479dd4d204889b523bd4fddc014a4ad',2010,'OM','Oman','communications',1313,'central desert plain, rugged mountains in north and south
Pacific Ocean
surface currents in the northern Pacific are dominated
by a clockwise, warm-water gyre (broad circular system of currents)
and in the southern Pacific by a counterclockwise, cool-water gyre;
in the northern Pacific, sea ice forms in the Bering Sea and Sea of
Okhotsk in winter; in the southern Pacific, sea ice from Antarctica
reaches its northernmost extent in October; the ocean floor in the
eastern Pacific is dominated by the East Pacific Rise, while the
western Pacific is dissected by deep trenches, including the Mariana
Trench, which is the world''s deepest
2.87 children born/woman (2010 est.)','f0d85a9045bb1036166fbf0caa9dd0e1d92f9b1f84bc4d6cccf8c229d07854b4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd4231e3a1cf844cde578de37e9046bb1031a8e76aec97810adc4057ca930770',2010,'PK','Pakistan','communications',1314,'flat Indus plain in east; mountains in north and northwest;
Balochistan plateau in west
3.28 children born/woman (2010 est.)','d86eb6b113f98ab05ca22521570ce2fd1a2c96363c855868ce652b8c5c399dac','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a333829a8a225fda32ddaa4d0a329eae60d965d7afeaf2062dc50215f1ef841c',2010,'PW','Palau','communications',1315,'varying geologically from the high, mountainous main island of
Babelthuap to low, coral islands usually fringed by large barrier
reefs
1.73 children born/woman (2010 est.)','9c0b96403f760cd7a0399d7366d4cfc23d7c692586e99b1d0e055c4e55dfb4a2','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae69e169dd517587e4c9228f4923ea82b155de18809f6292701ee04e2c778319',2010,'PA','Panama','communications',1316,'interior mostly steep, rugged mountains and dissected, upland
plains; coastal areas largely plains and rolling hills
2.48 children born/woman (2010 est.)','180a172945975992fda4c684a6b57cdffa6b10c65541f604a6e5808038414b72','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a838668499cf553a1d9490768a7e8ed52c3ef98c0cf614fae1d5d81125391a60',2010,'PG','Papua New Guinea','communications',1317,'mostly mountains with coastal lowlands and rolling
foothills
Paracel Islands
mostly low and flat
3.54 children born/woman (2010 est.)','00f17c2adb660f9da152f259a967673eeca98015d4b67767e4b714c812a647a9','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b987ac3100066b817e4545f781a029fe3662fb8f1b4a51020ff5721f5f380b',2010,'PY','Paraguay','communications',1318,'grassy plains and wooded hills east of Rio Paraguay; Gran
Chaco region west of Rio Paraguay mostly low, marshy plain near the
river, and dry forest and thorny scrub elsewhere
2.16 children born/woman (2010 est.)','ca63c3f98c1bfa3cb616cfca87a3befc8af4c12e8c71f0b39592250598268e74','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06de877a6176a0e4d11f4decf23f5ce52a1631a0a1bcc0745c4e9f3321157e39',2010,'PE','Peru','communications',1319,'western coastal plain (costa), high and rugged Andes in center
(sierra), eastern lowland jungle of Amazon Basin (selva)
2.32 children born/woman (2010 est.)','1ae84ffad3832ba2a4f1f5c84b7d9f69d763b5ab8154903d2275a6f818809eca','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb286379b1a05741cac9b4294640fc4c017ccf86d585d793a0071420a7c2e499',2010,'PH','Philippines','communications',1320,'mostly mountains with narrow to extensive coastal
lowlands
Pitcairn Islands
rugged volcanic formation; rocky coastline with
cliffs
3.23 children born/woman (2010 est.)
Pitcairn Islands
NA','ff88611d9c12d815a1e442f5164b69ebd07989739768e6e6045cc674b500bec4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1e243891415360477e61ff01c1e8b30d99353b81ece67615e1091ed062e7815',2010,'PL','Poland','communications',1321,'mostly flat plain; mountains along southern border
1.29 children born/woman (2010 est.)','ea1f2c917609fdfc9bbc852f4061c9896a9dc03f32dc6d11e63bf0aa8387cc4e','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('630019804baee70e71aa25db3f3a67c4be8b4741c922c9ff6c23be97180f60cb',2010,'PT','Portugal','communications',1322,'mountainous north of the Tagus River, rolling plains in
south
1.5 children born/woman (2010 est.)','4d2a3fcf981fb04464aa39dc5e626da555323b9e44b095c4b3a0dbdfe16b10e6','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63585babcfde116f3ac7173c52f4c1de55732e1728926fdf4926360b355d49c3',2010,'PR','Puerto Rico','communications',1323,'mostly mountains with coastal plain belt in north;
mountains precipitous to sea on west coast; sandy beaches along most
coastal areas
1.62 children born/woman (2010 est.)','00ad06fc2306bc02ec3cf8e9242591aaf7dd10e7f4c67bbd943e65fba959e21f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2deae1139b25e5c5e7dce219cc8e79196ac4b760c9bfd1c3fef8749308627b68',2010,'QA','Qatar','communications',1324,'mostly flat and barren desert covered with loose sand and
gravel
2.44 children born/woman (2010 est.)','93c0d231d46acc9a898160af5b66940d56c0a2f428cc00b2cc6fbbe633e863a7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e4c132a2bc7166f9b4ba7b87fc9efefef85364121d4b3574ef606a79f3346b',2010,'RO','Romania','communications',1325,'central Transylvanian Basin is separated from the Moldavian
Plateau on the east by the Eastern Carpathian Mountains and
separated from the Walachian Plain on the south by the Transylvanian
Alps
Russia
broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia; uplands and mountains along southern
border regions
1.27 children born/woman (2010 est.)
Russia
1.41 children born/woman (2010 est.)','c097e3ca12d486dc62cfe3d4268f1b3d3bcba8d7a8baa57c4fb8e5742f56b469','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c7ede38b815668faf37b9d316f2f86172086a7d256d6d5a7f10665f0495c896',2010,'RW','Rwanda','communications',1326,'mostly grassy uplands and hills; relief is mountainous with
altitude declining from west to east
Saint Barthelemy
hilly, almost completely surrounded by
shallow-water reefs, with 20 beaches
Saint Helena, Ascension, and Tristan da Cunha
the islands of this
group result from volcanic activity associated with the Atlantic
Mid-Ocean Ridge
Saint Helena: rugged, volcanic; small scattered plateaus and plains
Ascension: surface covered by lava flows and cinder cones of 44
dormant volcanoes; ground rises to the east
Tristan da Cunha: sheer cliffs line the coastline of the nearly
circular island; the flanks of the central volcanic peak are deeply
dissected; narrow coastal plain lies between The Peak and the
coastal cliffs
4.99 children born/woman (2010 est.)
Saint Helena, Ascension, and Tristan da Cunha
1.56 children
born/woman (2010 est.)','ac2d91445e11bd0e5e732ba391316f0c3c817d0f77d6ccd5516c40c9ee24c355','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b2bdfbcf277a22fb2680a55b42ac818da2d3b8272b186ecd807fc3a6d5993c1',2010,'LC','Saint Lucia','communications',1327,'volcanic and mountainous with some broad, fertile valleys
1.82 children born/woman (2010 est.)','0a85ef319bb3e639015eab7d5d4ceabcbddca3b16c407b1538679b91db08339e','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4793846f33d98a8fe60cfca7a5e17a75118939b0c2924180b16b8eae2adb4223',2010,'WS','Samoa','communications',1328,'two main islands (Savaii, Upolu) and several smaller islands
and uninhabited islets; narrow coastal plain with volcanic, rocky,
rugged mountains in interior
3.32 children born/woman (2010 est.)','b4c389a546fd24eaba9a4ea64ccc8707e4c6a009a95991794e4ee127c0576dc2','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b29e0cc534350180505c2c7987fa76b2c853f0bde35aa42e9026d69092dfe83',2010,'SN','Senegal','communications',1329,'generally low, rolling, plains rising to foothills in
southeast
4.86 children born/woman (2010 est.)','691995aeb8f79e5670e0695ae13c7928c34df9f24856767196de5008c1b04973','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdaa5b37bd2b80c8c4c551cc091bca5a6aae9d19eebdbccb11ffd1ec1cad98ca',2010,'RS','Serbia','communications',1330,'extremely varied; to the north, rich fertile plains; to the
east, limestone ranges and basins; to the southeast, ancient
mountains and hills
1.39 children born/woman (2010 est.)','514b8256fd7527d13498821cd14422e797a95d980432f1fdc43d3690d816dacc','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('038e529e0b6a7bdf771a5842865d44af39449a7d5f57e2550a612076b15cc4dc',2010,'SC','Seychelles','communications',1331,'Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
1.92 children born/woman (2010 est.)','037ff0751102ab81fa4bd1e5c47e4f889d30ae8847a1bbb22e5e49c4f5427070','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01cfe8797b8d91151e37582b5768a4db57bd7a0f42420546ec559848125dd4dc',2010,'SL','Sierra Leone','communications',1332,'coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
4.97 children born/woman (2010 est.)','57ac179ab1d4d7c92c191287ada3923fe7ec44107841144302fbaea1ad209cd1','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b95d71be9e9c4a7bb8665a281c9d58c04de5a1841816242af5eb82b5e3cf272f',2010,'SG','Singapore','communications',1333,'lowland; gently undulating central plateau contains water
catchment area and nature preserve
Sint Maarten
low, hilly terrain, volcanic origin
1.1 children born/woman (2010 est.)
Sint Maarten
1.7 children born/woman (2009)','37aa6e624ea7d9abff4de461558c4ab021bfa6d1aadd1ea31f37b6da7899ec6d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8e20b0ad230aa82ba2ab4e6ef2b0e0c056ca0fe8e2e5c5ac8e1e24cb96275d3',2010,'SK','Slovakia','communications',1334,'rugged mountains in the central and northern part and
lowlands in the south
1.36 children born/woman (2010 est.)','a19b40bf1ead2502e45ae313c4eeba1cd5b8de1f0961c103590f7c620cf973f4','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27fabec13c429cd760e527e463eec95f83a29511bbbb9072e1bcdafb514321c6',2010,'SI','Slovenia','communications',1335,'a short coastal strip on the Adriatic, an alpine mountain
region adjacent to Italy and Austria, mixed mountains and valleys
with numerous rivers to the east
1.29 children born/woman (2010 est.)','5c8e886a24578349f94cf3a0aa0486768464e3f31a8e5d3a875f66893a90652b','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d10688644f93c6d6c0aac6a5ccd771f2a6821e5afd010eddd79147b2bdb1f56',2010,'SB','Solomon Islands','communications',1336,'mostly rugged mountains with some low coral atolls
3.67 children born/woman (2010 est.)','f328be7178265ff117b502d2bf15e1fe0ca3483644191adfd605de740594b61f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdffd852aeab44a56f91c925b19d635b63bf1ce05913ee7e52e336fd5cc19120',2010,'SO','Somalia','communications',1337,'mostly flat to undulating plateau rising to hills in north
6.44 children born/woman (2010 est.)','ea0e4082a8a882c8cda5c2db710f64efb54130b2d8bd2ae1d11a9713cd1480a0','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43e5e737a4a3d1cdb0b999302e53aade4b7432e69c6482bc5748eca9b48ab78f',2010,'ZA','South Africa','communications',1338,'vast interior plateau rimmed by rugged hills and narrow
coastal plain
South Georgia and South Sandwich Islands
most of the islands, rising
steeply from the sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered mountains; the South
Sandwich Islands are of volcanic origin with some active volcanoes
Southern Ocean
the Southern Ocean is deep, 4,000 to 5,000 m over
most of its extent with only limited areas of shallow water; the
Antarctic continental shelf is generally narrow and unusually deep,
its edge lying at depths of 400 to 800 m (the global mean is 133 m);
the Antarctic icepack grows from an average minimum of 2.6 million
sq km in March to about 18.8 million sq km in September, better than
a sixfold increase in area; the Antarctic Circumpolar Current
(21,000 km in length) moves perpetually eastward; it is the world''s
largest ocean current, transporting 130 million cubic meters of
water per second - 100 times the flow of all the world''s rivers
2.33 children born/woman (2010 est.)','b7fa07d5d8354f8bd563d38d98fb4e3f4fbd93732c01efef9fa1ccf28b2cb8ee','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05e74d37a7b11d9279174059a2cc0e8ff22f362827a04b0d5e32b50393e8c08',2010,'ES','Spain','communications',1339,'large, flat to dissected plateau surrounded by rugged hills;
Pyrenees in north
Spratly Islands
flat
1.47 children born/woman (2010 est.)','1c8009ef86eea715f64c00e0bf31dcd93ba66d5a0b560cf2a5378b15ddc0e727','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a61884a07f674e6bf7a3d1eb49c8da949f55f1f4095d934cda15cf4e780a1346',2010,'LK','Sri Lanka','communications',1340,'mostly low, flat to rolling plain; mountains in
south-central interior
1.96 children born/woman (2010 est.)','1910ecb6ba41d07be082d82909157b56bb20ab620cb01fd4e4ea21d5e46967c5','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79009324d74937a28bfd1582955e315f99d46c7b866743de572253d3a751ae9a',2010,'SD','Sudan','communications',1341,'generally flat, featureless plain; mountains in far south,
northeast and west; desert dominates the north
4.93 children born/woman (2010 est.)','ba859c2c6f805cbc18a1d8313fd81fd238e0f04589e1a793b39d179c08d22e3c','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be09e1a58833438ce6e389fb890e64d3e2dfa899b68856a3db8c798949f4902b',2010,'SR','Suriname','communications',1342,'mostly rolling hills; narrow coastal plain with swamps
Svalbard
wild, rugged mountains; much of high land ice covered; west
coast clear of ice about one-half of the year; fjords along west and
north coasts
Swaziland
mostly mountains and hills; some moderately sloping plains
1.97 children born/woman (2010 est.)
Svalbard
NA
Swaziland
3.19 children born/woman (2010 est.)','616d8dc57465ea4ee4efd7f056cce9a012c451c8e909cf16761a1e748f640bad','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da61bd8d5d3ceb0d518ef607515ef03a82d99c69b955efa33eb246f9d3196db',2010,'SE','Sweden','communications',1343,'mostly flat or gently rolling lowlands; mountains in west
1.67 children born/woman (2010 est.)','c47c4d244bf7b8f462c3516906b9ab9fba9b9c783d56483c1a7998367e41aeb7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99c73f1df10c530dbbb48ec6bc92b6da4324311c71f8a82118711a17e3581d51',2010,'CH','Switzerland','communications',1344,'mostly mountains (Alps in south, Jura in northwest) with
a central plateau of rolling hills, plains, and large lakes
Syria
primarily semiarid and desert plateau; narrow coastal plain;
mountains in west
Taiwan
eastern two-thirds mostly rugged mountains; flat to gently
rolling plains in west
1.46 children born/woman (2010 est.)
Syria
3.02 children born/woman (2010 est.)
Taiwan
1.15 children born/woman (2010 est.)','efb9cf07d931bf2202905fbb720ff6d7c12eb7011e550dd4620195afd0633445','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52860fc835b48062c1d5b7c09804b431d71c148a5e8414a1dd764e06694dfa83',2010,'TJ','Tajikistan','communications',1345,'Pamir and Alay Mountains dominate landscape; western
Fergana Valley in north, Kofarnihon and Vakhsh Valleys in southwest
Tanzania
plains along coast; central plateau; highlands in north,
south
2.94 children born/woman (2010 est.)
Tanzania
4.31 children born/woman (2010 est.)','fe09f45becffeb9a49700b86049a598b9434179d92dce3ea39c310c232b20d47','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c742422b5d61bad018135677c080dfd8c6ebea715a75584b7269696fc3e0c63c',2010,'TH','Thailand','communications',1346,'central plain; Khorat Plateau in the east; mountains
elsewhere
1.65 children born/woman (2010 est.)','2a905db9520f360458a1f364d0399bddabbde8b8fb8e3999d509f79cfedbe046','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a38c2ece0690704cea579507ea992e5c33e1ca690a2cbf7eb7de0fb1752adc44',2010,'TG','Togo','communications',1347,'gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
4.74 children born/woman (2010 est.)','e146788b525da03ec58e5ec3df1067b255b9b150182b34abfccc12f7889d5f9e','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e96c379b4b89d1c7b25a4e45c01a7ae9e2502d65e0bf8df24088bab13477793',2010,'TO','Tonga','communications',1348,'most islands have limestone base formed from uplifted coral
formation; others have limestone overlying volcanic base
2 children born/woman (2010 est.)','fc591ff59038f73db5a480e8df4e3ac7af196c18fc15485c0b994d066f9d6fa8','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a5ef5b0e77a2a84cb951b25af2a5218ea7feb8ed2367b745d9a139b8d1a016a',2010,'TT','Trinidad and Tobago','communications',1349,'mostly plains with some hills and low mountains
1.72 children born/woman (2010 est.)','f0944dc59aacdfab080027b9258e2e3eed32099e7794d8ce3c8f112c048243ec','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bd8b1990576bf5d87b4e6b247ae2d85c8292951f2c9ccfaaf72b2a89c7e3c89',2010,'TN','Tunisia','communications',1350,'mountains in north; hot, dry central plain; semiarid south
merges into the Sahara
Turkey
high central plateau (Anatolia); narrow coastal plain;
several mountain ranges
1.71 children born/woman (2010 est.)
Turkey
2.18 children born/woman (2010 est.)','eeabec666aa05c453b27a4b5513048a3bbb33070659fa420c7af827c286744a7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a05fc8a84b42d60e3296567a622dfd719506cda65537a76dc02d41b9d551ffa4',2010,'TM','Turkmenistan','communications',1351,'flat-to-rolling sandy desert with dunes rising to
mountains in the south; low mountains along border with Iran;
borders Caspian Sea in west
2.19 children born/woman (2010 est.)','1e1fa11b14c9c1a452c0e1480c2730f7a308b65a55a70e4886d8a6c2ab25e6de','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4985795d914fbf1d7c08fc44f6229401080d6c9b3c5eecf1828fc53b7ce715c0',2010,'TC','Turks and Caicos Islands','communications',1352,'low, flat limestone; extensive marshes and
mangrove swamps
2.92 children born/woman (2010 est.)','b3455241c32999f7038f906606a2f620d9017a948be6bab459aaa3d56ad7d188','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9cfedb8fc0e91f1ee213c21c54614cab6e7abb074fac01352f0abf7adc0f5ef',2010,'','','raw',1,'CENTRAL INTELLIGENCE AGENCY
Digitized by the Internet Archive
in 2018 with funding from
Kahle/Austin Foundation
https://archive.org/details/ciaworldfactbookOOOOunit
THE CIA
WORLD
FACTBOOK
2010
Skyhorse Publishing
Copyright © 2009 by Skyhorse Publishing, Inc.
All Rights Reserved. No part of this book may be reproduced in any manner without the express
written consent of the publisher, except in the case of brief excerpts in critical reviews or articles.
All inquiries should be addressed to Skyhorse Publishing, 555 Eighth Avenue, Suite 903,
New York, NY 10018.
Skyhorse Publishing books may be purchased in bulk at special discounts for sales promotion,
corporate gifts, fund-raising, or educational purposes. Special editions can also be created to speci¬
fications. For details, contact the Special Sales Department, Skyhorse Publishing,
555 Eighth Avenue, Suite 903, New York, NY 10018 or info@skyhorsepublishing.com.
www.skyhorsepublishing.com
ISBN: 978-1-60239-727-9
10987654321
In general, information available as of May 2009 was used in the preparation of this edition.
Printed in Canada
CONTENTS','7d36591c4d8628d8a34dad150319c4958fcc0a97d5eb905b20de88a36fe23ae4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f29a308b2b2f844a331f9b72e963b2ed920f9c284a0e0f895c72b0572139095',2010,'','','raw',1,'The Project Gutenberg EBook of The 2010 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2010 CIA World Factbook
Author: United States. Central Intelligence Agency.
Release Date: April 11, 2011 [EBook #35830]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2010 CIA WORLD FACTBOOK ***
Produced by Al Haines
THE CIA WORLD FACTBOOK 2010
CONTENTS
What''s New?
Did You Know?
Guide to Country Profiles
Countries and Locations
Field Listings
Rank Orders
Appendixes
Notes and Definitions
History of the CIA Factbook
Contributors and Copyright Information
Frequently Asked Questions (FAQs)
======================================================================
THE WORLD FACTBOOK :: WHAT''S NEW
January 31, 2011
What do the initials ESA stand for? Check out Appendix A:
Abbreviations to find out. New space-based photos have been uploaded
for Australia, China, Namibia, Mexico, and the US.
January 25, 2011
What country enjoyed the lowest unemployment rate in 2010? Find out
by checking "Unemployment rate" under the Country Comparison feature
(in the References tab). The entire Economy category has been
updated to reflect data for years 2010 and earlier.
January 14, 2011
Did you know that the highest elevation in the Netherlands is not in
Europe? Where is it? Find out by checking the "Elevation extremes"
field in the Geography section. New space-based photos have been
added for Iran and Russia.
January 07, 2011
What country flag is only one color? To find out visit the Flags of
the World page.
December 30, 2010
What airport handles the most passengers annually? Find out by going
to the World entry, Transportation category, "Airports" field, and
locating the top ten airports by passengers and by cargo.
December 23, 2010
If it''s noon in Washington, DC, what time is it in Nairobi, Kenya?
The answer may be found in the Government section, under "Capital,"
where the time difference is specified. New photos from Kenya have
been uploaded.
December 17, 2010
How many rare earth elements (REEs) are there? Find the answer in
the "Definitions and Notes" (below the References tab). These
critical elements, necessary in so many of today''s high-tech
industries, are now listed in the "Natural resources" field, under
Geography, for countries that are producing REEs or initializing
mining operations (including Australia, China, Russia, South Africa,
and the US).
December 10, 2010
Quick! What''s the national anthem of Australia? Now you can find the
name, lyricist, composer, and additional basic anthem info for every
country in the world by visiting the new "National anthems" field in
the Government section of the Factbook.
November 30, 2010
Since 2004, The World Factbook Web site has been updated on a
bi-weekly schedule. Culminating a three-month trial effort, we are
pleased to announce that the Factbook will now be updated on a
weekly basis.
November 19, 2010
Significant updates entered under the People, Government, and
Communications categories.
November 11, 2010
In the Geography category, a new subfield, "volcanism," has been
added under the "Natural hazards" field for countries with
historically active volcanoes. The Economy section has been updated
to reflect the most recent data for 2009 and earlier years.
November 05, 2010
In the Economy category, the "Oil - exports," "Oil - imports," "Oil
- proved reserves," and "Natural gas - proved reserves" fields have
been updated with the most recent estimates available.
October 29, 2010
In the People category, significant updates have been made to the
"School life expectancy" and "Education expenditures" fields. In the
Economy category, the "Stock of domestic credit" field has been
updated to include data for 2009. In addition, the definition has
been expanded to include credit provided by all financial
institutions, not just banks, as had been The World Factbook
practice until now. For some countries this change significantly
broadens the coverage.
October 22, 2010
The dissolution of the Netherlands Antilles has resulted in two new
World Factbook entries: the autonomous entities of Curacao and Sint
Maarten (the remaining three islands - Bonaire, Saba, and Sint
Eustatius - have joined the Netherlands as special municipalities).
The number of entities in The World Factbook now stands at 267.
October 13, 2010
In the Economy category, the "Stock of money" and "Stock of quasi
money" fields have been updated and renamed as "Stock of narrow
money" and "Stock of broad money" in keeping with the International
Monetary Fund''s new presentation of monetary data. This new format
provides greater standardization of reporting and permits more
consistent comparisons across countries. Please see "Definitions and
Notes" (under the References tab) for descriptions of the new fields.
October 08, 2010
In the Communications category, the "Internet hosts" field has been
updated with 2010 data; significant updates entered in the
Geography, Government, and Military categories.
October 01, 2010
In the Transportation category, the "Merchant marine" field has been
updated with the latest available data; substantial updates also
entered in fields of the Government and Economy categories.
September 24, 2010
In the Economy category, new data have been added for 2009 in the
fields for "Central bank discount rate" and "Commercial bank prime
lending rate."
September 17, 2010
In the Transportation category, the "Roadways" field has been
updated with the latest available data; significant updates also
entered in fields of the Government and Military categories.
September 13, 2010
In the Government category, the amplification of flag descriptions -
to include explanations of colors and symbols - has been completed
for all of the country entries.
September 03, 2010
In addition to various population, governmental, and military
updates, new photos have been added for Burma, Canada, Poland, the
United Kingdom, and the United States.
August 23, 2010
In the Communications category, the former "Radio broadcast
stations" and "Television broadcast stations" entries have been
replaced by a new "Broadcast media" field that provides information
on the approximate number of public and private TV and radio
stations in a country, as well as basic information on the
availability of satellite and cable TV services. Malawi''s recently
unveiled new flag may be viewed either in the Flags of the World
link or under the Malawi country entry. In the Economy category, GDP
statistics have been updated and revised.
August 06, 2010
In the Transportation category, the "Airports," "Airports - with
paved runways," "Airports with unpaved runways," and "Heliports"
fields have all been updated with the latest available data.
July 29, 2010
The "International Court of Justice (ICJ)" entry listed under
International Organizations and Groups in Appendix B has been
expanded considerably and now includes countries adherent to
jurisdiction. Several fields in the Economy category covering trade
as well as oil and natural gas have been updated with the latest
available annual data.
July 23, 2010
Under the References tab, in the Definitions and Notes, the entry
for "Legal system" has been significantly expanded; it now includes
descriptions, origins, and features of the most common legal systems.
July 01, 2010
Many fields in the Economy category have been updated with the
latest available annual data, including "Labor force," "Unemployment
rate," "Budget - revenues and expenditures," "Public debt,"
"Inflation rate," "Current account balance," "Exports," "Imports,"
"Reserves of foreign exchange," and "Direct foreign investment."
June 18, 2010
The fields in the Economy category for "Stock of money," "Stock of
quasi-money," "and "Market value of publicly traded shares" have
been updated with the latest available data.
June 04, 2010
Significant updates entered under the Government, Economy, and
Military categories. The Country Comparisons function now also
appears in the ''World'' entry to allow users to quickly view how
countries rank in 58 different Factbook fields.
May 21, 2010
Dozens of new photos uploaded for Central and Eastern European
countries, most notably Bosnia and Herzegovina, Georgia, Latvia,
Poland, and Russia.
May 07, 2010
Major updates made to fields in the People, Government, and Military
categories. New photos appear under China, Romania, and Ukraine.
April 23, 2010
The ''World'' entry continues to accrue "top ten" rankings; recent
additions in the Geography category include the world''s ten highest
mountains and largest islands. The Transportation category lists the
top ten airports (both by passengers and cargo) and container ports,
as well as the ten longest rivers.
April 09, 2010
The ongoing expansion of flag descriptions - to also include
explanations of colors and symbols - is now complete for over
two-thirds of the Factbook entries.
March 26, 2010
The fields in the Economy category have been updated with the latest
available data. New photos introduced for the World, the Holy See
(Vatican City), and the Philippines.
March 05, 2010
In the Government category, a link to the World Leaders website
under the "Executive branch: cabinet" entry allows users to find a
listing of a country''s major officials.
February 19, 2010
Significant updates introduced in the Government, Communications,
and Transportation categories. New photos appear under France and
Germany.
January 26, 2010
In the Economy category, information has been updated and now covers
the year 2009. New photos added for Egypt and Italy.
January 08, 2010
The introductory Background statements have been updated or revised
for dozens of countries. New images introduced for Argentina, China,
the Czech Republic, South Africa, Svalbard, and Turkey.
December 04, 2009
In addition to various governmental and military updates, new photos
have been introduced for Germany, Greenland, Italy, Malaysia,
Maldives, and the United Kingdom.
November 13, 2009
Recent elections and governmental changes recorded for Afghanistan,
Aruba, Fiji, Germany, Haiti, Marshall Islands, Mongolia, Tunisia,
and Uruguay. In the Economy category, some 20 macro-economic fields
have been updated with the latest data. New NASA space photos added
for the Atlantic, Indian, and Pacific Oceans, as well as for
Montserrat and the World; new ground photos added for Cambodia,
France, and Luxembourg.
October 30, 2009
In the Economy category, all the energy-related fields have been
updated with the latest data; new photos added for Norway and Poland.
October 14, 2009
In addition to regular informational updates, new photos have been
added for Denmark, Estonia, Finland, Russia, and Sweden.
October 02, 2009
In the Transportation category, updates have been made to the
"Airports" and "Heliports" fields; new photos added for Libya,
Turkey, and the United Kingdom.
September 17, 2009
NASA images taken from space have been introduced to enhance various
country photo presentations. Significant numbers of high altitude
photos appear under China, Egypt, Spain, Australia, and New Zealand,
but can also be found scattered among other country entries. In the
Economy category, statistics for "Distribution of family income -
Gini index," "Public debt," and "Debt - external" now include two
year''s worth of data.
September 03, 2009
In the Economy category, statistics for "Current Account Balance,"
"Exports," "Imports," "Reserves of foreign exchange and gold,"
"Stock of direct foreign investment - at home," and "Stock of direct
foreign investment - abroad" now include two year''s worth of data;
statistics for "Market value of publicly traded shares" now include
three year''s worth of data. New photos added for Austria, France,
Monaco, Netherlands, and Netherlands Antilles.
August 17, 2009
Various rail gauge line lengths have been updated for all countries
in the Railways entry; selected economic and political entries also
updated.
July 31, 2009
In the Economy category, statistics for "Central bank discount
rate," "Commercial bank prime lending rate," "Stock of money,"
"Stock of quasi money," and "Stock of domestic credit" now include
two year''s worth of data.
July 20, 2009
Latest updates include changes to the chief of state or head of
government in Bosnia and Herzegovina, Croatia, Lithuania, and
Panama. New photographs have been added for Spain, Portugal,
Gibraltar, and South Africa.
July 01, 2009
With the launch of the new Web site, the former "Rank Order"
function was renamed "Country Comparisons." The link to Country
Comparisons may be found under the References tab. In addition, many
of the regional reference maps now incorporate both elevation and
vegetation on landmasses, and bathymetry for ocean areas. Statistics
for "Unemployment rate" and "Inflation rate (consumer prices)" now
include two year''s worth of data.
June 08, 2009
Completely redesigned website - presenting a cleaner look, improved
navigation, and a host of added features - launched on the World
Wide Web. Among the major enhancements are downloadable and
printable photos for nearly 100 countries, a "Did You Know?" section
explaining the impact of the Factbook around the world, and built-in
world rankings for many of the Factbook information fields.
Government sections reflect the results of recent parliamentary
elections in Kuwait - where women were elected for the first time -
and India, as well as presidential elections in Lithuania, Mongolia,
Panama, and South Africa.
April 27, 2009
Significant updates made to the People and Economy categories;
statistics for "GDP - real growth rate" and "GDP - per capita" (at
purchasing power parity) now include three year''s worth of data, in
2008 dollars. The Urbanization entry under People expanded to
include all countries.
April 03, 2009
In addition to regular country updates, statistics for "GDP
(purchasing power parity)" now include three year''s worth of data,
in 2008 dollars.
March 20, 2009
Recent major leadership changes in Guinea-Bissau, Latvia, and
Madagascar included in the Government sections of those countries.
March 02, 2009
Latest US Census Bureau figures - updating basic demographic data
for all countries - entered into the database. Entries on religions,
languages, ethnic groups, and literacy also updated.
February 06, 2009
Country information updated across all categories. Economic data now
includes 2008 estimates where available.
November 05, 2008
In order to provide more information on the nature and global
dimensions of the current financial crisis, five additional fields
appended to the Economy category: "Central bank discount rate,"
"Commercial bank prime lending rate," "Stock of money," "Stock of
quasi money," and "Stock of domestic credit."
August 06, 2008
In the People category, two new fields provide information on
education in terms of opportunity and resources: "School Life
Expectancy" and "Education expenditures."
November 06, 2007
In the Geography category, two new fields focus on the vital
resource of water: "Total renewable water resources" and "Freshwater
withdrawal."
October 31, 2007
Three new fields added to the Economy category: "Stock of direct
foreign investment - abroad," "Stock of direct foreign investment -
at home," "Market value of publicly traded shares."
Ongoing
Revision of some individual country maps, first introduced in the
2001 edition, continues. Several regional maps have been updated to
reflect boundary changes and place name spelling changes.
======================================================================
About :: DID YOU KNOW?
The World Factbook is one of the US Government''s most accessed
publications.
The World Factbook, produced for US policymakers and coordinated
throughout the US Intelligence Community, presents the basic
realities about the world in which we live. We share these facts
with the people of all nations in the belief that knowledge of the
truth underpins the functioning of free societies.
Who uses The World Factbook?
A wide variety of folks including US Government officials,
researchers, news organizations, corporations, geographers,
teachers, professors, librarians, and students. In short, anyone
looking for an expansive body of international data on a recently
updated Web site.
The World Factbook is a one-stop reference site.
Although many of the facts presented in The Factbook may be found in
various other publications, they are conveniently gathered together
in one place only at The World Factbook Web site.
The World Factbook is a unique reference in that it is updated
continuously - on average, every week.
Information in The Factbook is collected from - and coordinated with
- a wide variety of US Government agencies, as well as from hundreds
of published sources.
======================================================================
References :: Guide to Country Profiles
These are the Categories, Fields, and subfields of information
generally recorded for each country. Links are to the Definitions
and Notes about each entry.','9ededb311d0e247303c5de6407ff73620f96190351931e278a8c975b37a56467','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

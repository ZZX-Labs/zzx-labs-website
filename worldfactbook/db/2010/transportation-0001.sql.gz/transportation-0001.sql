SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b836d04481e9a25ed4e3cf248f9339a27a9628970e78be1ddb608c3dc04dab0',2010,'US','United States','transportation',130,'Airports
Airports— with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports— with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports
Pipelines
Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Roadways
total
paved
unpaved
Waterways
Merchant marine
total
ships by type
foreign-owned
registered in other countries
Ports and terminals
Transportation — note
Airports: 14,951 (2008)
Airports— with paved runways: total: 5,146
over 3,047 m: 190
2,438 to 3,047 m: 227
1,524 to 2,437 m: 1,464
914 to 1,523 m: 2,307
under 914 m: 958 (2008)
Airports — with unpaved runways:
total: 9,805
2,438 to 3,047 m: 6
1,524 to 2,437 m: 156
914 to 1,523 m: 1,734
under 914 m: 7,909 (2008)
Heliports: 146 (2007)
Pipelines: petroleum products 244,620
km; natural gas 548,665 km (2006)
Railways: total: 226,612 km
standard gauge : 226,612 km 1.435-m
gauge (2005)
Roadways: total: 6,465,799 km
paved: 4,209,835 km (includes 75,040 km
of expressways)
uhpaved: 2,255,964 km (2007)
Waterways: 41,009 km (19,312 km used
for commerce)
note: Saint Lawrence Seaway of 3,769 km,
including the Saint Lawrence River of
3,058 km, shared with Canada (2008)
Merchant marine: total 422
by type: barge carrier 6, bulk carrier 61 , cargo
69, carrier 2, chemical tanker 22, container
81 , passenger 1 9, passenger/cargo 59, petro¬
leum tanker 53, refrigerated cargo 3, roll
on/roll off 25, vehicle carrier 22
foreign-owned: 74 (Australia 1, Denmark
31, Germany 5, Japan 7, Malaysia 2,
Netherlands 1, Norway 9, Singapore 12,
Sweden 5, UK 1)
registered in other countries: 732 (Antigua
and Barbuda 8, Australia 2, Bahamas 106,
Bermuda 23, Cambodia 6, Canada 10,
Cayman Islands 42, Comoros 2, Cyprus
5, Ecuador 1, Greece 8, Hong Kong 29,
Ireland 2, Isle of Man 4, Italy 17, South
Korea 7, Liberia 98, Luxembourg 4, Malta
23, Marshall Islands 123, Netherlands 14,
Netherlands Antilles 1, Norway 8, Panama
126, Portugal 1, Puerto Rico 3, Russia 1,
Saint Vincent and the Grenadines 18,
Sierra Leone 1, Singapore 22, Trinidad
and Tobago 1, Tuvalu 1, UK 12, Vanuatu
1 , unknown 2) (2008)
Ports and terminals: Corpus Christi,
Duluth, Hampton Roads, Houston, Long
Beach, Los Angeles, New York, Philadel¬
phia, Tampa, Texas City','42c936caf6e686ff232f62fab1556f28d68b9a2e2e6feca1919a35b7e5a0df29','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b9e6271f460e991c94c72e57b1405c79b7f46d66174f285e0060a31a1cf0d1b',2010,'AF','Afghanistan','transportation',140,'Airports: 50 (2008)
Airports— with paved runways: total. 14
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports— with unpaved runways: total 36
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 16
914 to 1,523 m: 4
under 914 m: 10 (2008)
Heliports: 9 (2007)
Pipelines: gas 466 km (2008)
Roadways: total 42,150 km
paved: 12,350 km
unpaved: 29,800 km (2006)
Waterways: 1 ,200 km (chiefly Amu Darya,
which handles vessels up to 500 DWT)
(2008)
Ports and terminals:
Kheyrabad, Shir Khan','0223198c3c7224d2d9153eaf69634fe600a4ea8e8457af7d9ff979d0304ca4a3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('773b30fffb7bc92140db91247fe1944618d84531ffe11451d0474dd09f625b21',2010,'AL','Albania','transportation',150,'Airports: 8 (2008)
Airports— with paved runways:
total: 3 2,438 to 3,047 m: 3 (2008)
Airports— with unpaved runways:
total: 5
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Pipelines: gas 339 km; oil 207 km (2008)
Railways: total 447 km
standard gauge: 447 km 1 .435-m gauge
(2006)
8','08e5c5ebff326b391025ad64f91b079fa9f7a0727436287f89db721c6465bad7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a375249a69836654a58e9cf17e1d8cf48014dc5b957ff203588dc85c7fc2456e',2010,'DZ','Algeria','transportation',151,'Roadways: total: 18,000 km
paved: 7,020 km
unpaved: 10,980 km (2002)
Waterways: 43 km (2008)
Merchant marine: total: 24
by type: cargo 22, roll on/roll off 2
foreign-ovuned: 1 (Turkey 1)
registered in other countries: 2 (Panama 2)
(2008)
Ports and terminals: Durres, Sarande,
Shengjin, Vlore
Airports: 142 (2008)
Airports — with paved runways: total 57
over 3,047 m: 1 1
2,438 to 3,047 m: 28
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m: 1 (2008)
Airports— with unpaved runways: total 85
2,438 to 3,047 m: 3
1,524 to 2,437 m: 19
914 to 1,523 m: 40
under 914 m: 23 (2008)
Heliports: 2 (2007)
*
Pipelines: condensate 1,937 km; gas
14,648 km; liquid petroleum gas 2,933
km; oil 7,579 km (2008)
Railways: total 3,973 km
standard gauge: 2,888 km 1.435-m gauge
(283 km electrified)
narrow gauge: 1,085 km 1.055-m gauge
(2006)
Roadways: total 108,302 km
paved : 76,028 km (includes 645 km of
expressways)
unpaved: 32,274 km (2004)
Merchant marine: total 33
by type: bulk carrier 6, cargo 8, chemical tanker
1 , liquefied gas 9, passenger/cargo 3, petro¬
leum tanker 4, roll on/roll off 2
foreigmoumed: 18 (Jordan 7, UK 11) (2008)
Ports and terminals: Algiers, Annaba,
Arzew, Bejaia, Djendjene, Jijel, Mosta-
ganem, Oran, Skikda','d3ec7d6508793ec034f8fb30fe78ee137199f712320b48cc13af938a4e0dc223','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e3f0b4a821ecc0676e5e03fc0f879e491f7045f6aed6dcdb209317aa7b441a',2010,'AD','Andorra','transportation',168,'Airports: 3 (2008)
Airports — with paved runways:
total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2008)
Roadways: total: 221 km (2007)
Ports and terminals: Pago Pago','1b3aa94491d086c9c85eeabd37a29f443c943ab3f107c885f60069a72518ce72','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381889ca60cee7fa1718a242806405295dab3705f319dae511e639b61f961157',2010,'AO','Angola','transportation',178,'Roadways: total: 270 km (1994)
Airports: 21 1 (2008)
Airports — with paved runways: total: 30
over 3,047 m: 5
2,438 to 3,047 m: 8
1,524 to 2,437 m: 12
914 to 1,523 m: 4
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 181
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 32
914 to 1,523 m: 100
under 914 m: 42 (2008)
Pipelines: gas 2 km; oil 87 km (2008)
Railways: total: 2,761 km
narrow gauge: 2,638 km 1.067-m gauge;
1 23 km 0.600-m gauge (2006)
Roadways: total: 51,429 km
paved: 5,349 km
unpaved: 46,080 km (2001)
Waterways: 1,300 km (2008)
Merchant marine: total: 6
by type: cargo 1 , passenger/ cargo 2, petroleum
tanker 2, roll on/roll off 1
Airports: 200 (2008)
Airports— with paved runways: total: 26
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 17
914 to 1,523 m: 2
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 174 2,438 to 3,047 m: 1
1,524 to 2,437 m: 17
914 to 1,523 m: 89
under 914 m: 67 (2008)
Pipelines: gas 37 km; oil 39 km; refined
products 756 km (2008)
Railways: total: 5,138 km
narrow gauge: 3,987 km 1.067-m gauge
(858 km electrified); 125 km 1.000-m
gauge; 1 ,026 km 0.600-m gauge (2006)
Roadways: total: 153,497 km
paved: 2,794 km
unpaved: 150,703 km (2004)
Waterways: 15,000 km (2008)
Merchant marine: total: 1
by type: petroleum tanker 1
foreign-owned: 1 (Congo, Republic of the
1) (2008)
Ports and terminals: Banana, Boma,
Bukavu, Bumba, Goma, Kalemie, Kindu,
Kinshasa, Kisangani, Matadi, Mbandaka','11047f51122f160b8343a0a065efb186b9d5fa696a4797a20fe94b95552f5c11','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d3ac84476986ddd7d16e44c72a48e43620c6f3e84faa6e006e23f1b4ee81df0',2010,'AI','Anguilla','transportation',190,'Airports: 3 (2008)
Airports— with paved runways: total: l
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways: total: 2
under 914 m: 2 (2008)
Roadways: total: 175 km
paved: 82 km
unpaved: 93 km (2004)
Ports and terminals:
Blowing Point, Road Bay','48d2304bbc478a13b7933625eb130390d6bfdfc2b4a91d000e730cd0f2eab306','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adc4989eae33cc1d9e4592e1776ccaebb857f9958b469888e80289a27bb660d6',2010,'AR','Argentina','transportation',198,'Airports: 25 (2008)
24
Ports and terminals: Churchill (Canada),
Murmansk (Russia), Prudhoe Bay (US)
Transportation— note: sparse network
of air, ocean, river, and land routes; the
Northwest Passage (North America) and
Northern Sea Route (Eurasia) are impor¬
tant seasonal waterways
Airports: 1,150 (2008)
Airports — with paved runways: total: 154
over 3,047 m: 4
2,438 to 3,047 m: 26
1,524 to 2,437 m: 65
914 to 1,523 m: 50
under 914 m: 9 (2008)
Airports— with unpaved runways: total: 996
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 45
914 to 1,523 m: 526
under 914 m: 423 (2008)
Heliports: 1 (2007)
Pipelines: gas 28,138 km; liquid petro¬
leum gas 41 km; oil 5,939 km; refined
products 3,629 km (2008)
Railways: total: 31,902 km
broad gauge: 20,858 km 1.676-m gauge
(141 km electrified)
standard gauge: 2,885 km 1.435-m gauge
(26 km electrified)
narrow gauge: 7,922 km 1.000-m gauge;
237 km 0.750-m gauge (2006)
Roadways: total 231,374 km
paved: 69,412 km (includes 734 km of
expressways)
unpaved: 161,962 km (2004)
Waterways: 11,000 km (2007)
Merchant marine: total 46
by type: bulk carrier 3, cargo 9, chemical
tanker 2, container 1 , passenger 1 ,
passenger/cargo 3, petroleum tanker 24,
refrigerated cargo 2, roll on/roll off 1
foreign-owned: 14 (Brazil 1, Chile 7,
Spain 2, UK 4)
registered in other countries: 19 (Liberia 3,
Panama 8, Paraguay 5, Uruguay 3) (2008)
Ports and terminals: Arroyo Seco, Bahia
Blanca, Buenos Aires, La Plata, Punta
Colorada, Rosario, San Lorenzo-San Martin','841980e4b081e6435c936d93516cc012192d024edc8639e9d40f53d973fd7a81','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('179aaabc53620d8d549755083cd0112f45c3a64a91ab0de7b46c63aa5de9efc8',2010,'AG','Antigua and Barbuda','transportation',199,'Airports — with unpaved runways:
total: 25
over 3,047 m: 4
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 6 (2008)
Heliports: 53
note: all year-round and seasonal stations
operated by National Antarctic Programs
stations have some kind of helicopter
landing facilities, prepared (helipads) or
unprepared (2007)
Ports and terminals: there are no
developed ports and harbors in Antarc¬
tica; most coastal stations have offshore
anchorages, and supplies are transferred
from ship to shore by small boats, barges,
and helicopters; a few stations have a
basic wharf facility; US coastal stations
include McMurdo (77 51 S, 166 40 E),
and Palmer (64 43 S, 64 03 W); govern¬
ment use only except by permit (see
Permit Office under “Legal System”); all
ships at port are subject to inspection
in accordance with Article 7, Antarctic
Treaty; offshore anchorage is sparse and
intermittent; relevant legal instruments
and authorization procedures adopted by
the states parties to the Antarctic Treaty
regulating access to the Antarctic Treaty
area, to all areas between 60 and 90 degrees
of latitude south, have to be complied with
(see “Legal System”); The Hydrographic
Committee on Antarctica (HCA), a special
hydrographic commission of International
Hydrographic Organization (1HO), is
responsible for hydrographic surveying
and nautical charting matters in Antarctic
Treaty area; it coordinates and facilitates
provision of accurate and appropriate
charts and other aids to navigation in
support of safety of navigation in region;
membership of HCA is open to any IHO
Member State whose government has
acceded to the Antarctic Treaty and which
contributes resources and/or data to IHO
Chart coverage of the area; members of
HCA are Argentina, Australia, Brazil,
Chile, China, Ecuador, France, Germany,
Greece, India, Italy, NZ, Norway, Russia,
South Africa, Spain, UK, and US (2007)
Airports: 3 (2008)
Airports— with paved runways: total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 1
under 914 m: 1 (2008)
Roadways: total: 1,165 km
paved: 384 km
unpaved: 781 km (2002)
Merchant marine: total: 1,146
by type: barge carrier 2, bulk carrier 50, cargo
651, carrier 4, chemical tanker 5, container
392, liquefied gas 12, petroleum tanker
1, refrigerated cargo 9, roll on/roll off 20
foreign-oumed: 1,113 (Australia 1, Colombia
2, Cyprus 18, Denmark 19, Estonia
23, France 1, Germany 941, Greece 3,
Iceland 12, Italy 1, Latvia 13, Lithuania 5,
Netherlands 20, NZ 2, Norway 8, Poland 2,
Russia 4, Slovenia 6, Sweden 1 , Switzerland
8, Turkey 6, UK 9, US 8) (2008)
Ports and terminals: Saint John’s','a873558ee5602379de4e177a5c6992e811ef28cf4e1b1a1aa7212c85bd37aab2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebf87e58edae7d58c04c0f3894398d5cfe187afa3020a8ed6a786f06a534d23e',2010,'AM','Armenia','transportation',217,'Airports: 1 1 (2008)
Airports — with paved runways: total 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2008)
35
THE CIA WORLD FACTBOOK
Airports — with unpaved runways: total: 1
914 to 1,523 m: 1 (2008)
Pipelines: gas 2,233 km (2008)
Railways: total: 839 km
broad gauge: 839 km 1.520-m gauge (828
km electrified)
note: some lines are out of service (2006)
Roadways: total: 7,700 km
paved: 7,700 km (includes 1,561 km of
expressways) (2006)','be072b1cf218b4850f51c382d595f217df0340da1a61993a29c66422c44a5d1b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd09665667a1b1c8d99be1c79e12c722fe928afc2f200a9c4f2326fb99eead1f',2010,'NL','Netherlands','transportation',226,'Airports: 1 (2008)
Airports— with paved runways: total: l
2,438 to 3,047 m: 1 (2008)
Ports and terminals: Barcadera,
Oranjestad, Sint Nicolaas
Ports and terminals:
none; offshore anchorage only
Ports and terminals: Alexandria (Egypt),
Algiers (Algeria), Antwerp (Belgium), Barce¬
lona (Spain), Buenos Aires (Argentina),
Casablanca (Morocco), Colon (Panama),
Copenhagen (Denmark), Dakar (Senegal),
Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary
Airports: 27 (2008)
Airports — with paved runways: total: 20
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 7 914 to 1,523 m: 3
under 914 m: 4 (2008)
Heliports: 1 (2007)
Pipelines:
gas 3,816 km; oil 365 km; refined
products 716 km (2008)
Railways: total: 2,801 km
standard gauge: 2,801 km 1 .435-m gauge
(2,064 km electrified) (2007)
Roadways: total: 135,470 km (includes
2,582 km of expressways) (2007)
Waterways: 6,215 km (navigable for ships
of 50 tons) (2007)
Merchant marine: total. 622
by type: bulk carrier 9, cargo 381 , carrier 1 9,
chemical tanker 44, container 76, liquefied
gas 15, passenger 16, passenger/cargo 15,
petroleum tanker 11, refrigerated cargo 10,
roll on/roll off 23, specialized tanker 3
foreign-owned: 203 (Belgium 2, Cyprus
8, Denmark 29, Finland 14, France 1,
Germany 75, Ireland 10, Italy 1, South
Korea 1, Norway 12, Sweden 28, Turkey
1, UAE 5, UK 2, US 14)
registered in other countries: 178 (Antigua
and Barbuda 20, Australia 2, Austria
2, Bahamas 9, Cambodia 1, Canada 1,
Cyprus 22, Germany 1, Gibraltar 21,
Isle of Man 1, Liberia 6, Luxembourg 2,
Marshall Islands 8, Netherlands Antilles
38, Panama 14, Paraguay 1, Philippines
23, Portugal 1, Saint Vincent and the
Grenadines 3, US 1, unknown 1) (2008)
Ports and terminals:
Amsterdam, IJmuiden, Rotterdam,
Terneuzen, Vlissingen
Airports:
5 (2008)
Airports— with paved runways: total : 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2008)
Roadways: total: 845
Merchant marine: total. 147
by type: barge carrier 2, bulk carrier 2, cargo
72, carrier 19, chemical tanker 2, container
8, liquefied gas 1, passenger 2, petroleum
tanker 3, refrigerated cargo 27, roll on/roll
off 6, specialized tanker 3
foreign-owned: 123 (Belgium 1, Cuba 1,
Cyprus 21, Denmark 2, Germany 43,
Hong Kong 2, Netherlands 38, Norway 3,
Sweden 1, Turkey 10, US 1) (2008)
Ports and terminals: Bopec Terminal,
Willemstad','47ceb8e36c1b2b14a838b16f1a64014b8ff91d6c12a0f782e29c81de1be771c9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d284fe95b28b7d4e009b4e4140639902b8dc514190e7bc8d52768599eed647f',2010,'AU','Australia','transportation',231,'in 1901. The new country took advantage
of its natural resources to rapidly develop
agricultural and manufacturing industries
and to make a major contribution to the
British effort in World Wars I and II. In
recent decades, Australia has transformed
itself into an internationally competitive,
advanced market economy. It boasted one
of the OECD’s fastest growing economies
during the 1990s, a performance due in
large part to economic reforms adopted
in the 1980s. Long-term concerns include
climate-change issues such as the deple¬
tion of the ozone layer and more frequent
droughts, and management and conserva¬
tion of coastal areas, especially the Great
Barrier Reef.
Airports: 462 (2008)
Airports— with paved runways: total. 322
over 3,047 m: 1 1
2,438 to 3,047 m: 12
1,524 to 2,437 m: 144
914 to 1,523 m: 141
under 914 m: 14 (2008)
Airports— with unpaved runways:
total: 140
1,524 to 2,437 m: 19
914 to 1,523 m: 107
under 914 m: 14 (2008)
Heliports: 1 (2007)
Pipelines: gas 27,105 km; liquid petroleum
gas 240 km; oil 3,258 km; oil/gas/water 1
km (2008)
Railways: total: 38,550 km
broad gauge: 3,727 km 1.600-m gauge
standard gauge: 20,519 km 1.435-m gauge
(1,877 km electrified)
narrow gauge: 14,074 km 1.067-m gauge
(2,453 km electrified)
dual gauge: 230 km dual gauge (2006)
Roadways: total: 812,972 km
paved: 341,448 km
unpaved: 471,524 km (2004)
Waterways: 2,000 km (mainly used for
recreation on Murray and Murray-Darling
river systems) (2006)
Merchant marine: total 50
by type: bulk carrier 12, cargo 5, chemical
tanker 1, container 1, liquefied gas 4,
passenger 7, passenger/cargo 7, petroleum
tanker 8, roll on/roll off 5
foreign-owned: 24 (Canada 9, France 1 ,
Germany 2, Japan 1 , Netherlands 2, Norway
1, Singapore 1, UK 5, US 2)
registered in other countries: 28 (Antigua
and Barbuda 1 , Belize 1 , Bermuda 1 ,
Dominica 2, Fiji 1, Marshall Islands 1, NZ
1, Panama 4, Singapore 12, Tonga 1, US
1 , Vanuatu 2) (2008)
Ports and terminals: Brisbane, Dampier,
Fremantle, Gladstone, Hay Point,
Melbourne, Newcastle, Port Hedland, Port
Kembla, Port Walcott, Sydney
Ports and terminals: none; offshore
anchorage only','ea324a45aa7d71cb4b9b58b26d9e4dade23e75165de8ec90b5fe316cb6abe226','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81f283f8ca64a6d06e473e6dadc796e6aec9444b16795bc0b1b1f4d9dc2d13ca',2010,'AT','Austria','transportation',246,'Airports: 55 (2008)
Airports— with paved runways: total: 25
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 15 (2008)
Airports — with unpaved runways: total: 30
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 26 (2008)
Heliports: 1 (2007)
Pipelines: gas 2,721 km; oil 663 km;
refined products 157 km (2008)
Railways: total: 6,383 km
standard gauge: 5,924 km 1.435-m gauge
(3,772 km electrified)
narrow gauge: 371 km 1.000-m gauge;
88 km 0.760-m gauge (25 km electrified)
(2006)
46','1d86c3272a53e4eefe813d029211e122b175b6e674c8d2011403a565c6d3a55a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b492b291ff3a7af7b38bc6b2156f805b66c90729e0d73e62b99f7e3cd2ff3715',2010,'AZ','Azerbaijan','transportation',247,'Roadways:
total: 107,262 km
paved: 107,262 km (includes 1,677 km of
expressways) (2006)
Waterways: 358 km (2007)
Merchant marine: total: 4
by type: cargo 2, container 2
foreignowned: 2 (Netherlands 2)
registered in other countries: 4 (Cyprus 1,
Malta 1 , Saint Vincent and the Grenadines
2) (2008)
Ports and terminals: Enns, Krems, Linz,
Vienna
Airports: 35 (2008)
Airports— with paved runways: total: 27
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 13
914 to 1,523 m: 4
under 914 m: 2 (2008)
Airports — with unpaved runways: total 8
914 to 1,523 m: 1
under 914 m: 7 (2008)
Heliports: 1 (2007)
Pipelines: condensate 1 km; gas 3,361
km; oil 1 ,424 km (2008)
Railways: total: 2,122 km
broad gauge: 2,122 km 1.520-m gauge
(1,278 km electrified) (2006)
Roadways: total 59,141 km
paved: 29,210 km
unpaved: 29,931 km (2004)
Merchant marine: total 89
by type: cargo 26, passenger 2, passenger/
cargo 9, petroleum tanker 46, roll on/roll
off 3, specialized tanker 3
registered in other countries: 3 (Malta 2,
Panama 1) (2008)
Ports and terminals: Baku (Baki)
Airports: 62 (2008)
Airports — with paved runways: total: 23
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 6 (2008)
Airports — with unpaved runways:
total: 39
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m: 22 (2008)
Heliports: 1 (2007)
Roadways:
total: 2,717 km
paved: 1,560 km
unpaved: 1,157 km (2002)
Merchant marine:
total: 1,223
by type: barge carrier 1, bulk carrier 210,
cargo 226, carrier 2, chemical tanker 88,
combination ore/oil 1 2, container 65, lique¬
fied gas 77, passenger 109, passenger/cargo
35, petroleum tanker 209, refrigerated cargo
119, roll on/roll off 16, specialized tanker
3, vehicle carrier 51
foreign-oujned: 1,150 (Angola 6, Belgium
15, Bermuda 12, Brazil 2, Canada 84,
China 10, Croatia 1, Cuba 1, Cyprus
25, Denmark 67, Finland 9, France 30,
Germany 44, Greece 209, Flong Kong 30,
Iceland 1, Indonesia 2, Ireland 2, Isle of
Man 1, Italy 4, Japan 87, Jordan 2, Kenya
1, Malaysia 13, Monaco 15, Montenegro
2, Netherlands 9, Nigeria 2, Norway 189,
Poland 17, Russia 4, Saudi Arabia 16, Singa¬
pore 17, Slovenia 1, South Africa 1, Spain
14, Sweden 4, Switzerland 1, Thailand 5,
Trinidad and Tobago 1 , Turkey 8, UAE 23,
UK 56, US 106, Venezuela 1)
registered in other countries: 12 (Bolivia 1,
Panama 9, Peru 1, Portugal 1) (2008)
Ports and terminals: Freeport, Nassau,
South Riding Point ,','353a72e81183831635e59f841239df50bf2b28c6543310965813074afafc53a0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fee61a2fb3b7a963b4c5d8b5b1369eab74210ec3accf57a9c5afd6b5a93a3f3',2010,'BD','Bangladesh','transportation',261,'Airports: 3 (2008)
Airports— with paved runways:
total: 3
over 3,047 m: 2
2,438 to 3,047 m: 1 (2008)
Heliports: 1 (2007)
Pipelines: gas 20 km; oil 32 km (2008)
Roadways:
total: 3,498 km
paved: 2,768 km
unpaved: 730 km (2003)
Merchant marine:
total: 9
by type: bulk carrier 4, container 4, petro¬
leum tanker 1
foreign-owned: 6 (Kuwait 5, UAE 1) (2008)
Ports and terminals: Mina’ Salman, Sitrah
Airports: 17 (2008)
Airports— with paved runways:
total: 16
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 6 (2008)
Airports— with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2008)
Pipelines: gas 2,597 km (2008)
Railways: total: 2,768 km
broad gauge: 946 km 1.676-m gauge
narrow gauge: 1,822 km 1.000-m gauge
(2006)
Roadways:
total: 239,226 km
paved: 22,726 km
unpaved: 216,500 km (2003)
Waterways: 8,370 km
note: includes up to 3,060 km main cargo
routes; network reduced to 5,200 km in
dry season (2007)
Merchant marine:
total: 40
by type: bulk carrier 3, cargo 27, container
5, passenger/cargo 1, petroleum tanker 4
foreign-owned: 1 (China 1)
registered in other countries: 10 (Comoros 2,
Honduras 1 , Malta 2, Panama 2, Singapore
2, Togo 1) (2008)
Ports and terminals:
Chittagong, Mongla Port
Transportation— note: the International
Maritime Bureau reports the territorial
waters of Bangladesh as high risk for
armed robbery against ships; numerous
commercial vessels have been attacked
both at anchor and while underway; crews
have been robbed and stores or cargoes
stolen','154852c90e52a76d726772dea455a71bbfe7fdae37a80744cf4d58b097933a34','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5574ba67f023541854b998dd95e5895c243d741ad3af40fec150fe23c517e1',2010,'BB','Barbados','transportation',273,'Airports: 1 (2008)
Airports— with paved runways: total: 1
over 3,047 m: 1 (2008)
Roadways:
total: 1 ,600 km
paved: 1 ,600 km (2004)
Merchant marine: total: 85
by type: bulk carrier 15, cargo 50, chemical
tanker 7, passenger 1, passenger/cargo 1,
petroleum tanker 3, refrigerated cargo 6,
roll on/ roll off 2
foreign-owned: 80 (Canada 9, Greece 12,
India 1, Iran 2, Lebanon 1, Norway 38,
Sweden 7, Syria 1, UK 9)
registered in other countries: 1 (Saint Vincent
and the Grenadines 1 ) (2008)
Ports and terminals: Bridgetown','b1c979afcb4d8320480812e7f08e6f6b51d92ef3dbf75b5f8a7639e85959510b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5609ed3df933288e360f1dbd0e74b9758988004a071987728b82f7fc0fd9683',2010,'BE','Belgium','transportation',282,'Airports: 65 (2008)
Airports — with paved runways:
total: 35
over 3,047 m: 2
2,438 to 3,047 m: 22
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 6 (2008)
Airports — with unpaved runways:
total: 30
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 26 (2008)
Heliports: 1 (2007)
Pipelines: gas 5,250 km; oil 1,528 km;
refined products 1,730 km (2008)
Railways:
total: 5,512 km
broad gauge: 5,497 km 1.520-m gauge (874
km electrified)
standard gauge: 15 km 1.435 m (2006)
Roadways:
total: 94,797 km
paved: 84,028 km
unpaved: 10,769 km (2005)
Waterways: 2 ,500 km (use limited by loca¬
tion on perimeter of country and by shal¬
lowness) (2003)
Ports and terminals:
Mazyr','039d852bc1505e6608b232e944f59b563d2c778aadf3a1b52025a9ea107755d5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbf24b670b9941645a46adb492c82eb7de392f7cad4fa6eb074c408001c746b5',2010,'FR','France','transportation',290,'Airports: 42 (2008)
Airports — with paved runways:
total: 27
over 3,047 m: 6
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 9 (2008)
Airports — with unpaved runways:
total: 15
914 to 1,523 m: 1
under 914 m: 14 (2008)
Heliports: 1 (2007)
Pipelines:
gas 1,330 km; oil 158 km; refined prod¬
ucts 535 km (2008)
Railways: total: 3,536 km
standard gauge: 3,536 km 1.435-m gauge
(2,950 km electrified) (2006)
Roadways:
total: 152,256 km
paved: 119,079 km (includes 1,763 km of
expressways)
unpaved: 33,177 km (2006)
Waterways: 2,043 km (1,528 km in
regular commercial use) (2008)
Merchant marine: total: 79
by type : bulk carrier 20, cargo 9, chemical
tanker 1, container 6, liquefied gas 20,
passenger 2, petroleum tanker 11, roll on/
roll off 10
foreignowned: 6 (Denmark 4, France 2)
registered in other countries: 111 (Bahamas
15, Cyprus 2, France 6, Gibraltar 2, Greece
16, Hong Kong 3, Liberia 4, Luxembourg 7,
Malta 15, Mozambique 2, Netherlands 2,
Netherlands Antilles 1 , Panama 2, Portugal
8, Russia 4, Saint Kitts and Nevis 1, Saint
Vincent and the Grenadines 8, Sierra Leone
1 , Singapore 8, Vanuatu 4) (2008)
Ports and terminals: Antwerp, Gent,
Liege, Zeebrugge
suffered extensive losses in its empire,
wealth, manpower, and rank as a domi¬
nant nation-state. Nevertheless, France
today is one of the most modern coun¬
tries in the world and is a leader among
European nations. Since 1958, it has
constructed a hybrid presidential-parlia¬
mentary governing system resistant to the
instabilities experienced in earlier more
purely parliamentary administrations. In
recent years, its reconciliation and coop¬
eration with Germany have proved central
to the economic integration of Europe,
including the introduction of a common
exchange currency, the euro, in January
1999. At present, France is at the fore¬
front of efforts to develop the EU’s mili¬
tary capabilities to supplement progress
toward an EU foreign policy.
registered in other countries: 47 (Bahamas 9,
Germany 4, Gibraltar 3, Netherlands 14,
Norway 1 , Panama 2, Saint Kitts and Nevis
1, Sweden 12, UK 1) (2008)
Ports and terminals: Hamina, Helsinki,
Kokkola, Kotka, Naantali, Pori, Raahe,
Rauma, Turku
Airports: 475 (2008)
Airports— with paved runways: total: 295
over 3,047 m: 14
2,438 to 3,047 m: 26
1,524 to 2,437 m: 98
914 to 1,523 m: 82
under 914 m: 75 (2008)
Airports— with unpaved runways:
total: 180
1,524 to 2,43 7 m: 3
914 to 1,523 m: 71
under 914 m: 106 (2008)
Heliports: 3 (2007)
Pipelines: gas 14,688 km; oil 3,036 km;
refined products 5,080 km (2008)
Railways: total: 29,370 km
standard gauge: 29,203 km 1 .435-m gauge
(14,778 km electrified)
narrow gauge: 167 km 1.000-m gauge
(2006)
Roadways: total: 951,500 km
paved: 951,500 km (metropolitan France;
includes 10,950 km of expressways)
note: there are another 5,100 km of road¬
ways in overseas departments (2006)
Waterways: metropolitan France: 8,501
km (1,621 km accessible to craft of 3,000
metric tons)
French Guiana: 3,760 km (460 km
navigable by small oceangoing vessels and
coastal and river steamers, 3,300 km by
native craft) (2008)
Merchant marine: total: 138
by type: bulk carrier 2, cargo 1, chemical
tanker 32, container 25, liquefied gas 12,
passenger 3, passenger/cargo 33, petro¬
leum tanker 23, roll on/roll off 7
foreigmowned: 38 (Belgium 6, China 5,
Denmark 2, Germany 1, Italy 2, Japan 1,
NZ 1 , Norway 5, Saudi Arabia 1 , Singapore
2, Sweden 9, Switzerland 3)
registered in other countries: 127 (Antigua
and Barbuda 1, Australia 1, Bahamas 30,
244
Airports: 2 (2008)
Airports — with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Airports — with unpaved runways: total: 1
914 to 1,523 m: 1 (2008)
Merchant marine: total: 8
by type: chemical tanker 2, passenger 6
foreign-owned: 8 (France 6, French Poly¬
nesia 2) (2008)
Ports and terminals: Leava, Mata-Utu
Airports: 2 (2008)
Airports — with paved runways:
total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2008)
Roadways: total: 5,147 km
paved: 5,147 km
note: includes Gaza Strip (2006)','acf53e70f9e812f11c21b552a1083a431ece6c6a532d313c3843427e86b1107b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e90973014ce29c0aa17f09940c43785cd677334ca8a83c7d627e04486476629',2010,'BZ','Belize','transportation',300,'Airports: 44 (2008)
Airports — with paved runways: total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 2 (2008)
Airports — with unpaved runways: total: 40
2,438 to 3,047 m: 1
914 to 1,523 m: 12
under 914 m: 27 (2008)
Roadways: total: 3,007 km
paved: 575 km
unpaved: 2,432 km (2006)
Waterways: 825 km (navigable only by
small craft) (2008)
Merchant marine: total: 216
by type: barge carrier 1, bulk carrier 32,
cargo 152, chemical tanker 2, container 1,
passenger 1, petroleum tanker 9, refriger¬
ated cargo 12, roll on/roll off 5, special¬
ized tanker 1
foreign-owned: 178 (Australia 1, China 71,
Croatia 2, Cyprus 1, Estonia 6, Greece 1,
Iceland 2, Italy 3, Japan 8, South Korea 1,
Latvia 12, Norway 3, Peru 1, Russia 31,
Singapore 2, Spain 1, Turkey 15, Ukraine
7, UAE 5, UK 5) (2008)
Ports and terminals: Belize City, Big Creek','667a20d55d9183add655585ce21e54ceae9a87a2e8a4d5c9a434e1d7040e353c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea33aa4cb5af61ea2ff4b48caa2687401b97f63f7004c4ee9f7dedf67eeec17',2010,'BM','Bermuda','transportation',307,'Airports — with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Airports — with unpaved runways:
total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2008)
Railways: total: 758 km
narrow gauge: 758 km 1 .000-m gauge (2006)
Roadways: total: 16,000 km
paved: 1 ,400 km
unpaved: 14,600 km (2006)
Waterways: 150 km (on River Niger along
northern border) (2007)
Ports and terminals: Cotonou','8a0f999bfc11a8409fbdc8f311af078853af42619859ad7c56ea76f0e039461d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43690a6c4f530ac8b934e8651c7937253216144bc3782b4bf896487a16de9787',2010,'BT','Bhutan','transportation',316,'Airports: 1 (2008)
Airports — with paved runways: total: 1
2,438 to 3,047 m: 1 (2008)
Roadways: total: 447 km
paved: 447 km
note: public roads— 225 km; private
roads— 222 km (2007)
Merchant marine: total: 137
by type: bulk carrier 23, chemical tanker 3,
container 22, liquefied gas 33, passenger
24, passenger/cargo 5, petroleum tanker
18, refrigerated cargo 9
foreign-owned: 115 (Australia 1, China 10,
France 1, Germany 22, Greece 9, Hong
Kong 4, Ireland 1, Israel 3, Japan 2, Nigeria
11, Norway 5, Sweden 20, UK 3, US 23)
registered in other countries: 50 (Bahamas 12,
Marshall Islands 4, Philippines 34) (2008)
Ports and terminals:
Hamilton, Saint George
Airports: 2 (2008)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (2008)
Roadways:
total: 8,050 km
paved: 4,991 km
unpaved: 3,059 km (2003)
Airports: 1,009 (2008)
Airports — with paved runways: total: 16
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2008)
Airports— with unpaved runways:
total: 993
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 58
914 to 1,523 m: 186
under 914 m: 744 (2008)
Pipelines: gas 4,883 km; liquid petroleum
gas 47 km; oil 2,475 km; refined products
1,589 km (2008)
Railways: total: 3,504 km
narrow gauge: 3,504 km 1 .000-m gauge
(2006)
Roadways: total: 62,479 km
paved: 3,749 km
unpaved: 58,730 km (2004)
Waterways: 10,000 km (commercially
navigable) (2007)
Merchant marine: total: 23
by type: bulk carrier 1 , cargo 1 1 , carrier 1 ,
passenger/cargo 1, petroleum tanker 7,
refrigerated cargo 1, specialized tanker 1
foreign-owned: 7 (Bahamas 1 , China 1 , Iran
1, Singapore 1, Syria 2, Taiwan 1) (2008)
Ports and terminals: Puerto Aguirre (inland
port on the Paraguay/Parana waterway at
the Bolivia/Brazil border); Bolivia has free
port privileges in maritime ports in Argen¬
tina, Brazil, Chile, and Paraguay','2d91201edf846e8d73afaedd3f97fab2536734d4834183439b70fa57911af845','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8756e8a8018f6a6aed524d4901518a4a983fbe2b14ad60f95522f58ec37fb754',2010,'BA','Bosnia and Herzegovina','transportation',328,'Airports: 25 (2008)
Airports— with paved runways: total: 7
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
under 914 m: 2 (2008)
Airports— with unpaved runways:
total: 18
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 10 (2008)
Heliports: 5 (2007)
Railways: t
otal: 608 km
standard gauge: 608 km 1 .435-m gauge
(2006)
Roadways:
total: 21,846 km
paved: 11,425 km (4,714 km of interurban
roads)
unpaved: 10,421 km (2006)
Waterways: Sava River (northern border)
open to shipping but use limited (2008)
Ports and terminals: Bosanska Gradiska,
Bosanski Brod, Bosanski Samac, and
Brcko (all inland waterway ports on the
Sava), Orasje','aaedb6459b05c5c4c5fc14467be684d1b397af2a8a8936c9fab6a87fc4ade49b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d095f00eeceb0c8946f81ed9e696610b7e3c299ca21aa125b4335e4e16bf6401',2010,'BW','Botswana','transportation',336,'Airports: 77 (2008)
Airports— with paved runways:
total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways:
total: 67
1,524 to 2,437 m: 3
914 to 1,523 rn: 54
under 914 m: 10 (2008)
Railways: total: 888 km
narrow gauge: 888 km 1.067-m gauge
(2006)
Roadways: total: 25,798 km
paved: 8,410 km
unpaved: 17,388 km (2005)','b9fd63a09e89e1c7990cc73a056e11ca05095783b46f00f73970cece51dddc7e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7606c3ec7e13a28cdc621544c882425661afb93b758338a0b0e45dae18e654a9',2010,'BR','Brazil','transportation',348,'Airports: 4,176 (2008)
Airports — with paved runways: total: 734
over 3,047 m: 7
2,438 to 3,047 m: 26
1,524 to 2,437 m: 169
914 to 1,523 m: 476
under 914 m: 56 (2008)
Airports— with unpaved runways:
total: 3,442
1,524 to 2,437 m: 85
914 to 1,523 m: 1,541
under 914 m: 1,816 (2008)
Heliports: 16 (2007)
Pipelines: condensate/gas 62 km; gas
9,892 km; liquid petroleum gas 353 km;
oil 4,517 km; refined products 4,465 km
(2008)
96','7b6f8d5a095a34465c6a0880ff6fb8b7b64f6c4352a74e5b37f9cd94f130976f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e971e980ca3e6e1a63b8b21dbfacdc65eb95bf1fcf3cceb1be9f88dbe582ae2',2010,'IO','British Indian Ocean Territory','transportation',349,'Railways: total: 29,295 km
broad gauge: 4,932 km 1.600-m gauge (939
km electrified)
standard gauge : 194 km 1 .440-m gauge
narrow gauge: 23,773 km 1.000-m gauge
(581 km electrified)
dual gauge: 396 km 1 .000 m and 1 .600-m
gauges (three rails) (78 km electrified) (2006)
Roadways: total: 1,751,868 km
paved: 96,353 km
unpaved: 1,655,515 km (2004)
Waterways: 50,000 km (most in areas
remote from industry and population)
(2008)
Merchant marine: total: 136
by type: bulk carrier 19, cargo 22, carrier
1, chemical tanker 7, container 11,
liquefied gas 12, passenger/cargo 12,
petroleum tanker 45, roll on/roll off 7
foreign-owned: 25 (Chile 1, Denmark 2,
Germany 6, Greece 1, Mexico 1, Norway
5, Spain 9)
registered in other countries: 8 (Argentina 1 ,
Bahamas 2, Ghana 1, Liberia 3, Marshall
Islands 1) (2008)
Ports and terminals: Guaiba, Ilha Grande,
Paranagua, Rio Grande, Santos, Sao Sebas-
tiao, Tubarao
Transportation — note: die International
Maritime Bureau reports the territorial and
offshore waters in the Atlantic Ocean as a
significant risk for piracy and armed robbery
against ships; numerous commercial vessels
have been attacked and hijacked both at
anchor and while underway; crews have
been robbed and stores or cargoes stolen
Airports: 1 (2008)
Airports — with paved runways: total: 1
over 3,047 m: 1 (2008)
Roadways: note: short section of paved
road between port and airfield on Diego
Garcia
Ports and terminals: Diego Garcia
Airports: 4 (2008)
Airports — with paved runways: total: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports— with unpaved runways: total: 2
914 to 1,523 m: 2 (2008)
Roadways: total: 200 km
paved: 200 km (2007)
Merchant marine: registered in other coun¬
tries: 1 (Panama 1) (2008)
Ports and terminals: Road Town','cc16b4e718e9108cf2c1a1236c0fc8aa0ce75a03cb8f1a81cde84b6e161b2435','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb8f3b682969ad4ff2853b13cc4114b929354e779cfb8b4547dd5dfed439308',2010,'BG','Bulgaria','transportation',365,'Airports: 2 (2008)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2008)
Airports— with unpaved runways:
total: 1
914 to 1,523 m: 1 (2008)
Heliports: 3 (2007)
Pipelines: gas 37 km; oil 18 km (2008)
Roadways:
total: 3,650 km
paved: 2,819 km
unpaved: 831 km (2005)
Waterways: 209 km (navigable by craft
drawing less than 1.2 m) (2008)
Merchant marine:
total: 8
by type: liquefied gas 8
foreigmovuned: 1 (UK 1) (2008)
Ports and terminals: Lumut, Muara,
Seria
Airports: 204 (2008)
Airports — with paved runways: total: 127
over 3,047 m: 2
2,438 to 3,047 m: 18
1,524 to 2,437 m: 15
under 914 m: 92 (2008)
Airports — with unpaved runways:
total: 77
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 69 (2008)
Heliports: 4 (2007)
Pipelines: gas 2,926 km; oil 339 km;
refined products 1 56 km (2008)
Railways: total: 4,294 km
standard gauge: 4,049 km 1.435-m gauge
(2,710 km electrified)
narrow gauge: 245 km 0.760-m gauge
(2006)
Roadways:
total: 40,231 km
paved: 39,587 km (includes 331 km of
expressways)
unpaved: 644 km (2005)
Waterways: 470 km (2008)
Merchant marine: total: 74
by type: bulk carrier 37, cargo 14, chem¬
ical tanker 5, container 6, liquefied gas
2, passenger/cargo 2, petroleum tanker
3, roll on/roll off 4, specialized tanker 1
foreign-owned: 65 (Germany 63, Ireland
1, Russia 1)
registered in other countries: 31 (Comoros 2,
Malta 5, Panama 3, Saint Vincent and the
Grenadines 15, Slovakia 6) (2008)
Ports and terminals: Burgas, Varna','5593ad5ac945019a9044c777f0bba3efe08a633793e8ac4f6db1acc416132db6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccb5aad7f0a38e79dbf76fa8366b436f45a2db999535dbf999648edcbd7e983c',2010,'BF','Burkina Faso','transportation',378,'Airports: 26 (2008)
Airports — with paved runways: total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2008)
Airports — with unpaved runways: total: 24
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 8 (2008)
Railways:
total: 622 km
narrow gauge: 622 km 1 ,000-m gauge
note: another 660 km of this railway
extends into Cote D’Ivoire (2006)
Roadways:
total: 92,495 km
paved: 3,857 km
unpaved: 88,638 km (2004)
Airports: 84 (2008)
Airports— with paved runways: total: 31
over 3,047 m: 10
2,438 to 3,047 m: 10
1,524 to 2,437 m: 9
under 914 m: 2 (2008)
Airports — with unpaved runways:
total: 53
over 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 13
under 914 m: 30 (2008)
Heliports: 4 (2007)
Pipelines: gas 2,228 km; oil 558 km
(2008)
Railways: total: 3,955 km
narrow gauge: 3,955 km 1.000-m gauge
(2006)
Roadways:
total: 27,000 km
paved: 3,200 km
unpaved: 23,800 km (2006)
Waterways: 12,800 km (2008)
Merchant marine:
total: 24
by type: bulk carrier 1, cargo 17, passenger
2, passenger/cargo 3, specialized tanker 1
foreign-owned: 3 (Cyprus 1 , Germany 1 ,
Japan 1)
registered in other countries: 1 (Panama 1)
(2008)
Ports and terminals: Moulmein, Rangoon,
Sittwe
113
THE CIA WORLD FACTBOOK','cc92e515fc16fdc62a85a4e8ccb32eeea6071c52a3bd5659c183461aff686d70','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4595c5acb25a3b750ca77160d98e045c2daae64d7aeaab452aa362a7c12072f',2010,'BI','Burundi','transportation',384,'Airports: 8 (2008)
Airports— with paved runways: total: 1
over 3,047 m: 1 (2008)
Airports— with unpaved runways:
total: 7
914 to 1,523 m: 4
under 914 m: 3 (2008)
Heliports: 1 (2007)
Roadways:
total: 12,322 km
paved: 1,286 km
unpaved: 1 1 ,036 km (2004)
Waterways: mainly on Lake Tanganyika
(2008)
Ports and terminals: Bujumbura','e4e9609ce4587c13a7a2f348245d21d2164a59fb0f9cc61a0b35ea765b18e349','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609151c4a8f18055727459befe9e621f7afe3967597d9b05764d2db25ba34b9b',2010,'CM','Cameroon','transportation',393,'Airports: 17 (2008)
Airports— with paved runways:
total: 6 2,438 to 3,047 m: 2 1,524 to
2,437 m: 2 914 to 1,523 m: 2 (2008)
Airports — with unpaved runways:
total: 11
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 914 m: 1 (2008)
Heliports: 1 (2007)
Railways: total: 602 km
narrow gauge: 602 km 1 .000''m gauge
(2006)
Roadways: total: 38,257 km
paved: 2,406 km
unpaved: 35,851 km (2004)
Waterways: 2,400 km (mainly on Mekong
River) (2008)
Background: The former French
Cameroon and part of British Cameroon
merged in 1961 to form the present
country. Cameroon has generally enjoyed
stability, which has permitted the develop¬
ment of agriculture, roads, and railways,
as well as a petroleum industry. Despite a
slow movement toward democratic reform,
political power remains firmly in the hands
of President Paul BIYA.
Merchant marine: total. 626
by type: bulk carrier 41 , cargo 530, carrier 3,
chemical tanker 10, container 8, passenger/
cargo 6, petroleum tanker 11, refrigerated
cargo 1 5, roll on/ roll off 1 , vehicle carrier 1
foreign-owned: 467 (Canada 2, China 193,
Cyprus 7, Egypt 13, Gabon 1, Greece 3,
Hong Kong 8, Indonesia 2, Japan 1, South
Korea 22, Latvia 1, Lebanon 8, Nether¬
lands 1, Romania 1, Russia 83, Singapore
4, Syria 48, Taiwan 1, Turkey 26, Ukraine
34, UAE 2, US 6) (2008)
Ports and terminals: Phnom Penh,
Kampong Saom (Sihanoukville)
Airports: 34 (2008)
Airports — with paved runways: total: 10
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2008)
Airports— with unpaved runways:
total: 24 1,524 to 2,437 m: 4
914 to 1,523 m: 14
under 914 m: 6 (2008)
Pipelines: oil 889 km (2008)
Railways: total: 987 km
narrow gauge: 987 km 1 .000-m gauge (2006)
Roadways: total: 50,000 km
paved: 5,000 km
unpaved: 45,000 km (2004)
Waterways: navigation mainly on Benue
River; limited during rainy season (2008)
Ports and terminals: Douala, Limboh
Terminal','38787a046e7fa6dae0574d67c5c6c20ef14602dc22c2f817c88b94cc585747f3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c30ad8219132afad577b9d187c86f13336e0aa841d92630ebb88b39a43899fe4',2010,'CA','Canada','transportation',405,'Airports: 1,369 (2008)
Airports— with paved runways: total: 514
over 3,047 m: 18
2,438 to 3,047 m: 16
1,524 to 2,437 m: 152
914 to 1,523 rn: 251
under 914 m: 77 (2008)
Airports — with unpaved runways:
total: 855 1,524 to 2,437 m: 70
914 to 1,523 m: 367
under 914 m: 418 (2008)
Heliports: 11 (2007)
Pipelines: crude and refined oil 23,564
km; liquid petroleum gas 74,980 km
(2006)
Railways: total: 48,068 km
standard gauge: 48,068 km 1 .435-m gauge
(2006)
Roadways: total: 1,042,300 km
paved: 415,600 km (includes 17,000 km
of expressways)
unpaved: 626,700 km (2006)
Waterways: 636 km
note: Saint Lawrence Seaway of 3,769 km,
including the Saint Lawrence River of 3,058
km, shared with United States (2008)
Merchant marine: total. 175
by type: bulk carrier 60, cargo 13, carrier 1,
chemical tanker 1 0, combination ore/ oil 1 ,
container 2, passenger 6, passenger/cargo
64, petroleum tanker 12, roll on/roll off 6
foreignowned: 17 (Germany 3, Nether¬
lands 1, Norway 3, US 10)
registered in other countries: 206 (Australia
9, Bahamas 84, Barbados 9, Cambodia 2,
Cyprus 2, Denmark 1, Honduras 1, Hong
Kong 44, Liberia 7, Malta 1, Marshall
Islands 6, Norway 10, Panama 18, Saint
Vincent and the Grenadines 1, Spain 4,
Taiwan 2, Vanuatu 5) (2008)
Ports and terminals: Fraser River Port,
Halifax, Hamilton, Montreal, Port-Carrier,
127
THE CIA WORLD FACTBOOK
Quebec City, Saint John (New Brunswick),
Sept''Isles, Vancouver','a3d1af0075d4fe1e1d54b236dc09951b934877f379db16f0a0f52789ff9b04c0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc16de7748f0112dde25747af3c98eaf9a260b7684d78971f761c367aff540c',2010,'SN','Senegal','transportation',413,'Airports: 10(2008)
Airports— with paved runways: total: 9
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 2 (2008)
Roadways: total: 1,350 km
paved: 932 km
unpaved: 418 km (2000)
Merchant marine: total: 8
by type: cargo 2, chemical tanker 1 ,
passenger/cargo 5
foreignovuned: 2 (Spain 1, UK 1) (2008)
Ports and terminals: Porto Grande
Airports: 17 (2008)
Airports— with paved runways: total: 9
over 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2008)
Airports— with unpaved runways: total: 8
1,524 to 2,437 m: 6
914 to 1,523 m: 2 (2008)
Pipelines: gas 43 km; refined products 8
km (2008)
Railways: total: 906 km
narrow gauge: 906 km 1 .000
meter gauge (2006)
Roadways:
total: 13,576 km
paved: 3,972 km (includes 7 km of
expressways)
unpaved: 9,604 km (2003)
Waterways: 1,000 km (primarily on
Senegal, Saloum, and Casamance rivers)
(2008)
Ports and terminals: Dakar','59b366e47644e967e8aeff018a139ca2bdfbea370b281dd59a78f5641783ff98','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25b1152d92ea35821a858fd26046242c97effbc4d5cf9906b1a9862dd6672e51',2010,'KY','Cayman Islands','transportation',422,'Airports: 3 (2008)
Airports— with paved runways: total: 2
1,524 to 2,437 m: 2 (2008)
Airports — with unpaved runways: total: 1
914 to 1,523 m: 1 (2008)
Roadways: total: 785 km
paved: 785 km (2007)
Merchant marine: total: 109
by type: bulk carrier 30, cargo 2, chemical
tanker 42, petroleum tanker 1 5, refrigerated
cargo 10, roll on/ roll off 3, vehicle carrier 7
foreign-oumed: 107 (Denmark 3, Germany
1 5, Greece 16, Italy 4, Japan 1 3, Norway 1 ,
Singapore 10, UK 3, US 42) (2008)
132','9420d6e3c770acc9e5e79339a70e59ad4421ad02612b2fab01bbf91d6622d862','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2370fcd36cb70abbdd446a94f2b1f0239bc03c0fec1cae77d70f2e7ad26da15b',2010,'CF','Central African Republic','transportation',423,'Ports and terminals: Cayman Brae,
George Town
Airports: 44 (2008)
Airports— with paved runways: total-. 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways: total: 42
2,438 to 3,047 m : 1
1,524 to 2,437 m: 11
914 to 1,523 m: 19
under 914 m: 11 (2008)
Roadways: total: 24,307 km (2000)
Waterways: 2 ,800 km (primarily on the
Oubangui and Sangha rivers) (2007)
Ports and terminals: Bangui, Nola, Salo,
Nzinga','cd12699cf0ea5dd32f2015a77d64b7f99b9959044b2008efb048f11d723e7e72','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e20f34119e2060364fd0db929bb74c87e85b4404a32cf7cfc192b108ef130539',2010,'TD','Chad','transportation',436,'Airports: 53 (2008)
Airports— with paved runways: total. 8
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
under 914 m: 1 (2008)
Airports— with unpaved runways: total 45
2,438 to 3,047 m: 1
1,524 to 2,437 m: 13
914 to 1,523 m: 21
under 914 m: 10 (2008)
Pipelines: oil 250 km (2008)
Roadways: total 33,400 km
paved: 267 km
unpaved: 33,133 km (2002)
Waterways: Chari and Legone rivers are
navigable only in wet season (2008)
138','a1685ecdcaa8ed1a47c6148a46bf9ed30549e111ef5d2925f2f2446d31778ed1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56d84547e3b5f57160416ab354638d3e09f9f494e9a048f3fc904c48fe6a1c1d',2010,'CL','Chile','transportation',443,'Airports: 357 (2008)
Airports— with paved runways: total: 80
over 3,047 m: 5
2,438 to 3,047 m: 8
1,524 to 2,437 m: 22
914 to 1,523 m: 24
under 914 m: 21 (2008)
Airports — with unpaved runways:
total: 277 2,438 to 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 52
under 914 m: 211 (2008)
Pipelines: gas 2,676 km; liquid petroleum
gas 519 km; oil 892 km; refined products
769 km (2008)
Railways: total: 6,585 km
broad gauge: 2,831 km 1.676-m gauge
(1,317 km electrified)
narrow gauge: 3,754 km 1.000-m gauge
(2006)
Roadways: total: 80,505 km
paved: 16,745 km (includes 2,414 km of
expressways)
unpaved: 63,760 km (2004)
Merchant marine: total: 44
by type : bulk carrier 9 , cargo 7 , chemical tanker
8, container 1 , liquefied gas 2, passenger 4,
passenger/cargo 2, petroleum tanker 7, roll
on/ roll off 1 , vehicle carrier 3
registered in other countries: 40 (Argen¬
tina 7, Brazil 1, Cyprus 1, Isle of Man 6,
Marshall Islands 4, Norway 2, Panama 12,
Singapore 6, Venezuela 1) (2008)
Ports and terminals: Coronel, Fluasco,
Lirquen, Puerto Ventanas, San Antonio,
San Vicente, Valparaiso','b9afacd40e89dea1dc88270ee21db79bb7c1ad6ab4d41f61c91a9fb6fa18fff6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a28c497ae7b8c918d6a19e4589563a17e9dca171dcd28ef17371df58670275c5',2010,'CN','China','transportation',449,'Airports: 477 (2008)
Airports— with paved runways: total. 413
over 3,047 m: 59
2,438 to 3,047 m: 132
1,524 to 2,437 m: 129
914 to 1,523 m: 21
under 914 m: 72 (2008)
Airports— with unpaved runways: total 64
over 3,047 m: 3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 12
914 to 1,523 m: 17
under 914 m: 27 (2008)
Heliports: 35 (2007)
Pipelines: gas 28,132 km; oil 20,204 km;
refined products 9,746 km (2008)
Railways: total 75,438 km
standard gauge: 75,438 km 1.435-m gauge
(20,151 km electrified) (2005)
Roadways: total 1 ,930,544 km
paved: 1,575,571 km (includes 41,005 km
of expressways)
unpaved: 354,973 km (2005)
Waterways: 110,000 km navigable (2008)
Merchant marine: total 1,826
by type: barge carrier 4, bulk carrier 451,
cargo 689, carrier 2, chemical tanker 69,
combination ore/oil 1, container 162,
liquefied gas 44, passenger 8, passenger/
cargo 83, petroleum tanker 244, refriger¬
ated cargo 33, roll on/roll off 10, special¬
ized tanker 9, vehicle carrier 1 7
foreign-oumed: 20 (Ecuador 1, Greece 2,
Hong Kong 1 2, Indonesia 1 , Japan 2, South
Korea 1, Norway 1)
registered in other countries: 1 ,441 (Bahamas
10, Bangladesh 1, Belize 71, Bermuda
10, Bolivia 1, Cambodia 193, Cyprus
10, France 5, Georgia 10, Germany 2,
Honduras 3, Hong Kong 324, India 1,
Indonesia 2, Kiribati 15, South Korea 1,
Liberia 11, Malta 12, Marshall Islands
7, Mongolia 1, Norway 36, Panama 532,
Philippines 4, Saint Vincent and the
Grenadines 94, Sierra Leone 15, Singapore
14, Thailand 1, Tuvalu 16, unknown 39)
(2008)
Ports and terminals: Dalian, Guang¬
zhou, Ningbo, Qingdao, Qinhuangdao,
Shanghai, Shenzhen, Tianjin
Airports: 41 (2008)
Airports— with paved runways: total. 37
over 3,047 m: 8
2,438 to 3,047 m: 8
1,524 to 2,437 m: 11
914 to 1,523 m: 7
under 914 m: 3 (2008)
Airports— with unpaved runways: total 4
1,524 to 2,437 m: 2
under 914 m: 2 (2008)
Heliports: 4 (2007)
Pipelines: gas 406 km (2008)
Railways: total 1,588 km
standard gauge: 345 km 1 .435-m gauge
narrow gauge: 1,093 km 1.067-m gauge;
150 km .762-m gauge
note: the 150 km of .762 gauge track
belongs primarily to Taiwan Sugar Corpo¬
ration and Taiwan Forestry Bureau; some
to other entities (2007)
Roadways: total 40,262 km
paved: 38,171 km (includes 976 km of
expressways)
unpaved: 2,091 km (2007)
Merchant marine: total 102
by type: bulk carrier 32, cargo 19, chemical
tanker 1, container 24, passenger/cargo
3, petroleum tanker 14, refrigerated
cargo 7, roll on/roll off 2
foreign-owned: 3 (Canada 2, France 1)
registered in other countries: 536 (Bolivia 1,
Cambodia 1, Honduras 2, Hong Kong 11,
Indonesia 2, Italy 13, Kiribati 5, Liberia
91, Marshall Islands 1, Panama 320, Phil¬
ippines 1, Sierra Leone 1, Singapore 72,
Thailand 1 , UK 1 1 , unknown 3) (2008)
Ports and terminals: Chilung (Keelung),
Kaohsiung, Taichung','22dd4b963c305d729bc89106bbedbc50384862afc805acb2480b267ececba24c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc5c9d6dd9342db8a3613f056aa937e1065fcd2d29251fa597faff1dba4a94c',2010,'CX','Christmas Island','transportation',458,'Airports: 1 (2008)
Airports — with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total: 140 km
paved: 30 km
unpaved: 110 km (2007)
Ports and terminals: Flying Fish Cove
■
Ports and terminals: none;
anchorage only
offshore','ede01a2170af01c4a5703f6eea338beabf9bca84415ebce666a50266fdf72c1d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('753be2d61930961fd1f5ff80ade817a860e64a07bba78ea0aa808bf8b26602b2',2010,'CO','Colombia','transportation',466,'Airports: 1 (2008)
Airports— with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total: 22 km
paved: 10 km
unpaved: 1 2 km (2006)
Ports and terminals: Port Refuge
Airports:
991 (2008)
Airports— with paved runways: total: 107
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 39
914 to 1,523 m: 46
under 914 m: 12 (2008)
Airports— with unpaved runways: total: 884
over 3,047 m: 1
1,524 to 2,437 m: 35
914 to 1,523 m: 227
under 914 m: 621 (2008)
Heliports: 2 (2007)
Pipelines: gas 4,560 km; oil 6,094 km;
refined products 3,383 km (2008)
P''if 4 M
(kmm C&mm
momm
Arpum
*r
* .Demons
,v ''
/ ; . .:-y
T L>
0 m mm','ff129b3325d415603fe0e3896617aedb453a1eb6e0b74fcdba2591db5c678ced','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('798d1f101dfc602f6ab010e0a11215743263d329c85e05d0455627df5484761a',2010,'KM','Comoros','transportation',481,'Airports: 4 (2008)
Airports— with paved runways: total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2008)
Roadways: total: 880 km
paved: 673 km
unpaved: 207 km (2002)
Merchant marine: total: 1 36
by type: bulk carrier 15, cargo 87, carrier 2,
chemical tanker 5, container 2, passenger
1, passenger/cargo 1, petroleum tanker
9, refrigerated cargo 5, roll on/roll
off 8, specialized tanker 1
foreign-owned: 68 (Bangladesh 2, Bulgaria
2, Cyprus 1, Greece 6, India 2, Kenya 1,
Kuwait 1, Lebanon 4, Norway 1, Pakistan
4, Philippines 1, Russia 12, Saudi Arabia
1, Singapore 1, Syria 4, Turkey 8, Ukraine
8, UAE 7, US 2) (2008)
Ports and terminals: Mayotte, Mutsamudu','4b26bebdd4ca4465ed0e59d53a36d03d654858fa3af9f74fea0cfe3335560bde','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04a9b2679361578d2c5a8e01f7f7f6fb97f51992a0e4d64ee7799cd9ba9684a3',2010,'CG','Congo','transportation',486,'Airports: 24 (2008)
Airports — with paved runways: total 6
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2008)
Airports — with unpaved runways: total 1 8
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 1 (2008)
Pipelines:
gas 7 km; oil 207 km (2008)
Railways: total: 894 km
narrow gauge : 894 km 1.067-m gauge
(2006)
Roadways: total 17,289 km
paved: 864 km
unpaved: 16,425 km (2004)
Waterways: 1,120 km (commercially navi¬
gable on Congo and Oubanqui rivers)
(2008)
Merchant marine: registered in other coun¬
tries: 1 (Congo, Democratic Republic of the
1) (2008)
Ports and terminals: Brazzaville, Djeno,
Impfondo, Ouesso, Oyo, Pointe-Noire
163
THE CIA WORLD FACTBOOK','542dde2253886fdff7e67e670277bff793829624bd6ee9593d634579d50f2cf9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af307030ce4d44ad1f8155f0366d0994cd2eaebc16fb56ae05756447073b418f',2010,'NZ','New Zealand','transportation',496,'Airports: 9 (2008)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways:
total: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 1 (2008)
Roadways:
total: 320 km
paved: 33 km
unpaved: 287 km (2003)
Merchant marine: total: 26
by type: cargo 14, chemical tanker 1, petro¬
leum tanker 1, refrigerated cargo 8, roll
on/ roll off 2
foreign-owned: 1 7 (Latvia 1 , Lithuania 1 , NZ
1, Nigeria 1, Norway 5, Sweden 8) (2008)
Ports and terminals: Avatiu','63a9c83d7af558f205972651a27220016f0a97bccec79e04e0b295b2322d6c67','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7225ef01dc947e2f4bb81a4642ce7c433b6cdf4b54306698aec5dfa97a5ca600',2010,'CR','Costa Rica','transportation',505,'Ports and terminals: none; offshore
anchorage only
Airports: 149 (2008)
Airports— with paved runways: total: 37
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 22
under 914 m: 11 (2008)
Airports— with unpaved runways:
total: 112
914 to 1,523 m: 18
under 914 m: 94 (2008)
Pipelines:
refined products 796 km (2008)
Railways: total: 278 km
narrow gauge: 278 km 1.067-m gauge v v
note: none of the railway network is in
use (2007)
Roadways: total: 35,330 km
paved: 8,621 km
unpaved: 26,709 km (2004)
Waterways: 730 km (seasonally navigable
by small craft) (2008)
Merchant marine: total: 1
by type: passenger/cargo 1 (2008)
Ports and terminals: Caldera, Puerto
Limon
Airports: 31 (2008)
Airports— with paved runways: total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2008)
Airports — with unpaved runways: total 24
1,524 to 2,437 m: 6
914 to 1,523 m: 13
under 914 m: 5 (2008)
Pipelines: condensate 86 km; gas 1 80 km;
oil 92 km (2008)
Railways: total: 660 km
narrow gauge: 660 km 1.000 meter gauge
note: an additional 622 km of this railroad
extends into Burkina Faso (2006)
Roadways:
total: 80,000 km
paved: 6,500 km
unpaved: 73,500 km
note: includes intercity and urban roads;
another 20,000 km of dirt roads are in
poor condition and 150,000 km of dirt
roads are impassable (2006)
Waterways: 980 km (navigable rivers,
canals, and numerous coastal lagoons)
(2008)
Ports and terminals: Abidjan, Espoir,
San-Pedro','3ef3ae8e8cd6b3a1f8c01240e0bb132644d78347751dc43b6c74b4046ed26bf6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f507e51f1d55313d19e7759bb70f257891258892290f0bb3aca819126dc480d9',2010,'CU','Cuba','transportation',515,'Airports: 68 (2008)
Airports— with paved runways: total: 23
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 9 (2008)
Airports— with unpaved runways: total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 37 (2008)
Heliports: 2 (2007)
Pipelines: gas 1,327 km; oil 583 km (2008)
Railways: total: 2,726 km
standard gauge: 2,726 km 1.435-m gauge
(1,199 km electrified) (2006)
Roadways: total: 28,788 km (includes 877
km of expressways) (2006)
Waterways: 785 km (2008)
Merchant marine: total: 80
by type: bulk carrier 25, cargo 11, chemical
tanker 3, passenger/cargo 30, petroleum
tanker 8, refrigerated cargo 1 , rollon/ rolloff2
registered in other countries: 30 (Bahamas
1, Belize 2, Liberia 2, Malta 9, Marshall
Islands 6, Panama 3, Saint Vincent and
the Grenadines 7) (2008)
Ports and terminals: Omisalj, Ploce,
Rijeka, Sibenik, Vukovar (on Danube)','1684fd9cb2144d78161311600fbabb6fbba0f0db800d798d4e4953c4dc739c2b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92f8ea06704394bdcd4fbdac354e568c218a6f41f0ce7a93c59c7847a5ed1e40',2010,'CH','Switzerland','transportation',525,'Airports: 147 (2008)
Airports— with paved runways: total: 70
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2,437 m: 18
914 to 1,523 m: 5
under 914 m: 31 (2008)
Airports— with unpaved runways: total: 77
1,524 to 2,437 m: 1
914 to 1,523 m: 20
under 914 m: 56 (2008)
Pipelines: gas 41 km; oil 230 km (2008)
Railways: total: 4,226 km
standard gauge: 4,226 km 1.435-m gauge
(140 km electrified)
note: an additional 7,742 km of track is
used by sugar plantations; about 65% of
this track is standard gauge; the rest is
narrow gauge (2006)
Roadways: total: 60,858 km
paved: 29,820 km (includes 638 km of
expressway)
unpaved: 31,038 km (2000)
Waterways: 240 km (2008)
Merchant marine: total: 1 1
by type: bulk carrier 2, cargo 3, passenger
1, petroleum tanker 3, refrigerated cargo 2
foreignovuned: 1 (Spain 1)
registered in other countries: 1 3 (Bahamas 1 ,
Cyprus 1 , Netherlands Antilles 1 , Panama
10) (2008)
Ports and terminals: Cienfuegos, Havana,
Matanzas
Airports: 66 (2008)
Airports — with paved runways: total: 43
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 14
914 to 1,523 m: 5
under 914 m: 17 (2008)
Airports— with unpaved runways: total: 23
under 914 m: 23 (2008)
Heliports: 2 (2007)
Pipelines: gas 1,662 km; oil 94 km;
refined products 7 km (2008)
Railways: total: 4,839 km
standard gauge: 3,561 km 1.435-m gauge
(3,195 km electrified)
narrow gauge: 1,268 km 1.000-m gauge
(1,274 km electrified); 10 km 0.800-m
gauge (10 km electrified) (2006)
Roadways:
total: 71,298 km
paved: 71,298 km (includes 1,758 of
expressways) (2006)
Waterways: 65 km (Rhine River between
Basel-Rheinfelden and Schaffhausen-
Bodensee) (2008)
Merchant marine: total: 35
by type: bulk carrier 1 3, cargo 9, chemical
tanker 6, container 6, specialized tanker 1
registered in other countries: 106 (Antigua
and Barbuda 8, Bahamas 1 , France 3, Italy
8, Liberia 13, Malta 20, Marshall Islands
12, Panama 25, Portugal 2, Russia 3, Saint
Vincent and the Grenadines 6, Singapore
2, Tonga 1, UK 1, Vanuatu 1) (2008)
Ports and terminals: Basel
Airports: 101 (2008)
Airports— with paved runways: total. 28
over 3,047 m: 6
2,438 to 3,047 rn: 15
914 to 1,523 m: 2
under 914 m: 5 (2008)
Airports— with unpaved runways: total 73
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 58 (2008)
Heliports: 7 (2007)
Pipelines:
gas 2,900 km; oil 2,000 km (2008)
Railways: total 2,711 km
standard gauge: 2,460 km 1.435-m gauge
narrow gauge: 251 km 1.050-m gauge
(2006)
Roadways: total 97,401 km
paved: 19,490 km (includes 1,103 km of
expressways)
unpaved: 77,911 km (2006)
Waterways: 900 km (not economically
significant) (2008)
658
SYRIA
Merchant marine: total: 77
by type: bulk carrier 5, cargo 65, carrier
4, container 1, petroleum tanker 1, roll
on/ roll off 1
foreign-owned: 7 (Jordan 2, Lebanon 3,
Romania 2)
registered in other countries: 196 (Barbados
1, Bolivia 2, Cambodia 48, Comoros 4,
Cyprus 2, Dominica 2, Georgia 49, Hong
Kong 1, North Korea 1, Lebanon 2, Libya
2, Malta 6, Moldova 1, Panama 32, Saint
Kitts and Nevis 7, Saint Vincent and the
Grenadines 13, Sierra Leone 18, Slovakia
2, Togo 2, unknown 1) (2008)
Ports and terminals: Latakia, Tartus','2bc5e7c3c8012e32e9a7a309a08038ab11824a53dba1d04d0eb5f1730d303971','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29fd49a6d84acd60f746418d4963cfafb3cced8d8ddf0388c0fb347f93adad2d',2010,'CY','Cyprus','transportation',534,'Airports: 16(2008)
Airports— with paved runways: total: 1 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 1 (2008)
Airports— with unpaved runways: total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2008)
Heliports:
10(2007)
Roadways: total: 14,630 km (area under
government control: 1 2,280 km; area admin¬
istered by Turkish Cypriots: 2,350 km)
paved: area under government control: 7,979
km (includes 257 km of expressways); area
administered by Turkish Cypriots: 1 ,370 km
unpaved: area under government control:
4,301 km; area administered by Turkish
Cypriots: 980 km (2006)
Merchant marine: total: 858
by type: bulk carrier 295, cargo 1 82, chemical
tanker 63, container 193, liquefied gas 10,
passenger 5, passenger/cargo 24, petroleum
tanker 58, refrigerated cargo 10, roll on/roll
off 1 2, specialized tanker 1 , vehicle carrier 5
foreign-owned: 690 (Austria 1, Belgium 2,
Canada 2, Chile 1, China 10, Cuba 1,
Denmark 4, Estonia 5, Germany 189,
Greece 259, Hong Kong 2, India 2, Iran
10, Ireland 3, Israel 4, Italy 7, Japan 21,
South Korea 1, Latvia 1, Lebanon 1, Neth¬
erlands 22, Norway 18, Philippines 1,
Poland 18, Portugal 1, Russia 50, Singa¬
pore 3, Slovenia 4, Spain 6, Sweden 2,
Syria 2, Ukraine 4, UAE 9, UK 19, US 5)
registered in other countries: 256 (Antigua and
Barbuda 18, Bahamas 25, Belize 1, Burma
1, Cambodia 7, Comoros 1, Georgia 1,
Germany 2, Gibraltar 1, Greece 7, Liberia
63, Malta 31, Marshall Islands 37, Nether¬
lands 8, Netherlands Antilles 21, Panama
19, Poland 1, Russia 2, Saint Kitts and
Nevis 1 , Saint Vincent and the Grenadines
1, Samoa 1, Singapore 1, Tonga 1, Turkey
2, UK 2, unknown 1) (2008)
Ports and terminals: area under govern¬
ment control: Larnaca, Limassol, Vasilikos;
area administered by Turkish Cypriots:
Famagusta, Kyrenia
Airports: 122 (2008)
Airports— with paved runways: total: 45
over 3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m: 13
914 to 1,523 m: 2
under 914 m: 18 (2008)
Airports— with unpaved runways: total 77
1,524 to 2,437 m: 1
914 to 1,523 m: 26
under 914 m: 50 (2008)
Heliports: 1 (2007)
Pipelines: gas 7,010 km; oil 547 km;
refined products 94 km (2008)
Railways: total 9,597 km
standard gauge: 9,597 km 1.435-m gauge
(3,041 km electrified) (2006)
Roadways: total 128,512 km
paved: 128,512 km (includes 657 km of
expressways) (2007)
Waterways: 664 km (principally on Elbe,
Vltava, Oder, and other navigable rivers,
lakes, and canals) (2008)
Merchant marine: registered in other coun¬
tries: 1 (Saint Vincent and die Grenadines
1) (2008)
188
CZECH REPUBLIC
Ports and terminals: Decin, Prague, Usti
nad Labem','c5679da83ea34ccdc75bf353dfa3a59c80f57a718c08f616edc63029f40bd799','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e136c90ac8046c726217b64979413b5307e3bfe7598e6b77bf780c091d198ff',2010,'SE','Sweden','transportation',542,'Airports: 92 (2008)
Airports— with paved runways: total 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2008)
Airports — with unpaved runways: total: 64
914 to 1,523 m: 3
under 914 m: 61 (2008)
Pipelines: gas 2,858 km; oil 107 km
(2008)
Railways: total: 2,644 km
standard gauge: 2,644 km 1.435-m gauge
(636 km electrified) (2007)
Roadways: total: 72,362 km
paved: 72,362 km (includes 1,032 km of
expressways) (2006)
Waterways: 400 km (2008)
Merchant marine: total: 327
by type: bulk carrier 8, cargo 63, carrier 2,
chemical tanker 78, container 84, lique¬
fied gas 2, passenger/cargo 42, petroleum
tanker 29, refrigerated cargo 7, roll on/roll
off 8, specialized tanker 4
foreign-owned: 26 (Canada 1, Germany 1,
Germany 9, Greece 4, Iceland 2, Norway 3,
Sweden 6)
registered in other countries: 534 (Antigua
and Barbuda 19, Bahamas 67, Belgium
4, Brazil 2, Cayman Islands 3, Cyprus 4,
Egypt 1, Estonia 1, France 2, Germany 1,
Gibraltar 7, Hong Kong 24, Isle of Man
29, Italy 3, Jamaica 2, Liberia 12, Lithuania
5, Luxembourg 1, Malta 30, Marshall
Islands 10, Mexico 2, Netherlands 29,
192
DHEKELIA
Netherlands Antilles 2, Norway 25,
Panama 40, Portugal 3, Saint Vincent and
the Grenadines 16, Singapore 87, South
Africa 1, Spain 2, Sweden 4, Togo 1, UAE
1, UK 62, US 31, Venezuela 1) (2008)
Ports and terminals: Aalborg, Aarhus,
Copenhagen, Ensted, Esbjerg, Fredericia,
Kalundborg
Airports: 249 (2008)
Airports— with paved runways: total. 152
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 76
914 to 1,523 m: 25
under 914 m: 36 (2008)
Airports — with unpaved runways: total 97
914 to 1,523 m: 5
under 914 m: 92 (2008)
Heliports:
2 (2007)
Pipelines:
gas 786 km (2008)
Railways:
total: 1 1 ,528 km
standard gauge: 11,528 km 1.435-m gauge
(7,527 km electrified) (2006)
Roadways:
total 425,300 km
paved: 139,300 km (includes 1,740 km of
expressways)
unpaved: 286,000 km (2008)
Waterways:
2,052 km (2007)
Merchant marine: total 195
by type: bulk carrier 6, cargo 23, carrier 1,
chemical tanker 45, passenger 4, passenger/
cargo 36, petroleum tanker 15, roll on/roll
off 37, specialized tanker 3, vehicle carrier 25
foreign-owned: 41 (Denmark 4, Estonia
2, Finland 12, Germany 5, Italy 9,
Norway 7, UK 2)
registered in other countries: 207 (Antigua
and Barbuda 1, Bahamas 4, Barbados 7,
Bermuda 20, Cook Islands 8, Cyprus 2,
Denmark 6, Finland 2, France 9, Germany
1, Gibraltar 13, Isle of Man 1, Italy 1,
Liberia 10, Malaysia 3, Malta 2, Marshall
Islands 1, Netherlands 28, Netherlands
Antilles 1, Norway 34, Panama 6, Portugal
3, Saint Vincent and the Grenadines 2,
Singapore 20, UK 17, US 5) (2008)
Ports and terminals: Brofjorden,
Goteborg, Helsingborg, Lulea, Malmo,
Stenungsund, Stockholm, Trelleborg,
Visby','a8ddf51b50e37168ff023289a448a1eb7a46ece7317ba10e633e9e505973690b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1adf2242dbd77aea1cacd84fdbfb4e96adcde1a66238672815bb26bb848b4d96',2010,'DJ','Djibouti','transportation',554,'Airports: 13 (2008)
Airports — with paved runways: total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways:
total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2008)
Railways: total: 100 km (Djibouti segment
of the Addis Ababa-Djibouti railway)
narrow gauge: 100 km 1.000-m gauge
note: railway is under joint control of
Djibouti and Ethiopia but is largely inoper¬
able (2006)
Roadways: total: 3,065 km
paved: 1 ,226 km
unpaved: 1 ,839 km (2000)
Ports and terminals: Djibouti
Transportation — note: the International
Maritime Bureau reports offshore waters in
the Gulf of Aden are high risk for piracy;
numerous vessels, including commercial
shipping and pleasure craft, have been
attacked and hijacked both at anchor and
while underway; crew, passengers, and
cargo are held for ransom','f8a54429457b55933ca5e6f575409263e35ef13ecc13010099d4fefc687bedba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e41bbb3ba70d329b66b287c676c53fe1c088ca176ad348a0bd6e9c8aafffab0',2010,'DO','Dominican Republic','transportation',562,'Airports: 2 (2008)
Airports— with paved runways: total: 2
914 to 1,523 m: 2 (2008)
Roadways:
total: 780 km
paved: 393 km
unpaved: 387 km (2000)
Merchant marine: total: 53
by type: bulk carrier 14, cargo 27, chemical
tanker 3, petroleum tanker 5, refrigerated
cargo 2, roll on/roll off 1, vehicle carrier 1
foreign-owned: 47 (Australia 2, Estonia 7,
Greece 10, India 2, Latvia 1, Norway 1,
Russia 3, Saudi Arabia 2, Singapore 7, Syria
2, Turkey 5, Ukraine 4, UAE 1) (2008)
as Santo Domingo, sought to gain its own
independence in 1821, but was conquered
and ruled by the Haitians for 22 years;
it finally attained independence as the
Dominican Republic in 1844. In 1861,
the Dominicans voluntarily returned to the
Spanish Empire, but two years later they
launched a war that restored independence
in 1865. A legacy of unsettled, mostly non¬
representative rule followed, capped by the
dictatorship of Rafael Leonidas TRUJILLO
from 1930-61. Juan BOSCH was elected
president in 1962, but was deposed in a
military coup in 1963. In 1965, the United
States led an intervention in the midst of a
civil war sparked by an uprising to restore
BOSCH. In 1966, Joaquin BALAGUER
defeated BOSCH in an election to become
president. BALAGUER maintained a tight
grip on power for most of the next 30
years when international reaction to flawed
elections forced him to curtail his term
in 1996. Since then, regular competitive
elections have been held in which opposi¬
tion candidates have won the presidency.
Former President (1996-2000) Leonel
Ports and terminals: Portsmouth, Roseau
Airports: 36 (2008)
Airports— with paved runways:
total: 18
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 18
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 13 (2008)
Railways: total: 517 km
standard gauge: 375 km 1.435-m gauge
narrovu gauge: 142 km 0.762-m gauge
note: additional 1,226 km operated by
sugar companies in 1.076 m, 0.889 m, and
0.762-m gauges (2006)
Roadways: total: 19,705 km
paved: 9,872 km
unpaved: 9,833 km (2002)
Merchant marine: total: 1
by type: cargo 1
registered in other countries: 1 (Panama 1)
(2008)
Ports and terminals: Boca Chica, Caucedo,
Puerto Plata, Rio Haina, Santo Domingo','f90bb1420fdd3329cc1f15a1c7f1484d2b8c6bb53ff673be196915effb00a589','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24f6015aa1dd48ffc53feadefad076dcdfabce0ada5e1e2e0068b534a599919e',2010,'EC','Ecuador','transportation',574,'Airports: 418 (2008)
Airports — with paved runways: total: 102
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 16
914 to 1,523 m; 27
under 914 m: 52 (2008)
Airports — with unpaved runways: total:
316
914 to 1,523 m: 35
under 914 m: 281 (2008)
Heliports: 1 (2007)
Pipelines: extra heavy crude 435 km; gas 5
km; oil 1,374 km; refined products 1,301
km (2008)
Railways: total: 966 km
narrow gauge: 966 km 1 .067-m gauge
(2006)
Roadways: total: 43,670 km
paved: 6,472 km
unpaved: 37,198 km (2006)
Waterways: 1 ,500 km (most inaccessible)
(2008)
Merchant marine: total: 37
by type: cargo 1 , chemical tanker 1 , lique¬
fied gas 1, passenger 8, petroleum tanker
205
THE CIA WORLD FACTBOOK
24, refrigerated cargo 1 , specialized tanker 1
foreign-owned: 1 (US 1)
registered in other countries: 5 (China 1,
Panama 4) (2008)
Ports and terminals: Esmeraldas,
Guayaquil, Manta, Puerto Bolivar','103c2097b0ac371e8c2e965ad95b0dd8cea22cbe49252480c6fee15c03b83389','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ba400acbc3af961427e368fbf18778a2ffa2f6bf343572182bfb8d7ff12f0ec',2010,'EG','Egypt','transportation',584,'Airports: 85 (2008)
Airports — with paved runways: total: 71
over 3,047 m: 15
2,438 to 3,047 m: 35
1,524 to 2,437 m : 15
914 to 1,523 m: 2
under 914 m: 4 (2008)
Airports — with unpaved runways: total: 14
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 5 (2008)
Heliports: 3 (2007)
Pipelines: condensate 320 km; conden¬
sate/gas 13 km; gas 5,586 km; liquid
petroleum gas 956 km; oil 4,314 km; oil/
gas/water 3 km; refined products 895 km;
unknown 59 km; water 9 km (2008)
Railways: total: 5,063 km
standard gauge: 5,063 km 1 .435-m gauge
(62 km electrified) (2006)
Roadways: total: 92,370 km
paved: 74,820 km
unpaved: 1 7,550 km (2004)
Waterways: 3,500 km
note: includes Nile River, Lake Nasser,
Alexandria-Cairo Waterway, and numerous
smaller canals in delta; Suez Canal (193.5
km including approaches) navigable by
oceangoing vessels drawing up to 17.68 m
(2007)
Merchant marine: total: 67
by type: bulk carrier 11, cargo 28,
container 2, passenger/cargo 4, petroleum
tanker 13, roll on/roll off 9
foreign-owned: 10 (Denmark 1, Greece 8,
Lebanon 1)
registered in other countries: 58 (Cambodia
13, Georgia 12, Honduras 3, North Korea
1, Malta 1, Moldova 1, Panama 17, Saint
Kitts and Nevis 2, Saint Vincent and the
Grenadines 3, Saudi Arabia 1, Sierra
Leone 3, Togo 1) (2008)
Ports and terminals: Ayn Sukhnah, Alex¬
andria, Damietta, El Dekheila, Sidi Kurayr,
Suez','1f6a87217e98ce2df13cac33a0af8e0f4b2654a26f1e0e53ab5c4b391b9cd075','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1369289a75d90ef2507bb093b48cbaa229e9ba648dd71593397967db494579b',2010,'SV','El Salvador','transportation',591,'Airports: 65 (2008)
Airports — with paved runways: total: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2008)
Airports— with unpaved runways:
total: 61
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m: 47 (2008)
Heliports: 1 (2007)
Railways: total: 562 km
narrow gauge: 562 km 0.91 4-m gauge
note: railways have been inoperable since
2005 because of disuse and high costs that
led to a lack of maintenance (2007)
Roadways: total: 10,886 km
paved: 2,827 km (includes 327 km of
expressways)
■unpaved: 8,059 km (2000)
Waterways: Rio Lempa partially navigable
for small craft (2008)
Ports and terminals: Acajuda, Puerto
Cutuco','0743fc9e76a1fc225bee000f5e5f00b508f8ff5753d0af8dbbfe5c1821d31e5a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ce66688200084dbafcd590644d6cb3bee4b71d375ea19d54a53fa7e596739a5',2010,'GQ','Equatorial Guinea','transportation',601,'Airports: 6 (2008)
Airports — with paved runways: total: 5
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1 ,523 m: 1
under 914 m: 2 (2008)
Pipelines:
gas 38 km (2008)
Roadways:
total: 2,880 km (2000)
Merchant marine: total. 1
by type: cargo 1 (2008)
Ports and terminals: Bata, Malabo','023010be8440014f2b0597bd999da15db134a2a4a0141088a2fec5c6217b38dc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23ce3a7e110b1d7535495fb5d19918833e2551e5a9f624b3f2887ba8d990d15c',2010,'EE','Estonia','transportation',610,'Airports: 14 (2008)
Airports — with paved runways: total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2008)
Airports— with unpaved runways: total: 10
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 2 (2008)
Heliports: 1 (2007)
Railways: total: 306 km
narrow gauge: 306 km 0.950-m gauge
(2006)
Roadways: total: 4,010 km
paved: 874 km
unpaved: 3,136 km (2000)
Merchant marine: total: 5
by type: cargo 2, liquefied gas 1, petroleum
tanker 1 , roll on/ roll off 1 (2008)
Ports and terminals: Assab, Massawa
Airports: 19 (2008)
Airports — with paved runways:
total: 13
over 3,047 m: 1
2,438 to 3,047 m: 8
1,524 to 2,437 m: 1
914 to 1,523 m: 3 (2008)
Airports — with unpaved runways: total: 6
over 3,047 m: 1
1,524 to 2,437 m: 2
under 914 m: 3 (2008)','44687d6f3a8c5e635c59762a0ac3a56eb2d57e0866a6d1796f2cf0dc899ad13d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b43fdb765f9ea37439f95b16e7102d49a8389fafe12eae80eb2350f150d2c9d',2010,'ET','Ethiopia','transportation',621,'Airports: 63 (2008)
Airports— with paved runways: total: 16
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 5
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 47
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 9 (2008)
Railways: total: 699 km (Ethiopian segment
of the Addis Ababa-Djibouti railroad)
narrow gauge: 699 km 1 ,000-m gauge
note: railway is under joint control of
Djibouti and Ethiopia but is largely inoper¬
able (2006)
Roadways: total: 36,469 km
paved: 6,980 km
unpaved: 29,489 km (2004)
Merchant marine: total: 9
by type: cargo 8, roll on/roll off 1 (2008)
Ports and terminals: Ethiopia is land¬
locked and uses ports of Djibouti in
Djibouti and Berbera in Somalia
Airports: 26 (2008)
Airports— with paved runways: total. 8
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2008)
Airports— with unpaved runways: total 18
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
$14 to 1,523 m: 6
under 914 m: 7 (2008)
Railways: total 729 km
narrow gauge: 729 km 1.000-m gauge
(2006)
Roadways: total 18,709 km
paved: 3,368 km
unpaved: 15,341 km (2004)
Waterways: 1 ,800 km (2008)
Ports and terminals: Koulikoro
Military branches: Malian Armed Forces:
Army, Republic of Mali Air Force (Force
Aerienne de la Republique du Mali,
FARM), National Guard (2008)
Military service age and obligation: 18
years of age for compulsory and voluntary
military service; conscript service obliga¬
tion— 2 years (2008)
Manpower available for military
Service: males age 16-49: 2,603,700
females age 16-49: 2,441,776 (2008 est.)
Manpower fit for military service:
males age 16-49: 1,649,772
females age 16-49: 1,579,601 (2009 est.)
Manpower reaching militarily signifi¬
cant age annually: male. 147,846
female: 140,543 (2009 est.)
Military expenditures: 1.9% of GDP
(2006)
Disputes— international : none
Refugees and internally displaced
persons: refugees ( country of origin .): 6,300
(Mauritania) (2007)
tv:W~,‘4h:','4db39dfa56a56c813e02dda3be937883f8015e177c93c4bc714ced4294bf7a5e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('348521837d83965454860ee1b628fa13f6fbd6eb2339971aab8c2b6cf1b6e807',2010,'IT','Italy','transportation',627,'Airports: 3,127 3,393 (2008)
Airports — with paved runways:
total: 1,842
over 3,047 m: 107
2,438 to 3,047 m: 316
1,524 to 2,437 m: 518
914 to 1,523 m: 424
under 914 m: 111 (2008)
Airports— with unpaved runways:
total: 1,285
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 27
914 to 1,523 m: 243
under 914 m: 1,009 (2008)
Heliports: 100 (2007)
Railways: total: 236,436 km
broad gauge: 28,250 km
standard gauge: 200,401 km
narrow gauge: 7,771 km
other: 23 km (2007)
Roadways: total: 5, 454,446 km (2008)
Waterways: 52,332 km (2006)
Ports and terminals: Antwerp (Belgium),
Barcelona (Spain), Braila (Romania), Bremen
(Germany), Burgas (Bulgaria), Constanta
(Romania), Copenhagen (Denmark), Galati
(Romania), Gdansk (Poland), Hamburg
(Germany), Helsinki (Finland), Las Palmas
(Canary Islands, Spain), Le Havre (France),
Lisbon (Portugal), London (UK), Marseille
(France), Naples (Italy), Peiraiefs or Piraeus
(Greece), Riga (Latvia), Rotterdam (Neth¬
erlands), Stockholm (Sweden), Talinn
(Estonia), Tulcea (Romania), Varna
(Bulgaria)
Airports: 6 (2008)
Airports — with paved runways:
total: 2
2,438 to 3,047 m : 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways:
total: 4
under 914 m: 4 (2008)
Roadways:
total: 440 km
paved: 50 km
unpaved: 390 km (2008)
Ports and terminals: Stanley
Airports: 132 (2008)
Airports— with paved runways: total: 101
over 3,047 m: 8
2,438 to 3,047 m: 30
1,524 to 2,437 m: 16
914 to 1,523 m: 34
under 914 m: 13 (2008)
Airports — with unpaved runways: total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 19 (2008)
Heliports: 5 (2007)
Pipelines: gas 17,544 km; oil 1,241 km
(2008)
Railways: total: 19,460 km
standard gauge: 1 8,038 km 1 ,435-m gauge
(11,354 km electrified)
narrow gauge: 123 km 1 .000-m gauge (123
km electrified); 1,299 km 0.950-m gauge
(161 km electrified) (2006)
Roadways: total: 487,7 00 km
paved: 487,700 km (includes 6,700 km of
expressways) (2005)
Waterways: 2,400 km
note: used for commercial traffic; of limited
overall value compared to road and rail
(2008)
Merchant marine: total: 609
by type: bulk carrier 60, cargo 47, carrier 2,
chemical tanker 159, combination ore/oil
1 , container 25, liquefied gas 27, passenger
22, passenger/cargo 154, petroleum tanker
35, refrigerated cargo 4, roll on/roll off 33,
specialized tanker 13, vehicle carrier 27
foreign-owned: 64 (Denmark 3, France 2,
Greece 6, Japan 1, Lebanon 1, Nigeria 1,
Norway 2, Portugal 1 , Sweden 1 , Switzerland
8, Taiwan 13, Turkey 1, UK 7, US 17)
registered in other countries: 208 (Antigua and
Barbuda 1, Bahamas 4, Belize 3, Cayman
Islands 4, Cyprus 7, France 2, Liberia 41,
Malta 50, Marshall Islands 3, Netherlands
1, Norway 4, Panama 28, Portugal 12,
Russia 4, Saint Kitts and Nevis 1, Saint
Vincent and the Grenadines 17, Singapore
5, Slovakia 2, Spain 2, Sweden 9, Turkey
3, UK 5) (2008)
Ports and terminals: Augusta, Genoa,
Livorno, Ravenna, Sarroch, Taranto,
Trieste, Venice','0b492ba4741798564cb5b2226283b662f2c6f5ef7c6a8ae5e772a0db04a4d24d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc53611b6e3c025c911da0a5be7e0d86e1ba0155cf83bb0c979a9b1c086644e3',2010,'FO','Faroe Islands','transportation',636,'Airports: 1 (2008)
Airports — with paved runways: total: 1
914 to 1,523 m: 1 (2008)
Roadways: total: 463 km (2006)
Merchant marine: total: 12
by type: cargo 9, passenger/cargo 3
233
THE CIA WORLD FACTBOOK
foreign-owned: 5 (Iceland 1 , Norway 4)
(2008)
Ports and terminals: Torshavn, Vagur','cece4c0629d980f11b07c1bdeb9412f7233832e115ef9d47dc7b01d3d95d2561','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee49128f69bd4ee3bd4c28699b69837214b7fc9b39d74571f89ccd3fc3b5a1be',2010,'FJ','Fiji','transportation',644,'Airports: 28 (2008)
Airports — with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways:
total: 25
914 to 1,523 m: 7
under 914 m: 18 (2008)
Railways:
total: 597 km
narrow gauge: 597 km 0.600-m gauge
note: belongs to the government-owned Fiji
Sugar Corporation; used to haul sugarcane
during the harvest season, which runs
from May to December (2006)
236','fe3cdcde2d682e90708093c8501aed20b331af13e2b392a7bfbc9c67e92d5bc6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a71aabfcc19862f0c0be5d8216e922702bca4c4f6fa5f89822e54e6d7eb3bc6',2010,'FI','Finland','transportation',645,'Roadways: total: 3,440 km
paved: 1,692 km
unpaved: 1,748 km (2000)
Waterways: 203 km
note: 1 22 km navigable by motorized craft
and 200''metric''ton barges (2008)
Merchant marine: total: 9
by type: passenger 3, passenger/cargo 4,
roll on/ roll off 2
foreign-owned: 1 (Australia 1) (2008)
Ports and terminals: Lautoka, Suva
Airports: 148 (2008)
Airports— with paved runways:
total: 75
over 3,047 m: 3
2,438 to 3,047 m: 26 v ^
1,524 to 2,437 m: 10
914 to 1,523 m: 22
under 914 m: 14 (2008)
Airports— with unpaved runways:
total: 73
914 to 1,523 m: 3
under 914 m: 70 (2008)
Pipelines: gas 694 km (2008)
Railways: total: 5,741 km
broad gauge: 5,741 km 1.524-m gauge
(2,619 km electrified) (2006)
Roadways: total: 78,821 km
paved: 50,854 km (includes 700 km of
expressways)
unpaved: 27,967 km (2008)
Waterways: 7,842 km
note: includes Saimaa Canal system of
3,577 km; southern part leased from
Russia (2008)
Merchant marine: total: 98
by type: bulk carrier 3, cargo 28, carrier 1 ,
chemical tanker 6, container 3, passenger
5, passenger/cargo 18, petroleum tanker 5,
roll on/roll off 27, vehicle carrier 2
foreignowned: 8 (Estonia 2, Germany 1,
Norway 3, Sweden 2)','d2c55554e61b4a0eef6a82eaea6899109865283a404b4883541ae19ba247564b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160d8e1e54710466f990983df361d4d67ba1a25cbf350504070494345af088c3',2010,'PF','French Polynesia','transportation',657,'Belgium 2, Bermuda 1, Hong Kong 1,
Indonesia 1, Isle of Man 1, Italy 2, Liberia
5, Luxembourg 17, Malta 5, Morocco 14,
Netherlands 1, Norway 3, Panama 5, Saint
Vincent and the Grenadines 6, Singapore
1, Taiwan 1, UK 23, Wallis and Futuna
6) (2008)
Ports and terminals: Bordeaux, Calais,
Dunkerque, Le Havre, Marseille, Nantes,
Paris, Rouen, Strasbourg
Airports: 55 (2008)
Airports— with paved runways: t
otal: 48
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 34
under 914 m: 7 (2008)
Airports — with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2008)
Heliports: 1 (2007)
Roadways:
total: 2,590 km
paved: 1,735 km
unpaved: 855 km (1999)
Merchant marine: total: 15
by type: cargo 6, passenger 2, passenger/
cargo 5, refrigerated cargo 1 , roll on/ roll off 1
registered in other countries: 2 (Wallis and
Futuna 2) (2008)
Ports and terminals: Papeete
Airports: 4 (note— one each on Europa
Island, Glorioso Islands, Juan de Nova
Island, and Tromelin Island in the lies
Eparses district) (2006)
Ports and terminals: none; offshore
anchorage only
Transportation— note: aids to naviga¬
tion-lighthouses: Europa Island 18m; Juan
de Nova Island (W side) 37m; Tromelin
Island (NW point) 11m (all in the lies
Eparses district)','e18977aa0d32e70694b65c7bb896f640c768b667cd888ead9ff9cc691f58b98c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab0c771f3307767b5b54719524345587af69bc11d56d1ef99acf3b88a7a121e',2010,'GA','Gabon','transportation',669,'Airports: 39 (2008)
Airports — with paved runways: total: 12
over 3,047 m: 1
2,438 to 3,047 rn: 1
1,524 to 2,437 m : 9
914 to 1,523 m: 1 (2008)
Airports— with unpaved runways:
total: 27
1,524 to 2,437 m: 5
914 to 1,523 m: 10
under 914 m: 12 (2008)
Pipelines: gas 240 km; oil 723 km (2008)
Railways: total: 814 km
standard gauge: 814 km 1.435-m gauge
(2006)
Roadways: total 9,170 km
paved: 937 km
unpaved: 8,233 km (2004)
Waterways: 1 ,600 km (310 km on Ogooue
River) (2008)
Merchant marine: registered in other coun¬
tries: 2 (Cambodia 1, Panama 1) (2008)
Ports and terminals: Gamba, Libreville,
Lucinda, Port-Gentil
Airports: 1 (2008)
Airports — with paved runways: total: 1
over 3,047 m: 1 (2008)
Roadways:
total: 3,742 km
paved: 723 km
unpaved: 3,019 km (2004)
Waterways: 390 km (on River Gambia;
small ocean-going vessels can reach 190
km) (2008)
Merchant marine: total: 5
by type: passenger/cargo 4, petroleum
tanker 1 (2008)
Ports and terminals: Banjul
Airports: 1 (2008)
Airports — with paved runways: total: 1
over 3,047 m: 1 (2008)
257
THE CIA WORLD FACTBOOK
Airports— with unpaved runways: total: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Roadways: note: see entry for West Bank
Ports and terminals: Gaza','a687a3f7aa2a930916ff702105eff1e35c9cc8f7add23cb18e0c22cdd9f0e250','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40c235a5c324011b91d17ab814c198e0eb92cff90951779066e9e7d26b03e018',2010,'GE','Georgia','transportation',677,'Airports: 23 (2008)
Airports— with paved runways:
total: 19
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 2 (2008)
Airports— with unpaved runways:
total: 4
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2008)
Heliports: 3 (2007)
Pipelines: gas 1,591 km; oil 1,253 km
(2008)
Railways:
total: 1 ,612 km
broad gauge: 1,575 km 1.520-m gauge
(1,575 electrified)
narrow gauge: 37 km 0.91 2-m gauge (37
electrified) (2006)
Roadways: total: 20,329 km
paved: 7,854 km (includes 13 km of
expressways)
unpaved: 12,475 km (2006)
Merchant marine: total: 191
by type: bulk carrier 18, cargo 148, carrier
2, chemical tanker 1 , container 4, liquefied
gas 1, passenger/cargo 2, petroleum tanker
4, refrigerated cargo 5, roll on/roll off 4,
vehicle carrier 2
foreign-owned: 153 (China 10, Cyprus 1,
Egypt 12, Germany 2, Greece 5, Hong
Kong 2, Israel 2, Lebanon 4, Monaco 4,
Nigeria 1 , Romania 16, Russia 12, Syria 49,
Turkey 14, Ukraine 18, UAE 1) (2008)
Ports and terminals: Bat umi, P’ot’i
Transportation — note: large parts of trans¬
portation network are in poor condition
because of lack of maintenance and repair','1e53fc61b6bb084bf12b29902c490d45e60a565c93eb3fc38fae7e35ec2f3841','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08d6501261ead2dd2bfd4055e67cea2f05dd86b917d77afc6891e6bd250c4d48',2010,'GH','Ghana','transportation',685,'Airports: 549 (2008)
Airports— with paved runways:
total: 331
over 3,047 m: 1 3
2,438 to 3,047 m: 52
1,524 to 2,437 m: 59
914 to 1,523 m: 73
under 914 m: 134 (2008)
Airports— with unpaved runways:
total: 218
1,524 to 2,437 m: 3
914 to 1,523 m: 34
under 914 m: 181 (2008)
Heliports: 28 (2007)
Pipelines: gas 24,364 km; oil 3,379 km;
refined products 3,843 km (2008)
Railways:
total: 48,215 km
standard gauge: 47,962 km 1.435-m gauge
(20,278 km electrified)
narrow gauge: 229 km 1.000-m gauge (16
km electrified); 24 km 0.750-m gauge
(2006)
Roadways:
total: 644,480 km
paved: 644,480 km (includes 12,400 km
of expressways)
note: includes local roads (2006)
Waterways: 7,467 km
note: Rhine River carries most goods;
Main-Danube Canal links North Sea and
Black Sea (2008)
Merchant marine: total: 393
by type: bulk carrier 2, cargo 43, chemical
tanker 13, container 284, liquefied gas 5,
passenger 5, passenger/cargo 27, petro¬
leum tanker 1 1 , roll on/ roll off 3
foreign-owned: 11 (China 2, Cyprus 2,
Denmark 1, Finland 4, Netherlands 1,
Sweden 1)
registered in other countries: 2,998 (Antigua
and Barbuda 941, Australia 2, Bahamas
44, Bermuda 22, Brazil 6, Bulgaria 63,
Burma 1, Canada 3, Cayman Islands 15,
Cyprus 189, Denmark 9, Denmark 1,
Estonia 1, Finland 1, France 1, Georgia
2, Gibraltar 129, Hong Kong 6, India 2,
Indonesia 1, Isle of Man 56, Jamaica 4,
Liberia 849, Luxembourg 5, Malaysia 1,
Malta 91, Marshall Islands 235, Mongolia
4, Morocco 2, Netherlands 75, Netherlands
Antilles 43, Norway 1, NZ 1, Panama 44,
Portugal 20, Russia 1, Saint Vincent and
the Grenadines 3, Singapore 24, Slovakia
3, Spain 5, Sri Lanka 5, Sweden 5, Turkey
1, UK 76, US 5) (2008)
Ports and terminals: Bremen, Bremer-
haven, Duisburg, Hamburg, Karlsruhe,
Lubeck, Rostock, Wilhemshaven
Airports: 11 (2008)
Airports— with paved runways: total: 7
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 2 (2008)
Airports— with unpaved runways: total: 4
914 to 1,523 m: 3
under 914 m: 1 (2008)
Pipelines: oil 5 km; refined products 309
km (2008)
Railways:
total: 953 km
narrow gauge: 953 km 1.067-m gauge
(2006)
Roadways: total: 62,221 km
paved: 9,955 km
unpaved: 52,266 km (2006)
Waterways: 1,293 km
note: 168 km for launches and lighters on
Volta, Ankobra, and Tano rivers; 1,125
km of arterial and feeder waterways on
Lake Volta (2008)
Merchant marine: total: 4
by type : petroleum tanker 1 , refrigerated cargo 3
foreign-owned: 1 (Brazil 1) (2008)
Ports and terminals: Tema','39f4c5f023bd41636dd822e76edb48ecf08c870b984adcc6f1d74d2ab74ac008','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('158ed6e88a44fd2eaec38222016ca68385dceb8c15280df3f9aabc326b8390e2',2010,'GI','Gibraltar','transportation',697,'Airports: 1 (2008)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2008)
Roadways:
total: 29 km
paved: 29 km (2007)
Merchant marine: total: 240
by type: bulk carrier 5, cargo 125, chemical
tanker 51, container 43, passenger 1, petro¬
leum tanker 10, roll on/roll off 5
foreign-owned: 225 (Belgium 2, Cyprus 1,
Denmark 7, Finland 3, Germany 129,
Greece 6, Iceland 1, Morocco 4, Nether¬
lands 21, Norway 33, Sweden 13, UAE 3,
UK 2)
registered in other countries: 7 (Liberia 5,
Panama 1, Saint Vincent and the Gren¬
adines 1) (2008)
Ports and terminals: Gibraltar','93a1a8c2e5950c9f1e9edca7155b8e132c1efa60ac30ed89604c2ef82f2c1693','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28f3d5bab9e7947f1d0d9464a18cb072afcd97b278ad247fc9c1dc8ebb9932f2',2010,'GR','Greece','transportation',706,'Airports: 81 (2008)
Airports — with paved runways: total: 66
over 3,047 m: 5
2,438 to 3,047 m: 15
1,524 to 2,437 m: 20
914 to 1,523 m: 17
under 914 m: 9 (2008)
Airports— with unpaved runways:
total: 15
914 to 1,523 m: 3
under 914 m: 12 (2008)
Heliports: 9 (2007)
Pipelines: gas 1,197 km; oil 75 km
(2008)
Railways: total: 2,571 km
standard gauge: 1,565 km 1.435-m gauge
(764 km electrified)
narrow gauge: 961 km 1.000-m gauge; 22
km 0.750-m gauge
dual gauge: 23 km combined 1.435 m and
1 .000-m gauges (three rail system) (2006)
Roadways: total: 117,533 km
paved: 107,895 km (includes 880 km of
expressways)
unpaved: 9,638 km (2005)
Waterways: 6 km
note: Corinth Canal (6 km) crosses the
Isthmus of Corinth; shortens sea voyage by
325 km (2008)
Merchant marine: total: 869
by type: bulk carrier 260, cargo 66, carrier 1,
chemical tanker 66, combination ore/oil 2,
container 45, liquefied gas 10, passenger 13,
passenger/cargo 115, petroleum tanker 274,
roll on/roll off 15, specialized tanker 2
foreign-owned: 64 (Belgium 16, Cyprus 7,
Turkey 1, UK 32, US 8)
registered in other countries: 2,357 (Antigua
and Barbuda 3, Bahamas 209, Barbados 1 2,
Belize 1, Bermuda 9, Brazil 1, Cambodia
3, Cayman Islands 16, China 2, Comoros
6, Cyprus 259, Denmark 4, Dominica 10,
Egypt 8, Georgia 5, Gibraltar 6, Honduras
4, Hong Kong 22, Isle of Man 50, Italy
6, Jamaica 6, North Korea 1, Lebanon
2, Liberia 358, Maldives i, Malta 452,
Marshall Islands 269, Norway 3, Panama
510, Philippines 4, Portugal 4, Russia 1,
Saint Kitts and Nevis 3, Saint Vincent
and the Grenadines 71, Sao Tome and
Principe 1, Saudi Arabia 3, Sierra Leone 1,
Singapore 15, Slovakia 2, Turkey 1, UAE
3, Uruguay 1, Vanuatu 1, Venezuela 3,
unknown 5) (2008)
Ports and terminals: Agioitheodoroi,
Aspropyrgos, Pachi, Piraeus, Thessaloniki
Airports: 1 (2008)
Airports— with paved runways: total: 1
over 3,047 m: 1 (2008)
Heliports: l (2007)
Roadways: total: 384 km
paved: 384 km (2006)
Ports and terminals: Macau
Airports: 17 (2008)
Airports — with paved runways: total 10
2,438 to 3,047 m: 2
under 914 m: 8 (2008)','25faa95d7a6f56f0f8d7b160f251216c38ab8ef322a76ac646af4db642ed4a68','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a255bd322385b07e9271767bad00073d6b5dd74a646df5820c3bd2f9aebffa6',2010,'GL','Greenland','transportation',712,'Airports: 15 (2008)
Airports — with paved runways:
total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 6 (2008)
Airports— with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2008)
Roadways: note: although there are short
roads in towns, there are no roads between
towns; inter-urban transport takes place
either by sea or air (2005)
Merchant marine: total. 2
by type: cargo 1, passenger 1 (2008)
Ports and terminals: Sisimiut','c8c0b44f664916f7326880c776712cf94188fc872c162863e3082924715fd76f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b786538aeb7f96648bb8f461fa50a4a556029c6a7db2d5de2b9816d63b7f2119',2010,'GU','Guam','transportation',722,'Airports: 3 (2008)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2008)
Roadways:
total: 1,127 km
paved: 687 km
unpaved: 440 km (2000)
Ports and terminals: Saint George’s','59402075e34b9773993fd06ad8e495ee89fce79b53056b27ca0311fd6b975905','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be99b3854cbfc37726cfc87c789749b23059163c62e773b9f3b15984f1e173ef',2010,'GT','Guatemala','transportation',730,'Airports: 5; note— 2 serviceable (2008)
Airports— with paved runways: total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1— closed
914 to 1,523 m: 1— closed (2008)
Airports — with unpaved runways: total: 1
under 914 m: 1 (2008)
Roadways: total: 1,045 km (2007)
Ports and terminals: Apra Harbor
Airports: 374 (2008)
Airports— with paved runways: total: 12
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 3 (2008)
Airports — with unpaved runways:
total: 362
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 86
under 914 m: 270 (2008)
Pipelines: oil 480 km (2008)
Railways: total: 886 km
narrow gauge: 886 km 0.91 4-m gauge
(2006)
Roadways: total: 14,095 km
paved: 4,863 km (includes 75 km of
expressways)
unpaved: 9,232 km (2000)
Waterways: 990 km
note: 260 km navigable year round; addi¬
tional 7 30 km navigable during high-water
season (2007)
Ports and terminals: Puerto Quetzal,
Santo Tomas de Castilla','d3ead93da1d31ddd5a78ea075a95c60c833936c233d88f82419d4ea4dbed0e09','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('260e36911e86ccf93886e46f3356565ba133753985b193bcda8208a82ca7154b',2010,'GG','Guernsey','transportation',742,'Airports: 2 (2008)
Airports— with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Ports and terminals: Saint Peter Port,
Saint Sampson','afff7eb80663995849a27d11b650a03d15aa43e77ebe274730eb10d406004ddb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16a0e0ec3ee8e164ec75c779a9e563006e4088ddc7265cc9c9690efd52bebb78',2010,'GN','Guinea','transportation',747,'Airports: 1 7 (2008)
Airports— with paved runways: total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2008)
Airports — with unpaved runways:
total: 12
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 2 (2008)
Railways: total: 837 km
standard gauge: 175 km 1.435-m gauge
narrow gauge: 662 km 1 .000-m gauge
(2006)
Roadways: total: 44,348 km
paved: 4,342 km
unpaved: 40,006 km (2003)
Waterways: 1,300 km (navigable by
shallow-draft native craft) (2008)
Ports and terminals: Conakry, Kamsar','0bb5b7c6c9f3fda38920c00217367d8c28dc47c224328a3cf9f8fcd6f23eba66','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c424c7a8ae778cbb41e21d54cca4cac54d6a38941e57b69168705226bbc0749d',2010,'GW','Guinea-Bissau','transportation',756,'Airports: 9 (2008)
Airports — with paved runways: total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Airports — with unpaved runways: total: 7
1,524 to 2,437 m: 1
944 to 1,523 rn: 3
under 914 m: 3 (2008)
Roadways: total: 3,455 km
paved: 965 km
unpaved: 2,490 km (2002)
Waterways: rivers are navigable for some
distance; many inlets and creeks give shallow-
water access to much of interior (2008)
Ports and terminals: Bissau, Buba,
Cacheu, Farim','0e547c771336744d7ec14f3ee005f03f88bbad790adb9f645c38d9629dd892c8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cec23ed7343815edf7d192b2f7b3fca7a592c79a9a80a15b371d2bb8ece10c5',2010,'GY','Guyana','transportation',764,'Airports: 96 (2008)
Airports— with paved runways:
total: 10
1,524 to 2,437 m: 3
under 914 m: 7 (2008)
Airports— with unpaved runways:
total: 86
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 71 (2008)
Roadways:
total: 7,970 km
paved: 590 km
unpaved: 7,380 km (2000)
Waterways: 330 km
note: Berbice, Demerara, and Esse-
quibo rivers are navigable by oceangoing
vessels for 150 km, 100 km, and 80 km
respectively (2008)
Merchant marine:
total: 8
by type: cargo 6, petroleum tanker 1 , refrig¬
erated cargo 1
registered in other countries: 3 (Saint Vincent
and the Grenadines 2, unknown 1) (2008)
Ports and terminals: Georgetown','1b19ccf7b972310e7d96c0d44836879c59acfeec6af47349f07877d987d5deb5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da6ee33695c67889f3432be50bb74d3b63fb32a77a98b3e1936781dd8648e341',2010,'HN','Honduras','transportation',784,'Airports: 108 (2008)
Airports — with paved runways: total: 1 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 3 (2008)
Airports — with unpaved runways:
total: 96
1,524 to 2,437 m: 2
914 to 1,523 m: 17
under 914 m: 77 (2008)
Railways: total 699 km
narrow gauge: 279 km 1.067-m gauge; 420
km 0.91 4-m gauge (2006)
Roadways: total 1 3,600 km
paved: 2,775 km
unpaved: 10,825 km (2000)
Waterways: 465 km (most navigable only
by small craft) (2008)
Merchant marine: total 123
by type: bulk carrier 10, cargo 57, chemical
tanker 6, container 1 , liquefied gas 1 ,
passenger 4, passenger/cargo 7, petroleum
tanker 25, refrigerated cargo 7, roll on/roll
off 4, specialized tanker 1
foreignowned: 42 (Bangladesh 1 , Canada
1, China 3, Egypt 3, Greece 4, Hong
Kong 1 , Israel 1 , Japan 4, South Korea
6, Lebanon 1, Mexico 1, Singapore 12,
Taiwan 2, Tanzania 1, Vietnam 1) (2008)
Ports and terminals: La Ceiba, Puerto
Cortes, San Lorenzo, Tela','a0385da90961f870e093251cd3f923e4ee392d4f2f84f8231170a596f7df3f34','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e59d4910ca25fe5d6ad72d698b4822ba5273480fd29418d09a208a101f21aca',2010,'HK','Hong Kong','transportation',793,'Airports: 2 (2008)
Airports — with paved runways: total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Heliports: 5 (2007)
Roadways: total: 2,009 km
paved: 2,009 km (2007)
Merchant marine: total: 1,114
by type: barge carrier 2, bulk carrier 525,
cargo 142, carrier 3, chemical tanker 68,
combination ore/oil 2, container 205,
liquefied gas 22, passenger 6, passenger/
cargo 5, petroleum tanker 114, roll on/roll
off 4, specialized tanker 9, vehicle carrier 7
foreign-owned: 703 (Belgium 3, Canada
44, China 324, Denmark 24, France
1, Germany 6, Greece 22, Indonesia
7, Iran 15, Japan 111, South Korea
3, Norway 40, Philippines 1, Portugal
1, Russia 2, Singapore 18, Syria 1,
Taiwan 11, UAE 1, UK 39, US 29)
registered in other countries: 357 (Bahamas
30, Bermuda 4, Cambodia 8, China 12,
Cyprus 2, Georgia 2, Honduras 1, India 1,
Jamaica 1, Kiribati 4, Liberia 44, Malaysia
14, Malta 1, Marshall Islands 4, Mexico
1, Netherlands Antilles 2, Norway 20,
Panama 130, Philippines 1, Portugal 2,
Saint Vincent and the Grenadines 6,
Seychelles 1, Sierra Leone 1, Singapore 47,
Tuvalu 7, UK 2, Vietnam 1, unknown 8)
(2008)
Ports and terminals: Hong Kong','08867b572abda7f345b9c75f97e7e9478dc229fdb3d80864ba06b5e07a8d232e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d70fc25480143ad98efe7355c32860420481f2b73fade3ae4d67bd3bb7b8b736',2010,'HU','Hungary','transportation',801,'Airports: 46 (2008)
Airports— with paved runways: total: 20
over 3,047 m: 2
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 2 (2008)
Airports — with unpaved runways:
total: 26
311
THE CIA WORLD FACTBOOK
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 11
under 914 m: 10 (2008)
Heliports: 5 (2007)
Pipelines: gas 4,407 km; oil 987 km;
refined products 335 km (2008)
Railways: total: 8,057 km
broad gauge: 36 km 1.524-m gauge
standard gauge: 7,802 km 1.435-m gauge
(2,628 km electrified)
narrow gauge: 219 km 0.760-m gauge
(2006)
Roadways: total: 159,568 km
paved: 70,050 km (30,874 km of interurban
roads including 626 km of expressways)
unpaved: 89,518 km (2005)
Waterways: 1,622 km (most on Danube
River) (2008)
Ports and terminals: Budapest, Dunauj-
varos, Gyor-Gonyu, Csepel, Baja, Mohacs
(2003)','87f7161e55f8ff0504db0c5a795dd170573b18c83518a3c8627c1c0f077b8cfc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6019d72d6ecbafb6d916fa09eef4bc0987a7e02f40eebfc762d35c78cd2fb46f',2010,'IS','Iceland','transportation',810,'Airports: 99 (2008)
Airports — with paved runways: total: 6
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 2 (2008)
Airports— with unpaved runways: total: 93
1,524 to 2,437 m: 3
914 to 1,523 m: 27
under 914 m: 63 (2008)
Roadways: total: 13,058 km
paved/oiled gravel: 4,397 km (does not
include urban roads)
unpaved: 8,661 km (2007)
Merchant marine: total: 2
by type: passenger/cargo 2
registered in other countries: 37 (Antigua
and Barbuda 12, Bahamas 1, Belize 2,
Denmark 2, Faroe Islands 1, Gibraltar
1, Malta 5, Marshall Islands 3, Norway
3, Saint Vincent and the Grenadines 7)
(2008)
Ports and terminals: Grundartangi,
Flafnarfjordur, Reykjavik','fb6afa53c9610c82cf4c18f1c147626dbbf24103ac54044ee0b556e1404c0b6c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cb7aebc51494c7a74d490f6c48872b7ff9972187fc151439cce1374f6a7d9ef',2010,'IN','India','transportation',818,'Airports: 345 (2008)
Airports— with paved runways: total: 251
over 3,047 m: 19
2,438 to 3,047 m: 55
1,524 to 2,437 m: 77
914 to 1,523 m: 84
under 914 m: 16 (2008)
Airports— with unpaved runways: total: 94
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 rn: 39
under 914 m: 47 (2008)
Heliports: 30 (2007)
Pipelines: condensate/gas 2 km; gas
6,061 km; liquid petroleum gas 2,156 km;
oil 7,678 km; refined products 6,876 km
(2008)
Railways: total: 63,221 km
broad gauge: 46,807 km 1.676-m gauge
(17,343 km electrified)
narrow gauge: 13,290 km 1.000-m gauge
(165 km electrified); 3,124 km 0.762-m
gauge and 0.61 0-m gauge (2006)
Roadways: total: 3,316,452 km (includes
200 km of expressways) (2006)
Waterways: 14,500 km
note: 5,200 km on major rivers and 485
km on canals suitable for mechanized
vessels (2008)
Merchant marine: total: 501
by type: bulk carrier 102, cargo 241, carrier
1, chemical tanker 19, container 13, lique¬
fied gas 18, passenger 3, passenger/cargo
11, petroleum tanker 92, roll on/roll off 1
foreign-owned: 12 (China 1, Germany 2,
Hong Kong 1, UAE 6, UK 2)
registered in other countries: 61 (Barbados 1,
Comoros 2, Cyprus 2, Dominica 2, Liberia
2, Malta 2, Marshall Islands 1, Panama 27,
Saint Kitts and Nevis 1 , Saint Vincent and
the Grenadines 7, Singapore 13, unknown
1) (2008)
Ports and terminals: Chennai, Haldia,
Jawaharal Nehru, Kandla, Kolkata
(Calcutta), Mormugao, Mumbai (Bombay),
New Mangalore, Vishakhapatnam','3fb5313a0f27de1c42510bdb707a0ec0ea754fac24c9d49a6a4499372003b7bd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe0e8ed62e658094642e9b0d610640cbb40297b29105386276cb7a28769ec0ac',2010,'ID','Indonesia','transportation',821,'Ports and terminals: Chennai (Madras;
India), Colombo (Sri Lanka), Durban
(South Africa), Jakarta (Indonesia), Kolkata
(Calcutta; India) Melbourne (Australia),
Mumbai (Bombay; India), Richards Bay
(South Africa)
Transportation— note: the International
Maritime Bureau reports the territorial
waters of littoral states and offshore waters
as high risk for piracy and armed robbery
against ships, particularly in the Gulf of
Aden, along the east coast of Africa, the
Bay of Bengal, and the Strait of Malacca;
numerous vessels, including commercial
shipping and pleasure craft, have been
attacked and hijacked both at anchor
and while underway; hijacked vessels are
often disguised and cargoes stolen; crew
and passengers are often held for ransom,
murdered, or cast adrift
Airports: 669 (2008)
Airports— with paved runways: total: 163
over 3,047 m: 4
2,438 to 3,047 m: 17
1,524 to 2,437 m: 52
914 to 1,523 m: 54
under 914 m: 36 (2008)
Airports— with unpaved runways:
total: 506
1,524 to 2,437 m: 5
914 to 1,523 m: 26
under 914 m: 475 (2008)
Heliports: 17 (2007)
Pipelines: condensate 735 km; conden¬
sate/gas 73 km; gas 5,797 km; oil 5,721
km; oil/gas/water 12 km; refined products
1,370 km; water 44 km (2008)
Railways: total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge
(125 km electrified); 497 km 0.750-m
gauge (2006)
Roadways: total: 391,009 km
paved: 216,714 km
unpaved: 174,295 km (2005)
Waterways: 21,579 km (2008)
Merchant marine: total: 971
by type: bulk carrier 54, cargo 514, chemical
tanker 35, container 80, liquefied gas 7,
passenger 44, passenger/cargo 68, petro¬
leum tanker 143, refrigerated cargo 2,
roll on/roll off 10, specialized tanker 10,
vehicle carrier 4
foreign-owned: 43 (China 2, France 1,
Germany 1 , Japan 6, Norway 1 , Philippines
324
I RAN
1, Singapore 27, Taiwan 2, UAE 2)
registered in other countries: 114 (Bahamas
2, Cambodia 2, China 1, Hong Kong 7,
Liberia 2, Mongolia 1, Panama 31, Singa¬
pore 66, unknown 2) (2008)
Ports and terminals: Banjarmasin,
Belawan, Ciwandan, Kotabaru, Krueg
Geukueh, Palembang, Panjang, Sungai
Pakning, Tanjung Perak, Tanjung Priok
Transportation— note: the International
Maritime Bureau reports the territorial and
offshore waters in the Strait of Malacca
and South China Sea as high risk for
piracy and armed robbery against ships;
numerous commercial vessels have been
attacked and hijacked both at anchor and
while underway; hijacked vessels are often
disguised and cargo diverted to ports in
East Asia; crews have been murdered or
cast adrift
Airports: 317 (2008)
Airports— with paved runways: total. 130
over 3,047 m: 40
2,438 to 3,047 m: 29
1,524 to 2,437 m: 23
914 to 1,523 m: 32
under 914 m: 6 (2008)
Airports — with unpaved runways:
total: 187
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 144
under 914 m: 31 (2008)
Heliports: 14 (2007)
Pipelines: condensate 7 km; condensate/
gas 12 km; gas 19,246 km; liquid petro¬
leum gas 570 km; oil 7,018 km; refined
products 7,936 km (2008)
Railways: total: 8,367 km
broad gauge: 94 km 1.676-m gauge
standard gauge: 8,273 km 1.435-m gauge
(146 km electrified) (2006)
Roadways: total: 172,927 km
paved: 1 25,908 km (includes 1 ,429 km of
expressways)
unpaved: 47,019 km (2006)','ccd644942bb69afdf09b8e548aec8a09b574834aa1681d1740a86944f831af2f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('868892b814eadecb7317e74f18b00eec8b6a28cf7d0643b5811c2aebbb3bfd46',2010,'IE','Ireland','transportation',833,'Airports: 105 (2008)
Airports— with paved runways: total: 75
over 3,047 m: 19
2,438 to 3,047 m: 37
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 8 (2008)
Airports— with unpaved runways: total: 30
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 rn: 13
under 914 m: 6 (2008)
Heliports: 17 (2007)
Pipelines: gas 2,501 km; liquid petroleum
gas 918 km; oil 5,418 km; refined products
1,637 km (2008)
Railways: total: 2,272 km
standard gauge: 2,272 km 1.435-m gauge
(2006)
Roadways:
total: 44,900 km
paved: 37,851 km
unpaved: 7,049 km (2002)
Waterways: 5,279 km
note: Euphrates River (2,815 km), Tigris
River (1,899 km), and Third River (565
km) are principal waterways (2008)
Merchant marine: total: 14
by type: cargo 10, petroleum tanker 4 (2008)
Ports and terminals: A1 Basrah, Khawr az
Zubayr, Umm Qasr
Airports: 37 (2008)
Airports — with paved runways: total: 17
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m: 6 (2008)
Airports — with unpaved runways: total: 20
914 to 1,523 m: 2
under 914 m: 18 (2008)
Pipelines: gas 1,550 km (2008)
Railways: total: 3,237 km
broad gauge: 1,872 km 1.600-m gauge (37
km electrified)
narrow gauge: 1,365 km 0.91 4-m gauge
(operated by the Irish Peat Board to
transport peat to power stations and
briquetting plants) (2006)
Roadways: total: 96,602 km
paved: 96,602 km (includes 200 km of
expressways) (2003)
Waterways: 956 km (pleasure craft only)
(2008)
Merchant marine: total: 29
by type: cargo 25, chemical tanker 2,
container 1 , roll on/ roll off 1
foreign-owned: 2 (US 2)
registered in other countries: 21 (Bahamas 2,
Bermuda 1 , Bulgaria 1 , Cyprus 3, Isle of
Man 1 , Marshall Islands 1 , Netherlands
10, Slovakia 1, UK 1) (2008)
Ports and terminals: Cork, Dublin,
Shannon Foynes','973678f837e88dc7ff70f936fb3b6c4afa70e1017008a4325be5444a2a1b5209','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6055c0ab1beff3f28d071ad096168966c31a45bb548abe163bbf312716c57f27',2010,'IM','Isle of Man','transportation',844,'Airports: 1 (2008)
Airports— with paved runways:
total: 1
1,524 to 2,437 m: 1 (2008)
Railways: total: 65 km
standard gauge: 7 km 1.067-m gauge (7 km
electrified)
narrow gauge: 58 km 0.91 4-m gauge (29
km electrified)
note: primarily summer tourist attractions
(2006)
Roadways: total: 500 km (2008)
Merchant marine: total: 273
by type: bulk carrier 31, cargo 50, chemical
tanker 48, container 12, liquefied gas 41,
passenger/cargo 1, petroleum tanker 73,
refrigerated cargo 4, roll on/roll off 8,
vehicle carrier 5
foreign-owned: 181 (Chile 6, Denmark 29,
France 1 , Germany 56, Greece 50, Ireland 1 ,
Japan 6, Monaco 3, Netherlands 1 , Norway
20, Singapore 1 , Sweden 1 , Turkey 2, US 4)
registered in other countries: 7 (Bahamas 1,
Liberia 5, Marshall Islands 1) (2008)
Ports and terminals: Douglas, Ramsey','1ac2890eb75aab1abb739f5c1c5956d2fab081225bcb85dbfc67edcbd50ae425','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed568c9f2cad3302e788e485ecc47281a3962a2e33550a9c3481bc3cdcadc20d',2010,'IL','Israel','transportation',853,'Airports: 47 (2008)
Airports — with paved runways:
total: 30
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 7
914 to 1,523 m: 10
under 914 m: 6 (2008)
Airports — with unpaved runways:
total: 17
1,524 to 2,437 m: 1
341
THE CIA WORLD FACTBOOK
914 to 1,523 m: 2
under 914 m: 14 (2008)
Heliports: 3 (2007)
Pipelines: gas 1 76 km; oil 442 km; refined
products 261 km (2008)
Railways: total: 853 km
standard gauge: 853 km 1.435-m gauge
(2006)
Roadways:
total: 1 7,870 km
paved: 17,870 km (includes 146 km of
expressways) (2007)
Merchant marine: total: 1 1
by type: cargo 2, container 9
registered in other countries: 60 (Bermuda 3,
Cyprus 4, Georgia 2, Honduras 1, Liberia
23, Malta 18, Panama 3, Saint Vincent
and the Grenadines 2, Slovakia 4) (2008)
Ports and terminals: Ashdod, Elat (Eilat),
Hadera, Haifa','1a912ff143c22807967e1c3c6584612ea4fe9ff940384accb1c3421803621364','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed8a6d1bd29e19e8f009f702c78edaa2409c7160ba1d3f8455f1502f00a67c33',2010,'JM','Jamaica','transportation',861,'Airports: 27 (2008)
Airports — with paved runways: total: 12
2,438 to 3,047 m: 2
914 to 1,523 m: 3
under 914 m: 7 (2008)
Airports — with unpaved runways: total. 1 5
under 914 m: 15 (2008)
Roadways: total: 21,552 km
paved: 15,937 km (includes 33 km of
expressways)
unpaved: 5,615 km (2005)
Merchant marine: total 20
by type: bulk carrier 6, cargo 6, carrier 1 ,
container 4, roll on/roll off 3
foreign-owned : 17 (Denmark 2, Germany 4,
Greece 6, Hong Kong 1 , Latvia 1 , Russia
3) (2008)
Ports and terminals: Kingston, Port
Esquivel, Port Kaiser, Port Rhoades, Rocky
Point
Airports: 1 (2008)
Airports— with unpaved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Ports and terminals: none; offshore
anchorage only','20f5c6f5ec76307c33247d282ba453679ac22fb11acf06ed8c31882794a23691','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b29fb23b877f35ee6344115066f1ba5be7582a184fb29b8174b5e895883d2a27',2010,'JP','Japan','transportation',872,'Airports: 175 (2008)
Airports — with paved runways:
total: 144
over 3,047 m: 7
2,438 to 3,047 m: 41
1,524 to 2,437 m: 40
914 to 1,523 m: 28
under 914 m: 28 (2008)
Airports — with unpaved runways:
total: 31
914 to 1,523 m: 4
under 914 m: 27 (2008)
Heliports: 14 (2007)
Pipelines: gas 3,862 km; oil 167 km; oil/
gas/water 53 km (2008)
Railways: total: 23,474 km
standard gauge: 3,204 km 1.435-m gauge
(3,204 km electrified)
narrow gauge: 77 km 1.372-m gauge (77
km electrified); 20,182 km 1.067-m gauge
(13,334 km electrified); 11 km 0.762-m
gauge (1 1 km electrified) (2006)
Roadways: total: 1,196,999 km
paved: 949,101 km (includes 7,383 km of
expressways)
unpaved: 247,898 km (2006)
Waterways: 1,770 km (seagoing vessels
use inland seas) (2007)
Merchant marine: total: 683
by type: bulk carrier 136, cargo 30, carrier 3,
chemical tanker 27, container 11, liquefied
gas 59, passenger 12, passenger/cargo 135,
petroleum tanker 156, refrigerated cargo 2,
roll on/roll off 51, vehicle carrier 61
registered in other countries: 3,074
(Australia 1, Bahamas 87, Belize 8,
Bermuda 2, Burma 1, Cambodia 1,
Cayman Islands 13, China 2, Cyprus
21, France 1, Honduras 4, Hong Kong
111, Indonesia 6, Isle of Man 6, Italy 1 ,
South Korea 20, Liberia 116, Malaysia 4,
Malta 8, Marshall Islands 17, Nigeria 1,
352','041078cdfe64a23112973de6b6a10ace57fdaca03008930890472ca5fc4f402e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19c78c9938fe7c7ebcf02a69941fc0c22c05d20f27668411b7c52de2819ce1ef',2010,'JE','Jersey','transportation',873,'Norway 29, Panama 2335, Philippines 81,
Portugal 15, Saint Kitts and Nevis 3, Saint
Vincent and the Grenadines 3, Singapore
1 31 , Thailand 4, UK 4, US 7, Vanuatu 29,
Vietnam 1, unknown 1) (2008)
Ports and terminals: Chiba, Kawasaki,
Kobe, Mizushima, Moji, Nagoya, Osaka,
Tokyo, Tomakomai, Yohohama','d3a677b8a7b0eb10083545ac4bd86528b1786e3d8cf8c9c28d84166d91a34081','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f3671c429b4c7a71c9f424beb787dc1004e24b77a0ac7bb678d6819588cd675',2010,'JO','Jordan','transportation',882,'Airports: 1 (2008)
Airports — with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total: 358 km (2002)
Ports and terminals: Gorey, Saint Aubin,
Saint Helier
Airports: 17 (2008)
Airports— with paved runways: total: 1 5
over 3,047 m: 7
THE CIA WORLD FACTBOOK
2,438 to 3,047 m: 6
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 2
under 914 m: 2 (2008)
Heliports: 1 (2007)
Pipelines: gas 439 km; oil 49 km (2008)
Railways: total: 505 km
narrow gauge: 505 km 1 .050-m gauge (2006)
Roadways: total: 7,694 km
paved: 7,694 km (2006)
Merchant marine: total: 21
by type: cargo 8, container 1, passenger/
cargo 7, petroleum tanker 2, roll on/roll
off 3
foreign-owned: 1 3 (UAE 1 3)
registered in other countries: 24 (Algeria 7,
Bahamas 2, Panama 13, Syria 2) (2008)
Ports and terminals: A1 Aqabah','c53582b20f84f0299cc47b47f4d2ff054db7b3193e09bd9c67e8a7d0a6163932','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0859f21e3179dfafb6dc71c88b5ec74996758dd13d18ee0aafaf537d6fca9a04',2010,'KZ','Kazakhstan','transportation',897,'Airports: 95 (2008)
Airports— with paved runways: total: 64
over 3,047 m: 10
2,438 to 3,047 m: 26
1,524 to 2,437 m: 16
914 to 1,523 m: 4
under 914 m: 8 (2008)
Airports— with unpaved runways: total: 31
over 3,047 m: 5
2,438 to 3,047 m: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 13 (2008)
Heliports: 5 (2007)
Pipelines: condensate 658 km; gas 11,146
km; oil 10,376 km; refined products 1,095
km; water 1 ,465 km (2008)
Railways: total: 13,700 km
broad gauge: 13,700 km 1.520-m gauge
(3,700 km electrified) (2006)
Roadways:
total: 91,563 km
paved: 83,717 km
unpaved: 7,846 km (2006)
Waterways: 4,000 km (on the Ertis
((Irtysh)) River (80%) and Syr Darya ((Syrd-
ariya)) River) (2008)
Merchant marine: total: 5
by type: petroleum tanker 4, refrigerated
cargo 1 (2008)
Ports and terminals: Aqtau (Shevchenko),
Atyrau (Guryev), Oskemen (Ust-Kame¬
nogorsk), Pavlodar, Semey (Semipalatinsk)','ac19e2b773b8a8e858f9c63c715dd7580808c9cb6d67a08589c26f07c81e54b6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b972611c114028f95e3ad5cbbbe51194325d69e623daeab2b74560d290293a3',2010,'KE','Kenya','transportation',905,'Airports: 180 (2008)
Airports— with paved runways:
total: 16
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 6
under 914 m: 1 (2008)
Airports— with unpaved runways:
total: 164
1,524 to 2,437 m: 10
914 w 1,523 rn: 105
under 914 m: 49 (2008)
Pipelines: oil 4 km; refined products 928
km (2008)
Railways: total: 2,778 km
narrow gauge: 2,778 km 1.000-m gauge
(2006)
Roadways:
total: 63,265 km (interurban roads)
paved: 8,933 km
unpaved: 54,332 km
note: there also are 100,000 km of rural
roads and 14,500 km of urban roads for a
national total of 177,765 km (2004)
Waterways: part of Lake Victoria system is
within boundaries of Kenya (2007)
Merchant marine:
total: 1
by type: petroleum tanker 1
registered in other countries: 6 (Bahamas 1,
Comoros 1, Saint Vincent and the Gren¬
adines 2, Tuvalu 1, unknown 1) (2008)
Ports and terminals: Mombasa
365
THE CIA WORLD FACTBOOK','2bdf43025d5e8810e54fd321251eebb6e07851560a4810b7d1096f80a810fa1f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95b52eca1c1ccdc764c2b22ee3dcef5b6a7aa44d9d2f0a5f94aa786c2200d855',2010,'KI','Kiribati','transportation',913,'Airports: 19 (2008)
Airports — with paved runways: total 4
1,524 to 2,437 m: 4 (2008)
Airports— with unpaved runways:
total: 15
914 to 1,523 m: 11
under 914 m: 4 (2008)
Roadways: total: 670 km (2000)
Waterways: 5 km (small network of canals
ip Line Islands) (2007)
Merchant marine: total 43
by type: bulk carrier 2, cargo 18, chemical
tanker 3, petroleum tanker 6, refrigerated
cargo 14
foreign-owned: 31 (China 15, Hong Kong
4, South Korea 2, Singapore 4, Taiwan 5,
Turkey 1) (2008)
Ports and terminals: Betfo
Airports: 78 (2008)
Airports — with paved runways:
total: 36
over 3,047 m: 2
2,438 to 3,047 m: 22
1,524 to 2,437 m: 8
914 to 1,523 m: 1
under 914 m: 3 (2008)
Airports — with unpaved runways:
total: 42
2,438 to 3,047 m: 3
1,524 to 2,437 m: 17
914 to 1,523 m: 14
under 914 m: 8 (2008)
Heliports: 23 (2007)
Pipelines: oil 154 km (2008)
Railways: total: 5,235 km
standard gauge: 5,235 km 1.435-m gauge
(3,500 km electrified) (2006)
Roadways: total: 25,554 km
paved: 724 km
unpaved: 24,830 km (2006)
Waterways: 2,250 km (most navigable
only by small craft) (2008)
Merchant marine: total: 167
by type: bulk carrier 1 1 , cargo 121, carrier 1 ,
chemical tanker 4, container 3, passenger/
cargo 3, petroleum tanker 19, refrigerated
cargo 4, roll on/roll off 1
foreign-owned: 19 (Egypt 1, Greece 1,
Lebanon 1, Lithuania 1, Romania 4, Syria
1, UAE 8, Yemen 2)
registered in other countries: 2 (Mongolia 1 ,
Panama 1) (2008)
Ports and terminals: Ch’ongjin, Haeju,
Hungnam (Hamhung), Kimch’aek,
Kosong, Najin, Namp’o, Sinuiju, Songnim,
Sonbong (formerly Unggi), Ungsang,
Wonsan
Airports: 113 (2008)
Airports— with paved runways: total: 71
over 3,047 m: 3
2,438 to 3,047 m: 22
1,524 to 2,437 m: 12
914 to 1,523 m: 12
under 914 m: 22 (2008)
Airports — with unpaved runways: total: 42
914 to 1,523 m: 2
under 914 m: 40 (2008)
Heliports: 536 (2007)
Pipelines: gas 1,423 km; refined products
827 km (2008)
Railways: total: 3,381 km
standard gauge : 3,381 km 1 .435-m gauge
(1 ,843 km electrified) (2008)
Roadways:
total: 103,029 km
paved: 80,642 km (includes 3,367 km of
expressways)
unpaved: 22,387 km (2008)
Waterways: 1,608 km (most navigable
only by small craft) (2008)
Merchant marine: total: 812
by type: bulk carrier 212, cargo 226, carrier
2, chemical tanker 133, container 80, lique¬
fied gas 33, passenger 5, passenger/cargo
26, petroleum tanker 61 , refrigerated cargo
1 6, roll on/ roll off 9, specialized tanker 4,
vehicle carrier 5
foreign-owned: 31 (China 1, Japan 20,
Norway 2, UK 1, US 7)
registered in other countries: 363 (Belize 1,
Cambodia 22, China 1 , Cyprus 1 , Honduras
6, Hong Kong 3, Kiribati 2, Liberia 3, Malta
2, Marshall Islands 10, Mongolia 1, Neth¬
erlands 1, Panama 303, Russia 1, Singapore
3, Tuvalu 1, unknown 2) (2008)
Ports and terminals: Inch on, P’ohang,
Pusan, Ulsan
Airports: 10 (2008)
Airports— with paved runways: total: 6
2,438 to 3,047 m: 1
1,524 to 2,431 m: 1
under 914 m: 4 (2008)
Airports— with unpaved runways: total: 4
under 914 m: 4 (2008)
Heliports: 2 (2008)
Railways: total: 430 km
standard gauge: 430 km 1.435-m gauge
(2005)
Roadways: total: 1 ,924 km
paved: 1,666 km
unpaved: 258 km (2006)','ccfc0a073414e99c4cff28712972e91b67bd1b5513f7377321936a24dd4a8734','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb07c57c3871d3aa506838456a29e9072d3146df3aa63415de96510cd33e434',2010,'KW','Kuwait','transportation',922,'Airports: 7 (2008)
Airports— with paved runways: total: 4
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m • 1 (2008)
Airports — with unpaved runways: total 3
1,524 to 2,437 m: 1
under 914 m: 2 (2008)
Heliports: 4 (2007)
Pipelines: gas 269 km; oil 540 km; refined
products 57 km (2008)
Roadways: total: 5, 749 km
paved: 4,887 km
unpaved: 862 km (2004)
Merchant marine: total 38
by type: bulk carrier 2, cargo 1, carrier 3,
container 6, liquefied gas 4, petroleum
tanker 22
registered in other countries: 34 (Bahrain 5,
Comoros 1, Libya 1, Panama 2, Qatar 7,
Saint Kitts and Nevis 1, Saudi Arabia 7,
UAE 10) (2008)
Ports and terminals: Ash Shu’aybah, Ash
Shuwaykh, A z Zawr (Mina* Sa’ud), Mina’
‘Abd Allah, Mina’ al Ahmadi','cad5c40104d83974a42175ac0f531f71fb54618114da46acb5740fb2ac095bd1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d6f867919d2caf9e1c7863afb002299e8c4827df7d01acb1ab79795a63c63cc',2010,'KG','Kyrgyzstan','transportation',931,'Airports: 30 (2008)
Airports— with paved runways: total: 18
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 11
under 914 m: 3 (2008)
Airports— with unpaved runways:
total: 12
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 10 (2008)
Pipelines: gas 254 km; oil 16 km (2008)
Railways: total: 470 km
broad gauge: 470 km 1 .520-m gauge (2006)
Roadways: total: 18,500 km
paved: 16,909 km (includes 140 km of
expressways)
unpaved: 1,591 km (2003)
Waterways: 600 km (2008)
Ports and terminals: Balykchy (Ysyk-Kol
or Rybach’ye)','dfe202e4f8e0a3198a69ab0f06380647e0391ea8f26c227afa946747bc15b75b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('650ee8801847bb0804c9e1973ce4fb63c3f4437184b1ab32b5fa30f18cc7b189',2010,'TH','Thailand','transportation',938,'Airports: 42 (2008)
Airports — with paved runways: total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2008)
Airports — with unpaved runways: total: 32
1,524 to 2,437 m: 1
914 to 1 ,523 m: 9
under 914 m: 22 (2008)
Pipelines:
refined products 540 km (2008)
Roadways: total: 29,811 km
paved: 4,010 km
unpaved: 25,801 km (2006)
Waterways: 4,600 km
note: primarily Mekong and tributaries;
2,900 additional km are intermittently
navigable by craft drawing less than 0.5 m
(2008)
Merchant marine:
total: 1 ship (1000 CRT or over) 2,370
GRT/3,1 10 DWT
by type: cargo 1 (2008)','2139c140bae017f49d691e02219643af0b507ccab86e2222fc6cfc74e03eda95','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b6ce015c4486af2509ec74902048d713fea687567a3dd0b7ea518fe9092f29d',2010,'LV','Latvia','transportation',946,'Airports: 43 (2008)
Airports— with paved runways: total: 20
2,438 to 3,047 m: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 8 (2008)
Airports— with unpaved runways:
total: 23
914 to 1,523 m: 1
under 914 m: 22 (2008)
Pipelines: gas 948 km; refined products
415 km (2008)
Railways: total: 2,303 km
broad gauge: 2,270 km 1.520-m gauge (257
km electrified)
narrow gauge: 33 km 0.750-m gauge (2006)
Roadways:
total: 69,675 km
paved: 69,675 km (2006)
Waterways: 300 km (2007)
Merchant marine: total: 22
by type: cargo 8, chemical tanker 3, lique¬
fied gas 2, passenger/cargo 5, petroleum
tanker 2, roll on/roll off 2
foreign-owned: 2 (Estonia 2)
registered in other countries: 118 (Antigua
and Barbuda 13, Belize 12, Cambodia 1,
Cook Islands 1, Cyprus 1, Dominica 1,
Jamaica 1, Liberia 21, Malta 19, Marshall
Islands 16, Panama 8, Russia 2, Saint Kitts
and Nevis 5, Saint Vincent and the Gren¬
adines 1 7) (2008)
Ports and terminals: Riga, Ventspils','1814b13625ba6bedaca802967b56f97882e858b9f5c21f5ae8bd4a77acba739a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8575eda14dc23b86b2d308476f19e1149789c6a1667d439571a2366c25effac3',2010,'LB','Lebanon','transportation',951,'Airports: 7 (2008)
Airports— with paved runways: total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 2
914 to 1,523 m: 2 (2008)
Pipelines: gas 43 km (2008)
Railways: total: 401 km
standard gauge: 319 km 1.435 m
narrow gauge: 82 km 1 .050 m
note: rail system unusable because of the
damage done during fighting in the 1980s
and in 2006 (2006)
Roadways: total: 6,970 km (includes 170
km of expressways) (2005)
Merchant marine: total. 33
by type: bulk carrier 3, cargo 1 3, carrier 1 1 ,
passenger/ cargo 1 , refrigerated cargo 1 , roll
on/roll off 2, vehicle carrier 2
foreignowned: 4 (Greece 2, Syria 2)
registered in other countries: 55 (Barbados 1,
Cambodia 8, Comoros 4, Cyprus 1, Egypt
1, Georgia 4, Honduras 1, Italy 1, North
Korea 1, Liberia 2, Malta 11, Mongolia 2,
Panama 5, Saint Vincent and the Gren¬
adines 6, Sierra Leone 1, Syria 3, Togo 1,
unknown 2) (2008)
Ports and terminals: Beirut, Tripoli','6faccbba5a650484e2bb76f43fc45024abc4a3d1f64065ed0e1cb7aa6a03e857','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('608fa0de75d20029a07c77ae0faec8dfc28b06ee7af9399da9c8e4b2bbb924a5',2010,'LR','Liberia','transportation',959,'Airports: 28 (2008)
Airports— with paved runways: total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports— with unpaved runways: total: 25
914 to 1,523 m: 4
under 914 m: 21 (2008)
Roadways: total: 7,091 km
paved: 1 ,404 km
unpaved: 5,687 km (2003)
Airports: 52 (2008)
Airports— with paved runways:
total: 2
over 3,047 m: 1
1,524 to 2,437 m : 1 (2008)
Airports — with unpaved runways:
total: 50
1,524 to 2,437 m: 5
914 to 1,523 m: 9
under 914 m: 36 (2008)
Railways: total. 490 km
standard gauge: 345 km 1 .435-m gauge
narrow gauge: 145 km 1.067-m gauge
note: sections of railway are inoperable
because of damage suffered during civil
wars from 1980 to 2003 (2008)
Roadways:
total: 10,600 km
paved: 657 km
unpaved: 9,943 km (2000)
Merchant marine: total 2,204
by type: barge carrier 3, bulk carrier 390,
cargo 107, chemical tanker 241, combina¬
tion ore/oil 7, container 750, liquefied gas
84, passenger 1, passenger/cargo 3, petro¬
leum tanker 460, refrigerated cargo 103,
roll on/roll off 7, specialized tanker 12,
vehicle carrier 36
foreign-owned: 2,109 (Argentina 3, Belgium
4, Brazil 3, Canada 7, China 11, Croatia 2,
Cyprus 63, Denmark 1 2, Estonia 1 , France
5, Germany 849, Gibraltar 5, Greece 358,
Hong Kong 44, India 2, Indonesia 2,
Isle of Man 5, Israel 23, Italy 41, Japarp
116, South Korea 3, Latvia 21, Lebanon
2, Mexico 2, Monaco 8, Netherlands 6,
Nigeria 2, Norway 40, Poland 13, Qatar
4, Romania 2, Russia 94, Saudi Arabia
27, Singapore 32, Slovenia 3, Sweden
10, Switzerland 13, Taiwan 91, Turkey
7, Ukraine 25, UAE 23, UK 20, US 98,
Uruguay 3, Vietnam 4) (2008)
Ports and terminals: Buchanan,
Monrovia','f8fc74c8fd9a488fd567a5fccdb9d5135dd9d8ab2ae3f046afdf228796059db8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfe25e587c61d1f56d3ba8c1996cccf203e9cb82f4ecce3836ab0f551b0cdd26',2010,'LY','Libya','transportation',970,'Airports: 140 (2008)
Airports— with paved runways: total: 58
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2,437 m: 22
914 to 1,523 m: 6
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 82
over 3,047 m: 5
2,438 to 3,047 m: 1
1,524 to 2,437 m: 16
914 to 1,523 m: 41
under 914 m: 19 (2008)
Heliports: 2 (2007)
Pipelines: condensate 776 km; gas 2,860
km; oil 6,987 km (2008)
Railways: 0 km
note: Libya plans to build seven lines
totaling 2,757 km of 1.435-m gauge track
(2006)
Roadways: total: 100,024 km
paved: 57,214 km
unpaved: 42,810 km (2003)
Merchant marine: total: 17
by type: cargo 9, liquefied gas 3, petroleum
tanker 4, roll on/roll off 1
foreign-owned: 4 (Kuwait 1 , Norway 1 , Syria 2)
registered in other countries: 3 (Malta 3)
(2008)
Ports and terminals: As Sidrah, Az
Zuwaytinah, Marsa al Burayqah, Ra’s
Lanuf, Tripoli, Zawiyah
403
THE CIA WORLD FACTBOOK','c2b9a971e1af7daf1c67d029dbb666589fe2046ca829bb30337205ed3b7265d0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19c8d342b4d9aff1163c1ff77512ccec577309734fc2c3db5d5397336e6bcefa',2010,'LI','Liechtenstein','transportation',978,'Pipelines: gas 20 km (2008)
Railways: 9 km 1.435-m gauge (electrified)
note: belongs to the Austrian Railway
System connecting Austria and Switzerland
(2006)
Roadways: total: 380 km
paved: 380 km (2007)
Waterways: 28 km (2008)','057063cefd078f5dfadfab1f3f92fe26cf3e3fa794c1dcc54ae257db990108ec','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9aa8d864e3581cdb980ebc2f939e9afa38ee7f85f988de8cfd5b7ca71c5ff67',2010,'LU','Luxembourg','transportation',986,'Airports: 87 (2008)
Airports — with paved runways: total: 31
over 3,047 m: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 2
under 914 m: 18 (2008)
Airports— with unpaved runways: total: 56
over 3,047 m: 1
914 to 1,523 m: 3
under 914 m: 52 (2008)
Pipelines: gas 1,695 km; refined products
114 km (2008)
Railways: total: 1,771 km
broad gauge: 1,749 km 1.524-m
gauge (122 km electrified)
standard gauge: 22 km 1 .435-m gauge (2006)
Roadways: total: 80,715 km
paved: 71,301 km (includes 309 km of
expressways)
unpaved: 9,414 km (2007)
Waterways: 441 km (2007)
Merchant marine: total: 45
by type: cargo 23, container 2, passenger/
cargo 6, petroleum tanker 1, refrigerated
cargo 13
foreign-ovuned: 6 (Denmark 5, Ukraine 1)
registered in other countries: 28 (Antigua and
Barbuda 5, Cook Islands 1, North Korea 1,
Malta 1 , Norway 1 , Panama 7, Saint Vincent
and the Grenadines 9, unknown 3) (2008)
Ports and terminals: Klaipeda
Airports: 2 (2008)
Airports — with paved runways: total: 1
over 3,047 m: 1 (2008)
Airports — with unpaved runways:
total: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Pipelines: gas 155 km (2008)
Railways: total: 275 km
standard gauge: 275 km 1.435-m gauge
(243 km electrified) (2006)
Roadways: total: 5,227 km
paved: 5,227 km (includes 147 km of
expressways) (2004)
Waterways: 37 km (on Moselle River)
(2008)
Merchant marine: total: 45
by type: bulk carrier 6, cargo 3, chemical
tanker 15, container 4, liquefied gas 1,
passenger 3, passenger/cargo 1, petroleum
tanker 3, roll on/roll off 9
foreign-owned: 44 (Belgium 7, Denmark
1, France 17, Germany 5, Netherlands 2,
UK 8, US 4)
registered in other countries: 1 (Ukraine 1)
(2008)
Ports and terminals: Mertert','ed85d32c96e0ac1ea43c808f6f6687801e6832752f99d0f894e080546522d00f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d4ccda8fd6e5c399e9851eb57d3e13385a90f7fc12419a9ef65eddcfcd53c75',2010,'MG','Madagascar','transportation',992,'colony in 1896 but regained independence
in 1960. From 1992 to 1993, free presiden¬
tial and National Assembly elections were
held ending 17 years of single-party rule.
Airports— with unpaved runways: total 7
914 to 1,523 m: 3
under 914 m: 4 (2008)
Pipelines: gas 268 km; oil 120 km (2008)
Railways: total 699 km
standard gauge: 699 km 1 .435-m gauge
(223 km electrified) (2006)
Roadways: total: 13,182 km (includes 208
km of expressways) (2002)','58fd4b63b3be68d5a423abf627b244d769fa80b693b492e128c0398ac7e257d2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6b5bd014968056ffdc21cc91d37ebe9e2477fda10bc0ba6da1d20531f9706da',2010,'MW','Malawi','transportation',1001,'Airports: 90 (2008)
Airports— with paved runways: total: 27
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 17
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 63
1,524 to 2,437 m: 2
914 to 1,523 m: 39
under 914 m: 22 (2008)
Railways:
total: 854 km
narrow gauge: 854 km 1 .000-m gauge (2006)
Roadways:
total: 65,663 km
paved: 7,617 km
unpaved: 58,046 km (2003)
Waterways: 600 km
note: 432 km navigable (2008)
Merchant marine: total: 8
by type: cargo 4, passenger/cargo 2, petro¬
leum tanker 2 (2008)
Ports and terminals: Antsiranana,
Mahajanga, Toamasina, Toliara
Airports: 34 (2008)
Airports — with paved runways:
total: 6
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 rn: 4 (2008)
Airports— with unpaved runways:
total: 28
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 13 (2008)
Railways:
total: 797 km
narrow gauge: 797 km 1 .067-m gauge
(2006)
Roadways: total: 15,451 km
paved: 6,956 km
unpaved: 8,495 km (2003)
Waterways: 700 km (on Lake Nyasa (Lake
Malawi) and Shire River) (2008)
Ports and terminals: Chipoka, Monkey
Bay, Nkhata Bay, Nkhotakota, Chilumba','70a45da031ca1791ca9c317c3651f79fb983a5f4cdac53f2d19d696dd83c2c84','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdbc1e6a290b68ff9b3885b8e689c54b622870e31f8f3c67d771e0c7a25de8ab',2010,'MY','Malaysia','transportation',1012,'Airports: 116(2008)
Airports — with paved runways:
total: 36
over 3,047 m: 5
2,438 to 3,047 rn: 10
1,524 to 2,437 m: 7
914 to 1,523 m: 8
under 914 m: 6 (2008)
Airports — with unpaved runways:
total: 80
914 to 1,523 m: 8
under 914 m: 72 (2008)
Heliports: 2 (2007)
Pipelines: condensate 3 km; gas 1,965
km; oil 31 km; refined products 114 km
(2008)
Railways: total: 1,890 km
standard gauge: 57 km 1.435-m gauge (57
km electrified)
narrow gauge: 1,833 km 1.000-m gauge
(1 50 km electrified) (2006)
Roadways:
total: 98,721 km
paved: 80,280 km (includes 1,821 km of
expressways)
unpaved: 18,441 km (2004)
Waterways: 7,200 km
note: Peninsular Malaysia 3,200 km;
Sabah 1,500 km; Sarawak 2,500 km
(2008)
Merchant marine:
total: 306
by type: bulk carrier 12, cargo 97, carrier 1,
chemical tanker 34, container 46, liquefied
gas 33, passenger/cargo 5, petroleum tanker
71 , roll on/roll off 3, vehicle carrier 4
foreignowned: 40 (Germany 1 , Hong Kong
14, Japan 4, Russia 2, Singapore 16,
Sweden 3)
registered in other countries: 68 (Bahamas
13, Marshall Islands 3, Norway 1, Panama
12, Philippines 1, Saint Kitts and Nevis 1,
Singapore 27, Thailand 3, Tuvalu 1, US 2,
unknown 4) (2008)
Ports and terminals: Bintulu, Johor
Bahru, Kuantan, Labuan, George Town
(Penang), Port Kelang, Tanjung Pelepas
Transportation— note: the International
Maritime Bureau reports the territorial and
offshore waters in the Strait of Malacca
and South China Sea as high risk for piracy
and armed robbery against ships; numerous
commercial vessels have been attacked and
hijacked both at anchor and while underway;
hijacked vessels are often disguised and
cargo diverted to ports in East Asia; crews
have been murdered or cast adrift','b03b91014477de3a7aaeac7bec7798ed90a3c80768f47db9e915612cdadb1840','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c73ed8922f3e8c33c1036b6be38d3d112c6f94779538070f02610f696a04684c',2010,'MV','Maldives','transportation',1019,'Airports: 5 (2008)
Airports — with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways: total: 2
914 to 1,523 m: 2 (2008)
Roadways: total: 88 km
paved roads: 88 km— 60 km in Male; 14
km on Addu Atolis; 14 km on Laamu
note: village roads are mainly compacted
coral (2006)
Merchant marine: total: 29
by type: bulk carrier 1 , cargo 23, petroleum
tanker 3, refrigerated cargo 2
foreignowned: 1 (Greece 1)
registered in other countries: 2 (Panama 1 ,
Tuvalu 1) (2008)
Ports and terminals: Male','520a423bcda6589526ae376103c84b2962da630d7e02b0e82b19615753c0575d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86f2ab74932f505b9740a914d973fd25702b4957b7121414fd79971d4f517fc9',2010,'MH','Marshall Islands','transportation',1031,'Airports: 1 (2008)
Airports— with paved runways: total: 1
over 3,047 m: 1 (2008)
Roadways: total: 2,227 km
paved: 2,014 km
unpaved: 213 km (2005)
Merchant marine: total: 1,438
by type: bulk carrier 459, cargo 411, carrier
2, chemical tanker 171, container 80, lique¬
fied gas 25, passenger 29, passenger/cargo
15, petroleum tanker 159, refrigerated
cargo 32, roll on/roll off 37, specialized
tanker 1 , vehicle carrier 1 7
foreign-oumed: 1,343 (Austria 1, Azerbaijan
2, Bangladesh 2, Belgium 15, Bulgaria 5,
Canada 1 , China 1 2, Croatia 9, Cyprus 31 ,
Denmark 30, Egypt 1, Estonia 11, France
5, Germany 91, Greece 452, Hong Kong
1, Iceland 5, India 2, Iran 79, Israel 18,
Italy 50, Japan 8, South Korea 2, Latvia 19,
Lebanon 11, Libya 3, Lithuania 1, Norway
93, Pakistan 2, Poland 24, Portugal 3,
Romania 8, Russia 58, Slovenia 4, Spain 3,
Sweden 2, Switzerland 20, Syria 6, Turkey
176, Ukraine 30, UAE 5, UK 19, US 23)
registered in other countries: 3 (Panama 3)
(2008)
Ports and terminals: Marsaxlokk (Malta
Freeport), Valletta
Airports: 15 (2008)
Airports— with paved runways: total. 4
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways: total 1 1
914 to 1,523 m: 10
under 914 m: 1 (2008)
Roadways: total 2,028 km (includes 75
km of expressways) (2007)
Merchant marine: total 1,049
by type: barge carrier 1, bulk carrier 284,
cargo 71, carrier 1, chemical tanker 191,
combination ore/oil 4, container 188,
liquefied gas 47, passenger 5, passenger/
cargo 1, petroleum tanker 221, refrigerated
cargo 13, roll on/roll off 14, specialized
tanker 2, vehicle carrier 6
foreign-owned: 990 (Australia 1, Bermuda
4, Brazil 1, Canada 6, Chile 4, China
7, Croatia 6, Cyprus 37, Denmark 10,
Germany 235, Greece 269, Hong Kong 4,
Iceland 3, India 1 , Ireland 1 , Isle of Man 1 ,
Italy 3, Japan 1 7, South Korea 10, Latvia 16,
Malaysia 3, Mexico 4, Monaco 13, Nether¬
lands 8, Norway 66, Pakistan 1, Panama
1, Romania 1, Russia 9, Saudi Arabia 5,
Singapore 18, Slovenia 4, Spain 1, Sweden
1, Switzerland 12, Taiwan 1, Turkey 50,
UAE 15, UK 10, US 123) (2008)
Ports and terminals: Majuro
439
THE CIA WORLD FACTBOOK','a364dc45a1714635553186ea9ee8959507df2aad5f421a5ff86c15e3cd63f82d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02462267bc0fa5ba6262f12fc154dde8043ca5f5a332a91cf9324c03973b8c14',2010,'MU','Mauritius','transportation',1045,'Airports: 24 (2008)
Airports— with paved runways: total: 8
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4 (2008)
Airports— with unpaved runways: total: 1 6
1,524 to 2,437 m: 8
914 to 1,523 m: 7
under 914 m: 1 (2008)
Railways: 717 km
standard gauge: 717 km 1.435-m gauge
(2006)
0 ZS $»m
/ ''
■
.Goodiands
U - r* - - »
0 3.6 5 m
*
Triolet
cu//
kvMni''i C ?£*?" >
#PORT LOUIS
.
Centre*
de Oacy %
luwe. Bomes
, Curepipe
/ ■■
/ ■
y J
V - ■;
x • y
,/ T
v • / y
'' 4x/
Chemio
■
Grenier
♦
''
.Saute
UAC''CC ;
Airports: 5 (2008)
Airports — with paved runways: total: 2
over 3,047 m: 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways: total: 3
914 to 1,523 m: 2
under 914 m: 1 (2008)
Roadways: total: 2,028 km
paved: 2,028 km (includes 75 km of
expressways) (2007)
Merchant marine: total: 3
by type: passenger/cargo 2, refrigerated
cargo 1 (2008)
Ports and terminals: Port Louis
445
THE CIA WORLD FACTBOOK','006c5c9bd645b6dda7ba77ee2f37ba44e23aeefc2dba8131c8904e1e511ee0e9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a1a7c562bad2535e46caf8f3e59ed1528fcefa91229ed73163019b0f3efe724',2010,'YT','Mayotte','transportation',1057,'Airports: 1 (2008)
Airports— with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Ports and terminals: Dzaoudzi','32500fd5d1325cfdd5171df7179b8f83b541c06f42d086a4eb71a76e7275c94c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cdefa7eeaef95a7811f749eee615a46f1528a4a3a1702f6f2b46c3d81671acf',2010,'MX','Mexico','transportation',1061,'Airports: 1,848 (2008)
Airports— with paved runways: total: 243
over 3,047 m: 12
2,438 to 3,047 m: 29
1,524 to 2,437 m: 85
914 to 1,523 m: 81
under 914 m: 36 (2008)
Airports — with unpaved runways:
total: 1,605
over 3,047 m: 1
2,438 to 3,047 m: 1
I, 524 to 2,437 m: 64
914 to 1,523 m: 426
under 914 m: 1,113 (2008)
Heliports: 1 (2007)
Pipelines: gas 22,705 km; liquid petro¬
leum gas 1,875 km; oil 8,688 km; oil/gas/
water 228 km; refined products 6,520 km
(2006)
Railways: total: 17,665 km
standard gauge: 17,665 km 1.435-m gauge
(2006)
Roadways: total: 356,945 km
paved: 178,473 km (includes 6,279 km of
expressways)
unpaved: 178,472 km (2006)
Waterways: 2 ,900 km (navigable rivers
and coastal canals) (2008)
Merchant marine: total: 55
by type: bulk carrier 2, cargo 7, chemical
tanker 5, liquefied gas 4, passenger/cargo
I I , petroleum tanker 23, roll on/roll off 3
foreign-owned: 4 (Denmark 2, Hong Kong
1, UAE 1)
registered in other countries: 20 (Brazil 1,
Honduras 1, Liberia 2, Marshall Islands 4,
Panama 2, Portugal 1, Spain 3, Venezuela
5, unknown 1) (2008)
Ports and terminals: Altamira, Coatza-
coalcos, Manzanillo, Morro Redondo,
Salina Cruz, Tampico, Veracruz','f17fdf77e412d90869fcf00ffc56bf88fbbd44c914ee6dfd43e8c87b77d91c2c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdcefa59871b075edf7b1da185aa41b1d2f3f10b8e802ebb9785461737fe48f3',2010,'FM','Micronesia, Federated States of','transportation',1070,'Airports: 6 (2008)
Airports — with paved runways: total: 6
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2008)
Roadways: total: 240 km
paved: 42 km
unpaved: 198 km (2000)
Merchant marine: total: 3
by type: cargo 1 , passenger/ cargo 2 (2008)
Ports and terminals: Tomil Harbor','ce67175a35f71bb19518bf17c3ffb8fc798d2efc1d23b6bb5f131cf50bb5ad43','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0d7745565408ec63418f7f9981d7112ed36980268645a1f5297e22ade30f1c',2010,'MC','Monaco','transportation',1075,'Airports: 11 (2008)
Airports — with paved runways: total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2 (2008)
Airports— with unpaved runways: total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 2 (2008)
Pipelines: gas 1,906 km (2008)
Railways: total: 1,138 km
broad gauge: 1,124 km 1.520-m gauge
standard gauge: 14 km 1.435-m gauge
(2006)
Roadways: total: 12,666 km
paved: 12,117 km
unpaved: 549 km (2007)
Waterways: 424 km (on Dniester and Prut
rivers) (2008)
Heliports: 1 (2007)
Roadways: total: 50 km
paved: 50 km (2007)
Merchant marine: registered in other coun¬
tries: 70 (Bahamas 15, Georgia 4, Isle of
Man 3, Liberia 8, Marshall Islands 13,
Norway 5, Panama 16, Saint Vincent and
the Grenadines 5, Vanuatu 1) (2008)
Ports and terminals: Monaco','0d1f5f48ea0f1171ff048ed15a9438eda0d361fe23a229043ca8ab23d132c62a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d781c5589a8a26c7e0b46699cf24f6680f65c29dfbf46cf98c119841879791ff',2010,'MN','Mongolia','transportation',1087,'Airports: 44 (2008)
Airports— with paved runways: total: 12
over 3,047 m: 1
2,438 to 3,047 m: 10
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways: total : 32
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 24
914 to 1,523 m: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Railways: total: 1,810 km
broad gauge: 1,810 km 1.520-m gauge
(2008)
Roadways:
total: 49,249 km
paved: 2,671 km
unpaved: 46,578 km (2008)
Waterways: 580 km
note: only waterway in operation is Lake
Hovsgol (135 km); Selenge River (270 km)
and Orhon River (175 km) are navigable
but carry little traffic; lakes and rivers freeze
in winter, are open from May to September
(2007)
Merchant marine: total: 77
by type: bulk carrier 20, cargo 44, chemical
tanker 2, liquefied gas 1, passenger/cargo
1, petroleum tanker 2, roll on/roll off 6,
v
vehicle carrier 1
foreigmowned: 53 (China 1, Germany 4,
Indonesia 1, North Korea 1, South Korea
1 , Lebanon 2, Russia 9, Singapore 9, Thai¬
land 1, Ukraine 1, Vietnam 23) (2008)','d13748ba20a4c4a25cc34cc60d7bf0b9e5a52a96f4830cdea6323eab8c64b55d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0688991c8c0c07d531d0b4fe10191d7fe5cf25ee2a2d274b525511cbd12a1488',2010,'ME','Montenegro','transportation',1092,'Airports: 5 (2008)
Airports— with paved runways: total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2008)
464','d7dcb3d08b2bcee9a02cb5c6f002a1590e31902da1c4460a73a7c0ebac60ef19','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5c17f25302d4ae4878a591def2747837fa589741bf65a6d511a51c00ad03d95',2010,'MS','Montserrat','transportation',1093,'Airports — with unpaved runways: total: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Railways: total: 250 km
standard gauge: 250 km 1.435-m gauge
(electrified 1 69 km) (2006)
Roadways: total .- 7,368 km
paved: 4,742 km
unpaved: 2,626 km (2006)
Merchant marine: total: 6
by type: cargo 5, passenger/cargo 1
registered in other countries: 3 (Bahamas 2,
Saint Vincent and the Grenadines 1) (2008)
Ports and terminals: Bar','05c382511dcb54be2d455e9589acce6f00f30c9f26bcb2a6ae09e4c765cb6bff','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1955eb4a0a325a28e88e002cbe63baef187430e91ad24afed78c459e7b347a84',2010,'MA','Morocco','transportation',1101,'Airports: 2 (2008)
country comparison to the world: 208
Airports— with paved runways:
total: 1
under 9-14 m: 2 (2008)
Roadways: note: volcanic eruptions that
began in 1995 destroyed most of the 227
km road system; a new road infrastructure
has been built in the north end of the
island (2008)
Ports and terminals:
Little Bay, Plymouth
Airports: 60 (2008)
Airports— with paved runways:
total: 31
over 3,047 m: 10
2,438 to 3,047 m: 8
1,524 to 2,437 m: 9
914 to 1,523 m: 2
under 914 m: 2 (2008)
Airports — with unpaved runways: total: 29
2,438 to 3,047 m: 1
1,524 to 2,437 m: 8
914 to 1,523 m: 11
under 914 m: 9 (2008)
Heliports: 1 (2007)
Pipelines: gas 830 km; oil 439 km (2008)
Railways: total: 1,907 km
standard gauge: 1,907 km 1.435-m gauge
(1,003 km electrified) (2006)
Roadways: total: 57,625 km
paved: 35,664 km (includes 639 km of
expressways)
unpaved: 21,961 km (2006)
Merchant marine: total: 35
by type: cargo 3, chemical tanker 6, container
8, passenger/cargo 13, petroleum tanker 1,
roll on/ roll off 4
foreign-owned: 16 (France 14, Germany 2)
registered in other countries: 4 (Gibraltar 4)
'' (2008)
Ports and terminals: Agadir, Casablanca,
Mohammedia, Safi','429509d4f356601378772e59fb388adb98e23bc8e92abdf50bfa4532d7fca253','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97259bba35b51fee85b187d154ce091b592301d94dc132d41284cd311bc1c59d',2010,'MZ','Mozambique','transportation',1114,'Airports: 1 1 1 (2008)
Airports— with paved runways: total: 23
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 10
914 to 1,523 m: 4
under 914 m: 5 (2008)
Airports — with unpaved runways:
total: 88
2,438 to 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 32
under 914 m: 46 (2008)
Pipelines: gas 918 km; refined products
278 km (2008)
Railways: total: 3,123 km
narrow gauge : 2,983 km 1.067-m gauge;
140 km 0.762-m gauge (2006)
Roadways:
total: 30,400 km
paved: 5,685 km
unpaved: 24,715 km (2000)
Waterways: 460 km (Zambezi River navi-
gable to Tete and along Cahora Bassa
Lake) (2008)
Merchant marine: total: 2
by type: cargo 2
foreign-owned: 2 (Belgium 2) (2008)
Ports and terminals: Beira, Maputo,
Nacala','07bc561e108202bb9bf09fb33458d55d7d9857943433fd9cbdd30fa33e6080b6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71b570c34f56b77784d9e720d51935b93a8db1657e9e6cbdaba6d074ec0f1f57',2010,'NA','Namibia','transportation',1118,'Airports: 132 (2008)
Airports — with paved runways: total. 20
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 3 (2008)
Airports— with unpaved runways: total 112
2,438 to 3,047 m: 2
1,524 to 2,437 m: 23
914 to 1,523 m: 73
under 914 m: 14 (2008)
Railways: total: 2,382 km
narrow gauge: 2,382 km 1.067-m gauge
(2006)
Roadways: total 42,237 km
paved: 5,406 km
unpaved: 36,831 km (2002)
Merchant marine: total 1
by type: cargo 1
registered in other countries: 1 (Saint Vincent
and the Grenadines 1) (2008)
Ports and terminals: Luderitz, Walvis
Bay','3c9a5df63022d4aeae2eed161c0bf3afa0a6c1eb9eb0b0be01b95306a70bb897','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('188f7f3f37b7ff271ec4ac60e7f54760acc488d678d35fa4a0d5466d134552b0',2010,'NR','Nauru','transportation',1126,'Airports: 1 (2008)
Airports— with paved runways:
total: 1 1,524 to 2,437 m: 1 (2008)
Roadways: total: 24 km
paved: 24 km (2002)
Ports and terminals: Nauru','4cf1096681456791c5a18108562b4e882b2e87cc88edaeaf8137327a7d93c71d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10cca899e20033e6da05f6c0836aeeebab5c09ea29d2599cac608b7fd0b5bfd8',2010,'NP','Nepal','transportation',1133,'Airports: 47 (2008)
Airports — with paved runways:
total: 1 1
over 3,047 m: 1
914 to 1 ,523 m: 9
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 36
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 30 (2008)
Railways: total: 59 km
narrow gauge: 59 km 0.762-m gauge (2006)
483
THE CIA WORLD FACTBOOK
Roadways: total: 17,280 km
paved: 9,829 km
unpaved: 7,451 km (2004)','db7a303d640607db3f5a092962db462e6f49e8373dbbfe2b7b83ec78ea75dabd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9610bf8c9450cdb9b3fa95bfb6b9e7bd05fbb78bf42237ef94086121a4cd7182',2010,'NC','New Caledonia','transportation',1142,'Airports: 25 (2008)
Airports — with paved runways: total: 12
over 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 1 3
914 to 1,523 m: 5
under 914 m: 8 (2008)
Heliports: 6 (2007)
Roadways: total: 5,622 km (2006)
Merchant marine: total: 2
by type: cargo 1, passenger/cargo 1 (2008)
Ports and terminals: Noumea','5f38ca2d2ce701d39d7b3beb2363038e7f6a4545dde9d5ff3a6385cb03786e4a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('185e9142c9883c5c47c5f133298d95ca32872aa537c571fd31d244a20dcb4131',2010,'NI','Nicaragua','transportation',1148,'Airports: 121 (2008)
Airports— with paved runways: total. 41
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m : 12
914 to 1,523 m: 25
under 914 m: 1 (2008)
Airports — with unpaved runways: total 80
1,524 to 2,437 m: 3
914 to 1,523 m: 31
under 914 m: 46 (2008)
Pipelines: condensate 331 km; gas 1,838
km; liquid petroleum gas 172 km; oil 288
km; refined products 1 98 km (2008)
Railways:
total: 4,128 km
narrow gauge: 4,128 km 1.067-m gauge
(506 km electrified) (2006)
Roadways: total: 93,576 km
paved: 61,564 km
(includes 172 km of expressways)
unpaved: 32,012 km (2006)
Merchant marine: total 13
by type: bulk carrier 3, cargo 2, chemical
tanker 1, passenger/cargo 4, petroleum
tanker 1 , roll on/ roll off 2
foreign-owned: 3 (Australia 1, Germany 1,
South Africa 1)
registered in other countries: 5 (Antigua and
Barbuda 2, Cook Islands 1, France 1,
UK 1) (2008)
Ports and terminals: Auckland, Lyttelton,
Marsden Point, Tauranga, Wellington,
Whangarei
Airports: 144 (2008)
Airports— with paved runways:
total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2008)
Airports— with unpaved runways:
total: 133
1,524 to 2,437 m: 1
914 to 1,523 m: 16
under 914 m: 116 (2008)
Pipelines: oil 54 km (2008)
Railways:
total: 6 km
narrow gauge: 6 km 1 .067-m gauge (2006)
Roadways:
total: 19,036 km
paved: 2,299 km
unpaved: 16,737 km (2005)
Waterways: 2,220 km (including lakes
Managua and Nicaragua) (2008)
Ports and terminals: Bluefields, Corinto,
El Bluff','70bd3ddc11650249e1e167f7a56aa595b485fca4784b06cf710c0f84483351aa','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55578e28c133a2fb49f762bde3e537923eaa05334adc4447631a9127d4c23d25',2010,'NE','Niger','transportation',1157,'Airports: 27 (2008)
Airports — with paved runways:
total: 9
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways:
total: 18
1,524 to 2,437 m: 2
914 to 1,523 m: 13
under 914 m: 3 (2008)
Roadways:
total: 18,550 km
paved: 3,803 km
unpaved: 14,747 km (2006)
Waterways: 300 km (the Niger, the only
major river, is navigable to Gaya between
September and March) (2008)','512a4eec1704b9213e8268fa0c523c8750c8c91c00d43585fa9c7fc425240e12','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e64a6767f5fd103ea29803b8e6e3bce71a18a6110071e4390031e6bb46827624',2010,'NU','Niue','transportation',1166,'Airports: 60 (2008)
Airports — with paved runways: total: 38
over 3,047 m: 6
2,438 to 3,047 m: 12
1,524 to 2,437 m: 11
914 to 1,523 m: 7
under 914 m: 2 (2008)
Airports — with unpaved runways: total: 22
1,524 to 2,437 m: 2
914 to 1,523 m: 13
under 914 m: 7 (2008)
Heliports: 2 (2007)
Pipelines: condensate 21 km; gas 2,560
km; liquid petroleum gas 97 km; oil 3,396
km; refined products 4,090 km (2008)
Railways: total: 3,505 km
narrow gauge: 3,505 km 1.067-m
gauge (2006)
INTRODUCTION NIUE
Background: Niue’s remoteness, as well as
cultural and linguistic differences between
its Polynesian inhabitants and those of the
rest of the Cook Islands, have caused it to
be separately administered. The population
of the island continues to drop (from a peak
of 5,200 in 1966 to an estimated 1,444 in
2008), with substantial emigration to New
Zealand, 2,400 km to the southwest.
Roadways: total: 193,200 km
paved: 28,980 km
unpaved: 164,220 km (2004)
Waterways: 8,600 km (Niger and Benue
rivers and smaller rivers and creeks)
(2008)
Merchant marine: total: 68
by type: cargo 4, chemical tanker 12,
combination ore/oil 1, liquefied gas 2,
passenger/cargo 1, petroleum tanker 46,
specialized tanker 2
foreign-owned: 3 (Japan 1, South Africa 1,
Spain 1)
registered in other countries: 34 (Bahamas 2,
Bermuda 1 1 , Cook Islands 1 , Georgia 1 , Italy
1 , Liberia 2, Panama 1 0, Poland 1 , Seychelles
1, Sierra Leone 1, unknown 3) (2008)
Ports and terminals: Bonny Inshore
Terminal, Calabar, Lagos
Transportation — note: the International
Maritime Bureau reports the territorial
and offshore waters in the Niger Delta and
Gulf of Guinea as high risk for piracy and
armed robbery against ships; numerous
commercial vessels have been attacked
and hijacked both at anchor and while
underway; crews have been robbed and
stores or cargoes stolen','da6aa43bbbe6325827589604ed212d3ae2b3cbada5ec0e9b3a0336242c5a651c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('161a625d520915e4ae95a0b378e8e93f1ed04b0614fe851403e812d42460970b',2010,'NF','Norfolk Island','transportation',1173,'Airports: 1 (2008)
Airports— with paved runways: total: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total: 120 km
paved: 120 km (2008)
Ports and terminals: none; offshore
anchorage only
MILITARY NIUE
Military branches: no regular indigenous
military forces; Police Force
Military — note: defense is the responsi¬
bility of New Zealand','a1ed674f984ff8f41a782474f86c04658921a63bd40545acafcd1234a71f690b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64e1015c79fb62d502c50752974814c5a683742e8424e155296d15f6bfaf18bc',2010,'MP','Northern Mariana Islands','transportation',1177,'Airports: 1 (2008)
Airports— with paved runways:
total: 1 1,524 to 2,437 m: 1 (2008)
Roadways:
total: 80 km
paved: 53 km
unpaved: 27 km (2008)
Ports and terminals: none; loading jetties
at Kingston and Cascade','c7de4b657d09628537222eda3eb5e4438f7634c58572db0be6c3764a8d09549e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d1f37eaf33d078c1036df62419dfd91a3d07b08f402d9224834747d8b5ccc05',2010,'NO','Norway','transportation',1184,'Airports: 5 (2008)
Airports— with paved runways:
total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Roadways: total: 536 km (2007)
Ports and terminals: Saipan, Tinian
Airports: 98 (2008)
Airports— with paved runways: total: 67
2,438 to 3,047 m: 13
1,524 to 2,437 m: 12
914 to 1,523 m: 15
under 914 m: 27 (2008)
Airports— with unpaved runways:
total: 31
914 to 1,523 m: 6
under 914 m: 25 (2008)
Heliports: 1 (2007)
Pipelines: condensate 31 km;
gas 64 km (2008)
Railways: total: 4,114 km
standard gauge: 4,114 km 1.435-m gauge
(2,552 km electrified) (2008)
Roadways: total: 92,946 km
paved: 72,033 km (includes 664 km of
expressways)
unpaved: 20,913 km (2007)
Waterways: 1,577 km (2008)
Merchant marine: total-. 688
by type: bulk carrier 46, cargo 141 , carrier 3,
chemical tanker 137, combination ore/oil
1 2, container 4, liquefied gas 65, passenger/
cargo 117, petroleum tanker 85, refriger¬
ated cargo 14, roll on/roll off 13, special¬
ized tanker 1 , vehicle carrier 50
foreign-owned: 199 (Canada 10, Chile
2, China 36, Denmark 25, Estonia 1,
Finland 1, France 3, Germany 1, Greece
3, Hong Kong 20, Iceland 3, Italy 4, Japan
29, Lithuania 1, Malaysia 1, Monaco 5,
Poland 3, Saudi Arabia 3, Singapore 1,
Sweden 34, UK 5, US 8)
registered in other countries: 923 (Antigua
and Barbuda 8, Australia 1, Bahamas 189,
Barbados 38, Belize 3, Bermuda 5, Brazil
5, Canada 3, Cayman Islands 1, China 1,
Comoros 1, Cook Islands 5, Cyprus 18,
Denmark 3, Dominica 1 , Estonia 2, Faroe
Islands 4, Finland 3, France 5, Gibraltar
33, Hong Kong 40, Indonesia 1, Isle of
Man 20, Italy 2, South Korea 2, Liberia
40, Libya 1 , Malta 93, Marshall Islands 66,
Netherlands 12, Netherlands Antilles 3,
Panama 89, Philippines 10, Russia 2, Saint
Vincent and the Grenadines 13, Singapore
143, Spain 5, Sweden 7, Tuvalu 1, UK 31,
US 9, unknown 4) (2008)
Ports and terminals: Bergen, Borg Havn,
Haugesund, Maaloy, Mongstad, Narvik,
Oslo, Sture','c8ca71a46f165a22aa0b8f339c97353f9ef6d40e2795fb3a128657578e0de07e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a17f139d9071567c64eafce385d15b5b5d7b1e5b3579c17acfa86a03f1b1dae',2010,'OM','Oman','transportation',1193,'Airports: 130 (2008)
Airports — with paved runways: total. 10
over 3,047 m: 5
2,438 to 3,047 m: 4
914 to 1,523 rn: 1 (2008)
Airports — with unpaved runways:
total: 120
over 3,047 m: 1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 52
914 to 1,523 m: 33
under 914 m: 27 (2008)
Heliports: 2 (2007)
Pipelines: gas 4,126 km; oil 3,558 km;
refined products 263 km (2008)
Roadways: total 42,300 km
paved: 16,500 km (includes 550 km of
expressways)
unpaved: 25,800 km (2005)
Merchant marine: total 3
by type: chemical tanker 1 , passenger 1 ,
passenger/cargo 1
registered in other countries: 2 (Panama 2)
(2008)
Ports and terminals: Mina’ Qabus, Salalah
Ports and terminals: Bangkok (Thai¬
land), Hong Kong (China), Kao-hsiung
(Taiwan), Los Angeles (US), Manila
(Philippines), Pusan (South Korea), San
Francisco (US), Seattie (US), Shanghai
(China), Singapore, Sydney (Australia),
Vladivostok (Russia), Wellington (NZ),
Yokohama (Japan)
Transportation— note: Inside Passage
offers protected waters from southeast
Alaska to Puget Sound (Washington state);
the International Maritime Bureau reports
the territorial waters of littoral states and
offshore waters in the South China Sea
as high risk for piracy and armed robbery
against ships; numerous commercial vessels
have been attacked and hijacked both
at anchor and while underway; hijacked
vessels are often disguised and cargoes
stolen; crew and passengers are often held
for ransom, murdered, or cast adrift','f5b744383bf9fd3512c03cf0fbd6e84170f1e42ef390ab72dc0e85575ad954bd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b305828bfc2b7122a0e1d95d245afe6d5bf91533310af68681280f61027aa59',2010,'PK','Pakistan','transportation',1203,'Airports: 143 (2008)
Airports— with paved runways: total: 95
over 3,047 m: 16
2,438 to 3,047 m: 20
1,524 to 2,437 m: 32
914 to 1,523 m: 16
under 914 m: 11 (2008)
Airports — with unpaved runways: total: 48
1,524 to 2,437 m: 14
914 to 1,523 m: 14
under 914 m: 20 (2008)
Heliports: 18 (2007)
Pipelines: gas 10,402 km; oil 2,076 km;
refined products 792 km (2008)
Railways: total: 8,163 km
broad gauge: 7,718 km 1.676-m gauge (293
km electrified)
narrow gauge: 445 km 1.000-m gauge
(2006)
Roadways: total 259,758 km
paved: 162,879 km (includes 711 km of
expressways)
unpaved: 96,879 km (2005)
Merchant marine: total 15
by type: bulk carrier 1, cargo 10, petroleum
tanker 4
registered in other countries: 19 (Comoros
4, Malta 2, Marshall Islands 1 , Panama 9,
Saint Kitts and Nevis 3) (2008)
Ports and terminals: Karachi, Port
Muhammad Bin Qasim','128e4df758de00530de1c43e59b9c28479711c2cf625690be26d14d7431dd118','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28bcba65f745677661e208a9d102798352410a4660758c85c8d823e332aaf909',2010,'PH','Philippines','transportation',1212,'Airports: 3 (2008)
Airports — with paved runways: total: l
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways: total: 2
1,524 to 2,437 m: 2 (2008)
Roadways: note: estimated to have 60 km
of roads as of 1 996
Ports and terminals: Koror
524
Airports: 254 (2008)
Airports — with paved runways: total 85
over 3,047 m: 4
2,438 to 3,047 m: 7
1,524 to 2,437 m: 28
914 to 1,523 m: 36
under 914 m: 10 (2008)
Airports — with unpaved runways:
total: 169
1,524 to 2,437 m: 4
914 to 1,523 m: 66
under 914 m: 99 (2008)
Heliports: 2 (2007)
Pipelines: oil 107 km; refined products
112 km (2008)
Railways: total 897 km
narrow gauge: 897 km 1.067-m gauge (492
km are in operation) (2006)
Roadways: total 200,037 km
paved: 19,804 km
unpaved: 180,233 km (2003)
Waterways: 3 ,219 km (limited to vessels
with draft less than 1 .5 m) (2008)
Merchant marine: total 391
by type: bulk carrier 75, cargo 125, carrier
16, chemical tanker 17, container 6, lique¬
fied gas 5, passenger 6, passenger/cargo
68, petroleum tanker 36, refrigerated cargo
1 5, roll on/ roll off 1 1 , vehicle carrier 1 1
foreign-owned: 161 (Bermuda 34, China
4, Greece 4, Hong Kong 1, Japan 81,
Malaysia 1, Netherlands 23, Norway 10,
Singapore 1, Taiwan 1, UAE 1)
registered in other countries: 11 (Comoros
1, Cyprus 1, Hong Kong 1, Indonesia 1,
Panama 7) (2008)
Ports and terminals: Cagayan de Oro,
Cebu, Davao, Liman, Manila, Nasipit
Harbor
Transportation — note: the International
Maritime Bureau reports the territorial
and offshore waters in the South China
Sea as high risk for piracy and armed
robbery against ships; numerous commer¬
cial vessels have been attacked and hijacked
both at anchor and while underway;
hijacked vessels are often disguised and
cargo diverted to ports in East Asia; crews
have been murdered or cast adrift','4d8115e6d03ecc3910d9de5595b57022fe0866246c5f4f84728c065aa48ff5d1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be0ae19bd89a0bd5609b3a08cb8327062abe3f7bf868c5981388a05dfa4df34b',2010,'PA','Panama','transportation',1217,'Airports: 117 (2008)
Airports— with paved runways: total: 54
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 17
under 914 m: 30 (2008)
Airports— with unpaved runways: total: 63
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 51 (2008)
Heliports: 2 (2007)
Railways:
total: 355 km
standard gauge: 77 km 1.435-m gauge
narrow gauge: 278 km 0.91 4-m gauge (2006)
Roadways: total: 1 1 ,978 km
paved: 4,300 km
unpaved: 7,678 km (2002)
Waterways: 800 km (includes 82 km
Panama Canal) (2008)','3383e49be11d678ac8cc672b994c0d38ad116bb3a9d5294ca0e62020712360d6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c75f0c82f22630855f56976ce56b69ddb937c0cbb417acd628687c3f1da3f66',2010,'PG','Papua New Guinea','transportation',1225,'Airports: 55 7 (2008)
Airports — with paved runways: total: 21
2,438 to 3,047 m: 2
1,524 to 2,437 m : 14
914 to 1,523 m: 4
under 914 m: 1 (2008)
Airports— with unpaved runways:
total: 536
1,524 to 2,437 m: 8
914 to 1,523 m: 62
under 914 m: 466 (2008)
Heliports: 2 (2007)
Pipelines: oil 195 km (2008)
Roadways: total: 19,600 km
paved: 686 km
unpaved: 18,914 km (2000)
Waterways: 1 1 ,000 km (2006)
Merchant marine: total: 21
by type: bulk carrier 2, cargo 17, petroleum
tanker 2
foreign-owned: 6 (UAE 6) (2008)
Ports and terminals: Kimbe, Lae, Madang,
Rabaul, Wewak
Airports: l (2008)
Airports— with payed runways: total: 1
1,524 to 2,437 m: 1 (2008)
Ports and terminals: small Chinese port
facilities on Woody Island and Duncan
Island being expanded','5ce8d12f488006ac4e468a8c92cf7a6646aca456f9e7d095376c9cec86449d3e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07d96374e9cc206beb4ea402f538901be834d3f78ed62efb03dcb5e236f22a0',2010,'PE','Peru','transportation',1232,'Airports: 797 (2008)
Airports— with paved runways: total: 13
over 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 5 (2008)
Airports — with unpaved runways:
total: 784
1,524 to 2,437 m: 26
914 to 1,523 m: 288
under 914 m: 470 (2008)
Railways: total: 36 km
standard gauge: 36 km 1.435-m gauge
(2006)
Roadways: total: 29,500 km
paved: 14,986 km
unpaved: 14,514 km (2000)
Waterways: 3,100 km (2008)
Merchant marine: total: 23
by type: cargo 18, carrier 1, passenger 1,
petroleum tanker 2, roll on/roll off 1
foreignowned: 6 (Argentina 5, Netherlands
1) (2008)
Ports and terminals: Asuncion, Villeta,
San Antonio, Encarnacion
Airports: 202 (2008)
Airports — with paved runways: total: 56
over 3,047 m: 6
2,438 to 3,047 m: 20
1,524 to 2,437 m: 15
914 to 1,523 m: 11
under 914 m: 4 (2008)
Airports— with unpaved runways:
total: 146
2,438 to 3,047 m: 2
1,524 to 2,437 m: 24
914 to 1,523 m: 39
under 914 m: 81 (2008)
Heliports: 1 (2007)
Pipelines: extra heavy crude 533 km; gas
1 ,078 km; liquid petroleum gas 654 km; oil
1,018 km; refined products 15 km (2008)
Railways: total: 1,989 km
standard gauge: 1,726 km 1.435-m gauge
narrow gauge: 263 km 0.91 4-m gauge (2006)
Roadways: total: 78,829 km
paved: 11,351 km (includes 276 km of
expressways)
unpaved: 67,478 km (2004)
Waterways: 8,808 km
note: 8,600 km of navigable tributaries of
Amazon system and 208 km of Lago Titi¬
caca (2008)
Merchant marine: total: 8
by type: cargo 3, chemical tanker 1, petro¬
leum tanker 4
foreign-owned: 1 (Bahamas 1)
registered in other countries: 17 (Belize 1,
Panama 16) (2008)
Ports and terminals: Callao, Iquitos,
Matarani, Paita, Pucallpa, Yurimaguas;
note— Iquitos, Pucallpa, and Yurimaguas
are on the upper reaches of the Amazon
and its tributaries','2eb7f418e955a2ba8f04e86e2bc90f28d712cdd377faad7322091b215e9b3b9b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8489b5c598cc06644144ab5eabbe6c7700692b04625156333080981f4709a09',2010,'PL','Poland','transportation',1242,'Ports and terminals: Adamstown (on
Bounty Bay)
Airports: 126 (2008)
Airports— with paved runways: total: 84
over 3,047 m: 4
2,438 to 3,047 m: 30
1,524 to 2,437 m: 39
914 to 1,523 m: 7
under 914 m: 4 (2008)
Airports — with unpaved runways: total: 42
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 22 (2008)
Heliports: 7 (2007)
Pipelines: gas 13,631 km; oil 1,384 km;
refined products 777 km (2008)
Railways: total: 23,072 km
broad gauge: 629 km 1.524-m gauge
standard gauge: 22,443 km 1.435-m gauge
(20,555 km operational; 11,910 km electri-
fied) (2006)
Roadways: total: 423,997 km
paved: 295,356 km (includes 662 km of
expressways)
unpaved: 128,641 km (2006)
Waterways: 3,997 km (navigable rivers
and canals) (2007)
Merchant marine: total: 15
by type: cargo 8, chemical tanker 4,
passenger/cargo 1, roll on/roll off 1, vehicle
i v ''
carrier 1
foreign-owned: 2 (Cyprus 1, Nigeria 1)
registered in other countries: 98 (Antigua
and Barbuda 2, Bahamas 17, Cyprus 18,
Liberia 13, Malta 24, Norway 3, Panama
11, Saint Vincent and the Grenadines 1,
Slovakia 2, Vanuatu 7) (2008)
Ports and terminals: Gdansk, Gdynia,
Swinoujscie, Szczecin','62f4381819f178c19bbcf2522e9c360016b1f694915cf88e2913739708fe1b57','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be0cdce7cf76345fb598dc75eb54408e10c7b194bb03769dc6e1d7a8adfb26b5',2010,'PT','Portugal','transportation',1251,'Airports: 65 (2008)
Airports — with paved runways:
total: 43
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 5
914 to 1,523 m: 13
under 914 m: 11 (2008)
Airports— with unpaved runways: total: 22
914 to 1,523 m: 1
under 914 m: 21 (2008)
Pipelines: gas 1,098 km; oil 11 km;
refined products 1 88 km (2008)
Railways: total: 2,786 km
broad gauge: 2,603 km 1.668-m gauge
(1,351 km electrified)
narrow gauge: 183 km 1 .000-m gauge
(2006)
Roadways: total: 82,900 km
paved: 71,294 km (includes 2,300 km of
expressways)
unpaved: 1 1,606 km (2005)
Waterways: 210 km (on Douro River
from Porto) (2008)
Merchant marine: total: 117
by type: bulk carrier 10, cargo 36, carrier
1, chemical tanker 15, container 6, lique¬
fied gas 9, passenger 10, passenger/cargo
9, petroleum tanker 4, roll on/roll off 1,
specialized tanker 1 , vehicle carrier 1 5
foreign-owned: 84 (Bahamas 1, Belgium 8,
Denmark 3, Germany 20, Greece 4, Hong
Kong 2, Italy 12, japan 15, Mexico 1,
Netherlands 1, Spain 11, Sweden 3, Swit¬
zerland 2, US 1)
registered in other countries: 15 (Cyprus 1,
Hong Kong 1, Italy 1, Malta 3, Panama
9) (2008)
Ports and terminals: Leixoes, Lisbon,
Setubal, Sines','90e1a3998121722bb88fe40d0475a7a4b06420254226ba8753eb3463a46e2b23','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c088701d6a885a641f18c3d955a24c2da767bd5743888fb1aa3101400e07d0c4',2010,'PR','Puerto Rico','transportation',1259,'Airports: 29 (2008)
Airports — with paved runways: total: 1 7
over 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 5 (2008)
Airports— with unpaved runways: total: 1 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 10 (2008)
Railways:
total: 96 km
narrow gauge: 96 km 1 .000-m gauge
(2006)
Roadways:
total: 26,186 km
paved: 24,877 km (includes 427 km of
expressways)
unpaved: 1,309 km (2007)
Merchant marine:
total: 3
by type: roll on/ roll off 3
foreign-owned: 3 (US 3)
registered in other countries: 1 (Saint
Vincent and the Grenadines 1) (2008)
Ports and terminals: Guayanilla,
Mayaguez, San Juan
Airports: 1 (2008)
country comparison to the world: 217
579
THE CIA WORLD FACTBOOK
Airports— with paved runways:
total: 1
914 to 1,523 m: 1 (2008)
Transportation — note: nearest airport for
international flights is Princess Juliana
International Airport (SXM) located in
Sint Maarten
country comparison to the world:','173518b8531c8e2057d0d5e6e9a1ba45ca1af6ee10ea05eb2c08db1574f47b4e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78facdd3cddb0d1c27b863ec2cff7dd84272dd9222d174955aa8db227b62dca0',2010,'QA','Qatar','transportation',1264,'Airports: 5 (2008)
Airports— with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Heliports: 1 (2007)
Pipelines: condensate 145 km; conden¬
sate/gas 132 km; gas 978 km; liquid petro¬
leum gas 90 km; oil 382 km (2008)
Roadways: total: 7,790 km (2006)
Merchant marine: total: 22
by type: bulk carrier 2, cargo 2, chemical
tanker 2, container 8, liquefied gas 4, petro¬
leum tanker 4
foreign-oivned: 7 (Kuwait 7)
registered in other countries: 5 (Liberia 4,
Panama 1) (2008)
Ports and terminals: Doha, Ra’s Laffan','c808a3bd645015177bd8f0776eac269767b4ac33a0591dfa4743f79fa080a1ca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f114ad061df5b58862045c5da42a67f4856d7adb6fd7094fc930b03203b65ed8',2010,'RO','Romania','transportation',1270,'Airports: 53 (2008)
Airports— with paved runways: total: 25
over 3,047 m: 4
2,438 to 3,047 m: 10
1,524 to 2,437 m: 11 (2008)
Airports— with unpaved runways: total: 28
914 to 1,523 m: 7
under 914 m: 21 (2008)
Heliports: 2 (2007)
560
RUSSIA
Pipelines: gas 3,588 km; oil 2,424 km
(2008)
Railways: total: 10,789 km
broad gauge: 57 km 1.524-m gauge
standard gauge: 10,731 km 1.435-m gauge
(3,965 km electrified)
narrow gauge: 1 km 0.760''m gauge (2007)
Roadways: total: 198,817 km
paved: 60,043 km (includes 228 km of
expressways)
unpaved: 138,774 km (2004)
Waterways: 1,731 km
note: includes 1,075 km on Danube River,
524 km on secondary branches, and 132
km on canals (2006)
Merchant marine: total: 17
by type: cargo 11, passenger 1, passenger/
cargo 2, petroleum tanker 2, roll on/roll
off 1
registered in other countries: 49 (Cambodia
1, Georgia 16, North Korea 4, Liberia 2,
Malta 8, Marshall Islands 1, Moldova 3,
Panama 7, Saint Kitts and Nevis 1, Saint
Vincent and the Grenadines 1, Sierra
Leone 3, Syria 2) (2008)
Ports and terminals: Braila, Constanta,
Galati, Tulcea','140c68252b6d8b8401d161ad63ddc45f00ce9b5c1dc6a9f52dd33e378cd59751','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eeefcd859274c1410b47fac714f8c6b450f898ec960ec712002e72dff9fad540',2010,'RU','Russian Federation','transportation',1275,'Airports: 1,232 (2008)
Airports — with paved runways: total: 596
over 3,047 m: 52
2,438 to 3,047 rn: 197
1,524 to 2,437 m: 129
914 to 1,523 m: 100
under 914 m: 118 (2008)
Airports— with unpaved runways:
total: 636
over 3,047 m: 3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 68
914 to 1,523 m: 87
under 914 m: 466 (2008)
Heliports: 47 (2007)
Pipelines: condensate 122 km; gas
158,767 km; liquid petroleum gas 127 km;
oil 74,285 km; refined products 13,658
km; water 23 km (2008)
Railways: total: 87,157 km
broad gauge: 86,200 km 1.520-m gauge
(40,300 km electrified)
narrow gauge: 957 km 1.067-m gauge (on
Sakhalin Island)
note: an additional 30,000 km of non¬
common carrier lines serve industries
(2006)
Roadways: total: 933,000 km
paved: 754,984 km (includes 30,000 km of
expressways)
unpaved: 178,016 km
note: includes public, local, and depart¬
mental roads (2006)
Waterways: 102,000 km (including 33,000
km with guaranteed depth)
note: 72,000 km system in European Russia
links Baltic Sea, White Sea, Caspian Sea,
Sea of Azov, and Black Sea (2007)
Merchant marine: total: 1,074
by type: bulk carrier 25, cargo 663,
carrier 2, chemical tanker 27, combina¬
tion ore/oil 34, container 11, passenger
14, passenger/cargo 7, petroleum tanker
217, refrigerated cargo 59, roll on/roll off
10, specialized tanker 5
foreigmowned: 112 (Belgium 4, Cyprus 2,
Germany 1 , Greece 1 , Italy 4, South Korea
1, Latvia 2, Norway 2, Switzerland 3,
Turkey 80, Ukraine 11, US 1)
registered in other countries: 486 (Antigua
and Barbuda 4, Bahamas 4, Belize 31,
Bulgaria 1, Cambodia 83, Comoros 12,
Cyprus 50, Dominica 3, Georgia 12, Hong
Kong 2, Jamaica 3, Liberia 94, Malaysia 2,
Malta 58, Marshall Islands 9, Moldova 3,
Mongolia 9, Panama 18, Saint Kitts and
Nevis 19, Saint Vincent and the Gren¬
adines 21, Sierra Leone 11, Slovakia 1,
Tuvalu 2, Ukraine 1 , Vanuatu 2, unknown
31)(2008)
Ports and terminals: Azov, Kalinin¬
grad, Kavkaz, Nakhodka, Novorossiysk,
Primorsk, Saint Petersburg, Vostochnyy','656e7d40c034a6071f4800e2585d377bfcc51d5ce1e65e9e450f799a4019812f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34a295ab66fd3272e46c86733826ec03f5b80b2c98caa9751ead9db5b74e6bd5',2010,'RW','Rwanda','transportation',1283,'Airports: 9 (2008)
Airports — with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2008)
Airports — with unpaved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (2008)
Roadways:
total: 14,008 km
paved: 2,662 km
unpaved: 11,346 km (2004)
Waterways: Lac Kivu navigable by shallow-
draff barges and native craft (2008)
Ports and terminals: Cyangugu, Gisenyi,
Kibuye','9eda61683287b96427e5043730490c4ff9b856b985ea603a0372483b6588d7e3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfdaa62da1be796740a20b6cedd3ab9f07031d9e6f67c279dfce691a47e7fea5',2010,'GP','Guadeloupe','transportation',1288,'Airports: 1 (2008)
country comparison to the world: 215
Airports — with paved runways: total: 1
under 914 m: 1 (2008)
Transportation — note: nearest airport for
international flights is Princess Juliana
International Airport (SXM) located in
Sint Maarten (Netherlands Antilles)
country comparison to the world:','77fc7487339cf9237cf306ba50564b00abd1fbc71fb4a5f48cd731ddc430b25e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfc4a6aeb4721f6ead9f8b8158108179d2caa765a544e60348416e3811631fc9',2010,'KN','Saint Kitts and Nevis','transportation',1297,'Airports: 1 (2008)
Airports — with paved runways: total: 1
over 3,047 m: 1 (2008)
Roadways: total: 198 km (Saint Helena
138 km, Ascension 40 km, Tristan da
Cunha 20 km)
paved: 168 km (Saint Helena 118 km,
Ascension 40 km, Tristan da Cunha 1 0 km)
unpaved: 30 km (Saint Helena 20 km,
Ascension 0 km, Tristan da Cunha
10 km) (2002)
Ports and terminals:
Saint Helena: Jamestown
Ascension Island: Georgetown
Tristan da Cunha: Calshot Harbor
Transportation— note: there is no air
connection to Saint Helena or Tristan da
Cunha; an international airport for Saint
Helena is in development for 2010
Airports: 2 (2008)
Airports — with paved runways: total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Railways: total: 50 km
narrow gauge: 50 km 0.762-m gauge on
Saint Kitts for tourists (2006)
Roadways: total: 383 km
paved: 163 km
unpaved: 220 km (2002)
Merchant marine: total: 1 59
by type: bulk carrier 10, cargo 109, chemical
tanker 7, container 1, liquefied gas 1,
575
THE CIA WORLD FACTBOOK
passenger 1, passenger/cargo 2, petroleum
tanker 19, refrigerated cargo 7, roll on/roll
off 1 , specialized tanker 1
foreigmowned: 121 (Belgium 1, Cyprus 1,
Egypt 2, Estonia 3, Finland 1, Greece 3,
India 1 , Italy 1 , Japan 3, Kuwait 1 , Latvia 5,
Malaysia 1 , Pakistan 3, Romania 1 , Russia
19, Singapore 1, Spain 1, Syria 7, Turkey
35, Ukraine 9, UAE 18, UK 3, Yemen 1)
(2008)
Ports and terminals: Basseterre','6b51e48e01761d978e3455bd0eea3692a48ae72098b279e73aba4bfa89355f64','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c427ef9714b191afaecac719f7a03331e65b652ef2afb10505172f9ecf6043',2010,'LC','Saint Lucia','transportation',1309,'Airports: 2 (2008)
Airports — with paved runways: total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total: 1,210 km (2002)
Ports and terminals: Castries, Cul-de-Sac,
Vieux-Fort','2e046b12594fe8b5fe8d565bd93095d90e21ffb293ec94631035aaa6d50f36e0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc7b1d11d6e9ed6a82540b7418bf391c1866e8b98d87417caa540302c2400566',2010,'PM','Saint Pierre and Miquelon','transportation',1317,'Airports: 2 (2008)
Airports — with paved runways: total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Roadways: total: 1 1 7 km
paved: 80 km
unpaved: 37 km (2000)
Ports and terminals: Saint-Pierre','1e19b352f92b87e8e00110a93ff2a7b1a52714f889e6867ee0ef7b22e51506ca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5c92ea3742234bb0778876498ddc92df0448e04e552f3590946b8bd8793ae9b',2010,'VC','Saint Vincent and the Grenadines','transportation',1325,'Airports: 6 (2008)
Airports — with paved runways: total: 5
914 to 1,523 m: 4
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 1
under 914 m: 1 (2008)
Roadways:
total: 829 km
paved: 580 km
unpaved: 249 km (2003)
Merchant marine: total: 525
by type: barge carrier 1, bulk carrier 83,
cargo 315, carrier 20, chemical tanker 2,
liquefied gas 6, passenger 3, passenger/
cargo 17, petroleum tanker 17, refrigerated
cargo 20, roll on/roll off 18, specialized
tanker 2, container 21
foreign-owned: 476 (Austria 2, Barbados 1,','26293e8021315c863d0e025ceba91b0516ce7319fcb8d031c48db3b4f20d8929','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89c81ced24449a71d376165e93767a5a65160cd55056dfd8594fe668dbd57204',2010,'SM','San Marino','transportation',1334,'Airports: 4 (2008)
Airports — with paved runways: total: 3
2,438 to 3,047 m: 1
under 914 m: 2 (2008)
Airports — with unpaved runways: total: 1
under 914 m: 1 (2008)
Roadways: total: 2,337 km
paved: 332 km
unpaved: 2,005 km (2001)
Merchant marine: total: 1
by type: cargo 1
foreign-owned: 1 (Cyprus 1) (2008)
Ports and terminals: Apia','45cc997d04c4ecbdbd9d49421d8f52ff395de1aeeb6efe09e45b2351b80c71d1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68ed023f55bae89642c5c9a0d68009f26ade688a06750929ec74e0bde58f5a9f',2010,'ST','Sao Tome and Principe','transportation',1343,'Roadways: total: 292 km
paved: 292 km (2006)
Airports: 2 (2008)
Airports — with paved runways: total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Roadways: total: 320 km
paved: 218 km
unpaved: 102 km (2000)
Merchant marine: total 6
by type: bulk carrier 1, cargo 5
foreign-owned: 1 (Greece 1) (2008)
Ports and terminals: Sao Tome','080613bf3b8ebe0ba5c6e009758f146193473ed2fa7f8bf0d8218d712a5b39b6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13459daa22c8a8377f5000ad43e089682c949085e23c3262d89dc3993551dc97',2010,'SA','Saudi Arabia','transportation',1354,'Airports: 215 (2008)
Airports— with paved runways: total: 79
over 3,047 m: 31
2,438 to 3,047 m: 16
1,524 to 2,437 m: 27
914 to 1,523 m: 2
under 914 m: 3 (2008)
Airports— with unpaved runways: total. 1 36
2,438 to 3,047 m: 8
1,524 to 2,437 m: 71
914 to 1,523 m: 41
under 914 m: 16 (2008)
Heliports: 8 (2007)
Pipelines: condensate 212 km; gas 1,880
km; liquid petroleum gas 1,183 km; oil
4,239 km; refined products 1,148 km
(2008)
Railways: total: 1,392 km
standard gauge: 1,392 km 1.435-m gauge
(with branch lines and sidings) (2006)
Roadways: total: 221,372 km
paved: 47,529 km (includes 3,891 km of
expressways)
unpaved: 173,843 km (2006)
Merchant marine: total. 62
by type: cargo 5 , chemical tanker 1 3, container
5, passenger/cargo 8, petroleum tanker
20, refrigerated cargo 3, roll on/roll off 8
foreign-owned: 12 (Egypt 1, Greece 3,
Kuwait 7, UAE 1)
registered in other countries: 71 (Bahamas
16, Comoros 1, Dominica 2, France 1,
Liberia 27, Marshall Islands 5, Norway 3,
Panama 16) (2008)
Ports and terminals: Ad Dammam, A1
Jubayl, Jiddah, Yanbu’ al Sinaiyah','837fd569a3026646ffc3286a4bc78b12922ea9a89ce275541e8a6b1582e7e613','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b4371fa993e5859828608124c050f6c2f0273359f3e69501e8b11f728c75179',2010,'RS','Serbia','transportation',1362,'Airports: 39 (2007)
Airports— with paved runways: total 16
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
91 4 to 1,523 m: 2
under 914 m: 4 (2007)
Airports — with unpaved runways: total: 23
1,524 to 2,437 rn: 2
914 to 1,523 m: 9
under 914 m: 12 (2007)
Heliports: 2 (2007)
Pipelines: gas 1,921 km; oil 393 km
(2007)
Railways: total: 3,379 km
standard gauge: 3,379 km 1.435-m gauge
(electrified 1,254 km) (2006)
Roadways:
total: 36,875 km
paved: 31,392 km
unpaved: 5,483 km
note: roadways in Kosovo listed separately
(2006)
Waterways: 587 km (primarily on Danube
and Sava rivers) (2005)','221498e75ce9ebc99120ba3d75bdba16ca1efaf651699165cf97bbeb6ea96dd5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e186c1c830e5c56923fd1b95c860cebec029645c8b82f7ce749a6d345086e5ee',2010,'SC','Seychelles','transportation',1369,'Airports: 15 (2008)
Airports — with paved runways: total: 9
2,438 to 3,047 m : 1
914 to 1,523 m: 6
under 914 m: 2 (2008)
Airports— with unpaved runways: total: 6
914 to 1,523 m: 2
under 914 m: 4 (2008)
Roadways: total: 458 km
paved: 440 km
unpaved: 18 km (2003)
Merchant marine: total: 8
by type: cargo 1 , carrier 1 , chemical tanker 6
foreigmovuned: 3 (Flong Kong 1, Nigeria 1,
South Africa 1 ) (2008)
Ports and terminals: Victoria','bd040e19c2404ec8c1e09dfd1efc10ac0b10c1788449ccb3220492cd4cb55f49','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f8cbdd53deed65519ea6e7aebc037a0101bfe683ca795cf8692c08bde6712b6',2010,'SG','Singapore','transportation',1378,'Airports: 10 (2008)
Airports— with paved runways:
total: 1
over 3,047 m: 1 (2008)
Airports— with unpaved runways: total: 9
914 to 1,523 m: 7
under 914 m: 2 (2008)
Heliports:
2 (2007)
Roadways:
total: 1 1 ,300 km
paved: 904 km
unpaved: 10,396 km (2002)
Waterways:
800 km (600 km year round) (2007)
Merchant marine: total: 182
by type: bulk carrier 4, cargo 143, carrier
2, chemical tanker 3, container 6, liquefied
gas 2, passenger 1, passenger/cargo 6,
petroleum tanker 10, roll on/roll ofif 3,
specialized tanker 2
foreign-owned: 95 (Belgium 1, China 15,
Egypt 3, Greece 1 , Hong Kong 1 , Lebanon
1, Nigeria 1, Panama 1, Romania 3,
Russia 11, Syria 18, Taiwan 1, Turkey 15,
Ukraine 10, UAE 8, UK 2, US 1, Yemen
2) (2008)
Ports and terminals: Freetown, Pepel,
Sherbro Islands
Airports: 8 (2008)
Airports — with paved runways: total: 8
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2008)
Pipelines:
gas 106 km (2008)
Roadways:
total: 3,262 km
paved: 3,262 km (includes 150 km of
expressways) (2006)
Merchant marine: total: 1,292
by type: bulk carrier 167, cargo 87, carrier 5,
chemical tanker 209, container 273, lique¬
fied gas 96, petroleum tanker 386, refriger¬
ated cargo 5, roll on/roll off 4, specialized
tanker 7, vehicle carrier 53
foreign-oivned: 774 (Australia 12, Bangla¬
desh 2, Belgium 8, Chile 6, China 14,
Cyprus 1 , Denmark 87, France 1 , Germany
609
THE CIA WORLD FACTBOOK
24, Greece 15, Hong Kong 47, India 13,
Indonesia 66, Italy 5, Japan 131, South
Korea 3, Malaysia 27, Norway 143, Slovenia
1, Sweden 20, Switzerland 2, Taiwan 72,
Thailand 23, UAE 12, UK 17, US 22)
registered in other countries: 331 (Australia 1 ,
Bahamas 17, Belize 2, Bolivia 1, Cambodia
4, Cayman Islands 10, Comoros 1, Cyprus
3, Dominica 7, France 2, Honduras 12,
Hong Kong 18, Indonesia 27, Isle of Man
1, Kiribati 4, Liberia 32, Malaysia 16,
Marshall Islands 18, Mongolia 9, Norway
1, Panama 100, Philippines 1, Saint Kitts
and Nevis 1 , Saint Vincent and the Grena¬
dines 4, Thailand 2, Tuvalu 23, US 12,
unknown 2) (2008)
Ports and terminals:
Transportation — note: the International
Maritime Bureau reports the territorial
and offshore waters in the South China
Sea as high risk for piracy and armed
robbery against ships; numerous commer¬
cial vessels have been attacked and hijacked
both at anchor and while underway;
hijacked vessels are often disguised and
cargo diverted to ports in East Asia; crews
have been murdered or cast adrift','6fc7235140033cf57f9da01c73c2244f59a182d7d884e105cfad5c8725479d08','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf7db1dd216859656c1f9239acead88f1bab9874e702c140acbb4ae8f7924877',2010,'SI','Slovenia','transportation',1388,'Airports: 35 (2008)
Airports— with paved runways: total: 20
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 10 (2008)
Airports — with unpaved runways: total: 15
914 to 1,523 m: 8
under 914 m: 7 (2008)
Heliports: 1 (2007)
Pipelines:
gas 6,769 km; oil 416 km (2008)
Railways:
total: 3,662 km
broad gauge: 100 km 1 .520-m gauge
standard gauge: 3,512 km 1.435-m gauge
(1,588 km electrified)
narrow gauge: 50 km (1.000-m or 0.750-m
gauge) (2006)
Roadways: total: 43,761 km
paved: 38,085 km (includes 316 km of
expressways)
unpaved: 5,676 km (2006)
Waterways: 172 km (on Danube River)
(2008)
Merchant marine: total: 51
by type: bulk carrier 5, cargo 42, refriger¬
ated cargo 4
foreigmowned: 47 (Bulgaria 6, Germany
3, Greece 2, Ireland 1, Israel 4, Italy 2,
Poland 2, Russia 1, Slovenia 1, Syria 2,
Turkey 10, Ukraine 12, UK 1) (2008)
Ports and terminals:
Bratislava, Komarno
Airports: 14 (2008)
Airports— with paved runways: total: 6
over 3,047 m: 1
616','9d9e7febbe817691e32fc109b21868c9211f0c16ad5288f051b846a73ae8a1bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029a76d30d6c5f3dc9388b8f1269e973877f680a9fe534f91010acab0f019acb',2010,'SB','Solomon Islands','transportation',1394,'2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2008)
Pipelines: gas 840 km; oil 1 1 km (2008)
Railways: total: 1,229 km
standard gauge: 1,229 km 1.435-m gauge
(504 km electrified) (2006)
Roadways: total: 38,562 km
paved: 38,562 km (includes 579 km of
expressways) (2006)
Waterways: some transport on Danube
River (2008)
Merchant marine: registered in other
countries: 29 (Antigua and Barbuda 6,
Bahamas 1, Cyprus 4, Liberia 3, Malta
4, Marshall Islands 4, Saint Vincent and
the Grenadines 5, Singapore 1, Slovakia
1) (2008)
Ports and terminals: Koper
Airports: 35 (2008)
Airports— with paved runways: total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways: total .- 33
1,524 to 2,437 m: 1
914 to 1,523 m: 8
under 914 m: 24 (2008)
Heliports: 3 (2007)
Roadways: total 1 ,360 km
paved: 33 km
unpaved: 1,327 km
note: includes 800 km of private plantation
roads (2002)
Ports and terminals: Honiara, Malloco
Bay, Viru Harbor','5115d75f3e144edf1576f82352e2cb02b288e15af059a0528b7527938815fb56','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eef4d915c7933c397b5f51a8f1d58ce2f5fd6d4fb50ff8b0b022873d91ecc8c',2010,'SO','Somalia','transportation',1404,'Airports: 59 (2008)
Airports — with paved runways: total: 7
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways: total: 52
2,438 to 3,047 m: 4
1,524 to 2,437 m: 19
914 to 1,523 m: 23
under 914 m: 6 (2008)
Roadways:
total: 22,100 km
paved: 2,608 km
unpaved: 19,492 km (2000)
Merchant marine: total: 1
by type: cargo 1
foreignovuned: 1 (UAE 1) (2008)
Ports and terminals: Berbera, Kismaayo
Transportation — note: the International
Maritime Bureau reports the territo¬
rial and offshore waters in the Gulf of
Aden and Indian Ocean are high risk for
piracy and armed robbery against ships;
numerous vessels, including commercial
shipping and pleasure craft, have been
attacked and hijacked both at anchor and
while underway; crew, passengers, and
cargo are held for ransom','e31cdec872d7d36ae80fcc1dd678d2efd8be639b3a3ef029e494d4c8baf01372','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90f8bf3f63e4a08162e98642f7ba3513d5600837994e7013ef6c8ccca19766c4',2010,'ZA','South Africa','transportation',1408,'Airports: 636 (2008)
Airports— with paved runways: total: 146
over 3,047 m: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m: 52
914 to 1,523 m: 66
under 914 m: 13 (2008)
Airports— with unpaved runways:
total: 490
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 31
914 to 1,523 m: 312
under 914 m: 145 (2008)
Heliports:
1 (2007)
Pipelines:
condensate 11 km; gas 908 km; oil 980
km; refined products 1,379 km (2008)
Railways:
total: 20,872 km
narrow gauge: 20,436 km 1.065-m gauge
(8,931 km electrified); 436 km 0.61 0-m
gauge (2006)
Roadways:
total: 362,099 km
paved: 73,506 km (includes 239 km of
expressways)
unpaved: 288,593 km (2002)
Merchant marine: total: 3
by type: container 1, petroleum tanker 2
foreign-owned: 1 (Denmark 1)
registered in other countries: 8 (Bahamas 1,
Nigeria 1, NZ 1, Saint Vincent and the
Grenadines 1 , Seychelles 1 , UK 3) (2008)
Ports and terminals: Cape Town,
Durban, Port Elizabeth, Richards Bay,
Saldanha Bay','c94b06adcdefe8c1b6a6e13d3b33368490f8bbb041b5bc591ba16f0ebe19a8cc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6b5814049175d61e62139bc07d0f195afa596747c20e2c43e3fb585571cb8f3',2010,'ES','Spain','transportation',1417,'Ports and terminals: McMurdo, Palmer,
and offshore anchorages in Antarctica
note: few ports or harbors exist on southern
side of Southern Ocean; ice conditions limit
use of most to short periods in midsummer;
even then some cannot be entered without
icebreaker escort; most Antarctic ports are
operated by government research stations
and, except in an emergency, are not open
to commercial or private vessels; vessels
in any port south of 60 degrees south are
subject to inspection by observers under
Article 7 of the Antarctic Treaty; The
Flydrographic Committee on Antarctica
(HCA), a special hydrographic commission
of International Flydrographic Organiza¬
tion (IHO), is responsible for hydrographic
surveying and nautical charting matters in
Antarctic Treaty area; it coordinates and
facilitates provision of accurate and appro¬
priate charts and other aids to navigation
in support of safety of navigation in region;
membership of HCA is open to any IHO
Member State whose government has
of dictator Francisco FRANCO in 1975,
and rapid economic modernization (Spain
joined the EU in 1986) gave Spain a
dynamic and rapidly growing economy and
made it a global champion of freedom and
human rights. The government continues
to battle the Basque Fatherland and Liberty
(ETA) terrorist organization, but its major
focus for the immediate future will be on
measures to reverse the severe economic
recession that started in mid-2008.
Airports: 154 (2008)
Airports— with paved runways: total: 96
over 3,047 m: 18
2,438 to 3,047 m: 12
1,524 to 2,437 m: 18
914 to 1,523 m: 24
under 914 m: 24 (2008)
Airports— with unpaved runways: total: 58
1,524 to 2,437 m: 2
914 to 1,523 m: 17
under 914 m: 39 (2008)
Heliports: 8 (2007)
Pipelines: gas 7,738 km; oil 560 km;
refined products 3,445 km (2008)
Railways: total: 14,974 km
broad gauge: 11,919 km 1.668-m gauge
(6,950 km electrified)
standard gauge: 1,099 km 1.435-m gauge
(1 ,054 km electrified)
narrow gauge: 1,928 km 1.000-m gauge
(815 km electrified); 28 km 0.91 4-m gauge
(28 km electrified) (2006)
Roadways: total: 681,224 km
paved: 681,224 km (includes 13,872 km of
expressways) (2006)
632
SPRATLY ISLANDS
Waterways: 1 ,000 km (2008)
Merchant marine: total: 158
by type: bulk carrier 9, cargo 14, chemical
tanker 11, container 22, liquefied gas 11,
passenger 1, passenger/cargo 47, petro¬
leum tanker 16, refrigerated cargo 5,
roll on/roll off 15, specialized tanker 2,
vehicle carrier 5
foreign-owned: 26 (Canada 4, Denmark
2, Germany 5, Italy 2, Mexico 3,
Norway 5, UK 5)
registered in other countries: 110 (Angola 1,
Argentina 2, Bahamas 14, Belize 1, Brazil
9, Cape Verde 1 , Cuba 1 , Cyprus 6, Malta
3, Marshall Islands 1, Nigeria 1, Panama
50, Portugal 11, Saint Kitts and Nevis 1,
UK 1, Uruguay 6, Venezuela 1) (2008)
Ports and terminals: Algeciras, Barcelona,
Bilbao, Cartagena, Huelva, Tarragona,
Valencia
Airports: 4 (2008)
Airports — with paved runways: total: 3
914 to 1,523 m: 2
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 1
914 to 1,523 m: 1 (2008)
Heliports: 3 (2007)
Ports and terminals:
none; offshore anchorage only
Airports: 6 (2008)
Airports — with paved runways: total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Airports— with unpaved runways: total: 3
914 to 1,523 m: 1
under 914 m: 2 (2008)
Pipelines: gas 659 km; oil 336 km (2008)
Roadways: total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (2000)
Merchant marine: total. 9
by type: passenger 2, passenger/cargo 5,
petroleum tanker 2
foreign-owned: 1 (US 1)
registered in other countries: 2 (Bahamas 1,
unknown 1) (2008)
Ports and terminals: Point Fortin, Point
Li Us, Port-of-Spain','ab3ebd4e19d89c8e4154a581e30c780e4c19fba982ef468f104a06af32571b6f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff13d13fd13bb8bbd4f1eb5cd2507fa9260d4d9c3e1e2785f13d742b5dd56a3d',2010,'SD','Sudan','transportation',1425,'Airports: 18 (2008)
Airports — with paved runways: total: 14
over 3,047 m: 1
1,524 to 1,437 m: 6
914 to 1,523 m: 7 (2008)
Airports — with unpaved runways: total: 4
914 to 1,523 m: 1
under 914 m: 3 (2008)
Railways: total: 1,449 km
broad gauge: 1,449 km 1.676-m gauge
(2006)
Roadways:
total: 97,286 km
paved: 78,802 km
unpaved: 18,484 km (2003)
Waterways: 1 60 km (primarily on rivers in
southwest) (2008)
Merchant marine: total 26
by type: bulk carrier 4, cargo 18, chemical
tanker 1, container 1, petroleum tanker 2
foreign-owned: 5 (Germany 5)
registered in other countries: 1 (Panama 1)
(2008)
Ports and terminals: Colombo
Airports: 109 (2008)
Airports — with paved runways: total: 17
over 3,047 m: 3
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4
under 914 m: 1 (2008)
Airports — with unpaved runways: total. 92
1,524 to 2,437 m: 18
914 to 1,523 m: 43
under 914 m: 31 (2008)
Heliports: 4 (2007)
Pipelines: gas 156 km; oil 4,070 km;
refined products 1,613 km (2008)
Railways: total 5,978 km
narrow gauge: 4,578 km 1.067-m gauge;
1,400 km 0.600-m gauge for cotton
plantations (2006)
Roadways: total 1 1 ,900 km
paved: 4,320 km
unpaved: 7,580 km (2000)
Waterways: 4,068 km (1 ,723 km open year
round on White and Blue Nile rivers) (2008)
Merchant marine: total 3
by type: cargo 2, carrier 1 (2008)
Ports and terminals: Port Sudan','e4c5d6349f8c45a7dcbb65999db67998922a54ae7134e734ac7caf8a8a98420a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d16c8a0b5788d441708c8bbba7c4efc91f5108590da37213da64db49ed6ede95',2010,'SR','Suriname','transportation',1437,'Airports: 50 (2008)
Airports— with paved runways: total: 5
over 3,047 m: 1
under 914 m: 4 (2008)
Airports— with unpaved runways: total. 45
914 to 1,523 m: 5
under 914 m: 40 (2008)
Pipelines: oil 50 km (2008)
Roadways: total 4,304 km
paved: 1,130 km
unpaved: 3,174 km (2003)
Waterways: 1 ,200 km (most navigable by
ships with draffs up to 7 m) (2008)
Merchant marine: total 1
by type: cargo 1 (2008)
Ports and terminals:
Paramaribo, Wageningen
Airports: 4 (2008)
Airports— with paved runways: total: 1
2,438 to 3,047 m: 1 (2008)
Airports — with unpaved runways: total: 3
under 914 m: 3 (2008)
Heliports: 1 (2007)
Ports and terminals: Barentsburg, Long¬
yearbyen, Ny-Alesund, Pyramiden
Airports:
16 (2008)
Airports— with paved runways: total: 1
2,438 to 3,047 m: 1 (2008)
Airports— with unpaved runways: total: 15
914 to 1,523 m: 7
under 914 m: 8 (2008)
Railways:
total: 301 km
n&rrow gauge : 301 km 1 ,067-m gauge
(2006)
Roadways:
total: 3,594 km
paved: 1 ,078 km
unpaved: 2,516 km (2002)','985122ea4b3ad6cbc7f849c14087b23a24a23312ee363704cdd70a728e434ecc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a39feef9502466d66206b7035f468e16f3d994eafe209762cb090c34e2edb6a0',2010,'TJ','Tajikistan','transportation',1445,'Airports: 26 (2008)
Airports — with paved runways:
total: 18
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 3 (2008)
Airports — with unpaved runways: total: 8
914 to 1 ,523 m: 1
under 914 m: 7 (2008)
Pipelines: gas 549 km; oil 38 km (2008)
Railways: total: 482 km
broad gauge: 482 km 1.520-m gauge (2006)
Roadways: total: 27,767 km (2000)
Waterways: 200 km (along Vakhsh River)
(2008)
Airports: 124 (2008)
Airports — with paved runways: total: 9
over 3.047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 1 (2008)
Airports— with unpaved runways:
total: 115
1,524 to 2,437 m: 18
914 to 1,523 m: 63
under 914 m: 34 (2008)
Pipelines: gas 253 km; oil 888 km; refined
products 8 km (2008)
Railways: total: 3,690 km
narrow gauge: 969 km 1 .067-m gauge;
2,721 km 1.000-m gauge (2006)
Roadways: total: 78,891 km
paved: 6,808 km
unpaved: 72,083 km (2003)
Waterways: Lake Tanganyika, Lake
Victoria, and Lake Nyasa principal avenues
of commerce with neighboring countries;
rivers not navigable (2007)
Merchant marine: total: 9
by type: cargo 1, passenger/cargo 4, petro¬
leum tanker 4
registered in other countries: 1 (Honduras 1)
(2008)
Ports and terminals: Dar es Salaam
Transportation— note: the International
Maritime Bureau reports the territorial and
offshore waters in the Indian Ocean are
high risk for piracy and armed robbery
against ships; numerous commercial vessels
have been attacked and hijacked both at
anchor and while underway; crews have
been robbed and stores or cargoes stolen','477e4dfb288ea208a9c14914de7cc42cfb5be19766293307e9b6f2d0340873f9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72b33b1c8f5b500bcd0863be9cf2c84c44cecd2c3e9dfe828d42a92b3d6f6a8e',2010,'TL','Timor-Leste','transportation',1447,'Airports: 104 (2008)
Airports — with paved runways: total: 64
over 3,047 m: 8
2,438 to 3,047 m: 11
1,524 to 2,437 m: 24
914 to 1,523 m: 15
under 914 m: 6 (2008)
Airports — with unpaved runways:
total: 40
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m: 26 (2008)
Heliports: 3 (2007)
Pipelines: gas 1 ,348 km; refined products
323 km (2008)
Railways: total: 4,071 km
narrow gauge: 4,071 km 1.000-m gauge
(2006)
Roadways: total: 180,053 km (includes
450 km of expressways) (2006)
Waterways: 4,000 km
note: 3,701 km navigable by boats with
drafts up to 0.9 m (2008)
Merchant marine: total: 398
by type: bulk carrier 53, cargo 135, chem¬
ical tanker 15, container 22, liquefied gas
28, passenger/cargo 10, petroleum tanker
100, refrigerated cargo 32, specialized
tanker 2, vehicle carrier 1
foreign-owned: 1 6 (China 1 .Japan 4, Malaysia
3, Singapore 2, Taiwan 1, UK 5)
registered in other countries: 40 (Bahamas
5, Mongolia 1, Panama 10, Singapore 23,
Tuvalu 1) (2008)
Ports and terminals: Bangkok, Laem
Chabang, Prachuap Port, Si Racha
Airports: 6 (2008)
Airports — with paved runways: total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Airports — with unpaved runways: total: 4
914 to 1,523 m: 2
under 914 m: 2 (2008)
Heliports: 9 (2007)
Roadways: otab 6,040 km
paved: 2,600 km
unpaved: 3,440 km (2005)
Merchant marine: total: 1
by type: passenger/cargo 1 (2008)
Ports and terminals: Dili','414474712b361775d2c8ff9f691c176203be112d18d72c4fb2e2e9ef077636dd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ec490b16b2728a07478b41b2e3dc3bf698fd4dce5d140110caa0b3b9e45edba',2010,'TK','Tokelau','transportation',1459,'Airports: 8 (2008)
Airports— with paved runways: total: 2
2,438 to 3,047 m: 2 (2008)
Airports — with unpaved runways:
total: 6
914 to 1,523 m: 4
under 914 m: 2 (2008)
Railways: total: 568 km
narrow gauge : 568 km 1 .000-m gauge (2006)
Roadways: total: 7,520 km
paved: 2,376 km
unpaved: 5,144 km (2000)
Waterways: 50 km (seasonally on Mono
River depending on rainfall) (2008)
Merchant marine: total: 10
by type: cargo 9, refrigerated cargo 1
foreign-owned: 6 (Bangladesh 1 , Denmark 1 ,
Egypt 1 , Lebanon 1 , Syria 2) (2008)
Ports and terminals: Kpeme, Lome','3a42e336ee980dd4b33035988d5fd32dbd21cd7e88fa7831eca895e7addfbdf9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e2a7c97db48fd00b03d64f446c28fdbffdbada1b2a6cc1b6759914669eca29b',2010,'TO','Tonga','transportation',1466,'Ports and terminals: none; offshore
anchorage only
Military — note: defense is the responsi¬
bility of New Zealand
Airports: 6 (2008)
Airports — with paved runways: total: 1
2,438 to 3,047 m: 1 (2008)
Airports— with unpaved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2008)
Roadways:
total: 680 km
paved: 1 84 km
unpaved: 496 km (2000)
Merchant marine:
total: 13
by type: bulk carrier 1, cargo 8, carrier 1,
liquefied gas 1 , passenger/ cargo 1 , refriger¬
ated cargo 1
foreign-owned: 4 (Australia 1, Cyprus 1,
Switzerland 1, UK 1) (2008)
Ports and terminals: Nuku alofa','a3d15de506b597b3a2f6f9982a4a9e103004496d0f2e61479c667279b07aaef2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b6deb50ddc1c49dd9873e9c714d8ad3fd6792861318d94d8a657191caa8980b',2010,'TN','Tunisia','transportation',1477,'Airports: 30 (2008)
Airports— with paved runways:
total: 14
over 3,047 m: 3
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (2008)
Airports— with unpaved runways:
total: 16
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 7 (2008)
Pipelines: gas 2,102 km; oil 1,195 km;
refined products 372 km (2008)
Railways:
total: 2,153 km
standard gauge: 471 km 1.435-m gauge
narrow gauge: 1 ,674 km 1 .000-m gauge
(65 km electrified)
dual gauge: 8 km 1 .435 m and 1 .000-m
gauges (three rails) (2006)
689
THE CIA WORLD FACTBOOK
Roadways: total: 19,232 km
paved: 12,655 km (includes 262 km of
expressways)
unpaved: 6,577 km (2004)
Merchant marine:
total: 7
by type: bulk carrier 1, cargo 1, chemical
tanker 1 , passenger/cargo 4
registered in other countries: 1 (Panama 1)
(2008)
Ports and terminals: Bizerte, Gabes, La
Goulette, Rades, Sfax, Skhira
Airports: 103 (2008)
Airports— with paved runways: total: 90
over 3,047 m: 16
2,438 to 3,047 m: 33
1,524 to 2,437 m: 19
914 to 1,523 m: 19
under 914 m: 3 (2008)
Airports — with unpaved runways: total: 13
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 4 (2008)
Heliports: 18 (2007)
Pipelines: gas 7,555 km; oil 3,636 km
(2008)
Railways: total: 8,697 km
standard gauge: 8,697 km 1.435-m gauge
(1 ,920 km electrified) (2006)
Roadways: total: 426,951 km (includes
1,987 km of expressways) (2006)
Waterways: 1,200 km (2008)
Merchant marine: total: 612
by type: bulk carrier 101, cargo 281,
chemical tanker 70, combination ore/oil
1, container 35, liquefied gas 7, passenger
4, passenger/cargo 51, petroleum tanker
31, refrigerated cargo 1, roll on/roll off 28,
specialized tanker 2
693
THE CIA WORLD FACTBOOK
foreigmovuned: 8 (Cyprus 2, Germany 1,
Greece 1, Italy 3, UAE 1)
registered in other countries: 595 (Albania 1,
Antigua and Barbuda 6, Bahamas 8, Belize
15, Cambodia 26, Comoros 8, Dominica
5, Georgia 14, Greece 1, Isle of Man 2,
Italy 1, Kiribati 1, Liberia 7, Malta 176,
Marshall Islands 50, Moldova 3, Nether¬
lands 1, Nedierlands Antilles 10, Panama
94, Russia 80, Saint Kitts and Nevis 35,
Saint Vincent and the Grenadines 20,
Sierra Leone 15, Slovakia 10, Tuvalu
2, UK 2, unknown 2) (2008)
Ports and terminals: Aliaga, Diliskelesi,
Izmir, Kocaeli (Izmit), Mercin Limani,
Nemrut Limatii','8eb633e54a3e99463fa0ff101317e05151ae958ff165e8f96990bf49dc46536f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ed450d2ea69bf8608b23e24f9e986a169a804575c6c6335478e7697d5a8245b',2010,'TC','Turks and Caicos Islands','transportation',1485,'Airports: 28 (2008)
Airports — with paved runways: total: 22
over 3,047 m: 1
2,438 to 3,047 m: 11
1,524 to 2,437 m: 8
914 to 1,523 m: 2 (2008)
Airports— with unpaved runways: total: 6
1,524 to 2,437 m: 2
under 914 m: 4 (2008)
Heliports: 1 (2007)
Pipelines: gas 6,417 km; oil 1,457 km
(2008)
Railways: total: 2,440 km
broad gauge: 2,440 km 1.520-m gauge
(2006)
Roadways:
total : 58,592 km
paved: 47,577 km
unpaved: 11,015 km (2002)
Waterways: 1,300 km (Amu Darya and
Kara Kum canal are important inland
waterways) (2008)
Merchant marine:
total: 7
by type: cargo 4, petroleum tanker 2, refrig¬
erated cargo 1 (2008)
Ports and terminals: Turkmenbasy','88349742748711f1555f8615a54b79eae078ea8c19900306fefe6ed90d67232a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3d24bc719b00aea578563775b8b45e6e5282076381c42410cb355a49d7de7c7',2010,'TV','Tuvalu','transportation',1494,'Airports: 8 (2008)
Airports— with paved runways: total: 6
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 2 (2008)
Airports— with unpaved runways: total: 2
914 to 1,523 m: 1
under 914 m: 1 (2008)
Roadways: total. 121 km
paved: 24 km
unpaved: 97 km (2003)
Merchant marine: registered in other coun¬
tries: 1 (Panama 1) (2008)
Ports and terminals: Grand Turk,
Providenciales
Airports: 1 (2008)
Airports — with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total: 8 km
paved: 8 km (2002)
Merchant marine: total 80
by type: bulk carrier 7, cargo 30, chem¬
ical tanker 14, container 2, passenger 2,
passenger/cargo 1, petroleum tanker 22,
refrigerated cargo 1 , specialized tanker 1
foreign-oumed: 63 (China 16, Hong Kong
7, Kenya 1, South Korea 1, Malaysia 1,
Maldives 1 , Norway 1 , Russia 2, Singapore
23, Thailand 1, Turkey 2, Ukraine 1, US
1 , Vietnam 5) (2008)
Ports and terminals: Funafuti','76b2cd0ef3dc72cccace0a79592fbabf7b98443c1449806787577fa951919782','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a79176f5d7cbc045f2860a0d14379876aaf0c9b303287c68f8c8dd082b41273',2010,'UG','Uganda','transportation',1505,'Airports: 33 (2008)
Airports— with paved runways: total: 5
over 3,047 m: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways: total. 28
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 13
under 914 m: 8 (2008)
Railways: total 1,244 km
narrow gauge: 1,244 km 1.000-m gauge
(2006)
Roadways: total 70,746 km
paved: 16,272 km
unpaved: 54,474 km (2003)
Waterways: on Lake Victoria, 200 km
on Lake Albert, Lake Kyoga, and parts of
Albert Nile (2008)
Ports and terminals: Entebbe, Jinja, Port Bell','76aa00617c0f4eb5d2371ca07db285a747cdf17b9a7bb7d77f0c391304c22006','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d638665dd39d370ea2016f94f4015ea0baad1f05d01f0b6f107ee076b11cc7',2010,'UA','Ukraine','transportation',1513,'Airports: 434 (2008)
Airports— with paved runways: total: 193
over 3,047 m: 1 2
2,438 to 3,047 m: 53
1,524 to 2,437 m: 26
914 to 1,523 m: 6
under 914 m: 96 (2008)
Airports— with unpaved runways:
total: 241
2,438 to 3,047 m: 2
1,524 to 2,437 m: 8
914 to 1,523 m: 14
under 914 m: 217 (2008)
Heliports: 10 (2007)
Pipelines: gas 33,327 km; oil 4,514 km;
refined products 4,211 km (2008)
Railways: total: 21,852 km
broad gauge: 21,852 km 1.524-m gauge
(9,648 km electrified) (2007)
Roadways: total: 169,422 km
paved: 165,611 km (includes 15 km of
expressways)
unpaved: 3,811 km (2007)
Waterways: 2,176 km (most on Dnieper
River) (2007)
Merchant marine: total: 189
by type: bulk carrier 6, cargo 141, chem¬
ical tanker 1, container 3, passenger 6,
passenger/cargo 3, petroleum tanker
9, refrigerated cargo 11, roll on/roll off 7,
specialized tanker 2
foreignowned: 2 (Luxembourg 1, Russia 1)
registered in other countries: 204 (Belize
7, Cambodia 34, Comoros 8, Cyprus
4, Dominica 4, Georgia 18, Liberia
25, Lithuania 1, Malta 30, Moldova 5,
Mongolia 1, Panama 10, Russia 11, Saint
Kitts and Nevis 9, Saint Vincent and the
.Grenadines 11, Sierra Leone 10, Slovakia
12, Tuvalu 1, unknown 3) (2008)
Ports and terminals: Feodosiya, Kerch,
Kherson, Mariupol’, Mykolayiv, Odesa,
Yuzhnyy','210d7f64e28a508e887115db95d067eba55247d8a13ebdd04557f67c10657c28','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4990fec0c9773bf2b6d3716496bbcab2618f82a31137bc10b71feb51d17d5a3',2010,'AE','United Arab Emirates','transportation',1522,'Airports: 39 (2008)
Airports— with paved runways:
total: 22
over 3,047 m: 10
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 4
under 914 m: 2 (2008)
Airports— with unpaved runways:
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m: 5 (2008)
Heliports: 5 (2007)
Pipelines: condensate 458 km; gas 2,129
km; liquid petroleum gas 220 km; oil
1,310 km; refined products 212 km; water
90 km (2008)
Roadways: total: 4,080 km
paved: 4,080 km (includes 253 km of
expressways) (2008)
Merchant marine: total: 58
by type: bulk carrier 6, cargo 9, chemical
tanker 4, container 8, liquefied gas 1,
passenger/cargo 1 , petroleum tanker 24, roll
on/roll off 4, specialized tanker 1
foreign-owned: 14 (Denmark 1, Greece 3,
Kuwait 10)
registered in other countries: 313 (Bahamas
23, Bahrain 1, Belize 5, Cambodia 2,
Comoros 7, Cyprus 9, Dominica 1 , Georgia
1 , Gibraltar 3, Hong Kong 1 , India 6, Indo-
nesia 2, Iran 1, Jordan 13, North Korea 8,
Liberia 23, Malta 5, Marshall Islands 15,
Mexico 1, Netherlands 5, Panama 109,
Papua New Guinea 6, Philippines 1 , Saint
Kitts and Nevis 18, Saint Vincent and
the Grenadines 9, Saudi Arabia 1, ''Sierra
Leone 8, Singapore 12, Somalia 1, Turkey
1 , UK 9, unknown 6) (2008)
Ports and terminals: Mina’ Zayid (Abu
Dhabi), A1 Fujayrah, Mina’ Jabal ‘Ali
(Dubai), Mina’ Rashid (Dubai), Mina’
Saqr (Ra’s al Khaymah), Khawr Fakkan
(Sharjah)','a5cf04c6d50cd7091f3cf812942a016738eab6ebbee52d0968e9e8db583bdb4e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bf10cfa0e2affb5e3b83256b920c99678a8f283178eb03684e74b48ef24d12f',2010,'GB','United Kingdom','transportation',1529,'Airports: 510 (2008)
Airports — with paved runways: total: 312
over 3,047 m: 9
2,438 to 3,047 m: 32
1,524 to 2,437 m: 127
914 to 1,523 m: 79
under 914 m: 65 (2008)
Airports— with unpaved runways: total. 198
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 21
under 914 m: 173 (2008)
Heliports: 1 1 (2007)
Pipelines: condensate 43 km; gas 7,541
km; liquid petroleum gas 59 km; oil 699
km; refined products 4,41 7 km (2008)
Railways: total: 16,567 km
broad gauge: 303 km 1.600-m gauge (in
Northern Ireland)
standard gauge: 16,264 km 1.435-m gauge
(5,361 km electrified) (2006)
Roadways: total: 398,366 km
paved: 398,366 km (includes 3,520 km of
expressways) (2006)
Waterways: 3,200 km (620 km used for
commerce) (2008)
Merchant marine: total 518
by type: bulk carrier 33, cargo 67, carrier 5,
chemical tanker 61, container 180, lique¬
fied gas 1 8, passenger 1 0, passenger/ cargo
67, petroleum tanker 23, refrigerated cargo
12, roll on/roll off 24, vehicle carrier 18
foreign-oumed: 264 (Cyprus 2, Denmark
62, Finland 1, France 23, Germany 76,
Flong Kong 2, Ireland 1, Italy 5, Japan 4,
NZ 1, Norway 31, South Africa 3, Spain
1, Sweden 17, Switzerland 1, Taiwan 11,
Turkey 2, UAE 9, US 12)
registered in other countries: 391 (Algeria 11,
Antigua and Barbuda 9, Argentina 4, Australia
5, Bahamas 56, Barbados 9, Belize 5,
Bennuda 3, Brunei 1 , Cape Verde 1 , Cayman
Islands 3, Cyprus 19, Gibraltar 2, Greece
32, Hong Kong 39, India 2, Italy 7, South
Korea 1, Liberia 20, Luxembourg 8, Malta 19,
Marshall Islands 18, Netherlands 2, Norway
5, Panama 59, Saint Kitts and Nevis 3, Saint
Vincent and the Grenadines 14, Sierra Leone
2, Singapore 17, Slovakia 1, Spain 5, Sweden
2, Thailand 5, Tonga 1, US 1) (2008)
Ports and terminals: Dover, Felixstowe,
Immingham, Liverpool, London, South¬
ampton, Teesport (England), Forth Ports,
Hound Point (Scotland), Milford Haven
(Wales)','81c26b86b8466ce6edf0bacaa0cf009008abc5e32600d43e1c5b6c90d89b10c0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc4b1dff49c5478f4ce4f563d70609d44c0b317f0e49d098b7f6b09275fd811',2010,'UY','Uruguay','transportation',1536,'Airports: Baker Island: one abandoned
World War II runway of 1 ,665 m covered
with vegetation and unusable
Howland Island: airstrip constructed in
1937 for scheduled refueling stop on
the round-the-world flight of Amelia
EARHART and Fred NOONAN; the avia¬
tors left Lae, New Guinea, for Howland
Island but were never seen again; the
airstrip is no longer serviceable
Johnston Atoll: one closed and not main¬
tained
Kingman Reef: lagoon was used as a halfway
station between Hawaii and American
Samoa by Pan American Airways for flying
boats in 1937 and 1938
Midway Islands: 3— one operational (2,409
m paved); no fuel for sale except emergencies
Palmyra Atoll: 1—1 ,846 m unpaved runway;
privately owned (2008)
Ports and terminals: Baker, Howland, and
Jarvis Islands, and Kingman Reef: none;
offshore anchorage only
Johnston Atoll: Johnston Island
Midway Islands: Sand Island
Palmyra Atoll: West Lagoon
Airports: 56 (2008)
Airports — with paved runways: total: 9
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 2 (2008)
Airports — with unpaved runways:
total: 47
1,524 to 2,437 m: 3
914 to 1,523 m: 19
under 914 m: 25 (2008)
Pipelines: gas 226 km; oil 155 km (2008)
Railways: total: 2,073 km
standard gauge: 2,073 km 1.435-m gauge
note: 461 km have been taken out of service
and 460 km are in partial use (2006)
Roadways: total: 77,732 km
paved: 7,743 km
unpaved: 69,989 km (2004)
Waterways: 1 ,600 km (2008)
Merchant marine: total: 17
by type: cargo 3, chemical tanker 2,
passenger/cargo 9, petroleum tanker 2,
roll on/ roll off 1
foreignowned: 10 (Argentina 3, Greece 1,
Spain 6)
registered in other countries: 3 (Liberia 3)
(2008)
Ports and terminals: Montevideo','0be720227272a76470e680f58ac384f4e6861270a745154c4fdec6d8592556e6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('607da3978d02dc0448894e6c9411b0affe938d82df00f4c0c3bf2c7745889bf5',2010,'UZ','Uzbekistan','transportation',1545,'Airports: 54 (2008)
Airports — with paved runways: total: 33
over 3,047 m: 6
2,438 to 3,047 m: 13
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 4 (2008)
Airports — with unpaved runways:
total: 21
2,438 to 3,047 m: 2
under 914 m: 19 (2008)
Pipelines: gas 9,706 km; oil 868 km
(2008)
Railways: total: 3,950 km
broad gauge: 3,950 km 1.520-m gauge (620
km electrified) (2006)
Roadways: total: 86,496 km
paved: 75,511 km
unpaved: 10,985 km (2000)
Waterways: 1,100 km (2008)
Ports and terminals: Termiz (Amu Darya)','052e4407845bc13cbbcfd30f26aed355e80ce72c2c0e338c37cdd2258eadd56e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd89342ef665f7a251ca552d605612d9fc751406a4537fe5181555e202c58deb',2010,'VU','Vanuatu','transportation',1553,'Airports: 31 (2008)
Airports — with paved runways: total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2008)
Airports — with unpaved runways:
total: 28
914 to 1,523 m: 5
under 914 m: 23 (2008)
Roadways: total: 1 ,070 km
paved: 256 km
unpaved: 814 km (1999)
Merchant marine: total: 54
by type: bulk carrier 32, cargo 8, container
1, liquefied gas 2, passenger 1, petroleum
tanker 1 , refrigerated cargo 4, vehicle carrier 5
foreign-owned: 54 (Australia 2, Belgium 4,
Canada 5, Estonia 1, Greece 1, Japan 29,
Monaco 1, Poland 7, Russia 2, Switzerland
1, US 1) (2008)
Ports and terminals: Forari, Port-Vila,
Santo (Espiritu Santo)
Airports: 402 (2008)
Airports — with paved runways: total: 131
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m : 35
91 4 to 1,523 m: 64
under 914 m: 18 (2008)
Airports— with unpaved runways: total: 271
2,438 to 3,047 m: 1
1,524 to 2,437 m: 16
914 to 1,523 m: 102
under 914 m: 152 (2008)
Heliports: 2 (2007)
Pipelines: extra heavy crude 980 km; gas
5,036 km; oil 6,695 km; refined products
1,484 km; unknown 141 km (2008)
Railways: total : 682 km
standard gauge: 682 km 1 .435-m gauge (2006)
Roadways: total: 96,155 km
paved: 32,308 km
unpaved: 63,847 km (2002)
Waterways: 7,100 km
note: Orinoco River (400 km) and Lake de
Maracaibo navigable by oceangoing vessels
(2008)
Merchant marine: total: 62
by type: bulk carrier 9, cargo 16, chemical
*
tanker 3, liquefied gas 5, passenger/cargo 10,
petroleum tanker 17, refrigerated cargo 2
foreign-oumed: 12 (Chile 1, Denmark 1,
Greece 3, Mexico 5, Panama 1, Spain 1)
registered in other countries: 12 (Bahamas 1,
Panama 10, Saint Vincent and the Gren¬
adines 1) (2008)
Ports and terminals: La Guaira, Marac¬
aibo, Puerto Cabello, Punta Cardon
Transportation — note: the International
Maritime Bureau reports the territorial and
offshore waters in the Caribbean Sea as a
significant risk for piracy and armed robbery
against ships; numerous vessels, including
commercial shipping and pleasure craft,
have been attacked and hijacked both at
anchor and while underway; crews have
been robbed and stores or cargoes stolen
Airports: 44 (2008)
Airports— with paved runways: total: 37
over 3,047 m: 9
2,438 to 3,047 m: 5
1,524 to 2,437 m: 14
914 to 1,523 m: 9 (2008)
Airports— with unpaved runways: total: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 3 (2008)
Heliports: 1 (2007)
Pipelines: condensate/gas 42 km; gas 66
km; refined products 206 km (2008)
Railways: total: 2,600 km
standard gauge: 178 km 1.435-m gauge
narrow gauge: 2,169 km 1.000-m gauge
dual gauge: 253 km three-rail track combining
1.435 m and 1.000-m gauges (2006)
Roadways: total: 222,179 km
paved: 42,167 km
unpaved: 180,012 km (2004)
Waterways: 17,702 km (5,000 km navi¬
gable by vessels up to 1 .8 m draff) (2008)
Merchant marine: total: 387
by type: barge carrier 1 , bulk carrier 36, cargo
280, chemical tanker 1 2, container 14, lique¬
fied gas 6, passenger 1, passenger/cargo 1,
petroleum tanker 32, refrigerated cargo 2,
roll on/ roll off 1 , specialized tanker 1
foreign-owned: 2 (Hong Kong 1, Japan 1)
registered in other countries: 64 (Honduras
1, Liberia 4, Mongolia 23, Panama 30,
Tuvalu 5, unknown 1) (2008)
Ports and terminals: Da Nang, Hai
Phong, Ho Chi Minh City
Transportation— note: die International
Maritime Bureau reports the territorial
and offshore waters in the Soudi China
Sea as high risk for piracy and armed
robbery against ships; numerous commer¬
cial vessels have been attacked and hijacked
both at anchor and while underway;
hijacked vessels are often disguised and
cargo diverted to ports in East Asia; crews
have been murdered or cast adrift
Airports: 2 (2008)
Airports— with paved runways: total. 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2008)
Roadways: total 1,257 km (2007)
Ports and terminals: Charlotte Amalie,
Limetree Bay
Airports: 1 (2008)
Airports — with paved runways: total: 1
2,438 to 3,047 m: 1 (2008)
Ports and terminals: none; two offshore
anchorages for large ships
Transportation — note: there are no
commercial or civilian flights to and from
Wake Island, except in direct support of
island missions; emergency landing is
available','391c6a67ccf6d4cdc2585176c89f0df8fbe638e6a979eb352700bb65e1d82689','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3ee36b690df0bf64838e96a36df128c458d9aef3bda5d6d178cbb7b2c87c9f7',2010,'EH','Western Sahara','transportation',1564,'Airports: 9 (2008)
Airports — with paved runways: total: 3
2,438 to 3,047 m: 3 (2008)
Airports — with unpaved runways: total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 2 (2008)
Ports and terminals: Ad Dakhla, Cabo
Bojador, Laayoune (El Aaiun)
Airports: total airports— 49,024
top ten by passengers: Adanta (ATL)—
89,379,287; Chicago (ORD)-76, 177,855;
London (FHR)— 68,068,304; Tokyo
752
WORLD
(HND)— 66,823,414; Los Angeles
(LAX)-61 ,896,075; Paris (CDG)—
59,922,177; Dallas/Fort Worth (DFW)—
59,786,476; Frankfurt (FRA)— 54,161,856;
Beijing (PEK)-53,583,664; Madrid
(MAD)-52, 122,702
top ten by cargo (metric tons): Memphis
(MEM)— 3,840,491; Hong Kong (HKG)—
3,773,964; Anchorage (ANC)-2,825,51 1;
Shanghai (PVG)— 2,559,310; Inch’on
(ICN)— 2,555,580; Paris (CDG)-
2,297,896; Tokyo (NRT)-2,254,421;
Frankfurt (FRA)— 2,127,646; Louis''
ville (SDF)— 2,078,947; Miami (MIA)—
1,922,985 (2007)
Heliports: 1,359 (2007)
Railways: total: 1,370,782 km (2006)
Roadways: total: 68,937,575 km (2008)
Waterways: 671,886 km (2004)
Ports and terminals: top ten container ports
as measured by TwentyToot Equivalent Units
(TEUs): Singapore— 27, 935, 500; Shanghai-
26, 150, 000; Hong Kong-23,999,000;
Shenzhen (China)— 21 ,099,100; Pusan
(South Korea)— 1 3,254,703;— Rotterdam—
10,790,604; Dubai (UAE)-l 0,650,000;
Kaohsiung (Taiwan)— 1 0,256,829;
Hamburg— 9,91 7,180; Qingdao (China)—
9,462,000 (2007)','8d10017b5e2b425ff4ef74cb2926db244ee380242872d399e132d042e3438f46','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36305f4ee7f41c9a7d584f7349e47f3013ea06994bad06ac27789128060c6d4c',2010,'YE','Yemen','transportation',1572,'Airports: 54 (2008)
Airports— with paved runways: total: 17
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2008)
Airports — with unpaved runways: total: 37
over 3,047 m: 3
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 14
under 914 m: 8 (2008)
Pipelines: gas 96 km; liquid petroleum gas
22 km; oil 1,367 km (2008)
Roadways: total: 71,300 km
paved: 6,200 km
unpaved: 65,100 km (2005)
Merchant marine: total. 4
by type: cargo 1 , chemical tanker 1 , petroleum
tanker 1 , roll on/ roll off 1
registered in other countries: 1 3 (North Korea
2, Moldova 1, Panama 6, Saint Kitts and
Nevis 1, Sierra Leone 2, unknown 1)
(2008)
Ports and terminals: Aden, Hudaydah,
Mukalla
Transportation— note: the International
Maritime Bureau reports offshore waters in
the Gulf of Aden are high risk for piracy;
numerous vessels, including commercial
shipping and pleasure craft, have been
attacked and hijacked both at anchor and
while underway; crew, passengers, and
cargo are held for ransom','1bfcb7dca31b35a5ea6f271930f49258c6dae0f43914ab92fe6d09e90f555dda','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d47604b215c6c14dfd14a2940e449abd4ddf0fb9178e73528d2bc4c9c53e278',2010,'ZM','Zambia','transportation',1580,'Airports: 101 (2008)
Airports— with paved runways:
total: 9
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2008)
Airports— with unpaved runways:
total: 92
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 65
under 914 m: 22 (2008)
Pipelines: oil 771 km (2008)
Railways: total: 2,157 km
narrow gauge: 2,157 km 1.067''m gauge
note: includes 891 km of the Tanzania-
Zambia Railway Authority (TAZARA)
(2006)
Roadways: total: 91,440 km
paved: 20,117 km
unpaved: 71,323 km (2001)
Waterways: 2 ,250 km (includes Lake
Tanganyika and the Zambezi and Luapula
rivers) (2008)
Ports and terminals: Mpulungu','534b4ad0590efa61bce039cf42367209602ab53c1e3c572d161a783af4f7b15f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e355d15ed281627d2e85341d7c669bbd3506bd151d6166b5ed0bd621acc552',2010,'ZW','Zimbabwe','transportation',1589,'Airports: 227 (2008)
Airports — with paved runways:
total: 20
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 10(2008)
Airports — with unpaved runways:
total: 207
1,524 to 2,437 m: 3
914 to 1,523 m: 126
under 914 m: 78 (2008)
Pipelines: refined products 270 km (2008)
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge
(313 km electrified) (2006)
Roadways:
total: 97,267 km
paved: 18,481 km
unpaved: 78,786 km (2002)
Waterways: on Lake Kariba (2008)
Ports and terminals: Binga, Kariba','7599390d2a573411475bfcf9bb96c92bfc35f960aaff7a55ec41fe444a9629c9','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae207bf8fddc209ea0e8b604b1f8bd670752e7923b78c86e9d917fbe12be1096',2010,'','','transportation',7,'Airports:
Airports - with paved runways:
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,530 m
under 914 m
Airports - with unpaved runways:
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,530 m
under 914 m
Heliports:
Pipelines:
Railways:
total
broad gauge
standard gauge
narrow gauge
dual gauge
Roadways:
total
paved
unpaved
Waterways:
Merchant marine:
total
ships by type
foreign-owned
registered in other countries
Ports and terminals:
Transportation - note:','3590de7db24e8376786ba08333474ecf59c69d6404e1a60b64c3a05fea88c14f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95143f8288e01fe38a28110a97f91ce702469c7fdfa5cea3daa498ef657683c1',2010,'TC','Turks and Caicos Islands','transportation',30,'This category includes the entries dealing with the means for
movement of people and goods.
Transportation - note
This entry includes miscellaneous transportation information of
significance not included elsewhere.
U
Unemployment rate
This entry contains the percent of the labor force that is without
jobs. Substantial underemployment might be noted.
Urbanization
This entry provides two measures of the degree of urbanization of a
population. The first, urban population, describes the percentage of
the total population living in urban areas, as defined by the
country. The second, rate of urbanization, describes the projected
average rate of change of the size of the urban population over the
given period of time. Additionally, the World entry includes a list
of the ten largest urban agglomerations. An urban agglomeration is
defined as comprising the city or town proper and also the suburban
fringe or thickly settled territory lying outside of, but adjacent
to, the boundaries of the city.
UTC (Coordinated Universal Time)
See entry for Coordinated Universal Time.
W
Waterways
This entry gives the total length of navigable rivers, canals, and
other inland bodies of water.
Weights and Measures
This information is presented in This information is presented in <a
href = "../appendix/appendix-g.html"Appendix G: Weights and Measures
and includes mathematical notations (mathematical powers and names),
metric interrelationships (prefix; symbol; length, weight, or
capacity; area; volume), and standard conversion factors.
Y
Years
All year references are for the calendar year (CY) unless indicated
as fiscal year (FY). The calendar year is an accounting period of 12
months from 1 January to 31 December. The fiscal year is an
accounting period of 12 months other than 1 January to 31 December.
Note: Information for the US and US dependencies was complied from
material in the public domain and does not represent Intelligence
Community estimates.
======================================================================
About :: History
A Brief History of Basic Intelligence and The World Factbook
The Intelligence Cycle is the process by which information is
acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data that may
be fragmentary, contradictory, unreliable, ambiguous, deceptive, or
wrong. Intelligence is information that has been collected,
integrated, evaluated, analyzed, and interpreted. Finished
intelligence is the final product of the Intelligence Cycle ready to
be delivered to the policymaker.
The three types of finished intelligence are: basic, current, and
estimative. Basic intelligence provides the fundamental and factual
reference material on a country or issue. Current intelligence
reports on new developments. Estimative intelligence judges probable
outcomes. The three are mutually supportive: basic intelligence is
the foundation on which the other two are constructed; current
intelligence continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of country
and issue prospects for guidance of basic and current intelligence.
The World Factbook, The President''s Daily Brief, and the National
Intelligence Estimates are examples of the three types of finished
intelligence.
The United States has carried on foreign intelligence activities
since the days of George Washington but only since World War II have
they been coordinated on a government-wide basis. Three programs
have highlighted the development of coordinated basic intelligence
since that time: (1) the Joint Army Navy Intelligence Studies
(JANIS), (2) the National Intelligence Survey (NIS), and (3)The
World Factbook .
During World War II, intelligence consumers realized that the
production of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought
home to leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers. Detailed
and coordinated information was needed not only on such major powers
as Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and Marines
had to launch amphibious operations against many islands about which
information was unconfirmed or nonexistent. Intelligence authorities
resolved that the United States should never again be caught
unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office of
Naval Intelligence - ONI), and Gen. William J. Donovan (Director of
the Office of Strategic Services - OSS) decided that a joint effort
should be initiated. A steering committee was appointed on 27 April
1943 that recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish the
Joint Army Navy Intelligence Studies (JANIS). JANIS was the first
interdepartmental basic intelligence program to fulfill the needs of
the US Government for an authoritative and coordinated appraisal of
strategic basic intelligence. Between April 1943 and July 1947, the
board published 34 JANIS studies. JANIS performed well in the war
effort, and numerous letters of commendation were received,
including a statement from Adm. Forrest Sherman, Chief of Staff,
Pacific Ocean Areas, which said, "JANIS has become the indispensable
reference work for the shore-based planners."
The need for more comprehensive basic intelligence in the postwar
world was well expressed in 1946 by George S. Pettee, a noted author
on national security. He wrote in The Future of American Secret
Intelligence (Infantry Journal Press, 1946, page 46) that world
leadership in peace requires even more elaborate intelligence than
in war. "The conduct of peace involves all countries, all human
activities - not just the enemy and his war production."
The Central Intelligence Agency was established on 26 July 1947 and
officially began operating on 18 September 1947. Effective 1 October
1947, the Director of Central Intelligence assumed operational
responsibility for JANIS. On 13 January 1948, the National Security
Council issued Intelligence Directive (NSCID) No. 3, which
authorized the National Intelligence Survey (NIS) program as a
peacetime replacement for the wartime JANIS program. Before adequate
NIS country sections could be produced, government agencies had to
develop more comprehensive gazetteers and better maps. The US Board
on Geographic Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the maps.
The Hoover Commission''s Clark Committee, set up in 1954 to study the
structure and administration of the CIA, reported to Congress in
1955 that: "The National Intelligence Survey is an invaluable
publication which provides the essential elements of basic
intelligence on all areas of the world. There will always be a
continuing requirement for keeping the Survey up-to-date." The
Factbook was created as an annual summary and update to the
encyclopedic NIS studies. The first classified Factbook was
published in August 1962, and the first unclassified version was
published in June 1971. The NIS program was terminated in 1973
except for the Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with sales
through the US Government Printing Office (GPO). The Factbook was
first made available on the Internet in June 1997. The year 2010
marks the 63rd anniversary of the establishment of the Central
Intelligence Agency and the 67th year of continuous basic
intelligence support to the US Government by The World Factbook and
its two predecessor programs.
The Evolution of The World Factbook
National Basic Intelligence Factbook produced semiannually until
1980. Country entries include sections on Land, Water, People,
Government, Economy, Communications, and Defense Forces.
1981
Publication becomes an annual product and is renamed The World
Factbook. A total of 165 nations are covered on 225 pages.
1983
Appendices (Conversion Factors, International Organizations) first
introduced.
1984
Appendices expanded; now include: A. The United Nations, B. Selected
United Nations Organizations, C. Selected International
Organizations, D. Country Membership in Selected Organizations, E.
Conversion Factors.
1987
A new Geography section replaces the former separate Land and Water
sections. UN Organizations and Selected International Organizations
appendices merged into a new International Organizations appendix.
First multi-color-cover Factbook.
1988
More than 40 new geographic entities added to provide complete world
coverage without overlap or omission. Among the new entities are
Antarctica, oceans (Arctic, Atlantic, Indian, Pacific), and the
World. The front-of-the-book explanatory introduction expanded and
retitled to Notes, Definitions, and Abbreviations. Two new
Appendices added: Weights and Measures (in place of Conversion
Factors) and a Cross-Reference List of Geographic Names. Factbook
size reaches 300 pages.
1989
Economy section completely revised and now includes an Overview
briefly describing a country''s economy. New entries added under
People, Government, and Communications.
1990
The Government section revised and considerably expanded with new
entries.
1991
A new International Organizations and Groups appendix added.
Factbook size reaches 405 pages.
1992
Twenty new successor state entries replace those of the Soviet Union
and Yugoslavia. New countries are respectively: Armenia, Azerbaijan,
Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; and Bosnia and Hercegovina, Croatia, Macedonia, Serbia
and Montenegro, Slovenia. Number of nations in the Factbook rises to
188.
1993
Czechoslovakia''s split necessitates new Czech Republic and Slovakia
entries. New Eritrea entry added after it secedes from Ethiopia.
Substantial enhancements made to Geography section.
1994
Two new appendices address Selected International Environmental
Agreements. The gross domestic product (GDP) of most developing
countries changed to a purchasing power parity (PPP) basis rather
than an exchange rate basis. Factbook size up to 512 pages.
1995
The GDP of all countries now presented on a PPP basis. New appendix
lists estimates of GDP on an exchange rate basis. Communications
category split; Railroads, Highways, Inland waterways, Pipelines,
Merchant marine, and Airports entries now make up a new
Transportation category. The World Factbook is first produced on
CD-ROM.
1996
Maps accompanying each entry now present more detail. Flags also
introduced for nearly all entities. Various new entries appear under
Geography and Communications. Factbook abbreviations consolidated
into a new Appendix A. Two new appendices present a Cross-Reference
List of Country Data Codes and a Cross-Reference List of
Hydrogeographic Data Codes. Geographic coordinates added to Appendix
H, Cross-Reference List of Geographic Names. Factbook size expands
by 95 pages in one year to reach 652.
1997
The World Factbook introduced onto the Internet. A special printed
edition prepared for the CIA''s 50th anniversary. A schema or Guide
to Country Profiles introduced. New color maps and flags now
accompany each country profile. Category headings distinguished by
shaded backgrounds. Number of categories expanded to nine - the
current number - with the addition of an Introduction (for only a
few countries) and Transnational Issues (which includes
Disputes-international and Illicit drugs).
1998
The Introduction category with two entries, Current issues and
Historical perspective, expanded to more countries. Last year for
the production of CD-ROM versions of the Factbook.
1999
Historical perspective and Current issues entries in the
Introduction category combined into a new Background statement.
Several new Economy entries introduced. A new physical map of the
world added to the back-of-the-book reference maps.
2000
A new "country profile" added on the Southern Ocean. The Background
statements dramatically expanded to over 200 countries and
possessions. A number of new Communications entries added.
2001
Background entries completed for all 267 entities in the Factbook.
Several new HIV/AIDS entries introduced under the People category.
Revision begun on individual country maps to include elevation
extremes and a partial geographic grid. Weights and Measures
appendix deleted.
2002
New entry on Distribution of Family income - Gini index added.
Revision of individual country maps continued (process still
ongoing).
2003
In the Economy category, petroleum entries added for oil production,
consumption, exports, imports, and proved reserves, as well as
natural gas proved reserves.
2004
Bi-weekly updates launched on The World Factbook Web site.
Additional petroleum entries included for natural gas production,
consumption, exports, and imports. In the Transportation category,
under Merchant marine, subfields added for foreign-owned vessels and
those registered in other countries. Descriptions of the many forms
of government mentioned in the Factbook incorporated into the
Definitions and Notes.
2005
In the People category, a Major infectious diseases field added for
countries deemed to pose a higher risk for travelers. In the Economy
category, entries included for Current account balance, Investment,
Public debt, and Reserves of foreign exchange and gold. The
Transnational issues category expanded to include Refugees and
internally displaced persons. Category headings receive distinctive
colored backgrounds. These distinguishing colors are used in both
the printed and online versions of the Factbook. Size of the printed
Factbook reaches 702 pages.
2006
In the Economy category, national GDP figures now presented at
Official Exchange Rates (OER) in addition to GDP at purchasing power
parity (PPP). Entries in the Transportation section reordered;
Highways changed to Roadways, and Ports and harbors to Ports and
terminals.
2007
In the Government category, the Capital entry significantly expanded
with up to four subfields, including new information having to do
with time. The subfields consist of the name of the capital itself,
its geographic coordinates, the time difference at the capital from
coordinated universal time (UTC), and, if applicable, information on
daylight saving time (DST). Where appropriate, a special note is
added to highlight those countries with multiple time zones. A
Trafficking in persons entry added to the Transnational issues
category. A new appendix, Weights and Measures, (re)introduced to
the online version of the Factbook.
2008
In the Geography category, two fields focus on the increasingly
vital resource of water: Total renewable water resources and
Freshwater withdrawal. In the Economy category, three fields added
for: Stock of direct foreign investment - at home, Stock of direct
foreign investment - abroad, and Market value of publicly traded
shares. Concise descriptions of all major religions included in the
Definitions and Notes. Responsibility for printing of The World
Factbook turned over to the Government Printing Office.
2009
The online Factbook site completely redesigned with many new
features. In the People category, two new fields provide information
on education in terms of opportunity and resources: School Life
Expectancy and Education expenditures. Additionally, the
Urbanization entry expanded to include all countries. In the Economy
category, five fields added: Central bank discount rate, Commercial
bank prime lending rate, Stock of money, Stock of quasi money, and
Stock of domestic credit.
2010
In order to facilitate comparisons over time, dozens of the entries
in the Economy category expanded to include two (and in some cases
three) years'' worth of data. A variety of enhancements introduced on
the Factbook Web site.
2011
Weekly updates inaugurated on the The World Factbook Web site. The
dissolution of the Netherlands Antilles results in two new listings:
Curacao and Sint Maarten. A Broadcast media field replaces the
former Radio broadcast stations and TV broadcast stations entries.
Concise descriptions of all major Legal systems incorporated into
the Definitions and Notes. In the Geography section, under Natural
hazards, a Volcanism subfield added for countries with historically
active volcanoes. In the Government category, a new National anthems
field introduced.
======================================================================
About :: Copyright and Contributors
The World Factbook is prepared by the Central Intelligence Agency
for the use of US Government officials, and the style, format,
coverage, and content are designed to meet their specific
requirements. Information is provided by Antarctic Information
Program (National Science Foundation), Armed Forces Medical
Intelligence Center (Department of Defense), Bureau of the Census
(Department of Commerce), Bureau of Labor Statistics (Department of
Labor), Central Intelligence Agency, Council of Managers of National
Antarctic Programs, Defense Intelligence Agency (Department of
Defense), Department of Energy, Department of State, Fish and
Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National
Geospatial-Intelligence Agency (Department of Defense), Naval
Facilities Engineering Command (Department of Defense), Office of
Insular Affairs (Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on Geographic Names
(Department of the Interior), US Transportation Command (Department
of Defense), Oil & Gas Journal, and other public and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA).
The official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Citation model:
The World Factbook 2009. Washington, DC: Central Intelligence
Agency, 2009.
https://www.cia.gov/library/publications/the-world-factbook/index.html
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn: Office of Public Affairs
Washington, DC 20505
Hours: Monday-Friday 8:00 AM-4:30 PM Eastern Standard Time
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
======================================================================
About :: Purchasing
Printed copies of The World Factbook may be obtained from the
following:
US Government Printing Office
732 N. Capitol St.
Washington, DC 20401
Hours: Monday-Friday 7:00 AM-6:30 PM Eastern Standard Time (EST)
Telephone: [1] (202) 512-1800; toll free: [1] (866) 512-1800
FAX: [1] (202) 512-2104
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Hours: Monday-Friday 8:00 AM-6:00 PM Eastern Standard Time (EST)
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
https://www.cia.gov/library/publications/the-world-factbook/index.html
======================================================================
Frequently Asked Questions(by category)
Answers to many frequently asked questions (FAQs) are explained in
the Definitions and Notes section inThe World Factbook. Please
review this section to see if your question is already answered
there. In addition, we have compiled the following list of FAQs to
answer other common questions.
General ::
Can you provide additional information for a specific country?
The staff cannot provide data beyond what appears in The World
Factbook. The format and information in the Factbook are tailored to
the specific requirements of US Government officials and content is
focused on their current and anticipated needs. The staff welcomes
suggestions for new entries.
How often is The World Factbook updated?
Formerly our Web site and the published Factbook were only updated
annually. In November 2001, we began more frequent online updating
and for many years bi-weekly updates were the norm. In late 2010 we
began to update the online Factbook on a weekly schedule. The CIA
discontinued publishing the printed Factbook after the 2007 edition;
subsequent annual editions have been published by the US Government
Printing Office.
Can I use some or all of The World Factbook for my Web site (book,
research project, homework, etc.)?
The World Factbook is in the public domain and may be used freely by
anyone at anytime without seeking permission. However, US Code
(Section 403m) prohibits use of the CIA seal in a manner which
implies that the CIA approved, endorsed, or authorized such use. For
any questions about your intended use, you should consult with legal
counsel. Further information on use of The World Factbook is
described on the Contributors and Copyright Information page. As a
courtesy, please cite The World Factbook when used.
Why are there discrepancies between The World Factbook''s demographic
statistics and other sources?
Although estimates and projections start with the same basic data
from censuses, surveys, and registration systems, final estimates
and projections can differ as a result of factors including data
availability, assessment, and methods and protocols.
Data availability Researchers may obtain specific country data at
different times. Estimates or projections developed before the
results of a census have been released will not be as accurate as
those that take into account new census results.
Assessment Researchers can differ in their assessment of data
quality and in their estimates based on the available country data.
They often need to adjust their estimates due to such factors as
undercounting in a census or underregistration of births or deaths.
Methods and protocols Differences in methods and protocols can
shape the way estimates and projections are made of fertility,
mortality, and international migration, and how these data are
integrated with the population data. For example, the US Census
Bureau uses a model that projects the population ahead by single
years of age, a single year at a time (population statistics used in
the Factbook are based on this model), whereas the United Nations
model projects five-year age groups forward, five years at a time.
Why doesn''t The World Factbook include information on states,
departments, provinces, etc., for each country?
The World Factbook provides national-level information on countries,
territories, and dependencies, but not subnational administrative
units within a country. A comprehensive encyclopedia might be a
source for state/province-level information.
Is it possible to access older editions of The World Factbook to do
comparative research and trend analysis?
Previous editions of the Factbook , beginning with 2000, are
available for downloading - but not browsing - on the CIA Web site.
Rehosted versions of earlier editions of the Factbook are available
for browsing, as well as for downloading, at other Internet web
sites. We urge caution, however, in attempting to create time series
by stringing together economic data - especially dollar values -
from previous editions of the Factbook . Over time, data sources,
definitions, and economic accounting methods have changed. We
occasionally have made these changes ourselves in order to provide
our readers with the best information available. Also, in the case
of dollar values, changes in relative exchange rates and prices may
make trends difficult to comprehend. Therefore, individuals should
consult additional resources when doing comparative research','013982d3995ff5c635da0f8bc44ad706893fec894a52571eab11c61b3ef6b31d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fa5efc37c56437d70b3328c36c229c4ab0380df71421959565838f49b19c038',2010,'TC','Turks and Caicos Islands','transportation',31,'or
trend analysis.
Would it be possible to set up a partnership or collaboration
between the producers of The World Factbook and other organizations
or individuals?
The World Factbook does not partner with other organizations or
individuals, but we do welcome comments and suggestions that such
groups or persons choose to provide.','700c3bd62ec36cfbfa8b05a760cee72f4d54ffc3f370e3acda5cf8a0eaca1f27','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

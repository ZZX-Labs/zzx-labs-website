SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e17deb8b97107c178dacd252baa09351179ca87341cd440c7271e5a7ca69f551',2010,'AM','Armenia','energy',215,'Exports— partners: Russia 17.5%,
Germany 14.7%, Netherlands 13.5%,
Belgium 8.7%, Georgia 7.6%, US 6.6%,
Switzerland 4.3%, Bulgaria 4.1%, Ukraine
4% (2007)
Imports: $3,546 billion f.o.b. (2008 est.)
Imports — commodities: natural gas,
petroleum, tobacco products, foodstuffs,
diamonds
Imports — partners: Russia 15.1%,
Ukraine 7.7%, Kazakhstan 7.4%, Germany
6.8%, China 6%, France 4.6%, US 4.5%,
Iraq 4.3% (2007)
Reserves of foreign exchange and gold:
$1,954 billion (31 December 2008 est.)
Debt — external:
$1,372 billion (31 December 2007 est.)
Currency (code): dram (AMD)
Currency code: AMD
Exchange rates: drams (AMD) per US
dollar— 303.93 (2008 est.), 344.06 (2007),
414.69 (2006), 457.69 (2005), 533.45
(2004)','ccdb437d8c484830fbad9c65d940ec1a4ecf98be60870e5e3cc60f5b5a954d05','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

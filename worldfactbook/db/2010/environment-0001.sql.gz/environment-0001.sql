SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7895416ce0cbc5f271ff71502f99a56417a3f209da8d531afb3d3620f76e6490',2010,'US','United States','environment',1591,'members— (8) Canada, Denmark (Greenland, Faroe Islands), Finland, Iceland, Norway, Russia, Sweden, US
permanent participants— (6) Aleut International Association, Arctic Athabaskan Council, Gwich’in Council International, Inuit Circumpolar
Conference, Russian Association of Indigenous People of the North, Saami Council
observers-(8) China, France, Germany, Italy, Netherlands, Poland, Spain, UK
ASEAN Regional Forum (ARF)
established-25 July 1994
aim-to foster constructive dialogue and consultation on political and security issues of common interest and concern
members— (26) Australia, Bangladesh, Brunei, Burma, Cambodia, Canada, China, EU, India, Indonesia, Japan, North Korea, South Korea,
Laos, Malaysia, Mongolia, NZ, Pakistan, Papua New Guinea, Philippines, Russia, Singapore, Thailand, Timor-Leste, US, Vietnam
Asian Development Bank (ADB)
established-1 9 December 1 966
aim-to promote regional economic cooperation
members— (48) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma, Cambodia, China, Cook Islands, Fiji,
Georgia, Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands,
Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Palau, Papua New Guinea, Philippines, Samoa, Singapore,
Solomon Islands, Sri Lanka, Taiwan, Tajikistan, Thailand, Timor-Leste, Tonga, Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members— (19) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Luxembourg, Netherlands,
Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
Asia-Pacific Economic Cooperation (APEC)
established- 7 November 1989
aim-to promote trade and investment in the Pacific basin
members— (21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New
Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers— ( 3) Association of Southeast Asian Nations, Pacific Economic Cooperation Council, Pacific Islands Forum Secretariat
Association of Southeast Asian Nations (ASEAN)
established-8 August 1967
aim-to encourage regional economic, social, and cultural cooperation among the non-Communist countries of Southeast Asia
members— (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
772
INTERNATIONAL ORGANIZATIONS AND GROUPS
dialogue partners— (l l) Australia, Canada, China, EU, India, Japan, South Korea, NZ, Russia, US, UNDP; note— ASEAN promotes
cooperation with Pakistan in some areas of mutual interest
observers— (1 ) Papua New Guinea
Australia Group (AG)
establisbed-June 1985
aim-to consult on and coordinate export controls related to chemical and biological weapons
members— (41) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, European
Commission, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Latvia, Lithuania, Luxembourg,
Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK,
US
Australia-New Zealand-United States Security Treaty (ANZUS)
established -1 September 1951; effective— 29 April 1952
aim-to implement a trilateral mutual security agreement, although the US suspended security obligations to NZ on 11 August 1986;
Australia and the US continue to hold annual meetings
members— (3) Australia, NZ, US
Baltic Assembly (BA)
established-12 May 1990
aim-to thoroughly discuss various cooperation issues between Baltic states
members— (3) Estonia, Latvia, Lithuania
Bank for International Settlements (BIS)
established-20 January 1930; effective— 17 March 1930
aim-to promote cooperation among central banks in international financial settlements
members— (55) Algeria, Argentina, Australia, Austria, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada, Chile, China,
Croatia, Czech Republic, Denmark, European Central Bank, Estonia, Finland, France, Germany, Greece, Hong Kong, Hungary,
Iceland, India, Indonesia, Ireland, Israel, Italy, Japan, South Korea, Latvia, Lithuania, Macedonia, Malaysia, Mexico, Netherlands, NZ,
Norway, Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Thailand, Turkey, UK, US; note— Serbia and Montenegro have separate central banks; their links with BIS are currently
under review
Bay of Bengal Initiative for Multi-Sectoral Technical and Economic Cooperation (BIMSTEC)
establisbed-June 1997
aim-to foster socio-economic cooperation among members
members— (7) Bangladesh, Bhutan, Burma, India, Nepal, Sri Lanka, Thailand
Benelux Economic Union (Benelux)
note— acronym from Belgium, Netherlands, and Luxembourg
established- 3 February 1958; effective— 1 November 1960
aim-to develop closer economic cooperation and integration
members— (3) Belgium, Luxembourg, Netherlands
Big Seven
note— membership is the same as the Group of 7
established-l 97 5
aim-to discuss and coordinate major economic policies
members— (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
Black Sea Economic Cooperation Zone (BSEC)
established- 25 June 1 992
aim-to enhance regional stability through economic cooperation
members— { 12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Serbia, Turkey, Ukraine; note—
Macedonia is in the process of joining
observers— (1 7) Austria, Belarus, Black Sea Commission, Commission of the EC, Croatia, Czech Republic, Egypt, Energy Charter
Secretariat, France, Germany, International Black Sea Club, Israel, Italy, Poland, Slovakia, Tunisia, US; note— Bosnia and Herzegovina
and Slovenia have applied for observer status
Caribbean Community and Common Market (Caricom)
es tab! is bed-4 July 1973; effective— 1 August 1973
aim-to promote economic integration and development, especially among the less developed countries
members— (15) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members— (5) Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Turks and Caicos Islands
observers— (7) Aruba, Colombia, Dominican Republic, Mexico, Netherlands Antilles, Puerto Rico, Venezuela
773
THE CIA WORLD FACTBOOK
Caribbean Development Bank (CDB)
established-l 8 October 1969; effective— 26 January 1970
aim-to promote economic development and cooperation
regional members— ( 21) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands, Cayman Islands,
Colombia, Dominica, Grenada, Guyana, Haiti, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members— (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC)
see Economic and Monetary Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC)
note— acronym from Banque de Developpement des Etats de l’Afrique Centrale
established-3 December 1975 v v
aim-to provide loans for economic development
members— (10) African Development Bank (AfDB), Cameroon, Central African States Bank (BEAC), Central African Republic, Chad,
Republic of the Congo, Equatorial Guinea, France, Gabon, Kuwait v
Central American Bank for Economic Integration (BCIE)
note— acronym from Banco Centroamericano de Integration Economico
established-l 3 December 1960 signature of Articles of Agreement; 31 May 1961 began operations
aim-to promote economic integration and development
members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members— (7) Argentina, Colombia, Dominican Republic, Mexico, Panama, Spain, Taiwan
Central American Common Market (CACM)
established-l 3 December 1960, collapsed in 1969, reinstated in 1991
aim-to promote establishment of a Central American Common Market
members— (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua; note— Panama, although not a member, pursues full regional
cooperation
Central European Initiative (CEI)
note— evolved from the Quadrilateral Initiative and the Hexagonal Initiative
established- 11 November 1989 as the Quadrilateral Initiative, 27 July 1991 became the Hexagonal Initiative, July 1992 its present name
was adopted
aim-to form an economic and political cooperation group for the region between the Adriatic and the Baltic Seas
members— (18) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary, Italy, Macedonia,
Moldova, Montenegro, Poland, Romania, Serbia, Slovakia, Slovenia, Ukraine
centrally planned economies
a term applied mainly to the traditionally Communist states that looked to the former USSR for leadership; most are now evolving toward
more democratic and market-oriented systems; also known formerly as the Second World or as the Communist countries; through the
1 980s, this group included Albania, Bulgaria, Cambodia, China, Cuba, Czechoslovakia, German Democratic Republic, Hungary, North
Korea, Laos, Mongolia, Montenegro, Poland, Romania, Serbia, USSR, Vietnam
Collective Security Treaty Organization (CSTO)
established- 7 October 2002
aim-to coordinate military and political cooperation, to develop multilateral structures and mechanisms of cooperation for ensuring
national security of the member states
members— ( 7) Armenia, Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
Colombo Plan (CP)
established- May 1950 proposal was adopted; 1 July 1951 commenced full operations
aim-to promote economic and social development in Asia and the Pacific
members— (25) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos, Malaysia,
Maldives, Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Singapore, Sri Lanka, Thailand, US, Vietnam
Common Market for Eastern and Southern Africa (COMESA)
note— formerly known as Preferential Trade Area for Eastern and Southern Africa (PTA)
established-5 November 1993
aim-recognizing, promoting and protecting fundamental human rights, commitment to the principles of liberty and rule of law,
maintaining peace and stability through the promotion and strengthening of good neighborliness, commitment to peaceful settlement of
disputes among member states
members— (19) Burundi, Comoros, Democratic Republic of the Congo, Djibouti, Egypt, Eritrea, Ethiopia, Kenya, Libya, Madagascar,
Malawi, Mauritius, Rwanda, Seychelles, Sudan, Swaziland, Uganda, Zambia, Zimbabwe
774
INTERNATIONAL ORGANIZATIONS AND GROUPS
Commonwealth (C)
note— also known as Commonwealth of Nations
established— 31 December 1931
aim-to foster multinational cooperation and assistance, as a voluntary association that evolved from the British Empire
members— (5 3) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei, Cameroon, Canada,
Cyprus, Dominica, Fiji (suspended), The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya, Kiribati, Lesotho, Malawi, Malaysia,
Maldives, Malta, Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (reinstated 2004), Papua New Guinea, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa,
Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia; note— on 7 December 2003
Zimbabwe withdrew its membership from the Commonwealth
Commonwealth of Independent States (CIS)
established-8 December 1991; effective— 21 December 1991
aim-to coordinate intercommonwealth relations and to provide a mechanism for the orderly dissolution of the USSR
members— (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,
US
US
USA
840
USA
.us
United States Minor Outlying
-
UM
UMI
581
-
.um
‘ISO includes Baker Island, Howland
Islands
65 00 N
153 00 W
Alaska, Gulf of
Pacific Ocean
58 00 N
145 00 W
Alboran Sea
Adantic Ocean
36 00 N
2 30 W
Aldabra Islands (Groupe d''Aldabra)
52 55 N
172 57 E
19 45 N
155 45 W
Hawaiian Islands
21 00 N
157 45 W
Hawar (island)
57 49 N
152 23 W
Russia
67 20 N
37 00 E
Federated States of Micronesia
6 58 N
158 13 E
Pacific Ocean
39 00 N
124 00 E
Pacific Ocean
34 00 N
129 00 E
North Korea
40 00 N
127 00 E
South Korea
37 00 N
127 30 E
28 25 N
178 20 W
57 00 N
170 00 W
46 15 N
122 12 W
49 30 N
67 00 W
Adantic Ocean
49 15 N
67 00 W
Atlantic Ocean
48 00 N
62 00 W
57 11 N
170 16 W
French Southern and Antarctic
38 43 S
77 29 E
Lands
Saigon (city; former name for Ho Chi Minh City)
Saint Brandon (Cargados Carajos Shoals)
Saint Christopher (island)
Saint Christopher and Nevis
Saint Eustatius (island)
Saint George''s (capital)
Saint George''s Channel
Saint Helena Island
Saint Helens, Mount (volcano)
Saint Helier (capital)
Saint John (city)
Saint John''s (capital)
Saint Lawrence Island
Saint Lawrence Seaway
Saint Lawrence, Gulf of
Saint Paul Island
Saint Paul Island
Saint Paul Island (lie Saint-Paul)
837
Name
THE CIA WORLD FACTBOOK
Saint Peter Port (capital)
Saint Peter and Saint Paul Rocks (Penedos de Sao Pedro e
Sao Paulo)
Saint Petersburg (city; former capital)
Saint Thomas (island)
Saint Vincent Passage
Saint-Denis (capital)
Saint-Pierre (capital)
Saipan (island)
Sak''art''velo (local name for Georgia)
Sakhalin Island (Ostrov Sakhalin)
Sakishima Islands
Sala y Gomez, Isla (island)
Salisbury (city; former name for Harare)
Salzburg (city)
Samar (island)
Samaria (region)
Samoa Islands
Samos (island)
San Ambrosio, Isla (island)
San Andres y Providencia, Archipielago (island group)
San Bernardino Strait
San Felix, Isla (island)
San Jose (capital)
San Juan (capital)
San Marino (capital)
San Salvador (capital)
Sanaa (capital)
Sandzak (region)
Santa Cruz (city)
Santa Cruz Islands
Santa Sede (local name for the Holy See)
Santiago (capital)
Santo Antao (island)
Santo Domingo (capital)
Sao Paulo (city)
Sao Pedro e Sao Paulo, Penedos de (rocks)
Sao Tiago (island)
Sao Tome (island)
Sapporo (city)
Sapudi Strait
Sarajevo (capital)
Sarawak (state)
Sardinia (island)
Sargasso Sea (region)
Sark (island)
Savage Island (former name for Niue)
Savu Sea
Saxony (region)
Schleswig-Holstein (region)
Schweiz (local German name for Switzerland)
Scopus, Mount
Scotia Sea
Scotland (region)
Scott Island
Senegambia (region; former name of confederafion of
Senegal and The Gambia)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
38 53 N
77 02 W
Southern Ocean
72 00 S
45 00 W
867
THE CIA WORLD FACTBOOK
Deva*
Hunedoara
Veiika Corica
VOJVODINA
Besjto
; Mm y
Zren\\m''m
tUs- w. c _ j
■W.I «-**■» ->* «'' •»«''•>/> C"y
Vrsac.
''''4^ ''■ tis,
\\ mm
Pancew
^Belgrade
DLobAa-lureu
Severtn
ierevo','7a3c6b6a0b9af51f2c33685a4e5133678f90915cf252440cccb7a7bc57526de4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('090fb6c14625ffabf932e10a35432aa6ceaa94d5409e8933aafd2624e0fa796a',2010,'UZ','Uzbekistan','environment',1592,'Communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the Soviet model; most of the
original and the successor states are no longer Communist; see centrally planned economies
Comuinidade dos Paises de Lingua Porfuguesa (CPLP)
establis hed-l 996
aim- to establish a forum for friendship among Portuguese-speaking nations where Portuguese is an official language
members— (8) Angola, Brazil, Cape Verde, Guinea-Bissau, Mozambique, Portugal, Sao Tome and Principe, Timor-Leste
associate observers— (3) Equatorial Guinea, Mauritius, Senegal
Coordinating Committee on Export Controls (COCOM)
established in 1949 to control the export of strategic products and technical data from member countries to proscribed destinations;
members were: Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan, Luxembourg, Netherlands, Norway,
Portugal, Spain, Turkey, UK, US; abolished 31 March 1994; COCOM members established a new organization, the Wassenaar
Arrangement, with expanded membership on 12 July 1996 that focuses on nonproliferation export controls as opposed to East-West
control of advanced technology
Council for Mutual Economic Assistance (CEMA)
note— also known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist economies and abolished 1 January 1991; members included
Afghanistan (observer), Albania (had not participated since 1961 break with USSR), Angola (observer), Bulgaria, Cuba, Czechoslovakia,
Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer), Nicaragua (observer), Poland, Romania, USSR,
Vietnam, Yemen (observer), Yugoslavia (associate)
Council of Arab Economic Unity (CAEU)
established-3 June 1957; effective— 30 May 1964
aim-to promote economic integration among Arab nations
members— (10 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria, Yemen,
Palestine Liberation Organization
Council of Europe (CE)
established-5 May 1949; effective— 3 August 1949
aim-to promote increased unity and quality of life in Europe
members— (47) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Montenegro, Netherlands, Norway, Poland, Portugal, Romania, Russia,
San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK
observers— ( 5) Canada, Holy See, Japan, Mexico, US
Council of the Baltic Sea States (CBSS)
established-6 March 1992
aim-to promote cooperation among the Baltic Sea states in the areas of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and education, and transportation and communication
members— (12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia, Lithuania, Norway, Poland, Russia, Sweden
observers— (7) France, Italy, Netherlands, Slovakia, Ukraine, UK, US
Council of the Entente (Entente)
established- 29 May 1959
aim-to promote economic, social, and political coordination
members— (5) Benin, Burkina Faso, Cote d’Ivoire, Niger, Togo
775
THE CIA WORLD FACTBOOK
countries in transition
a term used by the International Monetary Fund (IMF) for the middle group in its hierarchy of advanced economies, countries in
transition, and developing countries; IMF statistics include the following 28 countries in transition: Albania, Armenia, Azerbaijan,
Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Macedonia, Moldova, Mongolia, Montenegro, Poland, Romania, Russia, Serbia, Slovakia, Slovenia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan; note— this group is identical to the group traditionally referred to as the “former USSR/Eastern Europe” except for
the addition of Mongolia
Customs Cooperation Council (CCC)
note— see World Customs Organization (WCO)
developed countries (DCs)
the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less developed
countries (LDCs); includes the marketoriented economies of the mainly democratic nations in the Organization for Economic Cooperation
and Development (OECD), Bermuda, Israel, South Africa, and the European ministates; also known as the First World, high-income
countries, the North, industrial countries; generally have a per capita GDP in excess of $10,000 although four OECD countries and
South Africa have figures well under $10,000 and two of the excluded OPEC countries have figures of more than $10,000; the 34 DCs
are: Andorra, Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy See,
Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ, Norway, Portugal, San Marino, South
Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note— similar to the new International Monetary Fund (IMF) term “advanced
economies” that adds Hong Kong, South Korea, Singapore, and Taiwan but drops Malta, Mexico, South Africa, and Turkey
developing countries
a term used by the International Monetary Fund (IMF) for the bottom group in its hierarchy of advanced economies, countries in transition,
and developing countries; IMF statistics include the following 126 developing countries: Afghanistan, Algeria, Angola, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Cyprus, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala. Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Morocco, Mozambique, Namibia, Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda, Uruguay, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note— this category would presumably also cover the following 46 other countries that
are traditionally included in the more comprehensive group of “less-developed countries”: American Samoa, Anguilla, British Virgin
Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana,
French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands,
Puerto Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands,
Wallis and Futuna, West Bank, Western Sahara
Developing Eight (D-8)
established-1 5 June 1997
aim-to improve developing countries’ positions in the world economy, diversify and create new opportunities in trade relations, enhance
participation in decision-making at the international level, provide better standards of living
member— (8) Bangladesh, Egypt, Indonesia, Iran, Malaysia, Nigeria, Pakistan, Turkey
East African Community (EAC)
note— originally established in 1967, it was disbanded in 1977
established-January 2001
aim-to establish a political and economic union among the countries
members— (5) Burundi, Kenya, Rwanda, Tanzania, Uganda
East African Development Bank (EADB)
established-6 June 1967; effective— 1 December 1967
aim-to promote economic development
members— (4) Kenya, Rwanda, Tanzania, Uganda
East Asia Summit (EAS)
established-1 4 December 2005
aim-to promote cooperation in political and security issues; to promote development, financial stability, energy security, economic integration
and growth; to eradicate poverty and narrow the development gap in East Asia, and to promote deeper cultural understanding
776
INTERNATIONAL ORGANIZATIONS AND GROUPS
members— (16) Australia, Brunei, Burma, Cambodia, China, India, Indonesia, Japan, South Korea, Laos, Malaysia, NZ, Philippines,
Singapore, Thailand, Vietnam
Economic and Monetary Community of Central Africa (CEMAC)
note— was formerly the Central African Customs and Economic Union (UDEAC)
established-8 December 1964; effective— 1 January 1966
aim-to promote the establishment of a Central African Common Market
members— (6) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, Gabon
Economic and Monetary Union (EMU)
note— an integral part of the European Union; also known as the European Economic and Monetary Union
established- 1-2 December 1969 (proposed at summit conference of heads of government; 7 February 1992 (Maastricht Treaty signed)
aim-to promote a single market by creating a single currency, the euro; timetable— 2 May 1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and stock exchanges begin using euros; 1 January 2002: the euro goes into circulation; 1 July
2002 local currencies no longer accepted
members— (16) Austria, Belgium, Cyprus, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Malta, Netherlands, Portugal,
Slovakia, Slovenia, Spain
Economic and Social Council (ECOSOC)
established-26 June 1945; effective— 24 October 1945
aim-to coordinate the economic and social work of the UN; includes five regional commissions (Economic Commission for Africa,
Economic Commission for Europe, Economic Commission for Latin America and the Caribbean, Economic and Social Commission
for Asia and the Pacific, Economic and Social Commission for Western Asia) and nine functional commissions (Commission for Social
Development, Commission on Human Rights, Commission on Narcotic Drugs, Commission on the Status of Women, Commission
on Population and Development, Statistical Commission, Commission on Science and Technology for Development, Commission on
Sustainable Development, and Commission on Crime Prevention and Criminal Justice)
members— (54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL)
note— acronym from Communaute Economique des Pays des Grands Lacs
established-20 September 1976
aim-to promote regional economic cooperation and integration
members— (3)Burundi,DemocraticRepublicoftheCongo, Rwanda; note— organizationcollapsedbecauseoffightingin 1998; reactivated in 2006
Economic Community of West African States (ECOWAS)
established-28 May 1975
aim-to promote regional economic cooperation
members— (15) Benin, Burkina Faso, Cape Verde, Cote d’Ivoire, The Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger,
Nigeria, Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO)
established-27''29 January 1985
aim-to promote regional cooperation in trade, transportation, communications, tourism, cultural affairs, and economic development
members— (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
Eurasian Economic Community (EAEC or EurasEC)
note— merged with Central Asian Cooperation Organization (CACO) in 2005
established- May 2001
aim-to create a common economic and energy policy
members— (6) Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
observers— (3) Armenia, Moldova, Ukraine
Euro-Atlantic Partnership Council (EAPC)
note— began as the North Adantic Cooperation Council (NACC); an extension of NATO
established-8 November 1991; effective— 20 December 1991
aim-to discuss cooperation on mutual political and security issues
members— (50) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Montenegro, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and Development (EBRD)
established-8''9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim-to facilitate the transition of seven centrally planned economies in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland,
Romania, former USSR, and former Yugoslavia) to market economies by committing 60% of its loans to privatization
777
THE CIA WORLD FACTBOOK
members— (63) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EC, European Investment Bank (EIB), Estonia, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Malta, Mexico, Moldova, Mongolia, Montenegro, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Community (or European Communities, EC)
established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal and Steel Community
(ECSC), the European Economic Community (EEC or Common Market), and to establish a completely integrated common market and
an eventual federation of Europe; merged into the European Union (EU) on 7 February 1992; member states at the time of merger were
Belgium, Denmark, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
established-A January 1 960; effective— 3 May 1 960 v "
aim-to promote expansion of free trade
members— (4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB)
established-25 March 1957; effective— 1 January 1958
aim-to promote economic development of the EU and its predecessors, the EEC and the EC
members— (27) Austria, Belgium, Bulgaria, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, UK
European Organization for Nuclear Research (CERN)
note— acronym retained from the predecessor organization Conseil Europeenne pour la Recherche Nucleaire
established-l July 1953; effective— 29 September 1954
aim-to foster nuclear research for peaceful purposes only
members— (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Italy, Netherlands,
Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers— (8) EC, India, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific, and Cultural Organization (UNESCO), US
European Space Agency (ESA)
established-31 May 1975
aim-to promote peaceful cooperation in space research and technology
members— { 17) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands, Norway,
Portugal, Spain, Sweden, Switzerland, UK
cooperating states— (5) Canada, Czech Republic, Hungary, Poland, Romania
European Union (EU)
note— see European Union entry at the end of the “country” listings
First World
another term for countries with advanced, industrialized economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO)
established- 16 October 1945
aim-to raise living standards and increase availability of agricultural products; a UN specialized agency
members— (192) includes all UN member countries except Brunei, Liechtenstein, and Singapore (189 total); plus Cook Islands, EC, Faroe
Islands, and Niue
former Soviet Union (FSU)
former term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of 15 countries consists of:
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less developed
countries (LDCs); these countries are in political and economic transition and may well be grouped differendy in the near future; this
group of 27 countries consists of: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic,
Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Poland, Romania, Russia, Slovakia, Slovenia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan, Yugoslavia; this group is identical to the IMF group “countries in transition” except for
the IMF’s inclusion of Mongolia
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also known as the
Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are included in the IMF’s “advanced
economies” group
778
INTERNATIONAL ORGANIZATIONS AND GROUPS
Franc Zone (FZ)
note— also known as Conference des Ministres des Finances des Pays de la Zone Franc
established- 1 964
aim-to form a monetary union among countries whose currencies were linked to the French franc
members— (16) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo, Cote d’Ivoire,
Equatorial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members included Angola, Botswana,
Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT)
see the World Trade Organization (WTO)
General Confederation of Trade Unions (GCTU)
established-l 6 April 1992
aim-to consolidate trade union actions to protect citizens’ social and labor rights and interests, to help secure trade unions’ rights and
guarantees, and to strengthen international trade union solidarity
members— (11) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan, Ukraine, Uzbekistan
Group of 2 (G-2)
informal term that came into use about 1986; to facilitate bilateral economic cooperation between the two most powerful economic giants;
members were Japan, US
Group of 3 (G-3)
estabiisKed-September 1990
aim-mechanism for policy coordination
members— (2) Colombia, Mexico; note— Panama shows interest in joining
Group of 5 (G-5)
established-22 September 1985
aim-to coordinate the economic policies of five major noncommunist economic powers
members— (5) France, Germany, Japan, UK, US
Group of 6 (G-6)
also known as Groupe des Six Sur le Desarmement (not to be confused with the Big Six) was established in 22 May 1 984 with the aim
of achieving nuclear disarmament; its members were Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7)
note— membership is the same as the Big Seven
established-22 September 1985
aim-to facilitate economic cooperation among the seven major noncommunist economic powers
members— ( 7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 8 (G-8)
established-October 1975
aim-to facilitate economic cooperation among the developed countries (DCs) that participated in the Conference on International
Economic Cooperation (CIEC), held in several sessions between December 1975 and 3 June 1977
members— (8) Canada, France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9)
established-NA
aim- to discuss matters of mutual interest on an informal basis
members— (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Serbia, Sweden
Group of 10 (G-10)
note— also known as the Paris Club; includes the wealthiest members of the IMF who provide most of the money to be loaned and act as
the informal steering committee; name persists despite increased membership
established-October 1962
aim-to coordinate credit policy
members— (11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
observers— (4) BIS, EU, IMF, OECD
Group of 11 (G-l 1)
note— also known as the Cartagena Group
established in 21-22 June 1984, in Cartagena, Colombia, aim was to provide a forum for largest debtor nations in Latin America;
members were: Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico, Peru, Uruguay, Venezuela
779
THE CIA WORLD FACTBOOK
Group of 15 (G-15)
note— byproduct of the Nonaligned Movement; name persists despite increased membership
establisKed-September 1 989
aim-to promote economic cooperation among developing nations; to act as the main political organ for the Nonaligned Movement
members— (18) Algeria, Argentina, Brazil, Chile, Egypt, India, Indonesia, Iran, Jamaica, Kenya, Malaysia, Mexico, Nigeria, Peru, Senegal,
Sri Lanka, Venezuela, Zimbabwe
Group of 20 (G-20)
established-created 1999; inaugurated 15-16 December 1999
aim-to promote open and constructive discussion between industrial and emerging-market countries on any issues related to global
economic stability; helps to support growth and development across the globe
members— (19) Argentina, Australia, Brazil, Canada, China, France, Germany, India, Indonesia, Italy, Japan, South Korea, Mexico,
Russia, Saudi Arabia, South Africa, Turkey, UK, US v v
Group of 24 (G-24)
established-l August 1989
aim-to promote the interests of developing countries in Africa, Asia, and Latin America within the IMF
members— (24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d’Ivoire, Egypt, Ethiopia, Gabon, Ghana,
Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, South Africa, Sri Lanka, Syria, Trinidad and Tobago,
Venezuela
observers— (1) China
Group of 77 (G-77)
established-l 5 Junel964; October 1967 first ministerial meeting
aim-to promote economic cooperation among developing countries; name persists in spite of increased membership
members— (129 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Federated States of Micronesia, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Pa','ca4b6ac03b24f5db145be40a7dbeb13b3195a47d3a6e7d8b3227603953bf74ae','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7172ba47ad015cf065dcf8292314deec24f452ffcc112752e0cddad5a53225b8',2010,'UZ','Uzbekistan','environment',1593,'pua New Guinea, Paraguay, Peru,
Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland,
Syria, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uruguay, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
Gulf Cooperation Council (GCC)
note— also known as the Cooperation Council for the Arab States of the Gulf
established- 25 May 1981
aim-to promote regional cooperation in economic, social, political, and military affairs
members— (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
Organization for Democracy and Economic Development (GUAM)
note-acronym standing for the member countries, Georgia, Ukraine, Azerbaijan, Moldova; formerly known as GUUAM before Uzbekistan
withdrew in 5 May 2005
established-l June 2001
aim-commits the countries to cooperation and assistance in social and economic development, the strengthening and broadening of trade
and economic relations, and the development and effective use of transport and communications, highways, and related infrastructure
crossing the boundaries of the member states
members— (4) Azerbaijan, Georgia, Moldova, Ukraine
high income countries
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC)
established-2l December 1982
aim-to organize and promote regional cooperation in all sectors, especially economic
members— (5) Comoros, France (for Reunion and Mayotte), Madagascar, Mauritius, Seychelles
industrial countries
another term for the developed countries; see developed countries (DCs)
l
Inter-American Development Bank (IADB)
note— also known as Banco Interamericano de Desarrollo (BID)
780
INTERNATIONAL ORGANIZATIONS AND GROUPS
established-8 April 1959; effective— 30 December 1959
aim-to promote economic and social development in Latin America
members— (47) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica,
Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany, Guatemala, Guyana, Haiti, Honduras,
Israel, Italy, Jamaica, Japan, South Korea, Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru, Portugal, Slovenia, Spain,
Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US, Uruguay, Venezuela
Inter-Governmental Authority on Development (IGAD)
note— formerly known as Inter-Governmental Authority on Drought and Development (IGADD)
established,-! 5-1 6 January 1986 as the Inter-Governmental Authority on Drought and Development; revitalized— 21 March 1996 as the
Inter-Governmental Authority on Development
aim-to promote a social, economic, and scientific community among its members
members— (6) Djibouti, Ethiopia, Kenya, Somalia, Sudan, Uganda; note— Eritrea declared its suspension in 2007
Inter-Parliamentary Union (IPU)
established-! 889
aim-f osters contacts amoxag parliamentarians, considers and expresses views of international interest and concern with the purpose of
bringing about action by parliaments and parliamentarians, contributes to the defense and promotion of human rights, contributes to
better knowledge of representative institutions
members— (154 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, Bahrain, Belarus, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Somalia, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Syria, Tanzania, Tajikistan, Thailand, Timor-Leste, Togo, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, Uruguay, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
associate members— (8) Andean Parliament, Central American Parliament, East African Legislative Assembly, European Parliament, Inter¬
parliamentary Committee of the West African Economic and Monetary Union, Latin American Parliament, Parliament of the Economic
Community of West African States, Parliamentary Assembly of the Council of Europe
International Atomic Energy Agency (IAEA)
established- 26 October 1956; effective— 29 July 1957
aim-to promote peaceful uses of atomic energy
members— (145) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belarus, Belgium,
Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Finland, France, Gabon, Georgia,
Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Palau, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Togo, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe;
note— membership pending for Bahrain, Burundi, Cape Verde, Republic of the Congo, Lesotho, Oman, Nepal until the necessary legal
instruments are deposited with the IAEA
International Bank for Reconstruction and Development (IBRD)
note— also known as the World Bank
established-22 July 1944; effective— 27 December 1945
aim-to provide economic development loans; a UN specialized agency
members— (185) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco, Nauru, and Tuvalu
International Chamber of Commerce (ICC)
established-! 9! 9
aim- to promote free trade and private enterprise and to represent business interests at national and international levels
members— (91 national committees) Algeria, Argentina, Australia, Austria, Bahrain, Bangladesh, Belgium, Brazil, Bulgaria, Burkina Faso,
Cameroon, Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican
781
THE CIA WORLD FACTBOOK
Republic, Ecuador, Egypt, El Salvador, Finland, France, Georgia, Germany, Ghana, Greece, Guatemala, Hong Kong, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South Korea, Kuwait, Lebanon, Lithuania, Luxembourg, Madagascar, Malaysia,
Mexico, Monaco, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan,
Tanzania, Thailand, Togo, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela; note— Peru is restructuring
International Civil Aviation Organization (ICAO)
established -7 December 1944; effective— 4 April 1947
aim-to promote international cooperation in civil aviation; a UN specialized agency
members— (190) includes all UN member countries except Dominica, Liechtenstein, and Tuvalu (189 total); plus Cook Islands
International Civilian Support Mission in Haiti (MICAH)
established 1 7 December 1 999 to promote respect for human rights; members included Argentina, Benin, Canada, France, India, Mali,
Niger, Senegal, Togo, Tunisia, US; closed 2001 v v
International Committee of the Red Cross (ICRC)
established- 17 February 1863
aim-to provide humanitarian aid in wartime v
members— (15-25 individuals) all Swiss nationals
International Court of Justice (ICJ)
note— also known as the World Court
established-3 February 1946 superseded Permanent Court of International Justice
aim-primary judicial organ of the UN
members— (15 judges) elected by the UN General Assembly and Security Council to represent all principal legal systems
International Criminal Court (ICCt)
established-l 1 April 2002
aim-to hold all individuals and countries accountable to international laws of conduct; to specify international standards of conduct; to
provide an important mechanism for implementing these standards; to ensure that perpetrators are brought to justice
members ( countries that have ratified the treaty)— (108) Afghanistan, Albania, Andorra, Antigua and Barbuda, Argentina, Australia, Austria,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia,
Canada, Central African Republic, Chad, Colombia, Comoros, Cook Islands, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Croatia, Cyprus, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Estonia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Guinea, Guyana, Honduras, Hungary, Iceland, Ireland, Italy, Japan, Jordan, Kenya,
South Korea, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Mali, Malta, Marshall
Islands, Mauritius, Mexico, Mongolia, Montenegro, Namibia, Nauru, Netherlands, NZ, Niger, Nigeria, Norway, Panama, Paraguay,
Peru, Poland, Portugal, Romania, Saint Vincent and the Grenadines, Saint Kitts and Nevis, Samoa, San Marino, Senegal, Serbia, Sierra
Leone, Slovakia, Slovenia, South Africa, Spain, Suriname, Sweden, Switzerland, Tajikistan, Tanzania, Timor-Leste, Trinidad and Tobago,
Uganda, UK, Uruguay, Venezuela, Zambia
International Criminal Police Organization (Interpol)
established-September 1923 set up as the International Criminal Police Commission; 13 June 1956 constitution modified and present
name adopted
aim-to promote international cooperation among police authorities in fighting crime
members— (187) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino,
Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
subbureaus— (11) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Hong Kong, Macau,
Montserrat, Puerto Rico, Turks and Caicos Islands
782
INTERNATIONAL O RG A N I Z A T I O N S AND GROUPS
International Development Association (IDA)
established- 26 January 1960; effective— 24 September 1960
aim-to provide economic loans for low-income countries; UN specialized agency and IBRD affiliate
members— (168) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia, Morocco, Mozambique, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Ukraine, UAE, UK, US, Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
International Energy Agency (IEA)
established-l 5 November 1974
aim-to promote cooperation on energy matters, especially emergency oil sharing and relations between oil consumers and oil producers;
established by the OECD
members— (28) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies (IFRCS)
note— formerly known as League of Red Cross and Red Crescent Societies (LORCS)
established-5 May 1919
aim-to organize, coordinate, and direct international relief actions; to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members— (185 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
observers— (2) Eritrea and Tuvalu
International Finance Corporation (IFC)
established-25 May 1955; effective— 24 July 1956
aim-to support private enterprise in international economic development; a UN specialized agency and IBRD affiliate
members— (181) includes all UN member countries except Andorra, Brunei, Cuba, North Korea, Liechtenstein, Monaco, Nauru, Saint
Vincent and the Grenadines, San Marino, Suriname, Tuvalu
International Fund for Agricultural Development (IFAD)
established-November 1974
aim-to promote agricultural development; a UN specialized agency
members— (165)
List A— (23 industrialized aid contributors) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Iceland, Ireland,
Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, UK, US
List B— (12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela
783
THE CIA WORLD FACTBOOK
List C— (130 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Niue, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Senegal, Serbia (suspended since 1992), Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Uganda, Uruguay, Vietnam, Yemen, Zambia, Zimbabwe
\\ s.
International Hydrographic Organization (IHO)
note— name changed from International Hydrographic Bureau on 22 September 1970
established-] une 1919; effective— June 1921
aim-to train hydrographic surveyors and nautical cartographers to achieve standardization in nautical charts and electronic chart displays;
to provide advice on nautical cartography and hydrography; to develop the sciences in the field of hydrography and techniques used for
descriptive oceanography
members— (80) Algeria, Argentina, Australia, Bahrain, Bangladesh, Belgium, Brazil, Burma, Canada, Chile, China (including Hong
Kong and Macau), Colombia, Democratic Republic of the Congo (suspended), Croatia, Cuba, Cyprus, Denmark, Dominican Republic
(suspended), Ecuador, Egypt, Estonia, Fiji, Finland, France, Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran, Ireland, Italy,
Jamaica, Japan, North Korea, South Korea, Kuwait, Latvia, Malaysia, Mauritius, Mexico, Monaco, Morocco, Mozambique, Netherlands,
NZ, Nigeria, Norway, Oman, Pakistan, Papua New Guinea, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia,
Serbia, Singapore, Slovenia, South Africa, Spain, Sri Lanka, Suriname (suspended), Sweden, Syria, Thailand, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela
International Labor Organization (ILO)
established-28 June 1919 set up as part of Treaty of Versailles; 1 1 April 1919 became operative; 14 December 1946 affiliated with the UN
aim-to deal with world labor issues; a UN specialized agency
members— (181) includes all UN member countries except Andorra, Bhutan, North Korea, Liechtenstein, Maldives, Federated States of
Micronesia, Monaco, Nauru, Palau, Tonga, and Tuvalu; note— includes the following dependencies: Netherlands (Netherlands Antilles
and Aruba)
International Maritime Organization (IMO)
note— name changed from Intergovernmental Maritime Consultative Organization (IMCO) on 22 May 1982
established-6 March 1 948 set up as the Inter-Governmental Maritime Consultative Organization; effective— 1 7 March 1 958
aim- to deal with international maritime affairs; a UN specialized agency
members— (167) includes all UN member countries except Afghanistan, Andorra, Armenia, Belarus, Bhutan, Botswana, Burkina Faso,
Burundi, Central African Republic, Chad, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Mali, Federated States of Micronesia, Nauru, Niger,
Palau, Rwanda, Tajikistan, Uganda, Uzbekistan, Zambia
associate members— (3) Faroe Islands, Hong Kong, Macau
International Monetary Fund (IMF)
establi shed-22 July 1944; effective— 27 December 1945
aim-to promote world monetary stability and economic development; a UN specialized agency
members— (1 85) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco, Nauru, Tuvalu; note— includes
the following dependencies or areas of special interest: China (Hong Kong and Macau), Netherlands (Netherlands Antilles a','303ce025094919ca3a919c9780f34b4e3044ba3d50a594553124aeac1b2f54fb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('559c8f688cee2d930489c1e851ec775da65a395a62af6614649fbcabec5ee155',2010,'UZ','Uzbekistan','environment',1594,'nd Aruba)
International Mobile Satellite Organization (IMSO)
established-l 5 April 1999
aim-acts as watchdog over Inmarsat (International Maritime Satellite Organization), a private company, to make sure it follows ICAO
standards and recommended practices; plays an active role in the development of international telecommunications policies
members— (92) Algeria, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Bosnia and Herzegovina, Brazil,
Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Comoros, Cook Islands, Costa Rica, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Egypt, Finland, France, Gabon, Germany, Ghana, Greece, Hungary; Iceland, India, Indonesia, Iran, Iraq, Israel,
Italy, Japan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya, Malaysia, Malta, Marshall Islands, Mauritius, Mexico, Monaco,
Montenegro, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Sweden, Switzerland,
Tanzania, Thailand, Tonga, Tunisia, Turkey, Ukraine, UAE, UK, US, Venezuela, Vietnam
International Olympic Committee (IOC)
established-23 June 1894
aim-to promote the Olympic ideals and administer the Olympic games: 2010 Winter Olympics in Vancouver, Canada; 2012 Summer
Olympics in London, UK; 2014 Winter Olympics in Sochi, Russia
784
INTERNATIONAL ORGANIZATIONS AND GROUPS
National Olympic Committees— (204 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria, American Samoa, Andorra,
Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Virgin Islands, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
International Organization for Migration (I0M)
note— established as Provisional Intergovernmental Committee for the Movement of Migrants from Europe; renamed Intergovernmental
Committee for European Migration (ICEM) on 15 November 1952; renamed Intergovernmental Committee for Migration (ICM) in
November 1980; current name adopted 14 November 1989
established-5 December 1951
aim- to facilitate orderly international emigration and immigration
members— (122) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, India, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia, Liberia, Libya, Lithuania, Luxembourg, Madagascar, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Rwanda, Senegal, Serbia, Sierra Leone, Slovakia,
Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Tunisia, Turkey,
Uganda, Ukraine, UK, US, Uruguay, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
observers— (16) Bahrain, Bhutan, China, Cuba, Ethiopia, Guyana, Holy See, Indonesia, Macedonia, Mozambique, Namibia, Papua New
Guinea, Russia, San Marino, Sao Tome and Principe, Turkmenistan
International Organization for Standardization (ISO)
estabiished-February 1947
aim-to promote the development of international standards with a view to facilitating international exchange of goods and services and
to developing cooperation in the sphere of intellectual, scientific, technological and economic activity
members— (105 national standards organizations) Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada, Chile, China, Colombia, Democratic
Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Ethiopia, Fiji,
Finland, France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Lebanon, Libya, Lithuania, Luxembourg, Macedonia, Malaysia, Malta, Mauritius,
Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Saint Lucia, Saudi Arabia, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden,
Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Zimbabwe
correspondent members— ( 41 plus the Palestine Liberation Organization) Afghanistan, Albania, Angola, Benin, Bhutan, Bolivia, Brunei,
Burkina Faso, Burma, Cameroon, Dominican Republic, El Salvador, Eritrea, Estonia, Gabon, Georgia, Guatemala, Guinea, Hong
Kong, Kyrgyzstan, Latvia, Macau, Madagascar, Malawi, Moldova, Montenegro, Mozambique, Namibia, Nepal, Papua New Guinea,
Paraguay, Rwanda, Senegal, Seychelles, Swaziland, Tajikistan, Togo, Turkmenistan, Uganda, Yemen, Zambia, Palestine Liberation
Organization
subscriber members— (10) Antigua and Barbuda, Burundi, Cambodia, Dominica, Guyana, Honduras, Laos, Lesotho, Saint Vincent and
the Grenadines, Suriname
International Organization of the French-speaking World (OIF)
note— name changed from Agency of Cultural and Technical Cooperation (ACCT) in 1997; also known as Organisation Internationale
de la Francophonie
established- 20 March 1970
785
THE CIA WORLD FACTBOOK
«
aim-founded around a common language to promote and spread the cultures of its members and to reinforce cultural and technical
cooperation between diem
members— (5 3) Albania, Andorra, Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Canada— New
Brunswick, Canada— Quebec, Cape Verde, Central African Republic, Chad, Cpmoros, Democratic Republic of Congo, Republic of
Congo, Cote d’Ivoire, Djibouti, Dominica, Egypt, Equatorial Guinea, France, French Community of Belgium, Gabon, Greece, Guinea,
Guinea-Bissau, Haiti, Laos, Lebanon, Luxembourg, Macedonia, Madagascar, Mali, Mauritania, Mauritius, Moldova, Monaco, Morocco,
Niger, Romania, Rwanda, Saint Lucia, Sao Tome and Principe, Senegal, Seychelles, Switzerland, Togo, Tunisia, Vanuatu, Vietnam
associates— ( 3) Armenia, Cyprus, Ghana
observers— (14) Austria, Croatia, Czech Republic, Georgia, Flungary, Latvia, Lithuania, Mozambique, Poland, Serbia, Slovakia, Slovenia,
Thailand, Ukraine
international Red Cross and Red Crescent Movement (ICRM)
established- 1928
aim- to promote worldwide humanitarian aid through the International Committee of the Red Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent Societies (IFRCS; formerly League of Red Cross and Red Crescent Societies or LORCS) in
peacetime
National Societies— (185 countries and the Palestine Liberation Organization); note— same as membership for International Federation of
Red Cross and Red Crescent Societies (IFRCS)
international Telecommunications Satellites Organization (ITSO)
established-August 1964
aim-to act as a watchdog over Intelsat, Ltd., a private company, to make sure it provides on a global and non-discriminatory basis public
telecommunication services
members— (148) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar,
Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, the Federated States of Micronesia, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal, Serbia, Singapore, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and
Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Telecommunication Union (ITU)
established- 17 May 1865 set up as the International Telegraph Union; 9 December 1932 adopted present name; effective— 1 January
1934; affiliated with the UN— 15 November 1947
aim-to deal with world telecommunications issues; a UN specialized agency
members— (191) includes all UN member countries except Palau, Timor-Leste (190 total); plus Holy See
International Trade Union Confederation (ITUC)
note— its predecessors were the Confederation of Free Trade Unions (ICFTU) and the World Confederation of Labor (WCL)
established— 3 November 2006
aim-to promote the trade union movement
members— (311 affiliated organizations in the following 154 countries and the Palestine Liberation Organization as of December 2007)
Albania, Algeria, Angola, Antigua and Barbuda, Aruba, Argentina, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bermuda, Bonaire, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi,
Cameroon, Canada, Cape Verde, Central African Republic, Comoros, Chad, Chile, Colombia, Democratic Republic of die Congo,
Republic of die Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Japan, Jordan, Kenya, Kiribati, South Korea, Kosovo, Kuwait, Latvia,
Liberia, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Mongolia,
Montenegro, Morocco, Mozambique, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri
Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Ukraine, UK, US, Vanuatu, Venezuela, Yemen, Zambia, Zimbabwe, and the Palestine Liberation Organization
Islamic Development Bank (IDB)
established- 15 December 1973 by declaration of intent; effective— 12 August 1974
aim-to promote Islamic economic aid and social development
786
INTERNATIONAL ORGANIZATIONS AND GROUPS
members— (55 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d’Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia,
Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique,
Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia,
Turkey, Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
Latin American Economic System (LAES)
note— also known as Sistema Economico Latinoamericana (SELA)
established-l 7 October 1975
aim- to promote economic and social development through regional cooperation
members— (27) Argentina, the Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican Republic,
Ecuador, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Secretaria General Iberoamericana
(SEGIB), Suriname, Trinidad and Tobago, Uruguay, Venezuela
Latin American Integration Association (LAIA)
note— also known as Asociacion Latinoamericana de Integracion (ALADI)
established-l 2 August 1980; effective— 18 March 1981
aim-to promote freer regional trade
members— ( 12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers— ( 26) China, Corporacion Andina de Fomento, Costa Rica, Dominican Republic, EC, El Salvador, Guatemala, Honduras,
Inter-American Development Bank, Inter-American Institute for Cooperation on Agriculture, Italy, Japan, South Korea, Latin America
Economic System, Nicaragua, Organization of American States, Panama, Pan-American Health Organization, Portugal, Romania, Russia,
Spain, Switzerland, Ukraine, United Nations Development Program, United Nations Economic Commission for Latin America and the
Caribbean
League of Arab States (LAS)
note— also known as Arab League (AL)
established-22 March 1945
aim-aim— to promote economic, social, political, and military cooperation
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
observers— ( 3) Eritrea, India, Venezuela
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as having no significant
economic growth, per capita GDPs normally less than $1,000, and low literacy rates; also known as the undeveloped countries; the 42
LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana, Burkina Faso, Burma, Burundi, Cape Verde, Central African Republic,
Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho,
Malawi, Maldives, Mali, Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia,
Sudan, Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed countries (LDCs)
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less developed
countries (LDCs); mainly countries and dependent areas with low levels of output, living standards, and technology; per capita GDPs are
generally below $5,000 and often less than $1 ,500; however, the group also includes a number of countries with high per capita incomes,
areas of advanced technology, and rapid rates of growth; includes the advanced developing countries, developing countries, Four Dragons
(Four Tigers), least developed countries (LLDCs), low-income countries, middle-income countries, newly industrializing economies
(NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are: Afghanistan, Algeria, American
Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin,
Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde,
Cayman Islands, Central African Republic, Chad, Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana, French Polynesia,
Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guatemala, Guernsey, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Isle of Man, Jamaica, Jersey, Jordan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall
Islands, Martinique, Mauritania, Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto Rico, Qatar, Reunion,
Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu,
UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen,
Zambia, Zimbabwe; note— similar to the new International Monetary Fund (IMF) term “developing countries” which adds Malta, Mexico,
787
THE CIA WORLD FACTBOOK
South Africa, and Turkey but omits in its recendy published statistics American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman
Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza
Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle of Man* Jersey, North Korea, Macau, Martinique, Mayotte,
Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion,
Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West
Bank, Western Sahara
low-income countries
another term for those less developed countries with below-average per capita GDPs; see less developed countries (LDCs)
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries (LDCs)
Multilateral Investment Guarantee Agency (MIGA)
established-12 April 1988
aim-encourages flow of foreign direct investment among member countries by offering investment insurance, consultation, and negotiation
on conditions for foreign investment and technical assistance; a UN specialized agency v
members— (1 73) includes all UN member countries except Andorra, Bhutan, Brunei, Burma, Comoros, Cuba, Kiribati, North Korea,
Liechtenstein, Marshall Islands, Monaco, Nauru, NZ, Niger, San Marino, Sao Tome and Principe, Somalia, Tonga, Tuvalu
Near Abroad
Russian term for the 14 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in which Moscow has
expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
new independent states (NIS)
a term referring to all the countries of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their economies; formerly
known as the newly industrializing countries (NICs); also known as advanced developing countries; usually includes the Four Dragons
(Hong Kong, South Korea, Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM)
established-l''6 September 1961
aim- to establish political and military cooperation apart from the traditional East or West blocs
members— (117 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cote d’Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon,
The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica,
Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Mauritania,
Mauritius, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Timor-Leste, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
observers— (15) Armenia, Azerb','40047a3e95e84b7b3a504042c7fdfbe150bace221dc9c1b23aac092a88c8a84c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f09dbd4f08382bc36cca94fdc35ac4fd1101a5f9e866b6798486692bbef9f70b',2010,'UZ','Uzbekistan','environment',1595,'aijan, Bosnia and Herzegovina, Brazil, China, Costa Rica, Croatia, El Salvador, Kazakhstan, Kyrgyzstan,
Mexico, Paraguay, Serbia, Ukraine, Uruguay
guests— (24) Australia, Austria, Bulgaria, Canada, Cyprus, Czech Republic, Finland, Germany, Greece, Holy See, Hungary, Italy,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland
Nordic Council (NC)
established-16 March 1952; effective— 12 February 1953
flim-to promote regional economic, cultural, and environmental cooperation
members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland, Norway, Sweden
observers— (3) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
established-A December 1975; effective— 1 June 1976
aim-to promote economic cooperation and development
members— (8) Denmark (including Faroe Islands and Greenland), Estonia, Finland (including Aland Islands), Iceland, Latvia, Lithuania,
Norway, Sweden
788
INTERNATIONAL ORGANIZATIONS AND GROUPS
North
a popular term for the rich industrialized countries generally located in the northern portion of the Northern Hemisphere; the counterpart
of the South; see developed countries (DCs)
North American Free Trade Agreement (NAFTA)
established-1 7 December 1992
aim-to eliminate trade barriers, promote fair competition, increase investment opportunities, provide protection of intellectual property
rights, and create procedures to settle disputes
members— (3) Canada, Mexico, US
North Atlantic Treaty Organization (NATO)
established-4 April 1 949
aim-to promote mutual defense and cooperation
members— ( 28) Albania, Belgium, Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, France, Germany, Greece, Hungary,
Iceland, Italy, Latvia, Lithuania, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA)
note— also known as OECD Nuclear Energy Agency
established-1 February 1958
aim-to promote the peaceful uses of nuclear energy; associated with OECD
members— (28) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey,
UK, US
Nuclear Suppliers Group (NSG)
note— also known as the London Suppliers Group or the London Group
established- 1974; effective— 1975
aim-to establish guidelines for exports of nuclear materials, processing equipment for uranium enrichment, and technical information to
countries of proliferation concern and regions of conflict and instability
members— ( 45) Argentina, Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, China, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, Kazakhstan, South Korea, Latvia, Lithuania,
Luxembourg, Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US
observer— (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and Development (OECD)
established- 14 December 1960; effective— 30 September 1961
aim- to promote economic cooperation and development
members— ( 30) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Japan, South Korea, Luxembourg, Mfexico, Netherlands, NZ, Norway, Poland, Portugal, Slovakia, Spain, Sweden,
Switzerland, Turkey, UK, US
special member— (1) EC
accession states-(5) Chile, Estonia, Israel, Russia, Slovenia
Organization for Security and Cooperation in Europe (OSCE)
note— formerly the Conference on Security and Cooperation in Europe (CSCE) established 3 July 1975
established-1 January 1995
aim-to foster the implementation of human rights, fundamental freedoms, democracy, and the rule of law; to act as an instrument of
early warning, conflict prevention, and crisis management; and to serve as a framework for conventional arms control and confidence
building measures
members— (56) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Holy See, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Montenegro, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan
partners for cooperation— (11) Afghanistan, Algeria, Egypt, Israel, Japan, Jordan, South Korea, Mongolia, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW)
established-29 April 1997
aim-to enforce the Convention on the Prohibition of the Development, Production, Stockpiling, and Use of Chemical Weapons and on
Their Destruction; to provide a forum for consultation and cooperation among the signatories of the Convention
members ( countries that have ratified the Convention)— (184) Afghanistan, Albania, Algeria, Andorra, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa
789
THE CIA WORLD FACTBOOK
Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Djibouti, Ecuador, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
signatory states (countries that have signed, but not ratified, the Convention)— (5) The Bahamas, Burma, Dominican Republic, Guinea-
Bissau, Israel
Organization of African Unity (OAU)
see African Union 1
Organization of American States (OAS)
established- 14 April 1890 as the International Union of American Republics; 30 April 1948 adopted present charter; effective— 13
December 1951
aim-to promote regional peace and security as well as economic and social development
members— ( 35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica,
Cuba (excluded from formal participation since 1962), Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala,
Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers— (63) Algeria, Angola, Armenia, Austria, Azerbaijan, Belgium, Benin, Bosnia and Herzegovina, Bulgaria, China, Croatia, Cyprus,
Czech Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU, Finland, France, Georgia, Germany, Ghana, Greece, Holy See,
Hungary, Iceland, India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia, Lebanon, Luxembourg, Morocco, Netherlands,
Nigeria, Norway, Pakistan, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Serbia, Slovakia, Slovenia, Spain, Sri
Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, Vanuatu, Yemen
Organization of Arab Petroleum Exporting Countries (OAPEC)
established-9 January 1968
aim-to promote cooperation in the petroleum industry
members— (11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, Tunisia (suspended), UAE
Organization of Eastern Caribbean States (OECS)
established-l 8 June 1981; effective— 4 July 1981
aim-to promote political, economic, and defense cooperation
members— (9) Anguilla, Antigua and Barbuda, British Virgin Islands, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia,
UZ
UZ
UZB
860
UZB
.UZ
41 20 N
69 18 E
Pacific Ocean
4 30 S
168 00 E
41 20 N
69 18 E
841
Name
THE CIA WORLD FACTBOOK
Transcarpathia (region; alternate name for Carpatho-
Ukraine)
Transjordan (former name for Jordan)
Transkei (enclave)
Transvaal (region; former name for northeastern South
Africa)
Transylvania (region)
Trindade, ilha de (island)
Trinidad (island)
Tripoli (capital)
Tripoli (city)
Tripolitania (region)
Tristan da Cunha Group (island group)
Trobriand Islands
Trucial Coast (former name for the United Arab Emirates)
Trucial Oman (former name for the United Arab Emirates)
Trucial States (former name for the United Arab Emirates)
Truk Islands (former name for the Chuuk Islands)
Tsugaru Strait
Tuamotu Islands (lies Tuamotu)
Tubuai Islands (lies Tubuai)
Tunb al Kubra (island)
Tunb as Sughra (island)
Tunis (capital)
Turin (city)
Turkish Straits (see Bosporus and Dardenelles)
Turkiye (local name for Turkey)
Turkmenia, Turkmeniya (former name for Turkmenistan)
Turks Island Passage
Tuscany (region)
Tutuila (island)
Tyrrhenian Sea
Ubangi-Shari (former name for the Central African Republic
Ukrayina (local name for Ukraine)
Ulaanbaatar (capital)
Uilung-do (island)
Ulster (region)
Uman (local name for Oman)
Unimak Pass (strait)
Union of Soviet Socialist Republics or USSR (former name
of a large Eurasian empire, roughly coequal with the
former Russian Empire)
United Arab Republic or UAR (former name for a federation
between Egypt and Syria)
Upper Volta (former name for Burkina Faso)
Ural Mountains
Urdunn (local name for Jordan)
Urundi (former name for Burundi)
Ussuri River
Vaduz (capital)
Vakhan (Wakhan Corridor)
Valletta (capital)
Valley, The (capital)
Van Diemen Strait (Osumi Strait)
Vancouver (city)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)','8ba387cb1b9e0890162f864b6ef0a2fd5e69d50ec076ca8ee2fab5959d3c6177','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b743cb19e58a8ded8e1215126db0432c24eb8f1cfa3d066646fd28d5c09bd3cf',2010,'VC','Saint Vincent and the Grenadines','environment',1596,'Organization of Petroleum Exporting Countries (OPEC)
established-l 4 September 1960
aim-to coordinate petroleum policies
members— (1 3) Algeria, Angola, Ecuador, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
Organization of the Islamic Conference (OIC)
established- 22-25 September 1969
aim-to promote Islamic solidarity in economic, social, cultural, and political affairs
members— (56 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d’Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau, Guyana,
Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco,
Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan,
Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers— (14) AU, Bosnia and Herzegovina, Central African Republic, ECO, Islamic Conference Youth Forum for Dialogue and
Cooperation, LAS, Moro National Liberation Front, NAM, OAU, Parliamentary Union of the OIC Member States, Russia, Thailand,
Turkish Muslim Community of Kibris, UN
Pacific Community (SPC)
local name of the Secretariat of the Pacific Community
Pacific Islands Forum (PIF)
note— formerly known as South Pacific Forum (SPF)
established-5 August 1971
790
INTERNATIONAL ORGANIZATIONS AND GROUPS
aim-to promote regional cooperation in political matters
members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
associate members— (2) French Polynesia, New Caledonia
partners— (1 3) Canada, China, EU, France, India, Indonesia, Japan, South Korea, Malaysia, Philippines, Thailand, UK, US
observers— (5) Asia Development Bank, The Commonwealth, Timor-Leste, Tokelau, Wallis and Futuna
Paris Club
established- 1956
aim-to provide a forum for debtor countries to negotiate rescheduling of debt service payments or loans extended by governments or
official agencies of participating countries; to help restore normal trade and project finance to debtor countries
members— (19) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Japan, Netherlands, Norway,
Russia, Spain, Sweden, Switzerland, UK, US
Partnership for Peace (PFP)
established-l 0-1 1 January 1994
aim-to expand and intensify political and military cooperation throughout Europe, increase stability, diminish threats to peace, and build
relationships by promoting the spirit of practical cooperation and commitment to democratic principles that underpin NATO; program
under the auspices of NATO
members— (22) Armenia, Austria, Azerbaijan, Belarus, Bosnia and Herzegovina, Finland, Georgia, Ireland, Kazakhstan, Kyrgyzstan,
Macedonia, Malta, Moldova, Montenegro, Russia, Serbia, Sweden, Switzerland, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note— a
nation that becomes a member of NATO is no longer a member of PFP
Permanent Court of Arbitration (PCA)
established-29 July 1899
aim-to facilitate the settlement of international disputes
members— (108) Argentina, Australia, Austria, Bahrain, Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria, Burkina Faso,
Cambodia, Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa Rica, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Germany,
Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, Kenya, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malaysia, Malta, Mauritius,
Mexico, Montenegro, Morocco, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Poland, Portugal,
Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Thailand, Togo, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
Rio Group (RG)
note— formerly known as Grupo de los Ocho, established NA December 1986; composed of the Contadora Group and the Lima Group
established— 1988
aim-to consult on regional Latin American issues
members— (21) Argentina, Belize, Bolivia, Brazil, CARICOM, Chile, Colombia, Costa Rica, Dominican Republic, Ecuador, El Salvador,
Guatemala, Guyana, Honduras, Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay, Venezuela
Schengen Convention
established-established— signed June 1990; effective March 1995
aim-aim— to allow free movement within an area without internal border controls
members— (25) Austria, Belgium, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Iceland, Italy, Latvia,
Lithuania, Luxembourg, Malta, Monaco, Netherlands, Norway, Poland, Portugal, Slovakia, Slovenia, Spain, Sweden, Switzerland;
note— UK and Ireland have not joined; Liechtenstein and Cyprus will probably join in 2009; Bulgaria and Romania are still not fully
implemented
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian governments and command
economies based on the Soviet model; the term is fading from use; see centrally planned economies
Secretariat of the Pacific Community (SPC)
established-6 February 1947; effective 29 July 1948
aim-to serve island development in 22 Pacific countries; to develop technical assistance and professional, scientific, and research support;
to build planning and management capability
members— (26) America Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall Islands, Federated
States of Micronesia, Nauru, New Caledonia, Niue, Northern Mariana Islands, NZ, Palau, Papua New Guinea, Pitcairn Islands, Samoa,
Solomon Islands, Tokelau, Tonga, Tuvalu, Vanuatu, US, Wallis and Futuna
Shanghai Cooperation Organization (SCO)
established-l 5 June 2001
aim-to combat terrorism, extremism, and separatism; to safeguard regional security through mutual trust, disarmament, and cooperative
security; and to increase cooperation in political, trade, economic, scientific and technological, cultural, and educational fields
791
THE CIA WORLD FACTBOOK
members— (6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
observers— (4) India, Iran, Mongolia, Pakistan
guests-(6) Afghanistan, ASEAN, CIS, EurAsEC, Turkmenistan, UN
socialist countries
in general, countries in which the government owns and plans the use of the major factors of production; note— the term is sometimes
used incorrectly as a synonym for Communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the counterpart of the
North; see less developed countries (LDCs)
South American Community of Nations (CSN)
established- 9 December 2004
aim-to coordinate common policies regarding multilateral organizations, to integrate physical infrastructure, and to consolidate the
merger of CAN and Mercosur
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Surinam, Uruguay, Venezuela
observers— (2) Mexico, Panama v
South Asian Association for Regional Cooperation (SAARC)
established-8 December 1985
aim-to promote economic, social, and cultural cooperation
members— (8) Afghanistan. Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
observers— ( 9) Australia, Burma, China, EU, Iran, Japan, South Korea, Mauritius, US
South Asia Co-operative Environment Program (SACEP)
established-] anuary 1983
aim-to promote regional cooperation in South Asia in the field of environment, both natural and human, and on issues of economic and
social development; to support conservation and management of natural resources of the region
members— (8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
South Pacific Forum (SPF)
note— see Pacific Island Forum
South Pacific Regional Trade and Economic Cooperation Agreement (Sparteca)
established-1981
aim- to redress unequal trade relationships of Australia and New Zealand with small island economies in the Pacific region
members— ( 16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
Southeast European Cooperative initiative (SECI)
established- 6 December 1996
aim-to encourage cooperation among participating states and to facilitate their integration into European structures
members— (13) Albania, Bosnia and Herzegovina, Bulgaria, Croatia, Greece, Hungary, Macedonia, Moldova, Montenegro, Romania,
Serbia, Slovenia, Turkey
observers— (18) Austria, Azerbaijan, Belgium, Canada, France, Georgia, Germany, Israel, Italy, Japan, Netherlands, Poland, Portugal,
Slovakia, Spain, Ukraine, UK, US
Southern African Customs Union (SACU)
established-l 1 December 1 969
aim-to promote free trade and cooperation in customs matters
members— (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC)
note— evolved from the Southern African Development Coordination Conference (SADCC)
established-l 7 August 1992
aim-to promote regional economic development and integration
members— (14) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Madagascar, Malawi, Mauritius, Mozambique, Namibia,
Seychelles, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market
note— also known as Mercado Comun del Cono Sur (Mercosur)
established-26 March 1991
aim-to increase regional economic cooperation
members— (4) Argentina, Brazil, Paraguay, Uruguay
associate members— (5) Bolivia, Chile, Colombia, Ecuador, Peru, Venezuela
792
INTERNATIONAL O R G A N I Z A T I O N S AND GROUPS
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
African Union/Unifed Nations Hybrid Operation in Darfur (UNAMID)
established ''—31 July 2007
aim-to contribute to the restoration of security conditions which will allow safe humanitarian assistance throughout Darfur, to contribute
to the protection of civilian populations under imminent threat of physical attack, to monitor, observe compliance with, and verify the
implementation of various ceasefire agreements
members— (31) Bangladesh, Burkina Faso, Burundi, Canada, China, Egypt, Ethiopia, France, Gabon, The Gambia, Ghana, Indonesia,
Jordan, Kenya, Libya, Malawi, Mali, Namibia, Nepal, Nigeria, Pakistan, Rwanda, Senegal, South Africa, Tanzania, Thailand, Togo,
Uganda, UK, Yemen, Zambia
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least developed countries
(LLDCs)
Union Latina
established- 15 May 1954; became functional 1983
aim-to project, protect, and promote the common heritage and unifying identities of the Latin, and Latin-influenced, world
members— (37) Andorra, Angola, Bolivia, Brazil, Cape Verde, Chile, Colombia, Cote d’Ivoire, Costa Rica, Cuba, Dominican Republic,
Ecuador, El Salvador, France, Guatemala, Guinea-Bissau, Haiti, Honduras, Italy, Mexico, Moldova, Monaco, Mozambique, Nicaragua,
Panama, Paraguay, Peru, Philippines, Portugal, Romania, San Marino, Sao Tome and Principe, Senegal, Spain, Timor-Leste, Uruguay,
Venezuela
observers— ( 3) Argentina, Holy See, Order of Malta
Union of South American Nations (UNASUR— Spanish; UNASUL— Portuguese)
formerly South American Community of Nations which terminated on 16 April 2007
established— 23 May 2008
aim-to model a community after the European Union which will include a common currency, parliament, passport, and defense policy
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Suriname, Uruguay, Venezuela
observers— (2) Mexico, Panama
United Nations (UN)
established-26 June 1945; effective— 24 October 1945
aim-to maintain international peace and security and to promote cooperation involving economic, social, cultural, and humanitarian
problems
constituent organizations— the UN is composed of six principal organs and numerous subordinate agencies and bodies as follows:
1) Secretariat
2) General Assembly: Joint United Nations Program on HIV/AIDS (UN-AIDS), International Research and Training Institute for the
Advancement of Women (INSTRAW), Office of the United Nations High Commissioner for Human Rights (OHCHR), Organization
for the Prohibition of Chemical Weapons (OPCW), Preparation Committee for the Nuclear-Test-Ban Treaty Organization (CTBTO),
United Nations Center for Human Settlements (UN-Habitat), United Nations Children’s Fund (UNICEF), United Nations Conference
on Trade and Development (UNCTAD), United Nations Democracy Fund (UNDEF), United Nations Development Program (UNDP),
United Nations Drug Control Program (UNDCP), United Nations Environment Program (UNEP), United Nations Fund for International
Partnerships (UNFIP), United Nations High Commissioner for Refugees (UNHCR), United Nations Institute for Disarmament Research
(UNIDIR), United Nations Institute for Training and Research (UNITAR), United Nations Interregional Crime and Justice Research
Institute (UNICRI), United Nations Population Fund (UNFPA), United Nations Office of Project Services (UNOPS), United Nations
Relief and Works Agency for Palestine Refugees in the Near East (UNRWA), United Nations Research Institute for Social Development
(UNRISD), United Nations System Staff College (UNSSC), United Nations University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former Yugoslavia (ICTY), International Criminal Tribunal for Rwanda
(ICTR), United Nations Compensation Commission, United Nations Disengagement Observer Force (UNDOF), African Union/
United Nations Hybrid Operation in Darfur (UNAMID), United Nations Integrated Mission in Timor-Leste (UNMIT), United Nations
Interim Administration Mission in Kosovo (UNMIK), United Nations Interim Force in Lebanon (UNIFIL), United Nations Mission
in Liberia (UNMIL), United Nations Military Observer Group in India and Pakistan (UNMOGIP), United Nations Operation in Cote
d’Ivoire (UNOCI), United Nations Mission for the Referendum in Western Sahara (MINURSO), United Nations Mission in the
Central African Republic and Chad (MINURCAT), United Nations Mission in the Sudan (UNMIS), United Nations Observer Mission
in Georgia (UNOMIG), United Nations Organization Mission in the Democratic Republic of the Congo (MONUC), United Nations
Peace-Keeping Force in Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti (MINUSTAH), and United Nations Truce
Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social Development, Commission on Crime Prevention and Criminal
Justice, Commission on Narcotics Drugs, Commission on Population and Development, Commission on Science and Technology for
793
THE CIA WORLD FACTBOOK
Development, Commission on Sustainable Development, Commission on the Status of Women, Economic and Social Commission for
Asia and the Pacific (ESCAP), Economic and Social Commission for Western Asia (ESCWA), Economic Commission for Africa (ECA),
Economic Commission for Europe (ECE), Economic Commission for Latin America and the Caribbean (ECLAC), Food and Agriculture
Organization of the United Nations (FAO), International Atomic Energy Agency (IAEA), International Bank for Reconstruction and
Development (IBRD), International Center for Secretariat of Investment Disputes (ICSID), International Civil Aviation Organization
(ICAO), International Development Association (IDA), International Finance Corporation (IFC), International Fund for Agricultural
Development (IFAD), International Labor Organization (ILO), International Maritime Organization (IMO), International Monetary Fund
(IMF), International Telecommunication Union (ITU), Multilateral Investment Geographic Agency (MIGA), Statistical Commission,
United Nations Educational, Scientific, and Cultural Organization (UNESCO), United Nations Forum on Forests, United Nations
Industrial Development Organization (UNIDO), Universal Postal Union (UPU), World Health Organization (WHO), World Intellectual
Property Organization (WIPO), World Meteorological Organization (WMO), World Tourism Organization (UNWTO), and World
Trade Organization (WTO)
5) Trusteeship Council (inactive; no trusteeships at this time) v
6) International Court of Justice (ICJ)
United Nations Children''s Fund (UNICEF)
note— acronym retained from the predecessor organization, UN International Children’s Emergency Fund
established-l 1 December 1 946
aim- to help establish child health and welfare services
members— (36) selected on a rotating basis from all regions
United Nations Conference on Trade and Development (UNCTAD)
established-30 December 1964
aim- to promote international trade
members— (193) all UN members plus Holy See
United Nations Development Program (UNDP)
established-22 November 1965
aim-to provide technical assistance to stimulate economic and social development
members ( executive board)— (36) selected on a rotating basis from all regions
United Nations Disengagement Observer Force (UNDOF)
established- 31 May 1974
aim-to observe the 1973 Arab-Israeli cease-fire; established by the UN Security Council
members— (6) Austria, Canada, Croatia, India, Japan, Poland
United Nations Educational, Scientific, and Cultural Organization (UNESCO)
established-l 6 November 1945; effective— 4 November 1946
aim-to promote cooperation in education, science, and culture
members— (193) includes all UN member countries except Liechtenstein (191 total); plus Cook Islands and Niue
associate members— (6) Aruba, British Virgin Islands, Cayman Islands, Macau, Netherlands Antilles, Tokelau
United Nations Environment Program (UNEP)
established-l 5 December 1972
aim-to promote international cooperation on all environmental matters
members— (58) selected on a rotating basis from all regions
United Nations General Assembly
established-26 June 1945; effective— 24 October 1945
aim-to function as the primary deliberative organ of the UN
members— (192) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR)
established-3 December 1949; effective— 1 January 1951
aim-to ensure the humanitarian treatment of refugees and find permanent solutions to refugee problems
members ( executive committee)— (1 6) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Benin, Brazil, Canada, Chile, China,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Cyprus, Denmark, Ecuador, Egypt, Estonia, Ethiopia, Finland,
France, Germany, Ghana, Greece, Guinea, Holy See, Hungary, India, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, South Korea,
Lebanon, Lesotho, Luxembourg, Macedonia, Madagascar, Mexico, Montenegro, Morocco, Mozambique, Namibia, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Pakistan, Philippines, Poland, Portugal, Romania, Russia, Serbia, Somalia, South Africa, Spain, Sudan,
Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yemen, Zambia
United Nations Industrial Development Organization (UNIDO)
established- 17 November 1966; effective— 1 January 1967
aim-UN specialized agency that promotes industrial development especially among the members
794
INTERNATIONAL O R G A N I Z A T I O N S AND GROUPS
members— (1 72) includes all UN member countries except Andorra, Antigua and Barbuda, Australia, Brunei, Canada, Estonia, Iceland,
Kiribati, Latvia, Liechtenstein, Marshall Islands, Federated States of Micronesia, Nauru, Palau, Samoa, San Marino, Singapore, Solomon
Islands, Tuvalu, US
United Nations Institute for Training and Research (UNITAR)
established-l 1 December 1 963 adoption of the resolution establishing the Institute; effective— 24 March 1 965
aim-to help the UN become more effective through training and research
members ( Board of Trustees)— (21) Algeria, Brazil, Burkina Faso, China, Republic of the Congo, Cuba, Estonia, France (2), Ghana, India,
Iran, Japan, Kuwait, Norway, Russia, South Africa, Switzerland (2), Thailand, US; note— the UN Secretary General can appoint up to
30 members
United Nations Integrated Mission in Timor-Leste (UNMIT)
established- 25 August 2006
aim-to support the Government, to support the electoral process, to ensure the restoration and maintenance of public security
members— (14) Australia, Bangladesh, Brazil, China, Fiji, India, Malaysia, Nepal, NZ, Pakistan, Philippines, Portugal, Sierra Leone,','d8efa90071a28e68417994f003d9c0666432a61f3c44d77dcff1e6749fc4b580','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd8d3951813ceb1543ff7eb601a7c72cd828bb066756dac01481d2fc5220522',2010,'SG','Singapore','environment',1597,'United Nations Interim Administration Mission in Kosovo (UNMIK)
established-10 June 1999
aim-to promote the establishment of substantial autonomy and self-government in Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key infrastructure and humanitarian and disaster relief
note— gives civilian support only; works closely with NATO Kosovo Force (KFOR)
United Nations Interim Force in Lebanon (UNIFIL)
established-l 9 March 1978
aim-to confirm the withdrawal of Israeli forces, and assist in reestablishing Lebanese authority in southern Lebanon; established by the
UN Security Council
members— (28) Belgium, China, Croatia, Cyprus, El Salvador, France, Germany, Ghana, Greece, Guatemala, Hungary, India, Indonesia,
Ireland, Italy, South Korea, Luxembourg, Macedonia, Malaysia, Nepal, Norway, Poland, Portugal, Qatar, Slovenia, Spain, Tanzania,
Turkey
United Nations Military Observer Group in India and Pakistan (UNMOGIP)
established-24 January 1 949
aim-to observe the 1 949 India-Pakistan cease-fire; established by the UN Security Council
members— ( 8) Chile, Croatia, Denmark, Finland, Italy, South Korea, Sweden, Uruguay
United Nations Mission for the Referendum in Western Sahara (MINURSO)
established-29 April 1991
aim-to supervise the cease-fire and conduct a referendum in Western Sahara; established by the UN Security Council
members— (28) Argentina, Austria, Bangladesh, Brazil, China, Croatia, Djibouti, Egypt, El Salvador, France, Ghana, Greece, Guinea,
Honduras, Hungary, Ireland, Italy, Kenya, Malaysia, Mongolia, Nigeria, Pakistan, Paraguay, Poland, Russia, Sri Lanka, Uruguay,
SN
SG
SGP
702
SGP
•Sg
1 17 N
Pacific Ocean
1 15 N','949b06d1c32738f8005d504992e6399dc442a54a9cb45c92102250331c2e2c9b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('912576bcdbe190b97a26b721a873190972a592d978acd337ec282c5bf38fd939',2010,'YE','Yemen','environment',1598,'United Nations Mission in the Central African Republic and Chad (MINURCAT)
established-25 September 2007
aim-to create the security and conditions which will to contribute to the protection of refugees, displaced persons, and citizens in danger,
to facilitate the provision of humanitarian assistance in eastern Chad and the northeastern Central African Republic, to create favorable
conditions for the reconstruction and economic and social development of these areas
members— (22) Bangladesh, Bolivia, Brazil, Ecuador, Egypt, Gabon, The Gambia, Ghana, Jordan, Kyrgyzstan, Mali, Nepal, Nigeria,
Pakistan, Poland, Portugal, Rwanda, Senegal, Spain, Uganda, Yemen, Zambia
United Nations Mission in Ethiopia and Eritrea (UNMEE)
established 31 July 2000; aim was to monitor the cessation of hostilities; mandate ended July 2008; members were Algeria, Austria,
Bangladesh, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, China, Croatia, Czech Republic, Denmark, Finland, France, The Gambia,
Germany, Ghana, Greece, Guatemala, India, Iran, Jordan, Kenya, Kyrgyzstan, Malaysia, Namibia, Nepal, Nigeria, Norway, Pakistan,
Paraguay, Peru, Poland, Romania, Russia, South Africa, Spain, Sri Lanka, Sweden, Tanzania, Tunisia, Ukraine, US, Uruguay, Zambia
United Nations Mission in Liberia (UNMIL)
established-19 September 2003
aim-to support the cease-fire agreement and peace process, protect UN facilities and people, support humanitarian activities, and assist
in national security reform
members— (45) Bangladesh, Benin, Bolivia, Brazil, China, Croatia, Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Ethiopia,
Finland, France, Ghana, Indonesia, Jordan, Kenya, South Korea, Kyrgyzstan, Malaysia, Mali, Moldova, Mongolia, Montenegro, Namibia,
Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia, Togo, Ukraine, UK, US, Yemen,
Zambia, Zimbabwe
795
THE CIA WORLD FACTBOOK
United Nations Mission in Sierra Leone (UNAMSIL)
established on 22 October 1999; aim was to cooperate with the Government of Sierra Leone and the other parties to the Peace Agreement
in the implementation of the agreement; to monitor the military and security situation in Sierra Leone; to monitor the disarmament
and demobilization of combatants and members of the Civil Defense Forces (CFD); to assist in monitoring respect for international
humanitarian law; mandate ended 31 December 2005; members were Bangladesh, Bolivia, China, Croatia, Czech Republic, Egypt, The
Gambia, Germany, Ghana, Guinea, Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Nepal, Nigeria, Pakistan, Russia, Slovakia, Sweden,
Tanzania, Thailand, Ukraine, UK, Uruguay, Zambia
United Nations Mission in the Sudan (UNMIS)
establisbed-March 2005
aim-to support implementation of the comprehensive Peace Agreement by Monitoring and verifying the implementation of the Cease
Fire Agreement, by observing and monitoring movements of armed groups, and by helping disarm, demobilizing and reintegrating armed
bands
membm~(61) Australia, Bangladesh, Belgium, Benin, Bolivia, Botswana, Brazil, Burkina Faso, Cambodia, Canada, China, Croatia,
Denmark, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon, Germany, Greece, Guatemala, Guinea, India, Indonesia, Jordan, Kenya,
South Korea, Kyrgyzstan, Malawi, Malaysia, Mali, Moldova, Mongolia, Mozambique, Namibia, Nepal, Netherland, NZ, Nigeria, Norway,
Pakistan, Paraguay, Peru, Philippines, Poland, Romania, Russia, Rwanda, Sri Lanka, Sweden,* Tanzania, Thailand, Turkey, Uganda,
Ukraine, Uruguay, UK, Yemen, Zambia, Zimbabwe
United Nations Mission of Support in East Timor (UNMISET)
established on 17 May 2002 to provide assistance to structures critical to public security and to assist in the development of law
enforcement agencies; to contribute to external security; members were Australia, Bangladesh, Bolivia, Brazil, Denmark, Fiji, Jordan,
Malaysia, Mozambique, Nepal, NZ, Pakistan, Philippines, Portugal, Russia, Sweden; completed its mandate 20 May 2005
United Nations Monitoring, Verification, and Inspection Commission (UNMOVIC)
formerly known as United Nations Special Commission for the Elimination of Iraq’s Weapons of Mass Destruction (UNSCOM);
established December 1999 with the aim to identify, account for, and eliminate Iraq’s weapons of mass destruction and the capacity to
produce them; commissioners were from Argentina, Brazil, Canada, China, UN Department for Disarmament Affairs, France, Germany,
India, Japan, Mexico, Nigeria, Russia, Senegal, Ukraine, UK, US; finished operations 29 June 2007
United Nations Observer Mission in Georgia (UNOMIG)
establish.ed-24 August 1993
aim-to verify compliance with the cease-fire agreement, to monitor weapons exclusion zone, and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security Council
members— (32) Albania, Austria, Bangladesh, Croatia, Czech Republic, Denmark, Egypt, France, Germany, Ghana, Greece, Hungary,
Indonesia, Jordan, South Korea, Lithuania, Moldova, Mongolia, Nepal, Nigeria, Pakistan, Poland, Romania, Russia, Sweden, Switzerland,
Turkey, Ukraine, UK, US, Uruguay, Yemen
United Nations Operation in Burundi (ONUB)
was established 21 May 2004 to support and help implement the efforts undertaken by Burundians to restore lasting peace and bring
about national reconciliation; members were Algeria, Bangladesh, Belgium, Benin, Bolivia, Burkina Faso, Chad, China, Egypt, Ethiopia,
Gabon, The Gambia, Ghana, Guatemala, Guinea, India, Jordan, Kenya, South Korea, Kyrgyzstan, Malawi, Malaysia, Mali, Mozambique,
Namibia, Nepal, Netherlands, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines, Portugal, Romania, Russia, Senegal, Serbia, South
Africa, Spain, Sri Lanka, Thailand, Togo, Tunisia, Uruguay, Yemen, Zambia; mandate was completed 31 December 2006
United Nations Organization Mission in the Democratic Republic of the Congo (MONUC)
established- 30 November 1999
aim-to establish contacts with the signatories to the cease-fire agreement and to plan for the observation of the cease-fire and disengagement
of forces
members— (48) Algeria, Bangladesh, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Burkina Faso, Canada, China, Czech Republic,
Denmark, Egypt, France, Ghana, Guatemala, India, Indonesia, Ireland, Jordan, Kenya, Malawi, Malaysia, Mali, Mongolia, Morocco,
Mozambique, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Poland, Romania, Russia, Senegal, Serbia, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Tunisia, Ukraine, UK, Uruguay, Yemen, Zambia
United Nations Operation in Cote d''Ivoire (UNOCI)
established-27 February 2004
aim-to facilitate the implementation by the Ivorian parties of the peace agreement signed by them in January 2003
members— (41) Bangladesh, Benin, Bolivia, Brazil, Chad, China, Croatia, Ecuador, El Salvador, Ethiopia, France, The Gambia, Ghana,
Guatemala, Guinea, India, Ireland, Jordan, Moldova, Morocco, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines,
Poland, Romania, Russia, Senegal, Serbia, Tanzania, Togo, Tunisia, Uganda, Uruguay, Yemen, Zambia, Zimbabwe
United Nations Peacekeeping Force in Cyprus (UNFICYP)
established-4 March 1964
aim-to serve as a peacekeeping force between Greek Cypriots and Turkish Cypriots in Cyprus; established by the UN Security Council
members— ( 7) Argentina, Austria, Canada, Croatia, Hungary, Slovakia, UK
796
INTERNATIONAL O RG A N I Z A T I O N S AND GROUPS
United Nations Population Fund (UNFPA)
note— acronym retained from predecessor organization UN Fund for Population Activities
established- July 1967
aim-to assist both developed and developing countries to deal with their population problems
members (executive board )—(36) selected on a rotating basis from all regions
United Nations Relief and Works Agency for Palestine Refugees in the Near East (UNRWA)
established- 8 December 1949
aim-to provide assistance to Palestinian refugees
members ( advisory commission)— ( 22) Australia, Belgium, Canada, Denmark, EC, Egypt, France, Germany, Italy, Japan, Jordan, Lebanon,
Netherlands, Norway, Saudi Arabia, Spain, Sweden, Switzerland, Syria, Turkey, UK, US
United Nations Research Institute for Social Development (UNRISD)
established-1963
aim-to conduct research into the problems of economic development during different phases of economic growth
members— no country members, but a Board of Directors consisting of a chairman appointed by the UN secretary general and 12
individual members
United Nations Secretariat
established-26 June 1945; effective— 24 October 1945
aim-to serve as the primary administrative organ of the UN; a Secretary General is appointed for a five-year term by the General Assembly
on the recommendation of the Security Council
members— the UN Secretary General and staff
United Nations Security Council (UNSC)
established-26 June 1945; effective— 24 October 1945
aim-to maintain international peace and security
permanent members— (5) China, France, Russia, UK, US
nonpermanent members— (10) elected for two-year terms by the UN General Assembly; Austria (2009-10), Burkina Faso (2008-09), Costa
Rica (2008-09), Croatia (2008-09), Japan (2009-10), Libya (2008-09), Mexico (2009-10), Turkey (2009-10), Uganda (2009-10), Vietnam
(2008-09)
United Nations Stabilization Mission in Haiti (MINUSTAH)
established-30 April 2004
aim-to stabilize Haiti in many areas for at least six months
members— ( 1 7) Argentina, Bolivia, Brazil, Canada, Chile, Croatia, Ecuador, France, Guatemala, Jordan, Nepal, Paraguay, Peru, Philippines,
Sri Lanka, US, Uruguay
United Nations Truce Supervision Organization (UNTSO)
establisKed-June 1948
aim-to supervise the 1948 Arab-Israeli cease-fire; currendy supports timely deployment of reinforcements to other peacekeeping operations
in the region as needed; initially established by the UN Security Council
members— (23) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France, Ireland, Italy, Nepal,
Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 1 1 UN trust territories; members were
China, France, Russia, UK, US; it formally suspended operations 1 November 1995 after the Trust Territory of the Pacific Islands (Palau)
became the Republic of Palau, a constitutional government in free association with the US; the Trusteeship Council was not dissolved
United Nations University (UNU)
established-3 December 1973
aim-to conduct research in development, welfare, and human survival and to train scholars
members— (24 members of UNU Council and the Rector are appointed by the Secretary General of the United Nations and the Director
General of UNESCO)
Universal Postal Union (UPU)
established- 9 October 1874, affiliated with the UN 15 November 1947; effective— 1 July 1948
aim-to promote international postal cooperation; a UN specialized agency
members— (191) includes all UN member countries except Andorra, Marshall Islands, Federated States of Micronesia, and Palau (189
total); plus Holy See and Overseas Territories of the UK; note— includes the following dependencies or areas of special interest: Australia
(Norfolk Island), China (Hong Kong, Macau), Denmark (Faroe Islands, Greenland), France (French Polynesia including Clipperton
Island, French Southern and Antarctic Lands, Mayotte, New Caledonia, Saint Barthelemy, Saint Martin, Saint Pierre and Miquelon,
Scattered Islands {Bassas da India, Europe, Juan de Nova, Glorioso Islands, Tromelinl, Wallis and Futuna), Netherlands (Aruba,
Netherlands Antilles), NZ (Cook Island, Niue, Tokelau), UK (Guernsey, Isle of Man, Jersey; Anguilla, Bermuda, British Indian Ocean
Territory, British Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar, Montserrat, Pitcairn Islands, Saint Helena, South
797
THE CIA WORLD FACTBOOK
Georgia and South Sandwich Islands, Turks and Caicos), US (American Samoa, Guam, Northern Mariana Islands, Puerto Rico, Virgin
Islands)
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member states at the time of
dissolution were: Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier members included German Democratic
Republic (GDR) and Albania
West African Development Bank (WADB)
note— also known as Banque Ouest-Africaine de Developpement (BOAD); is a financial institution of WAEMU
establisKed-14 November 1973
aim-to promote regional economic development and integration
regional members— (8) Benin, Burkina Faso, Cote d’Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
West African Economic and Monetary Union (WAEMU)
note— also known as Union Economique et Monetaire Ouest Africaine (UEMOA)
established- 1 August 1994
aim-to increase competitiveness of members’ economic markets; to create a common market v
members— (8) Benin, Burkina Faso, Cote d’Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
Western European Union (WEU)
established-23 October 1954; effective— 6 May 1955
aim-to provide mutual defense and to move toward political unification
members— (10) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members— (6) Czech Republic, Hungary, Iceland, Norway, Poland, Turkey
associate partners— (7) Bulgaria, Estonia, Latvia, Lithuania, Romania, Slovakia, Slovenia
observers— (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association (IDA), International
Finance Corporation (IFC), and Multilateral Investment Guarantee Agency (MIGA)
World Confederation of Labor (WCL)
established 19 June 1920 as the International Federation of Christian Trade Unions (IFCTU), renamed 4 October 1968; aim was
to promote the trade union movement; on 31 October 2006 it merged with the International Confederation of Free Trade Unions
(ICFTU) to form the International Trade Union Confederation (ITUC); members were (105 national organizations) Antigua and
Barbuda, Argentina, Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada,
Central African Republic, Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d’Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana,
Gabon, The Gambia, Ghana, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia,
Iran, Italy, Japan, Kazakhstan, South Korea, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Malta, Martinique, Mauritania, Mauritius, Mexico, Morocco, Namibia, Nepal, Netherlands, Netherlands Antilles,
Nicaragua, Niger, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania, Rwanda, Saint Lucia, Saint
Vincent and the Grenadines, Sao Tome and Principe, Senegal, Serbia, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri
Lanka, Suriname, Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam, Zambia,
YM
YE
YEM
887
YEM
.ye
from DIAM 65-18 Geopolitical Data
Elements and Related Features, Data
Standard No. 3, December 1994,
published by the Defense Intelligence
Agency
Zaire
-
-
-
-
-
-
see Democratic Republic of the Congo
12 46 N
45 01 E
Aden, Gulf of
Indian Ocean
12 30 N
48 00 E
Admiralty Island
United States (Alaska)
57 44 N
134 20 W
Admiralty Islands
15 00 N
48 00 E
Aland Islands
15 00 N
50 00 E
Hagatna (capital; formerly Agana)
15 21 N
42 34 E
Kamchatka Peninsula (Poluostrov Kamchatka)
Russia
56 00 N
160 00 E
Kampala (capital)
15 00 N
44 00 E
Adantic Ocean
25 40 N
77 09 W
12 39 N
43 25 E
Pacific Ocean
44 45 N
142 00 E
Iran
32 00 N
53 00 E
Indian Ocean
27 00 N
51 00 E
15 21 N
44 12 E
Montenegro, Serbia
43 05 N
19 45 E
Bolivia
17 48 S
63 10W
12 30 N
14 00 N
48 00 E
15 00 N
44 00 E
14 00 N
46 00 E
843
Name
THE CIA WORLD FACTBOOK
Yerevan (capital)
Yokohama (city)
Youth, Isle of (Isla de la Juvenfud)
Yucatan Channel
Yucatan Peninsula
Yugoslavia (former name for a federation of Serbia and
Montenegro)
Yugoslavia, Kingdom of (former name for a Balkan federation)
Yugoslavia, Socialist Federal Republic of (former name for a
Balkan federation)
Zagreb (capital)
Zaire (former name for the Democratic Republic of the
Congo)
Zakhalinskiy Zaliv (bay)
Zaliv Shelikhova (bay)
Zambezia (region)
Zanzibar (island)
Zhong Guo, Zhonghua (local name for China)
Zion, Mount (locale in Jerusalem)
Zurich (city)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)','a72dfac8ef3371c545f874dc22074b399d2724807b17bc5a0f2d9a5b4880d8d0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d8f95b985f0f2ba636ffda35cddd48b76482bee7e818373eec509c725087771',2010,'ZW','Zimbabwe','environment',1599,'World Customs Organization (WCO)
note— began as the Customs Cooperation Council (CCC)
established-! 5 December 1950
aim-to promote international cooperation in customs matters
members— (175) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominican Republic, EC, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal,
Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Samoa, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
798
INTERNATIONAL ORGANIZATIONS AND GROUPS
World Federation of Trade Unions (WFTU)
established- 3 October 1945
aim- to promote the trade union movement
members— (174 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Angola, Anguilla, Antigua and Barbuda,
Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bermuda, Bhutan, Bolivia, Bonaire, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba,
Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Guiana, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kosovo, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Martinique, Mauritania, Mauritius, Mayotte, Mexico, Moldova, Monaco, Mongolia, Montenegro, Montserrat, Morocco,
Mozambique, Namibia, Nepal, Netherlands, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar, Reunion, Romania, Russia, Rwanda, Saint Barthelemy,
Saint Eustatius, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Martin, Saint Vincent and the Grenadines, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, Somaliland, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tahiti, Taiwan, Tajikistan, Tanzania, Thailand,
Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, US Virgin Islands,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Wallis and Futuna, Western Sahara, Yemen, Zambia, Zimbabwe, Palestine
Liberation Organization
World Food Program (WFP)
established-24 November 1961
aim-to provide food aid in support of economic development or disaster relief; an ECOSOC organization
members— ( 36) selected on a rotating basis from all regions
World Health Organization (WHO)
established- 22 July 1946; effective— 7 April 1948
aim-to deal with health matters worldwide; a UN specialized agency
members— ( 193) includes all UN member countries except Liechtenstein (191 total); plus Cook Islands and Niue
World Intellectual Property Organization (WIPO)
established- 14 July 1967; effective— 26 April 1970
aim-to furnish protection for literary, artistic, and scientific works; a UN specialized agency
members— (184) includes all UN member countries except Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, Palau,
Solomon Islands, Timor-Leste, Tuvalu, Vanuatu (183 total); plus Holy See
World Meteorological Organization (WMO)
established-ll October 1947; effective— 4 April 1951
aim-to sponsor meteorological cooperation; a UN specialized agency
members— (1 88) includes all UN member countries except Andorra, Equatorial Guinea, Grenada, Liechtenstein, Marshall Islands, Nauru,
Palau, Saint Kitts and Nevis, Saint Vincent and the Grenadines, San Marino, Timor-Leste, Tuvalu (180 total); plus Aruba and the
Netherlands Antilles, British Caribbean Territories, Cook Islands, French Polynesia, Hong Kong, Macau, New Caledonia, and Niue
World Tourism Organization (UNWTO)
established-2 January 1975
aim-to promote tourism as a means of contributing to economic development, international understanding, and peace
members— (1 54) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya, Lithuania, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members— (7) Aruba, Flanders, Hong Kong, Macau, Madeira Islands, Netherlands Antilles, Puerto Rico
observers— (1 plus Palestine Liberation Organization) Holy See, Palestine Liberation Organization
799
THE CIA WORLD FACTBOOK
World Trade Organization (WTO)
note— succeeded General Agreement on Tariff and Trade (GATT)
established-1 5 April 1994; effective— 1 January 1995
aim-to provide a forum to resolve trade conflicts between members and to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members— (153) Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Estonia, EC, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macau, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico^ Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi
Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Swaziland,
Sweden, Switzerland, Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK,
US, Uruguay, Venezuela, Vietnam, Zambia, Zimbabwe
observers— (30) Afghanistan, Algeria, Andorra, Azerbaijan, The Bahamas, Belarus, Bhutan, Bosnia and Herzegovina, Comoros, Equatorial
Guinea, Ethiopia, Holy See, Iran, Iraq, Kazakhstan, Laos, Lebanon, Liberia, Libya, Montenegro, Russia, Samoa, Sao Tome and Principe,
Serbia, Seychelles, Sudan, Tajikistan, Uzbekistan, Vanuatu, Yemen; note— with the exception of the Holy See, an observer must start
accession negotiations within five years of becoming observers
Zangger Committee (ZC)
established— early 1970s
aim-to establish guidelines for the export control provisions of the Nonproliferation of Nuclear Weapons Treaty (NPT)
members— (36) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, China, Croatia, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observers— (1) European Commission
G-20
established-created 1999; inaugerated 15-16 December 1999
aim-to promote open and constructive discussion between industrial and emerging-market countries on any issues related to global
economic stability; helps to support growth and development across the globe
members-f 1 9) Argentina, Australia, Brazil, Canada, China, France, Germany, India, Indonesia, Italy, Japan, South Korea, Mexico, Russia,
Saudi Arabia, South Africa, Turkey, UK, US
800
APPENDIX C
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Nitrogen
Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Volatile
Organic Compounds or Their Transboundary Fluxes
Antarctic — Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature-l December 1 959
entered into force-23 June 1961
objective- to ensure that Antarctica is used for peaceful purposes only (such as international cooperation in scientific research); to defer the
question of territorial claims asserted by some nations and not recognized by others; to provide an international forum for management
of the region; applies to land and ice shelves south of 60 degrees south latitude
parties-i 46) Argentina, Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy, Japan, North Korea, South Korea,
Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland,
Turkey, Ukraine, UK, US, Uruguay, Venezuela
Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
note— abbreviated as Hazardous Wastes
opened for signature-22 March 1989
entered into force-5 May 1 992
objective- to reduce transboundary movements of wastes subject to the Convention to a minimum consistent with the environmentally
sound and efficient management of such wastes; to minimize the amount and toxicity of wastes generated and ensure their environmen¬
tally sound management as closely as possible to the source of generation; and to assist LDCs in environmentally sound management of
the hazardous and other wastes they generate
parties-(172 ) Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, EU, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal, Serbia, Seychelles,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen,
ZI
ZW
ZWE
716
ZWE
• ZW
814
APPENDIX E
CROSS-REFERENCE LIST OF HYDROGRAPHIC DATA CODES
IHO 23-4ttl: Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986, published by the International Hydrographic
Bureau of the International Hydrographic Organization; note— this document has not yet been ratified and only the 3rd Edition (1953)
remains in force
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1 : Chart of Limits of Seas and Oceans, revised January 1958, published by the Aeronautical Chart and Information Center
(ACIC), United States Air Force; note— ACIC is now part of the National Geospatial-Intelligence Agency (NGA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal Information Processing Standards
(FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always directly comparable because of differ¬
ences in the customers, needs, and requirements of the individual organizations. Even the number of principal water bodies varies from
organization to organization. Factbook users, for example, find the Adantic Ocean and Pacific Ocean entries useful, but none of the
following standards include those oceans in their entirety. Nor is there any provision for combining codes or overcodes to aggregate water
bodies. The recendy delimited Southern Ocean is not included.
Principal Oceans and Seas of the World With Hydrographic Codes by Institution
IHO 23-4th
IHO 23-3rd*
ACIC M 49-1
DIAM 65-18
Arctic Ocean
9
17
A
5A
Atlantic Ocean
f
-
-
-
Baltic Sea
2
1
B26
7B
Eastern Mediterranean
3.1.2
28 B
-
8E
Indian Ocean
5
45
F
6A
Mediterranean Sea
3.1
28
Bll
- \\
North Atlantic Ocean
1
23
B
1A
North Pacific Ocean
7
57
D
3A
Pacific Ocean
-
-
-
-
South Atlantic Ocean
4
32
C
2A
South China and Eastern Archipelagic Seas
6
49, 48
D18 plus others
3U plus others
South Pacific Ocean
8
61
E
4A
Western Mediterranean
3.1.1
28 A
-
8W
*The letters after the numbers are subdivisions, not footnotes.
815
. \\ '' V* ■ '' • ■ ;
. .&■ :I. ■ ■
.
'' * ''
< • . :
''■<! %
•■ * Ji ■ ■ ; ■ m
ft
. - V 1
. , ,vf: ■■■ :? • ■: ''•
* Si ■ •
■ r ‘ . • . \\
; V- • ■ , '' .
1 ''i
- at r; :
• ''
, ;; ; ;•/ V ■* =
, - ''■ '' "* '' ''i- ''■■■ •
* *'' • ■ * ■ • , "
, •. y,- -
■ ■ -
■ - • . ,
*
. : ‘ m
■ ■?. '' . •••• ) j
■ i '' ''"*v j '' '' -y^ : * : '' •
, : ; '' ,• Vj. < , ■ .
• - ,v- vA
: > -
■ ■ • ’ 5 ,■ '' > ; * ''■
■- -yS ''• ;;-s v
l-S:r ■ . : v ''f>v" • ^
.
■a • •
• • '' ,
:<Si
• : (O'' • ..
1
T.- •• • ■'' -■ '' « '' 1 . ■ • j/\\-r ■:
APPENDIX F
CROSS-REFERENCE LIST OF GEOGRAPHIC
NAMES
Name
Entry in
Latitude
Longitude
The World Factbook
(deg min)
(deg min)
Abidjan (capital)
Cote d’Ivoire
5 19 N
4 02 W
Abkhazia (region)
17 50 S
31 03 E
Harvey Islands (former name for Cook Islands)
20 00 S
30 00 E
17 50 S
105 00 W
20 00 S
30 00 E
Armenia, Azerbaijan, Belarus'',
Estonia, Georgia, Kazakh¬
stan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan,
Ukraine, Uzbekistan','4be70d394a5b2b2ace471b6204b9be9894975a438abc0c81125dd3225c6bf89d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95295cacba355812d271977c032fcff37e2ab5fd5ab06759c31f17540957d980',2010,'ZM','Zambia','environment',1600,'countries that have signed, but not yet ratified-( 3) Afghanistan, Haiti, US
\\
Biodiversity
see Convention on Biological Diversity
801
THE CIA WORLD FACTBOOK
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
Convention for the Conservation of Antarctic Seals
note— abbreviated as Antarctic Seals
opened for signature-l June 1972
entered into force-11 March 1978
objective-to promote and achieve the protection, scientific study, and rational use of Antarctic seals, and to maintain a satisfactory balance
within the ecological system of Antarctica
parties-( 1 6) Argentina, Australia, Belgium, Brazil, Canada, Chile, France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa, UK, US
countries that have signed, but not yet ratified-(l) NZ
Convention on Biological Diversify
note— abbreviated as Biodiversity
opened for signature-5 June 1992 »
entered into force-29 December 1 993
objective- to develop national strategies for the conservation and sustainable use of biological diversity
parties-(191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guate-
mala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thai¬
land, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— ( 1) US
Convention on Fishing and Conservation of Living Resources of the High Seas
note— abbreviated as Marine Life Conservation
opened for signature-29 April 1958
entered into force-20 March 1 966
objective- to solve through international cooperation the problems involved in the conservation of living resources of the high seas, consid¬
ering that because of the development of modern technology some of these resources are in danger of being overexploited
parties-( 38) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark, Dominican Republic, Fiji,
Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia, Mauritius, Mexico, Montenegro, Netherlands, Nigeria,
Portugal, Senegal, Serbia, Sierra Leone, Solomon Islands, South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad and Tobago,
Uganda, UK, US, Venezuela
countries that have signed, but not yet ratified-( 21) Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland, Indonesia,
Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka, Tunisia, Uruguay
Convenfion on Long-Range Transboundary Air Pollution
note— abbreviated as Air Pollution
opened for signature- 13 November 1979
entered into force-16 March 1983
objective- to protect the human environment against air pollution and to gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties-i 51) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Montenegro, Netherlands, Norway,
Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
countries that have signed, but not yet ratified-(2) Holy See, San Marino
Convention on Wetlands of International importance Especially as Waterfowl Habitat (Ramsar)
note— abbreviated as Wetlands
802
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
opened for signature-2 February 1971
entered into force- 21 December 1975
objective-to stem the progressive encroachment on and loss of wedands now and in the future, recognizing the fundamental ecological
functions of wedands and their economic, cultural, scientific, and recreational value
parties-! 154) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bang¬
ladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Lucia, Samoa, Sao Tome
and Principe, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden,
Switzerland, Syria, Tanzania, Tajikistan, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Zambia
Convention on the Conservation of Antarctic Marine Living Resources
note— abbreviated as Antarctic-Marine Living Resources
opened for signature-5 May 1 980
entered into force-7 April 1 982
objective- to safeguard the environment and protect the integrity of the ecosystem of the seas surrounding Antarctica, and to conserve
Antarctic marine living resources
parties-(31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, EU, Finland, France, Germany, Greece, India, Italy, Japan,
South Korea, Mauritius, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain, Sweden, Ukraine, UK, US,
Uruguay, Vanuatu
Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
note— abbreviated as Endangered Species
opened for signature-3 March 1973
entered into force-1 July 1975
objective- to protect certain endangered species from overexploitation by means of a system of import/export permits
parties-! 1 70) Afghanistan, Albania, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bangla¬
desh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Laos, Latvia, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
note— abbreviated as Marine Dumping
opened for signature-29 December 1972
entered into force- 30 August 1975
objective-to control pollution of the sea by dumping and to encourage regional agreements supplementary to the Convention; the London
Convention came into force in 1 996
parties-(88 ) Afghanistan, Angola, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados, Belarus, Belgium, Bolivia, Brazil,
Bulgaria, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus,
Denmark, Dominican Republic, Egypt, Equatorial Guinea, Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras,
Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Libya,
Luxembourg, Malta, Mexico, Monaco, Montenegro, Morocco, Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Peru, Philippines, Poland, Portugal, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Saudi Arabia, Serbia, Seychelles, Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Trinidad and
Tobago, Tunisia, Ukraine, UAE, UK, US, Vanuatu
associate members to the London Convention-(2) Faroe Islands, Macau countries that have signed, but not yet ratified-(3) Chad, Kuwait, Uruguay
803
THE CIA WORLD FACTBOOK
Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
note— abbreviated as Environmental Modification
opened for signature-10 December 1976
entered into force— 5 October 1978
objective- to prohibit the military or other hostile use of environmental modification techniques in order to further world peace and trust
t
among nations
parties-(13) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Bangladesh, Belarus, Belgium, Benin,
Brazil, Bulgaria, Canada, Cape Verde, Chile, China, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Egypt, Finland,
Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy, Japan, Kazakhstan, North Korea, South Korea, Kuwait, Laos,
Lithuania, Malawi, Mauritius, Mongolia, Netherlands, NZ, Nicaragua, Niger, Norway, Pakistan, Panama, Papua New Guinea, Poland,
Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Slovakia, Slovenia, Solomon Islands, Spain,
Sri Lanka, Sweden, Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified-( 16) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran, Iraq,
Lebanon, Liberia, Luxembourg, Morocco, Portugal, Sierra Leone, Syria, Turkey, Uganda
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling
note— abbreviated as Whaling
opened for signature-2 December 1 946
entered into force- 10 November 1948
objective- to protect all species of whales from overhunting; to establish a system of international regulation for the whale fisheries to
ensure proper conservation and development of whale stocks; and to safeguard for future generations the great natural resources repre¬
sented by whale stocks
parties— (84) Antigua and Barbuda, Argentina, Australia, Austria, Belgium, Belize, Benin, Brazil, Cambodia, Cameroon, Chile, China,
Republic of the Congo, Costa Rica, Cote D’Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominica, Ecuador, Eritrea, Estonia,
Finland, France, Gabon, The Gambia, Germany, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Hungary, Iceland, India, Ireland,
Israel, Italy, Japan, Kenya, Kiribati, South Korea, Laos, Lithuania, Luxembourg, Mali, Marshall Islands, Mauritania, Mexico, Monaco,
Mongolia, Morocco, Nauru, Netherlands, NZ, Nicaragua, Norway, Oman, Palau, Panama, Peru, Portugal, Romania, Russia, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino, Senegal, Slovakia, Slovenia, Solomon Islands, South Africa,
Spain, Suriname, Sweden, Switzerland, Tanzania, Togo, Tuvalu, UK, US, Uruguay
International Tropical Timber Agreement, 1983
note— abbreviated as Tropical Timber 83
opened for signature-18 November 1983
entered into force- 1 April 1985; this agreement expired when the International Tropical Timber Agreement, 1994, went into force
objective- to provide an effective framework for cooperation between tropical timber producers and consumers and to encourage the devel¬
opment of national policies aimed at sustainable utilization and conservation of tropical forests and their genetic resources
parties-(5 9) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African Republic, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland,
France, Gabon, Germany, Ghana, Greece, Guatemala, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Mexico, Nepal, Netherlands, NZ, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Russia, Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Vanuatu, Venezuela
International Tropical Timber Agreement, 1994
note— abbreviated as Tropical Timber 94
opened for signature-26 January 1994
entered into force- 1 January 1997
objective- to ensure that by the year 2000 exports of tropical timber originate from sustainably managed sources; to establish a fund to
assist tropical timber producers in obtaining the resources necessary to reach this objective
parties-(6l ) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African Republic, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland,
France, Gabon, Germany, Ghana, Greece, Guatemala, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
804
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Luxembourg, Malaysia, Mexico, Nepal, Netherlands, NZ, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Poland,
Portugal, Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Vanuatu, Venezuela
Kyoto Protocol to the United Nations Framework Convention on Climate Change
note— abbreviated as Climate Change-Kyoto Protocol
opened for signature- 16 March 1998
entered into force— 23 February 2005
objective- to further reduce greenhouse gas emissions by enhancing the national programs of developed countries aimed at this goal and
by establishing percentage reduction targets for the developed countries
parties-! 184) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Island, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified— (2) Kazakhstan, US
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
note— abbreviated as Ozone Layer Protection
opened for signature-16 September 1987
entered into force- 1 January 1989
objective- to protect the ozone layer by controlling emissions of substances that deplete it
parties-i 1 94) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guate¬
mala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozam¬
bique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
note— abbreviated as Ship Pollution
opened for signature-17 February 1978
805
THE CIA WORLD FACTBOOK
entered into force— 2 October 1983
objective- to preserve the marine environment through the complete elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances
parties-( 139) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Cape Verde, Chile, China, Colombia,
Comoros, Republic of Congo, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, Equatorial Guinea, Estonia, Faroe Islands, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guatemala, Guinea, Guyana, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Libya, Macau, Madagascar,
Malawi, Malaysia, Maldives, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Nedierlands, NZ, Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines,
Poland, Portugal, Qatar Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,- Slovenia, South Africa, Spain, Sri Lanka, Suri¬
name, Sweden, Switzerland, Syria, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu,
Vene','c0d82ef28cf03bb92c3486db0aec500c79a99f23b8bb63f2671f2d3faa19042a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62e4707329dc811ed36364ff085a6d1cd46d7c8e00dc5733914e1d6e18d4958e',2010,'ZM','Zambia','environment',1601,'zuela, Vietnam
Protocol on Environmental Protection to the Antarctic Treaty
note— abbreviated as Antarctic-Environmental Protocol
opened for signature- 4 October 1991
entered into force- 14 January 1998
objective- to provide for comprehensive protection of the Antarctic environment and dependent and associated ecosystems; applies to the
area covered by the Antarctic T reaty
consultative parties-(31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, China, Czech Republic, Ecuador, Finland, France,
Germany, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Romania, Russia, South Africa, Spain, Sweden,
Ukraine, UK, US, Uruguay
non consultative parties — (1 2) Austria, Colombia, Cuba, Denmark, Greece, Guatemala, Hungary, North Korea, Papua New Guinea,
Slovakia, Switzerland, Turkey
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Nitrogen
Oxides or Their Transboundary Fluxes
note— abbreviated as Air Pollution-Nitrogen Oxides
opened for signature-31 October 1988
entered into force- 14 February 1991
objective- to provide for the control or reduction of nitrogen oxides and their transboundary fluxes
parties-( 32) Austria, Belarus, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, EU, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Liechtenstein, Lithuania, Luxembourg, Netherlands, Norway, Russia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified-(l) Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Volatile
Organic Compounds or Their Transboundary Fluxes
note— abbreviated as Air Pollution-Volatile Organic Compounds
opened for signature-18 November 1991
entered into force-29 September 1 997
objective- to provide for the control and reduction of emissions of volatile organic compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse effects
parties-{23) Austria, Belgium, Bulgaria, Croatia, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy, Liechten¬
stein, Lithuania, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified-( 6) Canada, EU, Greece, Portugal, Ukraine, US
Profocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur Emissions
note— abbreviated as Air Pollution-Sulphur 94
opened for signature-l 4 June 1 994
entered into force-5 August 1 998
objective- to provide for a further reduction in sulfur emissions or transboundary fluxes ,
parties-( 28) Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, EU, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Liechtenstein, Lithuania, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden, Swit¬
zerland, UK
countries that have signed, but not yet ratified-( 3) Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air Poliution on Persistent Organic Pollutants
note— abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature- 24 June 1998
entered into force-23 October 2003
806
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
objective-to provide for the control and reduction of emissions of persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse effects
parties-( 29) Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, EU, Finland, France, Germany,
Hungary, Iceland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg, Moldova, Netherlands, Norway, Romania, Slovakia, Slovenia,
Sweden, Switzerland, UK
countries that have signed, but not yet ratified-(8 ) Armenia, Greece, Ireland, Poland, Portugal, Spain, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
note— abbreviated as Air Pollution-Sulphur 85
opened for signature-8 July 1985
entered into force-2 September 1 987
objective- to provide for a 30% reduction in sulfur emissions or transboundary fluxes by 1 993
parties-(23) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Lithuania, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space, and Under Water
note— abbreviated as Nuclear Test Ban
opened for signature-5 August 1 963
entered into force- 10 October 1963
objective- to obtain an agreement on general and complete disarmament under strict international control in accordance with the objec¬
tives of the United Nations; to put an end to the armaments race and eliminate incentives for the production and testing of all kinds of
weapons, including nuclear weapons
parties-(l 13) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas, Bangladesh, Belgium, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma, Canada, Central African Republic, Chad, China,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote d’Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia,
Luxembourg, Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San Marino,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US, Venezuela, Zambia
countries that have signed, but not yet ratified-( 1 7) Algeria, Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya, Mali, Pakistan,
Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam, Yemen
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS)
note— abbreviated as Law of the Sea
opened for signature-1 0 December 1 982
entered into force-1 6 November 1 994
objective-to set up a comprehensive new legal regime for die sea and oceans; to include rules concerning environmental standards as well
as enforcement provisions dealing with pollution of the marine environment
parties-{151) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain, Bangla¬
desh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Cameroon, Canada, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Egypt, Equatorial Guinea,
Estonia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South
Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama,
Papua New Guinea, Paraguay, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and
Tobago, Tunisia, Tuvalu, Uganda, Ukraine, UK, Uruguay, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
807
THE CIA WORLD FACTBOOK
countries that have signed, but not yet ratified-( 21) Afghanistan, Bhutan, Burundi, Cambodia, Central African Republic, Chad, Colombia,
Dominican Republic, El Salvador, Ethiopia, Iran, North Korea, Libya, Liechtenstein, Malawi, Niger, Rwanda, Swaziland, Switzerland,
Thailand, UAE
United Nations Convention to Combat Desertification in Those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
note— abbreviated as Desertification
opened for signature-14 October 1994
entered into force-26 December 1 996
objective- to combat desertification and mitigate the effects of drought through national action programs that incorporate long-term strate¬
gies supported by international cooperation and partnership arrangements
parties-(193) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechten¬
stein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauri¬
tius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru,
Nepal, Nedierlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Thai¬
land, Tanzania, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
United Nations Framework Convention on Climate Change
note— abbreviated as Climate Change
opened for signature-9 May 1992
entered into force-21 March 1994
objective-to achieve stabilization of greenhouse gas concentrations in the atmosphere at a low enough level to prevent dangerous anthro¬
pogenic interference with the climate system
parties-(l92) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d’Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guate¬
mala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lidiuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thai¬
land, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Wetlands
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for die Regulation of Whaling
808
APPENDIX D
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
FIPS 10: Countries, Dependencies, Areas of Special Sovereignty, and Their Principal Administrative Divisions ( FIPS 10) is maintained by the
Office of Targeting and Transnational Issues, National Geospatial-Intelligence Agency, and published by the National Institute of Stand¬
ards and Technology (Department of Commerce). FIPS 10 codes are intended for general use throughout the US Government, especially
in activities associated with the mission of the Department of State and national defense programs.
ISO 3166: Codes for the Representation of Names of Countries ( ISO 3166) is prepared by the International Organization for Standardiza¬
tion. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be needed for activities involving
exchange of data with international organizations that have adopted that standard. Except for the numeric codes, ISO 3166 codes have
been adopted in the US as FIPS 104-1: American National Standard Codes for the Representation of Names of Countries, Dependencies, and
Areas of Special Sovereignty for Information Interchange.
STAN AG 1059: Letter Codes for Geographical Entities (8th edition, 2004) is a Standardization Agreement (STANAG) established and
maintained by the North Atlantic Treaty Organization (NATO/OTAN) for the purpose of providing a common set of geo-spatial identi¬
fiers for countries, territories, and possessions. The 8th edition established trigraph codes for each country based upon the ISO 3166-1
alpha-3 character sets. These codes are used throughout NATO.
Internet: The Internet country code is the two-letter digraph maintained by the International Organization for Standardization (ISO) in
the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers Authority (IANA) to establish country-coded top-level domains
(ccTLDs).
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
ZA
ZM
ZMB
894
ZMB
.zm
15 25 S
28 17 E
15 00 S
30 00 E
Arctic Ocean
74 40 N
100 00 W
Adantic Ocean
66 00 N
6 00 E
15 00 S
30 00 E
836
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Rhodesia, Southern (former name for Zimbabwe)
Riga (capital)
Riga, Gulf of
Rio Muni (mainland region)
Rio de Janiero (city)
Rio de Oro (region)
Rio de la Plata (gulf)
Riyadh (capital)
Road Town (capital)
Robinson Crusoe Island (Mas a Tierra)
Rocas, Atol das (island)
Rockall (island)
Rodrigues (island)
Rome (capital)
Roncador Cay (island)
Roosevelt Island
Roseau (capital)
Ross Dependency (claimed by New Zealand)
Ross Island
Ross Sea
Rossiya (local name for Russia)
Rota (island)
Rotuma (island)
Ruanda (former name for Rwanda)
Rub al Khali (desert)
Rumelia (region)
Ruthenia (region; former name for Carpatho-Ukraine)
Ryukyu Islands
Saar (region)
Saaremaa (island)
Saba (island)
Sabah (state)
Sable Island
Safety Islands (lies du Salut)
Sahara Occidental (former name for Western Sahara)
Sahel (region)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)','0b047a1b5e1e431f4aec72383960e672c3c801c59d28657b09f9617ca5fcd435','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fd510bf161380d3ac05be698d639d169f0892b8426d7844f29112aa495baa2f',2010,'AF','Afghanistan','environment',1602,'AF
AF
AFG
004
AFG
.af
33 00 N
65 00 E
Agalega Islands
34 31 N
69 12 E
Kaduna (city)
37 00 N
73 00 E
37 00 N
73 00 E','bbe3687ee6306d32bf25b482598ba7ff2ea94c037a56accfe2f260f51ad17942','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f90310273c8316af9d8642057d3bac19ab5d0f548d0b8b86fdea4a1b86065f61',2010,'DZ','Algeria','environment',1603,'AG
DZ
DZA
012
DZA
.dz
28 00 N
3 00 E
Al Kuwayt (local name for Kuwait)
36 47 N
2 03 E
Alhucemas, Penon de (island group)
35 43 N
0 43 W','253da75126397c0e23e86ff3b14f611da3aa06f7c67678154da0d8d69a789de3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8612169b26ed16798717fd7c030511f95360c8fc7803360f9c46dacdfebc3d98',2010,'AS','American Samoa','environment',1604,'AQ
AS
ASM
016
ASM
.as
14 20 S
170 00 W
14 16 S
170 42 W
11 03 S
171 15 W
14 18 S
170 42 W
Adantic Ocean
40 00 N
12 00 E','c084fea909c6e5a32409f938afa033261433ab7ea679670eb3fbf1a1104d1af5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('869b365533fc8fd0e95a6f792ae5c149a3976929bc1cc6b99c7b26306542b9a1',2010,'AO','Angola','environment',1605,'AO
AO
AGO
024
AGO
.ao
5 33 S
12 12 E
Cape Verde
16 00 N
24 00 W
Atlantic Ocean
47 20 N
59 30 W
8 48 S
13 14 E
fCablruJa)
c e a u
St. Helena
(U.K.)
St. Helena
(St. Helena)
Namibe
laic yc$0!txtm
Victoria
*','184d935910a46b0e6cc458e7d3e8dd00b72cca23515c0765c5c134414c49f14a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64f3b2449714bc1a46147c1e4f44f56a2789f72b224ea0bb1648e013aefaa4bb',2010,'AQ','Antarctica','environment',1606,'AY
AQ
ATA
010
ATA
•aq
ISO defines as the territory south of 60
degrees south latitude
66 30 S
139 00 E
Aden (city)
71 00 S
70 00 W
Alexandretta (region; former name for Iskenderun)
Turkey
36 34 N
36 08 E
Alexandria (city)
67 00 S
163 00 E
Balochistan (region)
79 30 S
49 30 W
62 56 S
60 34 W
Adantic Ocean
67 00 N
24 00 W
French Southern and Antarctic
49 30 S
69 30 E
Lands
75 00 S
92 00 W
65 00 S
64 00 W
Argentina, Paraguay
24 00 S
60 00 W
The Bahamas
26 40 N
78 35 W
Atlantic Ocean
47 06 N
55 48 W
77 00 S
130 00 W
Saint Martin
18 04 N
63 05 W
68 48 S
90 35 W
Russia
59 55 N
30 15 E
73 30 S
12 00 E
Taiwan
24 27 N
118 23 E
79 30 S
162 00 W
80 00 S
180 00 E
81 30 S
175 00 W
Antarctica, Southern Ocean
76 00 S
175 00 W
Russia
60 00 N
100 00 E
67 24 S
179 55 W
The Gambia, Senegal
13 50 N
15 25 W
838
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Senyavin Islands
Seoul (capital)
Serendib (former name for Sri Lanka)
Serrana Bank (shoal)
Serranilla Bank (shoal)
Settlement, The (capital)
Severnaya Zemlya (island group; also Northland)
Shaba (region)
Shag Island
Shag Rocks
Shanghai (city)
Shenyang (city; also Mukden)
Shetland Islands
Shikoku (island)
Shikotan (island)
Shqiperia (local name for Albania)
Siam (former name for Thailand)
Siberia (region)
Sibufu Passage
Sicily (island)
Sicily, Strait of
Sidra, Gulf of
Sikkim (state)
Silesia (region)
Sinai Peninsula
Singapore (capital)
Singapore Strait
Sinkiang (autonomous region; also Xinjiang)
Sint Eustatius (island)
Sint Maarten (island; also Saint-Martin)
Sjaelland (island)
Skagerrak (strait)
Skopje (capital)
Slavonia (region)
Slovenija (local name for Slovenia)
Slovensko (local name for Slovakia)
Smyrna (region; former name for Izmir)
Society Islands (lies de la Soclete)
Socotra (island)
Sofia (capital)
Solomon Islands, northern
Solomon Islands, southern
Solomon Sea
Somaliland (region)
Somers Islands (former name for Bermuda)
Songkhla (city)
Sound, The (strait; also Oresund)
South Atlantic Ocean
South China Sea
South Georgia (island)
South Island
South Korea
South Orkney Islands
Entry in
The World Factbook
Latitude
(deg min)
Federated States of Micronesia
6 55 N
South Korea
37 34 N
61 00 S
Longitude
(deg min)
158 00 E
127 00 E
81 00 E
80 16 W
79 46 W
105 43 E
98 00 E
27 00 E
72 30 E
42 02 W
121 30 E
123 24 E
I 30 W
133 30 E
146 45 E
20 00 E
100 00 E
100 00 E
119 35 E
14 00 E
II 20 E
18 00 E
88 30 E
17 00 E
34 00 E
103 51 E
104 00 E
86 00 E
62 58 W
63 04 W
12 00 E
9 00 E
21 26 E
18 00 E
15 00 E
19 30 E
27 10 E
150 00 W
54 00 E
23 19 E
1 55 00 E
159 00 E
153 00 E
46 00 E
64 45 W
100 36 E
12 40 E
15 00 W
1 1 3 00 E
36 45 W
171 00 E
127 30 E
45 00 W
839
Name
THE CIA WORLD FACTBOOK
South Ossetia (region)
South Pacific Ocean
South Sandwich Islands
South Shetland Islands
South Tyrol (region)
South Vietnam (former name for the southern portion of
Vietnam)
South Yemen (People''s Democratic Republic of Yemen; now
part of Yemen)
South-West Africa (former name for Namibia)
Southern Grenadines (island group)
Southern Rhodesia (former name for Zimbabwe)
Soviet Union (former name of a large Eurasian empire,
roughly coequal with the former Russian Empire)
Spanish Guinea (former name for Equatorial Guinea)
Spanish Morocco (former name for northern Morocco)
Spanish North Africa (exclaves)
Spanish Sahara (former name)
Spanish West Africa (former name for Ifni and Spanish
Sahara)
Spice Islands (Moluccas)
Spitsbergen (island)
Srbija (local name for Serbia)
St. John''s (city)
Stanley (capital)
Stockholm (capital)
Strasbourg (city)
Stuttgart (city)
Sucre (constitutional capital)
Suez Canal
Suez, Gulf of
Suisse (local French name for Switzerland)
Sulawesi (island; Celebes)
Sulawesi Sea
Sulu Archipelago (island group)
Sulu Sea
Sumatra (island)
Sumba (island)
Sumba Strait
Sumbawa (island)
Sunda Islands (Soenda Isles)
Sunda Strait
Suomi (local name for Finland)
Surabaya (city)
Surigao Strait
Surinam (former name for Suriname)
Suriyah (local name for Syria)
Surtsey (volcanic island)
Suva (capital)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
62 00 S
59 00 W
66 30 S
139 00 E
French Southern and Antarctic
43 00 S
67 00 E
Lands
Pacific Ocean
10 00 N
101 00 E
Macedonia
41 50 N
22 00 E
72 20 S
99 00 W
72 00 S
155 00 E
71 00 S
120 00 E
Netherlands Antilles
12 06 N
68 56 W
Political Map of the World, June 2009
REFERENCE MAPS
POLITICAL MAP OF THE WORLD
863
THE CIA WORLD FACTBOOK
SOUTH AMERICA','9dba4fb616e91395c3c241096ab353622e608938c0fc76d76d9dcf35eda796f5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0680a1b888b4a532dee8dc96a4f11380f489e23121e862f16b87c86dba52ccb0',2010,'AG','Antigua and Barbuda','environment',1607,'AC
AG
ATG
028
ATG
•ag
14 34 N
90 44 W
17 38 N
61 48 W
Barcelona (city)
16 55 N
62 19 W
17 06 N
61 51 W','7f12ee99c1952c0b90a03f503fc91cfdeb7b646736b766a854b092275ee06424','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27e088a335d89854f7aa8f9b597d6166af72b00cfa024c9590b8caf06ba1111d',2010,'AR','Argentina','environment',1608,'AR
AR
ARG
032
ARG
.ar
34 36 S
58 27 W
35 00 S
63 00 W
48 00 S
61 00 W
><;Xi.i4 Ida
SOUTH
Orcadas
J | (ARGENTINA)
SOUTH ORKNEY
ISLANDS
SANAE IV
Neumaycr (SOUTH Novolazarevskaya "X,
(GERMANY! ALKK!AKry0,. Russia)
r (LM,y ■ ■ V -
•*». MM Svowa (JAPAN)
French Southern- '' ''
and Antarctic Lands
(FRANCE)
m
SHOULD ^
Usjrtiaia ISLANDS » r?
; Ur.iK^','d91789c9f675d2690e9d68fd353117c9df2f39425b8cb9d72cab54c54217de10','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47fa6a1304ee3a1dd234a1ce659467805c9cb3e55e2701766a5511acc3aa4ebc',2010,'AM','Armenia','environment',1609,'AM
AM
ARM
051
ARM
.am
40 00 N
45 00 E
Heard Island
Heard Island and McDonald
Islands
53 06 S
73 30 E
Hejaz (region)
40 11 N
44 30 E
Japan ,
35 26 N
139 37 E','79f74d33b53704889c6061454e8cc1bae700151eebfa86109634c3248905a26d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15e4e420430a53555574e2b35291915541bd5df198fb0e7c89e96cc46f074ab2',2010,'AW','Aruba','environment',1610,'AA
AW
ABW
533
ABW
.aw
Ashmore and Cartier Islands
AT
-
-
-
AUS
-
ISO includes with Australia
12 33 N
70 06 W
Adantic Ocean
55 50 N
12 40 E','50a33f0a81a3dfc8fc2b00427427c1e3dd4f9bfbd0be763fa41ff80de37cba25','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9168727381f140721d07ee1be59cd57ecc58d95da532b0faac5213ea2b72623',2010,'AU','Australia','environment',1611,'AS
AU
AUS
036
AUS
.au
ISO includes Ashmore and Cartier
Islands, Coral Sea Islands
10 12 S
142 16 E
Banks Island
27 28 S
153 02 E
Pacific Ocean
57 00 N
160 00 W
Atlantic Ocean
51 18 N
3 30 W
35 17 S
149 08 E
23 15 S
155 32 E
Russia
42 00 N
45 00 E
10 25 S
105 39 E
31 30 S
159 00 E
54 36 S
158 54 E
37 49 S
144 58 E
31 56 S
115 50 E
Taiwan
23 30 N
119 30 E
33 53 S
151 13 E
43 00 S
147 00 E
Pacific Ocean
50 00 N
141 00 E
Russia
76 00 N
104 00 E','29049b1d653f949dbb78c5fe622f4b5fca81b9155199a469c52e5ef6c3bb4bc1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74c9798d68659bb3004e0886300c22bf2c54956b9796f87e49f03fc76fa58304',2010,'AT','Austria','environment',1612,'AU
AT
AUT
040
AUT
.at
47 20 N
13 20 E
Ethiopia, Somalia
7 00 N
46 00 E
47 48 N
13 02 E
48 12 N
16 22 E
Laos
17 58 N
102 36 E','234a8b6e043122ac80eadc03e139a32fd4c55d0187e3c0b998fec13c4091bd9e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f8b5246db18c448210b45a3d8889f714fce662a5e17e07f14983fbcb113eeb1',2010,'AZ','Azerbaijan','environment',1613,'AJ
AZ
AZE
031
AZE
.az
Bahamas, The
BF
BS
BHS
044
BHS
.bs
40 30 N
47 30 E
Azores (islands)
40 23 N
49 51 E
Balabac Strait
Pacific Ocean
7 35 N
117 00 E
Balearic Islands
40 00 N
46 40 E
39 20 N
45 20 E','0f66db86034c3aec6232d1bad484ff1e93d5f6b9e390ee3318c2706bfd54820e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3984b97be52331b85d49e672b25c6dd2b6ddc60c28b78ec7b9e6a6ef910e7c9',2010,'BH','Bahrain','environment',1614,'BA
BH
BHR
048
BHR
.bh
Baker Island
FQ
-
-
UMI
ISO includes with the US Minor
Oudying Islands
26 00 N
50 33 E
Al Imarat al Arabiyah al Muttahidah (local name for the
7 00 N
81 00 E
Russia (Big Diomede), United
65 47 N
169 00 W
States (Little Diomede)
25 40 N
50 47 E
Hayastan (local name for Armenia)
26 13 N
50 35 E','305cbfbf0cb1c8255f1032c80552fee5f03de18f601482f7e35dc9b99f21052a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2e5624bdc35be6639b4cf719377cf9cdfc09b1bae34cdf04504844b7dc101e9',2010,'BD','Bangladesh','environment',1615,'BG
BD
BGD
050
BGD
.bd
23 43 N
90 25 E
24 00 N
90 00 E
Arctic Ocean
74 00 N
166 00 E','b004f694b870e935d8c4b7b1273b0af9fb2db96e23d0488e8c24d2ac94cdba18','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79ca458877252d7c43142f9006c7c555e1c7122c7b77793c32fbc3e53cd763db',2010,'BB','Barbados','environment',1616,'BB
BB
BRB
052
BRB
.bb
Bassas da India
BS
administered as part of French
Southern and Antarctic Lands; no ISO
codes assigned
13 06 N
59 37 W','67e3a49bfc9f747218517d2bba3b1474778f7d3f9fe625b4bed94c765f98ecba','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f7dc2a590e0a257d8ae49d1cd66f82bef0a8259eeed4d9a8dd3e256d50476c',2010,'BY','Belarus','environment',1617,'BO
BY
BLR
112
BLR
.by
53 00 N
28 00 E
53 00 N
28 00 E
53 00 N
28 00 E
53 54 N
27 34 E
832
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Misr (local name for Egypt)
Mitla Pass
Mocambique (local name for Mozambique)
Mogadishu (capital)
Moldavia (region)
Molucca Sea
Moluccas (Spice Islands)
Mombasa (city)
Mona Passage
Monaco (capital)
Mongol Uls (local name for Mongolia)
Monrovia (capital)
Monterrey (city)
Montevideo (capital)
Montreal (city)
Moravia (region)
Moravian Gate (pass)
Moroni (capital)
Mortlock Islands (Nomoi Islands)
Moscow (capital)
Mount Pinatubo (volcano)
Mozambique Channel
Mumbai (city; also Bombay)
Munich, Muenchen (city)
Muritaniyah (local name for Mauritania)
Musandam Peninsula
Muscat (capital)
Muscat and Oman (former name for Oman)
Myanma, Myanmar
N''Djamena (capital)
Nagorno-Karabakh (region)
Nairobi (capital)
Namib (desert)
Nampo-shoto (island group)
Nan Madol (ruins)
Naples (city)
Nassau (capital)
Natal (region)
Natuna Besar Islands
Natuna Sea
Naxcivan (region)
Naxos (island)
Nederland (local name for the Netherlands)
Nederlandse Antillen (local name for the Netherlands
Antilles)
Negev (region)
Negros (island)
Nejd (region)
Netherlands East Indies (former name for Indonesia)
Netherlands Guiana (former name for Suriname)
Nevis (island)
New Britain (island)
New Delhi (capital)
New Guinea (island)
New Hebrides (island group)
New Ireland (island)
New Siberian Islands
New Territories (mainland region)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Warsaw^','343ca5a535ea6e785f283cd46d08514777e8b9f1f4888ceac230fec404d287ca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74e051d3ebe6f477466fe9a560efecc23455011cd46447a1931be8b799894a21',2010,'BE','Belgium','environment',1618,'BE
BE
BEL
056
BEL
.be
51 13 N
4 25 E
Macau
22 10 N
113 33 E
50 50 N
4 00 E
50 50 N
4 20 E
50 26 N
6 02 E
Colombia ,
4 00 N
90 30 W
Atlantic Ocean
56 44 N
26 53 E
Falkland Islands
51 45 S
59 00 W
(Islas Malvinas)','e3209690837adafcdaf6692c9ae65c4dba6e4dc924ae53033f77d8725127a307','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e86e41c7dddd5fd7274fab3a1fbe3a4ecaa58b76b8ed4c02cd795064cf6eb284',2010,'BZ','Belize','environment',1619,'BH
BZ
BLZ
084
BLZ
.bz
17 30 N
88 12 W
Atlantic Ocean
51 35 N
56 30 W
Southern Ocean
71 00 S
85 00 W
17 15 N
88 46 W
17 15 N
88 45 W','85e876256eb32bc4c979ba0e695f94844af2290ee5fe796abf2ef641c32fca04','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a828becaba2b2dfd8dc88714330460354e58b02bac5a4607178d8f5a0d1df49',2010,'BM','Bermuda','environment',1620,'BD
BM
BMU
060
BMU
.bm
32 17 N
64 46 W
Han-guk (local name for South Korea
South Korea
37 00 N
127 30 E
Hanoi (capital)
Vietnam
21 02 N
105 51 E
Harare (capital)
32 20 N
tu.iu
lid
a 11 1 1 c
Oklahoma City
Phoenix Albuquerque
*.." " . .A ; ;
^Atlanta ‘charleston
f \\ (.) c e a n
Dallas*
Ciudad
Juarez
‘llermoslllo
111 Paso
Jacksonville^
San Houston ;
Antonio *-vz-
New Orleans.:
‘Chihuahua
Miami
THE BAHAMAS
.Nassau
M
t.a Pa?:,
%
Monrcrrev
• *
Torre on
Cildt Of h''U’XiC.
V
Matamoros
Havana.
★','90655b248697dfa164806bb719f9a3264275c7ebd3a4241483440b27a949e7bf','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbfc4f3729a9aea2ac5c32f468a8e88a34d2e03ed460bcb061cf13a3b632b961',2010,'BT','Bhutan','environment',1621,'BT
BT
BTN
064
BTN
.bt
Bolivia
BL
BO
BOL
068
BOL
.bo
27 30 N
90 30 E
27 28 N
89 39 E','3e04440199f52ad2c641bd7a55ea903d623c0b2aca45b794c2ac03385dd5684f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4b0dddae0b9690edf9ba18ca1cf59c8087b4ac44ea82fd32ea79370983944e5',2010,'BA','Bosnia and Herzegovina','environment',1622,'BK
BA
BIH
070
BIH
.ba
44 00 N
18 00 E
44 00 N
18 00 E
Atlantic Ocean
41 00 N
29 00 E
Atlantic Ocean
63 00 N
20 00 E
44 00 N
18 00 E
Hiiumaa (island)
43 52 N
18 25 E','d15650a415fafe270a790856c697b82067334857e1c197cdd84e187a3cec6aee','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee5b2cb6b0783f9377591ac2e4bb57a13d9f93f1288ddc6392dd61c347bd2fb',2010,'BW','Botswana','environment',1623,'BC
BW
BWA
072
BWA
.bw
809
THE CIA WORLD FACTBOOK
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
22 00 S
24 00 E
Beijing (capital)
24 45 S
25 55 E','5c8eef7e9f2f7a4036d3689b2d9b8811fa1ea4288cfedfb0e5cfbd61828bde1c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67d4c0733c9e357a5779833ca00cd5d23dc9049151145a876d825906ce75baf4',2010,'BV','Bouvet Island','environment',1624,'BV
BV
BVT
074
BVT
.bv
" (NORWAY;
PRINCE HOWARD ISLANDS
(SOUTH AFRICA)
m
/
FalKland Islands ''
(tsias Malvinas) •
(administered by U<K.,
claimed by ARGENTINA)
St^ut h Georgia and the
"South Sandwich Islands
(administered by. U.K..
claimed hv ARGENTINA1)''
ARGENTINE
CLAIM
BRITISH
CLAIM
j
J Southern !
Ocean
NORWEGIAN CLAIM
\\
ILLS
CROZET
undefined limit
kA/ .','831f061ee317cb679fed2bf4a77bce77baf9aeba21e53f4fe7ac7be342bf113c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d823e5d38da852dbd20f234eab93ee52c7bc13924cb93fc4d68d77a535a69626',2010,'BR','Brazil','environment',1625,'BR
BR
BRA
076
BRA
.br
15 47 S
47 55 W
3 51 S
32 25 W
20 30 S
28 51 W
22 55 S
43 17 W
3 51 S
33 49 W
0 23 N
29 23 W
Russia
59 55 N
30 15 E
Virgin Islands
18 21 N
64 55 W
Adantic Ocean
13 30 N
61 00 W
Reunion
20 52 S
55 28 E
23 35 S
46 43 W
0 23 N
29 23 W
Cape Verde
15 05 N
23 40 W
20 31 S
29 20 W','024777f7c7ba92e379b22940d3bfd1b4a560be527680ebaf2fac84d569e7354b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('223da61a1e3d4d39e946b457a3c62a72261375b83190f4dbc020eaa570f20d28',2010,'IO','British Indian Ocean Territory','environment',1626,'IO
IO
IOT
086
IOT
.io 1
British Virgin Islands
VI
VG
VGB
092
VGB
•vg
Brunei
BX
BN
BRN
096
BRN
.bn
6 00 S
71 30 E
Pacific Ocean
11 22 N
142 36 E
Guernsey, Jersey
49 20 N
2 20 W
Virgin Islands
18 21 N
64 56 W
7 20 S
72 25 E
6 00 S
71 30 E
Pacific Ocean
53 00 N
150 00 E','992ee7610c1b34befdb835e9e554aff5a7ae8a68c83882e2e0852236cf9d7e14','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b28cfc8a29cbc1bfd5e3a5d086d930927582422e1b2bfe8f951a67f82fc993c3',2010,'BF','Burkina Faso','environment',1627,'UV
BF
BFA
854
BFA
.bf
Burma
BM
MM
MMR
104
MMR
.mm
ISO uses the name Myanmar
12 22 N
1 31 W
13 00 N
2 00 W
Kazakhstan, Russia
60 00 N
60 00 E','393fb51929ce555b5d4b8585df5db91ce4ebbcb82e57f73bb1682c7c02161fa3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6bbcde64092bcd1b45b104ff417a7c15be1e618c7b5bce79d43ad1573149337',2010,'BI','Burundi','environment',1628,'BY
BI
BDI
108
BDI
.bi
3 23 S
29 22 E
Romania, Ukraine
48 00 N
26 00 E
3 30 S
30 00 E
China, Russia
48 28 N
135 02 E','21f4c2541087ae03923fcfba2d8d229c529f56975139a23a5f54cac9a436b102','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f37a24a1b2bfeffdfc8826e51940eac2e46609cd9484389eb69d59e156cd9ce',2010,'KH','Cambodia','environment',1629,'CB
KH
KHM
116
KHM
.kh
13 26 N
103 50 E
13 00 N
105 00 E
Kane Basin (portion of channel)
Arctic Ocean
79 30 N
68 00 W
Kanton Island
13 00 N
105 00 E
Khuriya Muriya Islands (Kuria Muria Islands)
11 33 N
104 55 E','f2f8ef2e6b9a17cc10ec76cf43f0cfd66131492c6bcbaa012d03d748ad13a132','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('243e24c1ceb9a12bfef97b47bbdc5fbd0bc6ab5bfb84f9d84e7bdc302455fa5f',2010,'CM','Cameroon','environment',1630,'CM
CM
CMR
120
CMR
V «v
.cm
6 00 N
12 00 E
4 03 N
9 42 E
Man, Isle of
54 09 N
4 28 W
Atlantic Ocean
51 00 N
1 30 E
Atlantic Ocean, Southern
60 00 S
60 00 W
Ocean
6 00 N
12 00 E
3 52 N
11 31 E
Federated States of Micronesia
9 30 N
138 00 E
Oouala
?* *
Yaounde1
Bangui
r','0515579e0aaf304e8fbbfdc73c92e5af1ad3805c1f09475b1a15ddfd4a40bf52','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deec88a84d7027ebdd149bae691b9fd55b4908e1c9db6ba28dd8263eec40d6b9',2010,'CA','Canada','environment',1631,'CA
CA
CAN
124
CAN
.ca
Cape Verde
CV
CV
CPV
132
CPV
.CV
79 30 N
90 00 W
68 00 N
70 00 W
Baghdad (capital)
75 15 N
121 30 W
Banks Islands (lies Banks)
51 02 N
114 04 W
Pacific Ocean
28 00 N
112 00 W
76 00 N
87 00 W
78 00 N
103 00 W
81 00 N
80 00 W
824
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Ellice Islands
Ellsworth Land (region)
Elobey, Islas de (island group)
Enderbury Island
Enewetak Atoll (Eniwetok Atoll)
England (region)
English Channel
Eniwetok Atoll (see Enewetak Atoll)
Eolie, Isole (island group)
Epirus, Northern (region)
Episkopi Cantonment (capital)
Ertra (local name for Eritrea)
Espana
Essequibo (region; claimed by Venezuela)
Etorofu (island; also Iturup)
Farquhar Group (island group; also Atoll de Farquhar)
Fergana Valley
Fernando Po (island; see Bioko)
Fernando de Noronha (island group)
Filipinos (local name for the Philippines; also Pilipinas)
Finland, Gulf of
Fiume (city; former name for Rijeka)
Florence (city)
Flores (island)
Flores Sea
Florida, Straits of
Fongafale (largest island of Funafuti)
Former Soviet Union (FSU)
Formosa (island)
Formosa Strait (see Taiwan Strait)
Foroyar (local name for Faroe Islands)
Fort-de-France (capital)
Frankfurt am Main (city)
Franz Josef Land (island group)
Freetown (capital)
French Cameroon (former name for Cameroon)
French Guinea (former name for Guinea)
French Indochina (former name for French possessions in
southeast Asia)
French Morocco (former name for Morocco)
French Somaliland (former name for Djibouti)
French Sudan (former name for Mali)
French Territory of the Afars and Issas (or FTAI; former name
for Djibouti)
French Togoland (former name for Togo)
French West Indies (former name for French possessions in
the West Indies)
Friendly Islands
Frisian Islands
Frunze (city; former name for Bishkek)
Funafuti (capital, atoll)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
44 39 N
63 36 W
Halmahera (island)
54 00 N
62 00 W
Atlantic Ocean
60 00 N
55 00 W
45 31 N
73 34 W
Czech Republic
49 30 N
17 00 E
Czech Republic
49 35 N
17 50 E
52 00 N
56 00 W
72 00 N
90 00 W
45 25 N
75 40 W
46 20 N
63 20 W
76 30 N
119 00 W
46 48 N
71 15 W
53 00 N
132 00 W
78 00 N
95 00 W
43 55 N
59 50 W
47 12 N
60 09 W
43 40 N
79 23 W
Pacific Ocean
10 25 S
142 10 E
49 16 N
123 08 W
842
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Vancouver Island
Vatican City (capital)
Velez de la Gomera, Penon de (island)
Venda (enclave)
Verde Island Passage
Victoria (capital)
Victoria (island)
Victoria Land (region)
Vienna (capital)
Vientiane (capital)
Vilnius (capital)
Viti Levu (island)
Vladivostok (city)
Vojvodina (region)
Volcano Islands
Vostok Island
Wake Atoll
Wakhan Corridor (see Vakhan)
Walachia (region)
Wales (region)
Wallis Islands
Walvis Bay (city; former exclave)
Warsaw (capital)
Washington, DC (capital)
Weddell Sea
Wellington (capital)
West Frisian Islands
West Germany (Federal Republic of Germany; former name
for western portion of Germany)
West Island (capital)
West Korea Strait (Western Channel)
West Pakistan (former name for present-day Pakistan)
West Siberian Plain
Western Channel (West Korea Strait)
Western Samoa (former name for Samoa)
Wetar Strait
White Sea
Wilkes Land (region)
Willemstad (capital)
Windhoek (capital)
Windward Passage
Winnipeg (city)
Wrangel Island (Ostrov Vrangelya)
Xianggang (local name for Hong Kong)
Y''israel (local name for Israel)
Yaitopya (local name for Ethiopia)
Yalu River
Yamoussoukro (capital)
Yangon (see Rangoon)
Yaounde (capital)
Yap Islands
Yaren (governmental center)
Yekaterinburg (city; formerly Sverdlovsk)
Yellow Sea
Yemen Arab Republic (also Yemen (Sanaa);
former name for northern portion of Yemen)
Yemen, People''s Democratic Republic of (also Yemen
(Aden); former name for southern portion of Yemen)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
49 45 N
126 00 W
Holy See
41 54 N
12 27 E
71 00 N
110 00 W
49 53 N
97 10W
Russia
71 14 N
179 36 W','f8b5de2f96cdb3f1ef71d752db87e093f9350111843de2e336a3e9a92176ed78','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('502a33f9a8ad1ae7984e56a8427da9299512a8fd216785d732b78c4c5a30d05d',2010,'CF','Central African Republic','environment',1632,'CT
CF
CAF
140
CAF
.cf
4 22 N
18 35 E
Banjul (capital)
The Gambia
13 28 N
16 39 W
Banks Island
7 00 N
21 00 E
Pacific Ocean
2 30 S
129 30 E
Czech Republic
49 45 N
15 30 E
Czech Republic, Slovakia
49 00 N
17 30 E
7 00 N
21 00 E
6 38 N
20 33 E','004f7583242aa4f902c8121d87a5ed6308b943796ee380ae8ca1937eb8210630','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('048031c4369301c5a19a31c88524357c8c20941d94dd97cc5681ef14a23bb6c5',2010,'TD','Chad','environment',1633,'CD
TD
TCD
148
TCD
.td
22 00 N
18 00 E
12 07 N
15 03 E
15 00 N
19 00 E
Kinder
;L»cV
(fetves/;
Socotra
N''Djamena
guinea-bissAi
v 1 s ''
Addis * VV
,..J Ababa
"x ETHIOPIA
, Hargeysa
X. ;
Pn>v
CENTRAL AFRICAN
REPUBLIC','f5023eac2e6efbfc7dd20cc83490936c783144f520b1813278d430acf6ca5e01','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e21ee07bde78b697433687a71d3c5dbd6903783bd6f8075348a8284ffd6e8255',2010,'CL','Chile','environment',1634,'Cl
CL
CHL
152
CHL
.cl
23 00 S
70 10W
24 30 S
69 15 W
42 50 S
74 00 W
56 30 S
68 43 W
27 07 S
109 22 W
Pacific Ocean
34 00 N
129 00 E
55 59 S
67 16 W
Horne, lies de (island group)
33 00 S
80 00 W
Pacific Ocean
48 18 N
124 00 W
Indian Ocean
27 40 N
33 55 E
Israel, West Bank
31 35 N
35 00 E
Bosnia and Herzegovina,
43 00 N
21 00 E
Croatia, Macedonia, Monte¬
negro, Serbia, Slovenia
33 38 S
78 52 W
Mauritius, Reunion
21 00 S
57 00 E
27 07 S
109 22 W
Afghanistan, Pakistan
32 00 N
69 00 E
Clipperton Island
10 17 N
109 13 W
27 07 S
109 22 W
33 38 S
78 52 W
26 28 S
105 00 W
26 21 S
79 52 W
26 17 S
80 05 W
33 27 S
70 40 W
Cape Verde
17 05 N
25 10W
>area of
^-n I <i rge m c rvt
t/y
(INDIA)
s\\. Weddell Sea
X W
j. ,/ Queen Maud Land
P''UdlleyiU.R.)
/ Belgrano II
M"'' . . ‘
''O V
x*e.
iW''-
■v,
V*v
XV - rY
CHILEAN I
CLAIM
m w .
South
V ?&c it i c
\\ O c e a n
AAS&:~^P,limC: Ax: . \\A ''"A''''
i
i r l •*,
SeHittyfidtiSEtt A !/■■■. fy- ■
J Ellsworth 1
JL _ tyMmMmJl,
#‘*A1 olodezhnaya
X '' /RUSSIA)
Enderbv ’ , ) M
\\ lif/lrf rf, y''''''
\\ -
® Mavvson
Mp''V.abecfsen (AUSTRALIA)
X lUIld \\ V ,
, X '' r~o£VV''A'' ''• , , - . :
y'' Q. V/ A,v,. .-(f :
-Zhong ShaniCHlNA)!
j/.HS
KERGUELEN H
Heard Island and
McDonald Islands
(AUSTRALIA)
Amundsen-Scott
, . 4897m) ^ pa,J 4 (U.S.)
J Land isnone "%*.
Mo ^
j, son m
( Bentley Subglacial Trench
A/4'' v iio/vvvt point in Anwetich. -2540 mj '' N
Morfe Byrd
hand
Amundsen ’ ke.T
Sea M ^ —
w
R(,M
1X1 \\ \\\\/
\\v)
Progress (RUSSIA)
Vostok
B(RUSSIA)
Concordia
(FRANCE AND /
■ TTAI-Y)
HavisfAUSTRALlA)
V?
I
AS . . . . !
± Mirnyv
+ (RUSSIA)
l Indian \\
. — 80 E 4-
O c e a n ¥
\\
> r > , (
A '' ’
//< ttiii:
J
/ A"''
it Casey
\\
Xvo.rzy''. >r:r ;«wt;>n
Argentina. Srazil, Chlic< China, Poland.
Russia. South Korea, Uruguay each have
a station on King George Island. A
rY” iAEspcranza
''||(ARCiF:NTiNA)
4 ■ Marambio 5.)
(ARGENTINA)
M\\
■ <!■/
A?
.. / ??
Arturo
(CHILE''
w
ft
OTiiggtnS:
, (£tliMy|
70
As
% ''
V
c-
\\ <V--''OV
\\ ^
K" A V '' ^gC?™»s
,-C?\\ jfjrah^m. . !''r
rs''iiif "h- mQ ■
■ W*''? VernbdsAv''r \\ %
Antarct^f^L^
• M
1 CyS’ VC<? .Vtdf
i.5«er>
Peninsula
Mi /X ■■
7i5 !
; youthen;
A Ocean
MM
A. -Vr.
San1!
A?
i
■ >vx ;
L/ ''
\\
XMcMUrdo \\ \\
\\ \\
(H|Z.) \\ \\\\
| y 4 \\ y
A Victoria Land \\ "% ''/
1 -X
../AUSTRALIA) ^
/ ^
/ "V. ^
%. /
V
/
I . . to \\
Scott
’/•w Island
''A- WAki
AW-^-'' ’ LTumont d’Urville
/ h . . (FRANCE)
%
HALLES'' X -v
ISL.ANDS
Southern
Ocean
\\F
FRENCH
& CLAIM
'' 4?
ON.
Ci4/W
South
P a c I f ( c
O c e an""~-
CHATHAM ISLANDS
(HF.W ZEALAND)
Campbell
Island
tfSEW Zr.AI.AND,
HEW
ZEALAND,
Macquarie Island
'' lAUSIRAUA)
AUCKLAND ISLANDS
^ y (NEW ZEALAND)
SNARES ISLANDS
"(NEW ZEALAND)
South Island
./
./
Tasmania
\\ yv^.
\\ ,4.Hdbart
\\ -i
\\ \\y ,sy
.Ad/
Kt)
Adelaide
Melbourne .#
/
1 Chfistc hutch
Wellington^ ( / .. ,%o-
. Canberra
/
iso
Sydney
\\ AUSTRALIA
m \\ PC
.XT.,-.:
U North Island
8031 21 Al (R02207) 3-05
854
REFERENCE MAPS
JAPAfi
.. occupied by fh#'' Sisv''nit Union in i fH5.
admimscerc''d b/Rufc$la. claimed by Japan.
{•’etropavlovsk
Kamchafskiy,
Serine
Mart h P a c I
Sakhalin
Khabarovsk
Okhotsk
Bethel
Magadan
Provideniy.
Artadvr''
Valdez
UNITED STATES v
Fairbanks ?/
juneau
Oymyakon
nawson
]/ l Vrangel
Isldiut
Yakutsk
WaiMJt!
laU
'' ^ftarr0W
Prudhoe
Bay
Verkhoyansk
'' a Bav
V-llowknite
'' NEW" i
SIBERIAN
ISLANDS
me (5Q«F) isotherm,
\\ -1 U ; ;
fete i
Catnbt i i H
Bav
M AD A
SEVERNA%\\
ZEMLYA
RUSSIA
iUZjvBBTH
North
Pale
BBaMM
Norii''sk;
. . fefe#fe
Repulse Bay
Dikson
FRANZ feUT
IOSEF teg
LAND te y
Qaanaaq
ITIiuJe)
NOVAYA
ZEMLYA
'' Svalbard
(NORWAY)','a841c71161ef2d24b886b7055a51b22d49ec668ab5ff376f3a36f3ba563da277','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c878b7b2ca6d2437b4d43ac15120e3b21b28f49f33089006c3e7aba104a48619',2010,'CN','China','environment',1635,'CH
CN
CHN
156
CHN
.cn
see also Taiwan
39 56 N
116 24 E
Beirut (capital)
23 06 N
113 16 E
30 43 N
104 04 E
35 00 N
105 00 E
Taiwan
23 30 N
121 00 E
Moldova
47 00 N
28 50 E
23 09 N
113 21 E
Guantanamo Bay (US Naval Base)
19 00 N
109 30 E
Haiphong (city)
Vietnam
20 52 N
106 41 E
Hala''ib Triangle (region)
Egypt (claimed), Sudan
(de facto)
22 30 N
35 00 E
Halifax (city)
36 00 N
84 00 E
Russia (de facto)
46 10N
152 00 E
22 10N
113 33 E
44 00 N
124 00 E
44 00 N
124 00 E
39 56 N
116 24 E
31 14 N
41 46 N
42 00 N
Netherlands Antilles
17 29 N
Netherlands Antilles
18 04 N
32 00 N
90 00 E
35 00 N
105 00 E
Israel, West Bank
31 46 N
35 14 E','1fddac4cc8d7b10b85bf98c0f78b821b6ecc3cb6216098523c82f666a5d81e3c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7bc604b36f01a9856d8264be5fcd603ce4f787f0763100932c5d2b6c3a980da',2010,'CX','Christmas Island','environment',1636,'KT
cx
CXR
162
CXR
.cx
Clipperton Island
IP
*
-
-
FYP
-
ISO includes with French Polynesia
10 25 S
Russia
79 30 N
Democratic Republic of the
8 00 S','c63c9ec0f56b1468aa8d58ac41c16962477720990283b648f0124675d160fd7f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e01b4a1d7166cd0c28b67391641953ca62864df07e83d526862bde1bc623e918',2010,'CC','Cocos (Keeling) Islands','environment',1637,'CK
cc
CCK
166
AUS
•CC
12 30 S
96 50 E
12 30 S
96 50 E
Kerguelen, lies (island group)
French Southern and Antarctic
Lands
49 30 S
69 30 E
Kermadec Islands
12 10S
96 55 E
Pacific Ocean
34 40 N
129 00 E','f101afa512c3c9149eb72c71e11d34af0c7d94a5793548684e62ab9198672f6f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae72167e63286e44a2240921d389846edc79b0672ae987a69f8105b8e61102a5',2010,'CO','Colombia','environment',1638,'CO
CO
COL
170
COL
.CO
10 59 N
74 48 W
Bashi Channel
Pacific Ocean
22 00 N
121 00 E
Basilan Strait
Pacific Ocean
6 49 N
122 05 E
Basque Provinces
4 36 N
74 05 W
Czech Republic
50 00 N
14 30 E
13 32 N
80 03 W
13 00 N
81 30 W
Pacific Ocean
12 32 N
124 10 E
14 25 N
15 51 N','61d81783c8bef8e249b4aace9beb29fbdfab3cca3d4c0fb96dee50bc4f67bb8b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bf29ae967b9e84411ddde7f3a85b92a969b51b129ae8d66532bccb9acd23a0e',2010,'KM','Comoros','environment',1639,'CN
KM
COM
174
COM
.km
Congo, Democratic Republic
CG
CD
COD
180
COD
.cd
formerly Zaire
of the
Congo, Republic of the
CF
CG
COG
178
COG
•eg
12 15 S
44 25 E
Turkey
39 56 N
32 52 E
12 10S
44 15 E
Vietnam
8 43 N
106 36 E
11 41 S
43 16 E
Federated States of Micronesia
5 30 N
153 40 E
Russia
55 45 N
37 35 E
. Moroni
*
-Oiortojw iskmds
(fUAHCE!
Walvis Bay
Scale 1:51,400,000
Azimuthal Equal-Area Projection
''mjmeHn Island
I PRAflCE}
Cape Town ^
Pretoria
SOUTH SWAZILAND
<-y\\%: * Maseru/ ''
AFRicr-^ /Durban
rtrniV-A LESOTHO
''Z: ■''
Port Elizabeth
800 Kilometers
— 1 - - - ,
800 Miles
Boundary representation Is
not necessarily authoritative.
853
THE CIA WORLD FACTBOOK
ANTARCTIC REGION
/
/
■ Year-round research station
Scale 1:68,000,000
'' Azimuthal Equal-Area Projection
0 500 1000 Kilometers
• ! — , — i - L, 1 r
Port Elizabeth
/ SOOTH •.*
AFRICA
*?,
5 o wt h I A 1 1 a n id c
f i
O tie a n
0
500
— ~i
1000 Miles
Twenty one of 2# Antarctic consultative nations have
made no claims to Antarctic territory (although Russia
and the United Stales have reserved the right to do so)
and they do not recognize the claims of the other. .
nations. -xA','55a5ac087b48479eda5f9fb165b3e1d007359556634705d0f05ac6b8843be092','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3602c1df7d8a496f70ee3177bdcb6a329cfa8ddd97c5e73f008cc97c7fcf2d05',2010,'CK','Cook Islands','environment',1640,'CW
CK
COK
184
COK
.ck
Coral Sea Islands
CR
-
-
-
AUS
-
ISO includes with Australia
21 12 S
159 46 W
10 53 S
165 49 W
Adantic Ocean
58 00 N
11 00 E
Virgin Islands
18 20 N
64 50 W
21 14 S
159 46 W
Hatay (province)
Turkey
36 30 N
36 15 E
Havana (capital)
10 53 S
165 49 W
India, Pakistan
30 50 N
73 30 E','8c6062026895b1373dccb90b8c08722cd4992eec03362ab3ffc759d9b1a09115','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d01904c5181aaec60f2f407bc93d7b2922f93d8990946e4305d52e608a33f1b6',2010,'CR','Costa Rica','environment',1641,'cs
CR
CRI
188
CRI
.cr
Cote d''Ivoire
IV
Cl
CIV
384
CIV
.ci
5 32 N
87 04 W
9 56 N
84 05 W','a2397a5da1f897f42d35c612370b3658832f7185c0baabc32838a1257dac8e4e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d4bcf470f28131a8952f23762a26d1296c1aacdfee464f175caa830c850106d',2010,'HR','Croatia','environment',1642,'HR
HR
HRV
191
HRV
.hr
43 00 N
17 00 E
45 19 N
14 25 E
45 10 N
15 30 E
827
Name
THE CIA WORLD FACTBOOK
Hudson Bay
Hudson Strait
Hunter Island
Iberian Peninsula
Iceland Sea
%
Ifni (region; former name of part of Spanish West Africa)
Inaccessible Island
Indochina (region)
Ingushetia (region)
Inhambane (region)
Inini (former name for French Guiana)
Inland Sea
Inner Hebrides (islands)
Inner Mongolia (region; also Nei Mongol)
Ionian Islands
Ionian Sea
Irian Jaya (province)
Irish Sea
Iron Gate (river gorge)
Iskenderun (region; formerly Alexandretfa)
Islamabad (capital)
Island (local name for Iceland)
Islas Malvinas (island group)
Istanbul (city)
Istrian Peninsula
Italia (local name for Italy)
Italian East Africa (former name for Italian possessions in
eastern Africa)
Italian Somaliland (former name for southern Somalia)
Ittihad al-lmarat al-Arabiyah (local name for the United Arab
Emirates)
Iturup (island; see Etorofu)
Ityop''iya (local name for Ethiopia)
Ivory Coast (former name for Cote d''Ivoire)
Iwo Jima (island)
Izmir (region)
Jakarta (capital)
James Bay
Jamestown (capital)
Jammu (city)
Jammu and Kashmir (region)
Japan, Sea of
Jars, Plain of
Java (island)
Java Sea
Jerusalem (capital, proclaimed)
Jiddah, Jeddah (city)
Johannesburg (city)
Joseph Bonaparte Gulf
Juan Fernandez, Islas de (island group)
Juan de Fuca, Strait of
Jubal, Strait of
Judaea (region)
Jugoslavia, Jugoslavia (local names for Yugoslavia, a
former Balkan federation)
Jutland (region)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Arctic Ocean
60 00 N
86 00 W
Arctic Ocean
62 00 N
71 00 W
New Caledonia, Vanuatu
22 24 S
172 06 E
Portugal, Spain
40 00 N
5 00 W
Arctic Ocean
68 00 N
20 00 W
42 24 N
18 31 E
45 27 N
45 48 N
15 58 E
Democratic Republic of the
15 00 S
30 00 E','b756ed4bebe81eeef8b96141a2b579fe264450794dc9dd24171e7c3a75788591','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eff0b71da243697260f887ddf4e1bf178b24d3acdf725549471b6cc02dec3182',2010,'CU','Cuba','environment',1643,'cu
CU
CUB
192
CUB
XU
20 00 N
75 08 W
Guatemala (capital)
23 08 N
82 22 W
Hawaii (island)
21 40 N
82 50 W
Kabardino-Balkaria (region)
Russia
43 30 N
43 30 E
Kabul (capital)
21 40 N
82 50 W
21 40 N
82 50 W
Atlantic Ocean
21 45 N
85 45 W
liil
: Mazatlart
\\ MEXICO
Scale: 1:38,700,000
Lambert Conformal Conic Projection,
standard parallels 3 7 “N and 63 °<V
Guadalajara ^ •
l.eon
0 AOO t>00 KifomCters
l- - ,
ISIAS
RCVlUAalGLDO
(MEXteo;
300
800 Mites
''% Mexico *
% ;
Acapulco*
Itampico
:4 .Veracruz
Puebla
Oaxaca
Cancun*
Merida
Kingston','eb4e60cd68496f2767dc4b0858a31a76f42453ca4d40eb652b9c71f62edc0d36','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92e494b111b00100eb20aa5fd7dbcbc4009ccb80773aebd15ed551b2f8e96a13',2010,'CY','Cyprus','environment',1644,'CY
CY
CYP
196
CYP
•cy
Czech Republic
EZ
CZ
CZE
203
CZE
.CZ
35 00 N
33 00 E
Kiel Canal (Nord-Ostsee Kanal)
Adantic Ocean
53 53 N
9 08 E
Kiev (city; former name for Kyiv)
35 00 N
33 00 E
Kirghizia, Kirgizia (former name for Kyrgyzstan)
35 10N
33 22 E
35 ION
33 22 E
Saint Helena
37 25 S
12 30 W
35 15 N
33 44 E
Albania, Greece
40 00 N
20 30 E
Saint Vincent and the
12 45 N
61 15 W
Grenadines
Beirut
Lebanon;
ISRAEL h
Tel Aviv-//
Port Yafo #
/§aid }erusaje^?|
''amascus
Ahvaz
Kerman
Gaza Strip/
.Suez 1
SINAI
PENINSULA
Caira
A I Jfzah','7debaa2f8318fac84ee59c8b3d72075fba7ba862c147e67b06720cc293669a03','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50dc8dbb479a63dac1e9031741a7a38db9ed4b27906d2def6079b13c5ffb3dc0',2010,'DK','Denmark','environment',1645,'DA
DK
DNK
208
DNK
.dk
55 10 N
15 00 E
55 40 N
12 35 E
Pacific Ocean
15 00 S
150 00 E
56 00 N
10 00 E
55 20 N
10 25 E
56 00 N
9 15 E
828
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Juventud, Isla de la (Isle of Youth)
55 30 N
Adantic Ocean
57 45 N
Macedonia
41 59 N','c7ddc5fa067819152eb055e5949bff71ddd99ad460d215fad008c280a356d5e4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96764f270a3e78dce48f68320c1e4ce554bade821715f4feeb99821693b102b5',2010,'DJ','Djibouti','environment',1646,'DJ
DJ
DJI
262
DJI
.dj
11 30 N
43 00 E
name for Djibouti)
Afghanestan (local name for Afghanistan)
11 30 N
43 15 E
Belarus, Russia, Ukraine v
46 30 N
32 18 E
(Dnyapro, Dnepr, Dnipro)
Moldova, Ukraine (Nistru,
46 18 N
30 17 E
Dnister)
Bulgaria, Romania
43 30 N
28 00 E
1 1 30 N
43 00 E
11 30 N
43 00 E
MIDDLE EAST
ft f
:’- W\\ •','ed3b8029457b2ac66c34a7eea1700754b5ab17134390221a154404f29ee45cb4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef564cacd4cd06648e0789ed07b6610700bb9ffd2a7276b6b8d59c702672e593',2010,'EC','Ecuador','environment',1647,'EC
EC
ECU
218
ECU
.ec
0 00 N
90 30 W
Russia
55 00 N
167 00 E
0 39 S
78 26 W
Guyana, Suriname
5 57 N
57 06 W
0 00 N
90 30 W
Poland, Ukraine
49 30 N
23 00 E
0 13 S
78 30 W','2f64fdd023072d4bcc7051c17eb8420750262f2d0e3eb71885bc66523194f1c3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2451828966fa64270492200c644d842b9553cca7ca03beb833cc20e56e7fe84a',2010,'EG','Egypt','environment',1648,'EG
EG
EGY
818
EGY
•eg
31 12 N
29 54 E
Algiers (capital)
30 03 N
31 15 E
30 13 N
33 09 E
30 20 N
32 23 E
27 00 N
30 00 E
30 02 N
32 54 E
29 30 N
29 55 N
32 33 E
Indian Ocean
28 10 N
33 27 E
CTUit
■ Manama
f QATAR
5<h''Aii u<
Viwmiz
Luxor
cf HOMAN
Dubai''
Abu
Dhabi
Doha
Omxn
Riyadh
Muscat
Aswan
Yanbu’*:
a 1 Bohr
UNITED ARAB /
AtJmwIstraffVfi
% dowtHfeiy ■
Jlala''ib
|iddah«','3069cafce70aa0e1302eaff60dc05a9803601852241b49fc94ddf2d8d343bf8e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d6071f9a2f5366b69877cc18a8700ddb2f471c11420196ca22792f80f69222d',2010,'GQ','Equatorial Guinea','environment',1649,'EK
GQ
GNQ
226
GNQ
•gq
1 25 S
5 36 E
3 30 N
8 42 E
Adantic Ocean
44 00 N
4 00 W
0 55 N
9 19 E
0 59 N
9 33 E
3 30 N
8 42 E
2 00 N
10 00 E
Guinea, Gulf of
Adantic Ocean
3 00 N
2 30 E
Guinee (local name for Guinea)
3 45 N
8 47 E
Indian Ocean
2 30 N
101 20 E
1 30 N
10 00 E
2 00 N
10 00 E','f2dfc1e3b16f3be35cbfe1967b6fc3e3d830e04a0a18d49a1c5490029dd85a00','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab15f12f024ca4081c152357c8138cf82d2c3d6e591fffd54f2383c7d16917bd',2010,'EE','Estonia','environment',1650,'EN
EE
EST
233
EST
.ee
59 00 N
26 00 E
58 50 N
22 30 E
Hispaniola (island)
Dominican Republic, Haiti
18 45 N
71 00 W
Ho Chi Minh City (formerly Saigon)
Vietnam
10 45 N
106 40 E
Hokkaido (island)
58 25 N
22 30 E
Netherlands Antilles
17 38 N
63 10W
59 25 N
24 45 E
Tanzania
6 00 S
35 00 E','5acd04641badfbf0e573be0db6bb3b94a0a2fa6103359fa9142a0bd145256ef7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa31f37f426f0b3b774dcf74afd64d55ae579b5d181b82b1e18b6ea4eb6263c',2010,'ET','Ethiopia','environment',1651,'ET
ET
ETH
231
ETH
.et
Europa Island
EU
administered as part of French
Southern and Antarctic Lands; no ISO
codes assigned
Falkland Islands (Islas
FK
FK
FLK
238
FLK
.fk
Malvinas)
8 00 N
38 00 E
Acapulco (city)
9 02 N
38 42 E
Adelie Land (claimed by France; also Terre Adelie)
8 00 N
38 00 E
Cote d’Ivoire
8 00 N
5 00 W
8 00 N
38 00 E
China, North Korea
39 55 N
124 20 E
Cote d’Ivoire
6 49 N
5 17 W
Burma
16 47 N
96 10 E','01729a38f4a6d89611a0777ba3df1ef9f3bfdb5634d2000e9c0c7247cf40138f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2816bf0c40a1be5c6d193bb128607fe1ae6203fdead7dabdeaab34e736c22089',2010,'FJ','Fiji','environment',1652,'FJ
FJ
FJI
242
FJI
•6
18 20 S
178 30 E
12 30 S
177 05 E
18 08 S
178 25 E
840
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Sverdlovsk (city; also Yekaterinburg)
Sverige (local name for Sweden)
Svizzera (local Italian name for Switzerland)
Swains Island
Swan Islands
Sydney (city)
T''bilisi (capital)
Tadzhikistan (former name for Tajikistan)
Tahiti (island)
Taipei (capital)
Taiwan Strait
Tallinn (capital)
Tanganyika (former name for the mainland portion of
Tanzania)
Tangier (city)
Tannu-Tuva (region)
Tarawa (island)
Tartary, Gulf of
Tashkent (capital)
Tasman Sea
Tasmania (island)
Tatar Strait
Taymyr Peninsula (Poluostrov Taymyr)
Tchad (local name for Chad)
Tegucigalpa (capital)
Tehran (capital)
Tel Aviv (capital, de facto)
Teluk Bone (gulf)
Teluk Tomini (gulf)
Terre Adelie (claimed by France; also Adelie Land)
Terres Australes et Antarctiques Francoises (local name for
the French Southern and Antarctic Lands)
Thailand, Gulf of
The Former Yugoslav Republic of Macedonia
Thessaloniki (city; also Salonika)
Thimphu (capital)
Thuringia (region)
Thurston Island
Tiberias, Lake
Tibet (autonomous region; also Xizang)
Tibilisi (see Tbilisi)
Tien Shan (mountains)
Tierra del Fuego (island, island group)
Timor (island)
Timor Lorosa''e (local name for Timor-Leste)
Timor Sea
Tinian (island)
Tiran, Strait of
Tirana, Tirane (capital)
Tirol, Tyrol (region)
Tobago (island)
Tokyo (capital)
Tonkin, Gulf of
Toronto (city)
Torres Strait
Torshavn (capital)
Toshkent (see Tashkent)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Russia
56 50 N
60 39 E
18 00 S
178 00 E
Russia
43 10N
131 56 E','e46c255889d827f88be35c0f37237c1cf2f583a649fa1cdac1a1fa5fe03c8bde','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('483ed15f6ab8302653a7f0e210a82db40f8d920e32c7f84bacc9567ca57c87e6',2010,'FI','Finland','environment',1653,'FI
FI
FIN
246
FIN
.ft
60 15 N
20 00 E
Alaska (state)
60 10 N
24 58 E
Herzegovina (political region)
64 00 N
26 00 E
Tampere
liHMS
/■r-x me X:
/ . *'' e . krXppw
;k ,; „."''f vf
mSSI ,, > , ||
; *<**’«* 5 /4 » . *j
* * ^ y A Ctavl^. r Aaint Petersburg
rf''''"7'','' ''/X''
////;''/,/; ■///. , A V
ypxp
I n ^
''rw^r ,''^::::l RUSSIA
HEBRIDES /S V?
■■■91
* • Ford ten y
Stockholm, / ^wnds ^ Tallinn \\
nX ESTOfiiA \\
SA ’ (A Z''Sdxl
•<i l I V. y :
„ ,, . . .... : W
/X
Wy*>- A
kk - - •'' j
Moscow
...,4 LATVIA \\
a .X-v-j .
V USSi
/Al 4s * ^Edinburgh
p^lifrr ,
^ Dubifw; ^
■vfWPi, & Nr$ S, ‘Manchester
A I KCLAnJJ <jF tiverpooi f'',
,. - *
- Cardiff Birmifh*m/AmSteri
J Ar''Rotterd^-:
/'' : London*''''^-,
•; '' A"'' f
l Lille* £ BKL. Bonn
k i
■>>''■ * y- -<
m
'' ''$} S''dtk Stii I /''r" V" * ;•
" '' | \\ LJTHUATiiA F VitSyehsk
| Ik Vilnius, MahilyowA
^ “toPtfiw»( A M,|sk Vi ,.,./
n-i ^ . V"'' BELARUS .,-y
>-^■4’- i''AC* ..<- GdaAsIc , Hrodna \\ , \\ P >
rn h \\ Horn , V
Hamburg P } Xhernihiv ‘
, a "a.. ,v i Warsaw l. v™**
Bremen ;^. t»C« lilt, pozni^fi \\ r~X
i * v .. ‘FOLAF1D
'' { ''*.w, f od Z :
Py
yy
w*
«%y- ''<y
)SKErn ^p*8. \\ : - *, Wroclaw
Coiogpe:
wm ife v %= . v sJm .
Zhytomyr','2f26ebf2f6ec1c6814c583b24ad662cbd2c97eecb9af1ca38d09fe23e88cb0ee','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c83bf6741ae3cdfb489e90fbdd5fd8d48617a0b5d5ed9054cbad6b8f4932cad5',2010,'FR','France','environment',1654,'FR
FR
FRA
250
FRA
.fr
France, Metropolitan
-
FX
FXX
249
-
.fx
ISO limits to the European part of
France, excluding French Guiana,
French Polynesia, French Southern
and Antarctic Lands, Guadeloupe,
Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon,
48 30 N
7 20 E
Pacific Ocean
28 40 N
129 30 E
44 50 N
0 34 W
Brunei, Indonesia, Malaysia
0 30 N
114 00 E
820
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Bornholm (island)
Bosna i Hercegovina (local name for Bosnia and
Herzegovina)
Bosnia (political region)
Bosporus (strait)
Bothnia, Gulf of
Bougainville (island)
Bougainville Strait
Bounty Islands
Bourbon Island (former name of Reunion)
Brasilia (capital)
Bratislava (capital)
Brazzaviile (capital)
Bridgetown (capital)
Brisbane (city)
Bristol Bay
Bristol Channel
Britain (see Great Britain)
British Bechuanaland (region; former name for northwest
South Africa)
British Central African Protectorate (former name of
Nyasaland)
British East Africa (former name for British possessions in
eastern Africa)
British Guiana (former name for Guyana)
British Honduras (former name for Belize)
British Solomon Islands (former name for Solomon Islands)
British Somaliland (former name for northern Somalia)
Brussels (capital)
Bubiyan (island)
Bucharest (capital)
Budapest (capital)
Buenos Aires (capital)
Bujumbura (capital)
Bukovina (region)
Byelarus (local name for Belarus)
Byelorussia (former name fcr Belarus)
Cabinda (province)
Cabo Verde (local name for Cape Verde)
Cabot Strait
Caicos Islands
Cairo (capital)
Calcutta (city)
Calgary (city)
California, Gulf of
Cameroun (local name for Cameroon)
Campbell Island
Campeche, Bay of
Canal Zone (former name for US possessions in Panama)
Canarias Sea
Canary Islands
Canberra (capital)
Cancun (city)
Canton (city; now Guangzhou)
Canton Island (Kanton Island)
Cape Juby (region; former name for Southern Morocco)
Cape Province (region; former name for Northern, Western,
and Eastern Cape Provinces of South Africa)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
42 00 N
9 00 E
48 42 N
6 11 E
43 18 N
5 23 E
48 52 N
2 20 E
46 00 N
2 00 E
48 35 N
7 44 E','57509411384f7decdbc4ce151f459eed48f7beaad046cfad78dcbffc128fa479','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('901834711d9ed5b0b39beee5b3fa083f056e8f7e6a89882bd766002b3a1c69b4',2010,'WF','Wallis and Futuna','environment',1655,'810
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
WF
WF
WLF
876
WLF
.wf
Oudying Islands
West Bank
WE
PS
PSE
275
PSE
.ps
ISO identifies as Occupied Palestinian
14 19 S
178 05 W
14 19 S
178 05 W
Hrvatska (local name for Croatia)
13 57 S
171 56 W
Taiwan
26 13 N
119 56 E
New Caledonia, Vanuatu
22 20 S
171 20 E
13 17 S
176 10W','d1e7959fffa0d1e84476baaf7b7e563c7ebe05d6bfef6e273a053c0fe45afc10','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5136e35382e61a6b234e85962df6864b98c46857912f11fbdccb01d043af5d0e',2010,'GF','French Guiana','environment',1656,'FG
GF
GUF
254
GUF
•gf
4 56 N
52 20 W
5 17 N
52 35 W
4 00 N
53 00 W
Ha''apai Group (island group)
4 00 N
53 00 W
5 20 N
52 37 W','54c26f13654b2745baaa54221ff6cf0c0e05082de2cfd3af95e95d2d9a6df6e5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20d10240790c27c346ae39eaa4bf054010a0fda599cb1321f186cc5d29eb6c07',2010,'PF','French Polynesia','environment',1657,'FP
PF
PYF
258
PYF
.Pf
ISO includes Clipperton Island
French Southern and Antarctic
Lands
FS
TF
ATF
260
ATF
.tf
FIPS 1 0-4 does not include the
French-claimed portion of Antarctica
(Terre Adelie)
23 20 S
151 00 W
16 30 S
151 45 W
23 09 S
134 58 W
Pacific Ocean v v
3 00 S
107 00 E
9 00 S
139 30 W
17 32 S
149 34 W
15 00 S
140 00 W
Germany, Poland
53 40 N
15 35 E
Federated States of Micronesia
6 55 N
158 15 E
17 00 S
17 37 S
149 27 W
Taiwan
25 03 N
121 30 E
Pacific Ocean
24 00 N
119 00 E
19 00 S
142 00 W
23 00 S
150 00 W
Iran
26 14 N
55 19 E
Iran
26 14 N
55 09 E','4e8105c4d43729b6c8fff97be2e995e3c8bc0d515fa37b01af93e8c0b439bea4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1699bd4be02e6806fcaeddfe3eb244fee6dee952b10e07ae7cbf52c56bdc8ae4',2010,'GA','Gabon','environment',1658,'GB
GA
GAB
266
GAB
•ga
Gambia, The
GA
GM
GMB
270
GMB
.gm
Gaza Strip
GZ
PS
PSE
275
PSE
.ps
ISO identifies as Occupied Palestinian
Territory
0 23 N
9 27 E
1 00 S
11 45 E','d20b75231cf4cc2e8d3864bca0a3dd628900c47d26a577fc773dd0dd18299940','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a2c93433d06c365ea4e47a8e3f1a5ade0863685f0e987b3173f1818886fcd43',2010,'GE','Georgia','environment',1659,'GG
GE
GEO
268
GEO
•ge
43 00 N
41 00 E
Abu Dhabi (capital)
41 45 N
42 10 E
Akmola (city; former name for Astana)
42 30 N
41 52 E
42 20 N
44 00 E
Pacific Ocean''
30 00 S
130 00 W
South Georgia and the South
57 45 S
26 30 W
Sandwich Islands
41 43 N
44 49 E
41 43 N
44 49 E
China, Kyrgyzstan
42 00 N
80 00 E
Argentina, Chile
54 00 S
69 00 W
Timor-Leste, Indonesia
9 00 S
125 00 E','1b3453524ddeead235f7f42beda80ee045df6cdc6a2b6b25f6574108feefee9b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7034d18a6400486c1d4833c4fa43d2ef7ebcbc067f16a277e07696ee54a1f120',2010,'DE','Germany','environment',1660,'GM
DE
DEU
276
DEU
.de
48 30 N
11 30 E
Beagle Channel
Atlantic Ocean
54 53 S
68 10W
Bear Island (see Bjornoya)
Svalbard
74 26 N
19 05 E
Beaufort Sea
Arctic Ocean
73 00 N
140 00 W
Bechuanaland (former name for Botswana)
52 31 N
13 24 E
52 30 N
13 33 E
52 30 N
13 20 E
48 00 N
8 15 E
South Georgia and the South
53 39 S
41 48 W
Sandwich Islands
Adantic Ocean
43 00 N
35 00 E
50 44 N
7 05 E
51 00 N
9 00 E
823
Name
THE CIA WORLD FACTBOOK
Devils Island (lie du Diable)
Devon Island
Dhaka (capital)
Dhivehi Raajje (local name for Maldives)
Dhofar (region)
Diego Garcia (island)
Diego Ramirez (islands)
Dili (capital)
Dilmun (former name for Bahrain)
Diomede Islands
Diu (region)
Djibouti (capital)
Dnieper (river)
Dniester (river)
Dobruja (region)
Dodecanese (island group)
Dodoma (city)
Doha (capital)
Donets Basin
Douala (city)
Douglas (capital)
Dover, Strait of
Drake Passage
Druk Yul (local name for Bhutan)
Dubai, Dubayy (city)
Dublin (capital)
Duesseldorf (city)
Durban (city)
Dushanbe (capital)
Dutch Antilles (former name for the Netherlands Antilles)
Dutch East Indies (former name for Indonesia)
Dutch Guiana (former name for Suriname)
Dutch West Indies (former name for the Netherlands
Antilles)
Dzungarian Gate (valley)
East China Sea
East Frisian Islands
East Germany (German Democratic Republic; former name
for eastern portion of Germany)
East Korea Strait (Eastern Channel or Tsushima Strait)
East Pakistan (former name for Bangladesh)
East Siberian Sea
Easter Island (Isla de Pascua)
Eastern Channel (East Korea Strait or Tsushima Strait)
Eastern Samoa (former name for American Samoa)
Edinburgh (city)
Eesti (local name for Estonia)
Eire (local name for Ireland)
Elba (island)
Elemi Triangle (region)
Ellada, Ellas (local name for Greece)
Ellef Ringnes Island
Ellesmere Island
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
51 13 N
6 47 E
53 44 N
7 25 E
52 00 N
13 00 E
Pacific Ocean
34 00 N
129 00 E
50 07 N
8 41 E
Russia
81 00 N
55 00 E
52 00 N
13 00 E
51 00 N
9 00 E
53 34 N
9 59 E
Hamilton (capital)
51 21 N
12 23 E
48 08 N
11 35 E
49 25 N
7 00 E
51 00 N
13 00 E
54 31 N
9 33 E
48 46 N
9 11 E
Bolivia
19 02 S
65 17 W
51 00 N
11 00 E
53 22 N
5 20 E','7e8fdd19f6175c38dc40e2d39ff098466f5ee1a32c45eb19ddd1c079e64a7dce','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308d06b80841682989e564097a6a5a5b09b5fc3c4c0b913010bde69f9b475f95',2010,'GH','Ghana','environment',1661,'GH
GH
GHA
288
GHA
•gh
5 33 N
0 13 W
Adamstown (capital)
Pitcairn Islands
25 04 S
130 05 W
Addis Ababa (capital)
8 00 N
2 00 W
Adantic Ocean
46 00 S
66 00 W
Adantic Ocean
41 30 S
64 00 W ,','cd02e486ada55383e90c2a60a821bac37d3de701dc9777b8771104cc61e65078','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee6eab5bd14659573cf46e8922ea5be057df6d797d25ff460b444d3a940eb2b1',2010,'GI','Gibraltar','environment',1662,'GI
GI
GIB
292
GIB
•gi
Glorioso islands
GO
administered as part of French
Southern and Antarctic Lands; no ISO
codes assigned
36 11 N
5 22 W
Adantic Ocean
35 57 N
5 36 W','e74cc66c72836761add64d934c505eefd5e5760f75ec903ce7416cc90f424ce8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9a6d9fe275120dc46ce02c17e756ca509981b93aedf12fcdbb3dcd652fa10cf',2010,'GR','Greece','environment',1663,'GR
GR
GRC
300
GRC
•gr
38 00 N
25 00 E
Aegean Sea
Adantic Ocean
38 30 N
25 00 E
Afars and issas, French Territory of the (or FTAI; former
37 45 N
24 42 E
The Bahamas
24 26 N
77 57 W
Adantic Ocean
18 30 N
63 40 W
37 59 N
23 44 E
39 40 N
19 45 E
37 56 N
22 56 E
35 15 N
24 45 E
37 00 N
25 10 E
36 00 N
27 05 E
Tanzania
6 11 S
35 45 E
39 00 N
22 00 E
38 30 N
20 30 E
Atlantic Ocean
38 30 N
18 00 E
38 22 N
26 04 E
Khmer Republic (former name for Cambodia)
39 54 N
25 21 E
Russia
59 55 N
30 15 E
39 15 N
26 15 E
37 05 N
25 30 E
37 30 N
22 25 E
Tanzania
5 20 S
39 45 E
36 10N
28 00 E
37 48 N
26 44 E
40 38 N
22 57 E','79068f6869183ff11cd7c15046ce550b23938e7a4008054edd68363ebd92a3a5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('084f0a8b2a03250677a5054c7080fdd19a86683b40d7952098366824f49c1337',2010,'GL','Greenland','environment',1664,'GL
GL
GRL
304
GRL
•gl
64 11 N
51 44 W
Syria
33 00 N
35 45 E
72 00 N
40 00 W
Kalahari (desert)
Botswana, Namibia
24 30 S
21 00 E
Kalimantan (region)
64 11 N
51 44 W
(DENMARK)
Ba.renU 5&r
Hjorneva
iSORWAYi
ijn''eniand
Paamiut
(Freder.ikshdb;
Perm
.Ian Mayer
V (NORWAY*.
Arkhangelsk;
Norvvegi''m
Kazan
Of.nuM.fk Str.
Samara
1 Nizhniy
Novgorod
Reykjavik
- \\ Saint
Petersburg
Moscow
Faroe
Torshavu . Islands
(DEfiMARK)
Saratov
SHETLAND g
ISLANDS’^''
(DENMARK)
y ,/W
Reykjavik
, UNITED STATES /% .
•"Bethel Ml. McKinley // '' AVi ''
i Kgiissi pant m Fairbanks » ''
mth ♦wriM.SlM «9» ? Iiutvik
+ -9 '' ,
»• Anchorage^ V4 Dawson • \\ ■■
Hwtks
IstuM
Resolute*
Kangerlu:ssl#q
/.Mr, (Sondre Strormiordl
,/ 4
<4lf,.,z Nuuk
* Kodiak
%
* Valdez
/ / Victoria '' | "yi "
\\/ •" . Island V (if- ''
T Cambridge Bay , - : 4
4 Repulse Bay^
'' '' Fcho Bay '' . * . . : ^ , 4) 4 ''
A''A Unfit* ''
4; /r .island
msA
*
PaamiuP''W /
Uav» Paanmtr''w
O-rederlkshab)
Whitehorse
luneati*
G V
Watson
.^i.afce
MM
Yeiiqyvknife
Rartkrn Inlet^
Iqafuit • :
.Mr/ ‘ ''''''My'' ?///,£%%
''''M
* Ivujivik
L avraaor
Hay Riwr*
C A n A D
Goose ftayT
ScheffervHle# : 4
<1
.
; Prince Rupert q
Prince o
Churchill
A, Islam! 0/
jf/% ■Nt''titfcumiiftind
< ''■ y, > ZZ^ |
< >/
. St. JohifhsA
A 4 ifw
Chisasibi
I o r
fig lie |::fs
V,ctona''*Van“H,ver
1#
*Jf*>;dmontort.% . ''0
j, . Saskatoon
-^Calgary
Regina^
Charlottetown Sydney
zzp a z y
,, / Fredericton
Quebec- *, ♦''Halifax
“ Salta John
Mooscmetg,
Winnipeg*
,P a C I f i C
''* 4 :
- ■ 4*''
Portland I
rT
z Q
05 r ■/ .. ...
V
o .
. m
Thunder
Bay
i c,.- '' Ottawa^ . '' ''
'' Si. P1>.;rre
vj/jtJ MiqueUMi
■rKAnce
!A .Boston
-.44 -A. >0 *■•
4,:.. jo
• ? -z k York
tmomaf:
O c e a n.
■33
aA ::
San Francisco#
^ ; ^v-z . . X_
o
Cl .Minneapolis* n . i it 4" #|#w,Yoffe
. . . 1|< *_ ‘M,,Sfukee* WVhtdsor ^ .Philadelphia
•Z UNITED . Cleveland . * ^If.more
Chicago
***** : 1 - ■ /'' CO > tl I Hl''tl ’ ^ — .
* ~ J *z |n| i> r t It
■■pi. ■ a*s%MSSP*.l ox:
- I PL# ‘ MUM touts A/ J Norfolk^,
■Z.
1.
Denver
las
Destfi Va(/ey + V
) Kansas City''
m-4$mcd 8Qm) M
I.OS Angeles* ^ "
San Diego* j. 4 ,
Tijuana*! . ‘
Mexicali ..
UT
c X A HP 17 C
^ ^ ^ ^ ^ ^ f Memphis','8d1d71967d55ba2b114a6720b122fe1d7a11c7e010b8bdc64e9ced86409fa90a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cecdcd1fd4c0f2ddcf22f5d6bdd4a4a35dbe958e4a9cf319589b2134b22098e3',2010,'GD','Grenada','environment',1665,'GJ
GD
GRD
308
GRD
•gd
12 07 N
61 40 W
826
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Grytviken (town; on South Georgia)
South Georgia and the South
Sandwich Islands
54 15 S
36 45 W
Guadalahara (city)
12 03 N
61 45 W
Adantic Ocean
52 00 N
6 00 W
Saint Helena
15 57 S
5 42 W
12 20 N
61 30 W','41b47d5d68be2e9b042540a7fed27f336b62e7ea56f13f907a4014bb988c3206','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c31e08da8f33d6c6ed03fe41673817c0c6bccde8595ca7b525f6a3e487973c8e',2010,'GU','Guam','environment',1666,'GQ
GU
GUM
316
GUM
•gu
13 28 N
144 45 E
Ajaccio (city)
France (Corsica)
41 55 N
8 44 E
Ajaria (region)
13 28 N
144 45 E
Hague, The (seat of government)','25ceda54df72279a076334700a39e6544c6e0c23dbbaf73c40213bd4a3e8e9dd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e732be2a0d617d22716aff7d5cdbec0014ef1ab8fb1020e4a92e3b38dcbde89e',2010,'GT','Guatemala','environment',1667,'GT
GT
GTM
320
GTM
•gt
14 38 N
90 31 W
Guine-Bissau (local name for Guinea-Bissau)','9d927c98df06d9962b39bac2b8a12535d89b5767758e487e509ef3573f251bf1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d69008307c94e7b98bd83473019444a15d87e3f62cd099efb5365a7a436f4d3',2010,'GG','Guernsey','environment',1668,'GK
GG
GGY
831
UK
•gg
49 43 N
2 12 W
Aleutian Islands
United States (Alaska)
52 00 N
176 00 W
Alexander Archipelago (island group)
United States (Alaska)
57 00 N
134 00 W
Alexander Island
49 27 N
2 32 W
49 26 N
2 21 W','b70bdc98b313cd38527cbe2dd6355eebf6f22c6a68d3a53b8403e44a06f32832','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eff8c114b94e99d6652b0195e311947e743bf223f52380b02d0ac81f10c199ae',2010,'GN','Guinea','environment',1669,'GV
GN
GIN
324
GIN
•gn
9 31 N
13 43 W
11 00 N
10 00 W
Cambodia, Laos, Vietnam
15 00 N
107 00 E
11 00 N
10 00 W
Gustavia (capital)
Saint Barthelemy
17 53 N
62 51 W
Guyane Francaise (local name for French Guiana)','5234f84291c99e729262665fea8309cc363e95f1de7467fa1002ed359bb1113b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee530079c72bd91b703f4be9cebcb65c7f3838507d9db5e9108bd85c4a76fc2',2010,'GW','Guinea-Bissau','environment',1670,'PU
GW
GNB
624
GNB
•gw
11 25 N
16 20 W
11 51 N
15 35 W
Svalbard
74 26 N
19 05 E
12 00 N
15 00 W
Guinea Ecuatorial (local name for Equatorial Guinea)
12 00 N
15 00 W','fc1d505e7e366a26e00d98244281b4c41a554a1bd9bddb731b2a78422954a548','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6e6707886b15ea20886d8fe7efb6590e6f881039e47e0432f64d0da9f5dd5c1',2010,'GY','Guyana','environment',1671,'GY
GY
GUY
328
GUY
•gy
5 00 N
59 00 W
6 59 N
58 23 W
Russia (de facto)
44 55 N
147 40 E
6 48 N
58 10W
The Gambia
13 30 N
14 47 W','f37d73c7e1a39e4159035285e0b3f14e688ac3e7a9b6b075390d8e6da056c11d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55927e7157b045535b143228103bf7f584fba25ca99c9a9128e0f61c9e9dd8cd',2010,'HT','Haiti','environment',1672,'HA
HT
HTI
332
HTI
.ht
Heard Island and McDonald
Islands
HM
HM
HMD
334
HMD
.hm
Holy See (Vatican City)
VT
VA
VAT
336
VAT
.va
Port-au^
Prince','0515b846f21d2a3aeb82b696a78729296f5d5f4fb83f7f08e9cbd8a286da2515','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85de30161311668fc9dff4a54f0bef56aab81f16dedc45ab925221fd213dc9f8',2010,'HK','Hong Kong','environment',1673,'HK
HK
HKG
344
HKG
.hk
Howland Island
HQ
-
"
UMI
ISO includes with the US Minor
Outlying Islands
22 15 N
114 10 E
Honiara (capital)
22 18 N
114 10E
Burma, Thailand
10 20 N
99 00 E
Indonesia 4
6 07 S
105 24 E
22 15 N
113 55 E
Laos
18 00 N
105 00 E
Arctic Ocean
76 00 N
126 00 E
Spain (Canary Islands)
28 06 N
15 24 W
Syria
36 00 N
35 50 E
22 24 N
114 10 E
833
Name
THE CIA WORLD FACTBOOK
Newfoundland (island, with mainland area, and a province)
Niamey (capital)
Nicobar Islands
Nicosia (capital; also Lefkosla)
Nightingale Island
Nihon, Nippon (local name for Japan)
Nomoi Islands (Mortlock Islands)
Norge (local name for Norway)
Norman Isles (Channel Islands)
North Atlantic Ocean
North Channel
North Frisian Islands
North Greenland Sea
North Island
North Ossetia (region)
North Pacific Ocean
North Sea
North Vietnam (former name for northern portion of
Vietnam)
North Yemen (Yemen Arab Republic; now part of Yemen)
Northeast Providence Channel
Northern Areas
Northern Cyprus (region)
Northern Epirus (region)
Northern Grenadines (political region)
Northern Ireland
Northern Rhodesia (former name for Zambia)
Northwest Passages
Norwegian Sea
Nouakchott (capital)
Noumea (capital)
Nouvelle-Caledonie (local name for New Caledonia)
Nouvelles Hebrides (former name for Vanuatu)
Novaya Zemlya (islands)
Nubia (region)
Nukualofa (capital)
Nunavut (region)
Nuuk (capital; also Godthab)
Nyasaland (former name for Malawi)
Nyassa (region)
Oahu (island)
Ocean Island (Banaba)
Ocean island (Kure Island)
Oesterreich (local name for Austria)
Ogaden (region)
Oil Islands (Chagos Archipelago)
Okhotsk, Sea of
Okinawa (island group)
Oland (island)
Oman, Gulf of
Ombai Strait
Oran (city)
Orange River Colony (region; former name of Free State
Province of South Africa)
Oranjestad (capital)
Oresund (The Sound) (strait)
Orkney Islands
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
22 15 N
114 10E','3aad3f9ca54737684d5bc844d741957ea0171369cce3c05f79942e03c4132113','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c7b79507fafd725a32262e7725be49a7571ab113f9b82e2834a39a086c9a862',2010,'IS','Iceland','environment',1674,'IC
IS
ISL
352
ISL
.is
65 00 N
18 00 W
Falkland Islands
51 45 S
59 00 W
(Islas Malvinas)
Turkey
41 01 N
28 58 E
Croatia, Slovenia
45 00 N
14 00 E
64 09 N
21 57 W
63 17 N
20 40 W','dd63fc0d06b85cb0290e691edf79de6d55135e1a8a6b7857b85441061731dcef','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55a83da50bbd4b94909557473ae75c9af15c8f6c6d704e443d5a3eaa4b0faded',2010,'IN','India','environment',1675,'IN
IN
IND
356
IND
.in
11 30 N
72 30 E
12 00 N
92 45 E
Indian Ocean
10 00 N
95 00 E
20 00 N
77 00 E
23 16 N
77 24 E
18 58 N
72 50 E
Netherlands Antilles
12 10N
68 15 W
Adantic Ocean
41 01 N
14 00 E
22 32 N
88 21 E
13 04 N
80 16 E
20 10 N
73 00 E
Syria
33 30 N
36 18 E
20 42 N
70 59 E
15 20 N
74 00 E
China, Mongolia
42 30 N
107 00 E
32 42 N
74 52 E
India, Pakistan
34 00 N
76 00 E
Pacific Ocean
40 00 N
135 00 E
Laos
19 27 N
103 10 E
10 00 N
73 00 E
Indian Ocean
7 00 N
76 00 E
10 00 N
73 00 E
13 04 N
80 16 E
8 17 N
73 02 E
18 58 N
72 50 E
28 36 N
77 12 E
Indonesia, Papua New Guinea
5 00 S
140 00 E
8 00 N
93 30 E
27 50 N
Czech Republic, Germany,
51 00 N','969365801d55651d83d8f33614207fd7beffaedb54ee50688320dcc19dda56fb','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40761058e34e92c87854b0e161b8b09ed17b4237d3897c42bb27e0f4ae305cb2',2010,'ID','Indonesia','environment',1676,'ID
ID
IDN
360
IDN
.id
Iran
IR
IR
IRN
364
IRN
.ir
8 20 S
115 00 E
Bali Sea
Indian Ocean
7 45 S
115 30 E
Balintang Channel
Pacific Ocean
19 49 N
121 40 E
Balintang Islands
2 30 S
106 00 E
Bangkok (capital)
2 00 S
121 00 E
Pacific Ocean
3 00 N
122 00 E
Adantic Ocean
51 00 N
6 30 W
5 00 S
120 00 E
8 45 S
121 00 E
Pacific Ocean
7 40 S
119 45 E
Adantic Ocean
25 00 N
79 45 W
1 00 N
128 00 E
Halmahera Sea
Pacific Ocean
0 30 S
129 00 E
Hamburg (city)
5 00 S
138 00 E
Atlantic Ocean
53 30 N
5 20 W
Romania, Serbia
44 41 N
22 31 E
Turkey
36 34 N
36 08 E
6 10 S
106 48 E
Arctic Ocean
54 00 N
80 00 W
Saint Helena
15 56 S
5 44 W
7 30 S
110 00 E
Pacific Ocean
5 00 S
1 10 00 E
Israel, West Bank
31 47 N
35 14 E
0 00 N
115 00 E
Kaliningrad (region; formerly part of East Prussia)
Russia
54 30 N
21 00 E
Kamaran (island)
9 00 S
120 00 E
* *
8 28 S
116 40 E
Indian Ocean
8 30 S
115 50 E
2 00 S
128 00 E
3 30 N
102 30 E
Pacific Ocean
3 30 N
108 00 E
5 00 S
120 00 E
2 00 S
28 00 E
Svalbard
78 00 N
20 00 E
2 00 S
121 00 E
Pacific Ocean
3 00 N
122 00 E
0 00 N
102 00 E
10 00S
120 00 E
Pacific Ocean
9 10 S
120 00 E
8 30 S
118 00 E
Indonesia, Malaysia
2 00 S
110 00 E
Indian Ocean
6 00 S
105 45 E
7 13 S
112 45 E
Pacific Ocean
10 15 N
125 23 E','d983a578ddbc516d3f6858c497997db49eb66e50a613125a3cceed4a315b2431','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a86a9888154a90dcd315a34bf7b05dec9212a68c08da7442877c12ee3d35139',2010,'IQ','Iraq','environment',1677,'IZ
IQ
IRQ
368
IRQ
.iq
33 00 N
44 00 E
Al Jaza''ir (local name for Algeria)
33 21 N
44 25 E
Baku (capital; also Baki, Baky)
33 00 N
44 00 E
Adantic Ocean
38 15 N
15 35 E','95477a7364090391f85b503ab829bfa0bd65d5cc6ac98e77ef361cc2dbadad58','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('461165488d90192032d6cc62668392d329d4253638e79aa0702cf8661f15df22',2010,'IL','Israel','environment',1678,'IS
IL
ISR
376
ISR
.il
32 54 N
35 20 E
Atlantic Ocean
11 00 N
60 55 W
32 50 N
35 00 E
Hainan Dao (island)
30 30 N
34 55 E
32 05 N
34 48 E
Pacific Ocean
4 00 S
120 45 E
Pacific Ocean
0 30 S
121 00 E
32 48 N
35 35 E
31 30 N
34 45 E','5aaa33b579b353a6045658fd729fb9171dc848a0ff76a5ec34c38ceb03b02748','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eda4f6056973410da53b1fcb02d39fb8c6b48f9257eeb1b464f564363dfad9f9',2010,'IT','Italy','environment',1679,'IT
IT
ITA
380
ITA
.it
42 46 N
10 17 E
Ethiopia (claimed), Kenya
5 00 N
35 30 E
(de facto), Sudan (claimed)
38 30 N
15 00 E
Albania, Greece
40 00 N
20 30 E
Akroti ri, Dhekelia
34 40 N
32 51 E
43 46 N
11 16 E
42 50 N
12 50 E
Eritrea, Ethiopia, Somalia
8 00 N
38 00 E
41 13 N
09 24 E
45 28 N
9 11 E
Adantic Ocean
19 55 N
65 27 W
40 51 N
14 15 E
The Bahamas
25 05 N
77 21 W
38 07 N
13 21 E
Israel, West Bank
32 00 N
35 15 E
Federated States of Micronesia
6 55 N
158 08 E
Indian Ocean
10 00 N
79 45 E
China, Tajikistan
38 00 N
73 00 E
36 47 N
12 00 E
35 40 N
12 40 E
41 54 N
12 29 E
40 00 N
9 00 E
Adantic Ocean
30 00 N
55 00 W
37 30 N
Adantic Ocean
37 20 N
Adantic Ocean
31 30 N
46 30 N
10 30 E
Vietnam
12 00 N
108 00 E
45 04 N
7 40 E
Atlantic Ocean
40 40 N
28 00 E
Turkey
39 00 N
35 00 E
43 25 N
11 00 E
CENTRAL BALKAN REGION
. -A,. .Nagvkanr/sa V fA\\
f 1 ’ \\ ) HddmeztXvasarheiv
V . Kaposv*,* i .*«**<% \\ ’ f
\\ HUNGARY s"s“ f
#4rf ''''
■■■■■ %a. ■ ''/ Subotica )
T/k
Bjclovar <S^ C.X
„ *»•“ f “ .w.','786daa4bc12815d1e30fb3e6d11e2e4665ac16d69928c1d46307c93a3c192aac','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5b71ff8426425995fba23c10486e493fbd8bbfc1a7bc122279f0a0758dc424a',2010,'JM','Jamaica','environment',1680,'JM
JM
JAM
388
JAM
.jm
Jan Mayen
JN
-
-
-
SJM
-
ISO includes with Svalbard
18 00 N
76 48 W
Kingston (capital)
f BELIZE
ikr Belmopan
HOMDURAS''
LAninyem.
'' Sea
Beuntlary representation is
not necessarily authoritative.
Guatemala te&ucigalpa
QUATEmXla'' t ''"T / t H1C|RAQUA
San Salvador Managua
EL SALVADOR *
860
REFERENCE MAPS
wmam
mmm.
^nae
ijjuikm
OCEANIA
861
Physical Map of the World, April 2008
THE CIA WORLD FACTBOOK
PHYSICAL MAP OF THE WORLD
3
I
I
862','ea01726cb646fb41da86a0dbc5858e43ad15e5531eb4f05697c787d71222952a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5311268240e1e88e3fdbce31ce1bb0811fa5b49bf66bea44226bdcdb89c8815',2010,'JP','Japan','environment',1681,'JA
JP
JPN
392
JPN
•JP
Jarvis Island
DQ
*
UMI
**
ISO includes with the US Minor
Outlying Islands
27 00 N''
142 10 E
43 00 N
17 00 E
44 00 N
143 00 E
Holland (region)
36 00 N
138 00 E
Hormuz, Strait of
Indian Ocean
26 34 N
56 15 E
Horn of Africa (region)
Djibouti, Eritrea, Ethiopia,
34 20 N
133 30 E
24 47 N
141 20 E
Turkey
38 25 N
27 10 E
34 41 N
135 10 E
33 00 N
131 00 E
Bolivia
16 30 S
68 09 W
Pacific Ocean
45 45 N
142 00 E
24 16 N
154 00 E
Venezuela
10 00 N
64 00 W
Guam, Northern Mariana
16 00 N
145 30 E
Islands
24 16 N
154 00 E
30 00 N
140 00 E
Federated States of Micronesia
6 85 N
158 35 E
36 00 N
138 00 E
Federated States of Micronesia
5 30 N
153 40 E
26 30 N
128 00 E
34 42 N
135 30 E
20 20 N
136 00 E
26 30 N
128 00 E
24 30 N
124 00 E
43 04 N
141 20 E
Pacific Ocean
7 05 S
114 10 E
33 45 N
Russia (de facto)
43 47 N
35 42 N
139 46 E
Pacific Ocean
20 00 N
108 00 E
25 00 N
141 00 E','2b7a68304400cf0373c3f67a73ca49bf49891cafd8d981b0e9ee26a2538341f5','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ca919b9574ed65c92a7b3b03eae05fa3cd9d885740d9c97912fbc19ecce4065',2010,'JE','Jersey','environment',1682,'JE
JE
JEY
832
UK
•je
Johnston Atoll
JQ
"
UMI
ISO includes with the US Minor
Oudying Islands
49 12 N
2 07 W
Canada (New Brunswick)
45 16 N
66 04 W','cbf2f13db578424ee934a3e8d1216efa3c84874e18f3b2542eb9004aaadd1b05','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c541ec8c92ff92c10a9a6e0318d3988063f47c280bcf00c9b62cf1d65b4e2866',2010,'JO','Jordan','environment',1683,'JO
JO
JOR
400
JOR
.jo
Juan de Nova Island
JU
administered as part of French
Southern and Antarctic Lands; no ISO
codes assigned
31 00 N
36 00 E
Al Yaman (local name for Yemen)
31 57 N
35 56 E
31 00 N
36 00 E
31 00 N
36 00 E
^Kuwait','c814abb746b10fe358c91c44615dc77bcd88384d886321db3e4a0cd4ed4382ed','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98fce0a51008a0531e930e8cbadd80094a536e60dfc94a5bdd14d17886795b03',2010,'KZ','Kazakhstan','environment',1684,'KZ
KZ
KAZ
398
KAZ
.kz
51 10N
71 30 E
Aksai Chin (region)
China (de facto), India
(claimed)
35 00 N
79 00 E
Al Arabiyah as Suudiyah (local name for Saudi Arabia)
43 15 N
76 57 E
Almaty (former capital)
43 15 N
76 57 E
817
Name
THE CIA WORLD FACTBOOK
Alofi (capital)
Alphonse Island
Alsace (region)
Amami Strait
Amindivi Islands (former name for Laccadive Islands)
Amirante Isles (island group; also Les Amirantes)
Amman (capital)
Amsterdam (capital)
Amsterdam Island (lie Amsterdam)
Amundsen Sea
Amur River
Amurskiy Liman (strait)
Anadyrskiy Zaliv (gulf)
Anatolia (region)
Andaman Islands
Andaman Sea
Andorra la Vella (capital)
Andros (island)
Andros Island
Anegada Passage
Angkor Wat (ruins)
Anglo-Egyptian Sudan (former name for Sudan)
Anjouan (island)
Ankara (capital)
Annobon (island)
Antananarivo (capital)
Antigua (island)
Antipodes Islands
Antwerp (city)
Aomen (local Chinese short-form name for Macau)
Aozou Strip (region)
Apia (capital)
Aqaba, Gulf of
Arab, Shatt al (river)
Arabian Sea
Arafura Sea
Aral Sea
Argun River
Aru Sea
As-Sudan (local name for Sudan)
Ascension Island
Ashgabat, Ashkhabad (capital)
Asmara, Asmera (capital)
Assumption Island
Astana (capital; formerly Akmola)
Asuncion (capital)
Asuncion Island
Atacama (desert)
Atacama (region)
Athens (capital)
Attu Island
Auckland (city)
Auckland Islands
Australes, lies (island group; also lies Tubuai)
Avarua (capital)
Axel Heiberg Island
Azad Kashmir (region)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
51 10N
71 30 E
48 00 N
68 00 E
Keeling Islands
48 00 N
68 00 E
Gaza Strip
31 25 N
34 20 E
*Kyiv
Crete
M-edtlerranem iSe<i
* Teh ran j .He*
i ftS *
Qpm
•Sir*
•ak
o
^Effahdn |-"|^ ^JSj
r
Ci : /
\\ PAR.
Scale 1:21,000,000 ft
Lambert Conformal Conic Projection,
standard parallels il''NandSS''N^ Ababa
? , X— ‘ ”
m 3ea
Socotra
(YEMEN)
0 500 Mites A* i
E , \\ /ETHIOPIA
Boundary representation is * ad,
not necessarily authoritative. $
■ ■ h , j ■■ 1 .
ft Golan Heights is Israeli-occupied Syria.
0 West Bank and Gaza Strip are Israeli-occupied with current
M status subject to the Israeli- Pales’ dan Interim Agreement --
,,v , ''.ir ■, permanent status to be determlneu through further negotiation.
„ Israel proclaimed lerusalem as Us capital in IV50. but the US. like
nearly all other countries, maintains its Embassy in Tel Aviv.
859
THE CIA WORLD FACTBOOK
NORTH AMERICA
Anadyr''*
Provideniya
i fyx? ; • L.j.y-.
! '' , Cherskiy , ■ ■ „ -
RUSSIA Pevek
Jan Mayen /
'' (NORWAY) /
O c e a n
"ii\\gr§
■ A
/ '' . Q^anaatf
r ''Sy A Ty (Thule)
: / v'' My ■< ''••''■imwte Mm
( 1 1 oqqdt^Jorjpfrt^
(Scoreste^fiiJ# )
y|;''tarJ#iD
ts< >
>5.^1
•.Nome''
Barrow
Prudhoe
« Bay
queen ETfiAfefj
fSLAN^S<xi^%
'' * ✓< -','b7b3db30a797e0f52cab2c5a0f60e460872aae4cb0aaf0cfa7ee16e8d8263271','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8243dae1e1a5864693075feaa05cca66cc3e50cc9e76cc8df2bd4195a83e9b9',2010,'KE','Kenya','environment',1685,'KE
KE
KEN
404
KEN
.ke
Kingman Reef
KQ
-
UMI
ISO includes with the US Minor
Outlying Islands
811
THE CIA WORLD FACTBOOK
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
4 03 S
39 40 E
Adantic Ocean
18 30 N
67 45 W
1 17 S
36 49 E','11f86dc2ca8c9d4e4dbc1b4dda1decb6c12fb546d2f0e58e67175773dffb251b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4989cf5632a29efd778e22614a2b109a5f973c7bab48db4cd164e7e2e89f162d',2010,'KI','Kiribati','environment',1686,'KR
KI
KIR
296
KIR
.ki
Korea, North
KN
KP
PRK
408
PRK
•kP
Korea, South
KS
KR
KOR
410
KOR
.kr
Kosovo
KV
-
-
-
-
-
ISO codes have not been designat
0 52 S
169 35 E
Banat (region)
Hungary, Romania, Serbia
45 30 N
21 00 E
Banda Sea
Pacific Ocean
5 00 S
128 00 E
Bandar Seri Begawan (capital)
Brunei
4 53 N
114 56 E
Bangka (island)
2 49 S
171 40 W
1 52 N
157 20 W
Arctic Ocean
69 00 N
171 00 W
Federated States of Micronesia
7 25 N
151 47 W
Turkey
36 50 N
34 30 E
3 08 S
171 05 W
1 25 N
173 00 E
2 49 S
171 40 W
Kara Sea
Arctic Ocean
76 00 N
80 00 E
Karachevo-Cherkessia (region)
Russia
43 40 N
41 50 E
Karachi (city)
1 52 N
157 20 W
Kishinev (see Chisinau)
Moldova
47 00 N
28 50 E
Kithira Strait
Adantic Ocean
36 00 N
23 00 E
829
Name
Entry in
The World Factbook
Latitude Longitude
(deg min) (deg min)
Kobe (city)
Kodiak island
Kola Peninsula (Kol''skiy Poluostrov)
Kolonia (town; former capital; changed to Palikir)
Korea Bay
Korea Strait
0 52 S
169 35 E
3 30 S
172 00 W
1 25 N
173 00 E
Pacific Ocean
50 00 N
141 00 E
10 06 S
152 23 W
Wake Island
19 17 N
166 39 E','1cfe8d346efad816678ce7a4b85f796af4a12eb92cbfa6e895880df2866bb242','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb5f5032b3255215ee9e69ad8fbd0b98a7125359a15862537098cef5b79408b1',2010,'KW','Kuwait','environment',1687,'KU
KW
KWT
414
KWT
.kw
29 30 N
45 45 E
Al Maghrib (local name for Morocco)
29 47 N
48 10 E
29 20 N
47 59 E
Russia
54 00 N
86 00 E
at B3tin','1151e9b3076447990d85b2e92077f083968db7d6254785634db4b4db6765be28','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5c19d5d6fe3fa14f7f9477fd6afe2ae8c3640fe4a583a613a37ff92616423db',2010,'KG','Kyrgyzstan','environment',1688,'KG
KG
KGZ
417
KGZ
•kg
Laos
LA
LA
LAO
418
LAO
.la
42 54 N
74 36 E
42 54 N
74 36 E
41 00 N
75 00 E
Klrguizstan (local name for Kyrgyzstan)
41 00 N
75 00 E
Kiritimati (Christmas Island)','8856c59a419d36488a89ba02596d165fc962d876fde6967aee852122cda42c73','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288d50cc44c5a2b768fe9141db17d53ff83369e20bfe2bc72adf8926e4e7e40e',2010,'LV','Latvia','environment',1689,'LG
LV
LVA
428
LVA
.lv
57 00 N
25 00 E
56 57 N
24 06 E
Atlantic Ocean
57 30 N
23 30 E','a6097e6d16fcbaab88cbd986707c18679ace8331eee47070712aae4c959c709c','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e92cc83653bd9c1a029d37ed3466d3acc765bbbdb5e725844ce97a2a55abcb8a',2010,'LB','Lebanon','environment',1690,'LE
LB
LBN
422
LBN
.lb
33 53 N
35 30 E
819
Name
THE CIA WORLD FACTBOOK
Bekaa Valley
Belau (Palau Islands)
Belep Islands (lies Belep)
Belfast (city)
Belgian Congo (former name for Democratic
Republic of the Congo)
Belgie, Belgique (local name for Belgium)
Belgrade (capital)
Belize City
Belle Isle, Strait of
Bellingshausen Sea
Belmopan (capital)
Belorussia (former name for Belarus)
Benadir (region; former name of Italian Somaliland)
Bengal, Bay of
Berau, Gulf of
Bering Island
Bering Sea
Bering Strait
Berkner Island
Berlin (capital)
Berlin, East (former name for eastern sector of Berlin)
Berlin, West (former name for western sector of Berlin)
Bern (capital)
Bessarabia (region)
Bharat (local name for India)
Bhopal (city)
Biafra (region)
Big Diomede Island
Bijagos, Arquipelago dos (island group)
Bikini Atoll
Bilbao (city)
Bioko (island)
Biscay, Bay of
Bishkek (capital)
Bishop Rock
Bismarck Archipelago (island group)
Bismarck Sea
Bissau (capital)
Bjornoya (Bear Island)
Black Forest (region)
Black Rock (island)
Black Sea
Bloemfontein (judicial capital)
Bo Hai (gulf)
Boa Vista (island)
Bogota (capital)
Bohemia (region)
Bombay (city; see Mumbai)
Bonaire (island)
Bonifacio, Strait of
Bonin Islands
Bonn (former capital)
Bophuthatswana (region; enclave)
Bora-Bora (island)
Bordeaux (city)
Borneo (island)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
34 00 N
36 05 E
Palau ''
7 30 N
134 30 E
33 50 N
36 50 E
33 50 N
36 50 E
Democratic Republic of the
11 40 S
27 28 E
34 26 N
35 51 E','60a5f69ce8a4251c97b180cd286fbcf3b065602c41e4f2170282fcfd461d60f0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('970a0d261c688dd8a309fc026ca284f8c42b870bf1f132acf61aa7e5273b3420',2010,'LY','Libya','environment',1691,'LY
LY
LBY
434
LBY
•ly
31 00 N
22 00 E
Czech Republic, Slovakia
49 00 N
18 00 E
32 54 N
13 11 E
31 00 N
14 00 E
Saint Helena
37 15 S
12 30 W','4c92615b1c497af1af9bca75898c7aca971a80ffb0236ce9c0606adcc25b7f81','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57c36a2d05de5152135f9d9ce21ad851d38b6839327fdfbcc62474e75ed3328e',2010,'LT','Lithuania','environment',1692,'LH
LT
LTU
440
LTU
.It
56 00 N
24 00 E
Adantic Ocean
43 30 N
9 00 E
830
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Lilongwe (capital)
Lima (capital)
Lincoln Sea
Line Islands
Lion, Gulf of
Lisbon (capital)
Little Belt (strait; also Lille Baelt)
Ljubljana (capital)
Llanos (region)
Lobamba (city)
Lombok (island)
Lombok Strait
Lome (capital)
London (capital)
Longyearbyen (capital)
Lord Howe Island
Lorraine (region)
Louisiade Archipelago
Lourenco Marques (city; former name for Maputo)
Loyalty Islands (lies Loyaute)
Luanda (capital)
Lubnan (local name for Lebanon)
Lubumbashi (city)
Lusaka (capital)
Luxembourg (capital)
Luzon (island)
Luzon Strait
Lyakhov Islands
55 43 N
21 30 E
54 41 N
25 19 E','cab640719ca2ad6112c1e0bbbb0304cb26e4bc9afbfd2f7cb9c9cd419b3c4285','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4abaecea513795eb499d01d76acbacf9f00bd124c4fe30960f2fd62c0850ced',2010,'LU','Luxembourg','environment',1693,'LU
LU
LUX
442
LUX
.lu
Macau
MC
MO
MAC
446
MAC
.mo
Macedonia
MK
MK
MKD
807
FYR
.mk
49 45 N
6 10 E','d4ebf92cf899a99fa1cbd35166cca417340e1328f17814376439f8f6d2d07a57','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e8decf7257cd99f71102ad44ad0f8ebd553065e8cda652bd79575d6214a67bb',2010,'MG','Madagascar','environment',1694,'MA
MG
MDG
450
MDG
.mg
18 52 S
47 30 E
20 00 S
47 00 E
20 00 S
47 00 E
Brunei, Indonesia, Malaysia,
2 30 N
120 00 E
Papua New Guinea,','481a8c3cc23dc8d560ebbe17f85110221c775a5cdc473eaf6dcf4b9258e53a8b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c1638a3c73efd786dec1f7433bf13728c6f7f41ef5fb7e0aa166a72ad4a3062',2010,'MW','Malawi','environment',1695,'MI
MW
MWI
454
MWI
.mw
13 30 S
34 00 E
Kenya, Tanzania, Uganda
1 00 N
38 00 E
13 59 S
33 44 E
13 30 S
34 00 E','4ee0d9eed223eff99480b50a100026a3b848cdb228a68f96dec20e692482097e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3535fd86572bd123fb9697b2489e8cf1e61963b1008ad37f30f5c1c4f7c950cb',2010,'MY','Malaysia','environment',1696,'MY
MY
MYS
458
MYS
.my
5 26 N
100 16 E
The Bahamas
23 30 N
75 46 W
3 10 N
101 42 E
Russia (de facto)
44 20 N
146 00 E
5 23 N
100 15 E
Atlantic Ocean
58 44 N
3 13 W
5 20 N
117 10 E
2 30 N
113 30 E','d1cf4c6f82bfc360ee1d776cac80faeb27cef537c38d114c4b2cbdc761fb3b3e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50ed0cf2668b1446902288d910aa87109e38d680307d041b3d00c9ad15818501',2010,'MT','Malta','environment',1697,'MT
MT
MLT
470
MLT
.mt
35 54 N
14 31 E
Rabat - ";;r; ■
Casablanca jk • 5
/ MOROCCO
Marrakech 1
Constantine
Esfahan
Funchal
X Tripoli
Vis,,.. ShTraz
X. / 4 Kuwait
KUWAIT""'' _ v,.„;
Mam««0W<-;'' ’ 7,
bahrIJa. Dh
Riyadh. DohX Uhj
★ QATAR VuJt*
CANARY ISLANDS
Abbas
Las Palmas
(ounc
UGYPT
Western
Muse.
Aswan]
OMAN;
Port |
Sudan:
Tombouetou i
MALI /
Ofndtanan ,
Khartoum dr,
Agadez','77e8b188c360321fc7a77596dbe6f2e6435f71a0639e1af1f4fd58de543594bc','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d1df74e1cdf24507f497e0b76c68bcc6e302bb0ee9f3d8ab4d29b6cb4ca727',2010,'MH','Marshall Islands','environment',1698,'RM
MH
MHL
584
MHL
.mh
11 35 N
165 23 E
11 30 N
162 15 E
11 30 N
162 15 E
9 05 N
167 20 E
7 05 N
171 08 E
Pacific Ocean
2 00 S
117 30 E
Macedonia
41 50 N
22 00 E
8 00 N
167 00 E
Burma
16 47 N
96 10 E
9 00 N
171 00 E
Indian Ocean
20 00 N
38 00 E','c9a01a9ae0bfc586a9c16ac6bd06d1f522364b5e3ec71b74ef84964e583a1936','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eee03dd57efb9100f467a01c339771f943e7841ed6fc6df01d1ff49220556079',2010,'MR','Mauritania','environment',1699,'MR
MR
MRT
478
MRT
,mr
20 00 N
12 00 W
20 00 N
12 00 W
Oman, United Arab Emirates
26 18 N
56 24 E
18 06 N
15 57 W','988d79e1fb972838dc37588ee0b2bb74472df3f04a78ddfd7041f301c5268cd0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72a8372ac564cd5326240193d8f9cf678379ec59ab467e8093cce2a924595685',2010,'MU','Mauritius','environment',1700,'MP
MU
MUS
480
MUS
.mu
10 25 S
56 40 E
Agana (city; former name for Hagatna)
16 25 S
59 38 E
Atlantic Ocean
15 00 N
73 00 W
Federated States of Micronesia,
7 30 N
148 00 E
20 10 S
57 30 E
19 42 S
63 25 E
16 25 S
59 38 E','6d877adec9a8de0c118a7e0ad31684a459358ee3513308482f1dde9c7d452d99','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0805e5a195ba6e82a15bb86aff58864bc3dff0cb6c20bae670b087d29149c007',2010,'MX','Mexico','environment',1701,'MX
MX
MEX
484
MEX
.mx
Micronesia, Federated
FM
FM
FSM
583
FSM
.fm
States of
Midway Islands
MQ
UMI
ISO includes with the US Minor
Moldova
MD
MD
MDA
498
MDA
.md
Outlying Islands
16 51 N
99 55 W
Accra (capital)
21 10 N
86 50 W
20 30 N
86 55 W
20 40 N
103 24 W
Guadalcanal (island)
29 11 N
118 17 W
Guangzhou (city; also Canton)
23 13 N
106 25 W
Swaziland
26 18 S
31 06 E
Heard Island and McDonald
53 06 S
73 30 E
Islands
19 24 N
99 09 W
Adantic Ocean
25 00 N
90 00 W
Republic of the Congo
1 00 S
15 00 E
25 40 N
100 19 W
19 00 N
112 45 W
19 30 N
89 00 W
Montenegro, Serbia
43 00 N
21 00 E
Bosnia and Herzegovina,
43 00 N
19 00 E
Croatia, Macedonia,
Montenegro, Serbia,','59503f13709e7f40f6f497a8b958e2d9d3058a5aa6373fca18ac0c939108d8a1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72cdaa115b3b1e85caaa3840ce97cab8397cda2a36386fb9210452cf53e854b8',2010,'MN','Mongolia','environment',1702,'MG
MN
MNG
496
MNG
.mn
46 00 N
105 00 E
46 00 N
105 00 E
North Korea
39 01 N
125 45 E
Marshall Islands, Federated
States of Micronesia,
Northern Mariana Islands,
47 55 N
106 53 E
South Korea
37 29 N
130 52 E
Ireland, United Kingdom
54 35 N
7 00 W','686385671aeb7b9d03fa4002347855103e12404e84fb3eaf76b63e881c8da32e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b69cfdd3f9be5b011628cdf6ac6571b89482deff98a8e4c67a0b33671b4c59fe',2010,'MA','Morocco','environment',1703,'MO
MA
MAR
504
MAR
.ma
32 00 N
5 00 W
Al Urdun (local name for Jordan)
27 53 N
12 58 W
33 35 N
7 34 W
32 00 N
5 00 W
29 22 N
10 09 W
Saint Helena
37 17 S
12 40 W
Cambodia, Laos, Vietnam
15 00 N
107 00 E
Russia
43 15 N
45 00 E
32 00 N
5 00 W
34 02 N
6 51 W
32 00 N
7 00 W
Spain (Ceuta, Islas Chafarinas,
35 15 N
4 00 W
Melilla, Penon de
Alhucemas, Penon de Velez
de la Gomera)
35 48 N
5 45 W
Russia
51 25 N
94 45 E','7ca207d220224db1e484af97f64e5db9156e2e196e8502e9ff43cfb58ad3bf72','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09bd854c71a61e45b35415dab6333f212689d1e6e2fb8f135f60ea53edfc886b',2010,'MZ','Mozambique','environment',1704,'MZ
MZ
MOZ
508
MOZ
.mz
22 30 S
34 30 E
25 56 S
32 34 E
25 58 S
32 35 E
18 15 S
35 00 E
13 30 S
37 00 E
United States (Hawaii)
21 30 N
158 00 W
18 15 S
35 00 E
16 00 S
37 00 E
Tanzania
6 10 S
39 11 E','908f0ab4d1da7b6816bb4cc6a4e24b5af5f961e9434dbe60307ff9ee03e836b7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f96c6ed8444c6863bb2c93f800cf2672189fdf8301a87120fd30a4a0369ade1a',2010,'NA','Namibia','environment',1705,'WA
NA
NAM
516
NAM
.na
22 00 S
17 00 E
24 00 S
15 00 E
22 00 S
17 00 E
22 59 S
14 31 E
22 34 S
17 06 E
Atlantic Ocean
20 00 N
73 50 W','4cf30b06e7c82c821687769a74850271c52bfbaf942e1945bf97e3bee57d117e','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35157a78258e78cba884d57a9dbf43a0c9cc3590c2df4e4f10a5620a730a95cc',2010,'NR','Nauru','environment',1706,'NR
NR
NRU
520
NRU
.nr
Navassa Island
BQ
-
-
-
US
-
ISO includes with the US Minor
0 32 S
166 55 E
835
Name
THE CIA WORLD FACTBOOK
Plymouth (capital)
Podgorica (administrative capital)
Polska (local name)
Polynesie Francaise (local name for French Polynesia)
Pomerania (region)
Ponape (Pohnpei) (island)
Port Louis (capital)
Port Moresby (capital)
Port-Vila (capital)
Port-au-Prince (capital)
Port-of-Spain (capital)
Porto-Novo (capital)
Portuguese East Africa (former name for Mozambique)
Portuguese Guinea (former name for Guinea-Bissau)
Portuguese Timor (former name for Timor-Leste)
Poznan (city)
Prague (capital)
Praia (capital)
Prathet Thai (local name for Thailand)
Pretoria (administrative capital)
Prevlaka peninsula
Pribilof Islands
Prince Edward Island
Prince Edward Islands
Prince Patrick Island
Principe (island)
Pristina, Prishtina, Prishtine (capital)
Prussia (region)
Pukapuka Atoll
Punjab (region)
Puntland (region)
Qazaqstan (local name for Kazakhstan)
Qita Ghazzah (local name Gaza Strip)
Quebec (city)
Queen Charlotte Islands
Queen Elizabeth Islands
Queen Maud Land (claimed by Norway)
Quemoy (island)
Quito (capital)
Rabat (capital)
Ralik Chain (island group)
Rangoon (capital; also Yangon)
Rapa Nui (Easter Island)
Ratak Chain (island group)
Red Sea
Redonda (island)
Republica Dominicana (local name for Dominican Republic)
Republique Centrafricain (local name for Central African
Republic)
Republique Francaise (local name for France)
Republique Gabonaise (local name for Gabon)
Republique Rwandaise (local name for Rwanda)
Republique Togolaise (local name for Togo)
Revillagigedo Island
Revillagigedo Islands
Reykjavik (capital)
Rhodes (island)
Rhodesia, Northern (former name for Zambia)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
0 32 S
166 55 E
Russia
56 50 N
60 39 E
Pacific Ocean
36 00 N
123 00 E','4112a74a65d07fd5be98f60146e58aad847375d999de5ea9f4b82c6179bf6df4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21b6c03498cfd475a01ded6f0adf7aa54ecf2377d42af807671d63b6cbd4ba6f',2010,'NP','Nepal','environment',1707,'NP
NP
NPL
524
NPL
.np
Outlying Islands
27 43 N
85 19 E
Kattegat (strait)
Adantic Ocean
57 00 N
11 00 E
Kauai Channel
Pacific Ocean
21 45 N
158 50 W
Kazakstan (former name for Kazakhstan)','a2030b9da45e2cc43db2ac635c6bb2d1e26c115462497d8134db3aadb44b31fa','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31941a08c01a2fad406c64869b45ff944bf650d0ccb35cc6237efa9c8ff21010',2010,'NL','Netherlands','environment',1708,'NL
NL
NLD
528
NLD
.nl
Netherlands Antilles
NT
AN
ANT
530
ANT
.an
52 23 N
4 54 E
French Southern and Antarctic
37 52 S
77 32 E
Lands
Southern Ocean
72 30 S
112 00 W
China, Russia
52 56 N
141 10 E
Pacific Ocean
53 00 N
141 30 E
Pacific Ocean 4
64 00 N
177 00 E
Turkey
39 00 N
35 00 E
52 05 N
4 18 E
Haifa (city)
52 30 N
5 45 E
Hong Kong (special administrative region)
52 30 N
5 45 E
Netherlands Antilles
12 15 N
68 45 W
53 26 N
5 30 E','9b915333b5be15f709ccd83ed28010eb8f92dc87d7cc28cd3300662319115f7f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cc4008ccde890e1154e3189c02eca9c74f7503666d8662d107c990f73a44535',2010,'NC','New Caledonia','environment',1709,'NC
NC
NCL
540
NCL
me
19 45 S
163 40 E
19 52 S
158 15 E
Pacific Ocean
38 30 N
120 00 E
21 00 S
167 00 E
22 16 S
166 27 E
21 30 S
165 30 E','26dff537ec7695e4d75e2cfe68742596e5e517e5f38fcd1db248db1156371e6f','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50a25c88be128c47935a7ca2910905da6eedf875a5fe38f8be520a1a748915fc',2010,'NZ','New Zealand','environment',1710,'NZ
NZ
NZL
554
NZL
.nz
49 41 S
178 43 E
36 52 S
174 46 E
51 00 S
166 30 E
47 43 S
174 00 E
Reunion
21 06 S
55 36 E
52 33 S
169 09 E
Atlantic Ocean
20 00 N
94 00 W
44 00 S
176 30 W
Russia
43 15 N
45 40 E
Pacific Ocean
34 00 N
126 30 E
Korea, South
33 20 N
126 30 E
29 50 S
178 15 W
Kerulen River
China, Mongolia
48 48 N
117 00 E
Khabarovsk (city)
Russia
48 27 N
135 06 E
Khanka, Lake
China, Russia
45 00 N
132 24 E
Khartoum (capital)
39 00 S
176 00 E
Russia
43 00 N
44 10 E
Pacific Ocean
30 00 N
165 00 W
Atlantic Ocean
56 00 N
4 00 E
Vietnam
23 00 N
106 00 E
43 00 S
South Korea
37 00 N
41 28 S
174 51 E','6390e09e98678bddb61a967fa61187f653f57819bb560c601bd27077f7287569','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09652a98bda78c62e6fb6314ce41442748857382342fa3de394777666bb7ea4b',2010,'NI','Nicaragua','environment',1711,'NU
NI
NIC
558
NIC
.ni
12 15 N
83 00 W
Guyana, Venezuela
3 38 N
66 50 W
12 15 N
83 00 W
12 09 N
86 17 W
v ^Managua
San Jose
80
. ishkfc ,
s w A’fldm
iCCH-ohlilA:
mmmms
Hartfniqiie (FRANCE) %
umStA ST. LUCIA l
. . . ^telands, $''(. viMLTm AMD *
''Vr''rH3, THE GRENADINES
v*?*'' .GRENADA/
BarranquilM, <*■■-£ Cdt£Ssi Caracas^ . J**M»**l»i»
? : * Valencia i£v\\_ t*<
/ \\ s''. "Valencia A;v- „ TjoiSACiO
A . \\ Banjdistmclo X. 4;
'' "" ''Sw '' < ■■■■. ■y
:«:*San Cristobal^ . $%*?***'' j ^Georgetown
Paramaribo
nnc
i SURINAM t! from 11/
...fe
: l a n.
c c a.
/ A Sac* Luts
‘ mt 01 laleza
/Li
l h ■ rf: f 1
L-LL ■; ;C"I . | Natal
V 1
o. * , ; "yf W'' J M# M z/S/zW''A
■ / ■
i Recife
_ mm _ pp nHnfli # #«» ?
A X, /Maceio
9p
of*'' '' 1
lx
A Salvador
Brasilia
'' l$ras,,,a*
, * ■ '' , g, ''A? / /g , 5
H I G H LA N - .
:.M> '' ; U
1 M - - X '' 4 ;/
At* f Held 1/
AftCHlPIELAGO \\
ILIAN FERNANDEZ .
(CHHX) . :
\\''ta >
^ I ;,dc Tucuman
. 7-tlTC
CMILife , .. • I _
A ,. .A. Porto Alegre
Caro Aconcagua , x , . ,, ..
ihigiiesi por,; ,i> — — Corciolvi, ,^.Saota Icy. ^ ( '' '' * /V
South America, 696Zm)\\ A# I 0- «--•■■
Valparaiso, .Mendoza ^ sosariA]^ /URUGUAY^ :< v
Santiago Buenos Alk*s-^
^ T 1 ; v 1
/- r j
Concepcion ; ''/''Ww*
n* J ARQEriTIM^
1
,*4, v Bahia Blanca,
IT} *
Puerto Mont!
Pi®
Sail Carlos d« A
''1 • Bartlodie \\
r<f0>- \\ V''
'' < -vA
lt pL''; ^
4# o
i.a Plato Montevideo
lie.
'' Mar del Plata
l c
0 c e a it
i
1
i ''
i
■■■ >
_
Coinodoro Kivadavia
Scale 1:35,000,000
Azimuthal Equal- Area Projection
0 500 Kilometers
Pratt: L*t
Ci-lkm
500 Miles
Hoimdary reprcsentailon is
no! necessarily awheritative.
^iiomrst point in Soutn America and
Z “>c Western Hemisphere. 105 mi
Punta
80
Cape
Morn
Stanley
Falkland Islands
(Islas Malvinas)
iadministered bv U.K..
claitned by AROEMTINA)
South Georgia anc! the
/ South Sandwich Islands
/ ^ (administered by U.R.,
/ ^ claimed by ARGF.hTINA)
/
864
REFERENCE MAPS
SOUTHEAST ASIA
865
THE CIA WORLD FACTBOOK
866
REFERENCE MAPS','8339d8b3caffb147029448ea841d3d804a96770248e5f5d4d80ef69d7642bd13','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b690a630503151d0e47ecd52abbd3f10df40a3365f03dc4c3e83e4ab9c046c63',2010,'NG','Nigeria','environment',1712,'NI
NG
NGA
566
NGA
•ng
9 12 N
7 11 E
Abyssinia (former name for Ethiopia)
5 30 N
7 30 E
Russia
65 46 N
169 06 W
10 33 N
7 27 E
Kailas Range
China, India
30 00 N
82 00 E
Kalaallit Nunaat (local name for Greenland)
6 27 N
3 24 E','a602dc444aef0df95152cdd9ffcb61a658b3e2a3d1ef37d47791275114ebe019','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c759872b32eb484bb33aa1fc42f717532f8a4bc9bad5b749c0e928248823d025',2010,'NU','Niue','environment',1713,'NE
NU
NIU
570
NIU
.nu
19 01 S
169 55 W
19 02 S
169 52 W
Pacific Ocean
9 30 S
122 00 E','32f0001ce85c3fc8532a42d64ca49b30a355b4ffe49b5f3138f081af6ef35716','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9dbd06308ba9094472ce1e1c5b71b6ccf03d018b557c4c6db13700468df2f3b',2010,'NF','Norfolk Island','environment',1714,'NF
NF
NFK
574
NFK
mf
29 03 S
167 58 E
Kingstown (capital)
Saint Vincent and the
Grenadines
13 09 N
61 14 W
Kinshasa (capital)
Democratic Republic of the
29 08 S
167 57 E
Pacific Ocean
20 00 N
1 34 00 E','31765430bd8c5266d9beb3a24061fdd547b81697f409e679af0e6e982bed5e00','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('578e049e8aef59fb0e63708f192cdd4431db767c015f37027cb4687ebff5f97d',2010,'MP','Northern Mariana Islands','environment',1715,'CQ
MP
MNP
580
MNP
.mp
19 40 N
145 24 E
18 08 N
145 47 E
14 10 N
145 12 E
15 12 N
145 45 E
Georgia v v
42 00 N
43 30 E
Russia
51 00 N
143 00 E
15 00 N
145 38 E
Indian Ocean
28 00 N
34 27 E','396026ae5ca1fae04f3ed6be144063b5ed22be47c4ec083ed7cb7843f639ec71','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aafe578a5e78af295568cb2fb7c32ae7cd1d8f63cefa2c3cf10309f031c99d12',2010,'NO','Norway','environment',1716,'NO
NO
NOR
578
NOR
.no
62 00 N
10 00 E
Guernsey, Jersey
49 20 N
2 20 W
Atlantic Ocean
30 00 N
45 00 W
Atlantic Ocean
55 10N
5 40 W
Denmark, Germany
54 50 N
8 12 E
Arctic Ocean
78 00 N
5 00 W
59 55 N
10 45 E
Pacific Ocean
31 00 N
131 00 E
Atlantic Ocean
40 00 N
19 00 E','278f0d1b52269dc7c8fce8df9f2e8d2e60385645640b594c0900d789ee6134c7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0be8e8c0c11d43d1cbec7382045d401db87b11d2dcebf24698f0137eb040a71',2010,'OM','Oman','environment',1717,'MU
OM
OMN
512
OMN
.om
17 00 N
54 10 E
17 30 N
56 00 E
Khyber Pass
Afghanistan, Pakistan
34 05 N
71 10 E
Kibris (Turkish local name for Cyprus)
23 37 N
58 35 E
21 00 N
57 00 E
Burma
22 00 N
98 00 E
21 00 N
57 00 E
Pacific Ocean
54 20 N
164 50 W
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakh''
stan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia,
, ■ •
Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
f '' '' ; ■*
Egypt, Syria
pftft . . /
■','59ffd0ae54e73732b99b6db48206ae0d22adcb46a31cc154684e321fde781f5a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c6cbb8bcc0beff23c3a07db883017587298756d6a151b65b1d21aa7c9474f46',2010,'PK','Pakistan','environment',1718,'PK
PK
PAK
586
PAK
.pk
34 30 N
74 00 E
818
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Name
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Azarbaycan, Azerbaidzhan (local name for Azerbaijan)
28 00 N
63 00 E
Baltic Sea
Atlantic Ocean
57 00 N
19 00 E
Bamako (capital)
33 42 N
73 10 E
24 51 N
67 03 E
Karafuto (island; former name for southern Sakhalin Island)
Russia
50 00 N
143 00 E
Karakoram Pass
China, India
35 30 N
77 50 E
Karelia, Kareliya (region)
Finland, Russia
63 15 N
30 48 E
Karelian Isthmus
Russia
60 25 N
30 00 E
Karimata Strait
Pacific Ocean
2 05 S
108 40 E
Kashmir (region)
India, Pakistan
34 00 N
76 00 E
Katanga (region)
Democratic Republic of the
31 33 N
74 23 E
Adantic Ocean
42 30 N
81 00 W
Adantic Ocean
45 00 N
83 00 W
Adantic Ocean
43 30 N
87 30 W
Adantic Ocean
43 30 N
78 00 W
Adantic Ocean
48 00 N
88 00 W
36 ON
75 0 E
34 01 N
71 40 E
30 00 N
70 00 E
Russia
60 00 N
75 00 E
Pacific Ocean
34 40 N
129 00 E','9a8d4e02aff280d71ffc2dc6d6343a5e36320414f244558544949e5538658c79','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eb888bbcaa8d3955173713d77ec33a494312b33368ec214d90fd9845365a8c1',2010,'PW','Palau','environment',1719,'PS
PW
PLW
585
PLW
.pw
812
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
STANAG-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
Palmyra Atoll
LQ
-
-
UMI
-
ISO includes with the US Minor
7 20 N
134 29 E
Kosovo
42 30 N
21 00 E
Federated States of Micronesia
5 20 N
163 00 E
10 00 N
155 00 E
7 01 N
134 15 E','2c253b53b227a90d8a04ed23e4ac92430ef5cfb95482e03b16d11ba802cca47a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5addce57c7293fccc1d1990a2f10480c94afb7b294ba4ade3919bd917d2f260a',2010,'PA','Panama','environment',1720,'PM
PA
PAN
591
PAN
.pa
Oudying Islands
9 00 N
79 45 W
Adantic Ocean
28 00 N
16 00 W
8 58 N
79 32 W
9 00 N
79 45 W
Pacific Ocean
8 00 N
79 30 W','9f386fd7cb0dc2d6b0cdcc9120aa83e97a10f1c8bc2ae577f22790c49a5dc274','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('884ee5c3250b5788ac39064b9f9a523711abc6c5c84f838ba08cf665f282cf06',2010,'PG','Papua New Guinea','environment',1721,'PP
PG
PNG
598
PNG
•Pg
Paracel Islands
PF
-
-
-
-
-
2 10 S
147 00 E
Adriatic Sea
Adantic Ocean
42 30 N
16 00 E
Adygey (region)
Russia
44 30 N
40 10 E
Aegean Islands
5 00 S
150 00 E
Pacific Ocean
4 00 S
148 00 E
6 00 S
155 00 E
Pacific Ocean
6 40 S
156 10 E
9 30 S
150 40 E
Russia
43 00 N
47 00 E
4 30 S
154 10 E
Arctic Ocean
79 00 N
5 00 W
Saint Vincent and the
13 15 N
61 12 W
Grenadines
11 00 S
153 00 E
6 00 S
150 00 E
3 20 N
152 00 E
Russia
75 00 N
142 00 E
9 30 S
147 10 E
6 00 S
8 38 S
151 04 E','86b43612c1053d1dd3b23acede6da03b1868e245c74c06e7868b0b18715db0cd','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9708cc5ee0f96c43bed3407a97f6e0fd672626a42b7efa9626eec16354047c17',2010,'PE','Peru','environment',1722,'PE
PE
PER
604
PER
•pe
12 03 S
77 03 W
Arctic Ocean
83 00 N
56 00 W
Jarvis Island, Kingman Reef,
0 05 N
157 00 W
Kiribati, Palmyra Atoll
Adantic Ocean
43 20 N
4 00 E','92bfd86a8196d27f45d615fd30681928568bde565a8899fbb6ffd71468955d81','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a4d0db460180350f68660e83ed33df3fe3ab1a40331cdf7f066b91b4b4b1b73',2010,'PH','Philippines','environment',1723,'RP
PH
PHL
608
PHL
.ph
Pitcairn Islands
PC
PN
PCN
612
PCN
.pn
19 10N
121 40 E
Baffin Bay
Arctic Ocean
73 00 N
66 00 W
Baffin Island
19 55 N
122 10 E
Balkan Peninsula
Albania, Bosnia and Herze¬
govina, Bulgaria, Croatia,
Greece, Kosovo, Macedonia,
Montenegro, Romania,
Serbia, Slovenia, Turkey
(European part)
42 00 N
23 00 E
Balleny Islands
20 30 N
121 50 E
Bavaria (region; also Bayern)
13 00 N
122 00 E
Adantic Ocean
60 00 N
27 00 E
10 50 N
124 50 E
South Korea
37 15 N
131 50 E
Pacific Ocean
40 30 N
121 20 E
16 00 N
121 00 E
Pacific Ocean
20 30 N
121 00 E
Russia
73 45 N
138 00 E
Macau
22 10 N
113 33 E
Malaysia, Thailand
7 10 N
100 35 E
14 35 N
121 00 E
Pacific Ocean
3 20 S
127 23 E
Indian Ocean
8 30 N
79 00 E
American Samoa *
14 13 S
169 35 W
8 00 N
125 00 E
Pacific Ocean
9 15 N
124 30 E
12 50 N
121 05 E
Pacific Ocean
12 20 N
120 40 E
15 08 N
120 21 E
Indian Ocean
19 00 S
41 00 E
10 00 N
123 00 E
9 30 N
118 30 E
11 15 N
122 30 E
15 08 N
120 21 E
12 00 N
125 00 E
West Bank
32 15 N
35 10 E
American Samoa, Samoa
14 00 S
171 00 W
6 00 N
121 00 E
Pacific Ocean
8 00 N
120 00 E','b7869b0c69090fc416ab8194bc5589b024ad311980cc94dba8ad90b9d87be3ac','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f5e479ef0b98298d8549fc3ef57dcda32d7642d2b50bcf924c539e7212a9338',2010,'PL','Poland','environment',1724,'PL
PL
POL
616
POL
.pi
54 23 N
18 40 E
Vietnam
20 08 N
107 44 E
Tanzania
6 48 S
39 17 E
Adantic Ocean
40 15 N
26 25 E
Adantic Ocean
67 00 N
57 00 W
Israel, Jordan, West Bank
32 30 N
35 30 E
54 23 N
18 40 E
50 03 N
19 56 E
52 00 N
20 00 E
52 25 N
16 55 E
Czech Republic
50 05 N
14 28 E
Cape Verde
14 55 N
23 31 W
52 15 N
21 00 E','67086b27f9cf375f4b8a93b3a1e829632b70928f2756d216d7ead61b12a65910','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65a53118d563238115a4370f121e0de889e1a47d152e5d99f9b039720ac25e95',2010,'PT','Portugal','environment',1725,'PO
PT
PRT
620
PRT
•Pt
38 30 N
28 00 W
Azov, Sea of
Atlantic Ocean
49 00 N
36 00 E
Bab el Mandeb (strait)
Indian Ocean
12 40 N
43 20 E
Babuyan Channel
Pacific Ocean
18 44 N
121 40 E
Babuyan Islands
38 43 N
9 08 W
Adantic Ocean
55 05 N
9 55 E
32 40 N
16 45 W
Istanbul
Ankara.
Lisbon
Mashhad £~\\
» Ui£y fLbmir TURKEY *
Athenf^ A Ada<% .
X| '' ^ ^ '' (fZMepfa C
,R
CYEKUS ^Damascus
»<i .’fa Beirut ?yfr p\\ ’
Jerusalem ; (C.
‘Ranghdzi ..AI^andm ^iSIVLEl^fAmman •
) "'' \\LCairtf\\f JORDAN I
\\ *a 4 / i
1 Ai fizah / YL M. y \\
dr Tehran
MADEIRA ISLANDS
.^PORTUGAL)
jl Valletta','44df402dde3541687f6cedb3044b007997835a46f7b4c79e7d819dc07b03e2d3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03a0a18e187f57980ced5259cedc09d69a9fe46dae9784fb8daf6ea37b1152e0',2010,'QA','Qatar','environment',1726,'QA
QA
QAT
634
QAT
•qa
Reunion
RE
RE
REU
638
REU
.re
25 17 N
51 32 E
Russia, Ukraine
48 15 N
38 30 E','0f1492f3aacbe72e7795222db2fa4d42e9fece2ceff8be6d8f0544a5a9f47453','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faa8ad21830d6068665b9b8fb9e7ec3b0cb4b1012be98c954970bcb751be0c22',2010,'RO','Romania','environment',1727,'RO
RO
ROU
642
ROU
.ro
Russia
RS
RU
RUS
643
RUS
.ru
44 26 N
26 06 E
46 30 N
24 00 E
44 45 N
26 05 E
: i / V
Sisak -
1, 1>rgu
Viciin *
,n» , L . •
Shengjirf* "c«*«(<ar ^Vclcs »S!lp
■ KiMi-p'' . MACEDONIA
Cerignola
v- V
Inter-Entity Boundary
Line OEBL)
(Dayton agreement line)
Scale 1:5,600,000
Lambert Conformal Conic Prelection
standard parallels 40‘‘43’ N and 43 al5’ N
a 50 Kilometer*
i i i i i i
LushniC ftajraaecr
1
f Berat
Korye.
''* ~ V, & \\ \\ c / Kastotfd
. : w.s v
v «|. m ri : f fy XMtmm
•r
0/ A- if ^ Kozam
/*
50 Kilometer*
■ -1- 1 1 T''1-!1 — , — i
50 Miles
,, > : **v
> s>~W % * y \\ '' % d] %y aM
RMRW ^■PWRP \\ v * -a>1 A % A W
Corfu l if ; :f :/ . jearm-a
Boundary representation if> Kcrkyf^ -/ .. ''
no! necessarllv authoritalive.
. -:----- . . . . • . . . . V:>: . : . ^ •" ^ T .
'' t W '' C
''
% QREEC
Mm A i
868
Reference
US$14.95
m ®
JL
From Afghanistan to Zimbabwe, The CIA World Factbook 2010 offers com¬
plete and up-to-date information on the world’s nations. Updated for 2010
with details on politics, populations, military expenditures, and economics,
it will be helpful whether you are keeping track of events in world hotspots
like Iran and Honduras, or double checking your knowledge of Russia and
Brazil.
For each country included,
offers:
etailed maps with new geopolitical data
itatistics on the population of each country, with
details on literacy rates, HIV prevalence, and age
structure
Jew data on military expenditures and capabilities
Details on important political parties
Information for diplomatic consultation
Facts on transportation and communication
infrastructure
■
ieography and natural resources
h more!
W8m
£ archive
Identifier:
r *5 -1 Jr
Included an
mental agn
measure cc
, h++ Central Intel
ernment of
nalists, anc
tional community in wmcn wc
. — ■ 1 .
Cia*orldfactbookGCOGunit
Title tu. _
29Z0e: The CIA worl« factbook
Central Intetliof tates ‘
''ive.org/detaiu/ A9ency
ational environ-
ps, weight and
se by U.S. gov-
i, travelers, jour-
bout the interna-
v w
Skyhorse Publishing, Inc.
555 Eighth Avenue, Suite 903
New York, NY 10018
www.skyhorsepublishing.com
9711662397279
2016-01-19 15:36
Cover design by Adam Bozarth
Printed in Canada','5fbec0529d3b9f94174442b2f8dced63626336ddcfd9225c932acb32bde3cd95','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a08d0b24433ec94cbe5e4e5fdb3057bdb4c1362997e05695081b08c33f15a14d',2010,'RW','Rwanda','environment',1728,'RW
RW
RWA
646
RWA
.rw
Saint Barthelemy
TB
BL
BLM
652
- .
.bl
ccTLD .fr and .gp may also be us<
Saint Helena
SH
SH
SHN
654
SHN
.sh
1 57 S
30 04 E
Kingston (capital)
2 00 S
30 00 E
2 00 S
30 00 E','571237298bb8fd99e87c4c20275f8339ada7a1779f09feb8318483854bb3d641','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9584a0df737442d0481afe1c1206729460ce0ee44a6bae7bbc3c2a4134970a9',2010,'KN','Saint Kitts and Nevis','environment',1729,'SC
KN
KNA
659
KNA
.kn
17 18 N
62 43 W
Bastia (city)
France (Corsica)
42 42 N
9 27 E
Basutoland (former name for Lesotho)
17 09 N
62 35 W
17 20 N
62 45 W
17 20 N
62 45 W
Netherlands Antilles
17 30 N
63 00 W','d97d5e088a7b69029477268a4614c1e9a8ff93e09601d844d969fd6ce3fbb994','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('237d6a0cfad1ead26370443ecf77e681d3e003ed5c44bd3a1cfa45cc7c0aa135',2010,'LC','Saint Lucia','environment',1730,'ST
LC
LCA
662
LCA
.lc
Saint Martin
RN
MF
MAF
663
-
.mf
ccTLD .fr and .gp may also be us<
14 01 N
61 00 W
Spain 1
42 00 N
2 00 E','91f2c3e33019fbbc05e4c5eacd5b78378b3758bbf1166fe86e280654b06f1058','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e15c700a618990f71617f32fad0450eedd4e4779461926068030934f3a7115b2',2010,'PM','Saint Pierre and Miquelon','environment',1731,'SB
PM
SPM
666
SPM
.pm
Saint Vincent and the
VC
VC
VCT
670
VCT
.VC
Grenadines
46 46 N
56 11 W','a4919e5ef618a0d227b428b254e763471aa1cd3cb99ad1650f154d51cd06cd92','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87945330fd1bf97e9a8b532689e252d570de3a6897a09f8c246aa71202a69465',2010,'WS','Samoa','environment',1732,'ws
WS
WSM
882
WSM
.ws
13 50 S
171 44 W
Indian Ocean
29 00 N
34 30 E
Iran, Iraq
29 57 N
48 34 E
Indian Ocean
15 00 N
65 00 E
Pacific Ocean
9 00 S
133 00 E
Kazakhstan, Uzbekistan
45 00 N
60 00 E
China, Russia
53 20 N
121 28 E
Pacific Ocean
6 15 S
135 00 E
13 35 S
172 20 W
Pacific Ocean
8 20 S
126 30 E
Arctic Ocean
65 30 N
38 00 E','e1530b5706fe683853d731f45772e5ba7f572746c9fa2b3cfccc140a0591b044','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('019b62ec795c7ed9fc4f98d76c66079627718f30dea0bc820f527b4bb44266ff',2010,'ST','Sao Tome and Principe','environment',1733,'TP
ST
STP
678
STP
.St
1 38 N
7 25 E
Kosovo
42 40 N
21 10 E
Germany, Poland, Russia
53 00 N
14 00 E
0 12 N
6 39 E','4c980146c1bae4bf9fd0b52381ff0ea1fcf7855499767570b0037c9ef880f2ed','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ed59eb405414981c57fd4d031babcf54c592a7214fd2631dbc401f64158798a',2010,'SA','Saudi Arabia','environment',1734,'SA
SA
SAU
682
SAU
.sa
25 00 N
45 00 E
Al Bahrayn (local name for Bahrain)
24 30 N
38 30 E
Helsinki (capital)
21 30 N
39 12 E
21 27 N
39 49 E
Adantic Ocean
36 00 N
15 00 E
24 05 N
45 15 E
24 38 N
46 43 E
British Virgin Islands
18 27 N
64 37 W
19 30 N
49 00 E
Albania, Bulgaria, Macedonia
42 00 N
22 30 E','d462962d3a274948c7dd16b1c311107f0ec53056930aff3304171dcea311d69d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5513ffd36c38d0770e6db8fac3ac73f660c169cdcf02a96b5795780cdcb4578b',2010,'RS','Serbia','environment',1735,'RI
RS
SRB
688
-
.rs
44 50 N
20 30 E
44 00 N
21 00 E
Canada (Newfoundland)
47 34 N
52 43 W
Falkland Islands (Islas
51 42 S
57 41 W
Malvinas)
45 35 N
20 00 E
Calatat
Paracm •
Jfeiik
\\ 4 , U i*‘ i«S(‘ ri ''>
'' '' c -
Krysevac
Mori^rta,
tcskovac,
pT. i'' Koscvska
Mitrovica
Pristina +
KOSOVO
y/''iMc
Permck
!\\\\\\ J
Dubrovi^k
Gjiian/
Gnjilane
bkovfea
Urosevae*
.Kvustcndif-
KumanoVe
Manfredonla
Durrfe
Kava|A
1 hesstsfonik!
i arisa
Manfredonla
Bariena
!;? .rtatii
Ancina
Moifetta','5c1c70202da17c01ccc2744cbc0344bfd020d17ed3738a33a343daa8b2354d58','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f5a045c9fb4795f14682f575ee04ae1fb6296a775d23e17f543515f92be8331',2010,'SC','Seychelles','environment',1736,'SE
SC
SYC
690
SYC
.sc
9 25 S
46 22 E
Alderney (island)
7 01 S
52 45 E
6 00 S
53 10 E
9 46 S
46 34 E
9 43 S
47 35 E
10 10 S
51 10 E
Kyrgyzstan, Tajikistan,
41 00 N
72 00 E
4 41 S
55 30 E
4 38 S
55 27 E','90d7aaed0139648c124678786a0cd7d0c20f1420812efac59bd5f35983fb4bea','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f94e05106a5e67f528a1c865b19d752253cbc5420754e721fd9b1201c57daafa',2010,'SK','Slovakia','environment',1737,'LO
SK
SVK
703
SVK
.sk
48 09 N
17 07 E
Republic of the Congo
4 16 S
15 17 E
48 40 N
Turkey
38 25 N','105f1543face88d66541ab4b1cddaebfa3a82a0f21df21ad17ac011dd8f07bca','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7982cc8562117290b26a0d822ab9523d6d52d507c16798808444c776770b931b',2010,'SI','Slovenia','environment',1738,'SI
SI
SVN
705
SVN
.si
46 03 N
14 31 E
Venezuela
8 00 N
68 00 W
Swaziland
26 27 S
31 12 E
46 00 N
Bosnia and Herzegovina,
43 00 N
19 00 E
Croatia, Macedonia,
Montenegro, Serbia, »
*Ce!je /
#fitfli$oar3','dda75b62fadb3be3365510093538a78e5db91d53de1f34edd20ef89f11b0c014','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e02ec40ea422c75469e5a9f8a72737b196a712427e0cb45aa4c805192b78de95',2010,'SB','Solomon Islands','environment',1739,'BP
SB
SLB
090
SLB
.sb
8 00 S
159 00 E
7 05 S
121 00 E
North Korea
40 00 N
127 00 E
9 32 S
160 12 E
Guadalupe, Isla de (island)
9 26 S
159 57 E
Honshu (island)
11 00 S
166 15 E
Holy See
41 54 N
12 27 E
8 00 S
Pacific Ocean
8 00 S','46ba15c2d10fbef9349c70bda06fabab61e99eae7584003257632a9fd07ac8a0','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5c0a455ac883fde7dbfa714b440937971bce88c01e946488e6be3e2f825fb34',2010,'SO','Somalia','environment',1740,'SO
SO
SOM
706
SOM
.so
4 00 N
46 00 E
Indian Ocean
15 00 N
90 00 E
Pacific Ocean
2 30 S
132 30 E
Russia
55 00 N
166 30 E
Pacific Ocean
60 00 N
175 00 W
Pacific Ocean
65 30 N
169 00 W
10 00 N
49 00 E
8 00 N
48 00 E
Horn, Cape (Cabo de Homos)
10 00 N
49 00 E
2 04 N
45 22 E
Moldova, Romania
47 00 N
29 00 E
Pacific Ocean
2 00 N
127 00 E
8 21 N
49 08 E
9 30 N
Porto- . ''
Novo VX-
Malah<
r.QOATOKtAL GUINEA
Yamoussoukro Accra -.
LIBERIA f ...-— sscQ -★
-•l"" Abidjan '' }','e2ced9ba2915d80fd4f4ea158bad3780ed71eaddd17440b8c805751630c5129a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d59175be1566b8b3be33fcea41f618239c6995f496fe37706189607eb8d426de',2010,'ZA','South Africa','environment',1741,'SF
ZA
ZAF
710
ZAF
.za
South Georgia and the Islands
sx
GS
SGS
239
SGS
•gs
29 12 S
26 07 E
Pacific Ocean
38 00 N
120 00 E
Cape Verde
16 05 N
22 50 W
26 30 S
25 30 E
27 30 S
23 30 E
31 30 S
22 30 E
821
THE CIA WORLD FACTBOOK
Name
Cape Town (legislative capital)
Cape of Good Hope (cape; also alternate name for Cape
Province of South Africa)
Caracas (capital)
Cargados Carajos Shoals
Caribbean Sea
Caroline Islands
Carpatho-Ukraine (region; former name for Zakarpats''ka
oblast7)
Carpentaria, Gulf of
Casablanca (city)
Castries (capital)
Catalonia (region)
Cato Island
Caucasus (region)
Cayenne (capital)
Celebes (island)
Celebes Sea
Celtic Sea
Central African Empire (former name for Central African
Republic)
Ceram (Seram) Sea
Ceska Republika (local name for Czech Republic)
Ceskoslovensko (former local name for Czechoslovakia)
Cetinje (capital city)
Ceuta (city)
Ceylon (former name for Sri Lanka)
Chafarinas, Islas (island)
Chagos Archipelago (Oil Islands)
Challenger Deep (Mariana Trench)
Channel Islands
Charlotte Amalie (capital)
Chatham Islands
Chechnya (region; also Chechnia)
Cheju Strait
Cheju-do (island)
Chengdu (city)
Chennai (city; also Madras)
Chesterfield Islands (lies Chesterfield)
Chihli, Gulf of (see Bo Hai)
Chiloe (Island)
China, People''s Republic of
China, Republic of
Chisinau (capital; also Kishinev)
Choiseul (island)
Choson (local name for North Korea)
Christmas Island (Indian Ocean)
Christmas Island (Pacific Ocean; also Kiritimafi)
Chukchi Sea
Chuuk Islands (Truk Islands)
Cilicia (region)
Ciskei (enclave)
Cifta del Vaticano (local name for Vatican City)
Cochin China (region)
Coco, Isla del (island)
Cocos Islands
Colombo (capital)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
33 57 S
18 25 E
South Africa ,
«
34 15 S
18 20 E
Venezuela
10 30 N
66 56 W
33 00 S
27 00 E
Holy See
41 54 N
12 27 E
Vietnam
11 00 N
107 00 E
29 51 S
31 02 E
34 24 S
18 30 E
26 15 S
28 00 E
Pacific Ocean
14 00 S
128 45 E
46 51 S
37 52 E
Adantic Ocean
40 40 N
28 15 E
29 00 S
30 25 E
28 20 S
26 40 E
25 42 S
28 13 E
46 35 S
38 00 E
32 15 S
28 15 E
25 10 S
29 25 E
23 00 S
31 00 E
Pacific Ocean
13 34 N
120 51 E','df95e2f8f62db3834cce9d2ace90b372e679e5fc20f3d957b1b0a9e56e717393','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92c71b909d6949103bc1dd4440e4058e6dac1503ddcfcd731608d28617c1678',2010,'ES','Spain','environment',1742,'SP
ES
ESP
724
ESP
.es
Spratly Islands
PG
-
-
-
-
-
35 13 N
3 53 W
Alma-Ata (city; former name for Almaty)
39 30 N
3 00 E
Balearic Sea (Iberian Sea)
Atlantic Ocean
40 30 N
2 00 E
Bali (island)
41 25 N
2 13 E
Barents Sea
Arctic Ocean
74 00 N
36 00 E
Barranquilla (city)
43 00 N
2 30 W
Bass Strait
Pacific Ocean
39 20 S
145 30 E
Basse-Terre (capital)
France (Guadeloupe)
16 00 N
61 44 W
Basseterre (capital)
43 15 N
2 58 W
28 00 N
15 30 W
35 53 N
5 19 W
35 12 N
2 26 W
40 00 N
4 00 W
42 45 N
8 10 E
40 24 N
3 41 W
Adantic Ocean
54 00 S
71 00 W
Algeria, Libya, Mauritania,
34 00 N
3 00 E
Morocco, Tunisia
39 30 N
3 00 E
39 30 N
3 00 E
831
Name
THE CIA WORLD FACTBOOK
Malmady (region)
Malpelo, Isla de (island)
Malta Channel
Malvinas, Islas (island group)
Mamoutzou (capital)
Managua (capital)
Manama (capital)
Manchukuo (former state)
Manchuria (region)
Manila (capital)
Manipa Strait
Mannar, Gulf of
Manua Islands
Maputo (capital)
Marcus Island (Minami-tori-shima)
Margarita, Isla (island)
Mariana Islands
Marie Byrd Land (region)
Marigot (capital)
Marion Island
Marmara, Sea of
Marquesas Islands (lies Marquises)
Marseille (cify)
Martin Vaz, llhas (island group)
Mas a Tierra (Robinson Crusoe Island)
Mascarene Islands
Maseru (capital)
Mata-Utu (capital)
Matsu (island)
Matthew Island
Mauritanie (local name for Mauritania)
Mazatlan (city)
Mbabane (capital)
McDonald Islands
Mecca (city)
Mediterranean Sea
Melbourne (city)
Melilla (exclave)
Memel (region)
Mesopotamia (region)
Messina, Strait of
Mexico City (capital)
Mexico, Gulf of
Middle Congo (former name for Republic of the Congo)
Milan (city)
Milwaukee Deep (Puerto Rico Trench)
Minami-tori-shima (Marcus Island)
Mindanao (island)
Mindanao Sea
Mindoro (island)
Mindoro Strait
Mingrelia (region)
Minicoy Island
Minorca Island (Isla de Menorca)
Minsk (capital)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
35 19 N
2 58 W
40 00 N
4 00 E
35 11 N
4 18 W','09f23a8bdaf5229acae8c281ebbe41285b4e14b67248bfdb813bfe2bb0fb71d8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d7dd953c8eaf04a85c49c6334ee4ed0980e5b70a597b34e11def112da56d235',2010,'LK','Sri Lanka','environment',1743,'CE
LK
LKA
144
LKA
.lk
7 00 N
81 00 E
6 56 N
79 51 E
822
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Colon, Archipielago de (Galapagos Islands)
Commander Islands (Komandorskiye Ostrova)
Comores (local name for Comoros)
Con Son (islands)
Conakry (capital)
Confederate Helvetica (local name for Switzerland)
Congo (Brazzaville) (former name for
Republic of the Congo)
Congo (Leopoldville) (former name for the Democratic
Republic of the Congo)
Constantinople (city; former name for Istanbul)
Cook Strait
Copenhagen (capital)
Coral Sea
Corfu (island)
Corinth (region)
Corisco (island)
Corn Islands (Islas del Maiz)
Corocoro Island
Corsica (island; also Corse)
Cosmoledo Group (island group; also Atoll de Cosmoledo)
Cotonou (former capital)
Cotopaxi (volcano)
Courantyne River
Cozumel (island)
Crete (island)
Crimea (region)
Crimean Peninsula
Crooked Island Passage
Crozet Islands (lies Crozet)
Cyclades (island group)
Cyrenaica (region)
Czechoslovakia (former name for the entity that
subsequently split into the Czech Republic and Slovakia)
D''Entrecasteaux Islands
Dagestan (region)
Dahomey (former name for Benin)
Daito Islands
Dakar (capital)
Dalmatia (region)
Daman (city; also Damao)
Damascus (capital)
Danger Islands (see Pukapuka Atoll)
Danish Straits
Danish West Indies (former name for the Virgin Islands)
Danmark (local name)
Danzig (city; former name for Gdansk)
Dao Bach Long Vi (island)
Dar es Salaam (capital)
Dardanelles (strait)
Davis Strait
Dead Sea
Deception Island
Denmark Strait
Desolation Islands (Isles Kerguelen)
Deutschland (local name for Germany)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
7 00 N','4a767496799693136e46b1d6c5da01b99e236ec1a2b1cf94c3575c21e71b000a','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('608d8bc884c0c8932499d621381c63e114c60672df0f857201d6ca9b3fc7555b',2010,'SD','Sudan','environment',1744,'su
SD
SDN
736
SDN
.sd
15 00 N
30 00 E
15 00 N
30 00 E
Saint Helena
7 57 S
14 22 W
15 36 N
32 32 E
Khios (island)
§aialah
....
Omdurman
^Khartoum
isawa
Asmara*
„ , '' ''
|||Pp
*Al Mukalla
Wad
Madani
)UTI','0341a3dd3e751c287464bf6fd67ddd83d48c7b9596e866b88de2f5129d57abf4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aabce6981b8ee89ffbb0914071316ba3bf6e1b0391f88a856a126f620b5a3342',2010,'SR','Suriname','environment',1745,'NS
SR
SUR
740
SUR
.sr
Svalbard
SV
SJ
SJM
744
SJM
•sj
ISO includes Jan Mayen
Swaziland
wz
SZ
SWZ
748
SWZ
.sz
4 00 N
56 00 W
Netherlands Antilles
12 10N
68 30 W
China, Kazakhstan
45 25 N
82 25 E
Pacific Ocean
30 00 N
126 00 E
4 00 N
56 00 W
5 50 N
55 10W
4 00 N
56 00 W
Syria
35 00 N
38 00 E','50734d3d0c08917e4a24a7f72edb3887cc9db9794a2c864ade0696b6f4cd0b9d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f22349772a7f2948e7099abc21854626ff77d8d33e96dbe7f2e49c7938c5834',2010,'SE','Sweden','environment',1746,'sw
SE
SWE
752
SWE
.se
57 43 N
11 58 E
57 30 N
18 33 E
Saint Helena
40 20 S
9 55 W
% - *
56 45 N
16 40 E
Indian Ocean
24 30 N
58 30 E
Pacific Ocean
8 30 S
125 00 E
59 20 N
18 03 E
62 00 N
15 00 E','3db3b3162459825347207cda6978809877125e23a0d8a4b829f203eaac74f3b1','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('257837afd30a6c91c4b1c2bbb1ba4f069b220b0025104384ef597a7edc49729d',2010,'CH','Switzerland','environment',1747,'sz
CH
CHE
756
CHE
.ch
Syria
SY
SY
SYR
760
SYR
•sy
Taiwan
TW
TW
TWN
158
TWN
.tw
46 57 N
7 26 E
Moldova, Romania, Ukraine
47 00 N
28 30 E
47 00 N
8 00 E
Republic of the Congo
1 00 S
15 00 E
Democratic Republic of the
0 00 N
25 00 E
46 12 N
6 10 E
Italy v
44 25 N
8 57 E
47 00 N
8 00 E
Israel, West Bank
31 48 N
35 14 E
Adantic Ocean, Southern
56 00 S
40 00 W
Ocean
47 00 N
8 00 E
47 00 N
8 00 E
47 23 N
8 32 E
844
^ ^ ^
APPENDIX G
WEIGHTS AND MEASURES
Note: At this time, only three countries— Burma, Liberia, and the US— have not adopted the International System of Units (SI, or metric
system) as their official system of weights and measures. Although use of the metric system has been sanctioned by law in the US since
1 866, it has been slow in displacing the American adaptation of the British Imperial System known as the US Customary System. The
US is the only industrialized nation that does not mainly use the metric system in its commercial and standards activities, but there is
increasing acceptance in science, medicine, government, and many sectors of industry.
Mathematical Notation
Mathematical Power Name
1018 or 1,000,000,000,000,000,000
one quintillion
1015 or 1,000,000,000,000,000
one quadrillion
1012 or 1,000,000,000,000
one trillion
109 or 1,000,000,000
one billion
106 or 1,000,000
one million
103 or 1,000
one thousand
102 or 100
one hundred
101 or 10
ten
100 or 1
one
10-1 or 0.1
one-tenth
10-2 or 0.01
one-hundredth
10-3 or 0.001
one-thousandth
10-6 or 0.000 001
one-millionth
10-9 or 0.000 000 001
one-billionth
10-12 or 0.000 000 000 001
one-trillionth
10-15 or 0.000 000 000 000 001
one-quadrillionth
10-18 or 0.000 000 000 000 000 001
one-quintillionth
Metric interrelationships
Prefix
Symbol
Length, weight, or capacity
yotta
Y
1024
zetta
Z
1021
exa
E
1018
peta
P
1015
tera
T
1012
giga
G
109
mega
M
106
kilo
k
103
hecto
h
102
deka
da
101
basic unit
-
1 meter, 1 gram, 1 liter
deci
d
10-1
centi
c
10-2
milli
m
10-3
micro
u
10-6
nano
n
10-9
pico
P
10-12
femto
f
10-15
atto
a
10-18
zepto
z
10-21
yocto
y
10-24
Conversion Factors
To Convert From To Multiply By
acres
ares
40.468 564 224
acres
hectares
0.404 685 642 24
acres
square feet
43,560
acres
square kilometers
0.004 046 856 422 4
acres
square meters
4,046.856 422 4
acres
square miles (statute)
0.001 562 50
acres
square yards
4,840
ares
square meters
100
ares
square yards
119.599
845
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From To
barrels, US beer
barrels, US beer
barrels, US petroleum
barrels, US petroleum
barrels, US petroleum
barrels, US proof spirits
barrels, US proof spirits
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
cables
cables
cables
carat
centimeters
centimeters
centimeters
centimeters
centimeters, cubic
centimeters, square
centimeters, square
centimeters, square
centimeters, square
chains, square surveyor’s
chains, square surveyor’s
chains, surveyor’s
chains, surveyor’s
chains, surveyor’s
cords of wood
cords of wood
cords of wood
cups
cups
degrees Celsius
degrees Fahrenheit
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
drams, avoirdupois
drams, avoirdupois
drams, avoirdupois
drams, troy
drams, troy
drams, troy
drams, troy
drams, liquid (US)
drams, liquid (US)
drams, liquid (US)
drams, liquid (US)
drams, liquid (US)
fathoms
fathoms
feet
feet
feet
feet
gallons
liters
gallons (British)
gallons (US)
liters
gallons
liters
bushels (British)
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
liters
pecks
fathoms
meters
yards
milligrams
feet
inches
meters
yards
cubic inches
square feet
square inches
square meters
square yards
ares
square feet
feet
meters
rods
cubic feet
cubic meters
cubic yards
liquid ounces (US)
liters
degrees Fahrenheit
degrees Celsius
bushels
cubic feet
cubic inches
dry pints
dry quarts
liters
pecks
avoirdupois ounces
grains
grams
grains
grams
scruples
troy ounces
cubic inches
liquid drams (British)
liquid ounces
milliliters
minims
feet
meters
centimeters
inches
kilometers
meters
846
Multiply By
31
117.347 77
34.97
42
158.987 29
40
151.416 47
0.968 9
1.244 456
2,150.42
0.035 239 07
0.046 090 96
3.523 907
64
32
35.239 070 17
4
120
219.456
240
200
0.032 808 40
0.393 700 8
0.01
0.010 936 13
0.061 023 744
0.001 076 39
0.155 000 31
0.000 1
0.000 119 599
4.046 86
4,356
66
20.116 8
4
128
3.624 556
4.740 7
8
0.236 588 2
multiply by 1.8 and add 32
subtract 32 and divide by 1 .8
0.283 775 9
0.353 146 7
610.237 4
18.161 66
9.080 829 8
10
1.135 104
0.062 55
27.344
1.771 845 2
60
3.887 934 6
3
0.125
0.226
1.041
0.125
3.696 69
60
6
1.828 8
30.48
12
0.000 304 8
0.304 8
WEIGHTS AND MEASURES
Conversion Factors
To Convert From
feet
feet
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, square
feet, square
feet, square
feet, square
feet, square
feet, square
furlongs
furlongs
furlongs
furlongs
furlongs
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
grains
grains
grains
grains
grains
grains
grains
grains
grains
grains
grains
grams
grams
grams
grams
grams
grams
To
statute miles
yards
bushels
cubic decimeters
cubic inches
cubic meters
cubic yards
dry pints
dry quarts
gallons
gills
liquid ounces
liquid pints
liquid quarts
liters
pecks
acres
square centimeters
square decimeters
square inches
square meters
square yards
feet
inches
meters
statute miles
yards
cubic feet
cubic inches
cubic meters
cubic yards
gills (US)
liquid gallons (British)
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims
centiliters
cubic feet
cubic inches
gallons
gills (British)
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grams
kilograms
milligrams
pennyweights
scruples
troy drams
troy ounces
troy pounds
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
kilograms
milligrams
Multiply By
0.000 189 39
0.333 333 3
0.803 563 95
28.316 847
I, 728
0.028 316 846 592
0.037 037 04
51.428 09
25.714 05
7.480 519
239.376 6
957.506 5
59.844 16
29.922 08
28.316 846 592
3.214 256
0.000 022 956 8
929.030 4
9.290 304
144
0.092 903 04
0.111 111 1
660
7.920
201.168
0.125
220
0.133 680 6
231
0.003 785 411 784
0.004 951 13
32
0.832 67
128
8
4
3.785 411 784
3,785.411 784
61,440
II. 829 4
0.004 177 517
7.218 75
0.031 25
0.832 67
4
0.25
0.125
0.118 294 118 25
118.294 118 25
1.920
0.036 571 43
0.002 285 71
0.000 142 86
0.064 798 91
0.000 064 798 91
64.798 910
0.042
0.05
0.016 6
0.002 083 33
0.000 173 61
0.564 383 39
0.035 273 961
0.002 204 622 6
15.432 361
0.001
1,000
847
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From
grams
grams
hands (height of horse)
hands (height of horse)
hectares
hectares
hectares
hectares
hectares
hectares
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, short
hundredweights, short
hundredweights, short
hundredweights, short
hundredweights, short
inches
inches
inches
inches
inches
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, square
inches, square
inches, square
inches, square
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilometers
kilometers
kilometers, square
kilometers, square
kilometers, square
kilometers, square
knots (nautical mi/hr)
knots (nautical mi/hr)
leagues, nautical
leagues, nautical
leagues, statute
848
To
troy ounces
troy pounds
centimeters
inches
acres
square feet
square kilometers
square meters
square miles
square yards
avoirdupois pounds
kilograms
long tons
metric tons
short tons
avoirdupois pounds
kilograms
long tons
metric tons
short tons
centimeters
feet
meters
millimeters
yards
bushels
cubic centimeters
cubic feet
cubic meters
cubic yards
dry pints
dry quarts
gallons
gills
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims (US)
pecks
square centimeters
square feet
square meters
square yards
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
grams
long tons
metric tons
short hundredweights
short tons
troy ounces
troy pounds
meters
statute miles
acres
hectares
square meters
statute miles
kilometers/hour
statute miles/hour
kilometers
nautical miles
kilometers
Multiply By
0.032 150 746 6
0.002 679 23
10.16
4
2.471 053 8
107,639.1
0.01
10,000
0.003 861 02
11,959.90
112
50.802 345
0.05
0.050 802 345
0.056
100
45.359 237
0.044 642 86
0.045 359 237
0.05
2.54
0.083 333 33
0.025 4
25.4
0.027 777 78
0.000 465 025
16.387 064
0.000 578 703 7
0.000 016 387 064
0.000 021 433 47
0.029 761 6
0.014 880 8
0.004 329 0
0.138 528 1
0.554 112 6
0.034 632 03
0.017 316 02
0.016 387 064
16.387 064
265.974 0
0.001 860 10
6.451 600
0.006 944 44
0.000 645 16
0.000 771 605
564.383 4
35.273 962
2.204 622 622
15,432.36
1,000
0.000 984 2
0.001
0.022 046 23
0.001 102 31
32.150 75
2.679 229
1,000
0.621 371 192
247.105 38
100
1,000,000
0.386 102 16
1.852
1.151
5.556
3
4.828 032
WEIGHTS AND MEASURES
Conversion Factors
To Convert From
leagues, statute
links, square surveyor’s
links, square surveyor’s
links, surveyor’s
links, surveyor’s
links, surveyor’s
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
meters
meters
meters
meters
meters
meters
meters
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, square
meters, square
meters, square
meters, square
meters, square
meters, square
microns
microns
mils
mils
miles, nautical
miles, nautical
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, square nautical
miles, square nautical
miles, square statute
miles, square statute
miles, square statute
miles, square statute
miles, square statute
miles, square statute
milligrams
milliliters
milliliters
milliliters
To
statute miles
square centimeters
square inches
centimeters
chains
inches
bushels
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
gallons
gills (US)
liquid ounces
liquid pints
liquid quarts
milliliters
pecks
centimeters
feet
inches
kilometers
millimeters
statute miles
yards
bushels
cubic feet
cubic inches
cubic yards
gallons
liters
pecks
acres
hectares
square centimeters
square feet
square inches
square yards
meters
inches
inches
millimeters
kilometers
statute miles
centimeters
feet
furlongs
inches
kilometers
meters
rods
yards
square kilometers
square statute miles
acres
hectares
sections
square kilometers
square nautical miles
square rods
grains
cubic inches
gallons
gills (US)
Multiply By
3
404.686
62.726 4
20.116 8
0.01
7.92
0.028 377 59
0.035 314 67
61.023 74
0.001
0.001 307 95
0.1
1.816 166
0.908 082 98
0.264 172 052
8.453 506
33.814 02
2.113 376
1.056 688 2
1,000
0.113 5104
100
3.280 839 895
39.370 079
0.001
1,000
0.000 621 371
1.093 613 298
28.377 59
35.314 666 7
61,023.744
1.307 950 619
264.172 05
1,000
113.510 4
0.000 247 105 38
0.000 1
10,000
10.763 910 4
1,550.003 1
1.195 990 046
0.000 001
0.000 039 4
0.001
0.025 4
1.852 0
1.150 779 4
160,934.4
5.280
8
63,360
1.609 344
1,609.344
320
1,760
3.429 904
1.325
640
258.998 811 033 6
1
2.589 988 110 336
0.755 miles
102,400
0.015 432 358 35
0.061 023 744
0.000 264 17
0.008 453 5
849
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From
milliliters
milliliters
milliliters
milliliters
milliliters
millimeters
minims (US)
minims (US)
minims (US)
minims (US)
minims (US)
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
paces (US)
paces (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pennyweights
pennyweights
pennyweights
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
850
To
liquid ounces
liquid pints
liquid quarts
liters
minims
inches
cubic inches
gills (US)
liquid ounces
milliliters
minims (British)
avoirdupois drams
avoirdupois pounds
grains
grams
kilograms
troy ounces
troy pounds
cubic feet
centiliters
cubic inches
gallons
gills (US)
liquid drams
liquid ounces (British)
liquid pints
liquid quarts
liters
milliliters
minims
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
grams
pennyweights
troy drams
troy pounds
centimeters
inches
bushels
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
liters
pecks (British)
grains
grams
troy ounces
bushels
cubic feet
cubic inches
dekaliters
dry pints (British)
dry quarts
liters
cubic feet
cubic inches
deciliters
gallons
gills (US)
liquid ounces
liquid pints (British)
Multiply By
0.033 814
02
0.002 113
4
0.001 056
7
0.001
16.230 73
0.039 370
078 7
0.003 759
77
0.000 520
83
0.002 083
33
0.061 611
52
1.041
16
0.062 5
437.5
28.349 523 125
0.028 349
523 125
0.911 458
3
0.075 954
86
0.001 044
38
2.957 35
1.804 687
5
0.007 812
5
0.25
8
1.041
0.062 5
0.031 25
0.029 573
53
29.573 529 6
480
17.554 29
1.097 143
0.068 571
43
480
31.103 476 8
20
8
0.083 333
3
76.2
30
0.25
0.311 114
537.605
0.008 809
77
0.011 522
74
0.880 976
75
16
8
8.809 767
5
0.968 9
24
1.555 173
84
0.05
0.015 625
0.019 444
63
33.600 312 5
0.055 061
05
0.968 9
0.5
0.550 610
47
0.016 710
07
28.875
4.731 76
0.125
4
16
0.832 67
WEIGHTS AND MEASURES
Conversion Factors
To Convert From
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
points (typographical)
points (typographical)
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quintals
quintals
quintals
rods
rods
rods
rods, square
rods, square
rods, square
scruples
scruples
scruples
sections (US)
sections (US)
spans
spans
steres
steres
tablespoons
tablespoons
teaspoons
teaspoons
To
liquid quarts
liters
milliliters
minims
inches
millimeters
avoirdupois drams
avoirdupois ounces
grains
grams
kilograms
long tons
metric tons
quintals
short tons
troy ounces
troy pounds
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
grams
kilograms
pennyweights
troy ounces
bushels
cubic feet
cubic inches
dekaliters
dry pints
dry quarts (British)
liters
pecks
pints, dry (US)
cubic feet
cubic inches
deciliters
gallons
gills (US)
liquid ounces
liquid pints (US)
liquid quarts (British)
liters
milliliters
minims
avoirdupois pounds
kilograms
metric tons
feet
meters
yards
acres
square meters
square yards
grains
grams
troy drams
square kilometers
square statute miles
centimeters
inches
cubic meters
cubic yards
milliliters
teaspoons
milliliters
tablespoons
Multiply By
0.5
0.473 176 473
473.176 473
7,680
0.013 837
0.351 459 8
256
16
7,000
453.592 37
0.453 592 37
0.000 446 428 6
0.000 453 592 37
0.004 535 92
0.000 5
14.583 33
1.215 278
210.651 4
13.165 71
0.822 857 1
5,760
373.241 721 6
0.373 241 721 6
240
12
0.031 25
0.038 889 25
67.200 625
0.110 122 1
2
0.968 9
1.101 221
0.125
2
0.033 420 14
57.75
9.463 53
0.25
8
32
2
0.832 67
0.946 352 946
946.352 946
15,360
220.462 26
100
0.1
16.5
5.029 2
5.5
0.006 25
25.292 85
30.25
20
1.295 978 2
0.333
2.589 988 1
1
22.86
9
1
1.307 95
14.786 76
3
4.928 922
0.333 333
851
THE CIA WORLD FACTBOOK
Conversion Factors
To Convert From
TO
Multiply By
ton-miles, long
metric ton-kilometers
1.635 169
ton-miles, short
metric ton-kilometers
1.459 972
tons, gross register
cubic feet of permanently enclosed space
100
tons, gross register
cubic meters of permanently enclosed space
2.831 684 7
tons, long (deadweight)
avoirdupois ounces
35,840
tons, long (deadweight)
avoirdupois pounds
2,240
tons, long (deadweight)
kilograms
1,016.046 909 8
tons, long (deadweight)
long hundredweights
20
tons, long (deadweight)
metric tons
1.016 046 908 8
tons, long (deadweight)
short hundredweights
22.4
tons, long (deadweight)
short tons
1.12
tons, metric
avoirdupois pounds
2,204.623
tons, metric
kilograms
1,000
tons, metric
long hundredweights
19.684 130 3
tons, metric
long tons
0.984 206 5
tons, metric
quintals
10
tons, metric
short hundredweights
22.046 23
tons, metric
short tons
1.102 311 3
tons, metric
troy ounces
32,150.75
tons, net register
cubic feet of permanently enclosed space
for cargo and passengers
100
tons, net register
cubic meters of permanently enclosed space
for cargo and passengers
2.831 684 7
tons, shipping
cubic feet of permanendy enclosed cargo space
42
tons, shipping
cubic meters of permanently enclosed cargo space
1.189 307 574
tons, short
avoirdupois pounds
2,000
tons, short
kilograms
907.184 74
tons, short
long hundredweights
17.857 14
tons, short
long tons
0.892 857 1
tons, short
metric tons
0.907 184 74
tons, short
short hundredweights
20
townships (US)
sections
36
townships (US)
square kilometers
93.239 572
townships (US)
square statute miles
36
miles, square statute
acres
640
miles, square statute
hectares
258.998 811 033 6
miles, square statute
square feet
27,878,400
miles, square statute
square meters
2,589,988.110 336
miles, square statute
square yards
3,097,600
yards
centimeters
91.44
yards
feet
3
yards
inches
36
yards
meters
0.914 4
yards
miles
0.000 568 18
yards, cubic
bushels
21.696 227
yards, cubic
cubic feet
27
yards, cubic
cubic inches
46,656
yards, cubic
cubic meters
0.764 554 857 984
yards, cubic
gallons
201.974 0
yards,, cubic
liters
764.554 857 984
yards, cubic
pecks
86.784 91
yards, square
acres
0.000 206 611 6
yards, square
hectares
0.000 083 612 736
yards, square
square centimeters
8,361.273 6
yards, square
square feet
9
yards, square
square inches
1,296
yards, square
square meters
0.836 127 36
yards, square
square miles
0.000 000 322 830
852
REFERENCE MAPS
AFRICA
Minsk
.X'' Amste^Esfn Berlin )
" /tiggflEJ * ;
'' Brussels* ^ GERMANY^i^
* . * f * **4™ Pfa^.,
X ; Paris /
\\ I StOTf^BcrtCX AU&-
j, / FRANCE
*'' ITALY SarSffl^Sii?^
Barcelona^.'' c„*» i''| Robtft
Madrid ,-j Tirana*
s. . 2y« - . ^
• { & ''"'''' l „ ■{ Sardinia
r''l Algiers Tunis C
RUSSIA''','8d2f13a8381fa18e9efa59b2fb48f48c0188d69181c1e5f88cb2b4b701462ce8','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('928341b420a003fb9df27d46c6991f592b14a6d7022b44fbcb7f9d8b2ba9c534',2010,'TJ','Tajikistan','environment',1748,'TI
TJ
TJK
762
TJK
•tj
Tanzania
TZ
TZ
TZA
834
TZA
.tz
38 35 N
68 48 E
Netherlands Antilles
12 10 N
68 30 W
39 00 N
71 00 E','aea7f7f0b4d25f46d2139fb9dbddd584638c33e57123874e69f5d03662f0331b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fbf6d7cf7f774aa61be529ae567e04aad3b9effa2d802fdcd5e0a7e0a667722',2010,'TH','Thailand','environment',1749,'TH
TH
THA
764
THA
.th
13 45 N
100 31 E
Bangui (capital)
15 00 N
100 00 E
15 00 N
Russia
60 00 N
Pacific Ocean
4 50 N
7 12 N
Adantic Ocean
55 50 N
Atlantic Ocean
30 00 S
Pacific Ocean
10 00 N
South Georgia and the South
54 15 S
Sandwich Islands','f2dd8ca709bd9e881fe43954d97a93b61d7ffb7b36b74df3d0c9079387dea10d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb04ba92fde2cd1b963683c9c86777eeecd626e56555f05a0b266f2ab7b4c3de',2010,'TL','Timor-Leste','environment',1750,'TT
TL
TLS
626
TLS
.d
8 35 S
125 36 E
9 00 S
126 00 E
9 00 N
126 00 E
Pacific Ocean
11 00 S
128 00 E','48200171b29402744ea58dbfc9e66d1b7d0ad6e7f97ffe4c492ae1bb6876f281','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82c4ba20cc40abc0672c5bc5eaa264bcaa35af0a77ec8aa8da9a2640c7cf9a6a',2010,'TG','Togo','environment',1751,'TO
TG
TGO
768
TGO
•tg
8 00 N
1 10E
Guadeloupe, Martinique
16 30 N
62 00 W
6 08 N
1 13 E
8 00 N
1 10 E
United States (Alaska)
55 35 N
131 06 W','bda3b644e68b69075dcd4a7f80d57a30be9e85ef9f684f54ed63bdb6bf3d0fa3','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e70cad4481e300fa254d3501e98be709e64ef7ba4cedd30a7171999e3c9478',2010,'TO','Tonga','environment',1752,'TN
TO
TON
776
TON
.to
20 00 S
175 00 W
Denmark, Germany,
53 35 N
6 40 E
19 42 S
174 29 W
Habomai Islands
Russia (de facto)
43 30 N
146 10 E
Hadhramauf (region)
21 08 S
175 12 W','ddf04e72019fce3e4c8210f7fc9b0d23f1256347fdafd69884fe6b6df3afc438','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31797b46079c00448dec0474ffe1eac66dd9fb45200c7f447cebdba84a4f18f7',2010,'TT','Trinidad and Tobago','environment',1753,'TD
TT
TTO
780
TTO
.tt
813
THE CIA WORLD FACTBOOK
STANA6-
Entity
FIPS 10
ISO 3166
1059
Internet
Comment
Tromelin Island
TE
*
*
*
administered as part of French
10 39 N
61 31 W
11 15 N
60 40 W
10 22 N
61 15 W','9d99b724c6baba94b1059798012e50e25d7bca7bfd595c74e4f15cc1796e1854','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3617d52b74899e8da35f2a37a8f961fd03a3d8da3500e773f216e9dca97f6386',2010,'TN','Tunisia','environment',1754,'TS
TN
TUN
788
J
«
i
TUN
.tn
Southern and Antarctic Lands; no ISO
codes assigned
Turkey
TU
TR
TUR
792
TUR
.tr
36 48 N
10 11 E','70fdd2972f4f2fe1ce37b5e4951d4a6c3e43d8929c67457c84bc3abb5d39b405','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61495c62b849d5a0e73f5662ce9151f09d0d77056bc63102779fc0508df4af34',2010,'TM','Turkmenistan','environment',1755,'TX
TM
TKM
795
TKM
.tm
37 57 N
58 23 E
40 00 N
60 00 E
Atlantic Ocean
21 40 N
71 00 W
1 Ttirkmenaba*
GARAGUM
g Ashgabat ^Mary
(lowest point in
Europe, -26 m)
Bat''umi,
Sarasun
rrabzon*
°4«i4SI
Sumqayit
Yerevan
- Mashhad*
Nicosia','20802bccd27277df8862bffd47f3b81e705dac60fbefe54ddaf0fec9e3c81173','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6700e0eb701f354f6eb6afcb86a39527aeb8b683b5d4bc2c8e2886bc8cd215f',2010,'TC','Turks and Caicos Islands','environment',1756,'TK
TC
TCA
796
TCA
.tc
21 56 N
71 58 W
21 28 N
71 08 W
Indian Ocean
35 00 S
130 00 E
Adantic Ocean
55 30 N
11 00 E','db2ecdb7cb5e0e3bbc107c10740ba6df3205d93c8ef84845455f98b12f0da613','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('790a792769ec4719ed00df0ddce64889dfd404b2c0db8cf3ebf1235451fdf280',2010,'TV','Tuvalu','environment',1757,'TV
TV
TUV
798
TUV
.tv
8 00 S
178 00 E
8 30 S
179 12 E
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakh¬
stan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Taiwan
23 30 N
121 00 E
Pacific Ocean
24 00 N
119 00 E
8 30 S
179 12 E
825
Name
THE CIA WORLD FACTBOOK
Fundy, Bay of
Futuna Islands (Hoorn Islands/lles de Horne)
Fyn (island)
Gaborone (capital)
Galapagos Islands (Archipielago de Colon)
Galicia (region)
Galicia (region)
Galilee (region)
Galleons Passage
Gambier Islands (lies Gambier)
Gaspar Strait
Gdansk (city; formerly Danzig)
Geneva (city)
Genoa (city)
George Town (capital)
George Town (city)
George Town (city)
Georgetown (capital)
Georgetown (city)
German Democratic Republic (East Germany; former name
for eastern portion of Germany)
German Southwest Africa (former name for Namibia)
Germany, Federal Republic of
Gibraltar (city, peninsula)
Gibraltar, Strait of
Gidi Pass
Gilbert Islands
Goa (state)
Gobi (desert)
Godthab (capital; also Nuuk)
Golan Heights (region)
Gold Coast (former name for Ghana)
Golfo San Jorge (gulf)
Golfo San Mafias (gulf)
Good Hope, Cape of
Goteborg (city)
Gotland (island)
Gough Island
Graham Land (region)
Gran Chaco (region)
Grand Bahama (island)
Grand Banks (fishing ground)
Grand Cayman (island)
Grand Turk (capital; also Cockburn Town)
Great Australian Bight
Great Belt (strait; also Store Baelt)
Great Bitter Lake
Great Britain (island)
Great Channel
Great Inagua (island)
Great Rift Valley
Greater Sunda Islands
Green Islands
Greenland Sea
Grenadines, Northern (island group)
Grenadines, Southern (island group)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Atlantic Ocean
45 00 N
66 00 W','18da017426c800600438373259da9a68f41ed0f179ca2387d289b55413829465','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('661f6ef9be176566863869d208ee0f9c97f73280e06066b6e618bc4aeb93a31c',2010,'UA','Ukraine','environment',1758,'UP
UA
UKR
804
UKR
.ua
48 22 N
23 32 E
Pacific Ocean
14 00 S
139 00 E
45 00 N
34 00 E
45 00 N
34 00 E
Adantic Ocean
22 55 N
74 35 W
French Southern and Antarctic
46 30 S
51 00 E
Lands
50 26 N
30 31 E
Kigali (capital)
50 26 N
30 31 E
48 22 N
23 32 E
48 22 N
23 32 E
49 00 N
32 00 E
Tashkent
te Berlin
GERMANY*
ARCTIC REGION
Okhotsk
! * * Rankin Inlet Kc^lot
90 W . - . . ♦— ----- i . fe-te ! . vbksc31-
Scale 1:39,000,000/
Azimuthal Equal-Area Projection
Kharkiv/ #-
l, Rostov-
855
THE CIA WORLD FACTBOOK
-X‘.K. ,A-“
^ {OnIo s'' l ’ ~" A
* f/'' SWEDEN
r>A->4< '' '' :
^ogcnbagcn . , t/, , !j/ '' ;''Tt% / / /
W-fr Stockholm . y \\ ^ / mw W”€B / «- ^
h rm ucm,.''.^Mwy^ KJU w»
%W*Heb,"kl'' ^ \\ fr/
m.x> .4 fi pXjP ° \\
4A /
•/ • :^ -‘ • x " s /•• '' ; yx /
{Minsky .?y \\y A-- ■ ''
BELA. /
<Yj^ Moscow ,
UKK. ''.’ y
£ -Wronezi _ „ , _ _
Kharkiv * - Perife
nniwftfk ''•/ /Yckaiertrtbufj
wD0n«sk Satatov^ , , Ufa * l
J '' Samara • V/ Chclvv)bmsk %
v? ■
O / ,> >--
,;: mfgfan
Svalbard ^
irfORWAY- m
-"""" '' ^ / 1 \\ \\ X “too:
y </ > ! 14L
x / mo ioo -f \\
'' \\ yi''RANZKKit/ ! j y
''\\ yffl.W’Z tOStcy / | ''-s
>X «*. w*f/ Arctic Ocean **
/ vtiH< / 1
ti,
Xy .
| \\ /iSbenMs
/ jM Stvpwk,'' X* «c
/ •''W»« x x
/■-FT ,A(: s
~~-- . mt |FUS''
Wiangc! V1 ..A ,! ,.. Aswiiienlya
Island / " ''''"■■» /i
/
4 / ",
c, yX-
k//k¥/
.4 -J1 , ■•
» i
\\ icr^&^yrJ ; ?v,/
,r^ %M \\ ,(\\ < ^ '' / /*c
/ . ;vj
\\ ; , ■ > V / «
/\\faha(y Novgor^
*, i ''■< 4.V,
KV J^V Vol^ogr^''
Vfv^%«w f ■>
‘ / A/
f>
A%>
“0-.fTJ>tW:- , / ^ /
A- •''. 1/jjjjLt .'' y§£V ''•■ v, "''-W,-
<.'' <Y!/ nf
}W<
en^aapf
^Philippine :
<IMDIA)
\\ y <: ^ Chennai
Cochin!
\\ f
^ f 1 SRI LANKA
A. UK'' »- *»
ANDAMAN
ISLANDS
HOWAl |
rA,
WW®*11®1 L T .waas*
V \\ " ''/ T i . A ~ ‘ 4 « i y
<\\ ‘M X .T^jy. S Siwty; , #; CA v»
>H-v pgypif. ''S[A,V,)S v y //J.. €,
MAI ,M„PC X C«|«4#
MALDIVLS//#
|ff Male I
cs*
<a
m&8M
ISLANPS
m&tA*
''f|w.
-t:
Scale 1:48,000,000
rJmuthal Equal-Area Projection
SO0 KItometcrs
I • .
SW Miles
Btsii ikary''ri? pwse nfati an is
not necessarily authoritative
_ _ _ (~<;tiaiOi
I n <i i a n ''
O c e a n
%
ISLANDS .''. 1 '' / ; ,-''»A:i<ai4t»%>
:;r '' - yi.^r
CUv , •• ^
Bandar Seri/.'' Ta».v ^
BeSawany 1 '' #
\\caebesse* J ^
i ■ MALAYSIA ■ . ;;/ /< i
\\^Ciii|la Lumpur '' , MALAYSIA ''//$
J$P*"
X/ l IS D O N i-. -S 1
i (akarta J,< , i
lava
A
^pHnflOK LES1
p Tbw *
t
I
A fit''
: AUSTRAL!.
856
REFERENCE MAPS
CENTRAL AMERICA AND THE CARIBBEAN
857
THE CIA WORLD FACTBOOK
EUROPE
^reenwTOi;. py "''■’SH }
■ (DENMARK! Jb*
m /
/
Green lane
Strati ^ l
A fir ^ /
Xif. flflin " >i
Reykjavi|: j€iLAWjD^
Jan Mayen
(NORWAY)
Nt>rvve£J4fH sct
>. a r?i^
Uammoriesx^i ''hi w . $/
0 $ - '', 1 /
Sf$0, \\
*w
/
Ipfr
V , ?,
kf
Jgl
t7 > m
:\\ M
- P
Torshavn
Rockall
(fift.L
M <j r t h
A t 1 a rt t i
c e a ii
Murmansk
, ,,, , M V
^ ^ , - ;A, . yr \\f
. T:
\\ ''XAp
C Arkhangel’sl
C; > ''
■ py-kP
vr:
- *Krakbw {
*L''viv
Vinnytsya
Guernsey (U.K.), '' r-4l t U»n y? V • ''
k,stv;N'' '' D*.;urxemW«rg L CZECH HEPUBOtyAA-^ c 4 '' Chernivts.^ MykoMy,J
(. I p..., Paris lux.''v "% '' Brno* ;'' SLOVAKIA “> .> '' " J
” I ^ , "7 .Stuttgart. Bratislava Ch’™ f
HB ; Strasbourg* .- Munich , • * ^ -Rm^Wc# ''''" Clui-M «*?''* '' MA>|odes
» ;p Mantes . \\ f{ • Vienna JN~-^j*u?ap«St • NaSca -♦''•• - MOLDOVA ?
^ . k ^-^l^-.,kPP AUSTRIA '' / * *, \\/ ‘
Zurkb* 4vU, 9 HUfiOAFCy A *
s ^ '' p''y./w:''''v<-P-«F •- v 1 l.f ROMANIA •
Aty Of
; A i5Cy!y
I
fRAMCE
''•* k»-.„
tk
M
|AZ:
J££ FS3 s»i CROATIA yc SERBIA /
^ BULGARIA
: y/ff P®
A • ''-• -.'', '' : !;
BOrtk-'' yl...
~40, /./ PP
1 * SPAIM '' Valencia^"
/ * Bordeaux
-r^-v. Bilbao / / | . M 7 %*U^~ > ’ nSrtao
- -• . < , ! .Toulouse HGNA^j^r ^
Andorra, ^ \\r* '' T i^drenrtr
la VelfakMarseille^t^y V p __AL
Zaragoza# I "
iMiK. ,
>y, P''*"'' Bucharest ’> /Constanta
"} ■/ -4r /''" \\ *.
Bud
< ''., ,,*t / Varna
Barcelona
v^.<v < r ^
Napie^*rJ fe -/X
i .''-- ;, /Xity X
r''~''y'', Ceuta I ;
/ ; yiSPAiM >LC: f
/ A Mellila °^5-vF/
/ / .
'' * '' k / ■-■ \\"> k ''
*< * y ,■»’''} ''v i
’Casablanca > <
• M, mUtK... Adttk Podgorfet^ TS4 Skopje ■
f> ilk v * "*■■'' *■■ -
yy kP^x/X
jLX
IstanbuU
</Vy ■ ''
-Sj
■* '' • ? Tirani*
A »•■
vfi
vl,/
■ BALEARIC
ISLANDS
Mediterranean Sea
I ■ x '' <
■ -V-..
I<?m<m 1 j
.Sea I ■
■\\ T£,.
I ?^ySP|fe!SsrC^
k sr
Atwan .
% kp CLy,,. ...
0> •-
^ iSm
Z p v *
MOROCCO k
p ^ /...
* - Rhodes u
4 ^kj# Scale I: 19,500,000 ^ A
*•*'' -A^k" - V''« i jk Lambert Conformal Conic Projection,
Valletta* standard parallels 40’\\’ and 56 ’N
Ad '' r I ,// k MAI TA <5 300 Kilometers
ALGERIA- kfi: ; ? ™M,S,V • !"■'' . " . ; . ■}
4* '' '' ''• • •• ''if ^ 4f''» &c''tnt<5Afy rvp»eNf*tk>t>un ts n<k
''• -.• . ..--.tr:-:v GsifLy?:
858
REFERENCE MAPS
ut''K- '' . Krasnodar
*
Sevastopol''
-v, ’Constanta
/Varna
Gora B’brus
c<sGrozr,yy
Sokhumi*
- Dasoguz >
>
i A .','7044b0df13b4d348475c82616d7b5b4212e47254924b1faf836503f5152d4037','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8659391d683107ec21f4f7890e108043b032d4658b74945954b1e37f3d3a3c96',2010,'AE','United Arab Emirates','environment',1759,'AE
AE
ARE
784
ARE
.ae
24 28 N
54 22 E
Abu Musa (island)
Iran
25 52 N
55 03 E
Abuja (capital)
24 00 N
54 00 E
United Arab Emirates)
Al Iraq (local name for Iraq)
25 18 N
55 18 E
24 00 N
54 00 E
Russia (de facto)
44 55 N
147 40 E
24 00 N
54 00 E
24 00 N
54 00 E
24 00 N
54 00 E
Federated States of Micronesia
7 25 N
151 47 E
Pacific Ocean
41 35 N
141 00 E','f8d80815e4f4fc848048605e6bfc49293af9aa8777c5a7fac0c532daae990bb4','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcbee1c2b6e9c9cb30086a790cd83059c686a62b164589908cbd9fa57492d1d3',2010,'GB','United Kingdom','environment',1760,'UK
GB
GBR
826
GBR
.uk
54 36 N
5 55 W
Democratic Republic of the
0 00 N
25 00 E
49 52 N
6 27 W
54 00 N
2 00 W
55 57 N
3 11 W
52 30 N
1 30 W
Adantic Ocean
50 20 N
1 00 w
54 00 N
2 00 W
Indian Ocean
6 25 N
94 20 E
The Bahamas
21 00 N
73 20 W
Ethiopia, Kenya
0 30 N
36 00 E
Brunei, Indonesia, Malaysia
2 00 S
110 00 E
56 30 N
6 20 W
China v
42 00 N
113 00 E
51 30 N
0 10 w
Svalbard
78 13 N
15 33 E
54 40 N
6 45 W
59 00 N
3 00 W
834
Name
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Osaka (city)
Oslo (capital)
Osumi Strait (Van Diemen Strait)
Otranto, Strait of
Ottawa (capital)
Ouagadougou (capital)
Outer Hebrides (islands)
Outer Mongolia (region)
Pyongyang (capital)
Pacific Islands, Trust Territory of the (former name
of a large area of the western North
Pacific Ocean)
Pagan (island)
Pago Pago (capital)
Palawan (island)
Palermo (city)
Palestine (region)
Palikir (capital)
Palk Strait
Pamirs (mountains)
Pampas (region)
Panama (capital)
Panama Canal
Panama, Gulf of
Panay (island)
Pantelleria, Isola di (island)
Papeete (capital)
Paramaribo (capital)
Parece Vela (island)
Paris (capital)
Pascua, isla de (Easter Island)
Pashtunistan (region)
Passion, lie de la (island)
Patagonia (region)
Peking (see Beijing)
Pelagian Islands (Isole Pelagie)
Peleliu (Beliliou) (island)
Peloponnese (peninsula)
Pemba Island
Penang Island
Pentland Firth (channel)
Perim (island)
Perouse Strait, La
Persia (former name for Iran)
Persian Gulf
Perth (city)
Pescadores (islands)
Peshawar (city)
Peter I Island
Petrograd (city; former name for Saint Petersburg)
Philip Island
Philippine Sea
Phnom Penh (capital)
Phoenix Islands
Pinatubo, Mount (volcano)
Pines, Isle of (island; former name for Isla de la Juventud)
Pleasant Island
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)
57 45 N
7 00 W
57 35 N
13 48 W
57 00 N
4 00 W
60 30 N
52 30 N
3 30 W','04743ad8ee50a4a274b17b936e2a338f8a2fc13354c4ffd0cc2b58dd53f5b26b','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ae1570cd04d26efd6f714dc6a522939c29528e7974cc4cabbe3f1f3524cd5b8',2010,'UY','Uruguay','environment',1761,'UY
UY
URY
858
URY
•uy
Island, Jarvis Island, Johnston Atoll,
Kingman Reef, Midway Islands,
Navas sa Island, Palmyra Atoll, Wake
Island
34 53 S
56 11 W','a47e8eae5151440b126660b901883b52189387ff77edd1b9b3ef608792c5f38d','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bc8477a02af88cb81813be83a23f46b778a9e9b4aae5f215210d4fe073f92b1',2010,'VU','Vanuatu','environment',1762,'NH
VU
VUT
548
VUT
.VU
Venezuela
VE
VE
VEN
862
VEN
.ve
Vietnam
VM
VN
VNM
704
VNM
.vn
Virgin Islands
VQ
VI
VIR
850
VIR
.vi
Virgin Islands (UK)
-
-
-
-
-
•vg
see British Virgin Islands
Virgin Islands (US)
-
-
-
-
-
.vi
see Virgin Islands
Wake Island
WQ
-
-
-
UMI
-
ISO includes with the US Minor
14 00 S
167 30 E
Barbuda (island)
16 00 S
167 00 E
16 00 S
167 00 E
Russia
74 00 N
57 00 E
Egypt, Sudan
20 30 N
33 00 E
17 44 S
168 19 E
Haiti v v
18 32 N
72 20 W','f55343a04e091ac0d9d1bf32db0b0c72a39689dfb1dd52e7c1d8cdd03d83d8c7','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3621dc35dd5b815175e2f9154b4703e2948ef78930fa80bea018d4582db185a3',2010,'EH','Western Sahara','environment',1763,'WI
EH
ESH
732
ESH
.eh
Territory
Western Samoa
-
-
-
-
-
.ws
see Samoa
World
-
-
-
-
-
••
the Factbook uses the W data code
23 45 N
15 45 W
Atlantic Ocean
35 00 S
59 00 W
24 30 N
13 00 W
Burkina Faso, Chad, The
15 00 N
8 00 W
Gambia, Guinea- Bissau,
Mali, Mauritania, Niger,
24 30 N
13 00 W
Morocco, Western Sahara
25 00 N
13 00 W','cf1e66a57099b749aaadc475171b59e0ad9a79a6ed4c483513b06e363f1f4f30','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87120c1db3d00dbab95a160fa26763b7d40befbd9ef2c8f52f18a151f69bccd5',2010,'CG','Congo','environment',1764,'Turkey
41 01 N
28 58 E
Pacific Ocean
41 15 S
174 30 E
10 00S
26 00 E
Kathmandu (capital)
4 18 S
15 18 E
Kipros (Greek local name for Cyprus)
Heard Island and McDonald
53 00 S
Islands
South Georgia and the South
53 33 S
Sandwich Islands
Pacific Ocean
54 00 N
142 00 E
Pacific Ocean
60 00 N
157 30 E
C|jOAf1DA^ £
Kisangani KENYA'' { y
~j ~ ** Nairobi i
. HWANDAi''rSSX> . * ML Kilimani
Sukavu*: ?/ V-y tn&iest point,
sQo X
. ?f* BURUNDI yTMombasa
a \\U , Dodoma//!
, • c, Zanzibar
t«yi X TANZANIA Dares
v viSalaam
SAO TOMf.
AND PRftK t!T dt,
Sdo lomi
W,< Lulsumbashi f i L 4 '' .Moroni . _ .Ciortoso IsLuxI#
^w, MALA^X^''^ ; *, " (HLANCE!
Kitwe^Julon^vwl chtafcj Xl
ZAMBIA ^ . deNaca^lc^-d^^ows^ .
LusakaX "fcacr^ \\
Jf* X ''SM -1 IFRANCC! )
X"”*''* j Mozambique'' ( »•"*"«
. X ZIMBABWE I . »:4ira '' " I!,i'' ''C;h . ^ Atitananarivo
aianaL / i ness- -T’” .sXH''nist
ARI ,-/ • . f i.auopaf MADAGASCAR *«,
2Z .y \\ a triwricr.) , ,stand t . 1/ OTtAl
1./ \\ . 1 . trmKxf . . 7 . . ■
W'' ITvnloei a I
AriQOL^
Port
Louis
-<gr ?o
ITpbtin’
."•LRE. *
AZORES
iPOBTOGAL)
Ponta
Delgada
AFQ
c CAPE VERDE
Nou«i4h ibou g~"~~
'' MAURITANIA
* Nouakchott
Sr3U Dakar
; ★ SENEOAl
rmcfiSSiS L suy/''.HW''jTJ
“"SC?''"’--''-;* X
“-irf Hj/Sn ! niQEWA
Freetown df X ^ Cf)TE jis, •*• Abuja ''’" f''C. \\ Moundou
SIERRA LEONf. X W OWOtRE /,;:
Monrovia ★ ! ^
X
Sanaa #
> pjibouii
r D.IIBOUT1 '' X
Mogadishu
IBQUA. GUI.)
Ascension
, (St. Helena)
Polnte','6e22020b901e254e70a01c8a9c43e8451b757aa11423b0d00ae1318ab1984d81','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654111e3d31d829b8c5d578888424982dd9d77e76e1cfe0123e5d8ebc12a22af',2010,'KR','Korea, Republic of','environment',1765,'Koror (capital)
Kosovo (region)
Kosrae (island)
Kowloon (city)
Kra, isthmus of
Krakatoa (volcano)
Krakow (city)
Kuala Lumpur (capital)
Kunashiri (island; also Kunashir)
Kunlun Mountains
Kuril Islands
Kuwait (capital)
Kuznetsk Basin
Kwajalein Atoll
Kyiv (capital)
Kyushu (island)
La Paz (administrative capital)
La Perouse Strait
Labrador (peninsula, region)
Labrador Sea
Laccadive Islands
Laccadive Sea
Lagos (former capifal)
Lahore (city)
Lake Erie
Lake Huron
Lake Michigan
Lake Ontario
Lake Superior
Lakshadweep (Laccadive Islands)
Lantau Island
Lao (local name for Laos)
Laptev Sea
Las Palmas (city)
Latakia (region)
Latvija (local name for Latvia)
Lau Group (island group)
Lefkosa (see Nicosia)
Leipzig (city)
Lemnos (island)
Leningrad (city; former name for Saint Petersburg)
Lesser Sunda Islands
Lesvos (island)
Leyte (island)
Liancourt Rocks (claimed by Japan)
Liaodong Wan (gulf)
Liban (local name for Lebanon)
Libreville (capital)
Lietuva (local name for Lithuania)
Ligurian Sea','1f7ae931a077c3bac0ccc297e0957d73b69fe997f5bddf6bef387497d2e999e2','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aecee0256294e1b309c6a55f2a0f810bb73d7ea44730a8a6a8d389c1d600221',2010,'MO','Macao','environment',1766,'Macau (special administrative region)
Macquarie Island
Madagasikara (local name for Madagascar)
Maddalena, Isola
Madeira Islands
Madras (city; see Chennai)
Madrid (capital)
Magellan, Strait of
Maghreb (region)
Magreb (local name for Morocco)
Magyarorszag (local name for Hungary)
Mahe Island
Maiz, Islas del (Corn Islands)
Majorca Island (Isla de Mallorca)
Majuro (capital)
Makassar Strait
Makedonija (local name for Macedonia)
Malabo (capital)
Malacca, Strait of
Malagasy Republic
Malay Archipelago
Malay Peninsula
Male (capital)
Mallorca, Isla de (island; also Majorca)
Entry in
The World Factbook
Latitude
(deg min)
Longitude
(deg min)','2cab5954010d8a7388ecb4e50db2668a2e0a16c4af8b8754c81e29278c9c72b6','internet-archive','ciaworldfactbook0000unit','txt','687a09ccfcd530de1484a703fc4bf8541c816f69d4a732fbcebc7771d3c95947','https://archive.org/download/ciaworldfactbook0000unit/ciaworldfactbook0000unit_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199d291f7ba5205f337221810bcbb919c7c068f96cb58baff03b04180efcdc4e',2010,'TG','Togo','environment',78,'Geography ::Canada
Location:
Northern North America, bordering the North Atlantic Ocean on the
east, North Pacific Ocean on the west, and the Arctic Ocean on the
north, north of the conterminous US
Geographic coordinates:
60 00 N, 95 00 W
Map references:
North America
Area:
total: 9,984,670 sq km
country comparison to the world: 2
land: 9,093,507 sq km
water: 891,163 sq km
Area - comparative:
slightly larger than the US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km with Alaska)
Coastline:
202,080 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the continental margin
Climate:
varies from temperate in south to subarctic and arctic in north
Terrain:
mostly plains with mountains in west and lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,959 m
Natural resources:
iron ore, nickel, zinc, copper, gold, lead, rare earth elements,
molybdenum, potash, diamonds, silver, fish, timber, wildlife, coal,
petroleum, natural gas, hydropower
Land use:
arable land: 4.57%
permanent crops: 0.65%
other: 94.78% (2005)
Irrigated land:
7,850 sq km (2003)
Total renewable water resources:
3,300 cu km (1985)
Freshwater withdrawal (domestic/industrial/agricultural):
total: 44.72 cu km/yr (20%/69%/12%)
per capita: 1,386 cu m/yr (1996)
Natural hazards:
continuous permafrost in north is a serious obstacle to development;
cyclonic storms form east of the Rocky Mountains, a result of the
mixing of air masses from the Arctic, Pacific, and North American
interior, and produce most of the country''s rain and snow east of
the mountains
volcanism: the vast majority of volcanoes in Western Canada''s Coast
Mountains remain dormant
Environment - current issues:
air pollution and resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning utilities, and
vehicle emissions impacting on agricultural and forest productivity;
ocean waters becoming contaminated due to agricultural, industrial,
mining, and forestry activities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Marine Life Conservation
Geography - note:
second-largest country in world (after Russia); strategic location
between Russia and US via north polar route; approximately 90% of
the population is concentrated within 160 km of the US border
People ::Canada
Population:
33,759,742 (July 2010 est.)
country comparison to the world: 36
Age structure:
0-14 years: 16.1% (male 2,761,711/female 2,626,836)
15-64 years: 68.7% (male 11,633,950/female 11,381,735)
65 years and over: 15.2% (male 2,220,189/female 2,862,787) (2010
est.)
Median age:
total: 40.7 years
male: 39.6 years
female: 41.8 years (2010 est.)
Population growth rate:
0.804% (2010 est.)
country comparison to the world: 138
Birth rate:
10.28 births/1,000 population (2010 est.)
country comparison to the world: 190
Death rate:
7.87 deaths/1,000 population (July 2010 est.)
country comparison to the world: 109
Net migration rate:
5.64 migrant(s)/1,000 population (2010 est.)
country comparison to the world: 15
Urbanization:
urban population: 80% of total population (2008)
rate of urbanization: 1% annual rate of change (2005-10 est.)
Sex ratio:
at birth: 1.056 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.98 male(s)/female (2010 est.)
Infant mortality rate:
total: 4.99 deaths/1,000 live births
country comparison to the world: 186
male: 5.34 deaths/1,000 live births
female: 4.63 deaths/1,000 live births (2010 est.)
Life expectancy at birth:
total population: 81.29 years
country comparison to the world: 10
male: 78.72 years
female: 84 years (2010 est.)
Total fertility rate:
1.58 children born/woman (2010 est.)
country comparison to the world: 179
HIV/AIDS - adult prevalence rate:
0.4% (2007 est.)
country comparison to the world: 80
HIV/AIDS - people living with HIV/AIDS:
73,000 (2007 est.)
country comparison to the world: 55
HIV/AIDS - deaths:
fewer than 500 (2007 est.)
country comparison to the world: 83
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups:
British Isles origin 28%, French origin 23%, other European 15%,
Amerindian 2%, other, mostly Asian, African, Arab 6%, mixed
background 26%
Religions:
Roman Catholic 42.6%, Protestant 23.3% (including United Church
9.5%, Anglican 6.8%, Baptist 2.4%, Lutheran 2%), other Christian
4.4%, Muslim 1.9%, other and unspecified 11.8%, none 16% (2001
census)
Languages:
English (official) 58.8%, French (official) 21.6%, other 19.6% (2006
Census)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
School life expectancy (primary to tertiary education):
total: 17 years
male: 17 years
female: 17 years (2004)
Education expenditures:
4.9% of GDP (2007)
country comparison to the world: 75
Government ::Canada
Country name:
conventional long form: none
conventional short form: Canada
Government type:
a parliamentary democracy, a federation, and a constitutional
monarchy
Capital:
name: Ottawa
geographic coordinates: 45 25 N, 75 42 W
time difference: UTC-5 (same time as Washington, DC during Standard
Time)
daylight saving time: +1hr, begins second Sunday in March; ends
first Sunday in November
note: Canada is divided into six time zones
Administrative divisions:
10 provinces and 3 territories*; Alberta, British Columbia,
Manitoba, New Brunswick, Newfoundland and Labrador, Northwest
Territories*, Nova Scotia, Nunavut*, Ontario, Prince Edward Island,
Quebec, Saskatchewan, Yukon Territory*
Independence:
1 July 1867 (union of British North American colonies); 11 December
1931 (recognized by UK)
National holiday:
Canada Day, 1 July (1867)
Constitution:
made up of unwritten and written acts, customs, judicial decisions,
and traditions; the written part of the constitution consists of the
Constitution Act of 29 March 1867, which created a federation of
four provinces, and the Constitution Act of 17 April 1982, which
transferred formal control over the constitution from Britain to
Canada, and added a Canadian Charter of Rights and Freedoms as well
as procedures for constitutional amendments
Legal system:
based on English common law, except in Quebec, where civil law
system based on French law prevails; accepts compulsory ICJ
jurisdiction with reservations
Suffrage:
18 years of age; universal
Executive branch:
head of state: Queen ELIZABETH II (since 6 February 1952);
represented by Governor General David JOHNSTON (since 1 October 2010)
head of government: Prime Minister Stephen Joseph HARPER (since 6
February 2006)
cabinet: Federal Ministry chosen by the prime minister usually from
among the members of his own party sitting in Parliament
(For more information visit the World Leaders website )
elections: the monarchy is hereditary; governor general appointed by
the monarch on the advice of the prime minister for a five-year
term; following legislative elections, the leader of the majority
party or the leader of the majority coalition in the House of
Commons generally designated prime minister by the governor general
Legislative branch:
bicameral Parliament or Parlement consists of the Senate or Senat
(105 seats; members appointed by the governor general on the advice
of the prime minister and serve until 75 years of age) and the House
of Commons or Chambre des Communes (308 seats; members elected by
direct, popular vote to serve a maximum of five-year terms)
elections: House of Commons - last held on 14 October 2008 (next to
be held no later than 15 October 2012)
election results: House of Commons - percent of vote by party -
Conservative Party 37.6%, Liberal Party 26.2%, New Democratic Party
18.2%, Bloc Quebecois 10%, Greens 6.8%, other 1%; seats by party -
Conservative Party 145, Liberal Party 77, New Democratic Party 37,
Bloc Quebecois 48, other 1
Judicial branch:
Supreme Court of Canada (judges are appointed by the prime minister
through the governor general); Federal Court of Canada; Federal
Court of Appeal; Provincial Courts (these are named variously Court
of Appeal, Court of Queen''s Bench, Superior Court, Supreme Court,
and Court of Justice)
Political parties and leaders:
Bloc Quebecois [Gilles DUCEPPE]; Conservative Party of Canada
[Stephen HARPER] (a merger of the Canadian Alliance and the
Progressive Conservative Party); Green Party [Elizabeth MAY];
Liberal Party [Michael IGNATIEFF]; New Democratic Party [Jack LAYTON]
Political pressure groups and leaders:
other: agricultural sector; automobile industry; business groups;
chemical industry; commercial banks; communications sector; energy
industry; environmentalists; public administration groups; steel
industry; trade unions
International organization participation:
ADB (nonregional member), AfDB (nonregional member), APEC, Arctic
Council, ARF, ASEAN (dialogue partner), Australia Group, BIS, C,
CDB, EAPC, EBRD, FAO, FATF, G-20, G-7, G-8, G-10, IADB, IAEA, IBRD,
ICAO, ICC, ICCt, ICRM, IDA, IEA, IFAD, IFC, IFRCS, IHO, ILO, IMF,
IMO, IMSO, Interpol, IOC, IOM, IPU, ISO, ITSO, ITU, ITUC, MIGA,
MINUSTAH, MONUSCO, NAFTA, NATO, NEA, NSG, OAS, OECD, OIF, OPCW,
OSCE, Paris Club, PCA, PIF (partner), SECI (observer), UN, UNAMID,
UNCTAD, UNDOF, UNESCO, UNFICYP, UNHCR, UNMIS, UNRWA, UNTSO, UNWTO,
UPU, WCO, WFTU, WHO, WIPO, WMO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Gary DOER
chancery: 501 Pennsylvania Avenue NW, Washington, DC 20001
telephone: [1] (202) 682-1740
FAX: [1] (202) 682-7701
consulate(s) general: Atlanta, Boston, Buffalo, Chicago, Dallas,
Denver, Detroit, Los Angeles, Miami, Minneapolis, New York, Phoenix,
San Diego, San Francisco, Seattle, Tucson
consulate(s): Anchorage, Houston, Philadelphia, Princeton (New
Jersey), Raleigh, San Jose (California), Tucson
Diplomatic representation from the US:
chief of mission: Ambassador David C. JACOBSON
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburg, NY 13669-0430; P.O. Box
866, Station B, Ottawa, Ontario K1P 5T1
telephone: [1] (613) 688-5335
FAX: [1] (613) 688-3082
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
Vancouver, Winnipeg
Flag description:
two vertical bands of red (hoist and fly side, half width) with
white square between them; an 11-pointed red maple leaf is centered
in the white square; the maple leaf has long been a Canadian symbol;
the official colors of Canada are red and white
National anthem:
name: "O Canada"
lyrics/music: Adolphe-Basile ROUTHIER [French], Robert Stanley WEIR
[English]/Calixa LAVALLEE
note: adopted 1980; originally written in 1880, "O Canada" served as
an unofficial anthem many years before its official adoption; the
anthem has French and English versions whose lyrics differ; as a
Commonwealth realm, in addition to the national anthem, "God Save
the Queen" serves as the royal anthem (see United Kingdom)
Economy ::Canada
Economy - overview:
As an affluent, high-tech industrial society in the trillion-dollar
class, Canada resembles the US in its market-oriented economic
system, pattern of production, and affluent living standards. Since
World War II, the impressive growth of the manufacturing, mining,
and service sectors has transformed the nation from a largely rural
economy into one primarily industrial and urban. The 1989 US-Canada
Free Trade Agreement (FTA) and the 1994 North American Free Trade
Agreement (NAFTA) (which includes Mexico) touched off a dramatic
increase in trade and economic integration with the US, its
principal trading partner. Canada enjoys a substantial trade surplus
with the US, which absorbs about three-fourths of Canadian exports
each year. Canada is the US''s largest foreign supplier of energy,
including oil, gas, uranium, and electric power. Given its great
natural resources, skilled labor force, and modern capital plant,
Canada enjoyed solid economic growth from 1993 through 2007.
Buffeted by the global economic crisis, the economy dropped into a
sharp recession in the final months of 2008, and Ottawa posted its
first fiscal deficit in 2009 after 12 years of surplus. Canada''s
major banks, however, emerged from the financial crisis of 2008-09
among the strongest in the world, owing to the country''s tradition
of conservative lending practices and strong capitalization. During
2010, Canada''s economy grew only 3%, because of weak exports.
GDP (purchasing power parity):
$1.335 trillion (2010 est.)
country comparison to the world: 15
$1.297 trillion (2009 est.)
$1.33 trillion (2008 est.)
note: data are in 2010 US dollars
GDP (official exchange rate):
$1.564 trillion (2010 est.)
GDP - real growth rate:
3% (2010 est.)
country comparison to the world: 128
-2.5% (2009 est.)
0.5% (2008 est.)
GDP - per capita (PPP):
$39,600 (2010 est.)
country comparison to the world: 22
$38,700 (2009 est.)
$40,000 (2008 est.)
note: data are in 2010 US dollars
GDP - composition by sector:
agriculture: 2.3%
industry: 26.4%
services: 71.3% (2009 est.)
Labor force:
18.59 million (2010 est.)
country comparison to the world: 31
Labor force - by occupation:
agriculture: 2%
manufacturing: 13%
construction: 6%
services: 76%
other: 3% (2006 est.)
Unemployment rate:
8% (2010 est.)
country comparison to the world: 91
8.3% (2009 est.)
Population below poverty line:
10.8%; note - this figure is the Low Income Cut-Off (LICO), a
calculation that results in higher figures than found in many
comparable economies; Canada does not have an official poverty line
(2005)
Household income or consumption by percentage share:
lowest 10%: 2.6%
highest 10%: 24.8% (2000)
Distribution of family income - Gini index:
32.1 (2005)
country comparison to the world: 100
31.5 (1994)
Investment (gross fixed):
22.1% of GDP (2010 est.)
country comparison to the world: 66
Public debt:
82.9% of GDP (2010 est.)
country comparison to the world: 16
82.5% of GDP (2009 est.)
Inflation rate (consumer prices):
1.6% (2010 est.)
country comparison to the world: 43
0.3% (2009 est.)
Central bank discount rate:
0.5% (31 December 2009)
country comparison to the world: 132
1.75% (31 December 2008)
Commercial bank prime lending rate:
2.4% (31 December 2009 est.)
country comparison to the world: 151
4.73% (31 December 2008 est.)
Stock of narrow money:
$560.8 billion (31 December 2010 est)
country comparison to the world: 10
$470.9 billion (31 December 2009 est)
Stock of broad money:
$1.469 trillion (31 December 2010 est.)
country comparison to the world: 12
$1.144 trillion (31 December 2009 est.)
Stock of domestic credit:
$2.963 trillion (31 December 2010 est.)
country comparison to the world: 10
$2.606 trillion (31 December 2009 est.)
Market value of publicly traded shares:
$1.681 trillion (31 December 2009)
country comparison to the world: 10
$1.002 trillion (31 December 2008)
$2.187 trillion (31 December 2007)
Agriculture - products:
wheat, barley, oilseed, tobacco, fruits, vegetables; dairy products;
forest products; fish
Industries:
transportation equipment, chemicals, processed and unprocessed
minerals, food products, wood and paper products, fish products,
petroleum and natural gas
Industrial production growth rate:
5.8% (2010 est.)
country comparison to the world: 57
Electricity - production:
620.7 billion kWh (2007 est.)
country comparison to the world: 7
Electricity - consumption:
536.1 billion kWh (2007 est.)
country comparison to the world: 8
Electricity - exports:
55.73 billion kWh (2008 est.)
Electricity - imports:
23.5 billion kWh (2008 est.)
Oil - production:
3.289 million bbl/day (2009 est.)
country comparison to the world: 6
Oil - consumption:
2.151 million bbl/day (2009 est.)
country comparison to the world: 11
Oil - exports:
2.001 million bbl/day (2008 est.)
country comparison to the world: 10
Oil - imports:
1.192 million bbl/day (2008 est.)
country comparison to the world: 15
Oil - proved reserves:
175.2 billion bbl
country comparison to the world: 2
note: includes oil sands (1 January 2010 est.)
Natural gas - production:
161.3 billion cu m (2009 est.)
country comparison to the world: 5
Natural gas - consumption:
94.62 billion cu m (2009 est.)
country comparison to the world: 7
Natural gas - exports:
94.67 billion cu m (2009 est.)
country comparison to the world: 3
Natural gas - imports:
16.59 billion cu m (2009 est.)
country comparison to the world: 16
Natural gas - proved reserves:
1.754 trillion cu m (1 January 2010 est.)
country comparison to the world: 21
Current account balance:
-$40.21 billion (2010 est.)
country comparison to the world: 184
-$38.08 billion (2009 est.)
Exports:
$406.8 billion (2010 est.)
country comparison to the world: 10
$323.3 billion (2009 est.)
Exports - commodities:
motor vehicles and parts, industrial machinery, aircraft,
telecommunications equipment; chemicals, plastics, fertilizers; wood
pulp, timber, crude petroleum, natural gas, electricity, aluminum
Exports - partners:
US 75.02%, UK 3.37%, China 3.09% (2009)
Imports:
$406.4 billion (2010 est.)
country comparison to the world: 12
$327.3 billion (2009 est.)
Imports - commodities:
machinery and equipment, motor vehicles and parts, crude oil,
chemicals, electricity, durable consumer goods
Imports - partners:
US 51.1%, China 10.88%, Mexico 4.56% (2009)
Reserves of foreign exchange and gold:
$NA (31 December 2010 est.)
$54.36 billion (31 December 2009 est.)
Debt - external:
$1.009 trillion (30 June 2010)
country comparison to the world: 15
$781.1 billion (31 December 2008)
Stock of direct foreign investment - at home:
$528.7 billion (31 December 2010 est.)
country comparison to the world: 10
$494.6 billion (31 December 2009 est.)
Stock of direct foreign investment - abroad:
$602.5 billion (31 December 2010 est.)
country comparison to the world: 11
$576.2 billion (31 December 2009 est.)
Exchange rates:
Canadian dollars (CAD) per US dollar - 1.0346 (2010), 1.1431 (2009),
1.0364 (2008), 1.0724 (2007), 1.1334 (2006)
Communications ::Canada
Telephones - main lines in use:
18.251 million (2009)
country comparison to the world: 16
Telephones - mobile cellular:
23.081 million (2009)
country comparison to the world: 38
Telephone system:
general assessment: excellent service provided by modern technology
domestic: domestic satellite system with about 300 earth stations
international: country code - 1; submarine cables provide links to
the US and Europe; satellite earth stations - 7 (5 Intelsat - 4
Atlantic Ocean and 1 Pacific Ocean, and 2 Intersputnik - Atlantic
Ocean region) (2007)
Broadcast media:
2 public television broadcasting networks each with a large number
of network affilates; several private-commercial networks also with
multiple network affiliates; overall, about 150 TV stations;
multi-channel satellite and cable systems provide access to a wide
range of stations including US stations; mix of public and
commercial radio broadcasters with the Canadian Broadcasting
Corporation (CBC), the public radio broadcaster, operating 4 radio
networks, Radio Canada International, and radio services to
indigenous populations in the north; roughly 2,000 licensed radio
stations in Canada (2008)
Internet country code:
.ca
Internet hosts:
7.77 million (2010)
country comparison to the world: 13
Internet users:
26.96 million (2009)
country comparison to the world: 16
Transportation ::Canada
Airports:
1,404 (2010)
country comparison to the world: 4
Airports - with paved runways:
total: 514
over 3,047 m: 18
2,438 to 3,047 m: 20
1,524 to 2,437 m: 148
914 to 1,523 m: 249
under 914 m: 79 (2010)
Airports - with unpaved runways:
total: 890
1,524 to 2,437 m: 73
914 to 1,523 m: 377
under 914 m: 440 (2010)
Heliports:
12 (2010)
Pipelines:
crude and refined oil 23,564 km; liquid petroleum gas 74,980 km
(2009)
Railways:
total: 46,688 km
country comparison to the world: 5
standard gauge: 46,688 km 1.435-m gauge (2008)
Roadways:
total: 1,042,300 km
country comparison to the world: 6
paved: 415,600 km (includes 17,000 km of expressways)
unpaved: 626,700 km (2008)
Waterways:
636 km
country comparison to the world: 78
note: Saint Lawrence Seaway of 3,769 km, including the Saint
Lawrence River of 3,058 km, shared with United States (2008)
Merchant marine:
total: 184
country comparison to the world: 36
by type: bulk carrier 66, cargo 12, carrier 1, chemical tanker 14,
combination ore/oil 1, container 2, passenger 6, passenger/cargo 64,
petroleum tanker 12, roll on/roll off 6
foreign-owned: 15 (France 1, Netherlands 1, Norway 4, US 9)
registered in other countries: 223 (Australia 7, Bahamas 102,
Barbados 13, Cambodia 2, Cyprus 2, Honduras 1, Hong Kong 70, Liberia
4, Malta 1, Marshall Islands 4, Norway 1, Panama 5, Spain 5, US 1,
Vanuatu 5) (2010)
Ports and terminals:
Fraser River Port, Halifax, Hamilton, Montreal, Port-Cartier, Quebec
City, Saint John (New Brunswick), Sept-Isles, Vancouver
Military ::Canada
Military branches:
Canadian Forces: Land Forces Command (LFC), Maritime Command
(MARCOM), Air Command (AIRCOM), Canada Command (homeland security)
(2010)
Military service age and obligation:
17 years of age for male and female voluntary military service (with
parental consent); 16 years of age for reserve and military college
applicants; Canadian citizenship or permanent residence status
required; maximum 34 years of age; service obligation 3-9 years
(2008)
Manpower available for military service:
males age 16-49: 8,051,656
females age 16-49: 7,780,644 (2010 est.)
Manpower fit for military service:
males age 16-49: 6,642,190
females age 16-49: 6,402,896 (2010 est.)
Manpower reaching militarily significant age annually:
male: 220,538
female: 208,033 (2010 est.)
Military expenditures:
1.1% of GDP (2005 est.)
country comparison to the world: 126
Transnational Issues ::Canada
Disputes - international:
managed maritime boundary disputes with the US at Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca, and the Gulf of Maine
including the disputed Machias Seal Island and North Rock; Canada,
the US, and other countries dispute the status of the Northwest
Passage; US works closely with Canada to intensify security measures
for monitoring and controlling legal and illegal movement of people,
transport, and commodities across the international border;
sovereignty dispute with Denmark over Hans Island in the Kennedy
Channel between Ellesmere Island and Greenland; commencing the
collection of technical evidence for submission to the Commission on
the Limits of the Continental Shelf in support of claims for
continental shelf beyond 200 nautical miles from its declared
baselines in the Arctic, as stipulated in Article 76, paragraph 8,
of the United Nations Convention on the Law of the Sea
Illicit drugs:
illicit producer of cannabis for the domestic drug market and export
to US; use of hydroponics technology permits growers to plant large
quantities of high-quality marijuana indoors; increasing ecstasy
production, some of which is destined for the US; vulnerable to
narcotics money laundering because of its mature financial services
sector
page last updated on January 20, 2011
======================================================================
@Cape Verde (Africa)
Introduction ::Cape Verde','8e58ad1a0c15e97072bbbb09ed3c3d904aae44714313477cb8e160d9f48eb942','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ca2a5c2f2b2543aa13d83e5e52c9a744f13e9af02780fc8ef6fb1a2cd5b103f',2010,'BB','Barbados','environment',232,'Geography - note:
vegetation scanty
People ::Saint Pierre and Miquelon
Population:
5,943 (July 2010 est.)
country comparison to the world: 228
Age structure:
0-14 years: 21.9% (male 789/female 755)
15-64 years: 66.4% (male 2,378/female 2,313)
65 years and over: 11.7% (male 382/female 446) (2010 est.)
Median age:
total: 42 years
male: 41.6 years
female: 42.4 years (2010 est.)
Population growth rate:
-0.909% (2010 est.)
country comparison to the world: 230
Birth rate:
8.58 births/1,000 population (2010 est.)
country comparison to the world: 218
Death rate:
8.41 deaths/1,000 population (July 2010 est.)
country comparison to the world: 88
Net migration rate:
-9.25 migrant(s)/1,000 population (2010 est.)
country comparison to the world: 213
Urbanization:
urban population: 89% of total population (2008)
rate of urbanization: 0.1% annual rate of change (2005-10 est.)
Sex ratio:
at birth: 1.04 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.98 male(s)/female (2010 est.)
Infant mortality rate:
total: 7.65 deaths/1,000 live births
country comparison to the world: 163
male: 8.94 deaths/1,000 live births
female: 6.29 deaths/1,000 live births (2010 est.)
Life expectancy at birth:
total population: 79.74 years
country comparison to the world: 30
male: 77.49 years
female: 82.12 years (2010 est.)
Total fertility rate:
1.54 children born/woman (2010 est.)
country comparison to the world: 183
HIV/AIDS - adult prevalence rate:
NA
HIV/AIDS - people living with HIV/AIDS:
NA
HIV/AIDS - deaths:
NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups:
Basques and Bretons (French fishermen)
Religions:
Roman Catholic 99%, other 1%
Languages:
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Education expenditures:
NA
Government ::Saint Pierre and Miquelon
Country name:
conventional long form: Territorial Collectivity of Saint Pierre and
Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et Miquelon
local short form: Saint-Pierre et Miquelon
Dependency status:
self-governing territorial overseas collectivity of France
Government type:
NA
Capital:
name: Saint-Pierre
geographic coordinates: 46 46 N, 56 11 W
time difference: UTC-3 (2 hours ahead of Washington, DC during
Standard Time)
daylight saving time: +1hr, begins second Sunday in March; ends
first Sunday in November
Administrative divisions:
none (territorial overseas collectivity of France); note - there are
no first-order administrative divisions as defined by the US
Government, but there are two communes - Saint Pierre, Miquelon at
the second order
Independence:
none (territorial collectivity of France; has been under French
control since 1763)
National holiday:
Bastille Day, 14 July (1789)
Constitution:
4 October 1958 (French Constitution)
Legal system:
the laws of France where applicable apply
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Nicolas SARKOZY (since 16 May 2007);
represented by Prefect Jean-Regis BORIUS (since 29 October 2009)
head of government: President of the Territorial Council Stephane
ARTANO (since 21 February 2007)
cabinet: NA
(For more information visit the World Leaders website )
elections: French president elected by popular vote for a five-year
term; election last held on 6 May 2007 (next to be held in 2012);
prefect appointed by the French president on the advice of the
French Ministry of Interior; president of the Territorial Council
elected by the members of the council
Legislative branch:
unicameral Territorial Council or Conseil Territorial (19 seats, 15
from Saint Pierre and four from Miquelon; members elected by popular
vote to serve six-year terms)
elections: elections last held on 19 and 26 in March 2006 (next to
be held in March 2012)
election results: percent of vote by party - NA; seats by party - AD
16, Cap sur l''Avenir 2, SPM 2000/AM 1
note: Saint Pierre and Miquelon elect one member to the French
Senate; elections last held on 21 September 2008 (next to be held in
September 2014); results - percent of vote by party - NA; seats by
party - UMP 1; Saint Pierre and Miquelon also elects one member to
the French National Assembly; elections last held on, first round -
10 June 2007, second round - 17 June 2007 (next to be held in 2012);
results - percent of vote by party - NA; seats by party - Left
Radical Party 1
Judicial branch:
Superior Tribunal of Appeals or Tribunal Superieur d''Appel
Political parties and leaders:
Archipelago Tomorrow or AD (affiliated with UDF/RPR list); Cap sur
l''Avenir (affiliated with PRG); Left Radical Party or PRG;
Rassemblement pour la Republique or RPR (now UMP); Saint Pierre and
Miquelon 2000/Avenir Miquelon or SPM 2000/AM; Socialist Party or PS;
Union pour la Democratie Francaise or UDF
Political pressure groups and leaders:
NA
International organization participation:
UPU, WFTU
Diplomatic representation in the US:
none (territorial overseas collectivity of France)
Diplomatic representation from the US:
none (territorial overseas collectivity of France)
Flag description:
a yellow three-masted sailing ship facing the hoist side rides on a
blue background with scattered, white, wavy lines under the ship; a
continuous black-over-white wavy line divides the ship from the
white wavy lines; on the hoist side, a vertical band is divided into
three parts: the top part (called ikkurina) is red with a green
diagonal cross extending to the corners overlaid by a white cross
dividing the rectangle into four sections; the middle part has a
white background with an ermine pattern; the third part has a red
background with two stylized yellow lions outlined in black, one
above the other; these three heraldic arms represent settlement by
colonists from the Basque Country (top), Brittany, and Normandy; the
blue on the main portion of the flag symbolizes the Atlantic Ocean
and the stylized ship represents the Grande Hermine in which Jacques
Cartier "discovered" the islands in 1536
note: the flag of France used for official occasions
National anthem:
note: as a collectivity of France, "La Marseillaise" is official
(see France)
Economy ::Saint Pierre and Miquelon
Economy - overview:
The inhabitants have traditionally earned their livelihood by
fishing and by servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining, however, because of
disputes with Canada over fishing quotas and a steady decline in the
number of ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic zone of 12,348 sq km
to settle a longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought. France heavily
subsidizes the islands to the great betterment of living standards.
The government hopes an expansion of tourism will boost economic
prospects. Fish farming, crab fishing, and agriculture are being
developed to diversify the local economy. Recent test drilling for
oil may pave the way for development of the energy sector.
GDP (purchasing power parity):
$48.3 million (2003 est.)
country comparison to the world: 223
note: supplemented by annual payments from France of about $60
million
GDP (official exchange rate):
$NA
GDP - real growth rate:
NA%
GDP - per capita (PPP):
$7,000 (2001 est.)
country comparison to the world: 130
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Labor force:
3,450 (2005)
country comparison to the world: 221
Labor force - by occupation:
agriculture: 18%
industry: 41%
services: 41% (1996 est.)
Unemployment rate:
10.3% (1999)
country comparison to the world: 113
Population below poverty line:
NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
8.1% (2005)
country comparison to the world: 190
Agriculture - products:
vegetables; poultry, cattle, sheep, pigs; fish
Industries:
fish processing and supply base for fishing fleets; tourism
Industrial production growth rate:
NA%
Electricity - production:
53 million kWh (2007 est.)
country comparison to the world: 197
Electricity - consumption:
49.29 million kWh (2007 est.)
country comparison to the world: 197
Electricity - exports:
0 kWh (2008 est.)
Electricity - imports:
0 kWh (2008 est.)
Oil - production:
0 bbl/day (2009 est.)
country comparison to the world: 136
Oil - consumption:
1,000 bbl/day (2009 est.)
country comparison to the world: 195
Oil - exports:
0 bbl/day (2007 est.)
country comparison to the world: 179
Oil - imports:
564 bbl/day (2007 est.)
country comparison to the world: 195
Oil - proved reserves:
0 bbl (1 January 2010 est.)
country comparison to the world: 129
Natural gas - production:
0 cu m (2008 est.)
country comparison to the world: 136
Natural gas - consumption:
0 cu m (2008 est.)
country comparison to the world: 155
Natural gas - exports:
0 cu m (2008 est.)
country comparison to the world: 134
Natural gas - imports:
0 cu m (2008 est.)
country comparison to the world: 139
Natural gas - proved reserves:
0 cu m (1 January 2010 est.)
country comparison to the world: 140
Exports:
$5.5 million (2005 est.)
country comparison to the world: 215
Exports - commodities:
fish and fish products, soybeans, animal feed, mollusks and
crustaceans, fox and mink pelts
Imports:
$68.2 million (2005 est.)
country comparison to the world: 213
Imports - commodities:
meat, clothing, fuel, electrical equipment, machinery, building
materials
Debt - external:
$NA
Exchange rates:
euros (EUR) per US dollar - 0.7715 (2010), 0.7179 (2009), 0.6734
(2008), 0.7345 (2007), 0.7964 (2006)
Communications ::Saint Pierre and Miquelon
Telephones - main lines in use:
4,800 (2009)
country comparison to the world: 213
Telephone system:
general assessment: adequate
domestic: NA
international: country code - 508; radiotelephone communication with
most countries in the world; satellite earth station - 1 in French
domestic satellite system
Broadcast media:
2 television stations with a third repeater station, all part of the
French Overseas Network; has radio stations on St. Pierre and on
Miquelon that are part of the French Overseas Network (2007)
Internet country code:
.pm
Internet hosts:
0 (2010)
country comparison to the world: 232
Transportation ::Saint Pierre and Miquelon
Airports:
2 (2010)
country comparison to the world: 203
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2010)
Roadways:
total: 117 km
country comparison to the world: 213
paved: 80 km
unpaved: 37 km (2000)
Ports and terminals:
Saint-Pierre
Military ::Saint Pierre and Miquelon
Manpower fit for military service:
males age 16-49: 1,097
females age 16-49: 1,096 (2010 est.)
Manpower reaching militarily significant age annually:
male: 36
female: 34 (2010 est.)
Military - note:
defense is the responsibility of France
Transnational Issues ::Saint Pierre and Miquelon
Disputes - international:
none
page last updated on January 12, 2011
======================================================================
@Saint Vincent and the Grenadines (Central America and Caribbean)
Introduction ::Saint Vincent and the Grenadines','755ce73295b161b023770aa9181190fce7b8c160be4d14a66c7852bd4c0d0913','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76b1135b0b2c29ee595f8493ced22fc058757b9f563a6bb9d7151674382d882d',2010,'MH','Marshall Islands','environment',288,'GDP (purchasing power parity):
$1.577 billion (2004 est.)
country comparison to the world: 193
GDP (official exchange rate):
$NA
GDP - real growth rate:
2% (2002 est.)
country comparison to the world: 149
GDP - per capita (PPP):
$14,500 (2004 est.)
country comparison to the world: 80
GDP - composition by sector:
agriculture: 1%
industry: 19%
services: 80% (2003 est.)
Labor force:
49,820 (2007 est.)
country comparison to the world: 189
Labor force - by occupation:
agriculture: 1%
industry: 19%
services: 80% (2003 est.)
Unemployment rate:
6.2% (2004)
country comparison to the world: 59
Population below poverty line:
28.9% (2002)
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
2.2% (2003)
country comparison to the world: 62
Agriculture - products:
fruit, vegetables, sorghum; Senepol cattle
Industries:
tourism, petroleum refining, watch assembly, rum distilling,
construction, pharmaceuticals, textiles, electronics
Industrial production growth rate:
NA%
Electricity - production:
776.4 million kWh (2007 est.)
country comparison to the world: 151
Electricity - consumption:
722 million kWh (2007 est.)
country comparison to the world: 150
Electricity - exports:
0 kWh (2008 est.)
Electricity - imports:
0 kWh (2008 est.)
Oil - production:
16,870 bbl/day (2009 est.)
country comparison to the world: 76
Oil - consumption:
88,820 bbl/day (2009 est.)
country comparison to the world: 82
Oil - exports:
388,000 bbl/day (2007 est.)
country comparison to the world: 33
Oil - imports:
480,600 bbl/day (2007 est.)
country comparison to the world: 27
Oil - proved reserves:
0 bbl (1 January 2010 est.)
country comparison to the world: 107
Natural gas - production:
0 cu m (2008 est.)
country comparison to the world: 113
Natural gas - consumption:
0 cu m (2008 est.)
country comparison to the world: 163
Natural gas - exports:
0 cu m (2008 est.)
country comparison to the world: 100
Natural gas - imports:
0 cu m (2008 est.)
country comparison to the world: 116
Natural gas - proved reserves:
0 cu m (1 January 2010 est.)
country comparison to the world: 121
Exports:
$4.234 billion (2001)
country comparison to the world: 116
Exports - commodities:
refined petroleum products
Imports:
$4.609 billion (2001)
country comparison to the world: 120
Imports - commodities:
crude oil, foodstuffs, consumer goods, building materials
Debt - external:
$NA
Exchange rates:
the US dollar is used
Communications ::Virgin Islands
Telephones - main lines in use:
75,000 (2009)
country comparison to the world: 150
Telephones - mobile cellular:
80,300 (2005)
country comparison to the world: 190
Telephone system:
general assessment: modern system with total digital switching, uses
fiber-optic cable and microwave radio relay
domestic: full range of services available
international: country code - 1-340; submarine cable connections to
US, the Caribbean, Central and South America; satellite earth
stations - NA
Broadcast media:
about a dozen television broadcast stations including 1 public TV
station; multi-channel cable and satellite TV services are
available; 24 radio stations broadcasting (2009)
Internet country code:
.vi
Internet hosts:
8,933 (2010)
country comparison to the world: 129
Internet users:
30,000 (2009)
country comparison to the world: 180
Transportation ::Virgin Islands
Airports:
2 (2010)
country comparison to the world: 201
Airports - with paved runways:
total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2010)
Roadways:
total: 1,260 km (2008)
country comparison to the world: 179
Ports and terminals:
Charlotte Amalie, Christiansted, Cruz Bay, Frederiksted, Limetree Bay
Military ::Virgin Islands
Manpower fit for military service:
males age 16-49: 17,675
females age 16-49: 21,070 (2010 est.)
Manpower reaching militarily significant age annually:
male: 805
female: 849 (2010 est.)
Military - note:
defense is the responsibility of the US
Transnational Issues ::Virgin Islands
Disputes - international:
none
page last updated on January 11, 2011
======================================================================
@Wake Island (Australia-Oceania)
Introduction ::Wake Island','ff5b0855e386bead9ae89694249c81280146cd949ba1d0eab59cfafc41680023','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d7634b89b27a8f1e98e463578c8dc95e9b4389bc068bb0eda08c45460eabe3f',2010,'CA','Canada','environment',771,'Cape Verde
The uninhabited islands were discovered and colonized by
the Portuguese in the 15th century; Cape Verde subsequently became a
trading center for African slaves and later an important coaling and
resupply stop for whaling and transatlantic shipping. Following
independence in 1975, and a tentative interest in unification with
Guinea-Bissau, a one-party system was established and maintained
until multi-party elections were held in 1990. Cape Verde continues
to exhibit one of Africa''s most stable democratic governments.
Repeated droughts during the second half of the 20th century caused
significant hardship and prompted heavy emigration. As a result,
Cape Verde''s expatriate population is greater than its domestic one.
Most Cape Verdeans have both African and Portuguese antecedents.','4c35c4f2feffe4dc04eae5190c09ac59b469691cd05fd0055d8fb42a8a245ce7','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1806d5a10344c1935c386f22d21b9d4e250176c8f003c61574d66d9315b331b',2010,'KY','Cayman Islands','environment',772,'The Cayman Islands were colonized from Jamaica by the
British during the 18th and 19th centuries and were administered by
Jamaica after 1863. In 1959, the islands became a territory within
the Federation of the West Indies. When the Federation dissolved in
1962, the Cayman Islands chose to remain a British dependency.','8d963fb0b610ed143e4aba91f5793934ed33b388c9688ce6066785f55f4b4f0d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('853b1698857bf9013972caa9709b8baad0dda51c1c6735a7a1e979910b691e68',2010,'CF','Central African Republic','environment',773,'The former French colony of Ubangi-Shari
became the Central African Republic upon independence in 1960. After
three tumultuous decades of misrule - mostly by military governments
- civilian rule was established in 1993 and lasted for one decade.
President Ange-Felix PATASSE''s civilian government was plagued by
unrest, and in March 2003 he was deposed in a military coup led by
General Francois BOZIZE, who established a transitional government.
Though the government has the tacit support of civil society groups
and the main parties, a wide field of candidates contested the
municipal, legislative, and presidential elections held in March and
May of 2005 in which General BOZIZE was affirmed as president. The
government still does not fully control the countryside, where
pockets of lawlessness persist. Unrest in the neighboring nations of
Chad, Sudan, and the DRC continues to affect stability in the
Central African Republic as well.','fe41e93407aa9bb7b6556c6f727594eafb916dcb80f1155d9d68a9d5dbb39836','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e8c966f5f3b26c4b1bd8b63ed4cb159419c888ee5a86d543f8a8731637e3977',2010,'TD','Chad','environment',774,'Chad, part of France''s African holdings until 1960, endured
three decades of civil warfare as well as invasions by Libya before
a semblance of peace was finally restored in 1990. The government
eventually drafted a democratic constitution and held flawed
presidential elections in 1996 and 2001. In 1998, a rebellion broke
out in northern Chad, which has sporadically flared up despite
several peace agreements between the government and the rebels. In
2005, new rebel groups emerged in western Sudan and made probing
attacks into eastern Chad despite signing peace agreements in
December 2006 and October 2007. Power remains in the hands of an
ethnic minority. In June 2005, President Idriss DEBY held a
referendum successfully removing constitutional term limits and won
another controversial election in 2006. Sporadic rebel campaigns
continued throughout 2006 and 2007. The capital experienced a
significant rebel threat in early 2008.','c3258e3fa10ae9922de6878430e30906c12b7aa4f6f26756f4fbbd475725e615','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c88179822a2f59e869ff4274558fc11d3915002d39e0bca69ea6c420ab3010e8',2010,'CL','Chile','environment',775,'Prior to the coming of the Spanish in the 16th century,
northern Chile was under Inca rule while the indigenous Mapuche
inhabited central and southern Chile. Although Chile declared its
independence in 1810, decisive victory over the Spanish was not
achieved until 1818. In the War of the Pacific (1879-83), Chile
defeated Peru and Bolivia and won its present northern regions. It
was not until the 1880s that the Mapuche Indians were completely
subjugated. After a series of elected governments, a three-year-old
Marxist government of Salvador ALLENDE was overthrown in 1973 by a
military coup led by Augusto PINOCHET, who ruled until a freely
elected president was installed in 1990. Sound economic policies,
maintained consistently since the 1980s, have contributed to steady
growth, reduced poverty rates by over half, and have helped secure
the country''s commitment to democratic and representative
government. Chile has increasingly assumed regional and
international leadership roles befitting its status as a stable,
democratic nation.','2e10937aa878eafdee6b2a5156173962a9698d3a457d28f8f14181dc7246f997','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('176ade73e17b3e5b66961a11faf06d9aac8834e31bc19e01f7887cf87fb22c6c',2010,'CN','China','environment',776,'For centuries China stood as a leading civilization, outpacing
the rest of the world in the arts and sciences, but in the 19th and
early 20th centuries, the country was beset by civil unrest, major
famines, military defeats, and foreign occupation. After World War
II, the Communists under MAO Zedong established an autocratic
socialist system that, while ensuring China''s sovereignty, imposed
strict controls over everyday life and cost the lives of tens of
millions of people. After 1978, MAO''s successor DENG Xiaoping and
other leaders focused on market-oriented economic development and by
2000 output had quadrupled. For much of the population, living
standards have improved dramatically and the room for personal
choice has expanded, yet political controls remain tight. China
since the early 1990s has increased its global outreach and
participation in international organizations.','c2fe6818e9e12ee44ef121e030ff6942a08c4c4d6eed686ad69186befda9435f','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbf40e259f94f4b7fb5e70c5d5299bd50e2671138b7f6a6beb0c3bf572ac053e',2010,'CX','Christmas Island','environment',777,'Named in 1643 for the day of its discovery, the
island was annexed and settlement began by the UK in 1888. Phosphate
mining began in the 1890s. The UK transferred sovereignty to
Australia in 1958. Almost two-thirds of the island has been declared
a national park.
Clipperton Island
This isolated island was named for John
CLIPPERTON, a pirate who made it his hideout early in the 18th
century. Annexed by France in 1855, it was seized by Mexico in 1897.
Arbitration eventually awarded the island to France, which took
possession in 1935.','3da2825344a9c8e79045198f4e0f0bebac960e9230b2b20eed9436fbb4fb05a9','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('193558cc2c8d984f18d3713702db974e3fadb59ab0084e81aad76009a1b562e1',2010,'CC','Cocos (Keeling) Islands','environment',778,'There are 27 coral islands in the group.
Captain William KEELING discovered the islands in 1609, but they
remained uninhabited until the 19th century. From the 1820s to 1978,
members of the CLUNIE-ROSS family controlled the islands and the
copra produced from local coconuts. Annexed by the UK in 1857, the
Cocos Islands were transferred to the Australian Government in 1955.
The population on the two inhabited islands generally is split
between the ethnic Europeans on West Island and the ethnic Malays on
Home Island.','28431b678b670064ca4b26ae43070cf5052ce5bc0eaadc9b8e7a587bc011a822','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbdf2226ded09e5267211d13af56cb6403ffce917eeae873126c49836ca9ce79',2010,'CO','Colombia','environment',779,'Colombia was one of the three countries that emerged from
the collapse of Gran Colombia in 1830 (the others are Ecuador and
Venezuela). A four-decade long conflict between government forces
and anti-government insurgent groups, principally the Revolutionary
Armed Forces of Colombia (FARC) heavily funded by the drug trade,
escalated during the 1990s. The insurgents lack the military or
popular support necessary to overthrow the government and violence
has been decreasing since about 2002, but insurgents continue
attacks against civilians and large areas of the countryside are
under guerrilla influence or are contested by security forces. More
than 31,000 former paramilitaries had demobilized by the end of 2006
and the United Self Defense Forces of Colombia (AUC) as a formal
organization had ceased to function. In the wake of the paramilitary
demobilization, emerging criminal groups arose, whose members
include some former paramilitaries. The Colombian Government has
stepped up efforts to reassert government control throughout the
country, and now has a presence in every one of its administrative
departments. However, neighboring countries worry about the violence
spilling over their borders. In January 2011, Colombia assumed a
nonpermanent seat on the UN Security Council for the 2011-12 term.','05814e0919519e78f3fb3df89f1c5f66954dd43e462f6ae0d5a17c8b929293ff','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26c5c0bc24ef9d62d0da1fec5473f8f40a10c5c61b93033f70e3f0c0168bc18b',2010,'KM','Comoros','environment',780,'Comoros has endured more than 20 coups or attempted coups
since gaining independence from France in 1975. In 1997, the islands
of Anjouan and Moheli declared independence from Comoros. In 1999,
military chief Col. AZALI seized power in a bloodless coup, and
helped negotiate the 2000 Fomboni Accords power-sharing agreement in
which the federal presidency rotates among the three islands, and
each island maintains its own local government. AZALI won the 2002
presidential election, and each island in the archipelago elected
its own president. AZALI stepped down in 2006 and President SAMBI
was elected to office. In 2007, Mohamed BACAR effected Anjouan''s
de-facto secession from the Union, refusing to step down in favor of
fresh Anjouanais elections when Comoros'' other islands held
legitimate elections in July. The African Union (AU) initially
attempted to resolve the political crisis by applying sanctions and
a naval blockade on Anjouan, but in March 2008, AU and Comoran
soldiers seized the island. The move was generally welcomed by the
island''s inhabitants.
Congo, Democratic Republic of the
Established as a Belgian colony in
1908, the Republic of the Congo gained its independence in 1960, but
its early years were marred by political and social instability.
Col. Joseph MOBUTU seized power and declared himself president in a
November 1965 coup. He subsequently changed his name - to MOBUTU
Sese Seko - as well as that of the country - to Zaire. MOBUTU
retained his position for 32 years through several sham elections,
as well as through brutal force. Ethnic strife and civil war,
touched off by a massive inflow of refugees in 1994 from fighting in
Rwanda and Burundi, led in May 1997 to the toppling of the MOBUTU
regime by a rebellion backed by Rwanda and Uganda and fronted by
Laurent KABILA. He renamed the country the Democratic Republic of
the Congo (DRC), but in August 1998 his regime was itself challenged
by a second insurrection again backed by Rwanda and Uganda. Troops
from Angola, Chad, Namibia, Sudan, and Zimbabwe intervened to
support KABILA''s regime. A cease-fire was signed in July 1999 by the
DRC, Congolese armed rebel groups, Angola, Namibia, Rwanda, Uganda,
and Zimbabwe but sporadic fighting continued. Laurent KABILA was
assassinated in January 2001 and his son, Joseph KABILA, was named
head of state. In October 2002, the new president was successful in
negotiating the withdrawal of Rwandan forces occupying eastern
Congo; two months later, the Pretoria Accord was signed by all
remaining warring parties to end the fighting and establish a
government of national unity. A transitional government was set up
in July 2003. Joseph KABILA as president and four vice presidents
represented the former government, former rebel groups, the
political opposition, and civil society. The transitional government
held a successful constitutional referendum in December 2005 and
elections for the presidency, National Assembly, and provincial
legislatures in 2006. The National Assembly was installed in
September 2006 and KABILA was inaugurated president in December
2006. Provincial assemblies were constituted in early 2007, and
elected governors and national senators in January 2007.
Congo, Republic of the
Upon independence in 1960, the former French
region of Middle Congo became the Republic of the Congo. A quarter
century of experimentation with Marxism was abandoned in 1990 and a
democratically elected government took office in 1992. A brief civil
war in 1997 restored former Marxist President Denis SASSOU-NGUESSO,
and ushered in a period of ethnic and political unrest.
Southern-based rebel groups agreed to a final peace accord in March
2003, but the calm is tenuous and refugees continue to present a
humanitarian crisis. The Republic of Congo was once one of Africa''s
largest petroleum producers, but with declining production it will
need new offshore oil finds to sustain its oil earnings over the
long term.','f63bc6f9f0e54aca94cce60b5e9b3fbcb93307c023873fbae213ac590fb168fd','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baa642cb7c2c7a24e7b2f8ddee02b1460c2dbb112e9f954f36eb5292989e280f',2010,'CK','Cook Islands','environment',781,'Named after Captain COOK, who sighted them in 1770, the
islands became a British protectorate in 1888. By 1900,
administrative control was transferred to New Zealand; in 1965,
residents chose self-government in free association with New
Zealand. The emigration of skilled workers to New Zealand and
government deficits are continuing problems.
Coral Sea Islands
Scattered over more than three-quarters of a
million square kilometers of ocean, the Coral Sea Islands were
declared a territory of Australia in 1969. They are uninhabited
except for a small meteorological staff on the Willis Islets.
Automated weather stations, beacons, and a lighthouse occupy many
other islands and reefs.','e46bdef811614f5a978a38a5d65218a50c42ff1a0bbbb68af9b96cfcdf879515','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10358e484783d5dd6b13c8cf2728b33c108a82ff503391d309468c9c43ae585b',2010,'CR','Costa Rica','environment',782,'Although explored by the Spanish early in the 16th
century, initial attempts at colonizing Costa Rica proved
unsuccessful due to a combination of factors, including: disease
from mosquito-infested swamps, brutal heat, resistance by natives,
and pirate raids. It was not until 1563 that a permanent settlement
of Cartago was established in the cooler, fertile central highlands.
The area remained a colony for some two and a half centuries. In
1821, Costa Rica became one of several Central American provinces
that jointly declared their independence from Spain. Two years later
it joined the United Provinces of Central America, but this
federation disintegrated in 1838, at which time Costa Rica
proclaimed its sovereignty and independence. Since the late 19th
century, only two brief periods of violence have marred the
country''s democratic development. Although it still maintains a
large agricultural sector, Costa Rica has expanded its economy to
include strong technology and tourism industries. The standard of
living is relatively high. Land ownership is widespread.
Cote d''Ivoire
Close ties to France since independence in 1960, the
development of cocoa production for export, and foreign investment
made Cote d''Ivoire one of the most prosperous of the West African
states, but did not protect it from political turmoil. In December
1999, a military coup - the first ever in Cote d''Ivoire''s history -
overthrew the government. Junta leader Robert GUEI blatantly rigged
elections held in late 2000 and declared himself the winner. Popular
protest forced him to step aside and brought Laurent GBAGBO into
power. Ivorian dissidents and disaffected members of the military
launched a failed coup attempt in September 2002. Rebel forces
claimed the northern half of the country, and in January 2003 were
granted ministerial positions in a unity government under the
auspices of the Linas-Marcoussis Peace Accord. President GBAGBO and
rebel forces resumed implementation of the peace accord in December
2003 after a three-month stalemate, but issues that sparked the
civil war, such as land reform and grounds for citizenship, remained
unresolved. In March 2007 President GBAGBO and former New Force
rebel leader Guillaume SORO signed the Ouagadougou Political
Agreement. As a result of the agreement, SORO joined GBAGBO''s
government as Prime Minister and the two agreed to reunite the
country by dismantling the zone of confidence separating North from
South, integrate rebel forces into the national armed forces, and
hold elections. Disarmament, demobilization, and reintegration of
rebel forces have been problematic as rebels seek to enter the armed
forces. Citizen identification and voter registration pose election
difficulties, and balloting planned for November 2009 was postponed
with no future date set. Several thousand UN troops and several
hundred French remain in Cote d''Ivoire to help the parties implement
their commitments and to support the peace process.','f01d41a8b8057b7ab955163aa48a3d7a324a69ccb740d5a5e5663d77baa18aee','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90029e64da9709360c64696230465e77f078ca7d61ee7e196988bfb2403e7a52',2010,'HR','Croatia','environment',783,'The lands that today comprise Croatia were part of the
Austro-Hungarian Empire until the close of World War I. In 1918, the
Croats, Serbs, and Slovenes formed a kingdom known after 1929 as
Yugoslavia. Following World War II, Yugoslavia became a federal
independent Communist state under the strong hand of Marshal TITO.
Although Croatia declared its independence from Yugoslavia in 1991,
it took four years of sporadic, but often bitter, fighting before
occupying Serb armies were mostly cleared from Croatian lands. Under
UN supervision, the last Serb-held enclave in eastern Slavonia was
returned to Croatia in 1998. In April 2009, Croatia joined NATO; it
is a candidate for eventual EU accession.','6d8dd52466ff5b6e2eb6f6f5ee311dee997e7a8afdab26558dd13af12497691d','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66c8992f8a3864962938515d9540f5d239ebc4fb57b3b7d1f3431a59c7f0bc03',2010,'CU','Cuba','environment',784,'The native Amerindian population of Cuba began to decline after
the European discovery of the island by Christopher COLUMBUS in 1492
and following its development as a Spanish colony during the next
several centuries. Large numbers of African slaves were imported to
work the coffee and sugar plantations, and Havana became the
launching point for the annual treasure fleets bound for Spain from
Mexico and Peru. Spanish rule eventually provoked an independence
movement and occasional rebellions that were harshly suppressed. US
intervention during the Spanish-American War in 1898 assisted the
Cubans in overthrowing Spanish rule. The Treaty of Paris established
Cuban independence from the US in 1902 after which the island
experienced a string of governments mostly dominated by the military
and corrupt politicians. Fidel CASTRO led a rebel army to victory in
1959; his iron rule held the subsequent regime together for nearly
five decades. He stepped down as president in February 2008 in favor
of his younger brother Raul CASTRO. Cuba''s Communist revolution,
with Soviet support, was exported throughout Latin America and
Africa during the 1960s, 1970s, and 1980s. The country faced a
severe economic downturn in 1990 following the withdrawal of former
Soviet subsidies worth $4 billion to $6 billion annually. Cuba at
times portrays the US embargo, in place since 1961, as the source if
its difficulties. Illicit migration to the US - using homemade
rafts, alien smugglers, air flights, or via the southwest border -
is a continuing problem. The US Coast Guard intercepted 982
individuals attempting to cross the Straits of Florida in fiscal
year 2009.
Curacao
Originally settled by Arawak Indians, Curacao was seized by
the Dutch in 1634 along with the neighboring island of Bonaire. Once
the center of the Caribbean slave trade, Curacao was hard hit by the
abolition of slavery in 1863. Its prosperity (and that of
neighboring Aruba) was restored in the early 20th century with the
construction of the Isla Refineria to service the newly discovered
Venezuelan oil fields. In 1954, Curacao and several other Dutch
Caribbean possesions were reorganized as the Netherlands Antilles,
part of the Kingdom of the Netherlands. In referenda in 2005 and
2009, the citizens of Curacao voted to become a self-governing
country within the Kingdom of the Netherlands. The change in status
became effective in October of 2010 with the dissolution of the
Netherlands Antilles.','253f70639eb713896055cf9436c367b764129cc793e0f790eca72649a0f80e06','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4106456cd233a0b84bb7f18ec030ccf9dbcf319b351936e1d368e26bde3e239c',2010,'CY','Cyprus','environment',785,'A former British colony, Cyprus became independent in 1960
following years of resistance to British rule. Tensions between the
Greek Cypriot majority and Turkish Cypriot minority came to a head
in December 1963, when violence broke out in the capital of Nicosia.
Despite the deployment of UN peacekeepers in 1964, sporadic
intercommunal violence continued forcing most Turkish Cypriots into
enclaves throughout the island. In 1974, a Greek
Government-sponsored attempt to seize control of Cyprus was met by
military intervention from Turkey, which soon controlled more than a
third of the island. In 1983, the Turkish Cypriot-occupied area
declared itself the "Turkish Republic of Northern Cyprus" ("TRNC"),
but it is recognized only by Turkey. The election of a new Cypriot
president in 2008 served as the impetus for the UN to encourage both
the Turkish and Cypriot Governments to reopen unification
negotiations. In September 2008, the leaders of the Greek Cypriot
and Turkish Cypriot communities started negotiations under UN
auspices aimed at reuniting the divided island. The entire island
entered the EU on 1 May 2004, although the EU acquis - the body of
common rights and obligations - applies only to the areas under the
internationally recognized government, and is suspended in the areas
administered by Turkish Cypriots. However, individual Turkish
Cypriots able to document their eligibility for Republic of Cyprus
citizenship legally enjoy the same rights accorded to other citizens
of European Union states.
Czech Republic
Following the First World War, the closely related
Czechs and Slovaks of the former Austro-Hungarian Empire merged to
form Czechoslovakia. During the interwar years, the new country''s
leaders were frequently preoccupied with meeting the demands of
other ethnic minorities within the republic, most notably the
Sudeten Germans and the Ruthenians (Ukrainians). After World War II,
a truncated Czechoslovakia fell within the Soviet sphere of
influence. In 1968, an invasion by Warsaw Pact troops ended the
efforts of the country''s leaders to liberalize Communist party rule
and create "socialism with a human face." Anti-Soviet demonstrations
the following year ushered in a period of harsh repression. With the
collapse of Soviet authority in 1989, Czechoslovakia regained its
freedom through a peaceful "Velvet Revolution." On 1 January 1993,
the country underwent a "velvet divorce" into its two national
components, the Czech Republic and Slovakia. The Czech Republic
joined NATO in 1999 and the European Union in 2004.','8754572f6cc3c39ed08d5b47c46e94955071e5053c0cf299b738c05442beb651','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81d9a826ed768445214071ec7be7b8cd33288e767adb37e0870f2e9bf96fdb78',2010,'DK','Denmark','environment',786,'Once the seat of Viking raiders and later a major north
European power, Denmark has evolved into a modern, prosperous nation
that is participating in the general political and economic
integration of Europe. It joined NATO in 1949 and the EEC (now the
EU) in 1973. However, the country has opted out of certain elements
of the European Union''s Maastricht Treaty, including the European
Economic and Monetary Union (EMU), European defense cooperation, and
issues concerning certain justice and home affairs.
Dhekelia
By terms of the 1960 Treaty of Establishment that created
the independent Republic of Cyprus, the UK retained full sovereignty
and jurisdiction over two areas of almost 254 square kilometers -
Akrotiri and Dhekelia. The larger of these is the Dhekelia Sovereign
Base Area, which is also referred to as the Eastern Sovereign Base
Area.','27006cb67b6c427cc87249989397da76c94a8d40c193c5086d934fb052b5280c','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bbcf5f21b083166666ff411597e02b2b114a4ff732d547513d52449edcfac04',2010,'DJ','Djibouti','environment',787,'The French Territory of the Afars and the Issas became
Djibouti in 1977. Hassan Gouled APTIDON installed an authoritarian
one-party state and proceeded to serve as president until 1999.
Unrest among the Afars minority during the 1990s led to a civil war
that ended in 2001 following the conclusion of a peace accord
between Afar rebels and the Issa-dominated government. In 1999,
Djibouti''s first multi-party presidential elections resulted in the
election of Ismail Omar GUELLEH; he was re-elected to a second term
in 2005. Djibouti occupies a strategic geographic location at the
mouth of the Red Sea and serves as an important transshipment
location for goods entering and leaving the east African highlands.
The present leadership favors close ties to France, which maintains
a significant military presence in the country but also has strong
ties with the US. Djibouti hosts the only US military base in
sub-Saharan Africa and is a front-line state in the global war on','a48bccce10f7b5f59c730addcd6b31a4789d2599c60ac502ce29870e09f4ff14','internet-archive','theciaworldfactb35830gut','txt','d59adc87729754e36363556f23ba83db59147dfa276545a676f1c061898588a6','https://archive.org/download/theciaworldfactb35830gut/35830.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

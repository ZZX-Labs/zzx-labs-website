SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25dc68b71e057edbed61b75405eafecd0a4a8cc8e5d9ee9ed78d175a79d2a4e6',1977,'AF','Afghanistan','communications',7,'Railroads: 0.6 km (single track) 1.524-meter gage,
government-owned spur of Soviet line
Highways: 20,885 km (1975); 2,460 km paved,
3,910 km gravel, 8,735 km improved earth, and 5,780
km unimproved earth
Inland waterways: total navigability 1,200 km;
steamers use Amu Darya
Ports: only minor river ports
Civil air: 6 major transport aircraft
Airfields: 38 total, 36 usable; 9 with permanent-
surface runways; 6 with runways 2,440-3,659 m, 11
with runways 1,220-2,489 m
Telecommunications: limited telephone, tele-
graph, and radiobroadcast services; television to be
introduced by 1978; 26,000 telephones; 112,000 radio
receivers, no TV receivers; 2 AM, no FM, no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 4.9
million; 2.6 million fit for military service; about
177,000 reach military age (22) annually
Supply: dependent on foreign sources, almost
exclusively the U.S.S.R.','c6eda8b36e5b0e68e40b0bf62cadb36b67fcfbdf4acde528824f5a3024fcc789','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3630ad15400c1929f83848c1edb053c0dd5183df669337ddc80db2b82ced1b5',1977,'AL','Albania','communications',8,'“Mediterranean Sea
{See reference map {V}
LAND
28,749 km?; 19% arable, 24% other agricultural,
43% forested, 14% other
Land boundaries: 716 km
WATER
Limits of territorial waters (claimed): 15 nm
Coastline: 418 km (including Sazan Island)
Approved For Release 2005/04/22 :
Railroads: 277 km standard gage (1.435 m), single
track, government-owned (1975)
Highways: 4,989 km; 1,287 km paved, 1,609 km
crushed stone and/or gravel, 2,093 km improved or
unimproved earth (1975)
Inland waterways: 43 km plus Albanian sections of
Lake Scutari, Lake Ohrid, and Lake Prespa (1976)
Freight carried: rail—2.8 million metric tons, 180
million metric ton/km (1971); highways—39 million
metric tons, 900 million metric ton/km (1971)
Ports: 2 major (Durres, Vlore), 2 minor (1976)
Pipelines: crude oil, 117 km; natural gas, 64 km
Civil air: no major transport aircraft (1976)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1976, 783 million leks; about 9%
of total budget','6aa07a8bd49748564e82d86fd7b2eac693af9f4a19d0d6728167f558cb9c97da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ad81de98ba75831c7c797b50b792f2a87e27a6f33f1408300db1aa7e14f3c76',1977,'DZ','Algeria','communications',12,'LAND
2,460,500 km?; 3% cultivated, 16% pasture and
meadows, 1% forested, 80% desert, waste, or urban
Land boundaries: 6,260 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,183 km
Railroads: 5,180 km; 3,951 km standard gage
(1.485 m), 1,083 km 1.055-meter gage, 146 km meter
gage (1.00 m); 302 km electrified; 198 km double
track
Highways: 78,367 km; 45,043 km concrete or
bituminous, 33,324 km gravel, crushed stone or
improved earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 3,983 km; refined products,
298 km; natural gas, 2,969-km
Civil air: 80 major transport aircraft
Airfields: 186 total, 184 usable; 55 with
permanent-surface runways; 22 with runways 2,440-
8,659 m; 108 with runways 1,220-2,439 m; 3 seaplane
stations
Telecommunications: adequate domestic and
international facilities in the north, primarily radio
communications in the desert; satellite ground
stations; 229,700 telephones; 1,150,000 radio
receivers; 500,000 TV receivers; 15 AM and 39 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 4,111,000;
2,427,000 fit for military service; average number
reaching military age (19) annually 163,000
Military budget: for fiscal year ending 31
December 1976, $309,392,000; 5.5% of national
budget
a€ape Verde qe : : : Port Sudan, Red
a
og!
Praia é
Mits''iwal
Asrherat”
Khartoum,
Bissau- &
Conakr
Freetown c)
Sierra
Leone
Monrovia
Eq. Guinea : oF ao ee os j Mogadiscio
Sao Tome and sonal A S
Principe ee
Eq. Guinea’
Zair
2h Bujumburak gp : Seychelles -
Kinshasa Victorta: .
South','53560bf6b1b44d190b05515c95610a12fde43b1cf164e7022a03932d57795735','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81447fee734d2fe19ee9e90973c08b064c874c3605edddd7cecf72d779e0c132',1977,'AD','Andorra','communications',16,'Atlantic.
Ocean
Mediterranean
eee
(See reference map iV}
LAND
466 km?
Land boundaries: 105 km
Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to
Spain and France; 2 AM stations, 1 FM, 1 TV station;
about 3,700 telephones; 8,000 radio receivers, 3,000
TV receivers
DEFENSE FORCES
Andorra has no defense forces; Spain and France
are responsible for protection as needed','c558e40235896fe05bb1686ed18191e4b4266251db2c01b31dc583c10bccb0e4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('500ad27ae2a60f9c3af2b5e2ca18534bc3dd87d96f74160984f6936f9c4a9170',1977,'AO','Angola','communications',20,'LAND
1,245,790 km?; 1% cultivated, 44% forested, 22%
meadows and pastures, 33% other (including fallow)
Land boundaries: 5,070 km
Approved For Release 2005/04/22 :
~ Cabinda’
-. dwanda
Atlantic
Ocean
(See reference map Vi)
WATER
Limits of territorial waters (claimed): 6 nm
(fishing 200 nm)
Coastline: 1,000 mi.
Railroads: 3,069 km; 2,758 km 1.067-meter gage,
310 km 0.600-meter gage
Highways: 73,828 km; 8,577 km_ bituminous-
surface treatment, 28,723 km crushed stone, gravel, or
improved earth, remainder unimproved earth
Inland waterways: 3,220 km navigable
Ports: 3 major (Luanda, Lobito, Mocamedes), 15
minor
Pipelines: crude oil, 179 km
Civil air: 15 major transport aircraft
Airfields: 575 total, 498 usable; 25 with
permanent-surface runways; 1 with runway over
8,660 m, 7 with runways 2,440-3,659 m, 78 with
runways 1,220-2,439 m
Telecommunications: network of open-wire and
radio-relay facilities; satellite ground station; 37,500
telephones; 116,000 radio receivers; 24 AM, 11 FM,
and no TV stations
DEFENSE FORCES
Military manpower: data not available
ANTIGUA
. (See reference map )
LAND
280 km?; 54% arable, 5% pasture, 14% forested, 9%
unused but potentially productive, 18% wasteland
and built on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 153 km
Railroads: 78 km narrow gage (0.760 m), employed
almost exclusively for handling cane
Highways: 380 km; 240 km main, 140 km
secondary
Ports: 1 major (St. John’s), 1 minor
Approved For Release 2005/04/22 :
Civil air: 8 major transport aircraft
Airfields: 8 total, 3 usable; 1 with asphalt runway
2,745 m; 2 seaplane stations
Telecommunications: automatic telephone sys-
tem; 3,350 telephones; tropospheric scatter links with
Tortola and St. Lucia; 22,000 radio receivers, 12,300
TV sets; 2 AM stations, 1 FM and 1 TV station; 1
coaxial submarine cable','e85d296d196d7f48d70d8ecda24bc3b5f0b53547d76c28e3646c1140529b1828','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b766ad4f1ff7568f12605c4bb426bddc9b528d3c7969bf980c151fe44c9bc3da',1977,'AR','Argentina','communications',24,'Buenos Aires *
ee since man fp
LAND
2,771,800 km?,; 57% agricultural (11% crops,
improved pasture and fallow, 46% natural grazing
land), 25% forested, 18% mountain, urban, or waste
Land boundaries: 9,414 km
WATER
Limits of territorial waters (claimed): 200 nm
(continental shelf, including sovereignty over
superjacent waters)
Coastline: 4,989 km
Railroads: 38,971 km; 3,200 km standard gage
(1.485 m), 22,000 km broad gage (1.676 m), 13,443
km meter gage (1.00 m), 120 km 0.75-meter gage, 208
km 0.600-meter gage; about 1,656 km double and
multiple track; 122 km electrified
Highways: 290,200 km, of which 39,500 km paved,
74,900 km gravel, 175,800 km improved earth
Inland waterways: 11,000 km navigable
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ARGENTINA/AUSTRALIA
Ports: 7 major, 21 minor
Pipelines: 4,090 km crude oil; 2,200 km refined
products; 8,120 km natural gas
Civil air: 46 major transport aircraft, includes 1
leased from a foreign country
Airfields: 2,345 total, 2,146 usable; 89 with
permanent-surface runways; 20 with runways 2,440-
3,659 m, 304 with runways 1,220-2,489 m; 6 seaplane
stations
Telecommunications: extensive modern system;
telephone network has 2,647,000 sets, radio relay
widely used, 2 (COMSAT) ground stations; estimated
12 million radio receivers and 4 million TV sets; 145
AM, 12 FM, and 64 TY stations
DEFENSE FORCES
Military manpower: males 15-49, 6,464,000;
5,210,000 fit for military service; average number
reaching military age (20) annually about 217,000
Military budget: proposed for fiscal year ending 31
December 1976, $822.7 million; about 9.5% of total
central government budget
e Bahia. ~~
‘Blanca
=.
1000 Miles
1000 Kilometers
on Falkland Is.
SEE isias Malvinas)
(Admin. by U.K,
claimed by
Argentina)
South Georgia
‘
(UK) 9
DOUNDARY REPRESENTATION iS
NOT NECESSARILY AUTHORITATIVE
502849 1-77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Iv Europe
400 Miles
400 Kilometers
vo jan Mayen
{Nor.
Norwegian
*
Reykjavik ee : ay . “sg Arkangel’sk
iceland Sea Cotfle cit ! \\, re
ated ie ; ay
: a 7
¥ alnesls Finland ‘o
a g 5
+ Norway - ANT
g elsinki, 4. i)
North deciles ite We "Leningrad
Bergen i “Oslo,
+ Moscow
Norih
Atlantic qvitoyus U.S.S.R
eMinsk
*','d48a2b42069436cf7b2f00e334bedd931e69042b5ede486d7f9770fc6dbc145a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccbd02e52e091f589b020a67747c6ffa66e6571d76554cf088391eabf00fa48e',1977,'AU','Australia','communications',28,'(See reference map Vill}
LAND
7,692,300 km?; 6% arable, 58% pasture, 2%
forested, 34% other
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm; prawn and crayfish on continental
shelf)
Coastline: about 25,760 km
Railroads: none
Highways: 199 km; 143 km bituminous, 56 km
crushed stone or earth
Ports: 1 small port (Victoria)
Civil air; no major transport aircraft
Airfields: 4 total, 4 usable on (Praslin Island,
Astove Island, Bird Island, Mahe Island) 1 permanent
surface 2,440-3,659 m
Telecommunications: direct radiocommunications
with adjacent islands and African coastal countries;
2,860 telephones; 16,000 radio, and no TV sets; 2 AM,
no FM, and no TV stations; submarine cables to
Aden, Tanzania, and Sri Lanka
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 7,000 fit
for military service
(Port) U.K)
Brunei
. Java Sea
Nt
Java RE 9 So CY Sot
< ed
>
INDIAN
OCEAN
503196 1-77
‘indonesia
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
eae
''/ Taiwan
NS
i acdao vd Mong Kong
MARIANA .
ISLANDS ©
Saipan
Guam ws.) ¢
Trust Territory of the Pacific islands
Yap’ “(.S.)
Mindanao = ; : ee
~ PALAU] ten aes jira “
ISLANDS , sfands.:,
AROLINE
Ponape .
” ISLANDS
gS:
Yen
g
8K.
—
Ly tan’.
ae trian Jaya
o eee
: 2
Port\\—__
Arafura Sea Moresby 2 A Guadalcanal
ae ee ™
\\
pe 7 New Guinea ‘
=
Papua
>)
EQ FSR
Banda Sea
Se. New Ireland
Bismarck Sea
Ne
4 . 1 Bougainville
SS Choiseul
et ta OISeu!
on ° Honiar.
cS
(Angle French Coadsmimum) 3
New
_ Caledonia’,','e2c92beeb6e9dbc33c992e7531468b0f1de226c1034f3d638049376e36d1c144','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54c53761a41713e86dbfa947e3f558369b308852007794bab83e7241722d8cfc',1977,'GN','Guinea','communications',33,'Railroads: 40,636 km; 9,197 km 1.60-meter gage,
18,894 km standard gage (1.435 m), 18,045 km 1.067-
meter gage; 800 km electrified (June 1962);
government-owned (except for few hundred kilo-
meters of privately owned track)
Highways: 863,767 km (1974); 208,227 km paved,
209,885 km gravel, crushed stone, or stabilized soil
surface, 445,655 km unimproved earth
Inland waterways: 8,368 km; mainly by small,
shallow-draft craft
Freight carried: rail—154.4 million metric tons
Ports: 12 major, numerous minor
Pipelines: crude oil, 740 km; refined products, 340
km; natural gas, 6,947 km
Civil air; 122 major transport aircraft
Airfields: 1,735 total, 1,644 usable; 195 with
permanent-surface runways, 2 with runways over
8,660 m; 17 with runways 2,440-3,659 m, 649 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: very good international and
domestic service; 5 million telephones; 14 million
radio receivers; 3.7 million TV receivers; 96 AM
stations, no FM station, 120 TV stations and 66
10
b
repeaters; 3 earth satellite stations; submarine cables
to New Zealand, New Guinea, Singapore, Malaysia,
Hong Kong, and Guam
DEFENSE FORCES
Military manpower: males 15-49, 3,281,000;
2,895,000 fit for military service; 124,000 reach
military age (17) annually
Military budget: for fiscal year ending 30 June
1977, $2.7 billion; about 9% of total central
government budget
o
(See reference map Vi)
LAND
295,154 km?, 4% cultivated, 18% grazing, 13%
fallow, 50% forest, 15% other
Land boundaries: 4,554 km
WATER
Limits of territorial waters (claimed): 18 nm
Coastline: 402 km
Railroads: 1,003 km; 858 km meter gage (1.00 m),
145 km 0.600-meter gage
Highways: approximately 13,755 km; including
1,231 km bituminous, 12,522 km gravel and earth
Inland waterways: 2,090 km
Ports: | major (Douala), 3 minor
Civil air: 6 major transport aircraft
Airfields: 63 total, 60 usable; 7 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 21
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: good telephone service; fair
to good telegraph service; 21,900 telephones; 232,000
radio receivers; 4 AM, no FM, and no TV stations; 1
submarine cable; radio-relay Yaounde to Fort
Foureau; satellite ground station at Yaounde
DEFENSE FORCES
Military manpower: males 15-49, 1,490,000;
741,000 fit for military service; average number
reaching military age (18) annually about 64,000
Military budget: for fiscal year ending 30 June
1977, $51,474,621; 9.5% of central government
budget
LAND
246,050 km?; 3% cropland, 10% forest
Land boundaries: 3,476 km
WATER
Limits of territorial waters (claimed): 130 nm
Coastline: 346 km
Railroads: 805 km meter gage (1.00 m), 8 km
standard gage
Highways: 7,604 km; 4,949 km paved, remainder
unimproved earth
Inland waterways: 1,795 km; 500 km navigable by
small oceangoing vessels, 1,295 km navigable by
shallow-draft steamers and barges
Ports: 1 major (Conakry), 3 minor
Civil air: 7 major transport aircraft
Airfields: 17 total, 17 usable; 4 with permanent-
surface runways; 3 with runways 2,440-3,659 m, 10
with runways 1,220-2,439 m; 3 seaplane landing areas
Telecommunications: inadequate system of open-
wire lines, small radiocommunication stations, and 1
radio-relay link; principal center Conakry, secondary
center Kankan; 8,300 telephones; 110,000 radio
receivers; 1 AM station, no FM, and no TV stations; 2
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 958,000; 485,000
fit for military service
Military budget: for fiscal year ending 30
September 1970 (latest information available),
$6,073,000; 8.0% of central government budget
86
Atlantic Ocean
(See reference map vi)
LAND
323,750 km?; 40% forest and woodland, 8%
cultivated, 52% grazing, fallow, and waste, 200 mi. of
lagoons and connecting canals along eastern coast
Land boundaries: 3,227 km
WATER
Limits of territorial waters (claimed): 6 nm
(fishing 12 nm)
Coastline: 515 km
Railroads: 657 km of the 1,173 km Abidjan to
Ouagadougou, Upper Volta line, all single track meter
gage (1.00 m); only diesel locomotives in use
Highways: 34,497 km; 1,628 km bituminous and
bituminous-surface treatment; 12,163 km gravel,
crushed stone, laterite, and improved earth;
remainder unimproved earth roads
Inland waterways: 740 km navigable rivers and
numerous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 3 minor
Civil air: 16 major transport aircraft
Airfields: 46 total, 44 usable; 3 with permanent-
surface runways; 2 with runways 2,440-3,659 m; 6
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: system only slightly above
African average; consists of open-wire lines and radio
relay links, which provide incomplete coverage of
country; Abidjan is only center; 25,200 telephones;
206,000 radio and 100,500 TV receivers; 2 AM, no
FM, and 4 TV stations; 1 submarine cable; satellite
earth station
DEFENSE FORCES
Military manpower: males 15-49, 1,161,000;
599,000 fit for military service; 50,000 males reach
military age (18) annually
106
Approved For Release 2005/04/22','45cada885139d1836d935d10835627979af79ded7adb5cc5f4faa38912ea83fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d877cd44447d0c97d6987ef2d3e313a9901b39e5227f8ab543a4af78ad736efe',1977,'AT','Austria','communications',34,'Vienna,
AUSTRIA og
(See reference map IV}
LAND
83,916 km?; 20% cultivated, 26% meadows and
pastures, 15% waste or urban, 38% forested, 1%
inland water
Land boundaries: 2,582 km
Railroads: 6,517 km; 5,877 km government-
owned; 5,397 km standard gage (1.435 m) of which
2,384 km electrified and 1,383 km double tracked;
480 km narrow gage (0.760 m) of which 91 km
electrified; 640 km privately owned (1.435- and 1.00-
meter gage)
Highways: approximately 33,600 km total national
classified network, including 10,400 km federal and
23,200 km provincial roads; about 20,800 km paved
(bituminous, concrete, stone block) and 12,800 km
unpaved (gravel, crushed stone, stabilized soil);
additional 60,800 km communal roads (mostly gravel,
crushed stone, earth)
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km natural gas;
171 km refined products
Civil air; 18 major transport aircraft, including 1
registered but leased from a foreign country
Airfields: 54 total, 50 usable; 13 with permanent-
surface runways; 3 with runways 2,440-3,659 m, 7
with runways 1,220-2,439 m
Telecommunications: highly developed and
efficient; extensive TV and radiobroadcast systems
with 88 AM, 94 FM, and 289 TV stations; 2.21
million telephones; 2.69 million radio receivers; 2.05
million television receivers; COMSAT station is
planned
ll
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
AUSTRIA/THE BAHAMAS
DEFENSE FORCES
Military manpower: males 15-49, 1,717,000;
1,380,000 fit for military service; average number
reaching military age (19) annually about 57,000
Military budget: for fiscal year ending 31
December 1976, $447 million; about 3.8% of the
federal budget
THE BAHAMAS
DOMINICAN
REPUBLIC |
(See reference map it}
LAND
11,896 km?; 1% cultivated, 29% forested, 70% built
on, wasteland, and other
WATER
Limits of territorial waters (claimed): 8 nm
(fishing, 12 nm)
Coastline: 3,542 km (New Providence Is. 76 km)
Railroads: none
Highways: 2,100 km total; 850 km paved, 1,250
km gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 11 major transport aircraft
Airfields: 54 total, 50 usable; 8 with permanent-
surface runways; 3 with runways 2,440-3,659 m, 22
with runways 1,220-2,439 m; 4 seaplane stations
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
THE BAHAMAS/BAHRAIN
Telecommunications: telecom facilities highly
developed, including 59,300 telephones in totally
automatic system; tropospheric scatter link with
Florida; 85,000 radio receivers and 80,000 TV sets, 3
AM and 2 FM stations; 3 coaxial submarine cables
: : Arabian
as — ss Sea
(See reference map ¥)
LAND
596 km? plus group of 32 smaller islands; 5%
cultivated, negligible forested area, remainder desert,
waste, or urban
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Highways: 193 km bituminous surfaced; un-
determined mileage of natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 56 km; refined products, 16
km; natural gas, 32 km
Civil air: 15 major transport aircraft (all registered
in Oman)
Airfields: 2 total, 1 usable; 1 with permanent-
surface runway; 1 with runway over 3,660 m; 1
seaplane station
13
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BAHRAIN/BANGLADESH
Telecommunications: excellent international
telecommunications; limited domestic services;
22,000 telephones; 85,000 radio receivers; 30,000 TV
sets; 1 AM radiobroadcast station; satellite earth
station; tropospheric scatter Bahrain to Qatar and','fc69d75cfdacf9be86a88763d7058b6712b10886fd04623a9d3638a63926760e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2b61452dc0d3ff35215c8c9a460a577b28c4fd3aa866fa39f11aacb15b2e644',1977,'AE','United Arab Emirates','communications',38,'DEFENSE FORCES
Military manpower: males 15-49, 63,000; fit for
military service 36,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31
December 1976; $20.22 million, 4.2% of total budget
LAND
82,880 km?;. almost all desert, waste or urban
212
Abu Dhabi
NITED ARABS. 22>
EMIRATES =
(See reference map Vill}
Land boundaries: 1,094 km (does not include
boundaries between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 nm for all
states except Sharjah (12 nm)
Coastline: 1,448 km
Railroads: none
Highways: 282 km bituminous, undetermined
mileage of earth tracks
Pipelines: 282 km crude oil
Ports: 5 major, 8 minor
conversion rate: 1 U.A.E, Dir-
Civil air: 3 major transport aircraft
Airfields: 56 total, 48 usable; 11 with permanent-
surface runways; 3 with runways over 3,660 m, 1 with
runways 2,440-3,659 m, 12 with runways 1;220-
2,439 m
Telecommunications: system is adequate; key
centers are Abu Zaby and Dubayy; 34,300 telephones;
52,000 radio and 25,000 TV receivers; 38 AM, 1 FM,
and 2 TV stations','8984df1d3d962b70c256df8b4380b5d2abcf2e633e3cd5362e6801274fc166d5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e69bddb3c8fb909608b93ad91ead1e124daf9671b6e605a3c0a904a6462dcfea',1977,'BD','Bangladesh','communications',39,'(See reference map Vit)
LAND
142,500 km?; 66% arable (including cultivated and
fallow), 18% not available for cultivation, 16%
forested
Land boundaries: 2,535 km
WATER
Limits of territorial waters (claimed): 12 nm;
fishing, 200 nm
Coastline: 580 km
Railroads: 3,470 km; 2,483 km meter gage (1.00
m), 953 km broad gage (1.676 m), 35 km narrow gage
(0.762 m), 290 km double track; government-owned
Highways: 44,930 km; 4,044 km paved, 2,022 km
gravel, 38,864 km earth
Inland waterways: 7,000 km; river steamers
navigate main waterways
Ports: 1 major; 5 minor
Pipelines: 150 km natural gas
Civil air: 9 major transport aircraft
Airfields: 24 total, 17 usable; 18 with permanent
surface runways; 3 with runways 2,440-3,659 m, 8
with runways 1,220-2,439 m
Telecommunications: inadequate international
radiocommunications and landline service; fair
domestic wire and microwave service; fair broadcast
service; 70,000 (est.) telephones; 500,000 radio sets;
20,000 (est.) TV sets; 10 AM, 1 FM, 2 TV stations,
and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 18,138,000;
8,565,000 fit for military service
Military budget: for fiscal year ending 80 June
1977, $103.4 million; about 3.5% of the central
government budget','ced903abfb793042a849b928e65166a5b636681b130cc85bf2b2228566e48015','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93040cba64ad5e0d02c5977cdd27584984c2e59841b1074fde19241a282cff1f',1977,'BB','Barbados','communications',43,'DOMINICAN
» REPUBLIC
: Atlantic
{>- ‘ Ocean
PUERTO”
RICO
%
(See reference map tt)
LAND
430 km?; 60% cropped, 10% permanent meadows,
30% built on, waste, other
Approved For Release 2005/04/22
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 97 km
Railroads: none
Highways: 1,370 km; 1,290 km paved, and 80 km
gravel, and earth
Ports: 1 major (Bridgetown), 2 minor
Civil air: 5 major transport aircraft
Airfields: 1 with permanent-surface runway 2,440-
3,659 m; 1 seaplane station
Telecommunications: islandwide automatic
telephone system with 43,000 telephones; tropo-
spheric scatter link to Trinidad; UHF/VHF links to
St. Vincent and St. Lucia; 130,000 radio and 40,000
TV sets, 2 AM stations, 1 FM, 1 TV station; 2
telegraph submarine cables; COMSAT ground station
DEFENSE FORCES
Military manpower: males 15-49, 51,000; 37,000
fit for military service; average number reaching
military age, (18) annually, 3,000; no conscription','5498b0118bbca8505ea80b779b24de1801bc69de8a28c634620844103b06e453','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33cb0fdca5aa09669b89de2e75f9ab76a7712b32e3fc3fc5d55b6dbdb0480757',1977,'BE','Belgium','communications',47,'LAND
80,562 km’; 28% cultivated, 24% meadow and
pasture, 28% waste, urban, or other; 20% forested
Land boundaries: 1,377 km
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: 64 km
Railroads: 4,394 km; 4,117 km standard gage
(1.435 m) and government-owned, 2,536 km double
track, 1,224 km electrified; 277 km privately owned,
electrified meter gage (1.00 m)
Highways: approximately 104,000 km, including
1,040 km limited access divided “Autoroute”
Inland waterways: 2,043 km, of which 1,528 km
are in regular use by commercial transport
Ports: 5 major, 1 minor
Pipelines: refined products, 965 km; crude, 161
km; natural gas, 3,218 km
Civil air: 54 major transport aircraft
Airfields: 44 total, 48 usable; 23 with permanent-
surface runways; 13 with runways 2,440-3,659 m, 6
with runways 1,220-2,439 m
Telecommunications: excellent domestic and
international telephone and telegraph facilities; 2.92
million telephones; 3.86 million radio receivers; 2.55
million TV receivers; 7 AM, 12 FM, and 20 TV
stations; 5 coaxial submarine cables; 1 communica-
tions satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,239,000;
1,796,000 fit for military service; average number
reaching military age (19) annually 75,000
Military budget: proposed for fiscal year ending 31
December 1976, $2,083 million; about 9.6% of
proposed central government budget','f193233a296f5fb18bc80ecddcc17c8684f684f9c9928deefdeccd74e18209a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('880a96ce2a8aa795532005c6c6fc75265e8a684450da0725537c57c0b8a3197b',1977,'BZ','Belize','communications',51,'(formerly British Honduras)
LAND
22,973 km?; 38% agricultural (5% cultivated), 46%
exploitable forest, 16% urban, waste, water, offshore
islands or other
17
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Gulf of 5
Mexico .
Caribbean
Sea
x Belmopan
Pacific
Ocean |
(See reference map fH}
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 386 km
Railroads: none
Highways: 2,240 km; 280 km paved, 795 km
gravel, 900 km improved earth and 265 km
unimproved earth
Inland waterways: 800 km river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: no major transport aircraft
Airfields: 36 total, 36 usable; 4 with permanent-
surface runways; 1 with runway 1,220-2,439 m; 1
seaplane station
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BELIZE/BENIN
Telecommunications: 5,700 telephones in auto-
matic and manual network; radio-relay system;
68,000 radio receivers; 8 AM stations
DEFENSE FORCES
Military manpower: males 15-49, 31,000; 19,000
fit for military service; 1,500 reach military age (18)
annually :','d91a7049ea18325f220b78c25052e2b4ba84feb4d08108c902232d97da4c6f5e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6380f33991233811eb042b4944744182310953889116e5d7d420bf9557fb755',1977,'BJ','Benin','communications',55,'(formerly Dahomey)
> Gulf of Guinea
(See referen
LAND
115,773 km?; southern third of country is most
fertile; arable land 80% (actually cultivated 11%),
forests and game preserves 19%, non-arable 1%
Land boundaries: 1,963 km
WATER
Limits of territorial waters (claimed): 12 nm (100
nm mineral exploitation limit)
Coastline: 121 km
Railroads: 579 km, all meter gage (1.00 m)
Highways: 6,938 km; 844 km paved, 1,872
km gravel and/or improved earth, remainder
unimproved
Inland waterways: 645 km navigable
Ports: 1 major (Cotonou), 1 minor
Civil air: no major transport aircraft
Airfields: 10 total, 10 usable; 1 with permament-
surface runway; 4 with runways 1,220-2,439 m
Telecommunications: system of open wire and
radio relay; 9,625 telephones; 54,000 radio receivers; 2
AM, no FM, and no TV stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 735,000; 369,000
fit for military service; about 82,000 males and 31,000
females reach military age (18) annually; both sexes
liable for military service
Supply: dependent on France and Guinea; aid
from North Korea and PRC is pending
Military budget: for fiscal year ending 31
December 1976, $7.4 million; about 11% of central
government budget','b782248dbeef6e709b282fe1c1aa52079de7360104a0259df2231a79a0b2c3d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf3d4595472d463321614d6e87fa15b1737d787b79f87a2cf0dea49777bd1886',1977,'BM','Bermuda','communications',59,'(See reference map fl)
LAND
54.4 km?; 8% arable, 60% forested, 21% built on,
wasteland, and other, 11% leased for air and naval
bases
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 103 km
20
Railroads: none
Highways: 190 km, all paved
Ports: 3 major (Hamilton, St. George Freeport,
Ireland Island)
Civil air: no major transport aircraft
Airfields: 1 with concrete runway 2,960 m; 1
seaplane station
Telecommunications: modern telecom system,
includes fully automatic telephone system with 38,100
sets; 50,000 radio and 22,000 TV receivers, 2 AM, 2
FM, and 2 TV stations; 3 coaxial submarine cables','2547dbb9d9ef8351d37e0a2519ccb91db609d2da7e7e3cc2c49201fd1e1b623d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cab07b0206d57613e60e12e2d2b3fda3d2460217437dece126194506f95bdcb',1977,'BT','Bhutan','communications',63,'Bay of
Bengal
(Ses reference map Vil)
LAND
46,600 km?; mi; 15% agricultural, 15% desert,
waste, urban, 70% forested
Land boundaries: about 870 km','93f55de9ecc06dbe2fc42d3151d1690a2c06b9a1f277d8b048589498ad9966c1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14ec81678568d64def5f72949d04d2052be567893da12f9589c9277e81a56c1b',1977,'IN','India','communications',68,'Highways: 1,304 km; 418 km surfaced, 515 km
improved, 371 km unimproved earth
Freight carried: not available, very light traffic
Civil air; no major transport aircraft
Airfields: 2 total, 1 asphalt runway 1,372 m, and 1
with concrete runway 899 m
Telecommunications: facilities inadequate; 600
telephones; 6,000 est. radio sets; no TV sets; 1 AM and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 287,000; 153,000
fit for military service; about 9,000 reach military age
(18) annually
Supply: dependent on India
21
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BOLIVIA
BOLIVIA
ipesgaae =
Pacific
Ocean.
(See reference map sil}
LAND
1,098,160 km?; 2% cultivated and fallow, 11%
pasture and meadow, 45% urban, desert, waste, or
other, 40% forest, 2% inland water
Land boundaries: 6,083 km
Railroads: 3,572 km single track, 3,540 km meter
gage (1.00 m), 32 km 0.760-meter gage; 96 km meter
gage (1.00 m) privately owned
Highways: 37,300 km; 1,150 km paved, 6,550 km
gravel, 5,950 km improved earth, 23,650 km
unimproved earth
Inland waterways: officially estimated to be
10,000 km of commercially navigable waterways
Pipelines: crude oil, 1,670 km; refined products
1,495 km; natural gas 560 km
Ports: none (Bolivian cargo moved through Arica
and Antofagasta, Chile, and Matarani, Peru)
Civil air: 49 major transport aircraft
Airfields: 572 total, 533 usable; 4 with permanent-
surface runways; 1 with runway over 3,660 m, 5 with
runways 2,440-3,659 m, 125 with runways 1,220-
2,439 m
Telecommunications: radio-relay system from La
Paz to Santa Cruz; improved international services;
55,000 telephones; est. 2.5 million radio and 45,000
TV receivers; 84 AM, 18 FM, and 3 TV stations;
COMSAT station planned
DEFENSE FORCES
Military manpower: males 15-49 1,289,000;
816,000 fit for military service; average number
reaching military age (19) annually about 59,000
LAND
3,136,500 km? (includes Indian part of Jammu-
Kashmir, Sikkim, Goa, Damao and Diu); 50% arable,
5% permanent meadows and pastures, 20% desert,
waste, or urban, 22% forested, 3% inland water
: CIA-RDP79-01051A000800010006-3
4
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
(See reference map Vil)
Land boundaries: 12,700 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing, 12 nm; additional 100 nm is fisheries
conservation zone, December 1968; archipelago
concept baselines)
Coastline: 7,000 km (includes offshore islands)
Railroads: 61,313 km; 25,550 km meter gage (1.00
m), 30,041 km broad gage (1.676 m), 4,476 km narrow
gage (0.762 m and 0,610 m), government owned; 46
km meter gage (1.00 m), 855 km broad gage (1.676
m), 345 km narrow gage (0.762 m and 0.610 m),
privately owned; 12,304 km double track; 10,160 km
electrified
Highways: 1,327,000 km; 415,000 km paved,
190,442 km gravel or crushed stone, 304,895
km improved earth, 416,663 km unimproved earth
Inland waterways: 14,300 km; 2,575 km navigable
by river steamers
Pipelines: crude oil, 1,432 km; refined products,
2,020 km; natural gas, 359 km
Ports: 8 major, 80 minor
Civil air: 98 major transport aircraft
Airfields: 370 total, 344 usable; 183 with
Permanent-surface runways; 2 with runways over
8,660 m, 52 with runways 2,440-3,659 m, 120 with
runways 1,220-2,439 m
Telecommunications: fair domestic telephone
service where available, good internal microwave
links; telegraph facilities widespread; AM broadcast
adequate; TV limited to Bombay and New Delhi:
international radio communications adequate;
1,690,000 telephones; 14,100,000 radio and 162,000
96
TV sets; about 165 AM stations at 80 locations, 7 TV
stations, 2 earth satellite stations; submarine cables
extend to Malaysia, Sri Lanka, and Aden
DEFENSE FORCES
Military manpower: males 15-49, 146,032,000;
85,916,000 fit for military service; about 6,800,000
reach military age (17) annually
Military budget: for fiscal year ending 31 March
1977, $2.8 billion; 20% of central government budget','c728b8582f6e7d61fdc2e9f84bb5b31c17c666c8b26c416b9f925fb8780b2ec8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3ce76f1b49717c48b413192454dc7ab9a9f60db2b6419b82abad081d25c77a3',1977,'BW','Botswana','communications',70,'LAND
569,800 km?; about 6% arable, less than 1% under
cultivation, mostly desert
Land boundaries: 3,774 km
Railroads: 640 km 1.065-meter gage
Highways: 21,000 km; 300 km paved; 1,350 km
crushed stone or gravel; remainder improved earth
and unimproved earth
Inland waterways: native craft only; of local
importance
Civil air: 8 major transport aircraft
Airfields: 82 total, 74 usable; 8 with permanent-
surface runways; 18 with runways 1,220-2,489 m
Telecommunications: the system is a minimal
combination of open-wire lines, radio-relay links, and
a few radiocommunication stations; Gaborone is the
center; 6,700 telephones; 57,000 radio receivers; 1
AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 164,000; 83,000
fit for military service; 8,000 reach military age (18)
annually','6f61cb506a9fa50dd83d45dadf958fef59d173f56804a7c8f9b3652899fdeaac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb288828dfc6e20f1c90e73b648c3ef6fd3358852a7e0bc1b41fd8b8d652d21c',1977,'BR','Brazil','communications',74,'LAND
8,521,100 km?; 4% cultivated, 18% pastures, 28%
built-on area, waste, and other, 60% forested
24
Atlantic
Brasilia
ed
{See reference map Hil)
Land boundaries: 13,076 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 7,491 km
Railroads: 31,896 km; 28,137 km meter gage (1.00
m), 3,336 km 1.60-meter gage, 194 km standard gage
(1.435 m), 229 km narrow gages; 2,593 km electrified
Highways: 1,312,700 km; 77,700 km_ paved,
1,235,000 km gravel or earth
Inland waterways: 50,000 km navigable
Ports: 6 major, 25 significant minor
Pipelines: crude oil, 1,365 km; refined products,
465 km; natural gas, 257 km
Civil air: 182 major transport aircraft
Airfields: 4,230 total, 4,175 usable; 152 with
permanent-surface runways; 15 with runways 2,440-
8,659 m, 403 with runways 1,220-2,439 m; 18
seaplane stations
Telecommunications: moderately good telecom
system; radio relay widely used; 5 communications
satellite ground stations; 3.34 million telephones; est.
32 million radio and 10.68 million TV receivers; 1,010
AM, 150 FM, and 167 TV stations; 6 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 24,844,000;
16,220,000 fit for military service; 1,250,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1976, $1,957 million; 9.5% of federal
budget
BRITISH SOLOMON ISLANDS
LAND
About 29,785 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 5,313 km
Railroad: none
Highways: 834 km; 241 km sealed or all-weather
Inland waterways: none
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 28 total, 22 usable; 1 with permanent
surface runway; 7 with runways 1,220-2,4389 m; 1
seaplane station
Telecommunications: 8 AM broadcast, no FM,
and no TV stations; 10,000 radio receivers, 1,544
telephones, no TY sets; international connections with
London, England, via cable broadcasts
BRUNEI
BRUNE!
Bandar. Seri Bagawap ga
(See reference map Vil)
LAND
5,776 km?; 3% cultivated; 22% industry, waste,
urban or other; 75% forested
Land boundaries: 381 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: 9.6 km narrow gage (0.610 m)
Highways: 1,207 km; 376 km paved (bituminous
treated), 402 km gravel or stone, 428 km unimproved
Inland waterways: 209 km; navigable by craft
drawing less than 1.2 meters
Ports: 2 minor (Bandar Seri Begawan, formerly
Brunei, and Kuala Belait)
Pipelines: crude oil, 135 km; refined products, 56
km; natural gas, 56 km; crude oil and natural gas, 241
km under construction
Civil air: 2 major transport aircraft
Airfields: 3 total, 8 usable; 2 with permanent-
surface runway; 1 with runway over 3,660 m; 2 with
runways 1,220-2,439 m
Telecommunications: service throughout country
is adequate for present needs; international service
good to adjacent Sabah and Sarawak; radiobroadcast
coverage good; 8,612 telephones; 20,500 radio and
12,000 est. TV sets; Radio Brunei broadcasts from 3
AM stations, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 38,000; 22,000
fit for military service; about 1,000 reach military age
(18) annually','4e9a61b285bbad9e1f6a96e144a9b533b436fe1344e2867b1192e8f450692071','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9ffab9854c91f97d89c9301f82c6a03a736c828ae39188de1ba85f85a3e195d',1977,'BG','Bulgaria','communications',78,'’ Black Sea
(See reference map IV)
LAND
111,852 km?; 41% arable, 11% other agricultural,
33% forested, 15% other
Land boundaries: 1,883 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 354 km
‘Railroads: 4,314 km; about 4,069 km standard
gage (1.485 m), 245 km narrow gage; 260 km double
track; 1,256 km electrified; government-owned (1975)
Highways: 32,000 km; 13,190 km paved, 7,552 km
crushed stone and gravel, 11,325 km earth (1974)
Inland waterways: 480 km (1976)
Freight carried: rail—78.8 million metric tons,
17.3 billion metric ton/km (1975); highway—223
million metric tons, 6.8 billion metric ton/km (1975);
waterway—4.3 million metric tons, 2.0 billion metric
ton/km (excl. int’]. transit traffic) (1974)
Ports: 2 major (Varna, Burgas), 5 minor (1976)
Civil air: 833 major transport aircraft (1976)
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1976, est. 507 million leva; about 6% of
total budget
BURMA
LAND
678,600 km?; 28% arable, of which 12% is
cultivated, 62% forest, 10% urban and other (1969)
Land boundaries: 5,850 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BURMA"
South
China Sea
nih
(See reference map Vil)
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,060 km
Railroads: 3,285 km; 3,172 km meter gage (1.00
m), 113 km narrow-gage industrial lines; 828 km
double track; government-owned
Highways: 27,000 km; 3,200 km bituminous,
17,700 km improved earth, gravel, 6,100 km
unimproved earth
Inland waterways: 12,800 km; 3,200 km navigable
by large commercial vessels
Ports: 4 major, 6 minor
Civil air: 17 major transport aircraft
Airfields: 80 total, 79 usable; 23 with permanent-
surface runways; 2 with runways 8,000-11,999 ft., 88
with runways 4,000-7,999 ft.
Telecommunications: provide minimum require-
ments for local intercity service; international service
is fair; radiobroadcast coverage is limited to the more
29
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BURMA/BURUNDI
populous areas; 29,411 telephones; 627,000 radio, and
no TV sets; 1 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military budget: (announced) for fiscal year
ending 81 March 1977; $144.5 million, comprising
5.5% of central government budget','f0150b1b4345e22b0b1e0ef268fd2f9574f9ce54018a4675747c95df3d0f38c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3c1b096f5ce60fd681072d3e5025ca5d59b18fd8afe4eb0a2a8709680395520',1977,'BI','Burundi','communications',83,'(See reference map Vi}
LAND
28,490 km?; about 37% arable (about 66%
cultivated), 23% pasture, 10% scrub and forest, 830%
other
Land boundaries: 974 km
Railroads: none
Highways: 5,954 km; 544 km_ bituminous,
remainder crushed stone, gravel, laterite, and
improved or unimproved earth
Inland waterways: Lake Tanganyika navigable for
lake steamers and barges, 1 minor lake port
Civil air: 4 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permanent-
surface runway; 1 with runway 2,440-3,659 m
Telecommunications: telegraph is principal
service, limited telephones; 4,800 telephones, 100,000
radio receivers; 2 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 932,000; 484,000
fit for military service; 48,000 reach military age (16)
annually
Ships: 3 high speed boats
Military budget: for fiscal year ending 31
December 1975, $8,556,000; about 23.4% of ordinary
budget','71efb3339977fe9ced102a64ef646c827ccdbc398a51dfdc25322bbec6b80739','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb33cc824d374ea0eebc273dc9137ce293b9dba35e84544bc77545193fd30e0d',1977,'KH','Cambodia','communications',87,'Gulf of
\\ Thailand: %
ES
(See reference mag Vi}
LAND
181,300 km?; 16% cultivated, 74% forested, 10%
built-on area, wasteland, and other
Land boundaries: 2,438 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: about 443 km
Railroads: 612 km meter gage (1.00 m);
government-owned
Highways: 13,036 km; 2,430 km bituminous, 7,033
km crushed stone, gravel, or improved earth; and
3,573 km unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all year to
craft drawing 0.6 meters; 282 km navigable to craft
drawing 1.8 meters
Ports: 2 major, 5 minor
Airfields: 60 total, 25 usable; 7 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 6
with runways 1,220-2,439 m; 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,798,000;
998,000 fit for military service; 78,000 reach military
age (18) annually
Military budget: unknown','5c35673c6ee3b729bc345467445682f47052e368e748dd89558e81d48eb2dcba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53f63a93dab47dfc2a531fd10019b243705ff7b9e51e9eaf941af9e54dcc1cd9',1977,'CA','Canada','communications',93,'LAND
9,971,500 km?*; 4% cultivated, 2% meadows and
pastures, 44% forested, 42% waste or urban, 8%
inland water
Land boundaries: 9,010 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing, 200 nm)
{See reference mag t}
Coastline: 90,908 km
Railroads: 70,904 km; 69,555 km standard gage
(1.485 m) (48 km electrified); 1,170 km 1.067-meter
gage (in Newfoundland); 179 km 0.914-meter gage
Highways: 829,308 km; 640,838 km surfaced
(189,798 km paved), 188,470 km earth
Inland waterways: 3,000 km
Pipelines: oil, 21,983 km total crude and refined;
natural gas, 74,740 km
Ports: 19 major, 8300 minor
Civil air: 596 major transport aircraft
Airfields: 1,783 total, 1,445 usable; 285 with
permanent-surface runways; 4 with runways over
3,660, 29 with runways 2,440-3,659 m, 283 with
runways 1,220-2,439 m; 58 seaplane stations
Telecommunications: excellent service provided by
modern telecom media; 13.54 million telephones;
22.0 million radiobroadcast receivers; 9.39 million TV
receivers; countrywide AM, FM, and TV coverage
including 630 AM, 80 FM, and 500 TV stations; 8
coaxial submarine cables; 8 major COMSAT stations
and 70 domestic COMSAT stations
DEFENSE FORCES
Military manpower: males 15-49, 5,691,000;
4,899,000 fit for military service; average number
reaching military age (17) annually 230,000
Military budget: proposed for fiscal year ending 31
March 1976, $3.4 billion: about 8.8% of proposed
central government budget
CAPE VERDE
LAND
4,040 km?, divided among 10 islands and several
islets
WATER
Limits of territorial waters: 100 nm
Coastline: 965 km
Ports; 1 major (Mindelo), 3 minor
Civil air: 2 major transport aircraft (registered in
Portugal)
Airfields: 6 total, 6 usable; 4 permanent surface
runways; 1 with runway 2,440-3,659 m, 4 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: interisland radio-relay
system, HF radio to mainland Portugal, about 1,600
telephones; 1 FM, 3 AM stations; 30,000 radio
receivers, 4 submarine cables (2 coaxial)
CENTRAL AFRICAN EMPIRE
(See reference map Vi}
LAND
626,780 km?; 10%-15% cultivated, 5% dense
forests, 80%-85% grazing, fallow, vacant arable land,
urban, waste
Land boundaries: 4,981 km
Railroads: none
Highways: 20,400 km; 190 km bituminous, 4,120
km gravel and/or crushed stone, 4,090 km improved
earth, remainder unimproved earth
Inland waterways: 7,080 km; traditional trade
carried on by means of dugouts on the extensive
system of rivers and streams; the Oubangui River
between Bangui and Brazzaville is navigable for
about 8 months a year, and short sections of the
Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July -
December) Oubangui navigable upstream from
Bangui as far as Quango
Ports: Bangui, Quango (river ports)
Civil air: 5 major transport aircraft
Airfields: 54 total, 48 usable; 3 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 18
with runways 1,220-2,439 m
Telecommunications: facilities are meager and
provide only barely sufficient services; network is
composed of low-capacity, low-powered radiocom-
munication stations and radio-relay links; single
center of Bangui has only international radio
connections; 5,100 telephones; 70,000 radio receivers;
1 AM, 1 FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 460,000; 237,000
fit for military service
Supply: mainly dependent on France, but has
received equipment from Israel, Italy, U.S.S.R.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','1f186933ff748584bb3c3a0d5841f4ca3eb9ded1079dbeb6cb6bb32eb0ad4be1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1ae260eead265e80e76a501679b9b381cf47f781d777242fb1717dad2198f7e',1977,'TD','Chad','communications',97,'{See raference map Vi)
LAND
1,284,640 km?; 17% arable, 35% pastureland, 2%
forest and scrub, 46% other uses and waste
Land boundaries: 5,987 km
Railroads: none
87
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CHAD/CHILE
Highways: 27,505 km; 242 km bituminous, 4,385
km gravel and laterite, and remainder unimproved
Inland waterways: approximately 2,090 km of
year-round navigability, increased to 4,830 km during
high-water period
Civil air: 4 major transport aircraft
Airfields: 67 total, 63 usable; 4 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 25
with runways 1,220-2,439 m
Telecommunications: fair system of radiocom-
munication stations only for intercity links; principal
center N’Djamena, secondary center Sarh; 5,480
telephones; 70,000 radio receivers; 1 AM, no FM, and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 985,000; 507,000
fit for military service; average number reaching
military age (20) annually about 40,000
Supply: dependent on France primarily
Military budget: for fiscal year ending 31
December 1976, $15.5 million; about 18% of total
budget','b4da8e352acdee58c822e95cf5309628911f1738e150006bba7f0df423822ed6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2c1040268a4a55d8b20f96c878c249663824b85c3a3b454438e00eec57bae3f',1977,'CL','Chile','communications',101,'Pacific
Atlantic
Ocean
(See reference map tit}
LAND
740,740 km?; 2% cultivated, 7% other arable, 15%
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 6,325 km
WATER
Limits of territorial waters (claimed): 8
nin (fishing 200 nm)
Coastline: 6,435 km
38
Railroads: 8,817 km; 3,337 km 1.676-meter gage,
246 km standard gage (1.435 m), 4,230 km meter gage
(1.00 m), 110 km narrow gage (0.760 m), 35 km 0.600-
15 pesos= US$1
Approved For Release 2005/04/22 :
meter gage, 857 km, specific gage not given; 318 km
double track; 1,187 km electrified
Highways: 63,750 km; 8,900 km paved, 31,800 km
gravel, 23,050 km improved and unimproved earth
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined products, 785
km; natural gas, 320 km
Ports: 10 major, 20 minor
Civil air: 44 major transport aircraft
Airfields: 353 total, 853 usable; 43 with
permanent-surface runways; 6 with runways 2,440-
3,659 m, 54 with runways 1,220-2,439 m; 6 seaplane
stations
Telecommunications: extensive radio relay
network; telephone network modern, 476,000
instruments; COMSAT ground station; 2.75 million
radio and 1 million TV receivers; 158 AM, 30 FM,
and 55 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,771,000;
2,088,000 fit for military service; average number
reaching military age (19) annually about 98,000
Military budget: for fiscal year ending 31
December 1976, US$394.9 million; about 21.2% of
central government budget
CHINA, PEOPLES REPUBLIC OF
{See reference map Vil)
LAND
9.6 million km?; 11% cultivated, sown area
extended by multicropping, 78% desert, waste, or
urban (32% of this area consists largely of denuded
wasteland, plains, rolling hills, and basins from which
about 3% could be reclaimed), 8% forested; 2%-3%
inland water
Land boundaries: 24,000 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 14,500 km
89
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CHINA, PEOPLES REPUBLIC OF
Railroads: networks total about 43,500 route km
common-carrier lines; about 600 km meter gage (1.00
m); rest standard gage (1.485 m); all single track
except 8,700 km double track on standard gage lines;
Paochi to Chengtu line electrified; about 9,500 km
industrial lines (gages range from 0.59 to 1.435 m)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CHINA, PEOPLES REPUBLIC OF/CHINA, REPUBLIC OF
Highways: about 800,000 km all types roads;
almost half (350,000 km) unimproved natural earth
roads and tracks; about 190,000 km improved earth
roads about 2- to 5-meters wide and in poor to fair
condition; remainder (about 240,000 km) includes
majority of principal roads
Ports: 9 major, 180 minor
Airfields: 382 total; 248 with permanent-surface
runways; 7 with runways over 8,660 m, 78 with
runways 2,440-3,659 m, 212 with runways 1,220-
2,489 m; 2 seaplane stations
Telecommunications: urban and industrial areas
served by reasonably adequate facilities for domestic
and international communication needs; facilities
being expanded; effective broadcast coverage is
provided by radio, extensive wired-broadcast
networks, and an expanding TV network; estimated 5
million telephones, 45 million radio receivers, 140
million wired-speakers and 350,000 TV receivers; 250
AM, 1 FM, and 105 TV transmitter and rebroadcast
stations; 3 standard international communications
satellite ground stations; coaxial cable links Canton to
Hong Kong; submarine cable links Shanghai to
Japan; additional submarine cables planned
CHINA, REPUBLIC OF
Taipei
REPUBLIC OF','daacfc0afd3abd3612f5ddbbe1bfaa238b88524fd972f146e54e8836d56e7e5d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87ccf8c87b5907d788c165b9553f212bd56c012e73b4d0066d368fd9c8bacb93',1977,'CN','China','communications',105,'(See reference map Vit)
LAND
32,260 km? (Taiwan and Pescadores); 24%
cultivated, 6% pasture, 55% forested, 15% other
(urban, industrial, denuded, water area)
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: 990 km Taiwan, 459 km offshore islands
Railroads: about 1,000 km common-carrier and
3,500 km industrial lines, all on Taiwan; common-
carrier lines consist of West System: 825 km meter
gage (1.00 m) with 325 km double track; East Line:
175 km narrow gage (0.762 m); common-carrier lines
owned by government and operated by Railway
Administration (TRA) under Ministry of Communica-
tions; industrial lines owned and operated by
government enterprises
Highways: network totals 16,575 km plus 483 km
on Penghu and offshore islands; 7,564 km paved,
6,276 km gravel and crushed stone, 2,736 km earth
Pipelines: 615 km refined products, 97 km natural
gas
Ports: 4 major, 5 minor
Airfields: 37 total, 35 usable; 26 with permanent-
surface runways; 2 with runways over 3,660 m, 10
with runways 2,440-3,659 m, 10 with runways 1,220-
2,439 m; 2 seaplane stations
42
Telecommunications: good international and
domestic service; 1.08 million telephones; est. 3
million radio receivers; 2.5 million TV receivers; 11]
AM, 6 FM broadcast stations; 8 TV systems; 2
international COMSAT ground stations; radio relay
links to Hong Kong and the Philippines; new inter-
island submarine cables; Manila submarine cable
planned
DEFENSE FORCES
Military manpower: males 15-49, 4,062,000;
3,178,000 fit for military service; average number
currently reaching military age (19) annually 192,000
La-sa
ef''un-ming
$ri Lanka
(Cayton)
efakutsk
(Harbin) *
Shen-yang,
Pei-ching
i J:
is (Peking), f 7
. wr ane)
Chiing-tao
{Tsingtao} {
Hsi-an
* (Sian)
eCh’eng-tu
Kuang- chou
(Cantor)
Macao 9 Hong Kong
ety WK)
wy N
a)
Luzon
< Philippines
ESN
naan
Palambange
a
1200 Miles
1200 Kilometers
NAMES AND BOUNDARY REPRESENTATION
ARE NOT NECESSARILY AUTHORITATIVE
503195 1-77 (540317)
ee ee a ae
Yogyakarta
Indonesi
oy
: ape
{
Sf
Perth eee:
Vd
Ss
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
28','96d55985e2ebd94ca36719a6e4832b455788bdf44cf8fe3b0cc2003a4df84476','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89b3a132aaaf60b4189f9daa0bc77280700f8c63785badf3c5db03cc287a2a94',1977,'CO','Colombia','communications',109,'> Bogota
_/ COLOMBIA
| Pacific
“Ocean
(Sea reference map fil)
LAND
1,139,600 km?; settled area 28% consisting of
cropland and fallow 5%, pastures 14%, woodland,
swamps, and water 6%, urban and other 3%;
unsettled area 72% —mostly forest and savannah
Land boundaries: 6,085 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,414 km
Railroads: 3,456 km, all 0.914-meter gage, single
track, 35 km electrified
Highways: 56,650 km; 7,150 km paved, 37,350 km
crushed stone or gravel, 8,150 km improved earth
Inland waterways: 14,300 km, navigable by
river boats
Pipelines: crude oil, 3,220 km; refined products,
1,330 km; natural gas, 590 km; natural gas liquids,
125 km
Ports: 5 major, 5 minor
Civil air: 120 major transport aircraft
Airfields: 719 total, 683 usable; 42 with
permanent-surface runways; 1 with runway over
3,660 m; 6 with runways 2,440-3,659 m, 85 with
runways 1,220-2,439 m; 11 seaplane stations
Telecommunications: nationwide radio-relay
system; COMSAT ground station; 1.28 million
telephones; 6.5 million radio and 1.4 million TV
receivers; 325 AM, 130 FM, and 56 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 5,164,000;
3,365,000 fit for military service; average number
reaching military age (18) annually about 236,000
Military budget: proposed for fiscal year ending 31
December 1976, $134.2 million; about 9% of central
government budget
43
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
COMOROS/CONGO
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
2. cone
fe 4,
U.S. Naval Basa Haiti Roe ane
: oaucPrlaey ae
Jamaica __ Pert sucbring ea iD eante
Domingo
a
Curagao
ae
Caracas
Middle America
geermuda
(U.K)
Puerto Rico-virgin is. (U.S, UKI
aoe 77 gAnguilla(U.K)
Ee 2 &, St Christopher (U.K)
4 PAntgua UIC)
Vn, re Nevis (U.K)
OW Guadeloupe (Fr)
SF WDominicalu.k,)
& Martinique (Fr)
QO gSt. Lucia(¥.k)
© St. Vincent
< NuK)
= Barbados
Netherlands Antilles
Trinidad
Porsot Siping Land Tobago
ee ™.
Venezuela
Approved For Release 2005/04/22 : CIA-RDP79-01051A009§900 1006 fy America
Ce:
Jamaica Haiti
aan “$Recife
= "Salvador
ee)
“Brasilia
Bolivia
Sucre
f
em
Rio de Janeiro
Antofagasta
South
Atlantic
Buenos Aires 2
Montevideo
Ocean','9a674ae6dce6d55716e6eaeeed2e435742c29547d5078b6ea4167cc6f572656b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82aaa8630be530f6f94122feb808e092b9d0016cbfd1591e66159cad2364ddcc',1977,'KM','Comoros','communications',113,'Indian Ocean
on, COMOROS
a4
{See reference map Vi}
LAND
2,170 km?; 4 main islands; forests 16%, pasture 7%,
cultivable area 48%, non-cultivable area 29%
WATER
Limits of territorial waters (claimed): 12 nm; 200
nm exclusive economic zone
Coastline: 340 km
Railroads: none
Highways: 999 km; approximately 295 km
bituminous, remainder crushed stone or gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 7 major transports (registered in France)
Airfields: 5 total, 5 usable; 5 with permanent
surface runways; 1 with runway 2,440-3,659 m, 4 with
runways 1,220-2,439 m
Telecommunications: minimal system of HF
radiocommunication stations for interisland, island
and external communications to Malagasy and
Reunion; Dzaoudzi center but of slight significance;
1,380 telephones; 36,000 radio receivers; 1 AM, 1 FM,
and no TV stations
Atlantic : Sp fone eae pth > Moroni
aaa
Ocean
South-w i i «la a ta
outh-We $Bai auritius
Africa : a Madagascar Port Louis,
Ont. Terr) fhe Reunion
{Fr}
Walvis Bay {Fi
(S. AT)
1000 Miles
1000 Kilometers Cape Town
Names and boundary representation
are nut necessarily authorilative
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
503194 1-77
Approved For Release 2005/04/22 : CIA-RDP79-01051A9998000f Q806- and Asia','7b2c2fd020057e1114354b99546c91913e8fc1352d6a5e4a7598f15034fdbcb1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0310a8ed0798aa7aa1fe862d9346ac6f9b18dff024ecf05c5949e6e32f0bd344',1977,'CG','Congo','communications',117,'LAND
349,650 km?; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or
waste
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Atlantic
Ocean
Land boundaries: 4,514 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 169 km
Railroads: 784 km, 1,065-meter gage, single track
Highways: 8,302 km; 365 km bituminous surface
treated; remainder gravel, laterite, or improved earth
Inland waterways: 6,485 km navigable
Ports: 1 major (Pointe Noire)
Civil air: 7 major transport aircraft
Airfields: 68 total, 51 usable; 3 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 18
with runways 1,220-2,489 m; 1 seaplane station
Telecommunications: services adequate for
government and public; network is comprised of low-
capacity, low-powered radiocommunication stations,
45
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CONGO/COOK ISLANDS/COSTA RICA
coaxial cables and wire lines; key centers are
Brazzaville, Pointe-Noire, and Dolisie; 10,200
telephones; 81,000 radio receivers; 2,700 TV receivers;
8 AM stations, no FM, and 1 TV station
DEFENSE FORCES
. Military manpower: males 15-49, 332,000; 166,000
fit for military service; about 13,000 reach military
age (20) annually
Military budget: for fiscal year ending 31
December 1976, $37,517,400; about 17% of central
government budget','8aeff54b210c92e5601233caacc3b1dd6e192b9cfa37efb9dac8fc8b92bbc431','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba6a49248e25e782498b4fb3407ca17ccbc4f51b0d89e49d54b94f4b12defc2',1977,'CK','Cook Islands','communications',121,'Pacific Ocean
~
oP Fl
Pacific Ocean
{See reference map Viti}
LAND
About 240 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 120 km
Railroads: none
Highways: 260 km; 19 km paved, 109 km gravel,
84 km improved earth, 48 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 3 total; 1 with composite surface runway
2,206 m, 8 with natural surface runways 1,220-2,439
m; 2 seaplane stations
Telecommunications: 6 AM, no FM, and no TV
stations; 7,000 radio receivers, and 960 telephones
(New Zealand)
Rarotonga.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Christmas
”
SD
c
>
za
_ Oo
(OK. admin.,
US. claims
LES MARQUISES
oo ae a %,
ze
K
oS
Be 5
a wpPapeete
V5 Tahiti
ae
cS
*
LES r BU;
&
; Mururua
French ilies Gambier
Polynesia
Pitcairn Island
(LKQ
Rapa.
Line of separation
(not a formal international
boundary or territorial limit)
1000 Nautical Miles
1000 Statute Miles
500
500
BOUNDARY REPRESENTATION IS
NOT NECESSARILY AUTHORITATIVE','b35960efd407ca06eceb31ae978a859f694741a72cd3032c21072435c7b116ce','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17e3ba5700b22528230a0b2693f065b5d206a670b43f2625e51a969ad3fc5b61',1977,'CR','Costa Rica','communications',125,'LAND
51,000 km?; 30% agricultural land (8% cultivated,
22% meadows and pasture), 60% forested, 10% waste,
urban, and other
Land boundaries: 670 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing 200 nm; specialized competence over living
resources to 200 nm)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
A
{See reference map ti}
Coastline: 1,290 km
Railroads: 651 km; 632 km 1.065-meter gage, 19
km 0.914-meter gage, all single track, 115 km
electrified
47
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
COSTA RICA/CUBA
Highways: 23,100 km; 1,650 km paved, 6,650 km
otherwise improved, 14,800 km unimproved earth
Inland waterways: about 7380 km_ perennially
navigable
Pipelines: refined products, 125 km
Ports: 3 major (Limon, Golfito, Puntarenas), 4
minor
Civil air: 25 major transport aircraft
Airfields: 157 total, 152 usable; 21 with
permanent-surface runways; 1 with runway 2,440-
3,659 m; 9 with runways 1,220-2,439 m; 2 seaplane
stations
'' Telecommunications: good domestic telephone
service; 113,700 telephones; connection into Central
American microwave net; 350,000 radio and 175,000
TV receivers; 45 AM, 10 FM, and 11 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 448,000; 292,000
fit for military service; average number reaching
military age (18) annually about 24,000
Supply: dependent on imports from U:S.
Military budget: for fiscal year ending 31
December 1978, $5.2 million for Ministry of Public
Security, including the Civil Guard; about 2.3% of
total central government budget
(See reference map fl)
LAND
114,478 km?; 35% cultivated, 30% meadow and
pasture, 20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 3,735 km
Railroads: 14,640 km government-owned; 5,040
km common-carrier lines of which 4,960 km standard
gage (1.485 m), 80 km 0.914-meter gage; about 9,600
km plantation/industrial lines, 6,400 km standard
gage (1.435 m), 3,200 narrow gage
Highways: 20,700 km; 8,800 km paved, 11,900 km
gravel and earth surfaced
Inland waterways: 240 km
Pipelines: natural gas, 80 km
Ports: 8 major (including U.S. Naval Base at
Guantanamo), 44 minor; Guantanamo under USS.
control
Civil air: 28 major transport aircraft (1 leased)
Airfields: 199 total, 182 usable; 45 with
permanent-surface runways; 1 with runway over
8,660 m, 8 with runways 2,440-3,659 m, 25 with
runways 1,220-2,439 m; 11 seaplane stations
Telecommunications: modern facilities adequately
serve military and most civil needs; excellent
international facilities; satellite ground station;
870,000 telephones; 2.0 million radio and 600,000 TV
receivers; 100 AM, 25 FM, and 17 TV stations; 4
submarine cables, including 1 coaxial
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1966 (last announced budget), $213
million; about 7.8% of total budget
Approved For Release 2005/04/22 :','1146116da65737daaa7845c29ef34c17b1d0c5df6a84bac002fdbac6a9423cf3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ec0d830b8b44c4d2c26e78b3124b017586b557c1f54a9dc94e9952c9e93f6da',1977,'CY','Cyprus','communications',129,'Mediterranean
LAND
9,251 km?; 47% arable and land under permanent
crops, 18% forested, 10% meadows and pasture, 25%
waste, urban areas, and other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 644 km','37264f777d33f9050b0ea036c371193c2c6071f1ec44d9f45512b40aa4328d46','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('545ca9f6e770cb0e9e620a1defc53691a0619922c83a8a6371f7155c280d2853',1977,'NL','Netherlands','communications',134,'Railroads: none
Highways: 9,358 km; 4,203 km bituminous surface
treated; 5,155 km gravel, crushed stone, and earth
Ports: 3 major (Famagusta, Larnaca, Limassol), 6
minor; Famagusta under Turkish control
Civil air: 5 major transport aircraft
Airfields: 13 total, 12 usable; 8 with permanent-
surface runways; 3 with runways 2,440-3,659 m; 4
with runways 1,220-2,439 m
Telecommunications: moderately good telecom-
munication system; 77,000 telephones; 206,000 radio
receivers; 86,000 TV receivers; 12 AM, 3 FM, and 4
TV stations; tropospheric scatter circuits to Greece and
Turkey; 2 submarine coaxial cables
DEFENSE FORCES
Military budget: for fiscal year ending 31
December 1976, $26.9 million about 18.1% of central
government budget
CZECHOSLOVAKIA
(See reference map IV)
LAND
127,946 km?; 42% arable, 14% other agricultural,
85% forested, 9% other
Land boundaries: 3,540 km
Railroads: 13,208 km; 12,920 km standard gage
(1.485 m), 112 km broad gage (1.524 m), 176 km
narrow gage (1.00 m and 1.067 m); 2,786 km double
track; 2,787 km electrified; government-owned (1975)
Highways: 72,981 km; 1,381 km concrete; 55,200
km bituminous; 2,880 km cobblestone, brick sett,
stone block; 18,520 km crushed stone, gravel,
improved earth (1975)
Inland waterways: 827 km (1976)
Pipelines: crude oil, 1,448 km; refined products,
861 km; natural gas, 5,601 km
Freight carried: rail—272.8 million metric tons,
62.8 billion metric ton/km (1975); highway—955.9
million metric tons, 13.6 billion metric ton/km
(1974); waterway—4.9 million metric tons, 2.8 billion
metric ton/km (excl. int''l. transit traffic) (1975)
Ports: no maritime ports; outlets are Gdynia,
Gdansk, and Szczecin in Poland; Rijeka and Koper in
Yugoslavia; Hamburg, FRG; Rostock, GDR; principal
river ports are Prague, Melnik, Usti nad Labem,
Decin, Komarno, Bratislava (1976)
Civil air; 28 major transport aircraft (1976)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1976, est. 20.4 billion crowns,
about 7% of total budget
Railroads: none
Highways: 56 km, mostly paved
Ports: 1 major (Gibraltar)
Civil air: 1 major transport aircraft
Airfields: 1 permanent-surface runway, 1,220-
2,439 m; 1 seaplane station
Telecommunications: international radiocom-
munication facilities; automatic telephone system
serving 8,000 telephones; 7,300 radio receivers; 7,000
TV receivers, 1 AM, 1 FM, and 2 TV stations; 3
submarine telegraph cables
DEFENSE FORCES
Military manpower: males 15-49, about 6,000;
about 8,000 fit for military service
Defense is responsibility of United Kingdom
GILBERT ISLANDS
NOTE: On October 1, 1975, by Constitutional
Order, the Ellice Islands were formally separated from
the British colony of Gilbert and Ellice Islands, thus
forming the new colony of Tuvalu. The remaining
islands in the former Gilbert and Ellice Islands Colony
were renamed the Gilbert Islands.
The islands that comprise the Gilbert Islands
Colony are the Gilbert Islands; Fanning Atoll and
Washington Island in the Line Islands; Ocean Island;
and those islands claimed by the United States:
Caroline, Christmas, Flint, Malden, Starbuck, and
Vostok in the Line Islands; and Birnie, Gardner, Hull,
McKean, Phoenix, and Sydney in the Phoenix Islands.
LAND
About 684 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 1,143 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22: CIA-RDP79-01051A000800010006-3
January 1977
GILBERT ISLANDS/GREECE
: unites “
afi ST.
Pacific Ocean ares
GILBERT
: ot MSLANDS
NEA” “te TUVALU
ae
tS
‘5
Pa,
~
(See reference map Vitl)
Railroads: none
Highways: 483 km of motorable roads
Approved For Release 2005/04/22 :
Inland waterways: small network of canals,
totaling 5 km, in Northern Line Islands
Ports: 1 minor
Civil air: no major transport. aircraft
Telecommunications: 1 AM _ broadcast station;
5,000 radio receivers, no TV sets, and 250 telephones;
connected with Lisbon, Portugal, via cable broadcasts
North
Sea
ee ae
msterdam
{See reference map {V)
LAND
33,929 km?; 70% cultivated, 5% waste, 8% forested,
8% inland water, 9% other
Land boundaries; 1,022 km
WATER
Limits of territorial waters (claimed): 8 nm
(fishing, 12 nm)
Coastline: 451 km
Railroads: 2,979 km, standard gage (1.435 m);
2,813 km government-owned (NS), 1,638 km
146
electrified, 1,556 km double track; 166 km privately-
owned
Highways: approximately 100,960 km including
1,440 km of limited access, divided “Motorways”;
about 82,240 km paved (bituminous, concrete, stone
block) and 2,720 km unpaved (gravel, crushed stone,
stabilized earth)
Inland waterways: 6,340 km, of which 35% is
usable by craft of 900 metric ton capacity or larger
Pipelines: 418 km crude oil; 965 km refined
products; 4,489 km natural gas
Ports; 8 major, 5 minor
Civil air: 105 major transport aircraft
Airfields: 27 total, 26 usable; 16 with permanent-
surface runways; 13 with runways 2,440-3,659 m, 3
with runways 1,220-2,439 m
Telecommunications: highly developed, ex-
cellently maintained, and well integrated; extensive
system of multiconductor cables, supplemented by
radio-relay links; 5.1 million telephones; 9 million
radiobroadcast and 3.67 million TV receivers; 5 AM,
12 FM, and 18 TV stations; 12 coaxial submarine
cables; communications satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,421,000;
3,071,000 fit for military service; average number
reaching military age (20) annually 116,000
Military budget: proposed for fiscal year ending 31
December 1976, $2,888 million; about 10% of central
government budget
NETHERLANDS ANTILLES
Atlantic Ocean
i
Cee wee
*
RX
a
_ ANTILLES
\\Coribhean
Sea
(See reference map 11)
LAND
1,020 km?; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 364 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NETHERLANDS ANTILLES
Railroads: none
Highways: 950 km; 300 km paved, 650 km gravel
and earth
Ports: 3 major (Willemstad, Oranjestad, Caracas-
baai, Bullennbaai); 6 minor
Civil air: 8 major transport aircraft
Airfields: 7 total, all usable; 7 with permanent-
surface runways; 2 with runways 2,440-8,659 m, 2
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: generally adequate telecom
facilities; extensive interisland radio relay links;
40,000 telephones, 132,000 radio and 35,000 TV
receivers, 11 AM and 5 TV stations, 5 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 33,000
fit for military service; about 2,000 reach military age
(20) annually
Defense is responsibility of the Netherlands
147
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','bd5cde0fbc97c0a97756151b80f1663c5c10d90a5d5ec7000b58c2d4ee8596d4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b2ff0b08619630f27c2a4dd7fae865bc4dcc824eecdabe351808b70feb9d3bc',1977,'DK','Denmark','communications',137,'LAND
42,994 km? (exclusive of Greenland and Faroe
Islands); 64% arable, 8% meadows and pastures, 11%
forested, 17% other
52
Approved For Release 2005/04/22
{See reference map 1V)
Land boundaries: 68 km
WATER
Limits of territorial waters (claimed): 3 nm
(fishing 200 nm)
Coastline: 3,379-km
Railroads: 2,744 km standard gage (1.435 m);
Danish State Railways (DSB) operate 2,227 km (1,999
km rail line and 228 km rail ferry services); 84 km
electrified, 743 km double tracked; 517 km of
standard gage lines are privately-owned and operated
Highways: approximately 64,480 km; 62,400 km
concrete, bitumen, or stone block; 2,080 km gravel,
crushed stone, improved earth
Inland waterways: 417 km
Pipelines: refined products, 418 km
Ports: 16 major, 44 minor
Civil air: 84 major transport aircraft including 9
belonging to Greenland
Airfields: 160 total, 123 usable; 22 with
permanent-surface runways; 8 with runways 2,440-
8,659 m, 8 with runways 1,220-2,439 m; 1 seaplane
station
Telecommunications: excellent telephone, tele-
graph, and broadcast services; 2.34 million
telephones; 1.84 million radiobroadcast receivers; 1.62
million TV receivers; 8 AM, 13 FM, and 380 TV
stations; 14 submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,195,000;
1,050,000 fit for military service; 38,000 reach military
age (20) annually
Military budget: proposed for fiscal year ending 31
March 1977, $852.7 million; about 6.5% of central
government budget
53
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
DOMINICA/DOMINICAN REPUBLIC
FALKLAND ISLANDS (MALVINAS)?
Atlantic
: FALKLAND
s22> ISLANDS
(See reference map Iti)
LAND
Colony—12,168 km?;, area consists of some 200
small islands, chief of which are East Falkland (6,680
km?) and West Falkland (5,276 km?); depend-
encies—consists of the South Sandwich Islands, South
Georgia, and the Shag and Clerke Rocks
WATER
Limits of territorial waters (claimed): 3 nm
Coastline; 1,288 km
Railroads: none
Highways: 35 km; 16 km paved, 19 km gravel, and
earth; no other made-up roads in the islands beyond
the immediate vicinity of Stanley
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 1 usable airfield, 1 seaplane station
Telecommunications: government-operated open-
wire and radiotelephone networks providing effective
service to almost all points on both islands; approx-
imately 650 telephones; 1 AM station and 1,100 est.
radiobroadcast receivers
8]
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GRENADA/GUADELOUPE','57eb3a99a9730b3b17865df14433de42a5f5484c539e6b4c19faa476d297731d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a00c6839a5803f469a13bd74e653236cd9e00f435686d1b7c93ac56faceb7d4',1977,'DM','Dominica','communications',141,'WREPUBLIC.
(See reference map Hl)
LAND
790 km?; 24% arable, 2% pasture, 67% forests, 7%
other
WATER
Limits of territorial waters (claimed); 3 nm
Coastline: 148 km
Railroads: none
Highways: 750 km; 370 km paved, 260 km gravel,
crushed stone, or stabilized earth surface, 120 km
unimproved
Ports: 2 minor (Roseau, Portsmouth)
Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 1,472 m
Telecommunications: 3,000 telephones in fully
automatic network; VHF and UHF link to St. Lucia;
15,000 radio receivers; 150 TV receivers; 1 AM and 1
TV station','6430f8388b29dafa3128bb0052accd866979f892ca2c26a3369a136b1d402210','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22a8f727e3df8e2174dc264f8c88bdd7735277dd854ea0dd1c8cee1f1b1dac75',1977,'DO','Dominican Republic','communications',145,'LAND
48,692 km?; 14% cultivated, 4% fallow, 17%
meadows and pastures, 45% forested, 20% built-on or
waste
Land boundaries: 361 km
WATER
Limits of territorial waters (claimed): 6 nm
(fishing 12 nm)
Coastline: 1,288 km
Railroads: 1,600 km; 104 km government-owned
common-carrier 1.065-meter gage; 1,496 km privately
owned plantation lines of 4 different gages ranging
from 0.60 m to 1.435 m, 0.760-meter gage
predominating
Highways: 11,400 km; 5,800 km paved, 5,600 km
gravel and improved earth
Pipelines: refined products, 69 km
Ports: 5 major (Santo Domingo, Barahona, Haina,
Las Calderas, San Pedro de Macoris), 17 minor
Civil air; 24 major transport aircraft
Airfields; 51 total, 44 usable; 11 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 9
with runways 1,220-2,439 m; 1 seaplane station
55
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
DOMINICAN REPUBLIC/ECUADOR
Telecommunications: relatively efficient domestic
system based on islandwide radio relay network;
115,000 telephones; 600,000 radio and 190,000 TV
receivers, 110 AM, 31 FM, and 11 TV stations; 3
submarine cables, including 1 coaxial; COMSAT
ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,102,000;
697,000 fit for military service; 51,000 reach military
age (18) annually','1123ccffaf513a30d7cbb7683ceabafa0ead9688cde499c376e712e68a91dcc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a4b80c6b24da335a74b12da634ac71ff0752ac72aa0dfbba9327cc0d8429c9f',1977,'EC','Ecuador','communications',149,'Galapagos
fslands
(See refarence map tit}
LAND
274,540 km? (including Galapagos Islands); 11%
cultivated, 8% meadows and pastures, 55% forested,
26% waste, urban, or other (excludes the Oriente and
the Galapagos Islands, for which information is not
available)
Land boundaries: 1,931 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,287 km (includes Galapagos Is. )
Railroads: 1,056 km; 984 km 1.065-meter gage, 72
km 0.750-meter gage; all single track
Highways: 20,550 km; 3,450 km paved, 17,100 km
otherwise improved
Inland waterways: 1,500 km
Pipelines: crude oil, 623 km; refined products, 473
km
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar),
11 minor
Civil air: 31 major transport aircraft
Airfields: 173 total, 173 usable; 17 with
permanent-surface runways; 6 with runways 2,440-
3,659 m, 21 with runways 1,220-2,439 m; 3 seaplane
stations
Telecommunications: facilities adequate only in
largest cities; COMSAT ground station; 185,000
telephones; 1.7 million radio and 300,000 TV
receivers; 240 AM, 88 FM, and 12 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,609,000;
1,050,000 fit for military service; average number
reaching military age (20) annually 66,000','96958c0e24b4de1144f663bd33d3edb2c36dd12f7ba4bfbe6c101e43221cb9a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b01f2110654d8476748a500f0b2cb38d4550068cf996be728d8dcc21289bc49',1977,'EG','Egypt','communications',153,'LAND
1,000,258 km? (including 57,498 km? occupied by
Israel); 2.8% cultivated (of which about 70% multiple
cropped); 96.5% desert, waste, or urban; 0.7% inland
water
Approved For Release 2005/04/22 :
(See reference mep V}
Land boundaries: 2,527 km (1967), excludes 2,469
km occupied area
WATER
Limits of territorial waters (claimed): 12 nm (plus
6 nm “necessary supervision zone’’)
Coastline: 3,444 km (1967), excludes occupied area
2,156 km
Railroads: 5,110 km; 917 km double track; 24 km
electrified; 4,510 km standard gage (1.435 m), 253 km
meter gage (1.00 m), 347 km 0.750-meter gage
Highways: 47,276 km; 9,524 km paved, 450 km
gravel and crushed stone, 10,302 km improved earth,
27,000 km unimproved earth
Inland waterways: 3,360 km; Suez Canal, 160 km
long, used by ocean-going vessels drawing up to 11.5
meters of water; Alexandria-Cairo waterway
navigable by barges of 500-metric ton capacity; Nile
and large canals by barges of 420-metric ton capacity;
Ismailia Canal by barges of 200- to 300-metric ton
capacity; secondary canals by sailing craft of 10- to
70-metric ton capacity
Freight carried: Suez Canal (1966)—242 million
metric tons of which 175.6 million metric tons were
POL
Pipelines: crude oil, 708 km; refined products, 499
km; natural gas, 121. km
58
Ports: 3 major (Alexandria, Port Said, Suez), 8
minor
Civil air: 18 major transport aircraft
Airfields: 100 total, 82 usable; 67 with permanent-
surface runways; 45 with runways 2,440-3,659 m, 1
with runway over 8,660 m, 19 with runways 1,220-
2,439 m; 2 seaplane stations
Telecommunications: second-best system of
coaxial and multiconductor cables, open-wire lines,
and radiocommunication stations in Africa; principal
centers Alexandria and Cairo, secondary centers Al
Mansurah, Ismailia, and Tanta; 503,200 telephones;
5.1 million radio and 620,000 TV receivers; 10 AM, 1
FM, and 22 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 8,456,000;
5,496,000 fit for military service; about 380,000 reach
military-age (20) annually','2e8babb420baaf6baeedf9fb804880f22b9002eacf2360c74a78c6f75918ec8e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c73e4c035bee9d3b050c69e92637d0f1f76b9d89f761341f2f24ebb31e3b7880',1977,'SV','El Salvador','communications',157,'(See reference map Ut)
LAND
21,400 km?; 32% cropland (9% corn, 5% cotton, 7%
coffee, 11% other), 26% meadows and pastures, 31%
nonagricultural, 11% forested
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 307 km
Railroads: 600 km 0.914-meter gage, single-
tracked; 456 km privately owned, 144 km
government-owned
Highways: 10,800 km; 1,300 km bituminous, 2,000
km gravel or crushed stone, 7,500 km earth
Inland waterways: Lempa River partially
navigable
Ports: 2 major (Acajutla, La Union), 2 minor
Civil air: 8 major transport aircraft
Airfields: 145 total, 145 usable; 1 with permanent
surfaced runway; 8 with runways 1,220-2,439 m; 1
seaplane station
Telecommunications: nationwide trunk radio relay
system; connection into Central American microwave
net; 54,200 telephones; 600,000 radio and 135,000 TV
receivers; 53 AM, 6 FM, and 5 TV stations
59
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
EL SALVADOR/EQUATORIAL GUINEA
DEFENSE FORCES
Military manpower: males 15-49, 963,000; 589,000
fit for military service; 44,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1976, $24.2 million; 7.2% of central
government budget','f54798ed17c5487716deb7a8fd17fe796581c007770f6201443aadf7ddc799f8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5508b25d8939608c31946ce98a04a0b08eabc525f01a20894802d971ab65569',1977,'GQ','Equatorial Guinea','communications',161,'SE F sa
Malabo,*
a
ROVATORIAL,
= BUINEA
Atlantic.
Qeean
(See reference map Vij
LAND
27,972 km?; Rio Muni, about 25,900 km?, largely
forested; Fernando Po, about 2,072 km?
Land boundaries: 539 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 296 km
Railroads: none
Highways: Rio Muni—2,460 km, including
approx. 185 km bituminous, remainder gravel and
earth; Fernando Po—300 km, including 146 km
bituminous, remainder gravel and earth
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
EQUATORIAL GUINEA/ETHIOPIA
Inland waterways: Rio Muni has approximately
167 km of year-round navigable waterway, used
mostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey
Malabo), 3 minor
Civil air: no major transport aircraft
Airfields: 5 total, 3 usable; 2 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 1 with
runway 1,220-2,439 m
Telecommunications: fairly adequate for the size
and stage of development of the country; interna-
tional communications by radio from Bata and
Malabo to Cameroon, Nigeria, and Spain; 1,500
telephones; 78,000 radio and 1,000 TV receivers; 2
AM stations, no FM stations, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 75,000; 37,000
fit for military service
Military budget: for fiscal year ending 31
December 1976, $3,475,700; 14.3% of central
government budget','9ce6313ee687622f7968789f451758427c8ce332971c6dcae561a7bce0043d47','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3efd966c004a830b8a9882330d3d87fd46bc7529cfb06df2cbc92878e0c69b86',1977,'ET','Ethiopia','communications',165,'"9g
(See reference map Vi}
LAND
1,178,450 km?; 10% cropland and orchards, 55%
meadows and natural pastures, 6% forests and
woodlands, 29% wasteland, built-on areas, and other
Land boundaries: 5,198 km
WATER
Limits of territorial waters (claimed): 12 nm;
sedentary fisheries extends to limit of fisheries
Coastline: 1,094 km (includes offshore islands)
Railroads: 1,014 km; 676 km meter gage (1.00 m),
32 km 1.067-meter gage, 306 km 0.95-meter gage; all
single track
Highways: 23,000 km; 2,700 km bituminous, 5,000
km crushed stone, gravel, or stabilized earth,
remainder earth
Inland waterways: navigation possible on Lake
Tana and on approx. 225 km of unconnected and
basically unimproved waterways, of which only 114
km are navigable year round
Ports: 2 major (Assab, Massawa), 1 minor
Civil air: 16 major transport aircraft
Airfields: 174 total, 162 usable; 7 with permanent-
surface runways; 1 with runway over 3,660 m, 6 with
runways 2,440-3,659 m, 48 with runways 1,220-
2,439 m
Telecommunications: system better than most
African countries; composed of open-wire lines,
radiocommunication stations, and small number of
62
Approved For Release 2005/04/22
multiconductor cable and radio-relay links; principal
center Addis Ababa, secondary center Asmara; 66,000
telephones; 500,000 radio receivers; 20,000 TV
receivers; 4 AM stations, no FM stations, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, 7,195,000;
3,834,000 fit for military service; average number
reaching military age (18) annually 285,000
Military budget: for fiscal year ending 7 August
1976, $83,653,846; 13.1% of central government
budget','2c5dc45e7cbe37ddc8332ac0279e5c9c99fc813cbff29d656de3727ee7703177','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc28fa677a497645ad891af188b91ca677f39bf492dc0eb7ca100c70ba94331',1977,'FO','Faroe Islands','communications',169,'(See reference map 1V)
LAND
1,340 km?; less than 5% arable, of which only a
fraction cultivated; archipelago consisting of 18
inhabited islands and a few uninhabited islets
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 764 km
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less
than 1,220 m
Civil air: no major transport aircraft
Approved For Release 2005/04/22
Telecommunications: good international com-
munications; fair domestic facilities; 15,000 tele-
phones, 12,000 radio receivers; 1 AM, and 3 FM
stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with','f58015ac9c8eedc23b8abcc46a827b816ad37f4119e3d614c59b84809df88988','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4abc09d68d4b48889e559461d3e9e77fcc17c3fe1f2033ad1509287dd45f7fc',1977,'FJ','Fiji','communications',173,'LAND
18,272 km?; landownership—83.6% Fijians, 1.7%
Indians, 6.4% government, 7.2% European, 1.1%
other; about 30% of land area is suitable for farming
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 1,129 km
64
Approved For Release 2005/04/22
Pacific Ocean
(See reference map Vill}
Railroads: none
Highways: 2,828 km (1974); 278 km paved, 2,549
km gravel or crushed stone
Inland waterways: 203 km; 122 km navigable by
motorized craft and 200-metric ton barges
Ports: 1 major, 6 minor
Civil air: 5 major transport aircraft
Airfields: 15 total, 15 usable; 2 with permanent
surface runways, 1 with runway 2,440-3,659 m, 1 with
runway 1,220-2,489 m, 2 seaplane stations
Telecommunications: modern local, interisland,
and international (wire/radio integrated) public and
special-purpose telephone, telegraph, and teleprinter
facilities; regional radio center; important COMPAC
cable link between U.S. /Canada and New Zealand/
Australia, et al.; 25,560 telephones; 300,000 radio
receivers; 5 AM, 2 FM, and no TV stations; 1 ground
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 148,000; 82,000
fit for military service; 6,000 reach military age (18)
annually
Military budget: the defense of the Fiji Islands was
the responsibility of the U.K. until 10 October 1970;
military budget for 1971, $314,000','af17285c01d346d59eb9f800dc88d7738653dd7f0e0ac3bd6cb6287fdacdc45c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a967492d10f06df65e4c331933a5c383fb0f44859c4d63b40f90ef5616a08001',1977,'FI','Finland','communications',177,'LAND
336,700 km?; 8% arable, 58% forested, 84% other
Land boundaries: 2,534 km
Approved For Release 2005/04/22 :
Norwegian “
Sea
(See reference map {V}
WATER
Limits of territorial waters (claimed): 4 nm;
Aaland Islands, 8 nm
Coastline: 1,126 km (approx. ) excludes islands and
coastal indentations
Railroads: 5,946 km; Finnish State Railways (VR)
operate a total 5,918 km 1.524-meter gage, 477 km
multiple track, and 395 km electrified; 22 km 0.750-
meter gage and 6 km 1.524-meter gage are privately
owned
Highways: about 72,800 km in national classified
network, including 29,600 km paved (bituminous,
concrete, bituminous surface treated) and 48,200 km
unpaved (stabilized gravel, gravel, earth); additional
29,440 km of private (state subsidized) roads
Inland waterways: 6,597 km_ total (including
Saimaa Canal); 3,700 km suitable for steamers;
Saimaa Canal locks (84 m by 13.2 m with a 5.2 m
depth over sill) can accommodate vessels of up to 82
m in length, 11.8 m beam, 4.4 m draft, and 24.5 m
mast height
Pipelines: natural gas, 161 km
Ports: 11 major, 14 minor
Civil air: 37 major transport aircraft (2 leased)
Airfields: 106 total, 105 usable; 37 with
permanent-surface runways; 17 with runways 2,440-
3,659 m, 24 with runways 1,220-2,489 m
Telecommunications: good telecom service from
cable and radio-relay network; 1.87 million
telephones; 2.2 million radio and 1.67 million TV
receivers; 13 AM, 40 FM, and 67 TV stations; 4
submarine cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,211,000;
983,000 fit for military service; 39,000 reach military
age (17) annually','1ec26af6aba942f8f1968b9d57f53db32dc9bd5b5b093e71224ea2fca4b279f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66e2558b5334b7076fb99665cbb5b8c056bed8fc2daccf643b1df5d08081e200',1977,'FR','France','communications',181,'LAND
551,670 km?; 35% cultivated, 26% meadows and
pastures, 14% waste, urban, or other, 25% forested
Land boundaries: 2,888 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
“Atlantic”
Oc0ean
Mediterranaan Sea
(See reference map 1V)
WATER
Limits of territorial waters (claimed): 12 nm
(fishing 200 nm)
Coastline: 3,427 km (includes Corsica, 644 km)
Railroads: 36,720 km; 35,552 km standard gage
(1,485 m), 1,168 km other gages (1.00 m to 1.435 m);
9,345 km electrified, 15,630 km double or multiple
track
Highways: National, Departmental, and Commu-
nal roads total 795,520 km comprising 468,160 km
paved, 304,000 km crushed stone and gravel, and
23,360 km improved earth; in addition, there are
approximately 694,400 km of local farm and forest
roads
Inland waterways: 14,912 km; 5,604 km heavily
traveled
Pipelines: crude oil, 2,258 km; refined products,
4,344 km; natural gas, 22,047 km
Ports: 28 major, 165 minor
Civil air: 325 major transport aircraft (including 13
foreign based but French registered)
Airfields: 451 total, 481 usable; 212 with
permanent-surface runways; 2 with runways over
8,660 m, 26 with runways 2,440-3,659 m, 122 with
runways 1,220-2,439 km; 2 seaplane stations
Telecommunications: highly developed system
provides satisfactory telephone, telegraph, and radio
and TV broadcast services; 13.8 million telephones;
18.5 million radiobroadcast receivers; 14.7 million TV
receivers; 42 AM, 94 FM, and 1,473 TV stations; 22
submarine cables (21 coaxial); 5 communication
satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 12,900,000; fit
for military service 10,400,000; 424,000 reach military
age (18) annually
68
Military budget: for fiscal year ending 31
December 1976, $11,111,110,900; about 17% of
central government budget
Railroads: none
Highways: 16,212 km; 7,712 km bituminous and
bituminous treated, 8,500 km gravel, crushed stone
and earth
Pipelines: crude oil 3,251 km; natural gas 282 km;
refined products 443 km (includes 217 km liquid
petroleum gas)
Ports: 3 major (Tobruk, Tripoli,
minor, and 5 petroleum terminals
1 Libyan pound=
Benghazi), 4
Approved For Release 2005/04/22 :
Civil air: 20 major transport aircraft; an additional
20 major transports are operated by external carriers
engaged in charter work for several oil companies
Airfields: 86 total, 79 usable; 15 with permanent-
surface runways, 1 with runway over 3,660 m, 12 with
runways 2,440-3,659 m, 32 with runways 1,220-2,439
m; 2 seaplane stations
Telecommunications: system is just within top
one-third of African systems; consists of radio-relay
and tropospheric-scatter links, open-wire lines, and
radiocommunication stations; principal centers are
Tripoli and Benghazi; 49,800 telephones; 225,000
radio and 10,000 TV receivers; 7 AM, 1 FM, and 2 TV
stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 538,000; 311,000
fit for military service; about 22,000 reach military
age (17) annually; conscription now being imple-
mented
Military budget: estimated for period 1 April-31
December 1976, $202,771,200; 3,9% of central
government budget
Military budget: Ufor fiscal year ending 31
December 1976, $18,802,308; 6.3% of central
government budget','19c50aa45af0c2cb588517b98226f31590c69385db61e0dcd3a48563d63e286d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6424a082f2d97a4677abf1f439d629c5458861f5413f7b5ba2bfbe73fb3b604e',1977,'GF','French Guiana','communications',185,'(See seference map Hi)
LAND
90,909 km?; 90% forested, 10% wasteland, built-on,
inland water and other, of which .05% is cultivated
and pasture
Land boundaries: 1,183 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 378 km
Railroads: 32 km private plantation line, 0.600-
meter gage
Highways: 500 km; 390 km paved, 110 km
improved and unimproved earth
Inland waterways: 460 km, navigable by small
oceangoing vessels and river and coastal steamers;
3,300 km possibly navigable by native craft
Approved For Release 2005/04/22 :
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-
surface runways; 1 with runway 2,440-3,659 m
Telecommunications: limited open-wire telecom
system with about 8,400 telephones; 7,100 radio
receivers and 3,100 TV receivers, 2 AM, 2 FM and 2
TV stations; COMSAT ground station
DEFENSE FORCES
Military manpower: males 15-49, 18,000; 9,000 fit
for military service','b76a679e23d81abaeaa79f6557b3980d6174ae0a2b6ce42849a544a69287eb82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be3bdc15fa157de451c0bd2a5046321e141fa2af1c290ec24addac73ef367a93',1977,'PF','French Polynesia','communications',189,'CHRISTMAS 18.
“Sy; FRENCH
POLYNESIA
pele COOK Is. = SEE eS
(See reference map Vill}
LAND
About 4,000 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 2,525 km
Highways: 3,700 km, all types
Ports: 1 major (Papeete), 6 minor
Airfields: 19 total, 19 usable; 10 with permanent
surface runways, 2 with runways 2,440-3,659 m, 9
with runways 1,220-2,489 m; 2 seaplane stations
Civil air: no major transport
Telecommunications: 12,400 telephones; 72,000
radio and 14,000 TV sets; 1 AM, no FM, and 6 TV
stations
DEFENSE FORCES
Defense is responsibility of France.
FRENCH TERRITORY OF THE
AFARS AND ISSAS
LAND
23,310 km?; 89% desert wasteland, 10% permanent
pasture, and less than 1% cultivated
Land boundaries: 517 km
WATER
Limits of territorial waters (claimed); 12 nm
Coastline: 314 km (includes offshore islands)
Railroads: 97 km meter gage (1.00 m)
Highways: 750 km; 100 km paved, 650 km
improved earth
Ports: 1 major (Djibouti)
Airfields; 7 total, 7 usable; 1 with permanent-
surface runway; 1 with runway 2,440-3,659 m, 4 with
runways 1,220-2,439 m
Civil air: 4 major transport aircraft (registered in
France)
Telecommunications: fair system of urban
facilities in Djibouti and radiocommunication stations
at outlying places; 3,400 telephones; 13,000 radio
receivers; 3,000 TV receivers; 1 AM, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, about 30,000;
about 17,000 fit for military service
Defense is responsibility of France
Railroads: none
Highways: 5,159 km; 367 km paved, 1,300 km
gravel, crushed stone, or stabilized surface, 797 km
improved earth, 2,696 km earth
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air:.no major transport aircraft
Airfields: 31 total, 31 usable; 2 with permanent-
surface runways; 2 with runways 1,220-2,439 m, 1
airfield over 2,440 m; 1 seaplane station
Telecommunications: 17,092 telephones; 60,000
radio and 15,000 TV sets; 1 AM, no FM, and 5 TV
stations; 1 earth satellite station
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NEW HEBRIDES/NEW ZEALAND
NEW HEBRIDES
Pacitic
Ocean
BRITISH
SOLOMON
= ISLANDS
ag Ss
PAS
s
Coral Sea
HEBRIDES’.
a
NEW :
CALEDONIA
(See reference map Vill}
LAND
About 14,763 km?
WATER
Limits of territorial waters; 3 nm
Coastline: about 2,528 km
Railroads: none
Highways: at least 240 km sealed or all-weather
roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Telecommunications: 3 AM _ broadcast stations;
11,000 radio receivers, and 900 telephones
DEFENSE FORCES
Personnel: no military forces maintained, however,
the French and British maintain constabularies of
about 70 men each','c2d73e851b62e42f26f0a0a4bce5c72d00e156c9e4fd6b67c4a64498c6d2e524','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('852b0768a8ecf099e61bd7df9bf99748ebf6f266e1ee474bb558b0bbc57b537e',1977,'GA','Gabon','communications',193,'LAND
264,180 km?; 75% forested, 15% savanna, 9%
urban and wasteland, less than 1% cultivated
Land boundaries: 2,422 km
WATER
Limits of territorial waters (claimed): 100 nm;
fishing, 150 nm
Coastline: 885 km
Railroads: none
Highways: 6,848 km; 182 km paved, 5,665 km
gravel and/or improved earth, remainder unimproved
earth
Inland waterways: approximately 1,600 km
perennially navigable
Pipelines: crude oil, 129 km
Ports: 3 major (Libreville, Port-Gentil, Owendo), 2
minor
Civil air: 24 major transport aircraft
Airfields: 163 total, 105 usable; 5 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 20
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: system of open-wire, radio-
relay, tropospheric scatter links and radiocommunica-
tion stations; satellite ground station; 4 AM, no FM,
and 2 TV stations; 7,000 telephones; 92,000 radio
receivers; 8,000 TV receivers
72
DEFENSE FORCES
Military manpower: males 15-49, 133,000; 69,000
fit for military service; 5,000 reach military age (20)
annually
Military budget: for fiscal year ending 31
December 1976, $20,252,310; 3% of central
government budget
THE GAMBIA
(See reference map VI)
LAND
10,360 km?; 25% uncultivated savanna, 16%
swamps, 4% forest parks, 55% upland cultivable
areas, built-up areas, ete.
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 80 km
Railroads: none
Highways: 1,858 km; 190 km bituminous surface
treated, 1,330 km_ gravel/laterite, remainder
unimproved earth
Inland waterways: 605 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
1,220-2,439 m; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-
relay; 2,310 telephones; 60,500 radio receivers; 1 AM,
1 FM and no TV stations; 1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 124,000; 63,000
fit for military service
GERMAN DEMOCRATIC
REPUBLIC
(Sas referance map IV}
LAND
108,262 km?; 43% arable, 15% meadows and
pasture, 27% forested, 15% other
Land boundaries: 2,309 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 901 km (including islands)
Railroads: 14,252 km; 13,912 km standard gage
(1.485 m), 340 km meter (1.00 m) or other narrow
gage, 2,850 km double track standard gage (1.435 m);
1,406 km overhead electrified (1974)
Highways: 47,603 km classified highways; 12,927
km state highways including 1,53] km autobahn;
34,676 km district roads; additionally about 80,000
km communal roads (1974)
Inland waterways: 2,499 km (1976)
Freight carried: rail—286.3 million metric tons,
49.1 billion metric ton/km (1974); highway—541.9
million metric tons, 15.2 million metric ton/km
(1974); waterway—14.5 million metric tons, 2.3
billion metric ton/km (excl. int’l. transit traffic)
(1975)
Pipelines: crude oil, 805 km; refined products, 241
km; natural gas 483 km
Ports: 4 major (Rostock, Wismar, Stralsund,
Sassnitz), 13 minor (1976)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1976, 10.2 billion DME; about
9% of total budget
: CIA-RDP79-01051A000800010006-3
eae |
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GERMANY, FEDERAL REP. OF
GERMANY, FEDERAL
REPUBLIC OF
(See reference map 1V)
LAND
248,640 km? (including West Berlin); 33%
cultivated, 23% meadows and pastures, 13% waste or
urban, 29% forested, 2% inland water
Land boundaries: 4,232 km
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 200 nm)
Coastline: 1,488 km (approx. )
Railroads: 33,453 km; 29,082 km government-
owned, standard gage (1.485 m), 12,491 km double
track; 9,760 km electrified; 4,421 km non-government
owned; 3,997 km standard gage (1.485 m); 214 km
electrified; 424 km meter gage (1.00 m); 186 km
electrified
Highways: 398,720 km; 161,400 km classified,
includes 153,160 km cement-concrete, bituminous, or
stone block (includes 5,792 km of autobahnen); 8,240
km gravel, crushed stone, improved earth; in addition,
237,320 km of unclassified roads of various surface
types
Inland waterways: 4,990 km of which almost 70%
usable by craft of 990 metric-ton capacity or larger
Pipelines: crude oil, 1,931 km; refined products,
1,609 km; natural gas, 95,414 km
Ports: 10 major, 11 minor
Civil air: 166 major transport aircraft
Airfields: 433 total, 877 usable; 203 with
permanent-surface runways; 3 with runways over
8,660 m, 35 with runways 2,440-8,659 m, 36 with
runways 1,220-2,439 m
76
Telecommunications: highly developed, modern
telecommunication service to all parts of the country;
fully adequate in all respects; 20.4 million telephones;
21.5 million radio and 19.5 million TV receivers; 90
AM, 129 FM, and 2,160 TV stations; 6 submarine
cables; 4 communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 14,749,000;
12,357,000 fit for military service; 460,000 reach
military age (18) annually','30cecda6475ff40428ae5f1066da2908da62017fd0b398a2b4b45c26a17805ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47db521ee290eeb376d168239521c6fcd40dcce0787f1deba02390fcf7a9a0b9',1977,'GH','Ghana','communications',197,'(Sea reference map Vi}
LAND
238,280 km?; 19% agricultural, 60% forest and
brush, 21% other
Land boundaries: 2,285 km
WATER
Limits of territorial waters (claimed): 30 nm
(undefined protective areas may be proclaimed
seaward of territorial sea, and up to 100 nm seaward
may be proclaimed fishing conservation zone)
Coastline: 539 km
Railroads: 953 km, all 1.067-meter gage; 32 km
double track; diesel locomotives gradually replacing
steam engines
Highways: 29,740 km; 4,020 km concrete or
bituminous surface, 12,870 km gravel or laterite, 8,850
km improved earth, remainder unimproved earth
Inland waterways: Volta, Ankobra, and Tano
rivers provide 285 km of perennial navigation for
launches and lighters; additional routes navigable
seasonally by small craft; Lake Volta reservoir
provides 1,125 km of arterial and feeder waterways
Pipelines: refined products, 3 km
Ports: 2 major (Tema, Takoradi), 1 naval base
(Sekondi), 4 minor
Civil air: 6 major transport aircraft
Airfields: 19 total, 18 usable; 4 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 9
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: good system of open-wire
and cable, radio-relay links and radiocommunication
stations; 54,500 telephones; 1,060,000 radio and
33,000 TV receivers; 3 AM, no FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,319,000;
1,286,000 fit for military service; 111,000 reach
military age (18) annually
Military budget: for fiscal year ending 30 June
1977, $98.7 million; 9.1% of central government
budget','c2924f64603a2d2b3c1a37a0c7b0a910779c4655bdf10ef5efca1ceb2ad7e4ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec7d41fea725737e1912c6f8a136f5c472a0bb10f5abb240c3ea6cd008bcdb99',1977,'GI','Gibraltar','communications',201,'(See reference map {V}
LAND
6.5 km?
Land boundaries: 1.6 km
WATER
Limits of territorial waters (claimed): 3 nm
77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GIBRALTAR/GILBERT ISLANDS
Coastline: 12 km','8b995551cfcea8f88bf6c7259505c4f5c8f3e9289e15fb1decee836254255d6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d9c9a5af918b56c4e1d313b8c2b2e09476d31557b89ab935d3470b7f4245132',1977,'GR','Greece','communications',205,'Mediterranean Sea
(See reference map 1V)
LAND
132,608 km?; 29% arable and land under
permanent crops, 40% meadows and pastures, 20%
forested, 11% wasteland, urban, other
Land boundaries: 1,191 km
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 13,676 km
Railroads: 2,567 km; 1,559 km standard gage
(1.435 m), 960 km meter gage (1.00 m), 32 km narrow
gage (0.60 m), 16 km narrow gage (0.750 m); all
government-owned
Highways: 36,714 km; 18,223 km paved, 12,451
km crushed stone and gravel, 5,062 km improved
earth, 978 km unimproved earth
Inland waterways: system consists of 3 coastal
canals and 8 unconnected rivers which provide
navigable length of just less than 80 km
Pipelines: crude oil, 26 km, refined products, 547
km
Ports: 17 major, 87 minor
Airfields: 67 total, 62 usable; 44 with permanent-
surface runways; 17 with runways 2,440-3,659 m, 22
with runways 1,220-2,439 m
Civil air: 35 major transport aircraft (including 2
withdrawn from service)
Telecommunications: adequate modern networks
reach all areas on mainland and islands; 2.18 million
telephones; 3.25 million radio receivers; 1.1 million
TV receivers; 31 AM, 18 FM, and 38 TV stations; 4
coaxial submarine cables; 2 communications satellite
ground stations
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GREECE/GREENLAND
DEFENSE FORCES
Military manpower: males 15-49, 2,256,000;
1,728,000 fit for military service; about 75,000 reach
military age (21) annually
Military budget: est. for fiscal year ending 31
December 1976, $1.16 billion; about 19.3% of central
government budget','0f532c88f41702c5b2558bc23feda620b7ac07f30ab6faeaf5896e1afece60e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc5f879aa28c87d8bdd42faa5e5c809d4f4a2d623bb97f4ce381337d7f214379',1977,'GL','Greenland','communications',209,'(See reference map t}
LAND
2,175,600 km?; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow,
15% other
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: 44,087 km (approx., includes minor
islands)
Railroads: none
Highways: none
Ports: 9 major, 23 minor
Civil air: 9 major transport aircraft (registered in
Denmark)
Airfields: 11 total, 6 usable; 8 with permanent-
surface runways; 3 with runways 2,440-3,659 m, 2
with runways 1,220-2,489 m; 7 seaplane stations
Telecommunications: adequate domestic and
international service provided by cables and radio
relay; 9,000 telephones; 12,500 radiobroadcast
receivers; 5 AM, 2 FM, and 3 TV stations; 2 coaxial
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, included with
Sea Norwegian
suet: ICELAND Sea
Reykjavik
Atlantic
Ocean
(Sea reference map iV}
LAND
102,952 km?; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 nm
(fishing, 200 nm, effective 15 October 1975)
Coastline: 4,988 km
Railroads: none
Highways: 11,048 km; 7,896 km crushed stone
(including lava) and gravel, 3,008 km unsurfaced
roads and motorable tracks, 144 km concrete or paved
Ports: 4 major (Akureyri, Hafnarfjordhur,
Reykjavik, Seydhisfjordhur), and about 50 minor
Civil air: 25 major transport aircraft registered
Airfields: 122 total, 100 usable; 3 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 9 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: adequate domestic service,
wire and radio communication system; 93,400
telephones; 80,000 radio and 55,000 TV receivers; 17
AM, 14 FM, and 80 TV stations; 2 coaxial submarine
cables
DEFENSE FORCES
Military manpower: males 15-49, 53,000; 48,000
fit for military service (Iceland has no conscription or
compulsory military service)
(Denmark)
pide \\ 8
§ fceland
ne a
nae
mye
wetlna Sa 9 ach 2
eKuybyshev
“ Back eVolgograd
som, Back
“yer |
: he,
Turkey
on
fs,
f Caspian
Yerevan Sea
B Bad
(Tarai
Sea
@fashkent
* Tehran
Kate a iran
\\,
spOatar
Saudi
Arabia
t','9cbe9144a0ca953df0c9189cff8b69edc51b3e9de9b7c9a3c989b58ed1fa749b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('116b2d8d1bf032cede6fb6f2a99f86cf405252398a15ae249ff68c7d1dc1e632',1977,'GD','Grenada','communications',213,'"puerto
ew Atlantic
Ocean
Caribbean .
cy
(See reference map Hl)
LAND
844 km? (Grenada and southern Grenadines); 44%
cultivated, 4% pastures, 12% forests, 17% unused but
potentially productive, 23% built on, wasteland, other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 121 km
Railroads: none
Highways: 980 km; 600 km paved, 180 km
otherwise improved; 200 km unimproved
Ports: 1 major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent
surface runways, 1 with runway 1,220-2,439 m
Telecommunications: automatic, islandwide
telephone system with 5,250 telephones; VHF and
UHF links to Trinidad and Carriacou; 21,000 radios
and 150 TV receivers; 3 AM stations
1975); food,','7577f650522265b814da110bee6530db55601c85876f5e69bbb61ae99118698d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92d3693bbe59942dbb49df58d3b854aeb5273eabf812e19d4c10876b1ee5f66b',1977,'GP','Guadeloupe','communications',217,'LAND
1,779 km?; 24% cropland, 9% pasture, 4% potential
cropland, 16% forest, 47% wasteland, built on; area
consists of two islands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 306 km','9922406d6032bf61c3ee90c95f38b049ada10663a9115a399965a988d86cdb31','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79af8590fcc14dd24a99ea04d35f08ac70df31593bb06187d5ffde7b0292e469',1977,'MQ','Martinique','communications',222,'Railroads: privately owned, narrow-gage planta-
tion lines
Highways: 2,030 km; 1,500 km paved, 580 km
gravel and earth
Ports: 1 major (Pointe-a-Pitre), 8 minor
Civil air: 2 major transport aircraft
Airfields: 8 total, 8 usable, 8 with permanent-
surface runways; 1 with runway 2,440-3,659 m; 2
seaplane stations
Telecommunications: domestic facilities inade-
quate; 24,600 telephones; inter-island VHF radio
links; 2 AM and 3 TV transmitters; about 32,000 radio
and 14,700 TV receivers
DEFENSE FORCES
Military manpower: males 15-49, included with
DOMINICAN Atlantic Ocean
REPUBLIC
¥ oa
PUERTO *,
RiCD
Caribbean Sea
)
LAND
1,100 km?2; 31% cropland, 16% pasture, 29% forest,
24% wasteland, built on
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 290 km
Railroads: none
Highways: 1,450 km; 1,000 km paved, 450 km
gravel and earth
Ports: 1 major (Fort-de-France), 5 minor
Civil air: no major transport aircraft
134
Approved For Release 2005/04/22
Airfields: 8 usable; 1 with permanent-surface
runway; 1 with runway 2,440-8,659 m; 1 seaplane
station
Telecommunications: domestic facilities inade-
quate; 81,700 telephones, inter-island VHF and UHF
radio links; COMSAT ground station; 1 AM, 1 FM,
and 5 TV stations; about 45,000 radio and 20,040 TV
receivers
DEFENSE FORCES
Military manpower: males 15-49, included in','ca4d2fcc22b578d539cf72cf1e6435f949fcbc5d12dad1d6fcacb2c94d622dcd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2abc792e712d38a84f9cab296a2b72bab6b78f67de47ee444f199d2991f5b6b',1977,'GT','Guatemala','communications',223,'LAND
108,880 km?; 14% cultivated, 10% pasture, 57%
forest, 19% other
Land boundaries: 1,625 km
83
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Gulf of','68b947e4a9a710406425aaab27aeec8055450ce170a0b0372f7edec21441803e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b603e5a439986e660da4ba2c60b06dd5fd766e9a1f659b2c8e593642db81f5a1',1977,'MX','Mexico','communications',224,'Caribbean
ts EL
SALVADOR
Pacitic Ocean
(See reference map it}
WATER
Limits of territorial waters (claimed): 12 nm (200
nm exclusive economic zone)
Coastline: 400 km
Railroads: 947 km, 0.914-meter gage, single-
tracked; 832 km government-owned, 115 km privately
owned
Highways: 12,400 km, 2,650 km bituminous, 6,300
km gravel, 3,450 km improved or unimproved earth
Inland waterways: 260 km navigable year-round;
additional 780 km navigable during high-water
season
Pipelines: crude oil, 48 km
Ports: 2 major (Puerto Barrios, Santo Tomas de
Castilla), 3 minor
Airfields: 337 total, 337 usable; 7 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 17
with runways 1,220-2,439 m; 1 seaplane station
Civil air: 12 major transport aircraft plus 8
withdrawn from use
Telecommunications: modern telecom facilities
limited to Guatemala City; 57,400 telephones;
360,000 radio and 110,000 TV receivers; 97 AM, 20
FM, and 5 TV stations; connection into Central
American microwave net
DEFENSE FORCES
Military manpower: males 15-49, 1,457,000;
948,000 fit for military service; about 65,000 reach
military age (18) annually
Military budget: proposed for fiscal year ending 31
December 1976, $34.0 million; 6.77% of central
government budget','a329d27f8027ad013904791e39fb913d7aa4adab7a05f2a37ba6980d35011fe0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f47efce394ff1350fb2dadcb78730a4f458145121553e4c44c0a16c2b9a4903e',1977,'GW','Guinea-Bissau','communications',228,'(formerly Portuguese Guinea)
(See reference map Vi}
LAND
36,260 km? (includes Bijagos archipelago)
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 150 nm
Coastline: 274 km
Railroads: none
Highways: approx. 3,218 km (418 km bituminous,
remainder earth)
Inland waterways: 1,600 km
Ports: 1 major (Bissau), 2 minor
Civil air: no major transport aircraft
Airfields: 60 total, 60 usable; 5 with permanent-
surface runways; 10 with runways 1,220-2,439 m; 1
seaplane station
Telecommunications: limited system of open-wire
lines and radiocommunication stations; 2,700
telephones; 10,000 radio receivers; 1 AM, no FM or
TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 119,000; 68,000
fit for military service','b59fca1587c2192a3e36397b7ec6bc97323d3aa42c81ab773247db29e18e466b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('039703a3232e187ebc41dfd75e2e634baa50e8d7649094f60d82ce2ebf457b1f',1977,'GY','Guyana','communications',232,'LAND
214,970 km?; 1% cropland, 3% pasture, 8%
savanna, 66% forested, 22% water, urban, and waste
Land boundaries: 2,575 km
“Caribbean
a ee
oS VENEZUELA
(See reference map Hi)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 459 km
Railroads: 165 km, all single track; 107 km 0.914-
meter gage, 29 km 1.065-meter gage
Highways: 3,500 km; 800 km paved, 1,550 km
otherwise improved, 1,150 km unimproved
Inland waterways: 5,900 km; Demerara River
navigable to Mackenzie by ocean steamers, others by
ferryboats, small craft only
Ports: 1 major (Georgetown), 3 minor
88
Civil air: 7 major transport aircraft
Airfields: 96 total, 88 usable; 5 with permanent-
surface runways; 12 with runways 1,220-2,439 m; 2
seaplane stations
Telecommunications: highly developed telecom
system with radio relay network and over 21,300
telephones; tropospheric scatter link to Trinidad;
280,000 radio receivers, 3 AM and 1 FM stations
DEFENSE FORCES
Military manpower: males 15-49, 188,000; 143,000
fit for military service
Military budget: for fiscal year ending 31
December 1975, $13.4 million; 4.9% of central
government budget','3af19865b94e42a44df4e0015b8777c958d0d9626ed3c1f7e0e7252c1fc9d1aa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6425540619778c9d6f8c4f34d72f96f8800d4e72ba15bbe08410a88999efbd5f',1977,'HT','Haiti','communications',236,'aa
(See reference map It}
LAND
27,713 km?; 31% cultivated, 18% rough pastures,
7% forested, 44% unproductive
Land boundary: 361 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing 15 nm)
Coastline: 1,771 km
Railroads: 80 km narrow gage (0.760 m), single-
track, privately owned industrial line; 8 km dual-gage
0.760- to 1.065-meter gage, government line,
dismantled
Highways: 3,200 km; 600 km paved, 950 km
otherwise improved, 1,650 km unimproved
Inland waterways: negligible; about 100 km
navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), 12
minor
Civil air: 7 major transport aircraft
Airfields: 16 total, 15 usable; 3 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 5
with runways 4,000-7,999 ft.; 2 seaplane stations
Telecommunications: all domestic facilities
inadequate, international facilities slightly better;
telephone expansion program underway; 11,000
telephones, 300,000 radio and 13,800 TV receivers, 32
AM, 5 FM, and 1 TV station; COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 1,162,000;
617,000 fit for military service; about 52,000 reach
military age (18) annually
Military budget: for fiscal year ending 30
September 1976, $10.9 million; about 18.6% of
operational budget','b915346d66052fb26afd9612898225a6cd71ec1235e02eb5ca24f5bb43f4fcc8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adbd67eaa9cd80fb39411e0e1588305a541fd77451bc9db27a892247b326c716',1977,'HN','Honduras','communications',240,'LAND
112,150 km?; 27% forested, 30% pasture, 36% waste
and built-up, 7% cropland
Land boundaries: 1,530 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 820 km
Railroads: 574 km; 325 km 1.067-meter gage, 249
km 0.914-meter gage
Highways: 8,700 km; 1,150 km bituminous
surfaced, 2,500 km gravel surfaced or improved earth,
5,050 km unimproved earth
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
HONDURAS/HONG KONG
Inland waterways: 1,200 km navigable by small
craft
Ports: 3 major (Puerto Cortes, La Ceiba, Tela), 9
minor
Civil air: 24 major transport aircraft
Airfields: 240 total, 21 usable; 4 with permanent-
surface runways; 1 with runway 2,440-3,659 m; 8 with
runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: improved, but still inade-
quate; connection into Central American microwave
net; 16,000 telephones; 300,000 radio and 50,000 TV
receivers; 97 AM, 12 FM, and 5 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 666,000; 392,000
fit for military service; about 27,000 reach military
age (18) annually
Military budget: proposed for fiscal year ending 31
December 1976, $22.3 million; about 8.6% of central
government budget (includes the armed forces and
other military)
oe
Barbadas
Nicaragua < age ees obirenada
. *_S—e-SpTrinidad and Tobago Atlantic
* Caracas
North
B illag~
Canal zone ?
(U.S. amin)
on
ee
Patan
Ocean
Venezuela
-Georgetown
@Medeltin » Paramaribo
Cayenne
nch Guiana
.
me
Bogota','1c87f874f2a7f0e882b693554cd0d2ecec6e9f7bab190420e9c37d1c8a4045c2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('658ad6018ff40a4ef89ea57a342b4a8e0f4e9f601ee9587eee28afa5b949fcbe',1977,'PH','Philippines','communications',244,'(See reference map Vil}
LAND .
1,036 km?; 14% arable, 10% forested, 76% other
(mainly grass, shrub, steep hill country)
Land boundaries: 24 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 733 km
Philippine Sea
(Sea reference map Vit}
LAND
800,440 km?; 58% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 nm
(under an archipelago theory, waters within straight
lines joining appropriate points of outermost islands
are considered internal waters; waters between these
baselines and the limits described in the Treaty of
Paris, December 10, 1898, the U.S.-Spain Treaty of
163
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
November 7, 1900, and the U.S.-U.K. Treaty of
January 2, 1930 are considered to be the territorial sea)
Coastline: about 22,540 km
Railroads: 3,503 km; 2 common-carrier systems
1.067-meter gage totaling about 1,170 km; 19
industrial systems with 4 different gages totaling 2,333
km; 34% government owned
Highways: 99,133 km (1974); 20,293 km paved;
47,836 km gravel, crushed stone, or stabilized soil
surface; 31,003 km improved earth
Inland waterways: 3,219 km; limited to shallow-
draft (less than 1.5 m) vessels
Pipelines: refined products, 251 km
Ports: 11 major, 100 minor
Civil air: 66 major transport aircraft
Airfields: 382 total, 302 usable; 52 with
permanent-surface runways; 7 with runways 2,440-
3,659 m, 34 with runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 9,671,000;
6,567,000 fit for military service; about 450,000 reach
military age (20) annually
Supply: limited small arms ammunition, small
patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships
and equipment from Australia, Japan, Singapore,
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
U.S., and Italy; aircraft and helicopters from West
Germany and U.S.
Military budget: for fiscal year ending 80 June
1977, $672.9 million; about 18% of central
government budget','0342c686f178993a87a81de5603ccebf66fdf2d7b5030afaa62b4cd0bb2b5512','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c18b8d38f101ee5ea7b0080f0d204903db7447c959d18b66dd6c4ae1907a0b51',1977,'HK','Hong Kong','communications',248,'Railroads: 85 km standard gage (1.485 m);
government owned
Highways: 966 km; 660 km paved, 306 km gravel
and crushed stone, or earth
Ports: 1 major
Civil air: 18 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-
surface runways; 1 with runway 8,000-11,999 ft., 1
with runway 4,000-7,999 ft.; 1 seaplane station
Telecommunications: modern facilities provide
domestic and international services; excellent
broadcast coverage provided by wired and radio
broadcast stations; closed-circuit TV and TV
broadcast facilities; 988,545 telephones; 2.5 million
radio receivers; 100,000 wired-speakers; 2 F M, 2AM
stations; wired-broadcast network; 2 TV stations, 2
closed-circuit TV networks; 2 international com-
munications satellite ground stations; coaxial cable
link to Canton; 5 submarine cables; submarine cable
planned to Taiwan and Philippines
DEFENSE FORCES
Military manpower: males 15-49, 1,164,000;
906,000 fit for military service; about 53,000 reach
military age (18) annually
Defense is the responsibility of U.K.','e71679a998f2981f537093b5691e3f3c49f709df2238089f4a841b2743a7c5cd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c594ff5c5aba1b65a0ea239bff434b7e206b716a1fc57a8c29b53286ac03850c',1977,'HU','Hungary','communications',249,'LAND
92,981 km?; 60% arable, 14% other agricultural,
16% forested, 10% other
Land boundaries: 2,245 km
Railroads: 8,392 km; 7,879 km standard gage
(1.485 m), 478 km narrow gage (mostly 0.747 m), 35
km broad gage (1.524 m), 1,159 km double track,
1,303 km electrified; government owned (1975)
Highways: 30,000 km; 350 km concrete, 21,450 km
bituminous, 250 km stone block, 7,000 km gravel, 950
km earth (1975)
Inland waterways: 1,687 km (1976)
Pipelines: crude oil, 1,287 km; refined products,
290 km; natural gas, 2,896 km
Freight carried; rail—132.1 million metric tons,
23.5 billion metric ton/km (1975); highway—479.4
million metric tons, 8.1 billion metric ton/km (1975);
waterway—est. 14.2 million metric tons, 8.3 billion
metric ton/km incl. int’]. transit traffic (1975)
River ports: 2 principal (Budapest, Dunaujvaros);
no maritime ports; outlets are Rostock, GDR, and
Gdansk, Gdynia, and Szczecin in Poland
DEFENSE FORCES
Military manpower: males 15-49, 2,656,000;
2,141,000 fit for military service; about 74,000 reach
military age (18) annually
Military budget (announced): for fiscal year
ending 31 December 1976, 12.3 billion forints; about
4% of total budget','d7509c6fb154323d6194d95ab0462b16617d1bb07032c2f78004d2ba9cd6d0a1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baa00af9efb5bd6679453217814bea65a80a84abec7b00f5d320a38c89b41385',1977,'ID','Indonesia','communications',253,'South China
“= Sea
"Indian Ocean
(See reference map Vil)
LAND
1,906,240 km?; 12% small holdings and estates,
64% forests, 24% inland water, waste, urban, and
other
Land boundaries: 2,736 km
WATER
Limits of territorial waters (claimed): under an
archipelago theory, claim is 12 nm, measured seaward
from straight baselines connecting the outermost
islands
Coastline: 54,716 km
Railroads: 7,863 km; 7,246 km 1.067-meter gage,
525 km 0.750-meter gage, 92 km 0,600-meter gage;
211 km double track; 101 km electrified; government
owned
Highways: 92,473 km; 20,278 km paved, 40,555
km gravel or crushed stone, 31,640 km improved or
unimproved earth
Inland waterways: 21,579 km; Sumatra 5,471 km,
Java and Madura 820 km, Borneo 10,460 km, Celebes
241 km, and Irian Barat 4,587 km
Ports: 10 major, 63 minor
Civil air: 114 major transport aircraft (includes 2
leased)
Airfields: 330 total, 302 usable; 50 with
permanent-surface runways; 9 with runways 2,440-
3,659 m, 64 with runways 1,220-2,439 m
Telecommunications: extensive interisland mi-
crowave system, HF police net, and domestic satellite
system; international and domestic service very good;
radiobroadcast coverage good; 285,000 telephones; 5
million radio and 300,000 TV sets; 150 AM, 1 FM,
and 12 TV stations; 2 submarine cables to Singapore
no longer in service
IRAN
LAND
1,647,240 km?; 14% agricultural, 11% forested,
16% cultivable with adequate irrigation, 51% desert,
waste, or urban, 8% migratory grazing and other
Land boundaries: 5,318 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing, 50 nm)
Coastline: 3,180 km, including islands, 676 km
97
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
IRAN
Arabian
Sea
(See referenca map V)
Railroads: 4,509 km standard gage (1.435 m), 92
km 1.676-meter gage
Highways: 43,442 km; 12,060 km bituminous and
bituminous treated, 22,920 km gravel and crushed
stone, 8,462 km improved earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
at
=
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
IRAN/IRAQ
Inland waterways: 904 km, excluding the Caspian
Sea, 104 km on the Shatt al Arab
Pipelines: crude oil, 2,639 km; refined products,
3,597 km; natural gas, 2,317 km
Ports: 7 major, 6 minor
Civil air: 35 major transport aircraft
Airfields: 173 total, 162 usable; 64 with
permanent-surface runways; 12 with runways over
3,660 m, 16 with runways 2,440-3,659 m, 63 with
runways 1,220-2,439 m
Telecommunications: most advanced system in the
Middle East of high-capacity radio-relay links, open-
wire lines, cables, and tropospheric links; principal
center Tehran, secondary centers Isfahan, Meshed,
and Tabriz; 805,600 telephones; 2.0 million radio and
1.7 million TV receivers; 31 AM, 1 FM, and 67 TV
stations; satellite earth station
DEFENSE FORCES
Military manpower: males 15-49, 7,910,000;
4,688,000 fit for military service; about 340,000 reach
military age (21) annually
Military budget: for fiscal year ending 20 March
1977, $10,150,310,000; 34.9% of central government
budget','9da5749799d702abeda3460481f79f86ba484304e8ec26f5be8522b0228da434','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b194877fad56a681e96823cad1d27db01a4e62d17b26535278ccb360668bdea',1977,'IQ','Iraq','communications',257,'< Caspian
Sea
Baghdad,
{See reference map V}
LAND
445,480 km?; 18% cultivated, 68% desert, waste, or
urban, 10% seasonal and other grazing land, 4% forest
and woodland
Land boundaries: 3,668 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 58 km
Railroads: 1,700 km; 1,123 km standard gage
(1.435 m), 577 km meter gage (1.00 m); 16 km meter
gage double track
Highways: 20,791 km; 6,490 km paved, 4,645 km
improved earth, 9,656 km unimproved earth
Inland waterways: 1,015 km; Shatt al Arab
navigable by maritime traffic for about 104 km; Tigris
and Euphrates navigable by shallow-draft steamers
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,481 km; 40 km refined
products; 1,360 km natural gas
Civil air: 15 major transport aircraft
Airfields: 82 total, 71 usable; 22 with permanent-
surface runways; 42 with runways 2,440-3,659 m, 18
with runways 1,220-2,439 m
Telecommunications: network consists of open-
wire lines, radio-relay links, and radiocommunication
stations; 152,900 telephones; 1.25 million radio
receivers; 352,000 TV receivers; 7 AM, no FM and 3
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,566,000;
1,436,000 fit for military service; about 120,000 reach
military age (18) annually
Military budget: est. for fiscal year ending 31
December 1976, $3,377,237,000; 33.7% of central
government budget and 22.5% of est. GNP; no service
allocation is available (dollar value converted from
Iraqi dinars at official rate of 0.2961 dinars = US$1)','6e84905f8db17d5d34f739fd16c75448c75a40c4ac348b35a857d418317cc665','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cc546ffb2e47ac641d96451e1e5baa859b7d8d426f7571673e78ffbb919503c',1977,'IE','Ireland','communications',261,'LAND
68,894 km?; 17% arable, 51% meadows and
pastures, 3% forested, 2% inland water, 27% waste
and urban
Land boundaries: 360 km
100
Approved For Release 2005/04/22
. of, 6
ee al
{See reference map {¥)
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: 1,448 km
Railroads: 2,189 km 1.600-meter gage, govern-
ment-owned
Highways: 88,302 km; 78,616 km surfaced, 9,686
km earth
Inland waterways: approx. 1,000 km
Ports: 6 major, 38 minor
Civil air: 24 major transport aircraft
Airfields: 38 total, 38 usable; 8 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 4 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: small, modern system; all
cities interconnected for telephone and telegraph
service; 429,000 telephones; 900,000 radiobroadcast
receivers; 637,000 TV receivers; 6 AM, 7 EM, and 25
TV stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 722,000; 567,000
fit for military service; about 29,000 reach military
age (17) annually
Military budget: for fiscal year ending 31 March
1976, $133.5 million; about 5% of the central
government budget
(See reference map V)
NOTE: The Arab territories occupied since the
1967 war are not included in the data below.
LAND
20,720 km? (excluding about 64,750 km? of
occupied territory in Jordan, Egypt, and Syria); 20%
cultivated, 40% pastureland and meadows, 4%
forested, 4% desert, waste, or urban, 3% inland water,
29% unsurveyed :
Land boundaries: 1,036 km (1967); including
occupied areas, 789 km
101
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','442206ee6ffcea5c88005c1e7efc5577fe102493175680f511e23310b068006d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16d2825779e4267bb86dadf416101875fdf7764e1317ac49e86994c057476a83',1977,'IL','Israel','communications',265,'WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 273 km (1967); including occupied
areas, 1,488 km
Railroads: 767 km standard gage (1.485 m)
Highways: 11,000 km paved roads, remainder
unknown
Pipelines: crude oil, 708 km; refined products, 290
km; natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Airfields: 53 total, 45 usable; 20 with permanent-
surface runways; 5 with runways 2,440-3,659 m, 9
with runways 1,220-2,439 m
Civil air: 23 major transport aircraft
Telecommunications: second to Iran, the most
modern and highly developed in the Middle East;
735,200 telephones; 450,000 radio and 579,000 TV
receivers; 28 TV, 18 AM, and 10 FM stations; 1
submarine cable; earth satellite station
DEFENSE FORCES
Military manpower: Jewish males 15-49, 730,000;
630,000 fit for military service; average number of
Jews reaching military age (18) annually —28,000
males, 27,000 females; both sexes liable for military
service
Military budget: for fiscal year ending 31 March
1977, $4,271,551,000; about 39.6% of central
government budget','4fa456baaf8de58522aa01b48b83150e1a0d1c2401e8bcad4a7ebce8a5953ad3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c0da384656833becd6621e1a463349897e3fc0f1ac57e36d120ec6c11118934',1977,'IT','Italy','communications',269,'LAND
301,217 km?; 50% cultivated, 17% meadow and
pasture, 21% forest, 3% unused but potentially
productive, 9% waste or urban
Land boundaries: 1,702 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,996 km
Approved For Release 2005/04/22 :
(See reference map iV)
Railroads: 20,690 km; 15,970 km government-
owned standard gage (1.435 m), 7,850 km electrified;
4,720 km non-government owned, 2,507 km standard
gage (1.435 m), 1,270 km electrified; 2,213 km narrow
gage (0.950 m), 517 km electrified
Highways: 286,400 km: autostrade 4,800 km, state
highways 41,200 km, provincial highways 91,200 km,
communal highways 149,200 km; 254,400 km
concrete, bituminous, or stone block, 24,800 km
gravel and crushed stone, 7,200 km earth
Inland waterways: 2,500 km navigable routes
Pipelines: crude oil, 1,770 km; refined products,
1,448 km; natural gas, 12,779 km
Ports: 16 major, 22 significant minor
Civil air: 140 major transport aircraft
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ITALY/IVORY COAST
Airfields: 148 total, 148 usable; 83 with
permanent-surface runways; 2 with runways over
3,660 m, 29 with runways 2,440-3,659 m, 42 with
runways 1,220-2,439 m; 11 seaplane stations
Telecommunications: well engineered, well
constructed, and efficiently operated; 14.8 million
telephones; 13.7 million radio and 12.6 million TV
receivers; 91 AM, 602 FM, and 868 TV stations; 11
coaxial submarine cables; 4 communication satellite
ground stations
DEFENSE FORCES
Military manpower: males 15-49, 13,841,000;
11,586,000 fit for military service; 480,000 reach
military age (18) annually
IVORY COAST','c82b1dd65eb4fcedd804e04440ea779ae682529ea4408ce09917a2cd38d4c541','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84ef131d896dcaaea1c715b5f6d1b4a83dbc7c0ac3abc2b8561d601768e426e5',1977,'JM','Jamaica','communications',273,'JAMAICA ingston :
Caribbean Sea
{See reference mag Ii)
LAND
11,422 km?; 21% arable, 23% meadows and
pastures, 19% forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,022 km
Railroads: 326 km government-owned, 69 km
privately owned, all standard gage (1.485 m), single
track
Highways: 13,050 km; 4,850 km paved, 4,850 km
gravel, 3,350 km unimproved earth surfaces
Pipelines: refined products, 10 km
Ports: 3 major (Kingston, Montego Bay, Montego
Freeport), 10 minor
Civil air: 13 major transport aircraft plus 2 leased
aircraft
Airfields: 42 total, 22 usable; 12 with permanent-
surface runways; 2 with runways 2,440-8,659 m, 1
with runway 1,220-2,489 m; 3 seaplane stations
Telecommunications: fully automatic domestic
telephone network with 100,200 telephones; satellite
ground station; 600,000 radio and 110,000 TV
receivers: 8 AM, 8 FM, and 9 TV stations; 8 coaxial
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 442,000;
313,000 fit for military service; no conscription;
average number currently reaching minimum
volunteer age (18) 23,000
Supply: dependent on U.K. and U.S.
Pacifie
Ocean
Philippine
Sea
{See reference map Vi}
LAND
370,370 km?;16% arable and cultivated, 3%
grassland, 12% urban and waste, 69% forested
107
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','bd67fb58dadcc7c13ee456000ddd8f41031282c8f3bef7efb8d88071be3f0656','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29006cd4dff1cb924e646414f416c2539c59ad4b975623dd67e267046ba51213',1977,'JP','Japan','communications',277,'WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 12,075 km Japan: 1,610 km Ryukyus
Railroads: 28,912 km; 1,077 km standard gage
(1.435 m), 27,885 km predominantly narrow gage
(1.067 m), 6,195 km double track, 7,376 km or 26% of
total route length electrified; 78% government-owned
: CIA-RDP79-01051A000800010006-3
oy
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
JAPAN/JORDAN
Highways: 1,059,100 km (1974); 308,784 km
paved, most of remainder gravel or crushed stone
Inland waterways: approx. 1,770 km; seagoing
craft ply all coastal “inland seas”
Pipelines: crude oil, 82 km; natural gas, 983 km
Ports: 53 major, over 2,000 minor
Civil air: 230 major transport aircraft (includes 2
leased)
Airfields: 183 total, 181 usable; 119 with
permanent-surface runways; 2 with runways over
3,660 m; 22 with runways 2,440-3,659 m, 44 with
runways 1,220-2,439 m, 5 seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 31,351,000;
26,433,000 fit for military service, about 810,000
reach military age (18) annually
Military budget: for fiscal year ending 31 March
1977, $5.1 billion proposed; about 6% of total budget
China Sea
{See reference map Vil)
LAND
126,900 km?; 17% arable and cultivated, 74% in
forest, scrub, and brush; remainder wasteland and
urban
Land boundaries: 1,675 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,495 km
Railroads: 4,535 km operating in 1976; 3,870 km
standard gage (1.435 m), 665 km narrow gage (0.762
m); 159 km double tracked; about 1,080 km
electrified; government-owned
Highways: about 20,278 km; 98.5% gravel,
crushed stone, or earth surface; 1.5% concrete or
bituminous
Inland waterways: 2,253 km; mostly navigable by
small craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,776,000;
2,242,000 fit for military service; 189,000 reach
military age (18) annually
KOREA, SOUTH
(See reference map Vil)
LAND
98,400 km?; 28% arable (22% cultivated), 10%
urban and other, 67% forested
Land boundaries: 241 km
WATER
Limits of territorial waters: 3 nm (fishing, 12 nm)
Coastline: 2,413 km
Freight carried: rail (1978) 4.8 billion metric
ton/km, 34.2 million metric tons; highway 21.8
million metric tons; air (1959) 361,184 kg carried
Pipelines: 515 km refined products
Ports: 10 major, 18 minor
Civil air: 28 major transport aircraft
Airfields: 121 total, 115 usable; 53 with
permanent-surface runways; 15 with runways 2,440-
113
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
KOREA, SOUTH/KUWAIT
8,659 m, 17 with runways 1,220-2,439 m; 2 seaplane
Stations
DEFENSE FORCES
Military manpower: males 15-49, 8,439,100;
5,492,000 fit for military service; average number
reaching military age (18) annually 368,000
Military budget: for fiscal year ending 31
December 1977, $1.9 billion; about 34% of central
government budget
Railroads: none
Highways: 784 km; 375 km bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports: 1 principal (Apia), 1 minor
Civil air: 2 major transport aircraft
Airfields: 4 total, all usable; 1 with permanent
surface runway 1,220-2,439 m
Telecommunications: 2,600 telephones; 20,000
radio receivers; 1 AM station
YEMEN (ADEN)
Arabian
(See reference map V}
LAND
287,490 km?; (border with Saudi Arabia un-
defined); only about 1% arable (of which less than
25% cultivated)
Land boundaries: 1,802 km
WATER
Limits of territorial waters (claimed): 12 nm (plus
6 nm “necessary supervision zone’)
Coastline: 1,383 km','17312b76115070d82eff64ccc877b6a2e9d5de53e7940ceab8597d7d4dd5a733','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b616d67a586f0acbb6d49175d6dfae6dcd0ea8733d52d89f84a2a15964da9e97',1977,'JO','Jordan','communications',281,'(See reference map Vv}
NOTE: The war between Israel and the Arab states
in June 1967 ended with Israel in control of West
Jordan. Although approx. 930,000 persons resided in
this area prior to the start of the war, fewer than
750,000 of them remain there under the Israeli
occupation, the remainder having fled to East Jordan.
Over 14,000 of those who fled were repatriated in
August 1967, but their return has been more than
offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These
and certain other effects of the 1967 Arab-Israeli war
are not included in the data below.
LAND
96,089 km? (including about 5,439 km? occupied by
Israel); 11% agricultural, 88% desert, waste, or urban,
1% forested
Land boundaries: 1,770 km (1967, 1,668 km
excluding occupied areas)
Approved For Release 2005/04/22
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 26 km
Railroads: 817 km 1.050-meter gage, single track
Highways: 7,080 km; 5,880 paved, 200 km
improved earth; 1,000 km unimproved earth
Pipelines: crude oil, 209 km
Ports: 1 major (Aqaba)
Civil air: 11 major transport aircraft
Airfields: 25 total, 16 usable; 12 with permanent-
surface runways; 2 with Tunways over 3,660 m, 11
with runways 2,440-3,659 m, 1 with runway 1,220-
2,439 m
Telecommunications: adequate telecommunica-
tion system for the needs of the country; 40,500
telephones; 529,000 radio and 205,000 TV receivers; 1
AM station, no FM station, and 1 TV station; 1 earth
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 605,000; 431,000
fit for military service; average number currently
reaching military age (18) annually 30,000
Military budget: for fiscal year ending 31
December 1976, $155,963,300; 19.4% of central
government budget
110
Approved For Release 2005/04/22 :
/ndian
Qcean
(See reference map Vif
LAND
582,750 km?; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland
adequate for grazing (1971)
Land boundaries: 3,368 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 586 km
Railroads: 2,040 km meter gage (1.00 m)
Highways: 52,372 km; 4,022 km paved, 48,350 km
gravel and/or earth
Approved For Release 2005/04/22
KENYA/KOREA, NORTH
Inland waterways: part of Lake Victoria and Lake
Rudolph are within boundaries of Kenya
Ports: 1 major (Mombasa), 3 minor
Civil air: 8 major transport aircraft
Airfields: 234 total, 215 usable; 6 with permanent-
surface runways; 1 with runway over 3,660 m, 2 with
runways 2,440-3,659 m, 41 with runways 1,220-
2,439 m
Telecommunications: in top group of African
systems; consists of radio-relay links, open-wire lines,
and radiocommunication stations, principal center
Nairobi, secondary centers Mombasa and Nakuru;
113,700 telephones; 774,000 radio and 37,500 TV
receivers; 4 AM, 1 FM, and 5 TV stations; satellite
ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,001,000;
1,841,000 fit for military service; no conscription
Military budget: for fiscal year ending 30 June
1976, $44,925,101; about 4.8% of central government
budget
KOREA, NORTH','9574d9786b919ab790184b1016713fe08ba9c2117281b27744f43bfa35bde793','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97b56031820e0880b4d6a59b43ceeb046173e83960fa1db1add725db720b68c5',1977,'KW','Kuwait','communications',285,'(See reference map V)
LAND
16,058 km? (excluding neutral zone but including
islands); insignificant amount forested; nearly all
desert, waste, or urban
Land boundaries: 459 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 499 km
Railroads: none
Highways: 2,494 km; 748 km bituminous; 1,746
km earth, sand, light gravel
Pipelines: crude oil, 877 km; refined products, 40
km; natural gas, 121 km
Ports: 3 major (Ash Shuwaikh, Ash Shuaybah,
Mina al Ahmadi), 4 minor
Civil air; 12 major transport aircraft
Airfields: 11 total, 6 usable; 4 with permanent-
surface runway; 1 with runway 2,440-3,659 m, 5 with
runways 1,220-2,439 m
Telecommunications: excellent international
and adequate domestic telecommunication facilities,
108,600 telephones; 500,000 radio and 135,000 TV
sets; 3 AM, no FM and 8 TV stations; satellite ground
station
DEFENSE FORCES
Military manpower: males 15-49, about 832,000;
about 192,000 fit for military service
Military budget: for fiscal year ending 31 March
1976, $222,428,950; 8% of central government budget
LAOS
(See reference map Vil}
LAND
236,804 km?; 8% agricultural, 60% forests, 32%
urban, waste, and other; except in very limited areas,
soil is very poor; most of forested area is not
exploitable
Land boundaries: 5,053 km
Highways: about 18,000 km; 1,300 km bituminous
or bituminous treated, 5,900 km gravel, crushed stone,
or improved earth; 10,800 km unimproved earth and
often impassable during rainy season mid-May to
mid-September
Inland waterways: about 4,587 km, primarily
Mekong and tributaries; 2,897 additional kilometers
are sectionally navigable by craft drawing less than
0.5 m
Ports (river): 5 major, 4 minor
Airfields: 116 total, 89 usable; 7 with permanent-
surface runways; 12 with runways 1,220-2,439 m, 1
with runway 2,440-3,659 m
DEFENSE FORCES
Military manpower: males 15-49, 808,000; 431,000
fit for military service; average number currently
reaching usual military age (18) annually, 34,000; no
conscription age specified
Military budget: no expenditure estimates are
available for FY76
116','1980a9e9a1040329a609961e57a602b89591a635c0ef40c3574596df6bc9467c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('365f880fa92be69e9dfbec921fb073c61fdb157e2fe405f0a46abb9b03609d9f',1977,'LB','Lebanon','communications',289,'(See reference map Vj
LAND
10,360 km?; 27% agricultural land, 64% desert,
waste, or urban, 9% forested
Land boundaries: 531 km
WATER
Limits of territorial waters (claimed): no specific
claims (fishing, 6 nm)
Coastline: 225 km
Railroads: 383 km; 296 km standard gage
(1.435 m), 82 km 1.050-meter gage; all single track
Highways: 7,370 km; 6,270 km paved, 450 km
gravel and crushed stone, 650 km improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 29 major transport aircraft
Airfields: 5 total, 3 usable; 3 with permanent-
surface runways; 3 with runways 2,440-3,659 m
Telecommunications: excellent international
telecommunication facilities include satellite ground
station; good domestic telephone and telegraph
service; 227,000 telephones; 1.3 million radio and
410,000 TV receivers; 2 FM, 1 AM, and 7 TV stations;
1 submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 500,000; 850,000
fit for military service; average of about 25,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1976, $145,355,620; 19% of central
government budget','5782ba2d957409aa49c8d639e55b98ebd745366bd1c22b85343249c48184e68e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e9ea4ac20df31c8fae1a3cb9b1c77ccdd2771ff9c0542ca1c2cb8ef177e7af3',1977,'LS','Lesotho','communications',293,'LAND
30,303 km?; 15% cultivable; largely mountainous
Land boundaries: 805 km
Railroads: 1.6 km; owned, operated, and included
in the statistics of the Republic of South Africa
Highways: approx. 2,327 km; 212 km paved; 843
km crushed stone, gravel, or stabilized soil: remainder
improved or unimproved earth
Civil air: no major transport aircraft
Airfields: 21 total, 20 usable; 3 with runways
1,220-2,489 m, 1 with permanent surface runway
Telecommunications: system a modest one
consisting of a few landlines, a small radio-relay
system, and minor radiccommunication stations;
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LESOTHO/LIBERIA
Maseru is the center; 3,725 telephones; 22,000 radio
receivers; 2 AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 220,000; fit for
military service 122,000','d0aaa64503ecb1aa556935c384b7cd200add621c651939f3739069fc3c7d2b91','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02a83bf296b6c165d19efc11a0bd8d430ffae7db4c882944e71ea4b2500fffeb',1977,'LR','Liberia','communications',297,'Monrovia
Atlantic Ocean
{See reference map Vl)
LAND
111,370 km?; 20% agricultural, 30% jungle and
swamps, 40% forested, 10% unclassified
Land boundaries: 1,336 km
WATER
Limits of territorial waters (claimed): 22 nm
Coastline: 579 km
Railroads: 502 km; 354 km standard gage (1.435
m), 145 km narrow gage (1.067 m); all lines single
track; rail systems owned and operated by foreign
steel and financial interests in conjunction with
Liberian Government
Highways: 7,952 km; 334 km bituminous treated;
remainder improved and unimproved laterite, gravel,
and/or earth
Inland waterways: 370 km
Ports: 3 major (Monrovia, Buchanan, Greenville-
Sino Harbor), 4 minor
Civil air: 1 major transport aircraft
Airfields: 80 total, 78 usable; 2 with permanent-
surface runways; 1 with runway 2,440-8,659 m, 6 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: telephone and telegraph
limited; main center is Monrovia; 3,400 telephones;
264,000 radio and 8,800 TV receivers; 5 AM, no FM,
and 5 TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 419,000; 224,000
fit for military service; no conscription
Military budget: for year ending 31 December
1976, $4.7 million; 3.6% of central government
budget','415f340dc5b2b3941657cce64ccb4b913b701e446591f4645e2c983645fcde78','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60e7ae3a43e661c71aef8925410b8b75bc2620c582e43457aca1e3d761ce09e7',1977,'LY','Libya','communications',301,'LAND
1,758,610 km?; 6% agricultural, 1% forested, 93%
desert, waste, or urban
Land boundaries: 4,345 km
WATER
Limits of territorial waters (claimed): 12 nm
(except for Gulf of Sidra where sovereignty is claimed
and northern limit of jurisdiction fixed at 32°30''N.
120
{See reterence map Vi}
and the unilaterally proclaimed 100 nm zone around
Tripoli)
Coastline: 1,770 km','d21cb912793ad21637b765aec046fe86654ef22256c1ac41efd5b6d2d8610fea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b909ddee30a456c5a641518e284fa8a2fa8f8254aad0126423b75f860da2d0dc',1977,'LI','Liechtenstein','communications',305,'(See reference map W)
LAND
168 km?
Land boundaries: 76 km
Railroads: 16.00 km, standard gage (1.435 m),
electrified; owned, operated, and included in statistics
of Austrian Federal Railways
Highways: no information on total kilometers
122
Approved For Release 2005/04/22
Civil air: 2 major transport aircraft registered in','4da7adbe51f414bcd6438c368bf0ebd6f5b58a9e58d9f6baa26ced243eb0c4d7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97a8fca926c95dedfad136470b709354b17b63d7bdcc295fa58a11217fcd3e53',1977,'CH','Switzerland','communications',309,'Airfields: none
Telecommunications; automatic telephone system
serving about 15,900 telephones; no broadcast
facilities; 5,500 radio and 4,700 TV receivers
(programs from Switzerland)
DEFENSE FORCES
Defense is responsibility of Switzerland
LAND
41,440 km?; 10% arable, 43% meadows and
pastures, 20% waste or urban, 24% forested, 3%
inland water
Land boundaries: 1,884 km
Railroads: 5,098 km; 2,895 km government-owned
(SBB), 2,822 km standard gage (1.485 m); 73 km
narrow gage (1.00 m); 1,339 km double track, 99%
electrified; 2,203 km non-government owned, 710 km
standard gage (1.435 m), 1,418 km meter-gage (1.00
m), 75 km 0.790-meter gage, 100% electrified
Highways: 60,512 km, all paved
Pipelines: 314 km crude oil; 1,046 km natural gas
Inland waterways: 65 km; Rhine River-Basel to
Bheinfelden, Schaffhausen to Constanz; in addition,
there are 12 navigable lakes ranging in size from Lake
Geneva to Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 80 major transport aircraft
Airfields: 79 total, 73 usable; 40 with permanent-
surface runways; 2 with runways over 3,660 m, 8 with
runways 2,440-3,659 m, 11 with runways 1,220-
2,439 m
Telecommunications: excellent domestic, interna-
tional, and broadcast services; 3.96 million
telephones; COMSAT station; 2.09 million radio and
1.79 million TV receivers; 7 AM, 94 FM, and 332 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 1,539,000;
1,331,000 fit for military service; 49,000 reach military
age (20) annually
Military budget: for fiscal year ending 31
December 1976, $1,186 million; 19.7% of central
government budget
SYRIA
LAND
186,480 km? including 1,295 km? of Israeli-
occupied territory; 48% arable, 29% grazing, 2%
forest, 21% desert
Land boundaries: 2,196 km (1967) (excluding
occupied area 2,156 km)
WATER
Limits of territorial waters (claimed): 12 nm (plus
6 nm “necessary supervision zone’’)
Coastline: 193 km
Approved For Release 2005/04/22 :
(See reference map V)
Railroads: 1,543 km; 1,281 km standard gage, 262
km narrow gage (1.050 m)
Highways: 11,500 km; 6,930 km paved, 1,800 km
gravel or crushed stone, 2,470 km improved earth, 800
km unimproved earth
Inland waterways: 672 km; of little importance
Pipelines: 1,304 km crude oil; 515 km refined
products
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
Civil-air: 9 major transport aircraft
200
Airfields: 38 total, 33 usable; 24 with permanent-
surface runways; 22 with runways 2,440-3,659 m, 2
with runways 1,220-2,439 m
Telecommunications: good international and
domestic service; 143,300 telephones; 1 million radio
and 224,000 TV receivers; 5 AM, no FM and 5 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 1,761,000,
984,000 fit for military service; about 93,000 reach
military age (19) annually
Military budget: for fiscal year ending 31
December 1975, $713,243,000; 25.2% of central
government budget
TANZANIA
TANZANIA
\\_Dar es Salaam
(See reference map VI)
LAND
939,652 km? (including islands of Zanzibar and
Pemba, 2,642 km?); 6% inland water, 15% cultivated,
31% grassland, 48% bush forest, woodland, on
mainland, 60% arable, of which 40% cultivated on
islands of Zanzibar and Pemba
Land boundaries: 3,883 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 1,424 km (this includes 113 km Mafia
Island; 177 km Pemba Island; and 212 km Zanzibar)
Railroads: 3,555 km; 960 km 1.065-meter gage;
2,595 km meter gage (1.00 m), 6.4 km double track;
Tanzania portion of Tan-Zam Railroad completed
Highways: total 42,695 km, including 627 km on
Zanzibar Island and 445 km on Pemba and Mafia
Islands; about 2,625 km bituminous treated (595 km
on Zanzibar and Pemba); 40,070 km gravel, crushed
stone, or unimproved earth
Pipelines: 982 km crude oil; 225 km natural gas
Inland waterways: 730 mi. of navigable streams;
several thousand mi. navigable on Lakes Tanganyika,
Victoria, and Nyasa
201
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TANZANIA/THAILAND
Ports: 3 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 10 major transport aircraft
Airfields: 107 total, 100 usable; 9 with permanent-
surface runways; 1 with runway 2,440-8,659 m, 42
with runways 1,220-2,439 m
Telecommunications: telephone and telegraph
good in main centers, only fair outside main towns;
58,000 telephones; 232,000 radio receivers; 4 AM, no
FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,557,000;
2,041,000 fit for military service
Military budget: for fiscal year ending 30 June
1977, $154.9 million; 17% of central government
budget ;
Bay
of Bengal
; Gulf of
‘ndian Ocean Thaitend
| PTHAILAND gti, South
ts, Bangko _—~v :
MABAYSIA
(See reference map Vil)
LAND
512,820 km?; 24% in farms, 56% forested, 20%
other
Land boundaries: 4,868 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,219 km
Railroads: 3,833 km meter gage (1.00 m), 97 km
double track
Highways: 28,806 km; 14,773 km paved, 4,731 km
crushed stone or gravel, 9,302 km earth and laterite
Inland waterways: 3,999 km mi. principal
waterways; 3,701 km with navigale depths of 0.9 m or
more throughout the year; numerous minor
waterways navigable by shallow-draft native craft
Ports: 2 major, 16 minor
Civil air: 25 major transport aircraft
Airfields: 158 total, 157 usable; 55 with
permanent-surface runways; 10 with runways 2,440-
3,659 m, 28 with runways 1,220-2,439 m
Telecommunications: service to general public
improved, but inadequate; bulk of service to
government activities provided by radiocommunica-
tion stations and radio-relay network; satellite ground
station; 312,000 telephones; over 3 million radios; and
over 650,000 televisions; approx. 110 AM, 30 FM, and
10 TV stations in government-controlled networks
DEFENSE FORCES
Military manpower: males 15-49, 11,018,000;
6,707,000 fit for military service; about 462,000 reach
military age (18) annually
Military budget: for fiscal year ending 30
September 1977, $604 million; 17.9% of central
government budget','233207c0eb15fbcf528d599606ef4b0a54a2121d5359b9c3c678f9b1d7532bc9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('170d64ede1454cb586a91d4d9594cb08f2674addae1b81f0716495108d6a1308',1977,'LU','Luxembourg','communications',310,'(See reference map IV}
LAND
2,590 km?; 25% arable, 27% meadows and pasture,
15% waste or urban, 33% forested, negligible amount
of inland water
Land boundaries: 356 km
Railroads: 270 km standard gage (1.435 m); 160
km double track; 136 km electrified
Highways: 4,528 km; all paved; about 80 km
limited access divided highway completed or under
construction
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 11 major transport aircraft (includes 3
registered in Iceland)
Airfields: 1 total, 1 usable with permanent-surface
runway 2,440-3,659 m
Telecommunications: adequate and efficient
system; 153,100 telephones; 200,000 radiobroadcast
receivers; 85,000 TV receivers; 2 AM, 1 FM, 2 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 82,000; 69,000
fit for military service; about 8,000 reach military age
(19) annually
Military budget: for fiscal year ending 31
December 1976, $23,234,000; 3.1% of the central
government budget','8ba595d8b30b04fc6499c0170ed57f1eaf3af7538c03eaa899f4d6b22dcec9ea','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d4e9f49f3d8df9b5ecf714b458e9605be94c142285f2876cc5e9df83770abf7',1977,'MO','Macao','communications',314,'LAND
15.5 km?; 10% agricultural, 90% urban
Land boundaries: 201 m
123
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MACAO/MADAGASCAR
ONG KONG
PHILIPPINES {
{See reference map Vii}
WATER
Limits of territorial waters (claimed): 6 nm;
fishing, 12 nm
Coastline: 40 km
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern communica-
tion facilities provide adequate services for domestic
and international requirements; broadcasting
coverage is provided by AM and FM radio facilities
and a wired broadcast network; 9,633 telephones;
65,000 radio receivers; 2 AM, 1 FM and no TV
stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000
fit for military service
Defense is responsibility of Portugal
Personnel: there are no Portuguese military
personnel in Macao','66eeddc0f7cf1bc8b8a44c99234289cc6435859ccf6e3ca00152454032e3241d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa2e42c82c40e672a9423f66cc5434bd8c63561eb567b75a2968e2053a51015d',1977,'MG','Madagascar','communications',318,'LAND
595,700 km?; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 4,828 km
Railroads: 884 km of meter gage (1.00 m)
Highways: 26,992 km; 4,285 km paved, 228 km
crushed stone, gravel, or stabilized soil; remainder
improved and unimproved earth
Inland waterways: 965 km (only local importance)
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 6 major transport aircraft
Airfields: 249 total, 129 usable; 28 with
permanent-surface runways; 3 with runways 2,440-
8,659 m, 47 with runways 1,220-2,439 m
Telecommunications: system above African
average; includes open-wire lines, some radio-relay
and coaxial links and a communication satellite
ground station; 29,300 telephones; 608,000 radio and
7,500 TV receivers; 1 AM station, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, 1,683,000;
993,000 fit for military service; average number
reaching military age (20) annually about 82,000
Supply: nearly all from France in the past, now
mostly from West and East European countries
Military budget: for fiscal year ending 31
December 1976, $40.2 million; about 7% of central
government budget','a171a5ed16f6180bf1fd8d9ceae2e28940bdc6ab6df348bf4fa43b4ebdc7d4e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05eda623b7b78a7e774fd76eeda53d7bc55cdbcb882cf288ded864aca551e059',1977,'MW','Malawi','communications',322,'LAND
95,053 km?; about 31% of land area arable (of
which less than half is cultivated), nearly 25%
forested, 6% meadow and pasture, 38% other
126
Approved For Release 2005/04/22
{See reference map Vi}
Land boundaries: 2,881 km
Railroads: 563 km 1.065-meter gage
Highways: 11,814 km; 1,245 km paved; 507 km
crushed stone, gravel, or stabilized soil; 6,157 km
unimproved earth
Inland waterways: Lake Malawi, 1,290 km and
Shire River, 144 km
Ports: 3 lake
Civil air: 6 major transport aircraft
Airfields: 47 total, 45 usable; 1 with permanent-
surface runway; 7 with runways 1,220-2,439 m
Telecommunications: the system is barely above
average for African countries and consists of thinly
spread open-wire lines, radio-relay links, and
radiocommunication stations; principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 19,350
telephones; 127,000 radio receivers; 5 AM, 4 FM and
no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,041,000; about
528,000 fit for military service','41bf873657e5351de4a7e3873ac6ce369167d5d64c70c5732d9b66d61250bcca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d81c03d46b3e7f7dc602e5619d0f2586165c27659721d3e274f869f5a3daba61',1977,'MY','Malaysia','communications',326,'South China
Sea
(See reference map Vi)
NOTE: Malaysia, which came into being on 16
September 1963, consists of Peninsular Malaysia,
which includes 11 states of the former Federation of
Malaya, plus East Malaysia, which includes the 2
former colonies of North Borneo (renamed Sabah) and
Sarawak
LAND
Peninsular Malaysia: 131,313 km*; 20% culti-
vated, 26% forest reserves, 54% other
Sabah: 76,146 km?; 18% cultivated, 34% forest
reserves, 53% other
Sarawak: 125,097 km?; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: 509 km Peninsular Malaysia,
1,786 km East Malaysia
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,068 km Peninsular Malaysia, 2,607 km
East Malaysia
Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter gage;
13 km double track; government-owned
East Malaysia: 154 km meter gage (1.00 m) in
Sabah
Highways:
Peninsular Malaysia: 18,100 km; 15,786 km
hard surfaced (mostly bituminous surface treatment),
1,569 km crushed stone/gravel, 745 km improved or
unimproved earth
East Malaysia: about 4,544 km (1,644 km in
Sarawak, 2,899 km in Sabah); 819 km hard surfaced
(mostly bituminous surface treatment), 2,936 km
gravel or crushed stone, 1,284 km earth
Inland waterways:
Peninsular Malaysia: 3,194 km
East Malaysia: 4,087 km (1,569 km in Sabah,
2,518 km in Sarawak)
Ports:
Peninsular Malaysia: 2 major, 13 minor
East Malaysia: 1 major, 14 minor (5 minor in
Sabah; 1 major, 9 minor in Sarawak)
Civil air: 25 major transport aircraft (including 1
Boeing 707 leased from U.K.)
Pipelines: crude oil, 69 km; refined products, 56
km
Airfields:
Peninsular Malaysia: 72 total, 72 usable; 16
with permanent-surface runways; 2 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Sabah: 33 total, 33 usable; 5 with permanent-
surface runways; 1 with runway 2,440-3,659 m; 4 with
runways 1,220-2,439 m
Sarawak: 44 total, 44 usable; 5 with permanent-
surface runways; 4 with runways 1,220-2,489 m
Telecommunications:
Peninsular Malaysia: good intercity service
provided mainly by microwave relay; international
service good; good coverage by radio and television
broadcasts; 220,000 telephones; 450,000 radio and
2,600,000 TV receivers; 26 AM, 1 FM, and 16 TV
stations; submarine cables extend to India, Ceylon,
and Singapore; connected to SEACOM submarine
cable terminal at Singapore by microwave relay; 1
ground satellite station
129
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MALAYSIA/MALDIVES
Sabah: adequate intercity radio-relay network
extends to Sarawak via Brunei; 18,500 telephones;
35,500 radio receivers; 3,200 TV receivers; 5 AM, 1
FM, 5 TV stations; SEACOM submarine cable links
to Hong Kong and Singapore; 1 gound satellite
station
Sarawak: adequate intercity radio-relay network
extends to Sabah via Brunei; 22,000 telephones;
107,000 radio and 1,000 TV receivers; 4 AM stations,
no FM, and 1 TV station
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males 15-49, 2,843,000;
1,780,000 fit for military service
Sabah: males 15-49, 195,000; 118,000 fit for
military service
Sarawak: males 15-49, 262,000: 156,000 fit for
military service; conscription age for Malaysia is 21—
an age reached by about 122,000 annually
External defense dependent on loose Five Power
Defense Agreement (FPDA) which replaced Anglo-
Malayan Defense Agreement of 1957 as amended in
1963
Military budget: for fiscal year ending 31
December 1976, $399.1 million; about 14% of central
government budget','1d2786fc9e9539d3cf8298fbf79af7620094b6d0269f02623b71ee8454481ded','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe0e87280283a52ff26b3d42814df01efce15f3e36f4b2963d39e0dd66ada74',1977,'MV','Maldives','communications',330,'= Indian Ocean
{See reference map Vil)
LAND
298 km?; 2,000 islands grouped into 12 atolls, about
220 islands inhabited
WATER
Limits of territorial waters (claimed): the land
and sea between latitudes 7°9’N. and 0°45''S. and
between longitudes 72°30’E. and 73°48''E; these
coordinates form a rectangle of approximately 37,000
130
Approved For Release 2005/04/22 :
nm’; territorial sea ranges from 2.75 to 55 nm; fishing,
approximately 100 nm
Coastline: 644 km (approx.)
Railroads: none
Highways: none
Ports: 2 minor
Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-
surface runways; | with runway 2,440-3,659 m, 1 with
runway 1,220-2,439 m
Telecommunications: minimal domestic and
international telecommunication facilities; 350
telephones; 2,460 radio sets; 1 AM station
E
{See valorioie = vy
LAND
1,204,350 km?; only about a fourth of area arable,
forests negligible, rest sparse pasture or desert
Land boundaries: 7,459 km
Railroads: 644 km meter gage (1.00 m)
Highways: approximately 13,208 km; 1,642 km
bituminous, 2,967 km gravel and improved earth,
remainder unimproved earth
Inland waterways: 1,815 km navigable
Civil air: 8 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-
surface runways; 2 with runway 2,440-3,659 m, 10
with runways 1,220-2,439 m
Telecommunications: system poor and provides
only minimum service to government, business, and
public; open-wire and radiocommunication used for
long distance telecommunications; radio sometimes
only link to outlying points; 7,800 telephones; 81,000
radio receivers; 2 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,334,000;
749,000 fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1976, $19,419,900; about 18% of central
government budget
(See reference map 1V}
LAND
313 km?; 45% agricultural, negligible amount
forested, remainder urban, waste, or other (1965)
WATER
Limits of territorial waters (claimed): 6 nm
(fishing 20 nm)
Coastline: 140 km
Highways: 1,239 km; 1,128 km paved (asphalt), 79
km crushed stone or gravel, 32 km improved and
unimproved earth
Ports: 1 major (Valletta), 2 minor
Civil air: 2 major transport aircraft (both leased)
Airfields: 4 total, 2 usable; 2 with permanent-
surface runways; 2 with runways 1,220-2,439 m; 1
seaplane station
Telecommunications: modern automatic tele-
phone system centered in Valletta; 51,900 telephones;
140,000 radio and 75,000 television receivers; 1 TV, 5
AM, and 4 FM stations, 8 submarine cables,
including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 89,000; 67,000
fit for military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment
from Italy
Military budget: for fiscal year ending 31 March
1977, $7,792,248; about 6.8% of central government
budget
Approved For Release 2005/04/22 :','afff21c708c38930f3ebeff4ab523076a50bdeeecd79fc1aaaf2513106c1fe32','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7247b534f6eba26d2802e0616db8f63305b6a4bcec568c1dc3946d42f65e595',1977,'MR','Mauritania','communications',335,'Nouakchott
\\).
(See reference map Vi}
LAND
1,085,210 km?; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 5,118 km
WATER
Limits of territorial waters (claimed): 30 nm
(fishing, 36 nm)
Coastline: 754 km
Railroads: 644 km standard gage (1.435 m), single
track, privately owned
Highways: 6,090 km; 558 km paved; 607 km
gravel, crushed stone, or otherwise improved; 4,925
km unimproved
Inland waterways: 800 km
Ports: 1 major (Nouadhibou), 2 minor
Civil air: 6 major transport aircraft
Airfields: 30 total, 30 usable; 9 with permanent-
surface runways; 1 with runway 2,440-3,659 m; 16
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: poor system of fragmentary
open-wire lines, a minor radio-relay link, and
radiocommunications stations; 1,300 telephones,
82,000 radio receivers; 1 AM, no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 314,000; 152,000
fit for military service; conscription law not
implemented
Supply: primarily dependent on France; has also
received material from Algeria, Morocco, U.K., and','9bc42c6922270825f6ca449182ee085c001cfe30f8872c0bc24368fcaabc2046','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('061bc8b301d739c58c1c0dc30015aff85e4c3e618f17d1fafde1baaa527543ad',1977,'ES','Spain','communications',339,'Military budget: for fiscal year ending 31
December 1976 (revised), $29 million; 22% of central
government budget
Atlantic
CANARY
ISLANDS
%o
{Sea reference map {V}
LAND
505,050 km2, including Canary (7,511 km?)and
Balearic Islands (5,025 km?); 41% arable and land
under permanent crops, 27% meadow and pasture,
22.% forest, 10% urban or other
Land boundaries: 1,899 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,964 km (includes Balearic Islands, 677
km, and Canary Islands, 1,158 km)
Railroads: 16,438 km; Spanish National Railways
(RENFE) operates 13,413 km 1.668-meter gage, 3,428
km electrified and 2,069 km double track; FEVE
(government-owned narrow gage railways) operates
2,016 km, 1,756 km meter gage (1.00 m) and 492 km
electrified; privately-owned railways operate 1,009
km, 736 km meter gage (1.00 m), 296 km electrified
and 56 km double track
Highways: 138,560 km national—56,280 km
bituminous treatment, 15,040 km crushed stone, 6,760
km bituminous, stone block and concrete; pro-
vincial—29, 120 km bituminous treatment, 29,440 km
crushed stone, 1,920 km bituminous, concrete, and
stone block
Inland waterways: 1,045 km; of minor importance
as transport arteries and contribute little to economy
Pipelines: 386 km crude oil; 1,080 km refined
products; 98 km natural gas
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SPAIN/SRI LANKA
Ports: 23 major, 150 minor
Civil air: 188 major transport aircraft (including 3
registered but leased from a foreign country)
Airfields (including Balearic and Canary
Islands): 91 total, 83 usable; 48 with permanent-
surface runways; 4 with runways over 8,660 m, 18
with runways 2,440-3,659 m, 34 with runways 1,220-
2,439 m; 4 seaplane stations
Telecommunications: generally adequate, modern
facilities; 8.0 million telephones; 8.5 million radio and
6.7 million televison receivers; 170 AM, 238 FM, and
738 TV stations; 10 coaxial submarine cables; 4
communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 8,620,000;
6,631,000 fit for military service, 290,000 reach
military age (20) annually
Military budget: for fiscal year ending 31
December 1976, $3,378,023,286; about 25.4% of the
proposed central government budget','473453b25a64fe137fd43e3da33b12ca341579baff87795e43af18421cb70b03','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32a8f9566775cb1e2b780ff393ccb4dad5161267115afdf01786e712447eee4a',1977,'MU','Mauritius','communications',340,'LAND
1,856 km? (excluding dependencies); 50%
agricultural, intensely cultivated; 39% forests,
woodlands, mountains, river, and natural reserves; 3%
built-up areas; 5% water bodies, 2% roads and tracks,
1% permanent wastelands
135
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
REUNION
indian Ocean
(See reference map Vi}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 177 km
Highways: 1,770 km; 1,593 km paved, 177 km
earth
Civil air: no major transport aircraft
Ports: 1 major (Port Louis)
Airfields: 6 total, 5 usable; 1 with permanent-
surface runway; 1 with runway 2,440-3,659 m
Telecommunications: radio telegraph service with
Reunion, Malagasy Republic, Seychelles, Zanzibar,
and other places in Africa; 1 AM, no FM, and 4 TV
stations; 22,600 telephones; 160,000 radio and 40,250
TV sets; submarine cables extend to Republic of South
Africa and Seychelles Islands
DEFENSE FORCES
Military manpower: males 15-49, 203,000; 104,000
fit for military service
Military budget: for fiscal year ending 30 June
1973, $3,981,038; 6.5% of central government budget
Pa
REUNION
Ocean
{See reference map VI}
LAND
2,512 km?; two-thirds of island extremely rugged,
consisting of volcanic mountains; 48,600 hectares (less
than one-fifth of the land) under cultivation
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 201 km
Railroads: none
Highways: 2,320 km; 1,940 km paved, remainder
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable; 2 with permanent-
surface runway; 1 with runway 2,440-3,659 m, 2 with
runways 1,220-2,439 m
Telecommunications: adequate system for size of
island of fairly modern open-wire lines and
radiocommunication stations; principal center Saint-
169
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
REUNION/RHODESIA
Denis; external radiocommunications to Comoro
Islands, France, Madagascar, and Mauritius; 25,400
telephones; 91,000 radio and 36,700 TV receivers; 2
AM, no FM, and 8 TV stations; 1 satellite ground
station
DEFENSE FORCES
Military manpower: military age males included
with France
RHODESIA
Indian Ocean
(See reference map Vi}
LAND
391,090 km?; 40% arable (of which 6% cultivated);
60% available for extensive cattle grazing; 39%
European alienated lands (farmed by modern
methods), 48% African, 7% national land, 6% not
alienated
Land boundaries: 3,017 km
Railroads: 2,715 km narrow gage (1.065 m); 44 km
double track
Highways: 78,428 km; 7,995 km paved, 32,855 km
crushed stone, gravel, stabilized soil, or improved
earth; 37,578 km unimproved earth
Inland waterways: 280 km on Lake Kariba
Pipelines: 8 km crude oil
Airfields: 326 total, 322 usable; 15 with
permanent-surface runways; 2 with runways over
3,660 m, 1 with runway 2,440-3,659 m, 25 with
runways 1,220-2,439 m
Civil air: 9 major transport aircraft
Telecommunications: system is one of the best in
Africa; consists of radio-relay links, open-wire lines,
and radiocommunication stations; principal center
Salisbury, secondary center Bulawayo; 171,900
telephones; 250,000 radio and 68,700 TV receivers; 8
AM, no FM and 2 TY stations
DEFENSE FORCES
Military manpower: males 15-49, 1,463,000;
894,000 fit for military service; average number
reaching military age (18) annually, 65,000
Military budget: for fiscal year ending 80 June
1977, $192,000,000; 23.9% of central government
budget','e17564d9d37e6eaca287297d046cebe698999419d75916b92a81f885c4d880a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('044d11053a165186e4b27df6dfbc60e9edcbff1392880c9f08b56084bdacda42',1977,'US','United States','communications',344,'Gulf
of Mexico
\\\\ Mexico |
{See reference map Il)
LAND
1,978,800 km?; 12% cropland, 40% pasture, 22%
forested, 26% other (including waste, urban areas and
public lands)
Land boundaries: 4,220 km
Approved For Release 2005/04/22 :
WATER
Limits of territorial waters (claimed): 12 nm (200
nm exclusive economic zone)
Coastline: 9,330 km
Railroads: 19,680 km; 18,576 km standard gage
(1.485 m); 1,104 km narrow gage (0.914 m); 102 km
electrified; 19,573 km government-owned, 107 km
privately-owned
Inland waterways: 2,900 km navigable rivers and
coastal canals
Pipelines: crude oil, 3,880 km; refined products,
3,860 km; natural gas, 5,580 km
Ports: 9 major, 20 minor
Civil air: 110 major transport aircraft
Airfields: 1,667 total, 1,653 usable; 127 with
permanent-surface runways; 2 with runways over
3,660 m, 22 with runways 2,440-3,659 m, 242 with
runways 1,220-2,439 m; 9 seaplane stations
Telecommunications: highly developed telecom
system with extensive radio relay links; connection
into Central American microwave net; communica-
tion satellite ground station; 2.96 million telephones,
about 19.0 million radio and 4.9 million TV receivers,
573 AM, 109 FM, and 168 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 13,449,000;
10,280,000 fit for military service; average number
reaching military age (18) annually, 700,000
Military budget: for year ending 31 December
1976, $728.6 million; about 4.4% of direct federal
budget (includes merchant marine and military
industry)
This ‘Factsheet’ on the U.S. is provided solely as a
service to those wishing to make rough comparisons of
foreign country data with a U.S. “‘yardstick.”
Information is from U.S. open sources and
publications and in no sense represents estimates by
the U.S. intelligence community.
LAND
9,363,396 km? (contiguous U.S. plus Alaska and
Hawaii); 19% cultivated, 27% grazing and pasture,
32% forested, 22% waste, urban, and other
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: 19,924 km
Railroads: 277,686 km (1973)
Highways: 6,059,200 km (1972)
Inland waterways: 40,416 km of navigable inland
channels, exclusive of the Great Lakes; freight carried
951 million short tons (1970)
Pipelines: petroleum, 279,966 km (1972)
Ports: 25 major
229
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Merchant marine: 600 ships (1,000 GRT or over)
totaling 9,982,730 GRT, 14,722,666 DWT; includes 3
passenger, 5 short-sea passenger, 168 cargo, 119
container, 14 roll-on/roll-off cargo, 234 tanker, 1
liquefied gas, 17 bulk, 2 combination ore/oil, 28
LASH Seebee and barge carriers, 19 specialized
carriers; in addition there are 178 ships in reserve fleet
Civil air: 5,214 major transport aircraft (1973)
Airfields: 15,257 (1976)
230
Telecommunications: 4,398 AM, 3,151 FM, 940
TV broadcast stations (1974); 147,000,000 telephones
(1975), 65 telephones per 100 population (1975); 360
million radio and 110 million TV receivers
DEFENSE FORCES
Personnel; army 1,148,000, navy and marines
1,065,000, air force 942,000 (1973)
Military budget: $80.6 billion (1974 est.)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Ellesmere —~y>_
Islang* ‘
eee Le 5
: : A i
United \\, wee | W
'' , A, Ca > D mere
States \\ ae Sd re
Fairbank:
fe anks » De Baffin Bay
fo ue GREY,
/ Yukon J se oak
Tero. eareat
island %,
axe
f eens / SY APSA
Yellowknife ” ‘ _—
er a oem Terr Lio, i
ms
. % Godthaab
3 ae
: va ee Lake Sf L Q)
3° Prince Rupert : a: Hudson
Some
British / 7 iia, Bay
vs Columbia ; / sae ;
‘ Alberta / c la /
*, Edmonton : Goose Bay Wf,
AS j cai ‘ oe
Vietorla Nancie \\ Vacsiisiial La co Se Ae J Jey Sie
ie < \\ ey Saskatoon I cy Quebec . <7 | Bt
: ar 4 on ee”
Pace ran a E a,
hese | Ontario» | U/
arlottetown
» Halifax
a0 va Scotia
Sal L tas ‘City me
Milwaukee ¢ SS
: Chicago’
500 Miles
e 0 500 Kilometers
BOUNDARY J-REPRESENTATION 16 | eet ele
ROT NECESSARILY AUTHORITATIVE oat
502847 1-77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
neLos Angeles
Dallas
ee ee .
pene geen gS
i
Monterrey,
Gulf of Mexico
Mazatlan s
ee” Niexico
e(:ampico
eGuadalajara
* .
Mexico 4Veracruz
~S._ Acapulco
bo at
See =a
wee Bey
Guat mala -
San Saivadore..
€i Salvador
800 Miles
400 800 Kilometers 6
BOUNDARY REPRESENTATION [6 "Galapagos Is.
NOT NECESSARILY AUTHORITATIVE
502848 1-77
sees | ; / ‘
Costa(Rica, \\
II
iN
Weshington™ |. )
ay
Ca
Turk and
oJ Caicos Is.
(LK)
Cayman ls.
(Kae 2%
Kings on
Caribbean Sea
Canal Zone
Sait osé (Ls. vila —
* si
A.
Bogota','dcafd48d54c8c74d074091e004344bc854b05fa16c4027a64a1cd96b97b36506','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d88327dff9ae03759c477b0bc058e3b01ff7fc6ec42eaf6fd09c08dd3fa9f2f8',1977,'MC','Monaco','communications',348,'<=
Mediterranean . Sea
(See reference map {V}
LAND
1.5 km?
Land boundaries: 3.7 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4.1 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MONACO/MONGOLIA
Railroads: 1.609 km (see France)
Highways: none; city streets
Ports: 1 minor
Civil air: no major aircraft
Airfields: none
Telecommunications: served by the French
communications system; automatic telephone system
Approved For Release 2005/04/22 :
with about 22,550 telephones; 2 AM, 1 FM, and 1 TV
station; 13,000 radio and 16,500 TV receivers
DEFENSE FORCES
France responsible for defense','8a481c8181ca670d565674da44a7ceba50e34e85f5531e62c7a9e786b931fce9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a9a7d469e4cb6a4afec111d3cdf826a192985908571a342e8c167432e6cd13',1977,'MN','Mongolia','communications',352,'(See reference map Vil)
LAND
1,564,619 km?; almost 90% of land area is pasture
or desert wasteland, varying in usefulness, less than
1% arable, 10% forested
Land boundaries: 8,000 km
Railroads: 1,516 km; all broad gage (1.524 m)
(1975)
Inland waterways: 616 km of principal routes
(1975)
Freight carried: rail—6.4 million metric tons,
2,812 million metric ton/km (1974); highway—10.6
million metric tons, 735.8 million metric ton/km
(1974)
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31
December 1975, 268 million tugriks, 10% of total
budget','50645a3660123cfbde37321284b6b1355c52eacd415e26148aab4c98af72f01b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90adac23476092d49eff335a7cccb5275109fc36edcdfe05ed4cc2827ff04380',1977,'MA','Morocco','communications',356,'LAND
409,200 km?; about 82% arable and grazing land,
17% forest and esparto, 51% desert, waste, and urban
140
Land boundaries: 1,996 km
WATER
Limits of territorial waters (claimed): 12 nm (200
nm exclusive economic zone)
Coastline: 1,835 km
Railroads: 1,756 km standard gage (1.435 m), 149
km double track; 793 km electrified
Highways: 52,304 km; 18,299 km bituminous
treated, 5,681 km gravel, crushed stone, and improved
earth, 28,324 km unimproved earth
Pipelines: 362 km crude oil; 491 km (abandoned)
refined products; 241 km natural gas
Ports: 8 major (including Spanish-controlled Ceuta
and Melilla), 10 minor
Civil air: 16 major transport aircraft
Airfields: 82 total, 79 usable; 23 with permanent-
surface runways; 2 with runways over 3,660 m, 11
with runways 2,440-3,659 m, 34 with runways 1,220-
2,439 m; 4 seaplane stations
Telecommunications: superior system by African
standards composed of open-wire lines, coaxial,
multiconductor and submarine cables and radio-relay
links; principal centers Casablanca and Rabat,
secondary centers Fes, Marrakech, Oujda, Sebaa
Aioun, Tangier and Tetouan; 189,000 telephones; 1.6
million radio and 460,000 TV receivers; 18 Moroccan
AM, 1 Voice of America AM, 3 FM, 27 TV stations; 2
submarine cables; 1 satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 3,916,000;
2,328,000 fit for military service; about 192,000 reach
military age (18) annually; limited conscription
Military budget: for fiscal year ending 31
December 1975, $339,248,800; 8.7% of central
government budget','ff0e52c577fa9aec672816b7d8fb0c9cd8551864583d7a6d589a949931e5e44d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c14ad5861e0719aa26a51617ab264e39944dc1663c4e5d7f50a7f1656e93a1b7',1977,'MZ','Mozambique','communications',360,'LAND
786,762 km?; 30% arable, of which 1% cultivated,
56% woodland and forest, 14% wasteland and inland
water
141
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MOZAMBIQU
&
RS
§
v
/ndian Ocean
(See reference map Vi}
Land boundaries: 4,627 km
WATER
Limits of territorial waters (claimed): 12 nm (200
nm exclusive economic zone) ;
Coastline: 2,470 km','97584c192bbfbea8ff960b165032fd22bbafc027d147f141280efa4844c388ae','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2b72d835d0901318906b39efef339c91f2c070c00e54f35e40b1aafea57f6c5',1977,'DE','Germany','communications',365,'Railroads: 3,144 km; 3,003 km 1.065-meter gage;
141 km narrow gage (0.750 m)
Highways: 32,200 km; 2,800 km paved; remainder
earth
Inland waterways: approx. 3,750 km of navigable
routes
Pipelines: crude oil, 306 km
Ports: 3 major (Maputo, Beira, Nacala), 2
significant minor
Civil air; 18 major transport aircraft
Airfields: 380 total, 324 usable; 28 with
permanent-surface runways; 6 with runways 2,440-
8,659 m; 39 with runways 1,220-2,439 m
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MOZAMBIQUE/NAURU/NEPAL
DEFENSE FORCES
Military manpower: males 15-49, 2,244,000;
1,163,000 fit for military service
Supply: mostly from the USSR and PRC, and toa
lesser extent from other Communist countries and
Railroads: 7,489 km; 446 km meter gage (1.00 m),
6,431 km broad gage (1.676 m), 612 km narrow gage
(0.762 m); 1,022 km double track; 286 km electrified;
government-owned
Highways: 63,567 km; 16,077 km paved, 12,862
km gravel, 1,843 km improved earth, 32,785 km
unimproved earth
Inland waterways: 1,850 km
Pipelines: 230 km crude oil; 1,931 km natural gas
Ports: 1 major, 5 minor
Civil air: 27 major transport aircraft
Airfields: 110 total, 107 usable; 65 with
permanent-surface runways; 1 with runway over
12,000 ft., 25 with runways 8,000-11,999 ft., 49 with
runways 4,000-7,999 ft.
Telecommunications: good international radio-
communication service over CENTO microwave and
intelsat satellite; domestic radiocommunications good
in East Pakistan, poor in West Pakistan; broadcast
service very good; 200,000 (est. ) telephones; 1,100,000
radio and 250,000 TV sets; 20 AM, no FM, 5 TV
stations, and 4 repeaters; 1 ground satellite station
DEFENSE
Military manpower: males 15-49, 17,214,000;
9,914,000 fit for military service; 833,000 reach
military age (17) annually
Military budget: for fiscal year ending 30 June
1977 $886 million; about 26% of central government
budget
158
Railroads: 5,149 km; 8,870 km 1.065-meter gage,
126 km meter gage (1.00 m); 186 km 0.610-meter
gage, 1,017 km 0.600-meter gage, 851 km 1.065-meter
gage electrified
Highways: 141,600 km; 2,000 km bituminous,
18,210 km gravel or crushed stone, remainder earth
Inland waterways: comprising the Zaire, its
tributaries, and unconnected lakes, the waterway
system affords over 15,000 km of navigable routes
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 740 km
Civil air: 43 major transport aircraft
Airfields: 387 total, 300 usable; 20 with
permanent-surface runways; 1 with runway over
3,660 m, 2 with runways 2,440-3,659 m, 56 with
runways 1,220-2,439 m
Telecommunications: limited, barely adequate
telephone service, telegraph service good; 25,000
telephones; 100,000 radio receivers; 7,100 TV
receivers; 12 AM, 1 FM, and 2 TV stations; 1 satellite
ground station
DEFENSE FORCES
Military manpower: males 15-49, 5,677,000;
2,835,000 fit for military service
Military budget: for fiscal year ending 31
December 1976, $72.3 million; 13% of central
government budget
227
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','b3162e1f50be0fc6eaa5b0ed08d8a773a9e6b68fbbd95674ede964b2b0e72f0d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66ebfa9f550cdf4f013a4bbe07fdc5ba0f14db71318e6082c18d75967fa1c158',1977,'PT','Portugal','communications',366,'(See reference map Vill}
LAND
21.2 km’; insignificant arable land, no urban areas,
extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 24 km
Railroads: none
Highways: about 27 km; 21 km paved, 6 km
improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 8 major transport aircraft
Airfields: 1, coral-surfaced, 5,620 ft.
Telecommunications: adequate intraisland and
international radiocommunications provided via
Australian facilities; 630 telephones; 3,600 radio
receivers, 1 AM, no FM and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 1,800; fit
for military service, about 1,000; average number
reaching military age (18) annually, 1975-79, less than
100
No formal defense structure and no regular armed
forces
LAND
Metropolitan Portugal: 94,276 km?, including the
Azores and Madeira Islands; 48% arable, 6% meadow
and pasture, 31% forested, 15% waste and urban,
inland water, and other
Land boundaries: 1,207 km
WATER
Limits of territorial waters (claimed): 6 nm
(fishing, 12 nm)
Coastline: 860 km (excludes Azores (708 km) and
Madeira (225 km))
Railroads: 3,593 km; state-owned Portuguese
Railroad Co. (CP) operates 2,807 km 1.665-meter
gage (406 km electrified and 426 km double track),
760 km meter-gage-(1.00 m); 26 km 1.665-meter gage
double track, electrified, privately-owned
Highways: 29,600 km; 17,600 km_ bituminous,
bituminous treatment, concrete and stoneblock;
11,520 km gravel and crushed stone; 480 km
improved earth; plus an additional 16,800 km of
unimproved earth roads (motorable tracks)
Inland waterways: 820 km navigable; relatively
unimportant to national economy, used by shallow-
draft craft limited to 297 metric ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 6 major, 34 minor
Civil air: 31 major transport aircraft
Airfields (including Azores and Madeira Islands):
51 total, 47 usable; 30 with permanent-surface
runways; 1 with runway over 3,660 m, 11 with
runways 2,440-8,659 m, 9 with runways 1,220-2,439
m; 6 seaplane stations
Telecommunications: facilities are generally
adequate; 1.11 million telephones; 1.8 million radio
and 770,000 television receivers; 389 AM, 84 FM, and
42. TV stations; 6 submarinne cables (including 2
coaxial); COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 2,400,000;
1,950,000 fit for military service; average number
reaching age (20) annually, about 75,000
Military budget: proposed for fiscal year ending 31
December 1976, $640.6 million; about 16.4% of
central government budget
167
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','968b42d9aa63bf4fbf024eaced0b8d1c6fe1c06c22764219688b263cf766678e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('709672123085004c0f65bf4ad1945274501d602bb0d1430ea7938fb58653bb08',1977,'NP','Nepal','communications',370,'LAND
141,400 km*; 16% agricultural area, 14%
permanent meadows and pastures, 38% alpine land
(unarable), waste, or urban; 32% forested
Land boundaries: 2,800 km
148
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Bay
of Bengal
(See reference map Vil}
Railroads: 169 km, all narrow gage (0.762 m);
mostly government owned; all in Terai close to Indian
border; only 53 km sector from border to Bizalpura
presently in use; a 45 km segment has been
abandoned and 71 km utilized to transport rock from
quarry near Dharau to Kosi Dam near Rajbiras
Highways: 3,700 km; 1,666 km paved, 533 km
gravel or crushed stone, 1,501 km improved and
unimproved earth, 322 km of seasonally motorable
tracks
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NEPAL/NETHERLANDS
Civil air: 5 major transport aircraft
Airfields: 54 total, 53 usable; 5 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 8 with
runways 1,220-2,489 m
Telecommunications: poor telephone and _tele-
graph service; good radiocommunication and
broadcast service; international radiocommunication
service is poor; 9,500 telephones, 80,000 radio and no
TV sets, 3 AM, no FM, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,152,000;
1,558,000 fit for military service; 140,000 reach
military age (17) annually
Military budget: for fiscal year ending 14 July
1977, $12.8 million; 6.2% of central government
budget','e59f7cc6e5d874509adfcc23f1e866fd94bd7dd3d7c7475079c848d9cc8a54ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08bfe0220da525547d282cdee92a0c814a686505bcf2155d22b272dc1fc9f3d5',1977,'NC','New Caledonia','communications',374,'<. Preapua >
: ben ces bares
‘ =,
Coral Sea &,
NEWS"
CALEDONIA Pacific
Ocean
7 ~ NEW
ZEALAND
(See reference map Vill)
LAND
22,015 km?; 6% cultivable, 22% pasture land, 15%
forests, 57% waste or other
WATER
Limits of territorial waters (claimed): 12 nm
(fishing, 3 nm)
Coastline: 2,254 km
Fr)
Tasmania
lobart
Lae
; z Santa isabel
Pe \\ Solomon Sea tog &
-Wake (U.3.)
VIII Oceania
¢ Kauai
Oahuss 3.
Maui
HAWAIIAN | ~~
ISLANDS
(United
States)
_ Johnston
U.S.)
Way
Kwajalein Se, °
‘fe “he Ne
ake
N O FR
~
yy,
%
SP
_Howland Ws.)
Baker U.S.)
Nauru (O.8.-t.K joint admins
Canton.«~
2
%
,
Py.
p .
eG pave
ty :
Qp°
Phoenix ——~
Gardner’ Hull
Soiomon islands . ilbert
UK,
Se (ULK,)
elaite SANTA K. ic oa
San Cristobal '' CRUZ
i a
Ss. American','3756fcecbbca33dd64e7667715d09a9421b846324575284f7cb15957894c0246','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71d2e8386cdf9ae780ecbb695b5fb9b80241f9507794e3d9da2b6d819e35a08',1977,'NZ','New Zealand','communications',376,'4
bd ge
Ne Pacifi¢
Coral Sea
Ocean
Tasman
Sea
NEW
He,
)
{Sea reference map VIlf)
LAND
268,276 km?; 3% cultivated, 50% pasture; 10%
parks and reserves; 20% waste, water, etc., 1% urban,
16% forested; 4 principal islands, 2 minor inhabited
islands, several minor uninhabited islands
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: about 15,184 km
Railroads: 4,799 km; all 1.067-meter gage; 274 km
double track; 113 km electrified; over 99%
government owned
Highways: 92,374 km (1974); 44,940 km paved,
47,434 km gravel or crushed stone
Inland waterways: 1,609 km; of little importance
to transportation
Pipelines: natural gas, 785 km
Ports: 3 major
Civil air: 42 major transport aircraft
Airfields: 189 total, 185 usable; 23 with
permanent-surface runways; 2 with runways 2,440-
3,659 m, 48 with runways 1,220-2,439 m; 4 seaplane
stations
Telecommunications: excellent international and
domestic systems; 1,500,000 telephones; 2,700,000
radio and 799,000 TV sets; 60 AM stations in 31 cities,
no FM, 4 TV stations, and 129 repeaters; submarine
cables extend to Australia and Fiji Islands; 1 ground
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 737,000;
624,000 fit for military service; average number
reaching military age (20) annually about 27,000
Military budget: proposed for fiscal year ending 31
March 1977, $223.4 million; about 3.5% of central
government budget
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','1f4f0427df3cca44def71fee5769aa260e6fc12de4e92d70ead404bc9ff0c145','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84589682a777b7beb3e7e1c3439d49f536bd62e9160d628d025316d55b1fa2ee',1977,'NI','Nicaragua','communications',380,'Caribbean Sea
Managua
Pacific Ocean
(See reference map tH}
LAND
147,900 km?; 7% arable, 7% prairie and pasture,
50% forest, 36% urban, waste, or other
Land boundaries: 1,220 km
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 200 nm; continental shelf, including
sovereignty over superjacent waters)
Coastline: 910 km
Railroads: 352 km; 320 km 1.065-meter gage,
government owned; 32 km narrow gage, privately
owned
Highways: 12,900 km; 1,350 km paved, 5,150 km
otherwise improved, 6,400 km unimproved
Inland waterways: 2,220 km, including 2 large
lakes
Pipelines: crude oil, 56 km
Ports: 4 major (Corinto, Puerto Cabezas, Puerto
Somnoza, San Juan del Sur), 6 minor
Civil air: 11 major transport aircraft
Airfields: 420 total, 413 usable; 5 with permanent-
surface runways; | with runway 2,440-3,659 m, 8 with
runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: low-capacity wire and
radio-relay network; connection into Central
American microwave net; satellite ground station;
22,000 telephones; 700,000 radio and 81,000 TV
receivers; 75 AM, 30 FM, and 7 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 541,000; 331,000
fit for military service; 24,000 reach military age (18)
annually
Military budget: for fiscal year ending 31
December 1976, $24.8 million for the Ministry of
Defense, including civil functions (e.g., police and
civil air); 7.8% of central government budget','047c0f9738c760c142ed65b9d2850a061ee4eb1da333ca28e42fee071cc70e63','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef2c0ee5f9dadc78951e9ee9457afc9eb19524f591b6c240b721f1bb3f6480a7',1977,'NE','Niger','communications',384,'LAND
1,266,510 km?; about 3% cultivated, perhaps 20%
somewhat arable, remainder desert
Land boundaries: 5,745 km
Railroads: none
Highways: approx. 6,944 km; 1,313 km bitumi-
nous, 2,550 km gravel, 3,081 km unimproved earth
Inland waterways: Niger River navigable 300 km
from Niamey to Gaya on the Dahomey frontier from
mid-December through March
Ports: Niger landlocked; outlet to sea is Cotonou,
Dahomey
Civil air: 4 major transport aircraft
Airfields: 66 total, 63 usable; 5 with permanent-
surface runways; 1 with runway 2,440-8,659 m, 18
with runways 1,220-2,439 m
Telecommunications: sparse system of open-wire
lines, radio-relay links, and small radiocommunica-
tions stations; principal telecommunication center
Niamey; 3,300 telephones; 100,000 radio and 500 TV
receivers; 9 AM stations, no FM, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,093,000;
584,000 fit for military service; about 45,000 reach
military age (18) annually
Approved For Release 2005/04/22 :','2a1206b644089975046ffac808d14f01cc78efdd641a8f792d70fa6b7b71e58c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c01972523745bdf07402614ccbac991ca103873048de3e65967ef7963316f78c',1977,'NG','Nigeria','communications',388,'/ NIGERIA
Lagos
ca
Gulf
of Guinea
LAND
924,680 km?; 24% arable (13% of total land area
under cultivation), 35% forested, 41% desert, waste,
urban, or other
Land boundaries: 4,034 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 853 km
Railroads: 3,508 km 1.067-meter gage
Highways: 89,318 km; 15,300 km paved (mostly
bituminous surface treatment); remainder laterite,
gravel, crushed stone, improved earth
Inland waterways: 8,575 km consisting of Niger
and Benue rivers and smaller rivers and creeks;
additionally, the newly formed Kainji Lake has
several hundred miles of navigable lake routes
Pipelines: 1,207 km crude oil; 97 km natural gas; 5
km refined products
Ports: 2 major (Lagos/Apapa, Port Harcourt), 10
minor
Civil air: 17 major transport aircraft
Airfields: 91 total, 76 usable; 15 with permanent-
surface runways; 5 with runways 2,440-3,659 m, 24
with runways 1,220-2,439 m; 4 seaplane stations
Telecommunications: composed of radio-relay
links, open-wire lines, and radiocommunication
stations; principal center Lagos, secondary centers
Ibadan and Kaduna; 111,500 telephones; 5 million
radio and 100,000 TV receivers; 25 AM, 6 FM, and 8
TV stations; 2 submarine cables; 1 satellite ground
station
DEFENSE FORCES
Military manpower: males 15-49, 14,970,000;
8,537,000 fit for military service; average number
reaching military age (18) annually 700,000
Military budget: for fiscal year ending 31 March
1977, $2.4 billion; about 16% of central government
budget','421c6236daf5d69e7e1dc695f4cdaed60aa89c03629794b00c310fbb2415dee6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('635be58d1778f339877be52385a233b46e9922db8a4c719d0957693abe26687c',1977,'NO','Norway','communications',392,'{See reference map {V)
LAND
Norway: 323,750 km?; Svalbard, 62,160 km?; Jan
Mayen, 373 km?; 3% arable, 2% meadows and
pastures, 21% forested, 74% other
Land boundaries: 2,579 km
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
WATER
Limits of territorial waters (claimed): 4 nm (200
nm exclusive economic zone)
Coastline: mainland 3,419 km; islands 2,413 km
(excludes long fjords and numerous small islands and
minor indentations which total as much as 16,093 km
overall)
Railroads: 4,257 km standard gage (1.435 m);
Norwegian State Railways (NSB) operates 4,241 km
(2,440 km electrified and 91 km double track); 16 km
privately-owned and electrified
Highways: 73,600 km; 14,400 km paved, 59,200
km crushed stone and gravel
Inland waterways: 1,577 km; 1.5-2.4 m draft
vessels maximum
Pipelines: refined products, 58 km
Ports: 9 major, 69 minor
Civil air: 60 major transport aircraft
Airfields: 98 total, 97 usable; 49 with permanent-
surface runways; 1] with runways 2,440-3,659 m, 16
with runways 1,220-2,439 m; 20 seaplane stations
Telecommunications: high-quality domestic and
international telephone, telegraph, and telex service;
1,43 million telephones; 2.2 radiobroadcast and 1.15
million TV receivers; 29 AM, 357 FM, and 740 TV
stations; 5 coaxial submarine cables; COMSAT
station
DEFENSE FORCES
Military manpower: males 15-49, 921,000;
748,000 fit for military service; average number
reaching military age (20) annually, 31,000','86486fa016b2f74e4963046b690ef2a4a7c5a85db7b71bafb1c99f6aa544e78c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('645016b6c7619f2efdc9c8df8b0dad1e628dd650732b937ff24502356b6ae22d',1977,'OM','Oman','communications',396,'| Arabian Sea
(See reference map V)
LAND
About 212,380 km?; negligible amount forested,
remainder desert, waste, or urban
Land boundaries: 1,384 km
156
WATER
Limits of territorial waters (claimed): 12 nm
(fishing 50 nm)
Coastline: 2,092 km
Highways: 2,816 km; 5 km bituminous surface,
2,811 km motorable track
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
OMAN/PAKISTAN
Pipelines: crude oil 370 km
Ports: 1 major (Qaboos), 6 minor
Civil air: 2 major transport aircraft
Airfields: 154 total, 147 usable; 4 with permanent-
surface runways; 1 runway over 3,660 m, 4 with
runways 2,440-3,659 m, 51 with runways 1,220-
2,489 m
Telecommunications: limited facilities of open-
wire, radio-relay and radiocommunications stations; |
satellite ground station; 4,300 telephones; 1 AM, no
FM, no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 121,000; 70,000
fit for military service
Gulf of
fs : Qman
bu Dhabj
United Arab
\\ Jiddah
2
» Part Sudan
Arabian Sea
Gall of om
Aden ran “~~ Socotra
« ,Diibouti _
ale
Ethiopia %
500 Miles
; T
Addis Ababa* 0 500 Kilometers
NAMES AND BOUNDARY REPRESENTATION indian Ocean
ARE NOT NECESSARILY AUTHORITATIVE
502851 1-77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
VI Africa
North
Atlantic
Ocean Vieite Fxfeomans
eo AZores : wee
(Port
é a , . ear.
: Cubraltar 4 at "
'' Rabat 1 Algiers Canis ita
Misia Mediterranean Sea
orecco * Tn
Canary Is. (sp) ; Tripoli, aa OO
fd we
2t% 2 }','0d1a7ca0a0a248acd2d14c491abc1b2d3c13cba9f824b9ff7e4bff97a722956a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1812a906a07d75843f33b9b9bd7a56f5ba62ec5ead8f4eb2453b2ad74064a21f',1977,'PK','Pakistan','communications',400,'Arabian Sea
(See reference map Vil)
LAND
803,000 km? (includes Pakistani part of Jammu-
Kashmir); 40% arable, including 24% cultivated; 23%
unsuitable for cultivation; 84% unreported, probably
mostly waste; 3% forested
Land boundaries: 5,900 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing 50 nm; plus right to establish 100 nm
conservation zones beyond territorial sea)
Coastline: 1,046 km','bae72dcc2f1d52f27dd9383dc57f953c0012616f8d49cc9e4e18ad39fa6372df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e1361358c627c105e6196325dbdf55c4d0908482031f5b098c6462c903891ac',1977,'PA','Panama','communications',404,'Caribbean Sea
. Pacific Ocean
(See reference map I)
LAND
75,650 km? (excluding Canal Zone, 1,430 km?);
24% agricultural land (9% fallow, 4% cropland, 11%
pasture), 20% exploitable forest, 56% other forests,
urban, and waste
Land boundaries: 630 km
WATER
Limits of territorial waters (claimed): 200 nm
(continental shelf including sovereignty over
superjacent waters)
Coastline: 2,490 km
Railroads: 488 km; 77 km 1.524-meter gage, 171
km 0.914-meter gage; 240 km plantation feeder lines
Highways: 7,160 km; 2,252 km paved, 1,850 km
gravel or crushed stone, 3,057 km improved and
unimproved earth; Panama Canal Zone 240 km; 230
km paved, 10 km gravel
Inland waterways: 800 km navigable by shallow
draft vessels; 82 km Panama Canal
Pipelines: refined products, 96 km
Ports: 2 major (Cristobal/Colon/Coco Solo,
Balboa/Panama City), 10 minor
Civil air: 21 major transport aircraft
Airfields: (including Canal Zone) 148 total, 142
usable; 31 with permanent-surface runways; 3 with
runways 2,440-3,659 m; 14 with runways 1,220-2,439
m; 2 seaplane stations
Telecommunications: domestic and international
telecom facilities well developed; connection into
Central American microwave net; COMSAT ground
station; 155,200 telephones; 600,000 radio and
250,000 TV receivers; 80 AM, 30 FM, and 13 TV
stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 377,000; 261,000
fit for military service; no conscription
Military budget: for fiscal year ending 381
December 1976, $32.6 million; about 10% of central
government budget','1f31c44653f6bf139a1d29647c2537de17a9ff68b1d333e57975dc06cfccda39','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a7c21be5fe6bb7006a31dcc925567074b9d3714334d330a32a1cb7ba55c7732',1977,'PG','Papua New Guinea','communications',408,'LAND
475,369 km?
Land boundaries: 966 km
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
159
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Pacific Ocean
BRITISH
S_ saLoMON
"wy ISLANDS
% tak
b
Coral Sea »
(See reference map Vill}
Coastline: about 5,152 km
Railroads: none
Highways: approx. 16,936 km; about 9,500 km
suitable for heavy and medium traffic, and about
7,436 km suitable for light traffic
Inland waterways: 10,940 km
Ports: 5 principal, 8 minor
Civil air: 16 major transport aircraft
Airfields: 534 total, 474 usable; 15 with
permanent-surface runways; 2 with runways 2,440-
8,659 m; 46 with runways 1,220-2,439 m; 1 with
runway 2,440 m—Nadzab; 2 seaplane stations
Telecommunications: Papua New Guinea telecom
services are adequate and are being improved;
principal telecom centers include Goroka, Lae,
Madang, Mount Hagen, and Wewak in New Guinea;
and Daru, Port Moresby and Samarai in Papua;
facilities provide radiobroadcast, radiotelephone and
telegraph, coastal radio, aeronautical radio and
international radiocommunication services; numerous
privately owned radio facilities exist; submarine
cables extend from Madang to Australia and Guam;
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
PAPUA NEW GUINEA/ PARAGUAY
17,000 telephones, 110,000 radios, but no TV sets; 31
AM, no FM and no TV facilities
DEFENSE FORCES
Military manpower: males 15-49, 651,400; about
858,000 fit for military service
Supply: dependent on Australia
Military budget: for fiscal year ending 30 June
1976, $22.3 million; 4.3% of central government
budget','db6eb08339061cd85fbb279ecf86db3b236f712760c5c7e0ae91d65a39113048','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a432700072cdec07029c6b80e99bf5bb94fca163b5a45f01e7343fc59ae1f016',1977,'PY','Paraguay','communications',412,'Atlantic Ocean
(See reference map ttl)
LAND
406,630 km?; 2% under crops, 24% meadow and
pasture, 52% forested, 22% urban, waste, and other
Land boundaries: 3,444 km
Railroads: 1,043 km; 437 km standard gage (1.485
m), 136 km meter gage (1.00 m), 470 km various
narrow gage (privately owned)
Highways: 15,900 km; 600 km bituminous treated,
5,000 km otherwise improved, 10,300 km unimproved
earth
Inland waterways: 3,100 km
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 7 major transport aircraft
Airfields: 923 total, 798 usable; 1 with permanent-
surface runway; 1 with runway 2,440-8,659 m, 19
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: local telecom facilities in
Asuncion good, intercity microwave net; 38,400
telephones; 750,000 radio and 60,000 TV receivers; 25
AM, 9 FM stations, and 1 TV station; COMSAT
station under construction
DEFENSE FORCES
Military manpower: males 15-49, 637,000; 481,000
fit for military service; average number currently
reaching military age (17) annually, 31,000','69581dae17dbfbe1453db6bd7671d4ce20c03afc1babf575315098eab5f1a4ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d8fa16a61af46ca0ef4c1cf2d8ddf8454c8b13442b540de21c32fd91f43d2a0',1977,'PE','Peru','communications',416,'LAND
1,284,640 km? (other estimates range as low as
1,248,380 km?); 2% cropland, 14% meadows and
pastures, 55% forested, 29% urban, waste, other
Land boundaries: 6,131 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,414 km
Railroads: 2,148 km; 1,776 km standard gage
(1.485 m); 46 km 0.60-meter gage; 326 km 0.914-
meter gage; 14 km double track
Highways: 50,700 km; 5,000 km paved, 10,000 km
gravel or crushed stone, 14,700 km improved earth,
21,000 km unimproved earth
Inland waterways: 8,600 km of navigable
tributaries of Amazon River system and 208 km Lake
Titicaca
Pipelines: crude oil, 471 km; natural gas and
natural gas liquids, 64 km
Ports: 7 major, 20 minor
Civil air: 34 major transport aircraft
Airfields: 305 total, 305 usable; 22 with
permanent-surface runways; 2 with runways over
3,660 m, 19 with runways 2,440-8,659 m, 49 with
runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: fairly adequate for most
requirements; new nationwide radio-relay system;
COMSAT ground station; 378,600 telephones; 2.2
million radio and 500,000 TV receivers; 200 AM, 7
FM, and 81 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 8,461,000;
2,341,000 fit for military service; average number
currently reaching military age (20) annually, 160,000
Military budget: a biennial budget for 1 January
1975 through 31 December 1976, $871 million; about
15.2% of central government biennial budget','4e45d2c13a0286f73928993546c83931b2b5bcb0898972875c36d3bef1f4576e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('649b0f3962ada8e0780869623d4020ca40b69963c049867be3d2af841538be75',1977,'PL','Poland','communications',421,'LAND
312,354 km?; 49% arable, 14% other agricultural,
27% forested, 10% other
Land boundaries: 3,090 km
WATER
Limits of territorial waters (claimed): 3 nm (8 nm
contiguous zone claimed in addition to the territorial
sea) (fishing, 12 nm)
Coastline: 491 km
Railroads: 26,597 km; 23,255 km standard gage
(1.485 m), 8,347 km narrow gage; 7,474 km double
track; 5,558 km electrified; government owned (1975)
Highways: 305,863 km; 65,000 km paved; 98,000
km crushed stone, gravel; 142,863 km earth (improved
and unimproved) (1976)
Inland waterways: 5,053 km navigable streams
and canals (1976)
Pipelines: 3,540 km for natural gas; 1,408 km for
crude oil; 322 km for refined products
Freight carried: rail—465 million metric tons,
130.1 billion metric ton/km (1975); highway—1,710
million metric tons, 32.3 billion metric ton/km
(1975); waterway—12.4 million metric tons, 2.3
billion metric ton/km; excl. int’. transit traffic (1975)
Ports: 4 major (Gdansk, Gdynia, Szczecin,
Swinoujscie), 6 minor (1976)
DEFENSE FORCES
Military budget announced: for fiscal year ending
31 December 1976, 52.9 billion zlotys; about 7% of
total budget
i ¢
Faderal © Oem. Rep.» "Wrociaw
"Bonn
ad
Lax. Hioputlc
7 j
\\ France “Romania
Lyon, Bucharest,
Bordeaux
{
Moaacag
ene 7
( Marseilla® ~ A
Gardlces )
ae
"Barcelona
°
Sardinia
© Balearic Is.
Valletta
Mediterranean
Morocco _
503001 1-77
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
V The Middle East
Tehran ,
Mediterranean Sea
ee Iran
ae ; : : : ? Estahan”
Alexandria’, \\
Bandar ‘Abbas
“pe.','1aa6c8fac85e21f607612d17be9bc1227ce49d639e1859b622b17e0976e6d736','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61693b4b1a9135ac3f9f21fb6eca1838ee2ffbabef734ff391ac569f23258686',1977,'QA','Qatar','communications',425,'ee
{SHRI
LATAR
Doha
ay
(See reference map V}
LAND
About 10,360 km?*; negligible amount forested;
mostly desert, waste, or urban
Land boundaries: 56 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 563 km
Railroads: none
Highways: 805 km; 442 km bituminous; 362 km
gravel; undetermined mileage of earth tracks
Pipelines: crude oil, 169 km; natural gas, 97 km
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 2 with permanent-
surface, 1 with runway over 8,660 m
Civil air: 1 major transport aircraft, registered in
the U.S.
Telecommunications: international telecom traffic
is by tropospheric scatter through Bahrain; fair
domestic facilities; 18,300 telephones; 35,000 radio
and 29,000 TV receivers; 1 AM station, no FM and 1
TV station
DEFENSE FORCES
Military manpower: males 15-49, about 46,000;
about 26,000 fit for military service
Supply: mostly from U.K.
Military budget: for fiscal year ending 24 January
1974, $53,680,900; 18% of central government budget
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
REUNION
indian','ac08b06157f5ea9d5047b2cb0d9f5c97ff6dd80dad5b37ef812fdad67613a5a7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c79b7775329f0a4de3bb529a1a49f3b66b422c22966e082e80df03d27903c3ea',1977,'RO','Romania','communications',429,'LAND
237,503 km?; 44% arable, 19% other agriculture,
27% forested, 10% other
Land boundary: 2,969 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 225 km
Railroads: 12,012 km; 10,367 km standard gage
(1.435 m), 1,682 km narrow gage, 13 km broad gage;
1,203 km electrified, 1,907 km double track;
government owned (1976)
Highways: 77,249 km; 12,232 km paved; 26,232
km other improved surfaces, 38,785 km earth (1976)
Inland waterways: 2,312 km (1976)
Pipelines: 2,785 km crude oil; 1,429 km refined
products; 5,149 km natural gas
Freight carried: rail—217.3 million metric tons,
54.6 billion metric ton/km (1974); highway—526
million metric tons, 8.3 billion metric ton/km (1974);
waterway—5.8 million metric tons, 2.0 billion metric
ton/km (excl. int''l. transit traffic) (1975)
Ports: major (Constanta, Galati, Braila, Mangalia),
2 minor (1976)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 31 December 1976, 10.4 billion lei; about 5%
of total budget
172
Approved For Release 2005/04/22','6e7746fb9750c3785e0ba1f74d3ab45e17220f2507696cfdc2a043421c3be774','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a533d6833f989df9d4073847d6d04344076c293476a5c2d349a1838ed76fba53',1977,'RW','Rwanda','communications',433,'- ‘ee reference map Vi)
LAND
25,900 km?; almost all the arable land, about +4
under cultivation, about 4 pastureland
Land boundaries: 877 km
Railroads: none
Highways: 9,120 km; 120 km paved, 3,000 km
gravel and/or improved earth, 6,000 km unimproved
Inland waterways: Lake Kivu navigable by
steamers and barges
Civil air: 1 major transport aircraft
Airfields: 10 total, 9 usable; 2 with permanent-
surface runways; 2 with runways 1,220-2,489 m, 1
with runway 2,440-3,659 m
Telecommunications: telephone and telegraph
limited; main center is Kigali; 2,480 telephones;
65,000 radio receivers; 2 AM, no FM or TY stations
DEFENSE FORCES
Military manpower: males 15-49, 981,000; 493,000
fit for military service; no conscription; 40,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1974, $6,522,000; 17.3% of central
government budget
1974); textiles,
Approved For Release 2005/04/22 :
ST. CHRISTOPHER-NEVIS-','1dfd5d69ac22029ac4eebed8642cb53836c9940ff9b8e9bdde586d6f067cecd7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbdf62aa96b8542e409d2a4f5c02c7d8a3eb460f1a766c77bbb5ba27aa8edf81',1977,'AI','Anguilla','communications',437,'Atlantic Ocean
eee
eo 5
ST. CHRISTOPHER %e, >
NEVIS’ yp.
8
_ Caribbean Sea
ce map ti)
LAND
389 km?; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 57 km, narrow gage (0.760 m) on St.
Kitts for sugar cane
Highways: 300 km; 100 km paved, 150 km
otherwise improved, 50 km unimproved earth
Ports: 38 minor (1 on each island)
Civil air: 1 major transport aircraft
Airfields: 3 total, 3 usable; 3 with permanent
surface runways; 1 with runway 1,220-2,439 m; 1
seaplane station
Telecommunications: good interisland VHF/UHF
radio connections and international link via Antigua;
about 1,900 telephones; 10,000 radio and 1,600 TV
receivers; 3 AM and 5 TV stations
174
ST. LUCIA
Atlantic Ocean
= Caribbean Sea ‘
* ST. LUCIA
(See reference mao 1)
LAND
616 km?; 50% arable, 3% pasture, 19% forest, 5%
unused but potentially productive, 23% wasteland
and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 158 km
Railroads: none
Highways: 670 km; 280 km paved; 890 km
otherwise improved
Ports: 1 major (Castries), 1 minor
Civil air: 2 major transport aircraft
Airfields: 3 total; 3 usable, 2 with permanent-
surface runways, 1 with runway 2,440-3,659 m, 1 with
runway 1,220-2,439 m; 2 seaplane stations
Telecommunications: fully automatic telephone
system with 6,980 telephones; direct radio-relay link
with Martinique; interisland tropospheric links to
Barbados and Antigua; 86,500 radio and 600 TV
receivers; 8 AM stations, 1 TV station
ST. VINCENT
LAND
389 km? (including northern Grenadines); 50%
arable, 3% pasture, 44% forest, 3% wasteland and
built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 84 km
Railroads: none
Highways: 1,750 km; 600 km paved; 1,000
km otherwise improved; 150 km unimproved earth
Ports: 1 major, 1 minor
Civil air: no major transport aircraft
Airfields: 5 total, 4 usable; 2 with permanent
surface runways, 1 with runway 1,220-2,439 m
Telecommunications: islandwide fully automatic
telephone system with 5,130 instruments; VHF/UHF
interisland links to Barbados and the Grenadines;
10,000 radio and 600 TV receivers; 2 AM stations','f4bbe6329aa0f8d58cc72d29be19a87be960d55c6e029b6ce0f11d25b26ffcc5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4e6e8971246eedd43b2078ee821479950ea2487ad9e2a4f9ff8a0b16c61405a',1977,'SM','San Marino','communications',441,'Mediterranean Sea
{Ses reference map 1V)
LAND
62 km?; 74% cultivated, 22% meadows and
pastures, 4% built-on
Land boundaries: 34 km
Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: automatic telephone system
serving 5,370 telephones; no radiobroadcasting or
television facilities, 4,400 radio and 3,800 TV receivers
(Italian broadcasts)
Approved For Release 2005/04/22 :','1e5117a47e65583318bce648cc6f9a9ba9189238f966f5e035e023e2cf16f339','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('907f32251ec01f2086101fe279555271b63ed3c6301398e627db8713c697c824',1977,'ST','Sao Tome and Principe','communications',445,'ey
SAO TOME
AND
PRINCIPE)
Sao Toms”
Atlantic Ocean
(See reference map V}
LAND
964 km? (Sao Tome, 855 km? and Principe, 109
km?; including small islets of Pedras Tinhosas)
WATER
Limits of territorial waters: 6 nm (fishing, 12 nm)
Coastline: estimated 209 km
Ports: 1 major (Sao Tome)
Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 2 permanent surface
runways; 2 with runways 1,220-2,439 m
Telecommunications: minimal system; 657
telephones; 10,000 radio receivers; 2 AM, 1 FM, and
no TV stations
DEFENSE FORCES
A company of 150 local troops has been formed into
a fledgling army.','18f013ff318e15224a91f1a54f597e4ff29c60baebd6036fac964ea4a14c75b5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('299f090a9c03205cee6fee28f608f595823d64ef31c4adb4cbf4fdda67471af6',1977,'SA','Saudi Arabia','communications',449,'LAND
Estimated at about 2,331,000 km? (boundaries
undefined and disputed); 1% agricultural, 1%
forested, 98% desert, waste, or urban
Land boundaries: 4,537 km
178
Riyadh ,.
SAUDI
ARABIA
(See reference mag V}
WATER
Limits of territorial waters (claimed): 12 nm (plus
6 nm “necessary supervision zone’)
Coastline: 2,510-km
Railroads: 575 km standard gage (1.435 m)
Highways: 17,850 km; 10,750 km bituminous,
7,100 km gravel and improved earth, undetermined
kilometers of earth roads and tracks
Pipelines: 2,480 km crude oil; 886 km refined
products; 98 km natural gas
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6
minor
Civil air: 20 major transport aircraft
Airfields: 107 total, 84 usable; 24 with permanent-
surface runways; 17 with runways 2,440-3,659 m, 39
with runways 1,220-2,489 m, 3 with runways over
3,660 m
Telecommunications; excellent international tele-
communications; fair domestic service; 84,650
telephones; 255,000 radio and 150,000 TV receivers; 4
AM, 1 FM, and 11 TV stations; 2 submarine cables; 2
satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 1,485,000;
821,000 fit for military service; about 64,000 reach
military age (18) annually
Military budget: for fiscal year ending 1 July 1976,
$7,460,820,900; about 23.7% of central government
budget','74594f9b8e6edd30e7e064b5c3d87bb43351206a1de53c16fc34c6f36d7d7400','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da056e453bac0d34d9e61fd14969d22023e4532f5df0ca00ab78e046eb17c54',1977,'SN','Senegal','communications',453,'Atlantic
© Qeean
(See reference map Vi)
LAND
196,840 km?; 18% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 2,680 km
WATER
Limits of territorial waters (claimed): 150 nm
(200 nm exclusive economic zone)
Coastline: 531 km
Railroads: 1,030 km meter gage (1.00 m); 64 km
double track
Highways: 13,330 km; 2,586 km bituminous, 456
km gravel, 10,288 km improved earth
Inland waterways: 1,505 km
Ports: 1 major (Dakar), 2 minor
Civil air: 5 major transport aircraft
Airfields: 27 total, 27 usable; 11 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 19
with runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: relatively advanced for
Africa; 36,400 telephones; 287,000 radio receivers;
1,800 TV receivers; 8 AM stations, no FM, and 1 TV
station; 3 submarine cables; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 989,000;
512,000 fit for military service; 52,000 reach military
age (18) annually
Military budget: for fiscal year ending 30 June
1976, $43,625,302; about 7.8% of central government
budget','3b75ef80629c579cce8c1e231ddf3b4c816505563555b8b75ce8533a534e4f12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb192e2389ed2dfe5b5c236dc2d82454c7cbb27f1de994692cc63231b9b9ab2d',1977,'SC','Seychelles','communications',457,'LAND
404 km?; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other
(mainly reefs and other surfaces unsuited for
agriculture); 40 granitic and 48 coral islands
WATER
Limits of territorial waters (claimed): 3 nm
(fishing 12 nm)
Coastline: 491 km (Mahe Island 93 km)','50a6ebdff05d1e4ccf8c408c4e2ae607486e6a0c399f4169024a2a8e91bac8d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59f456d9add26c3f7cb726e8024853b23840c6d0e359a0bbecf4c744541cb50c',1977,'SL','Sierra Leone','communications',461,'LAND
72,261 km?; 65% arable (6% of total land area
under cultivation), 27% pasture, 4% swampland, 4%
forested
Land boundaries: 933 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 402 km
181
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GUINEA“ Cpe
BISSAU
Freetow
SIERR
LEONE
3 i
Atlantic
Ocean
{See reterenca map Vi)
Railroads: about 96 km narrow gage (1.067 m)
privately owned mineral line operated by the Sierra
Leone Development Company
Highways: 7,076 km; 1,148 km_ bituminous
(including some bituminous treatment), 2,096 km
laterite (some gravel), and 3,832 km earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SIERRA LEONE/SINGAPORE
Inland waterways: 800 km; 600 km navigable
year-round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft
Airfields: 16 total, 16 usable; 6 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 5 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: telephone and telegraph are
adequate; 10,300 telephones; 62,000 radio and 6,000
TV receivers; 1 AM station, no FM, and | TV station;
3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 649,000; 312,000
fit for military service; no conscription
Military budget: for year ending 30 June 1975,
$9,548,203; 6.97% of central government budget','618b957058e45e0381cf3ea0ccafc11afb69c2f45f067551279c56e2a9e4e0f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e29c70f36cdb7559fb5e322bedb8c61aca3f9a39fcb8cfa07570300509087368',1977,'SG','Singapore','communications',465,'South
China Sea
(See reference map Vil)
LAND
583 km?; 31% built up area, roads, railroads, and
airfields, 22% agricultural, 47% other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Organized labor: 24% of labor force
Railroads: 38 km of meter gage
Highways: 2,200 km (1975); 1,700 km paved, 500
km crushed stone or improved earth
Ports: 3 major
Civil air: 19 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 2
with runways 1,220-2,489 m
Telecommunications: adequate domestic facilities;
good international service; good radio and television
broadcast coverage; 280,000 telephones; 356,000
tadio and 269,000 TV sets; 2 AM, 4 FM, and 2 TV
stations; SEACOM submarine cable extends to Hong
Kong via Sabah, Malaysia; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 628,000; 447,000
fit for military service
Military budget: for fiscal year ending 381 March
1977, $389.5 million; about 18.5% of central
government budget','b596402e72fe75c662136732539c3f7c9d08fd969049e3d07a637149aaf34f8e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('134a8f5dce7daa03eab668e249499a0b5b488d58f0f44d7ebd756a848660cf03',1977,'SO','Somalia','communications',469,'LAND
637,140 km?; 18% arable (0.3% cultivated), 32%
grazing, 14% scrub and forest, 41% mainly desert,
urban, or other
Land boundaries: 2,263 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline; 3,025 km
Railroads: none
Highways: 13,541 km; 986 km paved, 770 km
crushed stone, gravel, or stabilized soil, 11,835 km
improved or unimproved earth
Ports: 8 major (Mogadiscio, Berbera, Chisimaio)
Civil air: 4 major transport aircraft
Airfields: 56 total, 42 usable; 5 with permanent-
surface runways; 1 with runway over 3,660 m; 2 with
runways 2,440-3,659 m; 14 with runways 1,220-
2,489 m
Telecommunications: telephone poor, telegraph
fair; 4,740 telephones; 68,000 radio receivers; 2 AM,
no FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 768,000; 424,000
fit for military service; no conscription
Military budget: for fiscal year ending 31
December 1972, 19,400,000; 25.3% of central
government budget ‘','100a7f08b6edf3ef4ba18060bf7b6bf2329545c584aed57c5f500a8f71158d0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('126fc99c0b4be984044f3fdd2a2dadabeed30c33639b2735b01a7bf52413c9bd',1977,'ZA','South Africa','communications',473,'NOTE: separate data on Transket follows last entry
for South Africa
LAND
1,222,480 km?; (includes enclave of Walvis Bay,
1,124 km?); 12% cultivable, 2% forested, 86% desert,
waste, or urban
Land boundaries: 2,044 km
WATER
Limits of territorial waters (claimed): 6 nm
(fishing, 12 nm)
Coastline: 2,881 km
Railroads: 19,902 km; 19,196 km 1.065-meter gage
of which 2,456 km are multiple track; 4,472 km
electrified; 706 km 0.160-meter gage single track
Highways: 332,500 km; 52,100 km paved, 76,200
km crushed stone or gravel, 204,200 km improved and
unimproved earth
Pipelines: 836 km crude oil; 1,030 km refined
products; 322 km natural gas
Ports: 5 major, 6 minor
Civil air: 73 major transport aircraft
Airfields: 665 total, 532 usable; 60 with
permanent-surface runways; 1 with runway over
8,660 m, 7 with runways 2,440-3,659 m, 129 with
runways 1,220-2,439 m
Telecommunications: the system is the best
developed, most modern, and highest capacity in
Africa and consists of carrier-equipped open-wire
lines, coaxial cables, radio-relay links, and
radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria; 1.9 million telephones;
2.5 million radio and 100,000 TV receivers; 13 AM, 60
FM, and 18 TV stations; 4 submarine cables; satellite
ground-stations
DEFENSE FORCES
Military manpower: males 15-49, 6,109,000;
3,568,000 fit for military service; obligation for service
in Citizen Force begins at 18; volunteers for service in
permanent force must be 17
Military budget: for year ending 31 March 1977,
$1.6 billion; 17.2% of central government budget
Transkei
NOTE: Formerly an autonomous tribal homeland
in South Africa, Transkei was granted independence
by South Africa on October 26, 1976, but has not been
recognized by any other government or any
international organization. It remains heavily
dependent on South Africa for administrative and
economic support.
LAND
44,000 km? in one large and two small pieces
separated from each other by parts of South Africa
Land boundaries: 1,200 km
WATER
Coastline: 250 km
186 Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
i
1 ph. Pai
rR i 4a 2
Mp
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SOUTH AFRICA/SOUTH-WEST AFRICA
Railroads: less than 160 km
Highways: 725 km paved, 7,768 km unpaved
Ports: none; Transkei dependent on the South
African port of East London
DEFENSE FORCES
Military manpower: males 15-49, 215,000
Personnel: 254 army (including 7 officers)
Major ground units: 1 infantry battalion
SOUTH-WEST AFRICA
(Namibia)
LAND
823,620 km?; mostly desert except for interior
plateau and area along northern border
Land boundaries: 3,798 km
WATER
Limits of territorial waters (claimed): 6
nm (fishing, 12 nm)
Coastline: 1,489 km
Railroads: 2,326 km 1.065-meter gage, single track
Highways: 3,379 km; 3,765 km paved, 354 km
gravel, remainder earth roads and tracks
Ports: 1 major (Walvis Bay), 1 minor
Civil air: 5 major transport aircraft (registered in
South Africa)
Airfields: 112 total, 88 usable; 13 with permanent-
surface runways; 1 with runway over 3,660 m; 3 with
runways 2,440-3,659 m, 37 with runways 1,220-
2,489 m
Telecommunications: system is a meager combina-
tion of open-wire lines, a single short radio-relay link,
and scattered radiocommunication stations; Wind-
hoek is the center; 43,000 telephones; unknown
number of radio receivers; no AM, 1 FM, and no TV
stations
188 Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SOUTH-WEST AFRICA/SPAIN
DEFENSE FORCES
Military manpower: males 15-49, about 216,000;
about 126,000 fit for military service
Defense is responsibility of Republic of South Africa','55e635f18f0d2612311adf416e2fa88881895e1429862ce635a45de17e7f1689','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8402ebff2db8bf90b1e771c209021fd96a0b5bd068d0c4c69cbc47912dce6b5',1977,'LK','Sri Lanka','communications',480,'(formerly Ceylon)
a ae
Arabian
Sea
Bay
of Bengal}
SRI
: eae
Colombo*
indian Ocean
(See reference map Vil)
LAND
65,500 km?; 25% cultivated; 44% forested; 31%
waste, urban, and other
WATER
Limits of territorial waters (claimed): 12 nm
(fishing, 12 nm plus pearling in the Gulf of Mannar,
and right to establish 100 nm conservation zone)
Coastline: 1,340 km
Railroads: 1,535 km; 1,395 km 1.676-meter gage,
140 km 0.762-meter gage; 102 km double track; no
electrification; government owned
Highways: 52,200 km (1975); 24,300 km paved
(mostly bituminous treated), 18,800 km crushed stone
or gravel, 9,400 km improved earth or unimproved
earth; in addition several thousand km of tracks,
mostly unmotorable
Inland waterways: 430 km; navigable by shallow-
draft craft
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1 leased)
Airfields: 14 total, 10 usable; 10 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 6 with
runways 1,220-2,439 m
192
Telecommunications: an inadequate telephone
and a less extensive but more efficient telegraph
system serves most areas, with greatest concentration
around Colombo and Kandy; all areas are served by
radio and/or wire broadcast: good international
service; 70,000 (est. ) telephones; 530,000 radio sets, no
TV sets; 6 AM stations, 2 FM, and no TV stations;
submarine cables extend to India, Malaysia, Seychelle
Islands, and Aden; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,446,000;
2,596,000 fit for military service; 158,000 reach
military age (18) annually
Military budget: for fiscal year ending 31
December 1976, $21.3 million, 2% of central
government budget','8a64e5d193a670894c7d18a747522977169fb58b3cacc69293b16beb79fbb07f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('205fe68c2beda7d85b042ec3d56cacbd543e96deb44d1dc9a5b92e3c90c55d83',1977,'SD','Sudan','communications',484,'= SUDAN
(See reference map Vi}
LAND
2,504,530 km?; 37% arable (3% cultivated), 15%
grazing, 38% desert, waste, or urban, 15% forest
Land boundaries: 7,805 km
WATER
Limits of territorial waters (claimed); 12 nm (plus
6 nm “‘necessary supervision zone’’)
Coastline: 853 km
Railroads: 5,466 m; 4,754 km 1.067-meter gage,
716 km 1.6096-meter gage plantation line
Highways: 10,560 km; 310 km bituminous-treated,
1,100 km crushed stone or gravel, and 9,150 km
improved and unimproved earth roads; in addition,
there are an undetermined number of tracks
Inland waterways: 5,310 km navigable
Ports: 1 major (Port Sudan)
Civil air: 9 major transport aircraft
Airfields: 74 total, 70 usable; 7 with permanent-
surface runways; 2 with runways 2,440-3,659 m, 80
with runways 1,220-2,439 m
Telecommunications: large system by African
standards, but still barely adequate for size of country;
consists of open-wire lines, radio-relay links,
multiconductor cables, radiocommunication stations
and a tropospheric-scatter link; principal center
Khartoum, secondary centers Al Fashir and Port
Sudan; 56,000 telephones; 650,000 radio and 100,000
TV receivers; 2 AM stations, no FM, and 1 TV
station; 1 submarine cable; satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 4,079,000;
2,500,000 fit for military service; average number
reaching military age (18) annually, 180,000
Military budget: for fiscal year ending 30 June
1976, $120,620,300; 9.6% of central government
budget
193
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SURINAM
SURINAM
@
Caribbean A .
Sea ‘ Atlantic
Ocean
Paramaribo
Rt, FRENCH
; ={SuRINAM GUIANA
(See reference map tii)
LAND
142,709 km?; negligible amount of arable land,
meadows and pastures, 76% forest, 8% unused but
potentially productive, 16% built-on area, wasteland,
and other
Land boundaries: 1,561 km
WATER
Limits of territorial waters (claimed): 3 nm
(fishing, 12 nm)
Coastline: 386 km
Railroads: 166 km; 86 km meter gage (1.00 m)
(government-owned) and 80 km narrow gage
(industrial lines); all single track
Highways: 2,500 km; 500 km paved, 200 km
gravel, 600 km improved earth, 1,200 km unimproved
earth
Inland waterways: 4,500 km; most important
means of transport; oceangoing vessels with drafts
ranging from 4.2 m to 7 m can navigate many of the
principal waterways while native canoes navigate
upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
Airfields: 30 total, 29 usable; 2 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 4 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: international facilities good;
domestic radio-relay system; 14,000 telephones;
110,000 radio and 35,000 TV receivers, 5 AM, 1 FM,
and 3 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 100,000; 59,000
fit for military service
Ships: 3 river patrol craft
SWAZILAND
(See reference map Vi)
LAND
17,353 km?; most of area suitable for crops or
pastureland
Land boundaries: 435 km
Railroads: 222 km 1.065-meter gage, single track
Highways: 3,401 km; 241 km paved, 1,389 km
crushed stone, gravel, or stabilized soil, and 1,771 km
improved or unimproved earth
Civil air: 4 major transport aircraft
Airfields: 32 total, 26 usable; 1 with runway 1,220-
2,439 m
Telecommunications: the system consists of a few
open-wire lines and low-powered radiocommunica-
tion stations; Mbabane is the center; 6,970
telephones; 55,000 radio receivers; 1 AM, no FM or
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 113,000; 65,000
fit for military service','e246542890cd22918757eb0e5f4ce40e130369949b69327a85e3f383b1ad40f1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef2b948a7aa286a25d9447dfdfee995372db415496e3f856dc6d92636232197a',1977,'SE','Sweden','communications',488,'LAND
448,070 km?; 8% arable, 1% meadows and pastures,
55% forested, 36% other
Land boundaries: 2,196 km
WATER
Limits of territorial waters (claimed): 4 nm
(fishing, 12 nm)
Coastline: 3,218 km
Railroads: 11,931 km; Swedish State Railways
(SJ)—11,179 km standard gage (1.435 m), 6,959 km
electrified and 1,152 km double track; 182 km 0.891-
meter gage; privately-owned railways—472 km
standard gage (1.485 m) and 300 km electrified; 158
km 0.891-meter gage electrified
Highways: 96,640 km; 67,680 km are crushed
stone, gravel, or improved earth: and 28,960 km are
bitumen, concrete, stone block, or cobblestone
Inland waterways: 2,052 km navigable for small
steamers and barges
Ports: 17 major, and 30 significant minor
Civil air: 60 major transports
Airfields: 242 total, 234 usable; 128 with
permanent-surface runways; 7 with runways 2,440-
3,659 m, 86 with runways 1,220-2,439 m
Telecommunications: excellent domestic and
international facilities; 5.87 million telephones; 9
AM, 91 FM, and 240 TV stations; 5 million radio and
2.96 million TV receivers; 10 submarine cables,
including 4 coaxial, COMSAT ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,876,000;
1,670,000 fit for military service; 56,000 reach military
age (19) annually
Military budget: for fiscal year ending 30 June
1977, $2.41 billion; about 9.6% of central government
budget','5c38e0c89c488d28aed75952adba8129dfa20f644e5ad72a11ac7cf681a3c547','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a43dbede1b9fce6814c49db67d6d9d994abf208071397cde6b6e937e1f22b1d9',1977,'TG','Togo','communications',495,'LAND
56,980 km?; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,646 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 56 km
Railroads: 442 km meter gage (1.00 m), single track
Highways: approx. 7,172 km; 1,049 km paved,
6,123 km gravel/earth
Inland waterways: section of Mono River and
about 50 km of coastal lagoons and tidal creeks
Ports: 1 major (Lome), 1 minor
Civil air: 2 major transport aircraft
Airfields: 11 total, 11 usable; 1 with permanent-
surface runway 1,220-2,439 m
Telecommunications: poor system based on
skeletal network of open-wire lines supplemented bya
few radiocommunication stations; only center is
Lome; 6,100 telephones; 51,000 radio receivers; 2
AM, 1 FM radio station, 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 493,000; 260,000
fit for military service; no conscription
204
Supply: most military materiel obtained from','0fc2f52963cdad9de020e0caf3ba770dd35c13fb0f37edf85b70bb2454fedcc3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c85fdfb85339e201190f86b9feeee851cb9efa53cea392bf130f5c64d1a19351',1977,'TO','Tonga','communications',499,'Nuku''alofa
“Pacific Ocean.
(See reference map Vit)
LAND
997 km? (150 islands); 77% arable, 3% pasture, 138%
forest, 3% inland water, 4% other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 419 km (est.)
Railroads: none
Highways: 249 km (1974); 177 km rolled stone; 72
km coral base
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 4 total; 4 usable, 1 with grass runway
1,220-2,489 m; 1 seaplane station
Telecommunications: 1,090 telephones; 10,000
radio sets; no TV sets; 1 AM station
: Nive
gNuku alofa
South Island
TO OH PA
Rigen Reel: Paimyra
Gs0
"Washington
_o Hawaii
<
7
<<
‘Fanning
Jarvis
(8.3
PHOENIX IS.
(.&. admin. U8. claim)
Islands
Administered by New Zealand».
Claimed av 9.5.) R','ab23ee54ccb8a4f5a2dbf3974730d8fb149e719b20acd1aa9371b7eef894eb5f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4ee8860877bbc513f02330142b45684653c0438d6328c9af06f4cdd7d959a6b',1977,'TT','Trinidad and Tobago','communications',503,'LAND
5,128 km?; 41.9% in farms (of which 25.7% cropped
or fallow, 1.5% pasture, 10.6% forests, 4.1% unused or
built-on), 58.1% outside of farms, including grassland,
forest, built-up area, and wasteland
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 362 km
Railroads: none
Highways: 6,750 km; 4,000 km paved, 2,750 km
gravel or otherwise improved
Pipelines: 480 km crude oil; 19 km refined
products; 209 km natural gas
Ports: 3 major (Port of Spain, Chaquaramars Bay,
Point Tembladora), 6 minor
Civil air: 12 major transport aircraft
Airfields: 8 total, 7 usable; 4 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 4 with
runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: excellent international
service via tropospheric scatter links to Barbados and
Guyana; good local service) COMSAT ground
station; 68,600 telephones; 300,000 radio and 102,700
TV receivers; 2 AM, 2 FM, and 8 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 257,000; 183,000
fit for military service
Supply: mostly from U.K.','7c2bebeff7d077aa592bc162fef9e29f4620b56044e09cf36b0d770789866687','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c41b535bc596a5ea201bfd20a22b4492a90e895b0d4472cfe86cab9c8e41ab6b',1977,'TN','Tunisia','communications',507,'is
= TNS!
Veeieg,
A. heen S09
(See reference map VI)
LAND
164,206 km?; 28% arable land and tree crops, 23%
range and esparto grass, 6% forest, 48% desert, waste
or urban
Land boundaries: 1,408 km
WATER
Limits of territorial waters (claimed): 12 nm
(fishing, 12 nm exclusive fisheries zone follows the 50-
meter isobath for part of the coast, maximum 65 nm)
Coastline: 1,143 km (includes offshore islands)
Railroads: 1,999 km; 478 km standard gage (1.435
m), 1,526 km meter gage (1.00 m)
Highways: 16,093 km; 10,646 km bitimunous; 483
km gravel; 1,609 km improved earth; 3,355 km
unimproved earth
Pipelines: 797 km crude oil; 10 km refined
products; 72 km natural gas
Ports: 4 major, 8 minor
Civil air: 12 major transport aircraft
Airfields: 34 total, 29 usable; 11 with permanent-
surface runways; 3 with runways 2,440-3,659 m; 15
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: the system is above the
African average in amount and capacity of facilities
which consist of open-wire lines with multiconductor
cable or radio relay on trunk routes; key centers are
Safagis, Susah, Bizerte, and Tunis; 114,250
telephones; 401,000 radio and 100,000 TV receivers; 3
AM, 3 FM, and 7 TV stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,513,000;
833,000 fit for military service; about 60,000 reach
military age (20) annually
Military budget: for fiscal year ending 31
December 1975, $70,100,000; 5.2% of central
government budget
TURKEY
LAND
766,640 km’; 35% cropland, 25% meadows and
pastures, 23% forested, 17% other
Land boundaries: 2,574 km
207
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TURKEY
a ee Black Sea
eS a» Ankara
, TURKEY
: 3 coed
Wer
Mediterranean Sea ovens”
{See reference map V}
WATER
Limits of territorial waters (claimed): 6 nm except
in Black Sea where it is 12 nm (fishing, 12 nm)
Coastline: 7,200 km
Railroads: 8,253 km standard gage (1.435 m); 148
km double track; 72 km electrified
Highways: 60,000 km; 21,000 km bituminous;
28,000 km gravel or ccrushed stone; 2,500 km
improved earth; 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 647 km crude oil; 2,055 km refined
products
Ports: 10 major, 85 minor
Civil air: 22 major transport aircraft
Airfields: 119 total, 100 usable; 55 with
permanent-surface runways; 3 with runways over
3,660 m, 21 with runways 2,440-3,659 m, 28 with
runways 1,220-2,439 m
Telecommunications: new trunk domestic radio-
relay net, good international service; 1,023,000
telephones; 4.5 million radio and 900,000 TV
receivers; 40 AM, 4 FM, and 4 TV stations; COMSAT
station planned
DEFENSE FORCES
Military manpower: males 15-49, 10,411,000;
6,133,000 fit for military service; about 445,000 reach
military age (20) annually
Military budget: proposed for fiscal year ending 28
February 1977, $2,359.7 million; about 23.7% of
proposed central government budget','3bfb4cc0bea35988905a66b06c13537ab48b2a64a97fbf337d01b08d1ec8c496','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('714fd4069e1dee5b1964e17b73964828bfed329b7f6baae53f108542bf9234c6',1977,'TV','Tuvalu','communications',511,'(formerly Ellice Islands)
NOTE: On October 1, 1975, by Constitutional
Order, the Ellice Islands were formally separated from
the British colony of Gilbert and Ellice Islands, thus
forming the new colony of Tuvalu. The remaining
islands in the former Gilbert and Ellice Islands Colony
were renamed the Gilbert Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and
those islands claimed by the United States: Funafuti,
Nukufetau, Nukulailai, and Nurakita.
LAND
26 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
nires" .
ape STATES
Pacific Ocean
3. GILBERT
ISLANDS
& *;. TUVALU
te
a.
oe
@ Fil
(See raference map Vit}
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
Airfields: 1 total; 1 usable with runway 1,220-
2,489 m; 1 seaplane station
Telecommunications: 1 AM station; about 250
telephones','a8275b2d8fb4f521ed52a4635d1b71e12536fbc5d94cba1e0e9381be3896ad73','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa9d7962bd724aa25f8c2d2ea809575244b8c695c2f716dc03520d3ced3eb946',1977,'UG','Uganda','communications',514,'LAND
235,690 km?; 21% inland water and swamp,
including territorial waters of Lake Victoria, about
21% cultivated, 13% national parks, forest, and game
reserves, 45% forest, woodland, and grassland
Land boundaries: 2,680 km
209
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
UGANDA/U.S.S.R.
‘Indian
Ocean
{See reference map Vi}
Railroads: 1,216 km, meter gage (1.00 m ), single
track
Highways: 25,330 km; 2,064 km_ bituminous
surface treatment; 18,351 km crushed stone, gravel,
and laterite; 4,915 km earth roads and tracks
Inland waterways: Lake Victoria, Lake Albert,
Lake Kyoga, Lake George, and Lake Edward (9,670
km); Kagera River and Victoria Nile (610 km)
. Civil air: 10 major transport aircraft
Airfields: 53 total, 50 usable; 5 with permanent-
surface runways; 1 with runway over 3,660 m, 3 with
runways 2,440-8,659 m, 12 with runways 1,220-
2,489 m
Telecommunications: telephone and _ telegraph
services fair, intercity connections based on 3 or 12
channel carrier systems; 42,900 telephones; 275,000
radio and 70,400 TV receivers; 2 AM, no FM, and 6
TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 2,619,000;
about 1,489,000 fit for military service
Military budget: for fiscal year ending 30 June
1972, $42.7 million; 16.6% of central government
budget
U.S.S.R.
LAND
22,274,000 km?; 9.3% cultivated, 37.1% forest and
brush, 2.6% urban, industrial, and transportation,
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
U.S.S.R.
{See reference map Vit}
16.8% pasture and natural hay land, 34.2% desert,
swamp, or waste
Land boundaries: 20,619 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 46,670 km (incl. Sakhalin)
Railroads: 138,362 km; 136,529 km broad gage
(1.524 m); 1,833 km narrow gage (mostly 0.750 m);
108,902 km broad gage single track; 89,600 km
electrified; does not include industrial lines (1975)
Highways: 1,425,200 km; 308,800 km paved;
360,400 km gravel, crushed stone; 856,000 km
improved or unimproved earth (1975)
Inland waterways: 144,000 km_ navigable,
exclusive of Caspian Sea (1976)
Pipelines: 85,277 km crude oil; 12,872 km refined
products; 99,758 km natural gas
Ports: 63 major (most important: Leningrad,
Murmansk, Odessa, Novorossiysk, Ilichevsk, Vladivo-
stok, Nakhodka, Arkhangel’sk, Riga, Tallinn,
Kaliningrad, Liepaja, Ventspils, Nikolayev, Sevas-
topol); 116 selected minor (1976)
Freight carried: rail—3,621 million metric tons,
3,236.5 billion metric ton/km (1975); highways—19.6
billion metric tons, 312.3 billion metric ton/km
(1975); waterway—424 million metric tons, 220
billion metric ton/km (1975), excluding Caspian Sea
DEFENSE FORCES
Nuclear weapons: satisfies major requirements of
Soviet forces
Supply: fully supplies own needs and produces
large quantities of all types of materiel for export;
some light armored vehicles obtained from Eastern
Europe as an economic measure','ec37f0995b0d45b4dd8ea02bd91eb3a6b9e738001adb001cc3aa3b06b86a0223','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dca997f11ac9c25c5401673d301cff35090d28404d6b751353f27e9c3f7de4b',1977,'GB','United Kingdom','communications',521,'LAND
243,978 km?; 30% arable, 50% meadow and
pasture, 12% waste or urban, 7% forested, 1% inland
water
Approved For Release 2005/04/22
Atlantic
Ocean
(See reference map {¥)
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 12,429 km
Railroads: Great Britain—18,500 km; British
Railways (BR) operates 18,225 km standard gage
(1.485 m) (3,806 km electrified, 11,410 km double
track, 2,366 km multiple track) and 19 km 0,597-
meter gage; 256 km of. standard gage (1.435 m) and
several narrow gages are privately-owned; Northern
Ireland Railways (NIR) operates 327 km 1.600-meter
gage, 190 km double track
Highways: approx. 343,315 km and 23,175 km in
Northern Ireland
Inland waterways: 1,770 km of commercial routes
Pipelines: 933 km crude oil, almost all insig-
nificant; 2,907 km refined products; 1,770 km natural
gas
Ports: 23 major, 350 minor
Civil air: 519 major transport aircraft
Telecommunications: modern, efficient domestic
and international system; 22.4 million telephones;
41.7 million radio and 18.7 million TV receivers;
excellent countrywide broadcast; 97 AM, 118 FM and
300 TV stations; 45 submarine cables (42 coaxial); 3
earth satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 12,685,000;
10,701,000 fit for military service; no conscription;
445,000 reach military age (18) annually
Military budget: proposed for fiscal year ending 31
March 1977, $10.4 billion; about 9% of central
government budget
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
UPPER VOLTA
UPPER VOLTA
Atlantic
Ocean
{Sea reference mep VI}
LAND
274,540 km?; 50% pastureland, 21% fallow, 10%
cultivated, 9% forest and scrub, 10% waste and other
uses
Land boundaries: 3,307 km
Railroads: 1,172 km, 515 km meter gage (1.00 m),
single track, Ouagadougou to Abidjan, Ivory Coast
line
215
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
UPPER VOLTA/URUGUAY
Highways: 16,320 km; 520 km paved, 3,600 km
improved, 12,200 km unimproved
Civil air: no major transport aircraft
Airfields: 55 total, 54 usable; 2 with permanent-
surface runways; 2 with runway 2,440-3,659 m, 3 with
runways 1,220-2,439 m
Telecommunications: all services generally poor;
1,800 telephones; 100,000 radio and 6,000 TV
receivers; 2 AM stations, no FM, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,419,000;
710,000 fit for military service; no conscription
Supply: mainly dependent on France
Military budget: for fiscal year ending 31
December 1976, $18,243,900; 19.7% of central
government budget','c16abb920fff32f8064f5ebc7976e1e06d60dd79276682763e5dfc166e92b860','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ede9a1160ea1ccf8674753d2716b7f8acf8b1fca2acbbd0caffd337b0f6bd00',1977,'UY','Uruguay','communications',525,'Atlantic
Ocean
2 Montevideo
{See reference map 1V)
LAND
186,998 km?; 84% agricultural land (73% pasture,
11% cropland) 16% forest, urban, waste and other
Land boundaries: 1,352 km
WATER
Limits of territorial waters (claimed): 200 nm
(fishing 200 nm)
Coastline: 660 km
Railroads: 2,992 km, all standard gage (1.485 m)
and government owned
Highways: 51,800 km; 6,000 km paved, 7,400 km
otherwise surfaced, 15,400 km improved earth, 23,000
km earth tracks
Inland waterways: 1,600 km; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo
traffic, rail 15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor
Civil air: 15 major transport aircraft
Airfields: 99 total, 61 usable; 10 with permanent-
surface runways; 1 with runway 2,440-3,659 m, 11
with runways 1,220-2,489 m; 2 seaplane stations
Telecommunications: most modern facilities
concentrated in Montevideo; 258,000 telephones; 1.5
million radio and 400,000 TV receivers; 75 AM, 3
FM, and 17 TV stations; 2 submarine cables;
COMSAT station planned
DEFENSE FORCES
Military manpower: males 15-49, 747,000; 602,000
fit for military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1976, $73.8 million; 16.4% of central
government budget
Approved For Release 2005/04/22 :
VATICAN CITY
AUSTRIA :
Yueosiavia :
“Tyrrhenian 3
leas Ss
(See reference map iV)
LAND
0.438 km?
Land boundaries: 3 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 1 AM and 1 FM radio-
broadcasting station; 2,000-line automatic telephone
exchange
DEFENSE FORCES
Defense is responsibility of Italy
VENEZUELA
LAND
911,680 km?, 4% cropland, 18% pasture, 21%
forest, 57% urban, waste, and other
Land boundaries: 4,181 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 2,800 km
218
Caribbean Sez ae
Ocean |
{See reference map fit}
Railroads: 373 km standard gage (1.485 m) all
single track; 171 km government owned, 202 km
privately owned
Highways: 65,700 km; 19,600 km paved, 17,500
km gravel, 10,200 km improved earth, 18,400 km
unimproved (including trails)
Inland waterways: 7,100 km; Orinoco River and
Lake Maracaibo accept oceangoing vessels
Pipelines: 6,110 km crude oil; 400 km refined
products; 2,495 km natural gas
Ports: 6 major, 17 minor
Civil air: 67 major transport aircraft
Airfields: 292 total, 261 usable; 104 with
permanent-surface runways; 8 with runways 2,440-
3,659 m, 78 with runways 1,220-2,439 m; 2 seaplane
stations
Telecommunications: modern expanding telecom
system; satellite ground station; 609,400 telephones;
3.2 million radio and 1.3 million TV receivers; 157
AM, 50 FM, and 43 TV stations; 3 submarine cables,
including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 2,628,000;
1,854,000 fit for military service; 184,000 reach
military age (18) annually
VIETNAM
LAND
329,707 km?; 14% cultivated, 50% forested, 36%
urban inland water, and other
Land boundaries: 4,562 km
219
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
VIETNAM/WALLIS AND FUTNUNA
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,444 km (excluding islands)
Highways: 41,190 km; 5,471 km bituminous,
27,030 km gravel or improved earth, 8,690 km
unimproved earth
Inland waterways: about 17,072 km navigable;
more than 5,149 km navigable at all times by vessels
up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: military controlled
Airfields: 205 total, 169 usable; 73 with
permanent-surface runways; 10 with runways 2,440-
3,659 m, 30 with runways 1,220-2,439 m; 2 seaplane
stations
DEFENSE FORCES
Supply: dependent on the U.S.S.R., Eastern
European Communist countries, and the PRC for
virtually all new equipment; produces negligible
quantities of infantry weapons, ammunition and
explosive devices (Vietnam possesses a huge inventory
of U.S.- manufactured weapons and equipment
captured from the RVN)
Military budget: no expenditure estimates are
available; military aid from the U.S.S.R. and PRC has
been so extensive that actual allocation of Vietnam’s
domestic resorces to defense has not been indicative of
total military effort
NOTE: VN figures preliminary','4d7e6096c0073d40a55db9d63846ad55bf7c90aae23e0e545e76bb27cb72dff5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6259a0c068f64b4d6381ad721fc5b982157f9108682538e0671c542b63b0d41d',1977,'WF','Wallis and Futuna','communications',529,'LAND
About 207 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 129 km
Highways: 100 km of improved road on Uvea
Island (1972)
Ports: 2 minor
Airfields: 2 total, 2 usable; 1 with runway 1,220-
2,439 m, 1 seaplane station
Telecommunications: 43 telephones
DEFENSE
No formal defense structure; no regular Armed
Forces
70 Colonial Franc
Approved For Release 2005/04/22','315734b50a0ab8f726a6f8d14a5415fb673489850cd2b9eb2fec0c4493b4f070','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('069b52fd5ac3f52e9df5b859c039264510404cf02fe8e4010a9117962a867644',1977,'EH','Western Sahara','communications',533,'(formerly Spanish Sahara)
Atlantic Qcean
“» CANARY
ISLANDS
(See reference map vi
LAND
266,770 kim®, nearly all desert
Land boundaries: 2,086 km
WATER
Limits of territorial waters (claimed): 6 nm
(fishing, 12 nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km; 500 km bituminous treated,
5,600 kmunimproved earth roads and tracks
Ports: 2 major (El Aaiun, Villa Cisneros), 2 minor
Civil air: no major transport aircraft
Airfields: 14 total, 13 usable; 3 with permanent-
surface runways; 6 with runways 1,220-2,439 m
Telecommunications: telephone and telegraph
poor; 1,000 telephones; 16,000 radio receivers; 1 AM
station, no FM or TV stations
WESTERN SAMOA
To
UINEA °S,.
e », WESTERN
Pe 7 * SAMDA
(See reference map VI}
LAND
2,849 km?; comprised of 2 large islands of Savai’i
and Upolu and several smaller islands, including
Manono and Apolima; 65% forested, 24% cultivated,
11% industry, waste, or urban
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 403 km','27aa5645bd3a4bb530c1de9c86e45c496d5240c923c9fe1595475eac9eb08444','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('285a049063cef1d5cc0993bc0a844d78978e24d8080f4215a10c7871b199a558',1977,'YE','Yemen','communications',541,'Railroads: none
Highways: 5,311 km; 322 km bituminous treated,
290 km crushed stone and gravel, 4,699 km motorable
track
Ports: 1 major (Aden)
Pipelines: refined products, 32 km
Civil air: 6 major transport aircraft
Airfields: 95 total, 57 usable; 2 with permanent-
surface runways; 4 with runways 2,440-3,659 m, 32
with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: small system of open-wire
line, multiconductor cable, and radiocommunications
stations; only center Aden; 9,900 telephones; 250,000
radio and 31,000 TV receivers; 1 AM, no FM and 3
TV stations; 2 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 398,000; 220,000
fit for military service
Military budget: for fiscal year ending 31 March
1971, $15,816,000; about 34.4% of central govern-
ment budget
YEMEN (SANA)
/ndian
Ocean
(See reference map V¥}
LAND
194,250 km? (parts of border with Saudi Arabia and
Southern Yemen undefined); 20% agricultural, 1%
forested, 79% desert, waste, or urban
Land boundaries: 1,528 km
WATER
Limits of territorial waters (claimed): 12 nm (plus
6 nm “necessary supervision zone’)
Coastline: 523 km
Railroads: none
Highways: 3,477 km; 467 km bituminous; 485 km
crushed stone and gravel; 2,575 km earth, sand, and
light gravel
Ports: 1 major (Al Hudaydah), 2 minor
Civil air: 9 major transport aircraft
Airfields: 27 total, 18 usable; 6 with permanent-
surface runways; 4 with runways 2,440-3,659 m, 6
with runways 1,220-2,489 m
Telecommunications: system among Mideast’s
worst; consists of meager open-wire lines and low-
power radiocommunication stations; principal center
Sana, secondary centers Al Hudaydah and Taizz;
4,600 telephones; 87,000 radio receivers; 1 AM, no
FM or TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,585,000;
876,000 fit for military service; about 72,000 reach
military age (18) annually; univeral military
conscription law (10 January 1963) makes military
service obligatory for all Yemeni males 18-30
Military budget: for fiscal year ending 30 June
1975, $50,402,000; 54.6% of central government
budget
YUGOSLAVIA
Balgrade |
{See reference meg Hi)
LAND
255,892 km?; 82% arable, 25% meadows and
pastures, 34% forested, 9% other
Land boundaries: 3,001 km
WATER
Limits of territorial waters (claimed): 10 nm
(fishing, 12 nm)
Coastline: 1,521 km (mainland), plus 2,414 km
(offshore islands)
Railroads: 10,319 km; 9,353 km standard gage
(1.435 m), 966 km narrow gage; 794 double track;
2,116 km electrified (1974)
Highways: 98,372 km; 550 km concrete, 33,729 km
bituminous, 1,101 km stone block, 37,522 km gravel,
25,470 km earth (1974)
Inland waterways: 1,970 km (1976)
Freight carried: rail—81.5 million metric tons,
23.1 billion metric ton/km (1974); highway—80.7
million metric tons, 9.8 billion metric ton/km (1975);
waterway—19.4 million metric tons, 5.4 billion metric
ton/km (incl. int’]. transit traffic) (1974)
Pipelines: 322 km crude oil; 660 km natural gas
Ports: 9 major (most important: Rijeka, Split,
Koper, Bar), 24 minor (1976)
DEFENSE FORCES
Military budget (announced): for fiscal year
ending 81 December 1976, 32 billion dinars; about
6% of estimated GNP
ZAIRE
(See reference map V)
LAND
2,348,950 km?; 22% agricultural land (1%
cultivated), 45% forested, 33% other
Land boundaries: 9,902 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 37 km
{Aden} P
FT AB
e “i
Colombo €.”
Maldives ee
Ocean
de
“Sverdlovsk
Pe
Morth Pole
U.S. S.R.
Omsk
~
e Novosibirsk
e.
Wu-lu-mu-ch''i
* K''o-shih
(Kashgar)
(Urumehi)
we indian claim
Lan-chou,','dc8b6da496484ab14757f4460e0cfba176e1a31c490f369b8f6848271d2742f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a207680c213a8c1286bbb1205e862c5bf2f765044dfff4137ff3c502318e416d',1977,'ZM','Zambia','communications',543,'(See reference map Vij
LAND
745,920 km?; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered
trees and grassland
Land boundaries: 6,003 km
Railroads: 2,014 km, all narrow gage (1.065 m); 13
km double track
Highways: 31,671 km; 5,000 km paved, 2,694 km
crushed stone, gravel, or stabilized soil; remainder
improved and unimproved earth
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ZAMBIA/UNITED STATES
Inland waterways: 2,250 km including Zambezi
River, Luapula River, Lake Kariba, Lake Bangweulu,
Lake Tanganyika; principal port on Lake Tanganyika
is Mpulungu (of only local importance)
Pipelines: 724 km crude oil
Civil air: 8 major transport aircraft
Airfields: 168 total, 167 usable; 12 with
permanent-surface runways; 1 with runway over
3,660 m, 2 with runways 2,440-3,659 m, 21 with
runways 1,220-2,439 m
Telecommunications: all services being modern-
ized and increased; presently adequate but must be
expanded to permit growth; high-capacity wire and
tadio relay connect centers of Kitwe in northern
mining region and Lusaka along axial north-south
route; 68,000 telephones; 100,000 radio and 22,500
TV receivers; 4 AM, 1 FM, and 2 TV stations; 1
satellite ground station
DEFENSE FORCES
Military manpower: males 15-49, 1,125,000;
583,000 fit for military service
Military budget: for fiscal year ending 31
December 1972, $70,000,000; 11.6% of central
government budget','b714760ea6bc8a950450fb9bb33f4f07f65750e5e96ae2e49b2420e51ef0e369','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27df4546476c9a1307a3da8d8a652e2f8b5271b8acb1e389d97fd8b80771c70',1977,'WS','Samoa','communications',547,'Western (U.S.)
eames Pago
Apia” w#Pago
Tutuila
Rennell “
ee " Wallis and Futuna
Bs Fiji (Fr)
Santo, 4
FIJI] ISLANDS |
New Hebrides % >
Vanua Levu?
Viti Levury
“Suva. .’','8074f246c71f1f1215f092389299221e774a5234530e80f263a3fb33474c269f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

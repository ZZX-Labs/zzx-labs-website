SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c399a18a205893c2c91611f5d5841a57b3478af39658140e9e01dc8ec58fe3af',1977,'AF','Afghanistan','economy',6,'GNP: $1.2 billion (FY75, at 1972 prices), $60 per
capita; real growth rate about 2.4% (1973-75)
Agriculture: agriculture and animal husbandry
account for over 50% of GNP and occupy nearly 85%
of the labor force; main crops—wheat and other
grains, cotton, fruits, nuts; largely self-sufficient;
food shortages—wheat, sugar, tea
Major industries: cottage industries, food
processing, textiles, cement, coal mining
Electric power: 320,000 kW capacity (1975); 560
million kWh produced (1975), 29 kWh per capita
Exports: $229 million (f.0.b., FY76); fresh and
dried fruits, natural gas, karakul skins, carpets, hides,
and wool
Imports: $260 million (c.i.f., FY76); non-metallic
minerals, sugar, tires and tubes, textiles, tea, used
clothing, tobacco, transportation
Major trade partners: export—U.S.S.R., India,
U.K., Pakistan, West Germany, Switzerland, U.S.;
imports—Japan, U.S.S.R., India, West Germany,
U.K., U.S.
Aid: economic—U.S.S.R (1954-75), $1,275 million
extended, $638 million drawn; Eastern Europe (1954-
75), $39 million extended, $11 million drawn; China
(1965-75), $74 million extended, $28 million drawn;
U.S. (FY49-75), $514 million: committed; interna-
tional organizations (1946-75), $152 million;
military—U.S.S.R. (1956-75), $617 million extended,
$449 million drawn; Eastern Europe (1955-75), $31
million extended, $23 million drawn; U.S. (FY53-75),
$5 million committed
Budget: current expenditures $158 million, capital
expenditures $163 million for FY76
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
AFGHANISTAN/ALBANIA
Monetary conversion rate: 45 Afghanis=US$1
(official); 55 Afghanis=US$1 (March 1976)
Fiscal year: 21 March - 20 March','703a86181541cb4600e4c26d92edc0bd079f183f487f35e5082a8eab590a8d48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('597121f9f7b74d76c7d24180cb09baea140f97f87ccea8c376355524a8ec37b0',1977,'AL','Albania','economy',11,'GNP; $1.2 billion in 1972 (at 1972 prices), $520 per
capita
Agriculture: food deficit area; main crops—corn,
wheat, tobacco, sugar beets, cotton; food shortages—
wheat; caloric intake, 2,100 calories per day per capita
(1961/62)
Major industries: agricultural processing, textiles
and clothing, lumber, and extractive industries
Shortages: spare parts, machinery and equipment,
wheat
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ALBANIA/ALGERIA
Electric power: 500,000 kW capacity (1975); 1.8
billion kWh produced (1975), 740 kWh per capita
Exports: $91 million (1970 est.); 1964 trade—55%
minerals, metals, fuels; 23% foodstuffs (including
cigarettes); 17% agricultural materials (except foods);
5% consumer goods
Imports: $159 million (1970 est.); 1964 trade—
50% machinery, equipment, and spare parts; 16%
minerals, metals, fuels, construction materials; 16%
foodstuffs; 7% consumer goods; 7% fertilizers, other
chemicals, rubber; 4% agricultural materials (except
foodstuffs)
Monetary conversion rate: 5 leks = US$1 (commer-
cial); 12.5 leks = US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for consumption year 1 July - 30
June','49b9e73e8d8cfbae4c20d48cd98b1963d6448d3bf090d7ee57eba6825ab4a3d8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d517b64b1b2a084e45305d9a3b473f0db9de3bc811135011334267bd2735674',1977,'DZ','Algeria','economy',15,'GNP: $12.5 billion (1975 provisional), $730 per
capita, average annual increase since 1971 (current
prices), 26%; in real terms, 8% growth in 1974
Agriculture: main crops—wheat, barley, grapes,
citrus fruits ,
Major industries: petroleum, light industries,
natural gas, mining, petrochemical, electrical, and
automotive plants under construction
Electric power: 1,300,000 kW capacity (1975); 3.5
billion kWh produced (1975), 205 kWh per capita
Exports: $4,440 million (f.0.b., 1975); crude
petroleum 87%, other items—natural gas, wine, citrus
fruit, iron ore, vegetables; to France 24%, West
Germany 24%, Benelux 9%, Italy 8%, U.S.S.R. 7%
(1973)
Imports: $5,860 million (cif., 1975); major
items—capital goods 35%, semi-finished goods 28%,
foodstuffs 23%; from France 38%, West Germany 9%,
Italy 9%, U.S. 8% (1973)
Monetary conversion rate: 3.95 dinars =US$1
Fiscal year: calendar year','14de1c95139d6e388f8f5ca358c162129fb730f8e17c018ecb0a78c82c6af3f4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de3b69d0becd44cf3227e90eae457a5b90819ebaa610c624c02ecc9a4ce5d91b',1977,'AD','Andorra','economy',19,'Agriculture: sheep raising; small quantities of
tobacco, rye, wheat, barley, oats, and some vegetables
(less than 4% of land is arable)
Major industries: tourism ($1 million annually),
one cigarette factory (annual output $1 million),
handicrafts, smuggling (tobacco to France; manufac-
tured items, including automobiles and cameras, to
Spain)
Shortages: food
Electric power: 25,000 kW capacity (1975); 100
million kWh produced (1975), 308 kWh per capita;
power is mainly exported to Spain and France
Major trade partners: Spain, France','b16a336916ef3e5da220a1b78c38541306274b56cce930e4d636e6f8638706e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ce3b244c6a0878d32e211180f60f1c2e4664dd47ad779efdc1d00ed5cfa244b',1977,'AO','Angola','economy',23,'GDP: $8.0 billion (1974 est. ), $500 per capita, 6.1%
real growth (1970-72); growth probably negative in
1975-76 because of civil war
Agriculture: cash crops—coffee, sisal, corn, cotton,
sugar, manioc, and tobacco; food crops—cassava,
corn, vegetables, plantains, bananas, and other local
foodstuffs; largely self-sufficient in food
Fishing: catch 469,700 metric tons (1974); exports
$52.9 million; imports $5.5 million (1973)
Major industries: mining (oil, iron, diamonds), fish
processing, brewing, tobacco, sugar processing,
textiles, cement, food processing plants, building
construction
Electric power: 510,000 kW capacity (1975); 1.0
billion kWh produced (1975), 165 kWh per capita
Exports: $1.2 billion (f.0.b., 1974); oil, coffee,
diamonds, sisal, fish and fish products, iron ore,
timber, corn, and cotton (exports down sharply in
1975 and 1976)
Imports: $614 million (c.if., 1974); capital
equipment (machinery and electrical equipment),
wines, bulk iron and ironwork, steel and metals,
vehicles and spare parts, textiles and clothing,
medicines; military deliveries partially offset drop in
imports in 1975
Major trade partners: main partner Portugal,
followed by West Germany, U.S., U.K., Japan; trade
with U.S.S.R. and Cuba increasing since independ-
ence
Aid: military aid from U.S.S.R. and Cuba in 1975
Budget: (1975) balanced at about $740 million by
former Portuguese administration; budget not yet
published by new government
Monetary conversion rate: (still using Portuguese
currency) 31.39 escudos=US$1 as of July 1976
(floating since February 1978)
Fiscal year: calendar year
GDP: $51 million (1974 est.), $650 per capita; 2.7%
real growth
Agriculture: main crop, cotton
Major industries: oil refining, tourism
Shortages: electric power
Electric power: 23,000 kW capacity (1975); 36
million kWh produced (1975), 450 kWh per capita
Exports: $29 million (f.0.b., 1973); petroleum
products, cotton
Imports: $47 million (c.i.f., 1978); crude oil, food,
clothing
Major trade partners: 30% U.K., 25% U.S., 18%
Commonwealth Caribbean countries
Aid: economic—U.S. authorizations (FY46-75),
$1.5 million in loans
Monetary conversion rate: 2.70 East Caribbean
dollars = US$1 (July 1976)','7321dbff98aa48f9823cf75cfee203d310335b0bbb09d888cf66ec219c4e12fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('019f84eac61d85ef6c061b020ed25e443a67dcd0bfc4129a0b623cc073ab1886',1977,'AR','Argentina','economy',27,'GNP: $37.8 billion (at average theoretical parity
exchange rate, 1974), $1,510 per capita; 18%
government consumption, 62% private consumption,
22% investment, —2% net foreign demand (1975);
real GDP growth rate 1975, —1.4%
Agriculture: main products—cereals, oilseeds,
livestock products; Argentina is a major world
exporter of temperate zone foodstuffs
Fishing: catch 301,800 metric tons (1974), $44.6
million (1972); exports $25 million (1973), imports
$1.8 million (1973)
Major industries: food processing (especially
meatpacking), motor vehicles, consumer durables,
textiles, chemicals, printing, and metallurgy
Crude steel: 2.2 million metric tons produced
(1975), 80. kg per capita
Electric power: 9 million kW capacity (1975); 25
billion kWh produced (1975), 1,100 kWh per capita
Exports: $2.96 billion (f.0.b., 1975); meat, corn,
wheat, wool, hides, oilseeds
Imports: $3.95 billion (c.i.f., 1975); machinery,
fuel and lubricating oils, iron and steel, intermediate
industrial products
Major trade partners (1975): exports—10% Italy,
10% U.S.S.R., 8% Netherlands, 7% Brazil, 6% U.S.;
imports—16% U.S., 18% Japan, 11% FRG, 9% Brazil
Aid: economic—extensions from U.S. (FY46-75),
$990 million in loans, $17.9 million in grants; from
international organizations (FY46-75), $1.4 billion;
from other Western countries (1960-66), $315.5
million; from Communist countries (1954-75), $513
million ($56 million drawn); military—assistance
from U.S. (FY46-75), $230 million
Monetary conversion rate: official, 140 pesos=
US$1; free market 245 pesos=US$1, effective rate
approximately 159 pesos=US$1 for imports, 215
pesos = US$1 for exports (September 1976)
Fiscal year: calendar year','d558881eb961118aedb7df6d2d10a5f4e6a02dc8323a937046309c6800b26959','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03e3c39611f6ac7e06a1e80d1c834453bde2fb39aec1dce16772025f73265036',1977,'AU','Australia','economy',31,'GNP: $83.0 billion (1975), $6,050 per capita; 60%
private consumption, 16% government current
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
AUSTRALIA/AUSTRIA
expenditure, 24% investment (1975); real average
annual growth (1970-75), 3%
Agriculture: large areas devoted to livestock
grazing; 60% of area used for crops is planted in
wheat; major products—wool, livestock, wheat, fruits,
sugarcane self-sufficient in food; caloric intake, 3,300
calories per day per capita
Fishing: catch 123,500 metric tons (1974); exports
$94.5 million (FY75), imports $86.2 million (FY75)
Major industries: mining, bauxite, industrial and
transportation equipment, food processing, chemicals
Crude steel: 7.9 million metric tons produced
(1975), 580 kg per capita
Electric power: 20,600,000 kW capacity (1975);
74.1 billion kWh produced (1975), 5,410 kWh per
capita
Exports: $11.9 billion (f0.b., 1975); principal
products (1975)—44% agricultural products, 14%
metalliferous ores, 8% wool, 8% coal
Imports: $11.1 billion (f.0.b., 1975)
Major trade partners: (1975) exports—29% Japan,
10% U.S., 5% New Zealand, 5% U.K.; imports—20%
U.S., 15% U.K., 18% Japan
Aid: economic—Australian aid abroad $2.8 billion
(FY65-75); $430 million (FY75), 55% for Papua New
Aid: $32 million in aid during 1974-76 from U.K.;
US (FY53-75) $0.7 million
Budget: FY75—revenues $14.5 million, expendi-
tures $18 million
Monetary conversion rate: 5.4 Seychelles
rupees= US$1
Fiseal year: calendar year','f0279d2f5d99a6c4c7fcb839fc70473f3e11bc3a6cca5cdb3806976541df000b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f06b792ed42186283bb21aa57f1f8e08fd57f651aa29c0deccdc8c543a0fbc0',1977,'GN','Guinea','economy',32,'Budget: expenditures, A$21.9 billion; receipts
A$19.1 billion (FY76)
Monetary conversion rate: 0.81 Australian
dollar=US$1 (A$1 =US$1.24), July 1976
Fiscal year: 1 July - 30 June
GDP: $1,425 million (mid 1975), per capita about
$220; real growth rate about 2.2% per annum
Agriculture: commercial and food crops — cocoa,
coffee, timber, cotton, rubber, bananas, peanuts,
palm oil and palm kernels; root starches, livestock,
millet, sorghum, and rice
Fishing: imports 7,024 metric tons, $2.2 million;
exports 909 metric tons (largely shrimp), $3.5 million
(1975)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CAMEROON/CANADA
Major industries: small aluminum plant, food
processing and light consumer goods industries,
sawmills
Electric power: 358,000 kW capacity (1975); 1.1
billion kWh produced (1975), 170 kWh per capita
Exports: $449 million (f.0.b., 1975); cocoa and
coffee about 55%; other exports include timber,
aluminum, cotton, natural rubber, bananas, peanuts,
tobacco, and tea
Imports: $598 million (cif, 1975); consumer
goods, machinery, transport equipment, alumina for
refining, petroleum products, food and beverages
Major trade partners: about 70% of total trade
with France and other EC countries; about 5% of
total trade with U.S.
Budget: FY76 budget est. balanced at $500 million
Monetary conversion rate: 248.22 Communaute
Financiere Africaine francs= US$1 as of August 1976
Fiscal year: 1 July - 30 June
GDP: about $729 million (1975 est), $170 per
capita
Agriculture: cash crops—coffee, bananas, palm
products, peanuts, and pineapples; staple food
crops—cassava, rice, millet, corn, sweet potatoes;
livestock raised in some areas
Major industries: alumina, light manufacturing
and processing industries, bauxite mining
Electric power: 100,000 kW capacity (1975); 400
million kWh produced (1975), 90 kWh per capita
Exports: $190 million (f.0.b., 1975); alumina,
bauxite, coffee, pineapples, bananas, palm kernels
Imports: $187 million (c.if., 1975); petroleum
products, metals, machinery and transport equip-
ment, foodstuffs, textiles
Major trade partners: Communist countries,
Western Europe (including France), U.S.
Budget: (FY75) current revenue $180 million,
current expenditures $154 million
Monetary conversion rate: 20.33 syli=US$1
(February 1976)
Fiscal year: 1 October - 830 September
GDP: $4.1 billion (1975 est.), $825 capita; average
annual growth rate in constant prices, 3.1% (1970-75)
Agriculture: commercial—coffee, cocoa, wood,
bananas, pineapples, palm oil; food crops—corn,
millet, yams, rice; other commodities—cotton,
rubber, tobacco, fish; self-sufficient in most
foodstuffs, but rice, sugar, and meat imported
Fishing: catch 69,000 metric tons (1974) valued at
$20.8 million; exports $12.0 million (1974), imports
$23.8 million (1974)
Major industries: food and lumber processing, oil
refinery, automobile assembly plant, textiles, soap,
105
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
IVORY COAST/JAMAICA
flour mill, matches, three small shipyards, fertilizer
plant, and battery factory
Electric power: 450,000 kW capacity (1975); 962
million kWh produced (1975), 140 kWh per capita
Exports: $1.2 billion (f.0.b., 1975); coffee, tropical
woods, cocoa, 70% of total; bananas, pineapples,
palm oil
Imports: $1.1 billion (cif, 1975): about 40%
consumer goods, 10% raw materials and fuels, about
50% manufactured goods and semi-finished products
Major trade partners: France and other EC
countries about 65%, U.S, 13%, Communist countries
about 1%
Aid: economic—France (1960-69), $312 million;
EC through FY75, $203.2 million; U.S. (FY61-75),
$140.1 million: others (1960-71), $76 million,
including $18.5 million committed; no Communist
aid programs; military—non-Communist countries
(1954-67), $7.3 million
Budget: 1976 est.—revenues $626 million, current
expenditures $267 million, investment expenditures
$247 million
Monetary conversion rate: about 248.22 Com-
munaute Financiere Africaine francs = US$1, August
1976
Fiscal year: calendar year','5eabbcb29adf9e9ae4a736ae8bbd39dc086c4dba508eabd84e56cfa113f376b1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce609d94aa899ae230428fcd6646724a4ff2efe32cbccac125003dc563b5803e',1977,'AT','Austria','economy',37,'GNP: $37.7 billion (1975), $5,000 per capita;
53.5% consumption, 27.8% investment, 15.2%
government, 8.5% net errors and omissions (1974),
1975 growth rate —2.5%, constant prices
Agriculture: livestock, cereals, potatoes, sugar
beets; 84% self-sufficient; caloric intake 3,280 calories
per day per capita (1969-70)
Major industries: foods, iron and steel, machinery,
textiles, chemicals, electrical, paper and pulp
Crude steel: 4.7 million metric tons produced
(1974), 630 kg per capita (1974)
Electric power: 9,840,000 kW capacity (1975);
35.2 billion kWh produced (1975), 4,600 kWh per
capita
Exports: $7.5 billion (f.0.b., 1975); iron and steel
products, machinery and equipment, lumber, textiles
and clothing, paper products, chemicals
Imports: $9.4 billion (c.i.f., 1975); machinery and
equipment, chemicals, textiles, coal, petroleum,
foodstuffs
Major trade partners: (1975) 40% West Germany,
8.1% Italy, 6.7% Switzerland, 4.1% France, 2.9%
U.S., 54% EC; 14% EFTA; 18% Communist countries
Aid: economic—authorized—U.S. $1,218 million
through FY73; IBRD $105 million through FY73,
none since FY62; military—U.S., $116 million (FY52-
73); net official economic aid delivered to less
developed areas and multilateral agencies—$205
million (FY62-72), $40.2 million (1973) and $59.3
million (1974)
Budget: expenditures, $11,292 million; receipts,
$9,158 million; deficit $2,133 million (1975)
Monetary conversion rate: 17.42 shillings = US$1,
average 1975 (floating rate)
Fiscal year: calendar year
GNP; $496 million (at market prices, 1973), $2,490
per capita
Agriculture: food importer, main crops—fish,
fruits, vegetables
Major industries: tourism, cement, oil refining,
lumber, salt production
Electric power; 250,000 kW capacity (1975); 680
million kWh produced (1975), 3,600 kWh per capita
Exports: $2.3 billion (f.0.b., 1975 est.); fuel oil,
pharmaceuticals, cement, rum
Imports: $2.6 billion (c.i.f., 1975 est.); crude oil,
foodstuffs, manufactured goods
Major trade partners: exports—U.S. 86%, U.K.
2%, Canada 2%; imports—U.S. 24%, Libya 20%,
Nigeria 16% (1973)
Aid: economic—authorizations from U.S. (FY56-
75), $51.2 million in loans, $0.3 million in grants;
from international organizations (FY71-75), $2.0
million, $24.8 million in loans, $0.3 million in grants
Monetary conversion rate: 1 Bahamian dollar
(B$1)=US$1
Fisca] year: calendar year
GNP: $400 million (1974), $1,690 per capita,
dominated by oil industry; 1975 average daily crude
oil production, 60,000 bbls (oil expected to last 15
years if no new discoveries are made); 1975 non
associated natural gas production, 102 billion ft*;
government oil revenues for 1976 are estimated at
$383.6 million
Agriculture: produces dates, alfalfa, vegetables;
dairy and poultry farming; fishing; not self-sufficient
in food
Major industries: petroleum refining, aluminum
smelting, boatbuilding, shrimp fishing, pearls and
sailmakirig on a small scale; major development
projects include flourmill, and ISA town; OAPEC dry
dock to be built by 1977
Electric power: 500,000 kW capacity (1975); 900
million kWh produced (1975), 3,700 kWh per capita
Exports: exports and reexports, $164 million (1975);
non-oil exports (including reexports), $497.7 million
(1976 projected); oil exports, $457.9 million (1976 est.)
Imports: $1,337.7 million (1976 est. )
Major trade partners: U.K., U.S., Japan, EC
Aid: received $110 million in bilateral commit-
ments and committed itself $8.5 million to
multilateral agencies in CY74
Budget: (1976) $483 million, 72% of revenues from
oil
Monetary conversion rate: 1 Bahrain dinar=
US$2.52 (since January 1973)
Fiscal year: calendar year','d9ec9bc52f5e7802d271dd5270825894054a2ea974d6c38186aad44bc57bc76e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c82ae1efe8d5836aa094b39bca712e9185cba76dc333e4e7be8a63974b84064e',1977,'BD','Bangladesh','economy',42,'GNP: $6.05 billion est. (FY76 current prices), $75
per capita; real annual per capita growth (FY76),
8.7%
Agriculture: large subsistence farming, heavily
dependent on monsoon rainfall; main crops are jute
and rice; shortages—grain, cotton, and oilseeds
Fishing: catch 247,000 metric tons (1974)
Major industries: jute manufactures, food
processing and cotton textiles
Electric power: 810,000 kW capacity (1975); 1.4
billion kWh produced (1975), 18 kWh per capita
Exports: $356 million (FY76); raw and manu-
factured jute, leather, tea
Imports: $1,290 million (FY76); foodgrains, fuels,
raw cotton, fertilizer, manufactured products
Major trade partners: exports—U.S. 15%, U.S.S.R.
7.4%, U.K. 7.8%; imports—U.S, 25.4%, Canada 7.3%
(FY75)
Aid: economic—FY75 disbursements, $1,015
million of which U.S. provided 25%
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BANGLADESH/ BARBADOS
Budget: (FY75) revenue, $855 million; expendi-
tures, $1,061 million
Monetary conversion rate: 14.9 taka=US$1 (July
- 1976)
Fiscal year: 1 July - 30 June','04f1f38b4e26df1211dc1415b11acfc66ca8087718ed23edfc72e239197e30a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464b4a4c2c7e5f228be8f3fe782a69a33cc4606c47a39523e8ecc9166b7513ad',1977,'BB','Barbados','economy',46,'GDP: $264 million (1974), $1,100 per capita; real
growth rate 1974, —11%
15
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BARBADOS/BELGIUM
Agriculture: main products—sugar, subsistence
foods
Major industries: tourism, sugar milling, manufac-
turing
Electric power: 86,000 kW capacity (1975); 204
million kWh produced (1975), 950 kWh per capita
Exports: $107 million (f.0.b., 1975); sugar and
sugarcane byproducts, clothing
Imports: $217 million (c.if., 1975); foodstuffs,
machinery, manufactured goods
Major trade partners: exports—28% U.K., 14%
U.S,, 28% CARIFTA, 30% other; imports—25%
U.K., 21% U.S., 11% Canada, 18% CARIFTA, 30%
other (1973)
Aid: economic—authorization from U.S. (FY67-
75), $3.6 million; from international organizations
(FY63-75), $15.2 million
Monetary conversion rate: 2 Barbados dol-
lars= US$1 (June 1976)
Fiscal year: 1 April - 81 March','f2b31979c4b75c360b665696d112eb2c0f857965cf773daf6110ebd3a87d5c9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('620f63ae00de63a8589e40650b130d35ca2c4149a0e81f498ea71052a5dde1da',1977,'BE','Belgium','economy',50,'GNP: $59.1 billion (1975, in 1975 prices), $6,040
per capita; 1974—58% consumption, 25% invest-
ment, 15% government, 2% net foreign balance;
1975 real GNP growth rate—1.4%
Agriculture: livestock production predominates;
main crops—grains, beets, potatoes; 80% self-
sufficient in food; caloric intake, 3,230 calories per
day per capita (1969-70)
Fishing: exports $34 million (1975), imports $157
million (1975)
Major industries: engineering and metal products,
processed food and beverages, chemicals, basic
metals, textiles, and petroleum
Shortages: iron ore, nonferrous minerals, petroleum
Crude steel: capacity 14.8 million metric tons;
11.58 million metric tons produced; 1,180 kg per
capita (1975)
Electric power: 10,826,000 kW capacity (1975);
41.1 billion kWh produced (1975), 3,700 kWh per
capita
Exports: (Belgium-Luxembourg Economic Union)
$29.02 billion (f.0.b., 1975); ferrous metals, finished or
semifinished precious stones, textile products
Imports: (Belgium-Luxembourg Economic Union)
$30.5 billion (c.i.f., 1975); nonelectrical machinery,
motor vehicles, textiles, chemicals
Major trade partners: (Belgium-Luxembourg
Economic Union, 1975) EC-nine 70.5% (West
Germany 22%, France 19%, Netherlands 17%, U.K.
6.5%, Italy 4%); U.S. 4%; Communist countries
(U.S.S.R., East Germany, Poland, Czechoslovakia,
Hungary, Romania, Bulgaria) 4%
Aid: economic—received, U.S., $829 million
authorized (FY46-75), $36.3 million in FY74; IBRD,
$57.8 million (1949-75); military—received, $1,275
million authorized (FY46-75); net official economic
aid to less developed areas and multilateral agencies,
$1,365 million (FY60-70), $263.4 million in 1974
Ordinary budget, 1976 (projected): revenue,
$27.4 million, expenditures, $29.0 billion
Monetary conversion rate: (1975 average) 1
franc= US$0.0272
Fiscal year: calendar year','7bee9b8e4fad73a774973db5775b22f21cfc553b83102798df97532f804f7c51','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbae68c2d9ce329dfe1f65c04e0ff91936031c86a324c07b55309cb0a71ecd93',1977,'BZ','Belize','economy',54,'GDP: $87 million (1974), $680 per capita; 78%
private consumption, 17% public consumption, 36%
domestic investment, —31% net foreign balance
(1968); 8.5% real growth rate 1971
Agriculture: main products—sugar, citrus fruits,
corn, molasses, rice, beans, bananas, livestock
products; net importer of food; caloric intake, 2,500
calories per day per capita
Major industries: timber and forest products, food
processing, furniture, rum, soap
Electric power: 14,870 kW capacity (1975); 30
million kWh produced (1975), 220 kWh per capita
Exports: $71.3 million (f.0.b., 1975 est.); sugar,
molasses, clothing, lumber, citrus fruits, fish
Imports: $102 million (cif, 1975 est.); vehicles,
building materials, petroleum, food, textiles,
machinery
Major trade partners: exports—U.S. 80%, U.K.
24%, Mexico 22%, Canada 18%; imports—U.S. 34%,
U.K. 25%, Jamaica 7% (1970)
Aid: economic—U.S. authorizations (FY46-75),
$7.2 million in grants and $0.3 million in loans; from
international organizations (1946-75), $2.0 million
Monetary conversion rate: 2 Belize dollars = US$1
(April 1976)
Fiscal year: calendar year','4ad80455f7dcbbdb6e1bb4859bf0f540659b3c0f6d677ecd6589523798d5cef7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a69d57b7510779a9710ba941f7e02773c6182b870ead1a4ee657aa87451240e7',1977,'BJ','Benin','economy',58,'GNP: $372 million (1975), $120 per capita; no real
growth during 1970-1974
Agriculture: major cash crop is oil palms; peanuts,
cotton, coffee, sheanuts, and tobacco also produced
commercially; main food crops—corn, cassava, yams,
sorghum and millet; livestock, fish
Fishing: catch 32,900 metric tons (1974); exports
600 metric tons, imports 4,300 metric tons (1971)
Major industries: palm oil and palm kernel oil
processing
Electric power: 11,000 kW capacity (1975); 55
million kWh produced (1975), 17 kWh per capita
Exports: $94 million (f.0.b., 1974); palm products
(34%); other agricultural products
Imports: $181 million (c.i.f., 1974); clothing and
other consumer goods, cement, lumber, fuels,
foodstuffs, machinery, and transport equipment
Major trade partners: France, EC, france zone;
preferential tariffs to EC and franc zone countries
Aid: economic (through FY75)—EC, $67.1 million;
U.N., $12.5 million; other international organiza-
tions, $36.2 million; Taiwan, $1 million; U.S. (FY59-
75), $17.1 million; China, $44 million extended
(1972)
Budget: 1975 est.—receipts $73 million, expendi-
tures $77 million
19
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BENIN/BERMUDA
Monetary conversion rate: 248.22 Communaute
Financiere Africaine (CFA) francs =US81 as of August
1976
Fiscal year: calendar year','13acf9e5920a6a8caa3ed2af174df3b8d3e87a726f5d88bdfcd003cae665359e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c20cdf8592b8a5f87262fbf9242ba9fca5aac09724f13197a23e862288efde4',1977,'BM','Bermuda','economy',62,'GNP: $300-$350 million (at market prices, 1974),
$5,000-$6,000 per capita
Agriculture: main products—bananas, vegetables,
Faster lilies, dairy products, citrus fruits
Major industries: tourism, finance
Electric power: 86,200 kW capacity (1975); 300
million kWh produced (1975), 5,330 kWh per capita
Exports: $0.7 million (f.0.b., 1974); mostly
reexports of drugs and bunker fuel
Imports: $154.6 million (f.o.b., 1974); fuel,
foodstuffs, machinery
Major trade partners: 45% U.S., 22% U.K., 9%
Canada (1974)
Monetary conversion rate: 1 Bermuda dol-
lar=US$1
Fiscal year: 1 April - 81 March
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
te
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BERMUDA/BHUTAN','ad13070749e42880007fb2faa215eb02214fb319be4815b1d5444aba6bcb31a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ac21542ff1f27ccc1220ee698718e3df1b16f31242f52baf7f796a4d000e549',1977,'IN','India','economy',67,'GNP: under $100 per capita
Agriculture: rice, barley, wheat, potatoes, fruit
Major industries: handicrafts (particularly textiles)
Electric power: 2,000 kW capacity (1975); 6
million kWh produced (1975), 5 kWh per capita
Exports: about $1 million annually; rice, dolomite,
and handicrafts
Imports: about $1.4 million annually
Major trading partner: India
Aid: economic—India (FY61-72), $180 million
Monetary conversion rate: both ngultrums and
Indian rupees are legal tender; 8.77 ngultrums = 8.77
Indian rupees= US§1 as of October 1975
Fiscal year: 1 April - 31 March
GNP: $2.15 billion (1975, in 1975 dollars), $410 per
capita; 69% private consumption, 11% public
consumption, 16% gross domestic investment, +4%
net foreign balance (1974); real growth rate (1971-75)
average 6.1%; 1975 growth, 6.8%
Agriculture: main crops—potatoes, corn, rice,
sugarcane, yucca, bananas; imports significant
quantities of wheat; caloric intake, 70% of
requirements (1976)
Major industries: mining, smelting, petroleum
refining, food processing, textiles, and clothing
Electric power: 310,000 kw capacity (1975); 980
million kWh produced (1975), 195-kWh per capita
Exports: $460 million (f.0.b., 1975 est); tin,
petroleum, lead, zinc, silver, tungsten, antimony,
bismuth, gold, coffee, sugar, cotton, natural gas
Imports: $515 million (f.0.b., 1975 est.); foodstuffs,
chemicals, capital goods, pharmaceuticals, transpor-
tation
Major trade partners: exports—Western Europe,
20% (of which UK is largest market); Latin America,
40%; U.S., 30%; Eastern Europe, 4.6%; Japan, 4.3%;
imports—U.S., 25%; Western Europe, 19% (of which
West Germany is largest supplier); Japan, 10%; Latin
America, 39.6%; Eastern Europe, 4.5%; Canada,
1.3% (1974)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
i
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BOLIVIA/BOTSWANA
Aid: economic—extensions from U.S. (FY46-75),
$240.4 million in loans, $256.7 million in grants; from
international organizations (FY46-75), $372 million;
from other Western countries (1960-75), $53.8
million; Communist countries (1970-74), $60.2
military—assistance from U.S. (FY52-73), $36 million
Budget: $272 million revenues, $304 million
expenditures (1975)
Monetary conversion rate: 20.3 pesos = US$1
Fiscal year: calendar year
GNP: $85 billion (FY76, in 1975 prices), $140 per
capita; real growth 2.2% (FY70-76), 5% in FY76
95
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
INDIA/INDONESIA
Agriculture: main crops—rice, other cereals, pulses,
oilseeds, cotton, jute, sugarcane, tobacco, tea, and
coffee; must import foodgrains; caloric intake is low
and diet is deficient in protein
Fishing: catch 2.4 million metric tons (FY75);
exports $85 million (FY73), imports $2 million
Major industries: textiles, food processing, steel,
machinery, transportation equipment, cement, jute
manufactures
Crude steel: 7.2 million metric tons produced
(FY75)
Electric power: 21,360,000 kW capacity (1975);
82.2 billion kWh produced (1975), 187 kWh per
capita
Exports: $4.5 billion (f.0.b., FY76); tea, jute
manufactures, iron ore, cotton textiles, leather and
leather products, sugar
Imports: $6.1 billion (c.i.f., FY76); machinery and
transport equipment, petroleum, iron and steel, grains
and flour, fertilizers
Major trade partners: U:S., U.K., U.S.S.R. and
Eastern Europe, Japan, Iran
Budget: (FY77) revenue expenditures $8.5 billion,
capital expenditures $5.8 billion
Monetary conversion rate: 9.0 rupees = US$1
(August 1976)
Fiscal year: fiscal year ends 31 March of stated
year','5251d1ce31f4ffd609b62b2cfdabca0455a11108ee5199943eb9bcf0f0c82ed0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cea57b0756b08e2d46d4e9ebaf752f5d468fca15b14fd4c13b1c6ec451c58b1',1977,'BW','Botswana','economy',73,'GDP: $200 million (1975 est.), about $800 per
capita; growth in current prices about 15% annually
Agriculture: principal crops are corn and sorghum;
livestock raised and exported
Major industries: livestock processing, mining of
diamonds, copper, nickel, coal, asbestos, and
manganese
Electric power: 75,000 kW capacity (1975); 85
million kWh produced (1975), 270 kWh per capita
Exports: $106 million (1975 est.); cattle, animal
products, minerals
Imports: $176 million (1975); foodstuffs, vehicles,
textiles
Major trade partners: South Africa and U.K.
Budget: (1977) revenue $107 million ($78 million
from domestic taxes and $29 million from borrowing
and foreign aid), current expenditures $70 million,
investment expenditures $44 million
Monetary conversion rate: 1 SA Rand=US$1.15 as
of September 1975 (Botswana uses the South African
Rand)
Fiscal year: 1 April - 31 March','d0caca330e1ee50b2aa376559fd1965bbcb545de86f529718266eb545b1ed225','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd60607ca3dc57b96ec07df2ebc62dc0f102c04393a41c3f3194a13246514e85',1977,'BR','Brazil','economy',77,'GNP: $90.0 billion (1975, in 1974 prices), $830 per
capita; 28% gross investment, 79% consumption,
—7% net foreign balance (1975); real growth rate
1975, 4.2%
Agriculture: main products—coffee, rice, beef,
corn, milk, sugarcane, soybeans; nearly self-sufficient;
caloric intake, 2,900 calories per day per capita (1962)
Fishing: catch 604,700 metric tons (1974); exports,
$33.1 million (f.0.b. 1973), imports, $54.3 million
(f.0.b. 1978)
Major industries: textiles and other consumer
goods, chemicals, cement, lumber, steel, motor
vehicles, other metalworking industries
Crude steel: 9.5 million metric tons capacity (1975
est.); 8.3 million metric tons produced (1975); 80 kg
per capita
Electric power: 20,120,000 kW capacity (1975);
78.3 billion kWh produced (1975), 780 kWh per
capita
Exports: $8,655 million (f.0.b., 1975); coffee,
manufactures, iron ore, cotton, soybeans, sugar, wood,
cocoa, beef, shoes
Imports: $13,657 million (c.i.f., 1975); machinery,
chemicals, pharmaceuticals, petroleum, wheat
Major trade partners: exports—15% -U.S., 8%
Japan, 8% West Germany, 6% Netherlands, 4% Italy,
4% U.K.; imports—25% U.S., 11% West Germany,
9% Japan, 4% Italy, 8% U.K. (1975)
Aid: economic—extensions from U.S. (FY46-75),
loans $4.2 billion, grants $685 million; from
international organizations (FY46-75), $4.1 billion;
from other Western countries (1960-71), $617.0
million; from Communist countries (1959-75), $399
million; drawings (1959-75), $139 million
Budget: (1975) revenues $10.5 billion, expenditures
$10.4 billion
Monetary conversion rate: 11.62 cruzeiros = US$1
(October 1976, changes frequently)
Fiscal year: calendar year
GDP: $40 million (1973)
Agriculture: largely dominated by coconut
production with subsistence crops of yams, taro,
bananas; self-sufficient in rice
Electric power: 6,000 kW capacity (1975); 13
million kWh produced (1975), 67 kWh per capita
Exports: $15.5 million (1975); 839% copra, 27%
timber, 23% fish
Imports: $29.2 million (1975)
Major trade partners: exports—EEC excluding
U.K. 42%, Japan 29%; imports—Australia 34%, U.K.
14%, Japan 13% (1975)
26
Approved For Release 2005/04/22
Budget: (1971) revenues $9.8 million, expenditures
$9.9 million
Monetary conversion rate: 1 Australian dol-
lar=US$1.24 (July 1976)
GNP: $460 million (1975 est.), $2,970 per capita
Agriculture: main crops—ruber, rice, pepper, must
import most food
Major industry: crude petroleum, liquefied natural
gas
Electric power: 84,000 kW capacity (1975); 220
million kWh produced (1975), 1,400 kWh per capita
Exports: $1,000 million (f.0.b., 1975); 95% crude
petroleum and liquefied natural gas
Imports: $200 million (c.i.f., 1975); 25% machinery
and transport equipment, 46% manufactured goods,
16% food
Major trade partners: exports of crude petroleum
and liquefied natural gas to Japan; imports from
Japan 30%, U.S. 24%, U.K. 15%, Singapore 9%
Budget: (1976) revenues $640 million, expenditures
$250 million, surplus $390 million; 20% defense
Monetary conversion rate: 2.5 Brunei dollars=
US$1
Fiscal year: calendar year','111c0eaa5d86000d4b6f11bcf6a6d9f097f2bab0295766cf780f252ded82bca6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84dc61932973d729059aa67f331fa67a980dbf7767489b9b51184ba40d0f494a',1977,'BG','Bulgaria','economy',81,'GNP: $23.1 billion, 1975 (at 1975 prices), $2,640
per capita; 1970-75 real-growth rate, 8.9%
Agriculture: mainly self-sufficient; main crops—
grain, vegetables; caloric intake, 3,000 calories per
day per capita (1969/70)
Fishing: catch 115,000 metric tons (1974)
28
Major industries: agricultural processing, machin-
ery, textiles and clothing, mining, ore processing,
timber
Shortages: some raw materials, metal products,
meat and dairy products; fodder
Crude steel: 2.2 million metric tons produced
(1975), 250 kg per capita
Electric power: 7 million kW capacity (1975); 25.2
billion kWh produced (1975), 2,860 kWh per capita
Exports: $4,682 million (f.o.b., 1975); 41%
machinery, equipment, and transportation equip-
ment; 15% fuels, minerals, raw materials, metals, and
other industrial material; 2% agricultural raw
materials; 82% foodstuffs, raw materials for food
industry, and animals; 10% industrial consumer goods
(1975)
Imports: $5,398 million (f.0.b., 1975); 42%
machinery, equipment, and transportation equip-
ment; 40% fuels, minerals, raw materials, metals,
other materials; 7% agricultural raw materials; 6%
foodstuffs and animals; 5% industrial consumer goods
Major trade partners: $10,080 million in 1975;
20% with non-Communist countries, 80% with
Communist countries
Monetary conversion rate: .97 leva=US$1
(September 1976)
Fiscal year: calendar year; economic data reported
for calendar years except for caloric intake, which. is
reported for consumption year 1 July - 30 June
GDP: $3.2 billion (FY75, in current prices), $110
per capita; real growth rate 2.8% (FY75)
Agriculture: accounts for nearly 70% of total
employment and about 27% of GDP; main crops—
paddy, sugarcane, corn, peanuts; almost 100% self-
sufficient; most rice grown in deltaic land
Fishing: catch 485,000 metric tons (1975)
Major industries: agricultural processing; textiles
and footwear; wood and wood products, petroleum
refining
Electric power: 450,000 kW capacity (1975); 760
million kWh produced (1975), 24 kWh per capita
Exports: $176 million (f.0.b., 1975); rice, teak
Imports: $262 million (c.i.f£., 1975); machinery and
transportation equipment, textiles, other manufac-
tured goods
Major trade partners: exports—India, Western
Europe, China, U.K., Japan; imports—Japan,
Western Europe, India, U.K.
Budget: (FY76) $278 million revenues; $4386
million expenditures; $158 million deficit; 80%
military, 70% civilian
Monetary conversion rate: 6.542 kyat=US$1
(official)
Fiscal year: 1 April - 81 March','6986f096346d0496853fb5d4bb9fe7ce6471616ff86a7f8cc184af3a0824b58e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f6a12d1c1ae418e09efdcadbbdb645c91c557ace7d1f935cba4ac816d18644c',1977,'BI','Burundi','economy',86,'GNP: about $340 million (1975), $90 per capita;
2% real growth (1970-74)
Agriculture: major cash crops—coffee, cotton;
main food crops—manioc, yams, corn, sorghums,
bananas, haricot beans; marginally self-sufficient
Industries: light consumer goods such as beverages,
blankets, shoes, soap, assembly of imports
Electric power: 7,000 kw capacity (1975); 25
million kWh produced (1975), 7 kWh per capita
Exports: $46.2 million (f.0.b., 1975); coffee (85%),
tea, cotton, hides, skins
Imports: $47.5 million (c.if., 1975); textiles,
foodstuffs, transport equipment, petroleum products
Major trade partners: U.S., EEC countries
Aid: $40 million all donors (1975 est. ), major donors
EEC, IBRD/IDA, U.N.
Budget: FY75—revenue $39 million, current
expenditure $41 million
Monetary conversion rate: 90 Burundi francs=
US$1 (official)
Fiscal year: calendar year
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BURUNDI/CAMBODIA','04674fd57843f7c49d430e68113d2f4bcbd45f57b6e02dcdf7f0f2ae2f03be6b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6babf415465e61c56ad0e68497e359dd5f2ed5ef955260d2c59ece8b399b3491',1977,'KH','Cambodia','economy',90,'GNP: less than $500 million (1971), probably less
than $75 per capita (1975)
Agriculture: mainly subsistence except for rubber
plantations; main crops—rice, rubber, corn; food
shortages—rice, meat, vegetables, dairy products,
sugar, flour
Major industries: rice milling, fishing, wood and
wood products, textiles
Shortages: fossil fuels
Electric power: 122,000 kW capacity (1975); 250
million kWh produced (1975), 35 kWh per capita
Exports: probably less than $1 million est. (1975);
rubber
Imports: probably less than $25 million (1975);
food, fuel, machinery
Major trade partners: exports—Thailand, China;
imports—China, North Korea
Aid: economic—$906.1 million est. (FY53-75); U.S.
aid, $876.1 million; probably about $25 to $30 million
from China and North Korea; military—U.S.,
$2,228.6 million (FY46-75)
Budget: no budget data available since Com-
munists took over government
Monetary conversion rate: not announced yet by
new Khmer Rouge government
31
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CAMBODIA/CAMEROON
Fiscal year: calendar year','0902fb87092c8e7bb878ff73a78c1fa01691c3cfa273b6d4ce2b9cf95bff4b03','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46008e7a6fa1b1b8ee141b8a337fa2f359e93211c2f08f2a9eba61000038173d',1977,'CA','Canada','economy',96,'GNP: $154.7 billion (1975, in 1975 prices), $6,790
per capita (1975); 59% consumption, 20% investment,
24% government (1975); growth rate 4.3% (1970-75);
constant prices
Agriculture: main products—livestock, grains
(principally wheat), dairy products; food shortages—
fresh fruits and vegetables; caloric intake, 3,180
calories per day per capita (1966-67)
Fishing: catch 7 million metric tons; exports 2
million metric tons (1975)
Major industries: mining, metals, food products,
wood and paper products, transportation equipment,
chemicals
Shortages: rubber, rolled steel, fruits, precision
instruments
Crude steel: 13.0 million metric tons produced
(1975)
Electric power: 59,576,000 million kW capacity
(1975); 272.6 billion kWh produced (1975), 10,000
kWh per capita
Exports: $33,104 million (f.0.b., 1975, Canadian
source); principal items—transportation equipment,
wood and wood products including paper, ferrous and
nonferrous ores, crude petroleum, wheat; Canada is a
major food exporter
Imports: $35,952 million (cif, 1975, Canadian
source); principal items—transportation equipment,
machinery, crude petroleum, communication
equipment, textiles, steel, fabricated metals, office
machines, fruits and vegetables
Major trade partners: 67% U.S., 16% EC, 5%
Japan (1975)
Aid: economic—(received) U.S., $388 million
(FY46-75); gross official aid to less developed
countries and multilateral agencies, $3,688 million
(1960-73), $637 million (1973); military—U.S., $13.1
million (FY49-73), none since 1961
34
Budget: total revenues $30,784 million; current
expenditures $33,534 million; gross capital formation
$1,144 million; budget deficit $3,894 million
(1975) (National Accounts Basis)
Monetary conversion rate: there is no designated
par value for the Canadian dollar, which was allowed
to float freely on the exchanges beginning 1 June
1970; since then the Canadian dollar has moved
between US$0.98-1.04 in value, 1975 average
IC$ = US$0.9830
Fiscal year: 1 April - 31 March
GDP: $33.5 million (1973 est.); $110 per capita
income
Agriculture: main crops—corn, beans, manioc,
sweet potatoes; barely self-sufficient in food
Fishing: catch, 4,400 metric tons (1974);
largely undeveloped but provides major source of
export earnings
Major industries: salt mining
Electric power: 6,000 kW capacity (1975); 7
million kWh produced (1975); 25 kWh per capita
Exports: $2 million (f.0.b., 1973); fish, bananas,
salt
Imports: $34 million (c.i.f., 1973); machinery,
textiles
Major trade partners: Portugal, African neighbors
Aid: Portugal, $20 million (1974), for civil service
salaries, food, medicines; U.S., $5 million (1975), for
food and employment of rural workers
Budget: (est. 1974) $32 million expenditures, $12
million revenues
Monetary conversion rate: 27 escudos=US$1
(September 1975)
Fiscal year: probably calendar year
GDP: $266 million (1974), $150 per capita
Agriculture: commercial—cotton, coffee, peanuts,
sesame, wood; main food crops—manioc, corn,
peanuts, rice, potatoes, beef; requires wheat, flour,
tice, beef, and sugar imports
36
Major industries: sawmills, cotton textile mills,
brewery, diamond mining and splitting
Electric power: 27,000 kW capacity (1975); 65
million kWh produced (1975), 38 kWh per capita
Exports: $73 million (f.0.b., 1975); cotton, coffee,
diamonds, timber
Imports: $98 million (c.i.f., 1975 est.); textiles,
petroleum products, machinery and electrical
equipment, motor vehicles and equipment, chemicals
and pharmaceuticals
Aid: economic (through 1975)—U.S., $10.3
million; EC, $73.8 million; U.N., $11.5 million; other
international organizations, $23.4 million; Com-
munist Countries (1964-75), $7.2 million
Major trade partners: France; preferential tariff
applied to EC countries and franc zone; Yugoslavia,
Japan, U.S.
Budget: 1974 budget estimates—receipt $65.4
million, current expenditure $71.7 million
Monetary conversion rate: 248.22 Communaute
Financiere Africaine francs =US$1 as of August 1976
Fiscal year: calendar year','743e944a62826106425106792112967c42ac4285531d6a9d8fd5048f8aa2d434','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('789e28bf853f1d29df8ca7f825ad3fce8434b357932bbb4420602c4b918c5ffd',1977,'TD','Chad','economy',100,'GDP: $375 million (est. 1974), $90 per capita;
estimated real annual growth rate nearly zero since
1971
Agriculture: commercial—cotton, gum arabic,
livestock, fish; food crops—peanuts, millet, sorghum,
rice, dates, manioc, wheat; imports food
Fishing: catch 115,000 metric tons (1974)
Major industries: agricultural and livestock
processing plants (cotton textile mill, slaughterhouses,
brewery), natron
Electric power: 22,000 kW capacity (1975); 60
million kWh produced (1975), 15 kWh per capita
Exports: $68 million (f.0.b., 1974); cotton 74%
Imports: $114 million (c.i.f,, 1974); cement,
petroleum, foodstuffs, machinery, textiles, and motor
vehicles
Major trade partners: France (about 40% in 1973)
and UDEAC countries; preferential tariffs to EC and
franc zone countries
Aid: major source France, more than $10 million
(1971-73); EDF, more than $15 million (1971-78);
U.S. (FY62-74), $24.9 million; U.S.S.R., $5.0 million
(1968-75); China, $67.6 million (1971-75); military
aid (1954-68)—$5.4 million; from France, $4.1
million, remainder from West Germany and Israel;
more than $10 million annually (est.) in French
military aid (1969-71)
Budget: 1974 ordinary budget—$90 million
Monetary conversion rate: 248.22 Communaute
Financiere Africaine francs= US$1 as of August 1976
(floating)
Fiscal year: calendar year','a8dbe3e5338e39bed386ffce108775a98a564bccff40b88efe9eb0feb7b3359a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f2769e1d37a84b26c19aafdf4ecff9662bd5d4fb45887b2ffc8f73dba546b92',1977,'CL','Chile','economy',104,'GDP: $8.3 billion (1975), $780 per capita; 80.3%
private consumption, 13.4% government consump-
tion; 18.9% gross investment, —7.6% net imports and
factor payments abroad (1972 est.); real growth rate,
1970-75 average annual increase —0.47%
Agriculture: main crops—wheat, other cereals,
potatoes; about 65% self-sufficient; 2,650 calories per
day per capita (1971 est.)
Fishing: catch 1,127,000 metric tons (1974);
exports $49.1 million (1975)
Major industries: copper, nitrates, foodstuffs, fish
processing, textiles and apparel, iron and steel, pulp
and paper
Crude steel: 0.7 million metric tons capacity
(1967); 488,400 metric tons produced (1975), 50 kq
per capita
Electric power: 2,600,000 kW capacity (1975); 9.8
billion kWh produced (1975), 900 kWh per capita
Exports: $1.5 billion (f-0.b., 1975); copper, iron ore,
paper products, nitrates, iodine, and fresh fruit
Imports: $1.8 billion (c.if., 1975); foodstuffs,
petroleum, machinery and equipment, chemicals
Major trade partners: exports—41% 41% EC, 11%
Japan, 8% U.S., 29% LAFTA; imports—17% EC,
29% U.S., 27% LAFTA (1975)
Aid: economic—extensions from U.S. (FY46-73),
$1,484.6 million loans, $224 million grants; from
international organizations (FY46-75), $720 million
(of which IBRD $266 million, IDB $409 million);
from other Western countries (1960-66), $170.6
million; from Communist countries (1967-75), $447.7
million; military (FY53-75)—from U.S., $62 million
in loans, $154 million in grants
Budget: $1.8 billion revenues, $2.3 billion
expenditures (1975)
Monetary conversion rate:
(October 1976), changes frequently
Fiscal year: calendar year
GNP: $299 billion (1975), $320 per capita
Agriculture: main crops—rice, wheat, miscellane-
ous grains, cotton; caloric intake, 2,000 calories per
day per capita (1975); agriculture mainly subsistence;
grain imports 3.3 metric million tons in 1975
Major industries: iron and steel, coal, machine
building, armaments, textiles
Shortages: complex machinery and equipment,
highly skilled scientists and technicians
Crude steel: 26.0 million metric tons produced, 28
kg per capita (1975)
Exports: $6.9 billion (f.0.b., 1975); agricultural
products, minerals and metals, manufactured goods
Imports: $7.4 billion (c.i.f., 1975); grain, chemical
fertilizer, industrial raw materials, machinery and
equipment
Major trade partners: Japan, Hong Kong, West
Germany, Singapore/Malaysia, France, U.S.,
Canada, Australia, U.K., U.S.S.R. (1974)
Monetary conversion rate: about 2 yuan=US$1
(arbitrarily established)
Fiscal year: calendar year','260ce29c5942439336bb245d9074b95958c3371e8de06769a35d290416ecc675','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('440ac85cbaf53283b2450e60425cd778540233037091b7cf3317cfef3a8894c1',1977,'CN','China','economy',108,'GNP: $14.7 billion (1975, in 1975 prices), $920 per
capita; real growth, 8.3% (1970-75 average)
Agriculture: most arable land intensely farmed—
60% cultivated land under irrigation; main crops—
rice, sweet potatoes, sugarcane, bananas, pineapples,
citrus fruits; food shortages—wheat, corn, soybeans
Fishing: catch 779,825 metric tons (1975)
Major industries: textiles, clothing, chemicals,
plywood, electronics, sugar milling, food processing,
cement, ship building
Electric power: 5,500,000 kW capacity (1975);
21.8 billion kWh produced (1975), 1,300 kWh per
capita
Exports: $5,309 million (f.0.b., 1975); 31% textiles,
14% electrical machinery, 6% plywood and wood
products, 7% machinery and metal products, 7%
plastics, 5% sugar
Imports: $5,952 million (c.if.,, 1975); 18%
machinery, 9% electrical machinery, 9% basic metals,
10% crude oil, 10% chemical products
Major trade partners: exports—34% U.S., 13%
Japan; imports—30% Japan, 28% U.S. (1975)
Aid: economic—U.S. (FY46-75), $3.2 billion
committed; IBRD (1964-75), $311 million commit-
ted; Japan (1965-74), $247 million committed; ADB
(1968-75), $93 million committed; military—U.S.
(FY46-75), $4.2 billion committed
Budget: $2.9 billion (FY77)
Monetary conversion rate: NT$38 (New Tai-
wan)=US$1
Fiscal year: 1 July - 30 June','98cdc628de6fa3d63e889d3a9a72312ea235621c5f3870ca3ef1b556bb6d2e1d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c571f18c8db99ab19d428c90638a044f54a9ac7976468d433d37cb7fc5d79bd',1977,'CO','Colombia','economy',112,'GNP: $14.51 billion, est. (1975, in 1975 prices),
$650 per capita; 69% private consumption, 7% public
consumption, 25% gross investment, —1% net foreign
balance (1974); real growth rate (1975), 4.0%; average
real growth rate (1971-75), 5.8%
Agriculture: main crops—coffee, rice, corn,
sugarcane, plantains, bananas, cotton, tobacco;
caloric intake, 2,140 calories per day per capita (1970)
Fishing: catch 90,500 metric tons 1974; exports
$9.9 million (1972), imports $7.1 million (1972)
Major industries: textiles, food processing, clothing
and footwear, beverages, chemicals, and metal
products
Crude steel: 0.37 million metric tons production
(1972), 20 kg per capita
Electric power: 8,300,000 kW capacity (1975); 12
billion kWh produced (1975), 510 kWh per capita
Exports: $1.7 billion (f.0.b., 1975 est.); coffee,
fuel oil, cotton, tobacco, sugar, textiles, cattle and
hides
Imports: $1.3 billion (c.i.f., 1975 est.); transporta-
tion equipment, machinery, industrial metals and raw
materials, chemicals and pharmaceuticals, fuels,
fertilizers, paper and paper products, foodstuffs and
beverages
Major trade partners: exports—36% U.S., 16%
Germany, 7% Spain; imports—40% U.S., 10%
Germany, 8% Japan, 4% Spain (1973)
Aid: economic—extensions from U.S. (FY46-75),
$1,279 million loans, $302 million grants; from
international organizations (FY46-75), $1.8 billion;
from other Western countries (1960-71), $77.6
million; from Communist countries (1968-75) $24.5
million ($2.7 million drawn); military—assistance
from U.S. (FY46-75), $155 million
Budget: (1974) revenues $1.23 billion; expenditures
$1.28 billion
Monetary conversion rate: 34.760 pesos = US$1
(June 1976, changes frequently)
Fiscal year: calendar year','e04327a0ffccb1c391c98b29184d4bba6702257b8194ba65f09fe9819636c3b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99582e4a82f2cf61030edd5514a395e128ed3ae9f3493ba92e0f01c0b818978d',1977,'KM','Comoros','economy',116,'GDP: about $45 million (1973), $160 per capita;
growth probably negligible through 1974
Agriculture: food crops—rice, manioc, potatoes,
fruits, vegetables; export crops—essential oils for
perfumes (mainly ylang-ylang), vanilla, copra, cloves
Exports: $18 million (1974); perfume oils, vanilla,
copra, cloves
Imports: $37 million (1974); foodstuffs, cement,
fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic,
Italy, Kenya, Tanzania and U.S.
Electric power: 1,000 kW capacity (1975); 3
million kWh produced (1975); 10 kWh per capita
Aid: French aid in 1971 was about $2.7 million, or
about 50% of the island''s entire budget; Arab League,
$10 million in 1976
Budget: 1974—revenues, $10.5 million, current
expenditures, $9.4 million, investment expenditures,
$1.3. million
Monetary conversion rate: 216 Communaute
Financiere Africaine (CFA) francs=US$1 as of
January 1975 (floating since February 1973)','724b785595865e54954410671de002f9c58b8c0b2753f32c7e85fdb1cc8dbef9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1860c61066ab25bf1217ca6bcd5f705e001240118073390ee632d5e93f3ef82e',1977,'CG','Congo','economy',120,'GDP: about $600 million (1974 est.), $580 per
capita; real growth rate about 5% per year (1971-74)
Agriculture: cash crops—sugarcane, wood, coffee,
cocoa, palm kernels, peanuts, tobacco; food crops—
root crops, rice, corn, bananas, manioc, fish
Fishing: catch 19,000 metric tons (1974)
Major industries: crude oil, sawmills, brewery,
cigarettes, sugar mill, soap
Electric power: 47,000 kW capacity (1975); 115
million kWh produced (1975), 85 kWh per capita
Exports: $222 million (£.0.b., 1975); oil (68%),
lumber, sugar, tobacco, veneer, and plywood
Imports: $227 million (f.0.b., 1975); machinery,
transport equipment, manufactured consumer goods,
iron and steel, foodstuffs, petroleum products
Major trade partners: France and other EC
countries
Budget: 1973—revenue $82 million, expenditures
$104 million
Monetary conversion rate: 248.22 Communaute
Financiere Africaine francs = US$1 as of August 1976
Fiscal year: calendar year','90d537a4edfe6ca79942e3586c2637bc41306fc8a231c4afd2c799ab2c4e1945','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('391f3cbb3701d267e413c7130757e6a179c8d47c6fea91354c3c9459cbc3caa3',1977,'CK','Cook Islands','economy',124,'GDP: $400 per capita (1973)
Agriculture: export crops include copra, citrus
fruits, pineapple, tomatoes, and bananas, with
subsistence crops of yams and taro
Industry: fruit processing
Electric power: 3,000 kW capacity (1975); 9
million kWh produced (1975), 473 kWh per capita
Exports: $2.7 million (1971); fruit juice, clothing,
citrus fruits
Imports: $5.8 million (1971)
Major trade partners: (1970) exports—98% New
Zealand, imports—76% New Zealand, 7% Japan
Monetary conversion rate: 1 NZ$=US$0.9947
(July 1976)','b2a5a88f48edef0ae276ca7599d79d2661dcd8b47f5b3c1bca9be5b8e68495ef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee417a6aad120ba4451066456b5ab92430acb7d21d1ae836400ea3e493da840c',1977,'CR','Costa Rica','economy',128,'GNP: $1.7 billion (1975, in 1975 dollars), $860 per
capita; 72% private consumption, 17% public
consumption, 23% gross domestic investment, —12%
net foreign balance (1975); real growth rate 1975, 2%;
average growth (1971-74), 6.5%
Agriculture: main products—bananas, coffee,
sugarcane, rice, corn, cocoa, livestock products;
caloric intake, 2,610 calories per day per capita (1966)
Fishing: catch 14,000 metric tons (1974); exports,
$2.2 million (1973), imports, $0.3 million (1973)
Major industries: food processing, textiles and
clothing, construction materials, fertilizer
Electric power: 380,000 kW capacity (1975); 1.5
billion kWh produced (1975), 740 kWh per capita
Exports: $488 million (f.0.b., 1975); coffee,
bananas, beef, sugar, cacao
Imports: $699 million (c.i.f., 1975); manufactured
products, machinery, transportation equipment,
chemicals, fuels, foodstuffs, fertilizer
Major trade partners: exports—32% U.S., 24%
CACM, 13% West Germany; imports—84% U.S.,
16% CACM, 6% West Germany, 10% Japan (1974)
Aid: economic—extensions from U.S, (FY46-75),
$138 million loans, $117 million grants; from
international organizations (FY46-75), $349 million;
from other Western countries (1960-71), $7.7 million;
military—assistance from U.S. (FY60-75) $2.0
million; Communist—$15 million (economic) from
U.S.S.R. (1971)
Monetary conversion rate: 8.57 colones = US$1
Fiscal year: calendar year
GDP: $7.5 billion (1974 est., in 1974 prices), $820
per capita; 60% private consumption, 20% public
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CUBA/CYPRUS
consumption, 20% gross investment; real growth rate
1974, 3%
Agriculture: main crops—sugar, tobacco, coffee,
rice, potatoes, tubers, citrus fruits
Fishing: catch 180,000 metric tons (1975); exports
$75 million (1975), imports $24.4 million (1973)
Major industries: sugar milling, petroleum
refining, food and tobacco processing, textiles,
chemicals, paper and wood products, metals
Shortages: spare parts for transportation and
industrial machinery, consumer goods
Crude steel: 0.35 million metric tons capacity
(planned); 297,500 metric tons produced (1975); 30
kg per capita
Electric power: 1,220,000 kW capacity (1975); 6.5
billion kWh produced (1975), 650 kWh per capita
Exports: $3.3 billion (f.0.b., 1975 est.); sugar,
nickel, tobacco
Imports: $3.8 billion (c.if., 1975 est.); capital
goods, industrial raw materials, food, petroleum
Major trade partners: exports—60% U.S.S.R., 11%
other Communist countries, 8% Japan; imports—41%
U.S.S.R., 18% Japan, 10% other Communist countries
(1975)
Monetary conversion rate: 1 peso=US$1.21
(nominal)
Fiscal year: calendar year','d51b5b2f43be659accf6adb2e66b12f950259a0a0286cf422bdff27d066ec3e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8ee3c6d592c2be71818253118bbc32f0a0e557d16bc040371228cf74b23802e',1977,'CY','Cyprus','economy',132,'GNP: $710.8 million (1975), $1,090 per capita;
1974 real growth rate 2.0%
Agriculture: main crops—vine products, citrus,
potatoes, other vegetables; food shortages—grain,
50
dairy products, meat, fish; caloric intake, 2,460
calories per day per capita (1964-66)
Major industries: mining (cupreous and iron
pyrites, asbestos), manufactures principally for local
consumption—food, beverages, footwear
Shortages: water, petroleum
Electric power: 245,000 kW capacity (1975); 717
million kWh produced (1975), 890 kWh per capita
Exports: $151 million (f.0.b., 1975, converted at
average trade conversion factor of 1 Cyprus
pound = US$2.71); principal items—copper, pyrites,
citrus, raisins, and other agricultural products
Turkish Sector exports: $10 million (f.0.b., 1975,
converted at average conversion factor of 14.465
Turkish lira=US$1); principal items are foodstuffs,
petroleum, raw materials, and machinery
Imports: $308 million (cif, 1975, converted at
average trade conversion factor of 1 Cyprus
pound = US$2.71); principal items—manufactured
goods, machinery and transport equipment,
petroleum products, foods
Turkish Sector imports: $31 million (c.if., 1975,
converted at average trade conversion factor of 14.465
Turkish lira = US$1); principal items are citrus fruits
Major trade partners: (1975) imports—20% U.K.,
7% West Germany, 7% France, 6% Italy, 3% U.S.;
exports—36% U.K., 5% U.S.S.R., 3% Netherlands,
2% West Germany, 2% Greece
Turkish Sector major trade partners: (1975)
imports—64% Turkey, 12% U.K., 6% West Germany,
4% Lebanon; exports—44% Turkey, 33% U.K., 12%','127762c3566d66a1c46f8bc2f06ce08a16fafbd611257e6cc1b07228442056fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59e5f078eed12456dab8ac20659cef3a5a8c90f35cd65a225ae9f582ad43e115',1977,'NL','Netherlands','economy',133,'Aid: economic—U.S., $39.4 million authorized
(FY46-75), U.S., $26 million (1975); IBRD, $70.1
million (FY46-75); U.N. Technical Assistance, $1.7
million (FY46-72); U.N. Special Fund, $9.9 million
(FY46-72); Greece, $35 million (1975)
Turkish Sector aid: Turkey, $16 million
Budget: 1976—revenues $120 million, expenditures
$163 million, deficit $43 million
Turkish Sector budget: revenues $38 million,
expenditures $78 million, deficit $40 million
Monetary conversion rate: 1 Cyprus pound=
US$2.61 (December 1971 through January 1973), 1
Cyprus pound = US$2.531 (trade conversion factor as
of January 1976
Turkish Sector monetary conversion rate:
15.15 Turkish lira =US$1 (trade conversion factor as
of January 1976)
Fiscal year: calendar year
Note: 1974 and 1975 GNP, import, export, and
budget figures are Government of Cyprus figures
which include 100% of island until August 1974 and
60% of island thereafter; the Turkish sector of island
for last 4 months of 1974 is part of Turkish mainland
economy. With the passage of time, some information
on the Turkish sector of the island has become
available.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CYPRUS/CZECHOSLOVAKIA
GNP: $56.6 billion in 1975 (at 1975 prices), $3,820
per capita; 1975 real growth rate 4.9%
Agriculture: diversified agriculture; main crops—
wheat, rye, potatoes, sugar beets; net food importer—
meat, wheat, vegetable oils, fresh fruits and
vegetables; caloric intake, 3,100 calories per day per
capita (1967)
51
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CZECHOSLOVAKIA/ DENMARK
Major industries: machinery, food processing,
metallurgy, textiles, chemicals
Shortages: ores, crude oil
Crude steel: 14.3 million metric tons produced
(1975), 970 kg per capita
Electric power: 14 million kW capacity (1975);
59.2 billion kWh produced (1975), 3,980 kWh per
capita
Exports: $8,360 million (f.0.b., 1975); 47%
machinery, equipment; 31% fuels, raw materials; 5%
foods, food products, and live animals; 17% consumer
goods, excluding foods (1974)
Imports: $9,089 million (f.0.b., 1975); 36%
machinery, equipment; 45% fuels, raw materials; 10%
foods, food products, and live animals; 8% consumer
goods, excluding foods (1974)
Monetary conversion rate: noncommercial 9.27
crowns = US$1, commercial 5.58 crowns = US$1
Fiscal year: calendar year
Note: foreign trade figures were converted at the
rate of 5.58 crowns=US$1
Monetary conversion rate: 1 Gibraltar pound=
US$2.4522 (as of September 28, 1973, floating)
GDP: $740 per capita (1974)
Agriculture: copra, subsistence crops of vegetables,
supplemented by domestic fishing
Industry: phosphate production, expected to cease
in 1978
Electric power: 16,000 kW capacity (1975); 44
million kWh produced (1975), 733 kWh per capita
Exports: $8.6 million (1970 est.); 70% phosphate,
copra
Imports: $3.1 million (1970 est.); foodstuffs, fuel
Budget: (est.) revenue 5.877 million NZ$,
expenditure 4,577 million NZ$
Monetary conversion rate: 0.80 Australian $=
US$1 March 1976
GNP: $80.4 billion (1975, in 1975 prices), $5,900
per capita; 58% consumption, 21% investment, 19%
government; 2% foreign balance; average growth
rate, 4% in constant prices (1966-75)
Agriculture: animal husbandry predominates;
main crops—horticultural crops, grains, potatoes,
sugar beets; food shortages—grains, fats, oils; calorie
intake, 3,186 calories per day per capita (1970-71)
Fishing: catch 310,000 metric tons, $185 million
(1975); exports 213,639 metric tons, imports 106,031
metric tons (1975)
Major industries: food processing, metal and
engineering products, electrical and electronic
machinery and equipment, chemicals, petroleum
products, and natural gas
Shortages: crude petroleum, raw cotton, base
metals and ores, pulp, pulpwood, lumber, feedgrains,
and oilseeds
Crude steel: 6.1 million metric ton capacity; 4.8
million metric tons produced (1975), 350 kg per capita
Electric power: 16,491,000 kW capacity (1975);
54.8 billion kWh produced (1975), 4,200 kWh per
capita
Exports: $35,002 million (f.0.b., 1975); foodstuffs,
machinery, chemicals, petroleum products, natural
gas, textiles
Imports: $34,522 million (c.i.f., 1975); machinery,
transportation equipment, crude petroleum, food-
stuffs, chemicals, raw cotton, base metals and ores,
pulp
Major trade partners: (1975) 68% EC, 28% West
Germany, 18% Belgium-Luxembourg, 6% U.S.
Aid: economic—U.S., $1,400 million authorized
(FY46-75); IBRD, $236 million authorized (FY46-74),
none since 1958; military-—U.S., $1,284 million
authorized (FY49-75), none since FY65; net official
aid delivered to less developed areas and multilateral
agencies, $3.6 billion (FY62-75), $600 million (1975)
Budget: (1976) revenues $24.8 billion, expenditures
$30.8 billion, deficit $6.0 billion
Monetary conversion rate: 2.5292 guilders=
US$1, average 1975, floating
Fiscal year: calendar year
GNP; $280 million (1975 est.), $1,150 per capita;
real growth rate, —1% (est.)
Agriculture: little production
Major industries: petroleum refining on Curacao
and Aruba; tourism on Curacao, Aruba, and St.
Martin; light manufacturing on Curacao and Aruba
Electric power: 295,000 kW capacity (1975); 1.7
billion kWh produced (1975), 6,700 kWh per capita
Exports: $3,230 million (f.0.b., 1974); petroleum
products, phosphate
Imports: $3,601 million (cif, 1974); crude
petroleum, food manufactures
Major trade partners: exports—64% U.S., 7% EC,
5% Canada; imports—61% Venezuela, 12% U.S., 6%
Netherlands (1972)
Budget: (1972) public sector revenues, $177
million; public sector expenditures, $188 million
Monetary conversion rate: 1.8 Netherlands
Antillean florins (NAF)=US$1, official
Fiscal year: calendar year','25c356aab245da9861937e114533526ac9f5f2540053f2eb6b13bddd5dc95b0f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc4ed7bc9e3bcc9121d713f36d3084dfce1fcff618a1d13b5283c38f447470c1',1977,'DK','Denmark','economy',140,'GNP: $32.8 billion (1975), $6,470 per capita; 54%
private consumption, 26% investment, 20% govern-
ment; 1975 growth rate —2.5%, constant prices
Agriculture: highly intensive, specializes in
dairying and animal husbandry; main crops—cereals,
root crops; food imports—oilseeds, grain, feedstuffs;
caloric intake, 3,180 calories per day per capita (1968-
69)
Fishing: catch 1.73 million metric tons, exports
$427.7 million (1975)
Major industries: food processing, machinery and
equipment, textiles and clothing, chemical products,
electronics, transport equipment, metal products,
brick and mortar, furniture and other wood products
Crude steel: 564,000 metric tons produced (1975),
110 kg per capita
Electric power: 5,969,000 kW capacity (1975);
18.7 billion kWh produced (1975), 3,000 kWh per
capita
Exports: $8.712 million (f.0.b., 1975); principal
items—meat, dairy products, industrial machinery
and equipment, textiles and clothing, chemical
Approved For Release 2005/04/22
products, transport equipment, fish, furs, and
furniture
Imports: $10,368 million (c.i.f., 1975); principal
items—industrial machinery, transport equipment,
petroleum, textile fibers and yarns, iron and steel
products, chemicals, grain and feedstuffs, wood and
paper
Major trade partners: 45.4% EC-nine (16.8% West
Germany, 14.2% U.K.); 14.6% Sweden; 5.6% U.S.;
4.3% Communist countries (1975)
Aid: economic—U.S., $360 million authorized
FY46-75; IBRD, $85.2 million through 1975, none
since 1964; net official economic aid given to less
developed areas and multilateral agencies, $250.5
million (1960-70), $76.5 million (1971), $98.3 million
(1972), $131.6 million (1973), $170.9 million (1974);
military—U.S., $640 million (FY49-75)
Budget: (1976) expenditures $13.75 billion,
Premier
Monetary conversion rate: 1 Kroner = US$0.174,
1975, average exchange rate
Fiscal year: 1 April - 31 March
Government budget: Colony—revenues, $1.0
million (FY68); expenditures, $1.1 million (FY68)
Agriculture: Colony—predominantly sheep fa-
rming; dependencies—whaling and sealing
Major industries: Colony—wool processing;
dependencies—whale and seal processing
Electric power: 1,250 kW capacity (1975); 2.3
million kWh produced (1975), 1,100 kWh per capita
Exports: Colony—$2.28 million (1969); wool, hides
and skins, and other; dependencies—no exports in
1968 or 1969
Imports: Colony—$1.22 million (1969); food,
clothing, fuels, and machinery; dependencies—
$8,368 (1969); mineral fuels and lubricants, food, and
machinery
Major trade partners: nearly all exports to the
U.K., also some to the Netherlands and to Japan;
imports from Curacao, Japan, and the U.K.
Monetary conversion rate: 1 Falkland Island
pound = US$2.60','364608690c398d848dab2427aca66c2d298dac6e9e8ce63c649d3e6cddf5dabe','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('102604cbd9e39e16a43d360b75256339dbe59acbcee15e2e8169086da94d9f9f',1977,'DM','Dominica','economy',144,'GDP: $21.0 million (1971 est.), $270 per capita;
8.8% increase in 1971, including price changes
Agricultural products: bananas, citrus, coconuts,
cocoa
Major industries: agricultural processing, tourism
Electric power: 2,000 kW capacity (1975); 7
million kWh produced (1975), 100 kWh per capita
Exports: $12 million (f£.0.b., 1975); bananas, lime
juice and oil, cocoa, reexports
Imports: $22 million (c.i.f., 1975); machinery and
equipment, foodstuffs, manufactured articles, cement
Major trade partners: 47% U.K., 15% Com-
monwealth Caribbean countries, 7% U.S., 6%
Canada (1975)
Monetary conversion rate: 2.07 East Caribbean
dollars = US$1 (May 1975), now floating with pound
sterling','ed16d04dadade6603b8695763bbd0b95ef6a61731873db587188e0983c5ae2cf','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0e977b855b428ca5d623a694cc62f4c5c96d995bf7467ee846c19f072a5f536',1977,'DO','Dominican Republic','economy',148,'GNP: $3.9 billion (1975), $830 per capita; real
growth rate 1975, 4.8%
Agriculture: main crops—sugarcane, coffee, cocoa,
tobacco, rice, corn; imports rice; caloric intake, 2,200
calories per day per capita (1966)
Major industries: sugar processing, nickel mining,
bauxite mining, gold mining, textiles, cement
Electric power: 430,000 kW capacity (1975); 1.5
billion kWh produced (1975), 320 kWh per capita
Exports: $894 million (f.0.b., 1975); sugar, nickel,
coffee, tobacco, cocoa, bauxite
Imports: $950 million (cif, 1975); foodstuffs,
petroleum, industrial raw materials, capital
equipment
Major trade partners: exports—71% U.S. (1975);
imports—58% U.S. (1975)
Aid: economic—U.S. authorizations (FY46-75),
$235 million in grants, $297 million in loans; from
international organizations (FY46-75), $285 million;
military—assistance from U.S. (FY58-75), $38
million, mostly grant
Monetary conversion rate: 1 peso=US5$1
Fiscal year: calendar year','4819c84e56bcd6622acbc2daf9e68cf161f88e326ed8426a2284aee41690da81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('419b65fb4329a954652bc17b9a8c8bb9acaeeaa2dc8c78a5dcc523e0e6ee85e5',1977,'EC','Ecuador','economy',152,'GNP: $4.3 billion (est. 1975), $640per capita; 67%
private consumption, 11% public consumption, 22%
gross investment (1974); average annual real growth
rate 1973-75, 9.6%
Agriculture: main crops—bananas, coffee, cocoa,
sugarcane, cotton, corn, potatoes, rice; caloric intake,
1,970 calories per day per capita (1970)
Fishing: catch 105,200 metric tons (1974); exports
$43 million (1975), imports negligible
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ECUADOR/EGYPT
Major industries: food processing, textiles,
chemicals, fishing, petroleum
Electric power: 400,000 kW capacity (1975); 1.5
billion kWh produced (1975), 190 kWh per capita
Exports: $1.0 billion (f.0.b., 1975); petroleum,
bananas, coffee, cocoa, sugar, fish products
Imports: $1.0 billion (f.0.b., 1975); agricultural
and industrial machinery, wheat, petroleum products,
chemical products, transportation and communica-
tion equipment
Major trade partners: exports—41% U.S., 18%
LAFTA, 11% EC; imports—37% U.S., 23% EC, 14%
Japan (1974)
Aid: economic—extensions from U.S. (FY46-75),
$156 million loans, $133 million grants; from
international organizations (FY46-75), $439 million;
from Communist countries (1967-75), $19.4 million
loans; military—assistance from U.S. (FY49-75), $70
million
Budget: $695 million, 1976
Monetary conversion rate: 25 sucres = US$1
Fiscal year: calendar year','7edf05442ab9f5da5c4796ee89810de62d899ae18e72e89f0403a668e6614b69','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a7023c64e575ed958053125c98827d1e824ed608969e485f3e1145c20dd6039',1977,'EG','Egypt','economy',156,'GNP: $11.2 billion (1975, in current prices), $3800
per capita; inter war annual growth rate of 1% or less
accelerated to 4%-5% since 1973
Agriculture: main cash crop—cotton; other
crops—rice, rice, onions, beans, citrus fruit, wheat,
corn, barley; not self-sufficient in food, but
agriculture a net earner of foreign exchange
Major industries: textiles, food processing,
chemicals, petroleum, construction, cement
Electric power: 4,800,000 kW capacity (1975); 8.5
billion kWh produced (1975), 225 kWh per capita
Monetary conversion rate: official rate—1
Egyptian pound=US$2.54 (selling rate); 0.394
Egyptian pound = US$] (selling rate); parallel market
rate—I Egyptian pound=US$1.55, 0.645 Egyptian
pound = US$1
Fiscal year: calendar year, beginning in 1978','a5fbcc585b33862ffda5428e4d1ae986bf8ca7b6136d7460cc4fcde3eeaa630b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4d22fb770e4ce2201954a56fc0c609ce4ac27f69c3c95140b2e9485b2c300aa',1977,'SV','El Salvador','economy',160,'GNP: $1.6 billion (1974), $410 per capita; 76%
private consumption, 11% government consumption,
18% domestic investment, —8% net foreign balance
(1974); real growth rate, 3.5% (1975)
Agriculture: main crops—coffee, cotton, corn,
sugar, rice, beans; caloric intake, 2,000 calories per
day per capita (1963-64)
Fishing: catch 15,000 metric tons (1974); exports
$6.0 million (1971), imports $0.5 million (1972)
Major industries: food processing, textiles,
clothing, petroleum products
Electric power: 280,000 kW capacity (1975); 1
billion kWh produced (1975), 280 kWh per capita
Exports: $517 million (f.0.b., 1975); coffee, cotton,
sugar
Imports: $554 million (f.0.b., 1975); machinery,
automotive vehicles, petroleum, food-stuffs, fertilizer
Major trade partners: exports—33% U.S., 32%
CACM, 18% EC, 10% Japan (1973); imports—30%
U.S., 20% CACM, 20% EC, 7% Japan (1974)
Aid: economic—from U.S. (FY46-75), $172.2
million loans, $74.4 million grants, from international
organizations (FY46-75), $287 million; from other
Western countries (1960-71) $9.8 million; military—
assistance from U.S. (FY53-75), $15 million
Budget: (1976) $338 million
Monetary conversion rate: 2.5 colones=US$1
(official)
Fiscal year: calendar year','871bfb789b39fd3da006d5373922cb3cb2c795dbb7401693ac885851f3f63b95','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8088efe9a15d92ba37c3ad5cfcadefaa1fb36a5cd17ac12a793780ec3943edd5',1977,'GQ','Equatorial Guinea','economy',164,'GNP: $70 million (1972); $240 per capita
Agriculture: major cash crops—Rio Muni, timber,
coffee; Fernando Po, cocoa; main food products—
rice, yams, cassava, bananas, oil palm nuts, manioc,
and livestock
Fishing: catch 4,000 metric tons (1974)
Major industries: fishing, sawmilling
Electric power: 5,000 kW capacity (1975); 17
million kWh produced (1975), 53 kWh per capita
Exports: $19 million (1973); cocoa, coffee, and
wood
Imports: $21 million (1973); foodstuffs, chemicals
and chemical products, textiles
Major trade partner: Spain
Aid: Spain, $14.0 million (1969); Libya, $1 million
(1971); China $24 million extended (1971)
Budget: (1973) receipts $9 million, expenditures
$12 million
Monetary conversion rate: 64.47 Guinean
pesetas = US$1 (official)','dfd11ccded6b54c59a03c5bb7096e83306b752f2e5be931afe124f3110a8671f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47b2bfd3050b0a029e1363e98192a320367db1eb59209c0810cff40288cd506f',1977,'ET','Ethiopia','economy',168,'GDP: $2,680 million (1974), $100 per capita;
average annual real growth rate 4% (1967-72), zero
(1974)
Agriculture: main crops—coffee, teff, durra,
barley, wheat, corn, sugarcane, cotton, pulses,
oilseeds; livestock
Major industries: cement, sugar refining, cotton
textiles, food processing, oil refinery
Electric power: 297,000 kw capacity (1975); 490
million kWh produced (1975), 17 kWh per capita
Exports: $239 million (f.0.b., 1975); coffee 33%,
oilseeds 18%, pulses 14%, hides and skins 7%; $7.3
million to Communist countries (1975)
Imports: $310 million (cif, 1975); petroleum
products 22%, chemicals 15%, machinery including
aircraft 12%, road motor vehicles 12%; $16.9 million
from Communist Countries (1975)
Major trade partners: imports—Saudi Arabia,
Japan, Italy, West Germany, Iran, U.K., and U.S.;
exports—U.S., Saudi Arabia, FTAI, West Germany,
Egypt, Japan
Monetary conversion rate: 2.09 Ethiopian
dollars = US$1
Fiscal year: 8 July - 7 July','38160d5b454b0af7b390b6237cecf85e575ad1c1e4c0c6fe93f9655380d5b082','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fb946c6af95aecb11c4688171b46036103280a948c28b8de575e01b43ea4d37',1977,'FO','Faroe Islands','economy',172,'GDP: $108.3 million (1972), about $2,760 per
capita
Agriculture: sheep and cattle grazing
Fishing: catch 168,521 metric tons (1975); exports,
$65.0 million (1975)
Major industry: fishing
Electric power: 28,500 kW capacity (1975); 88
million kWh produced (1975), 2,000 kWh per capita
Exports: $80.8 million (f.0.b., 1975); fish and fish
products
Imports: $113.3 million (cif, 1975); machinery
and transport equipment, petroleum and petroleum
products, food products
Major trade partners: 46.6% Denmark, 12.8%
Norway, 8.0% U.K., 6.2% U.S. (1975)
Budget: (FY73) expenditures $21.4 million,
revenues $22.7 million
Monetary conversion rate: 1 Danish Kroner=
US$$0.174 (1975)
Fiscal year: 1 April - 31 March','0aaa539eda20bcfb2c512cef4b0c44c87a566e7de412a51bb34315d524c29aa8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('081608516edddb41ac68f35ceec8b8a07a6016193e4c42c1cbb35dd748792741',1977,'FJ','Fiji','economy',176,'GNP: $644 million (1975), $1,130 per capita; 5.8%
real growth rate (1971-75)
Agriculture: main crops—sugar, coconut products,
bananas, rice; major deficiency, grains
Major industries: sugar processing, tourism
Electric power: 90,000 kW capacity (1975); 250
million kWh produced (1975), 485 kWh per capita
Exports: $154 million (f.0.b., 1974, including
reexports); 70% sugar, 11% coconut oil, 9% gold
Imports: $271 million (c.i.f., 1974); 20%
manufactured goods, 19% food, 16% machinery
(1974)
Major trade partners: exports—38% U.K., 31%
U.S., 11% Australia; imports—30% Australia, 18%
Japan, 11% New Zealand, 4% U.S. (1974)
Aid: disbursed 1968—Australia $1.5 million, U.S.
$0.6 million, U.K. $4.2 million
Budget: (FY75 est.) revenues $102 million,
expenditures $102 million
Monetary conversion rate: 1 Fijian dol-
lar = US$1.1122 (June 1976)
Fiscal year: calendar year','8e2b3e05bd017a4a9c6098991215f2cf986073fd112fe287c53744edc0ef49e3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f48b6defcbdf73090cd6fe9bfa56f7a647e4c38fda5c78f84d8763a6a16e9b76',1977,'FI','Finland','economy',180,'GNP: $26 billion (1975), $5,530 per capita; 49.0%
consumption, 29.0% investment, 30.0% government,
—8% net exports of goods and services; 1975 growth
rate — 1.0%, constant prices
Agriculture: animal husbandry, especially
dairying, predominates; forestry important secondary
occupation for rural population; main crops—cereals,
sugar beets, potatoes; 85% self-sufficient; shortages—
food and fodder grains; caloric intake 2,940 calories
per day per capita (1970-71)
Major industries: include metal manufacturing
and shipbuilding, forestry and wood processing (pulp,
paper), copper refining
Shortages: fossil fuels; industrial raw materials,
except wood, and iron ore
Crude steel: 1.6 million metric tons produced
(1975), 840 kg per capita
Electric power: 7,342,000 kW capacity (1975);
26.5 billion kWh produced (1975), 6,300 kWh per
capita
Exports: $5.5 billion (f.0.b., 1975); timber, paper
and pulp, ships, machinery, iron and steel, clothing
and footwear
Imports: $7.6 billion (c.i-f., 1975); foodstuffs,
petroleum and petroleum products, chemicals,
66
transport equipment, iron and_ steel, machinery,
textile yarn and fabrics
Major trade partners: (1975) 84% EC-nine (12%
West Germany, 10% U.K.); 16% Sweden; 16%
U.S.S.R.; 5% U.S.
Aid: U.S. $203 million authorized FY46-75;
IBRD—$316 million authorized through FY46-75,
$20 million in 1975; Finnish foreign aid programs
have amounted to $23 million 1961-69, $15,000 in
1970
Budget: (1975) expenditures $6.2 billion, revenues
$6.6 billion
Monetary conversion rate: new markka (Fmk)
3.69 = US$1 (1975 trade conversion factor, IMF )
Fiscal year: calendar year','3c4038cfdeb5ee95f5ebf21610560afb41159e12d27a4a083bd0ef993f6c85d7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53ae3a1cb64c9828caf327d9a8484800b17f0b96f0ed158b6d2d98539c9306d4',1977,'FR','France','economy',184,'GNP: $336 billion (1975 est.), $6,340 per capita;
63.9% private consumption, 22.9% investment
(including government), 13.2% government con-
sumption; 1975 real growth rate —2.5%, average
annual growth rate 5.2% (1965-75)
Agriculture: Western Europes foremost producer;
main products—beef, cereals, sugar beets, potatoes,
wine grapes; self-sufficient for most temperate zone
foodstuffs; food shortages—fats and oils, tropical
produce; caloric intake, 3,270 calories per day per
capita (1969-70)
Fishing: catch 808,000 metric tons (1974); exports
$110 million, imports $405 million (1974)
Major industries: steel, machinery and equipment,
textiles and clothing, chemicals, food processing,
metallurgy, aircraft
Shortages: crude oil, textile fibers, most nonferrous
ores, coking coal, fats and oils
Crude steel: 21.6 million metric tons produced
(1975), 410 kg per capita
Electric power: 46,300,000 kW capacity (1975);
67
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FRANCE/FRENCH GUIANA
178.4 billion kWh produced (1975), 3,300 kWh per
capita
Exports: $53.0 billion (f.0.b., 1975); principal
items—machinery and_ transportation equipment,
foodstuffs, agricultural products, iron and _ steel
products, textiles and clothing, chemicals
Imports: $51.7 billion (cif, 1975); principal
items—crude petroleum, machinery and equipment,
chemicals, iron and steel products, footstuffs,
agricultural products
Major trade partners: 18% West Germany; 10%
Belgium-Luxembourg; 9% Italy; 6% U.S.; 6%
Netherlands; 6% U.K.; 4% Eastern Europe; 2%
U.S.S.R.; 4% France Zone
Aid: economic (received)—U.S., $5,363 million
authorized (FY46-75), $44 million in FY73; mili-
tary—U.S., $4,549 million authorized (FY46-75); net
official economic aid to less developed areas and
multilateral agencies—$8,400 million (FY60-70),
$1,125 million in 1971, $457 million in 1974
Budget: (1975) expenditures 280.0 billion francs,
revenues 242.6 billion francs, deficit 37.4 billion
francs
Monetary conversion rate: 1 franc=US$0.2333
(1975 average)
Fiscal year: calendar year
Aid: economic—no Communist country assistance;
U.S. aid extended $212.5 million (FY49-75);
international organizations $22 million; military—
arms obtained by cash purchase; chief suppliers
France, U.S.S.R., Czechoslovakia; U.S. suspended
since September 1969
Monetary conversion rate:
US$3.38
Fiscal year: 1 January - 31 December (beginning
1974)','13f8c2d17e21eee9805dd0efc3ae1817439bacf88c5656201a6ff03afc55fd82','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a048876b49fa01346164c1fdd211b1c636559db5908a98b9a58e9ab9af6dd186',1977,'GF','French Guiana','economy',188,'GNP: $40 million (at market prices, 1970), $800 per
capita
Agriculture: main crops—rice, corn, manioc,
cocoa, bananas, sugarcane
Fishing: catch 972 metric tons (1974); exports $3.7
million; imports $2.2 million (1971)
Major industries: timber, rum, gold mining,
production of rosewood essence, and space center
Electric power: 29,000 kW capacity (1975); 60
million kWh produced (1975), 1,100 kWh per capita
Exports: $5 million (f.0.b., 1973); shrimp, timber,
rum, rosewood essence
Imports: $56 million (c.i.f., 1973); food (grains,
processed meat), other consumer goods, producer
goods and petroleum
Major trade partners: exports—78% U.S, 11%
France, 5% Martinique; imports—49% France, 10%
U.S., 3% Trinidad and Tobago (1969)
Monetary conversion rate: 4.44 French francs=
US$1 (1976)
Fiscal year: calendar year','c0428c8d6064411ae7e4dd24e6508857ade5967324676a47209589b4e929515d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ba1c5a7b10b5473ad6f57bf1a2aef7838d889b81dd97f23bff080cf34d05f6',1977,'PF','French Polynesia','economy',192,'GDP: $259 million (1970) $1,960 per capita (1971)
Agriculture: coconut main crop
Major industries: maintenance of French nuclear
test base, tourism
Electric power: 36,000 kW capacity (1975); 95
million kWh produced (1975), 592 kWh per capita
Exports: $19 million (1978); principal products—
coconut products (79%), mother-of-pearl (14%)
(1971)
Imports: $211 million (1973)
Major trade partners: imports—59% France, 14%
U.S.; exports—86% France
Aid: France $16 million (1973)
Monetary conversion rate: 100 CFP = 1NZ$ (1971)
Gross territorial product: $65 million (1972)
Agriculture: livestock; desert conditions limit
commercial crops to about 15 acres, including fruits
and vegetables
Industry: ship repairs and services of port and
railroad
Electric power: 23,500 kW capacity (1975); 55
million kWh produced (1975), 440 kWh per capita
Imports: $74 million (1973); almost all domes-
tically needed goods
Exports: $20 million, including transit trade
(1973); hides and skins, and transit of coffee
Aid: $2.4 million in 1967 from France
Monetary conversion rate: 177 Djibouti francs=
US$1
Fiscal year: probably same as that for France
(calendar year)
GNP: $193 million, $1,800 per capita (1971 est.)
Agriculture: large areas devoted to cattle grazing;
major products—coffee and vegetables; 60% self
sufficient in beef; must import grains and vegetables
Industry: mining of nickel
Electric power: 320,000 kW capacity (1975); 1.7
billion kWh produced (1975), 13,236 kWh per capita
Exports: $289 million (f.0.b., 1975); 99% nickel
Imports: $348 million (c.if., 1975); machinery,
transport equipment, food
Major trade partners: (1972) exports—55%
France, 24% Japan, 11% U.S.; imports—52% France,
13% Australia, 12% rest of EEC
Monetary conversion rate: 86 CFP francs=US$1
(1972)
Agriculture: export crops of copra, cocoa, coffee,
some livestock and fish production; subsistence crops
of copra, taro, yams
Electric power: 4,000 kW capacity (1975); 12
million kWh produced (1975), 124 kWh per capita
Exports: $27 million (1974); 24% copra, 59%
frozen fish
Imports: $44 million (1974)
Monetary conversion rate: 1 pound=US$2.37
(official currency), 0.74 Australian $=US$1, 86
Colonial Franc Pacifique (CFP) =US$1 (1972)','6acb7ee8629289a7f4c7957d067f2429497ce5ca4e5b29bad7220ada2f462802','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33dff56d41691d997e94d36cae108555b4365287bb7b664c83d7a378a24d1351',1977,'GA','Gabon','economy',196,'GDP: $1,389 million (1974 est.), $2,600 per capita;
.61% growth (1973-74)
Agriculture: commercial—cocoa, coffee, wood,
palm oil, rice; main food crops—bananas, manioc,
peanuts, root crops; imports food
Fishing: catch 4,000 metric tons (1974)
Major industries: petroleum production, sawmills,
petroleum refinery, natural gas, agricultural
processing; mining of increasing importance; major
minerals—manganese, uranium, gold, and iron
Electric power: 85,000 kW capacity (1975); 215
million kWh produced (1975), 375 kWh per capita
Exports: $1.2 billion (f.0.b., 1975); crude
petroleum, wood and wood products, minerals
(manganese, uranium concentrates, gold)
Imports: $727 million (f.0.b., 1975); excluding
UDEAC trade; mining, roadbuilding machinery,
electrical equipment, transport vehicles, foodstuffs,
textiles
Major trade partners: France, U.S., West
Germany, and Curacao; preferential tariffs to EC and
franc zone
Budget: 1975 est.—receipts $630 million, current
expenditures $184 million, investment expenditures
$446 million
Monetary conversion rate: 248.22 Communaute
Financiere Africaine francs=US$1 as of August 1976
Fiscal year: calendar year
GDP: $104 million (FY75 est.), about $200 per
capita
Agriculture: main crops—peanuts, rice, palm
kernels
Fishing: catch 6,000 metric tons (1974); exports
956,000 (1974)
Major industry: peanut processing
Electric power: 10,000 kW capacity (1975); 16
million kWh produced (1975), 30 kWh per capita
Exports: $48 million (FY75); peanuts and peanut
products 90% to 95%, palm kernels
Imports: $51 million (FY75); textiles, foodstuffs,
tobacco, machinery, petroleum products
Major trade partners: exports—U.K. and France;
imports—U.K. and Japan
Aid: economic—U.K. (1968-71), about $8 million
commitment; U.S. (FY56-75), $9.0 million; other
international organizations (FY62-75), $10.8 million
Budget: (FY75 est.) current expenditures $13
million, receipts $17 million; development expendi-
tures $6.7 million, development receipts $7.2 million
Monetary conversion rate: 1 Dalasi = US$0.45
(August 1976)
Fiscal year: 1 July - 80 June
GNP: $70.2 billion in 1975 (1975 prices), $4,170 per
capita; 1975 growth rate 4.9%
Agriculture: food deficit area; main crops—
potatoes, rye, wheat, barley, oats, industrial crops;
shortages in grain, vegetables, vegetable oil, beef;
caloric intake, 3,000 calories per day per capita (1970-
71)
Fish catch: 827,000 metric tons (1975)
Major industries: metal fabrication, chemicals,
light industry, brown coal, and shipbuilding
Shortages: coking coal, coke, crude oil, rolled steel
products, nonferrous metals
Crude steel: 6.5 million metric tons produced
(1975), approx. 880 kg per capita
Electric power: 17,100,000 kW capacity (1975);
84.5 billion kWh produced (1975), 5,010 kWh per
capita
Exports: $10,088 million (f.0.b. delivering country,
1975)
Imports: $11,290 million (f.0.b. delivering country,
1975)
Major trade partners: $21,378 million (1975); 36%
U.S.S.R., 834% other Communist countries, 30% non-
Communist countries
Monetary conversion rate: 3.48 DME=US$1 for
trade data (1975 rate)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for the consumption year 1 July - 30
June
GNP: $423 billion (1975), $6,810 per capita
(including West Berlin) (1975); 56% consumption,
21% investment, 21% government consumption (does
not include total government spending); net foreign
balance 2%; average annual growth rate 1965-75,
4.3% in constant 1962 prices
Agriculture: main crops—grains, potatoes, sugar
beets; 75% self-sufficient; food shortages—fats and
oils, pulses, tropical products; caloric intake, 2,984
calories per day per capita (1973-74)
Fishing: catch 484,037 metric tons, $167 million
(1975); exports $117 million, imports $347 million
(1975)
75
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GERMANY, FEDERAL REP. OF/GHANA
Major industries: among world’s largest producers
of iron, steel, coal, cement, chemicals, machinery,
ships, vehicles
Shortages: fats and oils, sugar, cotton, wool,
tubber, petroleum, iron ore, bauxite, nonferrous
metals, sulfur
Crude steel: 60.6 million metric tons capacity; 40.4
million metric tons produced (1975); 650 kg per capita
Electric power: 75,766,000 kW capacity (1975);
301.5 billion kWh produced (1975), 4,800 kWh per
capita
Exports: $90 billion (f.0.b., 1975); manufactures
90.7% (machines and machine tools, chemicals, motor
vehicles, iron and steel products), agricultural
products 4.1%, fuels 3.1%, raw materials 2.1%
Imports: $75 billion (c.i.f., 1975); manufactures
58.2%, fuels 17.6%, agricultural products 13.8%, raw
materials 10.4%
Major trade partners: EC 46% (France 12%,
Netherlands 12%, Belgium-Luxembourg 8%, Italy
8%); other Europe 17%; U.S. 7%; OPEC 9%;
Communist economic 6%
Aid: economic—U.S. $4,212 million authorized
(FY46-75); $16 million authorized (FY73); military—
U.S., $939 million authorized (FY46-73), none since
FY64; net official aid flows to less developed countries
and multilateral agencies (1962-74)—$9,394 million,
$1,526 million (1974)
Budget: (1975) expenditures $61 billion, revenues
$48.8 billion, deficit $12.2 billion
Monetary conversion rate: DM 2.46 (West
German marks) = US$1 (1975 average)
Fiscal year: calendar year','70a1b2084d759d9ec5410716c1aac562007d34845e889d63c3bc05cb0403cef6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a934be2d2a70f9cc9d350f1d179ed3b66c2048b49585a5018e96073ea004ba74',1977,'GH','Ghana','economy',200,'GNP: $3.7 billion (1974) at current prices, about
$390 per capita; real growth rate 2% (1970-74)
Agriculture: main crop—cocoa; other crops
include root crops, corn, sorghum and millet, peanuts;
not self-sufficient, but can become so
Fishing: catch 223,500 metric tons (1974)
Major industries: mining, lumbering, light
manufacturing, fishing, aluminum
Electric power: 976,000 kW capacity (1975); 3.6
billion kWh produced (1975), 350 kWh per capita
Exports: $785 million (f.0.b., 1974); cocoa (about
65%), wood, gold, diamonds, manganese, bauxite,
and aluminum (aluminum regularly excluded from
balance of payments data)
Imports: $662 million (f.0.b., 1975); textiles and
other manufactured goods, food, fuels, transport
equipment
Major trade partners: U.K., EC, and U.S.
Budget: FY75—revenue $617 million, current
expenditure $482 million, capital expenditure $214
million
Monetary conversion rate: 1 Cedi = US$0.87
Fiscal year: 1 July - 30 June','c8b73de2ffd2275083df20e6196f5bb98671d72b4f079df20d665333b0f7bd88','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2db67b8b6811640c9aa9e38c043b5d514a947c1a7626036177b44579fe0487d0',1977,'GI','Gibraltar','economy',204,'Economic activity in Gibraltar centers on
commerce and large British naval and air bases;
nearly all trade in the well-developed port is transit
trade and port serves also as important supply depot
for fuel, water, and ships’ wares; recently built
dockyards and machine shops provide maintenance
and repair services to 3,500-4,000 vessels that call at
Gibraltar each year,
U.K. military establishments and civil government
employ nearly half the insured labor force; local
78
industry is confined to manufacture of tobacco,
roasted coffee, ice, mineral waters, candy, and canned
fish; some factories for manufacture of clothing are
being developed; a small segment of local population
makes its livelihood by fishing; in recent years tourism
has increased in importance.
Electric power: 25,000 kW capacity (1975); 50
million kWh produced (1975), 2,000 kWh per capita
Exports: $11.28 million (f.0.b., 1978); principally
reexports of tobacco, petroleum, and wine; 13% to
U.K.
Imports: $22.81 million; 60% from U.K.
Major trade partners: U.K., Morocco, Portugal,','a42234b23ebca9871297714dc4942830c2c9a2037a04b8f6a56838902ac31d24','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4519251a8f99ac5c14359a945b53ee2bd5d645e50dd89a4f882b057cbfcffb9f',1977,'GR','Greece','economy',208,'GNP: $21.1 billion (1975), $2,320 per capita;
70.5% consumption, 20.8% investment, 13.3%
government; net foreign balance —6.5%, real growth
rate 0.75% (1975); typical real growth rate averages
7.5%
Agriculture: subject to droughts; main crops—
wheat, olives, tobacco, cotton; nearly self-sufficient;
food shortages—livestock products; caloric intake,
2,960 calories per day per capita (1963)
Major industries: food processing, tobacco,
chemicals, textiles, petroleum refining, aluminum
processing
80
Shortages: petroleum, minerals, feed grains
Crude steel: 875,000 metric tons produced (1975),
100 kg per capita
Electric power: 4,763,000 kW capacity (1975);
14.6 billion kWh produced (1975), 1,120 kWh per
capita
Exports: $2,297 million (f.0.b., 1975); principal
items—tobacco, cotton, fruits, textiles
Imports: 5,328 million (cif, 1975); principal
items—machinery and automotive equipment,
manufactured consumer goods, petroleum and
petroleum products, chemicals, meat and live animals
Major trade partners: (January to November
1974)—44% EC, 18% U.S., 9% other European
countries, 8% CEMA countries
Aid: economic (authorized)—U.S., $1,992.2
million (FY46-73); International Finance Corpora-
tion, $15 million through FY73; U.N. Technical
Assistance, $4.3 million through FY72; U.N. Special
Fund, $63.1 million through 1972; IBRD, $118.9
million (FY68-73), $25 million in 1972; Consortium,
$40 million in 1966; EC (FY64-72) $69.2 million;
U.S.S.R. $7.7 million (1954-74); military—U.S.,
$2,337 million (FY1946-73)
Budget: (1975) expenditures $4,680 million,
revenues $4,072 million, deficit $609 million
Monetary conversion rate: 1 drachma = US$0.031
(1975 average)
Fiscal year: calendar year','7d77b11a2cd5afb400ee0d9562633343bc97ee36c43d2593f642cd810deb7c97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d575a299a8a43f5e161d2c45be609f2eec6a75589e034fb086269cde5244ed5',1977,'GL','Greenland','economy',212,'GNP: included in that of Denmark
Agriculture: arable areas largely in hay; sheep
grazing; garden produce
Fishing: catch 48,052 tons (1975); exports $35.6
million (1975)
Major industries: mining, slaughtering, fishing,
sealing
Electric power: 57,500 kW capacity (1975); 117
million kWh produced (1975), 2,300 kWh per capita
Exports: $88.6 million (f.0.b., 1975); fish and fish
products, nonmetallic minerals
Imports: $129.1 million (c.if., 1975); machinery
and transport equipment, petroleum and petroleum
products, food products
Major trade partners: (1975) Denmark 68%,
Finland 7.5%, Spain 5.8%
Monetary conversion rate: 1 Danish Kroner=
US$0.174 (1975)
Fiscal year: 1 April - 81 March
GNP: $1,204 million (1975), $5,470 per capita;
60% consumption, 38% investment, 11% government,
—2.3% net foreign balance (1975); 1975 growth rate
—3.5%, constant prices
94
Approved For Release 2005/04/22
Agriculture: cattle, sheep, dairying, hay, potatoes,
turnips; food shortages—grains, sugar, vegetable and
other fibers; caloric intake, 2,900 calories per day per
capita (1964-66)
Fishing: catch 938,486 metric tons; exports $246
million (1974)
Major industries: fish processing, aluminum
smelting, diatomite production, hydro-electricity
Shortages: grain, fuel, wood, minerals, vegetable
fibers
Electric power: 494,800 kW capacity (1975); 2.4
billion kWh produced (1975), 10,900 kWh per capita
Exports: $809 million (f.0.b., 1975); fish and fish
products, animal products, aluminum, diatomite
Imports: $488 million (c.i.f., 1975); machinery and
transportation equipment, petroleum, foodstuffs,
textiles
Major trade partners: (1975) exports—U.S. 29%,
EC 25%, U.S.S.R. 11%; imports—EC 45%, U.S. 9%,
U.S.S.R. 10%
Aid: economic—U.S. authorized (1949-73) $90.2
million, $1.2 million in FY72, $0.9 million in FY73;
IBRD $30 million through September 1973
Budget: (1975) expenditures $315 million, revenues
$292 million
Monetary conversion rate: 153.7 kronur=US$1
(1975); 100.0 kronur=US$1 (1974)
Fiscal year: calendar year','65c9df4d5ed8bfcea047ca5236f0aac4c0986be5502a7b182cdcdf8b96cddb83','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ae7cdebf3adaca7effa7c31fd05cd7dbc61b87896794fc2968ebe03ec953def',1977,'GD','Grenada','economy',216,'GNP: $38 million (in current prices, 1974), $380 per
capita; real growth rate 1974, —15%
Agriculture: main crops—spices, cocoa, bananas
Fishing: 1,800 metric tons (1972)
Electric power: 7,000 kW capacity (1975); 25
million kWh produced (1975), 270 kWh per capita
Exports: $12 million (f.0.b., 1975); nutmeg, cocoa
beans, bananas, mace
Imports: $24 million (c.i.f.,
machinery, building materials
Major trade partners: exports—33% U.K., 19%
West Germany, 18% Netherlands; imports—-27%
West Indies, 27% U.K., 9% U.S.
Monetary conversion rate: 2.70 East Caribbean
dollars = US$1 (July 1976)','08fd594127bcd278cb69a3d82245eb8bec39d30de074f113ac37d9338ef2c9ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('684559d2a53461aa87529f4eda5e8c43f9c7d3324ca9242348b72d94f8e3f2ee',1977,'MQ','Martinique','economy',221,'GDP: $302 million (1971), $880 per capita; real
growth rate (1971) 5.9%
Agriculture: main crops, sugarcane and bananas
Major industries: agricultural processing, sugar
milling and rum distillation
Electric power: 33,000 kW capacity (1975); 130
million kWh produced (1975), 380 kWh per capita
Exports: $78 million (f.0.b., 1975); sugar, bananas,
rum
Imports: $292 million (c.if., 1975), foodstuffs,
clothing and other consumer goods, raw materials and
supplies, and petroleum
Major trade partners: exports—71% France, 17%
U.S., 7% Germany, 5% other; imports—70% France,
9% U.S., 3% Germany, 3% Netherlands Antilles, 3%
Netherlands, 12% other (1968)
Monetary conversion rate: 4.44 French francs=
US$1 (1976)
Fiscal year: calendar year
GNP: $769 million (1975 at current prices), $2,220
per capita
Agriculture: bananas, sugarcane, and pineapples
Major industries: agricultural processing, par-
ticularly sugar milling and rum distillation; cement,
oil refining and tourism
Electric power: 32,000 kW capacity (1975); 155
million kWh produced (1975), 445 kWh per capita
Exports: $90 million (f.0.b., 1975); bananas,
refined petroleum products, rum, sugar, pineapples
Imports: $309 million (c.i.f., 1975); foodstuffs,
clothing and other consumer goods, raw materials and
supplies, and petroleum
Major trading partners: exports—82% France, 9%
Italy, 9% other; import-—70% France, 6% United
States, 3% Netherlands Antilles, 3% Netherlands, 18%
other (1968)
Monetary conversion rate: 4.60 French francs=
US$1 (1976)
Fiscal year: calendar year','58e24dd449a6a339f95ac1fd3d6a0c54d0c62f829af19847590ce4798e83d70d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab9c4ae2bada47dab87df3f39710db68fdd1bc50602c8d80ed520966ef005f8',1977,'MX','Mexico','economy',227,'GDP: $3,676 million (1975), $630 per capita; 82%
private consumption, 6% government consumption,
15% domestic investment, —3% net foreign balance
(1974); average annual real growth rate (1971-75),
6.1%
Agriculture: main products—coffee, cotton, corn,
beans, sugarcane, bananas, livestock; caloric intake,
2,200 calories per day per capita (1967)
Fishing: catch 5,000 metric tons (1974); exports
$2.6 million (1973), imports $0.7 million (1973)
Major industries: food processing, textiles and
clothing, furniture, chemicals, nonmetallic minerals,
metals
Electric power: 225,000 kW capacity (1975); 1.1
billion kWh produced (1975), 180 kWh per capita
Exports: $650 million (f.0.b., 1975 est.); coffee,
cotton, sugar, bananas, meat
Imports: $720 million (f.o.b., 1975. est.);
manufacured products, machinery, transportation
equipment, chemicals, fuels
Major trade partners: exports (1974)—34% U.5.,
28% CACM, 11% West Germany, 5% Japan; imports
(1974)—31% U.S., 17% CACM, 12% Venezuela, 9%
Japan, 8% West Germany
Aid: economic—from U.S. (FY46-75), $108 million
loans, $203 million grants; from international
organizations (FY46-75), $246 million; from other
Western countries (1960-71), $12.3 million; military—
assistance from U.S. (FY46-75), $39 million
Central government budget (1975): budgeted
expenditures $370 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GUATEMALA/GUINEA
Monetary conversion rate: 1 quetzal=US$1
(official)
Fiscal year: calendar year','980d8f6627ac6a4e8e64bce68e4c65267163599092fccaa2403191932e717cb6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48ed5610e8b8ab0f792dab86c76d6650cc8c28c0999af180a22f3b7bf0bae4df',1977,'GW','Guinea-Bissau','economy',231,'GDP: $112 million (est. 1975), $240 per capita
Agriculture: main crops—palm oil, root crops, rice,
coconuts, peanuts
Electric power: 11,000 kW capacity (1975); 17
million kWh produced (1975), 30 kWh per capita
Exports: $3.6 million (f.0.b., 1969); principally
peanuts, coconuts
Imports: $23.3 million (c.i.f., 1969); manufactured
goods, fuels, transport equipment, rice
Major trade partners: mostly Portugal, also
immediate neighbors
Aid: Portugal, small amounts
Monetary conversion rate: using Portuguese
currency; 31.39 escudos=US$1 (July 1976)
Fiscal year: probably is the calendar year','831f67d99f5514838fac501f361c5c50fd66d6dfccca499efdd515a826257a12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9f79e91c014d5eb8740a98f46fdab4dde941eecf0442f35221e555629292acc',1977,'GY','Guyana','economy',235,'GNP: $471 million (1975), $580 per capita; real
growth rate 1975, 5% est.
Agriculture: main crops—sugarcane, rice, other
food crops; food shortages—wheat flour, potatoes,
processed meat, dairy products; caloric intake, 2,180
calories per day per capita (1967)
Fishing: exported 5,100 metric tons valued at $4
million in 1974
Major industries: bauxite mining, alumina
production, sugar and rice milling, timber
Electric power: 175,000 kW capacity (1975); 370
million kWh produced (1975), 515 kWh per capita
Exports: $362 million (f.0.b., 1975); bauxite, sugar,
alumina, rice, shrimp, molasses, timber, diamonds,
rum
Imports: $351 million (c.if., 1975); manufactures,
machinery, food, petroleum
Major trade partners: exports—29% U.K., 24%
U.S., 14% CARICOM, 3% Canada; imports—29%
US., 22% U.K., 21% CARICOM, 4% Canada (1975)
Aid: economic—authorizations from U.S. (FY53-
75), $63 million in loans, $26 million in grants;
commitments from Communist countries—China
(1972-75), $36 million in loans, and East Germany
(1974), $10 million in loans; from international
organizations (FY46-75), $68 million
Monetary conversion rate: since October 1975
floating with US dollar, 1 US$ =G$2.55
Fiscal year: calendar year','cb8ff0e2a195837ee970396e997ee0c9088dcca1aa05a923fed05f7386ea2e6c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('280f13da50470b07febe4f13e563ea89023dbbe0e8069c6dc0de08bbf22ad4b7',1977,'HT','Haiti','economy',239,'GDP: $816 million (FY74), $160 per capita; real
growth rate 1974, 3.5%
Agriculture: main crops—coffee, sugarcane, rice,
corn, sorghum, pulses; caloric intake, 1,850 calories
per day per capita
Major industries: sugar refining, textiles, flour
milling, cement manufacturing, bauxite mining,
tourism, light assembly industries
Electric power: 70,000 kW capacity (1975); 185
million kWh produced (1975), 28 kWh per capita
Exports: $74 million (£.0.b., 1975 est. ); coffee, light
industrial products, bauxite, sugar, essential oils, sisal
Imports: $121 million (c.i.f., 1975 est.); consumer
durables, foodstuffs, industrial equipment, petroleum
products, construction materials
Major trade partners: exports—60% U.S.;
imports—40% U.S. (FY73)
Aid: economic authorizations—from U.S. (FY46-
75), $46 million loans, $109 million grants; from
international organizations (FY46-75), $102 million;
military authorizations—from U.S. (FY46-75), $4
million in grants
Monetary conversion rate: 5 gourdes = US$1
Fiscal year: 1 October - 30 September','4992d45525bbb69e85e907214cb14360338bfdcdef896925cd2d873615061b30','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('503aa2789f1e48b1b74747b7b6c0ea7aea33964926dd842a69ddcc4a1fee279c',1977,'HN','Honduras','economy',243,'GDP: $1,030 million (1975), $370 per capita; 79%
private consumption, 10% government consumption,
22% domestic investment; —11% net foreign balance
(1975); real growth rate, average 1971-75, 2.6%
Agriculture: main crops—bananas, coffee, corn,
beans, cotton, sugarcane, tobacco; caloric intake,
2,200 calories per day per capita (1970)
Fishing: exports $4.3 million (1972); imports $0.5
million (1972)
Major industries: agricultural processing, textiles,
clothing, wood products
Electric power: 167,000 kw capacity (1975); 420
million kWh produced (1975), 155 kWh per capita
Exports: $300 million (f.0.b., 1975); bananas,
lumber, coffee, meat, petroleum products
Imports: $410 million (c.i.f., 1975); manufactured
products, machinery, transportation equipment,
chemicals, petroleum
Major trade partners: exports—51% U.S., 12%
CACM, 11% West germany; imports—42% U.S.,
16% Venezuela, 138% CACM, 7% Japan, 3% West
Germany (1975)
Aid: economic—extensions from U.S. (FY46-75),
$107 million loans, $87 million grants; from
international organizations (FY46-73), $291 million;
from other Western countries (1960-73), $7.0 million;
military—assistance from U.S. (F Y46-75), $16 million
Budget (1976): expenditures, $240 million
Monetary conversion rate: 2 lempiras = US$1
(official)
Fiscal year: calendar year','6550ead342c481936686efd0990c2a03199d8be64a4d837159edc611972ca6bb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12c1622658d52e7ad1833291c831e3cadcfb25cda4a455d9d9ae961b9ab377f5',1977,'HK','Hong Kong','economy',247,'GDP: 6.8 billion (1975, in 1975 prices), $1,570 per
capita (est.); average real growth 4.8% (1970-75)
Agriculture: agriculture occupies a minor position
in the economy; main products—rice, vegetables,
dairy products; less than 20% self-sufficient; food
shortages—rice, wheat
Major industries: textiles and clothing, tourism,
plastics, electronics, light metal products, food
processing
91
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
HONG KONG/HUNGARY
Shortages: industrial raw materials, water, food
Electric power: 2,600,000 kW capacity (1975); 7.3
billion kWh produced (1975), 1,600 kWh per capita
Exports: $6.0 billion (f.0.b., 1975), including $1.4
billion reexports; principal products clothing, plastic
articles, textiles, electrical goods, wigs, footwear, light
metal manufactures
Imports: $6,8 billion (c.i.f., 1975)
Major trade partners; (1975) exports—25% U.S.,
9% U.K., 9% West Germany; imports—21% Japan,
20% China, 12% U.S,
Budget: (76/77) $1.44 billion
Monetary conversion rate: HK$4.884 = US$1
(September 1976)
Fiscal year: 1 April - 81 March','c041b50d1a2c4ed419ff93e792d66be2566465a08962ddbc5dd180de1c2a0597','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('681082646921fe5e7a5606da0544c82c39710b1897939f8fdc84f241d53af0b9',1977,'HU','Hungary','economy',252,'GNP; $27.8 billion in 1975 (at 1975 prices), $2,640
per capita; 1975 growth rate, 3.7%
Agriculture: normally self-sufficient; main crops—
corn, wheat, potatoes, sugar beets, wine grapes;
caloric intake 3,140 calories per day per capita (1970)
Major industries: mining, metallurgy, engineering
industries, processed foods, textiles, chemicals
(especially pharmaceuticals)
Shortages: metallic ores (except bauxite), copper,
high grade coal, forest products, crude oil
Crude steel: 3.67 million metric tons produced
(1975), 350 kg per capita
Electric power: 4,500,000 kW capacity (1975);
20.5 billion kWh produced (1975), 1,935 kWh per
capita
Exports: $6,066 million (f.o.b., 1975); 31%
machinery, 19% industrial consumer goods, 25% raw
materials and semimanufactures, 23% food and raw
materials for the food industry, energy sources 2%
(distribution for 1975)
Imports: $7,156 million (1975); 22% machinery,
8% industrial consumer goods, 49% raw materials and
semimanufactures; 9% food and raw materials for the
food industry, energy sources 12% (distribution for
1975)
Major trade partners: $13,221 million (1975); 69%
with Communist countries, 31% with non-Commu-
nist countries
Aid: U.S.S.R.—$338 million extended (1956-66),
$10 million extended in 1967, $167 million extended
in 1968; to less developed non-Communist coun-
tries —$666.3 million (1954-75)
Monetary conversion rate: 41.30 forints = US$1
(commercial); 20.65 forints=US$1 (noncommercial)
as of January 1976
Fiscal year: same as calendar year; economic data
reported for calendar years
NOTE: foreign trade figures were converted at the
1975 rate of 8.60 forints= US$1','066531f9c3ef20a1788f874ddc1b24389e05ad782ce4612efebb45a353685c41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('502cff6e2ebaad41cb4f088a8bd8ea089924544e2e657191afbbcc3a02903bef',1977,'ID','Indonesia','economy',256,'GNP: $29 billion (1975, current prices), about $220
per capita; real average annual growth (1970-75),
7.1%
Agriculture: subsistence food production, and
smallholder and plantation production for export;
main crops—rice, rubber, copra, other tropical
products; food shortage—rice, wheat
Fishing: catch 1.3 million tons (1974); exports $74
million (1974), imports $2 million (1974)
Major industries; processing agricultural products
and petroleum, textiles, mining
Approved For Release 2005/04/22 :
Electric power: 1,700,000 kW capacity (1975); 5.2
billion kWh produced (1975), 39 kWh per capita
Exports: $6,800 million (f.0.b., 1975); timber,
rubber, tin, copra, tea, coffee, tobacco, palm oil;
petroleum, $5,100 million (405 million bbls) (1975)
Imports: $5,000 million (c.i.f., 1975); rice, other
foodstuffs, textiles, chemicals, iron and steel products,
machinery, transport equipment, consumer durables
Major trade partners: exports (1975)—32% U.S.,
44% Japan, 9% Singapore; imports—18% U.S., 41%
Japan, 9% West Germany, 6% Singapore
Budget: (1976-77) expenditures $8.6 billion; 46%
current, 54% development expenditures; planned
receipts $8.6 billion
Monetary conversion rate: 415 rupiah = US$1
Fiscal year: 1 April - 31 March
GNP; $50 billion (1975), $1,510 per capita; recent
teal GNP growth, 13.8% (1970-75)
Agriculture: wheat, barley, rice, sugar beets,
cotton, dates, raisins, tea, tobacco, sheep, and goats
Electric power: 5,000,000 kW capacity (1975);
19.2 billion kWh produced (1975), 570 kWh per
capita
Exports: $19.9 billion (f.0.b., 1975); 96%
petroleum; also carpets, raw cotton, fruits, and nuts,
hide and leather items, ores
Imports: $13.3 billion (f.0.b., 1975); machinery,
iron and steel products, chemicals, pharmaceuticals,
electrical equipment, agricultural products
Major trade partners: exports—U.S., Japan, West
Germany, U.S.S.R. and other Communist countries;
imports—U.S., West Germany, Japan, U.K., U.S.S.R.
Budget: (FY76-77) $44.8 billion
Monetary conversion rate: 70.6 rials =US$1
Fiscal year: 21 March -20 March','4fc6f00406d1136afd5fc8993b854e1124582c78a69852344be90e30630baa98','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('059c8e13d31ba2307bb74a018cbcaeaa829e9aad1b3918059626892701dfadea',1977,'IQ','Iraq','economy',260,'GNP: $13 billion (1975 est.), $1,180 per capita
Agriculture: dates, wheat, barley, rice, livestock
Major industry: crude petroleum (third largest
producer in Middle East); 2.1 million b/d (est. 1976);
petroleum revenues estimated for 1976, $8.0 billion
99
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
IRAQ/IRELAND
Electric power: 1,200,000 kW capacity (1975); 3.4
billion kWh produced (1975), 303 kWh per capita
Exports: $8.3 billion (f.0.b., 1976 est.); net receipts
from oil, $8.0 billion; non-oil, $300 million est.
Imports: $5.1 billion (f.0.b., 1975 est.); 26% from
Communist countries (1973)
Major trade partners: exports—U.S, 2%, Italy
22%, France 19%, Netherlands 6%, U.K. 4%; im-
ports—U.S. 5.6%, U.K. 8.5%, U.S.S.R. 8.8%, France
8.4%, Japan 6.7%, Brazil 5.9%, Czechoslovakia 5.5%
(1978) st
Budget: $17 billion (FY76)
Monetary conversion rate: 1 Iraqi dinar = US$3.38
(end of July 1973)
Fiscal year: 1 January - 31 December','c214c51983c24dbb604125d37f2d27bb0924b6231e61fc65623cd9a75028b981','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f53f7a32c3527e8193191cb334b8870700153c920b44a5b6fdc35ceda0dea31',1977,'IE','Ireland','economy',264,'GNP: $7.9 billion (1975), $2,580 per capita; 68.2%
consumption, 23.2% investment, 19.8% government,
5.9% inventories; —5.3% net export of goods and
services; 1968-72 real growth rate, 4.3%; 1973, 5.2%;
1974, 0.2%; 1975, —3.5%
Agriculture: 70% of agricultural area used for
permanent hay and pasture; main products—
livestock and dairy products, barley, potatoes, sugar
beets, wheat; 85% self-sufficient; food shortages—
grains, fruits, vegetables; caloric intake 3,510 calories
per day per capita (1970)
Fishing: catch 89,500 metric tons (1974); exports of
fish and fish products $29.6 million (1974), imports of
fish and fish products $11.3 million (1974)
Major industries: food products, brewing, textiles
and clothing, machinery and transportation
equipment
Shortages: coal, petroleum, timber and woodpulp,
steel and nonferrous metals, fertilizers, cereals and
animal feeds, textile fibers and textiles
Crude steel: 85,000 metric tons produced in 1975,
30 kg per capita
Electric power: 2,200,000 kW capacity (1975); 7.9
billion kWh produced (1975), 2,500 kWh per capita
Exports: $3,201.2 million (f.0.b., 1975); live
animals, meat, dairy products, machinery, clothing,
chemicals
Imports: $3,775.7 million (c.if., 1975); petroleum
and petrol products, chemicals, machinery, cereals
Major trade partners; 73.8% EC-nine (51.2%
U.K., 7.5% West Germany); 6.7% U.S.; 2.0%
Communist countries (1975)
Aid: economic—U.S., $200 million authorized
(FY49-75); IBRD, $122 million authorized (FY64-75),
EC Common Borrowing Facility, $300 million
Budget: (1976) 2,093 million pounds expenditures,
1,374 million pounds revenues, 719 million pounds
deficit
Approved For Release 2005/04/22 :
Monetary conversion rate: 1 Irish pound=
US$2.2215 (1975 average)
Fiscal year: 1 April - 31 March','8a1a009d690bd6690d969d8facb7c7c4d0a13d2e1da7303e418f1170989a5ca3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52938840659f77a48097644a249d51887614209565ac07d5e6213fc2602df1e9',1977,'IL','Israel','economy',268,'GNP; $11.4 billion (1975, in 1975 prices), $3,380
per capita (converted to dollars at 6.33 Israeli
pounds = US$1); 1974 growth of real GNP —1.8%
Agriculture: main products—citrus and other
fruits, vegetables, beef and dairy products, poultry
products
Major industries: food processing, textiles and
clothing, diamond cutting and polishing, chemicals,
metal products, transport equipment, electrical
equipment, miscellaneous machinery, rubber and
plastic products, potash mining
Electric power: 2,200,000 kW capacity (1975); 12
billion kWh produced (1975), 3,520 kWh per capita
Exports: $1,835 million (f.0.b., 1975); major
items—polished diamonds, citrus and other fruits,
textiles and clothing, processed foods, fertilizer and
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
a a a AN A
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ISRAEL/ITALY
chemical products; tourism is leading foreign
exchange earner
Imports: $4,088 million (c.i.f., 1975); major
items—rough diamonds, chemicals, machinery, iron
and steel, cereals, textiles, vehicles, ships, and aircraft
Major trade partners: exports—EC, U.S., U.K.,
Japan, Hong Kong, Switzerland; imports—EC, U.S.,
U.K., Switzerland, Japan
Budget: FY ending 31 March 1977—$12 billion
(converted at 7.1 Israeli pounds = US$1)
Monetary conversion rate: 7.68 Israeli pounds =
US$1 (April 1976, changes almost monthly); par value
protected by a system of export subsidies and import
duties and by legal restrictions on conversion
Fiscal year: 1 April - 31 March','6ed6cacdbf733c84515ccc239f4e51fd20943cb167063de717a9ddf366e9ad60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccf2154ccb0ca3ef4e8e8c7b9c8130b959f66c652f2519c8552b4eb4e2d8a0fc',1977,'IT','Italy','economy',272,'GDP: $172 billion (1975), $3,090 per capita; 67.5%
private consumption, 21% gross fixed investment,
14.0% government, net foreign balance —6.1%; 1978
growth rate 6.3%, 1974 growth rate 3.4%, 1975
growth rate —3.5% (1970 constant prices)
104
Agriculture: important producer of fruits and
vegetables; main crops—cereals, potatoes, olives; 95%
self-sufficient; food shortages—fats, meat, fish, and
eggs; caloric intake, 3,100 calories per capita (1970)
Fishing: catch 462,000 metric tons (1973), $336
million (1973); exports $41 million (1974), imports
$155 million (1974)
Major industries: machinery and transportation
equipment, iron and steel, chemicals, food processing,
textiles
Shortages: coal, fuels, minerals
Crude steel: 21.9 million metric tons produced
(1975), 390 kg per capita
Electric power: 48,586,000 kW capacity (1975);
147.1 billion kWh produced (1975), 2,750 kWh per
capita
Exports: $34.8 billion (f.0.b., 1975); principal
items—machinery and transport equipment, textiles,
foodstuffs, chemicals, footwear
Imports: $38.4 billion (c.i.f., 1975); principal
items—machinery and transport equipment, food-
stuffs, ferrous and nonferrous metals, wool, cotton,
petroleum
Major trade partners: (1975) 43.6% EC-nine (18%
West Germany, 15% France, 4% Netherlands, 4%
U.K., 3% Belgium-Luxembourg); 8% U.S.; 3%
U.S.S.R. and 8% other Communist countries of
Eastern Europe
Aid: economic—U.S., $4,128 million (FY46-75),
$78.2 million authorized FY73; IBRD, $398 million
authorized through FY75, none since FY65;
International Finance Corporation, $1 million
authorized through FY75, none since FY60;
military—U.S., $2,545 million (FY46-73), $11.6
million authorized in FY73
Monetary conversion rate: Smithsonian rate as of
December 1973, 650.4 lira= US$1; average of Friday
closing rates in 1975—658 lira = US$1
Fiscal year: calendar year','b2e6e91cf01fabffaf27b6298b04f694191f3d24a62323d67f876891a14ab905','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35bd1b3a6bcab8b4c9214eedcce8113d0bf712fa177f7cfea6f2f48de066fa82',1977,'JM','Jamaica','economy',276,'GDP: 2,653 million (1975), $1,290 per capita; real
growth rate 1975, —2.3%
Agriculture: main crops—sugarcane, citrus fruits,
bananas, pimento, coconuts, coffee, cocoa
Major industries: bauxite mining, textiles, food
processing, light manufactures, tourism
Electric power: 758,000 kW capacity (1975); 2.2
billion kWh produced (1975), 1,050 kWh hr. per
capita
Exports: $810 million (£.0.b., 1975); alumina,
bauxite, sugar, bananas, citrus fruits and fruit
products, rum, cocoa
Imports: $1,115 million (cif, 1975); fuels,
machinery, transportation and electrical equipment,
food, fertilizer
Major trade partners: exports—U.S. 38%, U.K.
28%, Norway 11%, Canada 4%; imports—U.S. 37%,
U.K. 13%, Canada 5% (1975)
Aid: economic—authorizations from U.S. (FY56-
75), $181 million in loans, $57 million in grants; from
other Western countries (1960-74), $151 million; from
international organizations (FY46-75), $183 million;
military—authorizations from U.S. (FY63-75), $1
million in grants
Approved For Release 2005/04/22 :
Budget: FY76-77, prelim.—revenues $1,037
million, expenditures $1,016 million
Monetary conversion rate: 1 Jamaican dol-
lar = US$1.10
Fiscal year: 1 April - 81 March','875dbd73f0bde1321b66f051b8ce205f06d2c67c085d7c8f34965cdb62ae00dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d45a2968a9d81758b0ef867262a8864dd3110730ce1e34f29c992f47f241867',1977,'JP','Japan','economy',280,'GNP: $488 billion (1975, at 296.8 yen=US$1);
$463 billion in 1974 prices, $4,400 per capita (1975);
57% personal consumption, 32% investment, 11%
government current expenditure; real growth rate
2.1% (1975); average annual growth rate (1970-1975),
6.3%
Agriculture: land intensively cultivated—rice,
wheat, barley, sugar, potatoes, fruits; 72% self-
sufficient; food shortages—meat, wheat, feed grains,
edible oil and fats; caloric intake, 2,502 calories per
day per capita (1974)
Fishing: catch 10.8 million metric tons (1974)
Major industries: metallurgical and engineering
industries, electrical and electronic industries, textiles,
chemicals
Shortages: fossil fuels, most industrial raw materials
Crude steel: 102 million metric tons produced
(1975)
Electric power: 110,400,000 kW capacity (1975);
460 billion kWh produced (1975), 4,077 kWh per
capita
Exports: $54.8 billion (f.o.b., 1975); 54%
machinery and equipment, 22% metals and metal
products, 7% textiles
Imports: $49.7 billion (f.0.b., 1975); 44% fossil
fuels, 8% metals and metal products, 15% foodstuffs,
7% machinery and equipment
Major trade partners: exports—20% U.S., 15%
OPEC, 11% Communist countries, 10% EC, 4%
Australia, 40% other; imports—85% OPEC, 20%
U.S., 7% Australia, 6% EC, 5% Communist countries,
27% other
Aid: Japanese official foreign economic aid
disbursements 1975, $1,148 million
Budget: revenues $56.7 billion, expenditures $81.0
billion, deficit $24.3 billion (general account for fiscal
year ending March 1977)
Monetary conversion rate: 296.8 yen = US$1 (1975
average rate), floating since February 1973
Fiscal year: 1 April - 81 March
GNP: $7.5 billion (1975 est.), $450 per capita
Agriculture: main crops—rice, corn, vegetables;
food shortages—meat, cooking oils; production of
foodstuffs adequate for domestic needs at low levels of
consumption
Major industries: machine building, electric
power, chemicals, mining, metallurgy, textiles, food
processing
Shortages: complex machinery and equipment,
bituminous and coking coal, petroleum, rubber
Crude steel: 3.3 million metric tons produced
(1975), 210 kg per capita
Exports: $800 million; minerals, chemical and
metallurgical products (1974)
Imports: $1,100 million; machinery and equip-
ment, petroleum, foodstuffs, coking coal (1974)
Major trade partners: total trade turnover
$1.9 billion; 43% with non-Communist countries,
57% with Communist countries (1975)
112
Approved For Release 2005/04/22
Aid: economic and military aid from the U.S.S.R.
and China
Monetary conversion rate: 2.15 won = US$1
(arbitrarily established)
Fiscal year: calendar year
CNP: $18.0 billion (1975, in 1974 prices); real
growth 7.4% (1974); real growth 9.8% (1970-74
average)
Agriculture: 40% of the population live on the
land, but agriculture, forestry and fishery constitute
26% of GNP; main crops—rice, barley, wheat; not
self-sufficient; food shortages—barley, wheat, dairy
products, rice, corn
Fishing: catch 2,026,000 metric tons (1974)
Major industries: textiles and clothing, food
processing, chemical fertilizers, chemicals, plywood,
steel
Shortages: base metals, petroleum, lumber and
certain food grains
Electric power: 5.1 million kw capacity (1975);
19.9 billion kWh produced (1975), 555 kWh per
capita
Exports: $5.0 billion (f.0.b., 1975); clothing,
electrical machinery, plywood, footwear, processed
food, steel
Imports: $7.1 billion (c.i.f., 1975); oil, ships, steel,
wood, wheat, organic chemicals
Major trade partners: exports—30% U.S., 25%
Japan; imports—33% Japan, 26% U.S. (1975)
Aid: economic—U.S. (FY46-75), $6.4 billion
committed; Japan (1965-73), $1.8 billion extended;
military—U.S. (FY46-75), $6.5 billion committed
Budget: $5.5 billion (1976)
Monetary conversion rate: rate fixed at 484
won=US$1 since December 1974
Fiscal year: calendar year
Aid: New Zealand, $7 million (est. 1972-76)
Budget: 1975 est., revenues 14 million tala,
expenditures 22 million tala
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Se
hemi eT z
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Monetary conversion rate: WS Tala=US$1.30
(December 1975), 0.77 WS Tala=US$1
Major industries: timber, tourism','371d757d19d00adc17c0302bd5b7da5340b4a5726c2aaed3c459a056c47f744c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('292477bb7a91b27f957cd2b3139ed115a9942d993ca497e0e9c30e50067df64a',1977,'JO','Jordan','economy',284,'GNP: $1.2 billion (1975 est.), $440 per capita; real
growth rate (1973-75), 6%
Agriculture: main crops—wheat, fruits, vegetables,
olive oil; not self-sufficient in many foodstuffs
Major industries: phosphate mining, petroleum
refining, and cement production
Electric power: 150,000 kW capacity (1975); 825
million kWh produced (1975), 118 kWh per capita,
East Bank only
Exports: $125 million (f.0.b., 1975); fruits and
vegetables, phosphate rock; Communist share 5% of
total (1974)
Imports: $782 million (c.i.f., 1975); petroleum
products, textiles, capital goods, motor vehicles,
foodstuffs; Communist share 9% of total (1974)
Aid: economic—U.S., $924 million economic
assistance (FY46-75), of which $82 million loans, $827
million grants; military—$416 million total from U.S.
(FY58-75) including $269 million in MAP grants
Budget: (1976 est. )~expenditures $802 million
(non-military, $647 million, military $155 million),
development $349 million; deficit $37 million
Monetary conversion rate: 1 Jordanian dinar=
US$3.08, freely convertible; 0.8300 Jordanian dinar=
US$1
Fiscal year: calendar year
GDP: $2,500 million at current prices (1975), $190
per capita; 5% real growth 1970-75
Agriculture: main cash crops—coffee, sisal, tea,
pyrethrum, cotton, livestock; food crops—corn,
wheat, rice, cassava; largely self-sufficient in food
Fishing: 29,400 metric tons (1974)
Major industries: small-scale consumer goods
(plastic, furniture, batteries, textiles, soap, agricultural
processing, cigarettes, flour), oil refining, cement
Electric power: 285,000 kW capacity (1975); 900
million kWh produced (1975), 65 kWh per capita
Exports: $600 million (f.0.b., 1975 est.); coffee, tea,
livestock products, pyrethrum, soda ash, wattle-bark
tanning extract
Imports: $950 million (c.i.f., 1975 est.); machinery,
transport equipment, crude oil, paper and paper
products, iron and steel products, and textiles
Major trade partners: U.K. and EC, also Uganda
and Tanzania, which are part of East African
Economic Community
Budget: FY76 current revenues $1,009 million;
current expenditures $1,057 million; development
expenditures $198 million
Monetary conversion rate: 8.4 Kenya shillings =
US$1
Fiscal year: 1 July - 30 June','6daab40513e77baa3c5fe1b399be7ef271b59768757605da2d6bd0ba4a96ffb7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba0ae5509cf313e51aaa4f8529bde69e3c496780b8d7da43a42778d9b37511ef',1977,'KW','Kuwait','economy',288,'GNP: $13.9 billion (1975 est.), $13,500 per capita
est.
Agriculture: virtually none, dependent on imports
for food; approx. 75% of potable water must be
distilled or imported
Major industries: crude petroleum production
averaging 2.1 million b/d (includes Kuwait’s share of
neutral zone, down 30% from 1973); government
revenues from taxes and royalties on production,
refining, and consumption, $7.7 billion est. for 1975;
refinery production 90,720,273 bbls (1974), average
b/d refinery throughput equals 248,550 bbls; other
major industries include processing of fertilizers,
chemicals; building materials; flour, and fishing
Electric power: 1,500,000 kW capacity (1975); 4.5
billion kWh produced (1975), 4,860 kWh per capita
Exports: $8.1 billion (1976 est.), of which
petroleum accounted for about 98%; nonpetroleum
exports are mostly reexports, $600 million (1976 est. )
Imports: $3 billion (1976 est.); major suppliers—
U.S., Japan, U.K., West Germany
Aid: an aid donor, committed bilaterally or through
multilateral agencies nearly $3 billion in economic
assistance in 1975
: CIA-RDP79-01051A000800010006-3
a
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
KUWAIT/LAOS
Budget: (FY76/77) $7.6 billion revenues; State
reserves, $10 billion (1975)
Monetary conversion rate: 1 Kuwaiti dinar=
US$3.48 (1976)
Fiscal year: 1 July - 30 June
GNP: $220 million, $70 per capita (1972 est.)
Agriculture: main crops—rice (overwhelmingly
dominant), corn, vegetables; largely self-sufficient;
115
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LAOS/LEBANON
food shortages (due in part to distribution
deficiencies) including rice
Major industries: tin mining, timber, tobacco
Shortages: capital equipment, petroleum, transpor-
tation system
Electric power: 61,000 kW capacity (1975); 250
million kWh produced (1975), 79 kWh per capita
Exports: $3.2 million (f.0.b., 1975 est.); forest
products (40%), tin concentrates (53%); coffee,
undeclared exports of opium and tobacco
Imports: $30 million (c.if., est. 1975); rice and
other foodstuffs, petroleum products, machinery,
transportation equipment
Major trade partners: imports from Thailand,
U.S.S.R., Japan, France, China, Vietnam; exports to
Thailand and Malaysia; trade with Communist
countries insignificant; Laos was once a major transit
point in world gold trade, value of 1973 gold re-
exports $55 million
Aid: economic—$26 million (1975) of which $25
million, U.S.; remainder mostly U.S.S.R., China,
Vietnam, France, Japan, and international agencies;
military—no quantifiable data for 1975 or 1976
Budget: (1973-74) receipts, 13.3 billion kip;
expenditures, 36.0 billion kip; deficit 22,7 billion kip
(provisional totals); 45% military, 55% civilian; no
data available since Communists fully took over
government in 1975
Monetary conversion rate: as of 15 October 1976
200 kip=US$1 (official), 1,300 liberation kip = US$1
(free market)
Fiscal year: 1 July - 30 June','0f5311b68b2d3fa58900bc84bfdcbb42d369523e58cf420fb4abb1af06c9c25c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fdb5f7b02a19a133673a651ffcb635bd08572322859b30dcde2a665b1fec086',1977,'LB','Lebanon','economy',292,'Agriculture: fruits, wheat, corn, barley, potatoes,
tobacco, olives, onions; not self-sufficient in food
Major industries: service industries, food
processing, textiles, cement, oil refining, chemicals,
some metal fabricating, tourism
Electric power: 540,000 kW capacity (1975); 1
billion kWh produced (1975), 400 kWh per capita
Major trade partners: exports $1 billion est. (f.0.b.,
1974); most to Arab countries; imports $1.7 billion
(cif, 1974); chiefly from EC, U.K., and Arab
countries; trade deficit covered by large net receipts
from invisibles (particularly tourism and transporta-
tion) and private capital inflow
Budget: (1975) expenditures $863 million, current
expenditures $758 million, investment expenditures
$105 million
Monetary conversion rate: 1 Lebanese pound =
US$0.44 as of August 1975
Fiscal year: calendar year','3db003a6bb437f5d9908c91363af128070ae86c17d33d9770f5ebeb6ef6bfa2e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce744da8a66fea7141b49102c52d3d04718250566aa8b5447b95157295996efa',1977,'LS','Lesotho','economy',296,'GNP: $196 million (FY72 est.), $205 per capita;
growth rate (in current prices), 13% annually (FY70-
72 est.)
Agriculture: exceedingly primitive, mostly
subsistence farming and livestock; principal crops are
corn, wheat, pulses, sorghum, barley
Major industries: none
Electric power: approximately 20 million kWh
imported from South Africa (1975)
Exports: labor to South Africa (remittances $90
million est. in 1975); $12.6 million (est. f.0.b., 1975),
wool, mohair, wheat, cattle, diamonds, peas, beans,
corn, hides, skins
Imports: $95 million (est. c.i.f., 1975); mainly corn,
building materials, clothing, vehicles, machinery,
POL
Major trade partner: South Africa
Aid: economic aid—U.K. $9.4 million (plan FY71-
75); other $17.5 million (plan FY71-75): U.S. $23.1
million authorized (FY61-75); no military aid
Budget: (FY76) revenues, $63 million; current
expenditures, $38 million; development budget, $25
million
Monetary conversion rate: Lesotho uses the South
African rand; 1 SA rand =US$1.15 (as of September
1975)
Fiscal year: 1 April - 31 March','d061615343ed1d0171b0e60752e47bb8e28dda3d6a6a58fe3c58a24c5abb0abb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c557761fafb6ceb48b7b1dc01076ce4036ca5f5aae7c9899fd02577b0869d584',1977,'LR','Liberia','economy',300,'GDP: $745 million (1975), $425 per capita; 4%
current annual growth rate (1972-75)
Agriculture: rubber, rice, oil palm, cassava, coffee,
cocoa; imports of rice, wheat, and live cattle and beef
are necessary for basic diet
Fishing: catch 23,000 metric tons
Industry: rubber processing, food processing,
construction materials, furniture, palm oil processing,
mining (iron ore, diamonds), 10,000 b/d oil refinery
Electric power: 300,000 kW capacity (1975); 875
million kWh produced (1975), 490 kWh per capita
119
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LIBERIA/LIBYA
Exports: $406 million (f.0.b., 1975); iron ore,
rubber, diamonds, lumber and logs, coffee, cocoa
Imports: $332 million (cif, 1975); machinery,
transportation equipment, petroleum products,
manufactured goods, foodstuffs
Major trade partners: U.S., West Germany,
Netherlands, Italy, Belgium
Aid: economic—(FY46-75) U.S., $344.9 million;
military—(FY53-75) U.S., $13.9 million; other aid
($73.1 million through FY75), sources include IBRD,
U.N., IMF, West Germany, Republic of China
Budget: (FY75) revenues $127 million, expendi-
tures $124 million; development budget $27.2 million
Monetary conversion rate: Liberia uses US.
currency
Fiscal year; 1 July - 30 June (beginning 1 July
1976)','d29c79fbd0da3b2446f67d4d860ffdfb87b40b1ad8a78b5c9c5ebf829d8dba29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a9c30bd3147cb98759b6329e35d19059658b0ae9765a6f5293687dbd41662fa',1977,'LY','Libya','economy',304,'GNP: $11.9 billion (1975), $4,920 per capita
Agriculture: main crops—wheat, barley, olives,
dates, citrus fruits, peanuts; not self-sufficient in food
Major industries: petroleum, food processing,
textiles, handicrafts
Electric power: 1,000,000 kW capacity (1975); 1.4
billion kWh produced (1975), 685 kWh per capita
Exports: $6,120 million (1975); over 99%
petroleum
Imports: $4,400 million (c.i.f., 1975)
Major trade partners: imports—lItaly, West
Germany, U.S.; exports—Italy, West Germany, U.K.,','a3f7085ce1059279ae3c5f6a15ecb62cc7c59dd5a0cf9ac7b198f41084918937','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84d93fac68f4744dffa784e661e073367f7e82ffdb83c031441bb7f97b1c9ecb',1977,'LI','Liechtenstein','economy',308,'Despite its small size and sparse natural resources,
Liechtenstein has a prosperous economy based
primarily on small-scale light industry and farming.
Textiles, ceramics, precision instruments, phar-
maceuticals, and canned foods are the principal
manufactures produced, almost entirely for export.
Livestock raising and dairying are the main sources of
farm income; cereals and potatoes are the most
important farm crops. The Liechtenstein economy is
tied closely to that of Switzerland in a virtual customs
union. No national accounts data are available.
Major trade partners: exports (1972)—$138.6
million; 34% Switzerland, 35% EC, 48% EFTA
Electric power: 23,000 kW capacity (1975); 56
million kWh produced (1975), 1,900 kWh per capita;
power is exchanged with Switzerland, but net exports
average 35 million kWh yearly
Budget: (1976) revenues $93.2 million, expendi-
tures $96.2 million, deficit $3.0 million','87daf299a76fd691454eb97f37250d7cf9c8e81ac7ad91b1cd55d511d5809e94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55dd9513aaa074e445d3e379854a6bfa3fa05bbfc37e618c4e084a3c70e87344',1977,'LU','Luxembourg','economy',313,'GNP: $2,159 million (1975, in 1975 prices), $6,050
per capita; 1975 growth rate —7.3% at constant
prices; 52% consumption, 31% investment, 11%
government, 6% net exports of goods and services
(1974)
Agriculture: mixed farming; main crops—grains,
potatoes, fodder beets; food shortages—sugar, bread
grains, fats; caloric intake, 3,150 calories per day per
capita (1968-69)
Major industries: iron and steel, food processing,
chemicals, metal products and engineering, tires
Approved For Release 2005/04/22 :
Crude steel: 5387 thousand metric tons produced
(1974), 1,500 kg per capita
Electric power: 1,205,000 kW capacity (1975); 1.5
billion kWh produced (1975), 6,000 kWh per capita
Exports: see Belgium
Imports: see Belgium
Major trade partners: Luxembourg and Belgium
form an economic and customs union and report their
foreign trade jointly (see Belgium); Luxembourg’s
principal exports are iron and steel products; principal
imports are coal and consumer products; most foreign
trade is with Germany, Belgium, and other EC
countries
Aid: foreign aid to Luxembourg is included in aid
to Belgium
Budget (estimated): (1975) expenditures $695.1
million, revenues $591.6 million, deficit $103.6
million
Monetary conversion rate: 1975 average 1
franc=US$$0.0272 floating; under the BLEU
agreement, the Luxembourg franc is equal to the
Belgian franc which circulates freely in Luxembourg
Fiscal year: calendar year','5d3859a7a08428c70a5d91a72cdfca5cad5bfc2386068c5e7bb89e9dd3cc909b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72aa6223c7b90a8ed1009c15a36248b983d1aa81275ef3a587e1ea0d7dc7be4c',1977,'MO','Macao','economy',317,'Agriculture: main crops—rice, vegetables; food
shortages—rice, vegetables, meat; depends mostly on
imports for food requirements
Major industries: textiles, fireworks
Electric power: 70,000 kW capacity (1975); 175
million kWh produced (1975), 700 kWh per capita
Exports: $127 million (f.0.b., 1975); textiles and
clothing, foodstuffs
Imports: $147 million (c.i.f., 1975)
Major trade partners: exports—21% France, 14%
West Germany, 10% Hong Kong, 9% Portugal and
Portuguese colonies; imports—71% Hong Kong, 19%
China (1975)
Monetary conversion rate: 5.4 patacas = US$1
(December 1975)
Fiscal year: calendar year','0e537185da8b7c45b86af2599266e3a42674f732f5aae65df7f513e981c59c8a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6756f10c4b6557e2200e22fe96c4d8053738190e98e911bbf4543a794899cd7c',1977,'MG','Madagascar','economy',321,'GDP: $1.8 billion (1975), about $240 per capita;
real growth less than 1% (1970-75)
Agriculture: cash crops—coffee, vanilla, sugar,
tobacco, sisal, rice, cloves, raphia; food crops—rice,
cassava, cereals, potatoes, corn, beans, bananas,
coconuts, and peanuts, animal husbandry wide-
spread; imports some rice, milk, and cereal
Fishing: catch 63,900 metric tons (1974); exports
$14.6 million (1974)
Major industries: agricultural processing (meat
canneries, soap factories, brewery, tanneries, sugar
refining), light consumer goods industries (textiles,
glassware), cement plant, auto assembly plant, paper
mill, oil refinery
125
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MADAGASCAR/MALAWI
Electric power: 90,000 kW capacity (1975); 465
million kWh produced (1975), 62 kWh per capita
Exports: $330 million (f.0.b., 1975); 30% coffee,
8% vanilla, 7% sugar, 6% cloves; agricultural and
livestock products account for about 85% of export
earnings
Imports: $370 million (cif, 1975); consumer
goods about 19%, 21% footstuffs, 41% primary
products (crude oil, fertilizers, metal products), 19%
capital goods (1974)
Major trade partners: France (in 1974 accounted
for 87% of exports and 48% of imports), U.S., EC;
trade with Communist countries remains a minute
part of total trade
Budget: (FY75) revenues $450 million (including
$78 million projected borrowing), expenditures $450
million of which $324 million current, $126 million
development
Monetary conversion rate: 245 Malagasy
francs = US$1
Fiscal year: calendar year','5492ea910752bc656e043392fedf3683d9f1074aca68963926821d96485fd42d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51ec6d010a8d7ea9a800986322423257103c31410088dffa8ae7a702c79d12bb',1977,'MW','Malawi','economy',325,'GDP: $700 million (1975 est., in current prices),
$140 per capita; real growth rate 6.5% (1972-74)
Agriculture: cash crops—tobacco, tea, sugar,
peanuts, cotton, tung, maize; subsistence crops—
corn, sorghum, millet, pulses, root crops, fruit,
vegetables, rice
Electric power: 85,000 kW capacity (1975); 263
million kWh produced (1975), 50 kWh per capita
Major industries: agricultural processing (tea,
tobacco, sugar), sawmilling, cement, consumer goods
Exports: $135 million (f.0.b., 1975); tobacco, tea,
sugar, peanuts, cotton
Imports: $248 million (cif, 1975); manufactured
goods, machinery and transport equipment, building
and construction materials, fuel, fertilizer
Major trade partners: exports—U.K., other EEC,
Rhodesia, South Africa; imports—South Africa, U.K.,
Rhodesia, other EEC
Aid: economic—U.K. provides major development
support, about $144 million (1964-74); U.S. aid
commitments, $110 million (FY56-75); military—
U.K., $2.4 million (1954-68)
Budget: (FY75) $128 million
Monetary conversion rate: 1 Malawi kwacha=
US$1.09 (August 1976)
Fiscal year: 1 April - 81 March','fb19ece750248081e78479788e01bcffd687f7ee0237082a8743f719c7410def','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3b08f56c8c35ec1857333d4ce4f0c772ff32aebb46b98982631c755ff16f675',1977,'MY','Malaysia','economy',329,'GNP:
Malaysia: $8.1 billion (1975), $670 per capita;
average annual real growth (1968-75), 5.6%; (1975),
01%
Agriculture:
Peninsular Malaysia: natural rubber, rice, oil
palm; 10%-15% of rice requirements imported
Sabah: mainly subsistence; main crops—rubber,
timber, coconut, rice; food deficit—rice
Sarawak: main crops—rubber, timber, pepper;
food deficit—rice
Fishing: catch 496,900 metric tons (1974)
Major industries:
Peninsular Malaysia: rubber and oil palm
processing and manufacturing, light manufacturing
industry, tin mining and smelting, logging and
processing timber
Sabah: logging, petroleum production
Sarawak: agriculture processing, petroleum
production and refining, logging
Electric power:
Peninsular Malaysia: 1,085,000 kW capacity
(1975); 5.4 billion kWh produced (1975), 528 kWh
per capita
Sabah: 87,000 kW capacity (1975); 220 million
kWh produced (1975), 248 kWh per capita
Sarawak: 88,000 kW capacity (1975); 204
million kWh produced (1975), 174 kWh per capita
Exports: $3.6 billion (f.0.b., 1975); natural rubber,
palm oil, tin, timber, petroleum
Imports: $3.7 billion (c.i.f., 1975)
Major trade partners: exports—20% Singapore,
15% U.S., 14% Japan; imports—19% Japan, 11%
U.K., 11% U.S., 8% Singapore
Aid: economic—U.K. (1946-69) $260 million
disbursed; Japan (1966-68) $50 million extended;
IBRD (1959 - July 1974) $500 million (committed);
U.S. (1954-75) $121 million; military—(FY62-75) $64
million committed
Budget: 1976 revenues $2.1 billion; expenditures
$2.9 billion; deficit $800 million; 15% military, 85%
civilian
Monetary conversion rate: (Malaysia) 2.5
Malaysian dollars =US$1 (July 1976)
Fiscal year: calendar year','912aca1b159d28cd5a902571b0d4e76fd51451dab7d93a38f7a775f7b960e313','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a37b50a713c9d2f5ca46b9af737885c8b19a166cf587130227255a626462c155',1977,'MV','Maldives','economy',333,'GNP: under $100 per capita
Agriculture: crops—coconut and_shortages—rice,
wheat
Fishing: catch 37,500 metric tons (1974)
Major industries: fishing; some coconut processing
Electric power: 4,000 kW capacity (1975); 6
million kWh produced (1975), 45 kWh per capita
Exports: $2 million (f.0.b., 1973); fish
Imports: $3 million (c.i.f., 1973)
Major trade partner: Sri Lanka
Aid: U.K. (1960-65), $1.4 million drawn; Sri Lanka
(1967), $1 million committed; Japan and India
{amounts not known)
Fiscal year: calendar year
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MALDIVES/MALI
GDP: about $420 million (1975), $70 per capita;
annual real growth rate 2.1% (1972-75)
Agriculture: main crops—millet, sorghum, rice,
corn, peanuts; cash crops—peanuts, cotton, livestock
Fishing: catch 90,000 metric tons (1974)
Major industries: small local consumer goods and
processing
Electric power: 37,000 kW capacity (1975); 90
million kWh produced (1975), 15 kWh per capita
Exports: $60 million (f.0o.b., 1974); livestock,
peanuts, dried fish, cotton, skins
Imports: $183 million (cif., 1974); textiles,
vehicles, petroleum products, machinery, and sugar
Major trade partners: mostly with franc zone and
Western Europe; also with U.S.S.R., China
Budget: 1976 est. balanced at $110 million
131
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MALI/MALTA
Monetary conversion rate: 484.47 Mali francs=
US81, July 1976
Fiscal year: calendar year
GNP: $367 million (1975 est.), $1,140 per capita;
63% private consumption, 37% gross investment; real
growth has averaged about 7% per year in recent past,
in 1975 real growth was about 3.5% est.
Agriculture: overall, 20% self-sufficient; adequate
supplies of vegetables, poultry, milk and pork
products; shortages in beef, grain, animal fodder, and
fruits at various seasons; main products—potatoes,
cauliflowers, grapes, wheat, barley, tomatoes, citrus,
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MALTA/MARTINIQUE
cut flowers, green peppers, hogs, poultry, eggs; 2,680
calories per day per capita
Major industries: ship repair yard, building
industry, food manufacturing, textiles, tourism
Shortages: most consumer and industrial needs
(fuels and raw materials) must be imported
Electric power: 120,000 kW capacity (1975); 337
million kWh produced (1975), 1,150 kWh per capita
Exports: $168 million (f.0.b., 1975); textiles, scrap
metal, wine, agricultural products, and footwear
Imports: $362 million (c.i.f., 1975)
Major trade partners: 67% EC-nine (26% U.K.,
18% West Germany, 14% Italy); 10% Communist
countries; 5% U.S. (1975)
Aid: economic—U.S., $54 million (FY49-75), $10.1
million in 1974, and $9.5 million in 1975; Agreement
(loans and grants) (1964-74), $140 million; U.N.
Special Fund, $2.2 million through FY72; U.N.
Technical Assistance, $1.4 million through FY72;
China, $45 million (1972)
Budget: (1976/77) projects $252 million in
expenditures, $235 million in revenues
Monetary conversion rate: 1 Maltese pound=
US$2.67 (Smithsonian Agreement), December 1971;
the Maltese pound began floating in June 1972, with
the rate being determined between that of sterling and
that of the currencies of Malta’s major trading
partners; average trade conversion factor, year 1975: 1
Maltese pound = US$2.62
Fiscal year: 1 April - 31 March','423399e0be2bc88fb4a737b243c4d09ce12747adfe113b28601ce4c7e898c3e5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e378e79ab19768286c043031580f2eb5df33538876f8d6a336fb8fc3dc5894',1977,'MR','Mauritania','economy',338,'GDP: about $290 million (1975), $220 per capita,
average annual increase in current prices about 3.2%
(1971-78)
Agriculture: most Mauritanians are nomads or
subsistence farmers; main products—livestock,”
livestock, small grains, dates; cash crops—gum arabic;
livestock
Fishing: exports, 29,891 metric tons (1975)
Major industries: mining of iron ore and copper,
fishing
Electric power: 46,000 kW capacity (1975); 95
million kWh produced (1975), 70 kWh per capita
Exports: $168 million (f.0.b., 1975); iron ore, fish,
copper
Imports: $198 million (c.i.f., 1975); foodstuffs,
capital goods
Major trade partners: (trade figures not complete
because Mauritania has a form of customs union with
Senegal and much local trade unreported) France and
other EC members, U.K., and U.S. are main overseas
partners
Budget: 1976 est. $139 million total expenditures,
$11 million development expenditure included in
$139 million total, $149 million revenue
Monetary conversion rate: 45.90 Duguiya=US$1
as of July 1976 floating
Fiscal year: calendar year','14fdc6e2626c5ed9a1d6a7abdf6ac794543197cd751e3b4fa9528ac35480ce48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57e40848ea89882084e56197163324fba7cab5afb8bf227b321d7fed5d8d876c',1977,'MU','Mauritius','economy',343,'GNP: $380 million (1975), $430 per capita; real
growth (1970-75), 8%
Agriculture: sugar crop is major economic asset;
about 40% of land area is planted to sugar; most food
imported—rice is the staple food—and since
cultivation is already intense and expansion of
cultivable areas is unlikely, heavy reliance on food
imports except sugar and tea will continue
Shortage: land
Industries: mainly confined to processing
sugarcane, tea; some small-scale, simple manufac-
tures; tobacco fiber; some fishing; tourism, diamond
cutting, weaving and textiles, electronics
Electric power: 81,000 kW capacity (1975); 248
million kWh produced (1975), 280 kWh per capita
Exports: $305 million (f.0.b., 1975); mainly sugar,
tea, molasses
Imports: $330 million (c.i.f., 1975); foodstuffs 30%,
manufactured goods about 25%
Major trade partners: all EC-nine countries and
U.S. have preferential treatment, U.K. buys over 50%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MAURITIUS/MEXICO
of Mauritius’ sugar export at heavily subsidized
prices; small amount of sugar exported to Canada,
U.S., and Italy; imports from U.K. and EC primarily,
also from South Africa, Australia, and Burma; some
minor trade with China
Budget: revenues $172 million, current ex-
penditures $168 million, investment expenditure 365
million (1976)
Monetary conversion rate: 6.7 Mauritian
rupees = US$1 in August 1976 (floating with pound
sterling )
Fiscal year: 1 July - 30 June
Agriculture: cash crops—almost entirely sugar-
cane, small amounts of vanilla and perfume plants,
food crops—tropical fruit and vegetables, manioc,
bananas, corn, market garden produce, also some tea,
tobacco, and coffee; food crop inadequate, most food
needs imported
Major industries: 12 sugar processing mills, rum
distilling plants, cigarette factory, 2 tea plants, fruit
juice plant, canning factory, a slaughterhouse, and a
number of small shops producing handicraft items
Electric power: 75,000 kW capacity (1975); 185
million kWh produced (1975), 370 kWh per capita
Exports: $62 million (f.0.b., 1975), 90% sugar, 4%
perfume essences, 5% rum and molasses, 1% vanilla
and tea (1974)
Imports: $410 million (c.i.f., 1975); manufactured
goods, food, beverages, and tobacco, machinery and
transportation equipment, raw materials and
petroleum products
Major trade partners: France (in 1970 supplied
62% of Reunions imports, purchased 76% of its
exports); Mauritius (supplied 12% of imports)
Aid: French economic aid, $43.8 million 1974
Monetary conversion rate: about 224 Com-
munaute Financiere Africaine francs=US$1 as of
January 1976 (floating since February 1973)
Fiscal year: probably calendar year
GDP: $3.0 billion (1974), $490 per capita; real
growth rate, about 1% (1975)
Agriculture: main crops—tobacco, corn, sugar,
cotton; livestock; self-sufficient in foodstuffs except
wheat
Major industries: mining and steel, textiles
Electric power: 1,200,000 kW capacity (1975); 6.1
billion kWh produced (1975), 900 kWh per capita
Exports: $652 million (f.o.b., 1973), including net
gold sales and reexports; tobacco, asbestos, copper,
meat, chrome, gold, nickel, clothing, sugar
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
1 sith btn af
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
RHODESIA/ROMANIA
Imports: $541 million (c.i.f., 1973); machinery,
petroleum products, wheat, transport equipment
Major trade partners: South Africa, Portugal, and
Portuguese territories
Aid: no substantial military or economic aid
Budget: FY1976—revenues $678 million, expendi-
tures $895 million, deficit $217 million
Monetary conversion rate: 1 Rhodesian dol-
lar = US$1.54; 0.649 Rhodesian dollar=US$1
Fiscal year: 1 July - 30 June','416dd4e1921f88af08e0820fe8f4bc9380dd2f944916586192a8d7c5721b5123','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c5782b57b78ff77e483c9b4972a9358a3fa45b9ad6d2a77a5547633351388b1',1977,'US','United States','economy',347,'GDP: $78.6 billion (1975), $1,350 per capita; 74%
private consumption, 7% public consumption, 21%
domestic investment (1974 est.); net foreign balance
—2%; real growth rate 1975, 4% est.; real growth rate
1966/75, 6.3%
Agriculture: main crops—corn, cotton, wheat,
coffee, sugarcane, sorghum, oilseeds, pulses, and
vegetables; general self-sufficiency with minor
exceptions in meat and dairy products; caloric intake,
3,110 calories per day per capita (1968)
Fishing: catch 451,330 metric tons (1975); exports
valued at $104,126,000, imports at $16,784,000 (1974)
Major industries: processing of food, beverages,
and tobacco; chemicals, basic metals and metal
products, petroleum products, mining, textiles and
clothing, and transport equipment
Crude steel: 5.5 million metric tons capacity
(1975); 5.25 million metric tons produced (1975); 90
kg per capita
Electric power: 13,300,000 kW capacity (1975);
43.2 billion kWh produced (1975), 830 kWh per
capita
Exports: $3,309 million (f.0.b., 1975); cotton,
coffee, nonferrous minerals (including lead and zinc),
sugar, shrimp, petroleum, sulfur, salt, cattle and meat,
fresh fruit and tomatoes
Imports: $6,580 million (c.i.f£, 1975); machinery,
equipment, industrial vehicles, and intermediate
goods
Major trade partners: exports—60% U.S., 10%
EC, 4% Japan (1975); imports—62% U.S., 17% EC,
5% Japan
Aid: economic—extensions from U.S. (FY46-75),
$1,564 million in loans; $164.7 million in grants; from
international organizations (FY46-75), $3,357 million;
from other Western countries (1960-66), $122.7
million; military—assistance from U.S. (FY46-75),
$14 million
Budget: 1975 est. federal, revenues $8,246 million,
expenditures $11,610 million
Monetary conversion rate: floating, presently
being supported at 19.7 pesos=US81 (official)
Fiscal year: calendar year
138
GNP: $1,516 billion (1975); 64% private
consumption, 12% private investment, 24% govern-
ment; $7,100 per capita; 1975 growth rate —1.8%
(constant 1972 dollars)
Fishing: catch 2.2 million metric tons (1974),
valued at $898 million; imports $1,478 million, edible
products (1974); exports $195 million, edible products
(1974)
Crude steel: 106 million metric tons produced
(1975), 500 kg per capita
Electric power: 504,969,265 kW capacity (1975);
1,912 billion kWh produced (1975), 8,912 kWh per
capita est.
Exports: $107.6 billion (f.o.b., 1975); machinery
and transport equipment, chemicals, cereals, mineral
fuels
Imports: $103.4 billion (c.if., 1975); transport
equipment, machinery, mineral fuels, steel, nonfer-
rous metals, metal ores
Major trade partners: 21% Canada, 10% Japan,
5% West Germany, 4% U.K. (1975)
Official development assistance (aid): obligations
and loan authorizations (FY75), economic $7.7
billion, military $2.3 billion
Budget: National Accounts Basis, expenditures
$323.7 billion, revenues $287.6 billion
Fiscal year: 1 October - 30 September','a3d0c158012e3632adc035da841b9771abb6eaa23a7e510265c363c52064e514','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd82179f0772c07cbc08f91d49f56f15f078bf10361de03e2d3bcd311de92556',1977,'MC','Monaco','economy',351,'GNP: 55% tourism; 25%-30% industry (small and
primarily tourist oriented); 10%-15% registration fees
and sales of postage stamps; about 4% traceable to the
Monte Carlo casino
Major industries: chemicals, food processing,
precision instruments, glassmaking, printing
Electric power: 8,000 (standby) kW capacity
(1975); 80 million kWh supplied by France (1975),
2,000 kWh per capita
Trade: full customs integration with France, which
collects and rebates Monacan trade duties
Monetary conversion rate: 1 franc=US$0.2833','947d0fa64aa9b2029f07476e65cba11a3dc3926008b370b4168529420cfa055f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4071cd78604869b340ef34506117b67bd9eade364ce5fd07ed3f4cffb1ec7b57',1977,'MN','Mongolia','economy',355,'Agriculture: livestock raising predominates; main
crops—wheat, oats, barley
Industries: processing of animal products; building
materials; mining
Exports: beef for slaughter meat products, wool,
fluorspar, other minerals
Imports: machinery and equipment, petroleum,
clothing, building materials sugar, and tea
Major trade partners: nearly all trade with
Communist countries (approx. 80% with U.S.S.R.);
total turnover over $600 million (1974)
Aid: heavily dependent on U.S.S.R.
Monetary conversion rate: 3.31 tugriks=US$1
(arbitrarily established)
Fiscal year: calendar year','4957b3e028c4b4ed11098f16b782d95b574cf0ba548fdc3aed58cf6f00c8e715','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac5399b440806e82ea1d60104255516a0ae178cf5942afab4a850578df3c69f9',1977,'MA','Morocco','economy',359,'GNP: $6.9 billion (1975), almost $400 per capita;
average annual real growth 4% during 1970-73, 9% in
1974, and under 3% in 1975
Agriculture: cereal farming and livestock raising
predominate; main products—wheat, barley, citrus
fruit, wine, vegetables, olives; some fishing
Fishing: catch 288,142 metric tons (1974); exports
$78.8 million (1974)
Major sectors: mining and mineral processing
(phosphates, smaller quantities of iron, manganese,
lead, zinc, and other minerals), food processing,
textiles, construction and tourism
Electric power: 795,000 kW capacity (1975); 2.8
billion kWh produced (1975), 158 kWh per capita
Exports: $1,540 million (f.0.b., 1975); 55%
phosphates, 25% agricultural goods, 20% other
Imports: $2,570 million (c.i., 1975); 42% raw
material and semi-finished goods, 24% food, 20%
equipment, 14% consumer goods
Major trade partners: exports—32% France, 8%
West Germany, 8% Italy, 7% Benelux, 2% U.K.;
imports—31% France, 8%-U.S., 7% West Germany,
6% Italy (1972)
Monetary conversion rate: 4.51 dirhams=US$1
Fiscal year: calendar year','3a6297e2bc96c2bd6d9402a5811539c7ad41d57302b37bada7b74728ef3e787c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90bcc6549a570d839d72e2145554f290b7888c14e3aff6a79f42983cf45dd5dc',1977,'MZ','Mozambique','economy',363,'GNP: $2.3 billion (1972), about $250 per capita;
average annual growth probably negative in 1975-76
Agriculture: cash crops—raw cotton, cashew nuts,
sugar, tea, copra, sisal; other crops—corn, wheat,
peanuts, potatoes, beans, sorghum, and cassava; self-
sufficient in food except for wheat which must be
imported
Major industries: food processing (chiefly sugar,
tea, wheat, flour, cashew kernels); chemicals
(vegetable oil, oilcakes, soap, paints); petroleum
products; beverages; textiles; nonmetallic mineral
products (cement, glass, asbestos, cement products);
tobacco
Electric power: 440,000 kW capacity (1975); 588
million kWh produced (1975), 66 kWh per capita
Exports: $302 million (f.0.b., 1974 prelim. ); cashew
nuts, cotton, sugar, mineral products, timber
products, tea, copra, petroleum products
Imports: $470 million (f.0.b., 1974 prelim.);
machinery and electrical equipment, cotton textiles,
vehicles, petroleum products, wine, iron and steel
Major trade partners: over one-third of foreign
trade with Portugal; South Africa, U.S., U.K., West','0fcf59481e9b237115c3231f5a7a3e21b7e0914e6a6c131586692d130a87f95a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0a1a64fe299604d3a629e0e9b9a101a0230ef37a180715decbc93b0bcd765a4',1977,'DE','Germany','economy',364,'Aid: mainly from Portugal
Budget: (FY76) expenditures, $310 million,
revenues, $237 million
Monetary conversion rate: 31.39 escudos = US$1 as
of July 1976; plans to issue Mozambique currency
soon
Fiscal year: calendar year
Budget: expenditures, FY77—current expenditures,
$1,631 million; capital expenditures, $1,435 million
Monetary conversion rate: 9.9 rupees=US$1
(since February 1973)
Fiscal year: 1 July - 30 June
Aid: economic—U.S. (FY61-75), $685 million;
(1971 estimated disbursements) Belgium, $31.4
million; France, $6.6 million; other bilateral aid $5.4
million; U.N., $9.4 million; EC, $18.9 million; China
(1973), $100 million; military—U.S., $61 million
(FY62-75); IMF, $155 million (1976)
Budget: 1976 proposed—revenue and expenditures,
$720 million
Monetary conversion rate: 1 zaire=US$1.17
Fiscal year: calendar year','d949aeef79e8ae4af6f6326003a39b82ce8077bc1694ce8fca5de150b70d9343','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f86c231e349bf81d33a10acf3fd645ce27d672bb55f81749b086dd9d89ae4740',1977,'PT','Portugal','economy',369,'GNP: over $120 million (1975), $17,140 per capita
(est. )
Agriculture: negligible; almost completely
dependent on imports for food, water
Major industries: mining of phosphates, about 2
million tons per year
Electric power: 9,000 kW capacity (1975); 24
million kWh produced (1975), 3,429 kWh per capita
Exports: $120 million (f.0.b., 1975 est.); consisting
entirely of phosphates
Imports: $5 million (c.i.f., FY70)
Major trade partners: exports—75% Australia and
New Zealand; imports—Australia, U.K., New
Zealand, Japan
Monetary conversion rate: 1 Australian dol-
lar = US$1.2375 (July 1976)
Fiscal year: 1 July - 80 June
GNP: $14.8 billion est. (1975, in 1975 prices); 16%
government consumption, 85% private consumption;
—3% change in stocks, 14% gross fixed investment,
—12% net foreign trade growth rate, 7% average
(1969-73, 1968 base), 2.5% est. (1974), —10% est.
(1975)
Agriculture: generally undérdeveloped; main
crops—grains, potatoes, olives, grapes for wine; deficit
foods—sugar, grain, meat, fish, oil seeds; caloric
intake, 2,730 calories per day per capita (1969)
Fishing: landed 427,981 metric tons
Major industries: textiles and footwear; wood
pulp, paper, and cork; metalworking; oil refining;
chemicals; fish canning; wine
Shortages: coal, petroleum, cotton, steel
Crude steel: 385,000 est. metric tons produced
(1975), 40 kg per capita
Electric power: 3,793,000 kW capacity (1975);
10.4 billion kWh produced (1975), 1,100 kWh per
capita
Approved For Release 2005/04/22 :
Exports: $1,931 million (f.0.b., 1975); principal
items—cotton textiles, cork and cork products, canned
fish, wine, timber and timber products, resin
Imports: $3,819 million (cif, 1975); principal
items—petroleum, cotton, industrial machinery, iron
and steel, chemicals
Major trade partners: 44% EC (18% U.K., 11% W.
Germany, 7% France, 4% Italy); 11% EFTA, 11%
U.S., 4% Spain, 4% Iraq, 3% Japan, 2% Communist
countries (1975)
Aid: economic—U.S., $290 million (FY49-75);
military—U.S., $346 million (FY1949-75)
Budget: 1975—receipts, $2.28 billion, expendi-
tures, $3.42 billion (converted at 1975 average
exchange rate); 1976—receipts, $2.59 billion,
expenditures, $4.14 billion (converted at 1 es-
cudo= US$0.0333)
Monetary conversion rate: 1 escudo = US$0.0391
(1975 average); 1 escudo = US$0.0822 (September 30,
1976)
Fiscal year: calendar year','e6ce11890a57c2d7a39fae3d0b8584f5d2d011ad321725904428bc5c4188b36a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77185a85c8c8c25d078eebe531db6f4e36eaa9202426c031c7b065bcfd0402d0',1977,'NP','Nepal','economy',373,'GDP: $1,398 million (FY75, at current prices), $110
per capita; 2.5% real growth in FY75
Agriculture: over 90% of population engaged in
agriculture; main crops—rice, corn, wheat, sugarcane,
oilseeds
Major industries: small rice, jute, sugar, and
oilseed mills; match, cigarette, and brick factories
Electric power: 57,000 kW capacity (1975); 130
million kWh produced (1975), 10 kWh per capita
Exports: $85.8 million est. (FY75); rice and other
food products, jute, timber
Imports: $170.8 million est. (FY75); manufactured
consumer goods, fuel, construction materials, food
products
Major trade partner: over 80% India
Aid: economic—$35 million disbursements (FY75);
principal donors: India, U.S., China, international
agencies
Budget: (FY76 est.) domestic revenue $94.6
million, expenditure $158.5 million
Monetary conversion rate: 12.5 Nepalese
rupees = US$1 (October 1975)
Fiscal year: 15 July - 14 July','4fadeb21dbe733910e1fe8b36c44156f106211812c954f7b415d7a6ca13668ad','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92951297ffcad84a97345278273472e3f8c0fde3295de66ad437360fcfb3604f',1977,'NZ','New Zealand','economy',379,'GNP: $11.7 billion (1974), $3,870 per capita; real
average annual growth (1969-74) 3.8%
Agriculture: fodder and silage crops about one-half
of area planted in field crops; main products—wool,
meat, dairy products; New Zealand is food surplus
150
country; caloric intake, 3,500 calories per day per
capita (1964)
Fishing: catch 69,100 metric tons (1974)
Major industries: food processing, textile
production, machinery, transport equipment; wood
and paper products
Electric power: 4,900,000 kW capacity (1975);
19.7 billion kWh produced (1975), 6,254 kWh per
capita
Exports: $2.1 billion including re-exports (f.0.b.,
trade year 1975); principal products (trade year
1975)—27% meat, 17% dairy products, 15% wool
Imports: $3.7 billion (c.i.f., trade year 1975); 29%
machinery, 23% manufactured goods, 11% chemicals
(trade year 1975)
Major trade partners: (trade year 1975) exports—
22% U.K., 12% U.S., 12% Japan, 11% Australia;
imports—19% Australia, 19% U.K., 14% Japan, 18%
US.
Aid: gross official aid deliveries to LDC and
multilateral agencies FY75, $80.1 million
Budget: expenditures, 3,827 million NZ$, receipts,
3,330 million NZ$ (FY75)
Monetary conversion rate: NZ$1=US$0.9947,
July 1976
Fiscal year: 1 April - 31 March
NOTE: trade data are for year ending 30 June
1975; trade year and fiscal year do not correspond','2906b93db6d5f71efad28a322e723d999399a008c22056f25ec122b75d54d07f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f73154279bf164e2aa11276fc87079890be489b38c587effa5fe59ed2320d171',1977,'NI','Nicaragua','economy',383,'GDP: $1,591 million (1975 est.), $740 per capita;
75% private consumption, 9% government consump-
tion, 29% domestic investment, —13% net foreign
balance (1974); real growth rate 1975, 2.1% est.
Agriculture: main crops—cotton, coffee, sugar-
cane, rice, corn, beans, cattle; caloric intake, 2,300
calories per day per capita (1966)
Fishing: catch 16,700 metric tons (1974); exports
valued at $14.8 million (1975)
Major industries: food processing, chemicals,
metal products, textiles and clothing
Electric power: 280,000 kW capacity (1975); 810
million kWh produced (1975), 410 kWh per capita
Exports: $375 million (f.0.b., 1975); cotton, coffee,
chemical products, meat, sugar
Imports: $517 million (c.i.f., 1975); food and non-
food agricultural products, chemicals and phar-
151
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NICARAGUA/NIGER
maceuticals, transportation equipment, machinery,
construction materials, clothing, petroleum
Major trade partners: exports—27% U.S., 25%
CACM, 48% other; imports—32% U.S., 22% CACM,
46% other (1975)
Aid: economic—extensions from U.S. (FY46-75),
$191 million loans, $84 million grants; international
organizations (FY46-73), $266 million; military—
from U.S. (FY46-73), $26 million
Monetary conversion rate: 7 cordobas=US$1
(official)
Fiscal year: calendar year','20c4a77f1d76a391b1be93da8ef17812ca38d93bbc75a64415c18ef662ef8952','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e462e816514806194bc0bd6517a2b862789d46a282fbd3cdd45e8d6ca5f4a68b',1977,'NE','Niger','economy',387,'GDP: $454 million (1975 est.), $100 per capita
Agriculture: commercial—peanuts, cotton, live-
stock; main food crops—millet, sorghum, niebe beans,
vegetables
Major industries: cement plant, brick factory, rice
mill, small cotton gins, oil presses, slaughterhouse, and
a few other small light industries; uranium production
began in 1971
Electric power: 18,000 kW capacity (1975); 55
million kWh produced (1975), 10 kWh per capita
Exports: $126 million (est. f.o.b., 1975); about 60%
peanuts and related products, rest largely livestock,
hides, skins; exports understated because much
regional trade not recorded
Imports: $188 million (est. cif, 1975); fuels,
machinery, transport equipment, foodstuffs, consum-
er goods (largely for European residents)
Major trade partners: France (over 50% ), other EC
countries, Nigeria, UDEAC countries, U.S.;
preferential tariff to EC and franc zone countries
Aid: economic—France (1960 to mid-1967), $68
million; EC (FY61-73), $100 million; U.S. (FY61-75),
$59 million; West Germany, Israel, Republic of
China, and U.N. have also extended aid; military—
of $2.8 million (1954-68)
Budget: projected to balance at about $108 million
(1976)
Monetary conversion rate: about 248.22 Com-
munaute Financiere Africaine=US$1 as of August
1976, floating
Fiscal year: 1 October - 30 September','793ad6ad1381f4729b58bd8e40c91ad873e4b152c8642bd457d7ac4c56b3f2ca','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('728acc194d12c505f3ba88773fd36abc785bdd575e5dccd74e72c3db9c82e9a4',1977,'NG','Nigeria','economy',391,'GDP: $26 billion (1975 current prices), $365 per
capita; 6.7% growth rate (1970-75)
Agriculture: main crops—peanuts, cotton, cocoa,
rubber, yams, cassava, sorghum, palm kernels, millet,
corn, rice; livestock; almost self-sufficient
Fishing: catch 684,906 metric tons (1974); imports
$10.7 million (1973)
Major industries: mining—crude oil, natural gas,
coal, tin, columbite; processing industries—oil palm
peanut, cotton, rubber, petroleum, wood, hides, skins;
manufacturing industries—textiles, cement, building
materials, food products, footwear, chemical,
printing, ceramics
Electric power: 1,127,000 kW capacity (1975); 3.0
billion kWh produced (1975), 47 kWh per capita
Exports: $8.0 billion (f.0.b., 1975); oil (98%),
cocoa, palm products, rubber, timber, tin
Imports: $5.3 billion (c.i.f., 1975); machinery and
transport equipment, manufactured goods, chemicals
Major trade partners: U.K., EC, U.S.
Budget: FY76-77 proposed—current revenue $9.1
million, current and capital expenditures $8.8 billion
Monetary conversion rate: 1 Naira=US$1.60
(official)
Fiscal year: 1 April - 31 March
154','5bbc999445b0b46eb91ad765c7de1cd742cdac761b0bb4beae6c612e01ff9297','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd68f6a7a54476dc7f2b27d13c2be22484f922e0edb47395688418a546b4d0f6',1977,'NO','Norway','economy',395,'GNP: $24.6 billion in 1975 (at 1974 prices), $6,130
per capita; 52.38% private consumption; 33.8%
investment; 16.5% government; net foreign balance
—2.6%; 1975 growth rate 5.1%, in constant prices
Agriculture: animal husbandry predominates;
main crops—feed grains, potatoes, fruits, vegetables;
40% self-sufficient, food shortages—food grains,
sugar; caloric intake, 2,940 calories per day per capita
(1969-70)
Fishing: catch 2.3 million metric tons (1975); value
$343 million (1975); exports $397 million
Major industries: food processing, shipbuilding,
wood pulp, paper products, metals, chemicals
Shortages: most raw materials with the exception of
timber, petroleum, iron, copper, and ilmenite ore,
dairy products and fish
Crude steel: 914,000 metric tons produced (1975),
230 kg per capita
Electric power: 16,580,000 kW capacity (1975); 78
billion kWh produced (1975), 17,000 kWh per capita
Exports: $7,265 million (f.0.b., 1975); principal
items—metals, pulp and paper, fish products, ships,
chemicals, oil
Imports: $9,719 million (cif., 1975); principal
items—foodstuff, ships, fuels, motor vehicles, iron and
steel, chemical compounds, textiles
Major trade partners: 47.1% EC (15.8% U.K.,
13.2% West Germany, 6.4% Denmark); 17.8%
Sweden; 6.6% U.S.; 4.0% Sino-Soviet countries (1975)
Aid: economic—U.S., $707 million authorized
(FY46-75); IBRD, $145 million authorized through
1975, none since 1964; net official economic aid
delivered to less developed areas and multilateral
agencies, $134.2 million (1960-69), $36.8 million
(1970); $42.4 million (1971), $63 million (1972), $87
million (1973), $183 million (1974), $174 million
155
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NORWAY/OMAN
(1975), $232 million (proposed for 1976); military—
U.S., $944 million authorized (FY46-75)
Budget: (1976) revenues $7.4 billion, expenditures
$8.9 billion
Monetary conversion rate: 1 kroner=US$0.1914
(1975)
Fiscal year: calendar year','f10dec35dfed6cd9ec2db8b9f28450969917c05bdd8963009df2dfb9af6ce9b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6236e9b930d19f434c430e6436252394e6f846ff0d9f2bf46dfdfd15b12e315',1977,'OM','Oman','economy',399,'GNP: $900 million (1974 est.), $1,840 per capita
est.
Agriculture: based on subsistence farming (fruits,
dates, cereals, cattle, camels), fishing, and trade
Major industries: petroleum discovery in 1964;
production began in 1967; production 1975, 340,000
b/d; pipeline capacity, 400,000 b/d; revenue for 1975
est. at $1.1 billion
Electric power: 65,000 kW capacity (1975); 185
million kWh produced (1975), 365 kWh per capita
Exports: mostly petroleum; non-oil exports (mostly
agricultural), $3 million (1975)
Imports: $675.7 million (1975)
Major trade partners: U.K., U.S., other European,
Gulf states, India, Australia, China, Japan
Aid: bilateral assistance pledged, $134 million in
1974, IBRD $8 million; aid commitment by Oman,
$39 million to miltilateral institutions
Budget: (1976 projected) revenues $1.754 billion,
expenditures $1.857 billion
Monetary conversion rate: 1 Riyal Omani=
US$2:90 (as of October 1973)
Fiscal year: calendar year','2882c0bb983532b3ed666a272702ae6e346e60a1100e8ed4a81c259430536a87','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09c5a1bbb2de9890301057ae17eb05b1f464e7149871612efbba84cd08a106f5',1977,'PK','Pakistan','economy',403,'GDP: $12.2 billion (FY76) at exchange rate of 9.9
rupees = US$1 prevailing June 1978, $170 per capita;
real growth, 5% (FY76)
Agriculture: extensive irrigation; main crops—
wheat and cotton; foodgrain shortage, 1.5 million tons
imported in FY75
Fishing: catch 184,100 metric tons (1975)
Major industries: cotton textiles, food processing,
tobacco, engineering, chemicals, natural gas
Electric power: 2,730,000 kW capacity (1975);
11.5 billion kWh produced (1975), 158 kWh per
capita
Exports: $1,047 million (f.0.b., FY75); cotton (raw
and manufactured), rice
Imports: $2,140 million (c.i.f., FY75); wheat, crude
oil, machinery, transport equipment, chemicals
Major trade partners: U.S., U.K., Japan, West','4276449fa718bf1d6560ccbe9e115b338d7ad801e85809cf3589900e6c18184a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a21eaf3a3bb330ff7b9d5f1e264dfe5a7abd97e9a350129a2f5959036d7009b7',1977,'PA','Panama','economy',407,'GNP: $1,650 million (1974 est.), $1,020 per capita;
75% private consumption, 16% government con-
sumption, 25% gross fixed investment, —16% net
foreign balance (1974); real growth (1975), 1.7%
Agriculture: main crops—bananas, rice, corn,
coffee, sugarcane; self-sufficient in most basic foods;
2,450 calories per day per capita (1969)
Fishing: catch 66,000 metric tons (1974); exports
$22.3 million (1973); imports $1.7 million (1973)
Major industries: food processing, metal products,
construction materials, petroleum products, clothing,
furniture
Electric power (including Canal Zone): 480,000
kW capacity (1975); 2 billion kWh produced (1975),
800 kWh per capita
Exports: $278 million (f.0.b., 1975); bananas,
petroleum products, shrimp, sugar, meat, coffee
Imports: $795 million (f.0.b., 1975); manufactures,
transportation equipment, crude petroleum, chemi-
cals, foodstuffs
Major trade partners: exports—49% U.S., 16%
Canal Zone, 6% West Germany, 5% Italy; imports—
26% U.S., 18% Ecuador, 11% Venezuela, 8% Colon
Free Zone, 8% Saudi Arabia (1974)
Aid: economic—from U.S. (FY46-75), $237 million
loans, $171 million grants; from international
organizations (FY46-75), $266 million; from other
Western countries (1960-71), $28.9 million; mili-
tary—assistance from U.S. (FY46-75), $9 million
Monetary conversion rate: 1 balboa=US$1
(official)
Fiscal year: calendar year','6f9efb8870856b7af864941b88247ee1bd657dd77d39d52f8841f4905ea28803','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afe2074c026290f05857c6a56664d35f8cca79934be0452d6e700a860f0a67c1',1977,'PG','Papua New Guinea','economy',411,'GNP: $1.5 billion (FY74 est.); real average annual
growth rate (1969-74) 7% est.
Agriculture: main crops—coconuts, coffee, cocoa,
tea
Major industries: sawmilling and timber process-
ing, copper mining (Bougainville)
Electric power: 285,000 kW capacity (1975); 650
million kWh produced (1975), 239 kWh per capita
Exports: $721 million (f.0.b., FY74); principal
products—copper, coconut products, coffee beans,
timber
Imports: $365 million (f.0.b., FY74)
Major trade partners: Australia, U.K., Japan
Aid: economic—Australia, $1,158 million commit-
ted (1976-81); World Bank group (1968-September
1969), $7.5 million committed; U.S. (FY70-74), $32.5
million extended
Budget: (75-76) receipts 400 Australian dollars,
expenditures 408 Australian dollars
Monetary conversion rate: Kina $1=A$1
Fiscal year: 1 July - 30 June','e19d88c7bb2ff228484a3ef32d8bf7b902e84ce9fd40805ff688c54ac1422c78','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6672a339c963b5534e260f8d4ee86a9bed4a1ff10984a666f3d208ee73842889',1977,'PY','Paraguay','economy',415,'GDP: $1.5 billion (1975, at current prices), $590
per capita; 82% consumption; 18% gross domestic
investment (1975); real growth rate 1975, 5.0%
Agriculture: main crops—oilseeds, cotton, wheat,
manioc, sweet potatoes, tobacco, corn, rice,
sugarcane; self-sufficient in most foods; caloric intake,
2,580 calories per day per capita (1963-64); protein
intake, 70 grams per day per capita (20 grams of
animal origin)
Major industries: meat packing, oilseed crushing,
milling, brewing, textiles, light consumer goods,
cement
Electric power: 280,000 kW capacity (1975); 500
million kWh produced (1975), 200 kWh per capita
Exports: $176.4 million (f.0.b., 1975); meat,
timber, oilseeds, tobacco, cotton, quebracho extract,
hides, yerba mate, coffee
161
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
PARAGUAY/PERU
Imports: $227.3 million (f.0.b., 1975); foodstuffs,
machinery, transport equipment, fuels and lubricants,
textiles, chemicals
Major trade partners: 21% Argentina, 11% Brazil,
9% U.S., 9% West Germany, 9% U.K.
Aid: economic assistance—extensions from U.S.
(FY46-75), $96.4 million loans, $73.2 million grants;
from international organizations (FY46-75), $288.7
million; from other Western countries (1960-70),
$21.9 million; military—assistance from U.S. (FY57-
75), $26.4 million
Monetary conversion rate: 126 guaranies=US$1
(official rate, June 1976)
Fiscal year: calendar year','828dce8e5fec3b96d4c825e531c062b304cbc482f9c5fdac721649358a088b73','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('913a1cc9e397a4ea2f9bfba226b348f26a15e2280c742cb49eb07144c0aa0c78',1977,'PE','Peru','economy',419,'GNP: $12.7 billion (1975, in current prices), $800
per capita; 75% private consumption, 11% public
consumption, 15% gross investment; —1% net foreign
balance (1975); real growth rate (1975), 4%
Agriculture: main crops—wheat, potatoes, beans,
tice, barley, coffee, cotton, sugarcane; imports—
wheat, meat, lard and oils, rice, corn; caloric intake,
2,300 calories per day per capita (1964)
Fishing: catch 3.1 million metric tons (1975);
exports $203 million (1975)
Major industries: mining of metals, petroleum,
fishing, textiles and clothing, food processing, cement,
auto assembly, steel, ship-building, metal fabrication
Electric power: 2,413,000 kW capacity (1975); 7.7
billion kWh produced (1975), 517 kWh per capita
Exports: $1,378 million (f.0.b., 1975); fish and fish
products, copper, silver, iron, cotton, sugar, lead, zinc,
petroleum, coffee
Imports: $2,491 million (1975); foodstuffs,
machinery, transport equipment, iron and_ steel
semimanufactures, chemicals, pharmaceuticals
Major trade partners: exports—24% U.S., 19%
Latin America, 17% EC, 11% Japan, 10% U.S.S.R.
(1975); imports—31% U.S., 28% EC, 17% Latin
America, 12% Japan (1974)
Aid: economic—extensions from U.S. (FY46-75),
$681 million loans, $232 million grants; from
international organizations (FY46-75), $680 million;
from other Western countries (1960-72), $136.1
million; from Communist countries (1969-75), $268
million; military—assistance from U.S. (FY49-75),
$194 million; from Communist countries (1974), $183
million
Budget: (1975) $1.9 billion current revenues, $3.0
billion total expenditures including debt amortization
Monetary conversion rate: 65.74 soles=US$1
(October 1, 1976)
Fiscal year: calendar year','8674c31e8e5c1e8c5384676466de5afed6ef1842c84d1e603c93ab9cae47f7e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af97da47d41762a6c9a84fed907a98d9256a527e1c80ed19ed85c15d568edba4',1977,'PH','Philippines','economy',420,'GNP: $15.8 billion (1975), $370 per capita; 5.9%
real growth, 1975
Agriculture: main crops—rice, corn, coconut,
sugarcane, bananas, abaca, tobacco
Fishing: catch 1.8 million metric tons (1974)
Major industries: mining, agricultural processing,
textiles, chemicals and chemical products
Electric power: 3,450,000 kW capacity (1975);
12.5 billion kWh produced (1975), 284 kWh per
capita
Exports: $2,275 million (fob. 1975); sugar,
coconut products, logs and lumber, copper
concentrates, abaca
Imports: $3,350 million (f.0.b., 1975); petroleum,
industrial equipment, wheat
Major trade partners: (1975) exports—29% U.S.,
89% Japan; imports—28% Japan, 23% U.S.
Aid: economic—U.S. (FY46-75), $2.27 billion
committed; Japan (CY70-74), $266 million Commit-
ted; IBRD/IDA (CY66-74), $466 committed; mili-
tary—U.S. (FY46-74), $735 million committed
Budget: (FY75-76) revenues $2.1 billion, expend-
itures $2.5 billion, deficit $0.4 billion; 11% military,
84% civilian
Monetary conversion rate: 7.43 pesos=US$1,
August 1976
Fiscal year: 1 July - 30 June','046bd49a72f399c51d43f4d3d09e3ceba64820644c7105ae044154ecef9d9e48','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1c477593b9bf125c78b3dcb21a9e9063ba328a9af314df327b899ce14d60b9b',1977,'PL','Poland','economy',424,'GNP: $89.9 billion in 1975, at 1975 prices, $2,640
per capita, 1975 growth rate, 6.4%
Agriculture: self-sufficient for minimum require-
ments; main crops—grain, sugar beets, oilseeds,
potatoes, exporter of livestock products and sugar;
importer of grains; 3,200 calories per day per capita
(1970)
Fishing: catch 645,500 metric tons (1975)
Major industries: machine building, iron and steel,
extractive industries, chemicals, shipbuilding, and
food processing
Crude steel: 15 million metric tons produced
(1975), about 440 kg. per capita
Electric power: 20,300,000 kW kw. capacity
(1975); 97.1 billion kWh produced (1975), 2,840 kWh
per capita
Exports: $10,289 million (f.0.b., 1975); 41%
machinery and equipment, 39% fuels, raw materials,
and semimanufactures, 10% agricultural and food
products, 9% light industrial products
Imports: $12,545 million (f.0.b., 1975); 41%
machinery and equipment; 42% fuels, raw materials,
165
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
POLAND/PORTUGAL
and semimanufactures; 11% agricultural and food
products; 4% light industrial products
Major trade partners: $22,736 million (1975); 52%
with Communist countries, 48% with West
Monetary conversion rate: 3.32 zlotys=US$1
(commercial); 19.92 zlotys=US$1 (noncommercial)
Fiscal year: same as calendar year; economic data
are reported for calendar years except for caloric
intake which is reported for the consumption year, 1
July - 30 June','a2c710b65eee19e1fc0538df1bda10baf4f6b67e60a1c5aab026ea9bdc9f7922','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34be98658f835920c605a2d1d68cfd9b4d34b3a9314388bbcc7ec574a31bfde0',1977,'QA','Qatar','economy',428,'GNP: $1.8 billion (1975), $9,700 per capita
Agriculture: farming and grazing on small scale;
commercial fishing increasing in importance; most
food imported; rice and dates staple diet
Major industries: oil production and refining;
crude oil production from onshore and offshore
averaged 520,000 b/d (August 1976); 100% takeover
was announced in October 1976 of the Qatar
Petroleum Company, still netogiating with Qatar
Shell about offshore fields; oil revenues accrued $2
billion in 1976, representing 95% of govern-
ment/royal family income; major development
projects include $7 million harbor at Ad Dawhah,
fertilizer plant, 2 desalting plants, refrigerated storage
for fishing, and a cement plant
Electric power: capacity 200,000 kW (1975); 550
million kWh produced (1975), 2,820 kWh per capita
Exports: crude oil dominates; non-oil exports $34.7
million (1974 est.)
Imports: $402 million (1975)
Aid: aid donor, pledged $450 million 1974,
disbursed $200 million
Budget: (1976) budgeted expenditures $986 million
Monetary conversion rate: 1 Qatar-Dubai
tiyal = US$0.26 (through October 1976)
Fiscal year: 1 April - 81 March','f384fcb84d7ba972e345629deb6df2b2e7176fdfedba6f9fe7e57a1448497c35','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be5e76aa05af183ee8159f279a1d5b70c49b21cdf0733e90d9893ba7fe2a8c3b',1977,'RO','Romania','economy',432,'GNP: $51.4 billion (1975, in 1975 prices), $2,420
per capita; real growth rate, 8.7% (1971-75)
Agriculture: net exporter; main crops—corn,
wheat, oilseed; livestock—cattle, hogs, sheep; caloric
intake, 3,000 calories per day per capita (1967-68)
Fish catch: 129,300 metric tons (1974)
Major industries: machinery, metals, fuels,
chemicals, textiles, food processing, timber processing
Shortages: iron ore, coking coal, metallurgical
coke, cotton fibers, natural rubber
Crude steel: 9.5 million metric tons produced
(1975), 450 kg per capita
Electric power: 11,500,000 kW capacity (1975);
53.7 billion kWh produced (1975), 2,515 kWh per
capita
Exports: $5.3 billion (f.0.b., 1975); 43% fuels, raw
materials, semifinished products; 21% machinery and
equipment; 20% foodstuffs; and 16% consumer goods
(1974)
Imports: $5.3 billion (mixture f.o.b. and cif,
1975); 34% machinery and equipment; 54% fuels,
raw materials, semifinished products; 8% foodstuffs;
and 4% consumer goods (1974)
Major trade partners: $10.6 billion in 1975; 58%
non-Communist countries, 42% Communist countries
(1974)
Monetary conversion rate: 4.97 lei = US$1
(commercial) 12 lei=US$1 (tourist)
Fiscal year: same as calendar year; economic data
reported for calendar years except for caloric intake,
which is reported for consumption year, 1 July - 30
June','ec994295baa2fe4cd6dea8075bf33287bb246c0083e73399231b55873029de5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdd21d99727f6a327dc49cacbce40347666a7171a7cee5e17d976a368ec5b4c6',1977,'RW','Rwanda','economy',436,'GDP: $301 million (1974), $70 per capita
Agriculture: cash crops—mainly coffee, tea,
cotton, some pyrethrum; main food crops—bananas,
cassava; stock raising; self-sufficiency increasing but
country still imports some foodstuffs
Major industries: mining of cassiterite (tin ore),
agricultural processing, and light consumer goods
Electric power: 25,000 kW capacity (1975); 35
million kWh produced (1975), 8 kWh per capita
Exports: $37 million (f.0.b., 1974); mainly coffee,
tea, pyrethrum, cassiterite
Imports: $58 million (c.i.f.,
foodstuffs, machines, equipment
Major trade partners: U.S., Belgium, West
Germany, Kenya
Aid: external aid amounted to $52 million in 1974
with Belgium providing about 30% of this amount,
the European Development Fund 15%, and World
Bank about 15%; other donors include France,
Canada, Germany, U.S., Romania, Yugoslavia,
Kuwait, Abu Dhabi, and PRC
Budget: balanced at $45 million (FY75)
Monetary conversion rate: 92.84 Rwanda
francs = US$1 (official) since January 1974
Fiscal year: calendar year','c3ed123d6bcc2cf30466370c28915730608e003c896e3de696f6bb8871fcbd78','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae4c1a895b125d7df501d6cba44d90717e97b6fa50b9c51b4c20fb737f3217a5',1977,'AI','Anguilla','economy',440,'GDP: $14.7 million (1970), $210 per capita
Agriculture: main crops—sugar on St. Christopher,
cotton on Nevis
Major industries: sugar processing, salt extraction
Electric power: 14,500 kW capacity (1975); 32
million kWh produced (1975), 550 kWh per capita
Exports: $6.8 million (f.o.b., 1973); sugar,
molasses, cotton, salt, copra
Imports: $12.0 million (c.i.f., 1973); foodstuffs,
fuel, manufactures
Major trade partners: exports—50% U.S., 35%
U.K.; imports—21% U.K., 17% Japan, 11% USS.
(1978)
Monetary conversion rate: 2.70 East Caribbean
dollars = US$1 (July 1976)
GDP: $33.2 million (1973 est.), $300 per capita,
real growth rate 1973, negligible
Agriculture: main crops—bananas, copra, sugar,
cocoa, spices
Major industries: tourism, lime processing
Shortages: food, machinery, capital goods
Electric power: 14,000 kW capacity (1975); 40
million kWh produced (1975), 400 kWh per capita
Exports: $17 million (f.0.b., 1975); sugar, bananas,
cocoa
Imports: $49 million (c.if., 1975); foodstuffs,
machinery and equipment, fertilizers, petroleum
products
Major trade partners: 51% U.K., 9% Canada, 17%
US. (1970)
Monetary conversion rate: 2.70 East Caribbean
dollars = US$1 (July 1976)
GDP: $20 million (1971 est.), $200 per capita; 6.9%
growth in 1971
Agriculture: main crops—bananas, arrowroot,
coconut
Major industries: food processing
175
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ST. VINCENT/SAN MARINO
Electric power: 6,500 kW capacity (1975); 18
million kWh produced (1975), 180 kWh per capita
Exports: $4.7 million (f.o.b., 1973); bananas,
arrowroot, copra
Imports: $18.6 million (cif, 1973); fertilizer,
flour, transportation equipment, lumber, textiles
Major trade partners: exports—61% U.K., 30%
CARICOM, 9% U.S.; imports—29% CARICOM,
28% U.K., 9% Canada, 9% U.S. (1972)
Monetary conversion rate: 2.70 East Caribbean
dollars = US$1 (July 1976)','f305e205c7daf280aaed0a4281ac0bcfe890bd80cb3c3478d7378e7b04ddc582','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b99250765ffa56691d35be2d0dce55be697e50ddc9eb28f021f9995a912eed2',1977,'SM','San Marino','economy',444,'Principal economic activities of San Marino are
farming, livestock raising, light manufacturing, and
tourism; the government''s total budget for FY71 was
about $12 million, with the largest share of revenue
derived from the sale of postage stamps throughout
the world and from payments by the Italian
government in exchange for Italy’s monopoly in
retailing tobacco, gasoline, and a few other goods;
main problem is finding an additional $3 million to
finance badly needed water and electric power
systems expansions
Agriculture: principal crops are wheat (average
annual output about 4,400 metric tons/year) and
grapes (average annual output about 700 metric
tons/year); other grains, fruits, vegetables, and animal
feedstuffs are also grown; livestock population
numbers roughly 6,000 cows, oxen, and sheep; cheese
and hides are most important livestock products
Electric power: obtained from Italy, 1975
Manufacturing: consists mainly of cotton textile
production at Serravalle, brick and tile production at
Dogane, cement production at Acquaviva, Dogane,
and Fiorentino, and pottery production at Borgo
Maggiore; some tanned hides, paper, candy, baked
goods, Moscato wine, and gold and silver souvenirs
are also produced
Foreign transactions: dominated by tourism; in
summer months 20,000 to 30,000 foreigners visit San
Marino every day; a number of hotels and restaurants
have been built in recent years to accommodate them;
remittances from Sanmarinese abroad also represent
an important net foreign inflow; commodity trade
consists primarily of exchanging building stone, lime,
wood, chestnuts, wheat, wine, baked goods, hides,
and ceramics for a wide variety of consumer
manufactures','4b12b8282cfe11db108fb180aa2c403ce8a74053035952630ec2c093a74e3391','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0586a77c1b0c6936b9229ef2ad92d2bf9cabe80c9eb8fee9d5d4910a84afd81f',1977,'ST','Sao Tome and Principe','economy',448,'GNP: $20 million (1975 estimate); per capita
income $250 (1975 est.)
Agriculture: cash crops—cocoa, copra, coconut,
coffee, palm oil, bananas
Major industries: food processing on small scale,
timber
Electric power: 3,000 kW capacity (1975); 5
million kWh produced (1975), 65 kWh per capita
Exports: $18 million (f.0.b., 1973); mainly cocoa
(70%), copra (12%), coconut, coffee, palm oil
Imports: $10 million (c.i.f., 1973); communications
equipment, light and heavy vehicles, food products,
beverages, fuels and lubricants
Major trade partners: main partner, Portugal;
followed by Netherlands, West Germany, African
neighbors
Aid: Portugal remains principal aid donor;
however, the PRC and UNDP have established
substantial programs of technical assistance and the
Romanians and Cubans have somewhat smaller
programs; the U.S. is providing some training for Sao
Tomeans under regional AID programs
Budget: total expenditures $6.4 million (1970);
balance on ordinary budget $0.7 million (1970)
Monetary conversion rate: 27.40 escudos=US$1
(January 1976)
Fiseal year: probably calendar year','38c469ee3a3d6e8a23c147fa78a2090b96b33dd53e0e64a42dec999c9d8792da','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb434f7d117408c41aeee315007ca8bec19bc6973d994cda4c9de5c596cdd9ae',1977,'SA','Saudi Arabia','economy',452,'GNP; $31 billion (1975 est., 1975 prices), $5,530
per capita; annual growth in real GNP approx. 15%
(1973/75 average, non-oil)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SAUDI ARABIA/SENEGAL
Agriculture: dates, grains, livestock; not self-
sufficient in food
Major industries: petroleum production 8.8 million
b/d (August 1976); payments to Saudi Arabian
Government, $28.5 billion (1975 est.); cement
production and small steel-rolling mill and oil
refinery; several other light industries, including
factories producing detergents, plastic products,
furniture, etc; PETROMIN, a semipublic agency
associated with the Ministry of Petroleum, has
recently completed a major fertilizer plant
Electric power: 1,300,000 kW capacity (1975); 3
billion kWh produced (1975), 210 kWh per capita
Exports: $28.6 billion (f.0.b., 1975 est.); 99%
petroleum and petroleum products
Imports: $6.5 billion (f.0.b., 1975 est.); manufac-
tured goods, transportation equipment, construction
materials, and processed food products
Major trade partners: exports—U.S., Western
Europe, Japan; imports—U.S., Japan, West Germany
Monetary conversion rate: 1 Saudi riyal = US$0.28
as of February 1976 (linked to SDR, freely
convertible)
Fiscal year: follows Islamic year; the 1973-74
Saudi fiscal year covers the period 30 July 1973
through 1 July 1974','7e3e23b4372af49d87f8cccd493312e25712891f49a8abb429a821cfcd7b2ea8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56d416215a6d92b43d63127b940a06108b4f0bf6221ad465b38b8f0f81de20e1',1977,'SN','Senegal','economy',456,'GDP: $1.3 billion (1975 est.), $300 per capita; real
growth rate probably zero or negative since 1972
(1966-71)
Agriculture: main crops—peanuts, millet, sor-
ghum, manioc, rice; peanuts primary cash crop;
production of food crops increasing but still
insufficient for domestic requirements
Fishing: catch 357,030 metric tons (1974); exports
$21.7 million (1974)
Major industries: fishing, agricultural processing
plants, light manufacturing, mining
Electric power: 135,000 kW capacity (1975); 355
million kWh produced (1975), 80 kWh per capita
Exports: $340 million (f.0.b., 1975); approx. 35%
peanuts and peanut products; phosphate rock;
canned fish
180
Imports: $574 million (f.o.b., 1975); food,
consumer goods, machinery, transport equipment
Major trade partners: France, EC (other than
France), and franc zone
Aid: economic—France (1966-70), $115 million;
China (1975), $51.8 million; U.S. (FY61-75), $71
million; U.S.S.R., $7.6 million; EC (1961-73), $154
million; military—U.S. (FY61-75), $2.8 million
Budget: 1976—balanced at $535.5 million
Monetary conversion rate: francs; about 248.22
Communaute Financiere Africaine francs = US$1 as of
August 1976, floating
Fiscal year: 1 July - 80 June','02c9814cc0966ce4288ea6badd246f0001b6ede17132215add802f78575dcf33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b1669f982083de824564eb134909759bef3545a3cd4a639fe3ad4e13bf2982',1977,'SC','Seychelles','economy',460,'Agriculture: islands depend largely on coconut
production and export of copra; cinnamon, vanilla,
and patchouli (used for perfumes) are other cash
crops; food crops—small quantities of sweet potatoes,
Approved For Release 2005/04/22 :
cassava, sugarcane, and bananas; islands not self-
sufficient in foodstuffs and the bulk of the supply
must be imported
Major industries: processing of coconut and
vanilla, fishing, small-scale manufacture of consumer
goods, coir rope factory, tea factory
Electric power: 10,880 kW capacity (1975); 5
million kWh produced (1975), 85 kWh per capita
Exports: $6 million (f.0.b., 1975); cinnamon (bark
and oil) and vanilla account for almost 50% of the
total, copra accounts for about 40%, the remainder
consisting of patchouli, fish, and guano
Imports: $33 million (c.i.f., 1975), food, tobacco,
and beverages account for about 40% of imports,
manufactured goods about 25%, machinery and
transport equipment, petroleum products, textiles
Major trade partners: exports—India, U.S.;
imports—U.K., Burma, India, South Africa, Kenya,','765f17cd4801daf494322e4f84bc467860fdf2c43adf16296aaa07d49eff0ff2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('961e3c8d711a33516727b8e14e557158865350586b16dc7220f6c53fa09a9076',1977,'SL','Sierra Leone','economy',464,'GDP: $493 million (1974), $180 per capita; growth
rate 22% (1973-74)
Agriculture: main crops—palm kernels, coffee,
cocoa, rice, yams, millet, ginger, cassava; much of
cultivated land devoted to subsistence farming; food
crops insufficient for domestic consumption
Fishing: catch 51,300 metric tons (1974); imports
$3.1 million (1973)
Major industries: mining—diamonds, iron ore,
bauxite, rutile, manufacturing—beverages, textiles,
cigarettes, construction goods; 1 oil refinery
Electric power: 75,000 kW capacity (1975); 235
million kWh produced (1975), 85 kWh per capita
Exports: $138 million (f.0.b., 1975); diamonds, iron
ore, palm kernels, cocoa, coffee
Imports: $185 million est. (f.0.b., 1975 est.);
machinery and transportation equipment, manu-
factured goods, foodstuffs, petroleum products
Major trade partners: U.K., EC, Japan, U.S.,
Communist countries
Budget: (FY75) current revenues $106 million,
current expenditures $106 million
Monetary conversion rate: 1 leone=US$1.12
(August 1976)
Fiscal year: 1 July - 30 June','2ec6fabe90799532443b31885c067bb186508dec86ec4fd482b1a4998ebdb87b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c28a5178a9a01b4bbc2b97e3b89f151585ddae39abbe69675a430d120a708a8e',1977,'SG','Singapore','economy',468,'GNP: $5.62 billion (1975), $2,500 per capita;
10.7% average annual real growth (1966-75), 4.1%
(1975)
Agriculture: occupies a position of minor
importance in the economy, self-sufficient in pork,
poultry, and eggs, must import much of its other food
requirements; major crops—rubber, copra, fruit and
vegetables
Fishing: catch 19,236 metric tons (1974), imports—
41,300 metric tons (1978)
Major industries: petroleum refining, oil drilling
equipment, rubber processing and rubber products,
processed food and beverages, electronics, ship repair,
entrepot trade, financial services
Electric power: 1,109,000 kW capacity (1975); 4.2
billion kWh produced (1975), 1,894 kWh per capita
183
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22: CIA-RDP79-01051A000800010006-3
January 1977
SINGAPORE/SOMALIA
Exports: $5.3 billion (f.0.b., 1975); 40% reexports;
petroleum products, rubber, manufactured goods
Imports: $8.1 billion (cif, 1975); 18% goods
reexported; major retained imports—capital equip-
ment, manufactured goods, petroleum
Major trade partners: exports—Malaysia, U.S.,
Japan, U.K., Indonesia; imports—Japan, Malaysia,
ULS., U.K.
Aid: U.K.—(1960 - September 1969) $254 million
disbursed, (1969-73) $120 million extended; IBRD—
(1963-74) $143 million committed, $61 million
disbursed; U.S.—(FY53-74) $102 million committed
Budget: (FY76/77) revenues $1.3 billion, expend-
itures $2.1 billion, deficit $800 million; 25% military,
75% civilian
Monetary conversion rate: 2.46 Singapore
dollars = US$1 (August 1976)
Fiscal year: 1 April - 31 March','c49f42542d500c8e4cfa177e76700559d0edb48eff9308eda081414177cd9d04','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c903577fb07d234bf559c0201ea6eb5268d9cc72de5af3dcd88d651231a07a2',1977,'SO','Somalia','economy',472,'GDP: $220 million (1973 est.), $70 per capita
Agriculture: mainly a pastoral country; main
crops—bananas, sugarcane, cotton, cereals; livestock
Major industries: a few small industries, including
a sugar refinery, tuna and beef canneries, iron rod
plant
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Electric power: 18,000 kW capacity (1975); 45
million kWh produced (1975), 15 kWh per capita
Exports: $62 million (f£.0.b., 1974); bananas,
livestock, hides, skins
Imports: $129 million (c.i.f., 1974); textiles, cereals,
transport equipment, machinery, construction
equipment
Major trade partners: Italy and Arab countries;
$29 million imports from Communist countries (1973
est.)
Monetary conversion rate: 6.295 Somali shil-
lings = US$1
Fiscal year: 1 January - 31 December','3d10ad949d33f646b07b47c006ca1d28d93678ffff013e035be074551a386ca0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6129a580e5803c5c76a398b6905c9352c48acde2e5e3169ddc2a0aad5de14878',1977,'ZA','South Africa','economy',476,'GDP: $29.6 billion (1975), $1,190 per capita; real
growth rate 2.2% (1975)
Agriculture: main crops—corn, wool, wheat,
sugarcane, tobacco, citrus fruits; dairy products; self-
sufficient in foodstuffs
Fishing: catch 1.4 million metric tons (1974)
Major industries: mining, automobile assembly,
metalworking, machinery, textiles, iron and steel,
chemical, fertilizer, fishing
Electric power: 12,700,000 kW capacity (1975);
75.6 billion kWh produced (1975), 2,920 kWh per
capita
Exports: $4.2 billion (f.0.b., 1975, excluding gold);
wool, diamonds, corn, uranium, sugar, fruit, hides,
skins, metals, metallic ores, asbestos, fish products;
gold output $2.9 billion (1975)
Imports: $7,7 billion (c.if., 1975); motor vehicles,
machinery, metals, petroleum products, textiles,
chemicals
Major trade partners: U.K. and other Common-
wealth nations, U.S., West Germany, Japan
Aid: no substantial military or economic aid
Budget: FY77—revenue $7.3 billion, expenditures
$9.6 billion
Monetary conversion rate: 1 SA Rand = US$1.15 as
of September 1975, 0.87 SA Rand=US$1
Fiscal year: 1 April - 31 March
NOTE: Foreign trade figures are official South
African data converted at $1.40
‘
GDP: estimated at $150 million, $86 per capita
Agriculture: cash crops—tea, phormium tenax,
small amount of coffee; food crops—corn, sorghum,
dry beans; imports over half its foodstuffs from South
Africa; two-thirds of Transkei devoted to grazing—1.2
million cattle, 2.5 million sheep, 1.3 million goats
Major industries: forestry, textiles, tourism
Exports: timber, tea, sacks
Imports: foodstuffs, machines, equipment
Major trade partners: South Africa
Aid: South Africa, almost $500 million since 1970
Budget: $156 million (1976-77), about 70% of
which is provided by the South African government
Monetary conversion rate: 1 South African
Rand = US$1.15
Fiscal year: 1 April - 31 March
Agriculture: livestock raising (cattle and sheep)
predominates, subsistence crops (millet, sorghum,
corn, and some wheat) are raised but most food must
be imported
Fishing: catch 30,000 metric tons (1974)(processed
mostly in South African enclave of Walvis Bay)
Major industries: meatpacking, fish processing,
copper, lead, diamond, and uranium mining, dairy
products
Electric power: 155,000 kW capacity (1975); 535
million kWh produced (1975), 600 kWh per capita
Aid: South Africa is only major donor
Monetary conversion rate: 1 South African
Rand=US$1.15 (as of September 1975); 0.87 SA
Rand =US$1
Fiscal year: 1 April - 31 March','ac1c570c303b80ad2207da2e7615745ceac929ceb3faf9f91ddd38240fde11a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('436086fc2e57b92130a12bbc326b2e19d8ac0a882ef3e07bdb2f3b14e8592298',1977,'ES','Spain','economy',479,'GNP: $102.7 billion est. (1976), $2,880 per capita;
72.4% consumption, 6.3% investment, 9,7%
government 1975; foreign demand —7.7%; real
growth rate 1.9% (1976 est.); typical growth rate
25.5%
sik Approved For Release 2005/04/22
Agriculture: main crops—cereals, oranges, grapes
for wine, potatoes, olives, sugar beets; virtually self-
sufficient in good crop years; caloric intake, 2,750
calories per day per capita (1969-70)
Fishing: landed 1,380,000 metric tons valued at
$1,090.5 million in 1975; 1,323,521 metric tons at
$938.7 million in 1974
Major industries: food processing, textiles and
apparel (including footwear), metal manufacturing,
chemicals, shipbuilding, automobiles
Shortages: crude petroleum
Crude steel: 10.3 million metric tons produced
(1975), 3380 kg per capita
Electric power: 25,429,500 kW capacity (1975);
82.4 billion kWh produced (1975), 2,168 kWh per
'' capita
Exports: $7,653 million (f.0.b., 1975); principal
items—oranges and other fruits, iron and _ steel
products, textiles, wines, mercury, ships, canned fruits,
vegetables, and footwear
Imports: $16,159 million (cif, 1975); principal
items—machinery and transportation equipment,
petroleum and petroleum products, grains, cotton,
iron and steel
Major trade partners: (1975) 44% EC, 17% U.S.
and Canada, 6% Latin America, 2% CEMA
Aid: economic—U.S., $2.3 billion authorized
(FY46-75), IBRD, $427 million authorized (FY64-73),
$50.0 million authorized (FY73); military—U.S., $920
million authorized (FY53-75)
Budget; (1974) receipts $12,204 billion (704 billion
pesetas), expenditures $12,509 billion (721.6 billion
pesetas), deficit $305 million (17.6 billion pesetas)
Monetary conversion rate: 1 peseta=US$0.0174
(1975 average)
Fiscal year: calendar year','2c42316a5f01248a4a4fba7716324801cf8c0f95a3cf52ef74b9908ed61421b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe77f3a6acc44af9d4aa68ffa6830b597acdd480407b25c2eda24227c6b80b7e',1977,'LK','Sri Lanka','economy',483,'GNP: $3.1 billion in 1975 (1975 prices), $230 per
capita; real growth rate 3.6% (1975)
Agriculture: agriculture accounts for about 32% of
GNP; main crops—rice, rubber, tea, coconuts; 60%
self-sufficient in food; food shortages—rice, wheat,
sugar
Fishing: catch 110,700 metric tons (1974)
Major industries: processing of rubber, tea, and
other agricultural commodities; consumer goods
manufacture
Electric power: 422,000 kw capacity (1975); 1.3
billion kWh produced (1975), 94 kWh per capita
Exports: $558 million (1975); tea, rubber, coconut
products
Imports: $737 million (1975); food, petroleum,
fertilizer
Major trade partners: (1975) exports—16.1%
China, 12.1% Pakistan, 10.9% U.K.; imports—15.8%
China, 15.2% Saudi Arabia, 10.7% Japan
Budget: 1975 est. revenue $573 million, expendi-
ture $853 million
Monetary conversion rate: 8.6759 rupees=US$1
(June 1976), official rate
Fiscal year: 1 January - 31 December (starting
1973)','037e8092dae95041f732b54924f82fac81a0d255fed3cba7e42e86478dbdd300','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da03a1e84ad6beb0c1f80767ab28642eb5227cbc2f45b28c57177fbac943737d',1977,'SD','Sudan','economy',487,'GDP: $4.3 billion (1975), $240 per capita; 8%
growth at current prices 1968-69
Agriculture: main crops—sorghum, millet, wheat,
sesame, peanuts, beans, barley; not self-sufficient in
food production; main cash crops—cotton, gum
arabic
Major industries: cotton ginning, textiles, brewery,
cement, edible oils, soap, distilling, shoes, phar-
maceuticals
Electric power: 225,000 kW capacity (1975); 655
million kWh produced (1975), 87 kWh per capita
Exports: $438 million (f.0.b., 1975); cotton (46% ),
gum arabic, peanuts, sesame; $102 million exports to
Communist countries (FY71)
Imports: $887 million (cif., 1975); textiles,
petroleum products, vehicles, tea, wheat; $75 million
imports from Communist countries (FY71)
Major trade partners: U.K., West Germany, Italy,
India, U.S.S.R., China
Monetary conversion rate: 1 Sudanese pound =
US$2.87 (official); 0.348 Sudanese pound = US$1
Fiscal year: 1 July - 30 June
GNP: $395 million (1974); $850 per capita; real
growth rate 1974, 5.7%
Agriculture: main crops—trice, sugarcane, ba-
nanas; self-sufficient in major staple (rice); caloric
intake 2,350 calories per day per capita (1968)
Major industries: bauxite mining, alumina and
aluminum production, lumbering, food processing
Electric power: 320,000 kW capacity (1975); 1.6
billion kWh produced (1975), 3,800 kWh per capita
Exports: $280 million (f.o.b., 1975); bauxite,
alumina, aluminum, wood and wood products, rice
Imports: $264 million (c.if., 1975); capital
equipment, petroleum, iron and steel, cotton, flour,
meat, dairy products
Major trade partners: exports—39% U.S., 2%
Canada, 14% Netherlands; imports—35% U.S., 22%
Netherlands, 18% Europe (1971)
Aid: economic—extensions from U.S. (FY54-75),
$6.9 million in loans, $4.8 million in grants; from
international organizations (FY49-75), $56 million
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SURINAM/SWAZILAND
Monetary conversion rate: 1 Surinam guilder (S.
fl.) =US$0.565 (September 1976)
Fiscal year: calendar year
GDP: approx. $200 million (est. FY74), about $420
per capita; growth rate in current prices as much as
11% (FY71-74)
195
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SWAZILAND/SWEDEN
Agriculture: main crops—maize, cotton, rice,
sugar, and citrus fruits
Major industry: mining
Electric power: 75,000 kW capacity (1975); 125
million kWh produced (1975), 250 kWh per capita
Exports: $183 million (f0.b., 1975); iron ore,
asbestos, sugar, wood and forest products, citrus, meat
products, cotton
Imports: $132 million (f.0.b., 1975); food products,
manufactured goods, machinery, fertilizer, fuel
Major trade partners: Japan, U.K., South Africa
Aid: economic—U.K. $14.7 million (budgeted,
1971-73), U.S. $9.4 million (FY61-75), others
approximately $1.8 million; no military aid
Budget: FY77—revenue $86 million, recurrent
expenditure $47 million, development expenditure
$39 million
Monetary conversion rate: 1 Lilangeni=US$1.15
(as of September 1975)
Fiscal year: 1 April - 81 March','b0464688f6286034d95ea2d09c92eb8dcba9c849b6c3d01adb8613a4c8c993fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe7819884da5cd478f130c7fb403c449a59e4d4e3778eadda6e06c2000d65e70',1977,'SE','Sweden','economy',491,'GNP: $68.8 billion, $6,850 per capita (1975); 52%
consumption, 20.8% investment, 25% government;
2.0% net imports of goods and services (1973); 1974
growth rate 4.5% in constant prices
Agriculture: animal husbandry predominates with
milk and dairy products accounting for 40% of farm
income; main crops—grains, sugar beets, potatoes;
80% self-sufficient; food shortages—oils and fats,
tropical products; caloric intake, 2,880 calories per
day per capita (1967-68)
Fishing: catch 193,300 metric tons (1974), exports
$27 million, imports $136 million
Major industries: iron and steel, precision
equipment (bearings, radio and telephone parts,
armaments), shipbuilding, wood pulp and paper
products, processed foods, textiles, chemicals
Shortages: coal, petroleum, textile fibers, potash,
salt
Crude steel: 5.6 million metric tons produced
(1975), 733 kg per capita
Electric power: 22,833,000 kW capacity (1975);
79.2 billion kWh produced (1975), 10,000 kWh per
capita
Exports: $17,394 million (f.0.b., 1975); machinery,
motor vehicles and ships, wood pulp, paper products,
iron and steel products, metal ores and scrap,
chemicals
Imports: $18,027 million (c.if., 1975); machinery,
motor vehicles, petroleum and petroleum products,
textile yarn and fabrics, iron and steel, chemicals,
food, and live animals
Major trade partners: (1975) 15% West Germany,
11% U.K., 6% U.S., 9% Norway, 8% Denmark; 49%
EC-9; 5% U.S.S.R. and Eastern Europe
Aid: economic—U.S., $349.8 million authorized _
(FY46-75); $77.5 million in 1973; $24.7 million in
1972; net official aid to less developed countries and
multilateral agencies, $662.4 million (1960-70), $159
million in 1971, $198 million in 1972, $275 million in
1973
Budget: 1975—revenues $35.7 billion, expenditures
$35.3 billion
Monetary conversion rate: 1 kronor = US$0.241
average exchange rate 1974
Fiscal year: 1 July - 30 June','8814531d3421704768431209a505c6efc1a3137a84738bf3ce1403969a6b7028','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67de70fc5d632e1bf1ca1e59d81a80f1166b2dbbcef3dd6d13dd3c8acc4a555c',1977,'CH','Switzerland','economy',494,'GNP: $56.08 billion (1975, in 1975 prices), $8,590
per capita; 59.2% consumption, 20.8% investment,
13.0% government, net foreign balance 7.0% (1975);
1966-75 growth rate 2.2%, constant prices
Agriculture: dairy farming predominates; less than
50% self-sufficient; food shortages—fish, refined
sugar, fats and oils (other than butter), grains, eggs,
fruits, vegetables, meat; caloric intake, 3,190 calories
per day per capita (1969-70)
Major industries: machinery, chemicals, watches,
textiles, precision instruments
Shortages: practically all important raw materials
except hydroelectric energy
Electric power: 12,700,000 kW capacity (1975);
41.8 billion kWh produced (1975), 6,550 kWh per
capita
Exports: $13.0 billion (f.0.b., 1975); principal
items—machinery and equipment, chemicals,
precision instruments, metal products, textiles,
foodstuffs
Imports: $13.3 billion (cif., 1975); principal
items—machinery and transportation equipment,
metals and metal products, foodstuffs, chemicals,
textile fibers and yarns
Major trade partners: 55% EC (21% West
Germany, 11% France, 8% Italy, 6% U.K.); 10%
EFTA (5% Austria); 7% U.S.; 4% Communist
countries (1975)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SWITZERLAND/SYRIA
Aid: economic—authorized, U.S. $107 million
through FY74; net official economic aid delivered to
less developed areas and multilateral agencies $325
million (1962-74), $68 million in 1974
Budget: receipts, $4,739 million, expenditures
$5,246 million, deficit $507 million (1975)
Monetary conversion rate: 2.5813 Swiss francs =
US$1 (average 1975, floating)
Fiscal year: calendar year
GDP: $2.4 billion, est. (1975), $830 per capita; real
GDP growth rate 12%, 1975 est.
Agriculture: main crops—cotton, wheat, barley
and tobacco; sheep and goat raising; self-sufficient in
most foods in years of good weather
Major industries: textiles, petroleum (est. 190,000
b/d production, refining capacity is 315,000 b/d),
food processing, beverages, tobacco
Electric power: 1.5 million kW capacity (1975);
1.7 billion kWh produced (1975), 230 kWh per capita
Exports: $890 million (f.0.b., 1975); petroleum,
cotton, fruits and vegetables, grain, wool, and
livestock
Imports: $1,500 million (c.i.f., 1975); machinery
and metal products, textiles, fuels, foodstuffs
Major trade partners: exports—U.S.S.R., Italy,
and Lebanon; imports—Lebanon, West Germany,
Italy, U.S.S.R., Japan, and France
Budget: 1976 est.—revenues $4.4 billion (including
Arab aid payments), expenditures $4.4 billion
Monetary conversion rate: 3.70 Syrian pounds =
US$1
Fiscal year: calendar year
Mainland:
GDP: $2,300 million at current prices (1975), about
$150 per capita; real growth rate, 4% (1970-75)
Agriculture: main crops—cotton, coffee, sisal on
mainland; imports food grains
Fishing: catch 167,700 metric tons (1974); exports
valued at $356,000, imports $1.4 million (1974)
Major industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond mine, oil
refinery, shoes, cement, textiles, wood products
Electric power: 235,000 kW capacity (1975); 550
million kWh produced (1975), 35 kWh per capita
Exports: $390 million (£.0.b., 1975); coffee, cotton,
sisal, cashew nuts, meat, diamonds, cloves, tobacco,
tea
Imports: $800 million (c.if,, 1975); manufactured
goods, machinery and transport equipment, cotton
piece goods, crude oil, foodstuffs
Major trade partners: exports—China, U.K., Hong
Kong, India, Kenya, U.S.; imports—U.K., China,
Kenya, West Germany, U.S., Japan
Aid: about $160 million in aid is committed for
1976 from EC, China, IMF, U.S.; China has extended
$245 million in aid since 1967, primarily for Tan-Zum
Railway
Budget: (1976 est.) receipts $560 million,
expenditures $856 million
Monetary conversion rate: 8.4 Tanzanian
shillings=US$1
Fiscal year: 1 July - 30 June
Zanzibar:
GNP: $35 million (1967)
Agriculture: main crops—cloves, coconuts
Industries: agricultural processing
Electric power: see Tanganyika (above)
Exports: $12.6 million (1968); cloves and clove
products, coconut products
Imports: $5.6 million (1968), mainly foodstuffs and
consumer goods
Major trade partners: imports—China, Japan, and
mainland Tanzania; exports—Singapore, China,
Hong Kong, Indonesia, India, Pakistan
Aid: U.K. principal source of aid until 1964; U.S.
$86 million FY58-73; China is currently major source
Exchange rate: 1 Tanzanian shilling = US$0.14;
7.143 Tanzanian shillings = US$1
Fiscal year: 1 July - 30 June
GDP: $14.5 billion (1975), $340 per capita; 7% real
growth in 1975 (6.3% real growth, 1969-74)
Agriculture: world’s third largest rice exporter in
1974; main crops—rice, sugar, corn, rubber tapioca
Fishing: catch 1.5 million metric tons valued at
$420 million (1974): exports, 88,000 metric tons, $77
million (1974)
Major industries: agricultural processing, textiles,
wood and wood products, cement, tin and tungsten
ore mining; world’s second largest tungsten producer
and third largest tin producer
Shortages: fuel sources, including coal, petroleum;
scrap iron, and fertilizer
Electric power: 2,440,000 kw capacity (1975); 8.5
billion kWh produced (1975), 200 kWh per capita
Exports: $2,251 million (f.0.b., 1975); rice, sugar,
corn, rubber, tin, tapioca, kenaf
Imports: $3,276 million (c.i.f., 1975); machinery
and transport equipment, fuels and lubricants, base
metals, chemicals, and fertilizer
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
THAILAND/TOGO
Major trade partners: exports—Japan, U.S.,
Singapore, Netherlands, Hong Kong, Malaysia;
imports—Japan, U.S., West Germany, U.K.; about
1% or less trade with Communist countries
Budget: (FY76) receipts $2,433 million, expendi-
tures $3,134 million, deficit $701 million; 17%
military, 83% civilian
Monetary conversion rate: 20.0 baht = US$1
Fiscal year: 1 October - 30 September','aa39409eefe8d1bfe0b22fa21d65854951717dd43f9eb702cd99d3d9588b394c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('667922d04e0cdac52da8250c2e45df1bc88e2d4b170e0e473dfa70a954e25883',1977,'TG','Togo','economy',498,'GDP: $471 million (1975), about $210 per capita;
estimated real growth 1966-70, 5.3% average annual
rate
Agriculture: main cash crops—coffee, cocoa,
cotton; major food crops—yams, cassava, corn, beans,
rice, millet, sorghum, fish; must import some
foodstuffs
Major industries: phosphate mining, agricultural
processing, handicrafts, textiles, beverages
Electric power: 30,000 kW capacity (1975); 100
million kWh produced (1975), 44 kWh per capita
Exports: $124 million (f.0.b., 1975); phosphates,
cocoa, coffee, palm kernels, and cassava
Imports: $150 million (f.0.b., 1975); consumer
goods, fuels, machinery, tobacco, foodstuffs
Major trade partners: mostly with France and
other EC countries
Aid: 1975 disbursements—France, $13.6 million;
West Germany, $2.5 million; EEC, $1.5 million: U.S.,
$1.1 million; FY59-75 total commitments—EC, $62.9
million; U.S., $28 million; U.N., $16.8 million;
others, $24.6 million; China (1973), $45 million
Budget: 1976 revenues and expenditures, $217.5
million
Monetary conversion rate: Communaute Finan-
ciere Africaine 248,12 francs = US$1 as of August 1976
Fiscal year: calendar year','fd07a9652183571b1f21fea0c544fcbde8b4341807dcfccf76e50ea440468db2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f45f8c6424346d515ec759966eeecac3c38c90f6d9d4ecf77d89976a890c866',1977,'TO','Tonga','economy',502,'GNP: $39 million (1975), $380 per capita
Agriculture: largely dominated by coconut and
banana production with subsistence crops of taro,
yams, sweet potatoes, and bread fruit
Electric power: 4,000 kW capacity (1975); 7
million kWh produced (1975), 69 kWh per capita
Exports: $10 million (f.0.b., 1975); 65% copra, 7%
coconut products, 8% bananas
Imports: $28 million (c.if., 1975); food,
machinery, and petroleum
Major trade partners: (FY74) exports—25 %
Netherlands, 22% Australia, 20% New Zealand, 11%
Norway; imports—63% New Zealand and Australia
Budget: (FY76) revenues $6.7 million, expenditures
$8.3 million
Monetary conversion rate: 1 Tonga dol-
lar = US$1.40 (1976)
Fiscal year: 1 July - 30 June','add1f9f00e386638abccaa876d8122448222bba86f910d9292421f3ea50d771b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb7b7b1bfbc2ebca3a1ae6b3765a359b469a0f8b09504cec8702b99d191b5fb',1977,'TT','Trinidad and Tobago','economy',506,'GDP: $1,500 million (1974), $1,500 per capita; real
growth rate 1974, negligible
Agriculture: main crops—sugarcane, cocoa, coffee,
tice, citrus, bananas; largely dependent upon imports
of food
Fishing: catch 3,380 metric tons (1974); exports
$1.1 million (1974), imports $4.5 million (1974)
Major industries: petroleum, tourism, food
processing, cement
Electric power: 335,000 kW capacity (1975); 1.2
billion kWh produced (1975), 1,250 kWh per capita
Exports: $1.8 billion (f.0.b., 1975); petroleum and
petroleum products ($1.5 million), sugar, cocoa
Imports: $1.5 billion (c.i.f., 1975); crude petroleum
($749 million), machinery, fabricated metals,
transportation equipment, manufactured goods, food
Mafor trade partners: (excludes trade under
petroleum agreement) exports—U.S. 37%, U.K. 11%,
CARIFTA 21%; imports—U.S. 384%, U.K. 23%,
CARIFTA 10% (1972)
Aid: economic—from U.S, (FY46-75), $40.5
million in grants; from international organizations
(FY58-75), $14.8 million
Budget: (1974) central government revenues $609
million, expenditures $285 million
Monetary conversion rate: floating with pound
sterling; in February 1975, TT$2.3682 = US$1
Fiscal year: calendar year
206
Approved For Release 2005/04/22 :','459a3955bfea208a4112dab0a3a805a6e09989701caf47cf0491e709ec82a07f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e085dce45bd6ba4d2a466a50a68fdb14835cbcb688e30e6046db7be55825e6b2',1977,'TN','Tunisia','economy',510,'GDP: $4.4 billion (1975 est.), $760 per capita; real
growth of 9% in 1975
Agriculture: cereal farming and livestock herding
predominate; main crops—wheat, barley, olives,
fruits (especially citrus), viticulture, vegetables, dates
Major sectors: tourism, mining, food processing,
textiles and leather, light manufacturing, construction
materials, chemical fertilizers, petroleum
Electric power: 425,000 kW capacity (1975); 1.3
billion kWh produced (1975), 222 kWh per capita
Exports: $856 million (f.o.b., 1975); 34%
petroleum, 20% phosphates, 18% olive oil
Imports: $1,424 million (c.if., 1975); 836% raw
materials, 23% machinery and equipment, 14%
consumer goods, 19% food and beverages, 3% energy,
5% other
Major trade partners: exports—19% France, 19%
Italy, 18% West Germany, 10% Libya; imports—36%
France, 15% U.S., 9% Italy, 7% West Germany (1971)
Monetary conversion rate: 0.402 dinar=US$1
(trade rate)
Fiscal year: calendar year
GNP; $36.5 billion (1975), $860 per capita; 7.9%
real growth 1975, 7.8% average annual real growth
1970-75
Agriculture: main products—cotton, tobacco,
cereals, sugar beets, fruits, nuts, and _ livestock
products; self-sufficient in food in average years, 2,900
calories per day per capita (1972)
Major industries: textiles, food processing, mining
(coal, chromite, copper, boron minerals), steel,
petroleum
Crude steel: 1.4 million tons produced (1975), 30
kg per capita
Electric power: 3,300,000 kW capacity (1975);
14.4 billion kWh produced (1975), 250 kWh per
capita
Exports: $1,400 million (f.0.b., 1975); cotton,
tobacco, fruits, nuts, metals, livestock products,
textiles and clothing
Imports: $4,739 million (c.i.f., 1975); machinery,
transport equipment, metals, mineral fuels, fertilizers,
chemicals
Major trade partners: exports—21% West
Germany, 12% U.S., 9% Switzerland, 6% Italy;
208 Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TURKEY/TUVALU/UGANDA
imports—19% West Germany, 12% U.S., 11% U.K.,
11% Italy
Budget: (FY76) revenues $9.41 billion, expendi-
tures $10.21 billion, deficit $800 million
Monetary conversion rate: 16.0 Turkish liras=
US$1 (1 April 1976)
Fiscal year: 1 March - 28 February','37def4a2a6456d0cfe989afc82da1a13de6e3b6175ffb9e0edc4f8f9bb829484','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64f6e52023226688b3d4f04cbf816a28fdd9c6554a2983062eaf24cb6b817f8c',1977,'UG','Uganda','economy',517,'GDP; $1,700 million (1974, at current prices), $150
per capita; 0% real growth between 1970-74
Agriculture: main cash crops—coffee, cotton; other
cash crops—tobacco, tea, sugar, fish, livestock
Fishing: catch 167,500 metric tons (1974) million
(1971)
Major industries: agricultural processing (textiles,
sugar, coffee, plywood, beer), cement, copper smelter,
corrugated iron sheet, shoes, fertilizer
Electric power: 175,000 kW capacity (1975); 850
million kWh produced (1975), 74 kWh per capita
Exports: $244 million (f.0.b., 1975); coffee, cotton,
tea, copper (1971)
Imports: $240 million (c.i.f., 1975); petroleum
products, machinery, cotton piece goods, metals,
transport equipment
Major trade partners: U.K., U.S., Kenya (Uganda,
Kenya, and Tanzania form East African Economic
Community)
Monetary conversion rate: 8.4 Uganda. shil-
lings = US$1
Fiscal year: 1 July - 380 June
GNP: $865.3 billion (1975, in 1975 U.S. prices),
$3,400 per capita; in 1975 percentage shares were—
57% consumption, 29% investment, 14% government
and other, including defense (based on 1970 GNP in
rubles at adjusted factor cost); average annual rate of
growth of real GNP (1971-75), 3.8%
Agriculture: principal food crops—grain (espe-
cially wheat), potatoes; main industrial crops—
sugar cotton, sunflowers, and flax; degree of self-
sufficiency depends on fluctuations in crop yields;
given normal yields, U.S.S.R. is self-sufficient; caloric
intake, 3,000-3,200 calories per day per capita in
recent years
Fishing: catch 10.3 million metric tons (1975);
exports 491 thousand metric tons (1975), imports 26.7
thousand metric tons (1975)
Major industries: diversified, highly developed
capital goods industries; consumer goods industries
comparatively less developed
Shortages: natural rubber, bauxite and alumina,
tantalum, tin, tungsten and fluorspar
Crude steel; 154 million metric ton capacity as of 1
January 1976; 141 million metric tons produced in
1975, 550 kg per capita
Electric power: 218 million kW capacity (1975);
1,035 billion kWh produced (1975), 4,048 kWh per
capita
Exports: $33,401 million (f.0.b., 1975); fuels
(particularly petroleum and derivatives), metals,
agricultural products (timber, grain) and a wide
variety of manufactured goods (primarily capital
goods)
211
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
U.S.S.R./UNITED ARAB EMIRATES
Imports: $37,070 million (f.0.b., 1975); specialized
and complex machinery and equipment, textile fibers,
consumer manufactures, steel products (particularly
large diameter pipe), and any significant shortages in
domestic production (for example, grain imported
following poor domestic harvests)
Major trade partners: $70.5 billion (1975); trade
56% with Communist countries, 31% with in-
dustrialized West, and 18% with less developed
countries
Aid: economic—to non-Communist countries (total
extended 1975) $1,327 million; recipients included
Turkey $650 million, Afghanistan $437 million,
Somalia $62 million, Sri Lanka $57 million,
Bangladesh $46 million, Brazil $44 million; military—
(total extended 1975) $1,304 million; principal
recipients were Syria $300 million, India $204 million,
Afghanistan $125 million
Official monetary conversion rate: 0.7525
rubles = US$1; 1 ruble=US$1.3289 (September 1976)
Fiscal year: calendar year','1d7cac977e8077fc43f22805f07945163c7d8082ef9e38813af8a68f78c31428','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a8a91934ccc05180f05dfff6a27517c860360cddd04b19e4518cf86f0f32433',1977,'AE','United Arab Emirates','economy',520,'Agriculture: food imported, but some dates,
alfalfa, vegetables, fruit, tobacco raised
Electric power: 435,000 kW capacity (1975); 600
million kWh produced (1975), 3,000 kWh per capita
Exports: $7.3 billion ($7.0 in oil, $0.8 non-oil)
(f.0.b., 1976); crude petroleum, pearls, fish
Imports: $3 billion (£.0.b. , 1976); food, consumer
and capital goods
Major trade partners: U.K., U.S., Japan, India,
EC
Aid: 1974-75 foreign aid totaled $1 billion, the
1975-76 budget committed $875 million to direct
foreign aid; Abu Dhabi Fund for Arab Economic and
Social Development in 1975 lent $175 million to
LDC’s
Budget: total budget (1976), $1 billion, 70% from
Abu Dhabi
Monetary
ham = US$0.25
Fiscal year: calendar year','55c80e72b1d92df8ad22ca4ea4df89b0b5ff1957411a8bb7cdbb489aba9b5856','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f479f30e2c8dc1c1132f9148766d9c314d53c8b1a73097a78268db813837baf',1977,'GB','United Kingdom','economy',524,'GNP: $226 billion (1975, in 1975 prices), $4,040 per
capita; 61.6% consumption, 19.8% investment, 22.4%
government, —1.1% inventories, —2.5% net foreign
balance, real growth 3% (1955-75)
Agriculture: mixed farming predominates; main
products—wheat, barley, potatoes, sugar beets,
livestock, dairy products; 50% self-sufficient; food
shortages—meat, fruits, vegetables, cereals, dairy
products; caloric intake, 3,170 calories per day per
capita (1970-71)
Fishing: catch 954 thousand metric tons (1974),
$355 million (1974); exports $128 million, imports
$304 million (1975)
Major industries: machinery and transport
equipment, metals, food processing, paper and paper
products, textiles, chemicals, clothing
Shortages: rubber, petroleum, timber and
woodpulp, textile fibers, nonferrous metals, foodstuffs
214
Crude steel: 20.3 million metric tons produced
(1975); 28.1 million metric tons capacity (1975), 360
kg per capita
Electric power: 82 million kW capacity (1975);
272 billion kWh produced (1975), 5,100 kWh per
capita
Exports: $41.7 billion (f.0.b., 1975); machinery,
transport equipment, chemicals, metals, nonmetallic
mineral manufactures, textiles, beverages
Imports: $48.8 billion (f.0.b., 1975); foodstuffs,
petroleum, machinery, crude materials, chemicals,
nonferrous metals
Major trade partners: 35% EC, 4% Ireland, 3%
South Africa, 22% Sterling Area, 2% U.S.S.R. and
Eastern Europe, 2% Australia, 3% Canada, 9% U.S.
Aid: economic—(authorized) U.S., $9.0. billion
(FY46-75), $26 million in FY78; 51.4 million in FY72:;
net official economic aid to less developed areas and
multilateral agencies, $5,073 million (1960-69), $562
million in 1971; $609 million in 1972; military—U.S.,
$1.1 billion (FY46-75)
Budget (public sector): net expenditure planned
for FY77, $889 million
Monetary conversion rate: pound sterling floating,
average daily exchange rate 1975, 0.45 pounds = US$1
Fiscal year: 1 April - 81 March
GDP: $495 million (1974 est.), $80 per capita
Agriculture: cash crops—peanuts, shea nuts,
sesame, cotton; food crops—sorghum, millet, corn,
rice; livestock; largely self-sufficient
Fishing: catch 3,500 metric tons (1974)
Major industries: agricultural processing plants,
brewery, bottling, and brick plants; a few other light
industries
Electric power: 20,000 kW capacity (1975); 57
million kWh produced (1975), 9 kWh per capita
Exports: $68 million (f.0.b., 1974); livestock (on the
hoof), peanuts, shea nut products, cotton, sesame
Imports: $194 million (c.i.f., 1974); textiles, food,
and other consumer goods, transport equipment,
machinery, fuels
Major trade partners: Ivory Coast and Ghana;
overseas trade mainly with France and other EC
countries; preferential tariff to EC and frane zone
countries
Aid; economic—France (1964-September 1970),
$46 million; EC (FY1960-72), $87 million; U.S.S.R.,
China, Ghana, West Germany, and Israel have also
extended aid; U.S. (FY61-75), $47 million;
international organizations (FY60-73), $175 million;
China, $51 million (1978-75); military—France, $3.7
million (1964-70); U.S., $0.1 million (FY1962-75)
Budget: (1976) balanced at $94 million
Monetary conversion rate: about 248.22 Com-
munaute Financiere Africaine francs =US$1 as of
August 1976, floating
Fiscal year: calendar year','9074c213b76dcd48cffc1abb198db3646d2f0b9e04481a98936cf0895fd8041b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('594dd8680866b14ec86c9f1115461a51b8e369e48a22526e51b02c30af9d6dbb',1977,'UY','Uruguay','economy',528,'GNP: $2.8 billion (1975, in 1974 prices), $910 per
capita, 77% private consumption, 13% public
consumption, 12% gross investment (1969); net
foreign balance —2%; real growth rate 1975, 3.6%
Agriculture: large areas devoted to extensive
livestock grazing (17 million sheep, 9 million cattle);
main crops—wheat, rice, corn; self-sufficient in most
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
URUGUAY/VATICAN CITY
basic foodstuffs; caloric intake, 3,000 calories per day
per capita, with high protein content
Major industries: meat processing, wool and hides,
textiles, footwear, cement, petroleum refining
Crude steel: 13,000 metric tons produced (1972), 5
kg per capita
Electric power: 574,000 kW capacity (1975); 2.5
billion kWh produced (1975), 920 kWh per capita
Exports: $385 million (f.0.b., 1975); wool, hides
Imports: $548 million (c.if., 1975); fuels, metals,
machinery, transportation equipment
Major trade partners: exports—28% EC, 4% U.S.,
37% LAFTA; imports—30% LAFTA, 8% U.S., 18%
EC (1974)
Aid: economic—extensions from U.S. (FY46-75),
$138 million in loans, $29 million in grants; from
other Western countries (1960-74), $26 million; from
Communist countries—U.S.S.R. (1969-75), $52
million and Eastern Europe (1966-75), $25 million;
from international organizations (1946-75), $320
million; military—authorizations from U.S. (FY53-
75), $86 million
Monetary conversion rate: commercial rate, new
pesos 3.18=US$1, financial rate, new pesos
3,42 =US$1 (May 1976)
Fiscal year: calendar year
The Vatican City, seat of the Holy See, is supported
financially by contributions (known as Peter’s pence)
from Roman Catholics throughout the world; some
income derived from sale of Vatican postage stamps
and tourist mementos, fees for admission to Vatican
museums, and sale of publications; industrial activity
consists solely of printing and production of a small
amount of mosaics and staff uniforms
The banking and financial activities of the Vatican
are worldwide; the Institute for Religious Agencies
carries out fiscal operations and invests and transfers
funds of Roman Catholic religious communities
throughout the world; the Cardinal’s Commission
controls the administration of ordinary assets of the
Holy See and a Special Administration manages the
Holy See’s capital assets
Electric power: obtained from Rome city grid;
standby diesel powerplant with 2,100 kw capacity
(1975)
GNP: $27.3 billion (1975, in 1975 dollars), $2,280
per capita; 50% private consumption, 13% public
consumption, 29% gross investment, 8% foreign sector
(1975 est.), real growth rate 1975 est., 3.8%
Agriculture: main crops—cotton, sugarcane, corn,
coffee, rice; self-sufficient in rice and chicken, imports
wheat (U.S.) and meat (Colombia); caloric intake
2,600 calories per day per capita (1972)
Fishing: catch 162,400 metric tons (1974); exports
$14.4 million (1972), imports $9.5 million (1972)
Major industries: petroleum, iron-ore mining,
construction, food processing, textiles
Crude steel: 1.1 million metric tons produced
(1973), 100 kg per capita
Electric power: 4,400,000 kW capacity (1975); 17
billion kWh produced (1975), 1,550 kWh per capita
Exports: $9.5 billion (£.0.b., 1975); petroleum $8.9
billion (1975), iron ore, coffee
Imports: $6.0 billion (c.i.f., 1975); industrial
machinery and equipment, chemicals, manufactures,
wheat
Major trade partners: imports—42% U.S., 13%
West Germany, 8% Japan; exports—41% U.S., 13%
Canada, 12% Aruba, 9% Argentina
Aid: economic assistance—extensions from U.S.
(FY46-75), $127.9 million loans; $72.6 million grants,
from international organizations (FY46-75), $658
million; from Communist countries (1954-75), $10
million; military—assistance from U.S. (FY46-75),
$142 million
Budget: 1975—revenues $9.5 billion; expenditures,
$9.4 billion, capital $1.9 billion
Approved For Release 2005/04/22
Monetary conversion rate: 4.285 bolivares = US$1
(selling rate)
Fiscal year: calendar year','489151c25bad79ee0148b67f99d9394fb466600ec809ca4b43bb154fb82e4123','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba7e237b7cc3351c37d3aa15231c7feeb3c623952c70778694d23c4551101b1',1977,'WF','Wallis and Futuna','economy',532,'Agriculture: dominated by coconut production
with subsistence crops of yams, taro, bananas
Exports: negligible
Imports: $1.4 million (1972); largely foodstuffs and
some equipment associated with development
programs
Monetary conversion rate:
Pacifique (CFP)=US$1','702e78d8316b797744342a2b82a818fe7d9eb0e457feb7d21b996936beaf41d7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6182f72778d39280d8cd4413e737203f9d28558d63954abe46c3b74cba05d81d',1977,'EH','Western Sahara','economy',536,'Agriculture: practically none; some barley is grown
in nondrought years; fruit and vegetables in the few
oases; food imports are essential; camels, sheep, and
goats are kept by the nomadic natives; cash economy
exists largely for the garrison forces
221
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
WESTERN SAHARA/WESTERN SAMOA
Major industries: phosphate mining, fishing, and
handicrafts
Shortages: water
Electric power: 4,000 kW capacity (1975); 9
million kWh produced (1975), 84 kWh per capita
Exports: in 1975, up to $75 million in phosphates,
all other exports valued at under $1 million
Imports: $1,443,000 (1968); fuel for fishing fleet,
foodstuffs
Major trade partners: monetary trade largely with
Spain and Spanish possessions
Aid: small amounts from Spain in prior years
Monetary conversion rate: see Moroccan and
Mauritanian currencies','eb235e569450a2456f1d57507c66ebf77d5a6b79415ba0c361f11af8abd9e63b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2918020c9a6ae08a57628716e19188606f10a5ca1f86eabd17493d2d82a7882',1977,'WS','Samoa','economy',538,'GNP: $45 million (1974), $280 per capita
Agriculture: cocoa, bananas, copra; staple foods
include coconut, bananas, taro, and yams
Exports: $7 million (f.0.b., 1975); copra 38%, cocoa
26%, timber 3%
Imports: $36 million (c.if., 1975); food,
manufactured goods, machinery
Major trade partners: exports—43% New Zealand,
10% Netherlands, 14% West Germany, 12% U.S.;
imports—383% New Zealand, 19% Australia, 12%','515d9d689173b31786722bf1d1c2c7596e67c9e42a8ce4217ea1906b2e94d5cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88198555c48c4c749bf3e52253bc08307b65bb6b2cdd1af10ac32cd14a12289f',1977,'YE','Yemen','economy',540,'GNP: $100 million (1974 est.), $60 pér capita
Agriculture (all outside Aden): cotton is main cash
crop; cereals, dates, kat (qat), coffee, and livestock are
raised and there is a growing fishing industry; large
amount of food must be imported (particularly for
Aden); cotton, hides, skins, dried and salted fish are
exported
Major industries: petroleum refinery (production
150,000 b/d) mid-1971; capacity 178,000 b/d at
Little Aden operates on imported crude; oil
exploration activity
Electric power: 75,000 kW capacity (1975); 125
million kWh produced (1975), 75 kWh per capita
Exports: $20 million (1975 provisional), excluding
petroleum products but including re-exports
Imports: $154 million (1975 provisional)
Major trade partners: Yemen, East Africa, but
some cement and sugar imported from Communist
countries; crude oil imported from Persian Gulf,
exported mainly to U.K. and Japan
Budget: (FY1974-75, est. )—revenues $42 million,
expenditures $75 million
Monetary conversion rate: 1 S. Yemeni dinar=
US$2.90
Fiscal year: 1 April - 81 March
223
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
YEMEN (ADEN)/YEMEN (SANA)
GNP: $780 million (1974 est.), $130 per capita
Agriculture: sorghum and millet, gat (a mild
narcotic), cotton, coffee, fruits and vegetables; largely
self-sufficient in food
Major industries: cotton textiles and leather goods
produced on a small scale; handicraft and some
fishing; small aluminum products factory
Electric power: 15,000 kW capacity (1975); 25
million kWh produced (1975), 4.kWh per capita
Exports: $15 million (1974 est. ); qat, cotton, coffee,
hides, vegetables
Imports: $259 million (1975 est.); textiles and other
manufactured consumer goods, petroleum products,
sugar, grain, flour, other foodstuffs, and cement
Major trade partners: China, Yemen (Aden),
U.S.S.R., Japan, U.K., Australia, Saudi Arabia
Aid: bilateral pledges received—$167 million 1974,
multilateral—$36 million through 1972, $170 million
drawn through 1970; major donors include U.S.S.R.,
China, U.S., West Germany, Saudi Arabia: mili-
tary—$78 million from U.S.S.R.; $80 million from
Eastern Europe; $7 million western military aid
through 1978
Budget: (1974/75 est.) $711 million expenditures
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
YEMEN (SANA)/YUGOSLAVIA
Monetary conversion rate: 1 Yemeni rial=
US$0.22 as of October 1973
Fiscal year: 1 July - 30 June
GNP: $39.19 billion (1975 est., at 1975 prices),
$1,840 per capita; real growth rate 5.9% (1971-75)
Agriculture: diversified agriculture with many
small private holdings and large agricultural
combines; main crops—corn, wheat, tobacco, sugar
beets, and sunflowers; generally a net exporter of
foodstuffs and live animals; self-sufficient in food
except for tropical products, cotton, wool, and
vegetable meal feeds; caloric intake, 3,210 calories per
day per capita (1967)
Major industries: metallurgy, machinery and
equipment, textiles, wood processing, food processing
Shortages: electricity, fuels, steel, textile fibers,
chemicals
Crude steel: 2.9 million metric tons produced
(1975), 140 kg per capita
Electric power: 9 million kW capacity (1975); 40
billion kWh produced (1975), 1,870 kWh per capita
Exports: $4,072 million (f.o.b., 1975); 12%
foodstuffs and tobacco; 17% raw materials, fuels, and
chemicals; 28% machinery and equipment; 43% other
manufactures
Imports: $7,697 million (c.i.f., 1975); 7% foodstuffs
and tobacco; 33% raw materials, fuels, chemicals;
26% machinery and equipment; 84% other
manufactures
Major trade partners: 68% non-Communist
countries (35% EC, 6% U.S., 27% other non-
Communist countries), 32% Communist countries
Aid: postwar credits extended mainly by the U.S.
(about $3.6 billion, including grants and $0.7 billion
in military aid); Western Europe (more than $22
billion); IBRD ($1.1 billion); IMF (more than $730
million); Communist countries extended credits
totaling $464 million in 1956 ($125 million drawing
balance suspended in 1958) and $576 million during
1962-70 and $540 million in 1972; $173 million in
1974; Yugoslavia has extended credits totaling about
$850 million to 27 less developed countries of Africa,
Asia, and Latin America
226
Monetary conversion rate: 17.0 new dinars = US$1
Fiscal year: same as calendar year (all data refer to
calendar year or to middle or end of calendar year as
indicated)
GDP: $2.1 billion (1975 prices), $80 per capita; 4%
annual growth 1970-75
Agriculture: main cash crops—coffee, palm oil,
rubber; main food crops—manioc, bananas, root
crops, corn; some provinces self-sufficient
Fishing: catch 124,000 metric tons (1974); imports
$25 million (1972)
Major industries: mining, mineral processing, light
industries
Electric power: 1,100,000 kW capacity (1975); 5.0
billion kWh produced (1975), 200 kWh per capita
Exports: $825 million (f.0.b., 1975); copper, cobalt,
diamonds, other minerals, coffee
Imports: $1,057 million (cif, 1975); consumer
goods, foodstuffs, mining and other machinery,
transport equipment, fuels
Major trade partners: Belgium, U.S., and West','8c165ef6df9fad89d44fda783a74ffa52fac7387be2f83a328843643eda9a633','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1116e0dbd4d737bc5ca917cb3b0f0b43b58d59bb9f2e89c2e5cc36a3d9636509',1977,'ZM','Zambia','economy',546,'GNP: $2.3 billion (1975), $470 per capita; real
annual growth rate, 3% (1970-73)
Agriculture: main crops—corn, tobacco, cotton;
net importer of most major agricultural products
Fishing: catch 37,000 metric tons (1974); imports
$3.3 million (1973)
Major industries: copper mining and processing
Electric power: 1,100,000 kW capacity (1975); 6.4
billion kWh produced (1975), 1,300 kWh per capita
Exports: $780 million (f.0.b., 1975); copper (95%),
zinc, cobalt, lead, tobacco
Imports: $845 million (c.i.f., 1975); consumer
goods, machinery, transport equipment, foodstuffs,
fuels
Major trade partners: U.K., South Africa, Japan,
Western Europe
Aid: economic—China (1967-75), $304 million;
U.K. (1964-67), $63 million; IBRD (1965-75), $432
million; U.S. (FY53-75), $99 million; U.S.S.R., $9
million; Eastern Europe, $50 million; military—$9
million (1964-69), mainly U.K. and Canada; $12
million, Communist
Budget: 1975—revenue $690 million, expenditures
$932 million
Monetary conversion rate: 1 Zambia kwacha=
US$1.24 (official)
Fiscal year: calendar year','35f20f16fa868ea28be8b95680256d7efaffa029efe419930110d6d4e38d17c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

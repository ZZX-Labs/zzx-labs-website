SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64e45fa546cfabee257dcec252edb9a3ab5658bf604e6dd2b3779b7633cf3e31',1977,'','','raw',1,'Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3 > 26 ar
January 1977
@ JEUCHEN
21ISe
246T Aenuer - YONA LOW eDUabya1u]:
National Basic Intelligence
FACTBOOK
DIA and DOS
review(s) completed.
GC BIF 77-001 (U)
: January 1977
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
FOREWORD
The National Basic Intelligence Factbook, a compilation
of basic data on political entities worldwide, is coordinated and
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central Intelligence Agency,
Washington, D.C. 20505.
The publication is prepared for the use of U.S. Government
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to: |
q
Document Expediting (DOCEX) Project
Exchange and Gifts Division ‘
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX ‘
Project subscription service may purchase reproductions of spe-
cific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
National Basic Intelligence
FACTBOOK
January 1977
Supersedes the July 1976 issuance of this
Factbook, copies of which should be destroyed.
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977 .
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook
Page
Abbreviations for International Organizations . . . 2. 6 ee ee ee es Ix
United Nations (U.N.): Structure and Related Agencies .........-. xi
A=
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN . ow we ee 1
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA. 2 ¢.6 Soe Beck we ce ee a Ee a 2
ALGERIA. 2 foc eek we GOR HO te ie cae See Qe Sea ay ae, Goes 3
ANDORRA .. ine ee ee es 4
ANGOLA: &s-iscce once Glee tel foG Pe ea ee egy, er a eee 5
Anguilla (see ST. CHRISTOPHER-NEVIS)
ANTIGUA® {i fe ae ie eee arr ee a) Bo OP TE Ae 6
ARGENTINA .. 0.0 0 0 ee et ee ee ee 7
AUSTRALIA . 0c ce ee ee 9
AUSTRIAS #i-208 604 [8 Stee oe ee Sas aye ae ace a Se 10
Azores (see PORTUGAL)
Bp
BAHAMAS, THE ..... 6 ee te 12
BAHRAIN .. 0. ee ee 13
Balearic Islands (see SPAIN)
BANGLADESH .... 1 1 ee ee ee 14
BARBADOS ... 1... eee te 15
BELGIUM: (eg ce cen eee et Se SS 2 oe (ge OR ante ee ee ee de ee is 16
BELIZE? -se-) case & Bete ita 2k ok Pe WE PS eR a 17
BENIN: 6s. vice eee ce Ha Re ee a ee 19
BERMUDA ..... 2 ee ee te ee ee 20
BHUTAN © sfdw dee Se eh eo Re ea ce a oe ads 21
BOLIVIA: ce: 400 ee peas eRe te ee a es ce a ERs a he eb ey 22
BOTSWANA .. 0. ee 23
BRAZIL (fc hs, oe Ani ee Rta eee ae Blin ee, we A 24
British Honduras (see BELIZE)
BRITISH SOLOMON ISLANDS ........ Evite fen wet nig 2 chal aie oh 25
BRUNED «2 8% Sk we a Se ae a ee Oe ae Soe ee te 26
BULGARIA} “cco eRe ee HS we ee eG ee a Dei oh 27
BURMA fc oven SP he er ER ay RE ee Bee RE eas 28
BURUNDI .. 1... ee ee ee 30
—C=
Cabinda (see ANGOLA)
CAMBODIA . 2... ce ee 31
CAMEROON .... ee ee 32
GANADA) ~ 6 ce cece ae ee a eR ee ee ee 8 33
Canary Islands (see SPAIN)
CAPE VERDE. cs: e065 eck se 8 Sa ee ea Ra a es 34
CENTRAL AFRICAN EMPIRE ..... 6 ee et ee he ee ee 35
Ceylon (see SRI LANKA)
CHAD: (203 2 Gee ee ce eR a a Oe 37
CHIE ee oe er eee, ah ede NC see eal Ge ea a he st 38
CHINA, PEOPLES REPUBLIC OF ....-- ee eet ee res 39
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3 ii
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
—c— Page
CHINA, REPUBLIC OF ...........0. 0.000 ce eee ens 41
COLOMBIA ign ta. aoa ass Alp cc Ble ans Ek ea we Be 42
COMOROS ® is os da eo tice oe oan, Se ith ah deck Se lainbs ee can tyne ie 44
CONGO (Brazzaville)... ... 2. et 44
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS ............0. 0.00 eee neey 46
COSTA RICA: teense. Ah ek aaa eg ee Se aa clams Os 46
CUBA ci Ete ale dae ay So ed ee ee oe Dekel de 48
CYPRUS ®.. «boi eo anitein a ace year ay dies gis on doe ela ea ae ee 49
CZECHOSLOVAKIA «2... we 51
oe
Dahomey (see BENIN)
DENMARK. «5%. ce dhe Ge ok a ee th Me es oe ne BW ew 52
DOMINICA’ 2. se wie eine ati! wes Bone a oo oe, & 54
DOMINICAN REPUBLIC ............... 000 y eae 54
Dubai (see UNITED ARAB EMIRATES)
—-=
EGUADOR: f.c5-25 3S, hy ee ce ds ee ih al Ae BSS eles tt ee 56
EGYPT. keh Sask eat tated Bee arate ated oOo, Guballa hee 57
Ellice Islands (see TUVALU)
EL SALVADOR ... 1... tee ee te tet ts 58
EQUATORIAL GUINEA ..... 0.0... 0000 eee ee tne 60
EVGIORI As wil i wae ee Sh. are eds ay dh he Deng eS tes he a doe 61
Ps
FAROE ISLANDS ...........0.0 000, eee ee een ay 62
FALKLAND ISLANDS (MALVINAS) ...............04, 63
Fernando Po (see EQUATORIAL GUINEA)
FDU oe Spier tia hel tenes hie tes Sah gdh weve cals pie a Se igh ali’s se: ul eee at 64
FINLAND =< wii eect ee Wea hc ay a 4s anos Sle ae Hd Body ek eels 65
FRANCES oo cis oto aisiedhtes bat MR ea ae le OY acute ape pees dee see van 66
FRENCH GUIANA .... 1... 68
FRENCH POLYNESIA .... 1... ee ee 69
FRENCH TERRITORY OF THE AFARS AND ISSAS ........... 70
Fujairah (see UNITED ARAB EMIRATES)
—G—
GABON ..........0.. Wehses Gi a ae with kok ae te te eee le ti 71
GAMBIA: THE < ta: patna we ee aoe wt caw, ow roms Seg tea bea” 8 72
GERMAN DEMOCRATIC REPUBLIC ............08....0,. 73
GERMANY, FEDERAL REPUBLIC OF ................. 75
GHANA. eec8- ce cites lithas, to hee end a a) nti lenge ey og hi op ae ache he 76
GIBRALTAR: ce oid Se as ea aac 8 eR Oe Sages ke se Be oe nk 77
GILBERT ISLANDS... 2... 0. ee 78
GREECE secon S in FPG tenets ak oes ah a usay Se ee he dee ae 79
GREENLAND ... 2... ee ee ee 81
GRENADA. ps Saco gh ea ate a ae ae WA ode Bree awd hed gee 82
QUADELOU PE ie ise hot 8 eres a a oe AO eb oe dae eo aes 82
GUATEMALA .. ww. ee ee 83
GUINEA Y i et hee eae ae Ea oe 9 EON dai hee ae ces 85
GUINEA-BISSAU .. 2. 2. ee eg 86
Guinea, Portuguese (see GUINEA-BISSAU)
GUNANA® iis se Gee seed Beane A ne Me a ae eae ae ee Bec 87
iv Approved For Release 2005/04/22 : CIA-RDP79-01051A00080001 0006-3
Approved For Release 2005/04/22
January 1977
—H—','41cc811d55ff553b121a1a42e167578974a731b0f6c7831a03c2c70dd055fe54','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41c92738bf2bc93ce7e25e5505664ed5e2226aa5c7de725e34a490caa4f8262d',1977,'MZ','Mozambique','raw',2,'Pe ee ee ae
Approved For Release 2005/04/22 :
: CIA-RDP79-01051A000800010006-3
Pr ee ee
Pa er ee
Ce
CIA-RDP79-01051A000800010006-3
we
v
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
—N— Page
Namibia (see SOUTH WEST AFRICA) ;
NAURU) os vee es, be ee a ge ee a Ga ae oes Ue Se 143
NEPAL olive 8 a Se de BN Sn Gat Re ee ee She a as Ed! te ae dee hee 143
NETHERLANDS © oie oc a ed, ee aa ee Go a Wn a 145
NETHERLANDS ANTILLES .........0.. 0... 000 peas 146
NEW CALEDONIA) .-<- ee ae de ce ee Be a ce ap ae 148
NEW HEBRIDES .... 1... 2... ee ea 149
NEW ZEACAND® © 20 ie aclite Sus eas Glew Ro Ge we eee Gy ke en 149
NICARAGUA .. 2. 1 2 ee 151
NIG Ey lis BAS wes? ante a. ae iy Rade Ge Seda wy) Gide © aa ae ude ob ok 152
NIGERIAS | Ay te2 Soiewity Siig: Seg muted, Goede Se aes ati bebe ae eben ee 153
Northern Rhodesia (see ZAMBIA)
NORWAY. © c2 bod So tah Seton San GP Bre Na aad Te ge a ae Ae ad ee Ay ahve 154
—Oo—
OMAN" 5 5.3: seta oe Sede aries oes ee A A ae ce ln 156
Pie
PAKISTAN: — 6 Gi: eae eek 8 a ee a aw Ao Se ee eh ee 157
PANAMA: i. sy aca aR ak wane alate hat abel bee we 158
PAPUA NEW GUINEA ..........0.000 0.0000 2 eee 159
PARAGUAY! oo. ee eoteat ial alte boo Sel a ata ae a he ea an 161 -
Pemba (see TANZANIA)
PERU) fy.) cece Wee a wi 8 toad, Boia nh A Men a ae, ke, dew ead ah a 162
PHILIPPINES: of) 0st -kse od Saxena beds SA had. bbl ee 8 163
POLAND? 685. oa ak we ee Se a a Ko ce have eon as 165
PORTUGAL. 0-560 vie wih vino Gate Bb ocean bP tne ake a” Se oe an wed 166
Portuguese Guinea (see GUINEA-BISSAU)
Portuguese Timor (see INDONESIA)
=O.
QATAR) e6s.12 & ere ee hed ch ee ete Bea Be ee 168
=A
Ras al Khaimah (see UNITED ARAB EMIRATES)
REUNION® tx 42-2 @ as Greece Bek ete Rae be. RARE ee hak 169
RHODESIA! =o. joc ese Pe le eee eas eh eae sie VE ae Oe tt 170
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA! o> pce a 4 a la. cy Be ey ee WE AO Ee ape Stes ae 171
RWANDA} ch 68 25 Fea Bas er we as aS WE a a ae at ols, Beate Bok 172
=S
ST. CHRISTOPHER-NEVIS-ANGUILLA ...........0....040., 173
ST MEU CIA ses alte pce ay cerca 2 Ee age cask ee en Woke ow BN bh dda 174
STAVINCENT secu Sede de! Bap ee boked <e eels ee aU Aleta ae | 175
SAN /MARINO® (congo. oe a ee cee A Ra cetacean 176
SAO TOME and PRINCIPE ........... 0.0.00 0b ees 177
SAUDI ARABIA... 1. ee ee 178
SENEGAL. wc Fits Ge Se oh a ade Oy dan ge Bb eo Oe Ge 179
SEYCHELLES). 3 acts ae te aA ee Aen eae, Soe lee 180
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE: 6.6. i oe eke ce SS dpe a ee ede bw a 181
SINGAPORE 65.2 je feck Goi Gee de oe heh bo we ROS we A 183
SOMALIA. 22:3 se vie erage fak cere he, ee See gg ae Been 4 184
bs Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3 _
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
—sS— Page
SOUTH AFRICA ... 2... eee ts “ca bin as seed SEI OAT ie es oS 185
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA . 1... ee ee 187
SPAIN. ’va aod ve. was Sudha ce ace ten ects wees a a at ee a ER th 189
Spanish Sahara (see WESTERN SAHARA)
SRI LANKA (formerly Ceylon) . 2. 6 1 ee ee 191
SUDAN. vs ar ates ca a a ye ae reece 192
SURINAM) 50 oe ar Bl tee ear at el le Geeks BP ge Be ee 194
SWAZILAND vseci se poate anes elena dw edb as aael en, Bene BNE ake 195
SWEDEN og pes oe sid bee a ec Ae a ee oa ca Ve Bh 196
SWITZERLAND 2... ww wt et ee 197
SY RIA ae hs ee img ds Me Ra Sha a aR SP Tat ag oe ae ane Re See ah a 199
Tf
Tanganyika (see TANZANIA)
TANZANIA.) Se di oe, eo hl AL OO a Ne 200
Tasmania (see AUSTRALIA) ;
THAILAND: UA S Stee ear a a ne Oe Ve Ge ae ee 202
TOGO.) grok ae HR ee SO Geet eS eee Nie Se. aie hase 203
TONGA, (ecs os, Bocas os a Bt Be Pie oe ee ee es ee TE Peay 204
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ... 1 7 6 ee ee 205
TUNISIA. =. oe ee ce hee A Ra te eB ee So ces a SRA 206
TURKEY: -3--4.02-G8 803 2a Bete ene BP ee a ec ee eh, Ge a 207
TUVALU (formerly Ellice Islands) «6 6 6 1 ee ee ee 209
—y—
GANDA: 6 tis esd. ee cep ae We Se ae ek ca ae ee ee 209
Umm al Qaiwain (see UNITED ARAB EMIRATES)
CES SHR ny Sd a Geos Se yes Dee etl ete eae ee ae, ie aa 210
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qalwain .. 2... 1 2 ee ee 212
United Arab Republic (see EGYPT)
UNITED KINGDOM .. 1. ww ee 213
UNITED STATES . 1.0 2 ee ee 229
UPPER VOLTA’ > cc: cces6 8 tae Ga ER A ie ea Ree 215
WRUGUAY (een oe a A en, Ge ee he dec ae ek PS 216
—Vo=
VATICANCITY:- Saral ac € <8 ace ag ht Pew Hee Sw Pea 217
VENEZUELA. 5. i: ese ce ee ee a a OE ee °218
VIETNIANA act, 408 eae bee da BAO as hy Ace oe aa ee aad 219
—w—
WALLIS and FUTUNA . ww ww ee ee 220
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly SPANISH SAHARA) ......-. 2-4 > 221
WESTERN SAMOA. ww ww ee ee 222
-—Y—
YEMEN (Aden) «wg ww ee 223
YEMEN (Sata)? <4 3.0 wiles gees Gay ee Ge a eh we oe go 224
VUGOSLAVIA® in) eee 25 ke ae BS eee he a es Me 225
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3 "
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
—7Z—
ZAIRE: 3, ce Gis ate en a ean heat ans gl Site. ck dvds be wiht So or ok 226
ZAMBIA fos is ok dh herds ap Aig at wb cae, g tera dames Go de 4 i ee, 228
Zanzibar (see TANZANIA)
MAPS
Additional copies may be obtained from CIA Map Library
| CANADA
ll MIDDLE AMERICA
ltl SOUTH AMERICA
IV EUROPE
V THE MIDDLE EAST
VI AFRICA
Vil U.S.S.R. and ASIA
Vill OCEANIA
“ Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
IADB
IDB
IEA
IHO
IPU
IRC
LAFTA
LICROSS
NATO
Afro-Asian People’s Solidarity Organization
Aslan Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand,
and the United States
Association of Southeast Aslan Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market
Caribbean Free Trade Association
West African Economic Community
Councll for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey,
Niger, Upper Volta, and Togo
European Space Research Organization
European Atomic Energy Community
Inter-American Defense Board
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parllamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
North Atlantic Treaty Organization
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
*
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OAS Organization of American States
OAU Organization of African Unity
-OCAM Afro-Malagasy and Mauritian Common Organization
ODECA Organization of Central American States
OECD Organization for Economic Cooperation and Development
SELA Latin American Economic System
UDEAC Economic and Customs Union of Central Africa
UEAC Union of Central African States
WEU Western European Union
WCL World Confederation of Labor
WFTU World Federation of Trade Unions
WPC World Peace Council
COMMODITY ORGANIZATIONS
AIOEC Association of Iron Ore Exporting Countries
ANRPC Association of Natural Rubber Producting Countries
APC African Peanut (Groundnut) Council
ASSIMER International Mercury Producers Association
CIPEC Intergovernmental Council of Copper Exporting Countries
IATP International Association of Tungsten Producers
IBA International Bauxite Association
ICAC International Cotton Advisory Committee
IcCO International Cocoa Council
Ico International Coffee Organization
eee International Lead and Zinc Study Group
100C International Olive Oil Council
ISO International Sugar Organization
ITC International Tin Counell
IWC International Whaling Commission
IWC International Wheat Council
OAPEC Organization of Arab Petroleum Exporting Countries
OPEC Organization of Petroleum Exporting Countries
UPEB Union of Banana Exporting Countries
WSG International Wool Study Group
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
UNITED NATIONS (U.N.):; STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc
GA
ECOSOC
TC
ICJ
Operating Bodies:
UNCTAD
TDB
UNDP
UNICEF
UNIDO
Security Council
General Assembly
Economic and Social Council
Trusteeship Council
International Court of Justice
Secretariat
U.N. Conference on Trade and Development
Trade and Development Board
U.N. Development Program
U.N. Children''s Fund
U.N. Industrial Development Organization
Regional Economic Commissions:
ECA
ECE
ECLA
ECWA
ESCAP
Economic Commission for Africa
Economic Commission for Europe
Economic Commission for Latin America
Economic Commission for Western Asia
Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO
GATT
IBRD
ICAO
IDA
IFAD
IFC
ILO
IMCO
IMF (FUND)
ITU
UNESCO
UPU
WFC
WHO
WMO
Food and Agriculture Organization
General Agreement on Tariffs and Trade
International Bank for Reconstruction and Development
(World Bank)
International Civil Aviation Organization
International Development Association (IBRD Affiliate)
International Fund for Agricultural Development
International Finance Corporation (IBRD Affiliate)
International Labor Organization
Inter-Governmental Maritime Consultative Organization
International Monetary Fund
International Telecommunication Union
United Nations Educational, Scientific, and Cultural
Organization
Universal Postal Union
World Food Council
World Health Organization
World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA
International Atomic Energy Agency
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
xi
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
xii
Political, sociological, and economic data, including monetary conversion
rates, generally reflect information through mid-October 1976, except for
population estimates, which have been projected to 1 January 1977. Military
manpower estimates are as of 1 July 1976 except for average number of
males reaching military age, which are projected averages for the 5-year
period 1976-80. Military and communications data are as of 31 October 1976
unless otherwise indicated.
Most of the land utilization estimates are rough approximations, and most
of the statistical data are rounded (thousands and millions). Figures for
“arable” may reflect only the area actually under crops rather than the potential
cultivable. Fishing limits are included only when they differ from the territorial
limits.
For some countries GDP, rather than GNP, is shown. The difference
between the two is in the addition or subtraction of the value of return on
foreign investment. GDP equals GNP plus income earned in the country but
sent abroad, minus income earned abroad but sent into the country. GDP thus
tends to exceed GNP in debtor countries, and the reverse is true in creditor
countries.
Major ports are the largest maritime ports of the country, relative to other
ports of the same country, on the basis of estimated port capacity, alongside
berthing accommodations, and commercial or naval Importance. Minor ports
are the remaining ports of a country which have, relative to the major ports,
significantly lower estimated port capacity, fewer alongside berthing
accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S.
dollar equivalents. The dollar sign refers to U.S. dollars unless otherwise
Stated. The abbreviation FY stands for U.S. fiscal year; all years are calendar
years unless otherwise indicated.
Approximate Metric Conversions
Symbol When You Know = Multiply by To Find Symbol Symbol When You Know = Multiply by To Find Symbol
LENGTH LENGTH
mm millimeters 0.04 inches in in inches 2.5 centimeters em
cm centimeters 0.4 inches in ft feet 30 centimeters cm
m meters 3.3 feet ft yd yards 0.9 meters m
m meters 1 yards yd mi miles 1.6 kilometers km
km kilometers 06 miles mi
AREA
AREA in? square inches “65 square centimeters = cm?
cm? square centimeters 0.16 square inches in? f? squore feet 0.09 square moters m?
m? square meters 1.2 square yards yd? yd? square yards 0.8 square meters m
km? square kilometers 0.4 square miles mi? mi? square miles 2.6 square kilometers km?
ha hectares (10,000 m7} 2.5 acres acres 0.4 hectares ha
MASS (weight) MASS (weight)
9 grams 0.035 ounces oz oz ounces 28 grams g
kg kilograms 2.2 pounds Ib Ib pounds 0.45 kilograms kg
t tonnes (1000 kg) Vw short tons short tons Og fonnes
(2000 Ib)
VOLUME
ml milliliters 0.03 fluid ounces floz VOLUME
1 liters 2.1 pints pt tsp teaspoons 5 milliliters mi
I liters 1.06 = quarts qt Tbsp tablespoons 15 millititers ml
I liters 0.26 gallons gal floz — fluid ounces 30 milliliters mi
m cubic meters 35 cubic feet ft? c cups 0.24 liters (
m cubic meters 1.3 cubic yards yd? pt pints 0.47 liters i]
qt quarts 0.95 liters {
gal gallons 3.8 liters {
f cubic feet 0.03 cubic meters m
yd? cubic yards 0.76 cubic meters m?
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','4242da7d1b083cce31215fed483e661558d1c8f9e61fca6678dac29a85380d94','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d36beeb0fb77b29d0a35f95e3895f06ff7b45fdf3e86e432617e3f3abab57b2c',1977,'AF','Afghanistan','raw',3,'Kabul
ANISTAN
Arabian Sea
(See reference map Vil)
LAND
647,500 km?; 22% arable (12% cultivated, 10%
pasture), 75% desert, waste or urban, 3% forested
Land boundaries: 5,510 km','fa440a64a167c7c27a3606a7e662573e095f60e5a63374f8f2968439afd0943a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00af22750bb4f39ebeda4c10ca5ea0858c515ad6a37df00820acd186ac1e4fcc',1977,'AF','Afghanistan','people-and-society',4,'Population: 19,811,000 (January 1977), average
annual growth rate 2.3% (7-72 to 7-78)
Nationality; noun—Afghan(s); adjective—Afghan
Ethnic divisions: 50% Pushtuns, 25% Tajiks, 9%
Uzbeks, 9% Hazaras; minor ethnic groups include
Chahar Aimaks, Turkmen, Kizelbashes, and others
Religion: 87% Sunni Muslim, 12% Shia Muslim,
1% other
Language: 50% Pushtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily Uzbek and
Turkmen), 10% 30 minor languages (primarily
Baluchi and Pashai); much bilingualism
Literacy: under 10%
Labor force: about 4.3 million (1966 official est.);
75%-80% agriculture and animal husbandry, 20%-
25% commerce, small industry, services; massive
shortage of skilled labor
Organized labor: none','c401fdbab1b7f77ac4c701a63f4c33bb4baa40b6333208834af017b43c1ff490','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('815d63bea59018af8bb7fe4a3f23ace3f61592f1966bcabd62dc1043ee8c5e18',1977,'AL','Albania','people-and-society',9,'Population: 2,499,000 (January 1977), average
annual growth rate 2.4% (current)
Nationality: noun—Albanian(s); adjective—
Albanian
Ethnic divisions: 96% Albanian, remaining 4% are
Greeks, Vlachs, Gypsies, and Bulgarians
Religion: 70% Muslim, 20% Albanian Orthodox,
10% Roman Catholic (observances prohibited;
Albania claims to be the world’s first atheist state)
Language: Albanian, Greek
Literacy: about 70%; no reliable current statistics
available, but probably greatly improved
Labor force: 911,000 (1969); 60.5% agriculture,
17.9% industry, 21.6% other nonagricultural','1ede5a10cb31c409de2fdfe74df292a0f466bedde04a2a6e04901f8e46beaf9b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('656223369d34c2a35a4680d60e99b94e1689e41d1b7c1531821cc5cd7eff7745',1977,'DZ','Algeria','people-and-society',13,'Population: 17,558,000 (January 1977), average
annual growth rate 3.1% (7-74 to 7-75)
Nationality: noun—Algerian(s); adjective—
Algerian
Ethnic divisions: 99% Arab-Berbers, less than 1%
Europeans
Atlantic
Ocean
cy
Maditerrangs iy EE
(See raferonce mep V)
Religion: 99% Muslim, 1% Christian and Hebrew
Language: Arabic (official), French, Berber dialects
Literacy: 25% (5% Arabic, 9% French, 11% both)
Labor force: 2.8 million; 47% agriculture, 8%
industry, 24% other (military, police, civil service,
transportation workers, teachers, merchants,
construction workers); 40% of urban labor unem-
ployed
Organized labor: 17% of labor force claimed;
General Union of Algerian Workers (UGTA) is the
only labor organization and is subordinate to the
National Liberation Front','1aa4f0b1698a9220c36b066cd087d8778d5d304a61e2d68b3600b4959663bda8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('985405314f2768730e5a93cca8847ca6614dbd0b1a5050e8e325c2cfb8244c9e',1977,'AD','Andorra','people-and-society',17,'Population: 27,000 (official estimate for 1 July
1975)
Nationality: noun—Andorran(s); adjective—
Andorran
Ethnic divisions: Catalan stock; 830% Andorrans,
61% Spanish, 6% French, 8% other
Religion: virtually all Roman Catholic
Language: Catalan, many also speak some French
and Castilian
Labor force: unorganized; largely shepherds and
farmers','3ecc0c41d111fdfafe931766861cf4cd78a5a99e86f0d3f61108fd99d9c3bcba','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80b83ff9fe4722aa6da566d89c81eec1cb8cb7b690dc0f677494c7945a0064ca',1977,'AO','Angola','people-and-society',21,'Population: Angola, 6,148,000, does not take into
account recent emigration from Angola (January
1977); average annual growth rate 1.6% (12-60 to
12-70); Cabinda, 98,000 (January 1977), average
annual growth rate 3.3% (12-60 to 12-70)
_Nationality: noun—Angolan(s); adjective—
Angolan
Ethnic divisions: 93% African, 5% Europeans, 1%
mestizos
Religion: about 84% animist, 12% Roman
Catholic, 4% Protestant
Language: Portuguese (official), many native
dialects
Literacy: 10%-15%
Labor force: 2.6 million economically active
(1964); 581,000 wage workers (1967)
Organized labor: approx. 65,000 (1967)
Population: 71,000 (January 1977), average annual
growth rate 1.2% (7-70 to 7-75)
Nationality: noun—Antiguan(s); adjective—
Antiguan
Ethnic divisions: almost entirely African Negro
Religion: Church of England (predominant), other
Protestant sects and some Roman Catholic
Language: English
Literacy: about 80%
Organized labor: 18,000, 20% unemployment','5c05f821849a7fb282fc15e83a164557401fc814c135a539fcb9ae3618bb88ff','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcb00fb2ff12533d43a910bb42713f3dacfdb7fc914e22b0a94ab4c07749e3d7',1977,'AR','Argentina','people-and-society',25,'Population: 25,887,000 (January 1977), average
annual growth rate 1.3% (current)
Nationality: noun—Argentine(s); adjective—
Argentine
Ethnic divisions: approximately 85% white, 15%
mestizo, Indian, or other nonwhite groups
Religion: 90% nominally Roman Catholic (less
than 20% practicing), 2% Protestant, 2% Jewish, 6%
other
Language: Spanish
Literacy: 85% (90% in Buenos Aires)
CIA-RDP79-01051A000800010006-3
X
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Labor force: 10 million; 19% agriculture, 25%
manufacturing, 20% services, 11% commerce, 6%
transport and communications, 19% other
Organized labor: 25% of labor force (est. )','1c45bab8b239c814a9fbe97014a41005eec5d5392a57ae971e87c64b6af06c7b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bce00f6eefc98161cfccec94301f25578b9ff20918bc8590cd57708ad8a77df1',1977,'AU','Australia','people-and-society',29,'Population: 13,808,000 (January 1977), average
annual growth rate 1.7% (1-66 to 1-76)
Nationality; noun—Australian(s); adjective—
Australian
Ethnic divisions: 99% Caucasian, 1% Asian and
aborigine
Religion: 98% Christian
Language: English
Literacy: 98.5%
Labor force: 4.76 million; 14% agriculture, 32%
industry, 87% services, 15% commerce, 2% other
Organized labor: 44% of labor force','9b32a6f7d02ed940eb0a950a5796dba1f3ed95e14b19480a3dcf031e8a4c957a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e02062b35ebab02196bf8d9e4830e5b8a24682a3d17ca6aa6b263bcf581480c1',1977,'AT','Austria','people-and-society',35,'Population: 7,524,000 (January 1977), average
annual growth rate 0.1% (1-78 to 1-76)
Nationality: noun—Austrian(s); adjective—
Austrian
Ethnic divisions: 98.1% German, 0.7% Croatian,
0.3% Slovene, 0.9% other
Religion: 85% Roman Catholic, 7% Protestant, 8%
none or other
Language: German
Literacy: 98%
Labor force: 2,656,922 (1974); 18% agriculture
and forestry, 49% industry and crafts, 18% trade and
communications, 7% professions, 6% public service,
2% other; 2.4% registered unemployed; an estimated
200,000 Austrians are employed in other European
countries; foreign laborers in Austria number more
than 200,000 (1972); unemployment 2.0% (August
1975)
Organized labor: about two-thirds of wage and
salary workers (1971)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Population: 213,000 (January 1977), average
annual growth rate 2.8% (7-78 to 7-75)
Nationality: noun—Bahamian (sing., pl.); ad-
jective—Bahamian
Ethnic divisions: 80% Negro, 10% white, 10%
mixed
Religion: Baptists 29%, Church of England 23%,
Roman Catholic 23%, smaller groups of other
Protestant, Greek Orthodox, and Jews
Language: English
Labor force: 84,228 (1976); 25% organized
Population: 269,000 (January 1977), average
annual growth rate 3.3% (2-65 to 7-75)
Nationality: noun—Bahraini(s); adjective—
Bahraini
Ethnic divisions: 90% Arab, 7% Iranian, Pakistani,
and Indian, 3% other; native Bahrainis are a minority
Religion: Muslim
Language: Arabic, English also widely spoken
Literacy: about 40% (1970)
Labor force: 78,507 (1976)','d6d6dc5b28ea001cc668425347934c7404be95523b5f1ec62530b57614dcc330','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('371b82ab7725ad381a044a3508f816c86b26a33ebcf09b7906f9bf69f278294a',1977,'BD','Bangladesh','people-and-society',40,'Population: 76,565,000 (January 1977), average
annual growth rate 2.8% (current)
Nationality: noun—Bangladeshi(s); adjective—
Ethnic divisions: predominantly Bengali; fewer
than 1 million “Biharis’ and fewer than 1 million
tribals
Religion: about 83% Muslim, 16% Hindu; less
than 1% Buddhist and other
Language: Bengali
Literacy: about 25%
Labor force: over 26 million; extensive un-
deremployment; over 80% of labor force is in
agriculture
14
Approved For Release 2005/04/22','68ecb565e622019dee70fe337b48b0d37bb861dca28f6a4bb755c97f837b2de4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f6bc0ed3a4d1c60648fe377b76c7ea80104ea327a101d6deae3adab4c8d677',1977,'BB','Barbados','people-and-society',44,'i ia 239,000 (official estimate for 1 July
1973
Nationality: noun—Barbadian(s); adjective—
Barbadian
Ethnic divisions: 80% African, 17% mixed, 4%
European
Religion: Anglican, Roman Catholic, Methodist,
and Moravian
Language: English
Literacy: over 90%
Labor force: 97,000 (1978 est.) wage and salary
earners; unemployment 20-25% (1976)
Organized labor: 32%','cb54a77dfc11d929f25a85d709a7a2e0f846a463b38ee4fea2f8f8bb58b4143a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f28e450dbfde7de32186b86af5484529175e48179561fa35c609173c28ff7f7',1977,'BE','Belgium','people-and-society',48,'Population: 9,826,000 (January 1977), average
annual growth rate 0.1% (current)
Nationality: noun—Belgian(s); adjective—Belgian
16
Approved For Release 2005/04/22
(Sea reference map IV)
Ethnic divisions: 55% Flemings, 33% Walloons,
12% mixed or other
Religion: 97% Roman Catholic, 3% none or other
Language: French, Flemish (Dutch), German, in
small area of eastern Belgium; divided along ethnic
lines
Literacy: 97%
Labor force: 4.0 million; approximately 95% is
found in the following sectors: 32% manufacturing,
24% services, 16% commerce, banking, and insurance,
8% construction, 7.5% transportation and communi-
cation, 4% agriculture, forestry, and fishing, 1.2%
mining, 0.8% public utilities and sanitary services
(1972); 7.0% unemployed, September 1975
Organized labor: 48% of labor force (1969)','47bd8e187e3192b7c3c7013abf060e45865758e51669c5623ab28ec1d67724f2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b2e1142014205a74fbacf12e3c9fd7d560af8975a77fc5f9fdb2fcc46c77732',1977,'BZ','Belize','people-and-society',52,'Population: 145,000 (January 1977), average
annual growth rate 2.9% (current)
Nationality: noun—Belizean(s); adjective—
Belizean
Ethnic divisions: 51% Negro, 22% mestizo, 19%
Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-day Adventist, Methodist, Baptist, Jehovah''s
Witnesses, Mennonite
Language: English, Spanish, Maya, and Carib
Literacy: 70%-80%
Labor force: 34,500; 39% agriculture, 14%
manufacturing, 8% commerce, 12% construction and
transport, 20% services, 7% other; shortage of skilled
labor and all types of technical personnel; over 15%
are unemployed
Organized labor: 8% of labor force','3ad3c08d4fe57ae529b7aed43a8ec526e845d8753294e08f2d661479c58c2209','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4cea0c8354e2ca033180185e2d73f8c5856ddc97044987a254875164dc251d0',1977,'BJ','Benin','people-and-society',56,'Population: 3,235,000 (January 1977), average
annual growth rate 2.8% (8-72 to 8-74)
Nationality; noun—Beninese (sing. & pl.);
adjective—Beninese
Ethnic divisions: 99% Africans (42 ethnic groups,
most important being Fon, Adja, Yoruba, Bariba),
5,500 Europeans
Religion: 12% Muslim, 8% Christian, 80% animist
Language: French official; Fon and Yoruba most
common vernaculars in south, at least 6 major tribal
languages in north
Literacy: about 20%
Labor force: 85% of labor force engaged in
agriculture; 15% civil service, artisans, and industry
Organized labor: approximately 75% of wage
earners, divided among two major and several minor
unions','0b8732948852090c0eec2c72483e9ea399f75ea384fddf27ee5e69a9e6ef907e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8d1eecaf13ecb99eea94db7d074330a73dc79c19dc7143cf6fb74f3fce8e2ca',1977,'BM','Bermuda','people-and-society',60,'Population: 57,000 (January 1977), average annual
growth rate 1.5% (7-70 to 7-75)
Nationality: noun—Bermudan(s); adjective—
Bermudan
Ethnic divisions: approximately 63% African, 37%
white
Religion: 47.5% Church of England, 38.2% other
Protestant, 10.2% Catholic, 4.1% other
Language: English
Literacy: virtually 100%
Labor force: 25,200 (1975)','7b7013b7fef76696e7ae9d6cbf353f74fe2434305c65acc147e1320f27321a7d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9899ba64c207c26fe5ba98808c3a8beacf498af9ea8cbc2f2cf779d4c0963a1',1977,'BT','Bhutan','people-and-society',64,'Population: 1,217,000 (January 1977), average
annual growth rate 2.5% (current)
Nationality: noun—Bhutanese (sing., pl.);
adjective—Bhutanese
Ethnic divisions: 60% Bhotias, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25% Bud-
dhist-influenced Hinduism
Language: Bhotias speak various Tibetan dialects,
most widely spoken dialect is Dzongkha, the official
language; Nepalese speak various Nepalese dialects
Literacy: insignificant
Labor force: 300,000; 99% agriculture, 1%
industry; massive lack of skilled labor','b50edd664c3b34737b8b446bc0f151a1a196ffbfc0a80b4758c17abe77420748','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ab873002282c801a355d77587cf9194bf6101c687a20b857b5f5ebba401260e',1977,'IN','India','people-and-society',69,'Population: 5,624,000 (January 1977), average
annual growth rate 2.6% (current)
Nationality: noun—Bolivian(s); adjective—
Bolivian
Ethnic divisions: 50%-75% Indian, 20%-35%
mestizo, 5%-15% white
Religion: predominantly Roman Catholic; active
protestant minority, especially Methodist
Language: Spanish, Aymara, Quechua
Literacy: 835%-40%
Labor force: 2.5 million (1972); 69.1% agriculture,
3.3% mining, 9.6% services and utilities, 8%
manufacturing, 10% other
Organized labor: 150,000-200,000, concentrated in
mining, industry, construction, and transportation
Population: 684,993,000, including Sikkim and the
Indian-held part of disputed Jammu- Kashmir
(January 1977), average annual growth rate 2.2%
(current)
Nationality: noun—Indian(s); adjective—Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dravidian,
3% Mongoloid and other
Religion: 83.5% Hindu, 10.7% Muslim, 1.8% Sikh,
2.6% Christian, 0.7% Buddhist, 0.7% other
Language: 24 languages spoken by a million or
more persons each; numerous other languages and
dialects, for the most part mutually unintelligible;
Hindi is the national language and primary tongue of
30% of the people; English enjoys “associate” status
but is the most important language for national,
political, and commercial communication; Hindu-
stani, a popular variant of Hindi/Urdu, is spoken
widely throughout northern India
Literacy: males 39%; females 18%; both sexes 29%
(1971 census)
Labor force: about 197 million, 70% agriculture,
more than 10% unemployed and underemployed;
shortage of skilled labor is significant and
unemployment is rising
Organized labor: about 2.5% of total labor force','7bcc1e53a9a9c6ce60004dc771feb01335f6c8707ce6eaeb19b53c8729d4292f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3a4511bee7b8c7d2d6391bde1ac3e3d5b32d0c245c72b1a1f9761de6f333cb',1977,'BW','Botswana','people-and-society',71,'Population: 720,000 (January 1977), average
annual growth rate 2.6% (current)
Nationality: noun—Batswana (sing., pl.); ad-
jective—Botswana
Ethnic divisions: 94% Tswana, 5% Bushmen, 1%
European
Religion: 85% animist, 15% Christian
Language: Africans speak Tswana vernacular
Approved For Release 2005/04/22 :
Atlantic
Ocean
(See reference map V1)
Literacy: about 22% in English; about 32% in
Tswana; less than 1% secondary school graduates
Labor force: 385,000; most are engaged in cattle
raising and subsistence agriculture; about 51,000 in
internal cash economy, another 60,000 spend at least
6 to 9 months per year as wage earners in South Africa
(1971)
Organized labor: eight trade unions organized with
a total membership of approximately 9,000 (1972 est. )','2a777d4fb9efd3dc9fd6b12f1707e693b16948a6c00fc6297d2019990fba4aee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b84d0f62f7dddb4cd57d729e40fbd7f131debb3c3f5bbe17dadc9b001df6f08',1977,'BR','Brazil','people-and-society',75,'Population: 111,666,000 (January 1977), average
annual growth rate 2.8% (current)
Nationality: noun—Brazilian(s); adjective—
Brazilian
Ethnic divisions: 60% white, 30% mixed, 8%
Negro, and 2% Indian (1960 est.)
Religion: 93% Roman Catholic (nominal)
Language: Portuguese
Literacy: 67% of the population 15 years or older
(1970)
Labor force: about 30 million in 1970 (est.); 44.2%
agriculture, livestock, forestry, and fishing, 17.8%
industry, 15.8% services, transportation, and
communication, 8.9% commerce, 4.8% social
activities, 3.9% public administration, 5.1% other
Organized labor: about 50% of labor force; only
about 1.5 million pay dues
Population: 203,000 (January 1977), average
annual growth rate 3.4% (2-70 to 2-76)
Nationality: noun—British Solomon Islander(s);
adjective—British Solomon Islander
25
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BRITISH SOLOMON ISLANDS/BRUNEI
BRITISH SOLOMON
Sq ISLANDS
ck
ys
Coral Sea
Pacific
Ocean
{See reference map Vill}
Ethnic divisions: 93.0% Melanesians, 4.0%
Polynesians, 1.5% Micronesians, 0.3% Chinese, 0.8%
Europeans, 0.4% others
Religion: almost all at least nominally Christian;
Roman Catholic, Anglican, and Methodist churches
dominant
Literacy: 60%
Population: 163,000 (January 1977), average
annual growth rate 3.4% (8-71 to 7-74)
Nationality: noun—Bruneian(s); adjective—
Bruneian
Ethnic divisions: 52% Malays, 28% Chinese, 15%
indigenous tribes, 5% other
Religion: 60% Muslim (Islam official religion); 8%
Christian; 82% other (Buddhist and animist)
Language: Malay and English official, Chinese
Literacy: 45%
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BRUNEI/BULGARIA
Labor force: 32,155; 30.5% agriculture; 32.8%
industry, manufacturing, and construction; 33.8%
trade, transport, services; 2.9% other
Organized labor: 8.4% of labor force','4f7f77923b0368eac69d9888816efb7592347b67b1cb6eeb0ef48334fea7fe2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c69e8a08aac7ab791dcf6b898bf6dd2a1528dbf71b9347750120a46165286e',1977,'BG','Bulgaria','people-and-society',79,'Population: 8,795,000 (January 1977), average
annual growth rate 0.7% (current)
Nationality; noun—Bulgarian(s); adjective—
Bulgarian
Ethnic divisions: 85.3% Bulgarians, 8.5% Turks,
2.6% Gypsies, 2.5% Macedonians, 0.8% Armenians,
0.2% Russians, 0.6% other
Religion: regime promotes atheism; religious
background of population is 85% Bulgarian
27
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : €CIA-RDP79-01051A000800010006-3
January 1977
BULGARIA/BURMA
Orthodox, 13% Muslim, 0.8% Jewish, 0.7% Roman
Catholic, 0.5% Protestant, Gregorian-Armenian and
other
Language: Bulgarian; secondary languages closely
correspond to ethnic breakdown
Literacy: 95% (est. )
Labor force: 5.0 million (1974); 32% agriculture,
33% industry, 35% other
Population: 31,501,000 (January 1977), average
annual growth rate 2.3% (7-70 to 7-78)
Nationality: noun—Burman(s); adjective—Bur-
mese
Ethnic divisions: 72% Burman, 7% Karen, 6%
Shan, 2% Kachin, 2% Chin, 2% Chinese, 3% Indian,
6% other
Religion: 85% Buddhist, 15% animist and other
Language: Burmese; minority ethnic groups have
their own languages
Literacy: 70% (official claim)
Labor force: 11.9 million (1975); 67% agriculture,
13% industry, 20% services, commerce, and','56a25cd10c66d8bb17da70bedefd1e0ed9b93e7ac34e631415ec6113404809cc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('714f5da36ac6d17fe594e5f3f3788b0799a764aff2cb9f24c083314236fcf770',1977,'BI','Burundi','people-and-society',84,'Population: 38,897,000 (January 1977), average
annual growth rate 2.4% (7-70 to 7-75)
Nationality: noun—Burundian(s); adjective—
Burundian
Ethnic divisions: Africans—85% Hutu (Bantu),
14% Tutsi (Hamitic), 1% Twa (Pigmy); other Africans
include perhaps 50,000 Zairians and 40,000
Rwandans; non-Africans include about 8,000
Europeans-and 1,000 South Asians
Religion: about 60% Christian (53% Catholic, 7%
Protestant); rest mostly animist plus perhaps 2%
Muslims
Language: Kirundi and French official plus
Swahili (along Lake Tanganyika and in the
Bujumbura area)
Literacy: about 15% in Kirundi, 3% in French, no
serviceable estimate for Kiswahili
Labor force: about 2 million (1976 est.)
Organized labor: sole group is the Union of
Burundi Workers (UTB); by charter, membership is
extended to all Burundi workers (informally); figures
denoting “active membership” have been unob-
tainable
80
Approved For Release 2005/04/22','80e3b189649af1dc2bbef811951e384142d0d9559ab3c9f10877c4d067f89dfa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62d32fbe6037c8341449e31505bdf6a10419cb8d24c0cbbb4374829dad262e55',1977,'KH','Cambodia','people-and-society',88,'Population: 7,887,000 (January 1977), average
annual growth rate 2.2% (7-68 to 7-69)
Nationality; noun—Cambodian(s) or Khmer
(sing., pl.); adjective—Cambodian or Khmer
Ethnic divisions: 89% Khmer (Cambodian), 5%
Chinese, 3% Vietnamese, 3% other minorities
Approved For Release 2005/04/22 :
Religion: 95% Theravada Buddhism, 5% various
other
Language: Cambodian
Literacy: 55% (est.)','2d9b1c947db15df81eb4c10b1dd59ae89c332c34ff47915db38b79d703bd3a41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c136b0c317362c1f63ae2dcbeb59949a4677bc992add30b5a4a0ed5c5186fa81',1977,'GN','Guinea','people-and-society',91,'Population: 6,588,000 (January 1977), average
annual growth rate 2.1% (current)
Nationality: noun—Cameroonian(s); adjective—
Cameroonian
Ethnic divisions; about 200 tribes of widely
differing background; 31% Cameroon Highlanders,
19% Equatorial Bantu, 8% Northwestern Bantu, 10%
82
Fulani, 7% Eastern Nigritic, 11% Kirdi, 18% other
African, less than 1% non-African
Religion: about one-half animist, one-third
Christian; rest Muslim
Language: English and French official, 24 major
African language groups
Literacy: South 40%, North 10%
Labor force: most of population engaged in
subsistence agriculture and herding; 200,000 wage
earners (maximum) including 22,000 government
employees, 68,000 paid agricultural workers, 49,000 in
manufacturing
Organized labor: under 45% of wage labor force
Population: 4,584,000 (January 1977), average
annual growth rate 2.5% (current)
Nationality: noun—Guinean(s); adjective—
Guinean
Ethnic divisions: 99% African (3 major tribes—
Fulani, Malinke, Susu; and 15 smaller tribes)
Religion: 75% Muslim, 25% animist, Christian, less
than 1%
Language: French official; each tribe has own
language
Atlantic Ocean
(Sea reference map Vi}
Literacy: 5% to 10%; French only significant
written language
Labor force: 1.8 million, of whom less than 10%
are wage earners; most of population engages in
subsistence agriculture
Organized labor: virtually 100% of wage labor
force loosely affiliated with the National Confedera-
tion of Guinean Workers, which is closely tied to the
PDG
Population: 7,045,000, resident African population
only (January 1977), average annual growth rate 3.3%
(current)
Nationality: noun—Ivorian(s); adjective—Ivorian
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of population;
most important are Agni, Baoule, Krou, Senoufou,
Mandingo; approx. 1 million foreign Africans, mostly
Upper Voltans; about 33,000 non-Africans (25,000
French)
Religion: 66% animist, 22% Muslim, 12%
Christian
Language: French official, over 60 native dialects,
Dioula most widely spoken
Literacy: about 65% at primary school level
Labor force: over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of
labor force are wage earners, nearly half in agricul-
ture, remainder in government, industry, commerce,
and professions
Organized labor: 20% of wage labor force','789b87356b31b2d110343debe2eea58e21bf41518632cfba2f71d04b46c481db','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df8a3264416b282203cfdcd5c3c7bb86f436a8f05784798d5e96a9be646b31b6',1977,'CA','Canada','people-and-society',94,'Population: 23,314,000 (January 1977), average
annual growth rate 1.4% (7-70 to 7-75)
Nationality: noun—Canadian(s); adjective—
Canadian
Ethnic divisions: 44% British Isles origin, 30%
French origin, 26% other
Religion: 48% Protestant, 47% Catholic, 5% other
Language: English and French official
Labor force: 10.0 million; 29% service, 22%
manufacturing, 16% trade, 8% transportation and
utilities, 6% agriculture, 6% construction, 8% other,
7.0% unemployed
Organized labor: 27% of labor force
Population: 299,000 (January 1977), average
annual growth rate 1.0% (7-74 to 7-75)
Nationality: adjective—Cape Verdian
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CAPE VERDE/CENTRAL AFRICAN EMPIRE
CAPE VERDE
ae oye
to]
Praia
a
so ®
Atlantic Qcean BISSAU
wr
(See reference map {V}
Ethnic divisions: about 28% African; 70%
mulatto; 2% European
Religion: Catholicism, fused with local supersti-
tions
Language: Portuguese and crioula, a blend of
Portuguese and West African words
Literacy: 14%
Labor force: bulk of population engaged in
subsistence agriculture
Population: 1,846,000 (January 1977), average
annual growth rate 2.2% (7-67 to 7-71)
Nationality: noun—Central African(s); adjective—
Central African
35
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CENTRAL AFRICAN EMPIRE
Ethnic divisions: approximately 80 ethnic groups,
the majority of which have related ethnic and
linguistic characteristics; Banda (82%) and Baya-
Mandjia (29%) are largest single groups; 6,500
Europeans, of whom 6,000 are French and majority of
the rest Portuguese
Religion: 40% Protestant, 28% Catholic, 27%
animist, 5% Muslim; animistic beliefs.and practices
strongly influence the Christian majority
Language: French official; Sangho, the lingua
franca and unofficial national language
Literacy: estimated at 5%-10%
Labor force: about half the population economi-
cally active, 80% of whom are in agriculture;
approximately 64,000 salaried workers
Organized labor: 1% of labor force','3c2e9e36a6206bbeb0b8f707a80e92e70674fbac0d8d6fd1cd04fb99bf881c26','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92a5bc749524be75cbc8a25b79c9a7fdb2bcc2b97b89ac3a6b9b4a7c327173da',1977,'TD','Chad','people-and-society',98,'Population: 4,155,000 (January 1977), average
annual growth rate 2.1% (7-72 to 7-75)
Nationality; noun—Chadian(s); adjective—
Chadian
Ethnic divisions: over 240 tribes representing 12
major ethnic groups—Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou, Baguirmi,
Boulala, and Wadai) in the north and center and non-
Muslims (Sara, Mayo-Kebbi, and Chari) in the south;
some 150,000 nonindigenous, 5,000 of them French
Religion: about half Muslim, 5% Christian,
remainder animist
Language: French official; Chadian Arabic is
lingua franca in north, Sara and Sangho in south
Literacy: estimated 5%-10%
Labor force: only 55% of population in
economically active group, of which 90% are engaged
in unpaid subsistence farming, herding, and fishing;
47,000 wage earners in industry and civil service
Organized labor: about 20% of wage labor force','01311a96d35cdeff9f0773d117d5fac40c330332ea25cb60d0fd8038ad912024','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca96b130ce8d48821205ede8f2198bc6345d6e435e0051d37a8f7eb099a35db7',1977,'CL','Chile','people-and-society',102,'Population: 10,543,000 (January 1977), average
annual growth rate 1.9% (current)
Nationality: noun—Chilean(s); adjective—
Chilean
Ethnic divisions: 95% European stock and mixed
European with some Indian admixture, 3% Indian,
2% other
Religion: 89% Roman Catholic, 11% Protestant
Language: Spanish
Literacy: 89%
Labor force: 8.8 million (1973); 19% agricultural,
28% industry and construction, 29% services, 14%
commerce, 5% mining, 5% other (1978)
Organized labor:.25% of labor force (1973)
Population: 958,540,000 (January 1977), average
annual growth rate 1.5% (current)
Nationality: noun—Chinese (sing., pl.); adjec-
tive—Chinese
Ethnic divisions: 94% Han Chinese; 6% Chuang,
Uighur, Hui, Yi, Tibetan, Miao, Manchu, Mongol,
Pu-I, Korean, and numerous lesser nationalities
Religion: most people, even before 1949, have been
pragmatic and eclectic, not seriously religious; most
important elements of religion are Confucianism,
Taoism, Buddhism, ancestor worship; about 2%-3%
Muslim, 1% Christian
Language: Chinese (Mandarin mainly; also
Cantonese, Wu, Fukienese, Amoy, Hsiang, Kan,
Hakka dialects), and minority languages (see ethnic
divisions above)
Literacy: at least 25%
Labor force: 335 million (mid-1966); 85%
agriculture, 15% other; shortage of skilled labor
(managerial, technical, mechanics, etc.); surplus of
unskilled labor','6571273f18597e2690bee00e78b73417c3d39bf7552d9b4071c4c1286a5d5bdb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b9c5bb17471b7920312687734b567e03502741cfb8aa816445ae7dc2fc321e9',1977,'CN','China','people-and-society',106,'Population: 16,453,000, excluding the population
of Quemoy and Matsu Islands and foreigners
(January 1977), average annual growth rate 1.9%
(1-75 to 1-76)
Nationality: noun—Chinese (sing., pl.); adjec-
tive—Chinese
Ethnic divisions: 84% Taiwanese, 14% mainland
Chinese, 2% aborigines
Religion: 93% mixture of Buddhism, Confucian-
ism, and Taoism; 4.5% Christian; 2.5% other
Language: Chinese Mandarin (official language),
also Taiwanese and Hakka dialect
Literacy: about 90%
Labor force: 4.9 million; 38% primary industry
(agriculture), 32.1% secondary industry (including
manufacturing, mining, construction), 34.9% tertiary
industry (including commerce and services) 1972; 5%
unemployment (1975 est.)
Organized labor: about 12% of 1972 labor force
(government controlled)','4c99486d6b69c0b07a1af1495e71c37af28978c57ced4950e1d792011a4f6d08','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6cf230d7a8cd0e132290a8058664807f6a94747b73ff0c965c2dcaf1a86099e',1977,'CO','Colombia','people-and-society',110,'Population: 24,541,000 (January 1977), average
annual growth rate 2.8% (7-74 to 7-75)
Nationality: noun—Colombian(s); adjective—
Colombian
Ethnic divisions: 58% mestizo, 20% caucasian,
14% mulatto, 4% Negro, 3% mixed Negro-Indian, 1%
Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 47% of population over 15 years old
Labor force: 5.6 million (1966); 47% agriculture,
13% manufacturing, 18% services, 9% commerce,
13% other (1964); 10%-13% unemployment (1975)
Organized labor: 18% of labor force (1968)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977','4e5a9e8b05ca1ab48b6fe2ee3296e6b760285f1ce00898adc4e523e25c916c7d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96257725193bc193b1490a649321f5d158e8a5e4908736cb2a566ae18e929695',1977,'KM','Comoros','people-and-society',114,'Population: 318,000 (January 1977), average
annual growth rate 2.5% (current)
Nationality: noun—Comoran(s); adjective—
Comoran
Ethnic divisions: mixture of Arab, Malay, Negroid
Religion: predominantly Islamic
Language: French, Arabic, Swahili
Literacy: presumably low
Labor force: mainly agricultural','14cc6c86d9b33c9f79f4abb9bfdf5169661e0a1aad895b171985066a7a6d272d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53c2f9ef38276f47aae3ee7aaec6f2c1d789e2b7d7ae7ad1ecd7e4df5e999854',1977,'CG','Congo','people-and-society',118,'Population: 1,400,000 (January 1977), average
annual growth rate 2.6%: (current)
Nationality: noun—Congolese (sing., pl.); adjec-
tive—Congolese or Congo
Ethnic divisions: about 15 ethnic groups divided
into some 75 tribes, almost all Bantu; most important
ethnic groups are Kongo (48%) in south, Teke (17%)
in center, M’Bochi (12%) and Sangha (20% ) in north;
about 8,500 Europeans, mostly French
Religion: about half animist, half nominally
Christian, less than 1% Muslim
Language: French official, many African lan-
guages with Lingala and Kikongo most widely used
Literacy: about 20%
Labor force: about 40% of population economi-
cally active, most engaged in subsistence agriculture;
79,100 wage earners; 40,000-60,000 unemployed
Organized labor: 16% of total labor force (1965
est. )','a44b12dcfbd0fb515f9064c6fb67b5806a212e987f8ba95060a36a48bba4b88e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48b13df739fcad78aed784e920eca75e8024063527fda799b00ac381b1fb5a6c',1977,'CK','Cook Islands','people-and-society',122,'Population: 19,000, official estimate for 30 June
1974
Nationality: noun—Cook Islander(s); adjective—
Cook Islander
Ethnic divisions: 81.3% Polynesian (full blood),
7.7% Polynesian and European, 7.7% Polynesian and
other, 2.4% European, 0.9% other
Religion: Christian, majority of populace members
of Cook Islands Christian Church','0b31578cb47b7bdc914c8dc970069b6c786d7e6e13efd294ad7fe6ee754e19b7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaf4ec5fca3fa577bfd80c6fa31fe4e5100249f1dcefd3c2aa3dde1377886d15',1977,'CR','Costa Rica','people-and-society',126,'Population: 2,041,000 (January 1977), average
annual growth rate 2.4% (7-74 to 7-75)
Nationality; noun—Costa Rican(s); adjective—
Costa Rican
Ethnic divisions: 98% white (including mestizo),
2% Negro
Religion: 95% Roman Catholic
Language: Spanish
Literacy: about 85%
Labor force: 585,318 (1975); 36% agriculture; 12%
manufacturing; 11% commerce; 6% construction; 5%
transportation, utilities; 20% service (government,
education, social); 2% finance; 8% other; 7.4%
unemployment (1978)
Organized labor: about 11.5% of labor force
Population: 9,567,000 (January 1977), average
annual growth rate 1.6% (current)
48
Approved For Release 2005/04/22
Nationality: noun—Cuban(s); adjective—Cuban
Ethnic divisions: 51% mulatto, 37% white, 11%
Negro, 1% Chinese
Religion: at least 85% nominally Roman Catholic
before Castro assumed power
Language: Spanish
Literacy: about 96%
Labor force: 2.36 million; 34% agriculture, 17%
industry, 6% construction, 6% transportation, 29%
services, 8% unemployed and underemployed
Organized labor: 46% of total force','ed988cdc2d0fce361557c2c1728b38e4206a02f5e473a15f3fc148c23ae5eaef','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8444259026239c833895f5101857af62d35134dc95bc994bd2bcd47e9bce43a',1977,'CY','Cyprus','people-and-society',130,'Population: 650,000 (January 1977), average
annual growth rate 0.8% (1-72 to 1-75)
Nationality: noun—Cypriot(s); adjective—Cypriot
Ethnic divisions: 78% Greek; 18% Turkish; 4%
British, Armenian, and other
Religion: 78% Greek Orthodox, 18% Muslim, 4%
Masonite Armenian Apostolic and other
Language: Greek, Turkish, English
Literacy: about 82% of population 7 years or older
Labor force: 267,000 (1970 est.), 38% agriculture,
23% industry, 9% commerce, 2% mining, 28% other;
8,180 registered unemployed (December 1968)
Organized labor: 24% of labor force','b98baf30fe447b6dadd1956defa4ec26a56c7ca190181e3dde656151c3314db8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c0d71bd9f86a8051937a82e58b4f6a8435b57e8f2c9fe4cca9300b4511881f0',1977,'NL','Netherlands','people-and-society',135,'Population: 14,989,000 (January 1977), average
annual growth rate 0.8% (current)
Nationality: noun—Czechoslovak(s); adjective—
Czechoslovak
Ethnic divisions: 64.3% Czechs, 30.0% Slovaks,
4.0% Magyars, 0.6% Germans, 0.5% Poles, 0.4%
Ukrainians, 0.2% others (Jews, Gypsies)
Religion: 77% Roman Catholic, 20% Protestant,
2% Orthodox, 1% other
Language: Czech, Slovak, Hungarian
Literacy: almost complete
Approved For Release 2005/04/22
Labor force: 7.4 million; 14% agriculture, 38.6%
industry, 11% services, 36.4% construction, communi-
cations and others
Population: 55,000, preliminary total from census
of 8 December 1973
Nationality: noun—Gilbertese or Gilbert Island-
er(s); adjective—Gilbertese, or Gilbert Islander
Ethnic divisions: Micronesian
Religion: Catholic
Literacy: less than 50%
Population: 13,868,000 (January 1977), average
annual growth rate 1.0% (current)
Nationality: noun—Netherlander(s); adjective—
Ethnic divisions: 99% Dutch, 1% Indonesian and
other
Religion: 41% Protestant, 40% Roman Catholic,
19% unaffiliated
Language: Dutch
Literacy: 98%
Approved For Release 2005/04/22 :
- Labor force: 4.7 million; 830% manufacturing, 24%
services, 16% commerce, 10% agriculture, 9%
construction, 7% transportation and communications,
4% other; 4.8% unemployment (August 1975)
Organized labor: 33% of labor force
Population: 245,000 (January 1977), average
annual growth rate 1.5% (1-74 to 1-75)
Nationality: noun—Netherlands Antillean(s);
adjective—Netherlands Antillean
Ethnic divisions: racial mixture with African,
Caribbean Indian, European, Latin, and oriental
influences; negroid characteristics are dominant on
Curacao, Indian on Aruba
Religion: predominantly Roman Catholic; sizable
Protestant, smaller Jewish minorities
Language: officially Dutch; “Papiamento,” a
Spanish-Portuguese-Dutch-English dialect predomi-
nates; English widely spoken
Literacy: 95%
Labor force: 76,000 (1972); 2% agriculture, 20%
industry, 10% construction, 65% government and
services, 3% other
Organized labor: 60%-70% of labor force','42837a83cacceb16b6b6aad04c10f71de9ce1d5d51fa0b633a599c611f021c8b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2747e2837391ffe1b7fb67b66619006e763c9eb7ef264675d4566c443139655',1977,'DK','Denmark','people-and-society',138,'Population: 5,079,000 (January 1977), average
annual growth rate 0.3% (current)
Nationality: noun—Dane(s); adjective—Danish
Ethnic divisions: homogeneous white population
Religion: 96% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 1% other
Language: Danish; small German-speaking
minority
Literacy: 99%
Labor force: 2.5 million; 9.5% agriculture, forestry,
fishing, 26.6% manufacturing, 8.3% construction,
15.7% commerce, 6.8% transportation, 5.6% services,
25.7% government, 1.8% other; 7.6% of registered
labor force unemployed (January 1976)
Organized labor: 65% of labor force
Population: 2,000 (official estimate for 1 July 1974)
Nationality: noun—Falkland Islander(s); adjec-
tive—Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Church of England
Language: English
Literacy; compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in
agriculture, mostly sheepherding','78bba890ce2eb965655ba938c431ec91451f521e6d8aba45174f72a659716b57','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('871bc3ee089c1a24d4599259702ff035103700ae8c51fd1e0e2cde1dd86ba6f9',1977,'DM','Dominica','people-and-society',142,'Population: 78,000, average annual growth rate
1.6% (4-60 to 4-70)
Nationality: noun—Dominican(s); adjective—
Dominican
Ethnic divisions: mostly of African Negro descent
Religion: Roman Catholic, Church of England,
Methodist
Language: English; French patois
Literacy: about 80%
Labor force: 23,000; about 50% in agriculture
Organized labor: 25% of the labor force','94233fbbd7933dacfe04e853327ca8b3918dd6e1d1452504f5dbdca9c0ead85c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c4dce004983050a6bd7e584f4e6c3f81acfb70ab21223757e8e59ee09fb0250',1977,'DO','Dominican Republic','people-and-society',146,'Population: 4,906,000 (January 1977), average
annual growth rate 2.9% (current)
Nationality: noun—Dominican(s); adjective—
Dominican
Ethnic divisions: 73% mulatto, 16% white, 11%
Negro
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
oe Atlantic.
ge: Ocean”
¢ Santo =
Domingo.
(See reference map fi)
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.3 million; 73% agriculture, 8%
industry, 19% services and other
Organized labor: 12% of labor force','5897d4271d8f2f561c632be4fcfa5f281e054b49180e548d3d15369fb1ec302b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bd2d5419e81d2204c1f049beff172ab8e0f32666a12daa1b6ddd58a3db29ebe',1977,'EC','Ecuador','people-and-society',150,'Population: 7,133,000, excluding nomadic Indian
tribes (January 1977), average annual growth rate
3.4% (11-62 to 6-74)
Nationality: noun—Ecuadorean(s); adjective—
Ecuadorean
Ethnic divisions: 40% mestizo, 40% Indian, 10%
white, 5% Negro, 5% Oriental and other
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish, Quechua
Literacy: 57%
Labor force: 2 million, of which 56% agriculture,
18% manufacturing, 4% construction, 7% commerce,
56
4% public administration, 16% other services and
activities
Organized labor: less than 15% of labor force','a87613627dff24b4d028e6526e469fbb600c9bebc4824dddc1eba28d22de86c8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a99abcb1e18508a6117c962dff854c32e8c2b1a8776bc19351a3387d6f9c13e',1977,'EG','Egypt','people-and-society',154,'Population: 38,533,000 (January 1977), average
annual growth rate 2.3% (current)
Nationality: noun—Egyptian(s); adjective—
Egyptian or Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock; 10%
Greek, Italian, Syro- Lebanese
Religion: (official estimate) 94% Muslim, 6% Copt
and other
Language: Arabic official, English and French
widely understood by educated classes
Literacy: around 40%
Labor force: 8 to 12 million; 45% to 50%
agriculture, 10% industry, 10% trade and finance,
30% services and other; shortage of skilled labor
Organized labor: 1 to 8 million','58125a9b1283c4952859a9f61d2c41add67ab41a919443e117d9206da3743a1b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5a34986d1c3965e456564c1199fa831c3825ad0f4bd2aeb2b49c96c890d625',1977,'SV','El Salvador','people-and-society',158,'Population: 4,195,000 (January 1977), average
annual growth rate 3.1% (7-74 to 7-75)
Nationality: noun—Salvadoran(s); adjective—
Salvadoran
Ethnie divisions: 84%-88% mestizo; Indian and
white minorities, 6%-8% each
Religion: predominantly Roman Catholic,
probably 97%-98%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 :.CIA-RDP79-01051A000800010006-3
January 1977
Language: Spanish
Literacy: 50% literacy in urban areas, 30% in rural
areas
Labor force: 1,500,000 (est. 1975); 57% ag-
riculture, 14% services, 14% manufacturing, 6%
commerce, 9% other; shortage of skilled labor and
large pool of unskilled labor, but manpower training
programs improving situation
Organized labor: 4% of total labor force; 7% of
nonagricultural labor force (1976 est.)','9247873b741a2db1bbf039d25a27c7621189a0d69b0584b1dba98e62d3560b08','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663799175aba4a272b43e5ed9853c0fde4ed91707e658e60d772e65f61ebc1d6',1977,'GQ','Equatorial Guinea','people-and-society',162,'Population: 827,000 (January 1977), average
annual growth rate 1.8% (7-68 to 7-69); Rio Muni,
230,000, average annual growth rate 1.5% (7-68 to
7-69); Fernando Po, 97,000, average annual growth
rate 2.6% (7-68 to 7-69)
Nationality: noun—Equatorial Guinean(s); adjec-
tive—Equatorial Guinean
Ethnic divisions: indigenous population of
Province Francisco Macias Nguema primarily Bubi,
some Fernandinos; of Rio Muni primarily Fang; less
than 1,000 Europeans, primarily Spanish
Religion: natives all nominally Christian and
predominantly Roman Catholic; some pagan
practices retained
Language: Spanish official language of govern-
ment and business; also pidgin English, Fang
Literacy: 12% (est.)
Labor force: most Equatorial Guineans involved in
subsistence agriculture
60
Approved For Release 2005/04/22','4effce4c0a9cb29d237b663cd356e6fe49e2a5dd2d952349ba768e8c0097bb41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd1e0a69aa0643c299691583272bb8beae84ab47af44f710473e2ec2331d84b9',1977,'ET','Ethiopia','people-and-society',166,'Population: 29,044,000 (January 1977), average
annual growth rate 2.6% (7-74 to 7-75)
Approved For Release 2005/04/22
Nationality: noun—Ethiopian(s); adjective—
Ethiopian
Ethnic divisions: Galla 40%, Amhara and Tigrai
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage 2%, other 1%
Religion: 85%-40% Ethiopian Orthodox, 40%-45%
Muslims, 15%-20% animist, 5% other
Language: Amharic official; many local languages
and dialects; English major foreign language taught
in schools
Literacy: about 5%
Labor force: 90% agriculture and animal
husbandry; 10% government, military, and quasi-','1ac0c3eb79cc2d37dd77f480af6184e69e183b85986b98bc18a8f2676455ec20','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('247f4e7c5701f6a695f545a6648f7c68f4cee528862cdf480fd73c9aec4d9313',1977,'FO','Faroe Islands','people-and-society',170,'Population: 41,000, average annual growth rate
1.1% (1-71 to 1-75)
Nationality: noun—Faroese (sing., pl.); adjec-
tive—Faroese
Ethnic divisions: homogeneous white population
Religion: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy: 99%
Labor force: 15,000; largely engaged in fishing,
manufacturing, transportation, and commerce','f48d8c5d7cae87d7b59f4665401ffc2c8b06e7eb4ea007223a7de8590d683924','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab75c3404e29fc2ad68d2dc10c7a115a5e8d66e6cf1028a9223e793d07959d6a',1977,'FJ','Fiji','people-and-society',174,'Population: 590,000 (January 1977), average
annual growth rate 1.9% (7-72 to 7-75)
Nationality: noun—Fijian(s); adjective—Fijian
Ethnic divisions: 42% Fijian, 50% Indian, 8%
European, Chinese and others
Religion: Fijians mainly Christian, Indians are
Hindu with-a Muslim minority
Language: English and Fijian (official), Hindu-
stani widely spoken among Indians
Literacy: over 80%
Labor force: 95,000; over 50% in agriculture, no
breakdown on remainder
Organized labor: about 50% of labor force
organized into 22 unions; unions organized along lines
of work, breakdown by ethnic origin causes further
fragmentation','046c477077b17fa3464750b767e1f5d32fe6846581ce775cd17fe74fb3fbd0a6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e38e334be4c5d47b44db9905ed8520655f1cc14f2154bbed0a34d3bbbb01df',1977,'FI','Finland','people-and-society',178,'Population: 4,738,000 (January 1977), average
annual growth rate 0.4% (1-75 to 1-76)
Nationality: noun—Finn(s); adjective—Finnish
Fthnic divisions: homogeneous white population,
small Lappish minority
Religion: 93% Evangelical Lutheran, 1% Greek
Orthodox, 1% other, 5% no affiliation
Language: Finnish 92%, Swedish 7%; small Lapp-
and Russian-speaking minorities
Literacy: 99%
Labor force: 2.2 million; 16.6% agriculture,
forestry, and fishing, 26.4% mining and manufactur-
ing, 8.4% construction, 15.4% commerce, 6.8%
transportation and communications, 4.0% banking
and finance, 20.1% services; 3.3% unemployed
Organized labor: 60% of labor force','54438e3dc3bb1934199e162c1990a34a191b02c543a79045f2f42d753aa8b0e6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bacb7de089419efa1d127831377cbea0b7db9889e64438c8e9e10e3fd4301f5',1977,'FR','France','people-and-society',182,'Population: 53,096,000 (January 1977), average
annual growth rate 0.5% (1-74 to 1-76)
Nationality: noun—Frenchman (men), adjective—
French
Ethnic divisions: 45% Celtic; remainder Latin,
Germanic, Slav, Basque
Religion: 83% Catholic, 2% Protestant, 1% Jewish,
1% Muslim (North African workers), 13% unaffiliated
Language: French (100% of population); rapidly
declining regional patois—Provencal, Breton,
Germanic, Corsican, Catalan, Basque, Flemish
Literacy: 97%
Labor force: 22,100,000 (est. in mid-1975), 47%
services, 38% industry, 11% agriculture, 4%
unemployed
Organized labor: approximately 17% of labor
force, 23.4% of salaried labor force','cc33773cfbfb52fb22373a5bf7f8fd57e9fee3e85ee9061b25413f88e3431420','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb249435a1b3232936dfda0ced09dd1806f9b6f60cf8a2db3200294a7d216701',1977,'GF','French Guiana','people-and-society',186,'Population: 55,000 (January 1977), annual growth
rate 2.8% (7-67 to 7-73)
Nationality: noun—French Guianese (sing., pl.);
adjective—French Guiana
Ethnic divisions: 95% Negro or mulatto, 5%
caucasian, 10,000 East Indian, Chinese
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 17,012 (1967 census); services 49%,
construction 21%, agriculture 18%, industry 8%,
transportation 4%; information on unemployment
unavailable
Organized labor: 7% of labor force','5aeb84cd2d6990d538e534e844a52038639515baedd0be5bacd1c13903716789','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d6889312161a3b0471908e2b17c7258af748a6396480733827e12536b1e5581',1977,'PF','French Polynesia','people-and-society',190,'Population: 120,000 (official estimate for 1 July
1973)
Nationality: noun—French Polynesian(s); adjec-
tive—French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chinese,
6% local French, 4% metropolitan French
Religion: mainly Christian; 55% Protestant, 32%
Catholic
Population: 180,000 (official estimate for 1972)
Nationality: noun—Afar(s), Issa(s); adjective—
Afar, Issa
70
RENCH TERRITORY OF THE
4 AFARS AND iSSAS
ti
{See refereace map Vi)
Ethnic divisions: (approximate figures) 59,350
Somalis, mostly Issas (large number of the Somalis are
temporary immigrants from Somalia, not citizens of
territory), 58,650 Afars, 6,000 Arabs, 7,000 French
(inclusive of French military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely
used
Literacy: about 5%
Labor force: a small number of semiskilled laborers
at port
Organized labor: some 8,000 railway workers
organized
Organized labor: unorganized
Population: 98,000 (January 1977), average annual
growth rate 2.5% (7-68 to 7-74)
Nationality: noun—New Hebridean(s); adjec-
tive—New Hebrides
Ethnic divisions: 92% indigenous Melanesian, 3%
European, remainder Vietnamese, Chinese, and
various Pacific Islanders
Religion: most at least nominally Christian
Literacy: probably 10%-20%','12ca3d518cb1ba2b0d766ba5c5c29d1d37ee4f771cb8e4b243077ff60c79679f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f865b3dd1be3ba70d3bc13bb8e535c024018264251f23dc17aeeac531617113',1977,'GA','Gabon','people-and-society',194,'Population: 557,000 (January 1977), average
annual growth rate 1.7% (7-66 to 7-70)
Nationality: noun—Gabonese (sing., pl.); Gabo-
nese
Atlantic
Ocean
(See reference meg VI}
Ethnic divisions: about 40 Bantu tribes, including
4 major tribal groupings (Fang, Eshira, Mbede,
Okande); about 100,000 expatriate Africans and
Europeans, including 30,000 French
Religion: 55% to 75% Christian, less than 1%
Muslim, remainder animist
Language: French official language and medium
of instruction in schools; Fang is a major vernacular
language
Literacy: about 12%
Labor force: about 280,000 of whom 74,000 are
wage earners in the modern sector
Organized labor: less than 30% of wage labor force
Population: 544,000 (January 1977), average
annual growth rate 2.5% (7-68 to 7-70)
Nationality: noun—Gambian(s); adjective—
Gambian
Ethnic divisions: over 99% Africans (Malinke
40.8%, Fulani 13.5%, Wolof 12.9%, remainder made
up of several smaller groups), fewer than 1%
Europeans and Lebanese
Religion: 85% Muslim, 15% animist and Christian
Language: English official; Malinke and Wolof
most widely used vernaculars
Literacy: about 10%
Labor force: approx. 165,000, mostly engaged in
subsistence farming; about 15,000 are wage earners
(government, trade, services)
Organized labor: 25% to 30% of wage labor force
at most
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
ial
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
THE GAMBIA/GERMAN DEMOCRATIC REPUBLIC
Population: 16,778,000, including East Berlin
(January 1977), average annual growth rate —0.3%
(current)
Nationality: noun—German(s); adjective—Ger-
man
Ethnic divisions: 99.7% German, .8% Slavic and
other
Religion: 53% Protestant, 8% Roman Catholic,
39% unaffiliated or other; less than 5% of Protestants
and about 25% of Roman Catholics actively
participate
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
Labor force: 8.2 million; 34.1% industry; 4.7%
handicrafts; 6.8% construction; 11.9% agriculture;
73
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GERMAN DEMOCRATIC REPUBLIC
6.8% transport and communications; 10.1%
commerce; 16.8% services; 2.5% other
Organized labor: 87.7% of total labor force
Population: 61,590,000, including West Berlin
(January 1977), average annual growth rate -0.1%
(1-78 to 1-76)
Nationality: noun—German(s), adjective—Ger-
man
Ethnic divisions: 99% Germanic, 1% other
Religion: 46.9% Protestant, 45.4% Roman
Catholic, 7.7% other (as of 1970)
Language: German
Literacy: 99%
Labor force: 26.7 million; 44.1% in manufacturing
and construction, 15.2% services, 12.8% commerce,
8.2% government, 7.2% agriculture, 5.4% com-
munication and transportation, 1% mining; 4.7%
average unemployed as of 1975, excluding self
employed
Organized labor: 51% of total labor force; 37.5% of
wage and salary earners','4df3c2d59712357da98cfea11389b0637d2e6eb9ec600cd55a8e896fca3e2623','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e4daba0a89a5d34841ba835bf8be4abd1044ce6f1aca55be9fa719e522d72b3',1977,'GH','Ghana','people-and-society',198,'Population: 10,281,000 (January 1977), average
annual growth rate 2.8% (7-72 to 7-75)
Nationality: noun—Ghanaian(s); adjective—
Ghanaian
Ethnic divisions: 99.8% Negroid African (major
tribes Ashanti, Fante, Ewe), 0.2% European and other
Religion: 45% animists, 43% Christian, 12%
Muslim
Language: English official; African languages
include Akan 44%, Mole-Dagbani 16%, Ewe 13%,
and Ga-Adangbe 8%
Literacy: about 25% (in English)
Labor force: 3.4 million; 61% agriculture and
fishing, 16.8% industry, 15.2% sales and clerical, 4.1%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GHANA/GIBRALTAR
services, transportation, and communications, 2.9%
professional; 400,000 unemployed
Organized labor: 350,000 or approximately 10% of
labor force','7a211ea2cc6292e64a1bf208f27110dfb5300cce47658a6fe88e2580951cbfee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('477764d892e96b9fed061cae51576b4395817686685c6d93c195ddcf0bb5afcd',1977,'GI','Gibraltar','people-and-society',202,'Population: 29,000 (official estimate for 1 July
1974)
Nationality: noun—Gibraltarian(s); adjective—
Ethnic divisions: mostly Italian, English, Maltese,
Portuguese and Spanish descent
Religion: predominantly Roman Catholic
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian also
spoken; English used in the schools and for all official
purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltarian laborers
Organized labor: over 6,000','8e9959c9eab954eed097fd9b5dcb3353e5b969f920433159de5d45cd58df55dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3baf458cd3a1bd70b2aa2663df9aa5459f633b1946e60e509203113a289bb61a',1977,'GR','Greece','people-and-society',206,'Population: 9,123,000 (January 1977), average
annual growth rate 0.6% (7-70 to 7-75)
Nationality: noun—Greek(s); adjective—Greek
Ethnic divisions: 96% Greek, 2% Turkish, 1%
Albanian, 1% other
Religion: 97% Greek Orthodox, 2.5% Muslim,
0.5% other
Language: Greek; English and French widely
understood
Literacy: males about 92%; females about 73%;
total about 82%
Labor force: 3,400,000 (1975 est.); 40.5%
agriculture, 25.6% industry, 33.7% services;
unemployment 3%, but there is substantial
unemployment in agriculture
Organized labor: 20% of labor force est.','40fbe15ad767728fb8531ca47e8e6cd1e9c5fc194bf4f90ad640f684080f08a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('837880ddb975a3a6151b29e329b80b38dc470fe63bf87690e4622e4c8e8c2920',1977,'GL','Greenland','people-and-society',210,'Population: 51,000 (January 1977), average annual
growth rate 1.6% (1-71 to 1-75)
Nationality: noun—Greenlander(s); adjective—
Ethnic divisions: 86% Greenlander (Eskimos and
Greenland-born whites), 14% Danes
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 12,000; largely engaged in fishing and
sheep breeding
Population: 221,000 (January 1977), average
annual growth rate 0.9% (12-74 to 12-75)
Nationality: noun—lIcelander(s); adjective—
Icelandic
93
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ICELAND/INDIA
Ethnic divisions: homogeneous white population
Religion: 95% Evangelical Lutheran, 3% other
Protestant and Roman Catholic, 2% no affiliation
Language: Icelandic
Literacy: 99%
Labor force: 85,000; 22.6% agriculture and
fishing; 25.6% mining and manufacturing; 10.7%
construction; 12.8% commerce; 7.8% transportation
and communications; 15.2% services; and''5.7% other;
unemployment 0.6%
Organized labor: 60% of labor force','2490c5915a2ccf53844d1e7d48eb91e401ce39c0121ed81f3ed5e6b030c6654f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c85a7edd6aafdf077bf3da4059177953996a57af891ed26594e8a23d63880d71',1977,'GD','Grenada','people-and-society',214,'Population: 96,000 (January 1977), average annual
growth rate 0.5% (4-60 to 4-70)
Nationality: noun—Grenadian(s); adjective—
Grenadian
Ethnic divisions: mainly of African-Negro descent
Religion: Church of England; other Protestant
sects; Roman Catholic
Language: English; some French patois
Literacy: unknown
Labor force: 27,314 (1960); 40% agriculture, 30%
unemployed or underemployed
Organized labor: 33% of labor force','2a3da20d53687ad34bae468465c515deb437a3b81c7bc8b7da094840b0d9a8e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3635238a23d88a071617fe29ba9cd1bb0eca78d2f3597092b214999bb48dd410',1977,'GP','Guadeloupe','people-and-society',218,'Population: 853,000 (January 1977), average
annual growth rate 1.38% (7-67 to 7-73)
Nationality: noun—Guadeloupian(s); adjective—
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GUADELOUPE/GUATEMALA
“DOMINICAN
EPUBLIC.
PUERTO
‘=D pico
°
©.
“GUADELOUPE ¢
9
oo Caribbean Sea
(See reference mep H)
Ethnic divisions: 90% Negro or Mulatto, less than
5% East Indian, Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; 25% agriculture, 25%
unemployed
Organized labor: 11% of labor force','0e3baa3c8b7ec9b07dd3ae2cc9f6d5fcd1f6d17bdec5eac77e3c9a140d68a8f5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3445eb15bc3bb789454effb31a0ca896817b573e30c0be1a45abe88fda928d4',1977,'MX','Mexico','people-and-society',225,'Population: 6,099,000 (January 1977), average
annual growth rate 2.8% (7-72 to 7-73)
Nationality: noun—Guatemalan(s); adjective—
Guatemalan
Ethnic divisions: 41.4% Indian, 58.6% Ladino
(mestizo and westernized Indian)
Religion: predominantly Roman Catholic
Language: Spanish, but over 40% of the
population speaks an Indian language as a primary
tongue
Literacy: about 30%
Labor force (1974): 1.8 million; 52.5% agriculture,
10.1% manufacturing, 21.7% services, 7.9%
commerce, 3.9% construction, 2.1% transport, 0.7%
mining, 1.2% electrical, 0.8% other. Unemployment
estimates vary from 3% to 25%
Organized labor: 6.4% of labor force (1975)','9e21438eb80c37050379f29894973a586d9a54b92118c87009f12011dfb8e38f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bbfef432f3fd16dbdd505b9a765e17fb9ad3d68715c3a5475acd2ab91816406',1977,'GW','Guinea-Bissau','people-and-society',229,'Population: 518,000 (January 1977), average
annual growth rate 1.8% (current)
Nationality: noun—Guinean(s); adjective—
Guinean
Ethnic divisions: about 99% African (Balanta 30%,
Fulani 20%, Mandyako 14%, Malinke. 13%, and 23%
other tribes); less than 1% European and mulatto
Religion: 66% animist, 30% Muslim, 4% Christian
Language: Portuguese and numerous African
languages
Literacy: 3% to 5%
Labor force: bulk of population engaged in
subsistence agriculture','cd8a2479358ac528e9005e44637e294bb3b7de1988f8abd3581a1daa52a2c871','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b507b12259623ac27c03a9d7549f42cc994fad68c120839373f7eb38f7d6558',1977,'GY','Guyana','people-and-society',233,'Population: 818,000 (January 1977), average
annual growth rate 2.2% (current)
Nationality: noun—Guyanese (sing., pl.); adjec-
tive—Guyanese
Ethnic divisions: 51% East Indians, 43% Negro
and Negro mixed, 4% Amerindian, 2% white and
Chinese
Religion: 57% Christian, 38% Hindu, 9% Muslim,
1% other
Language: English
Literacy: 86%
Labor force: 201,000; about 25% agriculture, 14%
manufacturing, 16% services, 11% commerce, 3%
mining and quarrying, 10% other; 21% unemployed
Organized labor: 34% of labor force','f15657afa09782cdb0210906a1785dbee5abf9aa79cfbfa7d40f6d81d7df2d1e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44023e389f99393f059f71039946127e48123971009869312795fc313cb0e617',1977,'HT','Haiti','people-and-society',237,'Population: 4,682,000 (January 1977), average
annual growth rate 1.6% (8-70 to 8-75)
Nationality: noun—Haitian(s); adjective—Haitian
Ethnic divisions: over 90% Negro, nearly 10%
mulatto, few whites
Religion: 10% Protestant, 75% to 80% Roman
Catholic (of which an overwhelming majority also
practice Voodoo)
Language: French (official) spoken by only 10% of
population; all speak Creole
Literacy: 10% to 12%
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
HAITI/HONDURAS
Labor force: 2.6 million (est. January 1968); 86%
agriculture, 12% industry, 2% unemployed; shortage
of skilled labor; unskilled labor abundant
Organized labor: less than 1% of labor force','97f49c007f5303c0752cdee98e58a75d65e742b74870f84a54c76e1cffa68e5b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d56e381060c2811e772afabe38e6836c48df9b7c0cdc6d525538c231ec13865e',1977,'HN','Honduras','people-and-society',241,'Population: 2,872,000 (January 1977), average
annual growth rate 2.9% (7-74 to 7-75)
89
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Caribbean
Sea
te,
SALVADOR “
Pacific Ocean
{See reference mep tl)
Nationality: noun—Honduran(s); adjective—
Honduran
Ethnic divisions: 90% mestizo, 7% Indian, 2%
Negro, and 1% white
Religion: about 97% Roman Catholic
Language: Spanish
Literacy: 57.4% of persons 10 years of age and over
(est. 1970)
Labor force: approx. 900,000 (est. mid-1972); 66%
agriculture, 12% services, 8% manufacturing, 5%
commerce, 6% unemployed, 3% unspecified
Organized labor: 7% to 10% of labor force (mid-
1972)','5654cf09a6f974299795787effea94f91fce6a400b7fb8bd94303854856eef14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90641b272a1cdb05c0835a65f1d1eb0899fb046dca4c65dffd52967b8f8d3d38',1977,'PH','Philippines','people-and-society',245,'Population: 4,497,000 (January 1977), average
annual growth rate 2.0% (7-70 to 7-75)
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 10% Christian, 90% eclectic mixture of
local religions
Approved For Release 2005/04/22
Language: Chinese, English
Literacy: 75%
Labor force (1971 est.): 1.58 million; 48%
manufacturing, 20% services, 11% construction,
mining, quarrying and utilities, 13% commerce, 4%
agriculture, forestry, fisheries, and hunting, 7%
communications, 2% other; underemployment is a
serious problem
Organized labor: 12% of 1969 labor force
Population: 48,705,000 (January 1977), average
annual growth rate 2.7% (current)
Nationality: noun—Filipino(s); adjective—Philip-
pine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 10% Protestant,
4% Muslim, 3% Buddhist and other
Language: Tagalog (renamed Pilipino) is the
national language of the Philippine Republic; English
is the language of school instruction and government
business
Literacy: about 83%
Labor force: 11 million; 60% agriculture, forestry,
fishing, 12% manufacturing, 10.5% commerce, 10.5%
government and services (business, recreation,
domestic, personal), 3.5% transport, storage,
communication, 3% construction; 0.5% other','e402399a75580912a3ab2075b10795ad04cc0fec183d88fad051b9dfd938df81','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6998ef82c782df582fc9ff2cbbedc9a2e90d0e70657637b2137e474dbbb224a9',1977,'HU','Hungary','people-and-society',250,'Population: 10,634,000 (January 1977), average
annual growth rate 0.6% (current)
Nationality: noun—Hungarian(s); adjective—
Hungarian
92
(See reference map iV}
Ethnie divisions: 93.3% Magyar, 2.5% German,
2.4% Gypsy, 0.7% Jews, 1.1% other
Religion: 67.5% Roman Catholic, 20.0% Calvinist,
5.0% Lutheran, 7.5% atheist and other
Language: 98.2% Magyar, 1.8% other
Literacy: 97%
Labor force: 5,085,500 (1 January 1976); 28%
agriculture, 44% industry and building, 16% trade
and transport, 17% other nonagricultural','c9d5cc5fcea8432aae664f645ba59b596a0702e8af7326eb0de62ab5aaca4db3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbcace9594a78d8b1e49b14c7b7f85d2d03ed6840f34b10a45cc8835e1567e52',1977,'ID','Indonesia','people-and-society',254,'Population: 135,913,000, including Portuguese
Timor and West Irian (January 1977), average annual
growth rate 2.4% (current)
Nationality: noun—Indonesian(s); adjective—
Indonesian
Ethnic divisions: 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% Coastal Malays, 26% other
Religion: 85% Muslim, 9% Christian, 2%
Buddhist, 2% Hindu, 2% other
Language: Indonesian (modified form of Malay)
official; English, and Dutch leading foreign languages
Literacy: 60% (est.); 72% in 6-16 age group
Labor force: 44 million; 70% agriculture, 15%
industry, 15% miscellaneous and unemployed
Organized labor: 10% of labor force
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
FT ail
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
INDONESIA/IRAN
Population: 34,455,000 (January 1977), average
annual growth rate 2.9% (7-70 to 7-75)
Nationality: noun—lIranian(s); adjective—Iranian
Ethnic divisions: 63% Ethnic Persians, 3% Kurds,
13% other Iranian, 18% Turkic, 3% Arab and other
Semitic, 1% other
Religion: 93% Shia Muslim; 5% Sunni Muslim;
2% Zoroastrians, Jews, Christians and Baha’ is
Language: Farsi (Persian), Turki, Kurdish, Arabic
Literacy: about 37% of those 7 years of age and
older (1976 est. )
Labor force: 10.1 million est. 1976; 36%
agriculture, 21% manufacturing; shortage of skilled
labor substantial','5d1804927bfe575fd35a2098f2e80130d6ac4291ef92f7ecdf86f0c79d522744','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03be8b65bad5c0be0fd9f3c86390d322df6792234bd8facff41f4867c0588d22',1977,'IQ','Iraq','people-and-society',258,'Population: 11,577,000 (January 1977), average
annual growth rate 8.8% (10-74 to 10-75)
Nationality: noun—Iraqi(s); adjective—Iraqi
Ethnic divisions: 70.9% Arabs, 18.3% Kurds, 0.7%
Assyrians, 2.4% Turkomans, 7.7% other
Religion: 90% Muslim, 8% Christian, 2% other
Language: Arabic, Kurdish minority speaks
Kurdish
Literacy: 20% to 40%
Labor force: 2.4 million; 70% agriculture, 6.5%
industry, 6.7% government, 16.8% other; rural
underemployment high, but not serious because low
subsistence levels make it easy to care for
unemployed; severe shortage of technically trained
personnel
Organized labor: 11% of labor force','6401a32930c66a7621e557a90ae0df038487466437ff20a045eb10227036eb29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f58ea7cb02f7ed48ddb8dfe8dd32d5ac9832f9f4c832875fea98d0cb44e3f23',1977,'IE','Ireland','people-and-society',262,'Population: 3,167,000 (January 1977), average
annual growth rate 0.8% (7-65 to 7-75)
Nationality: noun—Irishman(men), Irish (collec-
tive pl.); adjective—Irish
Ethnic divisions: racially homogeneous Celts
Religion: 94% Roman Catholic, 4% Anglican, 2%
other
Language: English and Gaelic official; English is
generally spoken
Literacy: 98%-99%
Labor force: about 1,134,000 (1971); 26%
agriculture, forestry, fishing; 19% manufacturing;
15% commerce; 7% construction; 5% transportation;
4% government; 24% other; 9.8% unemployment
(February 1976)
Organized labor: 36% of labor force','ed44e2fe3a5ace032b8cfe549b879b81840ae56fb2fcd375b42e6c48178b21e7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d028d16763ddbe1b39609c4c3b2351c01b9e05d56c6179aa805ba4e1cfc833e5',1977,'IL','Israel','people-and-society',266,'Population: 8,545,000, excluding West Bank and
East Jerusalem (January 1977), average annual
growth rate 2.6% (1-74 to 1-76)
Nationality: noun—Israeli(s); adjective—Israel
Ethnic divisions: 85% Jews, 15% non-Jews (mostly
Arabs)
Religion: 89% Judaism, 8% Islam, 3% other
Language: Hebrew official; Arabic used officially
for Arab minority; English most commonly used
foreign language
Literacy: 88% Jews, 48% Arabs
Labor force: 1,133,000; 6.5% agriculture, forestry
and fishing; 25.3% manufacturing (mining, industry);
0.9% electricity and water; 8.1% construction and
public works; 12.2% commerce; 7.7% transport,
storage, and communications; 6.5% finance and
business; 26.1% public services; 6.7% personal and
other services (1974)
Organized labor: 90% of labor force','d03e39737e102145051b2dc57200353da1990fc7636693ee83e5c0996367e729','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18ccabd8763bdb30af5ec8837925064573c24c30b755483a3ccfd99543b5cc58',1977,'IT','Italy','people-and-society',270,'Population: 56,410,000 (January 1977), average
annual growth rate 0.7% (1-66 to 1-76)
Nationality: noun—Italian(s); adjective—Italian
Ethnic divisions: primarily Italian but population
includes small clusters of German-, French-, and
Slovene-Italians in the north and of Albanian-Italians
in the south
Religion: almost 100% nominally Roman Catholic
(de facto state religion)
Language: Italian; parts of Trentino-Alto Adige
Region (e.g., Bolzano) are predominantly German
speaking; significant French-speaking minority in
Valle d’Aosta Region; Slovene-speaking minority in
the Trieste-Gorizia area
Literacy: 5%-7% of population illiterate (1972);
illiteracy varies widely by region
Labor force: 19,549,000 (January 1975); 15.0%
agriculture, 42.9% industry, 39.0% other; 8.3%
unemployment (1975), 5.6% if underemployed (those
working less than 33-hour work week) are included;
1.5 million Italians employed in other Western
European countries
Organized labor: 20% (est.) of labor force','0b783b18651ee1f99b34231a1b4aab78d3c16a7913503d44626a6e3502955265','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51f9f62c731b2a64b72e0165e0d03995b053c5e77380ba01a21bc250bb6917ae',1977,'JM','Jamaica','people-and-society',274,'Population: 2,093,000 (January 1977), average
annual growth rate 1.7% (1-70 to 1-75)
Nationality: noun—Jamaican(s); adjective—
Jamaican
Ethnic divisions: African 76.3%, Afro-European
15.1%, Chinese and Afro-Chinese 1.2%, East Indian
and Afro-East Indian 3.4%, white 3.2%, other 0.9%
Religion: predominantly Protestant, some Roman
Catholic, some spiritualist cults
Language: English
Literacy: government claims 82%, but probably
only about one-half of that number are functionally
literate
Labor force: 810,700 (1973); 26% in agriculture,
forestry, fishing and mining, 10% manufacturing, 8%
public administration, 5% construction, 10%
commerce, 3% transportation and utilities, 15%
services, 22% unemployed (seasonal unemployment in
agriculture can push the unemployment figure to
25% ); shortage of technical and managerial personnel
Organized labor: about 25% of labor force (1966)','60c8c4436cf70dd83aecfeff6f15f509ed1bd6d58145c13b7eaa818f253c20cb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('677bdcf9a552a6f6939dee431435249f62e602c9e1f706f55ff1e6f6c59550ff',1977,'JP','Japan','people-and-society',278,'Population: 118,462,000, including Ryukyus
(January 1977), average annual growth rate 1.1%
(current)
Nationality: noun—Japanese (sing., pl.); adjec-
tive—Japanese
Ethnic divisions: 99.2% Japanese, 0.8% other
(mostly Korean)
Religion: most Japanese observe both Shinto and
Buddhist rites; about 16% belong to other faiths,
including 0.8% Christian
Language: Japanese
Literacy: 97.8% of those 15 years old and above
(1960 data)
Labor force (1975 figures): 53.2 million; 12.7%
agriculture, forestry, and fishing; 35.2% manufactur-
ing, mining, and construction; 48.2% trade and
services; 8.7% government; 1.9% unemployed;
surplus of skilled labor, 2.0 million est. employed
(Jan.-Mar. 1975)
Organized labor: 34.7% of labor force
Population: 17,294,000 (January 1977), average
annual growth rate 3.2% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: racially homogeneous
111
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
KOREA, NORTH/KOREA, SOUTH
Religion: Buddhism and Confucianism; religious
activities now almost nonexistent
Language: Korean
Literacy: 90% (est.)
Labor force: 6.1 million; 48% agriculture, 52%
non-agricultural; shortage of skilled and unskilled
labor
Population: 35,538,000 (January 1977), average
annual growth rate 2.0% (current)
Nationality: noun—Korean(s); adjective—Korean
Ethnic divisions: homogeneous; small Chinese
minority (approx. 20,000)
: CIA-RDP79-01051A000800010006-3
ae amen A
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
KOREA, SOUTH
Religion: strong Confucian tradition; pervasive
folk religion (Shamanism); vigorous Christian
minority (5.5% of population); Buddhism (including
estimated 20,000 members of Soka Gakkai);
Chondokyo (religion of the heavenly way), eclectic
religion with nationalist overtones founded in 19th
century, claims about 1.5 million adherents
Language: Korean
Literacy; about 90%
Labor force: about 10.5 million (1972); 48%
agriculture, fishing, forestry, 15% services; 13%
mining and manufacturing, 12% commerce; 12%
other
Organized labor: about 10% of nonagricultural
labor force
Population: 1,764,000, excluding the islands of
Perim and Kamaran for which no data are available
(January 1977), average annual growth rate 2.9%
(5-78 to 7-75)
Nationality: noun—Yemeni(s); adjective—Yemeni
Ethnic divisions: almost all Arabs; a few Indians,
Somalis, and Europeans in Aden
Religion: Muslim
Language: Arabic
Literacy: probably no higher than 10%; Aden 85%
(est. )
Approved For Release 2005/04/22
WESTERN SAMOA/YEMEN (ADEN)','ee60cc14367a312e2f60168a9d843c505f75299e6bc51d0422e79244a201f5a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8007a1d97f21c444ac148e0e94971be1f47066400a0c1ee805ecc900b48bd755',1977,'JO','Jordan','people-and-society',282,'Population: 2,833,000, including West Bank and
East Jerusalem (January 1977), average annual
growth rate 3.2% current; East Bank, 2,071,000,
average annual growth rate 3.7% (current); West
Bank, including East Jerusalem, 762,000, average
annual growth rate 2.0% (current)
Nationality: noun—Jordanian(s); adjective—
Jordanian
Ethnic divisions: 98% Arab, 1% Circassian, 1%
Armenian
Religion: 90%-92% Sunni Muslim, 8%-10%
Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 50%-55% in East Jordan;
somewhat less than 60% in West Jordan
Labor force: 638,000; less than 5% unemployed
Organized labor: 9.8% of labor force
Population: 14,113,000 (January 1977), average
annual growth rate 3.5% (7-71 to 7-75)
Nationality: noun—Kenyan(s); adjective—Kenyan
Ethnic divisions: 97% native African (including
Bantu, Nilotic, Hamitic and Nilo-Hamitic); 2%
Asian; 1% European, Arab and others
Religion: 56% Christian, 36% animist, 7% Muslim,
1% Hindu
Language: English and Swahili official; each tribe
has own language
Literacy: 27%
Labor force: 2.5 million; about 977,000 (39%) in
monetary economy (1967)
Organized labor: about 215,000','c05d49989e47fb265dffbf045173ce543edc4076493d1cac866e0fcfc1418b16','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dae935dc57f6d2e2c6fc914bd118c6a0bfa83ee027d341ee91196c18ce19731f',1977,'KW','Kuwait','people-and-society',286,'Population; 1,101,000 (January 1977), average
annual growth rate 6.2% (4-70 to 4-75)
Nationality: noun—Kuwaiti(s); adjective—Ku-
waiti
Ethnic divisions: 85% Arabs, 13% Iranians,
Indians, and Pakistani; native Kuwaitis are a minority
Religion: 99% Muslim, 1% Christian, Hindu,
Parsi, other
Language: Arabic; English commonly used foreign
language
Literacy: about 60%
Labor force: 340,000 (1976 est. ); 26% manufactur-
ing, 25% services, 35% government and professions,
9% commerce, 5% oil industry; two-thirds of labor
force is non-Kuwaiti
114
Approved For Release 2005/04/22
Organized labor: labor unions, first authorized in
1964, formed in oil industry and among government
personnel
Population: 3,455,000 (January 1977), average
annual growth rate 2.4% (7-78 to 7-74)
Nationality: noun—Lao (sing., pl.); adjective—
Lao or Laotian
Ethnic divisions: 47% Lao; 14% Tribal Tai; 25%
Phoutheung (Kha); 14% Meo, Yao, and other
Religion: 50% Buddhist, 50% animist and other
Language: Lao official, French predominant
foreign language
Literacy: about 12%
Labor force: about 1,268,000; 80%-90% agri-
culture; 159,286 engaged in manufacturing and
services, 28,400 (22,400 civil and 6,000 police)
government employees in FY72
Organized labor: only labor organization is
subordinate to the Communist Party','f3b09c19de6284c77178e3758f2b1c05cd8501d9a756a3073d2bda41ed0662cd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b8cc8d295ef5c813115054a54d5d75c33876bee5dd2731b50fa34d715f6b287',1977,'LB','Lebanon','people-and-society',290,'Population: 2,454,000 (January 1977), average
annual growth rate 2.3% (current)
Nationality: noun—Lebanese (sing. and pl.);
adjective—Lebanese
Ethnic divisions: 93% Arab, 6% Armenian, 1%
other
Religion: 55% Christian, 44% Muslim and Druze,
1% other (official estimates); Muslims, in. fact,
constitute a majority
Language: Arabic (official); French is widely
spoken
Literacy: 86%
Labor force: about 1 million economically active;
49% agriculture, 11% industry, 14% commerce, 26%
other; moderate unemployment
Organized labor: about 65,000','0699a532d918abf87342cb3fb2e12fb9e659c0199cad69b58c05882f3ad5d4e8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf82e0bf4cbaaaa3724442820bc51eb16e151d9b1b24aae08800e02425948fcb',1977,'LS','Lesotho','people-and-society',294,'Population: 1,074,000 (January 1977), average
annual growth rate 2.2% (7-72 to 7-75)
Nationality: noun—Basothan(s), adjective—
Basothan
117
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
(See reference map Vij
Ethnic divisions: 99.7% Sotho, 1,600 Europeans,
800 Asians
Religion: 70% or more Christian, rest animist
Language: all Africans speak Sesotho vernacular;
English is second language for literates
Literacy: 40%
Labor force: 87.4% of resident population engaged
in subsistence agriculture; 150,000 to 250,000 spend 6
months to many years as wage earners in South Africa
Organized labor: negligible','893a41478d5f4a33b1207e5c4ea571092d541cf7cb70b536ad1e70988ed432ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1065f393b7af586ef20fb3d794c95bb5667968e93490c84e1388f24500bc97e',1977,'LR','Liberia','people-and-society',298,'Population: 1,554,000 (January 1977), average
annual growth rate 2.9% (current)
Nationality: noun—Liberian(s), adjective—
Liberian
Ethnic divisions: 5% descendants of immigrant
Negroes; 95% indigenous Negroid African tribes
including Kpelle, Bassa, Kru, Grebo, Gola, Kissi,
Krahn, and Mandingo
Religion: probably more Muslims than Christians;
70%-80% animist
Language: English official, 28 tribal languages or
dialects, pidgin English used by about 20%
Literacy: about 24% over age 5
Labor force: 600,000, of which 120,000 are in
monetary economy; about 2,000 non-African
foreigners hold about 95% of the top level
management and engineering jobs
Organized labor: 2% of labor force','0297a4c3307dbe82b3af7f0db84eefb71450f943ccc25ab2cacc1e584ae47f6a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('192b28e4d61485bab9a3977b5800a54bedd11b2123777c411fd0f9fd69ba86b3',1977,'LY','Libya','people-and-society',302,'Population: 2,599,000 (January 1977), average
annual growth rate 4.2% (7-74 to 7-75)
Nationality: noun—Libyan(s); adjective—Libyan
Ethnic divisions: 97% Berber and Arab with some
Negro stock; some Greeks, Maltese, Jews, Italians,
Egyptians
Religion: 97% Muslim
Language: Arabic; Italian and English widely
understood in major cities
Literacy: 35%
Labor force: 485,000; between ages 15-64,
405,000-430,000; 61% of labor force in agriculture
(1964)','8caa16fc986a37058ef5ab19aa5bba57e6e107b25595e75bb9655dbeeceb2f6e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54ca7b257e82d7a4068a053aa180bd039d32890b3021d6799d3df9b27cb30c6b',1977,'LI','Liechtenstein','people-and-society',306,'Population: 25,000 (January 1977), average annual
growth rate 2.5% (12-60 to 12-70)
Nationality: noun—Liechtensteiner(s); adjective—
Ethnic divisions: 95% Germanic, 5% Italian and
other
Religion: 92% Roman Catholic
Language: German (dialect)
Literacy: 98%
121
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LIECHTENSTEIN/LUXEMBOURG
Labor force: 7,000, 8,500 foreign workers (mostly
from Austria and Italy); 59% industry, 20% trade and
commerce, 13% professional and other 8%
agriculture','d0c388c6eda85bd2b71a333d3a567c98bf2d993700dbf30d6fb865210e96ea13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb435453c6c6dd9aeeb8fabe383d020e15bc2d91bc512f77b7862f03e1b9ea14',1977,'LU','Luxembourg','people-and-society',311,'Population: 361,000 (January 1977), average
annual growth rate 0.7% (7-66 to 7-75)
Nationality: noun—Luxembourger(s); adjective—
Ethnic divisions: 88% Luxembourger, including an
estimated 5% of Italian descent; remainder French,
German, Belgian, etc.
Religion: 97% Roman Catholic, remaining 3%
Protestant and Jewish
Language: Luxembourgish, German, French; most
educated Luxembourgers also speak English
Literacy: 98%
Labor force: (1974) 158,000; 10% agriculture
(including forestry and fishing), 48% industry, 42%
services; 30% of labor force is foreign, comprising
workers from neighboring areas of Belgium, France,
and West Germany, as well as Italy and Portugal,
unemployment 0.1% August 1975
Organized labor: 45% of labor force
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LUXEMBOURG/MACAO','8ecca38ebace4b49d47abc614ecccdce19997ba96a309c5f42d694aa9f90c893','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64e8c4cd72668b8b956b0d3c99a3501a8891d56599b58718eabae83e975ba2e0',1977,'MO','Macao','people-and-society',315,'Population: 251,000 (official estimate for 1 July
1972)
Nationality; noun—Macaon(s); adjective—
Macaon
Ethnic divisions: 99% Chinese, 1% Portuguese
Religion: mainly Buddhist; 17,000 Catholics,
about one-half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese and
Macanese; no data on Chinese population
Labor force: 5% agriculture, 30% manufacturing,
3% construction, 1% utilities, 27% commerce, 8%
transportation and communications, 26% services
(1960 data)','b430fe5bc79046bee3c78e57a5b3090f1dff7bea226a502c3d959fc00e94711a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80810de07994c02ce5acd483891ac5ecfe0eae39c73b8282fbcf78c52d07efbf',1977,'MG','Madagascar','people-and-society',319,'Population: 7,812,000 (January 1977), average
annual growth rate 2.3% (7-69 to 7-70)
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
EoMORos
Tananarive
MADAGASCAR ©
“8 Indian Ocean
(See reference map Vi}
Nationality: noun—Malagasy (sing. and pl.);
adjective—Malagasy
Ethnic divisions: basic split between highlanders of
predominantly Malayo-Indonesian origin, consisting
of Merina (1,643,000) and related Betsileo (760,000),
on the one hand, and coastal tribes with mixed
Negroid, Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include Betsimisaraka
941,000, Tsimihety 442,000, Sakalava 375,000,
Antaisaka 415,000; there are also 10-12,000 European
French, 5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half animist; about 41%
Christian, 7% Muslim
Language: French and Malagasy official
Literacy: 45% of population age 10 and over
Labor force: about 3.4 million, of which 90% are
nonsalaried family workers engaged in subsistence
agriculture; of 175,000 wage and salary earners, 26%
agriculture, 17% domestic service, 15% industry, 14%
commerce, 11% construction, 9% services, 6%
transportation, 2% miscellaneous
Organized labor: 4% of labor force','4bbc20eb2c1b1328d455e975d6e11c2ffe16690f618c15604187b1cf29fc4a6d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d86d30bf782eebf162754fd6d5d9b4799357cc3121a233890b4d5d65d334552b',1977,'MW','Malawi','people-and-society',323,'Population: 5,245,000 (January 1977), average
annual growth rate 2.6% (7-72 to 7-75)
Nationality: noun—Malawian(s); adjective—
Malawian
Ethnic divisions: over 99% native African, less than
1% European and Asian
Religion: majority animist; rest Christian and
Muslim
Language: English and Chichewa official; Lomwe
is second African language
Literacy: 15% of population
Labor force: 225,000 wage earners employed in
Malawi (1974); 6,000 Europeans permanently
employed; 200,000 Malawians live and work in
Rhodesia, South Africa, and Zambia; 30% agriculture,
11% construction, 10% commerce, 13% manufac-
turing, 10% administration, 26% miscellaneous
services
Organized labor: small minority of wage earners
are unionized','144d14e22a7c9d07c0675371e998512ede723ab8e9238bf9c242784ad9d80226','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd6d69510c74a75fbd66ebc1f47b3a981a0d890516da901f3bcb249caaf880e5',1977,'MY','Malaysia','people-and-society',327,'Population: 12,395,000 (January 1977), average
annual growth rate 2.7% (7-70 to 7-75)
Peninsular Malaysia: 10,401,000, average
annual growth rate 2.6% (7-70 to 7-75)
Sabah: 852,000, average annual growth rate
4.2% (7-70 to 7-75)
Sarawak: 1,142,000, average annual growth rate
2.5% (7-70 to 7-75)
127
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Nationality: noun—Malaysian(s); adjective—
Malaysian
Ethnic divisions:
Malaysia: 50% Malay, 35% Chinese, 10%
Indian
Peninsular Malaysia: 53% Malay, 35% Chinese,
11% Indian and Pakistani, 1% other
Sabah: 21% Chinese, 69% indigenous tribes, 10%
other
Sarawak: 30% Chinese, 50% indigenous tribes,
19% Malay, 1% other
Religion:
Peninsular Malaysia: Malays nearly all Muslim,
Chinese predominantly Buddhists, Indians predomi-
nantly Hindu
Sabah: 88% Muslim, 17% Christian, 45% other
Sarawak: 23% Muslim, 24% Buddhist and
Confucianist, 16% Christian, 35% tribal religion, 2%
other
Language:
Peninsular Malaysia: Malay (official); English,
Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among
Chinese
Sarawak: English, Malay, Mandarin, numerous
tribal languages
Literacy:
Peninsular Malaysia: about 48%
Sabah and Sarawak: 23%
Labor force:
Malaysia: 4.2 million (1975)
Peninsular Malaysia: 3.6 million; 46.2% agricul-
ture, forestry, and fishing, 10.9% manufacturing and
construction, 31.9% trade, transport, and services
(1975)
Sabah: 213,000 (1967); 80% agriculture, forestry,
and fishing, 6% manufacturing and construction, 13%
trade and transportation, 1% other
Sarawak: 341,000 (1967); 80% agriculture,
forestry, and fishing, 6% manufacturing and
construction, 18% trade, transportation, and services,
1% other
Organized labor: 500,000 (1975 est.), about 15% of
total labor force; unemployment about 7% of total
labor force, but higher in urban areas','273051f1151b63b833d9ad4eb59a6e34a550d52a9fa58b9a3e4ef434d7da5587','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d53c16416eee0ce3a57d2037511e93ee2fc084f3d8e9bc4a7958049b595e030',1977,'MV','Maldives','people-and-society',331,'Population: 134,000 (January 1977), average
annual growth rate 2.1% (current)
Nationality: noun—Maldivian(s); adjective—
Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab and Negro
Religion: official Sunni Muslim
Language: Divehi (dialect of Sinhala)
Literacy: largely illiterate
Labor force: fishing industry employs most of the
male population
Population: 5,815,000 (January 1977), average
annual growth rate 2.8% (7-72 to 7-73)
Nationality: noun—Malian(s); adjective—Malian
Ethnic divisions: 99% native African including
tribes of both Berber and Negro descent
Religion: 90% Muslim, 9% animist, 1% Christian
Language: French official; several African
languages, of which Mande group most widespread
Literacy: under 5%
Labor force: approximately 100,000 salaried,
50,000 of whom are employed by the government,
most of population engaged in agriculture and animal
husbandry
Organized labor: UNTM, which claimed all
eligible employees, dissolved; thirteen national unions
currently directed by a government controlled
Coordination Committee of Mali Trade Unions
(CCSM)
Population: 320,000 (official estimate for 31
December 1975)
132
Approved For Release 2005/04/22
Nationality: noun—Maltese (sing. and pl.);
adjective—Maltese
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, British
Religion: 98% Roman Catholic
Language: English and Maltese
Literacy: about 83%; compulsory education
introduced in 1946
Labor force: 102,000; 20% services, 23%
government, 24% manufacturing, 6% agriculture, 4%
construction, 4% transportation and communications,
5% utilities and drydocks; 5% unemployed
Organized labor: approximately 40% of labor force','89fcd8eb68a2f45ed16b8943afd12797f9961f99f85770a75df457d301537821','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a6136fdda470731f0a1fb930db0488647640dc7325c51d1c6609583ccfb9fe',1977,'MQ','Martinique','people-and-society',334,'Population: 358,000 (January 1977), average
annual growth rate 1.1% (7-67 to 1-75)
Nationality: noun—Martiniquais (sing. and pl. );
adjective—Martiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, less than 5% East Indian
Lebanese, Chinese, 5% Caucasian
Religion: 95% Roman Catholic, 5% Hindu and
pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 23% agriculture, 20% public
services, 11% construction and public works, 10%
commerce and banking, 10% services, 9% industry,
17% other
Organized labor: 11% of labor force','4fa259c7c10ea60b3d80e2218bb96803da21c0619e5d317c8fd9bbb5c7a07d2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c43ea071e5870c7cb5e9c097d172d29f18ba40092d1cdd90104a1f0b908e60ce',1977,'MR','Mauritania','people-and-society',336,'Population: 1,371,000 (January 1977), average
annual growth rate 2.5% (7-72 to 7-75)
Nationality: noun—Mauritanian(s); adjective—
Mauritanian
Ethnic divisions: ¥; Moor, 4 Negro, % mix
Moor/Negro
Religion: nearly 100% Muslim
Language: Hassaniya Arabic is the national
language spoken by some 80% of the population,
French is the working language for government and
commerce
Literacy: about 10%
Labor force: about 35,000 wage earners (1976);
remainder of population in farming and herding
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MAURITANIA/MAURITIUS
Organized labor: 18,000 union members claimed
by single union, Mauritanian Workers’ Union','be69830c6de4678c55d0c625abed6c01544409f0c7f4e89870f79071c3de0e56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e239dda6e28495ba5310b83f3004a32e0ab51810a4b495dc6cdc81fa4213b74b',1977,'MU','Mauritius','people-and-society',341,'Population; 900,000 (January 1977), average
annual growth rate 1.2% (7-72 to 7-75)
Nationality; noun—Mauritian(s); adjective—
Mauritian
Ethnic divisions; 67% Indians, 29% Creoles, 3.5%
Chinese, 0.5% English and French
Religion: 51% Hindu, 33% Christian (mostly
Catholic with a few Anglican Protestants), 16%
Muslim
Language: English official language; Hindi,
Chinese, French Creole
Literacy: estimated 60% for those over 21, and 90%
for those of school age
Labor force: 175,000; 50% agriculture, 6%
industry; 20% government services; 14% are
unemployed, under-employed, or self-employed, 10%
other
Organized labor: about 35% of labor force
Population: 502,000 (January 1977), average
annual growth rate 1.9% (7-69 to 7-73)
Nationality: noun—Reunionnais (sing. & pl.);
adjective—Reunionnais
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French, African,
Malagasy, Chinese, and Indian origin
Religion: 94% Roman Catholic
Language: French (official), Creole widely used
Literacy: over 80% among younger generation
Labor force: primarily agricultural workers, high
seasonal unemployment
Population: 6,648,000 (January 1977), average
annual growth rate 3.5% (1-75 to 1-76)
Nationality: noun—Rhodesian(s); adjective—
Rhodesian
Ethnic divisions: 95.3% African, 4.2% European,
less than 0.5% Coloreds and Asians
Religion: 51% syncretic (part Christian, part
animist), 24% Christian, 24% animist, a few Muslim
Language: English official; Chishona and
Sindebele also widely used
Literacy: 25%-30%; of whites, nearly 100%
Labor force: (1972) 778,000 Africans (including
some migrants from Zambia and Malawi), 108,000
Europeans, Asians, and coloreds (people of mixed
heritage); 35% agriculture, 25% mining, manufactur-
ing, construction, 40% transport and services
Organized labor: about one-third of European
wage earners are unionized, but only a small minority
of Africans (1966)
170','d0e89b06732bf382e6599630e2b034a043d7647fba9f5b5b411478a5d374594c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60fcd315e1a175670ef269e273d7743693d3e6b9bce7c48453bffb411b77bd11',1977,'US','United States','people-and-society',345,'Population: 63,192 (January 1977), average annual
growth rate 3.3% (current)
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo, 30% Indian or
predominantly Indian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic, 3%
other
Language: Spanish
Literacy: 65% estimated; 84% claimed officially
Labor force (1973): 15.7 million (defined as those
12 years of age and older); 39.5% agriculture, 16.7%
manufacturing, 16.6% services, 16.8% construction,
utilities, commerce, and transport, 3% government,
7.4% unspecified activities
Organized labor: 20% of total labor force
Population: 215,966,000 (January 1977), average
annual growth rate 0.8% (current)
Ethnic divisions: 87.2% white, 11.3% negro, 1.4%
other
Religion: total membership in religious bodies,
131,484,000; Protestant 71,649,000, Roman Catholic
48,460,000, Jewish 6,115,000, other religions
3,841,361
Language: English, predominantly
Literacy: almost complete
Labor force: 92 million (1974)
Organized labor: 23.4% of total (1972)','e2f2a9c349c26190b07b2c25f444f0fa40bd6fda3e56a657aeff60c8681ab913','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d91c6ab814f751cdbfd108f8dd653460269db07b028adee92202620aeacdec84',1977,'MC','Monaco','people-and-society',349,'Population: 25,000 (official estimate for 31 July
1975)
Nationality: noun—Monacan(s) or Monegas-
que(s); adjective—Monacan or Monegasque
Ethnic divisions: Rhaetian stock
Religion: Roman Catholicism is official state
religion
Language: French
Literacy: almost complete','52a6d887620925cb20cd02fc157672171126687a3dba4c8fc66cd6377ccb23fd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6c7cfbaf739f9066e36419c58c92ad6af107c5a6949176927484f65e905d103',1977,'MN','Mongolia','people-and-society',353,'Population: 1,513,000 (January 1977), average
annual growth rate 3.2% (current)
Nationality: noun—Mongolian(s); adjective—
Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh, 2%
Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist, about
4% Muslim, limited religious activity because of
Communist regime
Languages: Khalkha Mongol used by over 90% of
population; minor languages include Turkic, Russian,
and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half the
population is in the labor force, including a large
percentage of Mongolian women; shortage of skilled
labor (no reliable information available)','3f24c20774ba010b8fc82cb7990e866777750d7d50d5e72c741f0ce59563a564','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dfc0a9cae5a6b9273ae3d7645378a7300ca927164ebfe93aab83e6ed3300cae',1977,'MA','Morocco','people-and-society',357,'Population: 18,090,000 (January 1977), average
annual growth rate 3.0% (7-71 to 7-75)
Nationality: noun—Moroccan(s); adjective—
Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.2% Jewish,
0.7% non-Moroccan
Religion: 98.7% Muslim, 1.1% Christian, 0.2%
Jewish
Language: Arabic (official); several Berber dialects;
French is language of much business, government,
diplomacy, and postprimary education
Literacy: 20%
Labor force: 6.3 million (1971 est.) 50%
agriculture, 15% industry, 26% services, 9% other
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers (UMT)','fc87e7e1b8bc18ac2ee4b1ffd592d1235f238d50ed0c1adf17f5a7a0f408a740','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950663bbbcf3f9f95783c3af518485c9d68894ec00fbcd47341fc2e7c870d80d',1977,'MZ','Mozambique','people-and-society',361,'Population: 9,294,000 (January 1977), average
annual growth rate 2.0% (7-71 to 7-72)
Nationality: noun—Mozambican(s); adjective—
Ethnic divisions: over.99% native African, less than
1% European and Asian
Religion: 65.6% animist, 21.5% Christian, 10.5%
Muslim, 2.4% other
Language: Portuguese (official); many tribal
dialects
Literacy: 7%-10% (est. )
Labor force: (1963 est.) 610,000; 50,000 non-
African wage earners, 560,000 African wage earners in
Mozambique; 290,000 additional African wage
eamers temporarily working in Rhodesia and South
Africa; unemployment serious problem; most native
Africans provide unskilled labor or remain in
subsistence agricultural sector
Organized labor: approx. 47,000 (end of 1970);
75% are white','e3a1d2620260c564b03875264a83bb803124e533e76001b0427fc1978f42a062','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71b107cc46e27cc7cdde2a430c277dfac75670195a03025bd9829d8d54e0893e',1977,'PT','Portugal','people-and-society',367,'Population: 7,000 (official estimate for 30 June
1969)
Nationality; noun—Nauruan(s); adjective—
Nauruan
Ethnic divisions: 48% Nauruans, 19% Chinese, 7%
Europeans, 26% other Pacific Islanders
Religion: Christian (24 Protestant, ¥ Catholic)
Language: Nauruan, a distinct Pacific Island
tongue; English, the language of school instruction,
spoken and understood by nearly all
Literacy: nearly universal
Population: metropolitan Portugal (including the
Azores and Madeira Islands), 9,587,000 (January
1977), average annual growth rate 1.0% (1-71 to 1-75)
Nationality: noun—Portuguese (sing. & pl.);
adjective—Portuguese
Ethnic divisions: homogeneous Mediterranean
stock in mainland, Azores, Madeira Islands
166
in
Atlantic
Ocean
(See reference map iV}
Religion: 97% Roman Catholic, 1% Protestant
sects, 2% other
Language: Portuguese
Literacy: 65% (1973)
Labor force: (1975) 3.1 million; 28% agriculture,
36% industry, 36% services; drastic rise in
unemployment—now more than 15% —due largely to
influx of refugees from former colonies, returning
migrant workers, and military cutbacks
Organized labor: the Communist-dominated
confederation, Intersindical, claims to represent 80%
of the labor force—a greatly exaggerated figure; a
group of “democratic unions’ organized in July 1976
to challenge Communist domination of labor unions,
claims to represent 17% of the work force','6d65784c8248f2b77ecaeae100eabf6a80512accced67754212264272678ba3a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ca614cfd46f8ef1d17f654cb69eb1666d57cd4ed3206f0281cfca17a36d23ed',1977,'NP','Nepal','people-and-society',371,'Population: 13,006,000 (January 1977), average
annual growth rate 2.2% (6-71 to 6-74)
Nationality: noun—Nepalese (sing. and _ pl.);
adjective—Nepalese
Ethnic divisions: two main categories, Indo-
Nepalese (about 80%) and Tibeto-Nepalese (about
20%), representing considerable intermixture of Indo-
Aryan and Mongolian racial strains; country divided
among many quasi-tribal communities
Religion: only official Hindu Kingdom in world,
although no sharp distinction between many Hindu
and Buddhist groups; small groups of Muslims and
Christians
Language: 20 mutually unintelligible languages
divided into numerous dialects; Nepali official
language and lingua franca for much of the country;
same script as Hindi
Literacy: about 12%
Labor force: 4.1 million; 95% agriculture, 5%
industry; great lack of skilled labor','45fe5d0136cdda9f8decad1e4923a6939f8b739d80fb5636a228bdf01ff4440a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56f89244bfbe8262b6a6242528a579b75a25fbbf1f2f9972741e3969cc297370',1977,'NC','New Caledonia','people-and-society',375,'Population; 146,000 (January 1977), average
annual growth rate 3.8% (7-61 to 7-74)
Nationality: noun—New Caledonian(s); adjec-
tive—New Caledonian
Ethnic divisions: Melanesian-Polynesian admix-
ture, over 28,000 Europeans of French extraction
Religion: natives 90% Christian
Language: Melanesian-Polynesian dialects
Literacy: unknown
Labor force: size unknown; Javanese and
Tonkinese laborers were imported for plantations and
mines in pre-World War II period; immigrant labor
now coming from Wallis Islands, New Hebrides, and','b729250d875958e02967f1d8eb192fc02aa2e9565a175f12e7ceb509b48763f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca9d81ba84aa7454916ed1e1fb1df2976d80e14a423734ad38d92f2daa9cb2c3',1977,'NZ','New Zealand','people-and-society',377,'Population: 3,203,000 (January 1977), average
annual growth rate 1.7% (1-75 to 1-76)
Nationality: noun—New Zealander(s); adjective—
149
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NEW HEBRIDES
Ethnie divisions: 93% European, 7% Maori
Religion: 90% Christian, 9% none or unspecified;
1% Hindu, Confucian, and other
Literacy: 98%
Labor force: 1,207,700; 13% agriculture, 38%
manufacturing and construction, 9% transportation
and communications, 24% commerce and finance,
21% administrative and professional; unemployment
5.7% (1976)
Organized labor: 52% of labor force','ab1e4d8bb317a8dc36e5d2a642624f1efc4c94d5debaa941d8e8ee15d78347dd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('669889c916a8d8cd701bb2340daadaf62a805b387c721c2c70496c76fc5880a3',1977,'NI','Nicaragua','people-and-society',381,'Population: 2,263,000 (January 1977), average
annual growth rate 3.3% (7-70 to 7-75)
Nationality: noun—Nicaraguan(s); adjective—
Nicaraguan
Ethnic divisions: 69% mestizo, 17% white, 9%
Negro, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); small English-
speaking minority on Atlantic coast
Literacy: 50% of population 10 years of age and
over
Labor force: 713,000 (1975 est.); 50% agriculture,
12% manufacturing, 14% services, 24% other;
shortage of skilled labor, but underemployment of un-
skilled labor except during harvest
Organized labor: about 5% of labor force','3c267f07b7106f9d77a4e64430ea327a39beb5ea52cc4773a93570e44b817d41','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d568cef0dd7e1c3b7e0862791b3fdc51291307fbbab34076787af4136cdcbe1d',1977,'NE','Niger','people-and-society',385,'Population: 4,792,000 (January 1977), average
annual growth rate 2.8% (7-70 to 7-75)
Nationality: noun—Nigerien (sing. and pl.);
adjective—Niger
Ethnic divisions: main Negroid groups 75% (of
which, Hausa 50%, Djerma and Songhai 21%);
152
(See reference map Vi}
Caucasian elements include Tuareg, Toubous, and
Tamacheks; mixed group includes Fulani
Religion: 80% Muslim, remainder largely animists
and a very few Christians
Language: French official, many African lan-
guages; Hausa used for trade
Literacy: about 6%
Labor force: 26,000 wage earners; bulk of
population engaged in subsistence agriculture and
animal husbandry
Organized labor: negligible','19450ba65e5968a317fd7a0e610a04b6acbd20e220ea6b51ce75b167f7eda5f9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb014889c274846f51e374a975ea3defe3a8a8e84308ec467b6670599f1b8f23',1977,'NG','Nigeria','people-and-society',389,'Population: 65,628,000 (January 1977), average
annual growth rate 2.9% (current)
Nationality: noun—Nigerian(s); adjective—
Nigerian
Ethnic divisions: 250 tribal groups, of which most
important are Hausa-Fulani (north), Ibo and Yoruba
(south); these 8 tribes total over 60% of population;
about 27,000 non-Africans
Religion: 47% Muslim, 34% Christian, 19% other
Literacy: est. 25%
Language: English official, Hausa, Yoruba, and
Ibo also widely used
Labor force: approx. 22.5 million; about 41% of
total population; roughly 1.3 million wage earners, of
whom 560,000 work in modern enterprises
Organized labor: about 530,000 wage earners,
approx. 2.4% of total labor force, belong to some 700
unions','ff935b339b5ba8dcd1575f4a10ae22091b0cef687dc92dbb7c01082bbc60d115','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5da65fa66edb8865ab43957a77c5855b0aa9fee2993c5b69ca55f412f6e6bd35',1977,'NO','Norway','people-and-society',393,'Population: 4,037,000 (January 1977), average
annual growth rate 0.5% (1-75 to 1-76)
Nationality: noun—Norwegian(s); adjective—
Norwegian
Ethnic divisions: homogeneous white population,
small Lappish minority
Religion: 96% Evangelical Lutheran, 4% other
Protestant and Roman Catholic, 1% other
Language: Norwegian, small Lapp and Finnish-
speaking minorities
Literacy: 99%
Labor force: 1.7 million; 11.4% agriculture,
forestry, fishing, 25.3% mining and manufacturing,
8.1% construction, 16.3% commerce, 9.9% transporta-
tion and communication, 28.5% services; 1.4%
unemployed
Organized labor: 60% of labor force','2e8818a08ff5391bc313254d90fb2bd6ddb8a380ea10a90da1d1e7bbfd69a78d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df72f3771408b676a38f42d00f19dcbfb9abebed10a37ba6f42bee14566614f2',1977,'OM','Oman','people-and-society',397,'Population: 525,000 (January 1977), average
annual growth rate 3.2% (current)
Nationality: noun—Omani(s); adjective—Omani
Ethnic divisions: almost entirely Arab with small
groups of Iranians, Baluchis, and Indians
Religion: Muslim
Language: Arabic
Literacy: very low','b301cf8c1b8358bfb1f1ed4f50440183b32067ac85448fec2cee5681651ae66a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06256eee042aa37675c58a82460759e5a7e30eac7d9219fba2f8873d5e255f07',1977,'PK','Pakistan','people-and-society',401,'Population: 73,452,000, excluding Junagardh,
Manavadar, Gilgit, Baltistan, and the disputed area
of Jammu-Kashmir (January 1977), average annual
growth rate 3.0% (7-74 to 7-75)
Nationality: noun—Pakistani(s); adjective—
Pakistani
Religion: 97% Muslim, 3% other
Approved For Release 2005/04/22
Language: official, Urdu; total spoken languages—
7% Urdu, 64% Punjabi, 12% Sindhi, 8% Pushtu, 9%
other; English is lingua franca
Literacy: about 14%
Labor force: 12.7 million (est. 1961); 60%
agriculture, 16% industry, 7% commerce, 15% service,
2% unemployed
Organized labor: 5% of labor force','77b17cb958cf23d7a9d20438dd3422748cdd14c04e9430b4ae457b276314280a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69e5565324bdbea34dab8d6bbbfcaf6a0c53ced5420ba8bf9e6eb4d28b2e15da',1977,'PA','Panama','people-and-society',405,'Population: 1,745,000 (January 1977), average
annual growth rate 3.1% (7-74 to 7-75)
Nationality: noun—Panamanian(s); adjective—
Panamanian
Ethnic divisions: 70% mestizo, 14% Negro, 9%
white, 7% Indian and other
Religion: over 90% Roman Catholic, remainder
mainly Protestant
Language: Spanish; about 14% speak English as
native tongue; many Panamanians bilingual
Literacy: 82% of population 10 years of age and
over
Labor force: 482,200 (1972 est. ); 39.5% commerce,
finance and services; 33.9% agriculture, hunting and
fishing; 9.7% manufacturing and mining; 6.8%
construction; 5% Canal Zone; 3.9% transportation
and communications; 1.2% utilities; national average
of 9-10% unemployed; shortage of skilled labor but an
oversupply of unskilled labor
Organized labor: 8.4% of labor force (1972 est.)','a0b4d24317f4d2669afea9a025942267100ee7581aabc0aa796d6fe1faa9eee9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a1e47284ed7796a534c4b6e9dab2fbad900fff9ab131808fabac718f60190a6',1977,'PG','Papua New Guinea','people-and-society',409,'Population: 2,865,000 (January 1977), average
annual growth rate 2.6% (7-66 to 7-75)
Nationality: noun—Papua New Guinean(s);
adjective—Papua New Guinean
Ethnic divisions: predominantly Melanesian and
Papuan, some Negrito, Micronesian, and Polynesian
types
Religion: over one-half of population nominally
Christian (490,000 Catholic, 320,000 Lutheran, other
Protestant sects); remainder animist
Language: 700 indigenous languages; pidgin
English and 2 or 3 native languages are linguae
francae for over one-half of population; English
spoken by 1% to 2% of population
Literacy: 1%; in English, 0.1%
Labor force: no available figures; mostly
subsistence farmers','02af96a253f6e8d9c1dc3309253d1be20b59dfc3d6dc2fa03fc78a6389464104','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e40a1970d9fee36703bb15fad1e25e155f3f9c11f45884b9febd67053e73995',1977,'PY','Paraguay','people-and-society',413,'Population: 2,764,000 (January 1977), average
annual growth rate 2.9% (current)
Nationality: noun—Paraguayan(s); adjective—
Paraguayan
Ethnic divisions: 95% mestizo, 5% white and
Indian
Religion: 97% Roman Catholic
Language: Spanish and Guarani
Literacy: officially estimated at 74% above age 10,
but probably much lower (40%)
Labor force: 800,000 (1971 est.); 55% agriculture,
forestry, fishing; 8% transport and other services; 19%
manufacturing and construction; 13% commerce and
professions; 5% miscellaneous (est. 1962)
Organized labor: about 5% of labor force','b9da831181c542a207f2e14cdfadb9fbed8d484dd0b2020cdc437c8eea70ce3e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76a4d03d3e59f03c4dfa4cd241c224be7aee42966c1f7101cbc1f3492f9cea30',1977,'PE','Peru','people-and-society',417,'Population: 16,027,000 (January 1977), average
annual growth rate 2.8% (7-61 to 6-72)
Nationality: noun—Peruvian; adjective—Peruvian
Ethnic divisions: 46% Indian; 38% mestizo (white-
Indian); 15% white; 1% Negro, Japanese, Chinese
162
(See reference map fi)
Religion: predominantly Roman Catholic
Language: Spanish, Quechua, Aymara
Literacy: 45% to 50%
Labor force: 5.0 million (1975); 42.1% agriculture,
17% services, 14% manufacturing, 9% trade, 4%
construction, 4% transportation, 2% mining, 4% other
Organized labor: 37.1% of labor force','b269d4938f0ddf637dbdf5786f8e2243cc0f6b24de67da98ab6ce6741d6fd453','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305f3bbdbe39593056b6c9a9fd1ce0dc84abf95c9e6f0c7fc6b3beab8e86c5a2',1977,'PL','Poland','people-and-society',422,'Population: 34,566,000 (January 1977), average
annual growth rate 1.1% (current)
Nationality: noun—Pole(s); adjective—Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrainians,
0.5% Belorussians, less than 0.05% Jews, 0.2% other
Religion: 95% Roman Catholic {about 75%
practicing), 5% Uniate, Greek Orthodox, Protestant,
and other
Language: Polish, no significant dialects
Literacy: about 98%
Labor force: 16.3 million; 38% agriculture, 26%
industry, 36% other non-agricultural','715ca9527e818e7943b109b0e824182886c860c6a300a23d7ee327e5f39dac72','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90071147e0bdcf7d9424bc9df8b175c56f641bd17e52f269a66f74396e72573c',1977,'QA','Qatar','people-and-society',426,'Population: 160,000 (January 1977), average
annual growth rate 3.3% (current)
Nationality: noun—Qatari(s); adjective—Qatari
Ethnic divisions: 56% Arab; 23% Iranian; 14%
Pakistani; 7% other
Religion: Muslim
Language: Arabic
Literacy: 10%-15%
Labor force: primarily foreign','5e7ae23db3bd94c7cdd9abaa9ac6ae58ae2b10e051c97e75ee4f927366a46601','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b09033073abb7e3d31dcd7d108d2d70767ff14aae438c5a3437f4b92af3c430',1977,'RO','Romania','people-and-society',430,'Population: 21,555,000 (January 1977), average
annual growth rate 0.9% (current)
Nationality: noun—Romanian(s); adjective—
Romanian
Ethnic divisions: 87% Romanian, 8% Hungarian,
2% German, 3% other
Approved For Release 2005/04/22
{Sea reference map 1V}
Religion: 14 million Romanian Orthodox, 1 million
Roman Catholic, 1 million Protestants, 100,000 Jews,
80,000 Muslims
Language: Romanian, Hungarian, German
Literacy: 98%-99% of total population
Labor force: 10.1 million (1974); 40% agriculture,
30% industry, 30% other nonagricultural','c8df33c7dc689fadc4ba138a0f2bc1ed11e2c2ac65d8533224577f8731de4bf2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26f1d66a2e4870a698d885b3d1149369aab22a38e41fdefede5475241d1cd9e4',1977,'RW','Rwanda','people-and-society',434,'Population: 4,397,000 (January 1977), average
annual growth rate 2.8% (1-70 to 1-75)
Nationality: noun—Rwandan(s); adjective—
Rwandan
Ethnic divisions: 90% Hutu, 9% Tutsi, 1% Twa
(Pygmoid)
Religion: 45% Catholic, 9% Protestant, 1%
Muslim, rest animist
Language: Kinyarwanda and French official;
Kiswahili used in commercial centers
Literacy: 10% in French and Kinyarwanda
Labor force: less than 5% in cash economy','b9f6b6721d448250c34640613cf6e2c926c9e77b0e44ab2f4f938482a7163048','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76ab777118ab5ce85e5cc123165ee054565b73e9073b1b079b37611ecb8f8383',1977,'AI','Anguilla','people-and-society',438,'Population: 70,000 (January 1977), average annual
growth rate 1.2% (4-60 to 4-70)
Ethnic divisions: mainly of African Negro descent
Nationality: noun—Kittsian(s), Nevisian(s),
Anguillan(s); adjective—Kittsian, Nevisian, An-
guillan
Religion: Church of England, other Protestant
sects, Roman Catholic
Language: English
Literacy: about 80%
Labor force: 19,616 (1960 est.)
Organized labor: 6,700
Population: 110,000 (January 1977), average
annual growth rate 1.5% (4-60 to 4-70)
Nationality: noun—St. Lucian(s); adjective—St.
Lucian
Ethnic divisions: mainly of African Negro descent
Religion: predominantly Roman Catholic
Language: English, French patois
Literacy: about 80%
Labor force: 38,000 (1969); 50% agriculture;
30%-35% unemployment (1975)
Organized labor: 20% of labor force
Population: 96,000 (January 1977), average annual
growth rate 1.1% (4-60 to 4-70)
Nationality: noun—St. Vincentian(s) or Vin-
centian(s); adjective—St. Vincentian or Vincentian
Approved For Release 2005/04/22 :
Atlantic Ocean
a
‘
x
® ST. VINCENT
4
(Sea reference map H}
Ethnic divisions: mainly of African Negro descent;
remainder mixed with some white and East Indian
and Carib Indian
Religion: Church of England, Methodist, Roman
Catholic
Language: English, some French patois
Literacy: about 80%
Labor force: 50,000 (1972 est.); about 60%
unemployed
Organized labor: 10% of labor force','afc44f841a0d207b42fc8dbe50e2eb57de7f67899aee31039756c8fbcd83880d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a96bc7c200691673185aee2f5fc6e8953de78b462040f015a102c910578389',1977,'SM','San Marino','people-and-society',442,'Population: 20,000 (official estimate for 30 June
1975)
Nationality: noun—Sanmarinese (sing. & pl.);
adjective—Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy; illiteracy relatively insignificant
176
Approved For Release 2005/04/22
Labor force: approx. 4,300
Organized labor: General Democratic Federation
of Sanmarinese Workers (affiliated with ICFTU) has
about 1,800 members; Communist-dominated
Camera del Lavoro, about 1,000 members','f48ae8a4d253edb9079ac163bce52fcab26b6532367cd9d5a379b9c32ccc298e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b346157f0c5d36194696d5313b3b6d7a34763cb216d8c0a43b3e478d54608d1',1977,'ST','Sao Tome and Principe','people-and-society',446,'Population: 75,000 (official estimate for 1 July
1972)
Nationality; noun—Sao Tomean(s); adjective—
Sao Tomean
Ethnic divisions: native Sao Tomeans, migrant
Cape Verdians, Portuguese
Religion: Roman Catholic, Evangelical Protestant,
Seventh Day Adventist
Language: Portuguese official
Literacy: estimated at 5%-10%
Labor force: most of population engaged in
subsistence agriculture and fishing; nearly half the
island’s work force, about 10,000 people, are
unemployed, the other half work on cocoa plantations','52033ec0e0a67017e7cbde00f2b372f4c9af74b766700182a8c01874fa1b9e23','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b30ef271e3a2258a67effaaea83b855e7e2de9f052d6c14ec62165fd40e9ba',1977,'SA','Saudi Arabia','people-and-society',450,'Population: 7,517,000 (January 1977), average
annual growth rate 3.1% (current)
Nationality: noun—Saudi(s); adjective—Saudi
Arabian or Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian (est. )
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: about 30% of population; 40%
agriculture and herding, 12% construction, 12%
service, 12% government, 11% commerce, 13% other','f1e4ba788389db86d3b0dcd0923e9ea06db8a110ad5573fd10366a9ebf2a8d40','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d2e178de458b01ec2a1040381222398eb5c0e414c3ce6899b5a546f655cadb',1977,'SN','Senegal','people-and-society',454,'Population: 5,174,000 (January 1977), average
annual growth rate 2.5% (current)
Nationality: noun—Senegalese (sing. & pl.);
adjective—Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani, 16.5%
Serer, 9% Tukulor, 9% Dyola, 6.5% Malinke, 4.5%
other African, 1% Europeans and Lebanese
Religion: 80% Muslim, 15% animist, 5% Christian
(mostly Roman Catholic)
Language: French official, but regular use limited
to literate minority; most Senegalese speak own tribal
language; use of Wolof vernacular spreading—now
spoken to some degree by nearly half the population
Literacy: 5%-10% (est.) in 14 plus age group
Labor force: 1,732,000; about 80% subsistence
agricultural workers; about 125,000 wage earners
Organized labor: majority of wage-labor force
represented by unions; however, dues-paying
membership very limited','31dddaedf56d0194c57e91cb42720b257727fd60105933613a4a4168289d1fbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0f3f509ccb549a0523b9572039e737a7b3b7ac05728d3bdb1c287b3e71e406d',1977,'SC','Seychelles','people-and-society',458,'Population: 60,000, average annual growth rate
2.2% (7-70 to 7-75)
Nationality: noun—Seychellois (sing. & pl.);
adjective—Seychelles
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SEYCHELLES/SIERRA LEONE
{ndian Qeean
SEYCHELLES %
7, Victoria
(Sea reference map Vi)
Ethnic divisions: Seychellois (admixture of Asians,
Africans, Europeans)
Religion: 90% Roman Catholic
Language: English official; Creole most widely
spoken
Literacy: limited
Labor force: 22,000 agriculture
Organized labor: 3 major trade unions','df5c71a48522b3946288dbf98983cc17f214b16bcd487498bbda3ce1f946061a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6abd446aea98412c1ae3b595d02447a4a1fa606d220ac369334c9bdbb1ba1165',1977,'SL','Sierra Leone','people-and-society',462,'Population: 2,810,000 (January 1977), average
annual growth rate 1.5% (7-78 to 7-74)
Nationality: noun—Sierra Leonean(s); adjective—
Sierra Leonean
Ethnic divisions: over 99% native African, rest
European and Asian; 13 tribes
Religion: 70% animist, 25% Muslim, 5% Christian
Language: English official, but regular use limited
to literate minority; principal vernaculars are Mende
in south and Temne in north; “Krio,”’ the language of
the resettled ex-slave population of the Freetown area,
is used as a lingua franca
Literacy: about 10%
Labor force: about 1.5 million; most of population
engages in subsistence agriculture; only small
minority, some 70,000, earn wages
Organized labor: 35% of wage earners','49dbd5e566a17345eaa0495b10dcb2ac887dcb2cb3d521f671fbc55b8b3ce917','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2550c138c3b7003997156b2fcff9ebe3f073db7a2a98373c077bd0345f9112f',1977,'SG','Singapore','people-and-society',466,'Population: 2,297,000 (January 1977), average
annual growth rate 1.4% (7-74 to 7-75)
Nationality: noun—Singaporean(s); adjective—
Ethnic divisions: 76.2% Chinese, 15% Malay, 7%
Indians and Pakistani, 1.8% other
Religion: majority of Chinese are Buddhists or
atheists; Malays nearly all Muslim; minorities include
Christians, Hindus, Sikhs, Taoists, Confucianists
Language: national language is Malay; Chinese,
Malay, Tamil, and English are official languages
Approved For Release 2005/04/22 :
Literacy: 70% (1970)
Labor force: 474,718; 0.5% agriculture, forestry,
and fishing, 0.4% mining and quarrying, 32.2%
manufacturing, 30.4% services, 5.2% construction,
21.5% commerce, 9.8% transport, storage, and','6bfa946ef12412cb46b77f0fb9837f01eb114f2ce6ecf78847120c3d6cc97c42','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeff38971ee6fd1ebefb0b178da5c58893e34874559a9ec981624a4833bcb238',1977,'SO','Somalia','people-and-society',470,'Population: 3,265,000 (January 1977), average
annual growth rate 2.3% (7-65 to 7-72)
184
=?” SOMALIA
Ls aes
Magadiscio
Indian
Ocean
(See reference map Vi}
Nationality: noun—Somali(s); adjective—Somali
Ethnic divisions: 85% Hamitic, rest mainly Bantu;
80,000 Arabs, 3,000 Europeans, 800 Asians
Religion: almost entirely Muslim
Language: Somali (written form recently instituted
by government); Arabic, Italian, English
Literacy: under 5%
Labor force: 965,000 (1968 est.); very few are
skilled laborers; 70% pastoral nomads, 30%
agriculturists, government employees, traders,
fishermen, handicraftsmen, other
Organized labor: law providing for government-
controlled labor union promulgated in June 1971, but
union so far not established','8aa23120e36f3ef1634f26fe0b7f0a68268f4013caa21fa28f3bc8edd0a5a13d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44c07c7a1c68592b0a2934f409f0a58aa988de15af60f4fda773f7b68252c9c0',1977,'ZA','South Africa','people-and-society',474,'Population: 26,493,000 (January 1977), average
annual growth rate 2.7% (7-65 to 7-75)
Nationality: noun—South African(s); adjective—
South African
Approved For Release 2005/04/22 :
SOMALIA/SOUTH AFRICA
Pretoria
*
SWAZILAQE) :
Indian
Ocean
SOUTH
AFRICA
HK. ,
“ZZ branskei
{See reference map Vi}
Ethnic divisions: 17.8% white, 69.9% African,
9.4% Colored, 2.9% Asian
Religion: primarily Christian except Asian and
African; 60% of Africans are animists
Language: Afrikaans and English official, Africans
have many vernacular languages
Literacy: almost all white population literate;
government estimates 85% of Africans literate
Labor force: 8.7 million (total of economically
active, 1970); 53% agriculture, 8% manufacturing,
7% mining, 5% commerce, 27% miscellaneous services
Organized labor: about 7% of total labor force is
unionized (mostly white workers); nonwhites have no
bargaining power
Population: 2,098,000, average annual growth rate
2.6% (9-60 to 5-70)
Nationality: noun—Transkeian(s); adjective—
Transkeian
Ethnic division: 98.9% African, 0.6% White, 0.5%
Colored (mulatto); Africans belong to Xhosa ethnic
group
Regligion: Whites and Coloreds predominantly
Christian; Africans either animist or Christian
Language: Whites, Coloreds, and educated
minority of Africans speak Afrikaans or English; bulk
of Africans speak Xhosa
Literacy: high for Whites and Coloreds; low for
Africans
Labor force: roughly 400,000 of whom only 50,000
are regularly employed in
Transkei; bulk are migrant workers in South Africa
Organized labor: no trade union, although some
White and Colored wage earners belong to South
African unions
Population: 929,000 (January 1977), average
annual growth rate 3.0% (7-68 to 7-74)
Nationality: noun—South West African(s);
adjective—South West African
Ethnic divisions: 14% white, 81% Africans, 5%
Colored (mulattoes); almost half the Africans belong
to Ovambo tribe; Damara tribe has almost 45,000
members; Herero, Okavango, Nama tribes have about
30,000 members each
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3 187
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SOUTH-WEST AFRICA
Atlantic
Ocean
SOUTH-WEST
Windhoek
WALVIS BAY~__#P
Afr) AFRICA
*
/ndian
Ocean
(See reference map VI}
Religion: whites predominantly Christian,
nonwhites either animist or Christian
Language: Afrikaans principal language of about
70% of white population, German of 22% and English
of 8%; several African languages
Literacy: high for white population; low for
nonwhite
Labor force: 203,300 (total of economically active,
1970); 68% agriculture, 15% railroads, 18% mining,
4% fishing
Organized labor: no trade unions, although some
white wage earners belong to South African unions','7deb8b07ccd6a707fbcb37d880238e9d26d11632d245f30fbc06636b1f66d1c3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67ad252033128703c009abd8c6c6c619183017dcc633fd2e20af39fa42734c9a',1977,'ES','Spain','people-and-society',477,'Population: 36,161,000, including the Balearic and
Canary Islands; also including Alhucemas, Ceuta,
Chafarinas, Melilla, and Penon de Velez de la
Gomera (January 1977), average annual growth rate
1.1% (current)
Nationality: noun—Spaniard(s); adjective—
Spanish
Ethnic divisions: homogeneous composite of
Mediterranean and Nordic types
Religion: 99% Roman Catholic, 1% other sects
Language: Castilian Spanish spoken by great
majority; but 17% speak Catalan, 7% Galician, and
2% Basque
Literacy: about 97%
Labor force (1974): 13.8 million; 23% agriculture,
37% industry, 40% services; registered unemployment
at end of 1975 was 2.8% of labor force, in reality
about 5%-6%
Organized labor: 90% of labor force in compulsory
government-controlled syndicates','525f4326a29b0dd6d9ff657667eab97c353808e3198a74eb69a2c7e69f12ecf2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8ba17e520fc94e05986cb7049193300f3b67922ecad9309248083a429e1f5ba',1977,'LK','Sri Lanka','people-and-society',481,'Population: 14,081,000 (January 1977), average
annual growth rate 1.9% (7-68 to 7-73)
Nationality: noun—Sri Lankan(s); adjective—Sri
Lankan
Approved For Release 2005/04/22
Ethnic divisions: 71% Sinhalese, 21% Tamil, 6%
Moor, 2% other
Religion: 64% Buddhist, 20% Hindu, 9%
Christian, 6% Muslim, 1% other
Language: Sinhala official, spoken by about 70%
of population; Tamil spoken by about 22%; English
commonly used in government and spoken by about
10% of the population
Literacy: 82% (1970 est.)
Labor force: 4 million, 17% unemployed;
employed persons—53.4% agriculture, 14.8% mining
and manufacturing, 12.4% trade and transport, 19.4%
services and other; extensive underemployment
Organized labor: 43% of labor force, over 50% of
which employed on tea, rubber, and coconut estates','28ef98ca11e36a2d4d9c4d64b155c6020c65a28f5cd7449971f44524aff047b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78297936c0bd2761298ff1dda1e1558f9b53fec4621a370c404608e544db9c3b',1977,'SD','Sudan','people-and-society',485,'Population: 18,428,000 (January 1977), average
annual growth rate 2.5% (7-74 to 7-75)
Nationality: noun—Sudanese (sing. and pl.);
adjective—Sudanese
Ethnic divisions: 89% Arab, 6% Beja, 52% Negro,
2% foreigners, 1% other
Religion: 73% Sunni Muslims in north, 23%
pagan, 4% Christian (mostly in south)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Language: Arabic, Nubian, Ta Bedawie, diverse
dialects of Nilotic, Nilo-Hamitic, and Sudanic
languages, English; program of Arabization in process
Literacy: 5% to 10%
Labor force: 5.8 million; 85% agriculture, 15%
industry, commerce, services, etc.; labor shortages
exist for almost all categories of employment
Population: 431,000 (January 1977), average
annual growth rate 2.3% (1-64 to 1-72)
Nationality: noun—Surinamer(s); adjective—
Surinamese
Ethnic divisions: 31% Creole (Negro and mixed),
37% Hindustani (East Indian), 15.8% Javanese,
10.3% Bush Negro, 2.6% Amerindian, 1.7% Chinese,
1.0% Europeans, 1.7% other and unknown
Religion: Muslim, Hindu, Moravian, Roman
Catholic, other—in order of size (% figures unknown)
Language: Dutch official; English widely spoken;
Sranon Tongo (Surinamese, sometimes called Taki-
Taki) is native language of Creoles and much of the
younger population, and is lingua franca among
others; Hindi; Javanese
Literacy: 70% to 75%
Labor force: 130,000 (1973)
Organized labor: approx. 83% of labor force
Population: 518,000 (January 1977), average
annual growth rate 3.2% (7-74 to 7-75)
Nationality: noun—Swazi(s); adjective—Swazi
Ethnic divisions: 96% African, 3% European, 1%
mulatto
Religion: 43% animist, 57% Christian
Language: English and Swati are official
languages; government business conducted in English
Literacy: about 25%
Labor force: 120,000; about 60,000 engaged in
subsistence agriculture; 55-60,000 wage earners, many
only intermittently, with 31% agriculture, 11%
government, 11% manufacturing, 12% mining and
forestry, 35% other (1968 est.); 7,900 employed in
South African mines (1969)
Organized labor: about 15% of wage earners are
unionized','f2b8e64c292862121c85be22acc5ca1fec9471479928e92696b59c58086d2495','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96649df4436d14cae5b26f0cbc759a66b59c182c5e937999915386148b316e83',1977,'SE','Sweden','people-and-society',489,'Population: 8,326,000 (January 1977), average
annual growth rate 0.3% (current)
Nationality: noun—Swede(s); adjective—Swedish
196
Approved For Release 2005/04/22
. Morwegian
» Sea
(See reference map iV}
Ethnic divisions: homogeneous white population;
small Lappish minority
Religion: 92% Evangelical Lutheran, 7% other
Protestant, Roman Catholic, Eastern Orthodox, 1%
other
Language: Swedish, small Lapp- and Finnish-
speaking minorities
Literacy: 99%
Labor force: 4.0 million; 6.4% agriculture, forestry,
fishing; 29.2% mining and manufacturing; 7.2%
construction; 13.6% commerce; 6.5% transportation
and communications; 29.8% services including
government; 5% banking, 2.2% unemployed
Organized labor: 80% of labor force','17dca84870cfc171ae0c2b6cb16ab9673fbfdfe4328359ea89168fe45f07f836','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('961df3a08feb6e7b11842534505d927b6124596a60e898f794742a360c67917b',1977,'CH','Switzerland','people-and-society',492,'Population: 6,415,000 (January 1977), average
annual growth rate 0.1% (1-73 to 1-76)
Nationality; noun—Swiss (sing. & pl.); adjective—
Swiss
197
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
(See reference map {¥}
Ethnic divisions: total population—69% German,
19% French, 10% Italian, 1% Romansch, 1% other;
Swiss nationals—74% German, 20% French, 4%
Italian, 1% Romansch, 1% other
Religion: 53% Protestant, 46% Roman Catholic
Language: Swiss nationals—74% German, 20%
French, 4% Italian, 1% Romansch, 1% other; total
population—69% German, 19% French, 10% Italian,
1% Romansch, 1% other
Literacy: 98%
Labor force: 3.0 million, about one-fifth foreign
workers, mostly Italian; 16% agriculture and forestry,
47% industry and crafts, 20% trade and trans-
portation, 5% professions, 2% in public service, 10%
domestic and other; approximately 0.4% unemployed
in August 1975
Organized labor: 20% of labor force
Population: 7,722,000 (January 1977), average
annual growth rate 3.3% (7-74 to 7-75)
Nationality; noun—Syrian(s); adjective—Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 70.5% Sunni Muslim, 16.3% other
Muslim sects, 13.2% Christians of various sects
Language: Arabic, Kurdish, Armenian; French and
English widely understood
Literacy: about 40%
Labor force: 2 million; 67% agriculture, 12%
industry (including construction), 21% miscellaneous
services; majority unskilled; shortage of skilled labor
Organized labor: 5% of labor force
Population: 15,772,000 (January 1977), average
annual growth rate 2.7% (7-74 to 7-75)
Nationality: noun—Tanzanian(s); adjective—
Tanzanian
Ethnic divisions: 99% native Africans consisting of
well over 100 tribes; 1% Asian, European, and Arab
Religion: Tanganyika—40% Animist, 30%
Christian, 30% Muslim; Zanzibar—almost all Muslim
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TANZANIA
Language: Swahili and English official, English
primary language of commerce, administration and
higher education; Swahili widely understood and
generally used for communication between ethnic
groups; first language of most people is one of the
local languages
Literacy: 15%-20%
Labor force: under 400,000 in paid employment,
over 90% in agriculture
Organized labor: 15% of labor force
Population: 43,736,000 (January 1977), average
annual growth rate 2.9% (7-70 to 7-75)
Nationality: noun—Thai (sing. & pl.); adjective—
Thai
Ethnic divisions: 75% Thai, 14% Chinese, 11%
minorities
Religion: 95.5% Buddhist, 4% Muslim, 0.5%
Christian
Language: Thai; English secondary language of
elite
Literacy: 70%
202
Approved For Release 2005/04/22
Labor force: 78% agriculture, 15% services, 7%
industry','82c7199c03d316b29666b910a32d6c100615b110de32927eb003d23fb7af17ec','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('406c17d0ed1c1659a955ef44870bac4856c94d80b2d9ff6aa9fff0536beb0b0d',1977,'TG','Togo','people-and-society',496,'Population: 2,304,000 (January 1977), average
annual growth rate 2.4% (7-73 to 7-75)
Nationality: noun—Togolese (sing. & pl.);
adjective—Togolese
Approved For Release 2005/04/22 :
Guif of Guinea
i
(See reference map Vi)
Ethnic divisions: 37 tribes; largest and most
important are Ewe in south and Cabrais in north;
under 1% European and Syrian-Lebanese
Religion: about 20% Christian, 5% Muslim, 75%
animist
Language: French, both official and language of
commerce; major African languages are Ewe and
Mina in the south and Dagomba and Kabie in the
north
Literacy: 54.9% of school age (7-14) currently in
school
Labor force: over 90% of population engaged in
subsistence agriculture; about 30,000 wage earners,
evenly divided between public and private sectors
Organized labor: 1 national union, the CNTT
organized in 1972','85dd2eefb778adf0d7263728e75799378b5035a0a17d65e215b55ceb95dc698c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('189c0c9711dd4f2a8a1474823ad1ca416660409e934625ee5b687a9cd2119ce4',1977,'TO','Tonga','people-and-society',500,'Population: 107,000 (January 1977), average
annual growth rate 3.2% (7-67 to 7-75)
Nationality: noun—Tongan(s); adjective—Tongan
Ethnic divisions: Polynesian, about 300 Europeans
Religion: Christian; Free Wesleyan Church claims
over 30,000 adherents
Language: Tongan, English
Literacy: 90%-95%; compulsory education for
children between ages of 6-14
Labor force: agriculture 10,303; mining 599
Organized labor: unorganized','8db9f05af5e657d71466d462cf5b7ea652a4316b8fa9fd105e7d3a2ee99247a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27c4112d554354c2edc0ff818f55bc0eecdaf8ef4868c28e2cc3bfdfa5f35843',1977,'TT','Trinidad and Tobago','people-and-society',504,'Population: 1,033,000 (January 1977), average
annual growth rate 1.3% (4-60 to 4-70)
Approved For Release 2005/04/22
0 - .
Caribbean Sea v Atlantic Ocean
‘
Port
{
© Spain’ TRINIDAD
B AND TOBAGO
Nationality: noun—Trinidadian(s), Tobagon-
ian(s); adjective—Trinidadian
Ethnic divisions: 43% Negro, 40% East Indian,
14% mixed, 1% white, 2% other
Religion: 26.8% Protestant, 31.2% Roman
Catholic, 23% Hindu, 6% Muslim, 18% unknown
Language: English
Literacy: 89%
Labor force: about 376,000 (1973 est.), about
15.4% agriculture, 18.7% mining, quarrying, and
manufacturing, 16.7% commerce; 16.2% construction
and utilities; 7.4% transportation and com-
munications; 21.8% services, 3.8% other
Organized labor: 30% of labor force','3d7fdca6d5555534ac30c709261c82ee9a0b28dd38aa2a0c9c26c14dcb505ffd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2c96acc0603b9259d3e7c08d9c8428c00d8adce947599259eb75695afc7767b',1977,'TN','Tunisia','people-and-society',508,'Population: 5,975,000 (January 1977), average
annual growth rate 2.3% (7-74 to 7-75)
CIA-RDP79-01051A000800010006-3
He
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TUNISIA/TURKEY
Nationality: noun—Tunisian(s); adjective—
Tunisian
Ethnic divisions: 98% Arab, 1% European, less
than 1% Jewish
Religion: 95% Muslim, 4% Christian, 1% Jewish
Language: Arabic (official), Arabic and French
(commerce)
Literacy: about 82%
Labor force: 1.4 million; 45% agriculture, 19%
manufacturing and construction, 5% trade and
finance, 3% transportation, communications, and
utilities, 2% mining; 25% underemployed; shortage of
skilled labor
Organized labor: 10% of labor force; General
Union of Tunisian Workers (UGTT), subordinate to
Destourian Socialist Party
Population: 41,516,000 (January 1977), average
annual growth rate 2.6% (current)
Nationality: noun—Turk(s); adjective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other
(mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16%
industry, 16% service; substantial shortage of skilled
labor; ample unskilled labor
Organized labor: 10% of labor force','8bec29970041ade40188956ac116f8256414d568ebf08dee642da4f8d351d7dc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19de5ac0e6bbf3c28a4cf0eeab8d47611517840fc2731c3798d0e3961697e264',1977,'TV','Tuvalu','people-and-society',512,'Population: 6,000, preliminary total from census of
8 December 1973
Ethnic divisions: Polynesian
Religion: Protestant
Literacy: less than 50%','495fd1ca473957dcb5b7523736253bfd8f74032343d5ab65d0d649ec8534faa0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d4bdf40ae94d4af1bd5c4096ea5451b48f815e8b27d61a0f49cb9e72d366333',1977,'UG','Uganda','people-and-society',515,'Population: 12,148,000 (January 1977), average
annual growth rate 3.4% (current)
Nationality: noun—Ugandan(s); adjective—
Ugandan
Ethnic divisions: 99% African, 1% European,
Asian, Arab
Religion: about 60% nominally Christian, 5%-10%
Muslim, rest animist
Language: English official; Luganda and Swahili
widely used; other Bantu and Nilotic languages
Literacy: about 20%-40%
Labor force: estimated 4.5 million, of which
about 250,000 in paid labor, remaining in subsistence
activities
Organized labor: 125,000 union members
Population: 258,106,000 (January 1977), average
annual growth rate 1.0% (current)
Nationality: noun—Soviet(s); adjective—Soviet
Ethnic divisions: 74% Slavic, 26% among some 170
ethnic groups
Religion: 70% atheist, 18% Russian Orthodox, 9%
Muslim, 3% other
Language: more than 200 languages and dialects
(at least 18 with more than 1 million speakers); 76%
Slavic group, 8% other Indo-European, 11% Altaic,
8% Uralian, 2% Caucasian
Literacy: 98.5% of population (ages 9-49)
Labor force: civilian 135 million (1976), 25%
agriculture, 75% industry and other non-agricultural
fields, unemployed not reported, shortage of skilled
labor reported','f6fa4b6694cc38e7aac22171d1549f19176ac22180182a6ea7b35ad1949dc360','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f8cb60e8e9093a7e000a13a59b1b186b30111b15969833bc27abe9fd724acf6',1977,'AE','United Arab Emirates','people-and-society',518,'Population: 656,000, preliminary total from 1975
census
Ethnic divisions: Arabs 72%; others include
Iranians, Pakistanis, and Indians
Religion: Muslim 96%, Christian, Hindu and other
4%
Language: Arabic
Literacy: 25% est. (1975)
Labor force: 203,000 (1975 est.); 85% in industry;
2% U.A.E. Arabs, 7% non-U.A.E. Arabs, 91%
Indians, Pakistanis, Iranians','347e807ee23d703df9019cdabd9547c74d565e1f1bb372c229310cff93be00f3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faacc480dc3a845a062a868e96bdb5dafc78c5238b8c120f2301b0955d963551',1977,'GB','United Kingdom','people-and-society',522,'Population: 56,043,000 (January 1977), average
annual growth rate 0.0% (current)
Nationality; $noun—Briton(s), British (collective
pl.); adjective—British
Ethnic divisions: 83% English, 9% Scottish, 5%
Welsh, 3% Irish
Religion: 27.0 million Church of England, 5.3
million Roman Catholic, 2.0 million Presbyterians,
760,000 Methodist, 450,000 Jews (registered )
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic (about
100,000 in Scotland)
Literacy: 98% to 99%
Labor force: (1974) 25.6 million; 1.6% agriculture,
1.4% mining, 30.7% manufacturing, 6.2% govern-
ment, 7.2% transportation and utilities, 5.2%
construction, 10.6% distributive trades, 25.3% all
services, 9.7% other; 2.1% unemployed
Organized labor: 40% of labor force
Population: 6,300,000 (January 1977), average
annual growth rate 2.3% (current)
Nationality: noun—Upper Voltan(s); adjective—
Upper Voltan
Ethnic divisions: more than 50 tribes; principal
tribe is Mossi (about 2.5 million), other important
groups are Gurunsi, Senufo, Lobi, Bobo, Mande, and
Fulani
Religion: majority of population animist, about
20% Muslim, 5% Christian (mainly Catholic)
Language: French official; tribal languages belong
to Sudanic family, spoken by 50% of the population
Literacy: 5%-10%
Labor force: about 95% of the economically active
population engaged in animal husbandry, subsistence
farming, and related agricultural pursuits; about
30,000 are wage earners; about 20% of male labor
force migrates annually to neighboring countries for
seasonal employment
Organized labor: 4 principal trade union groups','6f49365bc1a3c8e1315a8fa19f937248c846193da02b2fdf1fa450de746bb5b8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61e8475ec56c181684b022fb0085298ebc3fb6c1d6817a87f6d64473edb15417',1977,'UY','Uruguay','people-and-society',526,'Population: 2,788,000 (January 1977), average
annual growth rate 0.5% (10-68 to 5-75)
Nationality: noun—Uruguayan(s); adjective—
Uruguayan
Ethnic divisions: 85%-90% white, 5% Negro, 5%-
10% mestizo
Religion: 66% Roman Catholic (less than half
adult population attends church regularly)
Language: Spanish
216
Literacy: 90.5% for those 15 years of age or older
Labor force: 1,015,500 (1968 census); of those
employed in important sectors—25% government;
84% industry; 10% service; 23% other; 8%
agriculture, forestry, fishing and mining; no shortage
of skilled labor
Organized labor: about 25% of labor force
Population: 1,000 (official estimate for 1 July 1975)
Ethnic divisions: primarily Italians but also many
other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various modern
languages
Literacy: virtually complete
Labor force: approx. 700; Vatican City employees
divided into 8 categories—executives, officeworkers,
and salaried employees
Organized labor: none
Population: 12,366,000, excluding Indian jungle
population (January 1977), average annual growth
rate 3.1% (7-74 to 7-75)
Nationality: noun—Venezuelan(s); adjective—
Venezuelan
Ethnic divisions: 67% mestizo, 21% white, 10%
Negro, 2% Indian
Religion: 94% nominally Roman Catholic
Language: Spanish
Literacy: 74% (claimed, 1970 est.)
Labor force: million (1975); 24% agriculture, 6%
construction, 17% manufacturing, 6% transportation,
18% commerce, 25% services, 4% petroleum, utilities,
and other
Organized labor: 45% of labor force
Population: 47,101,000 (January 1977),
average annual growth rate 2.5% (current); Vietnam,
North, 25,070,000, average annual growth rate 2.3%
(current); Vietnam, South, 22,031,000, average
annual growth rate 2.9% (7-70 to 7-73)
Nationality: noun—Vietnamese (sing. & pl.);
adjective—Vietnamese
Ethnic divisions: 85%-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities include
Muong, Thai, Meo, Khmer, Man, Cham, and
mountain tribesman
Religion: Buddhism, Confucianism, Taoism,
Catholicism, Animism, Islam, and Protestantism
Language: Vietnamese, French, Chinese, English,
Khmer, tribal languages (Mon-Khmer and Malayo-
Polynesian)
Labor force: approximately 15 million, not
including military; about 70% agriculture and 8%
industry','8f0766634c7c5721c72e7ac9870585870af2ea9b62d4633fe90de3bbb20fe714','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02fc4b3123f649539de040595079fa84b272b0370201ed6b0746c56ee8622c53',1977,'WF','Wallis and Futuna','people-and-society',530,'Population: 9,000, official estimate for 1 July 1973
: CIA-RDP79-01051A000800010006-3
a
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
WALLIS AND FUTUNA/WESTERN SAHARA
(See reference map Vii}
Nationality: noun—Wallisian(s), Futunan(s), or
Wallis and Futuna Islander, adjective—Wallisian,
Futunan, or Wallis and Futuna Islanders
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','f7ef18102818a34c638484281f2a7fc8c4ae47e3cf59335741b2eac820ca641c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beebaca8efc5304204df7e48f774f0304762d0b982809f1fa493310ed584436b',1977,'EH','Western Sahara','people-and-society',534,'Population: 117,000 (official estimate for 1 July
1975)
Nationality: noun—Saharan(s); adjective—
Saharan
Ethnic divisions: Arab, Berber, and Negro nomads
Religion: Muslim
Language: local Arabic or Hassania
Literacy: among Spanish, probably nearly 100%;
among nomads, perhaps 5%
Labor force: 12,000; 50% agriculture, 50% other
Organized labor: none
Population: 157,000 (January 1977), average
annual growth rate 2.8% (7-65 to 7-75)
222
Nationality: noun—Western Samoan(s}; adjec-
tive—Western Samoa
Ethnic divisions: Polynesians, about 12,000
Euronesians (persons of European and Polynesian
blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London Missionary
Society)
Language: Samoan (Polynesian), English
Literacy: 85%-90% (education compulsory for all
children from 7-15 years)
Labor force: agriculture 19,148; mining and
manufacturing 1,716 (1961)
Organized labor: unorganized','b02e0158d8c721316a584376854742bb670a08af72ec218e3fa9f777833f39df','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51a2bfe2610acc16680249d3c2fcd724c918986dadba83f6fec7f1c878f0b08b',1977,'YE','Yemen','people-and-society',542,'Population: 6,791,000 (January 1977), average
annual growth rate 2.6% (7-71 to 7-72)
Nationality: noun—Yemeni(s); adjective—Yerneni
224
Approved For Release 2005/04/22
Ethnic divisions; 90% Arab, 10% Afro-Arab
(mixed)
Religion: 100% Muslim
Language: Arabic
Literacy: 15% (est.)
Labor force: almost entirely agriculture and
herding
Population: 21,650,000 (January 1977), average
annual growth rate 0.9% (current)
Nationality: noun—Yugoslav(s); adjective—
Yugoslav
Ethnic divisions: 39.7% Serb, 22.1% Croat, 8.4%
Muslims, 8.2% Slovene, 5.8% Macedonian, 2.5%
Montenegrin, 6.4% Albanian, 2.8% Hungarian, 4.6%
other (1971 census)
Religion: 41% Serbian Orthodox, 32% Roman
Catholic, 12% Muslim, 3% other, 12% none (1953
census)
Language: Serbo-Croatian, Slovene, Macedonian,
Albanian, Hungarian, and Italian
Literacy: 80.3% (1961)
Labor force: 18.5 million (1970); 49.6%
agriculture, 16% mining and manufacturing, 34.4%
other nonagricultural activities; reported unemploy-
ment averaged 8% of registered labor force (social
sector) in 1967
Population: 25,960,000 (January 1977), average
annual growth rate 2.8% (7-74 to 7-75)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ZAIRE
Nationality: noun—Zairian(s); adjective—Zairian
Ethnic divisions: over 200 African ethnic groups,
the majority are Bantu; four largest tribes—Mongo,
Luba, Kongo (all Bantu), and the Mangbetu-Azande
(Hamitic) make up about 45% of the population
Religion: 51% Christian, 45% animist, 4% other
Language: French, English, Lingala, Swahili,
Kikongo, and Chiluba are all classified as official
languages
Literacy: 5% fluent in French, about 35% have an
acquaintance with French
Labor force: about 8 million, but only about 18%
in wage structure','e98d0221f4838abb2910242d80138396a4ac44eee18888eff207b36b8c957647','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b142f7dfcc026798cdbb02efd4b8275ea70c0a652e406a0e29195dd65dff3e88',1977,'ZM','Zambia','people-and-society',544,'Population: 5,099,000 (January 1977), average
annual growth rate 2.7% (7-72 to 7-75)
Nationality: noun—Zambian(s); adjective—
Zambian
Ethnic divisions: 98.7% African, 1.1% European,
0.2% other
Religion: 82% animist, about 17% Christian, and
under 1% Hindu and Muslim
Language: English official; wide variety of
indigenous languages
Literacy: 28%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non-Africans; 15% mining, 9%
agriculture, 9% domestic service, 19% construction,
9% commerce, 10% manufacturing, 23% government
and miscellaneous services, 6% transport
Organized labor: 100,000 wage earners, primarily
in industrial sector, are unionized (early 1968)','68d28d44cea555162adb50d6c5cbad656e0123aca453024da62da3bc0b67b2fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
